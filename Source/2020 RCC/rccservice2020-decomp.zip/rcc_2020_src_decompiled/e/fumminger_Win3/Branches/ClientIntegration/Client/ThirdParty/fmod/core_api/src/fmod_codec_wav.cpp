// Address: 0x21e9960 | Name: _ZN4FMOD8CodecWav16getDescriptionExEv
FMOD::FMOD_CODEC_DESCRIPTION_EX *__cdecl FMOD::CodecWav::getDescriptionEx()
{
  stru_2ADB760.version = 65792;
  stru_2ADB760.timeunits = 10;
  stru_2ADB760.mType = FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_WAV_0;
  stru_2ADB760.mSize = 600;
  stru_2ADB760.name = "FMOD Wav Codec";
  stru_2ADB760.open = FMOD::CodecWav::openInternal;
  stru_2ADB760.close = FMOD::CodecWav::closeInternal;
  stru_2ADB760.read = FMOD::CodecWav::readInternal;
  stru_2ADB760.setposition = FMOD::CodecWav::setPositionInternal;
  stru_2ADB760.getposition = FMOD::CodecWav::getPositionInternal;
  stru_2ADB760.soundcreate = FMOD::CodecWav::soundCreateInternal;
  stru_2ADB760.canpoint = FMOD::CodecWav::canPointInternal;
  stru_2ADB760.getcontextinfo = FMOD::CodecWav::getContextInfoCallback;
  stru_2ADB760.setupcontext = FMOD::CodecWav::setupContextInternal;
  stru_2ADB760.cleanupcontext = FMOD::CodecWav::cleanupContextInternal;
  return &stru_2ADB760;
}


// Address: 0x21e9a30 | Name: _ZN4FMOD8CodecWav12openInternalEjP22FMOD_CREATESOUNDEXINFO
FMOD_RESULT_0 __fastcall FMOD::CodecWav::openInternal(
        FMOD::CodecWav *const this,
        FMOD_MODE usermode,
        FMOD_CREATESOUNDEXINFO *userexinfo)
{
  FMOD_RESULT_0 result; // eax
  unsigned int v5; // edx
  FMOD_CODEC_WAVEFORMAT *p_mWaveFormat; // rdi
  __int64 v7; // rcx
  const char **v8; // rdi
  unsigned int size; // esi
  FMOD::WAVE_FORMATEXTENSIBLE *mSrcFormat; // rsi
  FMOD::WAVE_FORMATEXTENSIBLE *p_mDestFormat; // rbp
  FMOD::WAVE_FORMATEXTENSIBLE *v12; // r12
  unsigned __int16 wFormatTag; // ax
  FMOD_CODEC_WAVEFORMAT *waveformat; // rbp
  unsigned __int16 v15; // cx
  unsigned int mReadBufferLength; // esi
  FMOD::WAVE_FORMATEXTENSIBLE *v17; // rax
  int nChannels; // edx
  unsigned int v19; // eax
  unsigned int v20; // edx
  FMOD::WAVE_FORMATEXTENSIBLE *v21; // rdi
  FMOD::WAVE_FORMATEXTENSIBLE *v22; // rsi
  unsigned int v23; // eax
  __int64 v24; // rdx
  __int64 i; // rcx
  unsigned __int16 wBitsPerSample; // r12
  unsigned __int8 *v27; // rax
  char wave[16]; // [rsp+0h] [rbp-48h] BYREF
  FMOD::WAVE_CHUNK chunk; // [rsp+10h] [rbp-38h] BYREF

  this->mType = FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_WAV_0;
  this->mDecoder = 0;
  this->mDecoderContext = 0;
  this->mDecoderContextMemory = 0;
  this->mPCMBufferMemory = 0;
  this->fileread = (FMOD_FILE_READ_CALLBACK)FMOD::Codec::defaultFileRead;
  this->mWaveFormatMemory = 0;
  this->mMetadata = 0;
  this->numsubsounds = 0;
  this->waveformat = 0;
  this->fileseek = (FMOD_FILE_SEEK_CALLBACK)FMOD::Codec::defaultFileSeek;
  this->waveformatversion = 3;
  this->metadata = FMOD::Codec::defaultMetaData;
  result = FMOD::File::read(this->mFile, &chunk, 1u, 8u, 0);
  if ( result )
    return result;
  if ( FMOD_strncmp((const char *)&chunk, "RIFF", 4) )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  result = FMOD::File::read(this->mFile, wave, 1u, 4u, 0);
  if ( result )
    return result;
  if ( FMOD_strncmp(wave, "WAVE", 4) )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  v5 = 56;
  p_mWaveFormat = &this->mWaveFormat;
  if ( (((_BYTE)this - 56) & 1) != 0 )
  {
    LOBYTE(this->mWaveFormat.name) = 0;
    p_mWaveFormat = (FMOD_CODEC_WAVEFORMAT *)((char *)&this->mWaveFormat.name + 1);
    LOBYTE(v5) = 55;
  }
  if ( ((unsigned __int8)p_mWaveFormat & 2) != 0 )
  {
    LOWORD(p_mWaveFormat->name) = 0;
    v5 -= 2;
    p_mWaveFormat = (FMOD_CODEC_WAVEFORMAT *)((char *)p_mWaveFormat + 2);
  }
  if ( ((unsigned __int8)p_mWaveFormat & 4) != 0 )
  {
    LODWORD(p_mWaveFormat->name) = 0;
    v5 -= 4;
    p_mWaveFormat = (FMOD_CODEC_WAVEFORMAT *)((char *)p_mWaveFormat + 4);
  }
  v7 = v5 >> 3;
  memset(p_mWaveFormat, 0, 8 * v7);
  v8 = &p_mWaveFormat->name + v7;
  if ( (v5 & 4) != 0 )
  {
    *(_DWORD *)v8 = 0;
    v8 = (const char **)((char *)v8 + 4);
  }
  if ( (v5 & 2) != 0 )
  {
    v8 = (const char **)((char *)v8 + 2);
    *((_WORD *)v8 - 1) = 0;
  }
  if ( (v5 & 1) != 0 )
    *(_BYTE *)v8 = 0;
  this->waveformat = &this->mWaveFormat;
  size = chunk.size;
  this->mSrcDataOffset = -1;
  this->mSyncPoint = 0;
  this->mNumSyncPoints = 0;
  result = FMOD::CodecWav::parseChunk(this, size);
  if ( result )
    return result;
  mSrcFormat = this->mSrcFormat;
  if ( !mSrcFormat )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  if ( this->mSrcDataOffset == -1 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mSrcFormat, "../../../core_api/src/fmod_codec_wav.cpp", 157);
    this->mSrcFormat = 0;
    this->mSrcDataOffset = 0;
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
  p_mDestFormat = &this->mDestFormat;
  *(_QWORD *)&this->mDestFormat.Format.wFormatTag = 0;
  *(_QWORD *)&this->mDestFormat.Format.nAvgBytesPerSec = 0;
  *(_QWORD *)&this->mDestFormat.Format.cbSize = 0;
  *(_QWORD *)&this->mDestFormat.SubFormat.Data1 = 0;
  *(_QWORD *)this->mDestFormat.SubFormat.Data4 = 0;
  v12 = this->mSrcFormat;
  this->mDestFormat.Format.wFormatTag = 1;
  wFormatTag = v12->Format.wFormatTag;
  if ( v12->Format.wFormatTag == 85 || wFormatTag == 80 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  if ( wFormatTag == 65534 )
  {
    if ( memcmp(&v12->SubFormat, &stru_596350, 0x10u) && memcmp(&v12->SubFormat, &stru_596340, 0x10u) )
      return FMOD_RESULT::FMOD_ERR_FORMAT_0;
    v21 = &this->mDestFormat;
    v22 = v12;
    v23 = 40;
    if ( (((_BYTE)this - 96) & 1) != 0 )
    {
      LOBYTE(p_mDestFormat->Format.wFormatTag) = v12->Format.wFormatTag;
      v22 = (FMOD::WAVE_FORMATEXTENSIBLE *)((char *)&v12->Format.wFormatTag + 1);
      v21 = (FMOD::WAVE_FORMATEXTENSIBLE *)((char *)&this->mDestFormat.Format.wFormatTag + 1);
      LOBYTE(v23) = 39;
    }
    if ( ((unsigned __int8)v21 & 2) != 0 )
    {
      v21->Format.wFormatTag = v22->Format.wFormatTag;
      v22 = (FMOD::WAVE_FORMATEXTENSIBLE *)((char *)v22 + 2);
      v21 = (FMOD::WAVE_FORMATEXTENSIBLE *)((char *)v21 + 2);
      v23 -= 2;
    }
    v24 = 0;
    for ( i = v23 >> 2; i; --i )
    {
      *(_DWORD *)&v21->Format.wFormatTag = *(_DWORD *)&v22->Format.wFormatTag;
      v22 = (FMOD::WAVE_FORMATEXTENSIBLE *)((char *)v22 + 4);
      v21 = (FMOD::WAVE_FORMATEXTENSIBLE *)((char *)v21 + 4);
    }
    if ( (v23 & 2) != 0 )
    {
      v21->Format.wFormatTag = v22->Format.wFormatTag;
      v24 = 2;
    }
    if ( (v23 & 1) != 0 )
      *((_BYTE *)&v21->Format.wFormatTag + v24) = *((_BYTE *)&v22->Format.wFormatTag + v24);
    waveformat = this->waveformat;
    wBitsPerSample = this->mDestFormat.Format.wBitsPerSample;
    waveformat->lengthpcm = 8
                          * (unsigned __int64)waveformat->lengthbytes
                          / wBitsPerSample
                          / this->mDestFormat.Format.nChannels;
    if ( memcmp(&this->mSrcFormat->SubFormat, &stru_596340, 0x10u) )
    {
      if ( wBitsPerSample != 16 )
      {
        if ( wBitsPerSample > 0x10u )
        {
          if ( wBitsPerSample != 24 )
          {
            if ( wBitsPerSample == 32 )
              goto LABEL_31;
            return FMOD_RESULT::FMOD_ERR_FORMAT_0;
          }
          goto LABEL_62;
        }
        if ( wBitsPerSample != 8 )
          return FMOD_RESULT::FMOD_ERR_FORMAT_0;
LABEL_58:
        waveformat->format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0;
        goto LABEL_32;
      }
LABEL_59:
      waveformat->format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
      goto LABEL_32;
    }
    waveformat->format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
    if ( wBitsPerSample != 32 )
      return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
  else
  {
    if ( (wFormatTag & 0xFFFD) != 1 )
      return FMOD_RESULT::FMOD_ERR_FORMAT_0;
    qmemcpy(p_mDestFormat, v12, 0x12u);
    waveformat = this->waveformat;
    v15 = this->mDestFormat.Format.wBitsPerSample;
    waveformat->lengthpcm = 8 * (unsigned __int64)waveformat->lengthbytes / v15 / this->mDestFormat.Format.nChannels;
    if ( wFormatTag != 3 )
    {
      if ( v15 != 16 )
      {
        if ( v15 > 0x10u )
        {
          if ( v15 != 24 )
          {
            if ( v15 == 32 )
            {
LABEL_31:
              waveformat->format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0;
              goto LABEL_32;
            }
            return FMOD_RESULT::FMOD_ERR_FORMAT_0;
          }
LABEL_62:
          waveformat->format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0;
          goto LABEL_32;
        }
        if ( v15 != 8 )
          return FMOD_RESULT::FMOD_ERR_FORMAT_0;
        goto LABEL_58;
      }
      goto LABEL_59;
    }
    waveformat->format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
    if ( v15 != 32 )
      return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
LABEL_32:
  result = FMOD_RESULT::FMOD_ERR_FORMAT_0;
  if ( (unsigned int)(waveformat->format - 1) <= 4 )
  {
    mReadBufferLength = this->mReadBufferLength;
    if ( mReadBufferLength )
    {
      v27 = (unsigned __int8 *)FMOD::MemPool::calloc(
                                 off_286F358->gSystemMemPool,
                                 mReadBufferLength,
                                 "../../../core_api/src/fmod_codec_wav.cpp",
                                 384,
                                 0);
      this->mReadBuffer = v27;
      if ( !v27 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      waveformat = this->waveformat;
    }
    v17 = this->mSrcFormat;
    nChannels = v17->Format.nChannels;
    waveformat->frequency = v17->Format.nSamplesPerSec;
    v19 = this->mLoopPoints[1];
    waveformat->channels = nChannels;
    v20 = this->mLoopPoints[0];
    if ( v19 <= v20 )
    {
      this->mDescription.mPoolType = FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_PCM;
    }
    else
    {
      waveformat->loopstart = v20;
      waveformat->loopend = v19;
      waveformat->mode = 2;
    }
    this->numsubsounds = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e9f90 | Name: j__ZN4FMOD8CodecWav12openInternalEjP22FMOD_CREATESOUNDEXINFO
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecWav::openInternal(
        FMOD_CODEC_STATE *codec,
        FMOD_MODE usermode,
        FMOD_CREATESOUNDEXINFO *userexinfo)
{
  return _ZN4FMOD8CodecWav12openInternalEjP22FMOD_CREATESOUNDEXINFO((FMOD::CodecWav *const)codec, usermode, userexinfo);
}


// Address: 0x21e9fa0 | Name: _ZN4FMOD8CodecWav13closeInternalEv
FMOD_RESULT_0 __fastcall FMOD::CodecWav::closeInternal(FMOD::CodecWav *const this)
{
  FMOD::CodecWav *mSrcFormat; // rsi
  unsigned __int8 *mReadBuffer; // rsi
  FMOD::SyncPointNamed *mSyncPoint; // rsi

  mSrcFormat = (FMOD::CodecWav *)this->mSrcFormat;
  if ( mSrcFormat && mSrcFormat != (FMOD::CodecWav *)&this->mSrcFormatMemory )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mSrcFormat, "../../../core_api/src/fmod_codec_wav.cpp", 438);
    this->mSrcFormat = 0;
  }
  mReadBuffer = this->mReadBuffer;
  if ( mReadBuffer )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mReadBuffer, "../../../core_api/src/fmod_codec_wav.cpp", 443);
    this->mReadBuffer = 0;
  }
  mSyncPoint = this->mSyncPoint;
  this->mReadBufferLength = 0;
  if ( mSyncPoint )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mSyncPoint, "../../../core_api/src/fmod_codec_wav.cpp", 449);
    this->mSyncPoint = 0;
  }
  this->mNumSyncPoints = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ea080 | Name: j__ZN4FMOD8CodecWav13closeInternalEv
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecWav::closeInternal(FMOD_CODEC_STATE *codec)
{
  return _ZN4FMOD8CodecWav13closeInternalEv((FMOD::CodecWav *const)codec);
}


// Address: 0x21ea090 | Name: _ZN4FMOD8CodecWav12readInternalEPvjPj
FMOD_RESULT_0 __fastcall FMOD::CodecWav::readInternal(
        FMOD::CodecWav *const this,
        void *buffer,
        unsigned int samples_in,
        unsigned int *samples_out)
{
  unsigned __int64 v6; // rbp
  FMOD_CODEC_WAVEFORMAT *waveformat; // rax
  int channels; // r13d
  __int64 v10; // rax
  FMOD_RESULT_0 result; // eax
  FMOD_CODEC_WAVEFORMAT *v12; // rsi
  unsigned int v13; // eax
  char v14; // r15
  unsigned __int64 v15; // rcx
  FMOD_SOUND_FORMAT_0 format; // eax
  FMOD_RESULT_0 v17; // eax
  FMOD_CODEC_WAVEFORMAT *v18; // rdx
  FMOD_RESULT_0 v19; // esi
  unsigned int v20; // ecx
  FMOD::File *mFile; // rdi
  unsigned __int64 v22; // rcx
  unsigned int *v23; // r8
  unsigned int v24; // edx
  __int64 v25; // rax
  unsigned int v26; // edi
  unsigned int v27; // ecx
  _BYTE *v28; // rdx
  char *v29; // rdx
  FMOD_CODEC_WAVEFORMAT *v30; // rdx
  unsigned int v31; // ecx
  unsigned __int64 v32; // rdi
  unsigned __int64 v33; // r8
  unsigned int pos; // [rsp+8h] [rbp-40h] BYREF
  unsigned int bytesread[15]; // [rsp+Ch] [rbp-3Ch] BYREF

  LODWORD(v6) = samples_in;
  waveformat = this->waveformat;
  channels = waveformat->channels;
  switch ( waveformat->format )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      v10 = 8;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      v10 = 16;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      v10 = 24;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      v10 = 32;
LABEL_3:
      v6 = (v10 * (unsigned __int64)samples_in) >> 3;
      break;
    default:
      break;
  }
  if ( (this->mSrcFormat->Format.wFormatTag & 0xFFFD) != 1 && this->mSrcFormat->Format.wFormatTag != 0xFFFE )
    return FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
  FMOD::File::tell(this->mFile, &pos);
  v12 = this->waveformat;
  v13 = this->mSrcDataOffset + v12->lengthbytes;
  if ( v13 <= pos )
    return FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
  v14 = 0;
  v15 = (unsigned int)(channels * v6);
  if ( v13 < (unsigned int)v15 + pos )
  {
    v14 = 1;
    v15 = v13 - pos;
  }
  format = v12->format;
  if ( format != FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0 )
  {
    if ( format == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0 )
    {
      v22 = v15 >> 1;
      mFile = this->mFile;
      v23 = samples_out;
      v24 = 2;
    }
    else
    {
      if ( (unsigned int)(format - 4) > 1 )
      {
        v17 = FMOD::File::read(this->mFile, buffer, 1u, v15, bytesread);
        v18 = this->waveformat;
        v19 = v17;
        v20 = v18->channels;
        if ( v20 )
        {
          switch ( v18->format )
          {
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
              v33 = 8;
              goto LABEL_39;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
              v33 = 16;
              goto LABEL_39;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
              v33 = 24;
              goto LABEL_39;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
              v33 = 32;
LABEL_39:
              LODWORD(v25) = (unsigned int)(8 * (unsigned __int64)bytesread[0] / v33) / v20;
              goto LABEL_40;
            default:
              *samples_out = bytesread[0];
              goto LABEL_16;
          }
        }
        goto LABEL_16;
      }
      mFile = this->mFile;
      v22 = v15 >> 2;
      v23 = samples_out;
      v24 = 4;
    }
    v19 = FMOD::File::read(mFile, buffer, v24, v22, v23);
    *samples_out /= this->waveformat->channels;
    goto LABEL_16;
  }
  v19 = FMOD::File::read(this->mFile, buffer, 1u, v15, bytesread);
  v25 = bytesread[0];
  v26 = bytesread[0] >> 2;
  if ( bytesread[0] >> 2 )
  {
    v27 = bytesread[0] >> 2;
    v28 = buffer;
    do
    {
      *v28 += 0x80;
      v28[1] += 0x80;
      v28[2] += 0x80;
      v28[3] += 0x80;
      v28 += 4;
      --v27;
    }
    while ( v27 );
    buffer = (char *)buffer + 4 * v26;
  }
  if ( (v25 & 3) != 0 )
  {
    v29 = (char *)buffer + (v25 & 3);
    do
    {
      *(_BYTE *)buffer += 0x80;
      buffer = (char *)buffer + 1;
    }
    while ( buffer != v29 );
  }
  v30 = this->waveformat;
  v31 = v30->channels;
  if ( v31 )
  {
    switch ( v30->format )
    {
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
        v32 = 8;
        goto LABEL_34;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
        v32 = 16;
        goto LABEL_34;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
        v32 = 24;
        goto LABEL_34;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
        v32 = 32;
LABEL_34:
        *samples_out = (unsigned int)(8 * v25 / v32) / v31;
        break;
      default:
LABEL_40:
        *samples_out = v25;
        break;
    }
  }
LABEL_16:
  if ( v14 )
    return FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
  result = v19;
  if ( v19 == FMOD_RESULT::FMOD_OK_0 )
    this->mPosition += *samples_out;
  return result;
}


// Address: 0x21ea380 | Name: j__ZN4FMOD8CodecWav12readInternalEPvjPj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecWav::readInternal(
        FMOD_CODEC_STATE *codec,
        void *buffer,
        unsigned int samples_in,
        unsigned int *samples_out)
{
  return _ZN4FMOD8CodecWav12readInternalEPvjPj((FMOD::CodecWav *const)codec, buffer, samples_in, samples_out);
}


// Address: 0x21ea390 | Name: _ZN4FMOD8CodecWav19setPositionInternalEijj
FMOD_RESULT_0 __fastcall FMOD::CodecWav::setPositionInternal(
        FMOD::CodecWav *const this,
        int subsound,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  unsigned int v6; // esi
  FMOD_RESULT_0 result; // eax
  unsigned int v8; // ebx
  unsigned int v9; // edx
  unsigned int v10; // edx
  FMOD_CODEC_WAVEFORMAT *waveformat; // rcx
  unsigned int lengthbytes; // eax
  int v13; // r9d
  FMOD::WAVE_FORMATEXTENSIBLE *mSrcFormat; // rdx
  unsigned int v15; // r9d
  unsigned __int64 lengthpcm; // rcx
  unsigned __int64 v17; // rdi
  unsigned int mReadBufferLength; // r8d
  unsigned int read; // [rsp+Ch] [rbp-102Ch] BYREF
  char buff[4096]; // [rsp+10h] [rbp-1028h] BYREF

  this->mPosition = position;
  if ( postype == 8 )
    return FMOD::File::seek(this->mFile, position + this->mSrcDataOffset, 0);
  v6 = 0;
  if ( position )
  {
    waveformat = this->waveformat;
    lengthbytes = waveformat->lengthbytes;
    switch ( waveformat->format )
    {
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
        v13 = 2;
        break;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
        v13 = 3;
        break;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
        v13 = 4;
        break;
      default:
        v13 = 1;
        break;
    }
    mSrcFormat = this->mSrcFormat;
    v15 = waveformat->channels * v13;
    if ( (mSrcFormat->Format.wFormatTag & 0xFFFD) == 1 && v15 )
    {
      lengthpcm = waveformat->lengthpcm;
      v17 = v15 * (lengthbytes / v15);
      v6 = v17 * position / lengthpcm;
    }
    else
    {
      mReadBufferLength = this->mReadBufferLength;
      if ( mReadBufferLength )
        lengthbytes = mReadBufferLength * (lengthbytes / mReadBufferLength);
      v17 = lengthbytes;
      lengthpcm = waveformat->lengthpcm;
      v6 = lengthbytes * (unsigned __int64)position / lengthpcm;
      if ( (mSrcFormat->Format.wFormatTag & 0xFFFD) != 1 || !v15 )
      {
        if ( mReadBufferLength )
          v6 = mReadBufferLength * (v6 / mReadBufferLength);
        goto LABEL_19;
      }
    }
    v6 = v15 * (v6 / v15);
LABEL_19:
    this->mPosition = lengthpcm * v6 / v17;
  }
  result = FMOD::File::seek(this->mFile, this->mSrcDataOffset + v6, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( this->mPCMBuffer && (v8 = position - this->mPosition) != 0 )
    {
      while ( 1 )
      {
        v9 = 1000;
        if ( v8 < 0x3E8 )
          v9 = v8;
        read = 0;
        result = FMOD::Codec::read(this, buff, v9, &read);
        v10 = read;
        this->mPosition += read;
        if ( result )
          break;
        if ( v10 <= v8 )
        {
          v8 -= v10;
          if ( v8 )
            continue;
        }
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
    else
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21ea570 | Name: j__ZN4FMOD8CodecWav19setPositionInternalEijj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecWav::setPositionInternal(
        FMOD_CODEC_STATE *codec,
        int subsound,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  return _ZN4FMOD8CodecWav19setPositionInternalEijj((FMOD::CodecWav *const)codec, subsound, position, postype);
}


// Address: 0x21ea580 | Name: _ZN4FMOD8CodecWav19getPositionInternalEPjj
FMOD_RESULT_0 __fastcall FMOD::CodecWav::getPositionInternal(
        FMOD::CodecWav *const this,
        unsigned int *position,
        FMOD_TIMEUNIT postype)
{
  *position = this->mPosition;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ea590 | Name: j__ZN4FMOD8CodecWav19getPositionInternalEPjj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecWav::getPositionInternal(
        FMOD_CODEC_STATE *codec,
        unsigned int *position,
        FMOD_TIMEUNIT postype)
{
  return _ZN4FMOD8CodecWav19getPositionInternalEPjj((FMOD::CodecWav *const)codec, position, postype);
}


// Address: 0x21ea5a0 | Name: _ZN4FMOD8CodecWav19soundCreateInternalEiP10FMOD_SOUND
FMOD_RESULT_0 __fastcall FMOD::CodecWav::soundCreateInternal(
        FMOD::CodecWav *const this,
        int subsound,
        FMOD_SOUND *sound)
{
  int mNumSyncPoints; // edx
  FMOD::SyncPointNamed *mSyncPoint; // rax
  __int64 v6; // rbp
  int v7; // ebx
  __int64 v9; // r10
  char *v10; // rax
  __int64 v11; // rcx
  __int64 v12; // rsi
  FMOD::SyncPointNamed *point; // [rsp+18h] [rbp-30h] BYREF

  mNumSyncPoints = this->mNumSyncPoints;
  if ( mNumSyncPoints )
  {
    mSyncPoint = this->mSyncPoint;
    if ( mSyncPoint )
    {
      v6 = 0;
      v7 = 0;
      if ( mNumSyncPoints > 0 )
      {
        while ( 1 )
        {
          v9 = *(_QWORD *)sound;
          v10 = (char *)mSyncPoint + v6;
          v11 = *(_QWORD *)(v10 + 28);
          v12 = *((unsigned int *)v10 + 11);
          point = (FMOD::SyncPointNamed *)v10;
          ++v7;
          v6 += 312;
          (*(void (__fastcall **)(FMOD_SOUND *, __int64, __int64, __int64, FMOD::SyncPointNamed **, _QWORD, _DWORD))(v9 + 264))(
            sound,
            v12,
            2,
            v11,
            &point,
            0,
            0);
          if ( this->mNumSyncPoints <= v7 )
            break;
          mSyncPoint = this->mSyncPoint;
        }
      }
      FMOD::SoundI::syncPointFixIndicies((FMOD::SoundI *const)sound);
      *((_QWORD *)sound + 32) = this->mSyncPoint;
      this->mSyncPoint = 0;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ea660 | Name: j__ZN4FMOD8CodecWav19soundCreateInternalEiP10FMOD_SOUND
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecWav::soundCreateInternal(FMOD_CODEC_STATE *codec, int subsound, FMOD_SOUND *sound)
{
  return _ZN4FMOD8CodecWav19soundCreateInternalEiP10FMOD_SOUND((FMOD::CodecWav *const)codec, subsound, sound);
}


// Address: 0x21ea670 | Name: _ZN4FMOD8CodecWav16canPointInternalEv
FMOD_RESULT_0 __fastcall FMOD::CodecWav::canPointInternal(FMOD::CodecWav *const this)
{
  FMOD::WAVE_FORMATEXTENSIBLE *mSrcFormat; // rbx
  FMOD_RESULT_0 v3; // ebp

  mSrcFormat = this->mSrcFormat;
  if ( !mSrcFormat )
    return FMOD_RESULT::FMOD_ERR_MEMORY_CANTPOINT_0;
  if ( mSrcFormat->Format.wFormatTag == 0xFFFE )
  {
    if ( memcmp(&mSrcFormat->SubFormat, &stru_596350, 0x10u) && memcmp(&mSrcFormat->SubFormat, &stru_596340, 0x10u) )
      return FMOD_RESULT::FMOD_ERR_MEMORY_CANTPOINT_0;
  }
  else if ( (mSrcFormat->Format.wFormatTag & 0xFFFD) != 1 )
  {
    return FMOD_RESULT::FMOD_ERR_MEMORY_CANTPOINT_0;
  }
  v3 = FMOD_RESULT::FMOD_ERR_MEMORY_CANTPOINT_0;
  if ( mSrcFormat->Format.wBitsPerSample != 8 )
    return FMOD_RESULT::FMOD_OK_0;
  return v3;
}


// Address: 0x21ea700 | Name: j__ZN4FMOD8CodecWav16canPointInternalEv
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecWav::canPointInternal(FMOD_CODEC_STATE *codec)
{
  return _ZN4FMOD8CodecWav16canPointInternalEv((FMOD::CodecWav *const)codec);
}


// Address: 0x21ea710 | Name: _ZN4FMOD8CodecWav22getContextInfoInternalEiPjS1_S1_
FMOD_RESULT_0 __fastcall FMOD::CodecWav::getContextInfoInternal(
        FMOD::CodecWav *const this,
        int numchannels,
        unsigned int *contextsize,
        unsigned int *pcmframesize,
        FMOD_MEMORY_TYPE *memtype)
{
  FMOD::WAVE_FORMATEXTENSIBLE *mSrcFormat; // rdx
  unsigned int wValidBitsPerSample; // eax

  if ( contextsize )
    *contextsize = 0;
  if ( !pcmframesize )
    return FMOD_RESULT::FMOD_OK_0;
  mSrcFormat = this->mSrcFormat;
  *pcmframesize = 64;
  if ( mSrcFormat && (mSrcFormat->Format.wFormatTag & 0xFFFD) != 1 )
  {
    wValidBitsPerSample = mSrcFormat->Samples.wValidBitsPerSample;
    if ( (_WORD)wValidBitsPerSample )
      *pcmframesize = wValidBitsPerSample;
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( this->mDescription.mPoolType == FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_ADPCM )
    return FMOD_RESULT::FMOD_OK_0;
  *pcmframesize = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ea770 | Name: _ZN4FMOD8CodecWav22getContextInfoCallbackEP16FMOD_CODEC_STATEiPjS3_S3_Pv
FMOD_RESULT_0 __fastcall FMOD::CodecWav::getContextInfoCallback(
        FMOD_CODEC_STATE *codec,
        int numchannels,
        unsigned int *contextsize,
        unsigned int *pcmframesize,
        FMOD_MEMORY_TYPE *memtype,
        void *userdata)
{
  if ( codec )
    return FMOD::CodecWav::getContextInfoInternal(
             (FMOD::CodecWav *const)codec,
             numchannels,
             contextsize,
             pcmframesize,
             memtype);
  if ( contextsize )
    *contextsize = 0;
  if ( pcmframesize )
    *pcmframesize = 64;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ea7a0 | Name: _ZN4FMOD8CodecWav20setupContextInternalEiiiPvPNS_5CodecE
FMOD_RESULT_0 __fastcall FMOD::CodecWav::setupContextInternal(
        FMOD::CodecWav *const this,
        int numchannels,
        int frequency,
        int subsound,
        void *contextmemory,
        FMOD::Codec_0 *sourcecodec)
{
  FMOD_RESULT_0 result; // eax
  FMOD::WAVE_FORMATEXTENSIBLE *v7; // rax
  unsigned __int16 wFormatTag; // dx

  if ( sourcecodec->mType != FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_WAV_0 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  v7 = *(FMOD::WAVE_FORMATEXTENSIBLE **)&sourcecodec[1].mDescription.mType;
  wFormatTag = v7->Format.wFormatTag;
  this->mSrcFormat = v7;
  if ( wFormatTag == 105 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  if ( wFormatTag == 17 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( (this->mMode & 0x200) != 0 && (wFormatTag & 0xFFFD) != 1 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  return result;
}


// Address: 0x21ea7f0 | Name: j__ZN4FMOD8CodecWav20setupContextInternalEiiiPvPNS_5CodecE
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecWav::setupContextInternal(
        FMOD_CODEC_STATE *codec,
        int numchannels,
        int frequency,
        int subsound,
        void *contextmemory,
        FMOD::Codec_0 *sourcecodec,
        void *userdata)
{
  return _ZN4FMOD8CodecWav20setupContextInternalEiiiPvPNS_5CodecE(
           (FMOD::CodecWav *const)codec,
           numchannels,
           frequency,
           subsound,
           contextmemory,
           sourcecodec);
}


// Address: 0x21ea800 | Name: _ZN4FMOD8CodecWav22cleanupContextInternalEv
FMOD_RESULT_0 __fastcall FMOD::CodecWav::cleanupContextInternal(FMOD::CodecWav *const this)
{
  this->mSrcFormat = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ea810 | Name: j__ZN4FMOD8CodecWav22cleanupContextInternalEv
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecWav::cleanupContextInternal(FMOD_CODEC_STATE *codec, void *userdata)
{
  return _ZN4FMOD8CodecWav22cleanupContextInternalEv((FMOD::CodecWav *const)codec);
}


// Address: 0x21ea820 | Name: _ZN4FMOD19FMOD_WriteWavHeaderEP8_IO_FILE17FMOD_SOUND_FORMATiij
FMOD_RESULT_0 __fastcall FMOD::FMOD_WriteWavHeader(
        FILE *fp,
        FMOD_SOUND_FORMAT_0 format,
        int numChannels,
        int sampleRate,
        unsigned int lengthBytes)
{
  FMOD_RESULT_0 result; // eax
  __int64 v6; // rax
  int v8; // r12d
  unsigned int v9; // ecx
  unsigned int v10; // r8d
  bool v11; // al
  char v12; // si
  unsigned __int16 v13; // dx
  const FMOD_GUID *v14; // rdx
  __int64 v15; // rax
  __int64 v16; // rdx
  FMOD::WAVE_CHUNK FmtHdr; // [rsp+10h] [rbp-88h] BYREF
  FMOD::WAVE_CHUNK DataChunk; // [rsp+20h] [rbp-78h] BYREF
  FMOD::WAVE_CHUNK WavHeader; // [rsp+30h] [rbp-68h] BYREF
  FMOD::WAVE_FORMATEXTENSIBLE Fmt; // [rsp+40h] [rbp-58h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !fp )
    return result;
  v6 = (unsigned int)(format - 1);
  if ( (unsigned int)v6 > 4 )
  {
    v8 = 0;
    fseek(fp, 0, 0);
    strcpy((char *)&FmtHdr, "fmt (");
    HIWORD(FmtHdr.size) = 0;
    v9 = sampleRate;
    v10 = lengthBytes;
    if ( numChannels > 2 )
      goto LABEL_4;
LABEL_14:
    memset(&Fmt.Format.cbSize, 0, 24);
    v11 = 0;
    v12 = 0;
    v13 = 1;
    goto LABEL_6;
  }
  v8 = dword_596320[v6];
  fseek(fp, 0, 0);
  strcpy((char *)&FmtHdr, "fmt (");
  v11 = format == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
  HIWORD(FmtHdr.size) = 0;
  v9 = sampleRate;
  v10 = lengthBytes;
  if ( format == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0 || numChannels > 2 )
    goto LABEL_5;
  if ( v8 <= 16 )
    goto LABEL_14;
LABEL_4:
  v11 = 0;
LABEL_5:
  memset(&Fmt.Format.cbSize, 0, 24);
  v12 = 1;
  v13 = -2;
LABEL_6:
  Fmt.Format.nSamplesPerSec = v9;
  Fmt.Format.wFormatTag = v13;
  Fmt.Format.nChannels = numChannels;
  Fmt.Format.wBitsPerSample = v8;
  Fmt.Format.nAvgBytesPerSec = (int)(v8 * numChannels * v9) / 8;
  Fmt.Format.nBlockAlign = v8 * numChannels / 8;
  if ( v12 )
  {
    Fmt.Format.cbSize = 22;
    v14 = &stru_596340;
    Fmt.Samples.wValidBitsPerSample = v8;
    if ( !v11 )
      v14 = &stru_596350;
    v15 = *(_QWORD *)&v14->Data1;
    v16 = *(_QWORD *)v14->Data4;
    *(_QWORD *)&Fmt.SubFormat.Data1 = v15;
    *(_QWORD *)Fmt.SubFormat.Data4 = v16;
  }
  DataChunk.size = v10;
  WavHeader.size = v10 + 56;
  qmemcpy(&DataChunk, "data", 4);
  qmemcpy(&WavHeader, "RIFF", 4);
  fwrite(&WavHeader, 8u, 1u, fp);
  fwrite("WAVE", 4u, 1u, fp);
  fwrite(&FmtHdr, 8u, 1u, fp);
  fwrite(&Fmt, 0x28u, 1u, fp);
  fwrite(&DataChunk, 8u, 1u, fp);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21eaa80 | Name: _ZN4FMOD17FMOD_WriteWavFileEPKcPv17FMOD_SOUND_FORMATiii
FMOD_RESULT_0 __fastcall FMOD::FMOD_WriteWavFile(
        const char *filename,
        void *data,
        FMOD_SOUND_FORMAT_0 format,
        int numchannels,
        int length,
        int sampleRate)
{
  FMOD_RESULT_0 v8; // ebx
  FILE *v10; // rax
  FILE *v11; // r14
  unsigned __int64 v12; // r15
  __int64 v13; // r15
  size_t v14; // r15
  _BYTE *v15; // rax

  if ( (unsigned int)(format - 4) <= 1 || (v8 = FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0, (unsigned int)(format - 1) <= 1) )
  {
    v8 = FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0;
    v10 = fopen(filename, "wb");
    v11 = v10;
    if ( v10 )
    {
      LODWORD(v12) = length;
      switch ( format )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
          v13 = 8;
          goto LABEL_7;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          v13 = 16;
          goto LABEL_7;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          v13 = 24;
          goto LABEL_7;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          v13 = 32;
LABEL_7:
          v12 = ((unsigned __int64)(unsigned int)length * v13) >> 3;
          break;
        default:
          break;
      }
      v14 = (unsigned int)(numchannels * v12);
      v8 = FMOD::FMOD_WriteWavHeader(v10, format, numchannels, sampleRate, v14);
      if ( v8 == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( format == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0 && (_DWORD)v14 )
        {
          v15 = data;
          do
            *v15++ += 0x80;
          while ( v15 != (char *)data + (unsigned int)(v14 - 1) + 1 );
        }
        v8 = FMOD_RESULT::FMOD_OK_0;
        if ( v14 != fwrite(data, 1u, v14, v11) )
          v8 = FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
      }
      fclose(v11);
    }
  }
  return v8;
}


