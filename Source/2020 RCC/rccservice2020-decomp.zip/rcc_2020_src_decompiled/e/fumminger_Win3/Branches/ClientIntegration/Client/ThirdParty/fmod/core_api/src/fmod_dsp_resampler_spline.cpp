// Address: 0x21e1290 | Name: FMOD_Resampler_Spline
void __fastcall FMOD_Resampler_Spline(
        float *out,
        int outlength,
        void *src,
        FMOD_SOUND_FORMAT_0 srcformat,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed,
        int channels)
{
  FMOD_SINT64 mValue; // r8
  int v9; // r9d
  FMOD_UINT64 v10; // rsi
  unsigned int mHi; // eax
  float v12; // xmm7_4
  float v13; // xmm8_4
  float v14; // xmm10_4
  float v15; // xmm4_4
  float v16; // xmm11_4
  float v17; // xmm9_4
  float v18; // xmm14_4
  FMOD_SINT64 v19; // r12
  FMOD_UINT64 v20; // rbp
  int v21; // r15d
  float v22; // xmm9_4
  __int64 v23; // rcx
  __int64 v24; // r11
  int v25; // r8d
  __int64 v26; // r10
  __int64 v27; // rax
  char *v28; // r11
  char *v29; // r10
  float v30; // xmm5_4
  float v31; // xmm4_4
  float v32; // xmm7_4
  float v33; // xmm3_4
  float v34; // xmm6_4
  float v35; // xmm10_4
  FMOD_SINT64 v36; // r12
  FMOD_UINT64 v37; // rbp
  int v38; // r15d
  float v39; // xmm10_4
  unsigned int v40; // r9d
  __int64 v41; // rax
  __int64 v42; // r10
  int v43; // r9d
  __int64 v44; // r10
  int v45; // esi
  char *v46; // r11
  char *v47; // r10
  float v48; // xmm5_4
  float v49; // xmm7_4
  float v50; // xmm4_4
  float v51; // xmm8_4
  float v52; // xmm6_4
  float v53; // xmm9_4
  FMOD_SINT64 v54; // r12
  FMOD_UINT64 v55; // rbp
  int v56; // r15d
  float v57; // xmm11_4
  __int64 v58; // rcx
  __int64 v59; // r11
  int v60; // r8d
  __int64 v61; // r10
  __int64 v62; // rax
  char *v63; // r11
  char *v64; // r10
  float v65; // xmm5_4
  float v66; // xmm7_4
  float v67; // xmm4_4
  float v68; // xmm8_4
  float v69; // xmm6_4
  float v70; // xmm10_4
  float v71; // xmm11_4
  __int64 v72; // rcx
  int v73; // r13d
  int v74; // r12d
  __int64 v75; // rsi
  __int64 v76; // rcx
  unsigned __int8 *v77; // r8
  unsigned __int8 *v78; // rsi
  float v79; // xmm5_4
  float v80; // xmm7_4
  float v81; // xmm4_4
  float v82; // xmm8_4
  float v83; // xmm6_4
  float v84; // xmm10_4
  FMOD_SINT64 v85; // r12
  FMOD_UINT64 v86; // rbp
  int v87; // r15d
  float v88; // xmm11_4
  __int64 v89; // rcx
  __int64 v90; // r11
  int v91; // r8d
  __int64 v92; // r10
  __int64 v93; // rax
  char *v94; // r11
  char *v95; // r10
  float v96; // xmm5_4
  float v97; // xmm7_4
  float v98; // xmm4_4
  float v99; // xmm8_4
  float v100; // xmm6_4
  float v101; // xmm10_4
  FMOD_SINT64 v102; // r9
  FMOD_UINT64 v103; // rcx
  unsigned int v104; // eax
  float v105; // xmm8_4
  __int64 v106; // r10
  float v107; // xmm9_4
  float v108; // xmm11_4
  float v109; // xmm10_4
  float v110; // xmm2_4
  float v111; // xmm5_4
  float v112; // xmm13_4
  FMOD_SINT64 v113; // r9
  FMOD_UINT64 v114; // rcx
  unsigned int v115; // eax
  __int64 v116; // r10
  float v117; // xmm4_4
  float v118; // xmm11_4
  float v119; // xmm8_4
  float v120; // xmm10_4
  float v121; // xmm9_4
  float v122; // xmm14_4
  float v123; // xmm7_4
  FMOD_SINT64 v124; // r8
  int v125; // r9d
  FMOD_UINT64 v126; // rsi
  unsigned int v127; // eax
  __int64 v128; // rbx
  float v129; // xmm7_4
  float v130; // xmm8_4
  float v131; // xmm10_4
  float v132; // xmm4_4
  float v133; // xmm11_4
  float v134; // xmm9_4
  float v135; // xmm14_4
  FMOD_SINT64 v136; // r9
  FMOD_UINT64 v137; // rcx
  unsigned int v138; // eax
  __int64 v139; // r10
  float v140; // xmm7_4
  float v141; // xmm4_4
  float v142; // xmm8_4
  float v143; // xmm10_4
  float v144; // xmm11_4
  float v145; // xmm9_4
  float v146; // xmm14_4
  FMOD_UINT64 v147; // [rsp+2Ch] [rbp-60h]
  FMOD_SINT64 v149; // [rsp+3Ch] [rbp-50h]
  int outlengtha; // [rsp+4Ch] [rbp-40h]

  outlengtha = outlength;
  switch ( srcformat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      if ( channels == 1 )
      {
        if ( outlength )
        {
          mValue = speed->mValue;
          v9 = outlength;
          v10 = position->mValue + mValue;
          do
          {
            ++out;
            mHi = position->mHi;
            v12 = (float)(int)position->mLo * 2.3283064e-10;
            v13 = (float)*((char *)src + mHi - 2) * 0.0078125;
            v14 = (float)*((char *)src + mHi - 1) * 0.0078125;
            v15 = (float)*((char *)src + mHi) * 0.0078125;
            v16 = (float)*((char *)src + mHi + 1) * 0.0078125;
            v17 = (float)*((char *)src + mHi + 2) * 0.0078125;
            v18 = (float)*((char *)src + mHi + 3) * 0.0078125;
            *(out - 1) = (float)((float)(v12 * 0.041666668)
                               * (float)((float)((float)((float)(v16 - v14) * 16.0)
                                               + (float)((float)(v13 - v17) + (float)(v13 - v17)))
                                       + (float)((float)((float)((float)((float)((float)((float)(v16 + v14) * 16.0) - v13)
                                                                       - (float)(30.0 * v15))
                                                               - v17)
                                                       + (float)((float)((float)((float)((float)((float)((float)((float)(66.0 * v16) - (float)(70.0 * v15)) - (float)(33.0 * v17))
                                                                                               + (float)(39.0 * v14))
                                                                                       + (float)(7.0 * v18))
                                                                               - (float)(9.0 * v13))
                                                                       + (float)((float)((float)((float)((float)((float)((float)((float)(126.0 * v15) - (float)(124.0 * v16)) + (float)(61.0 * v17)) - (float)(64.0 * v14)) - (float)(12.0 * v18))
                                                                                               + (float)(13.0 * v13))
                                                                                       + (float)((float)((float)((float)((float)(v16 - v15) * 50.0) + (float)((float)(v14 - v17) * 25.0)) + (float)((float)(v18 - v13) * 5.0))
                                                                                               * v12))
                                                                               * v12))
                                                               * v12))
                                               * v12)))
                       + v15;
            position->mValue = v10;
            v10 += mValue;
            --v9;
          }
          while ( v9 );
        }
      }
      else if ( outlength )
      {
        v36 = speed->mValue;
        v37 = position->mValue + speed->mValue;
        v38 = outlength;
        do
        {
          v39 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v40 = position->mHi;
            v41 = 0;
            v42 = v40;
            v43 = channels * v40;
            v44 = channels * (v42 - 2);
            v45 = channels + channels + v43;
            v46 = (char *)src + v44;
            v47 = (char *)src + v44 + channels;
            do
            {
              v48 = (float)v46[v41] * 0.0078125;
              v49 = (float)v47[v41] * 0.0078125;
              v50 = (float)*((char *)src + (unsigned int)(v43 + v41)) * 0.0078125;
              v51 = (float)*((char *)src + (unsigned int)(channels + v43 + v41)) * 0.0078125;
              v52 = (float)*((char *)src + (unsigned int)(v45 + v41)) * 0.0078125;
              v53 = (float)*((char *)src + (unsigned int)(channels + v45 + v41)) * 0.0078125;
              out[v41++] = (float)((float)((float)((float)((float)(v51 - v49) * 16.0)
                                                 + (float)((float)(v48 - v52) + (float)(v48 - v52)))
                                         + (float)((float)((float)((float)((float)((float)((float)(v51 + v49) * 16.0)
                                                                                 - v48)
                                                                         - (float)(30.0 * v50))
                                                                 - v52)
                                                         + (float)((float)((float)((float)((float)((float)((float)((float)(66.0 * v51) - (float)(70.0 * v50)) - (float)(33.0 * v52))
                                                                                                 + (float)(39.0 * v49))
                                                                                         + (float)(7.0 * v53))
                                                                                 - (float)(9.0 * v48))
                                                                         + (float)((float)((float)((float)((float)((float)((float)((float)(v50 * 126.0) - (float)(124.0 * v51)) + (float)(61.0 * v52)) - (float)(64.0 * v49)) - (float)(12.0 * v53))
                                                                                                 + (float)(13.0 * v48))
                                                                                         + (float)((float)((float)((float)((float)(v51 - v50) * 50.0) + (float)((float)(v49 - v52) * 25.0)) + (float)((float)(v53 - v48) * 5.0))
                                                                                                 * v39))
                                                                                 * v39))
                                                                 * v39))
                                                 * v39))
                                 * (float)(0.041666668 * v39))
                         + v50;
            }
            while ( channels > (int)v41 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v37;
          v37 += v36;
          --v38;
        }
        while ( v38 );
      }
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      if ( channels == 1 )
      {
        if ( outlength )
        {
          v136 = speed->mValue;
          v137 = position->mValue + v136;
          do
          {
            ++out;
            v138 = position->mHi;
            v139 = 2LL * v138;
            v140 = (float)(int)position->mLo * 2.3283064e-10;
            v141 = (float)*(__int16 *)((char *)src + v139) * 0.000030517578;
            v142 = (float)*(__int16 *)((char *)src + v139 - 4) * 0.000030517578;
            v143 = (float)*(__int16 *)((char *)src + v139 - 2) * 0.000030517578;
            v144 = (float)*((__int16 *)src + v138 + 1) * 0.000030517578;
            v145 = (float)*((__int16 *)src + v138 + 2) * 0.000030517578;
            v146 = (float)*((__int16 *)src + v138 + 3) * 0.000030517578;
            *(out - 1) = (float)((float)(v140 * 0.041666668)
                               * (float)((float)((float)((float)(v144 - v143) * 16.0)
                                               + (float)((float)(v142 - v145) + (float)(v142 - v145)))
                                       + (float)((float)((float)((float)((float)((float)((float)(v144 + v143) * 16.0)
                                                                               - v142)
                                                                       - (float)(30.0 * v141))
                                                               - v145)
                                                       + (float)((float)((float)((float)((float)((float)((float)((float)(66.0 * v144) - (float)(70.0 * v141)) - (float)(33.0 * v145))
                                                                                               + (float)(39.0 * v143))
                                                                                       + (float)(7.0 * v146))
                                                                               - (float)(9.0 * v142))
                                                                       + (float)((float)((float)((float)((float)((float)((float)((float)(126.0 * v141) - (float)(124.0 * v144)) + (float)(61.0 * v145)) - (float)(64.0 * v143)) - (float)(12.0 * v146))
                                                                                               + (float)(13.0 * v142))
                                                                                       + (float)((float)((float)((float)((float)(v144 - v141) * 50.0) + (float)((float)(v143 - v145) * 25.0)) + (float)((float)(v146 - v142) * 5.0))
                                                                                               * v140))
                                                                               * v140))
                                                               * v140))
                                               * v140)))
                       + v141;
            position->mValue = v137;
            v137 += v136;
            --outlength;
          }
          while ( outlength );
        }
      }
      else if ( outlength )
      {
        v54 = speed->mValue;
        v55 = position->mValue + speed->mValue;
        v56 = outlength;
        do
        {
          v57 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v58 = position->mHi;
            v59 = 2 * v58 - 4;
            v60 = channels + v58 * channels;
            v61 = channels * (v59 + 2);
            v62 = 0;
            v63 = (char *)src + channels * v59;
            v64 = (char *)src + v61;
            do
            {
              v65 = (float)*(__int16 *)&v63[2 * v62] * 0.000030517578;
              v66 = (float)*(__int16 *)&v64[2 * v62] * 0.000030517578;
              v67 = (float)*((__int16 *)src + (unsigned int)(v58 * channels + v62)) * 0.000030517578;
              v68 = (float)*((__int16 *)src + (unsigned int)(v60 + v62)) * 0.000030517578;
              v69 = (float)*((__int16 *)src + (unsigned int)(channels + v60 + v62)) * 0.000030517578;
              v70 = (float)*((__int16 *)src + (unsigned int)(channels + channels + v60 + v62)) * 0.000030517578;
              out[v62++] = (float)((float)((float)((float)((float)(v68 - v66) * 16.0)
                                                 + (float)((float)(v65 - v69) + (float)(v65 - v69)))
                                         + (float)((float)((float)((float)((float)((float)((float)(v68 + v66) * 16.0)
                                                                                 - v65)
                                                                         - (float)(30.0 * v67))
                                                                 - v69)
                                                         + (float)((float)((float)((float)((float)((float)((float)((float)(66.0 * v68) - (float)(70.0 * v67)) - (float)(33.0 * v69))
                                                                                                 + (float)(39.0 * v66))
                                                                                         + (float)(7.0 * v70))
                                                                                 - (float)(9.0 * v65))
                                                                         + (float)((float)((float)((float)((float)((float)((float)((float)(126.0 * v67) - (float)(v68 * 124.0)) + (float)(61.0 * v69)) - (float)(64.0 * v66)) - (float)(12.0 * v70))
                                                                                                 + (float)(13.0 * v65))
                                                                                         + (float)((float)((float)((float)((float)(v68 - v67) * 50.0) + (float)((float)(v66 - v69) * 25.0)) + (float)((float)(v70 - v65) * 5.0))
                                                                                                 * v57))
                                                                                 * v57))
                                                                 * v57))
                                                 * v57))
                                 * (float)(0.041666668 * v57))
                         + v67;
            }
            while ( channels > (int)v62 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v55;
          v55 += v54;
          --v56;
        }
        while ( v56 );
      }
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      if ( channels == 1 )
      {
        if ( outlength )
        {
          v124 = speed->mValue;
          v125 = outlength;
          v126 = position->mValue + v124;
          do
          {
            v127 = position->mHi;
            v128 = 3LL * v127;
            v129 = (float)(int)position->mLo * 2.3283064e-10;
            v130 = (float)((((unsigned __int8)*((char *)src + v128 - 4) << 24)
                          | ((unsigned __int8)*((char *)src + v128 - 6) << 8)
                          | ((unsigned __int8)*((char *)src + v128 - 5) << 16)) >> 8)
                 * 0.00000011920929;
            v131 = (float)((((unsigned __int8)*((char *)src + v128 - 1) << 24)
                          | ((unsigned __int8)*((char *)src + v128 - 3) << 8)
                          | ((unsigned __int8)*((char *)src + v128 - 2) << 16)) >> 8)
                 * 0.00000011920929;
            v132 = (float)(((*((unsigned __int8 *)src + v128 + 2) << 24)
                          | (*((unsigned __int8 *)src + v128) << 8)
                          | (*((unsigned __int8 *)src + v128 + 1) << 16)) >> 8)
                 * 0.00000011920929;
            ++out;
            v133 = (float)(((*((unsigned __int8 *)src + 3 * v127 + 5) << 24)
                          | (*((unsigned __int8 *)src + 3 * v127 + 3) << 8)
                          | (*((unsigned __int8 *)src + 3 * v127 + 4) << 16)) >> 8)
                 * 0.00000011920929;
            v134 = (float)(((*((unsigned __int8 *)src + 3 * v127 + 8) << 24)
                          | (*((unsigned __int8 *)src + 3 * v127 + 6) << 8)
                          | (*((unsigned __int8 *)src + 3 * v127 + 7) << 16)) >> 8)
                 * 0.00000011920929;
            v135 = (float)(((*((unsigned __int8 *)src + 3 * v127 + 11) << 24)
                          | (*((unsigned __int8 *)src + 3 * v127 + 9) << 8)
                          | (*((unsigned __int8 *)src + 3 * v127 + 10) << 16)) >> 8)
                 * 0.00000011920929;
            *(out - 1) = (float)((float)(v129 * 0.041666668)
                               * (float)((float)((float)((float)(v133 - v131) * 16.0)
                                               + (float)((float)(v130 - v134) + (float)(v130 - v134)))
                                       + (float)((float)((float)((float)((float)((float)((float)(v133 + v131) * 16.0)
                                                                               - v130)
                                                                       - (float)(30.0 * v132))
                                                               - v134)
                                                       + (float)((float)((float)((float)((float)((float)((float)((float)(66.0 * v133) - (float)(70.0 * v132)) - (float)(33.0 * v134))
                                                                                               + (float)(39.0 * v131))
                                                                                       + (float)(7.0 * v135))
                                                                               - (float)(9.0 * v130))
                                                                       + (float)((float)((float)((float)((float)((float)((float)((float)(126.0 * v132) - (float)(124.0 * v133)) + (float)(61.0 * v134)) - (float)(64.0 * v131)) - (float)(12.0 * v135))
                                                                                               + (float)(13.0 * v130))
                                                                                       + (float)((float)((float)((float)((float)(v133 - v132) * 50.0) + (float)((float)(v131 - v134) * 25.0)) + (float)((float)(v135 - v130) * 5.0))
                                                                                               * v129))
                                                                               * v129))
                                                               * v129))
                                               * v129)))
                       + v132;
            position->mValue = v126;
            v126 += v124;
            --v125;
          }
          while ( v125 );
        }
      }
      else if ( outlength )
      {
        v149 = speed->mValue;
        v147 = position->mValue + speed->mValue;
        do
        {
          v71 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v72 = position->mHi;
            v73 = v72 * channels;
            v74 = channels + v72 * channels;
            v75 = 3 * v72 - 6;
            v76 = 0;
            v77 = (unsigned __int8 *)src + channels * v75;
            v78 = (unsigned __int8 *)src + channels * (v75 + 3);
            do
            {
              v79 = (float)(((v77[2] << 24) | (*v77 << 8) | (v77[1] << 16)) >> 8) * 0.00000011920929;
              v80 = (float)(((v78[2] << 24) | (*v78 << 8) | (v78[1] << 16)) >> 8) * 0.00000011920929;
              v81 = (float)(((*((unsigned __int8 *)src + 3 * (unsigned int)(v73 + v76) + 2) << 24)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(v73 + v76)) << 8)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(v73 + v76) + 1) << 16)) >> 8)
                  * 0.00000011920929;
              v77 += 3;
              v78 += 3;
              v82 = (float)(((*((unsigned __int8 *)src + 3 * (unsigned int)(v74 + v76) + 2) << 24)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(v74 + v76)) << 8)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(v74 + v76) + 1) << 16)) >> 8)
                  * 0.00000011920929;
              v83 = (float)(((*((unsigned __int8 *)src + 3 * (unsigned int)(channels + v74 + v76) + 2) << 24)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(channels + v74 + v76)) << 8)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(channels + v74 + v76) + 1) << 16)) >> 8)
                  * 0.00000011920929;
              v84 = (float)(((*((unsigned __int8 *)src + 3 * (unsigned int)(v76 + channels + channels + v74) + 2) << 24)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(v76 + channels + channels + v74)) << 8)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(v76 + channels + channels + v74) + 1) << 16)) >> 8)
                  * 0.00000011920929;
              out[v76++] = (float)((float)((float)((float)((float)(v82 - v80) * 16.0)
                                                 + (float)((float)(v79 - v83) + (float)(v79 - v83)))
                                         + (float)((float)((float)((float)((float)((float)((float)(v82 + v80) * 16.0)
                                                                                 - v79)
                                                                         - (float)(30.0 * v81))
                                                                 - v83)
                                                         + (float)((float)((float)((float)((float)((float)((float)((float)(66.0 * v82) - (float)(70.0 * v81)) - (float)(33.0 * v83))
                                                                                                 + (float)(39.0 * v80))
                                                                                         + (float)(7.0 * v84))
                                                                                 - (float)(9.0 * v79))
                                                                         + (float)((float)((float)((float)((float)((float)((float)((float)(126.0 * v81) - (float)(v82 * 124.0)) + (float)(61.0 * v83)) - (float)(64.0 * v80)) - (float)(12.0 * v84))
                                                                                                 + (float)(13.0 * v79))
                                                                                         + (float)((float)((float)((float)((float)(v82 - v81) * 50.0) + (float)((float)(v80 - v83) * 25.0)) + (float)((float)(v84 - v79) * 5.0))
                                                                                                 * v71))
                                                                                 * v71))
                                                                 * v71))
                                                 * v71))
                                 * (float)(0.041666668 * v71))
                         + v81;
            }
            while ( channels > (int)v76 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v147;
          v147 += v149;
          --outlengtha;
        }
        while ( outlengtha );
      }
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      if ( channels == 1 )
      {
        if ( outlength )
        {
          v113 = speed->mValue;
          v114 = position->mValue + v113;
          do
          {
            ++out;
            v115 = position->mHi;
            v116 = 4LL * v115;
            v117 = (float)*(int *)((char *)src + v116) * 4.6566129e-10;
            v118 = (float)*((int *)src + v115 + 1) * 4.6566129e-10;
            v119 = (float)*(int *)((char *)src + v116 - 8) * 4.6566129e-10;
            v120 = (float)*(int *)((char *)src + v116 - 4) * 4.6566129e-10;
            v121 = (float)*((int *)src + v115 + 2) * 4.6566129e-10;
            v122 = (float)*((int *)src + v115 + 3) * 4.6566129e-10;
            v123 = (float)(int)position->mLo * 2.3283064e-10;
            *(out - 1) = (float)((float)(v123 * 0.041666668)
                               * (float)((float)((float)((float)(v118 - v120) * 16.0)
                                               + (float)((float)(v119 - v121) + (float)(v119 - v121)))
                                       + (float)((float)((float)((float)((float)((float)((float)(v118 + v120) * 16.0)
                                                                               - v119)
                                                                       - (float)(30.0 * v117))
                                                               - v121)
                                                       + (float)((float)((float)((float)((float)((float)((float)((float)(66.0 * v118) - (float)(70.0 * v117)) - (float)(33.0 * v121))
                                                                                               + (float)(39.0 * v120))
                                                                                       + (float)(7.0 * v122))
                                                                               - (float)(9.0 * v119))
                                                                       + (float)((float)((float)((float)((float)((float)((float)((float)(126.0 * v117) - (float)(124.0 * v118)) + (float)(61.0 * v121)) - (float)(64.0 * v120)) - (float)(12.0 * v122))
                                                                                               + (float)(13.0 * v119))
                                                                                       + (float)((float)((float)((float)((float)(v118 - v117) * 50.0) + (float)((float)(v120 - v121) * 25.0)) + (float)((float)(v122 - v119) * 5.0))
                                                                                               * v123))
                                                                               * v123))
                                                               * v123))
                                               * v123)))
                       + v117;
            position->mValue = v114;
            v114 += v113;
            --outlength;
          }
          while ( outlength );
        }
      }
      else if ( outlength )
      {
        v85 = speed->mValue;
        v86 = position->mValue + speed->mValue;
        v87 = outlength;
        do
        {
          v88 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v89 = position->mHi;
            v90 = 4 * v89 - 8;
            v91 = channels + v89 * channels;
            v92 = channels * (v90 + 4);
            v93 = 0;
            v94 = (char *)src + channels * v90;
            v95 = (char *)src + v92;
            do
            {
              v96 = (float)*(int *)&v94[4 * v93] * 4.6566129e-10;
              v97 = (float)*(int *)&v95[4 * v93] * 4.6566129e-10;
              v98 = (float)*((int *)src + (unsigned int)(v89 * channels + v93)) * 4.6566129e-10;
              v99 = (float)*((int *)src + (unsigned int)(v91 + v93)) * 4.6566129e-10;
              v100 = (float)*((int *)src + (unsigned int)(channels + v91 + v93)) * 4.6566129e-10;
              v101 = (float)*((int *)src + (unsigned int)(channels + channels + v91 + v93)) * 4.6566129e-10;
              out[v93++] = (float)((float)((float)((float)((float)(v99 - v97) * 16.0)
                                                 + (float)((float)(v96 - v100) + (float)(v96 - v100)))
                                         + (float)((float)((float)((float)((float)((float)((float)(v99 + v97) * 16.0)
                                                                                 - v96)
                                                                         - (float)(30.0 * v98))
                                                                 - v100)
                                                         + (float)((float)((float)((float)((float)((float)((float)((float)(66.0 * v99) - (float)(70.0 * v98)) - (float)(33.0 * v100))
                                                                                                 + (float)(39.0 * v97))
                                                                                         + (float)(7.0 * v101))
                                                                                 - (float)(9.0 * v96))
                                                                         + (float)((float)((float)((float)((float)((float)((float)((float)(126.0 * v98) - (float)(v99 * 124.0)) + (float)(61.0 * v100)) - (float)(64.0 * v97)) - (float)(12.0 * v101))
                                                                                                 + (float)(13.0 * v96))
                                                                                         + (float)((float)((float)((float)((float)(v99 - v98) * 50.0) + (float)((float)(v97 - v100) * 25.0)) + (float)((float)(v101 - v96) * 5.0))
                                                                                                 * v88))
                                                                                 * v88))
                                                                 * v88))
                                                 * v88))
                                 * (float)(0.041666668 * v88))
                         + v98;
            }
            while ( channels > (int)v93 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v86;
          v86 += v85;
          --v87;
        }
        while ( v87 );
      }
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      if ( channels == 1 )
      {
        if ( outlength )
        {
          v102 = speed->mValue;
          v103 = position->mValue + v102;
          do
          {
            ++out;
            v104 = position->mHi;
            v105 = *((float *)src + v104);
            v106 = 4LL * v104;
            v107 = *(float *)((char *)src + v106 - 8);
            v108 = *(float *)((char *)src + v106 - 4);
            v109 = *((float *)src + v104 + 2);
            v110 = *((float *)src + v104 + 1);
            v111 = (float)(int)position->mLo * 2.3283064e-10;
            v112 = *((float *)src + v104 + 3);
            *(out - 1) = (float)((float)(v111 * 0.041666668)
                               * (float)((float)((float)((float)(v110 - v108) * 16.0)
                                               + (float)((float)(v107 - v109) + (float)(v107 - v109)))
                                       + (float)((float)((float)((float)((float)((float)((float)(v110 + v108) * 16.0)
                                                                               - v107)
                                                                       - (float)(30.0 * v105))
                                                               - v109)
                                                       + (float)((float)((float)((float)((float)((float)((float)((float)(66.0 * v110) - (float)(70.0 * v105)) - (float)(33.0 * v109))
                                                                                               + (float)(39.0 * v108))
                                                                                       + (float)(7.0 * v112))
                                                                               - (float)(9.0 * v107))
                                                                       + (float)((float)((float)((float)((float)((float)((float)((float)(126.0 * v105) - (float)(124.0 * v110)) + (float)(61.0 * v109)) - (float)(64.0 * v108)) - (float)(12.0 * v112))
                                                                                               + (float)(13.0 * v107))
                                                                                       + (float)((float)((float)((float)((float)(v110 - v105) * 50.0) + (float)((float)(v108 - v109) * 25.0)) + (float)((float)(v112 - v107) * 5.0))
                                                                                               * v111))
                                                                               * v111))
                                                               * v111))
                                               * v111)))
                       + v105;
            position->mValue = v103;
            v103 += v102;
            --outlength;
          }
          while ( outlength );
        }
      }
      else if ( outlength )
      {
        v19 = speed->mValue;
        v20 = position->mValue + speed->mValue;
        v21 = outlength;
        do
        {
          v22 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v23 = position->mHi;
            v24 = 4 * v23 - 8;
            v25 = channels + v23 * channels;
            v26 = channels * (v24 + 4);
            v27 = 0;
            v28 = (char *)src + channels * v24;
            v29 = (char *)src + v26;
            do
            {
              v30 = *(float *)&v28[4 * v27];
              v31 = *((float *)src + (unsigned int)(v23 * channels + v27));
              v32 = *(float *)&v29[4 * v27];
              v33 = *((float *)src + (unsigned int)(v25 + v27));
              v34 = *((float *)src + (unsigned int)(channels + v25 + v27));
              v35 = *((float *)src + (unsigned int)(channels + channels + v25 + v27));
              out[v27++] = (float)((float)((float)((float)((float)(v33 - v32) * 16.0)
                                                 + (float)((float)(v30 - v34) + (float)(v30 - v34)))
                                         + (float)((float)((float)((float)((float)((float)((float)(v33 + v32) * 16.0)
                                                                                 - v30)
                                                                         - (float)(30.0 * v31))
                                                                 - v34)
                                                         + (float)((float)((float)((float)((float)((float)((float)((float)(66.0 * v33) - (float)(70.0 * v31)) - (float)(33.0 * v34))
                                                                                                 + (float)(39.0 * v32))
                                                                                         + (float)(7.0 * v35))
                                                                                 - (float)(9.0 * v30))
                                                                         + (float)((float)((float)((float)((float)((float)((float)((float)(126.0 * v31) - (float)(v33 * 124.0)) + (float)(v34 * 61.0)) - (float)(64.0 * v32)) - (float)(12.0 * v35))
                                                                                                 + (float)(13.0 * v30))
                                                                                         + (float)((float)((float)((float)((float)(v33 - v31) * 50.0) + (float)((float)(v32 - v34) * 25.0)) + (float)((float)(v35 - v30) * 5.0))
                                                                                                 * v22))
                                                                                 * v22))
                                                                 * v22))
                                                 * v22))
                                 * (float)(0.041666668 * v22))
                         + v31;
            }
            while ( channels > (int)v27 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v20;
          v20 += v19;
          --v21;
        }
        while ( v21 );
      }
      break;
    default:
      return;
  }
}


