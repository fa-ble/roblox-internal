// Address: 0x21c6a70 | Name: _ZN4FMOD6Thread10threadFuncEv
FMOD_RESULT_0 __fastcall FMOD::Thread::threadFunc(FMOD::Thread *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c6a80 | Name: _ZN4FMOD6ThreadD2Ev
void __fastcall FMOD::Thread::~Thread(FMOD::Thread *const this)
{
  this->_vptr_Thread = (int (**)(...))&off_29B0E30;
}


// Address: 0x21c6aa0 | Name: _ZN4FMOD6ThreadD0Ev
void __fastcall FMOD::Thread::~Thread(FMOD::Thread *const this)
{
  this->_vptr_Thread = (int (**)(...))&off_29B0E30;
  operator delete(this);
}


// Address: 0x2233c00 | Name: _ZN4FMOD15OcclusionThreadD2Ev
void __fastcall FMOD::OcclusionThread::~OcclusionThread(FMOD::OcclusionThread *const this)
{
  this->_vptr_Thread = (int (**)(...))&off_29B0E30;
}


// Address: 0x2233c10 | Name: _ZN4FMOD15OcclusionThreadD0Ev
void __fastcall FMOD::OcclusionThread::~OcclusionThread(FMOD::OcclusionThread *const this)
{
  this->_vptr_Thread = (int (**)(...))&off_29B0E30;
  operator delete(this);
}


// Address: 0x2234140 | Name: _ZN4FMOD11GeometryMgrD2Ev
void __fastcall FMOD::GeometryMgr::~GeometryMgr(FMOD::GeometryMgr *const this)
{
  this->mOcclusionThread._vptr_Thread = (int (**)(...))&off_29B0E30;
}


// Address: 0x224dcd0 | Name: _ZN4FMOD11AsyncThread12wakeupThreadEv
FMOD_RESULT_0 __fastcall FMOD::AsyncThread::wakeupThread(FMOD::AsyncThread *const this)
{
  FMOD_OS_SEMAPHORE *mSema; // rdi

  mSema = this->mThread.mSema;
  if ( mSema )
    return FMOD_OS_Semaphore_Signal(mSema);
  else
    return FMOD_RESULT::FMOD_OK_0;
}


