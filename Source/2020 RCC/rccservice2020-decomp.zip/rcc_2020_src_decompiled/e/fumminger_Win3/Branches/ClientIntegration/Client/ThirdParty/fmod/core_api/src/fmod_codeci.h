// Address: 0x21d0d40 | Name: _ZN4FMOD5Codec15defaultFileReadEPvS1_jPjS1_
FMOD_RESULT_0 __fastcall FMOD::Codec::defaultFileRead(
        void *handle,
        void *buffer,
        unsigned int size,
        unsigned int *read,
        void *a5)
{
  return FMOD::File::read((FMOD::File *const)handle, buffer, 1u, size, read);
}


// Address: 0x21d0d50 | Name: _ZN4FMOD5Codec15defaultFileSeekEPvjS1_
FMOD_RESULT_0 __fastcall FMOD::Codec::defaultFileSeek(void *handle, unsigned int pos, void *a3)
{
  return FMOD::File::seek((FMOD::File *const)handle, pos, 0);
}


// Address: 0x21d0d70 | Name: _ZN4FMOD5Codec15defaultMetaDataEP16FMOD_CODEC_STATE12FMOD_TAGTYPEPcPvj16FMOD_TAGDATATYPEi
FMOD_RESULT_0 __fastcall FMOD::Codec::defaultMetaData(
        FMOD_CODEC_STATE *codec,
        FMOD_TAGTYPE type,
        char *name,
        void *data,
        unsigned int datalen,
        FMOD_TAGDATATYPE datatype,
        int unique)
{
  return FMOD::Codec::metaData((FMOD::Codec *const)codec, type, name, data, datalen, datatype, unique == 1);
}


// Address: 0x2220000 | Name: _ZN4FMOD5Codec20defaultGetWaveFormatEP16FMOD_CODEC_STATEiP21FMOD_CODEC_WAVEFORMAT
FMOD_RESULT_0 __fastcall FMOD::Codec::defaultGetWaveFormat(
        FMOD_CODEC_STATE *codec,
        int index,
        FMOD_CODEC_WAVEFORMAT *waveformat_out)
{
  FMOD_CODEC_WAVEFORMAT *waveformat; // rcx
  FMOD_RESULT_0 result; // eax
  int numsubsounds; // edi

  waveformat = codec->waveformat;
  result = FMOD_RESULT::FMOD_ERR_PLUGIN_0;
  if ( waveformat )
  {
    LOBYTE(result) = 31;
    if ( index >= 0 )
    {
      numsubsounds = codec->numsubsounds;
      if ( !numsubsounds )
      {
        if ( index )
          return result;
LABEL_8:
        *waveformat_out = waveformat[index];
        return FMOD_RESULT::FMOD_OK_0;
      }
      if ( numsubsounds <= 0 || index < numsubsounds )
        goto LABEL_8;
    }
  }
  return result;
}


