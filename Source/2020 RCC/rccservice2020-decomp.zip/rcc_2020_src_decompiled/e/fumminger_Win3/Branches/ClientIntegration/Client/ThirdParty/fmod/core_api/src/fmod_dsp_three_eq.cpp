// Address: 0x223bca0 | Name: _ZN4FMOD10DSPThreeEQ16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPThreeEQ::getDescriptionEx()
{
  memset(&stru_2B054A0, 0, sizeof(stru_2B054A0));
  FMOD_strcpy_safe(stru_2B054A0.name, "Low Gain", 16);
  FMOD_strcpy_safe(stru_2B054A0.label, "dB", 16);
  *(_QWORD *)&stru_2B054A0.floatdesc.min = 0x41200000C2A00000LL;
  stru_2B054A0.description = "Low frequency gain in dB.  -80.0f to 10.0f.  Default = 0.";
  memset(&stru_2B05440, 0, sizeof(stru_2B05440));
  stru_2B054A0.intdesc.defaultval = 0;
  stru_2B054A0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B05440.name, "Mid Gain", 16);
  FMOD_strcpy_safe(stru_2B05440.label, "dB", 16);
  *(_QWORD *)&stru_2B05440.floatdesc.min = 0x41200000C2A00000LL;
  stru_2B05440.description = "Mid frequency gain in dB.  -80.0f to 10.0f.  Default = 0.";
  memset(&stru_2B053E0, 0, sizeof(stru_2B053E0));
  stru_2B05440.intdesc.defaultval = 0;
  stru_2B05440.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B053E0.name, "High Gain", 16);
  FMOD_strcpy_safe(stru_2B053E0.label, "dB", 16);
  *(_QWORD *)&stru_2B053E0.floatdesc.min = 0x41200000C2A00000LL;
  stru_2B053E0.description = "High frequency gain in dB.  -80.0f to 10.0f.  Default = 0.";
  memset(&stru_2B05380, 0, sizeof(stru_2B05380));
  stru_2B053E0.intdesc.defaultval = 0;
  stru_2B053E0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B05380.name, "Low Crossover", 16);
  FMOD_strcpy_safe(stru_2B05380.label, "Hz", 16);
  *(_QWORD *)&stru_2B05380.floatdesc.min = 0x46ABE00041200000LL;
  stru_2B05380.description = "Low-to-mid crossover frequency in Hz.  10.0 to 22000.0.  Default = 400.0.";
  memset(&stru_2B05320, 0, sizeof(stru_2B05320));
  stru_2B05380.intdesc.defaultval = 1137180672;
  stru_2B05380.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B05320.name, "High Crossover", 16);
  FMOD_strcpy_safe(stru_2B05320.label, "Hz", 16);
  *(_QWORD *)&stru_2B05320.floatdesc.min = 0x46ABE00041200000LL;
  stru_2B05320.description = "Mid-to-high crossover frequency in Hz.  10.0 to 22000.0.  Default = 4000.0.";
  memset(&stru_2B052C0, 0, sizeof(stru_2B052C0));
  stru_2B05320.intdesc.defaultval = 1165623296;
  stru_2B05320.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B052C0.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2B052C0.name, "Slope", 16);
  FMOD_strcpy_safe(stru_2B052C0.label, "dB/8ve", 16);
  *(_QWORD *)&stru_2B052C0.floatdesc.min = 0x200000000LL;
  stru_2B052C0.description = "Crossover Slope.  0 = 12dB/Octave, 1 = 24dB/Octave, 2 = 48dB/Octave.  Default = 1 (24dB/Octave).";
  *(_OWORD *)(&stru_2B052C0.datadesc + 2) = 1u;
  *(&stru_2B05280.mHandle + 1) = 28;
  stru_2B05280.mSize = 9728;
  stru_2B05280.mDescription = &stru_286F460;
  return &stru_2B05280;
}


// Address: 0x223bfd0 | Name: _ZN4FMOD10DSPThreeEQ12resetFiltersEv
void __fastcall FMOD::DSPThreeEQ::resetFilters(FMOD::DSPThreeEQ *const this)
{
  _DWORD *v1; // rax
  _DWORD *v2; // rdx
  int v3; // ebx

  v1 = (_DWORD *)((char *)this + 1428);
  do
  {
    v2 = v1 + 128;
    do
    {
      *v1 = 0;
      *(v1 - 1) = 0;
      v1 += 4;
      v1[508] = 0;
      v1[507] = 0;
      v1[1020] = 0;
      v1[1019] = 0;
      v1[1532] = 0;
      v1[1531] = 0;
    }
    while ( v1 != v2 );
  }
  while ( (_DWORD *)((char *)this + 3476) != v1 );
  v3 = 2;
  do
  {
    FMOD::RampingBiquadCoefficients::apply((FMOD::RampingBiquadCoefficients *const)((char *)this + 528), 0);
    FMOD::RampingBiquadCoefficients::apply((FMOD::RampingBiquadCoefficients *const)((char *)this + 752), 0);
    FMOD::RampingBiquadCoefficients::apply((FMOD::RampingBiquadCoefficients *const)((char *)this + 640), 0);
    FMOD::RampingBiquadCoefficients::apply((FMOD::RampingBiquadCoefficients *const)((char *)this + 864), 0);
    --v3;
  }
  while ( v3 );
}


// Address: 0x223c0c0 | Name: _ZN4FMOD10DSPThreeEQ18updateLowCrossoverEi
void __fastcall FMOD::DSPThreeEQ::updateLowCrossover(FMOD::DSPThreeEQ *const this, int steps)
{
  int v2; // eax
  FMOD::RampingBiquadCoefficients *v3; // r13
  FMOD::RampingBiquadCoefficients *v4; // r12

  FMOD::DSPThreeEQ::updateSampleRate(this);
  v2 = *((_DWORD *)this + 2423);
  if ( v2 == 1 )
  {
    v3 = (FMOD::RampingBiquadCoefficients *)((char *)this + 528);
    v4 = (FMOD::RampingBiquadCoefficients *)((char *)this + 752);
    FMOD::BiquadCoefficients::calculateLowpassCoefficients(
      (const FMOD::BiquadCoefficients *const)this + 11,
      *((float *)this + 2421),
      *((float *)this + 2419),
      0.70710677,
      (float *)this + 142,
      (float *)this + 143,
      (float *)this + 144,
      (float *)this + 145,
      (float *)this + 146);
    FMOD::BiquadCoefficients::calculateHighpassCoefficients(
      (const FMOD::BiquadCoefficients *const)((char *)this + 752),
      *((float *)this + 2421),
      *((float *)this + 2419),
      0.70710677,
      (float *)this + 198,
      (float *)this + 199,
      (float *)this + 200,
      (float *)this + 201,
      (float *)this + 202);
  }
  else if ( v2 == 2 )
  {
    v3 = (FMOD::RampingBiquadCoefficients *)((char *)this + 640);
    FMOD::BiquadCoefficients::calculateLowpassCoefficients(
      (const FMOD::BiquadCoefficients *const)this + 11,
      *((float *)this + 2421),
      *((float *)this + 2419),
      0.54000002,
      (float *)this + 142,
      (float *)this + 143,
      (float *)this + 144,
      (float *)this + 145,
      (float *)this + 146);
    v4 = (FMOD::RampingBiquadCoefficients *)((char *)this + 864);
    FMOD::BiquadCoefficients::calculateHighpassCoefficients(
      (const FMOD::BiquadCoefficients *const)((char *)this + 752),
      *((float *)this + 2421),
      *((float *)this + 2419),
      0.54000002,
      (float *)this + 198,
      (float *)this + 199,
      (float *)this + 200,
      (float *)this + 201,
      (float *)this + 202);
    FMOD::BiquadCoefficients::calculateLowpassCoefficients(
      (const FMOD::BiquadCoefficients *const)((char *)this + 640),
      *((float *)this + 2421),
      *((float *)this + 2419),
      1.34,
      (float *)this + 170,
      (float *)this + 171,
      (float *)this + 172,
      (float *)this + 173,
      (float *)this + 174);
    FMOD::BiquadCoefficients::calculateHighpassCoefficients(
      (const FMOD::BiquadCoefficients *const)this + 18,
      *((float *)this + 2421),
      *((float *)this + 2419),
      1.34,
      (float *)this + 226,
      (float *)this + 227,
      (float *)this + 228,
      (float *)this + 229,
      (float *)this + 230);
    FMOD::RampingBiquadCoefficients::apply((FMOD::RampingBiquadCoefficients *const)((char *)this + 528), steps);
    FMOD::RampingBiquadCoefficients::apply((FMOD::RampingBiquadCoefficients *const)((char *)this + 752), steps);
  }
  else
  {
    if ( v2 )
      return;
    v3 = (FMOD::RampingBiquadCoefficients *)((char *)this + 528);
    v4 = (FMOD::RampingBiquadCoefficients *)((char *)this + 752);
    FMOD::BiquadCoefficients::calculateLowpassCoefficients(
      (const FMOD::BiquadCoefficients *const)this + 11,
      *((float *)this + 2421),
      *((float *)this + 2419),
      0.5,
      (float *)this + 142,
      (float *)this + 143,
      (float *)this + 144,
      (float *)this + 145,
      (float *)this + 146);
    FMOD::BiquadCoefficients::calculateHighpassCoefficients(
      (const FMOD::BiquadCoefficients *const)((char *)this + 752),
      *((float *)this + 2421),
      *((float *)this + 2419),
      0.5,
      (float *)this + 198,
      (float *)this + 199,
      (float *)this + 200,
      (float *)this + 201,
      (float *)this + 202);
  }
  FMOD::RampingBiquadCoefficients::apply(v3, steps);
  FMOD::RampingBiquadCoefficients::apply(v4, steps);
}


// Address: 0x223c3b0 | Name: _ZN4FMOD10DSPThreeEQ19updateHighCrossoverEi
void __fastcall FMOD::DSPThreeEQ::updateHighCrossover(FMOD::DSPThreeEQ *const this, int steps)
{
  int v2; // eax
  FMOD::RampingBiquadCoefficients *v3; // r13
  FMOD::RampingBiquadCoefficients *v4; // r12

  FMOD::DSPThreeEQ::updateSampleRate(this);
  v2 = *((_DWORD *)this + 2423);
  if ( v2 == 1 )
  {
    v3 = (FMOD::RampingBiquadCoefficients *)((char *)this + 976);
    v4 = (FMOD::RampingBiquadCoefficients *)((char *)this + 1200);
    FMOD::BiquadCoefficients::calculateLowpassCoefficients(
      (const FMOD::BiquadCoefficients *const)((char *)this + 976),
      *((float *)this + 2421),
      *((float *)this + 2420),
      0.70710677,
      (float *)this + 254,
      (float *)this + 255,
      (float *)this + 256,
      (float *)this + 257,
      (float *)this + 258);
    FMOD::BiquadCoefficients::calculateHighpassCoefficients(
      (const FMOD::BiquadCoefficients *const)this + 25,
      *((float *)this + 2421),
      *((float *)this + 2420),
      0.70710677,
      (float *)this + 310,
      (float *)this + 311,
      (float *)this + 312,
      (float *)this + 313,
      (float *)this + 314);
  }
  else if ( v2 == 2 )
  {
    v3 = (FMOD::RampingBiquadCoefficients *)((char *)this + 1088);
    FMOD::BiquadCoefficients::calculateLowpassCoefficients(
      (const FMOD::BiquadCoefficients *const)((char *)this + 976),
      *((float *)this + 2421),
      *((float *)this + 2420),
      0.54000002,
      (float *)this + 254,
      (float *)this + 255,
      (float *)this + 256,
      (float *)this + 257,
      (float *)this + 258);
    v4 = (FMOD::RampingBiquadCoefficients *)((char *)this + 1312);
    FMOD::BiquadCoefficients::calculateHighpassCoefficients(
      (const FMOD::BiquadCoefficients *const)this + 25,
      *((float *)this + 2421),
      *((float *)this + 2420),
      0.54000002,
      (float *)this + 310,
      (float *)this + 311,
      (float *)this + 312,
      (float *)this + 313,
      (float *)this + 314);
    FMOD::BiquadCoefficients::calculateLowpassCoefficients(
      (const FMOD::BiquadCoefficients *const)((char *)this + 1088),
      *((float *)this + 2421),
      *((float *)this + 2420),
      1.34,
      (float *)this + 282,
      (float *)this + 283,
      (float *)this + 284,
      (float *)this + 285,
      (float *)this + 286);
    FMOD::BiquadCoefficients::calculateHighpassCoefficients(
      (const FMOD::BiquadCoefficients *const)((char *)this + 1312),
      *((float *)this + 2421),
      *((float *)this + 2420),
      1.34,
      (float *)this + 338,
      (float *)this + 339,
      (float *)this + 340,
      (float *)this + 341,
      (float *)this + 342);
    FMOD::RampingBiquadCoefficients::apply((FMOD::RampingBiquadCoefficients *const)((char *)this + 976), steps);
    FMOD::RampingBiquadCoefficients::apply((FMOD::RampingBiquadCoefficients *const)((char *)this + 1200), steps);
  }
  else
  {
    if ( v2 )
      return;
    v3 = (FMOD::RampingBiquadCoefficients *)((char *)this + 976);
    v4 = (FMOD::RampingBiquadCoefficients *)((char *)this + 1200);
    FMOD::BiquadCoefficients::calculateLowpassCoefficients(
      (const FMOD::BiquadCoefficients *const)((char *)this + 976),
      *((float *)this + 2421),
      *((float *)this + 2420),
      0.5,
      (float *)this + 254,
      (float *)this + 255,
      (float *)this + 256,
      (float *)this + 257,
      (float *)this + 258);
    FMOD::BiquadCoefficients::calculateHighpassCoefficients(
      (const FMOD::BiquadCoefficients *const)this + 25,
      *((float *)this + 2421),
      *((float *)this + 2420),
      0.5,
      (float *)this + 310,
      (float *)this + 311,
      (float *)this + 312,
      (float *)this + 313,
      (float *)this + 314);
  }
  FMOD::RampingBiquadCoefficients::apply(v3, steps);
  FMOD::RampingBiquadCoefficients::apply(v4, steps);
}


// Address: 0x223c6a0 | Name: _ZN4FMOD10DSPThreeEQ14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::createInternal(FMOD::DSPThreeEQ *const this)
{
  double v1; // xmm1_8
  __int64 v2; // r12
  int v4; // ebx
  __int64 v5; // rax
  FMOD_RESULT_0 result; // eax
  _DWORD *v7; // rax
  float v8; // xmm1_4
  float v9; // xmm0_4
  float v10; // xmm1_4
  float v11; // xmm0_4
  float v12; // xmm1_4
  float v13; // xmm0_4
  int v14; // eax
  int v15; // edi
  int v16; // xmm0_4
  _QWORD *v17; // rax
  __int64 v18; // rdx
  char *v19; // r9
  char *v20; // r8
  char *v21; // rsi
  char *v22; // rcx
  _QWORD *v23; // rdx

  v2 = 0;
  v4 = 0;
  FMOD::DSPThreeEQ::updateSampleRate(this);
  v5 = *((_QWORD *)this + 30);
  if ( *(int *)(v5 + 96) > 0 )
  {
    do
    {
      v7 = *(_DWORD **)(*(_QWORD *)(v5 + 104) + v2);
      if ( *v7 )
      {
        result = FMOD::DSPI::setParameterInt((FMOD::DSPI *const)this, v4, v7[14]);
        if ( result )
          return result;
      }
      else
      {
        result = FMOD::DSPI::setParameterFloat((FMOD::DSPI *const)this, v4, (__m128i)(unsigned int)v7[14], v1);
        if ( result )
          return result;
      }
      v5 = *((_QWORD *)this + 30);
      ++v4;
      v2 += 8;
    }
    while ( *(_DWORD *)(v5 + 96) > v4 );
  }
  v8 = *((float *)this + 2424);
  *((float *)this + 2404) = v8;
  if ( v8 > -80.0 )
    v9 = powf(10.0, v8 / 20.0);
  else
    v9 = 0.0;
  v10 = *((float *)this + 2425);
  *((_DWORD *)this + 2408) = 0;
  *((float *)this + 2405) = v9;
  v11 = 0.0;
  *((float *)this + 2409) = v10;
  if ( v10 > -80.0 )
    v11 = powf(10.0, v10 / 20.0);
  v12 = *((float *)this + 2426);
  *((_DWORD *)this + 2413) = 0;
  *((float *)this + 2410) = v11;
  v13 = 0.0;
  *((float *)this + 2414) = v12;
  if ( v12 > -80.0 )
    v13 = powf(10.0, v12 / 20.0);
  v14 = *((_DWORD *)this + 2429);
  *((float *)this + 2415) = v13;
  *((_DWORD *)this + 2418) = 0;
  v15 = 0;
  *((_DWORD *)this + 2419) = *((_DWORD *)this + 2427);
  v16 = *((_DWORD *)this + 2428);
  *((_DWORD *)this + 2423) = v14;
  v17 = (_QWORD *)((char *)this + 1432);
  *((_DWORD *)this + 2420) = v16;
  do
  {
    v18 = 112LL * (v15 >> 1);
    v19 = (char *)this + v18 + 528;
    v20 = (char *)this + v18 + 752;
    v21 = (char *)this + v18 + 976;
    v22 = (char *)this + v18 + 1200;
    v23 = v17 + 64;
    do
    {
      *v17 = v19;
      v17[256] = v20;
      v17 += 2;
      v17[510] = v21;
      v17[766] = v22;
    }
    while ( v17 != v23 );
    ++v15;
  }
  while ( v15 != 4 );
  FMOD::DSPThreeEQ::updateLowCrossover(this, 0);
  FMOD::DSPThreeEQ::updateHighCrossover(this, 0);
  *((_DWORD *)this + 2422) = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223c8f0 | Name: _ZN4FMOD10DSPThreeEQ14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPThreeEQ::createInternal((FMOD::DSPThreeEQ *const)dsp_state->instance);
}


// Address: 0x223c900 | Name: _ZN4FMOD10DSPThreeEQ13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::resetInternal(FMOD::DSPThreeEQ *const this)
{
  float v1; // xmm1_4
  float v2; // xmm0_4
  float v3; // xmm1_4
  float v4; // xmm0_4
  float v5; // xmm1_4
  float v6; // xmm0_4
  int v7; // eax
  int v8; // xmm0_4
  int v9; // xmm0_4

  FMOD::DSPThreeEQ::updateSampleRate(this);
  v1 = *((float *)this + 2424);
  *((float *)this + 2404) = v1;
  v2 = 0.0;
  if ( v1 > -80.0 )
    v2 = powf(10.0, v1 / 20.0);
  v3 = *((float *)this + 2425);
  *((_DWORD *)this + 2408) = 0;
  *((float *)this + 2405) = v2;
  v4 = 0.0;
  *((float *)this + 2409) = v3;
  if ( v3 > -80.0 )
    v4 = powf(10.0, v3 / 20.0);
  v5 = *((float *)this + 2426);
  *((_DWORD *)this + 2413) = 0;
  *((float *)this + 2410) = v4;
  v6 = 0.0;
  *((float *)this + 2414) = v5;
  if ( v5 > -80.0 )
    v6 = powf(10.0, v5 / 20.0);
  v7 = *((_DWORD *)this + 2429);
  *((float *)this + 2415) = v6;
  v8 = *((_DWORD *)this + 2427);
  *((_DWORD *)this + 2418) = 0;
  *((_DWORD *)this + 2419) = v8;
  v9 = *((_DWORD *)this + 2428);
  *((_DWORD *)this + 2423) = v7;
  *((_DWORD *)this + 2420) = v9;
  FMOD::DSPThreeEQ::resetFilters(this);
  FMOD::DSPThreeEQ::updateLowCrossover(this, 0);
  FMOD::DSPThreeEQ::updateHighCrossover(this, 0);
  *((_DWORD *)this + 2422) = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223ca80 | Name: _ZN4FMOD10DSPThreeEQ13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPThreeEQ::resetInternal((FMOD::DSPThreeEQ *const)dsp_state->instance);
}


// Address: 0x223ca90 | Name: _ZN4FMOD10DSPThreeEQ7processEPfS1_ji
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::process(
        FMOD::DSPThreeEQ *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int channels)
{
  unsigned int v6; // ebx
  char *v10; // r15
  int v11; // edx
  __int64 v12; // r8
  float *v13; // rsi
  float *v14; // rdi
  char *v17; // [rsp+28h] [rbp-50h]
  char *v18; // [rsp+30h] [rbp-48h]
  char *v19; // [rsp+38h] [rbp-40h]

  v6 = 0;
  if ( channels )
  {
    v10 = (char *)this + 7568;
    v17 = (char *)this + 1424;
    v18 = (char *)this + 3472;
    v19 = (char *)this + 5520;
    do
    {
      while ( 1 )
      {
        v11 = *((_DWORD *)this + 2423);
        if ( v11 != 1 )
          break;
        v12 = v6++;
        v13 = inbuffer;
        v14 = outbuffer++;
        ++inbuffer;
        ((void (__fastcall *)(float *, float *, _QWORD, _QWORD, __int64, char *, float, float, float, char *, char *, char *))FMOD_Optimised_Routines.FMOD_DSPThreeEQ_filterArray24dB)(
          v14,
          v13,
          length,
          (unsigned int)channels,
          v12,
          v17,
          *((float *)this + 2405),
          *((float *)this + 2410),
          *((float *)this + 2415),
          v19,
          v18,
          v10);
        if ( v6 == channels )
          return FMOD_RESULT::FMOD_OK_0;
      }
      if ( v11 == 2 )
      {
        ((void (__fastcall *)(float *, float *, _QWORD, _QWORD, _QWORD, char *, float, float, float, char *, char *, char *))FMOD_Optimised_Routines.FMOD_DSPThreeEQ_filterArray48dB)(
          outbuffer,
          inbuffer,
          length,
          (unsigned int)channels,
          v6,
          v17,
          *((float *)this + 2405),
          *((float *)this + 2410),
          *((float *)this + 2415),
          v19,
          v18,
          v10);
      }
      else if ( !v11 )
      {
        ((void (__fastcall *)(float *, float *, _QWORD, _QWORD, _QWORD, char *, float, float, float, char *, char *, char *))FMOD_Optimised_Routines.FMOD_DSPThreeEQ_filterArray12dB)(
          outbuffer,
          inbuffer,
          length,
          (unsigned int)channels,
          v6,
          v17,
          *((float *)this + 2405),
          *((float *)this + 2410),
          *((float *)this + 2415),
          v19,
          v18,
          v10);
      }
      ++v6;
      ++outbuffer;
      ++inbuffer;
    }
    while ( v6 != channels );
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223e540 | Name: _ZN4FMOD10DSPThreeEQ12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::readInternal(
        FMOD::DSPThreeEQ *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  unsigned int v9; // eax
  float v10; // xmm1_4
  float v11; // xmm0_4
  float v12; // xmm0_4
  int v13; // eax
  float v14; // xmm1_4
  float v15; // xmm0_4
  float v16; // xmm0_4
  int v17; // eax
  float v18; // xmm1_4
  float v19; // xmm0_4
  float v20; // xmm0_4
  int v21; // eax
  float v22; // xmm0_4
  float v23; // xmm0_4
  int v24; // eax
  int v26; // eax
  int v27; // eax

  v9 = *((_DWORD *)this + 2422);
  if ( v9 <= length )
  {
    *((_DWORD *)this + 2422) = 0;
    if ( inbuffer )
      goto LABEL_3;
    return FMOD_RESULT::FMOD_OK_0;
  }
  *((_DWORD *)this + 2422) = v9 - length;
  if ( !inbuffer )
    return FMOD_RESULT::FMOD_OK_0;
LABEL_3:
  v10 = *((float *)this + 2424);
  if ( v10 != *((float *)this + 2404) )
  {
    *((float *)this + 2404) = v10;
    if ( v10 > -80.0 )
      v11 = powf(10.0, v10 / 20.0);
    else
      v11 = 0.0;
    *((float *)this + 2406) = v11;
    v12 = v11 - *((float *)this + 2405);
    v13 = 256;
    if ( *((_DWORD *)this + 2422) >= 0x100u )
      v13 = *((_DWORD *)this + 2422);
    *((_DWORD *)this + 2408) = 1132462080;
    *((_DWORD *)this + 2422) = v13;
    *((float *)this + 2407) = v12 * 0.00390625;
  }
  v14 = *((float *)this + 2425);
  if ( v14 != *((float *)this + 2409) )
  {
    *((float *)this + 2409) = v14;
    if ( v14 > -80.0 )
      v15 = powf(10.0, v14 / 20.0);
    else
      v15 = 0.0;
    *((float *)this + 2411) = v15;
    v16 = v15 - *((float *)this + 2410);
    v17 = 256;
    if ( *((_DWORD *)this + 2422) >= 0x100u )
      v17 = *((_DWORD *)this + 2422);
    *((_DWORD *)this + 2413) = 1132462080;
    *((_DWORD *)this + 2422) = v17;
    *((float *)this + 2412) = v16 * 0.00390625;
  }
  v18 = *((float *)this + 2426);
  if ( v18 != *((float *)this + 2414) )
  {
    *((float *)this + 2414) = v18;
    if ( v18 > -80.0 )
      v19 = powf(10.0, v18 / 20.0);
    else
      v19 = 0.0;
    *((float *)this + 2416) = v19;
    v20 = v19 - *((float *)this + 2415);
    v21 = 256;
    if ( *((_DWORD *)this + 2422) >= 0x100u )
      v21 = *((_DWORD *)this + 2422);
    *((_DWORD *)this + 2418) = 1132462080;
    *((_DWORD *)this + 2422) = v21;
    *((float *)this + 2417) = v20 * 0.00390625;
  }
  v22 = *((float *)this + 2427);
  if ( v22 != *((float *)this + 2419) )
  {
    *((float *)this + 2419) = v22;
    FMOD::DSPThreeEQ::updateLowCrossover(this, 1024);
    v27 = 1024;
    if ( *((_DWORD *)this + 2422) >= 0x400u )
      v27 = *((_DWORD *)this + 2422);
    *((_DWORD *)this + 2422) = v27;
  }
  v23 = *((float *)this + 2428);
  if ( v23 != *((float *)this + 2420) )
  {
    *((float *)this + 2420) = v23;
    FMOD::DSPThreeEQ::updateHighCrossover(this, 1024);
    v26 = 1024;
    if ( *((_DWORD *)this + 2422) >= 0x400u )
      v26 = *((_DWORD *)this + 2422);
    *((_DWORD *)this + 2422) = v26;
  }
  v24 = *((_DWORD *)this + 2429);
  if ( *((_DWORD *)this + 2423) != v24 )
  {
    *((_DWORD *)this + 2423) = v24;
    FMOD::DSPThreeEQ::resetFilters(this);
    FMOD::DSPThreeEQ::updateLowCrossover(this, 0);
    FMOD::DSPThreeEQ::updateHighCrossover(this, 0);
  }
  if ( *((_DWORD *)this + 2422) )
    return FMOD::DSPThreeEQ::processAndRamp(this, inbuffer, outbuffer, length, inchannels);
  else
    return FMOD::DSPThreeEQ::process(this, inbuffer, outbuffer, length, inchannels);
}


// Address: 0x223e870 | Name: _ZN4FMOD10DSPThreeEQ12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPThreeEQ::readInternal(
           (FMOD::DSPThreeEQ *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x223e880 | Name: _ZN4FMOD10DSPThreeEQ25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPThreeEQ::setParameterFloatInternal(
        FMOD::DSPThreeEQ *const this,
        int index,
        float a3,
        float value)
{
  if ( index )
  {
    switch ( index )
    {
      case 1:
        *((float *)this + 2425) = a3;
        return 0;
      case 2:
        *((float *)this + 2426) = a3;
        return 0;
      case 3:
        *((float *)this + 2427) = a3;
        return 0;
      case 4:
        *((float *)this + 2428) = a3;
        return 0;
      default:
        return 0;
    }
  }
  else
  {
    *((float *)this + 2424) = a3;
    return 0;
  }
}


// Address: 0x223e8f0 | Name: _ZN4FMOD10DSPThreeEQ25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPThreeEQ::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPThreeEQ::setParameterFloatInternal((FMOD::DSPThreeEQ *const)dsp_state->instance, index, a3, value);
}


// Address: 0x223e900 | Name: _ZN4FMOD10DSPThreeEQ23setParameterIntInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::setParameterIntInternal(FMOD::DSPThreeEQ *const this, int index, int value)
{
  if ( index == 5 )
    *((_DWORD *)this + 2429) = value;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223e910 | Name: _ZN4FMOD10DSPThreeEQ23setParameterIntCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::setParameterIntCallback(FMOD_DSP_STATE *dsp_state, int index, int value)
{
  return FMOD::DSPThreeEQ::setParameterIntInternal((FMOD::DSPThreeEQ *const)dsp_state->instance, index, value);
}


// Address: 0x223e920 | Name: _ZN4FMOD10DSPThreeEQ25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::getParameterFloatInternal(
        FMOD::DSPThreeEQ *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v4; // xmm0_4

  switch ( index )
  {
    case 0:
      *value = *((float *)this + 2424);
      if ( valuestr )
      {
        v4 = *((float *)this + 2424);
        goto LABEL_4;
      }
      break;
    case 1:
      *value = *((float *)this + 2425);
      if ( valuestr )
      {
        v4 = *((float *)this + 2425);
        goto LABEL_4;
      }
      break;
    case 2:
      *value = *((float *)this + 2426);
      if ( valuestr )
      {
        v4 = *((float *)this + 2426);
        goto LABEL_4;
      }
      break;
    case 3:
      *value = *((float *)this + 2427);
      if ( valuestr )
      {
        v4 = *((float *)this + 2427);
        goto LABEL_4;
      }
      break;
    case 4:
      *value = *((float *)this + 2428);
      if ( valuestr )
      {
        v4 = *((float *)this + 2428);
LABEL_4:
        sprintf(valuestr, "%.02f", v4);
      }
      break;
    default:
      return FMOD_RESULT::FMOD_OK_0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223ea00 | Name: _ZN4FMOD10DSPThreeEQ25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPThreeEQ::getParameterFloatInternal(
           (FMOD::DSPThreeEQ *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x223ea10 | Name: _ZN4FMOD10DSPThreeEQ23getParameterIntInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::getParameterIntInternal(
        FMOD::DSPThreeEQ *const this,
        int index,
        int *value,
        char *valuestr)
{
  int v4; // eax

  if ( index != 5 )
    return FMOD_RESULT::FMOD_OK_0;
  v4 = *((_DWORD *)this + 2429);
  *value = v4;
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  if ( v4 == 1 )
  {
    strcpy(valuestr, "24dB");
    return FMOD_RESULT::FMOD_OK_0;
  }
  else if ( v4 == 2 )
  {
    strcpy(valuestr, "48dB");
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( v4 )
      return FMOD_RESULT::FMOD_OK_0;
    strcpy(valuestr, "12dB");
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x223ea70 | Name: _ZN4FMOD10DSPThreeEQ23getParameterIntCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::getParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int *value,
        char *valuestr)
{
  return FMOD::DSPThreeEQ::getParameterIntInternal((FMOD::DSPThreeEQ *const)dsp_state->instance, index, value, valuestr);
}


// Address: 0x223ea80 | Name: FMOD::FMOD_DSPThreeEQ_filterArray12dB_NoOpt
void __fastcall FMOD::FMOD_DSPThreeEQ_filterArray12dB_NoOpt(
        float *out,
        float *in,
        int length,
        int stride,
        int channel,
        FMOD::BiquadFilter (*lowpass1)[32],
        float lowgain,
        float midgain,
        float highgain,
        FMOD::BiquadFilter (*lowpass2)[32],
        FMOD::BiquadFilter (*highpass1)[32],
        FMOD::BiquadFilter (*highpass2)[32])
{
  int v12; // r14d
  int v13; // r13d
  int v14; // ebx
  int v16; // ebp
  __int64 v17; // r9
  __int64 v18; // r15
  FMOD::BiquadFilter *v19; // rbx
  FMOD::BiquadFilter *v20; // r11
  FMOD::BiquadFilter *v21; // r10
  float *v22; // r12
  FMOD::BiquadFilter *v23; // r9
  float *v24; // rbp
  float *coeff; // r8
  float *v26; // rcx
  float *v27; // rdx
  __int64 v28; // r15
  float *v29; // rax
  __int64 v30; // r14
  int v31; // esi
  __int64 v32; // r13
  float w2; // xmm6_4
  float v34; // xmm7_4
  float v35; // xmm8_4
  float v36; // xmm3_4
  float v37; // xmm9_4
  float v38; // xmm6_4
  float v39; // xmm4_4
  float v40; // xmm3_4
  float v41; // xmm3_4
  float v42; // xmm7_4
  float v43; // xmm3_4
  float v44; // xmm8_4
  float v45; // xmm4_4
  float v46; // xmm7_4
  float v47; // xmm5_4
  float v48; // xmm4_4
  float v49; // xmm4_4
  float v50; // xmm8_4
  float v51; // xmm4_4
  float v52; // xmm7_4
  float v53; // xmm5_4
  float v54; // xmm7_4
  float v55; // xmm4_4
  float v56; // xmm5_4
  float v57; // xmm5_4
  float v58; // xmm8_4
  float v59; // xmm9_4
  float v60; // xmm4_4
  float v61; // xmm8_4
  float v62; // xmm6_4
  float v63; // xmm4_4
  float v64; // xmm3_4
  float v65; // xmm4_4
  float v66; // xmm6_4
  float v67; // xmm7_4
  float v68; // xmm8_4
  float v69; // xmm9_4
  float v70; // xmm3_4
  float v71; // xmm6_4
  float v72; // xmm4_4
  float v73; // xmm3_4
  float v74; // xmm3_4
  float v75; // xmm7_4
  float v76; // xmm3_4
  float v77; // xmm8_4
  float v78; // xmm4_4
  float v79; // xmm7_4
  float v80; // xmm5_4
  float v81; // xmm4_4
  float v82; // xmm4_4
  float v83; // xmm8_4
  float v84; // xmm4_4
  float v85; // xmm7_4
  float v86; // xmm5_4
  float v87; // xmm7_4
  float v88; // xmm4_4
  float v89; // xmm5_4
  float v90; // xmm5_4
  float v91; // xmm8_4
  float v92; // xmm9_4
  float v93; // xmm4_4
  float v94; // xmm8_4
  float v95; // xmm6_4
  float v96; // xmm4_4
  float v97; // xmm3_4
  float v98; // xmm4_4
  float v99; // xmm6_4
  float v100; // xmm7_4
  float v101; // xmm8_4
  float v102; // xmm9_4
  float v103; // xmm3_4
  float v104; // xmm6_4
  float v105; // xmm4_4
  float v106; // xmm3_4
  float v107; // xmm3_4
  float v108; // xmm7_4
  float v109; // xmm3_4
  float v110; // xmm8_4
  float v111; // xmm4_4
  float v112; // xmm7_4
  float v113; // xmm5_4
  float v114; // xmm4_4
  float v115; // xmm4_4
  float v116; // xmm8_4
  float v117; // xmm4_4
  float v118; // xmm7_4
  float v119; // xmm5_4
  float v120; // xmm7_4
  float v121; // xmm4_4
  float v122; // xmm5_4
  float v123; // xmm5_4
  float v124; // xmm8_4
  float v125; // xmm9_4
  float v126; // xmm4_4
  float v127; // xmm8_4
  float v128; // xmm6_4
  float v129; // xmm4_4
  float v130; // xmm3_4
  float v131; // xmm4_4
  float v132; // xmm6_4
  float v133; // xmm7_4
  float v134; // xmm8_4
  float v135; // xmm9_4
  float v136; // xmm3_4
  float v137; // xmm6_4
  float v138; // xmm4_4
  float v139; // xmm3_4
  float v140; // xmm3_4
  float v141; // xmm7_4
  float v142; // xmm3_4
  float v143; // xmm8_4
  float v144; // xmm4_4
  float v145; // xmm7_4
  float v146; // xmm5_4
  float v147; // xmm4_4
  float v148; // xmm4_4
  float v149; // xmm8_4
  float v150; // xmm4_4
  float v151; // xmm7_4
  float v152; // xmm5_4
  float v153; // xmm7_4
  float v154; // xmm4_4
  float v155; // xmm5_4
  float v156; // xmm6_4
  float v157; // xmm5_4
  float v158; // xmm8_4
  float v159; // xmm5_4
  float w1; // xmm7_4
  float v161; // xmm4_4
  float v162; // xmm8_4
  float v163; // xmm6_4
  float v164; // xmm4_4
  __int64 v165; // rax
  int v166; // r11d
  __int64 v167; // r9
  FMOD::BiquadFilter *v168; // rbp
  FMOD::BiquadFilter *v169; // rbx
  FMOD::BiquadFilter *v170; // r10
  __int64 v171; // r12
  FMOD::BiquadFilter *v172; // r9
  float *v173; // r8
  float *v174; // rcx
  float *v175; // rdx
  float *v176; // rax
  float v177; // xmm6_4
  float v178; // xmm7_4
  float v179; // xmm8_4
  float v180; // xmm3_4
  float v181; // xmm9_4
  float v182; // xmm6_4
  float v183; // xmm4_4
  float v184; // xmm3_4
  float v185; // xmm3_4
  float v186; // xmm7_4
  float v187; // xmm3_4
  float v188; // xmm8_4
  float v189; // xmm4_4
  float v190; // xmm7_4
  float v191; // xmm5_4
  float v192; // xmm4_4
  float v193; // xmm4_4
  float v194; // xmm8_4
  float v195; // xmm4_4
  float v196; // xmm7_4
  float v197; // xmm5_4
  float v198; // xmm7_4
  float v199; // xmm4_4
  float v200; // xmm5_4
  float v201; // xmm6_4
  float v202; // xmm5_4
  float v203; // xmm8_4
  float v204; // xmm5_4
  float v205; // xmm7_4
  float v206; // xmm4_4
  float v207; // xmm8_4
  float v208; // xmm6_4
  float v209; // xmm4_4
  __int64 v210; // [rsp+0h] [rbp-68h]
  char lengtha; // [rsp+Ch] [rbp-5Ch]
  int len; // [rsp+10h] [rbp-58h]
  int v216; // [rsp+24h] [rbp-44h]
  float *v217; // [rsp+30h] [rbp-38h]

  v12 = 2 * stride;
  v13 = 3 * stride;
  v14 = length >> 2;
  lengtha = length;
  v16 = v14;
  len = v14;
  if ( v14 )
  {
    v17 = channel;
    v18 = stride;
    v19 = &(*lowpass1)[v17];
    v20 = &(*highpass1)[v17];
    v21 = &(*lowpass2)[v17];
    v22 = out;
    v23 = &(*highpass2)[v17];
    v210 = 16LL * stride;
    v216 = v16;
    v24 = in;
    v217 = in;
    coeff = v19->mCoefficients->coeff;
    v26 = v20->mCoefficients->coeff;
    v27 = v21->mCoefficients->coeff;
    v28 = v18;
    v29 = v23->mCoefficients->coeff;
    v30 = v12;
    v31 = v216;
    v32 = v13;
    do
    {
      w2 = v19->w2;
      v34 = coeff[5] * v19->w1;
      v35 = v26[5];
      v36 = coeff[8] * w2;
      v37 = v29[5];
      v38 = w2 * coeff[6];
      v39 = (float)(*v24 - (float)(coeff[7] * v19->w1)) - v36;
      v40 = coeff[4];
      v19->w2 = v19->w1;
      v19->w1 = v39;
      v41 = (float)(v40 * v39) + v34;
      v42 = v20->w2;
      v43 = v41 + v38;
      v44 = v35 * v20->w1;
      v45 = v26[8] * v42;
      v46 = v42 * v26[6];
      v47 = (float)(*v24 - (float)(v26[7] * v20->w1)) - v45;
      v48 = v26[4];
      v20->w2 = v20->w1;
      v20->w1 = v47;
      v49 = (float)(v48 * v47) + v44;
      v50 = v27[5] * v21->w1;
      v51 = v49 + v46;
      v52 = v21->w2;
      v53 = v27[8] * v52;
      v54 = v52 * v27[6];
      v55 = (float)(v51 - (float)(v27[7] * v21->w1)) - v53;
      v56 = v27[4];
      v21->w2 = v21->w1;
      v21->w1 = v55;
      v57 = (float)(v56 * v55) + v50;
      v58 = v23->w2;
      v59 = v37 * v23->w1;
      v60 = v29[8] * v58;
      v61 = v58 * v29[6];
      v62 = (float)(*v24 - (float)(v29[7] * v23->w1)) - v60;
      v63 = v29[4];
      v23->w2 = v23->w1;
      v23->w1 = v62;
      v64 = (float)((float)(v43 * lowgain) - (float)((float)(v57 + v54) * midgain))
          + (float)((float)((float)((float)(v63 * v62) + v59) + v61) * highgain);
      v65 = v24[v28];
      *v22 = v64;
      v66 = v19->w2;
      v67 = coeff[5] * v19->w1;
      v68 = v26[5];
      v69 = v29[5];
      v70 = coeff[8] * v66;
      v71 = v66 * coeff[6];
      v72 = (float)(v65 - (float)(coeff[7] * v19->w1)) - v70;
      v73 = coeff[4];
      v19->w2 = v19->w1;
      v19->w1 = v72;
      v74 = (float)(v73 * v72) + v67;
      v75 = v20->w2;
      v76 = v74 + v71;
      v77 = v68 * v20->w1;
      v78 = v26[8] * v75;
      v79 = v75 * v26[6];
      v80 = (float)(v24[v28] - (float)(v26[7] * v20->w1)) - v78;
      v81 = v26[4];
      v20->w2 = v20->w1;
      v20->w1 = v80;
      v82 = (float)(v81 * v80) + v77;
      v83 = v27[5] * v21->w1;
      v84 = v82 + v79;
      v85 = v21->w2;
      v86 = v27[8] * v85;
      v87 = v85 * v27[6];
      v88 = (float)(v84 - (float)(v27[7] * v21->w1)) - v86;
      v89 = v27[4];
      v21->w2 = v21->w1;
      v21->w1 = v88;
      v90 = (float)(v89 * v88) + v83;
      v91 = v23->w2;
      v92 = v69 * v23->w1;
      v93 = v29[8] * v91;
      v94 = v91 * v29[6];
      v95 = (float)(v24[v28] - (float)(v29[7] * v23->w1)) - v93;
      v96 = v29[4];
      v23->w2 = v23->w1;
      v23->w1 = v95;
      v97 = (float)((float)(v76 * lowgain) - (float)((float)(v90 + v87) * midgain))
          + (float)((float)((float)((float)(v96 * v95) + v92) + v94) * highgain);
      v98 = v24[v30];
      v22[v28] = v97;
      v99 = v19->w2;
      v100 = coeff[5] * v19->w1;
      v101 = v26[5];
      v102 = v29[5];
      v103 = coeff[8] * v99;
      v104 = v99 * coeff[6];
      v105 = (float)(v98 - (float)(coeff[7] * v19->w1)) - v103;
      v106 = coeff[4];
      v19->w2 = v19->w1;
      v19->w1 = v105;
      v107 = (float)(v106 * v105) + v100;
      v108 = v20->w2;
      v109 = v107 + v104;
      v110 = v101 * v20->w1;
      v111 = v26[8] * v108;
      v112 = v108 * v26[6];
      v113 = (float)(v24[v30] - (float)(v26[7] * v20->w1)) - v111;
      v114 = v26[4];
      v20->w2 = v20->w1;
      v20->w1 = v113;
      v115 = (float)(v114 * v113) + v110;
      v116 = v27[5] * v21->w1;
      v117 = v115 + v112;
      v118 = v21->w2;
      v119 = v27[8] * v118;
      v120 = v118 * v27[6];
      v121 = (float)(v117 - (float)(v27[7] * v21->w1)) - v119;
      v122 = v27[4];
      v21->w2 = v21->w1;
      v21->w1 = v121;
      v123 = (float)(v122 * v121) + v116;
      v124 = v23->w2;
      v125 = v102 * v23->w1;
      v126 = v29[8] * v124;
      v127 = v124 * v29[6];
      v128 = (float)(v24[v30] - (float)(v29[7] * v23->w1)) - v126;
      v129 = v29[4];
      v23->w2 = v23->w1;
      v23->w1 = v128;
      v130 = (float)((float)(v109 * lowgain) - (float)((float)(v123 + v120) * midgain))
           + (float)((float)((float)((float)(v129 * v128) + v125) + v127) * highgain);
      v131 = v24[v32];
      v22[v30] = v130;
      v132 = v19->w2;
      v133 = coeff[5] * v19->w1;
      v134 = v26[5];
      v135 = v29[5];
      v136 = coeff[8] * v132;
      v137 = v132 * coeff[6];
      v138 = (float)(v131 - (float)(coeff[7] * v19->w1)) - v136;
      v139 = coeff[4];
      v19->w2 = v19->w1;
      v19->w1 = v138;
      v140 = (float)(v139 * v138) + v133;
      v141 = v20->w2;
      v142 = v140 + v137;
      v143 = v134 * v20->w1;
      v144 = v26[8] * v141;
      v145 = v141 * v26[6];
      v146 = (float)(v24[v32] - (float)(v26[7] * v20->w1)) - v144;
      v147 = v26[4];
      v20->w2 = v20->w1;
      v20->w1 = v146;
      v148 = (float)(v147 * v146) + v143;
      v149 = v27[5] * v21->w1;
      v150 = v148 + v145;
      v151 = v21->w2;
      v152 = v27[8] * v151;
      v153 = v151 * v27[6];
      v154 = (float)(v150 - (float)(v27[7] * v21->w1)) - v152;
      v155 = v27[4];
      v21->w2 = v21->w1;
      v21->w1 = v154;
      v156 = v24[v32];
      v24 = (float *)((char *)v24 + v210);
      v157 = (float)(v155 * v154) + v149;
      v158 = v23->w2;
      v159 = v157 + v153;
      w1 = v23->w1;
      v161 = v29[8] * v158;
      v162 = v158 * v29[6];
      v163 = (float)(v156 - (float)(v29[7] * v23->w1)) - v161;
      v164 = v29[4];
      v23->w2 = v23->w1;
      v23->w1 = v163;
      v22[v32] = (float)((float)(v142 * lowgain) - (float)(v159 * midgain))
               + (float)((float)((float)((float)(v164 * v163) + (float)(v135 * w1)) + v162) * highgain);
      v22 = (float *)((char *)v22 + v210);
      --v31;
    }
    while ( v31 );
    v165 = v210 * ((unsigned int)(len - 1) + 1LL);
    out = (float *)((char *)out + v165);
    in = (float *)((char *)v217 + v165);
  }
  v166 = lengtha & 3;
  if ( (lengtha & 3) != 0 )
  {
    v167 = channel;
    v168 = &(*lowpass1)[v167];
    v169 = &(*highpass1)[v167];
    v170 = &(*lowpass2)[v167];
    v171 = 4LL * stride;
    v172 = &(*highpass2)[v167];
    v173 = v168->mCoefficients->coeff;
    v174 = v169->mCoefficients->coeff;
    v175 = v170->mCoefficients->coeff;
    v176 = v172->mCoefficients->coeff;
    do
    {
      v177 = v168->w2;
      v178 = v173[5] * v168->w1;
      v179 = v174[5];
      v180 = v173[8] * v177;
      v181 = v176[5];
      v182 = v177 * v173[6];
      v183 = (float)(*in - (float)(v173[7] * v168->w1)) - v180;
      v184 = v173[4];
      v168->w2 = v168->w1;
      v168->w1 = v183;
      v185 = (float)(v184 * v183) + v178;
      v186 = v169->w2;
      v187 = v185 + v182;
      v188 = v179 * v169->w1;
      v189 = v174[8] * v186;
      v190 = v186 * v174[6];
      v191 = (float)(*in - (float)(v174[7] * v169->w1)) - v189;
      v192 = v174[4];
      v169->w2 = v169->w1;
      v169->w1 = v191;
      v193 = (float)(v192 * v191) + v188;
      v194 = v175[5] * v170->w1;
      v195 = v193 + v190;
      v196 = v170->w2;
      v197 = v175[8] * v196;
      v198 = v196 * v175[6];
      v199 = (float)(v195 - (float)(v175[7] * v170->w1)) - v197;
      v200 = v175[4];
      v170->w2 = v170->w1;
      v170->w1 = v199;
      v201 = *in;
      in = (float *)((char *)in + v171);
      v202 = (float)(v200 * v199) + v194;
      v203 = v172->w2;
      v204 = v202 + v198;
      v205 = v172->w1;
      v206 = v176[8] * v203;
      v207 = v203 * v176[6];
      v208 = (float)(v201 - (float)(v176[7] * v172->w1)) - v206;
      v209 = v176[4];
      v172->w2 = v172->w1;
      v172->w1 = v208;
      *out = (float)((float)(v187 * lowgain) - (float)(v204 * midgain))
           + (float)((float)((float)((float)(v209 * v208) + (float)(v181 * v205)) + v207) * highgain);
      out = (float *)((char *)out + v171);
      --v166;
    }
    while ( v166 );
  }
}


// Address: 0x223f320 | Name: FMOD::FMOD_DSPThreeEQ_filterArray24dB_NoOpt
void __fastcall FMOD::FMOD_DSPThreeEQ_filterArray24dB_NoOpt(
        float *out,
        float *in,
        int length,
        int stride,
        int channel,
        FMOD::BiquadFilter (*lowpass1)[32],
        float lowgain,
        float midgain,
        float highgain,
        FMOD::BiquadFilter (*lowpass2)[32],
        FMOD::BiquadFilter (*highpass1)[32],
        FMOD::BiquadFilter (*highpass2)[32])
{
  int v12; // eax
  int v13; // ebx
  int v15; // ecx
  __int64 v16; // rsi
  FMOD::BiquadFilter *v17; // rbp
  FMOD::BiquadFilter *v18; // r12
  FMOD::BiquadFilter *v19; // r13
  FMOD::BiquadFilter *v20; // r11
  FMOD::BiquadFilter *v21; // r15
  FMOD::BiquadFilter *v22; // r14
  FMOD::BiquadFilter *v23; // r10
  __int64 v24; // r9
  const FMOD::BiquadCoefficients *v25; // rcx
  float *coeff; // r8
  const FMOD::BiquadCoefficients *v27; // rdi
  const FMOD::BiquadCoefficients *v28; // rsi
  float *v29; // rdx
  float *v30; // r9
  float *v31; // rax
  float w2; // xmm6_4
  float v33; // xmm7_4
  float b1; // xmm8_4
  float v35; // xmm4_4
  float v36; // xmm6_4
  float v37; // xmm3_4
  float v38; // xmm4_4
  float v39; // xmm4_4
  float v40; // xmm7_4
  float v41; // xmm4_4
  float v42; // xmm6_4
  float v43; // xmm3_4
  float v44; // xmm6_4
  float v45; // xmm4_4
  float v46; // xmm3_4
  float v47; // xmm3_4
  float v48; // xmm7_4
  float v49; // xmm3_4
  float v50; // xmm8_4
  float v51; // xmm4_4
  float v52; // xmm7_4
  float v53; // xmm5_4
  float b0; // xmm4_4
  float v55; // xmm4_4
  float v56; // xmm8_4
  float v57; // xmm4_4
  float v58; // xmm7_4
  float v59; // xmm5_4
  float v60; // xmm7_4
  float v61; // xmm4_4
  float v62; // xmm5_4
  float v63; // xmm9_4
  float v64; // xmm5_4
  float v65; // xmm8_4
  float v66; // xmm5_4
  float v67; // xmm7_4
  float v68; // xmm4_4
  float v69; // xmm7_4
  float v70; // xmm5_4
  float v71; // xmm4_4
  float a1; // xmm6_4
  float v73; // xmm4_4
  float v74; // xmm8_4
  float v75; // xmm4_4
  float v76; // xmm7_4
  float v77; // xmm4_4
  float v78; // xmm6_4
  float v79; // xmm7_4
  float v80; // xmm4_4
  float v81; // xmm6_4
  float v82; // xmm6_4
  float v83; // xmm8_4
  float v84; // xmm9_4
  float v85; // xmm4_4
  float v86; // xmm8_4
  float v87; // xmm5_4
  float v88; // xmm4_4
  float v89; // xmm4_4
  float v90; // xmm9_4
  float v91; // xmm4_4
  float v92; // xmm8_4
  float v93; // xmm5_4
  float v94; // xmm8_4
  float v95; // xmm4_4
  float v96; // xmm5_4
  float v97; // xmm6_4
  float v98; // xmm7_4
  float v99; // xmm8_4
  float v100; // xmm4_4
  float v101; // xmm6_4
  float v102; // xmm3_4
  float v103; // xmm4_4
  float v104; // xmm4_4
  float v105; // xmm7_4
  float v106; // xmm4_4
  float v107; // xmm6_4
  float v108; // xmm3_4
  float v109; // xmm6_4
  float v110; // xmm4_4
  float v111; // xmm3_4
  float v112; // xmm3_4
  float v113; // xmm7_4
  float v114; // xmm3_4
  float v115; // xmm8_4
  float v116; // xmm4_4
  float v117; // xmm7_4
  float v118; // xmm5_4
  float v119; // xmm4_4
  float v120; // xmm9_4
  float v121; // xmm4_4
  float v122; // xmm8_4
  float v123; // xmm4_4
  float v124; // xmm7_4
  float v125; // xmm5_4
  float v126; // xmm7_4
  float v127; // xmm4_4
  float v128; // xmm5_4
  float v129; // xmm5_4
  float v130; // xmm8_4
  float v131; // xmm5_4
  float v132; // xmm7_4
  float v133; // xmm4_4
  float v134; // xmm7_4
  float v135; // xmm5_4
  float v136; // xmm4_4
  float v137; // xmm6_4
  float v138; // xmm4_4
  float v139; // xmm8_4
  float v140; // xmm4_4
  float v141; // xmm7_4
  float v142; // xmm4_4
  float v143; // xmm6_4
  float v144; // xmm7_4
  float v145; // xmm4_4
  float v146; // xmm6_4
  float v147; // xmm6_4
  float v148; // xmm8_4
  float v149; // xmm9_4
  float v150; // xmm4_4
  float v151; // xmm8_4
  float v152; // xmm5_4
  float v153; // xmm4_4
  float v154; // xmm4_4
  float v155; // xmm9_4
  float v156; // xmm4_4
  float v157; // xmm8_4
  float v158; // xmm5_4
  float v159; // xmm8_4
  float v160; // xmm4_4
  float v161; // xmm5_4
  float v162; // xmm6_4
  float v163; // xmm7_4
  float v164; // xmm4_4
  float v165; // xmm6_4
  float v166; // xmm3_4
  float v167; // xmm4_4
  float v168; // xmm4_4
  float v169; // xmm7_4
  float v170; // xmm4_4
  float v171; // xmm6_4
  float v172; // xmm3_4
  float v173; // xmm6_4
  float v174; // xmm4_4
  float v175; // xmm3_4
  float v176; // xmm8_4
  float v177; // xmm3_4
  float v178; // xmm7_4
  float v179; // xmm3_4
  float v180; // xmm8_4
  float v181; // xmm4_4
  float v182; // xmm7_4
  float v183; // xmm5_4
  float v184; // xmm4_4
  float v185; // xmm4_4
  float v186; // xmm8_4
  float v187; // xmm4_4
  float v188; // xmm7_4
  float v189; // xmm5_4
  float v190; // xmm7_4
  float v191; // xmm4_4
  float v192; // xmm5_4
  float v193; // xmm5_4
  float v194; // xmm8_4
  float v195; // xmm5_4
  float v196; // xmm7_4
  float v197; // xmm4_4
  float v198; // xmm7_4
  float v199; // xmm5_4
  float v200; // xmm4_4
  float v201; // xmm6_4
  float v202; // xmm4_4
  float v203; // xmm8_4
  float v204; // xmm4_4
  float v205; // xmm7_4
  float v206; // xmm4_4
  float v207; // xmm6_4
  float v208; // xmm7_4
  float v209; // xmm4_4
  float v210; // xmm6_4
  float v211; // xmm6_4
  float v212; // xmm8_4
  float v213; // xmm9_4
  float v214; // xmm4_4
  float v215; // xmm8_4
  float v216; // xmm5_4
  float v217; // xmm4_4
  float v218; // xmm4_4
  float v219; // xmm9_4
  float v220; // xmm4_4
  float v221; // xmm8_4
  float v222; // xmm5_4
  float v223; // xmm8_4
  float v224; // xmm4_4
  float v225; // xmm5_4
  float v226; // xmm6_4
  float v227; // xmm7_4
  float v228; // xmm4_4
  float v229; // xmm6_4
  float v230; // xmm3_4
  float v231; // xmm4_4
  float v232; // xmm8_4
  float v233; // xmm4_4
  float v234; // xmm7_4
  float v235; // xmm4_4
  float v236; // xmm6_4
  float v237; // xmm3_4
  float v238; // xmm6_4
  float v239; // xmm4_4
  float v240; // xmm3_4
  float v241; // xmm3_4
  float v242; // xmm7_4
  float v243; // xmm3_4
  float v244; // xmm8_4
  float v245; // xmm4_4
  float v246; // xmm7_4
  float v247; // xmm5_4
  float v248; // xmm4_4
  float v249; // xmm4_4
  float v250; // xmm8_4
  float v251; // xmm4_4
  float v252; // xmm7_4
  float v253; // xmm5_4
  float v254; // xmm7_4
  float v255; // xmm4_4
  float v256; // xmm5_4
  float v257; // xmm5_4
  float v258; // xmm8_4
  float v259; // xmm5_4
  float v260; // xmm7_4
  float v261; // xmm4_4
  float v262; // xmm7_4
  float v263; // xmm5_4
  float v264; // xmm4_4
  float v265; // xmm9_4
  float v266; // xmm4_4
  float v267; // xmm8_4
  float v268; // xmm4_4
  float v269; // xmm7_4
  float v270; // xmm6_4
  float v271; // xmm7_4
  float v272; // xmm4_4
  float v273; // xmm6_4
  float v274; // xmm6_4
  float v275; // xmm8_4
  float v276; // xmm9_4
  float v277; // xmm4_4
  float v278; // xmm8_4
  float v279; // xmm5_4
  float v280; // xmm4_4
  float v281; // xmm4_4
  float v282; // xmm9_4
  float v283; // xmm4_4
  float v284; // xmm8_4
  float v285; // xmm5_4
  float v286; // xmm8_4
  float v287; // xmm4_4
  float v288; // xmm5_4
  __int64 v289; // rax
  __int64 v290; // rax
  FMOD::BiquadFilter *v291; // r15
  FMOD::BiquadFilter *v292; // r14
  FMOD::BiquadFilter *v293; // r13
  FMOD::BiquadFilter *v294; // rbp
  FMOD::BiquadFilter *v295; // r12
  FMOD::BiquadFilter *v296; // r11
  const FMOD::BiquadCoefficients *v297; // r9
  const FMOD::BiquadCoefficients *v298; // r8
  FMOD::BiquadFilter *v299; // rbx
  const FMOD::BiquadCoefficients *v300; // rsi
  const FMOD::BiquadCoefficients *v301; // rdx
  const FMOD::BiquadCoefficients *v302; // rcx
  FMOD::BiquadFilter *v303; // r10
  const FMOD::BiquadCoefficients *v304; // rdi
  const FMOD::BiquadCoefficients *v305; // rax
  float w1; // xmm5_4
  float v307; // xmm6_4
  float v308; // xmm7_4
  float v309; // xmm8_4
  float v310; // xmm4_4
  float v311; // xmm6_4
  float v312; // xmm3_4
  float v313; // xmm4_4
  float v314; // xmm4_4
  float v315; // xmm7_4
  float v316; // xmm4_4
  float v317; // xmm6_4
  float v318; // xmm3_4
  float v319; // xmm6_4
  float v320; // xmm4_4
  float v321; // xmm3_4
  float v322; // xmm3_4
  float v323; // xmm7_4
  float v324; // xmm3_4
  float v325; // xmm8_4
  float v326; // xmm4_4
  float v327; // xmm7_4
  float v328; // xmm5_4
  float v329; // xmm4_4
  float v330; // xmm4_4
  float v331; // xmm8_4
  float v332; // xmm4_4
  float v333; // xmm7_4
  float v334; // xmm5_4
  float v335; // xmm7_4
  float v336; // xmm4_4
  float v337; // xmm5_4
  float v338; // xmm9_4
  float v339; // xmm5_4
  float v340; // xmm8_4
  float v341; // xmm5_4
  float v342; // xmm7_4
  float v343; // xmm4_4
  float v344; // xmm7_4
  float v345; // xmm5_4
  float v346; // xmm4_4
  float v347; // xmm6_4
  float v348; // xmm4_4
  float v349; // xmm8_4
  float v350; // xmm4_4
  float v351; // xmm7_4
  float v352; // xmm4_4
  float v353; // xmm6_4
  float v354; // xmm7_4
  float v355; // xmm4_4
  float v356; // xmm6_4
  float v357; // xmm6_4
  float v358; // xmm8_4
  float v359; // xmm9_4
  float v360; // xmm4_4
  float v361; // xmm8_4
  float v362; // xmm5_4
  float v363; // xmm4_4
  float v364; // xmm4_4
  float v365; // xmm9_4
  float v366; // xmm4_4
  float v367; // xmm8_4
  float v368; // xmm5_4
  float v369; // xmm8_4
  float v370; // xmm4_4
  float v371; // xmm5_4
  const FMOD::BiquadCoefficients *mCoefficients; // [rsp+0h] [rbp-B8h]
  float *v373; // [rsp+8h] [rbp-B0h]
  float *v374; // [rsp+10h] [rbp-A8h]
  int v375; // [rsp+10h] [rbp-A8h]
  FMOD::BiquadFilter *v378; // [rsp+28h] [rbp-90h]
  __int64 v379; // [rsp+28h] [rbp-90h]
  const FMOD::BiquadCoefficients *v380; // [rsp+30h] [rbp-88h]
  __int64 v381; // [rsp+48h] [rbp-70h]
  int v382; // [rsp+54h] [rbp-64h]
  __int64 v383; // [rsp+58h] [rbp-60h]
  __int64 v384; // [rsp+60h] [rbp-58h]
  __int64 v385; // [rsp+68h] [rbp-50h]
  char lengtha; // [rsp+70h] [rbp-48h]

  v12 = 4 * stride;
  v13 = length >> 2;
  v15 = 2 * stride;
  lengtha = length;
  if ( length >> 2 )
  {
    v16 = channel;
    v382 = length >> 2;
    v17 = &(*lowpass2)[v16];
    v18 = &(*highpass1)[v16 + 32];
    v381 = 4LL * v12;
    v19 = &(*highpass1)[v16];
    v20 = &(*highpass2)[v16];
    v21 = &(*lowpass1)[v16];
    v22 = &(*lowpass1)[v16 + 32];
    v373 = in;
    v378 = &(*lowpass2)[v16 + 32];
    mCoefficients = (*lowpass2)[v16].mCoefficients;
    v384 = v15;
    v385 = v15 + stride;
    v23 = &(*highpass2)[v16 + 32];
    v374 = out;
    v24 = 4LL * stride;
    v25 = (*lowpass2)[v16 + 32].mCoefficients;
    coeff = v22->mCoefficients->coeff;
    v27 = (*highpass1)[v16].mCoefficients;
    v28 = (*highpass1)[v16 + 32].mCoefficients;
    v383 = v24;
    v29 = v20->mCoefficients->coeff;
    v30 = v21->mCoefficients->coeff;
    v31 = v23->mCoefficients->coeff;
    do
    {
      w2 = v21->w2;
      v33 = v30[5] * v21->w1;
      b1 = v27->b1;
      v35 = v30[8] * w2;
      v36 = w2 * v30[6];
      v37 = (float)(*v373 - (float)(v30[7] * v21->w1)) - v35;
      v38 = v30[4];
      v21->w2 = v21->w1;
      v21->w1 = v37;
      v39 = (float)(v38 * v37) + v33;
      v40 = coeff[5] * v22->w1;
      v41 = v39 + v36;
      v42 = v22->w2;
      v43 = coeff[8] * v42;
      v44 = v42 * coeff[6];
      v45 = (float)(v41 - (float)(coeff[7] * v22->w1)) - v43;
      v46 = coeff[4];
      v22->w2 = v22->w1;
      v22->w1 = v45;
      v47 = (float)(v46 * v45) + v40;
      v48 = v19->w2;
      v49 = v47 + v44;
      v50 = b1 * v19->w1;
      v51 = v27->a2 * v48;
      v52 = v48 * v27->b2;
      v53 = (float)(*v373 - (float)(v27->a1 * v19->w1)) - v51;
      b0 = v27->b0;
      v19->w2 = v19->w1;
      v19->w1 = v53;
      v55 = (float)(b0 * v53) + v50;
      v56 = v28->b1 * v18->w1;
      v57 = v55 + v52;
      v58 = v18->w2;
      v59 = v28->a2 * v58;
      v60 = v58 * v28->b2;
      v61 = (float)(v57 - (float)(v28->a1 * v18->w1)) - v59;
      v62 = v28->b0;
      v18->w2 = v18->w1;
      v63 = v29[5];
      v18->w1 = v61;
      v64 = (float)(v62 * v61) + v56;
      v65 = mCoefficients->b1 * v17->w1;
      v66 = v64 + v60;
      v67 = v17->w2;
      v68 = mCoefficients->a2 * v67;
      v69 = v67 * mCoefficients->b2;
      v70 = (float)(v66 - (float)(mCoefficients->a1 * v17->w1)) - v68;
      v71 = mCoefficients->b0;
      v17->w2 = v17->w1;
      a1 = v25->a1;
      v17->w1 = v70;
      v73 = (float)(v71 * v70) + v65;
      v74 = v25->b1 * v378->w1;
      v75 = v73 + v69;
      v76 = v378->w2;
      v77 = v75 - (float)(a1 * v378->w1);
      v78 = v25->a2 * v76;
      v79 = v76 * v25->b2;
      v80 = v77 - v78;
      v81 = v25->b0;
      v378->w2 = v378->w1;
      v378->w1 = v80;
      v82 = (float)(v81 * v80) + v74;
      v83 = v20->w2;
      v84 = v63 * v20->w1;
      v85 = v29[8] * v83;
      v86 = v83 * v29[6];
      v87 = (float)(*v373 - (float)(v29[7] * v20->w1)) - v85;
      v88 = v29[4];
      v20->w2 = v20->w1;
      v20->w1 = v87;
      v89 = (float)(v88 * v87) + v84;
      v90 = v31[5] * v23->w1;
      v91 = v89 + v86;
      v92 = v23->w2;
      v93 = v31[8] * v92;
      v94 = v92 * v31[6];
      v95 = (float)(v91 - (float)(v23->w1 * v31[7])) - v93;
      v96 = v31[4];
      v23->w2 = v23->w1;
      v23->w1 = v95;
      *v374 = (float)((float)(v49 * lowgain) + (float)((float)(v82 + v79) * midgain))
            + (float)((float)((float)((float)(v96 * v95) + v90) + v94) * highgain);
      v97 = v21->w2;
      v98 = v30[5] * v21->w1;
      v99 = v27->b1;
      v100 = v30[8] * v97;
      v101 = v97 * v30[6];
      v102 = (float)(*(float *)((char *)v373 + v383) - (float)(v30[7] * v21->w1)) - v100;
      v103 = v30[4];
      v21->w2 = v21->w1;
      v21->w1 = v102;
      v104 = (float)(v103 * v102) + v98;
      v105 = coeff[5] * v22->w1;
      v106 = v104 + v101;
      v107 = v22->w2;
      v108 = coeff[8] * v107;
      v109 = v107 * coeff[6];
      v110 = (float)(v106 - (float)(coeff[7] * v22->w1)) - v108;
      v111 = coeff[4];
      v22->w2 = v22->w1;
      v22->w1 = v110;
      v112 = (float)(v111 * v110) + v105;
      v113 = v19->w2;
      v114 = v112 + v109;
      v115 = v99 * v19->w1;
      v116 = v27->a2 * v113;
      v117 = v113 * v27->b2;
      v118 = (float)(*(float *)((char *)v373 + v383) - (float)(v27->a1 * v19->w1)) - v116;
      v119 = v27->b0;
      v19->w2 = v19->w1;
      v19->w1 = v118;
      v120 = v29[5];
      v121 = (float)(v119 * v118) + v115;
      v122 = v28->b1 * v18->w1;
      v123 = v121 + v117;
      v124 = v18->w2;
      v125 = v28->a2 * v124;
      v126 = v124 * v28->b2;
      v127 = (float)(v123 - (float)(v18->w1 * v28->a1)) - v125;
      v128 = v28->b0;
      v18->w2 = v18->w1;
      v18->w1 = v127;
      v129 = (float)(v128 * v127) + v122;
      v130 = mCoefficients->b1 * v17->w1;
      v131 = v129 + v126;
      v132 = v17->w2;
      v133 = mCoefficients->a2 * v132;
      v134 = v132 * mCoefficients->b2;
      v135 = (float)(v131 - (float)(mCoefficients->a1 * v17->w1)) - v133;
      v136 = mCoefficients->b0;
      v17->w2 = v17->w1;
      v137 = v25->a1;
      v17->w1 = v135;
      v138 = (float)(v136 * v135) + v130;
      v139 = v25->b1 * v378->w1;
      v140 = v138 + v134;
      v141 = v378->w2;
      v142 = v140 - (float)(v137 * v378->w1);
      v143 = v25->a2 * v141;
      v144 = v141 * v25->b2;
      v145 = v142 - v143;
      v146 = v25->b0;
      v378->w2 = v378->w1;
      v378->w1 = v145;
      v147 = (float)(v146 * v145) + v139;
      v148 = v20->w2;
      v149 = v120 * v20->w1;
      v150 = v29[8] * v148;
      v151 = v148 * v29[6];
      v152 = (float)(*(float *)((char *)v373 + v383) - (float)(v29[7] * v20->w1)) - v150;
      v153 = v29[4];
      v20->w2 = v20->w1;
      v20->w1 = v152;
      v154 = (float)(v153 * v152) + v149;
      v155 = v31[5] * v23->w1;
      v156 = v154 + v151;
      v157 = v23->w2;
      v158 = v31[8] * v157;
      v159 = v157 * v31[6];
      v160 = (float)(v156 - (float)(v23->w1 * v31[7])) - v158;
      v161 = v31[4];
      v23->w2 = v23->w1;
      v23->w1 = v160;
      *(float *)((char *)v374 + v383) = (float)((float)(v114 * lowgain) + (float)((float)(v147 + v144) * midgain))
                                      + (float)((float)((float)((float)(v161 * v160) + v155) + v159) * highgain);
      v162 = v21->w2;
      v163 = v30[5] * v21->w1;
      v164 = v30[8] * v162;
      v165 = v162 * v30[6];
      v166 = (float)(v373[v384] - (float)(v30[7] * v21->w1)) - v164;
      v167 = v30[4];
      v21->w2 = v21->w1;
      v21->w1 = v166;
      v168 = (float)(v167 * v166) + v163;
      v169 = coeff[5] * v22->w1;
      v170 = v168 + v165;
      v171 = v22->w2;
      v172 = coeff[8] * v171;
      v173 = v171 * coeff[6];
      v174 = (float)(v170 - (float)(v22->w1 * coeff[7])) - v172;
      v175 = coeff[4];
      v22->w2 = v22->w1;
      v176 = v27->b1;
      v22->w1 = v174;
      v177 = (float)(v175 * v174) + v169;
      v178 = v19->w2;
      v179 = v177 + v173;
      v180 = v176 * v19->w1;
      v181 = v27->a2 * v178;
      v182 = v178 * v27->b2;
      v183 = (float)(v373[v384] - (float)(v27->a1 * v19->w1)) - v181;
      v184 = v27->b0;
      v19->w2 = v19->w1;
      v19->w1 = v183;
      v185 = (float)(v184 * v183) + v180;
      v186 = v28->b1 * v18->w1;
      v187 = v185 + v182;
      v188 = v18->w2;
      v189 = v28->a2 * v188;
      v190 = v188 * v28->b2;
      v191 = (float)(v187 - (float)(v18->w1 * v28->a1)) - v189;
      v192 = v28->b0;
      v18->w2 = v18->w1;
      v18->w1 = v191;
      v193 = (float)(v192 * v191) + v186;
      v194 = mCoefficients->b1 * v17->w1;
      v195 = v193 + v190;
      v196 = v17->w2;
      v197 = mCoefficients->a2 * v196;
      v198 = v196 * mCoefficients->b2;
      v199 = (float)(v195 - (float)(mCoefficients->a1 * v17->w1)) - v197;
      v200 = mCoefficients->b0;
      v17->w2 = v17->w1;
      v201 = v25->a1;
      v17->w1 = v199;
      v202 = (float)(v200 * v199) + v194;
      v203 = v25->b1 * v378->w1;
      v204 = v202 + v198;
      v205 = v378->w2;
      v206 = v204 - (float)(v201 * v378->w1);
      v207 = v25->a2 * v205;
      v208 = v205 * v25->b2;
      v209 = v206 - v207;
      v210 = v25->b0;
      v378->w2 = v378->w1;
      v378->w1 = v209;
      v211 = (float)(v210 * v209) + v203;
      v212 = v20->w2;
      v213 = v29[5] * v20->w1;
      v214 = v29[8] * v212;
      v215 = v212 * v29[6];
      v216 = (float)(v373[v384] - (float)(v20->w1 * v29[7])) - v214;
      v217 = v29[4];
      v20->w2 = v20->w1;
      v20->w1 = v216;
      v218 = (float)(v217 * v216) + v213;
      v219 = v31[5] * v23->w1;
      v220 = v218 + v215;
      v221 = v23->w2;
      v222 = v31[8] * v221;
      v223 = v221 * v31[6];
      v224 = (float)(v220 - (float)(v31[7] * v23->w1)) - v222;
      v225 = v31[4];
      v23->w2 = v23->w1;
      v23->w1 = v224;
      v374[v384] = (float)((float)(v179 * lowgain) + (float)((float)(v211 + v208) * midgain))
                 + (float)((float)((float)((float)(v225 * v224) + v219) + v223) * highgain);
      v226 = v21->w2;
      v227 = v30[5] * v21->w1;
      v228 = v30[8] * v226;
      v229 = v226 * v30[6];
      v230 = (float)(v373[v385] - (float)(v21->w1 * v30[7])) - v228;
      v231 = v30[4];
      v21->w2 = v21->w1;
      v232 = v27->b1;
      v21->w1 = v230;
      v233 = (float)(v231 * v230) + v227;
      v234 = coeff[5] * v22->w1;
      v235 = v233 + v229;
      v236 = v22->w2;
      v237 = coeff[8] * v236;
      v238 = v236 * coeff[6];
      v239 = (float)(v235 - (float)(coeff[7] * v22->w1)) - v237;
      v240 = coeff[4];
      v22->w2 = v22->w1;
      v22->w1 = v239;
      v241 = (float)(v240 * v239) + v234;
      v242 = v19->w2;
      v243 = v241 + v238;
      v244 = v232 * v19->w1;
      v245 = v27->a2 * v242;
      v246 = v242 * v27->b2;
      v247 = (float)(v373[v385] - (float)(v27->a1 * v19->w1)) - v245;
      v248 = v27->b0;
      v19->w2 = v19->w1;
      v19->w1 = v247;
      v249 = (float)(v248 * v247) + v244;
      v250 = v28->b1 * v18->w1;
      v251 = v249 + v246;
      v252 = v18->w2;
      v253 = v28->a2 * v252;
      v254 = v252 * v28->b2;
      v255 = (float)(v251 - (float)(v18->w1 * v28->a1)) - v253;
      v256 = v28->b0;
      v18->w2 = v18->w1;
      v18->w1 = v255;
      v257 = (float)(v256 * v255) + v250;
      v258 = mCoefficients->b1 * v17->w1;
      v259 = v257 + v254;
      v260 = v17->w2;
      v261 = mCoefficients->a2 * v260;
      v262 = v260 * mCoefficients->b2;
      v263 = (float)(v259 - (float)(mCoefficients->a1 * v17->w1)) - v261;
      v264 = mCoefficients->b0;
      v17->w2 = v17->w1;
      v265 = v29[5];
      v17->w1 = v263;
      v266 = (float)(v264 * v263) + v258;
      v267 = v25->b1 * v378->w1;
      v268 = v266 + v262;
      v269 = v378->w2;
      v270 = v25->a2 * v269;
      v271 = v269 * v25->b2;
      v272 = (float)(v268 - (float)(v378->w1 * v25->a1)) - v270;
      v273 = v25->b0;
      v378->w2 = v378->w1;
      v378->w1 = v272;
      v274 = (float)(v273 * v272) + v267;
      v275 = v20->w2;
      v276 = v265 * v20->w1;
      v277 = v29[8] * v275;
      v278 = v275 * v29[6];
      v279 = (float)(v373[v385] - (float)(v29[7] * v20->w1)) - v277;
      v280 = v29[4];
      v20->w2 = v20->w1;
      v20->w1 = v279;
      v281 = (float)(v280 * v279) + v276;
      v282 = v31[5] * v23->w1;
      v283 = v281 + v278;
      v284 = v23->w2;
      v285 = v31[8] * v284;
      v286 = v284 * v31[6];
      v287 = (float)(v283 - (float)(v31[7] * v23->w1)) - v285;
      v288 = v31[4];
      v23->w2 = v23->w1;
      v23->w1 = v287;
      v374[v385] = (float)((float)(v243 * lowgain) + (float)((float)(v274 + v271) * midgain))
                 + (float)((float)((float)((float)(v288 * v287) + v282) + v286) * highgain);
      v374 = (float *)((char *)v374 + v381);
      v373 = (float *)((char *)v373 + v381);
      --v382;
    }
    while ( v382 );
    v289 = v381 * ((unsigned int)(v13 - 1) + 1LL);
    out = (float *)((char *)out + v289);
    in = (float *)((char *)in + v289);
  }
  v375 = lengtha & 3;
  if ( (lengtha & 3) != 0 )
  {
    v290 = channel;
    v291 = &(*lowpass1)[v290];
    v292 = &(*lowpass1)[v290 + 32];
    v293 = &(*highpass1)[v290];
    v294 = &(*lowpass2)[v290];
    v295 = &(*highpass1)[v290 + 32];
    v296 = &(*highpass2)[v290];
    v297 = (*lowpass1)[v290].mCoefficients;
    v298 = (*lowpass1)[v290 + 32].mCoefficients;
    v299 = &(*lowpass2)[v290 + 32];
    v300 = (*lowpass2)[v290].mCoefficients;
    v301 = (*highpass2)[v290].mCoefficients;
    v302 = (*lowpass2)[v290 + 32].mCoefficients;
    v303 = &(*highpass2)[v290 + 32];
    v304 = (*highpass1)[v290].mCoefficients;
    v379 = 4LL * stride;
    v380 = (*highpass1)[v290 + 32].mCoefficients;
    v305 = (*highpass2)[v290 + 32].mCoefficients;
    do
    {
      w1 = v291->w1;
      v307 = v291->w2;
      v308 = v297->b1;
      v309 = v304->b1;
      v310 = v297->a2 * v307;
      v311 = v307 * v297->b2;
      v312 = (float)(*in - (float)(v297->a1 * v291->w1)) - v310;
      v313 = v297->b0;
      v291->w2 = v291->w1;
      v291->w1 = v312;
      v314 = (float)(v313 * v312) + (float)(v308 * w1);
      v315 = v298->b1 * v292->w1;
      v316 = v314 + v311;
      v317 = v292->w2;
      v318 = v298->a2 * v317;
      v319 = v317 * v298->b2;
      v320 = (float)(v316 - (float)(v298->a1 * v292->w1)) - v318;
      v321 = v298->b0;
      v292->w2 = v292->w1;
      v292->w1 = v320;
      v322 = (float)(v321 * v320) + v315;
      v323 = v293->w2;
      v324 = v322 + v319;
      v325 = v309 * v293->w1;
      v326 = v304->a2 * v323;
      v327 = v323 * v304->b2;
      v328 = (float)(*in - (float)(v304->a1 * v293->w1)) - v326;
      v329 = v304->b0;
      v293->w2 = v293->w1;
      v293->w1 = v328;
      v330 = (float)(v329 * v328) + v325;
      v331 = v380->b1 * v295->w1;
      v332 = v330 + v327;
      v333 = v295->w2;
      v334 = v380->a2 * v333;
      v335 = v333 * v380->b2;
      v336 = (float)(v332 - (float)(v380->a1 * v295->w1)) - v334;
      v337 = v380->b0;
      v295->w2 = v295->w1;
      v338 = v301->b1;
      v295->w1 = v336;
      v339 = (float)(v337 * v336) + v331;
      v340 = v300->b1 * v294->w1;
      v341 = v339 + v335;
      v342 = v294->w2;
      v343 = v300->a2 * v342;
      v344 = v342 * v300->b2;
      v345 = (float)(v341 - (float)(v300->a1 * v294->w1)) - v343;
      v346 = v300->b0;
      v294->w2 = v294->w1;
      v347 = v302->a1;
      v294->w1 = v345;
      v348 = (float)(v346 * v345) + v340;
      v349 = v302->b1 * v299->w1;
      v350 = v348 + v344;
      v351 = v299->w2;
      v352 = v350 - (float)(v347 * v299->w1);
      v353 = v302->a2 * v351;
      v354 = v351 * v302->b2;
      v355 = v352 - v353;
      v356 = v302->b0;
      v299->w2 = v299->w1;
      v299->w1 = v355;
      v357 = (float)(v356 * v355) + v349;
      v358 = v296->w2;
      v359 = v338 * v296->w1;
      v360 = v301->a2 * v358;
      v361 = v358 * v301->b2;
      v362 = (float)(*in - (float)(v301->a1 * v296->w1)) - v360;
      v363 = v301->b0;
      v296->w2 = v296->w1;
      v296->w1 = v362;
      v364 = (float)(v363 * v362) + v359;
      v365 = v305->b1 * v303->w1;
      v366 = v364 + v361;
      v367 = v303->w2;
      v368 = v305->a2 * v367;
      v369 = v367 * v305->b2;
      v370 = (float)(v366 - (float)(v303->w1 * v305->a1)) - v368;
      v371 = v305->b0;
      v303->w2 = v303->w1;
      v303->w1 = v370;
      *out = (float)((float)(v324 * lowgain) + (float)((float)(v357 + v354) * midgain))
           + (float)((float)((float)((float)(v371 * v370) + v365) + v369) * highgain);
      in = (float *)((char *)in + v379);
      out = (float *)((char *)out + v379);
      --v375;
    }
    while ( v375 );
  }
}


// Address: 0x22403e0 | Name: FMOD::FMOD_DSPThreeEQ_filterArray48dB_NoOpt
void __fastcall FMOD::FMOD_DSPThreeEQ_filterArray48dB_NoOpt(
        float *out,
        float *in,
        int length,
        int stride,
        int channel,
        FMOD::BiquadFilter (*lowpass1)[32],
        float lowgain,
        float midgain,
        float highgain,
        FMOD::BiquadFilter (*lowpass2)[32],
        FMOD::BiquadFilter (*highpass1)[32],
        FMOD::BiquadFilter (*highpass2)[32])
{
  int v12; // eax
  __int64 v13; // r15
  FMOD::BiquadFilter *v14; // r14
  FMOD::BiquadFilter *v15; // r13
  FMOD::BiquadFilter *v16; // r12
  FMOD::BiquadFilter *v17; // rbp
  FMOD::BiquadFilter *v18; // r11
  FMOD::BiquadFilter *v19; // r10
  FMOD::BiquadFilter *v20; // rbx
  FMOD::BiquadFilter *v21; // rdx
  FMOD::BiquadFilter *v22; // rdi
  FMOD::BiquadFilter *v23; // rsi
  FMOD::BiquadFilter *v24; // rcx
  FMOD::BiquadFilter *v25; // r8
  FMOD::BiquadFilter *v26; // r15
  float w2; // xmm6_4
  float v28; // xmm7_4
  float v29; // xmm4_4
  float v30; // xmm6_4
  float v31; // xmm3_4
  float v32; // xmm4_4
  float v33; // xmm4_4
  float v34; // xmm7_4
  float v35; // xmm4_4
  float v36; // xmm6_4
  float v37; // xmm3_4
  float v38; // xmm6_4
  float v39; // xmm4_4
  float v40; // xmm3_4
  float v41; // xmm3_4
  float v42; // xmm7_4
  float v43; // xmm3_4
  float v44; // xmm6_4
  float v45; // xmm4_4
  float v46; // xmm6_4
  float v47; // xmm3_4
  float v48; // xmm4_4
  float v49; // xmm4_4
  float v50; // xmm7_4
  float v51; // xmm4_4
  float v52; // xmm6_4
  float v53; // xmm3_4
  float v54; // xmm6_4
  float v55; // xmm4_4
  float v56; // xmm3_4
  float v57; // xmm3_4
  float v58; // xmm7_4
  float v59; // xmm3_4
  float v60; // xmm8_4
  float v61; // xmm4_4
  float v62; // xmm7_4
  float v63; // xmm5_4
  float v64; // xmm4_4
  float v65; // xmm4_4
  float v66; // xmm8_4
  float v67; // xmm4_4
  float v68; // xmm7_4
  float v69; // xmm5_4
  float v70; // xmm7_4
  float v71; // xmm4_4
  float v72; // xmm5_4
  float v73; // xmm5_4
  float v74; // xmm8_4
  float v75; // xmm5_4
  float v76; // xmm7_4
  float v77; // xmm4_4
  float v78; // xmm7_4
  float v79; // xmm5_4
  float v80; // xmm4_4
  float v81; // xmm4_4
  float v82; // xmm8_4
  float v83; // xmm4_4
  float v84; // xmm7_4
  float v85; // xmm5_4
  float v86; // xmm7_4
  float v87; // xmm4_4
  float v88; // xmm5_4
  float v89; // xmm5_4
  float v90; // xmm8_4
  float v91; // xmm5_4
  float v92; // xmm7_4
  float v93; // xmm4_4
  float v94; // xmm7_4
  float v95; // xmm5_4
  float v96; // xmm4_4
  float v97; // xmm4_4
  float v98; // xmm8_4
  float v99; // xmm4_4
  float v100; // xmm7_4
  float v101; // xmm5_4
  float v102; // xmm7_4
  float v103; // xmm4_4
  float v104; // xmm5_4
  float v105; // xmm5_4
  float v106; // xmm8_4
  float v107; // xmm5_4
  float v108; // xmm7_4
  float v109; // xmm4_4
  float v110; // xmm7_4
  float v111; // xmm5_4
  float v112; // xmm4_4
  float v113; // xmm4_4
  float v114; // xmm8_4
  float v115; // xmm4_4
  float v116; // xmm7_4
  float v117; // xmm6_4
  float v118; // xmm7_4
  float v119; // xmm4_4
  float v120; // xmm6_4
  float v121; // xmm6_4
  float v122; // xmm8_4
  float v123; // xmm9_4
  float v124; // xmm4_4
  float v125; // xmm8_4
  float v126; // xmm5_4
  float v127; // xmm4_4
  float v128; // xmm4_4
  float v129; // xmm9_4
  float v130; // xmm4_4
  float v131; // xmm8_4
  float v132; // xmm5_4
  float v133; // xmm8_4
  float v134; // xmm4_4
  float v135; // xmm5_4
  float v136; // xmm5_4
  float v137; // xmm9_4
  float v138; // xmm5_4
  float v139; // xmm8_4
  float v140; // xmm4_4
  float v141; // xmm8_4
  float v142; // xmm5_4
  float v143; // xmm4_4
  float v144; // xmm4_4
  float v145; // xmm9_4
  float v146; // xmm4_4
  float v147; // xmm8_4
  float v148; // xmm5_4
  float v149; // xmm8_4
  float v150; // xmm4_4
  float v151; // xmm5_4
  float v152; // xmm6_4
  float v153; // xmm7_4
  float v154; // xmm4_4
  float v155; // xmm6_4
  float v156; // xmm3_4
  float v157; // xmm4_4
  float v158; // xmm4_4
  float v159; // xmm7_4
  float v160; // xmm4_4
  float v161; // xmm6_4
  float v162; // xmm3_4
  float v163; // xmm6_4
  float v164; // xmm4_4
  float v165; // xmm3_4
  float v166; // xmm3_4
  float v167; // xmm7_4
  float v168; // xmm3_4
  float v169; // xmm6_4
  float v170; // xmm4_4
  float v171; // xmm6_4
  float v172; // xmm3_4
  float v173; // xmm4_4
  float v174; // xmm4_4
  float v175; // xmm7_4
  float v176; // xmm4_4
  float v177; // xmm6_4
  float v178; // xmm3_4
  float v179; // xmm6_4
  float v180; // xmm4_4
  float v181; // xmm3_4
  float v182; // xmm3_4
  float v183; // xmm7_4
  float v184; // xmm3_4
  float v185; // xmm8_4
  float v186; // xmm4_4
  float v187; // xmm7_4
  float v188; // xmm5_4
  float v189; // xmm4_4
  float v190; // xmm4_4
  float v191; // xmm8_4
  float v192; // xmm4_4
  float v193; // xmm7_4
  float v194; // xmm5_4
  float v195; // xmm7_4
  float v196; // xmm4_4
  float v197; // xmm5_4
  float v198; // xmm5_4
  float v199; // xmm8_4
  float v200; // xmm5_4
  float v201; // xmm7_4
  float v202; // xmm4_4
  float v203; // xmm7_4
  float v204; // xmm5_4
  float v205; // xmm4_4
  float v206; // xmm4_4
  float v207; // xmm8_4
  float v208; // xmm4_4
  float v209; // xmm7_4
  float v210; // xmm5_4
  float v211; // xmm7_4
  float v212; // xmm4_4
  float v213; // xmm5_4
  float v214; // xmm5_4
  float v215; // xmm8_4
  float v216; // xmm5_4
  float v217; // xmm7_4
  float v218; // xmm4_4
  float v219; // xmm7_4
  float v220; // xmm5_4
  float v221; // xmm4_4
  float v222; // xmm4_4
  float v223; // xmm8_4
  float v224; // xmm4_4
  float v225; // xmm7_4
  float v226; // xmm5_4
  float v227; // xmm7_4
  float v228; // xmm4_4
  float v229; // xmm5_4
  float v230; // xmm5_4
  float v231; // xmm8_4
  float v232; // xmm5_4
  float v233; // xmm7_4
  float v234; // xmm4_4
  float v235; // xmm7_4
  float v236; // xmm5_4
  float v237; // xmm4_4
  float v238; // xmm4_4
  float v239; // xmm8_4
  float v240; // xmm4_4
  float v241; // xmm7_4
  float v242; // xmm6_4
  float v243; // xmm7_4
  float v244; // xmm4_4
  float v245; // xmm6_4
  float v246; // xmm6_4
  float v247; // xmm8_4
  float v248; // xmm9_4
  float v249; // xmm4_4
  float v250; // xmm8_4
  float v251; // xmm5_4
  float v252; // xmm4_4
  float v253; // xmm4_4
  float v254; // xmm9_4
  float v255; // xmm4_4
  float v256; // xmm8_4
  float v257; // xmm5_4
  float v258; // xmm8_4
  float v259; // xmm4_4
  float v260; // xmm5_4
  float v261; // xmm5_4
  float v262; // xmm9_4
  float v263; // xmm5_4
  float v264; // xmm8_4
  float v265; // xmm4_4
  float v266; // xmm8_4
  float v267; // xmm5_4
  float v268; // xmm4_4
  float v269; // xmm4_4
  float v270; // xmm9_4
  float v271; // xmm4_4
  float v272; // xmm8_4
  float v273; // xmm5_4
  float v274; // xmm8_4
  float v275; // xmm4_4
  float v276; // xmm5_4
  float v277; // xmm6_4
  float v278; // xmm7_4
  float v279; // xmm4_4
  float v280; // xmm6_4
  float v281; // xmm3_4
  float v282; // xmm4_4
  float v283; // xmm4_4
  float v284; // xmm7_4
  float v285; // xmm4_4
  float v286; // xmm6_4
  float v287; // xmm3_4
  float v288; // xmm6_4
  float v289; // xmm4_4
  float v290; // xmm3_4
  float v291; // xmm3_4
  float v292; // xmm7_4
  float v293; // xmm3_4
  float v294; // xmm6_4
  float v295; // xmm4_4
  float v296; // xmm6_4
  float v297; // xmm3_4
  float v298; // xmm4_4
  float v299; // xmm4_4
  float v300; // xmm7_4
  float v301; // xmm4_4
  float v302; // xmm6_4
  float v303; // xmm3_4
  float v304; // xmm6_4
  float v305; // xmm4_4
  float v306; // xmm3_4
  float v307; // xmm3_4
  float v308; // xmm7_4
  float v309; // xmm3_4
  float v310; // xmm8_4
  float v311; // xmm4_4
  float v312; // xmm7_4
  float v313; // xmm5_4
  float v314; // xmm4_4
  float v315; // xmm4_4
  float v316; // xmm8_4
  float v317; // xmm4_4
  float v318; // xmm7_4
  float v319; // xmm5_4
  float v320; // xmm7_4
  float v321; // xmm4_4
  float v322; // xmm5_4
  float v323; // xmm5_4
  float v324; // xmm8_4
  float v325; // xmm5_4
  float v326; // xmm7_4
  float v327; // xmm4_4
  float v328; // xmm7_4
  float v329; // xmm5_4
  float v330; // xmm4_4
  float v331; // xmm4_4
  float v332; // xmm8_4
  float v333; // xmm4_4
  float v334; // xmm7_4
  float v335; // xmm5_4
  float v336; // xmm7_4
  float v337; // xmm4_4
  float v338; // xmm5_4
  float v339; // xmm5_4
  float v340; // xmm8_4
  float v341; // xmm5_4
  float v342; // xmm7_4
  float v343; // xmm4_4
  float v344; // xmm7_4
  float v345; // xmm5_4
  float v346; // xmm4_4
  float v347; // xmm4_4
  float v348; // xmm8_4
  float v349; // xmm4_4
  float v350; // xmm7_4
  float v351; // xmm5_4
  float v352; // xmm7_4
  float v353; // xmm4_4
  float v354; // xmm5_4
  float v355; // xmm5_4
  float v356; // xmm8_4
  float v357; // xmm5_4
  float v358; // xmm7_4
  float v359; // xmm4_4
  float v360; // xmm7_4
  float v361; // xmm5_4
  float v362; // xmm4_4
  float v363; // xmm4_4
  float v364; // xmm8_4
  float v365; // xmm4_4
  float v366; // xmm7_4
  float v367; // xmm6_4
  float v368; // xmm7_4
  float v369; // xmm4_4
  float v370; // xmm6_4
  float v371; // xmm6_4
  float v372; // xmm8_4
  float v373; // xmm9_4
  float v374; // xmm4_4
  float v375; // xmm8_4
  float v376; // xmm5_4
  float v377; // xmm4_4
  float v378; // xmm4_4
  float v379; // xmm9_4
  float v380; // xmm4_4
  float v381; // xmm8_4
  float v382; // xmm5_4
  float v383; // xmm8_4
  float v384; // xmm4_4
  float v385; // xmm5_4
  float v386; // xmm5_4
  float v387; // xmm9_4
  float v388; // xmm5_4
  float v389; // xmm8_4
  float v390; // xmm4_4
  float v391; // xmm8_4
  float v392; // xmm5_4
  float v393; // xmm4_4
  float v394; // xmm4_4
  float v395; // xmm9_4
  float v396; // xmm4_4
  float v397; // xmm8_4
  float v398; // xmm5_4
  float v399; // xmm8_4
  float v400; // xmm4_4
  float v401; // xmm5_4
  float v402; // xmm6_4
  float v403; // xmm7_4
  float v404; // xmm4_4
  float v405; // xmm6_4
  float v406; // xmm3_4
  float v407; // xmm4_4
  float v408; // xmm4_4
  float v409; // xmm7_4
  float v410; // xmm4_4
  float v411; // xmm6_4
  float v412; // xmm3_4
  float v413; // xmm6_4
  float v414; // xmm4_4
  float v415; // xmm3_4
  float v416; // xmm3_4
  float v417; // xmm7_4
  float v418; // xmm3_4
  float v419; // xmm6_4
  float v420; // xmm4_4
  float v421; // xmm6_4
  float v422; // xmm3_4
  float v423; // xmm4_4
  float v424; // xmm4_4
  float v425; // xmm7_4
  float v426; // xmm4_4
  float v427; // xmm6_4
  float v428; // xmm3_4
  float v429; // xmm6_4
  float v430; // xmm4_4
  float v431; // xmm3_4
  float v432; // xmm3_4
  float v433; // xmm7_4
  float v434; // xmm3_4
  float v435; // xmm8_4
  float v436; // xmm4_4
  float v437; // xmm7_4
  float v438; // xmm5_4
  float v439; // xmm4_4
  float v440; // xmm4_4
  float v441; // xmm8_4
  float v442; // xmm4_4
  float v443; // xmm7_4
  float v444; // xmm5_4
  float v445; // xmm7_4
  float v446; // xmm4_4
  float v447; // xmm5_4
  float v448; // xmm5_4
  float v449; // xmm8_4
  float v450; // xmm5_4
  float v451; // xmm7_4
  float v452; // xmm4_4
  float v453; // xmm7_4
  float v454; // xmm5_4
  float v455; // xmm4_4
  float v456; // xmm4_4
  float v457; // xmm8_4
  float v458; // xmm4_4
  float v459; // xmm7_4
  float v460; // xmm5_4
  float v461; // xmm7_4
  float v462; // xmm4_4
  float v463; // xmm5_4
  float v464; // xmm5_4
  float v465; // xmm8_4
  float v466; // xmm5_4
  float v467; // xmm7_4
  float v468; // xmm4_4
  float v469; // xmm7_4
  float v470; // xmm5_4
  float v471; // xmm4_4
  float v472; // xmm4_4
  float v473; // xmm8_4
  float v474; // xmm4_4
  float v475; // xmm7_4
  float v476; // xmm5_4
  float v477; // xmm7_4
  float v478; // xmm4_4
  float v479; // xmm5_4
  float v480; // xmm5_4
  float v481; // xmm8_4
  float v482; // xmm5_4
  float v483; // xmm7_4
  float v484; // xmm4_4
  float v485; // xmm7_4
  float v486; // xmm5_4
  float v487; // xmm4_4
  float v488; // xmm4_4
  float v489; // xmm8_4
  float v490; // xmm4_4
  float v491; // xmm7_4
  float v492; // xmm6_4
  float v493; // xmm7_4
  float v494; // xmm4_4
  float v495; // xmm6_4
  float v496; // xmm6_4
  float v497; // xmm8_4
  float v498; // xmm9_4
  float v499; // xmm4_4
  float v500; // xmm8_4
  float v501; // xmm5_4
  float v502; // xmm4_4
  float v503; // xmm4_4
  float v504; // xmm9_4
  float v505; // xmm4_4
  float v506; // xmm8_4
  float v507; // xmm5_4
  float v508; // xmm8_4
  float v509; // xmm4_4
  float v510; // xmm5_4
  float v511; // xmm5_4
  float v512; // xmm9_4
  float v513; // xmm5_4
  float v514; // xmm8_4
  float v515; // xmm4_4
  float v516; // xmm8_4
  float v517; // xmm5_4
  float v518; // xmm4_4
  float v519; // xmm4_4
  float v520; // xmm9_4
  float v521; // xmm4_4
  float v522; // xmm8_4
  float v523; // xmm5_4
  float v524; // xmm8_4
  float v525; // xmm4_4
  float v526; // xmm5_4
  __int64 v527; // rax
  __int64 v528; // rax
  FMOD::BiquadFilter *v529; // r14
  FMOD::BiquadFilter *v530; // r13
  FMOD::BiquadFilter *v531; // r12
  FMOD::BiquadFilter *v532; // rbp
  FMOD::BiquadFilter *v533; // r15
  FMOD::BiquadFilter *v534; // rbx
  FMOD::BiquadFilter *v535; // r8
  FMOD::BiquadFilter *v536; // r11
  FMOD::BiquadFilter *v537; // r10
  FMOD::BiquadFilter *v538; // r9
  FMOD::BiquadFilter *v539; // rcx
  FMOD::BiquadFilter *v540; // rdi
  FMOD::BiquadFilter *v541; // rsi
  FMOD::BiquadFilter *v542; // rdx
  FMOD::BiquadFilter *v543; // rax
  float v544; // xmm6_4
  float v545; // xmm7_4
  float v546; // xmm4_4
  float v547; // xmm6_4
  float v548; // xmm3_4
  float b0; // xmm4_4
  float v550; // xmm4_4
  float v551; // xmm7_4
  float v552; // xmm4_4
  float v553; // xmm6_4
  float v554; // xmm3_4
  float v555; // xmm6_4
  float v556; // xmm4_4
  float v557; // xmm3_4
  float v558; // xmm3_4
  float v559; // xmm7_4
  float v560; // xmm3_4
  float v561; // xmm6_4
  float v562; // xmm4_4
  float v563; // xmm6_4
  float v564; // xmm3_4
  float v565; // xmm4_4
  float v566; // xmm4_4
  float v567; // xmm7_4
  float v568; // xmm4_4
  float v569; // xmm6_4
  float v570; // xmm3_4
  float v571; // xmm6_4
  float v572; // xmm4_4
  float v573; // xmm3_4
  float v574; // xmm3_4
  float v575; // xmm7_4
  float v576; // xmm3_4
  float v577; // xmm8_4
  float v578; // xmm4_4
  float v579; // xmm7_4
  float v580; // xmm5_4
  float v581; // xmm4_4
  float v582; // xmm4_4
  float v583; // xmm8_4
  float v584; // xmm4_4
  float v585; // xmm7_4
  float v586; // xmm5_4
  float v587; // xmm7_4
  float v588; // xmm4_4
  float v589; // xmm5_4
  float v590; // xmm5_4
  float v591; // xmm8_4
  float v592; // xmm5_4
  float v593; // xmm7_4
  float v594; // xmm4_4
  float v595; // xmm7_4
  float v596; // xmm5_4
  float v597; // xmm4_4
  float v598; // xmm4_4
  float v599; // xmm8_4
  float v600; // xmm4_4
  float v601; // xmm7_4
  float v602; // xmm5_4
  float v603; // xmm7_4
  float v604; // xmm4_4
  float v605; // xmm5_4
  float v606; // xmm5_4
  float v607; // xmm8_4
  float v608; // xmm5_4
  float v609; // xmm7_4
  float v610; // xmm4_4
  float v611; // xmm7_4
  float v612; // xmm5_4
  float v613; // xmm4_4
  float v614; // xmm4_4
  float v615; // xmm8_4
  float v616; // xmm4_4
  float v617; // xmm7_4
  float v618; // xmm5_4
  float v619; // xmm7_4
  float v620; // xmm4_4
  float v621; // xmm5_4
  float v622; // xmm5_4
  float v623; // xmm8_4
  float v624; // xmm5_4
  float v625; // xmm7_4
  float v626; // xmm4_4
  float v627; // xmm7_4
  float v628; // xmm5_4
  float v629; // xmm4_4
  float v630; // xmm4_4
  float v631; // xmm8_4
  float v632; // xmm4_4
  float v633; // xmm7_4
  float v634; // xmm6_4
  float v635; // xmm7_4
  float v636; // xmm4_4
  float v637; // xmm6_4
  float v638; // xmm6_4
  float v639; // xmm8_4
  float v640; // xmm9_4
  float v641; // xmm4_4
  float v642; // xmm8_4
  float v643; // xmm5_4
  float v644; // xmm4_4
  float v645; // xmm4_4
  float v646; // xmm9_4
  float v647; // xmm4_4
  float v648; // xmm8_4
  float v649; // xmm5_4
  float v650; // xmm8_4
  float v651; // xmm4_4
  float v652; // xmm5_4
  float v653; // xmm5_4
  float v654; // xmm9_4
  float v655; // xmm5_4
  float v656; // xmm8_4
  float v657; // xmm4_4
  float v658; // xmm8_4
  float v659; // xmm5_4
  float v660; // xmm4_4
  float v661; // xmm4_4
  float v662; // xmm9_4
  float v663; // xmm4_4
  float v664; // xmm8_4
  float v665; // xmm5_4
  float v666; // xmm8_4
  float v667; // xmm4_4
  float v668; // xmm5_4
  int offset2; // [rsp+8h] [rbp-128h]
  float *offset2a; // [rsp+8h] [rbp-128h]
  int inc; // [rsp+10h] [rbp-120h]
  float *inca; // [rsp+10h] [rbp-120h]
  int offset3; // [rsp+18h] [rbp-118h]
  float *offset3a; // [rsp+18h] [rbp-118h]
  FMOD::BiquadFilter *offset3b; // [rsp+18h] [rbp-118h]
  float *v676; // [rsp+20h] [rbp-110h]
  int v677; // [rsp+20h] [rbp-110h]
  float *v678; // [rsp+28h] [rbp-108h]
  const FMOD::BiquadCoefficients *mCoefficients; // [rsp+28h] [rbp-108h]
  float *v680; // [rsp+30h] [rbp-100h]
  const FMOD::BiquadCoefficients *v681; // [rsp+30h] [rbp-100h]
  float *v682; // [rsp+38h] [rbp-F8h]
  const FMOD::BiquadCoefficients *v683; // [rsp+38h] [rbp-F8h]
  float *v684; // [rsp+40h] [rbp-F0h]
  const FMOD::BiquadCoefficients *v685; // [rsp+40h] [rbp-F0h]
  float *v686; // [rsp+48h] [rbp-E8h]
  const FMOD::BiquadCoefficients *v687; // [rsp+48h] [rbp-E8h]
  float *v688; // [rsp+50h] [rbp-E0h]
  const FMOD::BiquadCoefficients *v689; // [rsp+50h] [rbp-E0h]
  float *v690; // [rsp+58h] [rbp-D8h]
  const FMOD::BiquadCoefficients *v691; // [rsp+58h] [rbp-D8h]
  float *coeff; // [rsp+60h] [rbp-D0h]
  const FMOD::BiquadCoefficients *v693; // [rsp+60h] [rbp-D0h]
  float *v694; // [rsp+68h] [rbp-C8h]
  const FMOD::BiquadCoefficients *v695; // [rsp+68h] [rbp-C8h]
  float *v696; // [rsp+70h] [rbp-C0h]
  const FMOD::BiquadCoefficients *v697; // [rsp+70h] [rbp-C0h]
  float *v698; // [rsp+78h] [rbp-B8h]
  const FMOD::BiquadCoefficients *v699; // [rsp+78h] [rbp-B8h]
  float *v700; // [rsp+80h] [rbp-B0h]
  __int64 v701; // [rsp+80h] [rbp-B0h]
  float *v702; // [rsp+88h] [rbp-A8h]
  const FMOD::BiquadCoefficients *v703; // [rsp+88h] [rbp-A8h]
  float *v704; // [rsp+90h] [rbp-A0h]
  const FMOD::BiquadCoefficients *v705; // [rsp+90h] [rbp-A0h]
  __int64 v706; // [rsp+98h] [rbp-98h]
  const FMOD::BiquadCoefficients *v707; // [rsp+98h] [rbp-98h]
  __int64 v708; // [rsp+A0h] [rbp-90h]
  const FMOD::BiquadCoefficients *v709; // [rsp+A0h] [rbp-90h]
  const FMOD::BiquadCoefficients *v710; // [rsp+A8h] [rbp-88h]
  FMOD::BiquadFilter *v713; // [rsp+C0h] [rbp-70h]
  FMOD::BiquadFilter *v714; // [rsp+C8h] [rbp-68h]
  FMOD::BiquadFilter *v715; // [rsp+D0h] [rbp-60h]
  __int64 v716; // [rsp+D8h] [rbp-58h]
  int v717; // [rsp+E4h] [rbp-4Ch]
  char lengtha; // [rsp+ECh] [rbp-44h]
  int len; // [rsp+F0h] [rbp-40h]

  lengtha = length;
  offset2 = 2 * stride;
  offset3 = 3 * stride;
  inc = 4 * stride;
  v12 = length >> 2;
  len = length >> 2;
  if ( length >> 2 )
  {
    v13 = channel;
    v14 = &(*lowpass1)[v13];
    v15 = &(*lowpass1)[v13 + 32];
    v16 = &(*lowpass1)[v13 + 64];
    v17 = &(*lowpass1)[v13 + 96];
    v18 = &(*highpass1)[v13 + 32];
    v19 = &(*highpass1)[v13 + 64];
    v20 = &(*highpass1)[v13];
    v713 = &(*lowpass2)[v13];
    v21 = &(*highpass2)[v13];
    v22 = &(*lowpass2)[v13 + 32];
    v23 = &(*lowpass2)[v13 + 64];
    v24 = &(*lowpass2)[v13 + 96];
    v714 = &(*highpass1)[v13 + 96];
    v715 = &(*highpass2)[v13 + 32];
    v25 = &(*highpass2)[v13 + 64];
    v26 = &(*highpass2)[v13 + 96];
    v708 = offset2;
    v706 = offset3;
    v716 = 4LL * inc;
    offset2a = v14->mCoefficients->coeff;
    coeff = v15->mCoefficients->coeff;
    v682 = v16->mCoefficients->coeff;
    inca = v17->mCoefficients->coeff;
    v694 = v20->mCoefficients->coeff;
    v684 = v18->mCoefficients->coeff;
    offset3a = v19->mCoefficients->coeff;
    v717 = v12;
    v690 = v25->mCoefficients->coeff;
    v702 = in;
    v696 = v714->mCoefficients->coeff;
    v680 = v26->mCoefficients->coeff;
    v704 = out;
    v686 = v713->mCoefficients->coeff;
    v676 = v22->mCoefficients->coeff;
    v698 = v23->mCoefficients->coeff;
    v688 = v24->mCoefficients->coeff;
    v678 = v21->mCoefficients->coeff;
    v700 = v715->mCoefficients->coeff;
    do
    {
      w2 = v14->w2;
      v28 = offset2a[5] * v14->w1;
      v29 = offset2a[8] * w2;
      v30 = w2 * offset2a[6];
      v31 = (float)(*v702 - (float)(offset2a[7] * v14->w1)) - v29;
      v32 = offset2a[4];
      v14->w2 = v14->w1;
      v14->w1 = v31;
      v33 = (float)(v32 * v31) + v28;
      v34 = coeff[5] * v15->w1;
      v35 = v33 + v30;
      v36 = v15->w2;
      v37 = coeff[8] * v36;
      v38 = v36 * coeff[6];
      v39 = (float)(v35 - (float)(coeff[7] * v15->w1)) - v37;
      v40 = coeff[4];
      v15->w2 = v15->w1;
      v15->w1 = v39;
      v41 = (float)(v40 * v39) + v34;
      v42 = v682[5] * v16->w1;
      v43 = v41 + v38;
      v44 = v16->w2;
      v45 = v682[8] * v44;
      v46 = v44 * v682[6];
      v47 = (float)(v43 - (float)(v682[7] * v16->w1)) - v45;
      v48 = v682[4];
      v16->w2 = v16->w1;
      v16->w1 = v47;
      v49 = (float)(v48 * v47) + v42;
      v50 = inca[5] * v17->w1;
      v51 = v49 + v46;
      v52 = v17->w2;
      v53 = inca[8] * v52;
      v54 = v52 * inca[6];
      v55 = (float)(v51 - (float)(inca[7] * v17->w1)) - v53;
      v56 = inca[4];
      v17->w2 = v17->w1;
      v17->w1 = v55;
      v57 = (float)(v56 * v55) + v50;
      v58 = v20->w2;
      v59 = v57 + v54;
      v60 = v694[5] * v20->w1;
      v61 = v694[8] * v58;
      v62 = v58 * v694[6];
      v63 = (float)(*v702 - (float)(v694[7] * v20->w1)) - v61;
      v64 = v694[4];
      v20->w2 = v20->w1;
      v20->w1 = v63;
      v65 = (float)(v64 * v63) + v60;
      v66 = v684[5] * v18->w1;
      v67 = v65 + v62;
      v68 = v18->w2;
      v69 = v684[8] * v68;
      v70 = v68 * v684[6];
      v71 = (float)(v67 - (float)(v684[7] * v18->w1)) - v69;
      v72 = v684[4];
      v18->w2 = v18->w1;
      v18->w1 = v71;
      v73 = (float)(v72 * v71) + v66;
      v74 = offset3a[5] * v19->w1;
      v75 = v73 + v70;
      v76 = v19->w2;
      v77 = offset3a[8] * v76;
      v78 = v76 * offset3a[6];
      v79 = (float)(v75 - (float)(offset3a[7] * v19->w1)) - v77;
      v80 = offset3a[4];
      v19->w2 = v19->w1;
      v19->w1 = v79;
      v81 = (float)(v80 * v79) + v74;
      v82 = v696[5] * v714->w1;
      v83 = v81 + v78;
      v84 = v714->w2;
      v85 = v696[8] * v84;
      v86 = v84 * v696[6];
      v87 = (float)(v83 - (float)(v696[7] * v714->w1)) - v85;
      v88 = v696[4];
      v714->w2 = v714->w1;
      v714->w1 = v87;
      v89 = (float)(v88 * v87) + v82;
      v90 = v686[5] * v713->w1;
      v91 = v89 + v86;
      v92 = v713->w2;
      v93 = v686[8] * v92;
      v94 = v92 * v686[6];
      v95 = (float)(v91 - (float)(v686[7] * v713->w1)) - v93;
      v96 = v686[4];
      v713->w2 = v713->w1;
      v713->w1 = v95;
      v97 = (float)(v96 * v95) + v90;
      v98 = v676[5] * v22->w1;
      v99 = v97 + v94;
      v100 = v22->w2;
      v101 = v676[8] * v100;
      v102 = v100 * v676[6];
      v103 = (float)(v99 - (float)(v676[7] * v22->w1)) - v101;
      v104 = v676[4];
      v22->w2 = v22->w1;
      v22->w1 = v103;
      v105 = (float)(v104 * v103) + v98;
      v106 = v698[5] * v23->w1;
      v107 = v105 + v102;
      v108 = v23->w2;
      v109 = v698[8] * v108;
      v110 = v108 * v698[6];
      v111 = (float)(v107 - (float)(v698[7] * v23->w1)) - v109;
      v112 = v698[4];
      v23->w2 = v23->w1;
      v23->w1 = v111;
      v113 = (float)(v112 * v111) + v106;
      v114 = v688[5] * v24->w1;
      v115 = v113 + v110;
      v116 = v24->w2;
      v117 = v688[8] * v116;
      v118 = v116 * v688[6];
      v119 = (float)(v115 - (float)(v688[7] * v24->w1)) - v117;
      v120 = v688[4];
      v24->w2 = v24->w1;
      v24->w1 = v119;
      v121 = (float)(v120 * v119) + v114;
      v122 = v21->w2;
      v123 = v678[5] * v21->w1;
      v124 = v678[8] * v122;
      v125 = v122 * v678[6];
      v126 = (float)(*v702 - (float)(v678[7] * v21->w1)) - v124;
      v127 = v678[4];
      v21->w2 = v21->w1;
      v21->w1 = v126;
      v128 = (float)(v127 * v126) + v123;
      v129 = v700[5] * v715->w1;
      v130 = v128 + v125;
      v131 = v715->w2;
      v132 = v700[8] * v131;
      v133 = v131 * v700[6];
      v134 = (float)(v130 - (float)(v700[7] * v715->w1)) - v132;
      v135 = v700[4];
      v715->w2 = v715->w1;
      v715->w1 = v134;
      v136 = (float)(v135 * v134) + v129;
      v137 = v690[5] * v25->w1;
      v138 = v136 + v133;
      v139 = v25->w2;
      v140 = v690[8] * v139;
      v141 = v139 * v690[6];
      v142 = (float)(v138 - (float)(v690[7] * v25->w1)) - v140;
      v143 = v690[4];
      v25->w2 = v25->w1;
      v25->w1 = v142;
      v144 = (float)(v143 * v142) + v137;
      v145 = v680[5] * v26->w1;
      v146 = v144 + v141;
      v147 = v26->w2;
      v148 = v680[8] * v147;
      v149 = v147 * v680[6];
      v150 = (float)(v146 - (float)(v680[7] * v26->w1)) - v148;
      v151 = v680[4];
      v26->w2 = v26->w1;
      v26->w1 = v150;
      *v704 = (float)((float)(v59 * lowgain) + (float)((float)(v121 + v118) * midgain))
            + (float)((float)((float)((float)(v151 * v150) + v145) + v149) * highgain);
      v152 = v14->w2;
      v153 = offset2a[5] * v14->w1;
      v154 = offset2a[8] * v152;
      v155 = v152 * offset2a[6];
      v156 = (float)(v702[stride] - (float)(offset2a[7] * v14->w1)) - v154;
      v157 = offset2a[4];
      v14->w2 = v14->w1;
      v14->w1 = v156;
      v158 = (float)(v157 * v156) + v153;
      v159 = coeff[5] * v15->w1;
      v160 = v158 + v155;
      v161 = v15->w2;
      v162 = coeff[8] * v161;
      v163 = v161 * coeff[6];
      v164 = (float)(v160 - (float)(coeff[7] * v15->w1)) - v162;
      v165 = coeff[4];
      v15->w2 = v15->w1;
      v15->w1 = v164;
      v166 = (float)(v165 * v164) + v159;
      v167 = v682[5] * v16->w1;
      v168 = v166 + v163;
      v169 = v16->w2;
      v170 = v682[8] * v169;
      v171 = v169 * v682[6];
      v172 = (float)(v168 - (float)(v682[7] * v16->w1)) - v170;
      v173 = v682[4];
      v16->w2 = v16->w1;
      v16->w1 = v172;
      v174 = (float)(v173 * v172) + v167;
      v175 = inca[5] * v17->w1;
      v176 = v174 + v171;
      v177 = v17->w2;
      v178 = inca[8] * v177;
      v179 = v177 * inca[6];
      v180 = (float)(v176 - (float)(inca[7] * v17->w1)) - v178;
      v181 = inca[4];
      v17->w2 = v17->w1;
      v17->w1 = v180;
      v182 = (float)(v181 * v180) + v175;
      v183 = v20->w2;
      v184 = v182 + v179;
      v185 = v694[5] * v20->w1;
      v186 = v694[8] * v183;
      v187 = v183 * v694[6];
      v188 = (float)(v702[stride] - (float)(v694[7] * v20->w1)) - v186;
      v189 = v694[4];
      v20->w2 = v20->w1;
      v20->w1 = v188;
      v190 = (float)(v189 * v188) + v185;
      v191 = v684[5] * v18->w1;
      v192 = v190 + v187;
      v193 = v18->w2;
      v194 = v684[8] * v193;
      v195 = v193 * v684[6];
      v196 = (float)(v192 - (float)(v684[7] * v18->w1)) - v194;
      v197 = v684[4];
      v18->w2 = v18->w1;
      v18->w1 = v196;
      v198 = (float)(v197 * v196) + v191;
      v199 = offset3a[5] * v19->w1;
      v200 = v198 + v195;
      v201 = v19->w2;
      v202 = offset3a[8] * v201;
      v203 = v201 * offset3a[6];
      v204 = (float)(v200 - (float)(offset3a[7] * v19->w1)) - v202;
      v205 = offset3a[4];
      v19->w2 = v19->w1;
      v19->w1 = v204;
      v206 = (float)(v205 * v204) + v199;
      v207 = v696[5] * v714->w1;
      v208 = v206 + v203;
      v209 = v714->w2;
      v210 = v696[8] * v209;
      v211 = v209 * v696[6];
      v212 = (float)(v208 - (float)(v696[7] * v714->w1)) - v210;
      v213 = v696[4];
      v714->w2 = v714->w1;
      v714->w1 = v212;
      v214 = (float)(v213 * v212) + v207;
      v215 = v686[5] * v713->w1;
      v216 = v214 + v211;
      v217 = v713->w2;
      v218 = v686[8] * v217;
      v219 = v217 * v686[6];
      v220 = (float)(v216 - (float)(v686[7] * v713->w1)) - v218;
      v221 = v686[4];
      v713->w2 = v713->w1;
      v713->w1 = v220;
      v222 = (float)(v221 * v220) + v215;
      v223 = v676[5] * v22->w1;
      v224 = v222 + v219;
      v225 = v22->w2;
      v226 = v676[8] * v225;
      v227 = v225 * v676[6];
      v228 = (float)(v224 - (float)(v676[7] * v22->w1)) - v226;
      v229 = v676[4];
      v22->w2 = v22->w1;
      v22->w1 = v228;
      v230 = (float)(v229 * v228) + v223;
      v231 = v698[5] * v23->w1;
      v232 = v230 + v227;
      v233 = v23->w2;
      v234 = v698[8] * v233;
      v235 = v233 * v698[6];
      v236 = (float)(v232 - (float)(v698[7] * v23->w1)) - v234;
      v237 = v698[4];
      v23->w2 = v23->w1;
      v23->w1 = v236;
      v238 = (float)(v237 * v236) + v231;
      v239 = v688[5] * v24->w1;
      v240 = v238 + v235;
      v241 = v24->w2;
      v242 = v688[8] * v241;
      v243 = v241 * v688[6];
      v244 = (float)(v240 - (float)(v688[7] * v24->w1)) - v242;
      v245 = v688[4];
      v24->w2 = v24->w1;
      v24->w1 = v244;
      v246 = (float)(v245 * v244) + v239;
      v247 = v21->w2;
      v248 = v678[5] * v21->w1;
      v249 = v678[8] * v247;
      v250 = v247 * v678[6];
      v251 = (float)(v702[stride] - (float)(v678[7] * v21->w1)) - v249;
      v252 = v678[4];
      v21->w2 = v21->w1;
      v21->w1 = v251;
      v253 = (float)(v252 * v251) + v248;
      v254 = v700[5] * v715->w1;
      v255 = v253 + v250;
      v256 = v715->w2;
      v257 = v700[8] * v256;
      v258 = v256 * v700[6];
      v259 = (float)(v255 - (float)(v700[7] * v715->w1)) - v257;
      v260 = v700[4];
      v715->w2 = v715->w1;
      v715->w1 = v259;
      v261 = (float)(v260 * v259) + v254;
      v262 = v690[5] * v25->w1;
      v263 = v261 + v258;
      v264 = v25->w2;
      v265 = v690[8] * v264;
      v266 = v264 * v690[6];
      v267 = (float)(v263 - (float)(v690[7] * v25->w1)) - v265;
      v268 = v690[4];
      v25->w2 = v25->w1;
      v25->w1 = v267;
      v269 = (float)(v268 * v267) + v262;
      v270 = v680[5] * v26->w1;
      v271 = v269 + v266;
      v272 = v26->w2;
      v273 = v680[8] * v272;
      v274 = v272 * v680[6];
      v275 = (float)(v271 - (float)(v680[7] * v26->w1)) - v273;
      v276 = v680[4];
      v26->w2 = v26->w1;
      v26->w1 = v275;
      v704[stride] = (float)((float)(v184 * lowgain) + (float)((float)(v246 + v243) * midgain))
                   + (float)((float)((float)((float)(v276 * v275) + v270) + v274) * highgain);
      v277 = v14->w2;
      v278 = offset2a[5] * v14->w1;
      v279 = offset2a[8] * v277;
      v280 = v277 * offset2a[6];
      v281 = (float)(v702[v708] - (float)(offset2a[7] * v14->w1)) - v279;
      v282 = offset2a[4];
      v14->w2 = v14->w1;
      v14->w1 = v281;
      v283 = (float)(v282 * v281) + v278;
      v284 = coeff[5] * v15->w1;
      v285 = v283 + v280;
      v286 = v15->w2;
      v287 = coeff[8] * v286;
      v288 = v286 * coeff[6];
      v289 = (float)(v285 - (float)(coeff[7] * v15->w1)) - v287;
      v290 = coeff[4];
      v15->w2 = v15->w1;
      v15->w1 = v289;
      v291 = (float)(v290 * v289) + v284;
      v292 = v682[5] * v16->w1;
      v293 = v291 + v288;
      v294 = v16->w2;
      v295 = v682[8] * v294;
      v296 = v294 * v682[6];
      v297 = (float)(v293 - (float)(v682[7] * v16->w1)) - v295;
      v298 = v682[4];
      v16->w2 = v16->w1;
      v16->w1 = v297;
      v299 = (float)(v298 * v297) + v292;
      v300 = inca[5] * v17->w1;
      v301 = v299 + v296;
      v302 = v17->w2;
      v303 = inca[8] * v302;
      v304 = v302 * inca[6];
      v305 = (float)(v301 - (float)(inca[7] * v17->w1)) - v303;
      v306 = inca[4];
      v17->w2 = v17->w1;
      v17->w1 = v305;
      v307 = (float)(v306 * v305) + v300;
      v308 = v20->w2;
      v309 = v307 + v304;
      v310 = v694[5] * v20->w1;
      v311 = v694[8] * v308;
      v312 = v308 * v694[6];
      v313 = (float)(v702[v708] - (float)(v694[7] * v20->w1)) - v311;
      v314 = v694[4];
      v20->w2 = v20->w1;
      v20->w1 = v313;
      v315 = (float)(v314 * v313) + v310;
      v316 = v684[5] * v18->w1;
      v317 = v315 + v312;
      v318 = v18->w2;
      v319 = v684[8] * v318;
      v320 = v318 * v684[6];
      v321 = (float)(v317 - (float)(v684[7] * v18->w1)) - v319;
      v322 = v684[4];
      v18->w2 = v18->w1;
      v18->w1 = v321;
      v323 = (float)(v322 * v321) + v316;
      v324 = offset3a[5] * v19->w1;
      v325 = v323 + v320;
      v326 = v19->w2;
      v327 = offset3a[8] * v326;
      v328 = v326 * offset3a[6];
      v329 = (float)(v325 - (float)(offset3a[7] * v19->w1)) - v327;
      v330 = offset3a[4];
      v19->w2 = v19->w1;
      v19->w1 = v329;
      v331 = (float)(v330 * v329) + v324;
      v332 = v696[5] * v714->w1;
      v333 = v331 + v328;
      v334 = v714->w2;
      v335 = v696[8] * v334;
      v336 = v334 * v696[6];
      v337 = (float)(v333 - (float)(v696[7] * v714->w1)) - v335;
      v338 = v696[4];
      v714->w2 = v714->w1;
      v714->w1 = v337;
      v339 = (float)(v338 * v337) + v332;
      v340 = v686[5] * v713->w1;
      v341 = v339 + v336;
      v342 = v713->w2;
      v343 = v686[8] * v342;
      v344 = v342 * v686[6];
      v345 = (float)(v341 - (float)(v686[7] * v713->w1)) - v343;
      v346 = v686[4];
      v713->w2 = v713->w1;
      v713->w1 = v345;
      v347 = (float)(v346 * v345) + v340;
      v348 = v676[5] * v22->w1;
      v349 = v347 + v344;
      v350 = v22->w2;
      v351 = v676[8] * v350;
      v352 = v350 * v676[6];
      v353 = (float)(v349 - (float)(v676[7] * v22->w1)) - v351;
      v354 = v676[4];
      v22->w2 = v22->w1;
      v22->w1 = v353;
      v355 = (float)(v354 * v353) + v348;
      v356 = v698[5] * v23->w1;
      v357 = v355 + v352;
      v358 = v23->w2;
      v359 = v698[8] * v358;
      v360 = v358 * v698[6];
      v361 = (float)(v357 - (float)(v698[7] * v23->w1)) - v359;
      v362 = v698[4];
      v23->w2 = v23->w1;
      v23->w1 = v361;
      v363 = (float)(v362 * v361) + v356;
      v364 = v688[5] * v24->w1;
      v365 = v363 + v360;
      v366 = v24->w2;
      v367 = v688[8] * v366;
      v368 = v366 * v688[6];
      v369 = (float)(v365 - (float)(v688[7] * v24->w1)) - v367;
      v370 = v688[4];
      v24->w2 = v24->w1;
      v24->w1 = v369;
      v371 = (float)(v370 * v369) + v364;
      v372 = v21->w2;
      v373 = v678[5] * v21->w1;
      v374 = v678[8] * v372;
      v375 = v372 * v678[6];
      v376 = (float)(v702[v708] - (float)(v678[7] * v21->w1)) - v374;
      v377 = v678[4];
      v21->w2 = v21->w1;
      v21->w1 = v376;
      v378 = (float)(v377 * v376) + v373;
      v379 = v700[5] * v715->w1;
      v380 = v378 + v375;
      v381 = v715->w2;
      v382 = v700[8] * v381;
      v383 = v381 * v700[6];
      v384 = (float)(v380 - (float)(v700[7] * v715->w1)) - v382;
      v385 = v700[4];
      v715->w2 = v715->w1;
      v715->w1 = v384;
      v386 = (float)(v385 * v384) + v379;
      v387 = v690[5] * v25->w1;
      v388 = v386 + v383;
      v389 = v25->w2;
      v390 = v690[8] * v389;
      v391 = v389 * v690[6];
      v392 = (float)(v388 - (float)(v690[7] * v25->w1)) - v390;
      v393 = v690[4];
      v25->w2 = v25->w1;
      v25->w1 = v392;
      v394 = (float)(v393 * v392) + v387;
      v395 = v680[5] * v26->w1;
      v396 = v394 + v391;
      v397 = v26->w2;
      v398 = v680[8] * v397;
      v399 = v397 * v680[6];
      v400 = (float)(v396 - (float)(v680[7] * v26->w1)) - v398;
      v401 = v680[4];
      v26->w2 = v26->w1;
      v26->w1 = v400;
      v704[v708] = (float)((float)(v309 * lowgain) + (float)((float)(v371 + v368) * midgain))
                 + (float)((float)((float)((float)(v401 * v400) + v395) + v399) * highgain);
      v402 = v14->w2;
      v403 = offset2a[5] * v14->w1;
      v404 = offset2a[8] * v402;
      v405 = v402 * offset2a[6];
      v406 = (float)(v702[v706] - (float)(offset2a[7] * v14->w1)) - v404;
      v407 = offset2a[4];
      v14->w2 = v14->w1;
      v14->w1 = v406;
      v408 = (float)(v407 * v406) + v403;
      v409 = coeff[5] * v15->w1;
      v410 = v408 + v405;
      v411 = v15->w2;
      v412 = coeff[8] * v411;
      v413 = v411 * coeff[6];
      v414 = (float)(v410 - (float)(coeff[7] * v15->w1)) - v412;
      v415 = coeff[4];
      v15->w2 = v15->w1;
      v15->w1 = v414;
      v416 = (float)(v415 * v414) + v409;
      v417 = v682[5] * v16->w1;
      v418 = v416 + v413;
      v419 = v16->w2;
      v420 = v682[8] * v419;
      v421 = v419 * v682[6];
      v422 = (float)(v418 - (float)(v682[7] * v16->w1)) - v420;
      v423 = v682[4];
      v16->w2 = v16->w1;
      v16->w1 = v422;
      v424 = (float)(v423 * v422) + v417;
      v425 = inca[5] * v17->w1;
      v426 = v424 + v421;
      v427 = v17->w2;
      v428 = inca[8] * v427;
      v429 = v427 * inca[6];
      v430 = (float)(v426 - (float)(inca[7] * v17->w1)) - v428;
      v431 = inca[4];
      v17->w2 = v17->w1;
      v17->w1 = v430;
      v432 = (float)(v431 * v430) + v425;
      v433 = v20->w2;
      v434 = v432 + v429;
      v435 = v694[5] * v20->w1;
      v436 = v694[8] * v433;
      v437 = v433 * v694[6];
      v438 = (float)(v702[v706] - (float)(v694[7] * v20->w1)) - v436;
      v439 = v694[4];
      v20->w2 = v20->w1;
      v20->w1 = v438;
      v440 = (float)(v439 * v438) + v435;
      v441 = v684[5] * v18->w1;
      v442 = v440 + v437;
      v443 = v18->w2;
      v444 = v684[8] * v443;
      v445 = v443 * v684[6];
      v446 = (float)(v442 - (float)(v684[7] * v18->w1)) - v444;
      v447 = v684[4];
      v18->w2 = v18->w1;
      v18->w1 = v446;
      v448 = (float)(v447 * v446) + v441;
      v449 = offset3a[5] * v19->w1;
      v450 = v448 + v445;
      v451 = v19->w2;
      v452 = offset3a[8] * v451;
      v453 = v451 * offset3a[6];
      v454 = (float)(v450 - (float)(offset3a[7] * v19->w1)) - v452;
      v455 = offset3a[4];
      v19->w2 = v19->w1;
      v19->w1 = v454;
      v456 = (float)(v455 * v454) + v449;
      v457 = v696[5] * v714->w1;
      v458 = v456 + v453;
      v459 = v714->w2;
      v460 = v696[8] * v459;
      v461 = v459 * v696[6];
      v462 = (float)(v458 - (float)(v696[7] * v714->w1)) - v460;
      v463 = v696[4];
      v714->w2 = v714->w1;
      v714->w1 = v462;
      v464 = (float)(v463 * v462) + v457;
      v465 = v686[5] * v713->w1;
      v466 = v464 + v461;
      v467 = v713->w2;
      v468 = v686[8] * v467;
      v469 = v467 * v686[6];
      v470 = (float)(v466 - (float)(v686[7] * v713->w1)) - v468;
      v471 = v686[4];
      v713->w2 = v713->w1;
      v713->w1 = v470;
      v472 = (float)(v471 * v470) + v465;
      v473 = v676[5] * v22->w1;
      v474 = v472 + v469;
      v475 = v22->w2;
      v476 = v676[8] * v475;
      v477 = v475 * v676[6];
      v478 = (float)(v474 - (float)(v676[7] * v22->w1)) - v476;
      v479 = v676[4];
      v22->w2 = v22->w1;
      v22->w1 = v478;
      v480 = (float)(v479 * v478) + v473;
      v481 = v698[5] * v23->w1;
      v482 = v480 + v477;
      v483 = v23->w2;
      v484 = v698[8] * v483;
      v485 = v483 * v698[6];
      v486 = (float)(v482 - (float)(v698[7] * v23->w1)) - v484;
      v487 = v698[4];
      v23->w2 = v23->w1;
      v23->w1 = v486;
      v488 = (float)(v487 * v486) + v481;
      v489 = v688[5] * v24->w1;
      v490 = v488 + v485;
      v491 = v24->w2;
      v492 = v688[8] * v491;
      v493 = v491 * v688[6];
      v494 = (float)(v490 - (float)(v688[7] * v24->w1)) - v492;
      v495 = v688[4];
      v24->w2 = v24->w1;
      v24->w1 = v494;
      v496 = (float)(v495 * v494) + v489;
      v497 = v21->w2;
      v498 = v678[5] * v21->w1;
      v499 = v678[8] * v497;
      v500 = v497 * v678[6];
      v501 = (float)(v702[v706] - (float)(v678[7] * v21->w1)) - v499;
      v502 = v678[4];
      v21->w2 = v21->w1;
      v21->w1 = v501;
      v503 = (float)(v502 * v501) + v498;
      v504 = v700[5] * v715->w1;
      v505 = v503 + v500;
      v506 = v715->w2;
      v507 = v700[8] * v506;
      v508 = v506 * v700[6];
      v509 = (float)(v505 - (float)(v700[7] * v715->w1)) - v507;
      v510 = v700[4];
      v715->w2 = v715->w1;
      v715->w1 = v509;
      v511 = (float)(v510 * v509) + v504;
      v512 = v690[5] * v25->w1;
      v513 = v511 + v508;
      v514 = v25->w2;
      v515 = v690[8] * v514;
      v516 = v514 * v690[6];
      v517 = (float)(v513 - (float)(v690[7] * v25->w1)) - v515;
      v518 = v690[4];
      v25->w2 = v25->w1;
      v25->w1 = v517;
      v519 = (float)(v518 * v517) + v512;
      v520 = v680[5] * v26->w1;
      v521 = v519 + v516;
      v522 = v26->w2;
      v523 = v680[8] * v522;
      v524 = v522 * v680[6];
      v525 = (float)(v521 - (float)(v680[7] * v26->w1)) - v523;
      v526 = v680[4];
      v26->w2 = v26->w1;
      v26->w1 = v525;
      v704[v706] = (float)((float)(v434 * lowgain) + (float)((float)(v496 + v493) * midgain))
                 + (float)((float)((float)((float)(v526 * v525) + v520) + v524) * highgain);
      v704 = (float *)((char *)v704 + v716);
      v702 = (float *)((char *)v702 + v716);
      --v717;
    }
    while ( v717 );
    v527 = v716 * ((unsigned int)(len - 1) + 1LL);
    out = (float *)((char *)out + v527);
    in = (float *)((char *)in + v527);
  }
  v677 = lengtha & 3;
  if ( (lengtha & 3) != 0 )
  {
    v528 = channel;
    v529 = &(*lowpass1)[v528];
    v530 = &(*lowpass1)[v528 + 32];
    v531 = &(*lowpass1)[v528 + 64];
    v532 = &(*lowpass1)[v528 + 96];
    v533 = &(*lowpass2)[v528 + 96];
    v534 = &(*highpass1)[v528];
    v535 = &(*lowpass2)[v528];
    v536 = &(*highpass1)[v528 + 32];
    v537 = &(*highpass1)[v528 + 64];
    v538 = &(*highpass1)[v528 + 96];
    v539 = &(*highpass2)[v528 + 32];
    v540 = &(*lowpass2)[v528 + 32];
    offset3b = &(*lowpass2)[v528 + 64];
    v541 = &(*highpass2)[v528];
    v701 = 4LL * stride;
    mCoefficients = (*lowpass1)[v528].mCoefficients;
    v703 = (*lowpass1)[v528 + 32].mCoefficients;
    v691 = (*lowpass1)[v528 + 64].mCoefficients;
    v681 = (*lowpass1)[v528 + 96].mCoefficients;
    v705 = (*highpass1)[v528].mCoefficients;
    v693 = (*highpass1)[v528 + 32].mCoefficients;
    v683 = (*highpass1)[v528 + 64].mCoefficients;
    v707 = (*highpass1)[v528 + 96].mCoefficients;
    v695 = (*lowpass2)[v528].mCoefficients;
    v685 = (*lowpass2)[v528 + 32].mCoefficients;
    v542 = &(*highpass2)[v528 + 64];
    v709 = (*lowpass2)[v528 + 64].mCoefficients;
    v697 = (*lowpass2)[v528 + 96].mCoefficients;
    v687 = (*highpass2)[v528].mCoefficients;
    v710 = (*highpass2)[v528 + 32].mCoefficients;
    v699 = (*highpass2)[v528 + 64].mCoefficients;
    v689 = (*highpass2)[v528 + 96].mCoefficients;
    v543 = &(*highpass2)[v528 + 96];
    do
    {
      v544 = v529->w2;
      v545 = mCoefficients->b1 * v529->w1;
      v546 = mCoefficients->a2 * v544;
      v547 = v544 * mCoefficients->b2;
      v548 = (float)(*in - (float)(mCoefficients->a1 * v529->w1)) - v546;
      b0 = mCoefficients->b0;
      v529->w2 = v529->w1;
      v529->w1 = v548;
      v550 = (float)(b0 * v548) + v545;
      v551 = v703->b1 * v530->w1;
      v552 = v550 + v547;
      v553 = v530->w2;
      v554 = v703->a2 * v553;
      v555 = v553 * v703->b2;
      v556 = (float)(v552 - (float)(v703->a1 * v530->w1)) - v554;
      v557 = v703->b0;
      v530->w2 = v530->w1;
      v530->w1 = v556;
      v558 = (float)(v557 * v556) + v551;
      v559 = v691->b1 * v531->w1;
      v560 = v558 + v555;
      v561 = v531->w2;
      v562 = v691->a2 * v561;
      v563 = v561 * v691->b2;
      v564 = (float)(v560 - (float)(v691->a1 * v531->w1)) - v562;
      v565 = v691->b0;
      v531->w2 = v531->w1;
      v531->w1 = v564;
      v566 = (float)(v565 * v564) + v559;
      v567 = v681->b1 * v532->w1;
      v568 = v566 + v563;
      v569 = v532->w2;
      v570 = v681->a2 * v569;
      v571 = v569 * v681->b2;
      v572 = (float)(v568 - (float)(v681->a1 * v532->w1)) - v570;
      v573 = v681->b0;
      v532->w2 = v532->w1;
      v532->w1 = v572;
      v574 = (float)(v573 * v572) + v567;
      v575 = v534->w2;
      v576 = v574 + v571;
      v577 = v705->b1 * v534->w1;
      v578 = v705->a2 * v575;
      v579 = v575 * v705->b2;
      v580 = (float)(*in - (float)(v705->a1 * v534->w1)) - v578;
      v581 = v705->b0;
      v534->w2 = v534->w1;
      v534->w1 = v580;
      v582 = (float)(v581 * v580) + v577;
      v583 = v693->b1 * v536->w1;
      v584 = v582 + v579;
      v585 = v536->w2;
      v586 = v693->a2 * v585;
      v587 = v585 * v693->b2;
      v588 = (float)(v584 - (float)(v693->a1 * v536->w1)) - v586;
      v589 = v693->b0;
      v536->w2 = v536->w1;
      v536->w1 = v588;
      v590 = (float)(v589 * v588) + v583;
      v591 = v683->b1 * v537->w1;
      v592 = v590 + v587;
      v593 = v537->w2;
      v594 = v683->a2 * v593;
      v595 = v593 * v683->b2;
      v596 = (float)(v592 - (float)(v683->a1 * v537->w1)) - v594;
      v597 = v683->b0;
      v537->w2 = v537->w1;
      v537->w1 = v596;
      v598 = (float)(v597 * v596) + v591;
      v599 = v707->b1 * v538->w1;
      v600 = v598 + v595;
      v601 = v538->w2;
      v602 = v707->a2 * v601;
      v603 = v601 * v707->b2;
      v604 = (float)(v600 - (float)(v707->a1 * v538->w1)) - v602;
      v605 = v707->b0;
      v538->w2 = v538->w1;
      v538->w1 = v604;
      v606 = (float)(v605 * v604) + v599;
      v607 = v695->b1 * v535->w1;
      v608 = v606 + v603;
      v609 = v535->w2;
      v610 = v695->a2 * v609;
      v611 = v609 * v695->b2;
      v612 = (float)(v608 - (float)(v695->a1 * v535->w1)) - v610;
      v613 = v695->b0;
      v535->w2 = v535->w1;
      v535->w1 = v612;
      v614 = (float)(v613 * v612) + v607;
      v615 = v685->b1 * v540->w1;
      v616 = v614 + v611;
      v617 = v540->w2;
      v618 = v685->a2 * v617;
      v619 = v617 * v685->b2;
      v620 = (float)(v616 - (float)(v685->a1 * v540->w1)) - v618;
      v621 = v685->b0;
      v540->w2 = v540->w1;
      v540->w1 = v620;
      v622 = (float)(v621 * v620) + v615;
      v623 = v709->b1 * offset3b->w1;
      v624 = v622 + v619;
      v625 = offset3b->w2;
      v626 = v709->a2 * v625;
      v627 = v625 * v709->b2;
      v628 = (float)(v624 - (float)(v709->a1 * offset3b->w1)) - v626;
      v629 = v709->b0;
      offset3b->w2 = offset3b->w1;
      offset3b->w1 = v628;
      v630 = (float)(v629 * v628) + v623;
      v631 = v697->b1 * v533->w1;
      v632 = v630 + v627;
      v633 = v533->w2;
      v634 = v697->a2 * v633;
      v635 = v633 * v697->b2;
      v636 = (float)(v632 - (float)(v697->a1 * v533->w1)) - v634;
      v637 = v697->b0;
      v533->w2 = v533->w1;
      v533->w1 = v636;
      v638 = (float)(v637 * v636) + v631;
      v639 = v541->w2;
      v640 = v687->b1 * v541->w1;
      v641 = v687->a2 * v639;
      v642 = v639 * v687->b2;
      v643 = (float)(*in - (float)(v687->a1 * v541->w1)) - v641;
      v644 = v687->b0;
      v541->w2 = v541->w1;
      v541->w1 = v643;
      v645 = (float)(v644 * v643) + v640;
      v646 = v710->b1 * v539->w1;
      v647 = v645 + v642;
      v648 = v539->w2;
      v649 = v710->a2 * v648;
      v650 = v648 * v710->b2;
      v651 = (float)(v647 - (float)(v710->a1 * v539->w1)) - v649;
      v652 = v710->b0;
      v539->w2 = v539->w1;
      v539->w1 = v651;
      v653 = (float)(v652 * v651) + v646;
      v654 = v699->b1 * v542->w1;
      v655 = v653 + v650;
      v656 = v542->w2;
      v657 = v699->a2 * v656;
      v658 = v656 * v699->b2;
      v659 = (float)(v655 - (float)(v699->a1 * v542->w1)) - v657;
      v660 = v699->b0;
      v542->w2 = v542->w1;
      v542->w1 = v659;
      v661 = (float)(v660 * v659) + v654;
      v662 = v689->b1 * v543->w1;
      v663 = v661 + v658;
      v664 = v543->w2;
      v665 = v689->a2 * v664;
      v666 = v664 * v689->b2;
      v667 = (float)(v663 - (float)(v689->a1 * v543->w1)) - v665;
      v668 = v689->b0;
      v543->w2 = v543->w1;
      v543->w1 = v667;
      *out = (float)((float)(v576 * lowgain) + (float)((float)(v638 + v635) * midgain))
           + (float)((float)((float)((float)(v668 * v667) + v662) + v666) * highgain);
      in = (float *)((char *)in + v701);
      out = (float *)((char *)out + v701);
      --v677;
    }
    while ( v677 );
  }
}


