// Address: 0x222cd30 | Name: _ZN4FMOD13ChannelStream6updateEi
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::update(FMOD::ChannelStream *const this, int delta_ms)
{
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, int))this->mRealChannel->_vptr_ChannelReal + 8))(
           this->mRealChannel,
           delta_ms);
}


// Address: 0x222cd40 | Name: _ZN4FMOD13ChannelStream9setVolumeEf
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setVolume(FMOD::ChannelStream *const this, double a2, float volume)
{
  FMOD::ChannelReal *mRealChannel; // rdi

  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, double, float))mRealChannel->_vptr_ChannelReal + 13))(
             mRealChannel,
             a2,
             volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x222cd60 | Name: _ZN4FMOD13ChannelStream12setFrequencyEf
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setFrequency(FMOD::ChannelStream *const this, double a2, float frequency)
{
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, double, float))this->mRealChannel->_vptr_ChannelReal + 14))(
           this->mRealChannel,
           a2,
           frequency);
}


// Address: 0x222cd70 | Name: _ZN4FMOD13ChannelStream6setPanEff
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setPan(
        FMOD::ChannelStream *const this,
        double a2,
        float pan,
        float fbpan)
{
  FMOD::ChannelReal *mRealChannel; // rdi

  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, double, float, float))mRealChannel->_vptr_ChannelReal
            + 15))(
             mRealChannel,
             a2,
             pan,
             fbpan);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x222cd90 | Name: _ZN4FMOD13ChannelStream14setLowPassGainEf
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setLowPassGain(FMOD::ChannelStream *const this, double a2, float gain)
{
  FMOD::ChannelReal *mRealChannel; // rdi

  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, double, float))mRealChannel->_vptr_ChannelReal + 21))(
             mRealChannel,
             a2,
             gain);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x222cdc0 | Name: _ZN4FMOD13ChannelStream19setReverbPropertiesEif
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setReverbProperties(
        FMOD::ChannelStream *const this,
        __int64 instance,
        double a3,
        float wet)
{
  FMOD::ChannelReal *mRealChannel; // rdi

  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, __int64, double, float))mRealChannel->_vptr_ChannelReal
            + 22))(
             mRealChannel,
             instance,
             a3,
             wet);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x222cdf0 | Name: _ZN4FMOD13ChannelStream9isPlayingEPbb
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::isPlaying(
        FMOD::ChannelStream *const this,
        bool *isplaying,
        bool includethreadlatency)
{
  *isplaying = !this->mFinished;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222ce70 | Name: _ZN4FMOD13ChannelStream5allocEv
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::alloc(FMOD::ChannelStream *const this)
{
  FMOD::SoundI *mSound; // r12
  FMOD::SystemI *mSystem; // rax
  volatile signed __int32 *p_mFlags; // rdx
  FMOD::SoundI *mSubSoundParent; // rax
  unsigned int mName_high; // eax
  FMOD::ChannelReal *mRealChannel; // rdi
  FMOD::SoundI *v8; // rbp
  __m128 v9; // xmm0
  FMOD_SOUND_TYPE_0 mType; // eax
  FMOD_MODE mMode; // edx
  FMOD::ChannelI *mParent; // rdx
  FMOD_RESULT_0 v13; // ebp
  FMOD::SystemI *v14; // rdi
  int (**vptr_SoundI)(...); // rax

  mSound = this->mSound;
  FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
  this->mFlags &= ~0x80u;
  FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
  mSystem = mSound->mSystem;
  p_mFlags = (volatile signed __int32 *)&mSound->mFlags;
  this->mFinished = 0;
  this->mLastPCM.mValue = 0;
  this->mDecodeOffset = 0;
  this->mSystem = mSystem;
  _InterlockedAnd((volatile signed __int32 *)&mSound->mFlags, 0xFFFFFFBF);
  _InterlockedOr((volatile signed __int32 *)&mSound->mFlags, 0x800u);
  if ( this->mPosition.mValue )
    _InterlockedOr(p_mFlags, 0x10u);
  mSubSoundParent = mSound->mSubSoundParent;
  if ( mSubSoundParent )
  {
    _InterlockedAnd((volatile signed __int32 *)&mSubSoundParent->mFlags, 0xFFFFFFBF);
    mName_high = HIDWORD(mSubSoundParent[1].mName);
  }
  else
  {
    mName_high = HIDWORD(mSound[1].mName);
  }
  this->mPosition.mHi = mName_high;
  mRealChannel = this->mRealChannel;
  v8 = *(FMOD::SoundI **)&mSound[1].mMagic;
  this->mSamplesPlayed = 0;
  this->mSamplesWritten = 0;
  v9 = _mm_cmplt_ss((__m128)LODWORD(mRealChannel->mMinFrequency), (__m128)0x42C80000u);
  LODWORD(this->mMinFrequency) = _mm_andnot_ps(v9, (__m128)LODWORD(mRealChannel->mMinFrequency)).m128_u32[0]
                               | v9.m128_i32[0] & 0x42C80000;
  this->mMaxFrequency = mRealChannel->mMaxFrequency;
  if ( v8 )
  {
    if ( (mSound->mMode & 0x400) != 0
      || (mType = mSound->mType, mType == FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_S3M_0)
      || mType == FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_XM_0
      || (unsigned int)(mType - 6) <= 2
      || mSound->mLength > v8->mLength )
    {
      _InterlockedAnd(p_mFlags, 0xFFFFFF7F);
      (*((void (__fastcall **)(FMOD::SoundI *, __int64))v8->_vptr_SoundI + 35))(v8, 2);
      (*((void (__fastcall **)(FMOD::SoundI *, _QWORD, __int64, _QWORD, __int64))v8->_vptr_SoundI + 39))(
        v8,
        0,
        2,
        v8->mLength - 1,
        2);
    }
    else
    {
      _InterlockedOr(p_mFlags, 0x88u);
      vptr_SoundI = v8->_vptr_SoundI;
      if ( (this->mMode & 6) != 0 )
        vptr_SoundI[35](v8, 2);
      else
        vptr_SoundI[35](v8, 1);
      (*((void (__fastcall **)(FMOD::SoundI *, _QWORD, __int64, _QWORD, __int64))v8->_vptr_SoundI + 39))(
        v8,
        mSound->mLoopStart,
        2,
        mSound->mLoopStart + mSound->mLoopLength - 1,
        2);
    }
    mMode = v8->mMode;
    mRealChannel = this->mRealChannel;
    v8->mSubSoundParent = mSound;
    mRealChannel->mMode = mMode;
    mRealChannel->mLoopStart = v8->mLoopStart;
    mRealChannel->mLoopLength = v8->mLoopLength;
    mRealChannel->mLength = v8->mLength;
  }
  mParent = this->mParent;
  mRealChannel->mSound = v8;
  mRealChannel->mDSP = 0;
  mRealChannel->mLoopCount = -1;
  mRealChannel->mParent = mParent;
  v13 = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *))mRealChannel->_vptr_ChannelReal + 5))(mRealChannel);
  if ( v13 == FMOD_RESULT::FMOD_OK_0 )
  {
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMLIST);
    v14 = this->mSystem;
    this->mStreamNode.mNodeData = this;
    this->mStreamNode.mNodePrev = v14->mStreamListChannelHead.mNodePrev;
    this->mStreamNode.mNodeNext = (FMOD::LinkedListNode *)((char *)&stru_120C0 + (_QWORD)v14);
    v14->mStreamListChannelHead.mNodePrev = &this->mStreamNode;
    this->mStreamNode.mNodePrev->mNodeNext = &this->mStreamNode;
    FMOD::SystemI::leaveCrit(v14, FMOD_SYSTEM_CRIT_STREAMLIST);
  }
  return v13;
}


// Address: 0x222d100 | Name: _ZN4FMOD13ChannelStream4stopEv
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::stop(FMOD::ChannelStream *const this)
{
  bool isCurrentThreadInTable; // al
  bool v3; // zf
  bool v4; // r12
  FMOD_RESULT_0 v5; // ebp
  FMOD::ChannelReal *mRealChannel; // rdi
  FMOD_RESULT_0 v7; // eax
  FMOD::ChannelReal *v8; // rdx
  FMOD::SystemI *mSystem; // rdi
  FMOD::LinkedListNode *p_mStreamNode; // rdx
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *mNodePrev; // rcx
  FMOD::SoundI *mSound; // rax
  FMOD::Codec *mCodec; // rax
  FMOD::File *mFile; // rdi

  isCurrentThreadInTable = FMOD::Thread::isCurrentThreadInTable(this->mSystem->mThreadId);
  v3 = (this->mMode & 0x10000) == 0;
  v4 = isCurrentThreadInTable;
  this->mFinished = 1;
  if ( v3 || isCurrentThreadInTable )
  {
    mSound = this->mSound;
    if ( mSound )
    {
      mCodec = mSound->mCodec;
      if ( mCodec )
      {
        mFile = mCodec->mFile;
        if ( mFile )
          FMOD::File::cancel(mFile);
      }
    }
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMUPDATE);
  }
  v5 = FMOD_RESULT::FMOD_OK_0;
  FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
  {
    v7 = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *))mRealChannel->_vptr_ChannelReal + 10))(mRealChannel);
    v8 = this->mRealChannel;
    v5 = v7;
    v8->mSound = 0;
    v8->mDSP = 0;
    v8->mParent = 0;
    this->mRealChannel = 0;
  }
  FMOD::ChannelReal::stop(this);
  FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
  if ( (this->mMode & 0x10000) == 0 || v4 )
    FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMUPDATE);
  FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMLIST);
  mSystem = this->mSystem;
  p_mStreamNode = &this->mStreamNode;
  mNodeNext = this->mStreamNode.mNodeNext;
  if ( mSystem->mStreamListChannelNext == &this->mStreamNode )
    mSystem->mStreamListChannelNext = mNodeNext;
  mNodePrev = this->mStreamNode.mNodePrev;
  mNodePrev->mNodeNext = mNodeNext;
  this->mStreamNode.mNodeNext->mNodePrev = mNodePrev;
  this->mStreamNode.mNodePrev = p_mStreamNode;
  this->mStreamNode.mNodeNext = p_mStreamNode;
  this->mStreamNode.mNodeData = 0;
  FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMLIST);
  return v5;
}


// Address: 0x222d270 | Name: _ZN4FMOD13ChannelStream13getPositionExEPjj
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::getPositionEx(
        FMOD::ChannelStream *const this,
        unsigned int *position,
        FMOD_TIMEUNIT postype)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rax
  FMOD_UINT32_32 pcm; // [rsp+0h] [rbp-18h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( position && this->mSound )
  {
    if ( (postype & 2) != 0 )
    {
      *position = this->mPosition.mHi;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else if ( (postype & 0x10) != 0 )
    {
      mRealChannel = this->mRealChannel;
      if ( mRealChannel )
      {
        result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, FMOD_UINT32_32 *))mRealChannel->_vptr_ChannelReal
                  + 17))(
                   this->mRealChannel,
                   &pcm);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          *position = pcm.mLo;
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
      else
      {
        *position = this->mPosition.mLo;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
    else
    {
      return FMOD::Stream::getPosition((FMOD::Stream *const)this->mSound, position, (unsigned __int8)postype);
    }
  }
  return result;
}


// Address: 0x222d300 | Name: _ZN4FMOD13ChannelStream13setLoopPointsEjj
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setLoopPoints(
        FMOD::ChannelStream *const this,
        unsigned int loopstart,
        unsigned int looplength)
{
  if ( FMOD::ChannelReal::setLoopPoints(this, loopstart, looplength) == FMOD_RESULT::FMOD_OK_0 )
    (*((void (__fastcall **)(FMOD::SoundI *, _QWORD, __int64, _QWORD, __int64))this->mSound->_vptr_SoundI + 39))(
      this->mSound,
      loopstart,
      2,
      loopstart + looplength - 1,
      2);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222d340 | Name: _ZN4FMOD13ChannelStream7setModeEj
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setMode(FMOD::ChannelStream *const this, FMOD_MODE mode)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rdi
  int (**vptr_ChannelReal)(...); // rax

  result = FMOD::ChannelReal::setMode(this, mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD))this->mSound->_vptr_SoundI + 35))(
               this->mSound,
               mode);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mRealChannel = this->mRealChannel;
      vptr_ChannelReal = mRealChannel->_vptr_ChannelReal;
      if ( (this->mSound->FMOD::LinkedListNode::mFlags.m_value & 0x80u) == 0 )
        return (FMOD_RESULT_0)vptr_ChannelReal[25](mRealChannel, mode & 0xFFFFFFF8);
      else
        return (FMOD_RESULT_0)vptr_ChannelReal[25](mRealChannel, mode);
    }
  }
  return result;
}


// Address: 0x222d3c0 | Name: _ZN4FMOD13ChannelStream12setLoopCountEi
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setLoopCount(FMOD::ChannelStream *const this, int loopcount)
{
  FMOD_RESULT_0 result; // eax

  if ( !this->mRealChannel )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  result = FMOD::ChannelReal::setLoopCount(this, loopcount);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD))this->mSound->_vptr_SoundI + 37))(
               this->mSound,
               (unsigned int)loopcount);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD_RESULT::FMOD_OK_0;
      if ( (this->mSound->FMOD::LinkedListNode::mFlags.m_value & 0x80) != 0 )
        return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, _QWORD))this->mRealChannel->_vptr_ChannelReal + 19))(
                 this->mRealChannel,
                 (unsigned int)loopcount);
    }
  }
  return result;
}


// Address: 0x222d440 | Name: _ZN4FMOD13ChannelStream13setPositionExEjjb
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setPositionEx(
        FMOD::ChannelStream *const this,
        unsigned int position,
        FMOD_TIMEUNIT postype,
        bool fromasync)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SoundI *mSound; // r13
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // r14d
  FMOD::ChannelI *mParent; // rax
  __int64 v10; // rdx
  _BOOL4 v11; // ecx
  FMOD::ChannelReal *v12; // rdi
  FMOD_RESULT_0 v13; // r14d
  char v14; // cl
  FMOD::ChannelReal *v15; // rdi
  unsigned int v16; // r15d
  FMOD::ChannelReal *mRealChannel; // rdi
  FMOD::ChannelReal *v18; // rdi
  FMOD::ChannelReal *v19; // rdi
  __int64 v20; // rdx
  FMOD::ChannelReal *v21; // rdi
  bool v22; // cl
  bool v23; // cl
  FMOD_RESULT_0 v24; // eax
  FMOD::ChannelReal *v25; // rdi
  FMOD::SoundI *mSubSoundParent; // rax
  FMOD::AsyncData *mAsyncData; // rax
  FMOD::AsyncData *v28; // rax
  FMOD::AsyncThread *mThread; // rdx
  FMOD_OS_CRITICALSECTION *mCrit; // rdi
  FMOD_OS_SEMAPHORE *mSema; // rdi
  _BOOL4 v32; // [rsp+Ch] [rbp-4Ch]
  _BOOL4 v33; // [rsp+Ch] [rbp-4Ch]
  bool v34; // [rsp+Ch] [rbp-4Ch]
  bool v35; // [rsp+Ch] [rbp-4Ch]
  bool paused[57]; // [rsp+1Fh] [rbp-39h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( SLOBYTE(this->mFlags) < 0 )
    return result;
  mSound = this->mSound;
  LOBYTE(result) = 31;
  if ( !mSound )
    return result;
  result = mSound->mOpenState.m_value;
  if ( result == FMOD_RESULT::FMOD_ERR_DSP_FORMAT_0 )
  {
    LOBYTE(result) = 46;
    if ( !fromasync )
      return result;
  }
  v32 = fromasync;
  mFlags = 0;
  FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
  mParent = this->mParent;
  if ( mParent )
    mFlags = mParent->mFlags;
  FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
  v11 = v32;
  if ( !this->mParent )
    return FMOD_RESULT::FMOD_OK_0;
  if ( (mFlags & 0x240000) == 0x40000 && position && postype == 2 )
  {
    v16 = mSound->mPosition - *(_DWORD *)(*(_QWORD *)&mSound[1].mMagic + 68LL);
    if ( position >= v16 && position < v16 + mSound[1].mMode )
    {
      FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
      mRealChannel = this->mRealChannel;
      if ( mRealChannel )
        (*((void (__fastcall **)(FMOD::ChannelReal *, unsigned __int64))mRealChannel->_vptr_ChannelReal + 16))(
          mRealChannel,
          (unsigned __int64)(position - v16) << 32);
      FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
      this->mLastPCM.mLo = 0;
      this->mPosition.mHi = position;
      this->mPosition.mLo = 0;
      this->mLastPCM.mHi = position - v16;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  else if ( postype == 16 )
  {
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
    v18 = this->mRealChannel;
    if ( v18 )
      (*((void (__fastcall **)(FMOD::ChannelReal *, _QWORD, __int64, _QWORD))v18->_vptr_ChannelReal + 27))(
        v18,
        position,
        16,
        0);
    FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( (mSound->mFlags.m_value & 0x80u) != 0 )
  {
    v12 = this->mRealChannel;
    if ( !v12
      || (result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, unsigned __int64, __int64, _BOOL4))v12->_vptr_ChannelReal
                    + 16))(
                     v12,
                     (unsigned __int64)position << 32,
                     v10,
                     v32)) == FMOD_RESULT::FMOD_OK_0 )
    {
      this->mPosition.mHi = position;
      this->mLastPCM.mHi = position;
      this->mPosition.mLo = 0;
      this->mLastPCM.mLo = 0;
      this->mDecodeOffset = 0;
      this->mSamplesWritten = 0;
      this->mSamplesPlayed = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
    return result;
  }
  if ( postype == 2 && mSound->mSubSoundIndex == mSound->mCodec->mSubSoundIndex && (mSound->mFlags.m_value & 0x10) == 0 )
  {
    if ( (this->mFlags & 0x40) == 0 )
      return FMOD_RESULT::FMOD_OK_0;
    if ( (mFlags & 0x10000) != 0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( (mSound->mMode & 0x10000) == 0 )
  {
    paused[0] = 0;
    if ( !v32 )
    {
      FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMUPDATE);
      v13 = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, bool *))this->mRealChannel->_vptr_ChannelReal + 12))(
              this->mRealChannel,
              paused);
      v11 = v32;
      if ( v13 )
        goto LABEL_24;
      v19 = this->mRealChannel;
      if ( v19 )
      {
        (*((void (__fastcall **)(FMOD::ChannelReal *, __int64))v19->_vptr_ChannelReal + 11))(v19, 1);
        v11 = v32;
      }
    }
LABEL_20:
    v33 = v11;
    v13 = FMOD::Stream::setPosition((FMOD::Stream *const)mSound, position, postype);
    v14 = v33;
    if ( v13 == FMOD_RESULT::FMOD_OK_0 )
    {
      FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
      v21 = this->mRealChannel;
      v22 = v33;
      if ( v21 )
      {
        (*((void (__fastcall **)(FMOD::ChannelReal *, _QWORD, __int64, _BOOL4))v21->_vptr_ChannelReal + 16))(
          v21,
          0,
          v20,
          v33);
        v22 = v33;
      }
      v34 = v22;
      FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
      this->mLastPCM.mValue = 0;
      this->mDecodeOffset = 0;
      this->mSamplesWritten = 0;
      this->mSamplesPlayed = 0;
      v23 = v34;
      if ( postype == 2 )
      {
        this->mPosition.mHi = position;
      }
      else
      {
        FMOD::Codec::getPosition(mSound->mCodec, &this->mPosition.mHi, 2u);
        v23 = v34;
      }
      v35 = v23;
      v24 = FMOD::Stream::flush((FMOD::Stream *const)mSound);
      v14 = v35;
      v13 = v24;
    }
    if ( v14 )
      return v13;
    v15 = this->mRealChannel;
    if ( v15 )
      (*((void (__fastcall **)(FMOD::ChannelReal *, bool))v15->_vptr_ChannelReal + 11))(v15, paused[0]);
LABEL_24:
    FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMUPDATE);
    return v13;
  }
  if ( v32 )
  {
    paused[0] = 0;
    goto LABEL_20;
  }
  FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
  this->mFlags |= 0x4000u;
  FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
  v25 = this->mRealChannel;
  if ( v25 )
    (*((void (__fastcall **)(FMOD::ChannelReal *, __int64))v25->_vptr_ChannelReal + 11))(v25, 1);
  FMOD::SoundI::clear(*(FMOD::SoundI *const *)&mSound[1].mMagic, 0, *(_DWORD *)(*(_QWORD *)&mSound[1].mMagic + 68LL));
  FMOD_OS_CriticalSection_Enter(mSound->mAsyncData->mThread->mCrit);
  mSound->mOpenState.m_value = FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0;
  _mm_mfence();
  mSubSoundParent = mSound->mSubSoundParent;
  if ( mSubSoundParent )
  {
    mSubSoundParent->mOpenState.m_value = FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0;
    _mm_mfence();
  }
  mAsyncData = mSound->mAsyncData;
  mAsyncData->mNode.mNodeData = mSound;
  mAsyncData->mPosition = position;
  mAsyncData->mPositionType = postype;
  v28 = mSound->mAsyncData;
  mThread = v28->mThread;
  mCrit = mThread->mCrit;
  v28->mNode.mNodePrev = mThread->mHead.mNodePrev;
  v28->mNode.mNodeNext = &mThread->mHead;
  mThread->mHead.mNodePrev = &v28->mNode;
  v28->mNode.mNodePrev->mNodeNext = &v28->mNode;
  FMOD_OS_CriticalSection_Leave(mCrit);
  mSema = mSound->mAsyncData->mThread->mThread.mSema;
  if ( !mSema )
    return FMOD_RESULT::FMOD_OK_0;
  FMOD_OS_Semaphore_Signal(mSema);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222d920 | Name: _ZN4FMOD13ChannelStream9setPausedEb
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setPaused(FMOD::ChannelStream *const this, bool paused)
{
  FMOD::SystemI *mSystem; // rbp
  char v3; // r14
  FMOD_RESULT_0 v4; // r12d

  mSystem = this->mSystem;
  if ( mSystem )
  {
    v3 = 1;
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
  }
  else
  {
    v3 = 0;
  }
  v4 = FMOD::ChannelReal::setPaused(this, paused);
  if ( v4 == FMOD_RESULT::FMOD_OK_0 && (this->mFlags & 0x4000) == 0 )
    v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, bool))this->mRealChannel->_vptr_ChannelReal + 11))(
           this->mRealChannel,
           paused);
  if ( !v3 || !mSystem )
    return v4;
  FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
  return v4;
}


// Address: 0x222d9c0 | Name: _ZN4FMOD13ChannelStream5startEv
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::start(FMOD::ChannelStream *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rdi
  FMOD::SystemI *mSystem; // rbp
  FMOD_RESULT_0 v5; // ebx

  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *))mRealChannel->_vptr_ChannelReal + 7))(mRealChannel);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mSystem = this->mSystem;
      if ( mSystem )
      {
        FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
        v5 = FMOD::ChannelReal::start(this);
        FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
        return v5;
      }
      else
      {
        return FMOD::ChannelReal::start(this);
      }
    }
  }
  return result;
}


// Address: 0x222da40 | Name: _ZN4FMOD13ChannelStream12updateStreamEv
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::updateStream(FMOD::ChannelStream *const this)
{
  bool *p_isplaying; // rsi
  __int64 v2; // r8
  FMOD::SystemI *mSystem; // r12
  char v5; // r15
  __int64 v6; // r9
  FMOD::SoundI *mSound; // rbp
  __int64 v8; // rdx
  __int64 v9; // r14
  volatile signed __int32 *p_mFlags; // r13
  FMOD::ChannelReal *mRealChannel; // rdi
  unsigned int v13; // eax
  FMOD::ChannelReal *v14; // rdi
  unsigned int mSamplesWritten; // edx
  unsigned int mSamplesPlayed; // eax
  signed int v17; // eax
  unsigned int mLoopStart; // edx
  unsigned int mLength; // eax
  __int64 v20; // rdx
  __int64 mLoopCount; // rcx
  unsigned int mDecodeOffset; // esi
  unsigned int v23; // eax
  unsigned int mMode; // r10d
  FMOD_RESULT_0 v25; // eax
  __int64 v26; // rcx
  unsigned int v27; // r10d
  unsigned int v28; // edx
  unsigned int v29; // eax
  FMOD_RESULT_0 v30; // eax
  unsigned int v31; // esi
  unsigned int mLoopLength; // edi
  unsigned int v33; // esi
  unsigned int v34; // eax
  FMOD::ChannelReal *v35; // rdi
  FMOD::AsyncData *mAsyncData; // rax
  FMOD::ChannelReal *v37; // rdi
  unsigned int v38; // eax
  FMOD::CHANNELREAL_FLAG v39; // [rsp+4h] [rbp-64h]
  int v40; // [rsp+4h] [rbp-64h]
  int v41; // [rsp+4h] [rbp-64h]
  unsigned int lenb; // [rsp+8h] [rbp-60h]
  unsigned int len; // [rsp+8h] [rbp-60h]
  unsigned int lena; // [rsp+8h] [rbp-60h]
  unsigned int lenc; // [rsp+8h] [rbp-60h]
  FMOD_RESULT_0 result; // [rsp+Ch] [rbp-5Ch]
  FMOD_RESULT_0 resulta; // [rsp+Ch] [rbp-5Ch]
  bool isplaying; // [rsp+1Fh] [rbp-49h] BYREF
  FMOD_UINT32_32 pcm; // [rsp+20h] [rbp-48h] BYREF

  mSystem = this->mSystem;
  pcm.mValue = 0;
  if ( mSystem )
  {
    p_isplaying = (bool *)&byte_7;
    v5 = 1;
    FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
    v6 = 1;
  }
  else
  {
    v5 = 0;
    v6 = 0;
  }
  mSound = this->mSound;
  v8 = 0;
  if ( !mSound )
    goto LABEL_7;
  v9 = *(_QWORD *)&mSound[1].mMagic;
  if ( mSound->mOpenState.m_value )
  {
    LOBYTE(v8) = 46;
    if ( mSound->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0 )
      _InterlockedOr((volatile signed __int32 *)&mSound->mFlags, 0x400u);
    goto LABEL_7;
  }
  p_mFlags = (volatile signed __int32 *)&mSound->mFlags;
  _InterlockedAnd((volatile signed __int32 *)&mSound->mFlags, 0xFFFFFBFF);
  v39 = this->mFlags & 0x80;
  if ( !v39 )
  {
    mRealChannel = this->mRealChannel;
    if ( mRealChannel )
    {
      lenb = v6;
      p_isplaying = &isplaying;
      v13 = (*((__int64 (__fastcall **)(FMOD::ChannelReal *, bool *, _QWORD))mRealChannel->_vptr_ChannelReal + 23))(
              mRealChannel,
              &isplaying,
              0);
      v8 = v13;
      v6 = lenb;
      if ( v13 )
        goto LABEL_7;
      if ( !isplaying )
        this->mFinished = 1;
    }
    if ( this->mFinished )
    {
      _InterlockedOr(p_mFlags, 8u);
      LODWORD(v8) = 0;
      goto LABEL_7;
    }
    v14 = this->mRealChannel;
    if ( !v14
      || (len = v6,
          LODWORD(v8) = (*((__int64 (__fastcall **)(FMOD::ChannelReal *, bool *, __int64))v14->_vptr_ChannelReal + 9))(
                          v14,
                          p_isplaying,
                          v8),
          !(_DWORD)v8)
      && (LODWORD(v8) = (*((__int64 (__fastcall **)(FMOD::ChannelReal *, FMOD_UINT32_32 *, _QWORD))this->mRealChannel->_vptr_ChannelReal
                         + 17))(
                          this->mRealChannel,
                          &pcm,
                          0),
          v6 = len,
          !(_DWORD)v8) )
    {
      if ( mSystem && v5 )
      {
        FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
        v6 = 0;
      }
      mSamplesWritten = this->mSamplesWritten;
      while ( 1 )
      {
        mSamplesPlayed = this->mSamplesPlayed;
        if ( (mSamplesPlayed <= mSamplesWritten || mSamplesPlayed - mSamplesWritten < mSound[1].mMode)
          && (!mSamplesPlayed || mSamplesPlayed >= mSamplesWritten || mSamplesWritten - mSamplesPlayed < mSound[1].mMode) )
        {
          break;
        }
        v5 = v6;
        if ( mSystem && !(_BYTE)v6 )
        {
          v5 = 1;
          FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
          v6 = 1;
        }
        if ( SLOBYTE(this->mFlags) < 0 || (*p_mFlags & 0x80u) != 0 )
          goto LABEL_31;
        mDecodeOffset = this->mDecodeOffset;
        v23 = *(_DWORD *)(v9 + 68);
        mMode = mSound[1].mMode;
        if ( mDecodeOffset <= v23 )
        {
          if ( v23 < mMode + mDecodeOffset )
            mMode = v23 - mDecodeOffset;
        }
        else
        {
          mMode = 0;
        }
        if ( mSystem )
        {
          lena = mMode;
          if ( v5 )
          {
            FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
            v25 = FMOD::Stream::fill((FMOD::Stream *const)mSound, this->mDecodeOffset, lena, 0);
          }
          else
          {
            v25 = FMOD::Stream::fill((FMOD::Stream *const)mSound, mDecodeOffset, mMode, 0);
          }
          result = v25;
          v5 = 1;
          FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
          v8 = (unsigned int)result;
          v27 = lena;
          v6 = 1;
        }
        else
        {
          resulta = (int)v6;
          lenc = mMode;
          v30 = FMOD::Stream::fill((FMOD::Stream *const)mSound, mDecodeOffset, mMode, 0);
          v27 = lenc;
          v8 = (unsigned int)v30;
          v6 = (unsigned int)resulta;
        }
        if ( (_DWORD)v8 && (unsigned int)(v8 - 15) > 1 )
        {
          v35 = this->mRealChannel;
          if ( v35 )
          {
            v41 = v8;
            (*((void (__fastcall **)(FMOD::ChannelReal *, __int64, __int64, __int64, __int64, __int64))v35->_vptr_ChannelReal
             + 11))(
              v35,
              1,
              v8,
              v26,
              v2,
              v6);
            LODWORD(v8) = v41;
          }
          mSound->mOpenState.m_value = FMOD_OPENSTATE::FMOD_OPENSTATE_ERROR_0;
          _mm_mfence();
          mAsyncData = mSound->mAsyncData;
          if ( mAsyncData )
            mAsyncData->mResult = v8;
          this->mFinished = 1;
          _InterlockedOr(p_mFlags, 8u);
          goto LABEL_7;
        }
        _InterlockedOr(p_mFlags, 0x10u);
        v28 = *(_DWORD *)(v9 + 68);
        v29 = v27 + this->mDecodeOffset;
        this->mDecodeOffset = v29;
        if ( v29 >= v28 )
          this->mDecodeOffset = v29 - v28;
        mSamplesWritten = v27 + this->mSamplesWritten;
        this->mSamplesWritten = mSamplesWritten;
        if ( mSystem && v5 )
        {
          FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
          mSamplesWritten = this->mSamplesWritten;
          v6 = 0;
        }
      }
      v5 = v6;
LABEL_31:
      v17 = pcm.mHi - this->mLastPCM.mHi;
      if ( v17 >= 0 || (v17 += *(_DWORD *)(v9 + 80), v17 >= 0) )
        v39 = v17;
      if ( mSystem && !v5 )
      {
        v5 = 1;
        FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
      }
      mLoopStart = this->mLoopStart;
      mLength = mSound->mLength;
      if ( mLength < mLoopStart + this->mLoopLength )
        this->mLoopLength = mLength - mLoopStart;
      if ( (this->mMode & 2) != 0 )
      {
        mLoopCount = (unsigned int)this->mLoopCount;
        if ( (_DWORD)mLoopCount )
        {
          mLoopLength = this->mLoopLength;
          v33 = this->mPosition.mHi + v39;
          this->mPosition.mHi = v33;
          if ( mLoopStart + mLoopLength - 1 < v33 )
          {
            v34 = (v33 - mLoopStart) / mLoopLength;
            if ( (int)mLoopCount > 0 )
            {
              if ( v34 > (unsigned int)mLoopCount )
                v34 = mLoopCount;
              this->mLoopCount = mLoopCount - v34;
            }
            this->mPosition.mHi = v33 - mLoopLength * v34;
          }
          goto LABEL_42;
        }
        v31 = this->mPosition.mHi + v39;
        v20 = mLength - 1;
        this->mPosition.mHi = v31;
        if ( (unsigned int)v20 < v31 )
          goto LABEL_40;
      }
      else
      {
        v20 = this->mPosition.mHi + v39;
        mLoopCount = mLength - 1;
        this->mPosition.mHi = v20;
        if ( (unsigned int)mLoopCount < (unsigned int)v20 )
        {
LABEL_40:
          if ( mLength == -1 )
          {
            this->mPosition.mValue = 0;
          }
          else if ( (mSound->mFlags.m_value & 8) != 0 )
          {
            v37 = this->mRealChannel;
            v38 = mSound->mLength;
            this->mPosition.mLo = 0;
            this->mPosition.mHi = v38;
            if ( v37 )
              (*((void (__fastcall **)(FMOD::ChannelReal *, __int64, __int64, __int64, __int64, __int64))v37->_vptr_ChannelReal
               + 11))(
                v37,
                1,
                v20,
                mLoopCount,
                v2,
                v6);
            this->mFinished = 1;
          }
        }
      }
LABEL_42:
      if ( mSystem && v5 )
      {
        v5 = 0;
        FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
      }
      this->mSamplesPlayed += v39;
      LODWORD(v8) = 0;
      this->mLastPCM = pcm;
    }
  }
LABEL_7:
  if ( v5 && mSystem )
  {
    v40 = v8;
    FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
    LODWORD(v8) = v40;
  }
  return (int)v8;
}


// Address: 0x222dfa0 | Name: _ZN4FMOD13ChannelStreamC2Ev
void __fastcall FMOD::ChannelStream::ChannelStream(FMOD::ChannelStream *const this)
{
  FMOD::ChannelReal::ChannelReal(this);
  this->mNodeData = 0;
  this->mStreamNode.mNodeData = 0;
  this->mRealChannel = 0;
  this->mSamplesWritten = 0;
  this->mNodePrev = &this->FMOD::LinkedListNode;
  this->mNodeNext = &this->FMOD::LinkedListNode;
  this->mSamplesPlayed = 0;
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2630;
  this->mStreamNode.mNodePrev = &this->mStreamNode;
  this->mStreamNode.mNodeNext = &this->mStreamNode;
}


// Address: 0x222e010 | Name: _ZN4FMOD13ChannelStream14setRealChannelEPNS_11ChannelRealE
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setRealChannel(
        FMOD::ChannelStream *const this,
        FMOD::ChannelReal *realchan)
{
  this->mRealChannel = realchan;
  return FMOD_RESULT::FMOD_OK_0;
}


