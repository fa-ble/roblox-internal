// Address: 0x2205940 | Name: _ZN4FMOD13DSPPitchShift16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPPitchShift::getDescriptionEx()
{
  memset(&stru_2AF6B00, 0, sizeof(stru_2AF6B00));
  FMOD_strcpy_safe(stru_2AF6B00.name, "Pitch", 16);
  FMOD_strcpy_safe(stru_2AF6B00.label, "x", 16);
  *(_QWORD *)&stru_2AF6B00.floatdesc.min = 0x400000003F000000LL;
  stru_2AF6B00.description = "Pitch value.  0.5 to 2.0.  Default = 1.0. 0.5 = one octave down, 2.0 = one octave up.  1.0 "
                             "does not change the pitch.";
  memset(&stru_2AF6AA0, 0, sizeof(stru_2AF6AA0));
  stru_2AF6B00.intdesc.defaultval = 1065353216;
  stru_2AF6B00.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF6AA0.name, "FFT size", 16);
  FMOD_strcpy_safe(stru_2AF6AA0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF6AA0.floatdesc.min = 0x4580000043800000LL;
  stru_2AF6AA0.description = "FFT window size.  256, 512, 1024, 2048, 4096.  Default = 1024.  Increase this to reduce 'sm"
                             "earing'.  This effect is a warbling sound similar to when an mp3 is encoded at very low bitrates.";
  memset(&stru_2AF6A40, 0, sizeof(stru_2AF6A40));
  stru_2AF6AA0.intdesc.defaultval = 1149239296;
  stru_2AF6AA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF6A40.name, "Overlap", 16);
  FMOD_strcpy_safe(stru_2AF6A40.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF6A40.floatdesc.min = 0x420000003F800000LL;
  stru_2AF6A40.description = "Window overlap.  1 to 32.  Default = 4.  Increase this to reduce 'tremolo' effect.  Increas"
                             "ing it by a factor of 2 doubles the CPU usage.";
  memset(&stru_2AF69E0, 0, sizeof(stru_2AF69E0));
  stru_2AF6A40.intdesc.defaultval = 1082130432;
  stru_2AF6A40.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF69E0.name, "Max channels", 16);
  FMOD_strcpy_safe(stru_2AF69E0.label, "channels", 16);
  stru_2AF69E0.description = "Maximum channels supported.  0 to 16.  0 = same as fmod's default output polyphony, 1 = mon"
                             "o, 2 = stereo etc.  See remarks for more.  Default = 0.  It is suggested to leave at 0!";
  *(_QWORD *)&stru_2AF69E0.floatdesc.min = 0x4180000000000000LL;
  stru_2AF69E0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AF69E0.intdesc.defaultval = 0;
  stru_2AF69A0.mDescription = &stru_286C3C0;
  *(&stru_2AF69A0.mHandle + 1) = 13;
  stru_2AF69A0.mSize = 49720;
  return &stru_2AF69A0;
}


// Address: 0x2205b50 | Name: _ZN4FMOD16DSPPitchShiftSMB6bitrv2EPfi
void __fastcall FMOD::DSPPitchShiftSMB::bitrv2(FMOD::DSPPitchShiftSMB *const this, float *data, int count)
{
  int v3; // r12d
  int *v4; // rax
  int v5; // r9d
  int *v6; // rbp
  int i; // r11d
  __int64 v8; // rax
  __int64 v9; // rcx
  float *v10; // rdx
  float *v11; // rax
  int v12; // edi
  int v13; // xmm1_4
  int v14; // xmm0_4
  int v15; // edi
  float *v16; // r14
  int v17; // xmm2_4
  float *v18; // r8
  int v19; // xmm2_4
  int v20; // xmm1_4
  int v21; // xmm0_4
  int v22; // r13d
  int *v23; // r14
  int v24; // r15d
  float *v25; // rdi
  float *v26; // rdx
  int v27; // xmm1_4
  int v28; // xmm0_4
  int v29; // xmm2_4
  int v30; // eax
  int *v31; // r8
  float *v32; // rdi
  float *v33; // rcx
  int v34; // eax
  float *v35; // rdx
  float *v36; // rax
  int v37; // r11d
  int v38; // xmm1_4
  int v39; // xmm0_4
  int v40; // r11d
  __int64 v41; // rbx
  int v42; // r11d
  float *v43; // rbp
  int v44; // xmm3_4
  __int64 v45; // rbx
  int v46; // r11d
  float *v47; // rbp
  int v48; // xmm1_4
  int v49; // xmm0_4
  int v50; // xmm3_4
  float *v51; // rbp
  int v52; // xmm1_4
  int v53; // xmm0_4
  int v54; // xmm2_4
  float *v55; // rbx
  int v56; // xmm2_4
  int v57; // xmm1_4
  int v58; // xmm0_4
  int v59; // [rsp+0h] [rbp-44h]
  int v60; // [rsp+4h] [rbp-40h]
  __int64 v61; // [rsp+Ch] [rbp-38h]

  dword_2AEC880[2] = 0;
  if ( count <= 8 )
  {
    if ( count != 8 )
      return;
    v3 = 1;
    v5 = 2;
    goto LABEL_15;
  }
  v3 = 1;
  do
  {
    count >>= 1;
    if ( v3 > 0 )
    {
      v4 = &dword_2AEC880[2];
      do
      {
        v4[v3] = count + *v4;
        ++v4;
      }
      while ( v4 != &dword_2AEC880[v3 - 1 + 3] );
    }
    v3 *= 2;
  }
  while ( 8 * v3 < count );
  v5 = 2 * v3;
  if ( 8 * v3 == count )
  {
    if ( v3 <= 0 )
      return;
LABEL_15:
    v22 = 2 * v5;
    v23 = &dword_2AEC880[3];
    v60 = v5;
    v24 = 0;
    v59 = dword_2AEC880[2];
    v61 = v5 + 1LL;
    while ( 1 )
    {
      ++v24;
      v25 = &data[v60 + v59];
      v26 = &data[v5 + v60 + v59];
      v27 = *(_DWORD *)v25;
      v28 = *((_DWORD *)v25 + 1);
      v29 = *((_DWORD *)v26 + 1);
      *v25 = *v26;
      *((_DWORD *)v25 + 1) = v29;
      *(_DWORD *)v26 = v27;
      *((_DWORD *)v26 + 1) = v28;
      if ( v24 == v3 )
        break;
      v30 = *v23;
      if ( v24 <= 0 )
      {
        v59 = *v23;
      }
      else
      {
        v59 = *v23;
        v31 = &dword_2AEC880[2];
        v32 = &data[v30 + 1];
        v33 = &data[v61 + v30];
        v34 = v5 + v30;
        v35 = &data[v61 + v34];
        v36 = &data[v61 + v5 + v34];
        do
        {
          v37 = *v31;
          v38 = *((_DWORD *)v32 - 1);
          v39 = *(_DWORD *)v32;
          ++v31;
          v32 += 2;
          v33 += 2;
          v35 += 2;
          v40 = 2 * v24 + v37;
          v36 += 2;
          v41 = v40;
          v42 = v22 + v40;
          v43 = &data[v41];
          v44 = *(_DWORD *)v43;
          *(v32 - 2) = v43[1];
          *((_DWORD *)v32 - 3) = v44;
          *(_DWORD *)v43 = v38;
          *((_DWORD *)v43 + 1) = v39;
          v45 = v42;
          v46 = v42 - v5;
          v47 = &data[v45];
          v48 = *((_DWORD *)v33 - 3);
          v49 = *((_DWORD *)v33 - 2);
          v50 = *(_DWORD *)v47;
          *(v33 - 2) = v47[1];
          *((_DWORD *)v33 - 3) = v50;
          *(_DWORD *)v47 = v48;
          *((_DWORD *)v47 + 1) = v49;
          v51 = &data[v46];
          v52 = *((_DWORD *)v35 - 3);
          v53 = *((_DWORD *)v35 - 2);
          v54 = *((_DWORD *)v51 + 1);
          *(v35 - 3) = *v51;
          *((_DWORD *)v35 - 2) = v54;
          *(_DWORD *)v51 = v52;
          *((_DWORD *)v51 + 1) = v53;
          v55 = &data[v22 + v46];
          v56 = *((_DWORD *)v55 + 1);
          v57 = *((_DWORD *)v36 - 3);
          v58 = *((_DWORD *)v36 - 2);
          *(v36 - 3) = *v55;
          *((_DWORD *)v36 - 2) = v56;
          *(_DWORD *)v55 = v57;
          *((_DWORD *)v55 + 1) = v58;
        }
        while ( v23 != v31 );
      }
      v60 += 2;
      ++v23;
    }
    return;
  }
  if ( v3 > 1 )
  {
    v6 = &dword_2AEC880[3];
    for ( i = 1; i != v3; ++i )
    {
      v8 = *v6;
      v9 = 0;
      v10 = &data[v8 + 1];
      v11 = &data[v5 + 1 + v8];
      do
      {
        v12 = dword_2AEC880[v9 + 2];
        v13 = *((_DWORD *)v10 - 1);
        v14 = *(_DWORD *)v10;
        ++v9;
        v10 += 2;
        v11 += 2;
        v15 = 2 * i + v12;
        v16 = &data[v15];
        v17 = *((_DWORD *)v16 + 1);
        *(v10 - 3) = *v16;
        *((_DWORD *)v10 - 2) = v17;
        *(_DWORD *)v16 = v13;
        *((_DWORD *)v16 + 1) = v14;
        v18 = &data[v5 + v15];
        v19 = *((_DWORD *)v18 + 1);
        v20 = *((_DWORD *)v11 - 3);
        v21 = *((_DWORD *)v11 - 2);
        *(v11 - 3) = *v18;
        *((_DWORD *)v11 - 2) = v19;
        *(_DWORD *)v18 = v20;
        *((_DWORD *)v18 + 1) = v21;
      }
      while ( i > (int)v9 );
      ++v6;
    }
  }
}


// Address: 0x2205ed0 | Name: _ZN4FMOD16DSPPitchShiftSMB7initFftEi
void __fastcall FMOD::DSPPitchShiftSMB::initFft(FMOD::DSPPitchShiftSMB *const this, int fftSize)
{
  float *mCosTab; // r10
  int v3; // edx
  int v4; // eax
  float v5; // xmm0_4
  float *v6; // r8
  int v7; // ecx
  unsigned int v8; // ebx
  float v9; // xmm1_4
  signed int v10; // eax
  int v11; // r9d
  float v12; // xmm0_4
  int v13; // eax
  float v14; // xmm0_4
  signed int v15; // eax
  int v16; // r9d

  mCosTab = this->mCosTab;
  v3 = fftSize >> 1;
  dword_2AEC880[0] = fftSize >> 1;
  dword_2AEC880[1] = 1;
  v4 = fftSize >> 2;
  flt_2AEC9A0[0] = 1.0;
  flt_2AEC9A0[1] = 0.0;
  v5 = mCosTab[4096];
  flt_2AEC9A0[v4] = v5;
  flt_2AEC9A0[v4 + 1] = v5;
  if ( fftSize >> 2 > 2 )
  {
    v6 = &flt_2AEC9A0[2];
    v7 = 2;
    v8 = 2 * ((unsigned int)(v4 - 3) >> 1) + 4;
    do
    {
      v14 = (float)v7 * (float)(1.0 / (float)((float)(fftSize >> 2) * 8.0));
      v15 = abs32((int)(float)(v14 * 32768.0)) & 0x7FFF;
      v16 = v15 >> 13;
      if ( v15 >> 13 == 2 )
      {
        v9 = -mCosTab[v15 - 0x4000];
      }
      else if ( v16 == 3 )
      {
        v9 = mCosTab[0x7FFF - v15];
      }
      else if ( v16 == 1 )
      {
        v9 = -mCosTab[0x3FFF - v15];
      }
      else
      {
        v9 = mCosTab[v15];
      }
      v10 = abs32((int)(float)((float)(v14 - 0.25) * 32768.0)) & 0x7FFF;
      v11 = v10 >> 13;
      if ( v10 >> 13 == 2 )
      {
        v12 = -mCosTab[v10 - 0x4000];
      }
      else if ( v11 == 3 )
      {
        v12 = mCosTab[0x7FFF - v10];
      }
      else if ( v11 == 1 )
      {
        v12 = -mCosTab[0x3FFF - v10];
      }
      else
      {
        v12 = mCosTab[v10];
      }
      *v6 = v9;
      v6 += 2;
      *(v6 - 1) = v12;
      flt_2AEC9A0[v3 - v7] = v12;
      v13 = v3 + 1 - v7;
      v7 += 2;
      flt_2AEC9A0[v13] = v9;
    }
    while ( v7 != v8 );
  }
  FMOD::DSPPitchShiftSMB::bitrv2(this, flt_2AEC9A0, v3);
}


// Address: 0x2206110 | Name: _ZN4FMOD16DSPPitchShiftSMB10bitrv2conjEPfi
void __fastcall FMOD::DSPPitchShiftSMB::bitrv2conj(FMOD::DSPPitchShiftSMB *const this, float *data, int count)
{
  int v3; // r12d
  int *v4; // rax
  int v5; // r8d
  __int64 v6; // r14
  int *v7; // rbp
  int v8; // ebx
  int v9; // r11d
  int v10; // r13d
  __int64 v11; // rcx
  float *v12; // rdx
  float *v13; // rax
  int v14; // edi
  float v15; // xmm1_4
  int v16; // xmm3_4
  int v17; // edi
  float *v18; // r15
  float v19; // xmm2_4
  float *v20; // r9
  float v21; // xmm1_4
  int v22; // xmm4_4
  int v23; // xmm3_4
  int v24; // r13d
  float *v25; // rax
  int v26; // r13d
  int *v27; // r14
  int v28; // r15d
  int v29; // r12d
  int v30; // edx
  float *v31; // r9
  float *v32; // rcx
  float *v33; // rax
  float v34; // xmm1_4
  int v35; // xmm3_4
  float v36; // xmm2_4
  int v37; // eax
  int *v38; // r9
  int v39; // r12d
  float *v40; // rdi
  float *v41; // rcx
  int v42; // eax
  float *v43; // rdx
  float *v44; // rax
  int v45; // r11d
  float v46; // xmm1_4
  int v47; // xmm3_4
  int v48; // r11d
  __int64 v49; // rbx
  int v50; // r11d
  float *v51; // rbp
  float v52; // xmm2_4
  __int64 v53; // rbx
  int v54; // r11d
  float *v55; // rbp
  float v56; // xmm1_4
  float v57; // xmm2_4
  int v58; // xmm3_4
  float *v59; // rbp
  float v60; // xmm1_4
  float v61; // xmm2_4
  int v62; // xmm3_4
  float *v63; // rbx
  float v64; // xmm1_4
  int v65; // xmm4_4
  int v66; // xmm3_4
  int v67; // [rsp+0h] [rbp-40h]
  int v68; // [rsp+4h] [rbp-3Ch]
  __int64 v69; // [rsp+8h] [rbp-38h]

  dword_2AEC880[2] = 0;
  if ( count <= 8 )
  {
    if ( count != 8 )
    {
      data[1] = -data[1];
      data[3] = -data[3];
      return;
    }
    v5 = 2;
    v3 = 1;
LABEL_15:
    v26 = 2 * v5;
    v27 = &dword_2AEC880[3];
    v28 = 0;
    v68 = v3;
    v67 = dword_2AEC880[2];
    v69 = v5 + 1LL;
    while ( 1 )
    {
      v29 = 2 * v28++;
      v30 = v5 + v29 + v67;
      data[v29 + 1 + v67] = -data[v29 + 1 + v67];
      v31 = &data[v30];
      v32 = &data[v30 + v5];
      v33 = &data[v5 + 1 + v30 + v5];
      v34 = -v31[1];
      v35 = *(_DWORD *)v31;
      v36 = -v32[1];
      *v31 = *v32;
      v31[1] = v36;
      *(_DWORD *)v32 = v35;
      v32[1] = v34;
      *v33 = -*v33;
      if ( v28 == v68 )
        break;
      v37 = *v27;
      if ( v28 <= 0 )
      {
        v67 = *v27;
      }
      else
      {
        v67 = *v27;
        v38 = &dword_2AEC880[2];
        v39 = v29 + 2;
        v40 = &data[v37 + 1];
        v41 = &data[v69 + v37];
        v42 = v5 + v37;
        v43 = &data[v69 + v42];
        v44 = &data[v69 + v5 + v42];
        do
        {
          v45 = *v38;
          v46 = -*v40;
          ++v38;
          v47 = *((_DWORD *)v40 - 1);
          v41 += 2;
          v48 = v39 + v45;
          v40 += 2;
          v43 += 2;
          v49 = v48;
          v50 = v26 + v48;
          v44 += 2;
          v51 = &data[v49];
          v52 = -v51[1];
          *(v40 - 3) = *v51;
          *(v40 - 2) = v52;
          *(_DWORD *)v51 = v47;
          v51[1] = v46;
          v53 = v50;
          v54 = v50 - v5;
          v55 = &data[v53];
          v56 = -*(v41 - 2);
          v57 = -v55[1];
          v58 = *((_DWORD *)v41 - 3);
          *(v41 - 3) = *v55;
          *(v41 - 2) = v57;
          *(_DWORD *)v55 = v58;
          v55[1] = v56;
          v59 = &data[v54];
          v60 = -*(v43 - 2);
          v61 = -v59[1];
          v62 = *((_DWORD *)v43 - 3);
          *(v43 - 3) = *v59;
          *(v43 - 2) = v61;
          *(_DWORD *)v59 = v62;
          v59[1] = v60;
          v63 = &data[v26 + v54];
          v64 = -*(v44 - 2);
          v65 = *(_DWORD *)v63;
          v66 = *((_DWORD *)v44 - 3);
          *(v44 - 2) = -v63[1];
          *((_DWORD *)v44 - 3) = v65;
          *(_DWORD *)v63 = v66;
          v63[1] = v64;
        }
        while ( v27 != v38 );
      }
      ++v27;
    }
    return;
  }
  v3 = 1;
  do
  {
    count >>= 1;
    if ( v3 > 0 )
    {
      v4 = &dword_2AEC880[2];
      do
      {
        v4[v3] = count + *v4;
        ++v4;
      }
      while ( v4 != &dword_2AEC880[v3 - 1 + 3] );
    }
    v3 *= 2;
  }
  while ( 8 * v3 < count );
  v5 = 2 * v3;
  if ( 8 * v3 == count )
  {
    if ( v3 <= 0 )
      return;
    goto LABEL_15;
  }
  v6 = v5 + 1LL;
  data[1] = -data[1];
  data[v6] = -data[v6];
  if ( v3 > 1 )
  {
    v7 = &dword_2AEC880[3];
    v8 = 2;
    v9 = 1;
    do
    {
      v10 = *v7;
      v11 = 0;
      v12 = &data[*v7 + 1];
      v13 = &data[v6 + *v7];
      do
      {
        v14 = dword_2AEC880[v11 + 2];
        v15 = -*v12;
        ++v11;
        v16 = *((_DWORD *)v12 - 1);
        v13 += 2;
        v17 = v8 + v14;
        v12 += 2;
        v18 = &data[v17];
        v19 = -v18[1];
        *(v12 - 3) = *v18;
        *(v12 - 2) = v19;
        *(_DWORD *)v18 = v16;
        v18[1] = v15;
        v20 = &data[v5 + v17];
        v21 = -*(v13 - 2);
        v22 = *(_DWORD *)v20;
        v23 = *((_DWORD *)v13 - 3);
        *(v13 - 2) = -v20[1];
        *((_DWORD *)v13 - 3) = v22;
        *(_DWORD *)v20 = v23;
        v20[1] = v21;
      }
      while ( v9 > (int)v11 );
      v24 = v8 + v10;
      ++v9;
      v8 += 2;
      ++v7;
      data[v24 + 1] = -data[v24 + 1];
      v25 = &data[v5 + 1 + v24];
      *v25 = -*v25;
    }
    while ( v9 != v3 );
  }
}


// Address: 0x2206550 | Name: _ZN4FMOD16DSPPitchShiftSMB6cft1stEPf
void __fastcall FMOD::DSPPitchShiftSMB::cft1st(FMOD::DSPPitchShiftSMB *const this, float *fftBuffer)
{
  float v2; // xmm0_4
  float v3; // xmm4_4
  float v4; // xmm5_4
  float v5; // xmm1_4
  float v6; // xmm7_4
  float v7; // xmm9_4
  float v8; // xmm3_4
  float v9; // xmm6_4
  float v10; // xmm8_4
  float v11; // xmm0_4
  float v12; // xmm4_4
  float v13; // xmm10_4
  float v14; // xmm2_4
  float v15; // xmm8_4
  float v16; // xmm7_4
  float v17; // xmm8_4
  float v18; // xmm6_4
  float v19; // xmm8_4
  float v20; // xmm5_4
  float v21; // xmm2_4
  float v22; // xmm7_4
  float v23; // xmm3_4
  float v24; // xmm5_4
  float v25; // xmm6_4
  float v26; // xmm9_4
  float v27; // xmm6_4
  float v28; // xmm9_4
  float v29; // xmm8_4
  float v30; // xmm4_4
  float v31; // xmm0_4
  float v32; // xmm8_4
  float v33; // xmm2_4
  float v34; // xmm1_4
  float v35; // xmm2_4
  float v36; // xmm3_4
  float v37; // xmm7_4
  float v38; // xmm3_4
  float v39; // xmm2_4
  float v40; // xmm1_4
  int v41; // ecx
  float *v42; // rax
  float *v43; // rdx
  __int64 v44; // rsi
  unsigned __int64 i; // rcx
  float v46; // xmm1_4
  float v47; // xmm3_4
  float v48; // xmm4_4
  float v49; // xmm8_4
  float v50; // xmm11_4
  float v51; // xmm6_4
  float v52; // xmm12_4
  float v53; // xmm13_4
  float v54; // xmm15_4
  float v55; // xmm8_4
  float v56; // xmm7_4
  float v57; // xmm5_4
  float v58; // xmm13_4
  float v59; // xmm14_4
  float v60; // xmm9_4
  float v61; // xmm15_4
  float v62; // xmm5_4
  float v63; // xmm6_4
  float v64; // xmm10_4
  float v65; // xmm6_4
  float v66; // xmm14_4
  float v67; // xmm12_4
  float v68; // xmm2_4
  float v69; // xmm14_4
  float v70; // xmm5_4
  float v71; // xmm14_4
  float v72; // xmm6_4
  float v73; // xmm5_4
  float v74; // xmm1_4
  float v75; // xmm5_4
  float v76; // xmm13_4
  float v77; // xmm4_4
  float v78; // xmm3_4
  float v79; // xmm9_4
  float v80; // xmm3_4
  float v81; // xmm8_4
  float v82; // xmm4_4
  float v83; // xmm5_4
  float v84; // xmm6_4
  float v85; // xmm3_4
  float v86; // xmm7_4
  float v87; // xmm11_4
  float v88; // xmm10_4
  float v89; // xmm13_4
  float v90; // xmm7_4
  float v91; // xmm13_4
  float v92; // xmm3_4
  float v93; // xmm4_4
  float v94; // xmm6_4
  float v95; // xmm5_4
  float v96; // xmm12_4
  float v97; // xmm8_4
  float v98; // xmm5_4
  float v99; // xmm9_4
  float v100; // xmm5_4
  float v101; // xmm14_4
  float v102; // xmm11_4
  float v103; // xmm2_4
  float v104; // xmm14_4
  float v105; // xmm12_4

  v2 = fftBuffer[3];
  v3 = fftBuffer[2];
  v4 = fftBuffer[1] + v2;
  v5 = fftBuffer[1] - v2;
  v6 = *fftBuffer + v3;
  v7 = fftBuffer[6];
  v8 = *fftBuffer - v3;
  v9 = fftBuffer[4] + v7;
  v10 = fftBuffer[7];
  v11 = fftBuffer[4] - v7;
  v12 = fftBuffer[5] + v10;
  v13 = fftBuffer[15];
  v14 = fftBuffer[5] - v10;
  v15 = v6;
  v16 = v6 - v9;
  v17 = v15 + v9;
  v18 = fftBuffer[10];
  fftBuffer[4] = v16;
  *fftBuffer = v17;
  v19 = v4;
  fftBuffer[5] = v4 - v12;
  v20 = fftBuffer[8];
  fftBuffer[1] = v19 + v12;
  fftBuffer[2] = v8 - v14;
  fftBuffer[6] = v14 + v8;
  v21 = fftBuffer[11];
  v22 = v20 + v18;
  v23 = fftBuffer[14];
  v24 = v20 - v18;
  v25 = fftBuffer[13];
  fftBuffer[7] = v5 - v11;
  v26 = v25;
  fftBuffer[3] = v5 + v11;
  v27 = v25 - v13;
  v28 = v26 + v13;
  v29 = fftBuffer[9];
  v30 = v29 - v21;
  v31 = flt_2AEC9A0[2];
  v32 = v29 + v21;
  v33 = fftBuffer[12];
  v34 = v33 - v23;
  v35 = v33 + v23;
  v36 = v22;
  v37 = v22 - v35;
  v38 = v36 + v35;
  v39 = v30 + v34;
  fftBuffer[13] = v37;
  fftBuffer[8] = v38;
  v40 = v34 - v30;
  fftBuffer[9] = v32 + v28;
  fftBuffer[12] = v28 - v32;
  fftBuffer[10] = (float)((float)(v24 - v27) - v39) * v31;
  fftBuffer[11] = (float)(v39 + (float)(v24 - v27)) * v31;
  fftBuffer[14] = (float)(v40 - (float)(v27 + v24)) * v31;
  fftBuffer[15] = (float)(v40 + (float)(v27 + v24)) * v31;
  v41 = 2 * this->mFFTFrameSize;
  if ( v41 > 16 )
  {
    v42 = fftBuffer;
    v43 = flt_2AEC9A0;
    v44 = 8LL * ((unsigned int)(v41 - 17) >> 4) + 8;
    for ( i = 0; ; v31 = flt_2AEC9A0[i / 4 + 2] )
    {
      v46 = flt_2AEC9A0[i / 4 + 3];
      i += 8LL;
      v43 += 4;
      v42 += 16;
      v47 = v43[1];
      v48 = *v43;
      v49 = v42[2];
      v50 = *v42 - v49;
      v51 = v42[3];
      v52 = *v42 + v49;
      v53 = v42[4];
      v54 = v42[6];
      v55 = v53 - v54;
      v56 = *v43 - (float)((float)(v46 + v46) * v47);
      v57 = v42[1];
      v58 = v53 + v54;
      v59 = v42[7];
      v60 = v57 - v51;
      v61 = v42[14];
      v62 = v57 + v51;
      v63 = v42[5];
      v64 = v63 - v59;
      v65 = v63 + v59;
      v66 = v52;
      v67 = v52 - v58;
      v68 = (float)((float)(v46 + v46) * *v43) - v47;
      *v42 = v66 + v58;
      v69 = v62;
      v70 = v62 - v65;
      v42[1] = v69 + v65;
      v71 = v42[15];
      v72 = (float)(v67 * v31) - (float)(v46 * v70);
      v73 = (float)(v70 * v31) + (float)(v67 * v46);
      v74 = -v46;
      v42[4] = v72;
      v42[5] = v73;
      v75 = v48;
      v76 = v47 * (float)(v60 + v55);
      v77 = (float)(v48 * (float)(v60 + v55)) + (float)(v47 * (float)(v50 - v64));
      v78 = v60;
      v79 = v42[13];
      v80 = v78 - v55;
      v81 = v42[9];
      v42[2] = (float)(v75 * (float)(v50 - v64)) - v76;
      v42[3] = v77;
      v82 = v56;
      v83 = v50 + v64;
      v84 = v68 * v80;
      v85 = v80 * v56;
      v86 = v42[10];
      v87 = v42[8] + v86;
      v88 = v42[8] - v86;
      v89 = v42[12];
      v90 = v89 - v61;
      v91 = v89 + v61;
      v42[7] = v85 + (float)(v68 * v83);
      v42[6] = (float)(v82 * v83) - v84;
      v92 = v43[3];
      v93 = v43[2];
      v94 = v93 - (float)((float)(v31 + v31) * v92);
      v95 = v42[11];
      v96 = v81 + v95;
      v97 = v81 - v95;
      v98 = v79;
      v99 = v79 - v71;
      v100 = v98 + v71;
      v101 = v87;
      v102 = v87 - v91;
      v103 = (float)((float)(v31 + v31) * v93) - v92;
      v42[8] = v101 + v91;
      v104 = v96;
      v105 = v96 - v100;
      v42[9] = v104 + v100;
      v42[12] = (float)(v74 * v102) - (float)(v105 * v31);
      v42[13] = (float)(v74 * v105) + (float)(v31 * v102);
      v42[10] = (float)(v93 * (float)(v88 - v99)) - (float)(v92 * (float)(v97 + v90));
      v42[11] = (float)(v93 * (float)(v97 + v90)) + (float)(v92 * (float)(v88 - v99));
      v42[14] = (float)(v94 * (float)(v88 + v99)) - (float)(v103 * (float)(v97 - v90));
      v42[15] = (float)((float)(v97 - v90) * v94) + (float)(v103 * (float)(v88 + v99));
      if ( i == v44 )
        break;
    }
  }
}


// Address: 0x2206a00 | Name: _ZN4FMOD16DSPPitchShiftSMB6cftmdlEPfi
void __fastcall FMOD::DSPPitchShiftSMB::cftmdl(FMOD::DSPPitchShiftSMB *const this, float *fftBuffer, int count)
{
  int v3; // r10d
  float *v4; // rax
  __int64 v5; // rcx
  float *v6; // r8
  float *v7; // r9
  float *v8; // rcx
  float v9; // xmm1_4
  float v10; // xmm0_4
  float v11; // xmm4_4
  float v12; // xmm5_4
  float v13; // xmm9_4
  float v14; // xmm1_4
  float v15; // xmm7_4
  float v16; // xmm3_4
  float v17; // xmm6_4
  float v18; // xmm8_4
  float v19; // xmm0_4
  float v20; // xmm4_4
  float v21; // xmm2_4
  int v22; // r13d
  float v23; // xmm0_4
  __int64 v24; // rcx
  float *v25; // rax
  float *v26; // r11
  float *v27; // r8
  float *v28; // rcx
  float v29; // xmm5_4
  float v30; // xmm6_4
  float v31; // xmm2_4
  float v32; // xmm7_4
  float v33; // xmm8_4
  float v34; // xmm4_4
  float v35; // xmm3_4
  float v36; // xmm5_4
  float v37; // xmm2_4
  float v38; // xmm1_4
  float v39; // xmm10_4
  float v40; // xmm3_4
  float v41; // xmm9_4
  float v42; // xmm7_4
  float v43; // xmm6_4
  float v44; // xmm2_4
  float v45; // xmm1_4
  float v46; // xmm7_4
  float v47; // xmm6_4
  int v48; // ebp
  int v49; // r15d
  __int64 v50; // rdi
  int v51; // r12d
  int v52; // r13d
  __int64 v53; // r14
  int v54; // ebx
  __int64 v55; // r8
  unsigned __int64 v56; // r10
  float v57; // xmm9_4
  __int64 v58; // r11
  float v59; // xmm5_4
  float v60; // xmm6_4
  float v61; // xmm0_4
  float v62; // xmm7_4
  float v63; // xmm8_4
  float *v64; // rsi
  float *v65; // rcx
  float *v66; // rdx
  float *v67; // rax
  float v68; // xmm1_4
  float v69; // xmm4_4
  float v70; // xmm10_4
  float v71; // xmm2_4
  float v72; // xmm3_4
  float v73; // xmm1_4
  float v74; // xmm12_4
  float v75; // xmm14_4
  float v76; // xmm4_4
  float v77; // xmm15_4
  float v78; // xmm14_4
  float v79; // xmm11_4
  float v80; // xmm3_4
  float v81; // xmm13_4
  float v82; // xmm12_4
  float v83; // xmm10_4
  float v84; // xmm3_4
  float v85; // xmm2_4
  float v86; // xmm2_4
  float v87; // xmm1_4
  float v88; // xmm2_4
  float v89; // xmm5_4
  float v90; // xmm6_4
  float v91; // xmm7_4
  float v92; // xmm8_4
  float v93; // xmm9_4
  float *v94; // rsi
  float *v95; // rcx
  float *v96; // rdx
  float *v97; // rax
  float v98; // xmm1_4
  float v99; // xmm4_4
  float v100; // xmm10_4
  float v101; // xmm2_4
  float v102; // xmm3_4
  float v103; // xmm1_4
  float v104; // xmm12_4
  float v105; // xmm14_4
  float v106; // xmm4_4
  float v107; // xmm15_4
  float v108; // xmm14_4
  float v109; // xmm11_4
  float v110; // xmm13_4
  float v111; // xmm10_4
  float v112; // xmm3_4
  float v113; // xmm2_4
  float v114; // xmm3_4
  float v115; // xmm13_4
  float v116; // xmm2_4
  float v117; // xmm1_4
  float v118; // xmm2_4
  __int64 v119; // [rsp+0h] [rbp-A0h]
  __int64 v120; // [rsp+0h] [rbp-A0h]
  float *v121; // [rsp+8h] [rbp-98h]
  int v122; // [rsp+1Ch] [rbp-84h]
  __int64 v123; // [rsp+28h] [rbp-78h]
  float *v124; // [rsp+30h] [rbp-70h]
  float *v125; // [rsp+38h] [rbp-68h]
  float *v126; // [rsp+40h] [rbp-60h]
  float *v127; // [rsp+48h] [rbp-58h]
  float *v128; // [rsp+50h] [rbp-50h]
  float *v129; // [rsp+58h] [rbp-48h]
  float *v130; // [rsp+60h] [rbp-40h]
  float *v131; // [rsp+68h] [rbp-38h]

  v3 = 4 * count;
  if ( count > 0 )
  {
    v4 = fftBuffer;
    v5 = count + 1LL;
    v6 = &fftBuffer[2 * count + 1];
    v7 = &fftBuffer[v5];
    v8 = &fftBuffer[2 * count + v5];
    do
    {
      v9 = v4[1];
      v4 += 2;
      v7 += 2;
      v6 += 2;
      v8 += 2;
      v10 = *(v7 - 2);
      v11 = *(v7 - 3);
      v12 = v9 + v10;
      v13 = *(v8 - 3);
      v14 = v9 - v10;
      v15 = *(v4 - 2) + v11;
      v16 = *(v4 - 2) - v11;
      v17 = *(v6 - 3) + v13;
      v18 = *(v8 - 2);
      v19 = *(v6 - 3) - v13;
      v20 = *(v6 - 2) + v18;
      v21 = *(v6 - 2) - v18;
      *(v4 - 2) = v15 + v17;
      *(v4 - 1) = v12 + v20;
      *(v6 - 3) = v15 - v17;
      *(v6 - 2) = v12 - v20;
      *(v7 - 3) = v16 - v21;
      *(v7 - 2) = v14 + v19;
      *(v8 - 3) = v21 + v16;
      *(v8 - 2) = v14 - v19;
    }
    while ( v4 != &fftBuffer[2 * ((unsigned int)(count - 1) >> 1) + 2] );
  }
  v22 = 5 * count;
  v23 = flt_2AEC9A0[2];
  if ( 4 * count < 5 * count )
  {
    v24 = count + 1LL;
    v25 = &fftBuffer[v3 + 1];
    v26 = &fftBuffer[v24 + v3];
    v27 = &fftBuffer[v24 + v22];
    v28 = &fftBuffer[6 * count + v24];
    do
    {
      v29 = *(v25 - 1);
      v25 += 2;
      v26 += 2;
      v27 += 2;
      v28 += 2;
      v30 = *(v26 - 3);
      v31 = *(v26 - 2);
      v32 = v29 + v30;
      v33 = *(v25 - 2) + v31;
      v34 = *(v25 - 2) - v31;
      v35 = *(v28 - 3);
      v36 = v29 - v30;
      v37 = *(v27 - 3) + v35;
      v38 = *(v27 - 3) - v35;
      v39 = *(v28 - 2);
      v40 = v32 + v37;
      v41 = *(v27 - 2) + v39;
      v42 = v32 - v37;
      v43 = *(v27 - 2) - v39;
      *(v25 - 3) = v40;
      v44 = v34 + v38;
      v45 = v38 - v34;
      *(v25 - 2) = v33 + v41;
      *(v27 - 2) = v42;
      *(v27 - 3) = v41 - v33;
      v46 = v36 - v43;
      v47 = v43 + v36;
      *(v26 - 3) = (float)(v46 - v44) * v23;
      *(v26 - 2) = (float)(v44 + v46) * v23;
      *(v28 - 2) = (float)(v45 + v47) * v23;
      *(v28 - 3) = (float)(v45 - v47) * v23;
    }
    while ( v25 != &fftBuffer[2 * ((unsigned int)(count - 1) >> 1) + 3 + v3] );
  }
  v48 = 8 * count;
  v122 = 2 * this->mFFTFrameSize;
  if ( 8 * count < v122 )
  {
    v49 = 12 * count;
    v50 = 2LL * count;
    v51 = 13 * count;
    v119 = v48 + count + (__int64)v3;
    v123 = v48 + (__int64)v3;
    v52 = v3 + v22;
    v53 = 0;
    v54 = 8 * count;
    v55 = 0;
    v56 = 0;
    v124 = &fftBuffer[v48 + 1];
    v125 = &fftBuffer[count + 1 + (__int64)v48];
    v126 = &fftBuffer[v48 + 1 + v50];
    v127 = &fftBuffer[9 * count + 1 + v50];
    v121 = fftBuffer + 3;
    v128 = &fftBuffer[v123 + 1];
    v129 = &fftBuffer[v119 + 1];
    v130 = &fftBuffer[12 * count + 1 + v50];
    v131 = &fftBuffer[13 * count + 1 + v50];
    do
    {
      v57 = flt_2AEC9A0[v56 / 4 + 3];
      v58 = 2 * v56;
      v59 = flt_2AEC9A0[v56 / 2 + 4];
      v60 = flt_2AEC9A0[v56 / 2 + 5];
      v61 = flt_2AEC9A0[v56 / 4 + 2];
      v62 = (float)((float)(v57 + v57) * v59) - v60;
      v63 = v59 - (float)((float)(v57 + v57) * v60);
      if ( v54 >= v52 )
      {
        v120 = v53 + v48;
      }
      else
      {
        v120 = v53 + v48;
        v64 = &v127[v55];
        v65 = &v126[v55];
        v66 = &v125[v55];
        v67 = &v124[v55];
        do
        {
          v68 = *v67;
          v67 += 2;
          v66 += 2;
          v65 += 2;
          v64 += 2;
          v69 = *(v66 - 2);
          v70 = *(v66 - 3);
          v71 = v68 + v69;
          v72 = *(v64 - 3);
          v73 = v68 - v69;
          v74 = *(v67 - 3) + v70;
          v75 = *(v65 - 3);
          v76 = v75 - v72;
          v77 = *(v64 - 2);
          v78 = v75 + v72;
          v79 = *(v67 - 3) - v70;
          v80 = v74 + v78;
          v81 = *(v65 - 2) + v77;
          v82 = v74 - v78;
          v83 = *(v65 - 2) - v77;
          *(v67 - 3) = v80;
          v84 = v71;
          v85 = v71 - v81;
          *(v67 - 2) = v84 + v81;
          *(v65 - 3) = (float)(v61 * v82) - (float)(v57 * v85);
          *(v65 - 2) = (float)(v85 * v61) + (float)(v82 * v57);
          v86 = v73;
          v87 = v73 - v76;
          v88 = v86 + v76;
          *(v66 - 3) = (float)(v59 * (float)(v79 - v83)) - (float)(v60 * v88);
          *(v66 - 2) = (float)(v88 * v59) + (float)((float)(v79 - v83) * v60);
          *(v64 - 3) = (float)(v63 * (float)(v79 + v83)) - (float)(v62 * v87);
          *(v64 - 2) = (float)(v87 * v63) + (float)((float)(v79 + v83) * v62);
        }
        while ( v67 != &v121[v53 + v48 + ((v52 - 1 - v54) & 0xFFFFFFFE)] );
      }
      v89 = *(float *)((char *)&flt_2AEC9A0[6] + v58);
      v90 = *(float *)((char *)&flt_2AEC9A0[7] + v58);
      v91 = (float)((float)(v61 + v61) * v89) - v90;
      v92 = v89 - (float)((float)(v61 + v61) * v90);
      if ( v49 < v51 )
      {
        v93 = -v57;
        v94 = &v131[v55];
        v95 = &v130[v55];
        v96 = &v129[v55];
        v97 = &v128[v55];
        do
        {
          v98 = *v97;
          v97 += 2;
          v96 += 2;
          v95 += 2;
          v94 += 2;
          v99 = *(v96 - 2);
          v100 = *(v96 - 3);
          v101 = v98 + v99;
          v102 = *(v94 - 3);
          v103 = v98 - v99;
          v104 = *(v97 - 3) + v100;
          v105 = *(v95 - 3);
          v106 = v105 - v102;
          v107 = *(v94 - 2);
          v108 = v105 + v102;
          v109 = *(v97 - 3) - v100;
          v110 = *(v95 - 2) + v107;
          v111 = *(v95 - 2) - v107;
          *(v97 - 3) = v104 + v108;
          v112 = v101;
          v113 = v101 - v110;
          v114 = v112 + v110;
          v115 = v61 * v113;
          *(v97 - 2) = v114;
          *(v95 - 2) = (float)(v113 * v93) + (float)((float)(v104 - v108) * v61);
          v116 = v103;
          v117 = v103 - v106;
          v118 = v116 + v106;
          *(v95 - 3) = (float)((float)(v104 - v108) * v93) - v115;
          *(v96 - 3) = (float)(v89 * (float)(v109 - v111)) - (float)(v90 * v118);
          *(v96 - 2) = (float)(v118 * v89) + (float)((float)(v109 - v111) * v90);
          *(v94 - 3) = (float)(v92 * (float)(v109 + v111)) - (float)(v91 * v117);
          *(v94 - 2) = (float)(v117 * v92) + (float)((float)(v109 + v111) * v91);
        }
        while ( v97 != &v121[((v51 - 1 - v49) & 0xFFFFFFFE) + v123 + v53] );
      }
      v54 += v48;
      v56 += 8LL;
      v52 += v48;
      v49 += v48;
      v51 += v48;
      v55 += v48;
      v53 = v120;
    }
    while ( v54 < v122 );
  }
}


// Address: 0x2207150 | Name: _ZN4FMOD16DSPPitchShiftSMB7cftfsubEPf
void __fastcall FMOD::DSPPitchShiftSMB::cftfsub(FMOD::DSPPitchShiftSMB *const this, float *fftBuffer)
{
  int v2; // edx
  float *v3; // r12
  int v4; // ebx
  int v5; // eax
  float *v6; // rdx
  float *v7; // rax
  float v8; // xmm1_4
  float v9; // xmm0_4
  float v10; // xmm2_4
  float v11; // xmm3_4
  int v12; // edx
  int v13; // edx
  __int64 v14; // rax
  float *v15; // rdx
  float *v16; // rcx
  float *v17; // rax
  float v18; // xmm1_4
  float v19; // xmm0_4
  float v20; // xmm4_4
  float v21; // xmm5_4
  float v22; // xmm9_4
  float v23; // xmm1_4
  float v24; // xmm7_4
  float v25; // xmm3_4
  float v26; // xmm6_4
  float v27; // xmm8_4
  float v28; // xmm0_4
  float v29; // xmm4_4
  float v30; // xmm2_4

  v2 = 8;
  v3 = fftBuffer;
  v4 = 2;
  v5 = 2 * this->mFFTFrameSize;
  if ( v5 <= 8 )
  {
LABEL_2:
    if ( v2 != v5 )
    {
LABEL_3:
      v6 = fftBuffer + 1;
      v7 = &fftBuffer[v4 + 1];
      do
      {
        v8 = *(v6 - 1);
        v6 += 2;
        v7 += 2;
        v9 = *(v7 - 3);
        v10 = *(v6 - 2);
        v11 = v10 - *(v7 - 2);
        *(v6 - 3) = v8 + v9;
        *(v6 - 2) = v10 + *(v7 - 2);
        *(v7 - 3) = v8 - v9;
        *(v7 - 2) = v11;
      }
      while ( v6 != &fftBuffer[2 * ((unsigned int)(v4 - 1) >> 1) + 3] );
      return;
    }
    goto LABEL_13;
  }
  FMOD::DSPPitchShiftSMB::cft1st(this, fftBuffer);
  v5 = 2 * this->mFFTFrameSize;
  if ( v5 <= 32 )
  {
    v2 = 32;
    v4 = 8;
    goto LABEL_2;
  }
  LOBYTE(v4) = 32;
  v12 = 8;
  while ( 1 )
  {
    FMOD::DSPPitchShiftSMB::cftmdl(this, fftBuffer, v12);
    v13 = 2 * this->mFFTFrameSize;
    if ( 4 * v4 >= v13 )
      break;
    v12 = v4;
    v4 *= 4;
  }
  if ( 4 * v4 != v13 )
  {
    if ( v4 <= 0 )
      return;
    goto LABEL_3;
  }
LABEL_13:
  if ( v4 > 0 )
  {
    v14 = v4 + 1LL;
    v15 = &fftBuffer[2 * v4 + 1];
    v16 = &fftBuffer[v14];
    v17 = &fftBuffer[2 * v4 + v14];
    do
    {
      v18 = fftBuffer[1];
      fftBuffer += 2;
      v16 += 2;
      v15 += 2;
      v17 += 2;
      v19 = *(v16 - 2);
      v20 = *(v16 - 3);
      v21 = v18 + v19;
      v22 = *(v17 - 3);
      v23 = v18 - v19;
      v24 = *(fftBuffer - 2) + v20;
      v25 = *(fftBuffer - 2) - v20;
      v26 = *(v15 - 3) + v22;
      v27 = *(v17 - 2);
      v28 = *(v15 - 3) - v22;
      v29 = *(v15 - 2) + v27;
      v30 = *(v15 - 2) - v27;
      *(fftBuffer - 2) = v24 + v26;
      *(fftBuffer - 1) = v21 + v29;
      *(v15 - 3) = v24 - v26;
      *(v15 - 2) = v21 - v29;
      *(v16 - 3) = v25 - v30;
      *(v16 - 2) = v23 + v28;
      *(v17 - 3) = v30 + v25;
      *(v17 - 2) = v23 - v28;
    }
    while ( fftBuffer != &v3[2 * ((unsigned int)(v4 - 1) >> 1) + 2] );
  }
}


// Address: 0x2207370 | Name: _ZN4FMOD16DSPPitchShiftSMB7cftbsubEPf
void __fastcall FMOD::DSPPitchShiftSMB::cftbsub(FMOD::DSPPitchShiftSMB *const this, float *fftBuffer)
{
  int v2; // edx
  float *v3; // r12
  int v4; // ebx
  int v5; // eax
  float *v6; // rdx
  float *v7; // rax
  float v8; // xmm3_4
  float v9; // xmm2_4
  float v10; // xmm1_4
  int v11; // edx
  int v12; // edx
  __int64 v13; // rax
  float *v14; // rdx
  float *v15; // rcx
  float *v16; // rax
  float v17; // xmm6_4
  float v18; // xmm1_4
  float v19; // xmm8_4
  float v20; // xmm5_4
  float v21; // xmm2_4
  float v22; // xmm10_4
  float v23; // xmm0_4
  float v24; // xmm2_4
  float v25; // xmm7_4
  float v26; // xmm9_4
  float v27; // xmm1_4
  float v28; // xmm6_4
  float v29; // xmm3_4

  v2 = 8;
  v3 = fftBuffer;
  v4 = 2;
  v5 = 2 * this->mFFTFrameSize;
  if ( v5 <= 8 )
  {
LABEL_2:
    if ( v2 != v5 )
    {
LABEL_3:
      v6 = &fftBuffer[v4 + 1];
      v7 = fftBuffer + 1;
      do
      {
        v8 = *(v7 - 1);
        v7 += 2;
        v6 += 2;
        v9 = *(v6 - 3);
        v10 = *(v6 - 2) - *(v7 - 2);
        *(v7 - 3) = v8 + v9;
        *(v7 - 2) = (float)-*(v7 - 2) - *(v6 - 2);
        *(v6 - 3) = v8 - v9;
        *(v6 - 2) = v10;
      }
      while ( v7 != &fftBuffer[2 * ((unsigned int)(v4 - 1) >> 1) + 3] );
      return;
    }
    goto LABEL_13;
  }
  FMOD::DSPPitchShiftSMB::cft1st(this, fftBuffer);
  v5 = 2 * this->mFFTFrameSize;
  if ( v5 <= 32 )
  {
    v2 = 32;
    v4 = 8;
    goto LABEL_2;
  }
  LOBYTE(v4) = 32;
  v11 = 8;
  while ( 1 )
  {
    FMOD::DSPPitchShiftSMB::cftmdl(this, fftBuffer, v11);
    v12 = 2 * this->mFFTFrameSize;
    if ( 4 * v4 >= v12 )
      break;
    v11 = v4;
    v4 *= 4;
  }
  if ( 4 * v4 != v12 )
  {
    if ( v4 <= 0 )
      return;
    goto LABEL_3;
  }
LABEL_13:
  if ( v4 > 0 )
  {
    v13 = v4 + 1LL;
    v14 = &fftBuffer[2 * v4 + 1];
    v15 = &fftBuffer[v13];
    v16 = &fftBuffer[2 * v4 + v13];
    do
    {
      v17 = fftBuffer[1];
      fftBuffer += 2;
      v15 += 2;
      v14 += 2;
      v16 += 2;
      v18 = *(v15 - 3);
      v19 = *(fftBuffer - 2) + v18;
      v20 = *(fftBuffer - 2) - v18;
      v21 = *(v15 - 2);
      v22 = *(v16 - 3);
      v23 = (float)-v17 - v21;
      v24 = v21 - v17;
      v25 = *(v14 - 3) + v22;
      v26 = *(v16 - 2);
      v27 = *(v14 - 3) - v22;
      v28 = *(v14 - 2) + v26;
      v29 = *(v14 - 2) - v26;
      *(fftBuffer - 2) = v19 + v25;
      *(fftBuffer - 1) = v23 - v28;
      *(v14 - 2) = v23 + v28;
      *(v14 - 3) = v19 - v25;
      *(v15 - 3) = v20 - v29;
      *(v15 - 2) = v24 - v27;
      *(v16 - 3) = v29 + v20;
      *(v16 - 2) = v27 + v24;
    }
    while ( fftBuffer != &v3[2 * ((unsigned int)(v4 - 1) >> 1) + 2] );
  }
}


// Address: 0x22075a0 | Name: _ZN4FMOD16DSPPitchShiftSMB3fftEPfi
void __fastcall FMOD::DSPPitchShiftSMB::fft(FMOD::DSPPitchShiftSMB *const this, float *fftBuffer, int sign)
{
  bool v3; // sf
  int v4; // edx

  v3 = sign < 0;
  v4 = 2 * this->mFFTFrameSize;
  if ( v3 )
  {
    FMOD::DSPPitchShiftSMB::bitrv2conj(this, fftBuffer, v4);
    FMOD::DSPPitchShiftSMB::cftbsub(this, fftBuffer);
  }
  else
  {
    FMOD::DSPPitchShiftSMB::bitrv2(this, fftBuffer, v4);
    FMOD::DSPPitchShiftSMB::cftfsub(this, fftBuffer);
  }
}


// Address: 0x22075f0 | Name: _ZN4FMOD16DSPPitchShiftSMB7smbInitEv
void __fastcall FMOD::DSPPitchShiftSMB::smbInit(FMOD::DSPPitchShiftSMB *const this)
{
  memset(this, 0, 0x4000u);
  memset(this->mOutFIFO, 0, sizeof(this->mOutFIFO));
  memset(this->mLastPhase, 0, sizeof(this->mLastPhase));
  memset(this->mSumPhase, 0, sizeof(this->mSumPhase));
  memset(this->mOutputAccum, 0, sizeof(this->mOutputAccum));
  memset(fftBuffer, 0, sizeof(fftBuffer));
  memset(flt_2AE0880, 0, sizeof(flt_2AE0880));
  memset(flt_2ADC880, 0, sizeof(flt_2ADC880));
  memset(flt_2AE8880, 0, sizeof(flt_2AE8880));
  memset(flt_2AE4880, 0, sizeof(flt_2AE4880));
  *(_DWORD *)((char *)&stru_14028.r_offset + (_QWORD)this) = 0;
}


// Address: 0x22076c0 | Name: _ZN4FMOD13DSPPitchShift14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPPitchShift::createInternal(FMOD::DSPPitchShift *const this)
{
  double v1; // xmm1_8
  float v2; // xmm0_4
  float *v3; // rbp
  int i; // ebx
  __int64 v5; // rax
  __int64 v6; // rbp
  int v7; // ebx
  FMOD_RESULT_0 result; // eax

  v2 = 1.0;
  v3 = (float *)((char *)this + 528);
  for ( i = 0; ; v2 = cosf((float)((float)i * 1.5707964) * 0.00012207031) )
  {
    ++i;
    *v3++ = v2;
    if ( i == 0x2000 )
      break;
  }
  v5 = *((_QWORD *)this + 30);
  v6 = 0;
  v7 = 0;
  *((_DWORD *)this + 12422) = 4;
  *((_QWORD *)this + 6212) = 0;
  *((_DWORD *)this + 12420) = 1065353216;
  if ( *(int *)(v5 + 96) <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    result = FMOD::DSPI::setParameterFloat(
               (FMOD::DSPI *const)this,
               v7,
               (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v5 + 104) + v6) + 56LL),
               v1);
    if ( result )
      break;
    v5 = *((_QWORD *)this + 30);
    ++v7;
    v6 += 8;
    if ( *(_DWORD *)(v5 + 96) <= v7 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2207790 | Name: _ZN4FMOD13DSPPitchShift14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPPitchShift::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPPitchShift::createInternal((FMOD::DSPPitchShift *const)dsp_state->instance);
}


// Address: 0x22077a0 | Name: _ZN4FMOD13DSPPitchShift15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPPitchShift::releaseInternal(FMOD::DSPPitchShift *const this)
{
  void *v1; // rsi

  v1 = (void *)*((_QWORD *)this + 6212);
  if ( v1 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_dsp_pitchshift.cpp", 801);
    *((_QWORD *)this + 6212) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22077f0 | Name: _ZN4FMOD13DSPPitchShift15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPPitchShift::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPPitchShift::releaseInternal((FMOD::DSPPitchShift *const)dsp_state->instance);
}


// Address: 0x2207800 | Name: _ZN4FMOD16DSPPitchShiftSMB13smbPitchShiftEfiifPfS1_ii
void __fastcall FMOD::DSPPitchShiftSMB::smbPitchShift(
        FMOD::DSPPitchShiftSMB *const this,
        float pitchShift,
        int numSampsToProcess,
        int osamp,
        float sampleRate,
        float *indata,
        float *outdata,
        int channel,
        int numchannels)
{
  __int64 v9; // r12
  float *v11; // rdx
  FMOD::DSPPitchShiftSMB *v12; // r15
  float v13; // xmm2_4
  int v14; // eax
  float v15; // xmm0_4
  int mFFTFrameSize; // esi
  float v17; // xmm1_4
  float v18; // xmm15_4
  float v19; // xmm14_4
  int v20; // eax
  int v21; // edx
  float *mWindow; // rcx
  unsigned __int64 v23; // rax
  float v24; // xmm0_4
  __m128 v25; // xmm13
  float *v26; // r13
  float *v27; // rbx
  int v28; // r12d
  float *v29; // r15
  float *v30; // r14
  float v31; // xmm15_4
  __m128 v32; // xmm0
  float v33; // xmm0_4
  float v34; // xmm14_4
  __m128 v35; // xmm1
  float v36; // xmm1_4
  float v37; // xmm12_4
  __m128 v38; // xmm0
  float v39; // xmm0_4
  float v40; // xmm1_4
  float v41; // xmm0_4
  float v42; // xmm0_4
  float v43; // xmm0_4
  float v44; // xmm0_4
  float v45; // xmm9_4
  float v46; // xmm5_4
  float v47; // xmm4_4
  float v48; // xmm3_4
  float v49; // xmm0_4
  float v50; // xmm11_4
  float v51; // xmm15_4
  float v52; // xmm14_4
  float v53; // xmm12_4
  float v54; // xmm0_4
  int v55; // edx
  signed int v56; // edx
  float v57; // xmm5_4
  int v58; // edx
  signed int v59; // edx
  float v60; // xmm4_4
  int v61; // edx
  signed int v62; // edx
  float v63; // xmm3_4
  int v64; // edx
  signed int v65; // edx
  float v66; // xmm12_4
  __m128 v67; // xmm6
  int v68; // edi
  __m128 v69; // xmm0
  int v70; // ecx
  int v71; // ebp
  float v72; // xmm11_4
  float v73; // xmm10_4
  __m128 v74; // xmm5
  float v75; // xmm0_4
  float v76; // xmm9_4
  __m128 v77; // xmm4
  float v78; // xmm8_4
  __m128 v79; // xmm3
  int v80; // eax
  float *v81; // rcx
  __int64 v82; // rdx
  unsigned __int64 v83; // rax
  float *mOutputAccum; // rax
  int v85; // xmm0_4
  int v86; // eax
  FMOD::DSPPitchShiftSMB *v87; // rdx
  __int64 v88; // rcx
  __int128 v89; // xmm4
  float *v90; // r11
  __int64 v91; // rax
  int v92; // edx
  float *mCosTab; // rcx
  float *v94; // r10
  float *v95; // rdx
  float *v96; // rax
  int v97; // esi
  float v98; // xmm2_4
  signed int v99; // edi
  int v100; // r9d
  float v101; // xmm0_4
  float v102; // xmm1_4
  float v103; // xmm0_4
  signed int v104; // edi
  int v105; // r9d
  float v106; // xmm1_4
  signed int v107; // edi
  int v108; // r9d
  float v109; // xmm1_4
  float v110; // xmm0_4
  signed int v111; // edi
  int v112; // r9d
  float v113; // xmm1_4
  signed int v114; // edi
  int v115; // r9d
  float v116; // xmm1_4
  float v117; // xmm0_4
  signed int v118; // edi
  int v119; // r9d
  float v120; // xmm1_4
  signed int v121; // edi
  int v122; // r9d
  float v123; // xmm1_4
  float v124; // xmm0_4
  __int128 v125; // xmm2
  float v126; // xmm10_4
  float v127; // xmm1_4
  float v128; // xmm6_4
  float v129; // xmm2_4
  float v130; // xmm1_4
  float v131; // xmm0_4
  float v132; // xmm10_4
  float v133; // xmm1_4
  float v134; // xmm9_4
  float v135; // xmm6_4
  signed int v136; // edi
  int v137; // r9d
  float *v138; // r8
  int j; // eax
  float freqPerBin; // [rsp+8h] [rbp-100h]
  float freqPerBina; // [rsp+8h] [rbp-100h]
  int fftFrameSize2; // [rsp+10h] [rbp-F8h]
  float expct; // [rsp+14h] [rbp-F4h]
  float outdataa; // [rsp+18h] [rbp-F0h]
  float *outdatab; // [rsp+18h] [rbp-F0h]
  __int32 imag0; // [rsp+20h] [rbp-E8h]
  __int32 imag0a; // [rsp+20h] [rbp-E8h]
  __int32 imag1; // [rsp+2Ch] [rbp-DCh]
  __int32 imag2; // [rsp+34h] [rbp-D4h]
  __int32 imag2a; // [rsp+34h] [rbp-D4h]
  __int32 imag2b; // [rsp+34h] [rbp-D4h]
  __int32 imag2c; // [rsp+34h] [rbp-D4h]
  __int32 imag3; // [rsp+3Ch] [rbp-CCh]
  int k1_0; // [rsp+44h] [rbp-C4h]
  int v155; // [rsp+48h] [rbp-C0h]
  int v156; // [rsp+4Ch] [rbp-BCh]
  int inFifoLatency; // [rsp+5Ch] [rbp-ACh]
  __int64 v158; // [rsp+60h] [rbp-A8h]
  int i; // [rsp+68h] [rbp-A0h]
  float *v161; // [rsp+70h] [rbp-98h]
  __int64 v162; // [rsp+78h] [rbp-90h]
  float *v163; // [rsp+80h] [rbp-88h]
  FMOD::DSPPitchShiftSMB *v164; // [rsp+88h] [rbp-80h]
  int stepSize; // [rsp+98h] [rbp-70h]
  float *v167; // [rsp+C0h] [rbp-48h]
  float v168; // [rsp+C8h] [rbp-40h]

  v9 = channel;
  v11 = &indata[v9];
  v161 = &indata[v9];
  if ( numSampsToProcess > 0 )
  {
    v12 = this;
    v13 = 0.0;
    v162 = 4LL * numchannels;
    v14 = 0;
    do
    {
      ++v14;
      v15 = fabs(*v11);
      v11 += numchannels;
      v13 = v13 + v15;
    }
    while ( v14 != numSampsToProcess );
    if ( v13 < 0.001 )
    {
      v138 = &outdata[v9];
      for ( j = 0; j != numSampsToProcess; ++j )
      {
        *v138 = 0.0;
        v138 = (float *)((char *)v138 + v162);
      }
    }
    else
    {
      mFFTFrameSize = this->mFFTFrameSize;
      fftFrameSize2 = mFFTFrameSize / 2;
      v17 = sampleRate / (float)mFFTFrameSize;
      stepSize = mFFTFrameSize / osamp;
      inFifoLatency = mFFTFrameSize - mFFTFrameSize / osamp;
      v18 = v17;
      v19 = (float)((float)(mFFTFrameSize / osamp) * 6.2831855) / (float)mFFTFrameSize;
      if ( !*(_DWORD *)((char *)&stru_14028.r_offset + (_QWORD)this) )
        *(_DWORD *)((char *)&stru_14028.r_offset + (_QWORD)this) = this->mFFTFrameSize - mFFTFrameSize / osamp;
      if ( *((_BYTE *)&stru_14040.r_offset + (_QWORD)this) )
      {
        outdatab = outdata;
        memset(this->mLastPhase, 0, sizeof(this->mLastPhase));
        memset(this->mSumPhase, 0, sizeof(this->mSumPhase));
        *((_BYTE *)&stru_14040.r_offset + (_QWORD)this) = 0;
        mFFTFrameSize = this->mFFTFrameSize;
        outdata = outdatab;
        v18 = v17;
      }
      v158 = 0;
      i = 0;
      v163 = &outdata[v9];
      v167 = &this->mOutputAccum[stepSize - 1 + 1];
      outdataa = (float)((float)osamp * v18) / 6.2831855;
      v168 = 6.2831855 / (float)osamp;
      while ( 1 )
      {
        v20 = *(_DWORD *)((char *)&stru_14028.r_offset + (_QWORD)v12);
        v12->mInFIFO[v20] = *(float *)((char *)v161 + v158);
        v21 = v20 - inFifoLatency;
        ++v20;
        *(float *)((char *)v163 + v158) = v12->mOutFIFO[v21];
        *(_DWORD *)((char *)&stru_14028.r_offset + (_QWORD)v12) = v20;
        if ( v20 >= mFFTFrameSize )
        {
          *(_DWORD *)((char *)&stru_14028.r_offset + (_QWORD)v12) = inFifoLatency;
          if ( mFFTFrameSize > 0 )
          {
            mWindow = v12->mWindow;
            v23 = 0;
            do
            {
              v24 = v12->mInFIFO[v23 / 4] * mWindow[v23 / 4];
              fftBuffer[v23 / 2 + 1] = 0.0;
              fftBuffer[v23 / 2] = v24;
              v23 += 4LL;
            }
            while ( v23 != 4LL * (unsigned int)(mFFTFrameSize - 1) + 4 );
          }
          FMOD::DSPPitchShiftSMB::fft(v12, fftBuffer, -1);
          v25 = 0u;
          if ( fftFrameSize2 < 0 )
          {
            memset(flt_2AE4880, 0, 4LL * v12->mFFTFrameSize);
            memset(flt_2AE8880, 0, 4LL * v12->mFFTFrameSize);
          }
          else
          {
            v26 = (float *)v12;
            v27 = fftBuffer;
            v164 = v12;
            v28 = 0;
            freqPerBin = v18;
            v29 = flt_2ADC880;
            v30 = flt_2AE0880;
            expct = v19;
            do
            {
              v67.m128_f32[0] = v27[1];
              v68 = v28 + 1;
              v69 = _mm_cmplt_ss(v25, v67);
              v70 = v28 + 2;
              v71 = v28 + 3;
              v72 = *v27;
              v73 = v27[2];
              v74.m128_f32[0] = v27[3];
              LODWORD(v75) = _mm_andnot_ps(v69, (__m128)0xBF800000).m128_u32[0] | v69.m128_i32[0] & 0x3F800000;
              v76 = v27[4];
              v77.m128_f32[0] = v27[5];
              v78 = v27[6];
              v79.m128_f32[0] = v27[7];
              v31 = 0.0;
              if ( v67.m128_f32[0] != 0.0 )
              {
                if ( v72 == 0.0 )
                {
                  v31 = 0.5 * (float)(v75 * 3.1415927);
                }
                else
                {
                  imag2 = *((_DWORD *)v27 + 5);
                  imag1 = *((_DWORD *)v27 + 3);
                  v25 = 0u;
                  v31 = atan2f(v27[1], *v27);
                  v68 = v28 + 1;
                  v70 = v28 + 2;
                  v77.m128_i32[0] = imag2;
                  v74.m128_i32[0] = imag1;
                }
              }
              v32 = _mm_cmplt_ss(v25, v74);
              LODWORD(v33) = _mm_andnot_ps(v32, (__m128)0xBF800000).m128_u32[0] | v32.m128_i32[0] & 0x3F800000;
              v34 = 0.0;
              if ( v74.m128_f32[0] != 0.0 )
              {
                if ( v73 == 0.0 )
                {
                  v34 = 0.5 * (float)(v33 * 3.1415927);
                }
                else
                {
                  k1_0 = v70;
                  imag2c = v77.m128_i32[0];
                  imag0a = v74.m128_i32[0];
                  v25 = 0u;
                  v34 = atan2f(v74.m128_f32[0], v73);
                  v70 = k1_0;
                  v77.m128_i32[0] = imag2c;
                  v74.m128_i32[0] = imag0a;
                }
              }
              v35 = _mm_cmplt_ss(v25, v77);
              LODWORD(v36) = _mm_andnot_ps(v35, (__m128)0xBF800000).m128_u32[0] | v35.m128_i32[0] & 0x3F800000;
              v37 = 0.0;
              if ( v77.m128_f32[0] != 0.0 )
              {
                if ( v76 == 0.0 )
                {
                  v37 = 0.5 * (float)(v36 * 3.1415927);
                }
                else
                {
                  v155 = v70;
                  imag2b = v74.m128_i32[0];
                  imag0 = v77.m128_i32[0];
                  v25 = 0u;
                  v37 = atan2f(v77.m128_f32[0], v76);
                  v70 = v155;
                  v74.m128_i32[0] = imag2b;
                  v77.m128_i32[0] = imag0;
                }
              }
              v38 = _mm_cmplt_ss(v25, v79);
              LODWORD(v39) = _mm_andnot_ps(v38, (__m128)0xBF800000).m128_u32[0] | v38.m128_i32[0] & 0x3F800000;
              v40 = 0.0;
              if ( v79.m128_f32[0] != 0.0 )
              {
                if ( v78 == 0.0 )
                {
                  v40 = 0.5 * (float)(v39 * 3.1415927);
                }
                else
                {
                  v156 = v70;
                  imag3 = v77.m128_i32[0];
                  imag2a = v74.m128_i32[0];
                  v25 = 0u;
                  v40 = atan2f(v79.m128_f32[0], v78);
                  v70 = v156;
                  v77.m128_i32[0] = imag3;
                  v74.m128_i32[0] = imag2a;
                }
              }
              v41 = fsqrt((float)((float)(v72 * v72) + (float)(v67.m128_f32[0] * v67.m128_f32[0])) + 0.0);
              *v29 = v41 + v41;
              v42 = fsqrt((float)((float)(v73 * v73) + (float)(v74.m128_f32[0] * v74.m128_f32[0])) + 0.0);
              v29[1] = v42 + v42;
              v43 = fsqrt((float)((float)(v76 * v76) + (float)(v77.m128_f32[0] * v77.m128_f32[0])) + 0.0);
              v29[2] = v43 + v43;
              v44 = fsqrt((float)((float)(v78 * v78) + (float)(v79.m128_f32[0] * v79.m128_f32[0])) + 0.0);
              v45 = (float)v28;
              v29[3] = v44 + v44;
              v46 = (float)(expct * (float)v28) + v26[0x2000];
              v26[0x2000] = v31;
              v47 = (float)(expct * (float)v68) + v26[8193];
              v48 = (float)(expct * (float)v70) + v26[8194];
              v26[8193] = v34;
              v49 = (float)(expct * (float)v71) + v26[8195];
              v26[8194] = v37;
              v26[8195] = v40;
              v50 = v31 - v46;
              v51 = v34 - v47;
              v52 = v37 - v48;
              v53 = v40 - v49;
              v54 = v40 - v49;
              v55 = (int)(float)(0.31830987 * v50);
              if ( v55 < 0 )
                v56 = v55 & 0xFFFFFFFE;
              else
                v56 = ((int)(float)(0.31830987 * v50) & 1) + (int)(float)(0.31830987 * v50);
              v57 = v50 - (float)((float)v56 * 3.1415927);
              v58 = (int)(float)(0.31830987 * v51);
              if ( v58 < 0 )
                v59 = v58 & 0xFFFFFFFE;
              else
                v59 = ((int)(float)(0.31830987 * v51) & 1) + (int)(float)(0.31830987 * v51);
              v60 = v51 - (float)((float)v59 * 3.1415927);
              v61 = (int)(float)(0.31830987 * v52);
              if ( v61 < 0 )
                v62 = v61 & 0xFFFFFFFE;
              else
                v62 = ((int)(float)(0.31830987 * v52) & 1) + (int)(float)(0.31830987 * v52);
              v63 = v52 - (float)((float)v62 * 3.1415927);
              v64 = (int)(float)(0.31830987 * v53);
              if ( v64 < 0 )
                v65 = v64 & 0xFFFFFFFE;
              else
                v65 = ((int)(float)(0.31830987 * v53) & 1) + (int)(float)(0.31830987 * v53);
              v28 += 4;
              v27 += 8;
              v66 = freqPerBin;
              v30 += 4;
              v29 += 4;
              v26 += 4;
              *(v30 - 4) = (float)(v45 * freqPerBin) + (float)(v57 * outdataa);
              *(v30 - 3) = (float)((float)v68 * freqPerBin) + (float)(v60 * outdataa);
              *(v30 - 2) = (float)((float)v70 * freqPerBin) + (float)(v63 * outdataa);
              *(v30 - 1) = (float)((float)v71 * freqPerBin)
                         + (float)((float)(v54 - (float)((float)v65 * 3.1415927)) * outdataa);
            }
            while ( fftFrameSize2 >= v28 );
            v12 = v164;
            memset(flt_2AE4880, 0, 4LL * v164->mFFTFrameSize);
            memset(flt_2AE8880, 0, 4LL * v164->mFFTFrameSize);
            v90 = flt_2AE8880;
            v91 = 0;
            v18 = freqPerBin;
            v19 = expct;
            do
            {
              v92 = (int)(float)((float)((float)(int)v91 * pitchShift) + 0.5);
              if ( fftFrameSize2 >= v92 )
              {
                flt_2AE8880[v92] = flt_2AE0880[v91] * pitchShift;
                flt_2AE4880[v92] = flt_2AE4880[v92] + flt_2ADC880[v91];
              }
              ++v91;
            }
            while ( fftFrameSize2 >= (int)v91 );
            mCosTab = v164->mCosTab;
            v94 = flt_2AE4880;
            v95 = fftBuffer;
            v96 = (float *)v164;
            v97 = 0;
            do
            {
              *(float *)&v89 = (float)(v97 + 1);
              v125 = v89;
              v124 = (float)((float)((float)v97 * expct) + (float)((float)((float)(*v90 / v66) - (float)v97) * v168))
                   + v96[10244];
              v96[10244] = v124;
              *(float *)&v125 = (float)((float)(*(float *)&v89 * expct)
                                      + (float)((float)((float)(v90[1] / v66) - *(float *)&v89) * v168))
                              + v96[10245];
              *((_DWORD *)v96 + 10245) = v125;
              v126 = *(float *)&v125;
              v127 = (float)((float)((float)(v97 + 2) * expct)
                           + (float)((float)((float)(v90[2] / v66) - (float)(v97 + 2)) * v168))
                   + v96[10246];
              v96[10246] = v127;
              freqPerBina = v127;
              v128 = (float)((float)((float)(v97 + 3) * expct)
                           + (float)((float)((float)(v90[3] / v66) - (float)(v97 + 3)) * v168))
                   + v96[10247];
              v96[10247] = v128;
              if ( v124 > 3.1415927 || v124 < -3.1415927 )
              {
                v124 = v124 - (float)((float)(int)(float)(v124 * 0.15915494) * 6.2831855);
                v96[10244] = v124;
              }
              if ( *(float *)&v125 > 3.1415927 || (v89 = 0xC0490FDB, *(float *)&v125 < -3.1415927) )
              {
                v89 = v125;
                v129 = *(float *)&v125 - (float)((float)(int)(float)(*(float *)&v125 * 0.15915494) * 6.2831855);
                v96[10245] = v129;
                v126 = v129;
              }
              if ( v127 > 3.1415927 || v127 < -3.1415927 )
              {
                v130 = v127 - (float)((float)(int)(float)(v127 * 0.15915494) * 6.2831855);
                v96[10246] = v130;
                freqPerBina = v130;
              }
              if ( v128 > 3.1415927 || v128 < -3.1415927 )
              {
                v128 = v128 - (float)((float)(int)(float)(v128 * 0.15915494) * 6.2831855);
                v96[10247] = v128;
              }
              v131 = v124 * 0.15915494;
              v132 = v126 * 0.15915494;
              v133 = *v94;
              v134 = freqPerBina * 0.15915494;
              v135 = v128 * 0.15915494;
              v136 = abs32((int)(float)(v131 * 32768.0)) & 0x7FFF;
              v137 = v136 >> 13;
              if ( v136 >> 13 == 2 )
              {
                v98 = -mCosTab[v136 - 0x4000];
              }
              else if ( v137 == 3 )
              {
                v98 = mCosTab[0x7FFF - v136];
              }
              else if ( v137 == 1 )
              {
                v98 = -mCosTab[0x3FFF - v136];
              }
              else
              {
                v98 = mCosTab[v136];
              }
              *v95 = v98 * v133;
              v99 = abs32((int)(float)((float)(v131 - 0.25) * 32768.0)) & 0x7FFF;
              v100 = v99 >> 13;
              if ( v99 >> 13 == 2 )
              {
                v101 = -mCosTab[v99 - 0x4000];
              }
              else if ( v100 == 3 )
              {
                v101 = mCosTab[0x7FFF - v99];
              }
              else if ( v100 == 1 )
              {
                v101 = -mCosTab[0x3FFF - v99];
              }
              else
              {
                v101 = mCosTab[v99];
              }
              v102 = v133 * v101;
              v103 = v94[1];
              v95[1] = v102;
              v104 = abs32((int)(float)(v132 * 32768.0)) & 0x7FFF;
              v105 = v104 >> 13;
              if ( v104 >> 13 == 2 )
              {
                v106 = -mCosTab[v104 - 0x4000];
              }
              else if ( v105 == 3 )
              {
                v106 = mCosTab[0x7FFF - v104];
              }
              else if ( v105 == 1 )
              {
                v106 = -mCosTab[0x3FFF - v104];
              }
              else
              {
                v106 = mCosTab[v104];
              }
              v95[2] = v106 * v103;
              v107 = abs32((int)(float)((float)(v132 - 0.25) * 32768.0)) & 0x7FFF;
              v108 = v107 >> 13;
              if ( v107 >> 13 == 2 )
              {
                v109 = -mCosTab[v107 - 0x4000];
              }
              else if ( v108 == 3 )
              {
                v109 = mCosTab[0x7FFF - v107];
              }
              else if ( v108 == 1 )
              {
                v109 = -mCosTab[0x3FFF - v107];
              }
              else
              {
                v109 = mCosTab[v107];
              }
              v95[3] = v103 * v109;
              v110 = v94[2];
              v111 = abs32((int)(float)(v134 * 32768.0)) & 0x7FFF;
              v112 = v111 >> 13;
              if ( v111 >> 13 == 2 )
              {
                v113 = -mCosTab[v111 - 0x4000];
              }
              else if ( v112 == 3 )
              {
                v113 = mCosTab[0x7FFF - v111];
              }
              else if ( v112 == 1 )
              {
                v113 = -mCosTab[0x3FFF - v111];
              }
              else
              {
                v113 = mCosTab[v111];
              }
              v95[4] = v113 * v110;
              v114 = abs32((int)(float)((float)(v134 - 0.25) * 32768.0)) & 0x7FFF;
              v115 = v114 >> 13;
              if ( v114 >> 13 == 2 )
              {
                v116 = -mCosTab[v114 - 0x4000];
              }
              else if ( v115 == 3 )
              {
                v116 = mCosTab[0x7FFF - v114];
              }
              else if ( v115 == 1 )
              {
                v116 = -mCosTab[0x3FFF - v114];
              }
              else
              {
                v116 = mCosTab[v114];
              }
              v95[5] = v110 * v116;
              v117 = v94[3];
              v118 = abs32((int)(float)(v135 * 32768.0)) & 0x7FFF;
              v119 = v118 >> 13;
              if ( v118 >> 13 == 2 )
              {
                v120 = -mCosTab[v118 - 0x4000];
              }
              else if ( v119 == 3 )
              {
                v120 = mCosTab[0x7FFF - v118];
              }
              else if ( v119 == 1 )
              {
                v120 = -mCosTab[0x3FFF - v118];
              }
              else
              {
                v120 = mCosTab[v118];
              }
              v95[6] = v120 * v117;
              v121 = abs32((int)(float)((float)(v135 - 0.25) * 32768.0)) & 0x7FFF;
              v122 = v121 >> 13;
              if ( v121 >> 13 == 2 )
              {
                v123 = -mCosTab[v121 - 0x4000];
              }
              else if ( v122 == 3 )
              {
                v123 = mCosTab[0x7FFF - v121];
              }
              else if ( v122 == 1 )
              {
                v123 = -mCosTab[0x3FFF - v121];
              }
              else
              {
                v123 = mCosTab[v121];
              }
              v97 += 4;
              v96 += 4;
              v90 += 4;
              v95 += 8;
              v94 += 4;
              *(v95 - 1) = v117 * v123;
            }
            while ( v97 != 4 * ((unsigned int)fftFrameSize2 >> 2) + 4 );
          }
          memset(&fftBuffer[v12->mFFTFrameSize + 2], 0, 4LL * (v12->mFFTFrameSize - 2));
          FMOD::DSPPitchShiftSMB::fft(v12, fftBuffer, 1);
          v80 = v12->mFFTFrameSize;
          if ( v80 > 0 )
          {
            v81 = v12->mWindow;
            v82 = 4LL * (unsigned int)(v80 - 1) + 4;
            v83 = 0;
            do
            {
              v12->mOutputAccum[v83 / 4] = (float)(v81[v83 / 4] * fftBuffer[v83 / 2]) + v12->mOutputAccum[v83 / 4];
              v83 += 4LL;
            }
            while ( v83 != v82 );
          }
          if ( stepSize > 0 )
          {
            mOutputAccum = v12->mOutputAccum;
            do
            {
              v85 = *(_DWORD *)mOutputAccum++;
              *((_DWORD *)mOutputAccum - 8201) = v85;
            }
            while ( mOutputAccum != v167 );
          }
          memmove(v12->mOutputAccum, &v12->mOutputAccum[stepSize], 4LL * inFifoLatency);
          memset(&v12->mOutputAccum[inFifoLatency], 0, 4LL * stepSize);
          if ( inFifoLatency > 0 )
          {
            v86 = stepSize;
            v87 = v12;
            do
            {
              v88 = v86++;
              v87 = (FMOD::DSPPitchShiftSMB *)((char *)v87 + 4);
              *((_DWORD *)&v87[-1].mResetPhaseFlag + 1) = LODWORD(v12->mInFIFO[v88]);
            }
            while ( v86 != stepSize + inFifoLatency );
          }
        }
        ++i;
        v158 += v162;
        if ( i == numSampsToProcess )
          break;
        mFFTFrameSize = v12->mFFTFrameSize;
      }
    }
  }
}


// Address: 0x2209070 | Name: _ZN4FMOD16DSPPitchShiftSMB6smbFftEPfi
void __fastcall FMOD::DSPPitchShiftSMB::smbFft(FMOD::DSPPitchShiftSMB *const this, float *fftBuffer, int sign)
{
  int mFFTFrameSize; // r8d
  int v5; // ebx
  int v6; // r10d
  float *v7; // r11
  int i; // r9d
  int v9; // eax
  int j; // ecx
  int v11; // esi
  int v12; // xmm0_4
  float *v13; // rax
  int v14; // xmm0_4
  int mFFTFrameBits; // r14d
  float v16; // xmm13_4
  float *mCosTab; // r13
  int v18; // r8d
  int v19; // ebp
  int v20; // r9d
  int v21; // r11d
  float v22; // xmm0_4
  signed int v23; // eax
  int v24; // edx
  float v25; // xmm5_4
  signed int v26; // eax
  int v27; // edx
  float v28; // xmm6_4
  float v29; // xmm6_4
  float *v30; // r10
  float v31; // xmm3_4
  __int128 v32; // xmm4
  __int64 v33; // rsi
  int v34; // edi
  float *v35; // rax
  float *v36; // rdx
  int k; // ecx
  float v38; // xmm1_4
  float v39; // xmm0_4
  float v40; // xmm0_4
  __int128 v41; // xmm0

  mFFTFrameSize = this->mFFTFrameSize;
  v5 = 2 * mFFTFrameSize - 2;
  if ( v5 > 2 )
  {
    v6 = 2 * mFFTFrameSize;
    v7 = fftBuffer + 2;
    for ( i = 2; i < v5; i += 2 )
    {
      if ( v6 > 2 )
      {
        v9 = 0;
        for ( j = 2; j < v6; j *= 2 )
        {
          v11 = i & j;
          v9 = 2 * (v9 - ((v11 == 0) - 1));
        }
        if ( v9 > i )
        {
          v12 = *(_DWORD *)v7;
          v13 = &fftBuffer[v9];
          *v7 = *v13;
          *(_DWORD *)v13 = v12;
          v14 = *((_DWORD *)v7 + 1);
          v7[1] = v13[1];
          *((_DWORD *)v13 + 1) = v14;
        }
      }
      v7 += 2;
    }
  }
  mFFTFrameBits = this->mFFTFrameBits;
  if ( mFFTFrameBits > 0 )
  {
    v16 = (float)sign;
    mCosTab = this->mCosTab;
    v18 = 2 * mFFTFrameSize;
    v19 = 0;
    v20 = 2;
    do
    {
      v20 *= 2;
      v21 = v20 >> 1;
      v22 = 0.5 / (float)(v20 >> 2);
      v23 = abs32((int)(float)(v22 * 32768.0)) & 0x7FFF;
      v24 = v23 >> 13;
      if ( v23 >> 13 == 2 )
      {
        v25 = -mCosTab[v23 - 0x4000];
      }
      else if ( v24 == 3 )
      {
        v25 = mCosTab[0x7FFF - v23];
      }
      else if ( v24 == 1 )
      {
        v25 = -mCosTab[0x3FFF - v23];
      }
      else
      {
        v25 = mCosTab[v23];
      }
      v26 = abs32((int)(float)((float)(v22 - 0.25) * 32768.0)) & 0x7FFF;
      v27 = v26 >> 13;
      if ( v26 >> 13 == 2 )
      {
        v28 = -mCosTab[v26 - 0x4000];
      }
      else if ( v27 == 3 )
      {
        v28 = mCosTab[0x7FFF - v26];
      }
      else if ( v27 == 1 )
      {
        v28 = -mCosTab[0x3FFF - v26];
      }
      else
      {
        v28 = mCosTab[v26];
      }
      v29 = v28 * v16;
      if ( v21 > 0 )
      {
        v30 = fftBuffer;
        v31 = 0.0;
        v32 = 0x3F800000u;
        v33 = 4LL * v20;
        v34 = 0;
        while ( 1 )
        {
          v35 = v30;
          v36 = &v30[v21];
          for ( k = v34; k < v18; v35 = (float *)((char *)v35 + v33) )
          {
            k += v20;
            v38 = (float)(*v36 * *(float *)&v32) - (float)(v36[1] * v31);
            v39 = (float)(*v36 * v31) + (float)(v36[1] * *(float *)&v32);
            *v36 = *v35 - v38;
            v36[1] = v35[1] - v39;
            v36 = (float *)((char *)v36 + v33);
            v40 = v39 + v35[1];
            *v35 = v38 + *v35;
            v35[1] = v40;
          }
          v41 = v32;
          v34 += 2;
          v30 += 2;
          *(float *)&v41 = (float)(*(float *)&v32 * v25) - (float)(v31 * v29);
          v31 = (float)(*(float *)&v32 * v29) + (float)(v31 * v25);
          if ( v21 <= v34 )
            break;
          v32 = v41;
        }
      }
      ++v19;
    }
    while ( v19 != mFFTFrameBits );
  }
}


// Address: 0x2209380 | Name: _ZN4FMOD16DSPPitchShiftSMB17setResetPhaseFlagEv
void __fastcall FMOD::DSPPitchShiftSMB::setResetPhaseFlag(FMOD::DSPPitchShiftSMB *const this)
{
  *((_BYTE *)&stru_14040.r_offset + (_QWORD)this) = 1;
}


// Address: 0x2209390 | Name: _ZN4FMOD13DSPPitchShift13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPPitchShift::resetInternal(FMOD::DSPPitchShift *const this)
{
  __int64 v1; // rax
  __int64 v2; // rbx
  int v3; // ebp

  v1 = *((_QWORD *)this + 6212);
  if ( v1 && *((int *)this + 12427) > 0 )
  {
    v2 = 0;
    v3 = 0;
    do
    {
      ++v3;
      FMOD::DSPPitchShiftSMB::smbInit((FMOD::DSPPitchShiftSMB *const)(v1 + v2));
      v1 = *((_QWORD *)this + 6212);
      *(_QWORD *)(v1 + v2 + 81976) = (char *)this + 528;
      v2 += 81992;
    }
    while ( *((_DWORD *)this + 12427) > v3 );
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2209400 | Name: _ZN4FMOD13DSPPitchShift13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPPitchShift::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPPitchShift::resetInternal((FMOD::DSPPitchShift *const)dsp_state->instance);
}


// Address: 0x2209410 | Name: _ZN4FMOD13DSPPitchShift12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPPitchShift::readInternal(
        FMOD::DSPPitchShift *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  __int64 v9; // rdi
  __int64 v10; // r15
  int v11; // ebp
  FMOD::DSPPitchShiftSMB *v12; // rdi
  float v13; // xmm1_4
  float v14; // xmm0_4
  int v15; // r9d

  if ( inbuffer )
  {
    if ( *((_DWORD *)this + 12427) >= inchannels && (v9 = *((_QWORD *)this + 6212)) != 0 )
    {
      v10 = 0;
      v11 = 0;
      if ( inchannels > 0 )
      {
        while ( 1 )
        {
          v12 = (FMOD::DSPPitchShiftSMB *)(v10 + v9);
          v13 = (float)*((int *)this + 12426);
          v14 = *((float *)this + 12420);
          v15 = v11++;
          v12->mFFTFrameSize = *((_DWORD *)this + 12421);
          v10 += 81992;
          v12->mFFTFrameBits = *((_DWORD *)this + 12428);
          FMOD::DSPPitchShiftSMB::smbPitchShift(
            v12,
            v14,
            length,
            *((_DWORD *)this + 12422),
            v13,
            inbuffer,
            outbuffer,
            v15,
            inchannels);
          if ( v11 == inchannels )
            break;
          v9 = *((_QWORD *)this + 6212);
        }
      }
    }
    else
    {
      memcpy_0(outbuffer, inbuffer, 4LL * *outchannels * length);
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22094f0 | Name: _ZN4FMOD13DSPPitchShift12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPPitchShift::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPPitchShift::readInternal(
           (FMOD::DSPPitchShift *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x2209500 | Name: _ZN4FMOD13DSPPitchShift25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPPitchShift::setParameterFloatInternal(FMOD::DSPI *this, int index, float a3, float value)
{
  FMOD::SystemI *mSystem; // rbx
  int v6; // r12d
  int v7; // ebp
  int v8; // r14d
  int mDSPMaxOutputChannels; // r15d
  FMOD::SystemI *v10; // rax
  int v11; // esi
  FMOD::DSPPitchShiftSMB *v12; // rdi
  float *v13; // r15
  float v14; // xmm7_4
  __int64 v15; // rax
  int v16; // ebp
  char v17; // r14
  int v18; // r10d
  float v19; // xmm5_4
  float v20; // xmm4_4
  float *v21; // rcx
  float *v22; // rdx
  __int64 v23; // rax
  __int64 v24; // rdi
  float v25; // xmm1_4
  int v26; // r9d
  float v27; // xmm1_4
  float v28; // xmm2_4
  int v29; // esi
  unsigned int v30; // r12d
  int v32; // r15d
  int v33; // eax
  int v34; // ecx
  __int64 v35; // rdx
  __int64 v36; // rax
  __int64 v37; // rcx
  int v38; // eax
  void *v39; // rsi
  char *v40; // rax
  char *v41; // rdi
  __int64 v42; // r12
  int v43; // ebp
  char *v44; // rax
  __int64 v45; // r14
  int v46; // r12d
  FMOD::DSPPitchShiftSMB *v47; // rdi
  bool v48; // zf
  int v49; // eax
  int v50; // edx
  int v51; // ecx
  float oldpitch; // [rsp+8h] [rbp-50h]
  char v53; // [rsp+Fh] [rbp-49h]

  mSystem = this->mSystem;
  v6 = *((_DWORD *)this + 12427);
  v7 = *((_DWORD *)this + 12421);
  oldpitch = *((float *)this + 12420);
  v8 = *((_DWORD *)this + 12422);
  if ( index == 1 )
  {
    if ( a3 <= 4096.0 )
    {
      v33 = 5;
      v32 = 256;
      while ( (float)v32 < a3 )
      {
        v32 *= 2;
        if ( !--v33 )
          goto LABEL_41;
      }
    }
    else
    {
      v32 = 4096;
    }
    if ( v7 != v32 )
    {
      if ( mSystem )
      {
        FMOD::SystemI::lockDSPInternal(mSystem);
        v10 = this->mSystem;
        v53 = 1;
      }
      else
      {
        v10 = 0;
        v53 = 0;
      }
      *((_DWORD *)this + 12421) = v32;
      mDSPMaxOutputChannels = *((_DWORD *)this + 12423);
      goto LABEL_6;
    }
    goto LABEL_41;
  }
  if ( index <= 1 )
  {
    if ( !index )
    {
      *((float *)this + 12420) = a3;
      if ( a3 == 0.0 )
        *((_DWORD *)this + 12420) = 1065353216;
    }
    goto LABEL_41;
  }
  if ( index == 2 )
  {
    if ( v8 != 4 )
    {
      if ( mSystem )
      {
        FMOD::SystemI::lockDSPInternal(mSystem);
        v10 = this->mSystem;
        v53 = 1;
      }
      else
      {
        v10 = 0;
        v53 = 0;
      }
      *((_DWORD *)this + 12422) = 4;
      mDSPMaxOutputChannels = *((_DWORD *)this + 12423);
      goto LABEL_6;
    }
    goto LABEL_41;
  }
  if ( index != 3 )
  {
LABEL_41:
    mDSPMaxOutputChannels = *((_DWORD *)this + 12423);
    v10 = mSystem;
    v53 = 0;
    goto LABEL_6;
  }
  mDSPMaxOutputChannels = (int)a3;
  v10 = this->mSystem;
  v53 = 0;
  *((_DWORD *)this + 12423) = (int)a3;
LABEL_6:
  *((_DWORD *)this + 12426) = v10->mDSPSampleRate;
  if ( !mDSPMaxOutputChannels )
    mDSPMaxOutputChannels = v10->mDSPMaxOutputChannels;
  if ( mDSPMaxOutputChannels != v6 )
  {
    if ( mSystem && !v53 )
    {
      FMOD::SystemI::lockDSPInternal(mSystem);
      v53 = 1;
    }
    *((_DWORD *)this + 12427) = mDSPMaxOutputChannels;
  }
  v11 = *((_DWORD *)this + 12421);
  if ( v11 == v7 )
    goto LABEL_84;
  v12 = (FMOD::DSPPitchShiftSMB *)*((_QWORD *)this + 6212);
  if ( !v12 )
  {
LABEL_42:
    v30 = 30;
    goto LABEL_43;
  }
  FMOD::DSPPitchShiftSMB::initFft(v12, v11);
  v11 = *((_DWORD *)this + 12421);
  if ( v11 == v7 )
  {
LABEL_84:
    if ( *((_DWORD *)this + 12422) == v8 )
      goto LABEL_67;
  }
  if ( !*((_QWORD *)this + 6212) )
    goto LABEL_42;
  if ( v11 == 1024 )
  {
    v15 = 1024;
    v14 = 1024.0;
    v16 = 512;
    v17 = 1;
    v18 = 513;
    v13 = flt_286BBA0;
    goto LABEL_22;
  }
  if ( v11 > 1024 )
  {
    if ( v11 == 2048 || v11 == 4096 )
      goto LABEL_21;
LABEL_55:
    v14 = -2.0;
    v15 = -2;
    v16 = -1;
    v17 = 0;
    v18 = 0;
    v13 = 0;
    goto LABEL_22;
  }
  if ( v11 != 256 && v11 != 512 )
    goto LABEL_55;
LABEL_21:
  v13 = flt_286BBA0;
  v14 = 1024.0;
  v15 = 1024;
  v16 = 512;
  v17 = 0;
  v18 = 513;
LABEL_22:
  v19 = v14 / (float)v11;
  v20 = fsqrt((float)((float)v11 * 0.25) * (float)*((int *)this + 12422));
  if ( v11 > 0 )
  {
    v21 = &v13[v15];
    v22 = (float *)((char *)this + 33296);
    v23 = 0;
    v24 = (unsigned int)(v11 - 1) + 1LL;
    do
    {
      if ( v17 )
      {
        if ( v18 > (int)v23 )
          v25 = v13[v23];
        else
          v25 = *v21;
        *v22 = v25;
      }
      else
      {
        v26 = 1;
        v27 = (float)(int)v23 * v19;
        if ( v27 > (float)v16 )
        {
          v26 = -1;
          v27 = v14 - v27;
        }
        v28 = v13[v27];
        if ( (float)(int)v27 == v27 || (v29 = v26 + (int)v27, v29 < 0) )
        {
          *v22 = v28;
          v25 = v28;
        }
        else
        {
          v25 = (float)((float)(v27 - (float)(int)v27) * (float)(v13[v29] - v28)) + v28;
          *v22 = v25;
        }
      }
      ++v23;
      ++v22;
      --v21;
      *(v22 - 1) = v25 / v20;
    }
    while ( v23 != v24 );
  }
  v34 = *((_DWORD *)this + 12427);
  if ( v34 > 0 )
  {
    v35 = *((_QWORD *)this + 6212);
    v36 = v35 + 81992;
    v37 = v35 + 81992 + 81992LL * (unsigned int)(v34 - 1);
    while ( 1 )
    {
      *(_QWORD *)(v35 + 81952) = (char *)this + 33296;
      v35 = v36;
      if ( v36 == v37 )
        break;
      v36 += 81992;
    }
  }
  FMOD::DSPI::reset(this);
LABEL_67:
  v38 = *((_DWORD *)this + 12427);
  if ( v38 == v6 )
  {
    if ( *((_QWORD *)this + 6212) )
      goto LABEL_74;
  }
  else
  {
    v39 = (void *)*((_QWORD *)this + 6212);
    if ( v39 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v39, "../../../core_api/src/fmod_dsp_pitchshift.cpp", 2195);
      v38 = *((_DWORD *)this + 12427);
    }
  }
  v30 = 38;
  v40 = (char *)FMOD::MemPool::alloc(
                  off_286F358->gSystemMemPool,
                  81992 * v38,
                  "../../../core_api/src/fmod_dsp_pitchshift.cpp",
                  2198,
                  0,
                  0);
  *((_QWORD *)this + 6212) = v40;
  if ( !v40 )
    goto LABEL_43;
  if ( *((int *)this + 12427) <= 0 )
    goto LABEL_80;
  v41 = v40;
  v42 = 0;
  v43 = 0;
  do
  {
    ++v43;
    FMOD::DSPPitchShiftSMB::smbInit((FMOD::DSPPitchShiftSMB *const)&v41[v42]);
    v41 = (char *)*((_QWORD *)this + 6212);
    v44 = &v41[v42];
    v42 += 81992;
    *((_QWORD *)v44 + 10244) = (char *)this + 33296;
    *((_QWORD *)v44 + 10247) = this + 1;
    v38 = *((_DWORD *)this + 12427);
  }
  while ( v38 > v43 );
LABEL_74:
  v45 = 0;
  v46 = 0;
  if ( v38 > 0 )
  {
    do
    {
      v47 = (FMOD::DSPPitchShiftSMB *)(*((_QWORD *)this + 6212) + v45);
      v48 = oldpitch == *((float *)this + 12420);
      v47->mPitchRatioFromLast = *((float *)this + 12420) / oldpitch;
      if ( !v48 )
        FMOD::DSPPitchShiftSMB::setResetPhaseFlag(v47);
      ++v46;
      v45 += 81992;
    }
    while ( *((_DWORD *)this + 12427) > v46 );
  }
LABEL_80:
  v49 = *((_DWORD *)this + 12421);
  *((_DWORD *)this + 12428) = 0;
  v50 = 1;
  if ( v49 > 1 )
  {
    do
    {
      v49 >>= 1;
      v51 = v50++;
    }
    while ( v49 > 1 );
    *((_DWORD *)this + 12428) = v51;
  }
  v30 = 0;
LABEL_43:
  if ( v53 && mSystem )
    FMOD::SystemI::unlockDSPInternal(mSystem);
  return v30;
}


// Address: 0x2209b20 | Name: _ZN4FMOD13DSPPitchShift25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPPitchShift::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPPitchShift::setParameterFloatInternal((FMOD::DSPI *)dsp_state->instance, index, a3, value);
}


// Address: 0x2209b30 | Name: _ZN4FMOD13DSPPitchShift25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPPitchShift::getParameterFloatInternal(
        FMOD::DSPPitchShift *const this,
        int index,
        float *value,
        char *valuestr)
{
  if ( index == 1 )
  {
    if ( value )
      *value = (float)*((int *)this + 12421);
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    sprintf(valuestr, "%d", *((_DWORD *)this + 12421));
    return FMOD_RESULT::FMOD_OK_0;
  }
  else if ( index <= 1 )
  {
    if ( index )
      return FMOD_RESULT::FMOD_OK_0;
    if ( value )
      *value = *((float *)this + 12420);
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    sprintf(valuestr, "%.02f", *((float *)this + 12420));
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( index != 2 )
    {
      if ( index == 3 )
      {
        if ( value )
          *value = (float)*((int *)this + 12423);
        if ( valuestr )
          sprintf(valuestr, "%d", *((_DWORD *)this + 12423));
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( value )
      *value = (float)*((int *)this + 12422);
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    sprintf(valuestr, "%d", *((_DWORD *)this + 12422));
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x2209c40 | Name: _ZN4FMOD13DSPPitchShift25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPPitchShift::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPPitchShift::getParameterFloatInternal(
           (FMOD::DSPPitchShift *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


