// Address: 0x21fa880 | Name: FMOD_Memory_Initialize
FMOD_RESULT_0 __fastcall FMOD_Memory_Initialize(
        void *poolmem,
        int poollen,
        FMOD_MEMORY_ALLOC_CALLBACK useralloc,
        FMOD_MEMORY_REALLOC_CALLBACK userrealloc,
        FMOD_MEMORY_FREE_CALLBACK userfree,
        FMOD_MEMORY_TYPE memtypeflags)
{
  FMOD::Global *v6; // r11
  FMOD::Global *v7; // rax
  FMOD_RESULT_0 result; // eax
  FMOD::MemPool *v9; // rax
  FMOD::MemPool *gSystemMemPool; // rax
  FMOD::MemPool *v11; // rax

  v6 = off_286F358;
  v7 = off_286F358;
  do
  {
    if ( v7->gSystem[0] )
      return FMOD_RESULT::FMOD_ERR_INITIALIZED_0;
    v7 = (FMOD::Global *)((char *)v7 + 8);
  }
  while ( v7 != (FMOD::Global *)&off_286F358->gFileThreadId );
  if ( (_BYTE)poollen )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  off_286F358->gMemoryTypeFlags = memtypeflags;
  if ( poollen )
  {
    if ( !poolmem || useralloc || userrealloc || userfree || poollen <= 255 )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    result = FMOD::MemPool::init(v6->gSystemMemPool, poolmem, poollen, 0, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      gSystemMemPool = off_286F358->gSystemMemPool;
      gSystemMemPool->mAlloc = 0;
      gSystemMemPool->mRealloc = 0;
      gSystemMemPool->mFree = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  else
  {
    if ( poolmem )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( useralloc && userrealloc )
    {
      if ( !userfree )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      v9 = v6->gSystemMemPool;
      v9->mAlloc = useralloc;
      v9->mRealloc = userrealloc;
      v9->mFree = userfree;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      if ( useralloc || userrealloc || userfree )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      v11 = v6->gSystemMemPool;
      v11->mAlloc = FMOD::Memory_DefaultMalloc;
      v11->mRealloc = FMOD::Memory_DefaultRealloc;
      v11->mFree = FMOD::Memory_DefaultFree;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21fa9e0 | Name: FMOD_Memory_GetStats
FMOD_RESULT_0 __fastcall FMOD_Memory_GetStats(int *currentalloced, int *maxalloced, FMOD_BOOL blocking)
{
  int v3; // ebx
  FMOD::SystemI *v4; // rbp
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 v6; // eax
  FMOD_RESULT_0 v7; // ebx

  if ( blocking )
  {
    v3 = 0;
    while ( 1 )
    {
      while ( 1 )
      {
        v4 = off_286F358->gSystem[v3];
        if ( v4 )
        {
          if ( v4->mInitialized )
            break;
        }
        if ( ++v3 == 8 )
          goto LABEL_10;
      }
      result = FMOD::SystemI::enterMainUpdateLock(off_286F358->gSystem[v3]);
      if ( result )
        break;
      v6 = FMOD::SystemI::flushDSPQueue(v4, 1);
      if ( v6 || (v6 = FMOD::SystemI::flushDSPReleaseQueue(v4)) != FMOD_RESULT::FMOD_OK_0 )
      {
        v7 = v6;
        FMOD::SystemI::leaveMainUpdateLock(v4);
        return v7;
      }
      ++v3;
      FMOD::SystemI::leaveMainUpdateLock(v4);
      if ( v3 == 8 )
        goto LABEL_10;
    }
  }
  else
  {
LABEL_10:
    if ( currentalloced )
      *currentalloced = off_286F358->gSystemMemPool->mCurrentAllocated;
    v7 = FMOD_RESULT::FMOD_OK_0;
    if ( maxalloced )
      *maxalloced = off_286F358->gSystemMemPool->mMaxAllocated;
    return v7;
  }
  return result;
}


// Address: 0x21faae0 | Name: FMOD_System_Create
FMOD_RESULT_0 __fastcall FMOD_System_Create(FMOD_SYSTEM **system)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v2; // rax
  FMOD_SYSTEM *v3; // rbp
  __int64 v4; // rdx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( system )
  {
    v2 = (FMOD::SystemI *)FMOD::MemPool::calloc(
                            off_286F358->gSystemMemPool,
                            (int)&stru_12630,
                            "../../../core_api/src/fmod.cpp",
                            284,
                            0);
    v3 = (FMOD_SYSTEM *)v2;
    if ( v2 )
    {
      FMOD::SystemI::SystemI(v2);
      *system = v3;
      v4 = 0;
      while ( off_286F358->gSystem[v4] )
      {
        if ( ++v4 == 8 )
        {
          FMOD::MemPool::free(off_286F358->gSystemMemPool, v3, "../../../core_api/src/fmod.cpp", 302);
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        }
      }
      off_286F358->gSystem[(int)v4] = (FMOD::SystemI *)v3;
      *(_DWORD *)((char *)&stru_115E0.r_offset + (_QWORD)v3) = v4;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      *system = 0;
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
  }
  return result;
}


// Address: 0x21fabb0 | Name: j__ZN4FMOD6System7releaseEv
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::System::release(FMOD_SYSTEM *system)
{
  return _ZN4FMOD6System7releaseEv((FMOD::System *const)system);
}


// Address: 0x21fabc0 | Name: FMOD_System_SetOutput
FMOD_RESULT_0 __fastcall FMOD_System_SetOutput(FMOD_SYSTEM *system, FMOD_OUTPUTTYPE_0 output)
{
  if ( system )
    return FMOD::System::setOutput((FMOD::System *const)system, output);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fabe0 | Name: FMOD_System_GetOutput
FMOD_RESULT_0 __fastcall FMOD_System_GetOutput(FMOD_SYSTEM *system, FMOD_OUTPUTTYPE_0 *output)
{
  if ( system )
    return FMOD::System::getOutput((FMOD::System *const)system, output);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fac00 | Name: FMOD_System_GetNumDrivers
FMOD_RESULT_0 __fastcall FMOD_System_GetNumDrivers(FMOD_SYSTEM *system, int *numdrivers)
{
  if ( system )
    return FMOD::System::getNumDrivers((FMOD::System *const)system, numdrivers);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fac20 | Name: FMOD_System_GetDriverInfo
FMOD_RESULT_0 __fastcall FMOD_System_GetDriverInfo(
        FMOD_SYSTEM *system,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels)
{
  if ( system )
    return FMOD::System::getDriverInfo(
             (FMOD::System *const)system,
             id,
             name,
             namelen,
             guid,
             systemrate,
             speakermode,
             speakermodechannels);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fac40 | Name: FMOD_System_SetDriver
FMOD_RESULT_0 __fastcall FMOD_System_SetDriver(FMOD_SYSTEM *system, int driver)
{
  if ( system )
    return FMOD::System::setDriver((FMOD::System *const)system, driver);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fac60 | Name: FMOD_System_GetDriver
FMOD_RESULT_0 __fastcall FMOD_System_GetDriver(FMOD_SYSTEM *system, int *driver)
{
  if ( system )
    return FMOD::System::getDriver((FMOD::System *const)system, driver);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fac80 | Name: FMOD_System_SetSoftwareChannels
FMOD_RESULT_0 __fastcall FMOD_System_SetSoftwareChannels(FMOD_SYSTEM *system, int numsoftwarechannels)
{
  if ( system )
    return FMOD::System::setSoftwareChannels((FMOD::System *const)system, numsoftwarechannels);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21faca0 | Name: FMOD_System_GetSoftwareChannels
FMOD_RESULT_0 __fastcall FMOD_System_GetSoftwareChannels(FMOD_SYSTEM *system, int *numsoftwarechannels)
{
  if ( system )
    return FMOD::System::getSoftwareChannels((FMOD::System *const)system, numsoftwarechannels);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21facc0 | Name: FMOD_System_SetSoftwareFormat
FMOD_RESULT_0 __fastcall FMOD_System_SetSoftwareFormat(
        FMOD_SYSTEM *system,
        int samplerate,
        FMOD_SPEAKERMODE_0 speakermode,
        int numrawspeakers)
{
  if ( system )
    return FMOD::System::setSoftwareFormat((FMOD::System *const)system, samplerate, speakermode, numrawspeakers);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21face0 | Name: FMOD_System_GetSoftwareFormat
FMOD_RESULT_0 __fastcall FMOD_System_GetSoftwareFormat(
        FMOD_SYSTEM *system,
        int *samplerate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *numrawspeakers)
{
  if ( system )
    return FMOD::System::getSoftwareFormat((FMOD::System *const)system, samplerate, speakermode, numrawspeakers);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fad00 | Name: FMOD_System_SetDSPBufferSize
FMOD_RESULT_0 __fastcall FMOD_System_SetDSPBufferSize(FMOD_SYSTEM *system, unsigned int bufferlength, int numbuffers)
{
  if ( system )
    return FMOD::System::setDSPBufferSize((FMOD::System *const)system, bufferlength, numbuffers);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fad20 | Name: FMOD_System_GetDSPBufferSize
FMOD_RESULT_0 __fastcall FMOD_System_GetDSPBufferSize(FMOD_SYSTEM *system, unsigned int *bufferlength, int *numbuffers)
{
  if ( system )
    return FMOD::System::getDSPBufferSize((FMOD::System *const)system, bufferlength, numbuffers);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fad40 | Name: FMOD_System_SetFileSystem
FMOD_RESULT_0 __fastcall FMOD_System_SetFileSystem(
        FMOD_SYSTEM *system,
        FMOD_FILE_OPEN_CALLBACK useropen,
        FMOD_FILE_CLOSE_CALLBACK userclose,
        FMOD_FILE_READ_CALLBACK userread,
        FMOD_FILE_SEEK_CALLBACK userseek,
        FMOD_FILE_ASYNCREAD_CALLBACK userasyncread,
        FMOD_FILE_ASYNCCANCEL_CALLBACK userasynccancel,
        int blockalign)
{
  if ( system )
    return FMOD::System::setFileSystem(
             (FMOD::System *const)system,
             (FMOD_FILE_OPEN_CALLBACK_0)useropen,
             (FMOD_FILE_CLOSE_CALLBACK_0)userclose,
             (FMOD_FILE_READ_CALLBACK_0)userread,
             (FMOD_FILE_SEEK_CALLBACK_0)userseek,
             (FMOD_FILE_ASYNCREAD_CALLBACK_0)userasyncread,
             (FMOD_FILE_ASYNCCANCEL_CALLBACK_0)userasynccancel,
             blockalign);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fad60 | Name: FMOD_System_AttachFileSystem
FMOD_RESULT_0 __fastcall FMOD_System_AttachFileSystem(
        FMOD_SYSTEM *system,
        FMOD_FILE_OPEN_CALLBACK useropen,
        FMOD_FILE_CLOSE_CALLBACK userclose,
        FMOD_FILE_READ_CALLBACK userread,
        FMOD_FILE_SEEK_CALLBACK userseek)
{
  if ( system )
    return FMOD::System::attachFileSystem(
             (FMOD::System *const)system,
             (FMOD_FILE_OPEN_CALLBACK_0)useropen,
             (FMOD_FILE_CLOSE_CALLBACK_0)userclose,
             (FMOD_FILE_READ_CALLBACK_0)userread,
             (FMOD_FILE_SEEK_CALLBACK_0)userseek);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fad80 | Name: FMOD_System_SetAdvancedSettings
FMOD_RESULT_0 __fastcall FMOD_System_SetAdvancedSettings(FMOD_SYSTEM *system, FMOD_ADVANCEDSETTINGS *settings)
{
  if ( system )
    return FMOD::System::setAdvancedSettings((FMOD::System *const)system, (FMOD_ADVANCEDSETTINGS_0 *)settings);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fada0 | Name: FMOD_System_GetAdvancedSettings
FMOD_RESULT_0 __fastcall FMOD_System_GetAdvancedSettings(FMOD_SYSTEM *system, FMOD_ADVANCEDSETTINGS *settings)
{
  if ( system )
    return FMOD::System::getAdvancedSettings((FMOD::System *const)system, (FMOD_ADVANCEDSETTINGS_0 *)settings);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fadc0 | Name: FMOD_System_SetCallback
FMOD_RESULT_0 __fastcall FMOD_System_SetCallback(
        FMOD_SYSTEM *system,
        FMOD_SYSTEM_CALLBACK callback,
        FMOD_SYSTEM_CALLBACK_TYPE callbackmask)
{
  if ( system )
    return FMOD::System::setCallback((FMOD::System *const)system, (FMOD_SYSTEM_CALLBACK_0)callback, callbackmask);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fade0 | Name: FMOD_System_SetPluginPath
FMOD_RESULT_0 __fastcall FMOD_System_SetPluginPath(FMOD_SYSTEM *system, const char *path)
{
  if ( system )
    return FMOD::System::setPluginPath((FMOD::System *const)system, path);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fae00 | Name: FMOD_System_LoadPlugin
FMOD_RESULT_0 __fastcall FMOD_System_LoadPlugin(
        FMOD_SYSTEM *system,
        const char *filename,
        unsigned int *handle,
        unsigned int priority)
{
  if ( system )
    return FMOD::System::loadPlugin((FMOD::System *const)system, filename, handle, priority);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fae20 | Name: FMOD_System_UnloadPlugin
FMOD_RESULT_0 __fastcall FMOD_System_UnloadPlugin(FMOD_SYSTEM *system, unsigned int handle)
{
  if ( system )
    return FMOD::System::unloadPlugin((FMOD::System *const)system, handle);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fae40 | Name: FMOD_System_GetNumNestedPlugins
FMOD_RESULT_0 __fastcall FMOD_System_GetNumNestedPlugins(FMOD_SYSTEM *system, unsigned int handle, int *count)
{
  if ( system )
    return FMOD::System::getNumNestedPlugins((FMOD::System *const)system, handle, count);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fae60 | Name: FMOD_System_GetNestedPlugin
FMOD_RESULT_0 __fastcall FMOD_System_GetNestedPlugin(
        FMOD_SYSTEM *system,
        unsigned int handle,
        int index,
        unsigned int *nestedhandle)
{
  if ( system )
    return FMOD::System::getNestedPlugin((FMOD::System *const)system, handle, index, nestedhandle);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fae80 | Name: FMOD_System_GetNumPlugins
FMOD_RESULT_0 __fastcall FMOD_System_GetNumPlugins(FMOD_SYSTEM *system, FMOD_PLUGINTYPE_0 plugintype, int *numplugins)
{
  if ( system )
    return FMOD::System::getNumPlugins((FMOD::System *const)system, plugintype, numplugins);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21faea0 | Name: FMOD_System_GetPluginHandle
FMOD_RESULT_0 __fastcall FMOD_System_GetPluginHandle(
        FMOD_SYSTEM *system,
        FMOD_PLUGINTYPE_0 plugintype,
        int index,
        unsigned int *handle)
{
  if ( system )
    return FMOD::System::getPluginHandle((FMOD::System *const)system, plugintype, index, handle);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21faec0 | Name: FMOD_System_GetPluginInfo
FMOD_RESULT_0 __fastcall FMOD_System_GetPluginInfo(
        FMOD_SYSTEM *system,
        unsigned int handle,
        FMOD_PLUGINTYPE_0 *plugintype,
        char *name,
        int namelen,
        unsigned int *version)
{
  if ( system )
    return FMOD::System::getPluginInfo((FMOD::System *const)system, handle, plugintype, name, namelen, version);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21faee0 | Name: FMOD_System_SetOutputByPlugin
FMOD_RESULT_0 __fastcall FMOD_System_SetOutputByPlugin(FMOD_SYSTEM *system, unsigned int handle)
{
  if ( system )
    return FMOD::System::setOutputByPlugin((FMOD::System *const)system, handle);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21faf00 | Name: FMOD_System_GetOutputByPlugin
FMOD_RESULT_0 __fastcall FMOD_System_GetOutputByPlugin(FMOD_SYSTEM *system, unsigned int *handle)
{
  if ( system )
    return FMOD::System::getOutputByPlugin((FMOD::System *const)system, handle);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21faf20 | Name: FMOD_System_CreateDSPByPlugin
FMOD_RESULT_0 __fastcall FMOD_System_CreateDSPByPlugin(FMOD_SYSTEM *system, unsigned int handle, FMOD_DSP **dsp)
{
  if ( system )
    return FMOD::System::createDSPByPlugin((FMOD::System *const)system, handle, (FMOD::DSP **)dsp);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21faf40 | Name: FMOD_System_GetDSPInfoByPlugin
FMOD_RESULT_0 __fastcall FMOD_System_GetDSPInfoByPlugin(
        FMOD_SYSTEM *system,
        unsigned int handle,
        const FMOD_DSP_DESCRIPTION_0 **description)
{
  if ( system )
    return FMOD::System::getDSPInfoByPlugin((FMOD::System *const)system, handle, description);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21faf60 | Name: FMOD_System_RegisterCodec
FMOD_RESULT_0 __fastcall FMOD_System_RegisterCodec(
        FMOD_SYSTEM *system,
        FMOD_CODEC_DESCRIPTION *description,
        unsigned int *handle,
        unsigned int priority)
{
  if ( system )
    return FMOD::System::registerCodec((FMOD::System *const)system, description, handle, priority);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21faf80 | Name: FMOD_System_RegisterDSP
FMOD_RESULT_0 __fastcall FMOD_System_RegisterDSP(
        FMOD_SYSTEM *system,
        const FMOD_DSP_DESCRIPTION_0 *description,
        unsigned int *handle)
{
  if ( system )
    return FMOD::System::registerDSP((FMOD::System *const)system, description, handle);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fafa0 | Name: FMOD_System_RegisterOutput
FMOD_RESULT_0 __fastcall FMOD_System_RegisterOutput(
        FMOD_SYSTEM *system,
        const FMOD_OUTPUT_DESCRIPTION_4 *description,
        unsigned int *handle)
{
  if ( system )
    return FMOD::System::registerOutput((FMOD::System *const)system, description, handle);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fafc0 | Name: FMOD_System_Init
FMOD_RESULT_0 __fastcall FMOD_System_Init(
        FMOD_SYSTEM *system,
        int maxchannels,
        FMOD_INITFLAGS flags,
        void *extradriverdata)
{
  if ( system )
    return FMOD::System::init((FMOD::System *const)system, maxchannels, flags, extradriverdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fafe0 | Name: FMOD_System_Close
FMOD_RESULT_0 __fastcall FMOD_System_Close(FMOD_SYSTEM *system)
{
  if ( system )
    return FMOD::System::close((FMOD::System *const)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb000 | Name: FMOD_System_Update
FMOD_RESULT_0 __fastcall FMOD_System_Update(FMOD_SYSTEM *system)
{
  if ( system )
    return FMOD::System::update((FMOD::System *const)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb020 | Name: FMOD_System_SetSpeakerPosition
__int64 __fastcall FMOD_System_SetSpeakerPosition(
        FMOD::System *system,
        __int32 speaker,
        float x,
        float y,
        FMOD_BOOL active)
{
  if ( system )
    return FMOD::System::setSpeakerPosition(system, speaker, x, y, active != 0);
  else
    return 31;
}


// Address: 0x21fb040 | Name: FMOD_System_GetSpeakerPosition
FMOD_RESULT_0 __fastcall FMOD_System_GetSpeakerPosition(
        FMOD_SYSTEM *system,
        FMOD_SPEAKER_0 speaker,
        float *x,
        float *y,
        FMOD_BOOL *active)
{
  FMOD_RESULT_0 result; // eax
  bool active2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( system )
  {
    result = FMOD::System::getSpeakerPosition((FMOD::System *const)system, speaker, x, y, &active2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( active )
        *active = active2;
    }
  }
  return result;
}


// Address: 0x21fb080 | Name: FMOD_System_SetStreamBufferSize
FMOD_RESULT_0 __fastcall FMOD_System_SetStreamBufferSize(
        FMOD_SYSTEM *system,
        unsigned int filebuffersize,
        FMOD_TIMEUNIT filebuffersizetype)
{
  if ( system )
    return FMOD::System::setStreamBufferSize((FMOD::System *const)system, filebuffersize, filebuffersizetype);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb0a0 | Name: FMOD_System_GetStreamBufferSize
FMOD_RESULT_0 __fastcall FMOD_System_GetStreamBufferSize(
        FMOD_SYSTEM *system,
        unsigned int *filebuffersize,
        FMOD_TIMEUNIT *filebuffersizetype)
{
  if ( system )
    return FMOD::System::getStreamBufferSize((FMOD::System *const)system, filebuffersize, filebuffersizetype);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb0c0 | Name: FMOD_System_Set3DSettings
__int64 __fastcall FMOD_System_Set3DSettings(
        FMOD::System *const system,
        double a2,
        float dopplerscale,
        float distancefactor,
        float rolloffscale)
{
  if ( system )
    return FMOD::System::set3DSettings(system, a2, dopplerscale, distancefactor, rolloffscale);
  else
    return 31;
}


// Address: 0x21fb0e0 | Name: FMOD_System_Get3DSettings
FMOD_RESULT_0 __fastcall FMOD_System_Get3DSettings(
        FMOD_SYSTEM *system,
        float *dopplerscale,
        float *distancefactor,
        float *rolloffscale)
{
  if ( system )
    return FMOD::System::get3DSettings((FMOD::System *const)system, dopplerscale, distancefactor, rolloffscale);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb100 | Name: FMOD_System_Set3DNumListeners
FMOD_RESULT_0 __fastcall FMOD_System_Set3DNumListeners(FMOD_SYSTEM *system, int numlisteners)
{
  if ( system )
    return FMOD::System::set3DNumListeners((FMOD::System *const)system, numlisteners);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb120 | Name: FMOD_System_Get3DNumListeners
FMOD_RESULT_0 __fastcall FMOD_System_Get3DNumListeners(FMOD_SYSTEM *system, int *numlisteners)
{
  if ( system )
    return FMOD::System::get3DNumListeners((FMOD::System *const)system, numlisteners);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb140 | Name: FMOD_System_Set3DListenerAttributes
FMOD_RESULT_0 __fastcall FMOD_System_Set3DListenerAttributes(
        FMOD_SYSTEM *system,
        int listener,
        const FMOD_VECTOR *pos,
        const FMOD_VECTOR *vel,
        const FMOD_VECTOR *forward,
        const FMOD_VECTOR *up)
{
  if ( system )
    return FMOD::System::set3DListenerAttributes((FMOD::System *const)system, listener, pos, vel, forward, up);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb160 | Name: FMOD_System_Get3DListenerAttributes
FMOD_RESULT_0 __fastcall FMOD_System_Get3DListenerAttributes(
        FMOD_SYSTEM *system,
        int listener,
        FMOD_VECTOR *pos,
        FMOD_VECTOR *vel,
        FMOD_VECTOR *forward,
        FMOD_VECTOR *up)
{
  if ( system )
    return FMOD::System::get3DListenerAttributes((FMOD::System *const)system, listener, pos, vel, forward, up);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb180 | Name: FMOD_System_Set3DRolloffCallback
FMOD_RESULT_0 __fastcall FMOD_System_Set3DRolloffCallback(FMOD_SYSTEM *system, FMOD_3D_ROLLOFF_CALLBACK callback)
{
  if ( system )
    return FMOD::System::set3DRolloffCallback((FMOD::System *const)system, callback);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb1a0 | Name: FMOD_System_MixerSuspend
FMOD_RESULT_0 __fastcall FMOD_System_MixerSuspend(FMOD_SYSTEM *system)
{
  if ( system )
    return FMOD::System::mixerSuspend((FMOD::System *const)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb1c0 | Name: FMOD_System_MixerResume
FMOD_RESULT_0 __fastcall FMOD_System_MixerResume(FMOD_SYSTEM *system)
{
  if ( system )
    return FMOD::System::mixerResume((FMOD::System *const)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb1e0 | Name: FMOD_System_GetDefaultMixMatrix
FMOD_RESULT_0 __fastcall FMOD_System_GetDefaultMixMatrix(
        FMOD_SYSTEM *system,
        FMOD_SPEAKERMODE_0 sourcespeakermode,
        FMOD_SPEAKERMODE_0 targetspeakermode,
        float *matrix,
        int matrixhop)
{
  if ( system )
    return FMOD::System::getDefaultMixMatrix(
             (FMOD::System *const)system,
             sourcespeakermode,
             targetspeakermode,
             matrix,
             matrixhop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb200 | Name: FMOD_System_GetSpeakerModeChannels
FMOD_RESULT_0 __fastcall FMOD_System_GetSpeakerModeChannels(
        FMOD_SYSTEM *system,
        FMOD_SPEAKERMODE_0 mode,
        int *channels)
{
  if ( system )
    return FMOD::System::getSpeakerModeChannels((FMOD::System *const)system, mode, channels);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb220 | Name: FMOD_System_GetVersion
FMOD_RESULT_0 __fastcall FMOD_System_GetVersion(FMOD_SYSTEM *system, unsigned int *version)
{
  if ( system )
    return FMOD::System::getVersion((FMOD::System *const)system, version);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb240 | Name: FMOD_System_GetOutputHandle
FMOD_RESULT_0 __fastcall FMOD_System_GetOutputHandle(FMOD_SYSTEM *system, void **handle)
{
  if ( system )
    return FMOD::System::getOutputHandle((FMOD::System *const)system, handle);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb260 | Name: FMOD_System_GetChannelsPlaying
FMOD_RESULT_0 __fastcall FMOD_System_GetChannelsPlaying(FMOD_SYSTEM *system, int *channels, int *realchannels)
{
  if ( system )
    return FMOD::System::getChannelsPlaying((FMOD::System *const)system, channels, realchannels);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb280 | Name: FMOD_System_GetCPUUsage
FMOD_RESULT_0 __fastcall FMOD_System_GetCPUUsage(
        FMOD_SYSTEM *system,
        float *dsp,
        float *stream,
        float *geometry,
        float *update,
        float *total)
{
  if ( system )
    return FMOD::System::getCPUUsage((FMOD::System *const)system, dsp, stream, geometry, update, total);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb2a0 | Name: FMOD_System_GetFileUsage
FMOD_RESULT_0 __fastcall FMOD_System_GetFileUsage(
        FMOD_SYSTEM *system,
        __int64 *sampleBytesRead,
        __int64 *streamBytesRead,
        __int64 *otherBytesRead)
{
  if ( system )
    return FMOD::System::getFileUsage((FMOD::System *const)system, sampleBytesRead, streamBytesRead, otherBytesRead);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb2c0 | Name: FMOD_System_CreateSound
FMOD_RESULT_0 __fastcall FMOD_System_CreateSound(
        FMOD_SYSTEM *system,
        const char *name_or_data,
        FMOD_MODE mode,
        FMOD_CREATESOUNDEXINFO *exinfo,
        FMOD_SOUND **sound)
{
  if ( system )
    return FMOD::System::createSound(
             (FMOD::System *const)system,
             name_or_data,
             mode,
             (FMOD_CREATESOUNDEXINFO_1 *)exinfo,
             (FMOD::Sound **)sound);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb2e0 | Name: FMOD_System_CreateStream
FMOD_RESULT_0 __fastcall FMOD_System_CreateStream(
        FMOD_SYSTEM *system,
        const char *name_or_data,
        FMOD_MODE mode,
        FMOD_CREATESOUNDEXINFO *exinfo,
        FMOD_SOUND **sound)
{
  if ( system )
    return FMOD::System::createStream(
             (FMOD::System *const)system,
             name_or_data,
             mode,
             (FMOD_CREATESOUNDEXINFO_1 *)exinfo,
             (FMOD::Sound **)sound);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb300 | Name: FMOD_System_CreateDSP
FMOD_RESULT_0 __fastcall FMOD_System_CreateDSP(
        FMOD_SYSTEM *system,
        const FMOD_DSP_DESCRIPTION_0 *description,
        FMOD_DSP **dsp)
{
  if ( system )
    return FMOD::System::createDSP((FMOD::System *const)system, description, (FMOD::DSP **)dsp);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb320 | Name: FMOD_System_CreateDSPByType
__int64 __fastcall FMOD_System_CreateDSPByType(FMOD::System *this, __int32 a2, FMOD::DSP **a3)
{
  if ( this )
    return FMOD::System::createDSPByType(this, a2, a3);
  else
    return 31;
}


// Address: 0x21fb340 | Name: FMOD_System_CreateChannelGroup
FMOD_RESULT_0 __fastcall FMOD_System_CreateChannelGroup(
        FMOD_SYSTEM *system,
        const char *name,
        FMOD_CHANNELGROUP **channelgroup)
{
  if ( system )
    return FMOD::System::createChannelGroup((FMOD::System *const)system, name, (FMOD::ChannelGroup **)channelgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb360 | Name: FMOD_System_CreateSoundGroup
FMOD_RESULT_0 __fastcall FMOD_System_CreateSoundGroup(
        FMOD_SYSTEM *system,
        const char *name,
        FMOD_SOUNDGROUP **soundgroup)
{
  if ( system )
    return FMOD::System::createSoundGroup((FMOD::System *const)system, name, (FMOD::SoundGroup **)soundgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb380 | Name: FMOD_System_CreateReverb3D
FMOD_RESULT_0 __fastcall FMOD_System_CreateReverb3D(FMOD_SYSTEM *system, FMOD_REVERB3D **reverb)
{
  if ( system )
    return FMOD::System::createReverb3D((FMOD::System *const)system, (FMOD::Reverb3D **)reverb);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb3a0 | Name: FMOD_System_PlaySound
FMOD_RESULT_0 __fastcall FMOD_System_PlaySound(
        FMOD_SYSTEM *system,
        FMOD_SOUND *sound,
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_BOOL paused,
        FMOD_CHANNEL **channel)
{
  if ( system )
    return FMOD::System::playSound(
             (FMOD::System *const)system,
             (FMOD::Sound *)sound,
             (FMOD::ChannelGroup *)channelgroup,
             paused != 0,
             (FMOD::Channel **)channel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb3c0 | Name: FMOD_System_PlayDSP
FMOD_RESULT_0 __fastcall FMOD_System_PlayDSP(
        FMOD_SYSTEM *system,
        FMOD_DSP *dsp,
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_BOOL paused,
        FMOD_CHANNEL **channel)
{
  if ( system )
    return FMOD::System::playDSP(
             (FMOD::System *const)system,
             (FMOD::DSP *)dsp,
             (FMOD::ChannelGroup *)channelgroup,
             paused != 0,
             (FMOD::Channel **)channel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb3e0 | Name: FMOD_System_GetChannel
FMOD_RESULT_0 __fastcall FMOD_System_GetChannel(FMOD_SYSTEM *system, int channelid, FMOD_CHANNEL **channel)
{
  if ( system )
    return FMOD::System::getChannel((FMOD::System *const)system, channelid, (FMOD::Channel **)channel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb400 | Name: FMOD_System_GetMasterChannelGroup
FMOD_RESULT_0 __fastcall FMOD_System_GetMasterChannelGroup(FMOD_SYSTEM *system, FMOD_CHANNELGROUP **channelgroup)
{
  if ( system )
    return FMOD::System::getMasterChannelGroup((FMOD::System *const)system, (FMOD::ChannelGroup **)channelgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb420 | Name: FMOD_System_GetMasterSoundGroup
FMOD_RESULT_0 __fastcall FMOD_System_GetMasterSoundGroup(FMOD_SYSTEM *system, FMOD_SOUNDGROUP **soundgroup)
{
  if ( system )
    return FMOD::System::getMasterSoundGroup((FMOD::System *const)system, (FMOD::SoundGroup **)soundgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb440 | Name: FMOD_System_AttachChannelGroupToPort
FMOD_RESULT_0 __fastcall FMOD_System_AttachChannelGroupToPort(
        FMOD_SYSTEM *system,
        FMOD_PORT_TYPE portType,
        FMOD_PORT_INDEX portIndex,
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_BOOL passThru)
{
  if ( system )
    return FMOD::System::attachChannelGroupToPort(
             (FMOD::System *const)system,
             portType,
             portIndex,
             (FMOD::ChannelGroup *)channelgroup,
             passThru != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb460 | Name: FMOD_System_DetachChannelGroupFromPort
FMOD_RESULT_0 __fastcall FMOD_System_DetachChannelGroupFromPort(FMOD_SYSTEM *system, FMOD_CHANNELGROUP *channelgroup)
{
  if ( system )
    return FMOD::System::detachChannelGroupFromPort((FMOD::System *const)system, (FMOD::ChannelGroup *)channelgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb480 | Name: FMOD_System_SetReverbProperties
FMOD_RESULT_0 __fastcall FMOD_System_SetReverbProperties(
        FMOD_SYSTEM *system,
        int instance,
        const FMOD_REVERB_PROPERTIES *prop)
{
  if ( system )
    return FMOD::System::setReverbProperties((FMOD::System *const)system, instance, prop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb4a0 | Name: FMOD_System_GetReverbProperties
FMOD_RESULT_0 __fastcall FMOD_System_GetReverbProperties(
        FMOD_SYSTEM *system,
        int instance,
        FMOD_REVERB_PROPERTIES *prop)
{
  if ( system )
    return FMOD::System::getReverbProperties((FMOD::System *const)system, instance, prop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb4c0 | Name: FMOD_System_LockDSP
FMOD_RESULT_0 __fastcall FMOD_System_LockDSP(FMOD_SYSTEM *system)
{
  if ( system )
    return FMOD::System::lockDSP((FMOD::System *const)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb4e0 | Name: FMOD_System_UnlockDSP
FMOD_RESULT_0 __fastcall FMOD_System_UnlockDSP(FMOD_SYSTEM *system)
{
  if ( system )
    return FMOD::System::unlockDSP((FMOD::System *const)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb500 | Name: FMOD_System_GetRecordNumDrivers
FMOD_RESULT_0 __fastcall FMOD_System_GetRecordNumDrivers(FMOD_SYSTEM *system, int *numdrivers, int *numconnected)
{
  if ( system )
    return FMOD::System::getRecordNumDrivers((FMOD::System *const)system, numdrivers, numconnected);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb520 | Name: FMOD_System_GetRecordDriverInfo
FMOD_RESULT_0 __fastcall FMOD_System_GetRecordDriverInfo(
        FMOD_SYSTEM *system,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels,
        FMOD_DRIVER_STATE *state)
{
  if ( system )
    return FMOD::System::getRecordDriverInfo(
             (FMOD::System *const)system,
             id,
             name,
             namelen,
             guid,
             systemrate,
             speakermode,
             speakermodechannels,
             state);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb540 | Name: FMOD_System_GetRecordPosition
FMOD_RESULT_0 __fastcall FMOD_System_GetRecordPosition(FMOD_SYSTEM *system, int id, unsigned int *position)
{
  if ( system )
    return FMOD::System::getRecordPosition((FMOD::System *const)system, id, position);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb560 | Name: FMOD_System_RecordStart
FMOD_RESULT_0 __fastcall FMOD_System_RecordStart(FMOD_SYSTEM *system, int id, FMOD_SOUND *sound, FMOD_BOOL loop)
{
  if ( system )
    return FMOD::System::recordStart((FMOD::System *const)system, id, (FMOD::Sound *)sound, loop != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb580 | Name: FMOD_System_RecordStop
FMOD_RESULT_0 __fastcall FMOD_System_RecordStop(FMOD_SYSTEM *system, int id)
{
  if ( system )
    return FMOD::System::recordStop((FMOD::System *const)system, id);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb5a0 | Name: FMOD_System_IsRecording
FMOD_RESULT_0 __fastcall FMOD_System_IsRecording(FMOD_SYSTEM *system, int id, FMOD_BOOL *recording)
{
  FMOD_RESULT_0 result; // eax
  bool recording2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( system )
  {
    result = FMOD::System::isRecording((FMOD::System *const)system, id, &recording2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( recording )
        *recording = recording2;
    }
  }
  return result;
}


// Address: 0x21fb5e0 | Name: FMOD_System_CreateGeometry
FMOD_RESULT_0 __fastcall FMOD_System_CreateGeometry(
        FMOD_SYSTEM *system,
        int maxpolygons,
        int maxvertices,
        FMOD_GEOMETRY **geometry)
{
  if ( system )
    return FMOD::System::createGeometry(
             (FMOD::System *const)system,
             maxpolygons,
             maxvertices,
             (FMOD::Geometry **)geometry);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb600 | Name: FMOD_System_SetGeometrySettings
__int64 __fastcall FMOD_System_SetGeometrySettings(FMOD::System *const system, double a2, float maxworldsize)
{
  if ( system )
    return FMOD::System::setGeometrySettings(system, a2, maxworldsize);
  else
    return 31;
}


// Address: 0x21fb620 | Name: FMOD_System_GetGeometrySettings
FMOD_RESULT_0 __fastcall FMOD_System_GetGeometrySettings(FMOD_SYSTEM *system, float *maxworldsize)
{
  if ( system )
    return FMOD::System::getGeometrySettings((FMOD::System *const)system, maxworldsize);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb640 | Name: FMOD_System_LoadGeometry
FMOD_RESULT_0 __fastcall FMOD_System_LoadGeometry(
        FMOD_SYSTEM *system,
        const void *data,
        int datasize,
        FMOD_GEOMETRY **geometry)
{
  if ( system )
    return FMOD::System::loadGeometry((FMOD::System *const)system, data, datasize, (FMOD::Geometry **)geometry);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb660 | Name: FMOD_System_GetGeometryOcclusion
FMOD_RESULT_0 __fastcall FMOD_System_GetGeometryOcclusion(
        FMOD_SYSTEM *system,
        const FMOD_VECTOR *listener,
        const FMOD_VECTOR *source,
        float *direct,
        float *reverb)
{
  if ( system )
    return FMOD::System::getGeometryOcclusion((FMOD::System *const)system, listener, source, direct, reverb);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb680 | Name: FMOD_System_SetNetworkProxy
FMOD_RESULT_0 __fastcall FMOD_System_SetNetworkProxy(FMOD_SYSTEM *system, const char *proxy)
{
  if ( system )
    return FMOD::System::setNetworkProxy((FMOD::System *const)system, proxy);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb6a0 | Name: FMOD_System_GetNetworkProxy
FMOD_RESULT_0 __fastcall FMOD_System_GetNetworkProxy(FMOD_SYSTEM *system, char *proxy, int proxylen)
{
  if ( system )
    return FMOD::System::getNetworkProxy((FMOD::System *const)system, proxy, proxylen);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb6c0 | Name: FMOD_System_SetNetworkTimeout
FMOD_RESULT_0 __fastcall FMOD_System_SetNetworkTimeout(FMOD_SYSTEM *system, int timeout)
{
  if ( system )
    return FMOD::System::setNetworkTimeout((FMOD::System *const)system, timeout);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb6e0 | Name: FMOD_System_GetNetworkTimeout
FMOD_RESULT_0 __fastcall FMOD_System_GetNetworkTimeout(FMOD_SYSTEM *system, int *timeout)
{
  if ( system )
    return FMOD::System::getNetworkTimeout((FMOD::System *const)system, timeout);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb700 | Name: FMOD_System_SetUserData
FMOD_RESULT_0 __fastcall FMOD_System_SetUserData(FMOD_SYSTEM *system, void *userdata)
{
  if ( system )
    return FMOD::System::setUserData((FMOD::System *const)system, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb720 | Name: FMOD_System_GetUserData
FMOD_RESULT_0 __fastcall FMOD_System_GetUserData(FMOD_SYSTEM *system, void **userdata)
{
  if ( system )
    return FMOD::System::getUserData((FMOD::System *const)system, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb740 | Name: FMOD_Sound_Release
FMOD_RESULT_0 __fastcall FMOD_Sound_Release(FMOD_SOUND *sound)
{
  if ( sound )
    return FMOD::Sound::release((FMOD::Sound *const)sound);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb760 | Name: FMOD_Sound_GetSystemObject
FMOD_RESULT_0 __fastcall FMOD_Sound_GetSystemObject(FMOD_SOUND *sound, FMOD_SYSTEM **system)
{
  if ( sound )
    return FMOD::Sound::getSystemObject((FMOD::Sound *const)sound, (FMOD::System **)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb780 | Name: FMOD_Sound_Lock
FMOD_RESULT_0 __fastcall FMOD_Sound_Lock(
        FMOD_SOUND *sound,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  if ( sound )
    return FMOD::Sound::lock((FMOD::Sound *const)sound, offset, length, ptr1, ptr2, len1, len2);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb7a0 | Name: FMOD_Sound_Unlock
FMOD_RESULT_0 __fastcall FMOD_Sound_Unlock(
        FMOD_SOUND *sound,
        void *ptr1,
        void *ptr2,
        unsigned int len1,
        unsigned int len2)
{
  if ( sound )
    return FMOD::Sound::unlock((FMOD::Sound *const)sound, ptr1, ptr2, len1, len2);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb7c0 | Name: FMOD_Sound_SetDefaults
FMOD_RESULT_0 __fastcall FMOD_Sound_SetDefaults(FMOD::Sound *sound, double a2, float frequency, int priority)
{
  if ( sound )
    return FMOD::Sound::setDefaults(sound, frequency, priority);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb7e0 | Name: FMOD_Sound_GetDefaults
FMOD_RESULT_0 __fastcall FMOD_Sound_GetDefaults(FMOD_SOUND *sound, float *frequency, int *priority)
{
  if ( sound )
    return FMOD::Sound::getDefaults((FMOD::Sound *const)sound, frequency, priority);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb800 | Name: FMOD_Sound_Set3DMinMaxDistance
FMOD_RESULT_0 __fastcall FMOD_Sound_Set3DMinMaxDistance(FMOD::Sound *sound, double a2, float min, float max)
{
  if ( sound )
    return FMOD::Sound::set3DMinMaxDistance(sound, min, max);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb820 | Name: FMOD_Sound_Get3DMinMaxDistance
FMOD_RESULT_0 __fastcall FMOD_Sound_Get3DMinMaxDistance(FMOD_SOUND *sound, float *min, float *max)
{
  if ( sound )
    return FMOD::Sound::get3DMinMaxDistance((FMOD::Sound *const)sound, min, max);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb840 | Name: FMOD_Sound_Set3DConeSettings
FMOD_RESULT_0 __fastcall FMOD_Sound_Set3DConeSettings(
        FMOD::Sound *sound,
        double a2,
        float insideconeangle,
        float outsideconeangle,
        float outsidevolume)
{
  if ( sound )
    return FMOD::Sound::set3DConeSettings(sound, insideconeangle, outsideconeangle, outsidevolume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb860 | Name: FMOD_Sound_Get3DConeSettings
FMOD_RESULT_0 __fastcall FMOD_Sound_Get3DConeSettings(
        FMOD_SOUND *sound,
        float *insideconeangle,
        float *outsideconeangle,
        float *outsidevolume)
{
  if ( sound )
    return FMOD::Sound::get3DConeSettings((FMOD::Sound *const)sound, insideconeangle, outsideconeangle, outsidevolume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb880 | Name: FMOD_Sound_Set3DCustomRolloff
FMOD_RESULT_0 __fastcall FMOD_Sound_Set3DCustomRolloff(FMOD_SOUND *sound, FMOD_VECTOR *points, int numpoints)
{
  if ( sound )
    return FMOD::Sound::set3DCustomRolloff((FMOD::Sound *const)sound, points, numpoints);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb8a0 | Name: FMOD_Sound_Get3DCustomRolloff
FMOD_RESULT_0 __fastcall FMOD_Sound_Get3DCustomRolloff(FMOD_SOUND *sound, FMOD_VECTOR **points, int *numpoints)
{
  if ( sound )
    return FMOD::Sound::get3DCustomRolloff((FMOD::Sound *const)sound, points, numpoints);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb8c0 | Name: FMOD_Sound_GetSubSound
FMOD_RESULT_0 __fastcall FMOD_Sound_GetSubSound(FMOD_SOUND *sound, int index, FMOD_SOUND **subsound)
{
  if ( sound )
    return FMOD::Sound::getSubSound((FMOD::Sound *const)sound, index, (FMOD::Sound **)subsound);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb8e0 | Name: FMOD_Sound_GetSubSoundParent
FMOD_RESULT_0 __fastcall FMOD_Sound_GetSubSoundParent(FMOD_SOUND *sound, FMOD_SOUND **parentsound)
{
  if ( sound )
    return FMOD::Sound::getSubSoundParent((FMOD::Sound *const)sound, (FMOD::Sound **)parentsound);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb900 | Name: FMOD_Sound_GetName
FMOD_RESULT_0 __fastcall FMOD_Sound_GetName(FMOD_SOUND *sound, char *name, int namelen)
{
  if ( sound )
    return FMOD::Sound::getName((FMOD::Sound *const)sound, name, namelen);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb920 | Name: FMOD_Sound_GetLength
FMOD_RESULT_0 __fastcall FMOD_Sound_GetLength(FMOD_SOUND *sound, unsigned int *length, FMOD_TIMEUNIT lengthtype)
{
  if ( sound )
    return FMOD::Sound::getLength((FMOD::Sound *const)sound, length, lengthtype);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb940 | Name: FMOD_Sound_GetFormat
FMOD_RESULT_0 __fastcall FMOD_Sound_GetFormat(
        FMOD_SOUND *sound,
        FMOD_SOUND_TYPE_0 *type,
        FMOD_SOUND_FORMAT_0 *format,
        int *channels,
        int *bits)
{
  if ( sound )
    return FMOD::Sound::getFormat((FMOD::Sound *const)sound, type, format, channels, bits);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb960 | Name: FMOD_Sound_GetNumSubSounds
FMOD_RESULT_0 __fastcall FMOD_Sound_GetNumSubSounds(FMOD_SOUND *sound, int *numsubsounds)
{
  if ( sound )
    return FMOD::Sound::getNumSubSounds((FMOD::Sound *const)sound, numsubsounds);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb980 | Name: FMOD_Sound_GetNumTags
FMOD_RESULT_0 __fastcall FMOD_Sound_GetNumTags(FMOD_SOUND *sound, int *numtags, int *numtagsupdated)
{
  if ( sound )
    return FMOD::Sound::getNumTags((FMOD::Sound *const)sound, numtags, numtagsupdated);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb9a0 | Name: FMOD_Sound_GetTag
FMOD_RESULT_0 __fastcall FMOD_Sound_GetTag(FMOD_SOUND *sound, const char *name, int index, FMOD_TAG *tag)
{
  if ( sound )
    return FMOD::Sound::getTag((FMOD::Sound *const)sound, name, index, tag);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fb9c0 | Name: FMOD_Sound_GetOpenState
FMOD_RESULT_0 __fastcall FMOD_Sound_GetOpenState(
        FMOD_SOUND *sound,
        FMOD_OPENSTATE_0 *openstate,
        unsigned int *percentbuffered,
        FMOD_BOOL *starving,
        FMOD_BOOL *diskbusy)
{
  FMOD_RESULT_0 result; // eax
  bool starving2; // [rsp+0h] [rbp-1Ah] BYREF
  bool diskbusy2; // [rsp+1h] [rbp-19h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( sound )
  {
    result = FMOD::Sound::getOpenState((FMOD::Sound *const)sound, openstate, percentbuffered, &starving2, &diskbusy2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( starving )
        *starving = starving2;
      if ( diskbusy )
        *diskbusy = diskbusy2;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21fba20 | Name: FMOD_Sound_ReadData
FMOD_RESULT_0 __fastcall FMOD_Sound_ReadData(FMOD_SOUND *sound, void *buffer, unsigned int length, unsigned int *read)
{
  if ( sound )
    return FMOD::Sound::readData((FMOD::Sound *const)sound, buffer, length, read);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fba40 | Name: FMOD_Sound_SeekData
FMOD_RESULT_0 __fastcall FMOD_Sound_SeekData(FMOD_SOUND *sound, unsigned int pcm)
{
  if ( sound )
    return FMOD::Sound::seekData((FMOD::Sound *const)sound, pcm);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fba60 | Name: FMOD_Sound_SetSoundGroup
FMOD_RESULT_0 __fastcall FMOD_Sound_SetSoundGroup(FMOD_SOUND *sound, FMOD_SOUNDGROUP *soundgroup)
{
  if ( sound )
    return FMOD::Sound::setSoundGroup((FMOD::Sound *const)sound, (FMOD::SoundGroup *)soundgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fba80 | Name: FMOD_Sound_GetSoundGroup
FMOD_RESULT_0 __fastcall FMOD_Sound_GetSoundGroup(FMOD_SOUND *sound, FMOD_SOUNDGROUP **soundgroup)
{
  if ( sound )
    return FMOD::Sound::getSoundGroup((FMOD::Sound *const)sound, (FMOD::SoundGroup **)soundgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbaa0 | Name: FMOD_Sound_GetNumSyncPoints
FMOD_RESULT_0 __fastcall FMOD_Sound_GetNumSyncPoints(FMOD_SOUND *sound, int *numsyncpoints)
{
  if ( sound )
    return FMOD::Sound::getNumSyncPoints((FMOD::Sound *const)sound, numsyncpoints);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbac0 | Name: FMOD_Sound_GetSyncPoint
FMOD_RESULT_0 __fastcall FMOD_Sound_GetSyncPoint(FMOD_SOUND *sound, int index, FMOD_SYNCPOINT **point)
{
  if ( sound )
    return FMOD::Sound::getSyncPoint((FMOD::Sound *const)sound, index, point);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbae0 | Name: FMOD_Sound_GetSyncPointInfo
FMOD_RESULT_0 __fastcall FMOD_Sound_GetSyncPointInfo(
        FMOD_SOUND *sound,
        FMOD_SYNCPOINT *point,
        char *name,
        int namelen,
        unsigned int *offset,
        FMOD_TIMEUNIT offsettype)
{
  if ( sound )
    return FMOD::Sound::getSyncPointInfo((FMOD::Sound *const)sound, point, name, namelen, offset, offsettype);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbb00 | Name: FMOD_Sound_AddSyncPoint
FMOD_RESULT_0 __fastcall FMOD_Sound_AddSyncPoint(
        FMOD_SOUND *sound,
        unsigned int offset,
        FMOD_TIMEUNIT offsettype,
        const char *name,
        FMOD_SYNCPOINT **point)
{
  if ( sound )
    return FMOD::Sound::addSyncPoint((FMOD::Sound *const)sound, offset, offsettype, name, point);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbb20 | Name: FMOD_Sound_DeleteSyncPoint
FMOD_RESULT_0 __fastcall FMOD_Sound_DeleteSyncPoint(FMOD_SOUND *sound, FMOD_SYNCPOINT *point)
{
  if ( sound )
    return FMOD::Sound::deleteSyncPoint((FMOD::Sound *const)sound, point);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbb40 | Name: FMOD_Sound_SetMode
FMOD_RESULT_0 __fastcall FMOD_Sound_SetMode(FMOD_SOUND *sound, FMOD_MODE mode)
{
  if ( sound )
    return FMOD::Sound::setMode((FMOD::Sound *const)sound, mode);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbb60 | Name: FMOD_Sound_GetMode
FMOD_RESULT_0 __fastcall FMOD_Sound_GetMode(FMOD_SOUND *sound, FMOD_MODE *mode)
{
  if ( sound )
    return FMOD::Sound::getMode((FMOD::Sound *const)sound, mode);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbb80 | Name: FMOD_Sound_SetLoopCount
FMOD_RESULT_0 __fastcall FMOD_Sound_SetLoopCount(FMOD_SOUND *sound, int loopcount)
{
  if ( sound )
    return FMOD::Sound::setLoopCount((FMOD::Sound *const)sound, loopcount);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbba0 | Name: FMOD_Sound_GetLoopCount
FMOD_RESULT_0 __fastcall FMOD_Sound_GetLoopCount(FMOD_SOUND *sound, int *loopcount)
{
  if ( sound )
    return FMOD::Sound::getLoopCount((FMOD::Sound *const)sound, loopcount);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbbc0 | Name: FMOD_Sound_SetLoopPoints
FMOD_RESULT_0 __fastcall FMOD_Sound_SetLoopPoints(
        FMOD_SOUND *sound,
        unsigned int loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int loopend,
        FMOD_TIMEUNIT loopendtype)
{
  if ( sound )
    return FMOD::Sound::setLoopPoints((FMOD::Sound *const)sound, loopstart, loopstarttype, loopend, loopendtype);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbbe0 | Name: FMOD_Sound_GetLoopPoints
FMOD_RESULT_0 __fastcall FMOD_Sound_GetLoopPoints(
        FMOD_SOUND *sound,
        unsigned int *loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int *loopend,
        FMOD_TIMEUNIT loopendtype)
{
  if ( sound )
    return FMOD::Sound::getLoopPoints((FMOD::Sound *const)sound, loopstart, loopstarttype, loopend, loopendtype);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbc00 | Name: FMOD_Sound_GetMusicNumChannels
FMOD_RESULT_0 __fastcall FMOD_Sound_GetMusicNumChannels(FMOD_SOUND *sound, int *numchannels)
{
  if ( sound )
    return FMOD::Sound::getMusicNumChannels((FMOD::Sound *const)sound, numchannels);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbc20 | Name: FMOD_Sound_SetMusicChannelVolume
FMOD_RESULT_0 __fastcall FMOD_Sound_SetMusicChannelVolume(FMOD::Sound *sound, int channel, double a3, float volume)
{
  if ( sound )
    return FMOD::Sound::setMusicChannelVolume(sound, channel, volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbc40 | Name: FMOD_Sound_GetMusicChannelVolume
FMOD_RESULT_0 __fastcall FMOD_Sound_GetMusicChannelVolume(FMOD_SOUND *sound, int channel, float *volume)
{
  if ( sound )
    return FMOD::Sound::getMusicChannelVolume((FMOD::Sound *const)sound, channel, volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbc60 | Name: FMOD_Sound_SetMusicSpeed
FMOD_RESULT_0 __fastcall FMOD_Sound_SetMusicSpeed(FMOD::Sound *sound, double a2, float speed)
{
  if ( sound )
    return FMOD::Sound::setMusicSpeed(sound, speed);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbc80 | Name: FMOD_Sound_GetMusicSpeed
FMOD_RESULT_0 __fastcall FMOD_Sound_GetMusicSpeed(FMOD_SOUND *sound, float *speed)
{
  if ( sound )
    return FMOD::Sound::getMusicSpeed((FMOD::Sound *const)sound, speed);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbca0 | Name: FMOD_Sound_SetUserData
FMOD_RESULT_0 __fastcall FMOD_Sound_SetUserData(FMOD_SOUND *sound, void *userdata)
{
  if ( sound )
    return FMOD::Sound::setUserData((FMOD::Sound *const)sound, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbcc0 | Name: FMOD_Sound_GetUserData
FMOD_RESULT_0 __fastcall FMOD_Sound_GetUserData(FMOD_SOUND *sound, void **userdata)
{
  if ( sound )
    return FMOD::Sound::getUserData((FMOD::Sound *const)sound, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbce0 | Name: FMOD_Channel_GetSystemObject
FMOD_RESULT_0 __fastcall FMOD_Channel_GetSystemObject(FMOD_CHANNEL *channel, FMOD_SYSTEM **system)
{
  if ( channel )
    return FMOD::ChannelControl::getSystemObject((FMOD::ChannelControl *const)channel, (FMOD::System **)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbd00 | Name: FMOD_Channel_Stop
FMOD_RESULT_0 __fastcall FMOD_Channel_Stop(FMOD_CHANNEL *channel)
{
  if ( channel )
    return FMOD::ChannelControl::stop((FMOD::ChannelControl *const)channel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbd20 | Name: FMOD_Channel_SetPaused
FMOD_RESULT_0 __fastcall FMOD_Channel_SetPaused(FMOD_CHANNEL *channel, FMOD_BOOL paused)
{
  if ( channel )
    return FMOD::ChannelControl::setPaused((FMOD::ChannelControl *const)channel, paused != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbd40 | Name: FMOD_Channel_GetPaused
FMOD_RESULT_0 __fastcall FMOD_Channel_GetPaused(FMOD_CHANNEL *channel, FMOD_BOOL *paused)
{
  FMOD_RESULT_0 result; // eax
  bool paused2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channel )
  {
    result = FMOD::ChannelControl::getPaused((FMOD::ChannelControl *const)channel, &paused2);
    if ( paused )
      *paused = paused2;
  }
  return result;
}


// Address: 0x21fbd70 | Name: FMOD_Channel_SetVolume
__int64 __fastcall FMOD_Channel_SetVolume(FMOD::ChannelControl *const channel, float a2, float volume)
{
  if ( channel )
    return FMOD::ChannelControl::setVolume(channel, a2, volume);
  else
    return 31;
}


// Address: 0x21fbd90 | Name: FMOD_Channel_GetVolume
FMOD_RESULT_0 __fastcall FMOD_Channel_GetVolume(FMOD_CHANNEL *channel, float *volume)
{
  if ( channel )
    return FMOD::ChannelControl::getVolume((FMOD::ChannelControl *const)channel, volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbdb0 | Name: FMOD_Channel_SetVolumeRamp
FMOD_RESULT_0 __fastcall FMOD_Channel_SetVolumeRamp(FMOD_CHANNEL *channel, FMOD_BOOL ramp)
{
  if ( channel )
    return FMOD::ChannelControl::setVolumeRamp((FMOD::ChannelControl *const)channel, ramp != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbdd0 | Name: FMOD_Channel_GetVolumeRamp
FMOD_RESULT_0 __fastcall FMOD_Channel_GetVolumeRamp(FMOD_CHANNEL *channel, FMOD_BOOL *ramp)
{
  FMOD_RESULT_0 result; // eax
  bool ramp2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channel )
  {
    result = FMOD::ChannelControl::getVolumeRamp((FMOD::ChannelControl *const)channel, &ramp2);
    if ( ramp )
      *ramp = ramp2;
  }
  return result;
}


// Address: 0x21fbe00 | Name: FMOD_Channel_GetAudibility
FMOD_RESULT_0 __fastcall FMOD_Channel_GetAudibility(FMOD_CHANNEL *channel, float *audibility)
{
  if ( channel )
    return FMOD::ChannelControl::getAudibility((FMOD::ChannelControl *const)channel, audibility);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbe20 | Name: FMOD_Channel_SetPitch
__int64 __fastcall FMOD_Channel_SetPitch(FMOD::ChannelControl *const channel, float a2, float pitch)
{
  if ( channel )
    return FMOD::ChannelControl::setPitch(channel, a2, pitch);
  else
    return 31;
}


// Address: 0x21fbe40 | Name: FMOD_Channel_GetPitch
FMOD_RESULT_0 __fastcall FMOD_Channel_GetPitch(FMOD_CHANNEL *channel, float *pitch)
{
  if ( channel )
    return FMOD::ChannelControl::getPitch((FMOD::ChannelControl *const)channel, pitch);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbe60 | Name: FMOD_Channel_SetMute
FMOD_RESULT_0 __fastcall FMOD_Channel_SetMute(FMOD_CHANNEL *channel, FMOD_BOOL mute)
{
  if ( channel )
    return FMOD::ChannelControl::setMute((FMOD::ChannelControl *const)channel, mute != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbe80 | Name: FMOD_Channel_GetMute
FMOD_RESULT_0 __fastcall FMOD_Channel_GetMute(FMOD_CHANNEL *channel, FMOD_BOOL *mute)
{
  FMOD_RESULT_0 result; // eax
  bool mute2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channel )
  {
    result = FMOD::ChannelControl::getMute((FMOD::ChannelControl *const)channel, &mute2);
    if ( mute )
      *mute = mute2;
  }
  return result;
}


// Address: 0x21fbeb0 | Name: FMOD_Channel_SetReverbProperties
__int64 __fastcall FMOD_Channel_SetReverbProperties(
        FMOD::ChannelControl *const channel,
        unsigned int instance,
        float a3,
        float wet)
{
  if ( channel )
    return FMOD::ChannelControl::setReverbProperties(channel, instance, a3, wet);
  else
    return 31;
}


// Address: 0x21fbed0 | Name: FMOD_Channel_GetReverbProperties
FMOD_RESULT_0 __fastcall FMOD_Channel_GetReverbProperties(FMOD_CHANNEL *channel, int instance, float *wet)
{
  if ( channel )
    return FMOD::ChannelControl::getReverbProperties((FMOD::ChannelControl *const)channel, instance, wet);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbef0 | Name: FMOD_Channel_SetLowPassGain
__int64 __fastcall FMOD_Channel_SetLowPassGain(FMOD::ChannelControl *const channel, float a2, float gain)
{
  if ( channel )
    return FMOD::ChannelControl::setLowPassGain(channel, a2, gain);
  else
    return 31;
}


// Address: 0x21fbf10 | Name: FMOD_Channel_GetLowPassGain
FMOD_RESULT_0 __fastcall FMOD_Channel_GetLowPassGain(FMOD_CHANNEL *channel, float *gain)
{
  if ( channel )
    return FMOD::ChannelControl::getLowPassGain((FMOD::ChannelControl *const)channel, gain);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbf30 | Name: FMOD_Channel_SetMode
FMOD_RESULT_0 __fastcall FMOD_Channel_SetMode(FMOD_CHANNEL *channel, FMOD_MODE mode)
{
  if ( channel )
    return FMOD::ChannelControl::setMode((FMOD::ChannelControl *const)channel, mode);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbf50 | Name: FMOD_Channel_GetMode
FMOD_RESULT_0 __fastcall FMOD_Channel_GetMode(FMOD_CHANNEL *channel, FMOD_MODE *mode)
{
  if ( channel )
    return FMOD::ChannelControl::getMode((FMOD::ChannelControl *const)channel, mode);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbf70 | Name: FMOD_Channel_SetCallback
FMOD_RESULT_0 __fastcall FMOD_Channel_SetCallback(FMOD_CHANNEL *channel, FMOD_CHANNELCONTROL_CALLBACK callback)
{
  if ( channel )
    return FMOD::ChannelControl::setCallback(
             (FMOD::ChannelControl *const)channel,
             (FMOD_CHANNELCONTROL_CALLBACK_0)callback);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fbf90 | Name: FMOD_Channel_IsPlaying
FMOD_RESULT_0 __fastcall FMOD_Channel_IsPlaying(FMOD_CHANNEL *channel, FMOD_BOOL *isplaying)
{
  FMOD_RESULT_0 result; // eax
  bool isplaying2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channel )
  {
    result = FMOD::ChannelControl::isPlaying((FMOD::ChannelControl *const)channel, &isplaying2);
    if ( isplaying )
      *isplaying = isplaying2;
  }
  return result;
}


// Address: 0x21fbfc0 | Name: FMOD_Channel_SetPan
__int64 __fastcall FMOD_Channel_SetPan(FMOD::ChannelControl *const channel, float a2, float pan)
{
  if ( channel )
    return FMOD::ChannelControl::setPan(channel, a2, pan);
  else
    return 31;
}


// Address: 0x21fbfe0 | Name: FMOD_Channel_SetMixLevelsOutput
__int64 __fastcall FMOD_Channel_SetMixLevelsOutput(
        FMOD::ChannelControl *const channel,
        float a2,
        float frontleft,
        float frontright,
        float center,
        float lfe,
        float surroundleft,
        float surroundright,
        float backleft)
{
  if ( channel )
    return FMOD::ChannelControl::setMixLevelsOutput(
             channel,
             a2,
             frontleft,
             frontright,
             center,
             lfe,
             surroundleft,
             surroundright,
             backleft);
  else
    return 31;
}


// Address: 0x21fc000 | Name: FMOD_Channel_SetMixLevelsInput
FMOD_RESULT_0 __fastcall FMOD_Channel_SetMixLevelsInput(FMOD_CHANNEL *channel, float *levels, int numlevels)
{
  if ( channel )
    return FMOD::ChannelControl::setMixLevelsInput((FMOD::ChannelControl *const)channel, levels, numlevels);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc020 | Name: FMOD_Channel_SetMixMatrix
FMOD_RESULT_0 __fastcall FMOD_Channel_SetMixMatrix(
        FMOD_CHANNEL *channel,
        float *matrix,
        int outchannels,
        int inchannels,
        int inchannel_hop)
{
  if ( channel )
    return FMOD::ChannelControl::setMixMatrix(
             (FMOD::ChannelControl *const)channel,
             matrix,
             outchannels,
             inchannels,
             inchannel_hop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc040 | Name: FMOD_Channel_GetMixMatrix
FMOD_RESULT_0 __fastcall FMOD_Channel_GetMixMatrix(
        FMOD_CHANNEL *channel,
        float *matrix,
        int *outchannels,
        int *inchannels,
        int inchannel_hop)
{
  if ( channel )
    return FMOD::ChannelControl::getMixMatrix(
             (FMOD::ChannelControl *const)channel,
             matrix,
             outchannels,
             inchannels,
             inchannel_hop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc060 | Name: FMOD_Channel_GetDSPClock
FMOD_RESULT_0 __fastcall FMOD_Channel_GetDSPClock(
        FMOD_CHANNEL *channel,
        unsigned __int64 *dspclock,
        unsigned __int64 *parentclock)
{
  if ( channel )
    return FMOD::ChannelControl::getDSPClock((FMOD::ChannelControl *const)channel, dspclock, parentclock);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc080 | Name: FMOD_Channel_SetDelay
FMOD_RESULT_0 __fastcall FMOD_Channel_SetDelay(
        FMOD_CHANNEL *channel,
        unsigned __int64 dspclock_start,
        unsigned __int64 dspclock_end,
        FMOD_BOOL stopchannels)
{
  if ( channel )
    return FMOD::ChannelControl::setDelay(
             (FMOD::ChannelControl *const)channel,
             dspclock_start,
             dspclock_end,
             stopchannels != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc0a0 | Name: FMOD_Channel_GetDelay
FMOD_RESULT_0 __fastcall FMOD_Channel_GetDelay(
        FMOD_CHANNEL *channel,
        unsigned __int64 *dspclock_start,
        unsigned __int64 *dspclock_end,
        FMOD_BOOL *stopchannels)
{
  FMOD_RESULT_0 result; // eax
  bool stopchannels2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channel )
  {
    result = FMOD::ChannelControl::getDelay(
               (FMOD::ChannelControl *const)channel,
               dspclock_start,
               dspclock_end,
               &stopchannels2);
    if ( stopchannels )
      *stopchannels = stopchannels2;
  }
  return result;
}


// Address: 0x21fc0d0 | Name: FMOD_Channel_AddFadePoint
__int64 __fastcall FMOD_Channel_AddFadePoint(
        FMOD::ChannelControl *const channel,
        unsigned __int64 dspclock,
        float a3,
        float volume)
{
  if ( channel )
    return FMOD::ChannelControl::addFadePoint(channel, dspclock, a3, volume);
  else
    return 31;
}


// Address: 0x21fc0f0 | Name: FMOD_Channel_SetFadePointRamp
__int64 __fastcall FMOD_Channel_SetFadePointRamp(
        FMOD::ChannelControl *const channel,
        unsigned __int64 dspclock,
        float a3,
        float volume)
{
  if ( channel )
    return FMOD::ChannelControl::setFadePointRamp(channel, dspclock, a3, volume);
  else
    return 31;
}


// Address: 0x21fc110 | Name: FMOD_Channel_RemoveFadePoints
FMOD_RESULT_0 __fastcall FMOD_Channel_RemoveFadePoints(
        FMOD_CHANNEL *channel,
        unsigned __int64 dspclock_start,
        unsigned __int64 dspclock_end)
{
  if ( channel )
    return FMOD::ChannelControl::removeFadePoints((FMOD::ChannelControl *const)channel, dspclock_start, dspclock_end);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc130 | Name: FMOD_Channel_GetFadePoints
FMOD_RESULT_0 __fastcall FMOD_Channel_GetFadePoints(
        FMOD_CHANNEL *channel,
        unsigned int *numpoints,
        unsigned __int64 *point_dspclock,
        float *point_volume)
{
  if ( channel )
    return FMOD::ChannelControl::getFadePoints(
             (FMOD::ChannelControl *const)channel,
             numpoints,
             point_dspclock,
             point_volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc150 | Name: FMOD_Channel_GetDSP
FMOD_RESULT_0 __fastcall FMOD_Channel_GetDSP(FMOD_CHANNEL *channel, int index, FMOD_DSP **dsp)
{
  if ( channel )
    return FMOD::ChannelControl::getDSP((FMOD::ChannelControl *const)channel, index, (FMOD::DSP **)dsp);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc170 | Name: FMOD_Channel_AddDSP
FMOD_RESULT_0 __fastcall FMOD_Channel_AddDSP(FMOD_CHANNEL *channel, int index, FMOD_DSP *dsp)
{
  if ( channel )
    return FMOD::ChannelControl::addDSP((FMOD::ChannelControl *const)channel, index, (FMOD::DSP *)dsp);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc190 | Name: FMOD_Channel_RemoveDSP
FMOD_RESULT_0 __fastcall FMOD_Channel_RemoveDSP(FMOD_CHANNEL *channel, FMOD_DSP *dsp)
{
  if ( channel )
    return FMOD::ChannelControl::removeDSP((FMOD::ChannelControl *const)channel, (FMOD::DSP *)dsp);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc1b0 | Name: FMOD_Channel_GetNumDSPs
FMOD_RESULT_0 __fastcall FMOD_Channel_GetNumDSPs(FMOD_CHANNEL *channel, int *numdsps)
{
  if ( channel )
    return FMOD::ChannelControl::getNumDSPs((FMOD::ChannelControl *const)channel, numdsps);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc1d0 | Name: FMOD_Channel_SetDSPIndex
FMOD_RESULT_0 __fastcall FMOD_Channel_SetDSPIndex(FMOD_CHANNEL *channel, FMOD_DSP *dsp, int index)
{
  if ( channel )
    return FMOD::ChannelControl::setDSPIndex((FMOD::ChannelControl *const)channel, (FMOD::DSP *)dsp, index);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc1f0 | Name: FMOD_Channel_GetDSPIndex
FMOD_RESULT_0 __fastcall FMOD_Channel_GetDSPIndex(FMOD_CHANNEL *channel, FMOD_DSP *dsp, int *index)
{
  if ( channel )
    return FMOD::ChannelControl::getDSPIndex((FMOD::ChannelControl *const)channel, (FMOD::DSP *)dsp, index);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc210 | Name: FMOD_Channel_Set3DAttributes
FMOD_RESULT_0 __fastcall FMOD_Channel_Set3DAttributes(
        FMOD_CHANNEL *channel,
        const FMOD_VECTOR *pos,
        const FMOD_VECTOR *vel)
{
  if ( channel )
    return FMOD::ChannelControl::set3DAttributes((FMOD::ChannelControl *const)channel, pos, vel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc230 | Name: FMOD_Channel_Get3DAttributes
FMOD_RESULT_0 __fastcall FMOD_Channel_Get3DAttributes(FMOD_CHANNEL *channel, FMOD_VECTOR *pos, FMOD_VECTOR *vel)
{
  if ( channel )
    return FMOD::ChannelControl::get3DAttributes((FMOD::ChannelControl *const)channel, pos, vel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc250 | Name: FMOD_Channel_Set3DMinMaxDistance
__int64 __fastcall FMOD_Channel_Set3DMinMaxDistance(
        FMOD::ChannelControl *const channel,
        float a2,
        float mindistance,
        float maxdistance)
{
  if ( channel )
    return FMOD::ChannelControl::set3DMinMaxDistance(channel, a2, mindistance, maxdistance);
  else
    return 31;
}


// Address: 0x21fc270 | Name: FMOD_Channel_Get3DMinMaxDistance
FMOD_RESULT_0 __fastcall FMOD_Channel_Get3DMinMaxDistance(
        FMOD_CHANNEL *channel,
        float *mindistance,
        float *maxdistance)
{
  if ( channel )
    return FMOD::ChannelControl::get3DMinMaxDistance((FMOD::ChannelControl *const)channel, mindistance, maxdistance);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc290 | Name: FMOD_Channel_Set3DConeSettings
__int64 __fastcall FMOD_Channel_Set3DConeSettings(
        FMOD::ChannelControl *const channel,
        float a2,
        float insideconeangle,
        float outsideconeangle,
        float outsidevolume)
{
  if ( channel )
    return FMOD::ChannelControl::set3DConeSettings(channel, a2, insideconeangle, outsideconeangle, outsidevolume);
  else
    return 31;
}


// Address: 0x21fc2b0 | Name: FMOD_Channel_Get3DConeSettings
FMOD_RESULT_0 __fastcall FMOD_Channel_Get3DConeSettings(
        FMOD_CHANNEL *channel,
        float *insideconeangle,
        float *outsideconeangle,
        float *outsidevolume)
{
  if ( channel )
    return FMOD::ChannelControl::get3DConeSettings(
             (FMOD::ChannelControl *const)channel,
             insideconeangle,
             outsideconeangle,
             outsidevolume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc2d0 | Name: FMOD_Channel_Set3DConeOrientation
FMOD_RESULT_0 __fastcall FMOD_Channel_Set3DConeOrientation(FMOD_CHANNEL *channel, FMOD_VECTOR *orientation)
{
  if ( channel )
    return FMOD::ChannelControl::set3DConeOrientation((FMOD::ChannelControl *const)channel, orientation);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc2f0 | Name: FMOD_Channel_Get3DConeOrientation
FMOD_RESULT_0 __fastcall FMOD_Channel_Get3DConeOrientation(FMOD_CHANNEL *channel, FMOD_VECTOR *orientation)
{
  if ( channel )
    return FMOD::ChannelControl::get3DConeOrientation((FMOD::ChannelControl *const)channel, orientation);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc310 | Name: FMOD_Channel_Set3DCustomRolloff
FMOD_RESULT_0 __fastcall FMOD_Channel_Set3DCustomRolloff(FMOD_CHANNEL *channel, FMOD_VECTOR *points, int numpoints)
{
  if ( channel )
    return FMOD::ChannelControl::set3DCustomRolloff((FMOD::ChannelControl *const)channel, points, numpoints);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc330 | Name: FMOD_Channel_Get3DCustomRolloff
FMOD_RESULT_0 __fastcall FMOD_Channel_Get3DCustomRolloff(FMOD_CHANNEL *channel, FMOD_VECTOR **points, int *numpoints)
{
  if ( channel )
    return FMOD::ChannelControl::get3DCustomRolloff((FMOD::ChannelControl *const)channel, points, numpoints);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc350 | Name: FMOD_Channel_Set3DOcclusion
__int64 __fastcall FMOD_Channel_Set3DOcclusion(
        FMOD::ChannelControl *const channel,
        float a2,
        float directocclusion,
        float reverbocclusion)
{
  if ( channel )
    return FMOD::ChannelControl::set3DOcclusion(channel, a2, directocclusion, reverbocclusion);
  else
    return 31;
}


// Address: 0x21fc370 | Name: FMOD_Channel_Get3DOcclusion
FMOD_RESULT_0 __fastcall FMOD_Channel_Get3DOcclusion(
        FMOD_CHANNEL *channel,
        float *directocclusion,
        float *reverbocclusion)
{
  if ( channel )
    return FMOD::ChannelControl::get3DOcclusion((FMOD::ChannelControl *const)channel, directocclusion, reverbocclusion);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc390 | Name: FMOD_Channel_Set3DSpread
__int64 __fastcall FMOD_Channel_Set3DSpread(FMOD::ChannelControl *const channel, float a2, float angle)
{
  if ( channel )
    return FMOD::ChannelControl::set3DSpread(channel, a2, angle);
  else
    return 31;
}


// Address: 0x21fc3b0 | Name: FMOD_Channel_Get3DSpread
FMOD_RESULT_0 __fastcall FMOD_Channel_Get3DSpread(FMOD_CHANNEL *channel, float *angle)
{
  if ( channel )
    return FMOD::ChannelControl::get3DSpread((FMOD::ChannelControl *const)channel, angle);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc3d0 | Name: FMOD_Channel_Set3DLevel
__int64 __fastcall FMOD_Channel_Set3DLevel(FMOD::ChannelControl *const channel, float a2, float level)
{
  if ( channel )
    return FMOD::ChannelControl::set3DLevel(channel, a2, level);
  else
    return 31;
}


// Address: 0x21fc3f0 | Name: FMOD_Channel_Get3DLevel
FMOD_RESULT_0 __fastcall FMOD_Channel_Get3DLevel(FMOD_CHANNEL *channel, float *level)
{
  if ( channel )
    return FMOD::ChannelControl::get3DLevel((FMOD::ChannelControl *const)channel, level);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc410 | Name: FMOD_Channel_Set3DDopplerLevel
__int64 __fastcall FMOD_Channel_Set3DDopplerLevel(FMOD::ChannelControl *const channel, float a2, float level)
{
  if ( channel )
    return FMOD::ChannelControl::set3DDopplerLevel(channel, a2, level);
  else
    return 31;
}


// Address: 0x21fc430 | Name: FMOD_Channel_Get3DDopplerLevel
FMOD_RESULT_0 __fastcall FMOD_Channel_Get3DDopplerLevel(FMOD_CHANNEL *channel, float *level)
{
  if ( channel )
    return FMOD::ChannelControl::get3DDopplerLevel((FMOD::ChannelControl *const)channel, level);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc450 | Name: FMOD_Channel_Set3DDistanceFilter
__int64 __fastcall FMOD_Channel_Set3DDistanceFilter(
        FMOD::ChannelControl *channel,
        FMOD_BOOL custom,
        float a3,
        float customLevel,
        float centerFreq)
{
  if ( channel )
    return FMOD::ChannelControl::set3DDistanceFilter(channel, custom != 0, a3, customLevel, centerFreq);
  else
    return 31;
}


// Address: 0x21fc470 | Name: FMOD_Channel_Get3DDistanceFilter
FMOD_RESULT_0 __fastcall FMOD_Channel_Get3DDistanceFilter(
        FMOD_CHANNEL *channel,
        FMOD_BOOL *custom,
        float *customLevel,
        float *centerFreq)
{
  FMOD_RESULT_0 result; // eax
  bool custom2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channel )
  {
    result = FMOD::ChannelControl::get3DDistanceFilter(
               (FMOD::ChannelControl *const)channel,
               &custom2,
               customLevel,
               centerFreq);
    if ( custom )
      *custom = custom2;
  }
  return result;
}


// Address: 0x21fc4a0 | Name: FMOD_Channel_SetUserData
FMOD_RESULT_0 __fastcall FMOD_Channel_SetUserData(FMOD_CHANNEL *channel, void *userdata)
{
  if ( channel )
    return FMOD::ChannelControl::setUserData((FMOD::ChannelControl *const)channel, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc4c0 | Name: FMOD_Channel_GetUserData
FMOD_RESULT_0 __fastcall FMOD_Channel_GetUserData(FMOD_CHANNEL *channel, void **userdata)
{
  if ( channel )
    return FMOD::ChannelControl::getUserData((FMOD::ChannelControl *const)channel, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc4e0 | Name: FMOD_Channel_SetFrequency
__int64 __fastcall FMOD_Channel_SetFrequency(FMOD::Channel *const channel, double a2, float frequency)
{
  if ( channel )
    return FMOD::Channel::setFrequency(channel, a2, frequency);
  else
    return 31;
}


// Address: 0x21fc500 | Name: FMOD_Channel_GetFrequency
FMOD_RESULT_0 __fastcall FMOD_Channel_GetFrequency(FMOD_CHANNEL *channel, float *frequency)
{
  if ( channel )
    return FMOD::Channel::getFrequency((FMOD::Channel *const)channel, frequency);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc520 | Name: FMOD_Channel_SetPriority
FMOD_RESULT_0 __fastcall FMOD_Channel_SetPriority(FMOD_CHANNEL *channel, int priority)
{
  if ( channel )
    return FMOD::Channel::setPriority((FMOD::Channel *const)channel, priority);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc540 | Name: FMOD_Channel_GetPriority
FMOD_RESULT_0 __fastcall FMOD_Channel_GetPriority(FMOD_CHANNEL *channel, int *priority)
{
  if ( channel )
    return FMOD::Channel::getPriority((FMOD::Channel *const)channel, priority);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc560 | Name: FMOD_Channel_SetPosition
FMOD_RESULT_0 __fastcall FMOD_Channel_SetPosition(FMOD_CHANNEL *channel, unsigned int position, FMOD_TIMEUNIT postype)
{
  if ( channel )
    return FMOD::Channel::setPosition((FMOD::Channel *const)channel, position, postype);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc580 | Name: FMOD_Channel_GetPosition
FMOD_RESULT_0 __fastcall FMOD_Channel_GetPosition(FMOD_CHANNEL *channel, unsigned int *position, FMOD_TIMEUNIT postype)
{
  if ( channel )
    return FMOD::Channel::getPosition((FMOD::Channel *const)channel, position, postype);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc5a0 | Name: FMOD_Channel_SetChannelGroup
FMOD_RESULT_0 __fastcall FMOD_Channel_SetChannelGroup(FMOD_CHANNEL *channel, FMOD_CHANNELGROUP *channelgroup)
{
  if ( channel )
    return FMOD::Channel::setChannelGroup((FMOD::Channel *const)channel, (FMOD::ChannelGroup *)channelgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc5c0 | Name: FMOD_Channel_GetChannelGroup
FMOD_RESULT_0 __fastcall FMOD_Channel_GetChannelGroup(FMOD_CHANNEL *channel, FMOD_CHANNELGROUP **channelgroup)
{
  if ( channel )
    return FMOD::Channel::getChannelGroup((FMOD::Channel *const)channel, (FMOD::ChannelGroup **)channelgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc5e0 | Name: FMOD_Channel_SetLoopCount
FMOD_RESULT_0 __fastcall FMOD_Channel_SetLoopCount(FMOD_CHANNEL *channel, int loopcount)
{
  if ( channel )
    return FMOD::Channel::setLoopCount((FMOD::Channel *const)channel, loopcount);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc600 | Name: FMOD_Channel_GetLoopCount
FMOD_RESULT_0 __fastcall FMOD_Channel_GetLoopCount(FMOD_CHANNEL *channel, int *loopcount)
{
  if ( channel )
    return FMOD::Channel::getLoopCount((FMOD::Channel *const)channel, loopcount);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc620 | Name: FMOD_Channel_SetLoopPoints
FMOD_RESULT_0 __fastcall FMOD_Channel_SetLoopPoints(
        FMOD_CHANNEL *channel,
        unsigned int loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int loopend,
        FMOD_TIMEUNIT loopendtype)
{
  if ( channel )
    return FMOD::Channel::setLoopPoints((FMOD::Channel *const)channel, loopstart, loopstarttype, loopend, loopendtype);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc640 | Name: FMOD_Channel_GetLoopPoints
FMOD_RESULT_0 __fastcall FMOD_Channel_GetLoopPoints(
        FMOD_CHANNEL *channel,
        unsigned int *loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int *loopend,
        FMOD_TIMEUNIT loopendtype)
{
  if ( channel )
    return FMOD::Channel::getLoopPoints((FMOD::Channel *const)channel, loopstart, loopstarttype, loopend, loopendtype);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc660 | Name: FMOD_Channel_IsVirtual
FMOD_RESULT_0 __fastcall FMOD_Channel_IsVirtual(FMOD_CHANNEL *channel, FMOD_BOOL *isvirtual)
{
  FMOD_RESULT_0 result; // eax
  bool isvirtual2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channel )
  {
    result = FMOD::Channel::isVirtual((FMOD::Channel *const)channel, &isvirtual2);
    if ( isvirtual )
      *isvirtual = isvirtual2;
  }
  return result;
}


// Address: 0x21fc690 | Name: FMOD_Channel_GetCurrentSound
FMOD_RESULT_0 __fastcall FMOD_Channel_GetCurrentSound(FMOD_CHANNEL *channel, FMOD_SOUND **sound)
{
  if ( channel )
    return FMOD::Channel::getCurrentSound((FMOD::Channel *const)channel, (FMOD::Sound **)sound);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc6b0 | Name: FMOD_Channel_GetIndex
FMOD_RESULT_0 __fastcall FMOD_Channel_GetIndex(FMOD_CHANNEL *channel, int *index)
{
  if ( channel )
    return FMOD::Channel::getIndex((FMOD::Channel *const)channel, index);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc6d0 | Name: FMOD_ChannelGroup_GetSystemObject
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetSystemObject(FMOD_CHANNELGROUP *channelgroup, FMOD_SYSTEM **system)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getSystemObject((FMOD::ChannelControl *const)channelgroup, (FMOD::System **)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc6f0 | Name: FMOD_ChannelGroup_Stop
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Stop(FMOD_CHANNELGROUP *channelgroup)
{
  if ( channelgroup )
    return FMOD::ChannelControl::stop((FMOD::ChannelControl *const)channelgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc710 | Name: FMOD_ChannelGroup_SetPaused
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_SetPaused(FMOD_CHANNELGROUP *channelgroup, FMOD_BOOL paused)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setPaused((FMOD::ChannelControl *const)channelgroup, paused != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc730 | Name: FMOD_ChannelGroup_GetPaused
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetPaused(FMOD_CHANNELGROUP *channelgroup, FMOD_BOOL *paused)
{
  FMOD_RESULT_0 result; // eax
  bool paused2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroup )
  {
    result = FMOD::ChannelControl::getPaused((FMOD::ChannelControl *const)channelgroup, &paused2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( paused )
        *paused = paused2;
    }
  }
  return result;
}


// Address: 0x21fc770 | Name: FMOD_ChannelGroup_SetVolume
__int64 __fastcall FMOD_ChannelGroup_SetVolume(FMOD::ChannelControl *const channelgroup, float a2, float volume)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setVolume(channelgroup, a2, volume);
  else
    return 31;
}


// Address: 0x21fc790 | Name: FMOD_ChannelGroup_GetVolume
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetVolume(FMOD_CHANNELGROUP *channelgroup, float *volume)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getVolume((FMOD::ChannelControl *const)channelgroup, volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc7b0 | Name: FMOD_ChannelGroup_SetVolumeRamp
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_SetVolumeRamp(FMOD_CHANNELGROUP *channelgroup, FMOD_BOOL ramp)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setVolumeRamp((FMOD::ChannelControl *const)channelgroup, ramp != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc7d0 | Name: FMOD_ChannelGroup_GetVolumeRamp
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetVolumeRamp(FMOD_CHANNELGROUP *channelgroup, FMOD_BOOL *ramp)
{
  FMOD_RESULT_0 result; // eax
  bool ramp2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroup )
  {
    result = FMOD::ChannelControl::getVolumeRamp((FMOD::ChannelControl *const)channelgroup, &ramp2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( ramp )
        *ramp = ramp2;
    }
  }
  return result;
}


// Address: 0x21fc810 | Name: FMOD_ChannelGroup_GetAudibility
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetAudibility(FMOD_CHANNELGROUP *channelgroup, float *audibility)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getAudibility((FMOD::ChannelControl *const)channelgroup, audibility);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc830 | Name: FMOD_ChannelGroup_SetPitch
__int64 __fastcall FMOD_ChannelGroup_SetPitch(FMOD::ChannelControl *const channelgroup, float a2, float pitch)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setPitch(channelgroup, a2, pitch);
  else
    return 31;
}


// Address: 0x21fc850 | Name: FMOD_ChannelGroup_GetPitch
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetPitch(FMOD_CHANNELGROUP *channelgroup, float *pitch)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getPitch((FMOD::ChannelControl *const)channelgroup, pitch);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc870 | Name: FMOD_ChannelGroup_SetMute
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_SetMute(FMOD_CHANNELGROUP *channelgroup, FMOD_BOOL mute)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setMute((FMOD::ChannelControl *const)channelgroup, mute != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc890 | Name: FMOD_ChannelGroup_GetMute
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetMute(FMOD_CHANNELGROUP *channelgroup, FMOD_BOOL *mute)
{
  FMOD_RESULT_0 result; // eax
  bool mute2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroup )
  {
    result = FMOD::ChannelControl::getMute((FMOD::ChannelControl *const)channelgroup, &mute2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( mute )
        *mute = mute2;
    }
  }
  return result;
}


// Address: 0x21fc8d0 | Name: FMOD_ChannelGroup_SetReverbProperties
__int64 __fastcall FMOD_ChannelGroup_SetReverbProperties(
        FMOD::ChannelControl *const channelgroup,
        unsigned int instance,
        float a3,
        float wet)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setReverbProperties(channelgroup, instance, a3, wet);
  else
    return 31;
}


// Address: 0x21fc8f0 | Name: FMOD_ChannelGroup_GetReverbProperties
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetReverbProperties(
        FMOD_CHANNELGROUP *channelgroup,
        int instance,
        float *wet)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getReverbProperties((FMOD::ChannelControl *const)channelgroup, instance, wet);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc910 | Name: FMOD_ChannelGroup_SetLowPassGain
__int64 __fastcall FMOD_ChannelGroup_SetLowPassGain(FMOD::ChannelControl *const channelgroup, float a2, float gain)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setLowPassGain(channelgroup, a2, gain);
  else
    return 31;
}


// Address: 0x21fc930 | Name: FMOD_ChannelGroup_GetLowPassGain
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetLowPassGain(FMOD_CHANNELGROUP *channelgroup, float *gain)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getLowPassGain((FMOD::ChannelControl *const)channelgroup, gain);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc950 | Name: FMOD_ChannelGroup_SetMode
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_SetMode(FMOD_CHANNELGROUP *channelgroup, FMOD_MODE mode)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setMode((FMOD::ChannelControl *const)channelgroup, mode);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc970 | Name: FMOD_ChannelGroup_GetMode
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetMode(FMOD_CHANNELGROUP *channelgroup, FMOD_MODE *mode)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getMode((FMOD::ChannelControl *const)channelgroup, mode);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc990 | Name: FMOD_ChannelGroup_SetCallback
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_SetCallback(
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_CHANNELCONTROL_CALLBACK callback)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setCallback(
             (FMOD::ChannelControl *const)channelgroup,
             (FMOD_CHANNELCONTROL_CALLBACK_0)callback);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fc9b0 | Name: FMOD_ChannelGroup_IsPlaying
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_IsPlaying(FMOD_CHANNELGROUP *channelgroup, FMOD_BOOL *isplaying)
{
  FMOD_RESULT_0 result; // eax
  bool isplaying2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroup )
  {
    result = FMOD::ChannelControl::isPlaying((FMOD::ChannelControl *const)channelgroup, &isplaying2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( isplaying )
        *isplaying = isplaying2;
    }
  }
  return result;
}


// Address: 0x21fc9f0 | Name: FMOD_ChannelGroup_SetPan
__int64 __fastcall FMOD_ChannelGroup_SetPan(FMOD::ChannelControl *const channelgroup, float a2, float pan)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setPan(channelgroup, a2, pan);
  else
    return 31;
}


// Address: 0x21fca10 | Name: FMOD_ChannelGroup_SetMixLevelsOutput
__int64 __fastcall FMOD_ChannelGroup_SetMixLevelsOutput(
        FMOD::ChannelControl *const channelgroup,
        float a2,
        float frontleft,
        float frontright,
        float center,
        float lfe,
        float surroundleft,
        float surroundright,
        float backleft)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setMixLevelsOutput(
             channelgroup,
             a2,
             frontleft,
             frontright,
             center,
             lfe,
             surroundleft,
             surroundright,
             backleft);
  else
    return 31;
}


// Address: 0x21fca30 | Name: FMOD_ChannelGroup_SetMixLevelsInput
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_SetMixLevelsInput(
        FMOD_CHANNELGROUP *channelgroup,
        float *levels,
        int numlevels)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setMixLevelsInput((FMOD::ChannelControl *const)channelgroup, levels, numlevels);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fca50 | Name: FMOD_ChannelGroup_SetMixMatrix
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_SetMixMatrix(
        FMOD_CHANNELGROUP *channelgroup,
        float *matrix,
        int outchannels,
        int inchannels,
        int inchannel_hop)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setMixMatrix(
             (FMOD::ChannelControl *const)channelgroup,
             matrix,
             outchannels,
             inchannels,
             inchannel_hop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fca70 | Name: FMOD_ChannelGroup_GetMixMatrix
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetMixMatrix(
        FMOD_CHANNELGROUP *channelgroup,
        float *matrix,
        int *outchannels,
        int *inchannels,
        int inchannel_hop)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getMixMatrix(
             (FMOD::ChannelControl *const)channelgroup,
             matrix,
             outchannels,
             inchannels,
             inchannel_hop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fca90 | Name: FMOD_ChannelGroup_GetDSPClock
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetDSPClock(
        FMOD_CHANNELGROUP *channelgroup,
        unsigned __int64 *dspclock,
        unsigned __int64 *parentclock)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getDSPClock((FMOD::ChannelControl *const)channelgroup, dspclock, parentclock);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcab0 | Name: FMOD_ChannelGroup_SetDelay
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_SetDelay(
        FMOD_CHANNELGROUP *channelgroup,
        unsigned __int64 dspclock_start,
        unsigned __int64 dspclock_end,
        FMOD_BOOL stopchannels)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setDelay(
             (FMOD::ChannelControl *const)channelgroup,
             dspclock_start,
             dspclock_end,
             stopchannels != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcad0 | Name: FMOD_ChannelGroup_GetDelay
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetDelay(
        FMOD_CHANNELGROUP *channelgroup,
        unsigned __int64 *dspclock_start,
        unsigned __int64 *dspclock_end,
        FMOD_BOOL *stopchannels)
{
  FMOD_RESULT_0 result; // eax
  bool stopchannels2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroup )
  {
    result = FMOD::ChannelControl::getDelay(
               (FMOD::ChannelControl *const)channelgroup,
               dspclock_start,
               dspclock_end,
               &stopchannels2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( stopchannels )
        *stopchannels = stopchannels2;
    }
  }
  return result;
}


// Address: 0x21fcb10 | Name: FMOD_ChannelGroup_AddFadePoint
__int64 __fastcall FMOD_ChannelGroup_AddFadePoint(
        FMOD::ChannelControl *const channelgroup,
        unsigned __int64 dspclock,
        float a3,
        float volume)
{
  if ( channelgroup )
    return FMOD::ChannelControl::addFadePoint(channelgroup, dspclock, a3, volume);
  else
    return 31;
}


// Address: 0x21fcb30 | Name: FMOD_ChannelGroup_SetFadePointRamp
__int64 __fastcall FMOD_ChannelGroup_SetFadePointRamp(
        FMOD::ChannelControl *const channelgroup,
        unsigned __int64 dspclock,
        float a3,
        float volume)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setFadePointRamp(channelgroup, dspclock, a3, volume);
  else
    return 31;
}


// Address: 0x21fcb50 | Name: FMOD_ChannelGroup_RemoveFadePoints
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_RemoveFadePoints(
        FMOD_CHANNELGROUP *channelgroup,
        unsigned __int64 dspclock_start,
        unsigned __int64 dspclock_end)
{
  if ( channelgroup )
    return FMOD::ChannelControl::removeFadePoints(
             (FMOD::ChannelControl *const)channelgroup,
             dspclock_start,
             dspclock_end);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcb70 | Name: FMOD_ChannelGroup_GetFadePoints
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetFadePoints(
        FMOD_CHANNELGROUP *channelgroup,
        unsigned int *numpoints,
        unsigned __int64 *point_dspclock,
        float *point_volume)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getFadePoints(
             (FMOD::ChannelControl *const)channelgroup,
             numpoints,
             point_dspclock,
             point_volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcb90 | Name: FMOD_ChannelGroup_GetDSP
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetDSP(FMOD_CHANNELGROUP *channelgroup, int index, FMOD_DSP **dsp)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getDSP((FMOD::ChannelControl *const)channelgroup, index, (FMOD::DSP **)dsp);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcbb0 | Name: FMOD_ChannelGroup_AddDSP
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_AddDSP(FMOD_CHANNELGROUP *channelgroup, int index, FMOD_DSP *dsp)
{
  if ( channelgroup )
    return FMOD::ChannelControl::addDSP((FMOD::ChannelControl *const)channelgroup, index, (FMOD::DSP *)dsp);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcbd0 | Name: FMOD_ChannelGroup_RemoveDSP
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_RemoveDSP(FMOD_CHANNELGROUP *channelgroup, FMOD_DSP *dsp)
{
  if ( channelgroup )
    return FMOD::ChannelControl::removeDSP((FMOD::ChannelControl *const)channelgroup, (FMOD::DSP *)dsp);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcbf0 | Name: FMOD_ChannelGroup_GetNumDSPs
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetNumDSPs(FMOD_CHANNELGROUP *channelgroup, int *numdsps)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getNumDSPs((FMOD::ChannelControl *const)channelgroup, numdsps);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcc10 | Name: FMOD_ChannelGroup_SetDSPIndex
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_SetDSPIndex(FMOD_CHANNELGROUP *channelgroup, FMOD_DSP *dsp, int index)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setDSPIndex((FMOD::ChannelControl *const)channelgroup, (FMOD::DSP *)dsp, index);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcc30 | Name: FMOD_ChannelGroup_GetDSPIndex
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetDSPIndex(FMOD_CHANNELGROUP *channelgroup, FMOD_DSP *dsp, int *index)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getDSPIndex((FMOD::ChannelControl *const)channelgroup, (FMOD::DSP *)dsp, index);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcc50 | Name: FMOD_ChannelGroup_Set3DAttributes
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Set3DAttributes(
        FMOD_CHANNELGROUP *channelgroup,
        const FMOD_VECTOR *pos,
        const FMOD_VECTOR *vel)
{
  if ( channelgroup )
    return FMOD::ChannelControl::set3DAttributes((FMOD::ChannelControl *const)channelgroup, pos, vel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcc70 | Name: FMOD_ChannelGroup_Get3DAttributes
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Get3DAttributes(
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_VECTOR *pos,
        FMOD_VECTOR *vel)
{
  if ( channelgroup )
    return FMOD::ChannelControl::get3DAttributes((FMOD::ChannelControl *const)channelgroup, pos, vel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcc90 | Name: FMOD_ChannelGroup_Set3DMinMaxDistance
__int64 __fastcall FMOD_ChannelGroup_Set3DMinMaxDistance(
        FMOD::ChannelControl *const channelgroup,
        float a2,
        float mindistance,
        float maxdistance)
{
  if ( channelgroup )
    return FMOD::ChannelControl::set3DMinMaxDistance(channelgroup, a2, mindistance, maxdistance);
  else
    return 31;
}


// Address: 0x21fccb0 | Name: FMOD_ChannelGroup_Get3DMinMaxDistance
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Get3DMinMaxDistance(
        FMOD_CHANNELGROUP *channelgroup,
        float *mindistance,
        float *maxdistance)
{
  if ( channelgroup )
    return FMOD::ChannelControl::get3DMinMaxDistance(
             (FMOD::ChannelControl *const)channelgroup,
             mindistance,
             maxdistance);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fccd0 | Name: FMOD_ChannelGroup_Set3DConeSettings
__int64 __fastcall FMOD_ChannelGroup_Set3DConeSettings(
        FMOD::ChannelControl *const channelgroup,
        float a2,
        float insideconeangle,
        float outsideconeangle,
        float outsidevolume)
{
  if ( channelgroup )
    return FMOD::ChannelControl::set3DConeSettings(channelgroup, a2, insideconeangle, outsideconeangle, outsidevolume);
  else
    return 31;
}


// Address: 0x21fccf0 | Name: FMOD_ChannelGroup_Get3DConeSettings
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Get3DConeSettings(
        FMOD_CHANNELGROUP *channelgroup,
        float *insideconeangle,
        float *outsideconeangle,
        float *outsidevolume)
{
  if ( channelgroup )
    return FMOD::ChannelControl::get3DConeSettings(
             (FMOD::ChannelControl *const)channelgroup,
             insideconeangle,
             outsideconeangle,
             outsidevolume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcd10 | Name: FMOD_ChannelGroup_Set3DConeOrientation
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Set3DConeOrientation(
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_VECTOR *orientation)
{
  if ( channelgroup )
    return FMOD::ChannelControl::set3DConeOrientation((FMOD::ChannelControl *const)channelgroup, orientation);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcd30 | Name: FMOD_ChannelGroup_Get3DConeOrientation
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Get3DConeOrientation(
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_VECTOR *orientation)
{
  if ( channelgroup )
    return FMOD::ChannelControl::get3DConeOrientation((FMOD::ChannelControl *const)channelgroup, orientation);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcd50 | Name: FMOD_ChannelGroup_Set3DCustomRolloff
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Set3DCustomRolloff(
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_VECTOR *points,
        int numpoints)
{
  if ( channelgroup )
    return FMOD::ChannelControl::set3DCustomRolloff((FMOD::ChannelControl *const)channelgroup, points, numpoints);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcd70 | Name: FMOD_ChannelGroup_Get3DCustomRolloff
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Get3DCustomRolloff(
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_VECTOR **points,
        int *numpoints)
{
  if ( channelgroup )
    return FMOD::ChannelControl::get3DCustomRolloff((FMOD::ChannelControl *const)channelgroup, points, numpoints);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcd90 | Name: FMOD_ChannelGroup_Set3DOcclusion
__int64 __fastcall FMOD_ChannelGroup_Set3DOcclusion(
        FMOD::ChannelControl *const channelgroup,
        float a2,
        float directocclusion,
        float reverbocclusion)
{
  if ( channelgroup )
    return FMOD::ChannelControl::set3DOcclusion(channelgroup, a2, directocclusion, reverbocclusion);
  else
    return 31;
}


// Address: 0x21fcdb0 | Name: FMOD_ChannelGroup_Get3DOcclusion
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Get3DOcclusion(
        FMOD_CHANNELGROUP *channelgroup,
        float *directocclusion,
        float *reverbocclusion)
{
  if ( channelgroup )
    return FMOD::ChannelControl::get3DOcclusion(
             (FMOD::ChannelControl *const)channelgroup,
             directocclusion,
             reverbocclusion);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcdd0 | Name: FMOD_ChannelGroup_Set3DSpread
__int64 __fastcall FMOD_ChannelGroup_Set3DSpread(FMOD::ChannelControl *const channelgroup, float a2, float angle)
{
  if ( channelgroup )
    return FMOD::ChannelControl::set3DSpread(channelgroup, a2, angle);
  else
    return 31;
}


// Address: 0x21fcdf0 | Name: FMOD_ChannelGroup_Get3DSpread
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Get3DSpread(FMOD_CHANNELGROUP *channelgroup, float *angle)
{
  if ( channelgroup )
    return FMOD::ChannelControl::get3DSpread((FMOD::ChannelControl *const)channelgroup, angle);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fce10 | Name: FMOD_ChannelGroup_Set3DLevel
__int64 __fastcall FMOD_ChannelGroup_Set3DLevel(FMOD::ChannelControl *const channelgroup, float a2, float level)
{
  if ( channelgroup )
    return FMOD::ChannelControl::set3DLevel(channelgroup, a2, level);
  else
    return 31;
}


// Address: 0x21fce30 | Name: FMOD_ChannelGroup_Get3DLevel
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Get3DLevel(FMOD_CHANNELGROUP *channelgroup, float *level)
{
  if ( channelgroup )
    return FMOD::ChannelControl::get3DLevel((FMOD::ChannelControl *const)channelgroup, level);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fce50 | Name: FMOD_ChannelGroup_Set3DDopplerLevel
__int64 __fastcall FMOD_ChannelGroup_Set3DDopplerLevel(FMOD::ChannelControl *const channelgroup, float a2, float level)
{
  if ( channelgroup )
    return FMOD::ChannelControl::set3DDopplerLevel(channelgroup, a2, level);
  else
    return 31;
}


// Address: 0x21fce70 | Name: FMOD_ChannelGroup_Get3DDopplerLevel
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Get3DDopplerLevel(FMOD_CHANNELGROUP *channelgroup, float *level)
{
  if ( channelgroup )
    return FMOD::ChannelControl::get3DDopplerLevel((FMOD::ChannelControl *const)channelgroup, level);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fce90 | Name: FMOD_ChannelGroup_Set3DDistanceFilter
__int64 __fastcall FMOD_ChannelGroup_Set3DDistanceFilter(
        FMOD::ChannelControl *channelgroup,
        FMOD_BOOL custom,
        float a3,
        float customLevel,
        float centerFreq)
{
  if ( channelgroup )
    return FMOD::ChannelControl::set3DDistanceFilter(channelgroup, custom != 0, a3, customLevel, centerFreq);
  else
    return 31;
}


// Address: 0x21fceb0 | Name: FMOD_ChannelGroup_Get3DDistanceFilter
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Get3DDistanceFilter(
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_BOOL *custom,
        float *customLevel,
        float *centerFreq)
{
  FMOD_RESULT_0 result; // eax
  bool custom2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroup )
  {
    result = FMOD::ChannelControl::get3DDistanceFilter(
               (FMOD::ChannelControl *const)channelgroup,
               &custom2,
               customLevel,
               centerFreq);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( custom )
        *custom = custom2;
    }
  }
  return result;
}


// Address: 0x21fcef0 | Name: FMOD_ChannelGroup_SetUserData
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_SetUserData(FMOD_CHANNELGROUP *channelgroup, void *userdata)
{
  if ( channelgroup )
    return FMOD::ChannelControl::setUserData((FMOD::ChannelControl *const)channelgroup, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcf10 | Name: FMOD_ChannelGroup_GetUserData
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetUserData(FMOD_CHANNELGROUP *channelgroup, void **userdata)
{
  if ( channelgroup )
    return FMOD::ChannelControl::getUserData((FMOD::ChannelControl *const)channelgroup, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcf30 | Name: FMOD_ChannelGroup_Release
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_Release(FMOD_CHANNELGROUP *channelgroup)
{
  if ( channelgroup )
    return FMOD::ChannelGroup::release((FMOD::ChannelGroup *const)channelgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcf50 | Name: FMOD_ChannelGroup_AddGroup
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_AddGroup(
        FMOD_CHANNELGROUP *channelgroup,
        FMOD_CHANNELGROUP *group,
        FMOD_BOOL propagatedspclock,
        FMOD_DSPCONNECTION **connection)
{
  if ( channelgroup )
    return FMOD::ChannelGroup::addGroup(
             (FMOD::ChannelGroup *const)channelgroup,
             (FMOD::ChannelGroup *)group,
             propagatedspclock != 0,
             (FMOD::DSPConnection **)connection);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcf70 | Name: FMOD_ChannelGroup_GetNumGroups
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetNumGroups(FMOD_CHANNELGROUP *channelgroup, int *numgroups)
{
  if ( channelgroup )
    return FMOD::ChannelGroup::getNumGroups((FMOD::ChannelGroup *const)channelgroup, numgroups);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcf90 | Name: FMOD_ChannelGroup_GetGroup
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetGroup(
        FMOD_CHANNELGROUP *channelgroup,
        int index,
        FMOD_CHANNELGROUP **group)
{
  if ( channelgroup )
    return FMOD::ChannelGroup::getGroup((FMOD::ChannelGroup *const)channelgroup, index, (FMOD::ChannelGroup **)group);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcfb0 | Name: FMOD_ChannelGroup_GetParentGroup
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetParentGroup(FMOD_CHANNELGROUP *channelgroup, FMOD_CHANNELGROUP **group)
{
  if ( channelgroup )
    return FMOD::ChannelGroup::getParentGroup((FMOD::ChannelGroup *const)channelgroup, (FMOD::ChannelGroup **)group);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcfd0 | Name: FMOD_ChannelGroup_GetName
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetName(FMOD_CHANNELGROUP *channelgroup, char *name, int namelen)
{
  if ( channelgroup )
    return FMOD::ChannelGroup::getName((FMOD::ChannelGroup *const)channelgroup, name, namelen);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fcff0 | Name: FMOD_ChannelGroup_GetNumChannels
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetNumChannels(FMOD_CHANNELGROUP *channelgroup, int *numchannels)
{
  if ( channelgroup )
    return FMOD::ChannelGroup::getNumChannels((FMOD::ChannelGroup *const)channelgroup, numchannels);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd010 | Name: FMOD_ChannelGroup_GetChannel
FMOD_RESULT_0 __fastcall FMOD_ChannelGroup_GetChannel(
        FMOD_CHANNELGROUP *channelgroup,
        int index,
        FMOD_CHANNEL **channel)
{
  if ( channelgroup )
    return FMOD::ChannelGroup::getChannel((FMOD::ChannelGroup *const)channelgroup, index, (FMOD::Channel **)channel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd030 | Name: FMOD_SoundGroup_Release
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_Release(FMOD_SOUNDGROUP *soundgroup)
{
  if ( soundgroup )
    return FMOD::SoundGroup::release((FMOD::SoundGroup *const)soundgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd050 | Name: FMOD_SoundGroup_GetSystemObject
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_GetSystemObject(FMOD_SOUNDGROUP *soundgroup, FMOD_SYSTEM **system)
{
  if ( soundgroup )
    return FMOD::SoundGroup::getSystemObject((FMOD::SoundGroup *const)soundgroup, (FMOD::System **)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd070 | Name: FMOD_SoundGroup_SetMaxAudible
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_SetMaxAudible(FMOD_SOUNDGROUP *soundgroup, int maxaudible)
{
  if ( soundgroup )
    return FMOD::SoundGroup::setMaxAudible((FMOD::SoundGroup *const)soundgroup, maxaudible);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd090 | Name: FMOD_SoundGroup_GetMaxAudible
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_GetMaxAudible(FMOD_SOUNDGROUP *soundgroup, int *maxaudible)
{
  if ( soundgroup )
    return FMOD::SoundGroup::getMaxAudible((FMOD::SoundGroup *const)soundgroup, maxaudible);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd0b0 | Name: FMOD_SoundGroup_SetMaxAudibleBehavior
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_SetMaxAudibleBehavior(
        FMOD_SOUNDGROUP *soundgroup,
        FMOD_SOUNDGROUP_BEHAVIOR behavior)
{
  if ( soundgroup )
    return FMOD::SoundGroup::setMaxAudibleBehavior((FMOD::SoundGroup *const)soundgroup, behavior);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd0d0 | Name: FMOD_SoundGroup_GetMaxAudibleBehavior
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_GetMaxAudibleBehavior(
        FMOD_SOUNDGROUP *soundgroup,
        FMOD_SOUNDGROUP_BEHAVIOR *behavior)
{
  if ( soundgroup )
    return FMOD::SoundGroup::getMaxAudibleBehavior((FMOD::SoundGroup *const)soundgroup, behavior);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd0f0 | Name: FMOD_SoundGroup_SetMuteFadeSpeed
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_SetMuteFadeSpeed(FMOD::SoundGroup *soundgroup, double a2, float speed)
{
  if ( soundgroup )
    return FMOD::SoundGroup::setMuteFadeSpeed(soundgroup, speed);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd110 | Name: FMOD_SoundGroup_GetMuteFadeSpeed
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_GetMuteFadeSpeed(FMOD_SOUNDGROUP *soundgroup, float *speed)
{
  if ( soundgroup )
    return FMOD::SoundGroup::getMuteFadeSpeed((FMOD::SoundGroup *const)soundgroup, speed);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd130 | Name: FMOD_SoundGroup_SetVolume
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_SetVolume(FMOD::SoundGroup *soundgroup, double a2, float volume)
{
  if ( soundgroup )
    return FMOD::SoundGroup::setVolume(soundgroup, volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd150 | Name: FMOD_SoundGroup_GetVolume
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_GetVolume(FMOD_SOUNDGROUP *soundgroup, float *volume)
{
  if ( soundgroup )
    return FMOD::SoundGroup::getVolume((FMOD::SoundGroup *const)soundgroup, volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd170 | Name: FMOD_SoundGroup_Stop
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_Stop(FMOD_SOUNDGROUP *soundgroup)
{
  if ( soundgroup )
    return FMOD::SoundGroup::stop((FMOD::SoundGroup *const)soundgroup);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd190 | Name: FMOD_SoundGroup_GetName
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_GetName(FMOD_SOUNDGROUP *soundgroup, char *name, int namelen)
{
  if ( soundgroup )
    return FMOD::SoundGroup::getName((FMOD::SoundGroup *const)soundgroup, name, namelen);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd1b0 | Name: FMOD_SoundGroup_GetNumSounds
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_GetNumSounds(FMOD_SOUNDGROUP *soundgroup, int *numsounds)
{
  if ( soundgroup )
    return FMOD::SoundGroup::getNumSounds((FMOD::SoundGroup *const)soundgroup, numsounds);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd1d0 | Name: FMOD_SoundGroup_GetSound
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_GetSound(FMOD_SOUNDGROUP *soundgroup, int index, FMOD_SOUND **sound)
{
  if ( soundgroup )
    return FMOD::SoundGroup::getSound((FMOD::SoundGroup *const)soundgroup, index, (FMOD::Sound **)sound);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd1f0 | Name: FMOD_SoundGroup_GetNumPlaying
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_GetNumPlaying(FMOD_SOUNDGROUP *soundgroup, int *numplaying)
{
  if ( soundgroup )
    return FMOD::SoundGroup::getNumPlaying((FMOD::SoundGroup *const)soundgroup, numplaying);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd210 | Name: FMOD_SoundGroup_SetUserData
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_SetUserData(FMOD_SOUNDGROUP *soundgroup, void *userdata)
{
  if ( soundgroup )
    return FMOD::SoundGroup::setUserData((FMOD::SoundGroup *const)soundgroup, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd230 | Name: FMOD_SoundGroup_GetUserData
FMOD_RESULT_0 __fastcall FMOD_SoundGroup_GetUserData(FMOD_SOUNDGROUP *soundgroup, void **userdata)
{
  if ( soundgroup )
    return FMOD::SoundGroup::getUserData((FMOD::SoundGroup *const)soundgroup, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd250 | Name: FMOD_DSP_Release
FMOD_RESULT_0 __fastcall FMOD_DSP_Release(FMOD_DSP *dsp)
{
  if ( dsp )
    return FMOD::DSP::release((FMOD::DSP *const)dsp);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd270 | Name: FMOD_DSP_GetSystemObject
FMOD_RESULT_0 __fastcall FMOD_DSP_GetSystemObject(FMOD_DSP *dsp, FMOD_SYSTEM **system)
{
  if ( dsp )
    return FMOD::DSP::getSystemObject((FMOD::DSP *const)dsp, (FMOD::System **)system);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd290 | Name: FMOD_DSP_AddInput
FMOD_RESULT_0 __fastcall FMOD_DSP_AddInput(
        FMOD_DSP *dsp,
        FMOD_DSP *input,
        FMOD_DSPCONNECTION **connection,
        FMOD_DSPCONNECTION_TYPE_0 type)
{
  if ( dsp )
    return FMOD::DSP::addInput((FMOD::DSP *const)dsp, (FMOD::DSP *)input, (FMOD::DSPConnection **)connection, type);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd2b0 | Name: FMOD_DSP_DisconnectFrom
FMOD_RESULT_0 __fastcall FMOD_DSP_DisconnectFrom(FMOD_DSP *dsp, FMOD_DSP *target, FMOD_DSPCONNECTION *connection)
{
  if ( dsp )
    return FMOD::DSP::disconnectFrom((FMOD::DSP *const)dsp, (FMOD::DSP *)target, (FMOD::DSPConnection *)connection);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd2d0 | Name: FMOD_DSP_DisconnectAll
FMOD_RESULT_0 __fastcall FMOD_DSP_DisconnectAll(FMOD_DSP *dsp, FMOD_BOOL inputs, FMOD_BOOL outputs)
{
  if ( dsp )
    return FMOD::DSP::disconnectAll((FMOD::DSP *const)dsp, inputs != 0, outputs != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd300 | Name: FMOD_DSP_GetNumInputs
FMOD_RESULT_0 __fastcall FMOD_DSP_GetNumInputs(FMOD_DSP *dsp, int *numinputs)
{
  if ( dsp )
    return FMOD::DSP::getNumInputs((FMOD::DSP *const)dsp, numinputs);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd320 | Name: FMOD_DSP_GetNumOutputs
FMOD_RESULT_0 __fastcall FMOD_DSP_GetNumOutputs(FMOD_DSP *dsp, int *numoutputs)
{
  if ( dsp )
    return FMOD::DSP::getNumOutputs((FMOD::DSP *const)dsp, numoutputs);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd340 | Name: FMOD_DSP_GetInput
FMOD_RESULT_0 __fastcall FMOD_DSP_GetInput(
        FMOD_DSP *dsp,
        int index,
        FMOD_DSP **input,
        FMOD_DSPCONNECTION **inputconnection)
{
  if ( dsp )
    return FMOD::DSP::getInput(
             (FMOD::DSP *const)dsp,
             index,
             (FMOD::DSP **)input,
             (FMOD::DSPConnection **)inputconnection);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd360 | Name: FMOD_DSP_GetOutput
FMOD_RESULT_0 __fastcall FMOD_DSP_GetOutput(
        FMOD_DSP *dsp,
        int index,
        FMOD_DSP **output,
        FMOD_DSPCONNECTION **outputconnection)
{
  if ( dsp )
    return FMOD::DSP::getOutput(
             (FMOD::DSP *const)dsp,
             index,
             (FMOD::DSP **)output,
             (FMOD::DSPConnection **)outputconnection);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd380 | Name: FMOD_DSP_SetActive
FMOD_RESULT_0 __fastcall FMOD_DSP_SetActive(FMOD_DSP *dsp, FMOD_BOOL active)
{
  if ( dsp )
    return FMOD::DSP::setActive((FMOD::DSP *const)dsp, active != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd3a0 | Name: FMOD_DSP_GetActive
FMOD_RESULT_0 __fastcall FMOD_DSP_GetActive(FMOD_DSP *dsp, FMOD_BOOL *active)
{
  FMOD_RESULT_0 result; // eax
  bool active2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp )
  {
    result = FMOD::DSP::getActive((FMOD::DSP *const)dsp, &active2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( active )
        *active = active2;
    }
  }
  return result;
}


// Address: 0x21fd3e0 | Name: FMOD_DSP_SetBypass
FMOD_RESULT_0 __fastcall FMOD_DSP_SetBypass(FMOD_DSP *dsp, FMOD_BOOL bypass)
{
  if ( dsp )
    return FMOD::DSP::setBypass((FMOD::DSP *const)dsp, bypass != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd400 | Name: FMOD_DSP_GetBypass
FMOD_RESULT_0 __fastcall FMOD_DSP_GetBypass(FMOD_DSP *dsp, FMOD_BOOL *bypass)
{
  FMOD_RESULT_0 result; // eax
  bool bypass2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp )
  {
    result = FMOD::DSP::getBypass((FMOD::DSP *const)dsp, &bypass2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( bypass )
        *bypass = bypass2;
    }
  }
  return result;
}


// Address: 0x21fd440 | Name: FMOD_DSP_SetWetDryMix
FMOD_RESULT_0 __fastcall FMOD_DSP_SetWetDryMix(FMOD::DSP *dsp, double a2, float prewet, float postwet, float dry)
{
  if ( dsp )
    return FMOD::DSP::setWetDryMix(dsp, prewet, postwet, dry);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd460 | Name: FMOD_DSP_GetWetDryMix
FMOD_RESULT_0 __fastcall FMOD_DSP_GetWetDryMix(FMOD_DSP *dsp, float *prewet, float *postwet, float *dry)
{
  if ( dsp )
    return FMOD::DSP::getWetDryMix((FMOD::DSP *const)dsp, prewet, postwet, dry);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd480 | Name: FMOD_DSP_SetChannelFormat
FMOD_RESULT_0 __fastcall FMOD_DSP_SetChannelFormat(
        FMOD_DSP *dsp,
        FMOD_CHANNELMASK channelmask,
        int numchannels,
        FMOD_SPEAKERMODE_0 source_speakermode)
{
  if ( dsp )
    return FMOD::DSP::setChannelFormat((FMOD::DSP *const)dsp, channelmask, numchannels, source_speakermode);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd4a0 | Name: FMOD_DSP_GetChannelFormat
FMOD_RESULT_0 __fastcall FMOD_DSP_GetChannelFormat(
        FMOD_DSP *dsp,
        FMOD_CHANNELMASK *channelmask,
        int *numchannels,
        FMOD_SPEAKERMODE_0 *source_speakermode)
{
  if ( dsp )
    return FMOD::DSP::getChannelFormat((FMOD::DSP *const)dsp, channelmask, numchannels, source_speakermode);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd4c0 | Name: FMOD_DSP_GetOutputChannelFormat
FMOD_RESULT_0 __fastcall FMOD_DSP_GetOutputChannelFormat(
        FMOD_DSP *dsp,
        FMOD_CHANNELMASK inmask,
        int inchannels,
        FMOD_SPEAKERMODE_0 inspeakermode,
        FMOD_CHANNELMASK *outmask,
        int *outchannels,
        FMOD_SPEAKERMODE_0 *outspeakermode)
{
  if ( dsp )
    return FMOD::DSP::getOutputChannelFormat(
             (FMOD::DSP *const)dsp,
             inmask,
             inchannels,
             inspeakermode,
             outmask,
             outchannels,
             outspeakermode);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd4e0 | Name: FMOD_DSP_Reset
FMOD_RESULT_0 __fastcall FMOD_DSP_Reset(FMOD_DSP *dsp)
{
  if ( dsp )
    return FMOD::DSP::reset((FMOD::DSP *const)dsp);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd500 | Name: FMOD_DSP_SetParameterFloat
FMOD_RESULT_0 __fastcall FMOD_DSP_SetParameterFloat(FMOD::DSP *dsp, int index, double a3, float value)
{
  if ( dsp )
    return FMOD::DSP::setParameterFloat(dsp, index, value);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd520 | Name: FMOD_DSP_SetParameterInt
FMOD_RESULT_0 __fastcall FMOD_DSP_SetParameterInt(FMOD_DSP *dsp, int index, int value)
{
  if ( dsp )
    return FMOD::DSP::setParameterInt((FMOD::DSP *const)dsp, index, value);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd540 | Name: FMOD_DSP_SetParameterBool
FMOD_RESULT_0 __fastcall FMOD_DSP_SetParameterBool(FMOD_DSP *dsp, int index, FMOD_BOOL value)
{
  if ( dsp )
    return FMOD::DSP::setParameterBool((FMOD::DSP *const)dsp, index, value != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd560 | Name: FMOD_DSP_SetParameterData
FMOD_RESULT_0 __fastcall FMOD_DSP_SetParameterData(FMOD_DSP *dsp, int index, void *data, unsigned int length)
{
  if ( dsp )
    return FMOD::DSP::setParameterData((FMOD::DSP *const)dsp, index, data, length);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd580 | Name: FMOD_DSP_GetParameterFloat
FMOD_RESULT_0 __fastcall FMOD_DSP_GetParameterFloat(
        FMOD_DSP *dsp,
        int index,
        float *value,
        char *valuestr,
        int valuestrlen)
{
  if ( dsp )
    return FMOD::DSP::getParameterFloat((FMOD::DSP *const)dsp, index, value, valuestr, valuestrlen);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd5a0 | Name: FMOD_DSP_GetParameterInt
FMOD_RESULT_0 __fastcall FMOD_DSP_GetParameterInt(
        FMOD_DSP *dsp,
        int index,
        int *value,
        char *valuestr,
        int valuestrlen)
{
  if ( dsp )
    return FMOD::DSP::getParameterInt((FMOD::DSP *const)dsp, index, value, valuestr, valuestrlen);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd5c0 | Name: FMOD_DSP_GetParameterBool
FMOD_RESULT_0 __fastcall FMOD_DSP_GetParameterBool(
        FMOD_DSP *dsp,
        int index,
        FMOD_BOOL *value,
        char *valuestr,
        int valuestrlen)
{
  FMOD_RESULT_0 result; // eax
  bool value2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp )
  {
    result = FMOD::DSP::getParameterBool((FMOD::DSP *const)dsp, index, &value2, valuestr, valuestrlen);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( value )
        *value = value2;
    }
  }
  return result;
}


// Address: 0x21fd600 | Name: FMOD_DSP_GetParameterData
FMOD_RESULT_0 __fastcall FMOD_DSP_GetParameterData(
        FMOD_DSP *dsp,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr,
        int valuestrlen)
{
  if ( dsp )
    return FMOD::DSP::getParameterData((FMOD::DSP *const)dsp, index, data, length, valuestr, valuestrlen);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd620 | Name: FMOD_DSP_GetNumParameters
FMOD_RESULT_0 __fastcall FMOD_DSP_GetNumParameters(FMOD_DSP *dsp, int *numparams)
{
  if ( dsp )
    return FMOD::DSP::getNumParameters((FMOD::DSP *const)dsp, numparams);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd640 | Name: FMOD_DSP_GetParameterInfo
FMOD_RESULT_0 __fastcall FMOD_DSP_GetParameterInfo(FMOD_DSP *dsp, int index, FMOD_DSP_PARAMETER_DESC **desc)
{
  if ( dsp )
    return FMOD::DSP::getParameterInfo((FMOD::DSP *const)dsp, index, desc);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd660 | Name: FMOD_DSP_GetDataParameterIndex
FMOD_RESULT_0 __fastcall FMOD_DSP_GetDataParameterIndex(FMOD_DSP *dsp, int datatype, int *index)
{
  if ( dsp )
    return FMOD::DSP::getDataParameterIndex((FMOD::DSP *const)dsp, datatype, index);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd680 | Name: FMOD_DSP_ShowConfigDialog
FMOD_RESULT_0 __fastcall FMOD_DSP_ShowConfigDialog(FMOD_DSP *dsp, void *hwnd, FMOD_BOOL show)
{
  if ( dsp )
    return FMOD::DSP::showConfigDialog((FMOD::DSP *const)dsp, hwnd, show != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd6a0 | Name: FMOD_DSP_GetInfo
FMOD_RESULT_0 __fastcall FMOD_DSP_GetInfo(
        FMOD_DSP *dsp,
        char *name,
        unsigned int *version,
        int *channels,
        int *configwidth,
        int *configheight)
{
  if ( dsp )
    return FMOD::DSP::getInfo((FMOD::DSP *const)dsp, name, version, channels, configwidth, configheight);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd6c0 | Name: FMOD_DSP_GetType
__int64 __fastcall FMOD_DSP_GetType(FMOD::DSP *a1, FMOD_DSP_TYPE *a2)
{
  if ( a1 )
    return FMOD::DSP::getType(a1, a2);
  else
    return 31;
}


// Address: 0x21fd6e0 | Name: FMOD_DSP_GetIdle
FMOD_RESULT_0 __fastcall FMOD_DSP_GetIdle(FMOD_DSP *dsp, FMOD_BOOL *idle)
{
  FMOD_RESULT_0 result; // eax
  bool idle2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp )
  {
    result = FMOD::DSP::getIdle((FMOD::DSP *const)dsp, &idle2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( idle )
        *idle = idle2;
    }
  }
  return result;
}


// Address: 0x21fd720 | Name: FMOD_DSP_SetUserData
FMOD_RESULT_0 __fastcall FMOD_DSP_SetUserData(FMOD_DSP *dsp, void *userdata)
{
  if ( dsp )
    return FMOD::DSP::setUserData((FMOD::DSP *const)dsp, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd740 | Name: FMOD_DSP_GetUserData
FMOD_RESULT_0 __fastcall FMOD_DSP_GetUserData(FMOD_DSP *dsp, void **userdata)
{
  if ( dsp )
    return FMOD::DSP::getUserData((FMOD::DSP *const)dsp, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd760 | Name: FMOD_DSP_SetMeteringEnabled
FMOD_RESULT_0 __fastcall FMOD_DSP_SetMeteringEnabled(FMOD_DSP *dsp, FMOD_BOOL inputEnabled, FMOD_BOOL outputEnabled)
{
  if ( dsp )
    return FMOD::DSP::setMeteringEnabled((FMOD::DSP *const)dsp, inputEnabled != 0, outputEnabled != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd790 | Name: FMOD_DSP_GetMeteringEnabled
FMOD_RESULT_0 __fastcall FMOD_DSP_GetMeteringEnabled(FMOD_DSP *dsp, FMOD_BOOL *inputEnabled, FMOD_BOOL *outputEnabled)
{
  FMOD_RESULT_0 result; // eax
  bool inputEnabled2; // [rsp+0h] [rbp-1Ah] BYREF
  bool outputEnabled2; // [rsp+1h] [rbp-19h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp )
  {
    result = FMOD::DSP::getMeteringEnabled((FMOD::DSP *const)dsp, &inputEnabled2, &outputEnabled2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( inputEnabled )
        *inputEnabled = inputEnabled2;
      if ( outputEnabled )
        *outputEnabled = outputEnabled2;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21fd7f0 | Name: FMOD_DSP_GetMeteringInfo
FMOD_RESULT_0 __fastcall FMOD_DSP_GetMeteringInfo(
        FMOD_DSP *dsp,
        FMOD_DSP_METERING_INFO_0 *inputInfo,
        FMOD_DSP_METERING_INFO_0 *outputInfo)
{
  if ( dsp )
    return FMOD::DSP::getMeteringInfo((FMOD::DSP *const)dsp, inputInfo, outputInfo);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd810 | Name: FMOD_DSP_GetCPUUsage
FMOD_RESULT_0 __fastcall FMOD_DSP_GetCPUUsage(FMOD_DSP *dsp, unsigned int *exclusive, unsigned int *inclusive)
{
  if ( dsp )
    return FMOD::DSP::getCPUUsage((FMOD::DSP *const)dsp, exclusive, inclusive);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd830 | Name: FMOD_DSPConnection_GetInput
FMOD_RESULT_0 __fastcall FMOD_DSPConnection_GetInput(FMOD_DSPCONNECTION *dspconnection, FMOD_DSP **input)
{
  if ( dspconnection )
    return FMOD::DSPConnection::getInput((FMOD::DSPConnection *const)dspconnection, (FMOD::DSP **)input);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd850 | Name: FMOD_DSPConnection_GetOutput
FMOD_RESULT_0 __fastcall FMOD_DSPConnection_GetOutput(FMOD_DSPCONNECTION *dspconnection, FMOD_DSP **output)
{
  if ( dspconnection )
    return FMOD::DSPConnection::getOutput((FMOD::DSPConnection *const)dspconnection, (FMOD::DSP **)output);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd870 | Name: FMOD_DSPConnection_SetMix
FMOD_RESULT_0 __fastcall FMOD_DSPConnection_SetMix(FMOD::DSPConnection *dspconnection, double a2, float volume)
{
  if ( dspconnection )
    return FMOD::DSPConnection::setMix(dspconnection, volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd890 | Name: FMOD_DSPConnection_GetMix
FMOD_RESULT_0 __fastcall FMOD_DSPConnection_GetMix(FMOD_DSPCONNECTION *dspconnection, float *volume)
{
  if ( dspconnection )
    return FMOD::DSPConnection::getMix((FMOD::DSPConnection *const)dspconnection, volume);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd8b0 | Name: FMOD_DSPConnection_SetMixMatrix
FMOD_RESULT_0 __fastcall FMOD_DSPConnection_SetMixMatrix(
        FMOD_DSPCONNECTION *dspconnection,
        float *matrix,
        int outchannels,
        int inchannels,
        int inchannel_hop)
{
  if ( dspconnection )
    return FMOD::DSPConnection::setMixMatrix(
             (FMOD::DSPConnection *const)dspconnection,
             matrix,
             outchannels,
             inchannels,
             inchannel_hop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd8d0 | Name: FMOD_DSPConnection_GetMixMatrix
FMOD_RESULT_0 __fastcall FMOD_DSPConnection_GetMixMatrix(
        FMOD_DSPCONNECTION *dspconnection,
        float *matrix,
        int *outchannels,
        int *inchannels,
        int inchannel_hop)
{
  if ( dspconnection )
    return FMOD::DSPConnection::getMixMatrix(
             (FMOD::DSPConnection *const)dspconnection,
             matrix,
             outchannels,
             inchannels,
             inchannel_hop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd8f0 | Name: FMOD_DSPConnection_GetType
FMOD_RESULT_0 __fastcall FMOD_DSPConnection_GetType(FMOD_DSPCONNECTION *dspconnection, FMOD_DSPCONNECTION_TYPE_0 *type)
{
  if ( dspconnection )
    return FMOD::DSPConnection::getType((FMOD::DSPConnection *const)dspconnection, type);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd910 | Name: FMOD_DSPConnection_SetUserData
FMOD_RESULT_0 __fastcall FMOD_DSPConnection_SetUserData(FMOD_DSPCONNECTION *dspconnection, void *userdata)
{
  if ( dspconnection )
    return FMOD::DSPConnection::setUserData((FMOD::DSPConnection *const)dspconnection, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd930 | Name: FMOD_DSPConnection_GetUserData
FMOD_RESULT_0 __fastcall FMOD_DSPConnection_GetUserData(FMOD_DSPCONNECTION *dspconnection, void **userdata)
{
  if ( dspconnection )
    return FMOD::DSPConnection::getUserData((FMOD::DSPConnection *const)dspconnection, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd950 | Name: FMOD_Geometry_Release
FMOD_RESULT_0 __fastcall FMOD_Geometry_Release(FMOD_GEOMETRY *geometry)
{
  if ( geometry )
    return FMOD::Geometry::release((FMOD::Geometry *const)geometry);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd970 | Name: FMOD_Geometry_AddPolygon
FMOD_RESULT_0 __fastcall FMOD_Geometry_AddPolygon(
        FMOD::Geometry *geometry,
        float directocclusion,
        float reverbocclusion,
        FMOD_BOOL doublesided,
        int numvertices,
        const FMOD_VECTOR *vertices,
        int *polygonindex)
{
  if ( geometry )
    return FMOD::Geometry::addPolygon(
             geometry,
             directocclusion,
             reverbocclusion,
             doublesided != 0,
             numvertices,
             vertices,
             polygonindex);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd990 | Name: FMOD_Geometry_GetNumPolygons
FMOD_RESULT_0 __fastcall FMOD_Geometry_GetNumPolygons(FMOD_GEOMETRY *geometry, int *numpolygons)
{
  if ( geometry )
    return FMOD::Geometry::getNumPolygons((FMOD::Geometry *const)geometry, numpolygons);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd9b0 | Name: FMOD_Geometry_GetMaxPolygons
FMOD_RESULT_0 __fastcall FMOD_Geometry_GetMaxPolygons(FMOD_GEOMETRY *geometry, int *maxpolygons, int *maxvertices)
{
  if ( geometry )
    return FMOD::Geometry::getMaxPolygons((FMOD::Geometry *const)geometry, maxpolygons, maxvertices);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd9d0 | Name: FMOD_Geometry_GetPolygonNumVertices
FMOD_RESULT_0 __fastcall FMOD_Geometry_GetPolygonNumVertices(FMOD_GEOMETRY *geometry, int index, int *numvertices)
{
  if ( geometry )
    return FMOD::Geometry::getPolygonNumVertices((FMOD::Geometry *const)geometry, index, numvertices);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fd9f0 | Name: FMOD_Geometry_SetPolygonVertex
FMOD_RESULT_0 __fastcall FMOD_Geometry_SetPolygonVertex(
        FMOD_GEOMETRY *geometry,
        int index,
        int vertexindex,
        const FMOD_VECTOR *vertex)
{
  if ( geometry )
    return FMOD::Geometry::setPolygonVertex((FMOD::Geometry *const)geometry, index, vertexindex, vertex);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fda10 | Name: FMOD_Geometry_GetPolygonVertex
FMOD_RESULT_0 __fastcall FMOD_Geometry_GetPolygonVertex(
        FMOD_GEOMETRY *geometry,
        int index,
        int vertexindex,
        FMOD_VECTOR *vertex)
{
  if ( geometry )
    return FMOD::Geometry::getPolygonVertex((FMOD::Geometry *const)geometry, index, vertexindex, vertex);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fda30 | Name: FMOD_Geometry_SetPolygonAttributes
FMOD_RESULT_0 __fastcall FMOD_Geometry_SetPolygonAttributes(
        FMOD::Geometry *geometry,
        int index,
        float directocclusion,
        float reverbocclusion,
        FMOD_BOOL doublesided)
{
  if ( geometry )
    return FMOD::Geometry::setPolygonAttributes(geometry, index, directocclusion, reverbocclusion, doublesided != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fda50 | Name: FMOD_Geometry_GetPolygonAttributes
FMOD_RESULT_0 __fastcall FMOD_Geometry_GetPolygonAttributes(
        FMOD_GEOMETRY *geometry,
        int index,
        float *directocclusion,
        float *reverbocclusion,
        FMOD_BOOL *doublesided)
{
  FMOD_RESULT_0 result; // eax
  bool doublesided2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( geometry )
  {
    result = FMOD::Geometry::getPolygonAttributes(
               (FMOD::Geometry *const)geometry,
               index,
               directocclusion,
               reverbocclusion,
               &doublesided2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( doublesided )
        *doublesided = doublesided2;
    }
  }
  return result;
}


// Address: 0x21fda90 | Name: FMOD_Geometry_SetActive
FMOD_RESULT_0 __fastcall FMOD_Geometry_SetActive(FMOD_GEOMETRY *geometry, FMOD_BOOL active)
{
  if ( geometry )
    return FMOD::Geometry::setActive((FMOD::Geometry *const)geometry, active != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdab0 | Name: FMOD_Geometry_GetActive
FMOD_RESULT_0 __fastcall FMOD_Geometry_GetActive(FMOD_GEOMETRY *geometry, FMOD_BOOL *active)
{
  FMOD_RESULT_0 result; // eax
  bool active2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( geometry )
  {
    result = FMOD::Geometry::getActive((FMOD::Geometry *const)geometry, &active2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( active )
        *active = active2;
    }
  }
  return result;
}


// Address: 0x21fdaf0 | Name: FMOD_Geometry_SetRotation
FMOD_RESULT_0 __fastcall FMOD_Geometry_SetRotation(
        FMOD_GEOMETRY *geometry,
        const FMOD_VECTOR *forward,
        const FMOD_VECTOR *up)
{
  if ( geometry )
    return FMOD::Geometry::setRotation((FMOD::Geometry *const)geometry, forward, up);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdb10 | Name: FMOD_Geometry_GetRotation
FMOD_RESULT_0 __fastcall FMOD_Geometry_GetRotation(FMOD_GEOMETRY *geometry, FMOD_VECTOR *forward, FMOD_VECTOR *up)
{
  if ( geometry )
    return FMOD::Geometry::getRotation((FMOD::Geometry *const)geometry, forward, up);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdb30 | Name: FMOD_Geometry_SetPosition
FMOD_RESULT_0 __fastcall FMOD_Geometry_SetPosition(FMOD_GEOMETRY *geometry, const FMOD_VECTOR *position)
{
  if ( geometry )
    return FMOD::Geometry::setPosition((FMOD::Geometry *const)geometry, position);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdb50 | Name: FMOD_Geometry_GetPosition
FMOD_RESULT_0 __fastcall FMOD_Geometry_GetPosition(FMOD_GEOMETRY *geometry, FMOD_VECTOR *position)
{
  if ( geometry )
    return FMOD::Geometry::getPosition((FMOD::Geometry *const)geometry, position);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdb70 | Name: FMOD_Geometry_SetScale
FMOD_RESULT_0 __fastcall FMOD_Geometry_SetScale(FMOD_GEOMETRY *geometry, const FMOD_VECTOR *scale)
{
  if ( geometry )
    return FMOD::Geometry::setScale((FMOD::Geometry *const)geometry, scale);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdb90 | Name: FMOD_Geometry_GetScale
FMOD_RESULT_0 __fastcall FMOD_Geometry_GetScale(FMOD_GEOMETRY *geometry, FMOD_VECTOR *scale)
{
  if ( geometry )
    return FMOD::Geometry::getScale((FMOD::Geometry *const)geometry, scale);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdbb0 | Name: FMOD_Geometry_Save
FMOD_RESULT_0 __fastcall FMOD_Geometry_Save(FMOD_GEOMETRY *geometry, void *data, int *datasize)
{
  if ( geometry )
    return FMOD::Geometry::save((FMOD::Geometry *const)geometry, data, datasize);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdbd0 | Name: FMOD_Geometry_SetUserData
FMOD_RESULT_0 __fastcall FMOD_Geometry_SetUserData(FMOD_GEOMETRY *geometry, void *userdata)
{
  if ( geometry )
    return FMOD::Geometry::setUserData((FMOD::Geometry *const)geometry, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdbf0 | Name: FMOD_Geometry_GetUserData
FMOD_RESULT_0 __fastcall FMOD_Geometry_GetUserData(FMOD_GEOMETRY *geometry, void **userdata)
{
  if ( geometry )
    return FMOD::Geometry::getUserData((FMOD::Geometry *const)geometry, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdc10 | Name: FMOD_Reverb3D_Release
FMOD_RESULT_0 __fastcall FMOD_Reverb3D_Release(FMOD_REVERB3D *reverb3d)
{
  if ( reverb3d )
    return FMOD::Reverb3D::release((FMOD::Reverb3D *const)reverb3d);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdc30 | Name: FMOD_Reverb3D_Set3DAttributes
FMOD_RESULT_0 __fastcall FMOD_Reverb3D_Set3DAttributes(
        FMOD::Reverb3D *reverb3d,
        const FMOD_VECTOR *position,
        double a3,
        float mindistance,
        float maxdistance)
{
  if ( reverb3d )
    return FMOD::Reverb3D::set3DAttributes(reverb3d, position, mindistance, maxdistance);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdc50 | Name: FMOD_Reverb3D_Get3DAttributes
FMOD_RESULT_0 __fastcall FMOD_Reverb3D_Get3DAttributes(
        FMOD_REVERB3D *reverb3d,
        FMOD_VECTOR *position,
        float *mindistance,
        float *maxdistance)
{
  if ( reverb3d )
    return FMOD::Reverb3D::get3DAttributes((FMOD::Reverb3D *const)reverb3d, position, mindistance, maxdistance);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdc70 | Name: FMOD_Reverb3D_SetProperties
FMOD_RESULT_0 __fastcall FMOD_Reverb3D_SetProperties(FMOD_REVERB3D *reverb3d, const FMOD_REVERB_PROPERTIES *properties)
{
  if ( reverb3d )
    return FMOD::Reverb3D::setProperties((FMOD::Reverb3D *const)reverb3d, properties);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdc90 | Name: FMOD_Reverb3D_GetProperties
FMOD_RESULT_0 __fastcall FMOD_Reverb3D_GetProperties(FMOD_REVERB3D *reverb3d, FMOD_REVERB_PROPERTIES *properties)
{
  if ( reverb3d )
    return FMOD::Reverb3D::getProperties((FMOD::Reverb3D *const)reverb3d, properties);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdcb0 | Name: FMOD_Reverb3D_SetActive
FMOD_RESULT_0 __fastcall FMOD_Reverb3D_SetActive(FMOD_REVERB3D *reverb3d, FMOD_BOOL active)
{
  if ( reverb3d )
    return FMOD::Reverb3D::setActive((FMOD::Reverb3D *const)reverb3d, active != 0);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdcd0 | Name: FMOD_Reverb3D_GetActive
FMOD_RESULT_0 __fastcall FMOD_Reverb3D_GetActive(FMOD_REVERB3D *reverb3d, FMOD_BOOL *active)
{
  FMOD_RESULT_0 result; // eax
  bool active2; // [rsp+1h] [rbp-9h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( reverb3d )
  {
    result = FMOD::Reverb3D::getActive((FMOD::Reverb3D *const)reverb3d, &active2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( active )
        *active = active2;
    }
  }
  return result;
}


// Address: 0x21fdd10 | Name: FMOD_Reverb3D_SetUserData
FMOD_RESULT_0 __fastcall FMOD_Reverb3D_SetUserData(FMOD_REVERB3D *reverb3d, void *userdata)
{
  if ( reverb3d )
    return FMOD::Reverb3D::setUserData((FMOD::Reverb3D *const)reverb3d, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21fdd30 | Name: FMOD_Reverb3D_GetUserData
FMOD_RESULT_0 __fastcall FMOD_Reverb3D_GetUserData(FMOD_REVERB3D *reverb3d, void **userdata)
{
  if ( reverb3d )
    return FMOD::Reverb3D::getUserData((FMOD::Reverb3D *const)reverb3d, userdata);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


