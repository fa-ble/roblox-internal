// Address: 0x21f1ea0 | Name: _ZN4FMOD8UserFile20mAsyncReadDoneNoWaitEP18FMOD_ASYNCREADINFO11FMOD_RESULT
void __fastcall FMOD::UserFile::mAsyncReadDoneNoWait(FMOD_ASYNCREADINFO *info, FMOD_RESULT_0 result)
{
  HIDWORD(info[1].handle) = result;
}


// Address: 0x21f1eb0 | Name: _ZN4FMOD8UserFile10reallyReadEPvjPj
FMOD_RESULT_0 __fastcall FMOD::UserFile::reallyRead(
        FMOD::UserFile *const this,
        void *buffer,
        unsigned int size,
        unsigned int *rd)
{
  FMOD_FILE_READ_CALLBACK mReadCallback; // rax
  FMOD_RESULT_0 result; // eax
  FMOD_FILE_READ_CALLBACK v6; // r9

  mReadCallback = this->mReadCallback;
  if ( mReadCallback )
  {
    result = mReadCallback(this->mHandle, buffer, size, rd, this->mUserData);
LABEL_3:
    this->mAsyncReadResult = result;
    return result;
  }
  v6 = this->mSystem->mReadCallback;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( !v6 )
    goto LABEL_3;
  result = v6(this->mHandle, buffer, size, rd, this->mUserData);
  this->mAsyncReadResult = result;
  return result;
}


// Address: 0x21f1f40 | Name: _ZN4FMOD8UserFile22mAsyncReadDoneWithWaitEP18FMOD_ASYNCREADINFO11FMOD_RESULT
void __fastcall FMOD::UserFile::mAsyncReadDoneWithWait(FMOD_ASYNCREADINFO *info, FMOD_RESULT_0 result)
{
  FMOD_OS_SEMAPHORE *userdata; // rdi

  HIDWORD(info[1].handle) = result;
  userdata = (FMOD_OS_SEMAPHORE *)info[1].userdata;
  if ( userdata )
    FMOD_OS_Semaphore_Signal(userdata);
}


// Address: 0x21f1f70 | Name: _ZN4FMOD8UserFile11reallyCloseEv
FMOD_RESULT_0 __fastcall FMOD::UserFile::reallyClose(FMOD::UserFile *const this)
{
  FMOD_FILE_CLOSE_CALLBACK mCloseCallback; // rax
  FMOD_OS_SEMAPHORE *mAsyncReadSema; // rdi

  mCloseCallback = this->mCloseCallback;
  if ( mCloseCallback
    || (mCloseCallback = *(FMOD_FILE_CLOSE_CALLBACK *)((char *)&stru_11700.r_offset + (unsigned __int64)this->mSystem)) != 0 )
  {
    mCloseCallback(this->mHandle, this->mUserData);
  }
  mAsyncReadSema = this->mAsyncReadSema;
  if ( mAsyncReadSema )
  {
    FMOD_OS_Semaphore_Free(mAsyncReadSema);
    this->mAsyncReadSema = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f1fd0 | Name: _ZN4FMOD8UserFile15reallyAsyncReadEP18FMOD_ASYNCREADINFOPjb
FMOD_RESULT_0 __fastcall FMOD::UserFile::reallyAsyncRead(
        FMOD::UserFile *const this,
        FMOD_ASYNCREADINFO *info,
        unsigned int *bytesread,
        bool frommainthread)
{
  FMOD_FILE_ASYNCREAD_CALLBACK mAsyncReadCallback; // rax
  FMOD_OS_SEMAPHORE *mAsyncReadSema; // rdi
  FMOD_RESULT_0 result; // eax

  info->handle = this->mHandle;
  mAsyncReadCallback = this->mAsyncReadCallback;
  if ( !mAsyncReadCallback
    && (this->mReadCallback || !*(unsigned __int64 *)((char *)&stru_11718.r_offset + (unsigned __int64)this->mSystem)) )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::UserFile *const, void *, _QWORD, unsigned int *))this->_vptr_File + 7))(
               this,
               info->buffer,
               info->sizebytes,
               &info->bytesread);
    goto LABEL_8;
  }
  this->mAsyncReadResult = FMOD_RESULT::FMOD_ERR_NOTREADY_0;
  if ( frommainthread )
  {
    info->done = FMOD::UserFile::mAsyncReadDoneWithWait;
    if ( mAsyncReadCallback )
      goto LABEL_4;
  }
  else
  {
    info->done = FMOD::UserFile::mAsyncReadDoneNoWait;
    if ( mAsyncReadCallback )
    {
LABEL_4:
      mAsyncReadCallback(info, this->mUserData);
      goto LABEL_5;
    }
  }
  mAsyncReadCallback = *(FMOD_FILE_ASYNCREAD_CALLBACK *)((char *)&stru_11718.r_offset + (unsigned __int64)this->mSystem);
  if ( mAsyncReadCallback )
    goto LABEL_4;
LABEL_5:
  if ( frommainthread )
  {
    mAsyncReadSema = this->mAsyncReadSema;
    if ( mAsyncReadSema )
    {
      FMOD_OS_Semaphore_Wait(mAsyncReadSema);
      result = this->mAsyncReadResult;
    }
    else
    {
      while ( 1 )
      {
        result = this->mAsyncReadResult;
        if ( result != FMOD_RESULT::FMOD_ERR_NOTREADY_0 )
          break;
        if ( this->mExit )
        {
          result = FMOD_RESULT::FMOD_ERR_NOTREADY_0;
          goto LABEL_8;
        }
        FMOD_OS_Time_Sleep(0xAu);
      }
    }
    goto LABEL_8;
  }
  result = FMOD_RESULT::FMOD_ERR_NOTREADY_0;
  if ( this->mAsyncReadResult != FMOD_RESULT::FMOD_ERR_NOTREADY_0 )
  {
    result = this->mAsyncReadResult;
LABEL_8:
    *bytesread = info->bytesread;
  }
  return result;
}


// Address: 0x21f2110 | Name: _ZN4FMOD8UserFile10reallySeekEj
FMOD_RESULT_0 __fastcall FMOD::UserFile::reallySeek(FMOD::UserFile *const this, unsigned int pos)
{
  FMOD_FILE_SEEK_CALLBACK mSeekCallback; // rax

  if ( !this->mAsyncReadCallback
    && (this->mReadCallback || !*(unsigned __int64 *)((char *)&stru_11718.r_offset + (unsigned __int64)this->mSystem))
    && ((mSeekCallback = this->mSeekCallback) != 0 || (mSeekCallback = this->mSystem->mSeekCallback) != 0) )
  {
    return (FMOD_RESULT_0)mSeekCallback(this->mHandle, pos, this->mUserData);
  }
  else
  {
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21f2190 | Name: _ZN4FMOD8UserFile12reallyCancelEP18FMOD_ASYNCREADINFO
FMOD_RESULT_0 __fastcall FMOD::UserFile::reallyCancel(FMOD::UserFile *const this, FMOD_ASYNCREADINFO *info)
{
  FMOD_FILE_ASYNCCANCEL_CALLBACK mAsyncCancelCallback; // rdx

  if ( (this->mAsyncReadCallback
     || !this->mReadCallback && *(unsigned __int64 *)((char *)&stru_11718.r_offset + (unsigned __int64)this->mSystem))
    && info->done
    && ((mAsyncCancelCallback = this->mAsyncCancelCallback) != 0
     || (mAsyncCancelCallback = this->mSystem->mAsyncCancelCallback) != 0) )
  {
    return (FMOD_RESULT_0)mAsyncCancelCallback(info, this->mUserData);
  }
  else
  {
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21f2210 | Name: _ZN4FMOD8UserFile10reallyOpenEPKcPj
FMOD_RESULT_0 __fastcall FMOD::UserFile::reallyOpen(
        FMOD::UserFile *const this,
        const char *name_or_data,
        unsigned int *filesize)
{
  FMOD_FILE_OPEN_CALLBACK mOpenCallback; // rax
  FMOD_RESULT_0 result; // eax
  bool v5; // zf

  mOpenCallback = this->mOpenCallback;
  if ( !mOpenCallback && (mOpenCallback = this->mSystem->mOpenCallback) == 0
    || (result = mOpenCallback(name_or_data, filesize, &this->mHandle, this->mUserData)) == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::UserFile *const, _QWORD))this->_vptr_File + 8))(this, 0);
    if ( result == FMOD_RESULT::FMOD_ERR_FILE_COULDNOTSEEK_0 )
    {
      this->mFlags &= ~1u;
      result = FMOD_RESULT::FMOD_OK_0;
    }
  }
  v5 = this->mAsyncReadCallback == 0;
  this->mAsyncReadSema = 0;
  if ( !v5
    || !this->mReadCallback && *(unsigned __int64 *)((char *)&stru_11718.r_offset + (unsigned __int64)this->mSystem) )
  {
    return FMOD_OS_Semaphore_Create(&this->mAsyncReadSema);
  }
  return result;
}


