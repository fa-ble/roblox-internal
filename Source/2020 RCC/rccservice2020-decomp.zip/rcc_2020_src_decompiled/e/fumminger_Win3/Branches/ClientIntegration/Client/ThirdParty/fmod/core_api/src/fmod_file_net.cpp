// Address: 0x2242940 | Name: _ZN4FMOD7NetFile11getMetadataEPPNS_8MetadataE
FMOD_RESULT_0 __fastcall FMOD::NetFile::getMetadata(FMOD::NetFile *const this, FMOD::Metadata **metadata)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( metadata )
  {
    LOBYTE(result) = 0;
    *metadata = &this->mMetadata;
  }
  return result;
}


// Address: 0x2242990 | Name: _ZN4FMOD7NetFile12reallyCancelEP18FMOD_ASYNCREADINFO
FMOD_RESULT_0 __fastcall FMOD::NetFile::reallyCancel(FMOD::NetFile *const this, FMOD_ASYNCREADINFO *info)
{
  FMOD_OS_Net_Close(this->mHandle);
  this->mHandle = (void *)-1LL;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22429b0 | Name: _ZN4FMOD7NetFile11reallyCloseEv
FMOD_RESULT_0 __fastcall FMOD::NetFile::reallyClose(FMOD::NetFile *const this)
{
  void *mHandle; // rdi
  FMOD_RESULT_0 result; // eax
  char *mMetabuf; // rsi

  mHandle = this->mHandle;
  if ( mHandle == (void *)-1LL
    || (result = FMOD_OS_Net_Close(mHandle), this->mHandle = (void *)-1LL, result == FMOD_RESULT::FMOD_OK_0) )
  {
    mMetabuf = this->mMetabuf;
    if ( mMetabuf )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, mMetabuf, "../../../core_api/src/fmod_file_net.cpp", 724);
      this->mMetabuf = 0;
    }
    return FMOD_Net_Shutdown();
  }
  return result;
}


// Address: 0x2242a20 | Name: _ZN4FMOD7NetFile11chunkedReadEPci
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::NetFile::chunkedRead(FMOD::NetFile *const this, char *buffer, int lengthBytes)
{
  int v3; // ebx
  signed int mBytesLeftInChunk; // ecx
  signed int v7; // r15d
  FMOD_RESULT_0 result; // eax
  bool v9; // zf
  void *mHandle; // rdi
  unsigned int *p_mBytesLeftInChunk; // [rsp+8h] [rbp-140h]
  char temp[264]; // [rsp+10h] [rbp-138h] OVERLAPPED BYREF

  v3 = lengthBytes;
  if ( !lengthBytes )
    return FMOD_RESULT::FMOD_OK_0;
  p_mBytesLeftInChunk = &this->mBytesLeftInChunk;
  while ( 1 )
  {
    mBytesLeftInChunk = this->mBytesLeftInChunk;
    if ( !mBytesLeftInChunk )
    {
      memset(temp, 0, 0x100u);
      mHandle = this->mHandle;
      qmemcpy(temp, "0x", 2);
      result = FMOD_Net_ReadLine(mHandle, &temp[2], 0x100u);
      if ( result )
        return result;
      __isoc99_sscanf(temp, "%x", p_mBytesLeftInChunk);
      mBytesLeftInChunk = this->mBytesLeftInChunk;
      if ( !mBytesLeftInChunk )
        break;
    }
    if ( mBytesLeftInChunk > v3 )
      mBytesLeftInChunk = v3;
    v7 = mBytesLeftInChunk;
    result = FMOD_Net_Read(this->mHandle, buffer, mBytesLeftInChunk);
    if ( result )
      return result;
    v3 -= v7;
    buffer += v7;
    v9 = this->mBytesLeftInChunk == v7;
    this->mBytesLeftInChunk -= v7;
    if ( v9 )
    {
      result = FMOD_Net_ReadLine(this->mHandle, temp, 2u);
      if ( result )
        return result;
      if ( !v3 )
        return FMOD_RESULT::FMOD_OK_0;
    }
    else if ( !v3 )
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
}


// Address: 0x2242b50 | Name: _ZN4FMOD7NetFileC2Ev
void __fastcall FMOD::NetFile::NetFile(FMOD::NetFile *const this)
{
  volatile unsigned int mFlags; // eax

  FMOD::File::File(this);
  this->mMetadata.mList.mNodeData = 0;
  this->mMetadata.mList.mType = FMOD_TAGTYPE::FMOD_TAGTYPE_UNKNOWN;
  this->mMetadata.mList.mDataType = FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_BINARY;
  this->mMetadata.mList.mName = 0;
  this->mMetadata.mList.mData[1] = 0;
  this->mMetadata.mList.mData[0] = 0;
  this->mMetadata.mList.mDataLen = 0;
  this->_vptr_File = (int (**)(...))off_29B29F0;
  this->mMetadata.mList.mUpdated = 1;
  this->mMetadata.mList.mUnique = 0;
  this->mMetadata.mList.mCurrentBuffer = 0;
  this->mMetadata.mList.mNodePrev = &this->mMetadata.mList;
  this->mMetadata.mList.mNodeNext = &this->mMetadata.mList;
  mFlags = this->mFlags;
  this->mHandle = (void *)-1LL;
  this->mAbsolutePos = 0;
  this->mHttpStatus = 0;
  this->mMetaint = 0;
  this->mBytesBeforeMeta = 0;
  this->mMetabuf = 0;
  this->mChunked = 0;
  this->mFlags = mFlags & 0xFFFFFFFE;
  this->mBytesLeftInChunk = 0;
  this->mDeviceType = 3;
}


// Address: 0x2242c50 | Name: _ZN4FMOD7NetFile8parseUrlEPcS1_iS1_iPtS1_iPb
FMOD_RESULT_0 __fastcall FMOD::NetFile::parseUrl(
        FMOD::NetFile *const this,
        char *url,
        char *host,
        int hostlen,
        char *auth,
        int authlen,
        unsigned __int16 *port,
        char *file,
        const int filelen,
        bool *mms)
{
  char *v14; // rbp
  char v15; // dl
  bool v16; // al
  char *v17; // rbx
  char v18; // al
  const char *v19; // rbx
  char v20; // al
  FMOD_RESULT_0 result; // eax
  const char *v22; // rsi
  signed __int64 v23; // rax
  char *v24; // rax
  __int64 v25; // rdx
  const char *v26; // rbx
  char v27; // cl
  __int64 v28; // r8
  const char *v29; // rax
  signed __int64 v30; // rbp
  char v31; // [rsp+8h] [rbp-1440h]
  signed __int64 v32; // [rsp+8h] [rbp-1440h]
  char tmp[1024]; // [rsp+10h] [rbp-1438h] BYREF
  char userpass[4152]; // [rsp+410h] [rbp-1038h] BYREF

  if ( mms )
    *mms = 0;
  if ( FMOD_strnicmp("http://", url, 7) && FMOD_strnicmp("http:\\\\", url, 7) )
  {
    if ( FMOD_strnicmp("https://", url, 8) && FMOD_strnicmp("https:\\\\", url, 8) )
    {
      if ( FMOD_strnicmp("mms://", url, 6) && FMOD_strnicmp("mms:\\\\", url, 6) )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      if ( mms )
        *mms = 1;
      v14 = url + 6;
    }
    else
    {
      v14 = url + 8;
    }
  }
  else
  {
    v14 = url + 7;
  }
  v15 = *v14;
  v16 = *v14 != 0;
  if ( !*v14 || v15 == 47 )
  {
    v31 = 0;
  }
  else
  {
    v17 = v14;
    if ( v15 == 64 )
    {
      v32 = 0;
    }
    else
    {
      do
      {
        v18 = *++v17;
        if ( *v17 == 47 || !v18 )
        {
          v16 = 1;
          v31 = 0;
          goto LABEL_13;
        }
      }
      while ( v18 != 64 );
      v32 = v17 - v14;
    }
    v22 = v14;
    v14 = v17 + 1;
    FMOD_strcpy_safe(userpass, v22, 4096);
    v15 = v17[1];
    v23 = v32;
    v31 = 1;
    userpass[v23] = 0;
    v16 = v15 != 0;
  }
LABEL_13:
  v19 = v14;
  if ( v15 != 58 && v16 && v15 != 47 )
  {
    do
      v20 = *++v19;
    while ( *v19 != 58 && v20 && v20 != 47 );
  }
  if ( FMOD_strlen(v14) >= hostlen )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  FMOD_strcpy_safe(host, v14, hostlen);
  host[v19 - v14] = 0;
  if ( *v19 == 47 || !*v19 )
  {
    *port = 80;
  }
  else
  {
    v24 = (char *)(v19 + 1);
    v25 = 0;
    v26 = v19 + 1025;
    do
    {
      v27 = *v24;
      v28 = (int)v25;
      if ( (unsigned __int8)(*v24 - 48) > 9u )
      {
        v19 = v24;
        goto LABEL_34;
      }
      ++v24;
      tmp[v25++] = v27;
    }
    while ( v24 != v26 );
    v19 = v24;
    v28 = 1024;
LABEL_34:
    tmp[v28] = 0;
    *port = strtol(tmp, 0, 10);
  }
  if ( (*v19 & 0xDF) != 0 && (unsigned __int8)(*v19 - 9) > 1u )
  {
    if ( FMOD_strlen(v19) >= filelen )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    v29 = &v19[FMOD_strlen(v19) - 1];
    if ( v19 < v29 )
    {
      do
      {
        if ( (unsigned __int8)(*v29 - 9) > 1u && *v29 != 32 )
          break;
        --v29;
      }
      while ( v29 != v19 );
    }
    v30 = v29 - v19;
    FMOD_strcpy_safe(file, v19, (_DWORD)v29 - (_DWORD)v19 + 2);
    file[v30 + 1] = 0;
  }
  else
  {
    FMOD_strcpy_safe(file, "/", filelen);
  }
  result = FMOD_RESULT::FMOD_OK_0;
  if ( v31 )
  {
    if ( auth )
      return FMOD_Net_EncodeBase64(userpass, auth, authlen);
  }
  return result;
}


// Address: 0x2242fd0 | Name: _ZN4FMOD7NetFile10openAsHTTPEPKcPcS3_S3_tPjj
FMOD_RESULT_0 __fastcall FMOD::NetFile::openAsHTTP(
        FMOD::NetFile *const this,
        const char *name_or_data,
        char *host,
        char *file,
        char *auth,
        unsigned __int16 port,
        unsigned int *filesize,
        unsigned int offset)
{
  char *v9; // rbx
  FMOD_RESULT_0 result; // eax
  const char *v11; // rdi
  FMOD_RESULT_0 Line; // eax
  void *v13; // rdx
  unsigned int v14; // eax
  int v15; // eax
  int v16; // edx
  bool v17; // zf
  char v18; // r15
  int v19; // eax
  char v20; // cl
  int v21; // eax
  char v22; // cl
  char *v23; // r13
  int v24; // eax
  char *v25; // r13
  int v26; // eax
  volatile unsigned int mFlags; // eax
  int v28; // eax
  int v29; // eax
  unsigned int mMetaint; // eax
  int v31; // eax
  char *v32; // rax
  int v33; // eax
  int v34; // eax
  int v35; // eax
  int v36; // eax
  char *v37; // r13
  int v38; // eax
  int v39; // eax
  char *v40; // r13
  int v41; // eax
  int v42; // eax
  char *v43; // r13
  int v44; // eax
  char *v45; // r13
  int v46; // eax
  char *v47; // r13
  int v48; // eax
  char *v49; // r13
  int v50; // eax
  char *v51; // r13
  int v52; // eax
  char *v53; // r13
  int v54; // eax
  char *v55; // r13
  int v56; // eax
  char *v57; // r13
  int v58; // eax
  FMOD_RESULT_0 tmpa; // [rsp+28h] [rbp-8B0h]
  char tmp; // [rsp+28h] [rbp-8B0h]
  char *tmpb; // [rsp+28h] [rbp-8B0h]
  char *tmpc; // [rsp+28h] [rbp-8B0h]
  char *tmpd; // [rsp+28h] [rbp-8B0h]
  char *tmpe; // [rsp+28h] [rbp-8B0h]
  char *tmpf; // [rsp+28h] [rbp-8B0h]
  char *tmpg; // [rsp+28h] [rbp-8B0h]
  char *tmph; // [rsp+28h] [rbp-8B0h]
  char *tmpi; // [rsp+28h] [rbp-8B0h]
  char *tmpj; // [rsp+28h] [rbp-8B0h]
  int redirect_count; // [rsp+30h] [rbp-8A8h]
  const char *redirect_counta; // [rsp+30h] [rbp-8A8h]
  char *string; // [rsp+38h] [rbp-8A0h]
  char *mAgent; // [rsp+50h] [rbp-888h]
  void **handle; // [rsp+68h] [rbp-870h]
  bool fakeagent; // [rsp+8Fh] [rbp-849h]
  unsigned __int16 new_port; // [rsp+92h] [rbp-846h] BYREF
  unsigned int byteswritten; // [rsp+94h] [rbp-844h] BYREF
  int version; // [rsp+98h] [rbp-840h] BYREF
  int statuscode; // [rsp+9Ch] [rbp-83Ch] BYREF
  char new_host[1024]; // [rsp+A0h] [rbp-838h] BYREF
  char new_file[1080]; // [rsp+4A0h] [rbp-438h] BYREF

  mAgent = this->mAgent;
  sprintf(this->mAgent, "FMODStudio/%x.%02x.%02x", 2, 0, 2);
  v9 = (char *)FMOD::MemPool::alloc(
                 off_286F358->gSystemMemPool,
                 0x2000,
                 "../../../core_api/src/fmod_file_net.cpp",
                 222,
                 0,
                 0);
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v9 )
  {
    fakeagent = 0;
    redirect_count = 0;
    handle = &this->mHandle;
RECONNECT:
    v11 = FMOD_Net_ProxyHostname;
    if ( FMOD_Net_ProxyHostname )
    {
LABEL_4:
      Line = FMOD_OS_Net_Connect(v11, FMOD_Net_ProxyPort, 1, handle);
      if ( Line == FMOD_RESULT::FMOD_OK_0 )
        goto LABEL_5;
    }
    else
    {
      while ( 1 )
      {
        Line = FMOD_OS_Net_Connect(host, port, 1, handle);
        if ( Line )
          goto LABEL_25;
LABEL_5:
        v13 = (void *)name_or_data;
        if ( !FMOD_Net_ProxyHostname )
          v13 = file;
        sprintf(v9, "GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nIcy-MetaData:1\r\n", v13, host, mAgent);
        if ( FMOD_Net_ProxyAuth )
        {
          FMOD_strcat_safe(v9, "Proxy-Authorization: Basic ", 0x2000);
          FMOD_strcat_safe(v9, FMOD_Net_ProxyAuth, 0x2000);
          FMOD_strcat_safe(v9, "\r\n", 0x2000);
        }
        if ( *auth )
        {
          FMOD_strcat_safe(v9, "Authorization: Basic ", 0x2000);
          FMOD_strcat_safe(v9, auth, 0x2000);
          FMOD_strcat_safe(v9, "\r\n", 0x2000);
        }
        if ( offset && (this->mFlags & 0x2000) != 0 )
        {
          sprintf(new_file, "Range: bytes=%d-%d\r\n", offset, this->mFileSize);
          FMOD_strcat_safe(v9, new_file, 0x2000);
        }
        FMOD_strcat_safe(v9, "Connection: close\r\n\r\n", 0x2000);
        byteswritten = 0;
        v14 = FMOD_strlen(v9);
        Line = FMOD_OS_Net_Write(this->mHandle, v9, v14, &byteswritten);
        if ( Line )
          goto LABEL_25;
        Line = FMOD_Net_ReadLine(this->mHandle, v9, 0x1FFFu);
        if ( Line )
          goto LABEL_25;
        v15 = FMOD_strlen(v9);
        Line = FMOD_Net_ParseHTTPStatus(v9, v15, &version, &statuscode);
        if ( Line )
          goto LABEL_25;
        v16 = statuscode;
        v17 = statuscode == 206;
        this->mHttpStatus = statuscode;
        if ( v17 || v16 == 200 )
        {
          string = v9 + 10;
          redirect_counta = v9 + 9;
          do
          {
            if ( FMOD_Net_ReadLine(this->mHandle, v9, 0x1FFFu) )
              break;
            if ( FMOD_strncmp("Content-Length:", v9, 15) )
            {
              if ( FMOD_strncmp("Content-Range: bytes", v9, 20) )
              {
                if ( FMOD_strncmp("Accept-Ranges: bytes", v9, 20) )
                {
                  if ( FMOD_strncmp("Transfer-Encoding: chunked", v9, 26) )
                  {
                    if ( FMOD_strncmp("icy-metaint:", v9, 12) )
                    {
                      if ( FMOD_strncmp("icy-br:", v9, 7) )
                      {
                        if ( FMOD_strncmp("icy-pub:", v9, 8) )
                        {
                          if ( FMOD_strncmp("icy-notice1:", v9, 12) )
                          {
                            if ( FMOD_strncmp("icy-notice2:", v9, 12) )
                            {
                              if ( FMOD_strncmp("icy-name:", v9, 9) )
                              {
                                if ( FMOD_strncmp("icy-genre:", v9, 10) )
                                {
                                  if ( FMOD_strncmp("icy-url:", v9, 8) )
                                  {
                                    if ( FMOD_strncmp("icy-irc:", v9, 8) )
                                    {
                                      if ( FMOD_strncmp("icy-icq:", v9, 8) )
                                      {
                                        if ( !FMOD_strncmp("icy-aim:", v9, 8) )
                                        {
                                          v57 = FMOD_eatwhite(v9 + 8);
                                          v58 = FMOD_strlen(v57);
                                          FMOD::Metadata::addTag(
                                            &this->mMetadata,
                                            FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
                                            "icy-aim",
                                            v57,
                                            v58 + 1,
                                            FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                                            0);
                                        }
                                      }
                                      else
                                      {
                                        v55 = FMOD_eatwhite(v9 + 8);
                                        v56 = FMOD_strlen(v55);
                                        FMOD::Metadata::addTag(
                                          &this->mMetadata,
                                          FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
                                          "icy-icq",
                                          v55,
                                          v56 + 1,
                                          FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                                          0);
                                      }
                                    }
                                    else
                                    {
                                      v53 = FMOD_eatwhite(v9 + 8);
                                      v54 = FMOD_strlen(v53);
                                      FMOD::Metadata::addTag(
                                        &this->mMetadata,
                                        FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
                                        "icy-irc",
                                        v53,
                                        v54 + 1,
                                        FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                                        0);
                                    }
                                  }
                                  else
                                  {
                                    v51 = FMOD_eatwhite(v9 + 8);
                                    v52 = FMOD_strlen(v51);
                                    FMOD::Metadata::addTag(
                                      &this->mMetadata,
                                      FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
                                      "icy-url",
                                      v51,
                                      v52 + 1,
                                      FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                                      0);
                                  }
                                }
                                else
                                {
                                  v49 = FMOD_eatwhite(string);
                                  v50 = FMOD_strlen(v49);
                                  FMOD::Metadata::addTag(
                                    &this->mMetadata,
                                    FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
                                    "icy-genre",
                                    v49,
                                    v50 + 1,
                                    FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                                    0);
                                }
                              }
                              else
                              {
                                v47 = FMOD_eatwhite(redirect_counta);
                                v48 = FMOD_strlen(v47);
                                FMOD::Metadata::addTag(
                                  &this->mMetadata,
                                  FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
                                  "icy-name",
                                  v47,
                                  v48 + 1,
                                  FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                                  0);
                              }
                            }
                            else
                            {
                              v45 = FMOD_eatwhite(v9 + 12);
                              v46 = FMOD_strlen(v45);
                              FMOD::Metadata::addTag(
                                &this->mMetadata,
                                FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
                                "icy-notice2",
                                v45,
                                v46 + 1,
                                FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                                0);
                            }
                          }
                          else
                          {
                            v43 = FMOD_eatwhite(v9 + 12);
                            v44 = FMOD_strlen(v43);
                            FMOD::Metadata::addTag(
                              &this->mMetadata,
                              FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
                              "icy-notice1",
                              v43,
                              v44 + 1,
                              FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                              0);
                          }
                        }
                        else
                        {
                          v40 = FMOD_eatwhite(v9 + 8);
                          v41 = FMOD_strlen(v40);
                          FMOD::Metadata::addTag(
                            &this->mMetadata,
                            FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
                            "icy-pub",
                            v40,
                            v41 + 1,
                            FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                            0);
                        }
                      }
                      else
                      {
                        v37 = FMOD_eatwhite(v9 + 7);
                        v38 = FMOD_strlen(v37);
                        FMOD::Metadata::addTag(
                          &this->mMetadata,
                          FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
                          "icy-br",
                          v37,
                          v38 + 1,
                          FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                          0);
                      }
                    }
                    else
                    {
                      this->mMetaint = strtol(v9 + 12, 0, 10);
                    }
                  }
                  else
                  {
                    this->mChunked = 1;
                  }
                }
                else
                {
                  mFlags = this->mFlags;
                  BYTE1(mFlags) |= 0x20u;
                  this->mFlags = mFlags;
                }
              }
            }
            else if ( filesize )
            {
              *filesize = strtol(v9 + 15, 0, 10);
            }
            if ( FMOD_strncmp("ice-bitrate: ", v9, 13) )
            {
              if ( FMOD_strncmp("ice-description: ", v9, 17) )
              {
                if ( FMOD_strncmp("ice-public: ", v9, 12) )
                {
                  if ( FMOD_strncmp("ice-name: ", v9, 10) )
                  {
                    if ( FMOD_strncmp("ice-genre: ", v9, 11) )
                    {
                      if ( FMOD_strncmp("ice-url: ", v9, 9) )
                      {
                        if ( FMOD_strncmp("ice-irc: ", v9, 9) )
                        {
                          if ( FMOD_strncmp("ice-icq: ", v9, 9) )
                          {
                            if ( FMOD_strncmp("ice-aim: ", v9, 9) )
                            {
                              if ( FMOD_strncmp("ice-audio-info: ", v9, 16) )
                              {
                                if ( !FMOD_strncmp("ice-private: ", v9, 13) )
                                {
                                  tmpj = FMOD_eatwhite(v9 + 13);
                                  v42 = FMOD_strlen(tmpj);
                                  FMOD::Metadata::addTag(
                                    &this->mMetadata,
                                    FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                                    "ice-private",
                                    tmpj,
                                    v42 + 1,
                                    FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                                    0);
                                }
                              }
                              else
                              {
                                tmpi = FMOD_eatwhite(v9 + 16);
                                v39 = FMOD_strlen(tmpi);
                                FMOD::Metadata::addTag(
                                  &this->mMetadata,
                                  FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                                  "ice-audio-info",
                                  tmpi,
                                  v39 + 1,
                                  FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                                  0);
                              }
                            }
                            else
                            {
                              tmph = FMOD_eatwhite(redirect_counta);
                              v36 = FMOD_strlen(tmph);
                              FMOD::Metadata::addTag(
                                &this->mMetadata,
                                FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                                "ice-aim",
                                tmph,
                                v36 + 1,
                                FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                                0);
                            }
                          }
                          else
                          {
                            tmpg = FMOD_eatwhite(redirect_counta);
                            v35 = FMOD_strlen(tmpg);
                            FMOD::Metadata::addTag(
                              &this->mMetadata,
                              FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                              "ice-icq",
                              tmpg,
                              v35 + 1,
                              FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                              0);
                          }
                        }
                        else
                        {
                          tmpf = FMOD_eatwhite(redirect_counta);
                          v34 = FMOD_strlen(tmpf);
                          FMOD::Metadata::addTag(
                            &this->mMetadata,
                            FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                            "ice-irc",
                            tmpf,
                            v34 + 1,
                            FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                            0);
                        }
                      }
                      else
                      {
                        tmpd = FMOD_eatwhite(redirect_counta);
                        v31 = FMOD_strlen(tmpd);
                        FMOD::Metadata::addTag(
                          &this->mMetadata,
                          FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                          "ice-url",
                          tmpd,
                          v31 + 1,
                          FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                          0);
                      }
                    }
                    else
                    {
                      tmpe = FMOD_eatwhite(v9 + 11);
                      v33 = FMOD_strlen(tmpe);
                      FMOD::Metadata::addTag(
                        &this->mMetadata,
                        FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                        "ice-genre",
                        tmpe,
                        v33 + 1,
                        FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                        0);
                    }
                  }
                  else
                  {
                    tmpc = FMOD_eatwhite(string);
                    v29 = FMOD_strlen(tmpc);
                    FMOD::Metadata::addTag(
                      &this->mMetadata,
                      FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                      "ice-name",
                      tmpc,
                      v29 + 1,
                      FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                      0);
                  }
                }
                else
                {
                  tmpb = FMOD_eatwhite(v9 + 12);
                  v28 = FMOD_strlen(tmpb);
                  FMOD::Metadata::addTag(
                    &this->mMetadata,
                    FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                    "ice-public",
                    tmpb,
                    v28 + 1,
                    FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                    0);
                }
              }
              else
              {
                v25 = FMOD_eatwhite(v9 + 17);
                v26 = FMOD_strlen(v25);
                FMOD::Metadata::addTag(
                  &this->mMetadata,
                  FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                  "ice-description",
                  v25,
                  v26 + 1,
                  FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                  0);
              }
            }
            else
            {
              v23 = FMOD_eatwhite(v9 + 13);
              v24 = FMOD_strlen(v23);
              FMOD::Metadata::addTag(
                &this->mMetadata,
                FMOD_TAGTYPE::FMOD_TAGTYPE_ICECAST,
                "ice-bitrate",
                v23,
                v24 + 1,
                FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                0);
            }
          }
          while ( FMOD_strlen(v9) );
          mMetaint = this->mMetaint;
          if ( !mMetaint
            || (this->mBytesBeforeMeta = mMetaint,
                v32 = (char *)FMOD::MemPool::alloc(
                                off_286F358->gSystemMemPool,
                                4081,
                                "../../../core_api/src/fmod_file_net.cpp",
                                611,
                                0,
                                0),
                (this->mMetabuf = v32) != 0) )
          {
            Line = FMOD_RESULT::FMOD_OK_0;
          }
          else
          {
            (*((void (__fastcall **)(FMOD::NetFile *const))this->_vptr_File + 6))(this);
            Line = FMOD_RESULT::FMOD_ERR_MEMORY_0;
          }
          goto LABEL_25;
        }
        if ( (unsigned int)(v16 - 301) <= 2 || (v16 & 0xFFFFFFFD) == 0x131 )
        {
          if ( redirect_count > 15 )
            goto LABEL_58;
          v18 = 0;
          tmp = 0;
          while ( 1 )
          {
LABEL_37:
            if ( FMOD_Net_ReadLine(this->mHandle, v9, 0x1FFFu) )
            {
LABEL_42:
              if ( tmp )
              {
                FMOD_OS_Net_Close(this->mHandle);
                this->mHandle = (void *)-1LL;
                goto RECONNECT;
              }
              if ( v18 )
              {
LABEL_82:
                Line = FMOD_RESULT::FMOD_ERR_HTTP_ACCESS_0;
                goto LABEL_25;
              }
LABEL_58:
              Line = FMOD_RESULT::FMOD_ERR_HTTP_0;
              goto LABEL_25;
            }
            if ( !FMOD_strnicmp("Location: ", v9, 10) )
              break;
            if ( !FMOD_strnicmp("content-security-policy: sandbox", v9, 32) )
              v18 = 1;
            if ( !FMOD_strlen(v9) )
              goto LABEL_42;
          }
          new_file[0] = 0;
          new_host[0] = 0;
          new_port = 0;
          if ( FMOD_strnicmp(v9 + 10, "http://", 7)
            && FMOD_strnicmp(v9 + 10, "https://", 8)
            && FMOD_strnicmp(v9 + 10, "https:\\\\", 8)
            && FMOD_strnicmp(v9 + 10, "http:\\\\", 7) )
          {
            *(_DWORD *)(v9 + 3) = 1886680168;
            *(_WORD *)(v9 + 7) = 12090;
            v9[9] = 47;
            FMOD::NetFile::parseUrl(this, v9 + 3, new_host, 1023, 0, 0, &new_port, new_file, 1023, 0);
          }
          else
          {
            FMOD::NetFile::parseUrl(this, v9 + 10, new_host, 1023, 0, 0, &new_port, new_file, 1023, 0);
          }
          if ( FMOD_strlen(new_host) )
          {
            v19 = FMOD_stricmp(new_host, host);
            v20 = tmp;
            if ( v19 )
              v20 = 1;
            tmp = v20;
            FMOD_strcpy_safe(host, new_host, 1024);
            if ( FMOD_strlen(new_file) )
              goto LABEL_47;
          }
          else
          {
            if ( !FMOD_strlen(new_file) )
              goto LABEL_33;
LABEL_47:
            v21 = FMOD_stricmp(new_file, file);
            v22 = tmp;
            if ( v21 )
              v22 = 1;
            tmp = v22;
            FMOD_strcpy_safe(file, new_file, 1024);
          }
LABEL_33:
          if ( new_port && port != new_port )
          {
            port = new_port;
            tmp = 1;
          }
          ++redirect_count;
          if ( !FMOD_strlen(v9) )
            goto LABEL_42;
          goto LABEL_37;
        }
        if ( v16 != 403 )
          break;
        if ( fakeagent )
          goto LABEL_82;
        strcpy(mAgent, "Winamp");
        FMOD_OS_Net_Close(this->mHandle);
        this->mHandle = (void *)-1LL;
        fakeagent = 1;
        v11 = FMOD_Net_ProxyHostname;
        if ( FMOD_Net_ProxyHostname )
          goto LABEL_4;
      }
      if ( v16 == 407 )
      {
        Line = FMOD_RESULT::FMOD_ERR_HTTP_PROXY_AUTH_0;
      }
      else if ( v16 <= 407 )
      {
        if ( v16 == 401 )
          goto LABEL_82;
        Line = FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0;
        if ( v16 != 404 )
          goto LABEL_58;
      }
      else
      {
        Line = FMOD_RESULT::FMOD_ERR_HTTP_TIMEOUT_0;
        if ( v16 != 408 )
        {
          Line = FMOD_RESULT::FMOD_ERR_HTTP_SERVER_ERROR_0;
          if ( (unsigned int)(v16 - 500) > 5 )
            goto LABEL_58;
        }
      }
    }
LABEL_25:
    tmpa = Line;
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v9, "../../../core_api/src/fmod_autocleanup.h", 190);
    return tmpa;
  }
  return result;
}


// Address: 0x2244010 | Name: _ZN4FMOD7NetFile10reallySeekEj
FMOD_RESULT_0 __fastcall FMOD::NetFile::reallySeek(FMOD::NetFile *const this, unsigned int pos)
{
  FMOD_RESULT_0 result; // eax

  result = (*((unsigned int (__fastcall **)(FMOD::NetFile *const, _QWORD))this->_vptr_File + 9))(this, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::NetFile::openAsHTTP(this, this->mName, this->mHost, this->mName, this->mAuth, this->mPort, 0, pos);
  return result;
}


// Address: 0x2244060 | Name: _ZN4FMOD7NetFile9openAsMMSEPKcPcS3_S3_tPj
FMOD_RESULT_0 __fastcall FMOD::NetFile::openAsMMS(
        FMOD::NetFile *const this,
        const char *name_or_data,
        char *host,
        char *file,
        char *auth,
        unsigned __int16 port,
        unsigned int *filesize)
{
  return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
}


// Address: 0x2244070 | Name: _ZN4FMOD7NetFile10reallyOpenEPKcPj
FMOD_RESULT_0 __fastcall FMOD::NetFile::reallyOpen(
        FMOD::NetFile *const this,
        const char *name_or_data,
        unsigned int *filesize)
{
  FMOD_RESULT_0 result; // eax
  unsigned int v6; // r10d
  char *mAuth; // rdi
  __int64 v8; // rcx
  char *v9; // rdi
  unsigned __int16 mPort; // r9
  FMOD_RESULT_0 v11; // ebp
  bool mms; // [rsp+2Fh] [rbp-839h] BYREF
  char file[1024]; // [rsp+30h] [rbp-838h] BYREF
  char url[1080]; // [rsp+430h] [rbp-438h] BYREF

  mms = 0;
  result = FMOD_Net_Init();
  if ( result )
    return result;
  *filesize = -1;
  v6 = 4096;
  mAuth = this->mAuth;
  if ( (((_BYTE)this + 0x80) & 1) != 0 )
  {
    this->mAuth[0] = 0;
    mAuth = &this->mAuth[1];
    LOWORD(v6) = 4095;
  }
  if ( ((unsigned __int8)mAuth & 2) != 0 )
  {
    mAuth += 2;
    v6 -= 2;
    *((_WORD *)mAuth - 1) = 0;
  }
  if ( ((unsigned __int8)mAuth & 4) != 0 )
  {
    *(_DWORD *)mAuth = 0;
    v6 -= 4;
    mAuth += 4;
  }
  v8 = v6 >> 3;
  memset(mAuth, 0, 8 * v8);
  v9 = &mAuth[8 * v8];
  if ( (v6 & 4) != 0 )
  {
    *(_DWORD *)v9 = 0;
    v9 += 4;
    if ( (v6 & 2) == 0 )
    {
LABEL_11:
      if ( (v6 & 1) == 0 )
        goto LABEL_12;
      goto LABEL_17;
    }
  }
  else if ( (v6 & 2) == 0 )
  {
    goto LABEL_11;
  }
  v9 += 2;
  *((_WORD *)v9 - 1) = 0;
  if ( (v6 & 1) != 0 )
LABEL_17:
    *v9 = 0;
LABEL_12:
  FMOD_strcpy_safe(url, name_or_data, 1024);
  result = FMOD::NetFile::parseUrl(this, url, this->mHost, 1023, this->mAuth, 4096, &this->mPort, file, 1023, &mms);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mPort = this->mPort;
    if ( mms )
      v11 = FMOD::NetFile::openAsMMS(this, url, this->mHost, file, this->mAuth, mPort, filesize);
    else
      v11 = FMOD::NetFile::openAsHTTP(this, url, this->mHost, file, this->mAuth, mPort, filesize, 0);
    result = FMOD_RESULT::FMOD_OK_0;
    if ( v11 )
    {
      (*((void (__fastcall **)(FMOD::NetFile *const))this->_vptr_File + 6))(this);
      return v11;
    }
  }
  return result;
}


// Address: 0x2244290 | Name: _ZN4FMOD7NetFile11chunkedReadEPci_0
FMOD_RESULT_0 __fastcall FMOD::NetFile::chunkedRead(FMOD::NetFile *const this, char *buffer, int lengthBytes)
{
  if ( this->mChunked )
    return FMOD::NetFile::chunkedRead(this, buffer, lengthBytes);
  if ( lengthBytes )
    return FMOD_Net_Read(this->mHandle, buffer, lengthBytes);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22442c0 | Name: _ZN4FMOD7NetFile10reallyReadEPvjPj
FMOD_RESULT_0 __fastcall FMOD::NetFile::reallyRead(
        FMOD::NetFile *const this,
        void *buffer,
        unsigned int size,
        unsigned int *rd)
{
  unsigned int v6; // ebp
  unsigned int v8; // eax
  unsigned int mAbsolutePos; // ecx
  unsigned int mFileSize; // edx
  FMOD_RESULT_0 result; // eax
  unsigned int v12; // r14d
  unsigned int mBytesBeforeMeta; // eax
  int mMetaint; // edx
  char *mMetabuf; // rdi
  unsigned int v16; // esi
  int v17; // edx
  __int64 v18; // rcx
  char *v19; // rdi
  char *v20; // rax
  char *v21; // r15
  const char *v22; // rcx
  char v23; // al
  const char *v24; // r14
  char *v25; // rax
  const char *v26; // rcx
  int v27; // eax
  int v28; // eax
  char *v29; // rax
  const char *v30; // r14
  char *v31; // r15
  char v32; // al
  char *v33; // rsi
  int v34; // eax
  int v35; // eax
  char *title; // [rsp+8h] [rbp-60h]
  char *titlea; // [rsp+8h] [rbp-60h]
  char *data; // [rsp+10h] [rbp-58h]
  char *v39; // [rsp+18h] [rbp-50h]
  char tmp[57]; // [rsp+2Fh] [rbp-39h] BYREF

  v6 = size;
  *rd = 0;
  if ( !this->mMetaint )
  {
LABEL_5:
    mAbsolutePos = this->mAbsolutePos;
    mFileSize = this->mFileSize;
    result = FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
    if ( mAbsolutePos != mFileSize )
    {
      v12 = 4096;
      if ( mFileSize < v6 + mAbsolutePos )
        v6 = mFileSize - mAbsolutePos;
      mBytesBeforeMeta = this->mBytesBeforeMeta;
      if ( v6 <= 0x1000 )
        v12 = v6;
      if ( mBytesBeforeMeta && v12 > mBytesBeforeMeta )
        v12 = this->mBytesBeforeMeta;
      result = FMOD::NetFile::chunkedRead(this, (char *)buffer, v12);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        *rd = v12;
        mMetaint = this->mMetaint;
        this->mAbsolutePos += v12;
        if ( mMetaint )
          this->mBytesBeforeMeta -= v12;
      }
    }
    return result;
  }
  v8 = this->mBytesBeforeMeta;
  if ( v8 )
  {
    if ( size > v8 )
      v6 = this->mBytesBeforeMeta;
    goto LABEL_5;
  }
  result = FMOD::NetFile::chunkedRead(this, tmp, 1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mMetabuf = this->mMetabuf;
    v16 = 4081;
    v17 = 16 * (unsigned __int8)tmp[0];
    if ( ((unsigned __int8)mMetabuf & 1) != 0 )
    {
      *mMetabuf = 0;
      LOBYTE(v16) = -16;
      ++mMetabuf;
    }
    if ( ((unsigned __int8)mMetabuf & 2) != 0 )
    {
      mMetabuf += 2;
      v16 -= 2;
      *((_WORD *)mMetabuf - 1) = 0;
    }
    if ( ((unsigned __int8)mMetabuf & 4) != 0 )
    {
      *(_DWORD *)mMetabuf = 0;
      v16 -= 4;
      mMetabuf += 4;
    }
    v18 = v16 >> 3;
    memset(mMetabuf, 0, 8 * v18);
    v19 = &mMetabuf[8 * v18];
    if ( (v16 & 4) != 0 )
    {
      *(_DWORD *)v19 = 0;
      v19 += 4;
    }
    if ( (v16 & 2) != 0 )
    {
      v19 += 2;
      *((_WORD *)v19 - 1) = 0;
    }
    if ( (v16 & 1) != 0 )
      *v19 = 0;
    result = FMOD::NetFile::chunkedRead(this, this->mMetabuf, v17);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v20 = FMOD_strstr(this->mMetabuf, "StreamTitle='");
      v21 = v20;
      if ( v20 )
      {
        v22 = v20 + 13;
        v20[11] = 0;
        v23 = v20[13];
        v24 = v22;
        if ( v23 && v23 != 59 )
        {
          do
            ++v24;
          while ( *v24 != 59 && *v24 );
        }
        *((_BYTE *)v24 - 1) = 0;
        title = (char *)v22;
        v25 = FMOD_strstr(v22, " - ");
        v26 = title;
        if ( v25 )
        {
          *v25 = 0;
          v39 = v25;
          data = title;
          titlea = v25 + 3;
          v27 = FMOD_strlen(v26);
          FMOD::Metadata::addTag(
            &this->mMetadata,
            FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
            "ARTIST",
            data,
            v27 + 1,
            FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
            1);
          if ( titlea )
          {
            v28 = FMOD_strlen(titlea);
            FMOD::Metadata::addTag(
              &this->mMetadata,
              FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
              "TITLE",
              titlea,
              v28 + 1,
              FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
              1);
            v21[11] = 32;
            *((_BYTE *)v24 - 1) = 32;
            *v39 = 32;
            goto LABEL_40;
          }
        }
        else
        {
          v35 = FMOD_strlen(title);
          FMOD::Metadata::addTag(
            &this->mMetadata,
            FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
            "ARTIST",
            title,
            v35 + 1,
            FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
            1);
        }
        v21[11] = 32;
        *((_BYTE *)v24 - 1) = 32;
      }
LABEL_40:
      v29 = FMOD_strstr(this->mMetabuf, "StreamUrl='");
      v30 = v29;
      if ( v29 )
      {
        v31 = v29 + 11;
        v29[9] = 0;
        v32 = v29[11];
        v33 = v31;
        if ( v32 != 59 && v32 )
        {
          do
            ++v33;
          while ( *v33 != 59 && *v33 );
        }
        *(v33 - 1) = 0;
        v34 = FMOD_strlen(v31);
        FMOD::Metadata::addTag(
          &this->mMetadata,
          FMOD_TAGTYPE::FMOD_TAGTYPE_SHOUTCAST,
          v30,
          v31,
          v34 + 1,
          FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
          1);
      }
      this->mBytesBeforeMeta = this->mMetaint;
      goto LABEL_5;
    }
  }
  return result;
}


