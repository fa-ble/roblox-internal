// Address: 0x21ff500 | Name: FMOD_File_SetDiskBusy
FMOD_RESULT_0 __fastcall FMOD_File_SetDiskBusy(int busy)
{
  FMOD_OS_CRITICALSECTION *gFileCrit; // rdi

  if ( busy )
  {
    FMOD_OS_CriticalSection_Enter(off_286F358->gFileCrit);
    off_286F358->gFileBusy = 1;
  }
  else
  {
    gFileCrit = off_286F358->gFileCrit;
    off_286F358->gFileBusy = 0;
    FMOD_OS_CriticalSection_Leave(gFileCrit);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ff550 | Name: FMOD_File_GetDiskBusy
FMOD_RESULT_0 __fastcall FMOD_File_GetDiskBusy(int *busy)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( busy )
  {
    *busy = off_286F358->gFileBusy;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21ff570 | Name: _ZN4FMOD10FileThreadC2Ev
void __fastcall FMOD::FileThread::FileThread(FMOD::FileThread *const this)
{
  FMOD::Thread *p_mThread; // rdi

  this->mNodePrev = this;
  this->mNodeNext = this;
  p_mThread = &this->mThread;
  p_mThread[-1].mUserCallback = 0;
  FMOD::Thread::Thread(p_mThread);
  this->mFileListHead.mNodeData = 0;
  this->mFileListCrit = 0;
  this->mFileListCurrent = 0;
  this->mFileListNext = 0;
  this->mFileListHead.mNodePrev = &this->mFileListHead;
  this->mFileListHead.mNodeNext = &this->mFileListHead;
  this->mThreadActive = 0;
  this->mDeviceType = 0;
  this->mOwned = 0;
}


// Address: 0x21ff5f0 | Name: _ZN4FMOD10FileThread4initEibPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::FileThread::init(
        FMOD::FileThread *const this,
        int devicetype,
        bool owned,
        FMOD::SystemI *system)
{
  FMOD_OS_CRITICALSECTION **p_mFileListCrit; // rdi
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v9; // rax
  FMOD_RESULT_0 inited; // ebp
  FMOD::Global *v11; // rdx
  FMOD::LinkedListNode *mNodeNext; // rax

  p_mFileListCrit = &this->mFileListCrit;
  *((_DWORD *)p_mFileListCrit + 2) = devicetype;
  this->mOwned = owned;
  result = FMOD_OS_CriticalSection_Create(p_mFileListCrit, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v9 = 0;
    if ( owned )
      v9 = system;
    inited = FMOD::Thread::initThread(
               &this->mThread,
               "FMOD file thread",
               FMOD::FileThread::threadFunc,
               this,
               FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_FILE,
               FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_HIGH,
               0x4000,
               0,
               10,
               v9,
               1);
    if ( inited )
    {
      FMOD_OS_CriticalSection_Free(this->mFileListCrit, 0);
      return inited;
    }
    else
    {
      v11 = off_286F358;
      if ( !this->mOwned )
        off_286F358->gFileThreadId = this->mThread.mThreadID;
      mNodeNext = v11->gFileThreadHead.mNodeNext;
      this->mThreadActive = 1;
      this->mNodePrev = &v11->gFileThreadHead;
      this->mNodeNext = mNodeNext;
      mNodeNext->mNodePrev = this;
      this->mNodePrev->FMOD::LinkedListNode::mNodeNext = this;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21ff6f0 | Name: _ZN4FMOD10FileThread7releaseEv
FMOD_RESULT_0 __fastcall FMOD::FileThread::release(FMOD::FileThread *const this)
{
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD_OS_CRITICALSECTION *mFileListCrit; // rdi

  mNodePrev = this->mNodePrev;
  mNodePrev->mNodeNext = this->mNodeNext;
  this->mNodeNext->mNodePrev = mNodePrev;
  this->mNodePrev = this;
  this->mNodeNext = this;
  this->mThreadActive = 0;
  FMOD::Thread::closeThread(&this->mThread);
  if ( !this->mOwned )
    off_286F358->gFileThreadId = 0;
  mFileListCrit = this->mFileListCrit;
  if ( mFileListCrit )
    FMOD_OS_CriticalSection_Free(mFileListCrit, 0);
  FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_file.cpp", 269);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ff780 | Name: _ZN4FMOD4File13getFileThreadEv
FMOD_RESULT_0 __fastcall FMOD::File::getFileThread(FMOD::File *const this)
{
  bool v1; // r14
  int v2; // r13d
  FMOD::Global *v3; // rdx
  FMOD::FileThread *v4; // rax
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD_RESULT_0 v6; // eax
  FMOD_RESULT_0 result; // [rsp+Ch] [rbp-2Ch]

  if ( FMOD_strnicmp("http://", this->mName, 7) )
  {
    v3 = off_286F358;
    mNodeNext = off_286F358->gFileThreadHead.mNodeNext;
    if ( mNodeNext != &off_286F358->gFileThreadHead )
    {
      while ( LODWORD(mNodeNext[17].mNodePrev) != 4 )
      {
        mNodeNext = mNodeNext->mNodeNext;
        if ( mNodeNext == &off_286F358->gFileThreadHead )
          goto LABEL_7;
      }
      goto LABEL_5;
    }
LABEL_7:
    v1 = 0;
    v2 = 4;
  }
  else
  {
    v1 = 1;
    v2 = 3;
    v3 = off_286F358;
  }
  v4 = (FMOD::FileThread *)FMOD::MemPool::alloc(
                             v3->gSystemMemPool,
                             424,
                             "../../../core_api/src/fmod_file.cpp",
                             327,
                             0,
                             0);
  mNodeNext = v4;
  if ( !v4 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  FMOD::FileThread::FileThread(v4);
  v6 = FMOD::FileThread::init((FMOD::FileThread *const)mNodeNext, v2, v1, this->mSystem);
  if ( v6 == FMOD_RESULT::FMOD_OK_0 )
  {
LABEL_5:
    this->mFileThread = (FMOD::FileThread *)mNodeNext;
    return FMOD_RESULT::FMOD_OK_0;
  }
  result = v6;
  FMOD::MemPool::free(off_286F358->gSystemMemPool, mNodeNext, "../../../core_api/src/fmod_file.cpp", 336);
  return result;
}


// Address: 0x21ff8c0 | Name: _ZN4FMOD4FileC2Ev
void __fastcall FMOD::File::File(FMOD::File *const this)
{
  this->mNodeData = 0;
  this->mFlags = 3;
  this->mNodePrev = &this->FMOD::LinkedListNode;
  this->mNodeNext = &this->FMOD::LinkedListNode;
  this->_vptr_File = (int (**)(...))off_29B17D0;
}


// Address: 0x21ff8f0 | Name: _ZN4FMOD4File4initEPNS_7SystemIEji
FMOD_RESULT_0 __fastcall FMOD::File::init(
        FMOD::File *const this,
        FMOD::SystemI *system,
        unsigned int filesize,
        int blocksize)
{
  char *mName; // rdi
  unsigned int v6; // edx
  __int64 v7; // rcx
  char *v8; // rdi
  FMOD_ASYNCREADINFO *p_mAsyncReadInfo; // rdi
  unsigned int v10; // edx
  __int64 v11; // rcx
  void **v12; // rdi

  this->mLength = filesize;
  this->mFileSize = filesize;
  this->mBlockSize = blocksize;
  this->mFileThread = 0;
  mName = this->mName;
  *(_QWORD *)(mName - 20) = 0;
  *(_QWORD *)(mName - 28) = 0;
  v6 = 256;
  *(_QWORD *)(mName + 340) = system;
  *((_DWORD *)mName + 77) = 0;
  *(_QWORD *)(mName + 412) = 0;
  *(_QWORD *)(mName + 420) = 0;
  *((_DWORD *)mName + 70) = 0;
  *((_DWORD *)mName + 74) = 0;
  *((_DWORD *)mName + 75) = 0;
  *((_DWORD *)mName + 76) = 0;
  *((_DWORD *)mName + 73) = 0;
  *((_DWORD *)mName + 69) = 0;
  *((_DWORD *)mName + 71) = 0;
  *((_DWORD *)mName + 101) = 0;
  *((_DWORD *)mName + 102) = 0;
  *((_DWORD *)mName + 79) = 0;
  *(_QWORD *)(mName + 260) = 0;
  *((_DWORD *)mName + 67) = 0;
  *((_DWORD *)mName + 68) = 0;
  *((_DWORD *)mName + 83) = 0;
  *((_DWORD *)mName + 78) = 0;
  *(mName - 8) = 0;
  *((_DWORD *)mName - 1) = 3;
  if ( ((unsigned __int8)mName & 1) == 0 )
  {
    if ( ((unsigned __int8)mName & 2) == 0 )
      goto LABEL_3;
LABEL_21:
    mName += 2;
    v6 -= 2;
    *((_WORD *)mName - 1) = 0;
    if ( ((unsigned __int8)mName & 4) == 0 )
      goto LABEL_4;
    goto LABEL_22;
  }
  mName = &this->mName[1];
  this->mName[0] = 0;
  LOWORD(v6) = 255;
  if ( (((_BYTE)this + 69) & 2) != 0 )
    goto LABEL_21;
LABEL_3:
  if ( ((unsigned __int8)mName & 4) == 0 )
    goto LABEL_4;
LABEL_22:
  *(_DWORD *)mName = 0;
  v6 -= 4;
  mName += 4;
LABEL_4:
  v7 = v6 >> 3;
  memset(mName, 0, 8 * v7);
  v8 = &mName[8 * v7];
  if ( (v6 & 4) != 0 )
  {
    *(_DWORD *)v8 = 0;
    v8 += 4;
  }
  if ( (v6 & 2) != 0 )
  {
    v8 += 2;
    *((_WORD *)v8 - 1) = 0;
  }
  if ( (v6 & 1) != 0 )
    *v8 = 0;
  p_mAsyncReadInfo = &this->mAsyncReadInfo;
  v10 = 56;
  if ( (((_BYTE)this - 96) & 1) == 0 )
  {
    if ( (((_BYTE)this - 96) & 2) == 0 )
      goto LABEL_12;
LABEL_24:
    p_mAsyncReadInfo = (FMOD_ASYNCREADINFO *)((char *)p_mAsyncReadInfo + 2);
    v10 -= 2;
    HIWORD(p_mAsyncReadInfo[-1].done) = 0;
    if ( ((unsigned __int8)p_mAsyncReadInfo & 4) == 0 )
      goto LABEL_13;
    goto LABEL_25;
  }
  p_mAsyncReadInfo = (FMOD_ASYNCREADINFO *)((char *)&this->mAsyncReadInfo.handle + 1);
  LOBYTE(this->mAsyncReadInfo.handle) = 0;
  LOBYTE(v10) = 55;
  if ( (((_BYTE)this - 95) & 2) != 0 )
    goto LABEL_24;
LABEL_12:
  if ( ((unsigned __int8)p_mAsyncReadInfo & 4) == 0 )
    goto LABEL_13;
LABEL_25:
  LODWORD(p_mAsyncReadInfo->handle) = 0;
  v10 -= 4;
  p_mAsyncReadInfo = (FMOD_ASYNCREADINFO *)((char *)p_mAsyncReadInfo + 4);
LABEL_13:
  v11 = v10 >> 3;
  memset(p_mAsyncReadInfo, 0, 8 * v11);
  v12 = &p_mAsyncReadInfo->handle + v11;
  if ( (v10 & 4) != 0 )
  {
    *(_DWORD *)v12 = 0;
    v12 = (void **)((char *)v12 + 4);
  }
  if ( (v10 & 2) != 0 )
  {
    v12 = (void **)((char *)v12 + 2);
    *((_WORD *)v12 - 1) = 0;
  }
  if ( (v10 & 1) != 0 )
    *(_BYTE *)v12 = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ffb50 | Name: _ZN4FMOD4File8shutDownEv
FMOD_RESULT_0 __cdecl FMOD::File::shutDown()
{
  FMOD::FileThread *mNodeNext; // rdi
  FMOD::Global *v1; // rbx

  mNodeNext = (FMOD::FileThread *)off_286F358->gFileThreadHead.mNodeNext;
  if ( mNodeNext != &off_286F358->gFileThreadHead )
  {
    while ( 1 )
    {
      v1 = (FMOD::Global *)mNodeNext->mNodeNext;
      FMOD::FileThread::release(mNodeNext);
      if ( v1 == (FMOD::Global *)&off_286F358->gFileThreadHead )
        break;
      mNodeNext = (FMOD::FileThread *)v1;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ffba0 | Name: _ZN4FMOD4File6cancelEv
FMOD_RESULT_0 __fastcall FMOD::File::cancel(FMOD::File *const this)
{
  int (**vptr_File)(...); // rax

  vptr_File = this->_vptr_File;
  this->mExit = 1;
  return (FMOD_RESULT_0)vptr_File[9](this, &this->mAsyncReadInfo);
}


// Address: 0x21ffbc0 | Name: _ZN4FMOD4File5closeEv
FMOD_RESULT_0 __fastcall FMOD::File::close(FMOD::File *const this)
{
  FMOD::FileThread *mFileThread; // rax
  FMOD::FileThread *v3; // rdx
  FMOD::LinkedListNode *v4; // rax
  FMOD::LinkedListNode *mNodeNext; // rsi
  FMOD::LinkedListNode *mNodePrev; // rcx
  FMOD_OS_CRITICALSECTION *mFileListCrit; // rdi
  FMOD::FileThread *v8; // rdi
  FMOD_RESULT_0 v9; // eax
  FMOD::SystemI *mSystem; // rdx
  FMOD_RESULT_0 v11; // ebp
  void (__fastcall *v12)(void *, void *); // rdx
  char *mEncryptionKey; // rsi
  void *mBufferMemory; // rsi

  FMOD::File::cancel(this);
  if ( (this->mFlags & 0x10) != 0 && this->mSema )
  {
    do
      FMOD_OS_Time_Sleep(0xAu);
    while ( this->mSema );
  }
  mFileThread = this->mFileThread;
  if ( mFileThread )
  {
    FMOD_OS_CriticalSection_Enter(mFileThread->mFileListCrit);
    v3 = this->mFileThread;
    v4 = &this->FMOD::LinkedListNode;
    mNodeNext = this->mNodeNext;
    if ( &this->FMOD::LinkedListNode == v3->mFileListNext )
      v3->mFileListNext = mNodeNext;
    mNodePrev = this->mNodePrev;
    mFileListCrit = v3->mFileListCrit;
    mNodePrev->mNodeNext = mNodeNext;
    this->mNodeNext->mNodePrev = mNodePrev;
    this->mNodePrev = v4;
    this->mNodeNext = v4;
    FMOD_OS_CriticalSection_Leave(mFileListCrit);
    v8 = this->mFileThread;
    if ( v8->mOwned )
      FMOD::FileThread::release(v8);
    this->mFileThread = 0;
  }
  v9 = (*((unsigned int (__fastcall **)(FMOD::File *const))this->_vptr_File + 6))(this);
  mSystem = this->mSystem;
  v11 = v9;
  if ( mSystem )
  {
    v12 = *(void (__fastcall **)(void *, void *))((char *)&stru_11730.r_offset + (_QWORD)mSystem);
    if ( v12 )
      v12(this->mRiderHandle, this->mRiderUserData);
  }
  mEncryptionKey = this->mEncryptionKey;
  if ( mEncryptionKey )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mEncryptionKey, "../../../core_api/src/fmod_file.cpp", 613);
    this->mEncryptionKey = 0;
    this->mEncryptionKeyLength = 0;
  }
  mBufferMemory = this->mBufferMemory;
  if ( mBufferMemory )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mBufferMemory, "../../../core_api/src/fmod_file.cpp", 621);
    this->mBufferMemory = 0;
    this->mBuffer = 0;
  }
  return v11;
}


// Address: 0x21ffd50 | Name: _ZN4FMOD4File4flipEb
FMOD_RESULT_0 __fastcall FMOD::File::flip(FMOD::File *const this, bool frommainthread)
{
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 mAsyncReadResult; // edx
  __int64 mBufferSkip; // r9
  unsigned int mBlockSize; // edi
  unsigned int mBlockOffset; // esi
  char *v9; // r13
  unsigned int i; // ebp
  FMOD_RESULT_0 v11; // eax
  int v12; // r14d
  unsigned int mLength; // ecx
  FMOD_RESULT_0 v14; // r15d
  __int64 bytesread; // rdx
  FMOD::SystemI *v16; // rax
  void (__fastcall *mReadRiderCallback)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  signed int v18; // edx
  signed int mBufferSize; // ecx
  float mCurrentPosition; // xmm1_4
  float v21; // xmm0_4
  int v22; // edx
  bool v23; // zf
  unsigned int v24; // ecx
  unsigned int v25; // eax
  volatile unsigned int v26; // eax
  unsigned int v27; // esi
  unsigned int v28; // eax
  signed int mNextPositionDisplay; // eax
  signed int mStartOffset; // edx
  volatile unsigned int mFlags; // edx
  int v32; // eax
  FMOD::SystemI *mSystem; // rax
  __int64 mCategory; // rdx
  unsigned int r[15]; // [rsp+2Ch] [rbp-3Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_NOTREADY_0;
  mAsyncReadResult = this->mAsyncReadResult;
  if ( mAsyncReadResult == FMOD_RESULT::FMOD_ERR_NOTREADY_0 || !frommainthread && !this->mSema )
    return result;
  mBufferSkip = this->mBufferSkip;
  mBlockSize = this->mBlockSize;
  mBlockOffset = this->mBlockOffset;
  v9 = (char *)this->mBuffer + mBlockOffset + mBufferSkip + this->mAsyncRead;
  i = this->mBlockSize - mBufferSkip - this->mAsyncRead;
  this->mFlags |= 0x10u;
  if ( i )
  {
    v11 = mAsyncReadResult;
    v12 = 0;
    r[0] = 0;
LABEL_5:
    if ( (v11 & 0xFFFFFFEF) != 0 )
    {
      mLength = this->mLength;
      this->mAsyncReadResult = FMOD_RESULT::FMOD_OK_0;
      v14 = v11;
      goto LABEL_7;
    }
    bytesread = this->mAsyncReadInfo.bytesread;
    if ( (_DWORD)bytesread )
    {
      this->mAsyncRead += bytesread;
      r[0] = bytesread;
      v14 = v11;
      this->mAsyncReadInfo.bytesread = 0;
      this->mAsyncReadResult = FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      if ( frommainthread )
        mNextPositionDisplay = v12 + this->mNextPosition;
      else
        mNextPositionDisplay = this->mNextPositionDisplay;
      mLength = this->mLength;
      if ( mLength != -1 )
      {
        mStartOffset = this->mStartOffset;
        if ( mStartOffset < mNextPositionDisplay && mLength <= mNextPositionDisplay - mStartOffset )
        {
          v14 = FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
LABEL_7:
          i = 0;
          bytesread = 0;
          if ( mLength == -1 )
          {
LABEL_21:
            if ( v14 == FMOD_RESULT::FMOD_ERR_FILE_EOF_0 )
            {
              v25 = this->mNextPositionDisplay;
              if ( v25 )
              {
                this->mFileSize = v25;
                this->mLength = v25;
              }
            }
          }
          goto LABEL_8;
        }
      }
      mFlags = this->mFlags;
      this->mAsyncReadInfo.offset = mNextPositionDisplay;
      v32 = 100;
      this->mAsyncReadInfo.buffer = v9;
      this->mAsyncReadInfo.bytesread = 0;
      this->mAsyncReadInfo.handle = this;
      if ( (mFlags & 0x1000) == 0 )
        v32 = !frommainthread ? 0x32 : 0;
      this->mAsyncReadInfo.priority = v32;
      mSystem = this->mSystem;
      this->mAsyncReadInfo.userdata = 0;
      this->mAsyncReadResult = FMOD_RESULT::FMOD_OK_0;
      this->mAsyncReadInfo.sizebytes = i;
      if ( mSystem )
      {
        mCategory = this->mCategory;
        if ( (_DWORD)mCategory != 3 )
          _InterlockedAdd64(&mSystem->mFileBytesRead[mCategory].m_value, (int)i);
      }
      v14 = (*((unsigned int (__fastcall **)(FMOD::File *const, FMOD_ASYNCREADINFO *, unsigned int *, bool))this->_vptr_File
             + 10))(
              this,
              &this->mAsyncReadInfo,
              r,
              frommainthread);
      if ( v14 == FMOD_RESULT::FMOD_ERR_NOTREADY_0 && !frommainthread )
        return FMOD_RESULT::FMOD_ERR_NOTREADY_0;
      this->mAsyncReadInfo.bytesread = 0;
      bytesread = r[0];
    }
    if ( v14 == FMOD_RESULT::FMOD_OK_0 )
      goto LABEL_8;
    v24 = this->mLength;
    for ( i = bytesread; ; i = 0 )
    {
      bytesread = i;
      if ( v24 == -1 )
        goto LABEL_21;
      do
      {
LABEL_8:
        v16 = this->mSystem;
        if ( v16 )
        {
          mReadRiderCallback = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v16->mReadRiderCallback;
          if ( mReadRiderCallback )
          {
            mReadRiderCallback(this->mRiderHandle, v9, bytesread, 0, this->mRiderUserData);
            LODWORD(bytesread) = r[0];
          }
        }
        if ( !(_DWORD)bytesread || i < (unsigned int)bytesread )
        {
          mBufferSize = this->mBufferSize;
LABEL_25:
          mBlockOffset = this->mBlockOffset;
          mBlockSize = this->mBlockSize;
          goto LABEL_26;
        }
        i -= bytesread;
        v12 += bytesread;
        v9 += (unsigned int)bytesread;
        v18 = this->mNextPositionDisplay + bytesread;
        mBufferSize = this->mBufferSize;
        mCurrentPosition = (float)(int)this->mCurrentPosition;
        v21 = (float)v18;
        this->mNextPositionDisplay = v18;
        v22 = 0;
        if ( (int)(float)((float)((float)(v21 - mCurrentPosition) / (float)mBufferSize) * 100.0) >= 0 )
          v22 = (int)(float)((float)((float)(v21 - mCurrentPosition) / (float)mBufferSize) * 100.0);
        v23 = !this->mExit;
        this->mPercentBuffered = v22;
        if ( !v23 )
        {
          this->mExit = 0;
          goto LABEL_25;
        }
        if ( !i )
          goto LABEL_25;
        v11 = this->mAsyncReadResult;
        r[0] = 0;
        if ( v11 != FMOD_RESULT::FMOD_ERR_NOTREADY_0 )
          goto LABEL_5;
        bytesread = 0;
      }
      while ( v14 == FMOD_RESULT::FMOD_OK_0 );
      v24 = this->mLength;
    }
  }
  mBufferSize = this->mBufferSize;
  v14 = FMOD_RESULT::FMOD_OK_0;
LABEL_26:
  v26 = this->mFlags;
  if ( mBlockOffset )
    BYTE1(v26) |= 2u;
  else
    BYTE1(v26) |= 1u;
  this->mFlags = v26;
  v27 = mBlockSize + mBlockOffset;
  v28 = 0;
  this->mBufferSkip = 0;
  this->mAsyncRead = 0;
  this->mAsyncError = v14;
  if ( v27 < mBufferSize )
    v28 = v27;
  this->mBlockOffset = v28;
  this->mFlags &= 0xFFFFEF6F;
  result = v14;
  if ( !frommainthread )
    --this->mSema;
  return result;
}


// Address: 0x2200170 | Name: _ZN4FMOD10FileThread10threadFuncEv
FMOD_RESULT_0 __fastcall FMOD::FileThread::threadFunc(FMOD::FileThread *const this)
{
  FMOD::LinkedListNode *p_mFileListHead; // r12
  FMOD::LinkedListNode *mNodeNext; // rbp
  FMOD::LinkedListNode *mFileListNext; // rax
  bool v5; // zf

  if ( !this->mThreadActive )
    return FMOD_RESULT::FMOD_OK_0;
  p_mFileListHead = &this->mFileListHead;
  FMOD_OS_CriticalSection_Enter(this->mFileListCrit);
  mNodeNext = this->mFileListHead.mNodeNext;
  this->mFileListCurrent = mNodeNext;
  if ( mNodeNext != &this->mFileListHead )
  {
    while ( 1 )
    {
      mFileListNext = mNodeNext->mNodeNext;
      v5 = (HIDWORD(mNodeNext[16].mNodePrev) & 0x80) == 0;
      this->mFileListNext = mNodeNext->mNodeNext;
      if ( v5 )
      {
        this->mFileListCurrent = mFileListNext;
        if ( mFileListNext == p_mFileListHead )
          break;
      }
      else
      {
        FMOD_OS_CriticalSection_Leave(this->mFileListCrit);
        FMOD::File::flip((FMOD::File *const)&mNodeNext[-1].mNodeData, 0);
        FMOD_OS_CriticalSection_Enter(this->mFileListCrit);
        mFileListNext = this->mFileListNext;
        this->mFileListCurrent = mFileListNext;
        if ( mFileListNext == p_mFileListHead )
          break;
      }
      mNodeNext = mFileListNext;
    }
  }
  FMOD_OS_CriticalSection_Leave(this->mFileListCrit);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2200240 | Name: j__ZN4FMOD10FileThread10threadFuncEv
// attributes: thunk
void __fastcall FMOD::FileThread::threadFunc(void *data)
{
  _ZN4FMOD10FileThread10threadFuncEv((FMOD::FileThread *const)data);
}


// Address: 0x2200250 | Name: _ZN4FMOD4File12seekAndResetEv
FMOD_RESULT_0 __fastcall FMOD::File::seekAndReset(FMOD::File *const this)
{
  unsigned int mCurrentPosition; // ecx
  unsigned int mBufferSize; // esi
  volatile unsigned int mFlags; // eax
  unsigned int v4; // ebp
  volatile unsigned int v5; // eax
  FMOD_RESULT_0 v6; // eax
  FMOD::SystemI *mSystem; // rdx
  FMOD_RESULT_0 v8; // r12d
  void (__fastcall *mSeekRiderCallback)(_QWORD, _QWORD, _QWORD); // rcx

  if ( (this->mFlags & 0x10) != 0 && this->mSema )
  {
    do
      FMOD_OS_Time_Sleep(0xAu);
    while ( this->mSema );
  }
  mCurrentPosition = this->mCurrentPosition;
  mBufferSize = this->mBufferSize;
  this->mBlockOffset = 0;
  this->mBufferSkip = 0;
  this->mAsyncRead = 0;
  mFlags = this->mFlags;
  v4 = mBufferSize * (mCurrentPosition / mBufferSize);
  BYTE1(mFlags) &= ~1u;
  this->mFlags = mFlags;
  v5 = this->mFlags;
  this->mBufferPos = mCurrentPosition % mBufferSize;
  this->mNextPosition = v4;
  this->mNextPositionDisplay = v4;
  BYTE1(v5) &= ~2u;
  this->mFlags = v5;
  v6 = (*((unsigned int (__fastcall **)(FMOD::File *const, _QWORD, _QWORD))this->_vptr_File + 8))(
         this,
         v4,
         mCurrentPosition % mBufferSize);
  mSystem = this->mSystem;
  v8 = v6;
  if ( mSystem )
  {
    mSeekRiderCallback = (void (__fastcall *)(_QWORD, _QWORD, _QWORD))mSystem->mSeekRiderCallback;
    if ( mSeekRiderCallback )
      mSeekRiderCallback(this->mRiderHandle, v4, this->mRiderUserData);
  }
  return v8;
}


// Address: 0x2200330 | Name: _ZN4FMOD4File19checkBufferedStatusEv
FMOD_RESULT_0 __fastcall FMOD::File::checkBufferedStatus(FMOD::File *const this)
{
  FMOD_RESULT_0 result; // eax
  unsigned int mNextPosition; // eax
  unsigned int mCurrentPosition; // ecx
  unsigned int mBufferSkip; // edi
  unsigned int v6; // ebp
  unsigned int v7; // ecx
  unsigned int mBufferSize; // edx
  unsigned int mBlockSize; // esi
  int v10; // edx
  signed int v11; // eax
  unsigned int v12; // eax
  unsigned int v13; // edx
  unsigned int v14; // ecx
  bool v15; // cc
  volatile unsigned int mFlags; // edx
  unsigned int v17; // edx
  unsigned int v18; // edx

  result = this->mAsyncError;
  if ( result && (unsigned int)(result - 15) > 1 )
    return result;
  mNextPosition = this->mNextPosition;
  mCurrentPosition = this->mCurrentPosition;
  if ( mNextPosition < mCurrentPosition
    || (mBufferSize = this->mBufferSize, mBlockSize = this->mBlockSize, mBufferSize > mBlockSize)
    && (this->mFlags & 0x280) == 0
    && mCurrentPosition < mNextPosition - mBlockSize )
  {
    mBufferSkip = this->mBufferSkip;
    v6 = -1;
    if ( !mBufferSkip )
      goto LABEL_15;
    goto LABEL_6;
  }
  mBufferSkip = this->mBufferSkip;
  v10 = (int)(float)((float)((float)((float)(int)this->mNextPositionDisplay - (float)(int)mCurrentPosition)
                           / (float)(int)mBufferSize)
                   * 100.0);
  this->mPercentBuffered = v10;
  if ( v10 < 0 || mBufferSkip )
  {
    this->mPercentBuffered = 0;
    v11 = (mNextPosition + mBlockSize - 1 - mCurrentPosition) / mBlockSize;
    v6 = v11;
    if ( mBufferSkip )
    {
      if ( v11 > 2 )
      {
        this->mBufferSkip = 0;
        goto LABEL_15;
      }
LABEL_6:
      v7 = mCurrentPosition - this->mBufferPos;
      this->mNextPositionDisplay = mBufferSkip;
      v6 = -1;
      this->mNextPosition = v7;
      goto LABEL_15;
    }
  }
  else
  {
    v6 = (mNextPosition + mBlockSize - 1 - mCurrentPosition) / mBlockSize;
  }
  if ( v6 == 2 )
  {
    if ( mBlockSize >= this->mBufferSize )
      goto LABEL_35;
    return FMOD_RESULT::FMOD_OK_0;
  }
LABEL_15:
  if ( (this->mFlags & 0x10) != 0 )
  {
    this->mFlags |= 0x20u;
    while ( this->mSema )
      FMOD_OS_Time_Sleep(0xAu);
    this->mFlags &= ~0x20u;
  }
  v12 = this->mBlockSize;
  if ( v6 == 1 )
  {
    if ( this->mBufferSize > v12 )
    {
      if ( this->mSema )
      {
        do
          FMOD_OS_Time_Sleep(0xAu);
        while ( this->mSema );
        v12 = this->mBlockSize;
      }
      mFlags = this->mFlags;
      LOBYTE(mFlags) = mFlags | 0x90;
      this->mFlags = mFlags;
      ++this->mSema;
      v17 = this->mNextPosition;
      this->mNextPositionDisplay = v17;
      this->mNextPosition = v17 + v12;
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( this->mBufferSize != v12 )
      goto LABEL_35;
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( this->mBufferSize > v12 && v6 == 2 )
    return FMOD_RESULT::FMOD_OK_0;
  if ( v6 )
  {
LABEL_35:
    if ( (this->mFlags & 1) != 0 )
    {
      result = FMOD::File::seekAndReset(this);
      if ( result )
        return result;
    }
  }
  result = FMOD::File::flip(this, 1);
  if ( (result & 0xFFFFFFEF) != 0 )
  {
LABEL_27:
    if ( result == FMOD_RESULT::FMOD_ERR_FILE_DISKEJECTED_0 )
      this->mFlags |= 0x20u;
    return result;
  }
  this->mFlags &= ~0x20u;
  v13 = this->mBlockSize;
  if ( this->mBufferSize == v13 && result == FMOD_RESULT::FMOD_ERR_FILE_EOF_0 && this->mLength == -1 )
    return FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
  v14 = this->mNextPosition;
  this->mNextPositionDisplay = v14;
  v15 = v13 <= this->mBufferPos;
  this->mNextPosition = v13 + v14;
  if ( v15 )
  {
    result = FMOD::File::flip(this, 1);
    if ( (result & 0xFFFFFFEF) == 0 )
    {
      this->mFlags &= ~0x20u;
      v18 = this->mNextPosition;
      this->mNextPositionDisplay = v18;
      this->mNextPosition = this->mBlockSize + v18;
      return result;
    }
    goto LABEL_27;
  }
  return result;
}


// Address: 0x2200670 | Name: _ZN4FMOD4File4readEPvjjPj
FMOD_RESULT_0 __fastcall FMOD::File::read(
        FMOD::File *const this,
        void *buffer,
        unsigned int size,
        unsigned int count,
        unsigned int *rd)
{
  FMOD_RESULT_0 result; // eax
  _BYTE *v6; // r12
  unsigned int v7; // ebx
  unsigned int mLength; // eax
  unsigned int mCurrentPosition; // edx
  unsigned int v11; // ecx
  unsigned int v12; // ebp
  FMOD_RESULT_0 v13; // r14d
  unsigned int v14; // ecx
  __int64 mBufferPos; // rsi
  unsigned int v16; // r15d
  unsigned int v17; // eax
  unsigned int v18; // eax
  bool v19; // cf
  unsigned int mBlockSize; // ecx
  bool v21; // zf
  unsigned int mNextPosition; // esi
  signed int v23; // eax
  unsigned int v24; // eax
  volatile unsigned int mFlags; // ecx
  FMOD::SystemI *mSystem; // rcx
  __int64 mCategory; // rdx
  volatile unsigned int v28; // eax
  FMOD::SystemI *v29; // rax
  void (__fastcall *mReadRiderCallback)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  unsigned int v31; // eax
  int v32; // ecx
  FMOD_RESULT_0 v33; // r15d
  bool v34; // cl
  __int64 v35; // rdi
  char v36; // al
  int v37; // eax
  bool v38; // cc
  _WORD *v39; // rax
  __int64 v40; // rdi
  unsigned __int8 v41; // dl
  int v42; // eax
  unsigned int *v43; // rax
  unsigned int v44; // edx
  bool eof; // [rsp+2Bh] [rbp-3Dh]
  size_t n[7]; // [rsp+2Ch] [rbp-3Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v6 = buffer;
  if ( buffer )
  {
    v7 = size * count;
    if ( ((size * count) & 0x80000000) == 0 )
    {
      mLength = this->mLength;
      this->mExit = 0;
      LODWORD(n[0]) = size * count;
      if ( mLength == -1
        || (mCurrentPosition = this->mCurrentPosition, v11 = this->mStartOffset + mLength, v7 + mCurrentPosition <= v11) )
      {
        eof = 0;
      }
      else
      {
        result = FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
        if ( mCurrentPosition > v11 )
          return result;
        eof = 1;
        v7 = v11 - mCurrentPosition;
        LODWORD(n[0]) = v11 - mCurrentPosition;
      }
      if ( v7 )
      {
        v12 = 0;
        while ( 1 )
        {
          while ( 1 )
          {
            mBlockSize = this->mBlockSize;
            v21 = mBlockSize == this->mBufferSize;
            LODWORD(n[0]) = v7;
            if ( v21 && mBlockSize < v7 && !this->mBufferPos && (this->mFlags & 1) != 0 )
              break;
            v13 = FMOD::File::checkBufferedStatus(this);
            if ( v13 == FMOD_RESULT::FMOD_ERR_FILE_EOF_0 )
            {
              v14 = this->mBlockSize;
              if ( v14 == this->mBufferSize && this->mLength == -1 )
              {
LABEL_54:
                v33 = v13;
                v34 = 0;
                goto LABEL_37;
              }
            }
            else
            {
              if ( v13 )
                goto LABEL_54;
              v14 = this->mBlockSize;
            }
            mBufferPos = this->mBufferPos;
            v16 = n[0];
            v17 = v14 - this->mBufferPos % v14;
            if ( v17 < LODWORD(n[0]) )
            {
              LODWORD(n[0]) = v14 - this->mBufferPos % v14;
              v16 = v17;
            }
            v13 = FMOD_RESULT::FMOD_OK_0;
            memcpy_0(&v6[v12], (char *)this->mBuffer + mBufferPos, v16);
            v18 = v16 + this->mBufferPos;
            v19 = v18 < this->mBufferSize;
            this->mBufferPos = v18;
            if ( !v19 )
              this->mBufferPos = 0;
            this->mCurrentPosition += v16;
            v12 += v16;
            v7 -= v16;
            if ( !v7 )
              goto LABEL_35;
          }
          mNextPosition = this->mNextPosition;
          v23 = v7;
          if ( mBlockSize )
          {
            if ( this->mCurrentPosition == mNextPosition )
            {
              v24 = v7;
            }
            else
            {
              result = FMOD::File::seekAndReset(this);
              if ( result )
                return result;
              v24 = n[0];
              mBlockSize = this->mBlockSize;
              mNextPosition = this->mNextPosition;
            }
            v23 = mBlockSize * (v24 / mBlockSize);
            LODWORD(n[0]) = v23;
          }
          mFlags = this->mFlags;
          this->mAsyncReadInfo.bytesread = 0;
          this->mAsyncReadInfo.handle = this;
          this->mAsyncReadInfo.offset = mNextPosition;
          this->mAsyncReadInfo.sizebytes = v23;
          this->mAsyncReadInfo.buffer = &v6[v12];
          this->mAsyncReadInfo.priority = ((int)(mFlags << 19) >> 31) & 0x64;
          mSystem = this->mSystem;
          if ( mSystem )
          {
            mCategory = this->mCategory;
            if ( (_DWORD)mCategory != 3 )
              _InterlockedAdd64(&mSystem->mFileBytesRead[mCategory].m_value, v23);
          }
          v13 = (*((unsigned int (__fastcall **)(FMOD::File *const, FMOD_ASYNCREADINFO *, size_t *, __int64))this->_vptr_File
                 + 10))(
                  this,
                  &this->mAsyncReadInfo,
                  n,
                  1);
          v28 = this->mFlags;
          this->mAsyncReadInfo.bytesread = 0;
          this->mFlags = v28 & 0xFFFFFFEF;
          v29 = this->mSystem;
          if ( v29 )
          {
            mReadRiderCallback = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v29->mReadRiderCallback;
            if ( mReadRiderCallback )
              mReadRiderCallback(this->mRiderHandle, &v6[v12], LODWORD(n[0]), 0, this->mRiderUserData);
          }
          if ( (v13 & 0xFFFFFFEF) != 0 )
            return v13;
          v31 = this->mNextPosition;
          v32 = n[0];
          this->mNextPositionDisplay = v31;
          this->mNextPosition = v32 + v31;
          if ( !v32 )
          {
            v34 = 0;
            v33 = FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
            goto LABEL_37;
          }
          if ( v13 == FMOD_RESULT::FMOD_ERR_FILE_EOF_0 )
            goto LABEL_54;
          this->mCurrentPosition += v32;
          v12 += v32;
          v7 -= v32;
          if ( !v7 )
          {
LABEL_35:
            v33 = v13;
            v34 = eof && v13 == FMOD_RESULT::FMOD_OK_0;
            goto LABEL_37;
          }
        }
      }
      else
      {
        v34 = eof;
        v12 = 0;
        v33 = FMOD_RESULT::FMOD_OK_0;
LABEL_37:
        if ( size == 2 )
        {
          if ( (this->mFlags & 8) != 0 && v12 >> 1 )
          {
            v39 = v6;
            do
            {
              *v39 = __ROL2__(*v39, 8);
              ++v39;
            }
            while ( v39 != (_WORD *)&v6[2 * (v12 >> 1)] );
          }
        }
        else if ( size == 4 && (this->mFlags & 8) != 0 && v12 >> 2 )
        {
          v43 = (unsigned int *)v6;
          do
          {
            v44 = *v43++;
            *(v43 - 1) = _byteswap_ulong(v44);
          }
          while ( v43 != (unsigned int *)&v6[4 * (v12 >> 2)] );
        }
        if ( this->mEncryptionKeyLength )
        {
          if ( (this->mFlags & 0x400) != 0 )
          {
            if ( v12 )
            {
              v40 = (__int64)&v6[v12];
              do
              {
                v41 = this->mEncryptionKey[this->mEncryptionKeyIndex] ^ *v6;
                *v6 = (v41 >> 7)
                    | ((v41 & 0x40) >> 5)
                    | ((v41 & 0x20) >> 3)
                    | ((v41 & 0x10) >> 1)
                    | (2 * (v41 & 8))
                    | (32 * (v41 & 2))
                    | (8 * (v41 & 4))
                    | (v41 << 7);
                v42 = this->mEncryptionKeyIndex + 1;
                v38 = v42 < this->mEncryptionKeyLength;
                this->mEncryptionKeyIndex = v42;
                if ( !v38 )
                  this->mEncryptionKeyIndex = 0;
                ++v6;
              }
              while ( v6 != (_BYTE *)v40 );
            }
          }
          else
          {
            v35 = (__int64)&v6[v12];
            if ( v12 )
            {
              do
              {
                v36 = (*v6 >> 7)
                    | ((*v6 & 0x40) >> 5)
                    | ((*v6 & 0x20) >> 3)
                    | ((*v6 & 0x10) >> 1)
                    | (2 * (*v6 & 8))
                    | (32 * (*v6 & 2))
                    | (8 * (*v6 & 4))
                    | (*v6 << 7);
                *v6 = v36;
                *v6 = this->mEncryptionKey[this->mEncryptionKeyIndex] ^ v36;
                v37 = this->mEncryptionKeyIndex + 1;
                v38 = v37 < this->mEncryptionKeyLength;
                this->mEncryptionKeyIndex = v37;
                if ( !v38 )
                  this->mEncryptionKeyIndex = 0;
                ++v6;
              }
              while ( v6 != (_BYTE *)v35 );
            }
          }
        }
        if ( size )
          v12 /= size;
        if ( rd )
          *rd = v12;
        result = FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
        if ( !v34 )
          return v33;
      }
    }
  }
  return result;
}


// Address: 0x2200c40 | Name: _ZN4FMOD4File7getByteEPh
FMOD_RESULT_0 __fastcall FMOD::File::getByte(FMOD::File *const this, unsigned __int8 *val)
{
  FMOD_RESULT_0 result; // eax
  unsigned __int8 temp; // [rsp+Bh] [rbp-Dh] BYREF
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, &temp, 1u, 1u, rd);
  if ( val )
    *val = temp;
  return result;
}


// Address: 0x2200c80 | Name: _ZN4FMOD4File7getByteEPt
FMOD_RESULT_0 __fastcall FMOD::File::getByte(FMOD::File *const this, unsigned __int16 *val)
{
  FMOD_RESULT_0 result; // eax
  unsigned __int8 temp; // [rsp+Bh] [rbp-Dh] BYREF
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, &temp, 1u, 1u, rd);
  if ( val )
    *val = temp;
  return result;
}


// Address: 0x2200cc0 | Name: _ZN4FMOD4File7getByteEPj
FMOD_RESULT_0 __fastcall FMOD::File::getByte(FMOD::File *const this, unsigned int *val)
{
  FMOD_RESULT_0 result; // eax
  unsigned __int8 temp; // [rsp+Bh] [rbp-Dh] BYREF
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, &temp, 1u, 1u, rd);
  if ( val )
    *val = temp;
  return result;
}


// Address: 0x2200d00 | Name: _ZN4FMOD4File7getByteEPa
FMOD_RESULT_0 __fastcall FMOD::File::getByte(FMOD::File *const this, char *val)
{
  FMOD_RESULT_0 result; // eax
  char temp; // [rsp+Bh] [rbp-Dh] BYREF
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, &temp, 1u, 1u, rd);
  if ( val )
    *val = temp;
  return result;
}


// Address: 0x2200d40 | Name: _ZN4FMOD4File7getByteEPs
FMOD_RESULT_0 __fastcall FMOD::File::getByte(FMOD::File *const this, __int16 *val)
{
  FMOD_RESULT_0 result; // eax
  char temp; // [rsp+Bh] [rbp-Dh] BYREF
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, &temp, 1u, 1u, rd);
  if ( val )
    *val = temp;
  return result;
}


// Address: 0x2200d80 | Name: _ZN4FMOD4File7getByteEPi
FMOD_RESULT_0 __fastcall FMOD::File::getByte(FMOD::File *const this, int *val)
{
  FMOD_RESULT_0 result; // eax
  char temp; // [rsp+Bh] [rbp-Dh] BYREF
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, &temp, 1u, 1u, rd);
  if ( val )
    *val = temp;
  return result;
}


// Address: 0x2200dc0 | Name: _ZN4FMOD4File7getWordEPt
FMOD_RESULT_0 __fastcall FMOD::File::getWord(FMOD::File *const this, unsigned __int16 *val)
{
  FMOD_RESULT_0 result; // eax
  unsigned __int16 temp; // [rsp+Ah] [rbp-Eh] BYREF
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, &temp, 2u, 1u, rd);
  if ( val )
    *val = temp;
  return result;
}


// Address: 0x2200e00 | Name: _ZN4FMOD4File7getWordEPj
FMOD_RESULT_0 __fastcall FMOD::File::getWord(FMOD::File *const this, unsigned int *val)
{
  FMOD_RESULT_0 result; // eax
  unsigned __int16 temp; // [rsp+Ah] [rbp-Eh] BYREF
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, &temp, 2u, 1u, rd);
  if ( val )
    *val = temp;
  return result;
}


// Address: 0x2200e40 | Name: _ZN4FMOD4File7getWordEPs
FMOD_RESULT_0 __fastcall FMOD::File::getWord(FMOD::File *const this, __int16 *val)
{
  FMOD_RESULT_0 result; // eax
  __int16 temp; // [rsp+Ah] [rbp-Eh] BYREF
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, &temp, 2u, 1u, rd);
  if ( val )
    *val = temp;
  return result;
}


// Address: 0x2200e80 | Name: _ZN4FMOD4File7getWordEPi
FMOD_RESULT_0 __fastcall FMOD::File::getWord(FMOD::File *const this, int *val)
{
  FMOD_RESULT_0 result; // eax
  __int16 temp; // [rsp+Ah] [rbp-Eh] BYREF
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, &temp, 2u, 1u, rd);
  if ( val )
    *val = temp;
  return result;
}


// Address: 0x2200ec0 | Name: _ZN4FMOD4File8getDwordEPj
FMOD_RESULT_0 __fastcall FMOD::File::getDword(FMOD::File *const this, unsigned int *val)
{
  FMOD_RESULT_0 result; // eax
  unsigned int rd; // [rsp+8h] [rbp-10h] BYREF
  unsigned int temp[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, temp, 4u, 1u, &rd);
  if ( val )
    *val = temp[0];
  return result;
}


// Address: 0x2200f00 | Name: _ZN4FMOD4File8getDwordEPi
FMOD_RESULT_0 __fastcall FMOD::File::getDword(FMOD::File *const this, int *val)
{
  FMOD_RESULT_0 result; // eax
  unsigned int rd; // [rsp+8h] [rbp-10h] BYREF
  int temp[3]; // [rsp+Ch] [rbp-Ch] BYREF

  result = FMOD::File::read(this, temp, 4u, 1u, &rd);
  if ( val )
    *val = temp[0];
  return result;
}


// Address: 0x2200f40 | Name: _ZN4FMOD4File4seekEii
FMOD_RESULT_0 __fastcall FMOD::File::seek(FMOD::File *const this, int pos, int mode)
{
  FMOD_RESULT_0 v3; // ebp
  unsigned int mLength; // eax
  unsigned int v6; // r12d
  unsigned int v7; // eax
  unsigned int mNextPosition; // edx
  unsigned int mBlockSize; // eax
  unsigned int mBufferSize; // ecx
  unsigned int mEncryptionKeyLength; // esi
  unsigned int mCurrentPosition; // r12d
  int (**vptr_File)(...); // rax
  FMOD_RESULT_0 v14; // eax
  FMOD::SystemI *mSystem; // rdx
  void (__fastcall *mSeekRiderCallback)(_QWORD, _QWORD, _QWORD); // rcx

  v3 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (unsigned int)mode <= 2 )
  {
    this->mExit = 0;
    if ( mode )
    {
      if ( mode == 1 )
      {
        mCurrentPosition = this->mCurrentPosition;
        mLength = this->mLength;
      }
      else
      {
        mLength = this->mLength;
        mCurrentPosition = mLength + this->mStartOffset;
      }
      v6 = pos + mCurrentPosition;
    }
    else
    {
      mLength = this->mLength;
      v6 = pos + this->mStartOffset;
    }
    if ( mLength != -1 )
    {
      v7 = this->mStartOffset + mLength;
      if ( v6 > v7 )
      {
        v6 = 0;
        if ( pos >= 0 )
          v6 = v7;
      }
    }
    mNextPosition = this->mNextPosition;
    if ( mNextPosition || (this->mFlags & 1) != 0 )
    {
      mBlockSize = this->mBlockSize;
    }
    else
    {
      mBlockSize = this->mBlockSize;
      v3 = FMOD_RESULT::FMOD_ERR_FILE_COULDNOTSEEK_0;
      if ( v6 >= mBlockSize )
        return v3;
    }
    mBufferSize = this->mBufferSize;
    if ( mBlockSize != mBufferSize
      || (this->mFlags & 1) != 0
      || mBlockSize > mNextPosition
      || (!mNextPosition || (v3 = FMOD_RESULT::FMOD_ERR_FILE_COULDNOTSEEK_0, v6 >= mNextPosition - mBlockSize))
      && (v3 = FMOD_RESULT::FMOD_ERR_FILE_COULDNOTSEEK_0, v6 < mNextPosition + mBlockSize) )
    {
      mEncryptionKeyLength = this->mEncryptionKeyLength;
      this->mCurrentPosition = v6;
      if ( mEncryptionKeyLength )
        this->mEncryptionKeyIndex = (v6 - this->mStartOffset) % mEncryptionKeyLength;
      if ( mBufferSize )
      {
        v3 = FMOD_RESULT::FMOD_OK_0;
        this->mBufferPos = v6 % mBufferSize;
      }
      else
      {
        vptr_File = this->_vptr_File;
        this->mNextPosition = v6;
        this->mNextPositionDisplay = v6;
        v14 = vptr_File[8](this, v6);
        mSystem = this->mSystem;
        if ( mSystem )
        {
          mSeekRiderCallback = (void (__fastcall *)(_QWORD, _QWORD, _QWORD))mSystem->mSeekRiderCallback;
          v3 = v14;
          if ( mSeekRiderCallback )
            mSeekRiderCallback(this->mRiderHandle, v6, this->mRiderUserData);
        }
        else
        {
          return v14;
        }
      }
    }
  }
  return v3;
}


// Address: 0x2201100 | Name: _ZN4FMOD4File4tellEPj
FMOD_RESULT_0 __fastcall FMOD::File::tell(FMOD::File *const this, unsigned int *pos)
{
  FMOD_RESULT_0 result; // eax
  unsigned int mCurrentPosition; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( pos )
  {
    mCurrentPosition = this->mCurrentPosition;
    this->mExit = 0;
    *pos = mCurrentPosition;
    *pos = mCurrentPosition - this->mStartOffset;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2201130 | Name: _ZN4FMOD4File14setStartOffsetEj
FMOD_RESULT_0 __fastcall FMOD::File::setStartOffset(FMOD::File *const this, unsigned int offset)
{
  unsigned int mLength; // eax
  unsigned int v3; // edx
  unsigned int v4; // eax

  mLength = this->mLength;
  v3 = offset - this->mStartOffset;
  this->mStartOffset = offset;
  if ( mLength == -1 )
    return FMOD_RESULT::FMOD_OK_0;
  v4 = mLength - v3;
  this->mLength = v4;
  return this->mFileSize < offset + v4 ? 0x1C : 0;
}


// Address: 0x2201170 | Name: _ZN4FMOD4File14getStartOffsetEPj
FMOD_RESULT_0 __fastcall FMOD::File::getStartOffset(FMOD::File *const this, unsigned int *offset)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( offset )
  {
    *offset = this->mStartOffset;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2201190 | Name: _ZN4FMOD4File14allocateBufferEv
FMOD_RESULT_0 __fastcall FMOD::File::allocateBuffer(FMOD::File *const this)
{
  FMOD_RESULT_0 v1; // ebp
  void *mBufferMemory; // r13
  void *mBuffer; // r14
  void *v4; // rax

  v1 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  mBufferMemory = this->mBufferMemory;
  mBuffer = this->mBuffer;
  v4 = FMOD::MemPool::calloc(
         off_286F358->gSystemMemPool,
         this->mBufferSize + 1,
         "../../../core_api/src/fmod_file.cpp",
         1872,
         0);
  this->mBufferMemory = v4;
  if ( v4 )
  {
    this->mBuffer = v4;
    if ( mBuffer )
      memcpy_0(v4, mBuffer, this->mBufferSize);
    v1 = FMOD_RESULT::FMOD_OK_0;
    if ( mBufferMemory )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, mBufferMemory, "../../../core_api/src/fmod_file.cpp", 1887);
  }
  return v1;
}


// Address: 0x2201240 | Name: _ZN4FMOD4File4openEPKcjjS2_
FMOD_RESULT_0 __fastcall FMOD::File::open(
        FMOD::File *const this,
        const char *name_or_data,
        unsigned int length,
        unsigned int offset,
        const char *encryptionkey)
{
  volatile unsigned int mFlags; // eax
  volatile unsigned int v6; // eax
  unsigned int mBlockSize; // eax
  FMOD_RESULT_0 Buffer; // eax
  FMOD::SystemI *mSystem; // rax
  void (__fastcall *mOpenRiderCallback)(const char *, unsigned int *, void **, void **); // rax
  unsigned int mLength; // eax
  unsigned int mFileSize; // ecx
  unsigned int mStartOffset; // edx
  unsigned int v14; // esi
  char *mEncryptionKey; // rsi
  void *mBufferMemory; // rsi
  FMOD_RESULT_0 resulta; // [rsp+8h] [rbp-20h]
  FMOD_RESULT_0 resultb; // [rsp+8h] [rbp-20h]

  mFlags = this->mFlags;
  this->mLength = length;
  this->mStartOffset = offset;
  this->mCurrentPosition = 0;
  this->mNextPosition = 0;
  this->mNextPositionDisplay = 0;
  this->mBlockOffset = 0;
  this->mBufferPos = 0;
  this->mFlags = mFlags & 0xFFFFFFF7;
  v6 = this->mFlags;
  this->mBufferSkip = 0;
  this->mAsyncRead = 0;
  this->mAsyncError = FMOD_RESULT::FMOD_OK_0;
  this->mEncryptionKeyLength = 0;
  this->mEncryptionKeyIndex = 0;
  this->mFlags = v6 & 0xFFFFFFDF;
  this->mFileSize = offset + length;
  if ( encryptionkey && !this->mEncryptionKey )
  {
    this->mEncryptionKeyLength = FMOD_strlen(encryptionkey);
    this->mEncryptionKey = FMOD_strdup(encryptionkey);
  }
  mBlockSize = this->mBlockSize;
  this->mBufferSize = mBlockSize;
  if ( !mBlockSize || this->mBuffer || (Buffer = FMOD::File::allocateBuffer(this)) == FMOD_RESULT::FMOD_OK_0 )
  {
    Buffer = (*((unsigned int (__fastcall **)(FMOD::File *const, const char *, unsigned int *))this->_vptr_File + 5))(
               this,
               name_or_data,
               &this->mFileSize);
    if ( Buffer )
    {
      mEncryptionKey = this->mEncryptionKey;
      if ( mEncryptionKey )
      {
        resulta = Buffer;
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mEncryptionKey, "../../../core_api/src/fmod_file.cpp", 506);
        Buffer = resulta;
        this->mEncryptionKey = 0;
        this->mEncryptionKeyLength = 0;
      }
      mBufferMemory = this->mBufferMemory;
      if ( mBufferMemory )
      {
        resultb = Buffer;
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mBufferMemory, "../../../core_api/src/fmod_file.cpp", 512);
        this->mBufferMemory = 0;
        this->mBuffer = 0;
        return resultb;
      }
    }
    else
    {
      if ( name_or_data && (this->mFlags & 2) != 0 )
        FMOD_strcpy_safe(this->mName, name_or_data, 256);
      mSystem = this->mSystem;
      if ( mSystem )
      {
        mOpenRiderCallback = (void (__fastcall *)(const char *, unsigned int *, void **, void **))mSystem->mOpenRiderCallback;
        if ( mOpenRiderCallback )
          mOpenRiderCallback(name_or_data, &this->mFileSize, &this->mRiderHandle, &this->mRiderUserData);
      }
      mLength = this->mLength;
      if ( mLength )
      {
        mFileSize = this->mFileSize;
      }
      else
      {
        mLength = this->mFileSize;
        this->mLength = mLength;
        mFileSize = mLength;
      }
      mStartOffset = this->mStartOffset;
      v14 = mLength + mStartOffset;
      Buffer = FMOD_RESULT::FMOD_OK_0;
      if ( v14 > mFileSize )
        this->mLength = mFileSize - mStartOffset;
    }
  }
  return Buffer;
}


// Address: 0x22014a0 | Name: _ZN4FMOD4File18enableDoubleBufferEjPv
FMOD_RESULT_0 __fastcall FMOD::File::enableDoubleBuffer(
        FMOD::File *const this,
        unsigned int sizebytes,
        void *oldbuffer)
{
  unsigned int mBlockSize; // ecx
  unsigned int mBufferSize; // r12d
  unsigned int v7; // eax
  unsigned int v8; // eax
  unsigned int v9; // eax
  void *v10; // rax
  void *mBufferMemory; // rax
  FMOD_RESULT_0 result; // eax
  FMOD::FileThread *mFileThread; // rax
  FMOD::LinkedListNode *mNodeNext; // rcx
  FMOD_OS_CRITICALSECTION *mFileListCrit; // rdi

  mBlockSize = this->mBlockSize;
  if ( !mBlockSize )
    return FMOD_RESULT::FMOD_OK_0;
  if ( sizebytes <= 0x7FF )
    sizebytes = 2048;
  mBufferSize = this->mBufferSize;
  this->mBufferSkip = mBlockSize;
  v7 = sizebytes;
  this->mBlockOffset = 0;
  if ( sizebytes < mBlockSize )
    v7 = mBlockSize;
  v8 = mBlockSize * (v7 / mBlockSize);
  this->mBlockSize = v8;
  this->mNextPosition = v8;
  this->mNextPositionDisplay = v8;
  v9 = 2 * v8;
  this->mBufferSize = v9;
  if ( !oldbuffer )
  {
    mBufferMemory = FMOD::MemPool::realloc(
                      off_286F358->gSystemMemPool,
                      this->mBufferMemory,
                      v9 + 1,
                      "../../../core_api/src/fmod_file.cpp",
                      1952,
                      1u);
    this->mBufferMemory = mBufferMemory;
    if ( mBufferMemory )
      goto LABEL_9;
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
  v10 = FMOD::MemPool::calloc(off_286F358->gSystemMemPool, v9 + 1, "../../../core_api/src/fmod_file.cpp", 1943, 1u);
  this->mBufferMemory = v10;
  if ( !v10 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  memcpy_0(v10, oldbuffer, mBufferSize);
  mBufferMemory = this->mBufferMemory;
LABEL_9:
  this->mBuffer = mBufferMemory;
  result = FMOD::File::getFileThread(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    FMOD_OS_CriticalSection_Enter(this->mFileThread->mFileListCrit);
    mFileThread = this->mFileThread;
    mNodeNext = mFileThread->mFileListHead.mNodeNext;
    mFileListCrit = mFileThread->mFileListCrit;
    this->mNodePrev = &mFileThread->mFileListHead;
    this->mNodeNext = mNodeNext;
    mNodeNext->mNodePrev = &this->FMOD::LinkedListNode;
    this->mNodePrev->FMOD::LinkedListNode::mNodeNext = &this->FMOD::LinkedListNode;
    FMOD_OS_CriticalSection_Leave(mFileListCrit);
    result = FMOD::File::checkBufferedStatus(this);
    if ( (result & 0xFFFFFFEF) == 0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2201630 | Name: _ZN4FMOD4File7getNameEPPKc
FMOD_RESULT_0 __fastcall FMOD::File::getName(FMOD::File *const this, const char **name)
{
  if ( name )
    *name = this->mName;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2201640 | Name: _ZN4FMOD4File7setNameEPKc
FMOD_RESULT_0 __fastcall FMOD::File::setName(FMOD::File *const this, const char *name)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( name )
  {
    FMOD_strcpy_safe(this->mName, name, 256);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2201670 | Name: _ZN4FMOD4File15setFileCategoryENS_18FMOD_FILE_CATEGORYE
FMOD_RESULT_0 __fastcall FMOD::File::setFileCategory(FMOD::File *const this, FMOD::FMOD_FILE_CATEGORY category)
{
  if ( (unsigned int)(this->mDeviceType - 4) <= 1 )
    this->mCategory = category;
  return FMOD_RESULT::FMOD_OK_0;
}


