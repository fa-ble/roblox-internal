// Address: 0x21a7970 | Name: _ZN4FMOD6System7releaseEv
FMOD_RESULT_1 __fastcall FMOD::System::release(FMOD::System *const this)
{
  FMOD_RESULT_1 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( v1 )
    goto LABEL_2;
  if ( !lockScope.mSystem || FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem) == FMOD_RESULT::FMOD_OK_0 )
    lockScope.mSystem = 0;
  v1 = FMOD::SystemI::release(systemi);
  if ( v1 )
  {
LABEL_2:
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      _buffer[0] = 0;
      FMOD_ReportError(
        v1,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
        this,
        "System::release",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x21a7a20 | Name: _ZN4FMOD6System9setOutputE15FMOD_OUTPUTTYPE
FMOD_RESULT_1 __fastcall FMOD::System::setOutput(FMOD::System *const this, FMOD_OUTPUTTYPE_1 output)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::setOutput(systemi, output)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, output);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setOutput",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21a7ad0 | Name: _ZN4FMOD6System9getOutputEP15FMOD_OUTPUTTYPE
FMOD_RESULT_1 __fastcall FMOD::System::getOutput(FMOD::System *const this, FMOD_OUTPUTTYPE_1 *output)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::getOutput(systemi, output)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, output);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getOutput",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21a7b80 | Name: _ZN4FMOD6System13getNumDriversEPi
FMOD_RESULT_1 __fastcall FMOD::System::getNumDrivers(FMOD::System *const this, int *numdrivers)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::getNumDrivers(systemi, numdrivers)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numdrivers);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getNumDrivers",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21a7c30 | Name: _ZN4FMOD6System13getDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_
FMOD_RESULT_1 __fastcall FMOD::System::getDriverInfo(
        FMOD::System *const this,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_1 *speakermode,
        int *speakermodechannels)
{
  FMOD_RESULT_1 DriverInfo; // r12d
  int v13; // eax
  int v14; // r15d
  int v15; // r15d
  int v16; // r15d
  int v17; // r15d
  int v18; // r14d
  int v19; // r14d
  int v20; // r13d
  int v21; // r13d
  int v22; // r13d
  int v23; // eax
  int v25; // [rsp+1Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+20h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+28h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+30h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  DriverInfo = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (DriverInfo
     || (DriverInfo = FMOD::SystemI::getDriverInfo(
                        systemi,
                        id,
                        name,
                        namelen,
                        guid,
                        systemrate,
                        speakermode,
                        speakermodechannels)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v25 = FMOD::FMOD_FormatArg(_buffer, 256, id);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v25], 256 - v25, ", ");
    v14 = v13 + v25 + FMOD::FMOD_FormatArg(&_buffer[v13 + v25], 256 - (v13 + v25), name);
    v15 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, ", ") + v14;
    v16 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, namelen) + v15;
    v17 = FMOD::FMOD_FormatArg(&_buffer[v16], 256 - v16, ", ") + v16;
    v18 = v17 + FMOD::FMOD_FormatArg(&_buffer[v17], 256 - v17, guid);
    v19 = FMOD::FMOD_FormatArg(&_buffer[v18], 256 - v18, ", ") + v18;
    v20 = v19 + FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, systemrate);
    v21 = FMOD::FMOD_FormatArg(&_buffer[v20], 256 - v20, ", ") + v20;
    v22 = FMOD::FMOD_FormatArg(&_buffer[v21], 256 - v21, speakermode) + v21;
    v23 = FMOD::FMOD_FormatArg(&_buffer[v22], 256 - v22, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v23 + v22], 256 - (v23 + v22), speakermodechannels);
    FMOD_ReportError(
      DriverInfo,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getDriverInfo",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return DriverInfo;
}


// Address: 0x21a7e70 | Name: _ZN4FMOD6System9setDriverEi
FMOD_RESULT_1 __fastcall FMOD::System::setDriver(FMOD::System *const this, int driver)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::setDriver(systemi, driver)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, driver);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setDriver",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21a7f20 | Name: _ZN4FMOD6System9getDriverEPi
FMOD_RESULT_1 __fastcall FMOD::System::getDriver(FMOD::System *const this, int *driver)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::getDriver(systemi, driver)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, driver);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getDriver",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21a7fd0 | Name: _ZN4FMOD6System19setSoftwareChannelsEi
FMOD_RESULT_1 __fastcall FMOD::System::setSoftwareChannels(FMOD::System *const this, int numsoftwarechannels)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::setSoftwareChannels(systemi, numsoftwarechannels)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numsoftwarechannels);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setSoftwareChannels",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21a8080 | Name: _ZN4FMOD6System19getSoftwareChannelsEPi
FMOD_RESULT_1 __fastcall FMOD::System::getSoftwareChannels(FMOD::System *const this, int *numsoftwarechannels)
{
  FMOD_RESULT_1 SoftwareChannels; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  SoftwareChannels = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (SoftwareChannels
     || (SoftwareChannels = FMOD::SystemI::getSoftwareChannels(systemi, numsoftwarechannels)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numsoftwarechannels);
    FMOD_ReportError(
      SoftwareChannels,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getSoftwareChannels",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return SoftwareChannels;
}


// Address: 0x21a8130 | Name: _ZN4FMOD6System17setSoftwareFormatEi16FMOD_SPEAKERMODEi
FMOD_RESULT_1 __fastcall FMOD::System::setSoftwareFormat(
        FMOD::System *const this,
        int samplerate,
        FMOD_SPEAKERMODE_1 speakermode,
        int numrawspeakers)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v6
     || (v6 = FMOD::SystemI::setSoftwareFormat(systemi, samplerate, speakermode, numrawspeakers)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, samplerate);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), speakermode);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), numrawspeakers);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setSoftwareFormat",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21a8280 | Name: _ZN4FMOD6System17getSoftwareFormatEPiP16FMOD_SPEAKERMODES1_
FMOD_RESULT_1 __fastcall FMOD::System::getSoftwareFormat(
        FMOD::System *const this,
        int *samplerate,
        FMOD_SPEAKERMODE_1 *speakermode,
        int *numrawspeakers)
{
  FMOD_RESULT_1 v6; // ebx
  FMOD::SystemI *v7; // rax
  int v9; // eax
  int v10; // r12d
  int v11; // eax
  int v12; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( v6 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v12 = FMOD::FMOD_FormatArg(_buffer, 256, samplerate);
      v9 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
      v10 = v9 + v12 + FMOD::FMOD_FormatArg(&_buffer[v9 + v12], 256 - (v9 + v12), speakermode);
      v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v11 + v10], 256 - (v11 + v10), numrawspeakers);
      FMOD_ReportError(
        v6,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
        this,
        "System::getSoftwareFormat",
        _buffer);
    }
  }
  else
  {
    v7 = systemi;
    if ( samplerate )
      *samplerate = systemi->mDSPSampleRate;
    if ( speakermode )
      *speakermode = v7->mSpeakerMode;
    if ( numrawspeakers )
      *numrawspeakers = v7->mDSPMaxOutputChannels;
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21a83d0 | Name: _ZN4FMOD6System16setDSPBufferSizeEji
FMOD_RESULT_1 __fastcall FMOD::System::setDSPBufferSize(
        FMOD::System *const this,
        unsigned int bufferlength,
        int numbuffers)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4 || (v4 = FMOD::SystemI::setDSPBufferSize(systemi, bufferlength, numbuffers)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, bufferlength);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), numbuffers);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setDSPBufferSize",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21a84d0 | Name: _ZN4FMOD6System16getDSPBufferSizeEPjPi
FMOD_RESULT_1 __fastcall FMOD::System::getDSPBufferSize(
        FMOD::System *const this,
        unsigned int *bufferlength,
        int *numbuffers)
{
  FMOD_RESULT_1 DSPBufferSize; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  DSPBufferSize = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (DSPBufferSize
     || (DSPBufferSize = FMOD::SystemI::getDSPBufferSize(systemi, bufferlength, numbuffers)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, bufferlength);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), numbuffers);
    FMOD_ReportError(
      DSPBufferSize,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getDSPBufferSize",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return DSPBufferSize;
}


// Address: 0x21a85d0 | Name: _ZN4FMOD6System13setFileSystemEPF11FMOD_RESULTPKcPjPPvS5_EPFS1_S5_S5_EPFS1_S5_S5_jS4_S5_EPFS1_S5_jS5_EPFS1_P18FMOD_ASYNCREADINFOS5_ESI_i
FMOD_RESULT_1 __fastcall FMOD::System::setFileSystem(
        FMOD::System *const this,
        FMOD_FILE_OPEN_CALLBACK_0 useropen,
        FMOD_FILE_CLOSE_CALLBACK_0 userclose,
        FMOD_FILE_READ_CALLBACK_0 userread,
        FMOD_FILE_SEEK_CALLBACK_0 userseek,
        FMOD_FILE_ASYNCREAD_CALLBACK_0 userasyncread,
        FMOD_FILE_ASYNCCANCEL_CALLBACK_0 userasynccancel,
        int blockalign)
{
  FMOD_RESULT_1 v11; // r12d
  int v13; // eax
  int v14; // r15d
  int v15; // r15d
  int v16; // r15d
  int v17; // r15d
  int v18; // r14d
  int v19; // r14d
  int v20; // r13d
  int v21; // r13d
  int v22; // r13d
  int v23; // eax
  int v25; // [rsp+2Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+30h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+38h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+40h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v11 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v11
     || (v11 = FMOD::SystemI::setFileSystem(
                 systemi,
                 (FMOD_FILE_OPEN_CALLBACK)useropen,
                 (FMOD_FILE_CLOSE_CALLBACK)userclose,
                 (FMOD_FILE_READ_CALLBACK)userread,
                 (FMOD_FILE_SEEK_CALLBACK)userseek,
                 (FMOD_FILE_ASYNCREAD_CALLBACK)userasyncread,
                 (FMOD_FILE_ASYNCCANCEL_CALLBACK)userasynccancel,
                 blockalign)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v25 = FMOD::FMOD_FormatArg(_buffer, 256, useropen != 0);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v25], 256 - v25, ", ");
    v14 = v13 + v25 + FMOD::FMOD_FormatArg(&_buffer[v13 + v25], 256 - (v13 + v25), userclose != 0);
    v15 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, ", ") + v14;
    v16 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, userread != 0) + v15;
    v17 = FMOD::FMOD_FormatArg(&_buffer[v16], 256 - v16, ", ") + v16;
    v18 = v17 + FMOD::FMOD_FormatArg(&_buffer[v17], 256 - v17, userseek != 0);
    v19 = FMOD::FMOD_FormatArg(&_buffer[v18], 256 - v18, ", ") + v18;
    v20 = v19 + FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, userasyncread != 0);
    v21 = FMOD::FMOD_FormatArg(&_buffer[v20], 256 - v20, ", ") + v20;
    v22 = FMOD::FMOD_FormatArg(&_buffer[v21], 256 - v21, userasynccancel != 0) + v21;
    v23 = FMOD::FMOD_FormatArg(&_buffer[v22], 256 - v22, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v23 + v22], 256 - (v23 + v22), blockalign);
    FMOD_ReportError(
      v11,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setFileSystem",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v11;
}


// Address: 0x21a8830 | Name: _ZN4FMOD6System16attachFileSystemEPF11FMOD_RESULTPKcPjPPvS5_EPFS1_S5_S5_EPFS1_S5_S5_jS4_S5_EPFS1_S5_jS5_E
FMOD_RESULT_1 __fastcall FMOD::System::attachFileSystem(
        FMOD::System *const this,
        FMOD_FILE_OPEN_CALLBACK_0 useropen,
        FMOD_FILE_CLOSE_CALLBACK_0 userclose,
        FMOD_FILE_READ_CALLBACK_0 userread,
        FMOD_FILE_SEEK_CALLBACK_0 userseek)
{
  FMOD_RESULT_1 v8; // r12d
  int v10; // eax
  int v11; // r15d
  int v12; // r15d
  int v13; // r14d
  int v14; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v8 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v8
     || (v8 = FMOD::SystemI::attachFileSystem(
                systemi,
                (FMOD_FILE_OPEN_CALLBACK)useropen,
                (FMOD_FILE_CLOSE_CALLBACK)userclose,
                (FMOD_FILE_READ_CALLBACK)userread,
                (FMOD_FILE_SEEK_CALLBACK)userseek)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, useropen != 0);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v11 = v10 + v15 + FMOD::FMOD_FormatArg(&_buffer[v10 + v15], 256 - (v10 + v15), userclose != 0);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ") + v11;
    v13 = v12 + FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, userread != 0);
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v14 + v13], 256 - (v14 + v13), userseek != 0);
    FMOD_ReportError(
      v8,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::attachFileSystem",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v8;
}


// Address: 0x21a89e0 | Name: _ZN4FMOD6System19setAdvancedSettingsEP21FMOD_ADVANCEDSETTINGS
FMOD_RESULT_1 __fastcall FMOD::System::setAdvancedSettings(FMOD::System *const this, FMOD_ADVANCEDSETTINGS_0 *settings)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2
     || (v2 = FMOD::SystemI::setAdvancedSettings(systemi, (FMOD_ADVANCEDSETTINGS *)settings)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, settings);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setAdvancedSettings",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21a8a90 | Name: _ZN4FMOD6System19getAdvancedSettingsEP21FMOD_ADVANCEDSETTINGS
FMOD_RESULT_1 __fastcall FMOD::System::getAdvancedSettings(FMOD::System *const this, FMOD_ADVANCEDSETTINGS_0 *settings)
{
  FMOD_RESULT_1 AdvancedSettings; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  AdvancedSettings = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (AdvancedSettings
     || (AdvancedSettings = FMOD::SystemI::getAdvancedSettings(systemi, (FMOD_ADVANCEDSETTINGS *)settings)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, settings);
    FMOD_ReportError(
      AdvancedSettings,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getAdvancedSettings",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return AdvancedSettings;
}


// Address: 0x21a8b40 | Name: _ZN4FMOD6System11setCallbackEPF11FMOD_RESULTP11FMOD_SYSTEMjPvS4_S4_Ej
FMOD_RESULT_1 __fastcall FMOD::System::setCallback(
        FMOD::System *const this,
        FMOD_SYSTEM_CALLBACK_0 callback,
        FMOD_SYSTEM_CALLBACK_TYPE callbackmask)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r14d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4
     || (v4 = FMOD::SystemI::setCallback(systemi, (FMOD_SYSTEM_CALLBACK)callback, callbackmask)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, callback != 0);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), callbackmask);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setCallback",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21a8c50 | Name: _ZN4FMOD6System13setPluginPathEPKc
FMOD_RESULT_1 __fastcall FMOD::System::setPluginPath(FMOD::System *const this, const char *path)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::setPluginPath(systemi, path)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, path);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      (const char *)&info_ptr.unknown_chunks_num + 1,
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21a8d00 | Name: _ZN4FMOD6System10loadPluginEPKcPjj
FMOD_RESULT_1 __fastcall FMOD::System::loadPlugin(
        FMOD::System *const this,
        const char *filename,
        unsigned int *handle,
        unsigned int priority)
{
  FMOD_RESULT_1 Plugin; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  Plugin = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (Plugin || (Plugin = FMOD::SystemI::loadPlugin(systemi, filename, handle, priority)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, filename);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), handle);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), priority);
    FMOD_ReportError(
      Plugin,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::loadPlugin",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return Plugin;
}


// Address: 0x21a8e50 | Name: _ZN4FMOD6System12unloadPluginEj
FMOD_RESULT_1 __fastcall FMOD::System::unloadPlugin(FMOD::System *const this, unsigned int handle)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::unloadPlugin(systemi, handle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, handle);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::unloadPlugin",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21a8f00 | Name: _ZN4FMOD6System19getNumNestedPluginsEjPi
FMOD_RESULT_1 __fastcall FMOD::System::getNumNestedPlugins(FMOD::System *const this, unsigned int handle, int *count)
{
  FMOD_RESULT_1 NumNestedPlugins; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  NumNestedPlugins = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (NumNestedPlugins
     || (NumNestedPlugins = FMOD::SystemI::getNumNestedPlugins(systemi, handle, count)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, handle);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), count);
    FMOD_ReportError(
      NumNestedPlugins,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getNumNestedPlugins",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return NumNestedPlugins;
}


// Address: 0x21a9000 | Name: _ZN4FMOD6System15getNestedPluginEjiPj
FMOD_RESULT_1 __fastcall FMOD::System::getNestedPlugin(
        FMOD::System *const this,
        unsigned int handle,
        int index,
        unsigned int *nestedhandle)
{
  FMOD_RESULT_1 NestedPlugin; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  NestedPlugin = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (NestedPlugin
     || (NestedPlugin = FMOD::SystemI::getNestedPlugin(systemi, handle, index, nestedhandle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, handle);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), index);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), nestedhandle);
    FMOD_ReportError(
      NestedPlugin,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getNestedPlugin",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return NestedPlugin;
}


// Address: 0x21a9150 | Name: _ZN4FMOD6System13getNumPluginsE15FMOD_PLUGINTYPEPi
FMOD_RESULT_1 __fastcall FMOD::System::getNumPlugins(
        FMOD::System *const this,
        FMOD_PLUGINTYPE_1 plugintype,
        int *numplugins)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4 || (v4 = FMOD::SystemI::getNumPlugins(systemi, plugintype, numplugins)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, plugintype);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), numplugins);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getNumPlugins",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21a9250 | Name: _ZN4FMOD6System15getPluginHandleE15FMOD_PLUGINTYPEiPj
FMOD_RESULT_1 __fastcall FMOD::System::getPluginHandle(
        FMOD::System *const this,
        FMOD_PLUGINTYPE_1 plugintype,
        int index,
        unsigned int *handle)
{
  FMOD_RESULT_1 PluginHandle; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  PluginHandle = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (PluginHandle
     || (PluginHandle = FMOD::SystemI::getPluginHandle(systemi, plugintype, index, handle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, plugintype);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), index);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), handle);
    FMOD_ReportError(
      PluginHandle,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getPluginHandle",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return PluginHandle;
}


// Address: 0x21a93a0 | Name: _ZN4FMOD6System13getPluginInfoEjP15FMOD_PLUGINTYPEPciPj
FMOD_RESULT_1 __fastcall FMOD::System::getPluginInfo(
        FMOD::System *const this,
        unsigned int handle,
        FMOD_PLUGINTYPE_1 *plugintype,
        char *name,
        int namelen,
        unsigned int *version)
{
  FMOD_RESULT_1 PluginInfo; // r13d
  int v10; // eax
  int v11; // r15d
  int v12; // r15d
  int v13; // r15d
  int v14; // r15d
  int v15; // r14d
  int v16; // eax
  int v19; // [rsp+1Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+20h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+28h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+30h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  PluginInfo = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (PluginInfo
     || (PluginInfo = FMOD::SystemI::getPluginInfo(systemi, handle, plugintype, name, namelen, version)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v19 = FMOD::FMOD_FormatArg(_buffer, 256, handle);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, ", ");
    v11 = v10 + v19 + FMOD::FMOD_FormatArg(&_buffer[v10 + v19], 256 - (v10 + v19), plugintype);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ") + v11;
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, name) + v12;
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ") + v13;
    v15 = v14 + FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, namelen);
    v16 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v16 + v15], 256 - (v16 + v15), version);
    FMOD_ReportError(
      PluginInfo,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getPluginInfo",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return PluginInfo;
}


// Address: 0x21a9570 | Name: _ZN4FMOD6System17setOutputByPluginEj
FMOD_RESULT_1 __fastcall FMOD::System::setOutputByPlugin(FMOD::System *const this, unsigned int handle)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::setOutputByPlugin(systemi, handle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, handle);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setOutputByPlugin",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21a9620 | Name: _ZN4FMOD6System17getOutputByPluginEPj
FMOD_RESULT_1 __fastcall FMOD::System::getOutputByPlugin(FMOD::System *const this, unsigned int *handle)
{
  FMOD_RESULT_1 OutputByPlugin; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  OutputByPlugin = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (OutputByPlugin || (OutputByPlugin = FMOD::SystemI::getOutputByPlugin(systemi, handle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, handle);
    FMOD_ReportError(
      OutputByPlugin,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getOutputByPlugin",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return OutputByPlugin;
}


// Address: 0x21a96d0 | Name: _ZN4FMOD6System17createDSPByPluginEjPPNS_3DSPE
FMOD_RESULT_1 __fastcall FMOD::System::createDSPByPlugin(
        FMOD::System *const this,
        unsigned int handle,
        FMOD::DSP **dsp)
{
  FMOD_RESULT_1 DSPByPlugin; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  DSPByPlugin = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (DSPByPlugin
     || (DSPByPlugin = FMOD::SystemI::createDSPByPlugin(systemi, handle, (FMOD::DSPI **)dsp)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, handle);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), dsp);
    FMOD_ReportError(
      DSPByPlugin,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::createDSPByPlugin",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return DSPByPlugin;
}


// Address: 0x21a97d0 | Name: _ZN4FMOD6System18getDSPInfoByPluginEjPPK20FMOD_DSP_DESCRIPTION
FMOD_RESULT_1 __fastcall FMOD::System::getDSPInfoByPlugin(
        FMOD::System *const this,
        unsigned int handle,
        const FMOD_DSP_DESCRIPTION **description)
{
  FMOD_RESULT_1 DSPInfoByPlugin; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  DSPInfoByPlugin = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (DSPInfoByPlugin
     || (DSPInfoByPlugin = FMOD::SystemI::getDSPInfoByPlugin(systemi, handle, description)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, handle);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), description);
    FMOD_ReportError(
      DSPInfoByPlugin,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getDSPInfoByPlugin",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return DSPInfoByPlugin;
}


// Address: 0x21a98d0 | Name: _ZN4FMOD6System13registerCodecEP22FMOD_CODEC_DESCRIPTIONPjj
FMOD_RESULT_1 __fastcall FMOD::System::registerCodec(
        FMOD::System *const this,
        FMOD_CODEC_DESCRIPTION *description,
        unsigned int *handle,
        unsigned int priority)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v6 || (v6 = FMOD::SystemI::registerCodec(systemi, description, handle, priority)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, description);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), handle);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), priority);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::registerCodec",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21a9a20 | Name: _ZN4FMOD6System11registerDSPEPK20FMOD_DSP_DESCRIPTIONPj
FMOD_RESULT_1 __fastcall FMOD::System::registerDSP(
        FMOD::System *const this,
        const FMOD_DSP_DESCRIPTION *description,
        unsigned int *handle)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4 || (v4 = FMOD::SystemI::registerDSP(systemi, description, handle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, description);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), handle);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::registerDSP",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21a9b20 | Name: _ZN4FMOD6System14registerOutputEPK23FMOD_OUTPUT_DESCRIPTIONPj
FMOD_RESULT_1 __fastcall FMOD::System::registerOutput(
        FMOD::System *const this,
        const FMOD_OUTPUT_DESCRIPTION *description,
        unsigned int *handle)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4 || (v4 = FMOD::SystemI::registerOutput(systemi, description, handle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, description);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), handle);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::registerOutput",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21a9c20 | Name: _ZN4FMOD6System4initEijPv
FMOD_RESULT_1 __fastcall FMOD::System::init(
        FMOD::System *const this,
        int maxchannels,
        FMOD_INITFLAGS flags,
        void *extradriverdata)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  v6 = FMOD::SystemI::validate(this, &systemi, 0);
  if ( (v6 || (v6 = FMOD::SystemI::init(systemi, maxchannels, flags, extradriverdata)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, maxchannels);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), flags);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), extradriverdata);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::init",
      _buffer);
  }
  return v6;
}


// Address: 0x21a9d60 | Name: _ZN4FMOD6System5closeEv
FMOD_RESULT_1 __fastcall FMOD::System::close(FMOD::System *const this)
{
  FMOD_RESULT_1 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( v1 )
    goto LABEL_2;
  if ( !lockScope.mSystem || FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem) == FMOD_RESULT::FMOD_OK_0 )
    lockScope.mSystem = 0;
  v1 = FMOD::SystemI::close(systemi);
  if ( v1 )
  {
LABEL_2:
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      _buffer[0] = 0;
      FMOD_ReportError(
        v1,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
        this,
        "System::close",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x21a9e10 | Name: _ZN4FMOD6System6updateEv
FMOD_RESULT_1 __fastcall FMOD::System::update(FMOD::System *const this)
{
  FMOD_RESULT_1 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v1 || (v1 = FMOD::SystemI::update(systemi)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      v1,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::update",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x21a9eb0 | Name: _ZN4FMOD6System18setSpeakerPositionE12FMOD_SPEAKERffb
__int64 __fastcall FMOD::System::setSpeakerPosition(
        FMOD::System *const this,
        __int32 speaker,
        float x,
        float y,
        bool active)
{
  FMOD_RESULT_0 v6; // ebx
  int v8; // r15d
  int v9; // r15d
  int v10; // r15d
  int v11; // r15d
  int v12; // r15d
  int v13; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v6
     || (v6 = FMOD::SystemI::setSpeakerPosition(systemi, (FMOD_SPEAKER_0)speaker, x, y, active)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v8 = FMOD::FMOD_FormatArg(_buffer, 256, speaker);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v8], 256 - v8, ", ") + v8;
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, y) + v9;
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, y) + v11;
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), active);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setSpeakerPosition",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v6;
}


// Address: 0x21aa040 | Name: _ZN4FMOD6System18getSpeakerPositionE12FMOD_SPEAKERPfS2_Pb
FMOD_RESULT_1 __fastcall FMOD::System::getSpeakerPosition(
        FMOD::System *const this,
        FMOD_SPEAKER_1 speaker,
        float *x,
        float *y,
        bool *active)
{
  FMOD_RESULT_1 SpeakerPosition; // r13d
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r14d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  SpeakerPosition = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (SpeakerPosition
     || (SpeakerPosition = FMOD::SystemI::getSpeakerPosition(systemi, speaker, x, y, active)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, speaker);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), x);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = v11 + FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, y);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), active);
    FMOD_ReportError(
      SpeakerPosition,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getSpeakerPosition",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return SpeakerPosition;
}


// Address: 0x21aa1d0 | Name: _ZN4FMOD6System19setStreamBufferSizeEjj
FMOD_RESULT_1 __fastcall FMOD::System::setStreamBufferSize(
        FMOD::System *const this,
        unsigned int filebuffersize,
        FMOD_TIMEUNIT filebuffersizetype)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4
     || (v4 = FMOD::SystemI::setStreamBufferSize(systemi, filebuffersize, filebuffersizetype)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, filebuffersize);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), filebuffersizetype);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setStreamBufferSize",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21aa2d0 | Name: _ZN4FMOD6System19getStreamBufferSizeEPjS1_
FMOD_RESULT_1 __fastcall FMOD::System::getStreamBufferSize(
        FMOD::System *const this,
        unsigned int *filebuffersize,
        FMOD_TIMEUNIT *filebuffersizetype)
{
  FMOD_RESULT_1 StreamBufferSize; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  StreamBufferSize = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (StreamBufferSize
     || (StreamBufferSize = FMOD::SystemI::getStreamBufferSize(systemi, filebuffersize, filebuffersizetype)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, filebuffersize);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), filebuffersizetype);
    FMOD_ReportError(
      StreamBufferSize,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getStreamBufferSize",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return StreamBufferSize;
}


// Address: 0x21aa3d0 | Name: _ZN4FMOD6System13set3DSettingsEfff
__int64 __fastcall FMOD::System::set3DSettings(
        FMOD::System *const this,
        double a2,
        float dopplerscale,
        float distancefactor,
        float rolloffscale)
{
  FMOD_RESULT_0 v5; // ebx
  int v7; // r14d
  int v8; // r14d
  int v9; // r14d
  int v10; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v5 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v5
     || (v5 = FMOD::SystemI::set3DSettings(systemi, dopplerscale, distancefactor, rolloffscale)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v7 = FMOD::FMOD_FormatArg(_buffer, 256, dopplerscale);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v7], 256 - v7, ", ") + v7;
    v9 = FMOD::FMOD_FormatArg(&_buffer[v8], 256 - v8, dopplerscale) + v8;
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), dopplerscale);
    FMOD_ReportError(
      v5,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::set3DSettings",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v5;
}


// Address: 0x21aa530 | Name: _ZN4FMOD6System13get3DSettingsEPfS1_S1_
FMOD_RESULT_1 __fastcall FMOD::System::get3DSettings(
        FMOD::System *const this,
        float *dopplerscale,
        float *distancefactor,
        float *rolloffscale)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v6
     || (v6 = FMOD::SystemI::get3DSettings(systemi, dopplerscale, distancefactor, rolloffscale)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, dopplerscale);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), distancefactor);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), rolloffscale);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::get3DSettings",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21aa680 | Name: _ZN4FMOD6System17set3DNumListenersEi
FMOD_RESULT_1 __fastcall FMOD::System::set3DNumListeners(FMOD::System *const this, int numlisteners)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::set3DNumListeners(systemi, numlisteners)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numlisteners);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::set3DNumListeners",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21aa730 | Name: _ZN4FMOD6System17get3DNumListenersEPi
FMOD_RESULT_1 __fastcall FMOD::System::get3DNumListeners(FMOD::System *const this, int *numlisteners)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::get3DNumListeners(systemi, numlisteners)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numlisteners);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::get3DNumListeners",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21aa7e0 | Name: _ZN4FMOD6System23set3DListenerAttributesEiPK11FMOD_VECTORS3_S3_S3_
FMOD_RESULT_1 __fastcall FMOD::System::set3DListenerAttributes(
        FMOD::System *const this,
        int listener,
        const FMOD_VECTOR *pos,
        const FMOD_VECTOR *vel,
        const FMOD_VECTOR *forward,
        const FMOD_VECTOR *up)
{
  FMOD_RESULT_1 v8; // r13d
  int v10; // eax
  int v11; // r15d
  int v12; // r15d
  int v13; // r15d
  int v14; // r15d
  int v15; // r14d
  int v16; // eax
  int v19; // [rsp+1Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+20h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+28h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+30h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v8 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v8
     || (v8 = FMOD::SystemI::set3DListenerAttributes(systemi, listener, pos, vel, forward, up)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v19 = FMOD::FMOD_FormatArg(_buffer, 256, listener);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, ", ");
    v11 = v10 + v19 + FMOD::FMOD_FormatArg(&_buffer[v10 + v19], 256 - (v10 + v19), pos);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ") + v11;
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, vel) + v12;
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ") + v13;
    v15 = v14 + FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, forward);
    v16 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v16 + v15], 256 - (v16 + v15), up);
    FMOD_ReportError(
      v8,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::set3DListenerAttributes",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v8;
}


// Address: 0x21aa9b0 | Name: _ZN4FMOD6System23get3DListenerAttributesEiP11FMOD_VECTORS2_S2_S2_
FMOD_RESULT_1 __fastcall FMOD::System::get3DListenerAttributes(
        FMOD::System *const this,
        int listener,
        FMOD_VECTOR *pos,
        FMOD_VECTOR *vel,
        FMOD_VECTOR *forward,
        FMOD_VECTOR *up)
{
  FMOD_RESULT_1 v8; // r13d
  int v10; // eax
  int v11; // r15d
  int v12; // r15d
  int v13; // r15d
  int v14; // r15d
  int v15; // r14d
  int v16; // eax
  int v19; // [rsp+1Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+20h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+28h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+30h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v8 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v8
     || (v8 = FMOD::SystemI::get3DListenerAttributes(systemi, listener, pos, vel, forward, up)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v19 = FMOD::FMOD_FormatArg(_buffer, 256, listener);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, ", ");
    v11 = v10 + v19 + FMOD::FMOD_FormatArg(&_buffer[v10 + v19], 256 - (v10 + v19), pos);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ") + v11;
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, vel) + v12;
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ") + v13;
    v15 = v14 + FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, forward);
    v16 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v16 + v15], 256 - (v16 + v15), up);
    FMOD_ReportError(
      v8,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::get3DListenerAttributes",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v8;
}


// Address: 0x21aab80 | Name: _ZN4FMOD6System20set3DRolloffCallbackEPFfP19FMOD_CHANNELCONTROLfE
FMOD_RESULT_1 __fastcall FMOD::System::set3DRolloffCallback(
        FMOD::System *const this,
        FMOD_3D_ROLLOFF_CALLBACK callback)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::set3DRolloffCallback(systemi, callback)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, callback != 0);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::set3DRolloffCallback",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21aac30 | Name: _ZN4FMOD6System12mixerSuspendEv
FMOD_RESULT_1 __fastcall FMOD::System::mixerSuspend(FMOD::System *const this)
{
  FMOD_RESULT_1 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v1 || (v1 = FMOD::SystemI::mixerSuspend(systemi)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      v1,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::mixerSuspend",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x21aacd0 | Name: _ZN4FMOD6System11mixerResumeEv
FMOD_RESULT_1 __fastcall FMOD::System::mixerResume(FMOD::System *const this)
{
  FMOD_RESULT_1 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v1 || (v1 = FMOD::SystemI::mixerResume(systemi)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      v1,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::mixerSuspend",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x21aad70 | Name: _ZN4FMOD6System22getSpeakerModeChannelsE16FMOD_SPEAKERMODEPi
FMOD_RESULT_1 __fastcall FMOD::System::getSpeakerModeChannels(
        FMOD::System *const this,
        FMOD_SPEAKERMODE_1 mode,
        int *channels)
{
  FMOD_RESULT_1 SpeakerModeChannels; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  SpeakerModeChannels = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (SpeakerModeChannels
     || (SpeakerModeChannels = FMOD::SystemI::getSpeakerModeChannels(systemi, mode, channels)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      SpeakerModeChannels,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getSpeakerModeChannels",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return SpeakerModeChannels;
}


// Address: 0x21aae10 | Name: _ZN4FMOD6System19getDefaultMixMatrixE16FMOD_SPEAKERMODES1_Pfi
FMOD_RESULT_1 __fastcall FMOD::System::getDefaultMixMatrix(
        FMOD::System *const this,
        FMOD_SPEAKERMODE_1 sourceSpeakerMode,
        FMOD_SPEAKERMODE_1 targetSpeakerMode,
        float *matrix,
        int matrixHop)
{
  FMOD_RESULT_1 DefaultMixMatrix; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  DefaultMixMatrix = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (DefaultMixMatrix
     || (DefaultMixMatrix = FMOD::SystemI::getDefaultMixMatrix(
                              systemi,
                              sourceSpeakerMode,
                              targetSpeakerMode,
                              matrix,
                              matrixHop)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      DefaultMixMatrix,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getDefaultMixMatrix",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return DefaultMixMatrix;
}


// Address: 0x21aaed0 | Name: _ZN4FMOD6System10getVersionEPj
FMOD_RESULT_1 __fastcall FMOD::System::getVersion(FMOD::System *const this, unsigned int *version)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::getVersion(systemi, version)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, version);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getVersion",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21aaf80 | Name: _ZN4FMOD6System15getOutputHandleEPPv
FMOD_RESULT_1 __fastcall FMOD::System::getOutputHandle(FMOD::System *const this, void **handle)
{
  FMOD_RESULT_1 OutputHandle; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  OutputHandle = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (OutputHandle || (OutputHandle = FMOD::SystemI::getOutputHandle(systemi, handle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, handle);
    FMOD_ReportError(
      OutputHandle,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getOutputHandle",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return OutputHandle;
}


// Address: 0x21ab030 | Name: _ZN4FMOD6System18getChannelsPlayingEPiS1_
FMOD_RESULT_1 __fastcall FMOD::System::getChannelsPlaying(FMOD::System *const this, int *channels, int *realchannels)
{
  FMOD_RESULT_1 ChannelsPlaying; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  ChannelsPlaying = FMOD::SystemI::validate(this, &systemi, 0);
  if ( (ChannelsPlaying
     || (ChannelsPlaying = FMOD::SystemI::getChannelsPlaying(systemi, channels, realchannels)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, channels);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), realchannels);
    FMOD_ReportError(
      ChannelsPlaying,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getChannelsPlaying",
      _buffer);
  }
  return ChannelsPlaying;
}


// Address: 0x21ab110 | Name: _ZN4FMOD6System11getCPUUsageEPfS1_S1_S1_S1_
FMOD_RESULT_1 __fastcall FMOD::System::getCPUUsage(
        FMOD::System *const this,
        float *dsp,
        float *stream,
        float *geometry,
        float *update,
        float *total)
{
  FMOD_RESULT_1 CPUUsage; // r9d
  int v11; // eax
  int v12; // r15d
  int v13; // r15d
  int v14; // r15d
  int v15; // r15d
  int v16; // r14d
  int v17; // eax
  int v19; // [rsp+8h] [rbp-150h]
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  CPUUsage = FMOD::SystemI::validate(this, &systemi, 0);
  if ( (CPUUsage
     || (CPUUsage = FMOD::SystemI::getCPUUsage(systemi, dsp, stream, geometry, update, total)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = CPUUsage;
    v19 = FMOD::FMOD_FormatArg(_buffer, 256, dsp);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, ", ");
    v12 = v11 + v19 + FMOD::FMOD_FormatArg(&_buffer[v11 + v19], 256 - (v11 + v19), stream);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ") + v12;
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, geometry) + v13;
    v15 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, ", ") + v14;
    v16 = v15 + FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, update);
    v17 = FMOD::FMOD_FormatArg(&_buffer[v16], 256 - v16, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v17 + v16], 256 - (v17 + v16), total);
    FMOD_ReportError(
      __result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getCPUUsage",
      _buffer);
    return __result;
  }
  return CPUUsage;
}


// Address: 0x21ab2d0 | Name: _ZN4FMOD6System12getFileUsageEPxS1_S1_
FMOD_RESULT_1 __fastcall FMOD::System::getFileUsage(
        FMOD::System *const this,
        __int64 *sampleBytesRead,
        __int64 *streamBytesRead,
        __int64 *otherBytesRead)
{
  FMOD_RESULT_1 FileUsage; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  FileUsage = FMOD::SystemI::validate(this, &systemi, 0);
  if ( (FileUsage
     || (FileUsage = FMOD::SystemI::getFileUsage(systemi, sampleBytesRead, streamBytesRead, otherBytesRead)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, sampleBytesRead);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), streamBytesRead);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), otherBytesRead);
    FMOD_ReportError(
      FileUsage,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getFileUsage",
      _buffer);
  }
  return FileUsage;
}


// Address: 0x21ab410 | Name: _ZN4FMOD6System11createSoundEPKcjP22FMOD_CREATESOUNDEXINFOPPNS_5SoundE
FMOD_RESULT_1 __fastcall FMOD::System::createSound(
        FMOD::System *const this,
        const char *name_or_data,
        FMOD_MODE mode,
        FMOD_CREATESOUNDEXINFO_1 *exinfo,
        FMOD::Sound **sound)
{
  FMOD_RESULT_1 v8; // r9d
  int v10; // eax
  int v11; // r15d
  int v12; // r15d
  int v13; // r14d
  int v14; // eax
  int v15; // [rsp+8h] [rbp-150h]
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  v8 = FMOD::SystemI::validate(this, &systemi, 0);
  if ( (v8
     || (v8 = FMOD::SystemI::createSound(
                systemi,
                name_or_data,
                mode,
                (FMOD_CREATESOUNDEXINFO *)exinfo,
                (FMOD::SoundI **)sound)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = v8;
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, name_or_data);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v11 = v10 + v15 + FMOD::FMOD_FormatArg(&_buffer[v10 + v15], 256 - (v10 + v15), mode);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ") + v11;
    v13 = v12 + FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, exinfo);
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v14 + v13], 256 - (v14 + v13), sound);
    FMOD_ReportError(
      __result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::createSound",
      _buffer);
    return __result;
  }
  return v8;
}


// Address: 0x21ab590 | Name: _ZN4FMOD6System12createStreamEPKcjP22FMOD_CREATESOUNDEXINFOPPNS_5SoundE
FMOD_RESULT_1 __fastcall FMOD::System::createStream(
        FMOD::System *const this,
        const char *name_or_data,
        FMOD_MODE mode,
        FMOD_CREATESOUNDEXINFO_1 *exinfo,
        FMOD::Sound **sound)
{
  FMOD_RESULT_1 Stream; // r9d
  int v10; // eax
  int v11; // r15d
  int v12; // r15d
  int v13; // r14d
  int v14; // eax
  int v15; // [rsp+8h] [rbp-150h]
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  Stream = FMOD::SystemI::validate(this, &systemi, 0);
  if ( (Stream
     || (Stream = FMOD::SystemI::createStream(
                    systemi,
                    name_or_data,
                    mode,
                    (FMOD_CREATESOUNDEXINFO *)exinfo,
                    (FMOD::SoundI **)sound)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = Stream;
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, name_or_data);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v11 = v10 + v15 + FMOD::FMOD_FormatArg(&_buffer[v10 + v15], 256 - (v10 + v15), mode);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ") + v11;
    v13 = v12 + FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, exinfo);
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v14 + v13], 256 - (v14 + v13), sound);
    FMOD_ReportError(
      __result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::createStream",
      _buffer);
    return __result;
  }
  return Stream;
}


// Address: 0x21ab710 | Name: _ZN4FMOD6System9createDSPEPK20FMOD_DSP_DESCRIPTIONPPNS_3DSPE
FMOD_RESULT_1 __fastcall FMOD::System::createDSP(
        FMOD::System *const this,
        const FMOD_DSP_DESCRIPTION *description,
        FMOD::DSP **dsp)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4 || (v4 = FMOD::SystemI::createDSP(systemi, description, (FMOD::DSPI **)dsp)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, description);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), dsp);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::createDSP",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21ab810 | Name: _ZN4FMOD6System15createDSPByTypeE13FMOD_DSP_TYPEPPNS_3DSPE
__int64 __fastcall FMOD::System::createDSPByType(FMOD::System *this, __int32 a2, FMOD::DSP **a3)
{
  FMOD_RESULT_0 DSPByType; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  DSPByType = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (DSPByType
     || (DSPByType = (unsigned int)FMOD::SystemI::createDSPByType(systemi, (FMOD_DSP_TYPE)a2, (FMOD::DSPI **)a3)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, a2);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), a3);
    FMOD_ReportError(
      DSPByType,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::createDSPByType",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)DSPByType;
}


// Address: 0x21ab910 | Name: _ZN4FMOD6System18createChannelGroupEPKcPPNS_12ChannelGroupE
FMOD_RESULT_1 __fastcall FMOD::System::createChannelGroup(
        FMOD::System *const this,
        const char *name,
        FMOD::ChannelGroup **channelgroup)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4
     || (v4 = FMOD::SystemI::createChannelGroup(systemi, name, (FMOD::ChannelGroupI **)channelgroup)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, name);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), channelgroup);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::createChannelGroup",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21aba10 | Name: _ZN4FMOD6System16createSoundGroupEPKcPPNS_10SoundGroupE
FMOD_RESULT_1 __fastcall FMOD::System::createSoundGroup(
        FMOD::System *const this,
        const char *name,
        FMOD::SoundGroup **soundgroup)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4
     || (v4 = FMOD::SystemI::createSoundGroup(systemi, name, (FMOD::SoundGroupI **)soundgroup)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, name);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), soundgroup);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::createSoundGroup",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21abb10 | Name: _ZN4FMOD6System14createReverb3DEPPNS_8Reverb3DE
FMOD_RESULT_1 __fastcall FMOD::System::createReverb3D(FMOD::System *const this, FMOD::Reverb3D **reverb)
{
  FMOD_RESULT_1 Reverb3D; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  Reverb3D = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (Reverb3D
     || (Reverb3D = FMOD::SystemI::createReverb3D(systemi, (FMOD::ReverbI **)reverb)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, reverb);
    FMOD_ReportError(
      Reverb3D,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::createReverb3D",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return Reverb3D;
}


// Address: 0x21abbc0 | Name: _ZN4FMOD6System9playSoundEPNS_5SoundEPNS_12ChannelGroupEbPPNS_7ChannelE
FMOD_RESULT_1 __fastcall FMOD::System::playSound(
        FMOD::System *const this,
        FMOD::Sound *sound,
        FMOD::ChannelGroup *channelgroup,
        bool paused,
        FMOD::Channel **channel)
{
  FMOD_RESULT_1 v7; // r13d
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r14d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v7
     || (v7 = FMOD::SystemI::playSound(
                systemi,
                (FMOD::SoundI *)sound,
                (FMOD::ChannelGroupI *)channelgroup,
                paused,
                (FMOD::ChannelI **)channel)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, sound);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), channelgroup);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = v11 + FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, paused);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), channel);
    FMOD_ReportError(
      v7,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::playSound",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v7;
}


// Address: 0x21abd50 | Name: _ZN4FMOD6System7playDSPEPNS_3DSPEPNS_12ChannelGroupEbPPNS_7ChannelE
FMOD_RESULT_1 __fastcall FMOD::System::playDSP(
        FMOD::System *const this,
        FMOD::DSP *dsp,
        FMOD::ChannelGroup *channelgroup,
        bool paused,
        FMOD::Channel **channel)
{
  FMOD_RESULT_1 v7; // r13d
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r14d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v7
     || (v7 = FMOD::SystemI::playDSP(
                systemi,
                (FMOD::DSPI *)dsp,
                (FMOD::ChannelGroupI *)channelgroup,
                paused,
                (FMOD::ChannelI **)channel)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, dsp);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), channelgroup);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = v11 + FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, paused);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), channel);
    FMOD_ReportError(
      v7,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::playDSP",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v7;
}


// Address: 0x21abee0 | Name: _ZN4FMOD6System10getChannelEiPPNS_7ChannelE
FMOD_RESULT_1 __fastcall FMOD::System::getChannel(FMOD::System *const this, int channelid, FMOD::Channel **channel)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4 || (v4 = FMOD::SystemI::getChannel(systemi, channelid, (FMOD::ChannelI **)channel)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, channelid);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), channel);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getChannel",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21abfe0 | Name: _ZN4FMOD6System21getMasterChannelGroupEPPNS_12ChannelGroupE
FMOD_RESULT_1 __fastcall FMOD::System::getMasterChannelGroup(
        FMOD::System *const this,
        FMOD::ChannelGroup **channelgroup)
{
  FMOD_RESULT_1 MasterChannelGroup; // ebx
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  MasterChannelGroup = FMOD::SystemI::validate(this, &systemi, 0);
  if ( MasterChannelGroup == FMOD_RESULT::FMOD_OK_0 )
  {
    MasterChannelGroup = FMOD::SystemI::getMasterChannelGroup(systemi, (FMOD::ChannelGroupI **)channelgroup);
    if ( MasterChannelGroup == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, channelgroup);
    FMOD_ReportError(
      MasterChannelGroup,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getMasterChannelGroup",
      _buffer);
  }
  return MasterChannelGroup;
}


// Address: 0x21ac0a0 | Name: _ZN4FMOD6System19getMasterSoundGroupEPPNS_10SoundGroupE
FMOD_RESULT_1 __fastcall FMOD::System::getMasterSoundGroup(FMOD::System *const this, FMOD::SoundGroup **soundgroup)
{
  FMOD_RESULT_1 MasterSoundGroup; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  MasterSoundGroup = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (MasterSoundGroup
     || (MasterSoundGroup = FMOD::SystemI::getMasterSoundGroup(systemi, (FMOD::SoundGroupI **)soundgroup)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, soundgroup);
    FMOD_ReportError(
      MasterSoundGroup,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getMasterSoundGroup",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return MasterSoundGroup;
}


// Address: 0x21ac150 | Name: _ZN4FMOD6System24attachChannelGroupToPortEjyPNS_12ChannelGroupEb
FMOD_RESULT_1 __fastcall FMOD::System::attachChannelGroupToPort(
        FMOD::System *const this,
        FMOD_PORT_TYPE portType,
        FMOD_PORT_INDEX portIndex,
        FMOD::ChannelGroup *channelgroup,
        bool passThru)
{
  FMOD_RESULT_1 v8; // ebx
  int v10; // eax
  int v11; // r13d
  int v12; // eax
  int v13; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v8 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v8
     || (v8 = FMOD::SystemI::attachChannelGroupToPort(
                systemi,
                portType,
                portIndex,
                (FMOD::ChannelGroupI *)channelgroup,
                passThru)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v13 = FMOD::FMOD_FormatArg(_buffer, 256, portType);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ");
    v11 = v10 + v13 + FMOD::FMOD_FormatArg(&_buffer[v10 + v13], 256 - (v10 + v13), portIndex);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v12 + v11], 256 - (v12 + v11), channelgroup);
    FMOD_ReportError(
      v8,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::attachChannelGroupToPort",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v8;
}


// Address: 0x21ac2a0 | Name: _ZN4FMOD6System26detachChannelGroupFromPortEPNS_12ChannelGroupE
FMOD_RESULT_1 __fastcall FMOD::System::detachChannelGroupFromPort(
        FMOD::System *const this,
        FMOD::ChannelGroup *channelgroup)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2
     || (v2 = FMOD::SystemI::detachChannelGroupFromPort(systemi, (FMOD::ChannelGroupI *)channelgroup)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, channelgroup);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::detachChannelGroupFromPort",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ac350 | Name: _ZN4FMOD6System19setReverbPropertiesEiPK22FMOD_REVERB_PROPERTIES
FMOD_RESULT_1 __fastcall FMOD::System::setReverbProperties(
        FMOD::System *const this,
        int instance,
        const FMOD_REVERB_PROPERTIES *prop)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4 || (v4 = FMOD::SystemI::setReverbProperties(systemi, instance, prop)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, instance);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), prop);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setReverbProperties",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21ac450 | Name: _ZN4FMOD6System19getReverbPropertiesEiP22FMOD_REVERB_PROPERTIES
FMOD_RESULT_1 __fastcall FMOD::System::getReverbProperties(
        FMOD::System *const this,
        int instance,
        FMOD_REVERB_PROPERTIES *prop)
{
  FMOD_RESULT_1 ReverbProperties; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  ReverbProperties = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (ReverbProperties
     || (ReverbProperties = FMOD::SystemI::getReverbProperties(systemi, instance, prop)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, instance);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), prop);
    FMOD_ReportError(
      ReverbProperties,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getReverbProperties",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return ReverbProperties;
}


// Address: 0x21ac550 | Name: _ZN4FMOD6System7lockDSPEv
FMOD_RESULT_1 __fastcall FMOD::System::lockDSP(FMOD::System *const this)
{
  FMOD_RESULT_1 result; // eax
  FMOD_RESULT_1 __result; // [rsp+Ch] [rbp-11Ch]
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-110h] BYREF
  char _buffer[264]; // [rsp+20h] [rbp-108h] BYREF

  result = FMOD::SystemI::validate(this, &systemi, 0);
  if ( (result || (result = FMOD::SystemI::lockDSP(systemi)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = result;
    _buffer[0] = 0;
    FMOD_ReportError(
      result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::lockDSP",
      _buffer);
    return __result;
  }
  return result;
}


// Address: 0x21ac5e0 | Name: _ZN4FMOD6System9unlockDSPEv
FMOD_RESULT_1 __fastcall FMOD::System::unlockDSP(FMOD::System *const this)
{
  FMOD_RESULT_1 result; // eax
  FMOD_RESULT_1 __result; // [rsp+Ch] [rbp-11Ch]
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-110h] BYREF
  char _buffer[264]; // [rsp+20h] [rbp-108h] BYREF

  result = FMOD::SystemI::validate(this, &systemi, 0);
  if ( (result || (result = FMOD::SystemI::unlockDSP(systemi)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = result;
    _buffer[0] = 0;
    FMOD_ReportError(
      result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::unlockDSP",
      _buffer);
    return __result;
  }
  return result;
}


// Address: 0x21ac670 | Name: _ZN4FMOD6System19getRecordNumDriversEPiS1_
FMOD_RESULT_1 __fastcall FMOD::System::getRecordNumDrivers(
        FMOD::System *const this,
        int *numdrivers,
        int *numconnected)
{
  FMOD_RESULT_1 RecordNumDrivers; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  RecordNumDrivers = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (RecordNumDrivers
     || (RecordNumDrivers = FMOD::SystemI::getRecordNumDrivers(systemi, numdrivers, numconnected)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, numdrivers);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), numconnected);
    FMOD_ReportError(
      RecordNumDrivers,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getRecordNumDrivers",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return RecordNumDrivers;
}


// Address: 0x21ac770 | Name: _ZN4FMOD6System19getRecordDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_Pj
FMOD_RESULT_1 __fastcall FMOD::System::getRecordDriverInfo(
        FMOD::System *const this,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_1 *speakermode,
        int *speakermodechannels,
        FMOD_DRIVER_STATE *state)
{
  FMOD_RESULT_1 RecordDriverInfo; // r12d
  int v14; // eax
  int v15; // r15d
  int v16; // r15d
  int v17; // r15d
  int v18; // r15d
  int v19; // r14d
  int v20; // r14d
  int v21; // r13d
  int v22; // r13d
  int v23; // r13d
  int v24; // r13d
  int v25; // r13d
  int v26; // eax
  int v28; // [rsp+2Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+30h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+38h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+40h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  RecordDriverInfo = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (RecordDriverInfo
     || (RecordDriverInfo = FMOD::SystemI::getRecordDriverInfo(
                              systemi,
                              id,
                              name,
                              namelen,
                              guid,
                              systemrate,
                              speakermode,
                              speakermodechannels,
                              state)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v28 = FMOD::FMOD_FormatArg(_buffer, 256, id);
    v14 = FMOD::FMOD_FormatArg(&_buffer[v28], 256 - v28, ", ");
    v15 = v14 + v28 + FMOD::FMOD_FormatArg(&_buffer[v14 + v28], 256 - (v14 + v28), name);
    v16 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ") + v15;
    v17 = FMOD::FMOD_FormatArg(&_buffer[v16], 256 - v16, namelen) + v16;
    v18 = FMOD::FMOD_FormatArg(&_buffer[v17], 256 - v17, ", ") + v17;
    v19 = v18 + FMOD::FMOD_FormatArg(&_buffer[v18], 256 - v18, guid);
    v20 = FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, ", ") + v19;
    v21 = v20 + FMOD::FMOD_FormatArg(&_buffer[v20], 256 - v20, systemrate);
    v22 = FMOD::FMOD_FormatArg(&_buffer[v21], 256 - v21, ", ") + v21;
    v23 = FMOD::FMOD_FormatArg(&_buffer[v22], 256 - v22, speakermode) + v22;
    v24 = FMOD::FMOD_FormatArg(&_buffer[v23], 256 - v23, ", ") + v23;
    v25 = FMOD::FMOD_FormatArg(&_buffer[v24], 256 - v24, speakermodechannels) + v24;
    v26 = FMOD::FMOD_FormatArg(&_buffer[v25], 256 - v25, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v26 + v25], 256 - (v26 + v25), state);
    FMOD_ReportError(
      RecordDriverInfo,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getRecordDriverInfo",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return RecordDriverInfo;
}


// Address: 0x21ac9f0 | Name: _ZN4FMOD6System17getRecordPositionEiPj
FMOD_RESULT_1 __fastcall FMOD::System::getRecordPosition(FMOD::System *const this, int id, unsigned int *position)
{
  FMOD_RESULT_1 RecordPosition; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  RecordPosition = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (RecordPosition
     || (RecordPosition = FMOD::SystemI::getRecordPosition(systemi, id, position)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, id);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), position);
    FMOD_ReportError(
      RecordPosition,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getRecordPosition",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return RecordPosition;
}


// Address: 0x21acaf0 | Name: _ZN4FMOD6System11recordStartEiPNS_5SoundEb
FMOD_RESULT_1 __fastcall FMOD::System::recordStart(FMOD::System *const this, int id, FMOD::Sound *sound, bool loop)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v6 || (v6 = FMOD::SystemI::recordStart(systemi, id, (FMOD::SoundI *)sound, loop)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, id);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), sound);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), loop);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::recordStart",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21acc40 | Name: _ZN4FMOD6System10recordStopEi
FMOD_RESULT_1 __fastcall FMOD::System::recordStop(FMOD::System *const this, int id)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::recordStop(systemi, id)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, id);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::recordStop",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21accf0 | Name: _ZN4FMOD6System11isRecordingEiPb
FMOD_RESULT_1 __fastcall FMOD::System::isRecording(FMOD::System *const this, int id, bool *recording)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v4 || (v4 = FMOD::SystemI::isRecording(systemi, id, recording)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, id);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), recording);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::isRecording",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21acdf0 | Name: _ZN4FMOD6System14createGeometryEiiPPNS_8GeometryE
FMOD_RESULT_1 __fastcall FMOD::System::createGeometry(
        FMOD::System *const this,
        int maxpolygons,
        int maxvertices,
        FMOD::Geometry **geometry)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v6
     || (v6 = FMOD::SystemI::createGeometry(systemi, maxpolygons, maxvertices, (FMOD::GeometryI **)geometry)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, maxpolygons);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), maxvertices);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), geometry);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::createGeometry",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21acf40 | Name: _ZN4FMOD6System19setGeometrySettingsEf
__int64 __fastcall FMOD::System::setGeometrySettings(FMOD::System *const this, double a2, float maxworldsize)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v3 || (v3 = FMOD::SystemI::setGeometrySettings(systemi, maxworldsize)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, maxworldsize);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setGeometrySettings",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21acff0 | Name: _ZN4FMOD6System19getGeometrySettingsEPf
FMOD_RESULT_1 __fastcall FMOD::System::getGeometrySettings(FMOD::System *const this, float *maxworldsize)
{
  FMOD_RESULT_1 GeometrySettings; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  GeometrySettings = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (GeometrySettings
     || (GeometrySettings = FMOD::SystemI::getGeometrySettings(systemi, maxworldsize)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, maxworldsize);
    FMOD_ReportError(
      GeometrySettings,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getGeometrySettings",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return GeometrySettings;
}


// Address: 0x21ad0a0 | Name: _ZN4FMOD6System12loadGeometryEPKviPPNS_8GeometryE
FMOD_RESULT_1 __fastcall FMOD::System::loadGeometry(
        FMOD::System *const this,
        const void *data,
        int datasize,
        FMOD::Geometry **geometry)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v6
     || (v6 = FMOD::SystemI::loadGeometry(systemi, data, datasize, (FMOD::GeometryI **)geometry)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, data);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), datasize);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), geometry);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::loadGeometry",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21ad1f0 | Name: _ZN4FMOD6System20getGeometryOcclusionEPK11FMOD_VECTORS3_PfS4_
FMOD_RESULT_1 __fastcall FMOD::System::getGeometryOcclusion(
        FMOD::System *const this,
        const FMOD_VECTOR *listener,
        const FMOD_VECTOR *source,
        float *direct,
        float *reverb)
{
  FMOD_RESULT_1 GeometryOcclusion; // r13d
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r14d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  GeometryOcclusion = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (GeometryOcclusion
     || (GeometryOcclusion = FMOD::SystemI::getGeometryOcclusion(systemi, listener, source, direct, reverb)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, listener);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), source);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = v11 + FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, direct);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), reverb);
    FMOD_ReportError(
      GeometryOcclusion,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getGeometryOcclusion",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return GeometryOcclusion;
}


// Address: 0x21ad380 | Name: _ZN4FMOD6System15setNetworkProxyEPKc
FMOD_RESULT_1 __fastcall FMOD::System::setNetworkProxy(FMOD::System *const this, const char *proxy)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::setNetworkProxy(systemi, proxy)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, proxy);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setNetworkProxy",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ad430 | Name: _ZN4FMOD6System15getNetworkProxyEPci
FMOD_RESULT_1 __fastcall FMOD::System::getNetworkProxy(FMOD::System *const this, char *proxy, int proxylen)
{
  FMOD_RESULT_1 NetworkProxy; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  NetworkProxy = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (NetworkProxy
     || (NetworkProxy = FMOD::SystemI::getNetworkProxy(systemi, proxy, proxylen)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, proxy);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), proxylen);
    FMOD_ReportError(
      NetworkProxy,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getNetworkProxy",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return NetworkProxy;
}


// Address: 0x21ad530 | Name: _ZN4FMOD6System17setNetworkTimeoutEi
FMOD_RESULT_1 __fastcall FMOD::System::setNetworkTimeout(FMOD::System *const this, int timeout)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (v2 || (v2 = FMOD::SystemI::setNetworkTimeout(systemi, timeout)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, timeout);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setNetworkTimeout",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ad5e0 | Name: _ZN4FMOD6System17getNetworkTimeoutEPi
FMOD_RESULT_1 __fastcall FMOD::System::getNetworkTimeout(FMOD::System *const this, int *timeout)
{
  FMOD_RESULT_1 NetworkTimeout; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  NetworkTimeout = FMOD::SystemI::validate(this, &systemi, &lockScope);
  if ( (NetworkTimeout || (NetworkTimeout = FMOD::SystemI::getNetworkTimeout(systemi, timeout)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, timeout);
    FMOD_ReportError(
      NetworkTimeout,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::getNetworkTimeout",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return NetworkTimeout;
}


// Address: 0x21ad690 | Name: _ZN4FMOD6System11setUserDataEPv
FMOD_RESULT_1 __fastcall FMOD::System::setUserData(FMOD::System *const this, void *_userdata)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::SystemI::validate(this, &systemi, 0);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = FMOD::SystemI::setUserData(systemi, _userdata);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      "System::setUserData",
      _buffer);
  }
  return v2;
}


// Address: 0x21ad750 | Name: _ZN4FMOD6System11getUserDataEPPv
FMOD_RESULT_1 __fastcall FMOD::System::getUserData(FMOD::System *const this, void **_userdata)
{
  FMOD_RESULT_1 UserData; // ebx
  FMOD::SystemI *systemi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  UserData = FMOD::SystemI::validate(this, &systemi, 0);
  if ( UserData == FMOD_RESULT::FMOD_OK_0 )
  {
    UserData = FMOD::SystemI::getUserData(systemi, _userdata);
    if ( UserData == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      UserData,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SYSTEM,
      this,
      (const char *)&info_ptr.scal_unit + 3,
      _buffer);
  }
  return UserData;
}


