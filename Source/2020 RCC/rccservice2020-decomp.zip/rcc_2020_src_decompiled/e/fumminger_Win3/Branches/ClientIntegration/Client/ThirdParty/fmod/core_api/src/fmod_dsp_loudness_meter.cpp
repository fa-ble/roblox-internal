// Address: 0x21f4f80 | Name: _ZN4FMOD16DSPLoudnessMeter16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPLoudnessMeter::getDescriptionEx()
{
  memset(&stru_2ADC1A0, 0, sizeof(stru_2ADC1A0));
  stru_2ADC1A0.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2ADC1A0.name, "State", 16);
  FMOD_strcpy_safe(stru_2ADC1A0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2ADC1A0.floatdesc.min = 0x1FFFFFFFDLL;
  stru_2ADC1A0.description = "Integration state";
  memset(&stru_2ADC140, 0, sizeof(stru_2ADC140));
  *(_OWORD *)(&stru_2ADC1A0.datadesc + 2) = 1u;
  stru_2ADC140.type = FMOD_DSP_PARAMETER_TYPE_DATA;
  FMOD_strcpy_safe(stru_2ADC140.name, "Weights", 16);
  FMOD_strcpy_safe(stru_2ADC140.label, (const char *)&uri_string, 16);
  stru_2ADC140.intdesc.min = 0;
  stru_2ADC140.description = "Channel weightings for loudness";
  memset(&stru_2ADC0E0, 0, sizeof(stru_2ADC0E0));
  stru_2ADC0E0.type = FMOD_DSP_PARAMETER_TYPE_DATA;
  FMOD_strcpy_safe(stru_2ADC0E0.name, "Loudness", 16);
  FMOD_strcpy_safe(stru_2ADC0E0.label, (const char *)&uri_string, 16);
  stru_2ADC0E0.intdesc.min = -100;
  *(&stru_2ADC0A0.mHandle + 1) = 30;
  stru_2ADC0A0.mSize = 3680;
  stru_2ADC0E0.description = "Loudness info and maximum true peak level";
  stru_2ADC0A0.mDescription = &stru_286B7A0;
  return &stru_2ADC0A0;
}


// Address: 0x21f5110 | Name: _ZN4FMOD16DSPLoudnessMeter22initialiseLoudnessInfoEP22FMOD_DSP_LOUDNESS_INFO
void __fastcall FMOD::DSPLoudnessMeter::initialiseLoudnessInfo(FMOD_DSP_LOUDNESS_INFO *info)
{
  FMOD_DSP_LOUDNESS_INFO *v1; // rdx
  unsigned int v2; // esi
  __int64 v3; // rcx
  _DWORD *v4; // rdi
  _DWORD *loudness_histogram; // rdi
  unsigned int v6; // esi
  __int64 v7; // rcx
  _DWORD *v8; // rdi

  v1 = info;
  v2 = 292;
  if ( ((unsigned __int8)info & 1) == 0 )
  {
    if ( ((unsigned __int8)info & 2) == 0 )
      goto LABEL_3;
LABEL_21:
    info = (FMOD_DSP_LOUDNESS_INFO *)((char *)info + 2);
    v2 -= 2;
    HIWORD(info[-1].max_momentary_loudness) = 0;
    if ( ((unsigned __int8)info & 4) == 0 )
      goto LABEL_4;
    goto LABEL_22;
  }
  info = (FMOD_DSP_LOUDNESS_INFO *)((char *)info + 1);
  LOBYTE(v1->momentary_loudness) = 0;
  LOBYTE(v2) = 35;
  if ( (((_BYTE)v1 + 1) & 2) != 0 )
    goto LABEL_21;
LABEL_3:
  if ( ((unsigned __int8)info & 4) == 0 )
    goto LABEL_4;
LABEL_22:
  info->momentary_loudness = 0.0;
  v2 -= 4;
  info = (FMOD_DSP_LOUDNESS_INFO *)((char *)info + 4);
LABEL_4:
  v3 = v2 >> 3;
  memset(info, 0, 8 * v3);
  v4 = (_DWORD *)(&info->momentary_loudness + 2 * v3);
  if ( (v2 & 4) != 0 )
    *v4++ = 0;
  if ( (v2 & 2) != 0 )
  {
    v4 = (_DWORD *)((char *)v4 + 2);
    *((_WORD *)v4 - 1) = 0;
  }
  if ( (v2 & 1) != 0 )
    *(_BYTE *)v4 = 0;
  loudness_histogram = (_DWORD *)v1->loudness_histogram;
  v1->momentary_loudness = -80.0;
  v1->shortterm_loudness = -80.0;
  v1->integrated_loudness = -80.0;
  v1->loudness_10th_percentile = -80.0;
  v6 = 264;
  v1->loudness_95th_percentile = -80.0;
  if ( (((_BYTE)v1 + 20) & 1) == 0 )
  {
    if ( ((unsigned __int8)loudness_histogram & 2) == 0 )
      goto LABEL_12;
LABEL_24:
    loudness_histogram = (_DWORD *)((char *)loudness_histogram + 2);
    v6 -= 2;
    *((_WORD *)loudness_histogram - 1) = 0;
    if ( ((unsigned __int8)loudness_histogram & 4) == 0 )
      goto LABEL_13;
    goto LABEL_25;
  }
  loudness_histogram = (_DWORD *)((char *)v1->loudness_histogram + 1);
  LOBYTE(v1->loudness_histogram[0]) = 0;
  LOBYTE(v6) = 7;
  if ( (((_BYTE)v1 + 21) & 2) != 0 )
    goto LABEL_24;
LABEL_12:
  if ( ((unsigned __int8)loudness_histogram & 4) == 0 )
    goto LABEL_13;
LABEL_25:
  *loudness_histogram = 0;
  v6 -= 4;
  ++loudness_histogram;
LABEL_13:
  v7 = v6 >> 3;
  memset(loudness_histogram, 0, 8 * v7);
  v8 = &loudness_histogram[2 * v7];
  if ( (v6 & 4) != 0 )
    *v8++ = 0;
  if ( (v6 & 2) != 0 )
  {
    v8 = (_DWORD *)((char *)v8 + 2);
    *((_WORD *)v8 - 1) = 0;
  }
  if ( (v6 & 1) != 0 )
    *(_BYTE *)v8 = 0;
  v1->max_true_peak = -80.0;
  v1->max_momentary_loudness = -80.0;
}


// Address: 0x21f52a0 | Name: _ZN4FMOD16DSPLoudnessMeter14clearLevelListEPNS0_15LevelLinkedListE
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::clearLevelList(FMOD::DSPLoudnessMeter::LevelLinkedList *listHead)
{
  FMOD::DSPLoudnessMeter::LevelLinkedList *mNext; // rsi
  FMOD::DSPLoudnessMeter::LevelLinkedList *v2; // rbx

  mNext = listHead->mNext;
  listHead->mNext = 0;
  if ( !mNext )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    v2 = mNext->mNext;
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mNext, "../../../core_api/src/fmod_dsp_loudness_meter.cpp", 249);
    if ( !v2 )
      break;
    mNext = v2;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f5300 | Name: _ZN4FMOD16DSPLoudnessMeter15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::releaseInternal(FMOD::DSPLoudnessMeter *const this)
{
  FMOD::DSPLoudnessMeter::clearLevelList((FMOD::DSPLoudnessMeter::LevelLinkedList *)this + 219);
  FMOD::DSPLoudnessMeter::clearLevelList((FMOD::DSPLoudnessMeter::LevelLinkedList *)this + 220);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f5320 | Name: _ZN4FMOD16DSPLoudnessMeter15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLoudnessMeter::releaseInternal((FMOD::DSPLoudnessMeter *const)dsp_state->instance);
}


// Address: 0x21f5330 | Name: _ZN4FMOD16DSPLoudnessMeter13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::resetInternal(FMOD::DSPLoudnessMeter *const this)
{
  *((_BYTE *)this + 3536) = 1;
  *((_BYTE *)this + 3537) = 1;
  *((_BYTE *)this + 3538) = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f5350 | Name: _ZN4FMOD16DSPLoudnessMeter13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLoudnessMeter::resetInternal((FMOD::DSPLoudnessMeter *const)dsp_state->instance);
}


// Address: 0x21f5360 | Name: _ZN4FMOD16DSPLoudnessMeter24insertPowerIntoLevelListEfPNS0_15LevelLinkedListEf
__int64 __fastcall FMOD::DSPLoudnessMeter::insertPowerIntoLevelList(
        float a1,
        float power,
        FMOD::DSPLoudnessMeter::LevelLinkedList *listHead,
        float absoluteThreshold)
{
  float v6; // xmm1_4
  float v7; // xmm0_4
  __int64 result; // rax
  FMOD::DSPLoudnessMeter::LevelLinkedList *mNext; // rbx
  FMOD::DSPLoudnessMeter::LevelLinkedList *v10; // rax

  v6 = power + 0.69099998;
  if ( v6 > -80.0 )
    v7 = powf(10.0, v6 / 10.0);
  else
    v7 = 0.0;
  result = 0;
  if ( v7 <= a1 )
  {
    while ( 1 )
    {
      mNext = listHead->mNext;
      if ( !mNext || a1 <= mNext->mPower )
        break;
      listHead = listHead->mNext;
    }
    v10 = (FMOD::DSPLoudnessMeter::LevelLinkedList *)FMOD::MemPool::calloc(
                                                       off_286F358->gSystemMemPool,
                                                       16,
                                                       "../../../core_api/src/fmod_dsp_loudness_meter.cpp",
                                                       301,
                                                       0);
    listHead->mNext = v10;
    if ( v10 )
    {
      v10->mPower = a1;
      v10->mNext = mNext;
      return 0;
    }
    else
    {
      listHead->mNext = mNext;
      return 38;
    }
  }
  return result;
}


// Address: 0x21f5430 | Name: _ZN4FMOD16DSPLoudnessMeter13gatedLoudnessEPNS0_15LevelLinkedListEf
float __fastcall FMOD::DSPLoudnessMeter::gatedLoudness(
        FMOD::DSPLoudnessMeter::LevelLinkedList *listHead,
        float a2,
        float relativeThreshold)
{
  FMOD::DSPLoudnessMeter::LevelLinkedList *mNext; // rax
  float v4; // xmm1_4
  FMOD::DSPLoudnessMeter::LevelLinkedList *v5; // rdx
  int v6; // ecx
  float v7; // xmm2_4
  float v8; // xmm0_4
  float v9; // xmm0_4
  float mPower; // xmm1_4
  int v11; // edx
  float v12; // xmm0_4
  float v13; // xmm0_4

  mNext = listHead->mNext;
  if ( mNext )
  {
    v4 = 0.0;
    v5 = listHead->mNext;
    v6 = 0;
    do
    {
      v4 = v4 + v5->mPower;
      v5 = v5->mNext;
      ++v6;
    }
    while ( v5 );
    v7 = v4 / (float)v6;
  }
  else
  {
    v7 = NAN;
  }
  if ( a2 < 80.0 )
  {
    v8 = powf(10.0, (float)-a2 / 10.0);
    mNext = listHead->mNext;
  }
  else
  {
    v8 = 0.0;
  }
  v9 = v8 * v7;
  if ( mNext )
  {
    while ( 1 )
    {
      mPower = mNext->mPower;
      if ( v9 <= mNext->mPower )
        break;
      mNext = mNext->mNext;
      if ( !mNext )
        goto LABEL_16;
    }
    v11 = 0;
    v12 = 0.0;
    while ( 1 )
    {
      mNext = mNext->mNext;
      ++v11;
      v12 = v12 + mPower;
      if ( !mNext )
        break;
      mPower = mNext->mPower;
    }
    v13 = v12 / (float)v11;
    if ( v13 <= 0.0 )
      return -80.691002;
  }
  else
  {
LABEL_16:
    v13 = NAN;
  }
  return (float)(log10f(v13) * 10.0) - 0.69099998;
}


// Address: 0x21f5550 | Name: _ZN4FMOD16DSPLoudnessMeter16getLoudnessRangeEPNS0_15LevelLinkedListEfffPfS3_
float __fastcall FMOD::DSPLoudnessMeter::getLoudnessRange(
        FMOD::DSPLoudnessMeter::LevelLinkedList *listHead,
        float relativeThreshold,
        __m128 lowPercentile,
        __m128 highPercentile,
        float *lowLoudness,
        float *highLoudness)
{
  __m128 v6; // xmm4
  FMOD::DSPLoudnessMeter::LevelLinkedList *mNext; // rbx
  FMOD::DSPLoudnessMeter::LevelLinkedList *v9; // rax
  int v10; // ecx
  float v11; // xmm3_4
  float v12; // xmm3_4
  float v13; // xmm0_4
  float v14; // xmm3_4
  FMOD::DSPLoudnessMeter::LevelLinkedList *v15; // rax
  int i; // ecx
  int v17; // ebp
  __m128 v18; // xmm1
  float v19; // xmm1_4
  float result; // xmm0_4
  float v21; // xmm5_4
  float v22; // xmm4_4
  __m128 v23; // xmm8
  float v24; // xmm0_4
  __m128 v25; // xmm5
  float *p_mPower; // rax
  float v27; // xmm1_4
  float mPower; // xmm0_4
  float v29; // xmm0_4
  __m128 v30; // xmm1
  float *v31; // rax
  float v32; // xmm2_4
  float v33; // xmm3_4
  float v34; // xmm0_4
  float v35; // xmm0_4
  float low; // [rsp+8h] [rbp-50h]
  float v37; // [rsp+28h] [rbp-30h]

  v6 = lowPercentile;
  mNext = listHead->mNext;
  if ( mNext )
  {
    v9 = listHead->mNext;
    v10 = 0;
    v11 = 0.0;
    do
    {
      v11 = v11 + v9->mPower;
      v9 = v9->mNext;
      ++v10;
    }
    while ( v9 );
    v12 = v11 / (float)v10;
  }
  else
  {
    v12 = NAN;
  }
  if ( relativeThreshold < 80.0 )
  {
    v13 = powf(10.0, (float)-relativeThreshold / 10.0);
    v6 = (__m128)lowPercentile.m128_u32[0];
    highPercentile = (__m128)highPercentile.m128_u32[0];
    mNext = listHead->mNext;
  }
  else
  {
    v13 = 0.0;
  }
  v14 = v12 * v13;
  if ( !mNext )
    goto LABEL_19;
  while ( v14 > mNext->mPower )
  {
    mNext = mNext->mNext;
    if ( !mNext )
      goto LABEL_19;
  }
  v15 = mNext;
  for ( i = 0; ; ++i )
  {
    v15 = v15->mNext;
    if ( !v15 )
      break;
  }
  if ( highPercentile.m128_f32[0] < v6.m128_f32[0] )
    goto LABEL_19;
  v17 = 0;
  v6.m128_f32[0] = v6.m128_f32[0] * (float)i;
  v18 = v6;
  highPercentile.m128_f32[0] = (float)(highPercentile.m128_f32[0] * (float)i) / 100.0;
  v18.m128_f32[0] = v6.m128_f32[0] / 100.0;
  if ( (float)(v6.m128_f32[0] / 100.0) >= 1.0 )
  {
    while ( 1 )
    {
      mNext = mNext->mNext;
      ++v17;
      if ( !mNext )
        break;
      v22 = (float)v17;
      if ( (float)((float)v17 + 1.0) > v18.m128_f32[0] )
        goto LABEL_26;
    }
LABEL_19:
    v19 = -80.0;
    result = 0.0;
    v21 = -80.0;
    goto LABEL_20;
  }
  v17 = 0;
  v22 = (float)0;
LABEL_26:
  v23 = (__m128)0x7FFFFFFFu;
  v24 = v18.m128_f32[0];
  v25 = _mm_and_ps(v18, (__m128)0x7FFFFFFFu);
  if ( v25.m128_f32[0] < 8388608.0 )
  {
    v25.m128_f32[0] = (float)(int)v18.m128_f32[0];
    LODWORD(v24) = COERCE_UNSIGNED_INT(v25.m128_f32[0] - COERCE_FLOAT(_mm_cmpgt_ss(v25, v18).m128_u32[0] & 0x3F800000))
                 | _mm_andnot_ps((__m128)0x7FFFFFFFu, v18).m128_u32[0];
  }
  p_mPower = &mNext->mNext->mPower;
  v27 = v18.m128_f32[0] - v24;
  if ( p_mPower )
    mPower = (float)((float)(1.0 - v27) * mNext->mPower) + (float)(v27 * *p_mPower);
  else
    mPower = mNext->mPower;
  v21 = -80.691002;
  if ( mPower > 0.0 )
  {
    v37 = v22;
    highPercentile = (__m128)highPercentile.m128_u32[0];
    v23 = (__m128)0x7FFFFFFFu;
    v21 = (float)(10.0 * log10f(mPower)) - 0.69099998;
    v22 = v37;
  }
  if ( (float)(v22 + 1.0) <= highPercentile.m128_f32[0] )
  {
    while ( 1 )
    {
      mNext = mNext->mNext;
      ++v17;
      if ( !mNext )
        break;
      if ( (float)((float)v17 + 1.0) > highPercentile.m128_f32[0] )
        goto LABEL_38;
    }
    v19 = -80.0;
    goto LABEL_37;
  }
LABEL_38:
  v29 = highPercentile.m128_f32[0];
  v30 = _mm_and_ps(highPercentile, v23);
  if ( v30.m128_f32[0] < 8388608.0 )
  {
    v30.m128_f32[0] = (float)(int)highPercentile.m128_f32[0];
    LODWORD(v29) = COERCE_UNSIGNED_INT(v30.m128_f32[0] - COERCE_FLOAT(_mm_cmpgt_ss(v30, highPercentile).m128_u32[0] & 0x3F800000))
                 | _mm_andnot_ps(v23, highPercentile).m128_u32[0];
  }
  v31 = &mNext->mNext->mPower;
  v32 = highPercentile.m128_f32[0] - v29;
  if ( v31 )
    v33 = (float)((float)(1.0 - v32) * mNext->mPower) + (float)(v32 * *v31);
  else
    v33 = mNext->mPower;
  if ( v33 <= 0.0 )
  {
    v19 = -80.691002;
    if ( v21 >= -80.691002 )
    {
LABEL_44:
      v19 = v21;
      result = v21 - v21;
      goto LABEL_20;
    }
LABEL_37:
    result = v19 - v21;
    goto LABEL_20;
  }
  low = v21;
  v34 = log10f(v33);
  v21 = low;
  if ( (float)((float)(v34 * 10.0) - 0.69099998) <= low )
    goto LABEL_44;
  v35 = log10f(v33);
  v21 = low;
  v19 = (float)(10.0 * v35) - 0.69099998;
  result = v19 - low;
LABEL_20:
  if ( lowLoudness )
    *lowLoudness = v21;
  if ( highLoudness )
    *highLoudness = v19;
  return result;
}


// Address: 0x21f5910 | Name: _ZN4FMOD16DSPLoudnessMeter20getLoudnessHistogramEPNS0_15LevelLinkedListEffbiPf
void __fastcall FMOD::DSPLoudnessMeter::getLoudnessHistogram(
        FMOD::DSPLoudnessMeter::LevelLinkedList *listHead,
        float lowestLoudness,
        float highestLoudness,
        bool includeOutliers,
        int histogramLength,
        float *histogram)
{
  float v9; // xmm4_4
  float v10; // xmm0_4
  float v12; // xmm1_4
  FMOD::DSPLoudnessMeter::LevelLinkedList *mNext; // rbx
  float v14; // xmm5_4
  float v15; // xmm4_4
  int v16; // r12d
  float *i; // rbp
  float v18; // xmm0_4
  float v19; // xmm1_4
  float *v20; // rax
  float v21; // xmm0_4
  float v22; // xmm1_4
  float v23; // [rsp+0h] [rbp-58h]
  float v24; // [rsp+0h] [rbp-58h]
  float highestLoudnessb; // [rsp+4h] [rbp-54h]
  float highestLoudnessa; // [rsp+4h] [rbp-54h]
  float v27; // [rsp+Ch] [rbp-4Ch]
  float v28; // [rsp+10h] [rbp-48h]

  v9 = lowestLoudness;
  v10 = 0.0;
  v12 = lowestLoudness + 0.69099998;
  if ( v12 > -80.0 )
  {
    highestLoudnessa = highestLoudness;
    v24 = v9;
    v10 = powf(10.0, v12 / 10.0);
    v9 = v24;
    highestLoudness = highestLoudnessa;
  }
  if ( histogramLength )
  {
    if ( histogram )
    {
      v28 = v9;
      v27 = (float)(highestLoudness - v9) / (float)histogramLength;
      if ( v27 > 0.0 )
      {
        memset(histogram, 0, 4LL * histogramLength);
        mNext = listHead->mNext;
        v14 = v27;
        v15 = v28;
        if ( !includeOutliers )
        {
LABEL_7:
          v16 = 0;
          for ( i = histogram; v16 < histogramLength; ++i )
          {
            if ( !mNext )
              break;
            ++v16;
            v18 = 0.0;
            v19 = (float)((float)((float)v16 * v14) + v15) + 0.69099998;
            if ( v19 > -80.0 )
            {
              highestLoudnessb = v15;
              v23 = v14;
              v18 = powf(10.0, v19 / 10.0);
              v14 = v23;
              v15 = highestLoudnessb;
            }
            do
            {
              if ( v18 <= mNext->mPower )
                break;
              mNext = mNext->mNext;
              *i = *i + 1.0;
            }
            while ( mNext );
          }
          if ( includeOutliers && mNext )
          {
            v20 = &histogram[histogramLength - 1];
            v21 = *v20;
            do
            {
              mNext = mNext->mNext;
              v21 = v21 + 1.0;
            }
            while ( mNext );
            *v20 = v21;
          }
          return;
        }
        if ( mNext )
        {
          if ( v10 <= mNext->mPower )
            goto LABEL_7;
          v22 = *histogram;
          while ( 1 )
          {
            v22 = v22 + 1.0;
            mNext = mNext->mNext;
            *histogram = v22;
            if ( !mNext )
              break;
            if ( v10 <= mNext->mPower )
              goto LABEL_7;
          }
        }
        mNext = 0;
        goto LABEL_7;
      }
    }
  }
}


// Address: 0x21f5b80 | Name: _ZN4FMOD16DSPLoudnessMeter22calculateLoudnessRangeEPfS1_
void __fastcall FMOD::DSPLoudnessMeter::calculateLoudnessRange(
        FMOD::DSPLoudnessMeter *const this,
        float *range10thPercentile,
        float *range95thPercentile)
{
  FMOD::DSPLoudnessMeter::getLoudnessRange(
    (FMOD::DSPLoudnessMeter::LevelLinkedList *)this + 220,
    20.0,
    (__m128)0x41200000u,
    (__m128)0x42BE0000u,
    range10thPercentile,
    range95thPercentile);
}


// Address: 0x21f5bb0 | Name: _ZN4FMOD16DSPLoudnessMeter26calculateLoudnessHistogramEPf
void __fastcall FMOD::DSPLoudnessMeter::calculateLoudnessHistogram(
        FMOD::DSPLoudnessMeter *const this,
        float *histogram)
{
  FMOD::DSPLoudnessMeter::getLoudnessHistogram(
    (FMOD::DSPLoudnessMeter::LevelLinkedList *)this + 219,
    -60.0,
    6.0,
    0,
    66,
    histogram);
}


// Address: 0x21f5be0 | Name: _ZN4FMOD16DSPLoudnessMeter12resetBuffersEv
void __fastcall FMOD::DSPLoudnessMeter::resetBuffers(FMOD::DSPLoudnessMeter *const this)
{
  char *v2; // rdi
  unsigned int v3; // esi
  __int64 v4; // rcx
  char *v5; // rdi
  _DWORD *v6; // rdx
  char *v7; // rax
  int v8; // ecx

  FMOD::DSPLoudnessMeter::initialiseLoudnessInfo((FMOD_DSP_LOUDNESS_INFO *)((char *)this + 528));
  v2 = (char *)this + 3360;
  *((_DWORD *)this + 874) = -1029701632;
  *((_DWORD *)this + 871) = 0;
  *((_DWORD *)this + 872) = 0;
  v3 = 120;
  if ( (((_BYTE)this + 32) & 1) == 0 )
  {
    if ( ((unsigned __int8)v2 & 2) == 0 )
      goto LABEL_3;
LABEL_14:
    v2 += 2;
    v3 -= 2;
    *((_WORD *)v2 - 1) = 0;
    if ( ((unsigned __int8)v2 & 4) == 0 )
      goto LABEL_4;
    goto LABEL_15;
  }
  v2 = (char *)this + 3361;
  *((_BYTE *)this + 3360) = 0;
  LOBYTE(v3) = 119;
  if ( (((_BYTE)this + 33) & 2) != 0 )
    goto LABEL_14;
LABEL_3:
  if ( ((unsigned __int8)v2 & 4) == 0 )
    goto LABEL_4;
LABEL_15:
  *(_DWORD *)v2 = 0;
  v3 -= 4;
  v2 += 4;
LABEL_4:
  v4 = v3 >> 3;
  memset(v2, 0, 8 * v4);
  v5 = &v2[8 * v4];
  if ( (v3 & 4) != 0 )
  {
    *(_DWORD *)v5 = 0;
    v5 += 4;
  }
  if ( (v3 & 2) != 0 )
  {
    v5 += 2;
    *((_WORD *)v5 - 1) = 0;
  }
  if ( (v3 & 1) != 0 )
    *v5 = 0;
  v6 = (_DWORD *)((char *)this + 932);
  v7 = (char *)this + 1980;
  v8 = 32;
  do
  {
    *v6 = 0;
    *(v6 - 1) = 0;
    v7 += 44;
    v6[4] = 0;
    v6[3] = 0;
    v6 += 8;
    *((_DWORD *)v7 - 8) = 0;
    *((_DWORD *)v7 - 9) = 0;
    *((_DWORD *)v7 - 10) = 0;
    *((_DWORD *)v7 - 11) = 0;
    *((_DWORD *)v7 - 12) = 0;
    *((_DWORD *)v7 - 13) = 0;
    *((_DWORD *)v7 - 14) = 0;
    *((_DWORD *)v7 - 15) = 0;
    *((_DWORD *)v7 - 16) = 0;
    *((_DWORD *)v7 - 17) = 0;
    *((_DWORD *)v7 - 18) = 0;
    --v8;
  }
  while ( v8 );
}


// Address: 0x21f5d40 | Name: _ZN4FMOD16DSPLoudnessMeter15resetIntegratedEv
void __fastcall FMOD::DSPLoudnessMeter::resetIntegrated(FMOD::DSPLoudnessMeter *const this)
{
  char *v2; // rdi
  unsigned int v3; // esi
  __int64 v4; // rcx
  char *v5; // rdi

  FMOD::DSPLoudnessMeter::clearLevelList((FMOD::DSPLoudnessMeter::LevelLinkedList *)this + 219);
  FMOD::DSPLoudnessMeter::clearLevelList((FMOD::DSPLoudnessMeter::LevelLinkedList *)this + 220);
  v2 = (char *)this + 548;
  *((_DWORD *)this + 134) = -1029701632;
  *((_DWORD *)this + 135) = -1029701632;
  *((_DWORD *)this + 136) = -1029701632;
  v3 = 264;
  if ( (((_BYTE)this + 36) & 1) == 0 )
  {
    if ( ((unsigned __int8)v2 & 2) == 0 )
      goto LABEL_3;
LABEL_12:
    v2 += 2;
    v3 -= 2;
    *((_WORD *)v2 - 1) = 0;
    if ( ((unsigned __int8)v2 & 4) == 0 )
      goto LABEL_4;
    goto LABEL_13;
  }
  v2 = (char *)this + 549;
  *((_BYTE *)this + 548) = 0;
  LOBYTE(v3) = 7;
  if ( (((_BYTE)this + 37) & 2) != 0 )
    goto LABEL_12;
LABEL_3:
  if ( ((unsigned __int8)v2 & 4) == 0 )
    goto LABEL_4;
LABEL_13:
  *(_DWORD *)v2 = 0;
  v3 -= 4;
  v2 += 4;
LABEL_4:
  v4 = v3 >> 3;
  memset(v2, 0, 8 * v4);
  v5 = &v2[8 * v4];
  if ( (v3 & 4) != 0 )
  {
    *(_DWORD *)v5 = 0;
    v5 += 4;
  }
  if ( (v3 & 2) != 0 )
  {
    v5 += 2;
    *((_WORD *)v5 - 1) = 0;
  }
  if ( (v3 & 1) != 0 )
    *v5 = 0;
  *((_DWORD *)this + 204) = -1029701632;
  *((_DWORD *)this + 874) = -1029701632;
  *((_DWORD *)this + 875) = 0;
}


// Address: 0x21f5e50 | Name: _ZN4FMOD16DSPLoudnessMeter12resetMaxPeakEv
void __fastcall FMOD::DSPLoudnessMeter::resetMaxPeak(FMOD::DSPLoudnessMeter *const this)
{
  *((_DWORD *)this + 873) = 0;
  *((_DWORD *)this + 203) = -1029701632;
}


// Address: 0x21f5e70 | Name: _ZN4FMOD16DSPLoudnessMeter12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::readInternal(
        FMOD::DSPLoudnessMeter *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  unsigned int v8; // r12d
  float *v9; // rbx
  int v10; // r8d
  bool v11; // bp
  float *v12; // rsi
  float v13; // xmm1_4
  float v14; // xmm0_4
  float v15; // xmm7_4
  float v16; // xmm5_4
  int v17; // edi
  __int128 v18; // xmm6
  FMOD::DSPLoudnessMeter *v19; // rax
  float *v20; // r10
  float *v21; // r11
  float *v22; // rdx
  __int128 v23; // xmm11
  float *v24; // r9
  float v25; // xmm2_4
  float v26; // xmm3_4
  float v27; // xmm4_4
  float v28; // xmm1_4
  float v29; // xmm3_4
  float v30; // xmm0_4
  float v31; // xmm1_4
  float *v32; // r9
  float v33; // xmm2_4
  float v34; // xmm1_4
  float v35; // xmm4_4
  float v36; // xmm1_4
  float v37; // xmm3_4
  float v38; // xmm0_4
  float v39; // xmm3_4
  float v40; // xmm1_4
  float v41; // xmm0_4
  float v42; // xmm1_4
  float v43; // xmm14_4
  float v44; // xmm15_4
  float v45; // xmm2_4
  float v46; // xmm3_4
  float v47; // xmm4_4
  float v48; // xmm6_4
  float v49; // xmm7_4
  float v50; // xmm8_4
  float v51; // xmm13_4
  float v52; // xmm12_4
  float v53; // xmm0_4
  float v54; // xmm9_4
  float v55; // xmm10_4
  int v56; // xmm7_4
  int v57; // xmm6_4
  float v58; // xmm9_4
  float v59; // xmm5_4
  float v60; // xmm5_4
  float v61; // xmm5_4
  float v62; // xmm2_4
  float v63; // xmm0_4
  __int64 i; // rax
  float v65; // xmm2_4
  int v66; // r8d
  __int64 v67; // rax
  int v68; // eax
  float v69; // xmm0_4
  FMOD_RESULT_0 result; // eax
  char *v71; // rdi
  float *v72; // rsi
  __int64 v73; // rdx
  __int64 v74; // rcx
  char *v75; // rdi
  float *v76; // rsi
  int v77; // edx
  __int16 v78; // dx
  float shortterm; // [rsp+0h] [rbp-178h]
  float maxPeak; // [rsp+8h] [rbp-170h]
  float maxPeaka; // [rsp+8h] [rbp-170h]
  bool updateHistogram; // [rsp+Fh] [rbp-169h]
  float maxMomentary; // [rsp+10h] [rbp-168h]
  float v84; // [rsp+14h] [rbp-164h]
  float v85; // [rsp+14h] [rbp-164h]
  float v86; // [rsp+14h] [rbp-164h]
  float v87; // [rsp+14h] [rbp-164h]
  float v88; // [rsp+14h] [rbp-164h]
  float integrated; // [rsp+1Ch] [rbp-15Ch]
  float rangeLow; // [rsp+28h] [rbp-150h] BYREF
  float rangeHigh; // [rsp+2Ch] [rbp-14Ch] BYREF
  float histogram[82]; // [rsp+30h] [rbp-148h] BYREF

  v8 = length;
  v9 = inbuffer;
  memcpy_0(outbuffer, inbuffer, length * 4LL * inchannels);
  if ( *((_BYTE *)this + 3536) )
  {
    FMOD::DSPLoudnessMeter::resetBuffers(this);
    *((_BYTE *)this + 3536) = 0;
  }
  if ( *((_BYTE *)this + 3537) )
  {
    FMOD::DSPLoudnessMeter::resetIntegrated(this);
    *((_BYTE *)this + 3537) = 0;
  }
  if ( *((_BYTE *)this + 3538) )
  {
    FMOD::DSPLoudnessMeter::resetMaxPeak(this);
    *((_BYTE *)this + 3538) = 0;
  }
  v10 = *((_DWORD *)this + 871);
  maxPeak = *((float *)this + 132);
  v11 = *((_DWORD *)this + 917) == 1;
  shortterm = *((float *)this + 133);
  v12 = (float *)((char *)this + 4 * v10 + 3360);
  v13 = *((float *)this + 135);
  v14 = *((float *)this + 136);
  v15 = *((float *)this + 874);
  integrated = *((float *)this + 134);
  rangeLow = v13;
  rangeHigh = v14;
  v16 = *((float *)this + 873);
  maxMomentary = v15;
  if ( !v8 )
  {
    updateHistogram = 0;
    LODWORD(v18) = 0;
    goto LABEL_41;
  }
  v17 = *((_DWORD *)this + 872);
  updateHistogram = 0;
  v18 = 0;
  if ( *((_DWORD *)this + 870) == v17 )
    goto LABEL_25;
  while ( 1 )
  {
    ++v17;
LABEL_10:
    if ( inchannels > 0 )
      break;
    while ( 1 )
    {
      --v8;
      v21 = v9;
      *((_DWORD *)this + 872) = v17;
      if ( !v8 )
        goto LABEL_40;
LABEL_24:
      v9 = v21;
      if ( *((_DWORD *)this + 870) != v17 )
        break;
LABEL_25:
      v62 = (float)((float)((float)(*v12 + *((float *)this + (v10 + 29) % 30 + 840))
                          + *((float *)this + (v10 + 28) % 30 + 840))
                  + *((float *)this + (v10 + 27) % 30 + 840))
          / (float)(4 * v17);
      if ( *(float *)&v18 < v62 )
      {
        v84 = v16;
        v18 = (unsigned int)v18;
        maxPeak = (float)(10.0 * log10f(v62)) - 0.69099998;
        v16 = v84;
      }
      else
      {
        maxPeak = -80.691002;
      }
      if ( v11 && *((int *)this + 875) > 3 )
      {
        v88 = v16;
        result = (unsigned int)FMOD::DSPLoudnessMeter::insertPowerIntoLevelList(
                                 v62,
                                 -70.0,
                                 (FMOD::DSPLoudnessMeter::LevelLinkedList *)this + 219,
                                 v62);
        if ( result )
          return result;
        integrated = FMOD::DSPLoudnessMeter::gatedLoudness(
                       (FMOD::DSPLoudnessMeter::LevelLinkedList *)this + 219,
                       10.0,
                       -70.0);
        v18 = (unsigned int)v18;
        maxMomentary = fmaxf(maxMomentary, maxPeak);
        v16 = v88;
      }
      v63 = *(float *)&v18;
      for ( i = 0; i != 120; i += 4 )
        v63 = v63 + *(float *)((char *)this + i + 3360);
      v65 = v63 / (float)(30 * *((_DWORD *)this + 870));
      if ( v11 && *((int *)this + 875) > 29 )
      {
        v87 = v16;
        result = (unsigned int)FMOD::DSPLoudnessMeter::insertPowerIntoLevelList(
                                 v65,
                                 -70.0,
                                 (FMOD::DSPLoudnessMeter::LevelLinkedList *)this + 220,
                                 v65);
        if ( result )
          return result;
        FMOD::DSPLoudnessMeter::calculateLoudnessRange(this, &rangeLow, &rangeHigh);
        v18 = (unsigned int)v18;
        v16 = v87;
      }
      if ( *(float *)&v18 < v65 )
      {
        v86 = v16;
        v18 = (unsigned int)v18;
        shortterm = (float)(10.0 * log10f(v65)) - 0.69099998;
        v16 = v86;
      }
      else
      {
        shortterm = -80.691002;
      }
      if ( v11 )
      {
        v85 = v16;
        FMOD::DSPLoudnessMeter::calculateLoudnessHistogram(this, histogram);
        updateHistogram = 1;
        v18 = (unsigned int)v18;
        v16 = v85;
      }
      v66 = *((_DWORD *)this + 871);
      *((_DWORD *)this + 872) = 0;
      v17 = 1;
      v10 = (v66 + 1) % 30;
      *((_DWORD *)this + 871) = v10;
      v67 = v10 + 840LL;
      *((_DWORD *)this + v67) = 0;
      v12 = (float *)((char *)this + 4 * v67);
      v68 = *((_DWORD *)this + 875);
      if ( v68 > 29 )
        goto LABEL_10;
      *((_DWORD *)this + 875) = v68 + 1;
      if ( inchannels > 0 )
        goto LABEL_11;
    }
  }
LABEL_11:
  v19 = this;
  v20 = (float *)((char *)this + 3540);
  v21 = &v9[inchannels - 1 + 1];
  v22 = (float *)this;
  v23 = v18;
  do
  {
    v24 = (float *)*((_QWORD *)v19 + 117);
    v25 = *((float *)v19 + 232);
    v26 = *((float *)v19 + 233);
    v27 = v24[5] * v25;
    v28 = v24[8] * v26;
    v29 = v26 * v24[6];
    v30 = (float)(*v9 - (float)(v24[7] * v25)) - v28;
    v31 = v24[4];
    v32 = (float *)*((_QWORD *)v19 + 119);
    *((float *)v19 + 233) = v25;
    v33 = *((float *)v19 + 236);
    *((float *)v19 + 232) = v30;
    v34 = (float)(v31 * v30) + v27;
    v35 = v32[5] * v33;
    v36 = v34 + v29;
    v37 = *((float *)v19 + 237);
    v38 = v32[8] * v37;
    v39 = v37 * v32[6];
    v40 = (float)(v36 - (float)(v32[7] * v33)) - v38;
    v41 = v32[4];
    *((float *)v19 + 237) = v33;
    *((float *)v19 + 236) = v40;
    *v12 = (float)((float)((float)((float)((float)(v41 * v40) + v35) + v39)
                         * (float)((float)((float)(v41 * v40) + v35) + v39))
                 * *v20)
         + *v12;
    if ( !v11 )
      goto LABEL_12;
    v42 = *v9;
    v43 = v22[488];
    v44 = v22[489];
    v45 = v22[492];
    v46 = v22[493];
    v47 = v22[494];
    v48 = v22[495];
    v49 = v22[496];
    v50 = v22[497];
    v51 = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(0.0017089844 * *v9)
                                                                                        + (float)(0.010986328 * v43))
                                                                                - (float)(0.01965332 * v44))
                                                                        + (float)(0.033203125 * v22[490]))
                                                                - (float)(0.059448242 * v22[491]))
                                                        + (float)(0.1373291 * v45))
                                                + (float)(0.97216797 * v46))
                                        - (float)(0.10229492 * v47))
                                + (float)(0.047607422 * v48))
                        - (float)(0.026611328 * v49))
                + (float)(0.014892578 * v50))
        - (float)(v22[498] * 0.0083007812);
    v52 = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(-0.029174805 * *v9)
                                                                                        + (float)(0.029296875 * v43))
                                                                                - (float)(0.051757812 * v44))
                                                                        + (float)(0.089111328 * v22[490]))
                                                                - (float)(0.16650391 * v22[491]))
                                                        + (float)(v45 * 0.46508789))
                                                + (float)(0.77978516 * v46))
                                        - (float)(0.20031738 * v47))
                                + (float)(0.1015625 * v48))
                        - (float)(0.058227539 * v49))
                + (float)(v50 * 0.033081055))
        - (float)(v22[498] * 0.018920898);
    v53 = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(-0.018920898 * *v9)
                                                                                        + (float)(0.033081055 * v43))
                                                                                - (float)(0.058227539 * v44))
                                                                        + (float)(0.1015625 * v22[490]))
                                                                - (float)(0.20031738 * v22[491]))
                                                        + (float)(0.77978516 * v45))
                                                + (float)(0.46508789 * v46))
                                        - (float)(0.16650391 * v47))
                                + (float)(0.089111328 * v48))
                        - (float)(0.051757812 * v49))
                + (float)(0.029296875 * v50))
        - (float)(v22[498] * 0.029174805);
    v54 = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(-0.0083007812 * *v9)
                                                                                + (float)(0.014892578 * v43))
                                                                        - (float)(0.026611328 * v44))
                                                                + (float)(0.047607422 * v22[490]))
                                                        - (float)(0.10229492 * v22[491]))
                                                + (float)(0.97216797 * v45))
                                        + (float)(0.1373291 * v46))
                                - (float)(0.059448242 * v47))
                        + (float)(0.033203125 * v48))
                - (float)(0.01965332 * v49))
        + (float)(0.010986328 * v50);
    v55 = 0.0017089844 * v22[498];
    v22[498] = v50;
    v22[497] = v49;
    v22[496] = v48;
    v56 = *((_DWORD *)v22 + 491);
    v57 = *((_DWORD *)v22 + 490);
    v22[495] = v47;
    v58 = v54 + v55;
    v22[494] = v46;
    v22[493] = v45;
    *((_DWORD *)v22 + 492) = v56;
    *((_DWORD *)v22 + 491) = v57;
    v22[490] = v44;
    v22[489] = v43;
    v22[488] = v42;
    if ( *(float *)&v23 > v51 )
    {
      v59 = fmaxf(v16, -v51);
      if ( *(float *)&v23 <= v52 )
      {
LABEL_16:
        v60 = fmaxf(v59, v52);
        if ( *(float *)&v23 <= v53 )
          goto LABEL_17;
        goto LABEL_21;
      }
    }
    else
    {
      v59 = fmaxf(v16, v51);
      if ( *(float *)&v23 <= v52 )
        goto LABEL_16;
    }
    v60 = fmaxf(v59, -v52);
    if ( *(float *)&v23 <= v53 )
    {
LABEL_17:
      v61 = fmaxf(v60, v53);
      if ( *(float *)&v23 <= v58 )
        goto LABEL_18;
      goto LABEL_22;
    }
LABEL_21:
    v61 = fmaxf(v60, -v53);
    if ( *(float *)&v23 <= v58 )
    {
LABEL_18:
      v16 = fmaxf(v61, v58);
      goto LABEL_12;
    }
LABEL_22:
    v16 = fmaxf(v61, -v58);
LABEL_12:
    ++v9;
    v19 = (FMOD::DSPLoudnessMeter *)((char *)v19 + 32);
    ++v20;
    v22 += 11;
  }
  while ( v9 != v21 );
  --v8;
  v18 = v23;
  *((_DWORD *)this + 872) = v17;
  if ( v8 )
    goto LABEL_24;
LABEL_40:
  v13 = rangeLow;
  v14 = rangeHigh;
LABEL_41:
  *((float *)this + 132) = maxPeak;
  *((float *)this + 133) = shortterm;
  *((float *)this + 136) = v14;
  *((float *)this + 134) = integrated;
  *((float *)this + 135) = v13;
  v69 = -80.0;
  if ( *(float *)&v18 < v16 )
  {
    maxPeaka = v16;
    v69 = log10f(v16) * 20.0;
    v16 = maxPeaka;
  }
  result = FMOD_RESULT::FMOD_OK_0;
  *((float *)this + 203) = v69;
  *((float *)this + 204) = maxMomentary;
  *((float *)this + 873) = v16;
  *((float *)this + 874) = maxMomentary;
  if ( updateHistogram )
  {
    v71 = (char *)this + 548;
    v72 = histogram;
    LOWORD(result) = 264;
    if ( (((_BYTE)this + 36) & 1) != 0 )
    {
      v71 = (char *)this + 549;
      v72 = (float *)((char *)histogram + 1);
      *((_BYTE *)this + 548) = LOBYTE(histogram[0]);
      result = FMOD_RESULT::FMOD_ERR_DSP_FORMAT_0|0x100;
    }
    if ( ((unsigned __int8)v71 & 2) != 0 )
    {
      v78 = *(_WORD *)v72;
      v71 += 2;
      v72 = (float *)((char *)v72 + 2);
      result -= 2;
      *((_WORD *)v71 - 1) = v78;
    }
    if ( ((unsigned __int8)v71 & 4) != 0 )
    {
      v77 = *(_DWORD *)v72;
      v71 += 4;
      ++v72;
      result -= 4;
      *((_DWORD *)v71 - 1) = v77;
    }
    v73 = 0;
    v74 = (unsigned int)result >> 3;
    qmemcpy(v71, v72, 8 * v74);
    v76 = &v72[2 * v74];
    v75 = &v71[8 * v74];
    if ( (result & 4) != 0 )
    {
      *(float *)v75 = *v76;
      v73 = 4;
    }
    if ( (result & 2) != 0 )
    {
      *(_WORD *)&v75[v73] = *(_WORD *)((char *)v76 + v73);
      v73 += 2;
    }
    if ( (result & 1) != 0 )
      v75[v73] = *((_BYTE *)v76 + v73);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21f6a90 | Name: _ZN4FMOD16DSPLoudnessMeter12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPLoudnessMeter::readInternal(
           (FMOD::DSPLoudnessMeter *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x21f6aa0 | Name: _ZN4FMOD16DSPLoudnessMeter23setParameterIntInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::setParameterIntInternal(
        FMOD::DSPLoudnessMeter *const this,
        int index,
        int value)
{
  if ( index )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  switch ( value )
  {
    case -2:
      goto LABEL_9;
    case -1:
      *((_BYTE *)this + 3537) = 1;
LABEL_9:
      *((_BYTE *)this + 3538) = 1;
      return FMOD_RESULT::FMOD_OK_0;
    case -3:
      *((_BYTE *)this + 3537) = 1;
      break;
    default:
      *((_DWORD *)this + 917) = value;
      break;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f6b00 | Name: _ZN4FMOD16DSPLoudnessMeter14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::createInternal(FMOD::DSPLoudnessMeter *const this)
{
  char *v2; // rax
  __int64 v3; // rdx
  char *v4; // rdi
  __int64 v5; // rcx
  char *v6; // rdi

  FMOD::DSPLoudnessMeter::initialiseLoudnessInfo(&info);
  v2 = (char *)this + 1980;
  *((_DWORD *)this + 212) = 1069842169;
  *((_DWORD *)this + 213) = -1070840640;
  v3 = 0;
  *((_DWORD *)this + 214) = 1067017456;
  *((_DWORD *)this + 215) = -1076336762;
  *((_DWORD *)this + 216) = 1060864988;
  *((_DWORD *)this + 224) = 1065353216;
  *((_DWORD *)this + 225) = -1073741824;
  *((_DWORD *)this + 226) = 1065353216;
  *((_DWORD *)this + 227) = -1073825312;
  *((_DWORD *)this + 228) = 1065186656;
  do
  {
    *(_QWORD *)((char *)this + v3 + 936) = (char *)this + 832;
    *(_QWORD *)((char *)this + v3 + 952) = (char *)this + 880;
    v3 += 32;
    *((_DWORD *)v2 + 3) = 0;
    *((_DWORD *)v2 + 2) = 0;
    v2 += 44;
    *((_DWORD *)v2 - 10) = 0;
    *((_DWORD *)v2 - 11) = 0;
    *((_DWORD *)v2 - 12) = 0;
    *((_DWORD *)v2 - 13) = 0;
    *((_DWORD *)v2 - 14) = 0;
    *((_DWORD *)v2 - 15) = 0;
    *((_DWORD *)v2 - 16) = 0;
    *((_DWORD *)v2 - 17) = 0;
    *((_DWORD *)v2 - 18) = 0;
  }
  while ( v3 != 1024 );
  v4 = (char *)this + 3540;
  LOWORD(v3) = 128;
  if ( (((_BYTE)this - 44) & 1) == 0 )
  {
    if ( ((unsigned __int8)v4 & 2) == 0 )
      goto LABEL_5;
LABEL_14:
    v4 += 2;
    LODWORD(v3) = v3 - 2;
    *((_WORD *)v4 - 1) = 0;
    if ( ((unsigned __int8)v4 & 4) == 0 )
      goto LABEL_6;
    goto LABEL_15;
  }
  v4 = (char *)this + 3541;
  *((_BYTE *)this + 3540) = 0;
  LOBYTE(v3) = 127;
  if ( (((_BYTE)this - 43) & 2) != 0 )
    goto LABEL_14;
LABEL_5:
  if ( ((unsigned __int8)v4 & 4) == 0 )
    goto LABEL_6;
LABEL_15:
  *(_DWORD *)v4 = 0;
  LODWORD(v3) = v3 - 4;
  v4 += 4;
LABEL_6:
  v5 = (unsigned int)v3 >> 3;
  memset(v4, 0, 8 * v5);
  v6 = &v4[8 * v5];
  if ( (v3 & 4) != 0 )
  {
    *(_DWORD *)v6 = 0;
    v6 += 4;
  }
  if ( (v3 & 2) != 0 )
  {
    v6 += 2;
    *((_WORD *)v6 - 1) = 0;
  }
  if ( (v3 & 1) != 0 )
    *v6 = 0;
  *((_DWORD *)this + 885) = 1065353216;
  *((_DWORD *)this + 886) = 1065353216;
  *((_DWORD *)this + 887) = 1065353216;
  *((_DWORD *)this + 888) = 0;
  *((_DWORD *)this + 889) = 1068792545;
  *((_DWORD *)this + 890) = 1068792545;
  *((_DWORD *)this + 891) = 1068792545;
  *((_DWORD *)this + 892) = 1068792545;
  *((_DWORD *)this + 876) = 0;
  *((_QWORD *)this + 439) = 0;
  *((_DWORD *)this + 880) = 0;
  *((_QWORD *)this + 441) = 0;
  *((_DWORD *)this + 870) = 4800;
  FMOD::DSPLoudnessMeter::resetBuffers(this);
  FMOD::DSPLoudnessMeter::resetIntegrated(this);
  FMOD::DSPLoudnessMeter::resetMaxPeak(this);
  FMOD::DSPLoudnessMeter::resetInternal(this);
  FMOD::DSPLoudnessMeter::setParameterIntInternal(this, 0, 1);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f6d60 | Name: _ZN4FMOD16DSPLoudnessMeter14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLoudnessMeter::createInternal((FMOD::DSPLoudnessMeter *const)dsp_state->instance);
}


// Address: 0x21f6d70 | Name: _ZN4FMOD16DSPLoudnessMeter23setParameterIntCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::setParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int value)
{
  return FMOD::DSPLoudnessMeter::setParameterIntInternal(
           (FMOD::DSPLoudnessMeter *const)dsp_state->instance,
           index,
           value);
}


// Address: 0x21f6d80 | Name: _ZN4FMOD16DSPLoudnessMeter23getParameterIntInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::getParameterIntInternal(
        FMOD::DSPLoudnessMeter *const this,
        int index,
        int *value,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax
  int v5; // eax
  const char *v6; // rsi

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( value && !index )
  {
    v5 = *((_DWORD *)this + 917);
    *value = v5;
    if ( valuestr )
    {
      v6 = "Paused";
      if ( v5 )
        v6 = "Analysing";
      strcpy(valuestr, v6);
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21f6dd0 | Name: _ZN4FMOD16DSPLoudnessMeter23getParameterIntCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::getParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int *value,
        char *valuestr)
{
  return FMOD::DSPLoudnessMeter::getParameterIntInternal(
           (FMOD::DSPLoudnessMeter *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x21f6de0 | Name: _ZN4FMOD16DSPLoudnessMeter24setParameterDataInternalEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::setParameterDataInternal(
        FMOD::DSPLoudnessMeter *const this,
        int index,
        void *data,
        unsigned int length)
{
  FMOD_RESULT_0 result; // eax

  if ( index != 1 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !data )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( length == 128 )
  {
    *(_QWORD *)((char *)this + 3540) = *(_QWORD *)data;
    *(_QWORD *)((char *)this + 3548) = *((_QWORD *)data + 1);
    *(_QWORD *)((char *)this + 3556) = *((_QWORD *)data + 2);
    *(_QWORD *)((char *)this + 3564) = *((_QWORD *)data + 3);
    *(_QWORD *)((char *)this + 3572) = *((_QWORD *)data + 4);
    *(_QWORD *)((char *)this + 3580) = *((_QWORD *)data + 5);
    *(_QWORD *)((char *)this + 3588) = *((_QWORD *)data + 6);
    *(_QWORD *)((char *)this + 3596) = *((_QWORD *)data + 7);
    *(_QWORD *)((char *)this + 3604) = *((_QWORD *)data + 8);
    *(_QWORD *)((char *)this + 3612) = *((_QWORD *)data + 9);
    *(_QWORD *)((char *)this + 3620) = *((_QWORD *)data + 10);
    *(_QWORD *)((char *)this + 3628) = *((_QWORD *)data + 11);
    *(_QWORD *)((char *)this + 3636) = *((_QWORD *)data + 12);
    *(_QWORD *)((char *)this + 3644) = *((_QWORD *)data + 13);
    *(_QWORD *)((char *)this + 3652) = *((_QWORD *)data + 14);
    *(_QWORD *)((char *)this + 3660) = *((_QWORD *)data + 15);
    FMOD::DSPLoudnessMeter::resetInternal(this);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21f6ee0 | Name: _ZN4FMOD16DSPLoudnessMeter24setParameterDataCallbackEP14FMOD_DSP_STATEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::setParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void *data,
        unsigned int length)
{
  return FMOD::DSPLoudnessMeter::setParameterDataInternal(
           (FMOD::DSPLoudnessMeter *const)dsp_state->instance,
           index,
           data,
           length);
}


// Address: 0x21f6ef0 | Name: _ZN4FMOD16DSPLoudnessMeter24getParameterDataInternalEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::getParameterDataInternal(
        FMOD::DSPLoudnessMeter *const this,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  if ( index == 1 )
  {
    *data = (char *)this + 3540;
    *length = 128;
  }
  else
  {
    if ( index != 2 )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( *((_BYTE *)this + 3537) )
      *data = &info;
    else
      *data = (char *)this + 528;
    *length = 292;
  }
  if ( valuestr )
    *valuestr = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f6f60 | Name: _ZN4FMOD16DSPLoudnessMeter24getParameterDataCallbackEP14FMOD_DSP_STATEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPLoudnessMeter::getParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  return FMOD::DSPLoudnessMeter::getParameterDataInternal(
           (FMOD::DSPLoudnessMeter *const)dsp_state->instance,
           index,
           data,
           length,
           valuestr);
}


