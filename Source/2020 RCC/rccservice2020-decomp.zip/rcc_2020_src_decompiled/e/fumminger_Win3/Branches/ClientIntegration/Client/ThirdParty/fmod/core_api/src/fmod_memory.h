// Address: 0x21c7240 | Name: _ZN4FMOD16AlignedAllocatorILi1EE5allocEi
void *__fastcall FMOD::AlignedAllocator<1>::alloc(int size)
{
  return FMOD::MemPool::alloc(off_286F358->gSystemMemPool, size, "../../../core_api/src/fmod_memory.h", 232, 0, 0);
}


