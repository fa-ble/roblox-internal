// Address: 0x224bcd0 | Name: _ZN4FMOD7SystemI32calculateSpeakerAnglesAndNormalsEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::calculateSpeakerAnglesAndNormals(FMOD::SystemI *const this)
{
  int i; // ebp
  float z; // eax
  float v4; // xmm3_4
  float v5; // xmm0_4
  float v6; // xmm1_4
  float x; // xmm0_4
  float v8; // xmm3_4
  float v9; // xmm4_4
  float v10; // xmm3_4
  float v11; // xmm4_4

  for ( i = 0; i != 12; ++i )
  {
    while ( !this->mSpeaker[0].mActive )
    {
      ++i;
      this = (FMOD::SystemI *const)((char *)this + 48);
      if ( i == 12 )
        return FMOD_RESULT::FMOD_OK_0;
    }
    *(_QWORD *)&this->mSpeaker[0].mXZNormal.x = *(_QWORD *)&this->mSpeaker[0].mPosition.x;
    z = this->mSpeaker[0].mPosition.z;
    *(_DWORD *)((char *)&stru_11838.r_offset + (_QWORD)this) = 0;
    v4 = this->mSpeaker[0].mXZNormal.x * this->mSpeaker[0].mXZNormal.x;
    this->mSpeaker[0].mXZNormal.z = z;
    v5 = fsqrt((float)(v4 + 0.0) + (float)(this->mSpeaker[0].mXZNormal.z * this->mSpeaker[0].mXZNormal.z));
    if ( v5 <= 0.0 )
    {
      this->mSpeaker[0].mXZNormal.x = 0.0;
      *(_DWORD *)((char *)&stru_11838.r_offset + (_QWORD)this) = 0;
      this->mSpeaker[0].mXZNormal.z = 0.0;
    }
    else
    {
      this->mSpeaker[0].mXZNormal.x = this->mSpeaker[0].mXZNormal.x / v5;
      *(float *)((char *)&stru_11838.r_offset + (_QWORD)this) = *(float *)((char *)&stru_11838.r_offset + (_QWORD)this)
                                                              / v5;
      this->mSpeaker[0].mXZNormal.z = this->mSpeaker[0].mXZNormal.z / v5;
    }
    v6 = this->mSpeaker[0].mXZNormal.z;
    x = this->mSpeaker[0].mXZNormal.x;
    if ( v6 != 0.0 || (v8 = 0.0, x != 0.0) )
    {
      v9 = this->mSpeaker[0].mXZNormal.z;
      if ( v6 < 0.0 )
        v9 = -v6;
      v10 = this->mSpeaker[0].mXZNormal.x;
      if ( x < 0.0 )
        v10 = -x;
      if ( v9 < v10 )
      {
        v11 = 3.0 - (float)(v6 / v10);
        if ( x >= 0.0 )
        {
LABEL_14:
          v8 = v11;
          goto LABEL_15;
        }
        v8 = 10.0 - v11;
      }
      else
      {
        v11 = (float)(x / v9) + 1.0;
        if ( v6 >= 0.0 )
          goto LABEL_14;
        v8 = 6.0 - v11;
      }
    }
LABEL_15:
    this->mSpeaker[0].mXZAngle = v8;
    this = (FMOD::SystemI *const)((char *)this + 48);
    *(float *)((char *)&dword_11814 + (_QWORD)this) = (float)(atan2f(x, v6) * 180.0) / 3.1415927;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224bf10 | Name: _ZN4FMOD7SystemI19prepareSpeakerPairsEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::prepareSpeakerPairs(FMOD::SystemI *const this)
{
  FMOD::SystemI *v1; // rdx
  float *v2; // rcx
  float *i; // rbx
  float *v4; // rax
  float v5; // xmm1_4
  float *v6; // rbp
  float v7; // xmm0_4
  FMOD_SPEAKERCONFIG *j; // rax
  bool v9; // r8
  __m128 v10; // xmm0
  __m128 v11; // xmm0
  FMOD_SPEAKERCONFIG *v12; // rdx
  float mXZAngle; // xmm0_4
  float *v14; // rsi
  float v15; // xmm1_4
  float v16; // xmm1_4
  float v17; // xmm1_4
  float v18; // xmm5_4
  float v19; // xmm4_4
  float v20; // xmm3_4
  float v21; // xmm1_4
  float v22; // xmm5_4
  float v23; // xmm4_4
  float v24; // xmm3_4
  float v25; // xmm6_4
  float v26; // xmm1_4
  float v27; // xmm0_4
  float v28; // xmm1_4
  float v29; // xmm0_4
  float v30; // xmm3_4
  float v31; // xmm0_4
  float v32; // xmm1_4
  float v33; // xmm0_4
  float v34; // xmm3_4
  float v35; // xmm0_4
  float v36; // xmm4_4
  float v37; // xmm3_4
  float v38; // xmm4_4
  float v39; // xmm4_4
  float v40; // xmm3_4
  float v41; // xmm4_4

  v1 = this;
  v2 = *(float **)((char *)&stru_11A60.r_offset + (_QWORD)this);
  for ( i = v2; i; i = v4 )
  {
    v4 = (float *)v1->mSpeakerList[1];
    v5 = i[8];
    v6 = v4;
    if ( !v4 )
      v6 = *(float **)((char *)&stru_11A60.r_offset + (_QWORD)this);
    v7 = v6[8];
    if ( v5 != v7 && ((float)(v7 - v5) > 4.0 || v5 > v7 && (float)(v5 - v7) < 4.0) )
    {
      v18 = i[5] - v6[5];
      v19 = i[6] - v6[6];
      v20 = i[7] - v6[7];
      v21 = fsqrt((float)((float)(v18 * v18) + (float)(v19 * v19)) + (float)(v20 * v20));
      if ( v21 <= 0.0 )
      {
        v27 = -0.0;
        v26 = -0.0;
        v25 = -0.0;
        v24 = 0.0;
        v23 = 0.0;
        v22 = 0.0;
      }
      else
      {
        v22 = v18 / v21;
        v23 = v19 / v21;
        v24 = v20 / v21;
        v25 = -v22;
        v26 = -v23;
        v27 = -v24;
      }
      i[5] = v22;
      i[7] = v24;
      i[6] = v23;
      v6[7] = v27;
      v6[6] = v26;
      v28 = i[7];
      v6[5] = v25;
      v29 = i[5];
      if ( v28 != 0.0 || (v30 = 0.0, v29 != 0.0) )
      {
        v39 = v28;
        if ( v28 < 0.0 )
          v39 = -v28;
        v40 = i[5];
        if ( v29 < 0.0 )
          v40 = -v29;
        if ( v39 >= v40 )
        {
          v41 = (float)(v29 / v39) + 1.0;
          if ( v28 < 0.0 )
          {
            v30 = 6.0 - v41;
            goto LABEL_29;
          }
        }
        else
        {
          v41 = 3.0 - (float)(v28 / v40);
          if ( v29 < 0.0 )
          {
            v30 = 10.0 - v41;
            goto LABEL_29;
          }
        }
        v30 = v41;
      }
LABEL_29:
      i[8] = v30;
      v31 = atan2f(v29, v28);
      v32 = v6[7];
      i[9] = (float)(v31 * 180.0) / 3.1415927;
      v33 = v6[5];
      if ( v32 != 0.0 || (v34 = 0.0, v33 != 0.0) )
      {
        v36 = v32;
        if ( v32 < 0.0 )
          v36 = -v32;
        v37 = v6[5];
        if ( v33 < 0.0 )
          v37 = -v33;
        if ( v36 >= v37 )
        {
          v38 = (float)(v33 / v36) + 1.0;
          if ( v32 < 0.0 )
          {
            v34 = 6.0 - v38;
            goto LABEL_31;
          }
        }
        else
        {
          v38 = 3.0 - (float)(v32 / v37);
          if ( v33 < 0.0 )
          {
            v34 = 10.0 - v38;
            goto LABEL_31;
          }
        }
        v34 = v38;
      }
LABEL_31:
      v6[8] = v34;
      v35 = atan2f(v33, v32);
      v2 = *(float **)((char *)&stru_11A60.r_offset + (_QWORD)this);
      v6[9] = (float)(v35 * 180.0) / 3.1415927;
      break;
    }
    v1 = (FMOD::SystemI *)((char *)v1 + 8);
  }
  for ( j = (FMOD_SPEAKERCONFIG *)v2; j; j = v12 )
  {
    v12 = this->mSpeakerList[1];
    mXZAngle = j->mXZAngle;
    v14 = (float *)v12;
    if ( !v12 )
      v14 = v2;
    v15 = v14[8];
    if ( mXZAngle != v15 )
    {
      v16 = v15 - mXZAngle;
      if ( v16 < 0.0 )
      {
        v17 = (float)-v16 - 4.0;
        if ( v17 < 0.0 )
LABEL_21:
          v9 = v17 < -0.0020000001;
        else
          v9 = v17 > 0.0020000001;
      }
      else
      {
        v17 = v16 - 4.0;
        if ( v17 < 0.0 )
          goto LABEL_21;
        v9 = v17 > 0.0020000001;
      }
      j->mPairUseVBAP = v9;
      if ( v9 )
      {
        v10.m128_f32[0] = (float)(j->mXZNormal.x * v14[7]) - (float)(v14[5] * j->mXZNormal.z);
        v11 = _mm_cmplt_ss((__m128)0LL, v10);
        LODWORD(j->mPairVBAPSign) = _mm_andnot_ps(v11, (__m128)0xBF800000).m128_u32[0] | v11.m128_i32[0] & 0x3F800000;
      }
    }
    this = (FMOD::SystemI *const)((char *)this + 8);
  }
  return (int)j;
}


// Address: 0x224c380 | Name: _ZN4FMOD7SystemI15sortSpeakerListEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::sortSpeakerList(FMOD::SystemI *const this)
{
  __int64 i; // rax
  int mDSPMaxOutputChannels; // ebp
  __int64 v3; // rax
  FMOD::SystemI *v4; // rsi
  bool *v5; // r8
  float *v6; // rcx
  float v7; // xmm1_4
  float *v8; // rax
  __int64 v9; // rdx
  int *v10; // rax
  bool used[40]; // [rsp+0h] [rbp-28h] BYREF

  if ( *(int *)((char *)&dword_1181C + (_QWORD)this) == 1 )
    return FMOD_RESULT::FMOD_OK_0;
  for ( i = 0; i != 96; i += 8 )
    *(unsigned __int64 *)((char *)&stru_11A60.r_offset + (_QWORD)this + i) = 0;
  mDSPMaxOutputChannels = this->mDSPMaxOutputChannels;
  memset(used, 0, 12);
  FMOD::SystemI::calculateSpeakerAnglesAndNormals(this);
  if ( mDSPMaxOutputChannels > 0 )
  {
    v3 = (unsigned int)(mDSPMaxOutputChannels - 1);
    v4 = this;
    v5 = &this->mInitialized + 8 * v3;
    v6 = (float *)((char *)&stru_11850 + (_QWORD)this + 48 * v3);
    do
    {
      v7 = 16.0;
      v8 = (float *)((char *)&stru_11820 + (_QWORD)this);
      do
      {
        v9 = *(int *)v8;
        if ( (_DWORD)v9 != 3 && *((_BYTE *)v8 + 40) && v7 > v8[8] && !used[v9] )
        {
          v7 = v8[8];
          *(unsigned __int64 *)((char *)&stru_11A60.r_offset + (_QWORD)v4) = (unsigned __int64)v8;
        }
        v8 += 12;
      }
      while ( v8 != v6 );
      v10 = *(int **)((char *)&stru_11A60.r_offset + (_QWORD)v4);
      if ( v10 )
        used[*v10] = 1;
      v4 = (FMOD::SystemI *)((char *)v4 + 8);
    }
    while ( v4 != (FMOD::SystemI *)v5 );
  }
  return FMOD::SystemI::prepareSpeakerPairs(this);
}


// Address: 0x224c490 | Name: _ZN4FMOD7SystemI14setSpeakerModeE16FMOD_SPEAKERMODEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::setSpeakerMode(
        FMOD::SystemI *const this,
        FMOD_SPEAKERMODE_0 speakermode,
        int numrawspeakers)
{
  FMOD::Output *mOutput; // rax
  FMOD::Output *v5; // rax
  FMOD::DownMix *mDownMix; // rdi
  FMOD::DownMix *v7; // rax
  int v9; // eax
  float y; // [rsp+4h] [rbp-14h]
  float x; // [rsp+8h] [rbp-10h]
  float v12; // [rsp+Ch] [rbp-Ch]

  if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
  {
    mOutput = this->mOutput;
    speakermode = mOutput->mSpeakerMode;
    LODWORD(mOutput) = mOutput->mSpeakerModeChannels;
    *(int *)((char *)&dword_1181C + (_QWORD)this) = speakermode;
    this->mDSPMaxOutputChannels = (int)mOutput;
    goto LABEL_3;
  }
  if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
  {
    *(int *)((char *)&dword_1181C + (_QWORD)this) = 1;
    this->mDSPMaxOutputChannels = numrawspeakers;
    goto LABEL_7;
  }
  *(int *)((char *)&dword_1181C + (_QWORD)this) = speakermode;
  if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
  {
    v9 = 5;
    goto LABEL_21;
  }
  if ( speakermode > FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
  {
    v9 = 8;
    if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
      goto LABEL_21;
    LOBYTE(v9) = 6;
    if ( speakermode < FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
      goto LABEL_21;
    LOBYTE(v9) = 12;
    if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
      goto LABEL_21;
    if ( speakermode == 1000 )
      goto LABEL_20;
LABEL_26:
    v9 = 0;
    goto LABEL_21;
  }
  if ( speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
  {
    v9 = 4;
    if ( speakermode > FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
      goto LABEL_21;
    LOBYTE(v9) = 1;
    if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0 )
      goto LABEL_21;
    goto LABEL_26;
  }
LABEL_20:
  v9 = 2;
LABEL_21:
  this->mDSPMaxOutputChannels = v9;
LABEL_3:
  switch ( speakermode )
  {
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0:
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_LEFT_0, 0.0, 1.0, 1);
      break;
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0:
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_LEFT_0, -0.5, 0.86602539, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_RIGHT_0, 0.5, 0.86602539, 1);
      break;
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_QUAD_0:
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_LEFT_0, -0.70710677, 0.70710677, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_RIGHT_0, 0.70710677, 0.70710677, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_SURROUND_LEFT_0, -0.70710677, -0.70710677, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_SURROUND_RIGHT_0, 0.70710677, -0.70710677, 1);
      break;
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0:
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_LEFT_0, -0.5, 0.86602539, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_RIGHT_0, 0.5, 0.86602539, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_CENTER_0, 0.0, 1.0, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_SURROUND_LEFT_0, -0.93969262, -0.34202012, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_SURROUND_RIGHT_0, 0.93969262, -0.34202012, 1);
      break;
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_5POINT1_0:
      v5 = this->mOutput;
      if ( v5->mSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_5POINT1_0 )
      {
        if ( (v5->mChannelMask & 0xC0) != 0 )
        {
          v12 = 0.49999982;
          x = -0.49999982;
          y = -0.86602551;
        }
        else
        {
          v12 = 0.93969262;
          x = -0.93969262;
          y = -0.34202012;
        }
      }
      else
      {
        v12 = 0.93969262;
        x = -0.93969262;
        y = -0.34202012;
      }
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_LEFT_0, -0.5, 0.86602539, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_RIGHT_0, 0.5, 0.86602539, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_CENTER_0, 0.0, 1.0, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_LOW_FREQUENCY_0, 0.0, 1.0, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_SURROUND_LEFT_0, x, y, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_SURROUND_RIGHT_0, v12, y, 1);
      break;
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0:
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_LEFT_0, -0.5, 0.86602539, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_RIGHT_0, 0.5, 0.86602539, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_CENTER_0, 0.0, 1.0, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_LOW_FREQUENCY_0, 0.0, 1.0, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_SURROUND_LEFT_0, -1.0, -0.000000043711388, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_SURROUND_RIGHT_0, 1.0, -0.000000043711388, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_BACK_LEFT_0, -0.49999982, -0.86602551, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_BACK_RIGHT_0, 0.49999982, -0.86602551, 1);
      break;
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0:
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_LEFT_0, -0.5, 0.86602539, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_RIGHT_0, 0.5, 0.86602539, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_FRONT_CENTER_0, 0.0, 1.0, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_LOW_FREQUENCY_0, 0.0, 1.0, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_SURROUND_LEFT_0, -1.0, -0.000000043711388, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_SURROUND_RIGHT_0, 1.0, -0.000000043711388, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_BACK_LEFT_0, -0.49999982, -0.86602551, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_BACK_RIGHT_0, 0.49999982, -0.86602551, 1);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_TOP_FRONT_LEFT_0, 0.0, 1.0, 0);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_TOP_FRONT_RIGHT_0, 0.0, 1.0, 0);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_TOP_BACK_LEFT_0, 0.0, 1.0, 0);
      FMOD::SystemI::setSpeakerPosition(this, FMOD_SPEAKER::FMOD_SPEAKER_TOP_BACK_RIGHT_0, 0.0, 1.0, 0);
      break;
    default:
      break;
  }
LABEL_7:
  mDownMix = this->mDownMix;
  if ( mDownMix )
  {
    (*((void (__fastcall **)(FMOD::DownMix *))mDownMix->_vptr_DownMix + 1))(mDownMix);
    this->mDownMix = 0;
  }
  if ( this->mDSPMaxOutputChannels == this->mOutput->mSpeakerModeChannels )
    return FMOD::SystemI::sortSpeakerList(this);
  v7 = (FMOD::DownMix *)FMOD::MemPool::calloc(
                          off_286F358->gSystemMemPool,
                          200,
                          "../../../core_api/src/fmod_systemi_speaker.cpp",
                          151,
                          0);
  if ( v7 )
  {
    v7->mConnection.mInputNode.mNodeData = 0;
    v7->mConnection.mOutputNode.mNodeData = 0;
    v7->mConnection.mMixMatrix.mData = 0;
    v7->mConnection.mMixMatrix.mOutChannels = 0;
    v7->_vptr_DownMix = (int (**)(...))&off_29B2730;
    v7->mConnection.mMixMatrixCurrent.mData = 0;
    v7->mConnection.mMixMatrixCurrent.mInChannels = 0;
    v7->mConnection.mMixMatrixCurrent.mOutChannels = 0;
    v7->mConnection.mInputNode.mNodePrev = &v7->mConnection.mInputNode;
    v7->mConnection.mInputNode.mNodeNext = &v7->mConnection.mInputNode;
    v7->mConnection.mUserData.mMixMatrixUser.mData = 0;
    v7->mConnection.mUserData.mMixMatrixUser.mInChannels = 0;
    v7->mConnection.mOutputNode.mNodePrev = &v7->mConnection.mOutputNode;
    v7->mConnection.mOutputNode.mNodeNext = &v7->mConnection.mOutputNode;
    v7->mConnection.mMixMatrix.mInChannels = 0;
    v7->mConnection.mUserData.mMixMatrixUser.mOutChannels = 0;
    v7->mConnection.mSystem = 0;
    v7->mConnection.mInputUnit = 0;
    v7->mConnection.mOutputUnit = 0;
    this->mDownMix = v7;
    return FMOD::SystemI::sortSpeakerList(this);
  }
  this->mDownMix = 0;
  return FMOD_RESULT::FMOD_ERR_MEMORY_0;
}


// Address: 0x224cc20 | Name: _ZN4FMOD7SystemI18channelLayoutsInitEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::channelLayoutsInit(FMOD::SystemI *const this)
{
  FMOD::ChannelLayout *v1; // rbp
  FMOD_SPEAKERMODE_0 v2; // ebx
  FMOD_RESULT_0 result; // eax
  int count; // [rsp+Ch] [rbp-3Ch] BYREF
  const float *directions; // [rsp+10h] [rbp-38h] BYREF
  const FMOD::FMOD_CHANNEL_TYPE *types; // [rsp+18h] [rbp-30h] BYREF

  v1 = (FMOD::ChannelLayout *)((char *)&stru_11AC0 + (_QWORD)this);
  v2 = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
  while ( 1 )
  {
    count = 0;
    directions = 0;
    types = 0;
    FMOD::ChannelLayout::speakerConfiguration(v2, &count, &types, &directions, 0);
    result = FMOD::ChannelLayout::init(v1, count, types, directions);
    if ( result )
      break;
    ++v2;
    ++v1;
    if ( v2 == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MAX_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224ccc0 | Name: _ZN4FMOD7SystemI19channelLayoutsCloseEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::channelLayoutsClose(FMOD::SystemI *const this)
{
  char *v1; // rbp
  __int64 i; // rbx
  FMOD::ChannelLayout *v3; // rdi

  v1 = (char *)&stru_11AC0 + (_QWORD)this;
  for ( i = 0; i != 1536; i += 192 )
  {
    v3 = (FMOD::ChannelLayout *)&v1[i];
    FMOD::ChannelLayout::close(v3);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224cd00 | Name: _ZN4FMOD7SystemI16getChannelLayoutE16FMOD_SPEAKERMODEPPKNS_13ChannelLayoutE
FMOD_RESULT_0 __fastcall FMOD::SystemI::getChannelLayout(
        FMOD::SystemI *const this,
        FMOD_SPEAKERMODE_0 mode,
        const FMOD::ChannelLayout **layout)
{
  FMOD_RESULT_0 result; // eax
  unsigned __int32 v4; // esi

  if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
    mode = *(int *)((char *)&dword_1181C + (_QWORD)this);
  result = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  if ( this->mInitialized )
  {
    LOBYTE(result) = 31;
    if ( layout )
    {
      v4 = mode - 1;
      if ( v4 <= 7 )
      {
        *layout = (const FMOD::ChannelLayout *)((char *)&stru_11AC0 + (_QWORD)this + 192 * (int)v4);
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x224cd50 | Name: _ZN4FMOD7SystemI22getSpeakerModeChannelsE16FMOD_SPEAKERMODEPi
FMOD_RESULT_0 __fastcall FMOD::SystemI::getSpeakerModeChannels(
        FMOD::SystemI *const this,
        FMOD_SPEAKERMODE_0 mode,
        int *channels)
{
  FMOD_RESULT_0 result; // eax
  const FMOD::ChannelLayout *layout; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channels )
  {
    if ( mode )
    {
      layout = 0;
      result = FMOD::SystemI::getChannelLayout(this, mode, &layout);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        *channels = layout->mChannelCount;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
    else
    {
      *channels = this->mDSPMaxOutputChannels;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x224cdb0 | Name: _ZN4FMOD7SystemI13sumMonoMatrixEP14FMOD_DSP_STATE16FMOD_SPEAKERMODEffPf
FMOD_RESULT_0 __fastcall FMOD::SystemI::sumMonoMatrix(
        FMOD_DSP_STATE *state,
        FMOD_SPEAKERMODE_0 sourceSpeakerMode,
        float lowFrequencyGain,
        float overallGain,
        float *matrix,
        float a6)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *const *instance; // rax
  const FMOD::ChannelLayout *sourceLayout; // [rsp+18h] [rbp-10h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( matrix )
  {
    instance = (FMOD::SystemI *const *)state->instance;
    sourceLayout = 0;
    result = FMOD::SystemI::getChannelLayout(instance[22], sourceSpeakerMode, &sourceLayout);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return (unsigned int)FMOD::ChannelLayout::sumMonoMatrix(sourceLayout, lowFrequencyGain, overallGain, a6, matrix);
  }
  return result;
}


// Address: 0x224ce20 | Name: _ZN4FMOD7SystemI15sumStereoMatrixEP14FMOD_DSP_STATE16FMOD_SPEAKERMODEfffiPf
FMOD_RESULT_0 __fastcall FMOD::SystemI::sumStereoMatrix(
        FMOD_DSP_STATE *state,
        FMOD_SPEAKERMODE_0 sourceSpeakerMode,
        float pan,
        float lowFrequencyGain,
        float overallGain,
        int matrixHop,
        float *matrix)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *const *instance; // rax
  const FMOD::ChannelLayout *sourceLayout; // [rsp+1Ch] [rbp-10h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( matrix && (unsigned int)(matrixHop - 1) <= 0x1F )
  {
    instance = (FMOD::SystemI *const *)state->instance;
    sourceLayout = 0;
    result = FMOD::SystemI::getChannelLayout(instance[22], sourceSpeakerMode, &sourceLayout);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return (unsigned int)FMOD::ChannelLayout::sumStereoMatrix(
                             sourceLayout,
                             pan,
                             lowFrequencyGain,
                             overallGain,
                             matrixHop,
                             matrix);
  }
  return result;
}


// Address: 0x224cea0 | Name: _ZN4FMOD7SystemI17sumSurroundMatrixEP14FMOD_DSP_STATE16FMOD_SPEAKERMODES3_fffffiPf27FMOD_DSP_PAN_SURROUND_FLAGS
FMOD_RESULT_0 __fastcall FMOD::SystemI::sumSurroundMatrix(
        FMOD_DSP_STATE *state,
        FMOD_SPEAKERMODE_0 sourceSpeakerMode,
        FMOD_SPEAKERMODE_0 targetSpeakerMode,
        float direction,
        float extent,
        float rotation,
        float lowFrequencyGain,
        float overallGain,
        int matrixHop,
        float *matrix,
        FMOD_DSP_PAN_SURROUND_FLAGS flags)
{
  FMOD_RESULT_0 result; // eax
  void *instance; // rax
  FMOD::SystemI *v16; // r13
  const FMOD::ChannelLayout *sourceLayout; // [rsp+20h] [rbp-38h] BYREF
  const FMOD::ChannelLayout *targetLayout; // [rsp+28h] [rbp-30h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( matrix )
  {
    if ( (unsigned int)(matrixHop - 1) <= 0x1F )
    {
      instance = state->instance;
      sourceLayout = 0;
      v16 = (FMOD::SystemI *)*((_QWORD *)instance + 22);
      result = FMOD::SystemI::getChannelLayout(v16, sourceSpeakerMode, &sourceLayout);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        targetLayout = 0;
        result = FMOD::SystemI::getChannelLayout(v16, targetSpeakerMode, &targetLayout);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
          return (unsigned int)FMOD::ChannelLayout::sumSurroundMatrix(
                                 sourceLayout,
                                 targetLayout,
                                 direction,
                                 extent,
                                 (__m128)LODWORD(rotation),
                                 lowFrequencyGain,
                                 overallGain,
                                 matrixHop,
                                 matrix,
                                 flags);
      }
    }
  }
  return result;
}


// Address: 0x224cf80 | Name: _ZN4FMOD7SystemI23sumMonoToSurroundMatrixEP14FMOD_DSP_STATE16FMOD_SPEAKERMODEffffiPf
FMOD_RESULT_0 __fastcall FMOD::SystemI::sumMonoToSurroundMatrix(
        FMOD_DSP_STATE *state,
        FMOD_SPEAKERMODE_0 targetSpeakerMode,
        float direction,
        float extent,
        float lowFrequencyGain,
        float overallGain,
        int matrixHop,
        float *matrix)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *const *instance; // rax
  const FMOD::ChannelLayout *targetLayout; // [rsp+20h] [rbp-10h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( matrix && (unsigned int)(matrixHop - 1) <= 0x1F )
  {
    instance = (FMOD::SystemI *const *)state->instance;
    targetLayout = 0;
    result = FMOD::SystemI::getChannelLayout(instance[22], targetSpeakerMode, &targetLayout);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return (unsigned int)FMOD::ChannelLayout::sumSurroundMatrixMono(
                             targetLayout,
                             direction,
                             extent,
                             lowFrequencyGain,
                             overallGain,
                             matrixHop,
                             matrix);
  }
  return result;
}


// Address: 0x224d010 | Name: _ZN4FMOD7SystemI25sumStereoToSurroundMatrixEP14FMOD_DSP_STATE16FMOD_SPEAKERMODEfffffiPf
FMOD_RESULT_0 __fastcall FMOD::SystemI::sumStereoToSurroundMatrix(
        FMOD_DSP_STATE *state,
        FMOD_SPEAKERMODE_0 targetSpeakerMode,
        float direction,
        float extent,
        float rotation,
        float lowFrequencyGain,
        float overallGain,
        int matrixHop,
        float *matrix)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *const *instance; // rax
  const FMOD::ChannelLayout *targetLayout; // [rsp+24h] [rbp-10h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( matrix && (unsigned int)(matrixHop - 1) <= 0x1F )
  {
    instance = (FMOD::SystemI *const *)state->instance;
    targetLayout = 0;
    result = FMOD::SystemI::getChannelLayout(instance[22], targetSpeakerMode, &targetLayout);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return (unsigned int)FMOD::ChannelLayout::sumStereoToSurroundMatrix(
                             targetLayout,
                             direction,
                             extent,
                             rotation,
                             lowFrequencyGain,
                             overallGain,
                             matrixHop,
                             matrix);
  }
  return result;
}


// Address: 0x224d0b0 | Name: _ZN4FMOD7SystemI19getDefaultMixMatrixE16FMOD_SPEAKERMODES1_Pfi
FMOD_RESULT_0 __fastcall FMOD::SystemI::getDefaultMixMatrix(
        FMOD::SystemI *const this,
        FMOD_SPEAKERMODE_0 sourceSpeakerMode,
        FMOD_SPEAKERMODE_0 targetSpeakerMode,
        float *matrix,
        int matrixHop)
{
  double v5; // xmm1_8
  float v6; // xmm2_4
  FMOD_RESULT_0 result; // eax
  int mChannelCount; // r8d
  const FMOD::ChannelLayout *v10; // rbp
  const FMOD::ChannelLayout *v11; // rbx
  int hopa; // [rsp+Ch] [rbp-2Ch]
  const FMOD::ChannelLayout *sourceLayout; // [rsp+10h] [rbp-28h] BYREF
  const FMOD::ChannelLayout *targetLayout; // [rsp+18h] [rbp-20h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( matrix && (unsigned int)matrixHop <= 0x20 )
  {
    if ( sourceSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
    {
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
    else
    {
      result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      if ( targetSpeakerMode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
      {
        sourceLayout = 0;
        result = FMOD::SystemI::getChannelLayout(this, sourceSpeakerMode, &sourceLayout);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          targetLayout = 0;
          result = FMOD::SystemI::getChannelLayout(this, targetSpeakerMode, &targetLayout);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            mChannelCount = matrixHop;
            v10 = sourceLayout;
            if ( !matrixHop )
              mChannelCount = sourceLayout->mChannelCount;
            v11 = targetLayout;
            hopa = mChannelCount;
            memset(matrix, 0, 4LL * targetLayout->mChannelCount * mChannelCount);
            return (unsigned int)FMOD::ChannelLayout::sumDefaultMatrix(v10, v11, 1.0, hopa, matrix, v5, v6);
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x224d190 | Name: _ZN4FMOD7SystemI14getRolloffGainEP14FMOD_DSP_STATE28FMOD_DSP_PAN_3D_ROLLOFF_TYPEfffPf
__int64 __fastcall FMOD::SystemI::getRolloffGain(
        FMOD_DSP_STATE *state,
        FMOD_DSP_PAN_3D_ROLLOFF_TYPE rolloff,
        float distance,
        float minDistance,
        float maxDistance,
        float *gain,
        double a7,
        float a8)
{
  if ( gain )
    return FMOD::getRolloffGain(
             rolloff,
             distance,
             minDistance,
             maxDistance,
             *(float *)((char *)&stru_11358.r_offset + *((_QWORD *)state->instance + 22)),
             gain,
             a8);
  else
    return 31;
}


