// Address: 0x220db50 | Name: _ZN4FMOD17DSPHighPassSimple16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPHighPassSimple::getDescriptionEx()
{
  memset(&stru_2AF6DA0, 0, sizeof(stru_2AF6DA0));
  FMOD_strcpy_safe(stru_2AF6DA0.name, "Cutoff freq", 16);
  FMOD_strcpy_safe(stru_2AF6DA0.label, "hz", 16);
  *(_QWORD *)&stru_2AF6DA0.floatdesc.min = 0x46ABE00041200000LL;
  stru_2AF6DA0.intdesc.defaultval = 1148846080;
  stru_2AF6DA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AF6DA0.description = "Highpass cutoff frequency in hz.  10.0 to 22000.0.  Default = 1000.0";
  *(&stru_2AF6D60.mHandle + 1) = 26;
  stru_2AF6D60.mSize = 800;
  stru_2AF6D60.mDescription = &stru_286C6E0;
  return &stru_2AF6D60;
}


// Address: 0x220dc00 | Name: _ZN4FMOD17DSPHighPassSimple13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPHighPassSimple::resetInternal(FMOD::DSPHighPassSimple *const this)
{
  __int64 i; // rax

  for ( i = 0; i != 128; i += 4 )
  {
    *(_DWORD *)((char *)this + i + 532) = 0;
    *(_DWORD *)((char *)this + i + 660) = 0;
  }
  LOBYTE(i) = 0;
  return (int)i;
}


// Address: 0x220dc30 | Name: _ZN4FMOD17DSPHighPassSimple13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPHighPassSimple::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPHighPassSimple::resetInternal((FMOD::DSPHighPassSimple *const)dsp_state->instance);
}


// Address: 0x220dc40 | Name: _ZN4FMOD17DSPHighPassSimple18updateCoefficientsEf
__int64 __fastcall FMOD::DSPHighPassSimple::updateCoefficients(
        FMOD::DSPHighPassSimple *const this,
        float a2,
        float cutoffhz)
{
  int v3; // eax
  float v4; // xmm2_4
  float v5; // xmm1_4
  __int64 result; // rax

  v3 = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  if ( a2 >= 22000.0 )
  {
    *((_DWORD *)this + 197) = 0;
    return 0;
  }
  else
  {
    v4 = (float)v3;
    v5 = (float)v3 / 3.1415927;
    result = 0;
    if ( v5 >= a2 )
      *((float *)this + 197) = (float)(1.0 / (float)(6.2831855 * a2))
                             / (float)((float)(1.0 / v4) + (float)(1.0 / (float)(6.2831855 * a2)));
    else
      *((float *)this + 197) = (float)(22000.0 - a2) / (float)(3.0 * (float)(22000.0 - v5));
  }
  return result;
}


// Address: 0x220dcf0 | Name: _ZN4FMOD17DSPHighPassSimple14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPHighPassSimple::createInternal(FMOD::DSPHighPassSimple *const this)
{
  double v1; // xmm1_8
  __int64 v2; // rbp
  __int64 v3; // rax
  int v4; // ebx
  FMOD_RESULT_0 result; // eax
  float v6; // xmm0_4

  v2 = 0;
  v3 = *((_QWORD *)this + 30);
  v4 = 0;
  if ( *(int *)(v3 + 96) > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v4,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v3 + 104) + v2) + 56LL),
                 v1);
      if ( result )
        break;
      v3 = *((_QWORD *)this + 30);
      ++v4;
      v2 += 8;
      if ( *(_DWORD *)(v3 + 96) <= v4 )
        goto LABEL_6;
    }
  }
  else
  {
LABEL_6:
    FMOD::DSPHighPassSimple::resetInternal(this);
    v6 = *((float *)this + 198);
    *((float *)this + 132) = v6;
    FMOD::DSPHighPassSimple::updateCoefficients(this, v6, *(float *)&v1);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x220dd80 | Name: _ZN4FMOD17DSPHighPassSimple14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPHighPassSimple::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPHighPassSimple::createInternal((FMOD::DSPHighPassSimple *const)dsp_state->instance);
}


// Address: 0x220dd90 | Name: _ZN4FMOD17DSPHighPassSimple12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPHighPassSimple::readInternal(
        FMOD::DSPHighPassSimple *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float v6; // xmm1_4
  float v9; // xmm0_4
  float v10; // xmm15_4
  float *v11; // r11
  __int64 v12; // r10
  unsigned __int64 v13; // rdx
  __int64 v14; // rdi
  __m128 v15; // xmm2
  float *v16; // rax
  float *v17; // r8
  float v18; // xmm3_4
  float v19; // xmm0_4
  unsigned int v20; // r9d
  float v21; // xmm1_4
  float v22; // xmm0_4
  _DWORD *v24; // rax
  float v25; // xmm3_4
  float v26; // xmm0_4
  __m128 v27; // xmm2
  float v28; // xmm1_4
  float v29; // xmm0_4
  float v30; // xmm11_4
  float v31; // xmm10_4
  float v32; // xmm9_4
  float v33; // xmm7_4
  float v34; // xmm8_4
  float v35; // xmm5_4
  float v36; // xmm4_4
  float v37; // xmm3_4
  float v38; // xmm2_4
  float v39; // xmm1_4
  float v40; // xmm0_4
  float v41; // xmm8_4
  __m128 v42; // xmm6
  float v43; // xmm13_4
  float *v44; // rax
  float v45; // xmm12_4
  float v46; // xmm5_4
  float v47; // xmm11_4
  float v48; // xmm4_4
  float v49; // xmm10_4
  float v50; // xmm3_4
  float v51; // xmm9_4
  float v52; // xmm2_4
  float v53; // xmm1_4
  float v54; // xmm7_4
  float v55; // xmm0_4
  float v56; // xmm5_4
  float v57; // xmm6_4
  float v58; // xmm1_4
  float v59; // xmm0_4
  __m128 v60; // xmm2
  float v61; // xmm4_4
  float v62; // xmm3_4
  float v63; // xmm1_4
  float v64; // xmm0_4
  float v65; // xmm9_4
  float v66; // xmm8_4
  float v67; // xmm7_4
  float v68; // xmm5_4
  float v69; // xmm13_4
  float v70; // xmm12_4
  float v71; // xmm11_4
  float v72; // xmm4_4
  float v73; // xmm3_4
  float v74; // xmm2_4
  float v75; // xmm1_4
  __m128 v76; // xmm0
  float v77; // xmm10_4
  float v78; // xmm13_4
  float v79; // xmm5_4
  float v80; // xmm14_4
  float v81; // xmm6_4
  float v82; // xmm13_4
  float v83; // xmm6_4
  float v84; // xmm13_4
  float v85; // xmm9_4
  float v86; // xmm2_4
  float v87; // xmm14_4
  float v88; // xmm10_4
  float v89; // xmm5_4
  float v90; // xmm12_4
  float v91; // xmm8_4
  float v92; // xmm11_4
  float v93; // xmm7_4
  float v94; // xmm3_4
  float v95; // xmm15_4
  float v96; // xmm10_4
  int prev_xG; // [rsp+0h] [rbp-40h]
  float prev_xGa; // [rsp+0h] [rbp-40h]
  unsigned int prev_xAa; // [rsp+8h] [rbp-38h]
  float prev_xA; // [rsp+8h] [rbp-38h]
  int prev_xFa; // [rsp+Ch] [rbp-34h]
  float prev_xF; // [rsp+Ch] [rbp-34h]
  float prev_xH; // [rsp+10h] [rbp-30h]
  float prev_xE; // [rsp+14h] [rbp-2Ch]

  if ( !inbuffer )
    return FMOD_RESULT::FMOD_OK_0;
  v9 = *((float *)this + 198);
  if ( v9 != *((float *)this + 132) )
  {
    *((float *)this + 132) = v9;
    prev_xFa = inchannels;
    prev_xAa = length;
    FMOD::DSPHighPassSimple::updateCoefficients(this, v9, v6);
    inchannels = prev_xFa;
    length = prev_xAa;
  }
  v10 = *((float *)this + 197);
  if ( v10 == 1.0 )
  {
    memcpy_0(outbuffer, inbuffer, length * 4LL * inchannels);
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( v10 == 0.0 )
  {
    prev_xG = inchannels;
    memset(outbuffer, 0, length * 4LL * inchannels);
    if ( prev_xG > 0 )
    {
      v24 = (_DWORD *)((char *)this + 532);
      do
      {
        *v24 = 0;
        v24[32] = 0;
        ++v24;
      }
      while ( v24 != (_DWORD *)((char *)this + 4 * (unsigned int)(prev_xG - 1) + 536) );
      return FMOD_RESULT::FMOD_OK_0;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( inchannels == 1 )
  {
    v25 = *((float *)this + 133);
    v26 = *((float *)this + 165);
    if ( length )
    {
      v27 = (__m128)LODWORD(flt_286C6D0);
      while ( 1 )
      {
        v28 = *inbuffer;
        ++outbuffer;
        ++inbuffer;
        v29 = (float)(v26 + v28) + v27.m128_f32[0];
        v27 = _mm_xor_ps(v27, (__m128)0x80000000);
        v26 = (float)(v29 - v25) * v10;
        *(outbuffer - 1) = v26;
        if ( !--length )
          break;
        v25 = v28;
        v10 = *((float *)this + 197);
      }
      flt_286C6D0 = v27.m128_f32[0];
    }
    else
    {
      v28 = *((float *)this + 133);
    }
    *((float *)this + 133) = v28;
    *((float *)this + 165) = v26;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( inchannels != 2 )
    {
      if ( inchannels == 6 )
      {
        v30 = *((float *)this + 133);
        v31 = *((float *)this + 134);
        v32 = *((float *)this + 135);
        v33 = *((float *)this + 137);
        v34 = v33;
        v35 = *((float *)this + 165);
        v36 = *((float *)this + 166);
        v37 = *((float *)this + 167);
        v38 = *((float *)this + 168);
        v39 = *((float *)this + 169);
        v40 = *((float *)this + 170);
        if ( length )
        {
          v41 = *((float *)this + 136);
          v42 = (__m128)LODWORD(flt_286C6D0);
          v43 = *((float *)this + 138);
          v44 = &inbuffer[6 * length];
          while ( 1 )
          {
            v45 = *inbuffer;
            inbuffer += 6;
            outbuffer += 6;
            v46 = (float)((float)(v35 + v45) + v42.m128_f32[0]) - v30;
            v47 = *(inbuffer - 5);
            v35 = v46 * v10;
            v48 = (float)((float)(v36 + v47) + v42.m128_f32[0]) - v31;
            v49 = *(inbuffer - 4);
            v36 = v48 * v10;
            v50 = (float)((float)(v37 + v49) + v42.m128_f32[0]) - v32;
            v51 = *(inbuffer - 3);
            v37 = v50 * v10;
            v52 = (float)((float)(v38 + v51) + v42.m128_f32[0]) - v41;
            v34 = *(inbuffer - 2);
            v38 = v52 * v10;
            v53 = (float)((float)(v39 + v34) + v42.m128_f32[0]) - v33;
            v54 = *(inbuffer - 1);
            *(outbuffer - 6) = v35;
            *(outbuffer - 5) = v36;
            *(outbuffer - 4) = v37;
            v39 = v53 * v10;
            *(outbuffer - 3) = v38;
            v55 = (float)(v40 + v54) + v42.m128_f32[0];
            v42 = _mm_xor_ps(v42, (__m128)0x80000000);
            *(outbuffer - 2) = v39;
            v40 = (float)(v55 - v43) * v10;
            *(outbuffer - 1) = v40;
            if ( inbuffer == v44 )
              break;
            v43 = v54;
            v33 = v34;
            v41 = v51;
            v32 = v49;
            v31 = v47;
            v30 = v45;
            v10 = *((float *)this + 197);
          }
          flt_286C6D0 = v42.m128_f32[0];
        }
        else
        {
          v54 = *((float *)this + 138);
          v51 = *((float *)this + 136);
          v49 = *((float *)this + 135);
          v47 = *((float *)this + 134);
          v45 = *((float *)this + 133);
        }
        *((float *)this + 133) = v45;
        *((float *)this + 134) = v47;
        *((float *)this + 135) = v49;
        *((float *)this + 136) = v51;
        *((float *)this + 137) = v34;
        *((float *)this + 138) = v54;
        *((float *)this + 165) = v35;
        *((float *)this + 166) = v36;
        *((float *)this + 167) = v37;
        *((float *)this + 168) = v38;
        *((float *)this + 169) = v39;
        *((float *)this + 170) = v40;
      }
      else if ( inchannels == 8 )
      {
        v65 = *((float *)this + 133);
        v66 = *((float *)this + 135);
        prev_xF = *((float *)this + 138);
        v67 = *((float *)this + 136);
        prev_xH = *((float *)this + 140);
        v68 = *((float *)this + 165);
        v69 = *((float *)this + 166);
        v70 = *((float *)this + 167);
        v71 = *((float *)this + 168);
        v72 = *((float *)this + 169);
        v73 = *((float *)this + 170);
        v74 = *((float *)this + 171);
        v75 = *((float *)this + 172);
        if ( length )
        {
          prev_xE = *((float *)this + 137);
          v76 = (__m128)LODWORD(flt_286C6D0);
          v77 = *((float *)this + 166);
          v78 = *((float *)this + 165);
          v79 = *((float *)this + 134);
          v80 = *((float *)this + 139);
          while ( 1 )
          {
            v81 = *inbuffer;
            outbuffer += 8;
            inbuffer += 8;
            v82 = v78 + v81;
            prev_xA = v81;
            v83 = *(inbuffer - 2);
            v84 = (float)(v82 + v76.m128_f32[0]) - v65;
            v85 = *(inbuffer - 7);
            v86 = (float)((float)(v74 + v83) + v76.m128_f32[0]) - v80;
            v87 = *(inbuffer - 1);
            v78 = v84 * v10;
            v74 = v86 * v10;
            v88 = (float)((float)(v77 + v85) + v76.m128_f32[0]) - v79;
            v89 = *(inbuffer - 6);
            v77 = v88 * v10;
            v75 = (float)((float)((float)(v75 + v87) + v76.m128_f32[0]) - prev_xH) * v10;
            v90 = (float)((float)(v70 + v89) + v76.m128_f32[0]) - v66;
            prev_xGa = *(inbuffer - 5);
            v91 = *(inbuffer - 4);
            v70 = v90 * v10;
            v92 = (float)((float)(v71 + prev_xGa) + v76.m128_f32[0]) - v67;
            v93 = *(inbuffer - 3);
            *(outbuffer - 8) = v78;
            *(outbuffer - 7) = v77;
            *(outbuffer - 6) = v70;
            v71 = v92 * v10;
            *(outbuffer - 2) = v74;
            *(outbuffer - 1) = v75;
            v72 = (float)((float)((float)(v72 + v91) + v76.m128_f32[0]) - prev_xE) * v10;
            *(outbuffer - 5) = v71;
            v94 = (float)((float)(v73 + v93) + v76.m128_f32[0]) - prev_xF;
            v76 = _mm_xor_ps(v76, (__m128)0x80000000);
            *(outbuffer - 4) = v72;
            v73 = v94 * v10;
            *(outbuffer - 3) = v73;
            if ( !--length )
              break;
            prev_xH = v87;
            v80 = v83;
            prev_xF = v93;
            prev_xE = v91;
            v66 = v89;
            v10 = *((float *)this + 197);
            v79 = v85;
            v67 = prev_xGa;
            v65 = prev_xA;
          }
          flt_286C6D0 = v76.m128_f32[0];
          v95 = v89;
          v68 = v78;
          v69 = v77;
          v96 = prev_xA;
        }
        else
        {
          v83 = *((float *)this + 139);
          v87 = *((float *)this + 140);
          prev_xGa = *((float *)this + 136);
          v91 = *((float *)this + 137);
          v93 = *((float *)this + 138);
          v95 = *((float *)this + 135);
          v85 = *((float *)this + 134);
          v96 = *((float *)this + 133);
        }
        *((float *)this + 133) = v96;
        *((float *)this + 134) = v85;
        *((float *)this + 135) = v95;
        *((float *)this + 136) = prev_xGa;
        *((float *)this + 137) = v91;
        *((float *)this + 138) = v93;
        *((float *)this + 139) = v83;
        *((float *)this + 140) = v87;
        *((float *)this + 165) = v68;
        *((float *)this + 166) = v69;
        *((float *)this + 167) = v70;
        *((float *)this + 168) = v71;
        *((float *)this + 169) = v72;
        *((float *)this + 170) = v73;
        *((float *)this + 171) = v74;
        *((float *)this + 172) = v75;
      }
      else if ( inchannels > 0 )
      {
        v11 = (float *)((char *)this + 532);
        v12 = 4LL * inchannels;
        v13 = 0;
        v14 = 4LL * (unsigned int)(inchannels - 1) + 4;
        v15 = (__m128)LODWORD(flt_286C6D0);
        do
        {
          v16 = &inbuffer[v13 / 4];
          v17 = &outbuffer[v13 / 4];
          v18 = *v11;
          v19 = v11[32];
          if ( length )
          {
            v20 = length;
            while ( 1 )
            {
              v21 = *v16;
              v16 = (float *)((char *)v16 + v12);
              v22 = (float)(v19 + v21) + v15.m128_f32[0];
              v15 = _mm_xor_ps(v15, (__m128)0x80000000);
              v19 = (float)(v22 - v18) * *((float *)this + 197);
              *v17 = v19;
              v17 = (float *)((char *)v17 + v12);
              if ( !--v20 )
                break;
              v18 = v21;
            }
          }
          else
          {
            v21 = *v11;
          }
          v13 += 4LL;
          *v11++ = v21;
          v11[31] = v19;
        }
        while ( v13 != v14 );
        flt_286C6D0 = v15.m128_f32[0];
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    v56 = *((float *)this + 133);
    v57 = *((float *)this + 134);
    v58 = *((float *)this + 165);
    v59 = *((float *)this + 166);
    if ( length )
    {
      v60 = (__m128)LODWORD(flt_286C6D0);
      while ( 1 )
      {
        v61 = *inbuffer;
        outbuffer += 2;
        v62 = inbuffer[1];
        inbuffer += 2;
        v63 = (float)(v58 + v61) + v60.m128_f32[0];
        v64 = (float)(v59 + v62) + v60.m128_f32[0];
        v60 = _mm_xor_ps(v60, (__m128)0x80000000);
        v58 = (float)(v63 - v56) * v10;
        v59 = (float)(v64 - v57) * v10;
        *(outbuffer - 2) = v58;
        *(outbuffer - 1) = v59;
        if ( !--length )
          break;
        v57 = v62;
        v56 = v61;
        v10 = *((float *)this + 197);
      }
      flt_286C6D0 = v60.m128_f32[0];
    }
    else
    {
      v62 = *((float *)this + 134);
      v61 = *((float *)this + 133);
    }
    *((float *)this + 133) = v61;
    *((float *)this + 134) = v62;
    *((float *)this + 165) = v58;
    *((float *)this + 166) = v59;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x220e650 | Name: _ZN4FMOD17DSPHighPassSimple12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPHighPassSimple::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPHighPassSimple::readInternal(
           (FMOD::DSPHighPassSimple *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x220e660 | Name: _ZN4FMOD17DSPHighPassSimple25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPHighPassSimple::setParameterFloatInternal(
        FMOD::DSPHighPassSimple *const this,
        int index,
        float a3,
        float value)
{
  if ( !index )
    *((float *)this + 198) = a3;
  return 0;
}


// Address: 0x220e670 | Name: _ZN4FMOD17DSPHighPassSimple25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPHighPassSimple::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPHighPassSimple::setParameterFloatInternal(
           (FMOD::DSPHighPassSimple *const)dsp_state->instance,
           index,
           a3,
           value);
}


// Address: 0x220e680 | Name: _ZN4FMOD17DSPHighPassSimple25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPHighPassSimple::getParameterFloatInternal(
        FMOD::DSPHighPassSimple *const this,
        int index,
        float *value,
        char *valuestr)
{
  if ( index )
    return FMOD_RESULT::FMOD_OK_0;
  *value = *((float *)this + 198);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  sprintf(valuestr, "%.02f", *((float *)this + 198));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e6d0 | Name: _ZN4FMOD17DSPHighPassSimple25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPHighPassSimple::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPHighPassSimple::getParameterFloatInternal(
           (FMOD::DSPHighPassSimple *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


