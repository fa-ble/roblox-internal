// Address: 0x21d2530 | Name: _ZN4FMOD11DSPLowPass216getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPLowPass2::getDescriptionEx()
{
  memset(&stru_2AD8660, 0, sizeof(stru_2AD8660));
  FMOD_strcpy_safe(stru_2AD8660.name, "Cutoff freq", 16);
  FMOD_strcpy_safe(stru_2AD8660.label, "hz", 16);
  stru_2AD8660.description = "Lowpass cutoff frequency in hz.  1.0 to 22000.0.  Default = 5000.0";
  memset(&stru_2AD8600, 0, sizeof(stru_2AD8600));
  stru_2AD8660.intdesc.min = 1065353216;
  *(_QWORD *)(&stru_2AD8660.datadesc + 1) = 0x459C400046ABE000LL;
  stru_2AD8660.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8600.name, "Resonance", 16);
  FMOD_strcpy_safe(stru_2AD8600.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AD8600.floatdesc.min = 0x42FE00003F800000LL;
  stru_2AD8600.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AD8600.description = "Lowpass resonance Q value. 0.0 to 127.0.  Default = 1.0";
  stru_2AD8600.intdesc.defaultval = 1065353216;
  *(&stru_2AD85C0.mHandle + 1) = 4;
  stru_2AD85C0.mDescription = &stru_286A600;
  stru_2AD85C0.mSize = 816;
  return &stru_2AD85C0;
}


// Address: 0x21d2670 | Name: _ZN4FMOD11DSPLowPass213resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass2::resetInternal(FMOD::DSPLowPass2 *const this)
{
  __int64 i; // rax

  for ( i = 0; i != 256; i += 8 )
  {
    *(_DWORD *)((char *)this + i + 540) = 0;
    *(_DWORD *)((char *)this + i + 536) = 0;
  }
  LOWORD(i) = 0;
  return (int)i;
}


// Address: 0x21d26a0 | Name: _ZN4FMOD11DSPLowPass213resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass2::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLowPass2::resetInternal((FMOD::DSPLowPass2 *const)dsp_state->instance);
}


// Address: 0x21d26b0 | Name: _ZN4FMOD11DSPLowPass218updateCoefficientsEff
__int64 __fastcall FMOD::DSPLowPass2::updateCoefficients(
        FMOD::DSPLowPass2 *const this,
        float a2,
        float resonance,
        float cutoff)
{
  float v4; // xmm0_4
  float v5; // xmm0_4
  __m128 v6; // xmm4
  __m128 v7; // xmm2
  __m128 v8; // xmm2
  float v9; // xmm1_4
  float v10; // xmm0_4
  float v11; // xmm1_4
  float v12; // xmm0_4
  __m128 v13; // rt1
  unsigned __int32 v14; // xmm3_4
  float fc; // [rsp+1Ch] [rbp-Ch]

  fc = (float)(6.2831855 / (float)*(int *)(*((_QWORD *)this + 22) + 1696LL)) * resonance;
  v4 = powf(10.0, (float)-(float)(a2 * 0.1875) / 20.0);
  v5 = v4 + v4;
  v6 = (__m128)0x3F800000u;
  v7.m128_f32[0] = (float)(1.0 - v5) * fc;
  v8 = _mm_cmpge_ss((__m128)0x40000000u, v7);
  v9 = (float)(1.0 / fc) * (float)(1.0 / fc);
  v8.m128_f32[0] = (float)(v5
                         - COERCE_FLOAT(
                             _mm_andnot_ps(v8, (__m128)0x40000000u).m128_u32[0]
                           | COERCE_UNSIGNED_INT((float)(1.0 - v5) * fc) & v8.m128_i32[0]))
                 / fc;
  v10 = (float)(v8.m128_f32[0] + v9) + v9;
  v8.m128_f32[0] = (float)(v8.m128_f32[0] + 1.0) + v9;
  v6.m128_f32[0] = 1.0 / v8.m128_f32[0];
  v11 = (float)-v9 / v8.m128_f32[0];
  v12 = v10 / v8.m128_f32[0];
  v13.m128_i32[0] = 925353388;
  v14 = COERCE_UNSIGNED_INT(1.0 / v8.m128_f32[0]) & _mm_cmpge_ss(v6, v13).m128_u32[0];
  if ( v11 < -0.99900001 && v12 > 1.999 )
  {
    v12 = 2.0;
    v11 = -1.0;
  }
  *((_DWORD *)this + 198) = v14;
  *((float *)this + 199) = v12;
  *((float *)this + 200) = v11;
  return 0;
}


// Address: 0x21d27e0 | Name: _ZN4FMOD11DSPLowPass214createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass2::createInternal(FMOD::DSPLowPass2 *const this)
{
  double v1; // xmm1_8
  float v2; // xmm2_4
  __int64 v3; // rbp
  __int64 v4; // rax
  int v5; // ebx
  FMOD_RESULT_0 result; // eax
  float v7; // xmm0_4
  float v8; // xmm1_4

  v3 = 0;
  v4 = *((_QWORD *)this + 30);
  v5 = 0;
  if ( *(int *)(v4 + 96) > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v5,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v4 + 104) + v3) + 56LL),
                 v1);
      if ( result )
        break;
      v4 = *((_QWORD *)this + 30);
      ++v5;
      v3 += 8;
      if ( *(_DWORD *)(v4 + 96) <= v5 )
        goto LABEL_6;
    }
  }
  else
  {
LABEL_6:
    FMOD::DSPLowPass2::resetInternal(this);
    v7 = *((float *)this + 201);
    v8 = *((float *)this + 202);
    *((float *)this + 132) = v7;
    *((float *)this + 133) = v8;
    FMOD::DSPLowPass2::updateCoefficients(this, v7, v8, v2);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21d2880 | Name: _ZN4FMOD11DSPLowPass214createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass2::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLowPass2::createInternal((FMOD::DSPLowPass2 *const)dsp_state->instance);
}


// Address: 0x21d2890 | Name: _ZN4FMOD11DSPLowPass212readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass2::readInternal(
        FMOD::DSPLowPass2 *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float v6; // xmm2_4
  __int64 v7; // r13
  float *v8; // rbp
  float v9; // xmm0_4
  float v12; // xmm1_4
  float v13; // xmm0_4
  float *v14; // r11
  __int64 v15; // r10
  __int64 v16; // rdx
  __m128 v17; // xmm2
  float *v18; // rax
  float *v19; // r8
  float v20; // xmm1_4
  float v21; // xmm3_4
  int v22; // r9d
  float v23; // xmm0_4
  float v24; // xmm0_4
  float v25; // xmm0_4
  _DWORD *v27; // rax
  float v28; // xmm2_4
  float v29; // xmm0_4
  __m128 v30; // xmm3
  float i; // xmm4_4
  float v32; // xmm1_4
  float v33; // xmm1_4
  float v34; // xmm5_4
  float v35; // xmm4_4
  float v36; // xmm9_4
  float v37; // xmm1_4
  __m128 v38; // xmm3
  float v39; // xmm2_4
  float v40; // xmm10_4
  float v41; // xmm6_4
  float v42; // xmm2_4
  float v43; // xmm1_4
  float v44; // xmm1_4
  float v45; // xmm1_4
  float v46; // xmm12_4
  float v47; // xmm10_4
  float v48; // xmm2_4
  float v49; // xmm4_4
  float v50; // xmm13_4
  float v51; // xmm3_4
  float v52; // xmm11_4
  float v53; // xmm15_4
  float v54; // xmm14_4
  __m128 v55; // xmm7
  float v56; // xmm6_4
  float v57; // xmm9_4
  float v58; // xmm8_4
  float v59; // xmm6_4
  float v60; // xmm5_4
  float v61; // xmm4_4
  float v62; // xmm3_4
  float v63; // xmm2_4
  float v64; // xmm15_4
  float v65; // xmm15_4
  float v66; // xmm9_4
  float v67; // xmm1_4
  float v68; // xmm11_4
  float v69; // xmm8_4
  float v70; // xmm2_4
  float v71; // xmm4_4
  float v72; // xmm3_4
  float v73; // xmm5_4
  float v74; // xmm11_4
  float v75; // xmm12_4
  __m128 v76; // xmm1
  float v77; // xmm13_4
  float v78; // xmm14_4
  float v79; // xmm10_4
  float v80; // xmm8_4
  float v81; // xmm10_4
  float v82; // xmm9_4
  float v83; // xmm8_4
  float v84; // xmm7_4
  float v85; // xmm15_4
  float v86; // xmm6_4
  float v87; // xmm5_4
  float v88; // xmm4_4
  float v89; // xmm3_4
  float v90; // xmm2_4
  float v91; // xmm2_4
  float v92; // xmm9_4
  float v93; // xmm10_4
  float fyD2; // [rsp+Ch] [rbp-5Ch]
  float fyD2a; // [rsp+Ch] [rbp-5Ch]
  float fyB2; // [rsp+10h] [rbp-58h]
  float fyE2; // [rsp+20h] [rbp-48h]
  float fyE2a; // [rsp+20h] [rbp-48h]
  float fyF2; // [rsp+24h] [rbp-44h]
  float fyF2a; // [rsp+24h] [rbp-44h]
  float fyG2; // [rsp+28h] [rbp-40h]
  float fyE2_0; // [rsp+2Ch] [rbp-3Ch]
  float fyF2_0; // [rsp+30h] [rbp-38h]
  float fyG2_0; // [rsp+34h] [rbp-34h]
  float fyH2; // [rsp+38h] [rbp-30h]
  float fyC2; // [rsp+3Ch] [rbp-2Ch]

  v7 = length;
  v8 = inbuffer;
  if ( !inbuffer )
    return FMOD_RESULT::FMOD_OK_0;
  v9 = *((float *)this + 201);
  v12 = *((float *)this + 202);
  if ( v9 != *((float *)this + 132) || v12 != *((float *)this + 133) )
  {
    *((float *)this + 132) = v9;
    *((float *)this + 133) = v12;
    FMOD::DSPLowPass2::updateCoefficients(this, v9, v12, v6);
  }
  v13 = *((float *)this + 198);
  if ( v13 == 0.0 && *((float *)this + 199) == 2.0 && *((float *)this + 200) == -1.0 )
  {
    memset(outbuffer, 0, v7 * 4LL * inchannels);
    if ( inchannels > 0 )
    {
      v27 = (_DWORD *)((char *)this + 536);
      do
      {
        *v27 = 0;
        v27[1] = 0;
        v27 += 2;
      }
      while ( v27 != (_DWORD *)((char *)this + 8 * (unsigned int)(inchannels - 1) + 544) );
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( inchannels == 1 )
  {
    v28 = *((float *)this + 134);
    if ( (_DWORD)v7 )
    {
      v29 = *((float *)this + 135);
      v30 = (__m128)LODWORD(flt_286A5E8);
      for ( i = *((float *)this + 198); ; i = *((float *)this + 198) )
      {
        v32 = *v8 + v30.m128_f32[0];
        ++outbuffer;
        ++v8;
        v30 = _mm_xor_ps(v30, (__m128)0x80000000);
        v33 = (float)((float)(v32 * i) + (float)(*((float *)this + 199) * v28)) + (float)(v29 * *((float *)this + 200));
        *(outbuffer - 1) = v33;
        LODWORD(v7) = v7 - 1;
        if ( !(_DWORD)v7 )
          break;
        v29 = v28;
        v28 = v33;
      }
      flt_286A5E8 = v30.m128_f32[0];
    }
    else
    {
      v33 = *((float *)this + 134);
      v28 = *((float *)this + 135);
    }
    *((float *)this + 134) = v33;
    *((float *)this + 135) = v28;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else if ( inchannels == 2 )
  {
    v34 = *((float *)this + 134);
    v35 = *((float *)this + 136);
    v36 = *((float *)this + 137);
    if ( (_DWORD)v7 )
    {
      v37 = *((float *)this + 135);
      v38 = (__m128)LODWORD(flt_286A5E8);
      while ( 1 )
      {
        v39 = *v8;
        outbuffer += 2;
        v8 += 2;
        v40 = *((float *)this + 199);
        v41 = *((float *)this + 200);
        v42 = (float)((float)((float)(v39 + v38.m128_f32[0]) * v13) + (float)(v40 * v34)) + (float)(v37 * v41);
        v43 = *(v8 - 1) + v38.m128_f32[0];
        v38 = _mm_xor_ps(v38, (__m128)0x80000000);
        *(outbuffer - 2) = v42;
        v44 = (float)((float)(v43 * v13) + (float)(v40 * v35)) + (float)(v41 * v36);
        *(outbuffer - 1) = v44;
        LODWORD(v7) = v7 - 1;
        if ( !(_DWORD)v7 )
          break;
        v36 = v35;
        v35 = v44;
        v37 = v34;
        v34 = v42;
        v13 = *((float *)this + 198);
      }
      flt_286A5E8 = v38.m128_f32[0];
    }
    else
    {
      v44 = *((float *)this + 136);
      v42 = *((float *)this + 134);
      v35 = *((float *)this + 137);
      v34 = *((float *)this + 135);
    }
    *((float *)this + 134) = v42;
    *((float *)this + 135) = v34;
    *((float *)this + 136) = v44;
    *((float *)this + 137) = v35;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( inchannels != 6 )
    {
      if ( inchannels == 8 )
      {
        fyD2a = *((float *)this + 140);
        fyE2a = *((float *)this + 142);
        fyE2_0 = *((float *)this + 143);
        fyF2a = *((float *)this + 144);
        fyF2_0 = *((float *)this + 145);
        fyG2 = *((float *)this + 146);
        fyG2_0 = *((float *)this + 147);
        fyH2 = *((float *)this + 149);
        if ( (_DWORD)v7 )
        {
          v70 = *((float *)this + 135);
          v71 = *((float *)this + 139);
          v72 = *((float *)this + 141);
          v73 = *((float *)this + 137);
          v74 = *((float *)this + 148);
          v75 = *((float *)this + 134);
          v76 = (__m128)LODWORD(flt_286A5E8);
          v77 = *((float *)this + 136);
          v78 = *((float *)this + 138);
          while ( 1 )
          {
            v80 = *v8;
            outbuffer += 8;
            v8 += 8;
            v81 = *((float *)this + 199);
            v82 = *((float *)this + 200);
            v83 = (float)((float)((float)(v80 + v76.m128_f32[0]) * v13) + (float)(v81 * v75)) + (float)(v70 * v82);
            v84 = (float)((float)((float)(*(v8 - 7) + v76.m128_f32[0]) * v13) + (float)(v77 * v81)) + (float)(v73 * v82);
            v85 = (float)((float)((float)(*(v8 - 6) + v76.m128_f32[0]) * v13) + (float)(v78 * v81)) + (float)(v71 * v82);
            v86 = (float)((float)((float)(*(v8 - 5) + v76.m128_f32[0]) * v13) + (float)(fyD2a * v81))
                + (float)(v72 * v82);
            v87 = (float)((float)((float)(*(v8 - 4) + v76.m128_f32[0]) * v13) + (float)(fyE2a * v81))
                + (float)(fyE2_0 * v82);
            v88 = (float)((float)((float)(*(v8 - 3) + v76.m128_f32[0]) * v13) + (float)(fyF2a * v81))
                + (float)(fyF2_0 * v82);
            v89 = (float)((float)((float)(*(v8 - 2) + v76.m128_f32[0]) * v13) + (float)(fyG2 * v81))
                + (float)(fyG2_0 * v82);
            v90 = *(v8 - 1) + v76.m128_f32[0];
            *(outbuffer - 8) = v83;
            *(outbuffer - 7) = v84;
            v76 = _mm_xor_ps(v76, (__m128)0x80000000);
            *(outbuffer - 6) = v85;
            *(outbuffer - 5) = v86;
            *(outbuffer - 4) = v87;
            *(outbuffer - 3) = v88;
            *(outbuffer - 2) = v89;
            v91 = (float)((float)(v90 * v13) + (float)(v81 * v74)) + (float)(v82 * fyH2);
            *(outbuffer - 1) = v91;
            LODWORD(v7) = v7 - 1;
            if ( !(_DWORD)v7 )
              break;
            fyG2_0 = fyG2;
            v79 = fyF2a;
            fyF2a = v88;
            fyH2 = v74;
            v74 = v91;
            fyG2 = v89;
            v70 = v75;
            fyE2_0 = fyE2a;
            v75 = v83;
            fyE2a = v87;
            v71 = v78;
            v72 = fyD2a;
            v73 = v77;
            fyF2_0 = v79;
            fyD2a = v86;
            v78 = v85;
            v77 = v84;
            v13 = *((float *)this + 198);
          }
          v92 = v74;
          fyB2 = v77;
          v93 = v75;
          fyC2 = v78;
          flt_286A5E8 = v76.m128_f32[0];
        }
        else
        {
          v91 = *((float *)this + 148);
          v92 = *((float *)this + 149);
          v89 = *((float *)this + 146);
          v83 = *((float *)this + 134);
          fyG2 = *((float *)this + 147);
          v93 = *((float *)this + 135);
          v88 = *((float *)this + 144);
          fyF2a = *((float *)this + 145);
          v87 = *((float *)this + 142);
          v86 = *((float *)this + 140);
          fyE2a = *((float *)this + 143);
          v85 = *((float *)this + 138);
          v84 = *((float *)this + 136);
          fyD2a = *((float *)this + 141);
          fyC2 = *((float *)this + 139);
          fyB2 = *((float *)this + 137);
        }
        *((float *)this + 136) = v84;
        *((float *)this + 137) = fyB2;
        *((float *)this + 139) = fyC2;
        *((float *)this + 141) = fyD2a;
        *((float *)this + 143) = fyE2a;
        *((float *)this + 145) = fyF2a;
        *((float *)this + 134) = v83;
        *((float *)this + 135) = v93;
        *((float *)this + 138) = v85;
        *((float *)this + 140) = v86;
        *((float *)this + 142) = v87;
        *((float *)this + 144) = v88;
        *((float *)this + 146) = v89;
        *((float *)this + 147) = fyG2;
        *((float *)this + 148) = v91;
        *((float *)this + 149) = v92;
      }
      else if ( inchannels > 0 )
      {
        v14 = (float *)((char *)this + 536);
        v15 = 4LL * inchannels;
        v16 = 0;
        v17 = (__m128)LODWORD(flt_286A5E8);
        do
        {
          v18 = &inbuffer[v16];
          v19 = &outbuffer[v16];
          v20 = *v14;
          v21 = v14[1];
          if ( (_DWORD)v7 )
          {
            v22 = v7;
            while ( 1 )
            {
              v23 = *v18;
              v18 = (float *)((char *)v18 + v15);
              v24 = v23 + v17.m128_f32[0];
              v17 = _mm_xor_ps(v17, (__m128)0x80000000);
              v25 = (float)((float)(v24 * *((float *)this + 198)) + (float)(*((float *)this + 199) * v20))
                  + (float)(v21 * *((float *)this + 200));
              *v19 = v25;
              v19 = (float *)((char *)v19 + v15);
              if ( !--v22 )
                break;
              v21 = v20;
              v20 = v25;
            }
          }
          else
          {
            v25 = *v14;
            v20 = v14[1];
          }
          *v14 = v25;
          v14 += 2;
          ++v16;
          *(v14 - 1) = v20;
        }
        while ( v14 != (float *)((char *)this + 8 * (unsigned int)(inchannels - 1) + 544) );
        flt_286A5E8 = v17.m128_f32[0];
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    v45 = *((float *)this + 140);
    fyD2 = *((float *)this + 143);
    v46 = *((float *)this + 134);
    v47 = *((float *)this + 138);
    fyE2 = *((float *)this + 145);
    if ( (_DWORD)v7 )
    {
      v48 = *((float *)this + 135);
      v49 = *((float *)this + 137);
      v50 = *((float *)this + 136);
      v51 = *((float *)this + 139);
      v52 = *((float *)this + 142);
      v53 = *((float *)this + 141);
      v54 = *((float *)this + 144);
      v55 = (__m128)LODWORD(flt_286A5E8);
      while ( 1 )
      {
        v56 = *v8;
        v8 += 6;
        v57 = *((float *)this + 199);
        outbuffer += 6;
        v58 = *((float *)this + 200);
        v59 = (float)((float)((float)(v56 + v55.m128_f32[0]) * v13) + (float)(v57 * v46)) + (float)(v48 * v58);
        v60 = (float)((float)((float)(*(v8 - 5) + v55.m128_f32[0]) * v13) + (float)(v50 * v57)) + (float)(v49 * v58);
        v61 = (float)((float)((float)(*(v8 - 4) + v55.m128_f32[0]) * v13) + (float)(v47 * v57)) + (float)(v51 * v58);
        v62 = (float)((float)((float)(*(v8 - 3) + v55.m128_f32[0]) * v13) + (float)(v45 * v57)) + (float)(v53 * v58);
        v63 = (float)((float)((float)(*(v8 - 2) + v55.m128_f32[0]) * v13) + (float)(v52 * v57)) + (float)(fyD2 * v58);
        v64 = *(v8 - 1) + v55.m128_f32[0];
        *(outbuffer - 6) = v59;
        *(outbuffer - 5) = v60;
        v55 = _mm_xor_ps(v55, (__m128)0x80000000);
        *(outbuffer - 4) = v61;
        *(outbuffer - 3) = v62;
        *(outbuffer - 2) = v63;
        v65 = (float)((float)(v64 * v13) + (float)(v57 * v54)) + (float)(v58 * fyE2);
        *(outbuffer - 1) = v65;
        if ( v8 == &inbuffer[6 * (unsigned int)(v7 - 1) + 6] )
          break;
        fyE2 = v54;
        v54 = v65;
        fyD2 = v52;
        v53 = v45;
        v52 = v63;
        v45 = v62;
        v48 = v46;
        v51 = v47;
        v46 = v59;
        v47 = v61;
        v49 = v50;
        v50 = v60;
        v13 = *((float *)this + 198);
      }
      v66 = v45;
      fyF2 = v52;
      v67 = v65;
      flt_286A5E8 = v55.m128_f32[0];
      v68 = v50;
      v69 = v54;
    }
    else
    {
      v67 = *((float *)this + 144);
      v69 = *((float *)this + 145);
      v63 = *((float *)this + 142);
      v62 = *((float *)this + 140);
      v61 = *((float *)this + 138);
      fyF2 = *((float *)this + 143);
      v66 = *((float *)this + 141);
      v60 = *((float *)this + 136);
      v59 = *((float *)this + 134);
      v47 = *((float *)this + 139);
      v68 = *((float *)this + 137);
      v46 = *((float *)this + 135);
    }
    *((float *)this + 134) = v59;
    *((float *)this + 135) = v46;
    *((float *)this + 136) = v60;
    *((float *)this + 137) = v68;
    *((float *)this + 138) = v61;
    *((float *)this + 139) = v47;
    *((float *)this + 140) = v62;
    *((float *)this + 141) = v66;
    *((float *)this + 142) = v63;
    *((float *)this + 143) = fyF2;
    *((float *)this + 144) = v67;
    *((float *)this + 145) = v69;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21d3400 | Name: _ZN4FMOD11DSPLowPass212readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass2::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPLowPass2::readInternal(
           (FMOD::DSPLowPass2 *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x21d3410 | Name: _ZN4FMOD11DSPLowPass225setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPLowPass2::setParameterFloatInternal(
        FMOD::DSPLowPass2 *const this,
        int index,
        float a3,
        float value)
{
  if ( index )
  {
    if ( index == 1 )
      *((float *)this + 201) = a3;
    return 0;
  }
  else
  {
    *((float *)this + 202) = a3;
    return 0;
  }
}


// Address: 0x21d3440 | Name: _ZN4FMOD11DSPLowPass225setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPLowPass2::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPLowPass2::setParameterFloatInternal((FMOD::DSPLowPass2 *const)dsp_state->instance, index, a3, value);
}


// Address: 0x21d3450 | Name: _ZN4FMOD11DSPLowPass225getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass2::getParameterFloatInternal(
        FMOD::DSPLowPass2 *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v4; // xmm0_4

  if ( !index )
  {
    *value = *((float *)this + 202);
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    v4 = *((float *)this + 202);
    goto LABEL_5;
  }
  if ( index == 1 )
  {
    *value = *((float *)this + 201);
    if ( valuestr )
    {
      v4 = *((float *)this + 201);
LABEL_5:
      sprintf(valuestr, "%.02f", v4);
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d34c0 | Name: _ZN4FMOD11DSPLowPass225getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass2::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPLowPass2::getParameterFloatInternal(
           (FMOD::DSPLowPass2 *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


