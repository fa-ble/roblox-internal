// Address: 0x2233c30 | Name: _ZN4FMOD11GeometryMgr26mainOctreeLineTestCallbackEPNS_10OctreeNodeEPv
bool __fastcall FMOD::GeometryMgr::mainOctreeLineTestCallback(FMOD::OctreeNode *item, void *data)
{
  FMOD::GeometryI *v2; // rdi

  v2 = *(FMOD::GeometryI **)&item[2].aabb.xMin;
  *((_QWORD *)data + 4) = v2;
  return FMOD::GeometryI::lineTest(v2, (FMOD::GeometryI::LineTestData *)data);
}


// Address: 0x2233c40 | Name: _ZN4FMOD15OcclusionThreadC2Ev
void __fastcall FMOD::OcclusionThread::OcclusionThread(FMOD::OcclusionThread *const this)
{
  FMOD::Thread::Thread(this);
  this->mQueueRoot.mNodeData = 0;
  this->mQueueCrit = 0;
  this->mTasks = 0;
  this->mGeometryMgr = 0;
  this->_vptr_Thread = (int (**)(...))&off_29B2770;
  this->mQueueRoot.mNodePrev = &this->mQueueRoot;
  this->mQueueRoot.mNodeNext = &this->mQueueRoot;
}


// Address: 0x2233ca0 | Name: _ZN4FMOD15OcclusionThread4initEPNS_11GeometryMgrE
FMOD_RESULT_0 __fastcall FMOD::OcclusionThread::init(FMOD::OcclusionThread *const this, FMOD::GeometryMgr *geometryMgr)
{
  FMOD_OS_CRITICALSECTION **p_mQueueCrit; // rdi
  FMOD_RESULT_0 result; // eax
  int mNumChannels; // ebp
  FMOD::OCCLUSION_TASK *v6; // rdx
  FMOD::OCCLUSION_TASK *v7; // rax
  int v8; // edx

  p_mQueueCrit = &this->mQueueCrit;
  p_mQueueCrit[1] = (FMOD_OS_CRITICALSECTION *)geometryMgr;
  result = FMOD_OS_CriticalSection_Create(p_mQueueCrit, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mNumChannels = this->mGeometryMgr->mSystem->mNumChannels;
    v6 = (FMOD::OCCLUSION_TASK *)FMOD::MemPool::calloc(
                                   off_286F358->gSystemMemPool,
                                   mNumChannels << 6,
                                   "../../../core_api/src/fmod_geometry_mgr.cpp",
                                   82,
                                   0);
    this->mTasks = v6;
    result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    if ( v6 )
    {
      v7 = v6;
      v8 = 0;
      if ( mNumChannels )
      {
        do
        {
          ++v8;
          v7->state = OCCLUSION_STATE_READY;
          v7->mNodeData = 0;
          v7->mNodePrev = v7;
          v7->mNodeNext = v7;
          ++v7;
        }
        while ( mNumChannels != v8 );
      }
      return FMOD::Thread::initThread(
               this,
               "FMOD geometry thread",
               0,
               0,
               FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_GEOMETRY,
               FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_LOW,
               0x4000,
               0,
               0,
               this->mGeometryMgr->mSystem,
               1);
    }
  }
  return result;
}


// Address: 0x2233db0 | Name: _ZN4FMOD15OcclusionThread7releaseEv
FMOD_RESULT_0 __fastcall FMOD::OcclusionThread::release(FMOD::OcclusionThread *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD_OS_CRITICALSECTION *mQueueCrit; // rdi
  FMOD::OCCLUSION_TASK *mTasks; // rsi

  result = FMOD::Thread::closeThread(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mQueueCrit = this->mQueueCrit;
    if ( mQueueCrit )
    {
      result = FMOD_OS_CriticalSection_Free(mQueueCrit, 0);
      if ( result )
        return result;
      this->mQueueCrit = 0;
    }
    mTasks = this->mTasks;
    result = FMOD_RESULT::FMOD_OK_0;
    if ( mTasks )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, mTasks, "../../../core_api/src/fmod_geometry_mgr.cpp", 117);
      this->mTasks = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2233e30 | Name: _ZN4FMOD15OcclusionThread7enqueueEyP11FMOD_VECTOR
void __fastcall FMOD::OcclusionThread::enqueue(
        FMOD::OcclusionThread *const this,
        FMOD_UINT_NATIVE currentHandle,
        FMOD_VECTOR *worldposition)
{
  FMOD_OS_CRITICALSECTION *mQueueCrit; // r13
  FMOD::OCCLUSION_TASK *v5; // rax
  bool v6; // zf
  FMOD::ChannelGroupI *v7; // rax
  FMOD::OCCLUSION_TASK *p_mGeometryTask; // rdx
  float x; // xmm0_4
  FMOD::ChannelI *channeli; // [rsp+0h] [rbp-38h] BYREF
  FMOD::ChannelGroupI *channelgroupi; // [rsp+8h] [rbp-30h] BYREF

  channeli = 0;
  if ( FMOD::ChannelI::validate((FMOD::Channel *)currentHandle, &channeli, 0) == FMOD_RESULT::FMOD_OK_0 )
  {
    mQueueCrit = this->mQueueCrit;
    FMOD_OS_CriticalSection_Enter(mQueueCrit);
    v5 = &this->mTasks[(__int64)channeli->mIndex];
    if ( v5->state != OCCLUSION_STATE_UPDATED )
    {
      v6 = v5 == v5->mNodeNext;
      v5->position.x = worldposition->x;
      v5->state = OCCLUSION_STATE_READY;
      v5->currenthandle = currentHandle;
      v5->position.y = worldposition->y;
      v5->position.z = worldposition->z;
      if ( v6 && v5 == v5->mNodePrev )
      {
        v5->mNodePrev = this->mQueueRoot.mNodePrev;
        v5->mNodeNext = &this->mQueueRoot;
        this->mQueueRoot.mNodePrev = v5;
        v5->mNodePrev->FMOD::LinkedListNode::mNodeNext = v5;
      }
    }
LABEL_4:
    FMOD_OS_CriticalSection_Leave(mQueueCrit);
    return;
  }
  if ( FMOD::ChannelGroupI::validate((FMOD::ChannelGroup *)currentHandle, &channelgroupi, 0) == FMOD_RESULT::FMOD_OK_0 )
  {
    mQueueCrit = this->mQueueCrit;
    FMOD_OS_CriticalSection_Enter(mQueueCrit);
    v7 = channelgroupi;
    if ( channelgroupi->mGeometryTask.state != OCCLUSION_STATE_UPDATED )
    {
      p_mGeometryTask = &channelgroupi->mGeometryTask;
      v6 = &channelgroupi->mGeometryTask == channelgroupi->mGeometryTask.mNodeNext;
      channelgroupi->mGeometryTask.state = OCCLUSION_STATE_READY;
      x = worldposition->x;
      v7->mGeometryTask.currenthandle = currentHandle;
      v7->mGeometryTask.position.x = x;
      v7->mGeometryTask.position.y = worldposition->y;
      v7->mGeometryTask.position.z = worldposition->z;
      if ( v6 && p_mGeometryTask == v7->mGeometryTask.mNodePrev )
      {
        v7->mGeometryTask.mNodePrev = this->mQueueRoot.mNodePrev;
        v7->mGeometryTask.mNodeNext = &this->mQueueRoot;
        this->mQueueRoot.mNodePrev = p_mGeometryTask;
        v7->mGeometryTask.mNodePrev->mNodeNext = p_mGeometryTask;
      }
    }
    goto LABEL_4;
  }
}


// Address: 0x2233fd0 | Name: _ZN4FMOD15OcclusionThread7dequeueEv
FMOD::OCCLUSION_TASK *__fastcall FMOD::OcclusionThread::dequeue(FMOD::OcclusionThread *const this)
{
  FMOD_OS_CRITICALSECTION *mQueueCrit; // r12
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD::LinkedListNode *mNodePrev; // rax

  mQueueCrit = this->mQueueCrit;
  FMOD_OS_CriticalSection_Enter(mQueueCrit);
  mNodeNext = this->mQueueRoot.mNodeNext;
  if ( &this->mQueueRoot == mNodeNext && mNodeNext == this->mQueueRoot.mNodePrev )
  {
    mNodeNext = 0;
  }
  else
  {
    mNodePrev = mNodeNext->mNodePrev;
    mNodePrev->mNodeNext = mNodeNext->mNodeNext;
    mNodeNext->mNodeNext->mNodePrev = mNodePrev;
    mNodeNext->mNodePrev = mNodeNext;
    mNodeNext->mNodeNext = mNodeNext;
  }
  FMOD_OS_CriticalSection_Leave(mQueueCrit);
  return (FMOD::OCCLUSION_TASK *)mNodeNext;
}


// Address: 0x2234040 | Name: _ZN4FMOD15OcclusionThread17retrieveOcclusionEy
FMOD::OCCLUSION_TASK *__fastcall FMOD::OcclusionThread::retrieveOcclusion(
        FMOD::OcclusionThread *const this,
        FMOD_UINT_NATIVE currentHandle)
{
  FMOD::OCCLUSION_TASK *result; // rax
  FMOD::ChannelI *channeli; // [rsp+0h] [rbp-28h] BYREF
  FMOD::ChannelGroupI *channelgroupi; // [rsp+8h] [rbp-20h] BYREF

  if ( !this->mTasks )
    return 0;
  if ( FMOD::ChannelI::validate((FMOD::Channel *)currentHandle, &channeli, 0) == FMOD_RESULT::FMOD_OK_0 )
  {
    result = &this->mTasks[(__int64)channeli->mIndex];
    if ( result->state == OCCLUSION_STATE_UPDATED )
    {
      result->state = OCCLUSION_STATE_CHECKED;
      return result;
    }
    return 0;
  }
  if ( FMOD::ChannelGroupI::validate((FMOD::ChannelGroup *)currentHandle, &channelgroupi, 0) )
    return 0;
  result = &channelgroupi->mGeometryTask;
  if ( channelgroupi->mGeometryTask.state != OCCLUSION_STATE_UPDATED )
    return 0;
  channelgroupi->mGeometryTask.state = OCCLUSION_STATE_CHECKED;
  return result;
}


// Address: 0x22340f0 | Name: _ZN4FMOD11GeometryMgrC2Ev
void __fastcall FMOD::GeometryMgr::GeometryMgr(FMOD::GeometryMgr *const this)
{
  FMOD::OcclusionThread::OcclusionThread(&this->mOcclusionThread);
  this->mInitialized = 0;
  this->mSystem = 0;
  this->mMainOctree = 0;
  this->mRefCount = 0;
  this->mFirstUpdateItem = 0;
  this->mWorldSize = 1000.0;
  this->mMoved = 1;
}


// Address: 0x2234150 | Name: _ZN4FMOD11GeometryMgr4initEPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::GeometryMgr::init(FMOD::GeometryMgr *const this, FMOD::SystemI *system)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_OK_0;
  if ( !this->mInitialized )
  {
    this->mSystem = system;
    result = FMOD_OS_CriticalSection_Create(&this->mGeometryCrit, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::OcclusionThread::init(&this->mOcclusionThread, this);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        this->mInitialized = 1;
    }
  }
  return result;
}


// Address: 0x22341a0 | Name: _ZN4FMOD11GeometryMgr5closeEv
FMOD_RESULT_0 __fastcall FMOD::GeometryMgr::close(FMOD::GeometryMgr *const this)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_OK_0;
  if ( this->mInitialized )
  {
    result = FMOD::OcclusionThread::release(&this->mOcclusionThread);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD_OS_CriticalSection_Free(this->mGeometryCrit, 0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        this->mGeometryCrit = 0;
        this->mInitialized = 0;
      }
    }
  }
  return result;
}


// Address: 0x22341f0 | Name: _ZN4FMOD11GeometryMgr17acquireMainOctreeEv
FMOD_RESULT_0 __fastcall FMOD::GeometryMgr::acquireMainOctree(FMOD::GeometryMgr *const this)
{
  float v1; // xmm1_4
  FMOD_RESULT_0 result; // eax
  FMOD::Octree *v4; // rdi

  result = FMOD_RESULT::FMOD_OK_0;
  ++this->mRefCount;
  if ( !this->mMainOctree )
  {
    v4 = (FMOD::Octree *)FMOD::MemPool::alloc(
                           off_286F358->gSystemMemPool,
                           32,
                           "../../../core_api/src/fmod_geometry_mgr.cpp",
                           373,
                           0,
                           0);
    this->mMainOctree = v4;
    result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    if ( v4 )
    {
      FMOD::Octree::Octree(v4, v1);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2234270 | Name: _ZN4FMOD11GeometryMgr17releaseMainOctreeEv
void __fastcall FMOD::GeometryMgr::releaseMainOctree(FMOD::GeometryMgr *const this)
{
  FMOD::Octree *mMainOctree; // rdi

  if ( this->mRefCount - 1 <= 0 )
  {
    this->mRefCount = 0;
    mMainOctree = this->mMainOctree;
    if ( mMainOctree )
    {
      FMOD::Octree::~Octree(mMainOctree);
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        this->mMainOctree,
        "../../../core_api/src/fmod_geometry_mgr.cpp",
        398);
      this->mMainOctree = 0;
    }
  }
  else
  {
    --this->mRefCount;
  }
}


// Address: 0x22342f0 | Name: _ZN4FMOD11GeometryMgr12setWorldSizeEf
__int64 __fastcall FMOD::GeometryMgr::setWorldSize(FMOD::GeometryMgr *const this, float a2, float worldSize)
{
  FMOD::Octree *mMainOctree; // rdi

  if ( a2 == this->mWorldSize )
    return 0;
  this->mWorldSize = a2;
  mMainOctree = this->mMainOctree;
  if ( !mMainOctree )
    return 0;
  FMOD::Octree::setMaxSize(mMainOctree, worldSize);
  return 0;
}


// Address: 0x2234330 | Name: _ZN4FMOD11GeometryMgr8flushAllEv
FMOD_RESULT_0 __fastcall FMOD::GeometryMgr::flushAll(FMOD::GeometryMgr *const this)
{
  FMOD::GeometryI *mFirstUpdateItem; // rdi
  FMOD::GeometryI *mNextUpdateItem; // rbx

  mFirstUpdateItem = this->mFirstUpdateItem;
  this->mFirstUpdateItem = 0;
  if ( !mFirstUpdateItem )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    mNextUpdateItem = mFirstUpdateItem->mNextUpdateItem;
    mFirstUpdateItem->mToBeUpdated = 0;
    mFirstUpdateItem->mNextUpdateItem = 0;
    FMOD::GeometryI::flush(mFirstUpdateItem);
    if ( !mNextUpdateItem )
      break;
    mFirstUpdateItem = mNextUpdateItem;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2234390 | Name: _ZN4FMOD11GeometryMgr11lineTestAllEPK11FMOD_VECTORS3_PfS4_
FMOD_RESULT_0 __fastcall FMOD::GeometryMgr::lineTestAll(
        FMOD::GeometryMgr *const this,
        const FMOD_VECTOR *start,
        const FMOD_VECTOR *end,
        float *directOcclusion,
        float *reverbOcclusion)
{
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // r15
  __int64 v9; // rax
  FMOD::Octree *mMainOctree; // rdi
  FMOD::GeometryI::LineTestData lineTestData; // [rsp+10h] [rbp-68h] BYREF

  if ( this->mMainOctree )
  {
    mGeometryCrit = this->mGeometryCrit;
    FMOD_OS_CriticalSection_Enter(mGeometryCrit);
    FMOD::GeometryMgr::flushAll(this);
    v9 = *(_QWORD *)&start->x;
    mMainOctree = this->mMainOctree;
    lineTestData.directTransmission = 1.0;
    *(_QWORD *)&lineTestData.start.x = v9;
    *(float *)&v9 = start->z;
    lineTestData.reverbTransmission = 1.0;
    lineTestData.geometryI = 0;
    LODWORD(lineTestData.start.z) = v9;
    lineTestData.end = *end;
    FMOD::Octree::testLine(mMainOctree, FMOD::GeometryMgr::mainOctreeLineTestCallback, &lineTestData, start, end);
    if ( directOcclusion )
      *directOcclusion = 1.0 - lineTestData.directTransmission;
    if ( reverbOcclusion )
      *reverbOcclusion = 1.0 - lineTestData.reverbTransmission;
    FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  }
  else
  {
    if ( directOcclusion )
      *directOcclusion = 0.0;
    if ( reverbOcclusion )
      *reverbOcclusion = 0.0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22344a0 | Name: _ZN4FMOD15OcclusionThread10threadFuncEv
FMOD_RESULT_0 __fastcall FMOD::OcclusionThread::threadFunc(FMOD::OcclusionThread *const this)
{
  FMOD::OCCLUSION_TASK *v1; // rax
  FMOD::OCCLUSION_TASK *v2; // rbp
  FMOD::GeometryMgr *mGeometryMgr; // rax
  float v5; // xmm0_4
  FMOD::TimeStamp *p_mGeometryTimeStamp; // rdi
  float direct_o; // [rsp+8h] [rbp-40h] BYREF
  float reverb_o; // [rsp+Ch] [rbp-3Ch] BYREF
  FMOD_VECTOR reverbpos; // [rsp+10h] [rbp-38h] BYREF

  FMOD::TimeStamp::stampIn(&this->mGeometryMgr->mSystem->mGeometryTimeStamp);
  v1 = FMOD::OcclusionThread::dequeue(this);
  v2 = v1;
  if ( v1 && v1->state == OCCLUSION_STATE_READY )
  {
    FMOD::GeometryMgr::lineTestAll(
      this->mGeometryMgr,
      &this->mGeometryMgr->mSystem->mListener[0].mPosition,
      &v1->position,
      &v1->directocclusion,
      &v1->reverbocclusion);
    FMOD::SystemI::get3DListenerAttributes(this->mGeometryMgr->mSystem, 0, &reverbpos, 0, 0, 0);
    FMOD::GeometryMgr::lineTestAll(this->mGeometryMgr, &v2->position, &reverbpos, &direct_o, &reverb_o);
    mGeometryMgr = this->mGeometryMgr;
    v5 = 1.0 - reverb_o;
    v2->state = OCCLUSION_STATE_UPDATED;
    p_mGeometryTimeStamp = &mGeometryMgr->mSystem->mGeometryTimeStamp;
    v2->reverbgain = v5;
    FMOD::TimeStamp::stampOut(p_mGeometryTimeStamp, 95);
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    FMOD::TimeStamp::stampOut(&this->mGeometryMgr->mSystem->mGeometryTimeStamp, 95);
    FMOD_OS_Time_Sleep(0xAu);
    return FMOD_RESULT::FMOD_OK_0;
  }
}


