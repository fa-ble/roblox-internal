// Address: 0x21f71b0 | Name: _ZN4FMOD14ReverbPhysical4initEiPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::ReverbPhysical::init(
        FMOD::ReverbPhysical *const this,
        int instance,
        FMOD::SystemI *system)
{
  double v3; // xmm1_8
  FMOD_RESULT_0 result; // eax
  bool v5; // zf
  int v6; // ebp
  FMOD::SystemI *mSystem; // rax
  FMOD_SPEAKERMODE_0 mSpeakerMode; // ecx
  int v9; // edx
  int numdsps; // [rsp+0h] [rbp-38h] BYREF
  unsigned int handle; // [rsp+4h] [rbp-34h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *descriptionex; // [rsp+8h] [rbp-30h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (unsigned int)instance <= 3 )
  {
    LOBYTE(result) = 0;
    v5 = this->mDSP == 0;
    this->mSystem = system;
    this->mInstance = instance;
    if ( v5 )
    {
      result = FMOD::PluginFactory::getNumDSPs(system->mPluginFactory, &numdsps);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v6 = 0;
        if ( numdsps <= 0 )
          return FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
        while ( 1 )
        {
          mSystem = this->mSystem;
          descriptionex = 0;
          if ( FMOD::PluginFactory::getDSPHandle(mSystem->mPluginFactory, v6, &handle) == FMOD_RESULT::FMOD_OK_0
            && FMOD::PluginFactory::getDSP(this->mSystem->mPluginFactory, handle, &descriptionex) == FMOD_RESULT::FMOD_OK_0
            && *(&descriptionex->mDescription.mHandle + 1) == 19 )
          {
            break;
          }
          if ( numdsps <= ++v6 )
            return FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
        }
        result = FMOD::PluginFactory::createDSP(
                   this->mSystem->mPluginFactory,
                   &descriptionex->mDescription,
                   0,
                   &this->mDSP);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          mSpeakerMode = this->mSystem->mSpeakerMode;
          if ( mSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
          {
            v9 = 5;
            goto LABEL_19;
          }
          if ( mSpeakerMode <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
          {
            if ( mSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
              goto LABEL_18;
            v9 = 4;
            if ( mSpeakerMode > FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
              goto LABEL_19;
            LOBYTE(v9) = 1;
            if ( mSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0 )
              goto LABEL_19;
          }
          else
          {
            if ( mSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
            {
              v9 = 8;
              goto LABEL_19;
            }
            if ( mSpeakerMode < FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
            {
              v9 = 6;
              goto LABEL_19;
            }
            v9 = 12;
            if ( mSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
            {
LABEL_19:
              FMOD::DSPI::setChannelFormat(this->mDSP, 0, v9, mSpeakerMode);
              return FMOD::DSPI::setParameterFloat(this->mDSP, 12, (__m128i)0xC2A00000, v3);
            }
            if ( mSpeakerMode == 1000 )
            {
LABEL_18:
              v9 = 2;
              goto LABEL_19;
            }
          }
          v9 = 0;
          goto LABEL_19;
        }
      }
    }
  }
  return result;
}


// Address: 0x21f7320 | Name: _ZN4FMOD14ReverbPhysical7releaseEv
FMOD_RESULT_0 __fastcall FMOD::ReverbPhysical::release(FMOD::ReverbPhysical *const this)
{
  FMOD::DSPI *mDSP; // rdi
  FMOD_RESULT_0 result; // eax

  mDSP = this->mDSP;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( mDSP )
  {
    result = FMOD::DSPI::disconnectFrom(mDSP, 0, 0, FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = (*((unsigned int (__fastcall **)(FMOD::DSPI *))this->mDSP->_vptr_DSPI + 2))(this->mDSP);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        this->mDSP = 0;
    }
  }
  return result;
}


// Address: 0x21f7360 | Name: _ZN4FMOD14ReverbPhysical13setPropertiesEPK22FMOD_REVERB_PROPERTIES
FMOD_RESULT_0 __fastcall FMOD::ReverbPhysical::setProperties(
        FMOD::ReverbPhysical *const this,
        const FMOD_REVERB_PROPERTIES *prop)
{
  double v2; // xmm1_8
  FMOD::DSPI *mDSP; // rdi
  FMOD_RESULT_0 result; // eax

  mDSP = this->mDSP;
  if ( !mDSP )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD::DSPI::setActive(mDSP, 1, 1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD::DSPI::setParameterFloat(this->mDSP, 0, (__m128i)LODWORD(prop->DecayTime), v2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::DSPI::setParameterFloat(this->mDSP, 1, (__m128i)LODWORD(prop->EarlyDelay), v2);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD::DSPI::setParameterFloat(this->mDSP, 2, (__m128i)LODWORD(prop->LateDelay), v2);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = FMOD::DSPI::setParameterFloat(this->mDSP, 3, (__m128i)LODWORD(prop->HFReference), v2);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = FMOD::DSPI::setParameterFloat(this->mDSP, 4, (__m128i)LODWORD(prop->HFDecayRatio), v2);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              result = FMOD::DSPI::setParameterFloat(this->mDSP, 5, (__m128i)LODWORD(prop->Diffusion), v2);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                result = FMOD::DSPI::setParameterFloat(this->mDSP, 6, (__m128i)LODWORD(prop->Density), v2);
                if ( result == FMOD_RESULT::FMOD_OK_0 )
                {
                  result = FMOD::DSPI::setParameterFloat(this->mDSP, 7, (__m128i)LODWORD(prop->LowShelfFrequency), v2);
                  if ( result == FMOD_RESULT::FMOD_OK_0 )
                  {
                    result = FMOD::DSPI::setParameterFloat(this->mDSP, 8, (__m128i)LODWORD(prop->LowShelfGain), v2);
                    if ( result == FMOD_RESULT::FMOD_OK_0 )
                    {
                      result = FMOD::DSPI::setParameterFloat(this->mDSP, 9, (__m128i)LODWORD(prop->HighCut), v2);
                      if ( result == FMOD_RESULT::FMOD_OK_0 )
                      {
                        result = FMOD::DSPI::setParameterFloat(this->mDSP, 10, (__m128i)LODWORD(prop->EarlyLateMix), v2);
                        if ( result == FMOD_RESULT::FMOD_OK_0 )
                          return FMOD::DSPI::setParameterFloat(this->mDSP, 11, (__m128i)LODWORD(prop->WetLevel), v2);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21f74d0 | Name: _ZN4FMOD7ReverbIC2Ev
void __fastcall FMOD::ReverbI::ReverbI(FMOD::ReverbI *const this)
{
  this->mNode.mNodePrev = &this->mNode;
  this->mNode.mNodeNext = &this->mNode;
  this->mNode.mNodeData = 0;
  this->mActive = 1;
  this->mUserData = 0;
  this->mPosition.x = 0.0;
  this->mPosition.y = 0.0;
  this->mPosition.z = 0.0;
  this->mMinRadius = 0.0;
  this->mMaxRadius = 0.0;
  this->mMinMaxDistance = 0.0;
  this->mGain = 0.0;
}


// Address: 0x21f7520 | Name: _ZN4FMOD7ReverbI8validateEPNS_8Reverb3DEPPS0_
FMOD_RESULT_0 __fastcall FMOD::ReverbI::validate(FMOD::Reverb3D *reverb, FMOD::ReverbI **reverbi)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( reverbi )
  {
    LOBYTE(result) = 30;
    if ( reverb )
    {
      *reverbi = (FMOD::ReverbI *)reverb;
      LOBYTE(result) = 0;
    }
  }
  return result;
}


// Address: 0x21f7540 | Name: _ZN4FMOD7ReverbI7releaseEb
FMOD_RESULT_0 __fastcall FMOD::ReverbI::release(FMOD::ReverbI *const this, bool freethis)
{
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::SystemI *mSystem; // rdi

  mNodePrev = this->mNode.mNodePrev;
  mNodePrev->mNodeNext = this->mNode.mNodeNext;
  this->mNode.mNodeNext->mNodePrev = mNodePrev;
  this->mNode.mNodePrev = &this->mNode;
  this->mNode.mNodeNext = &this->mNode;
  mSystem = this->mSystem;
  if ( mSystem )
    FMOD::SystemI::update3DReverbs(mSystem);
  if ( freethis )
    FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_reverbi.cpp", 314);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f75b0 | Name: _ZN4FMOD7ReverbI15set3DAttributesEPK11FMOD_VECTORff
__int64 __fastcall FMOD::ReverbI::set3DAttributes(
        FMOD::ReverbI *const this,
        const FMOD_VECTOR *position,
        float a3,
        float mindistance,
        float maxdistance)
{
  if ( position )
    this->mPosition = *position;
  this->mMinRadius = a3;
  this->mMaxRadius = mindistance;
  if ( a3 > mindistance )
  {
    this->mMinRadius = mindistance;
    a3 = mindistance;
  }
  this->mMinMaxDistance = mindistance - a3;
  return 0;
}


// Address: 0x21f75f0 | Name: _ZN4FMOD7ReverbI15get3DAttributesEP11FMOD_VECTORPfS3_
FMOD_RESULT_0 __fastcall FMOD::ReverbI::get3DAttributes(
        FMOD::ReverbI *const this,
        FMOD_VECTOR *position,
        float *mindistance,
        float *maxdistance)
{
  if ( position )
    *position = this->mPosition;
  if ( mindistance )
    *mindistance = this->mMinRadius;
  if ( maxdistance )
    *maxdistance = this->mMaxRadius;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f7630 | Name: _ZN4FMOD7ReverbI13setPropertiesEPK22FMOD_REVERB_PROPERTIES
FMOD_RESULT_0 __fastcall FMOD::ReverbI::setProperties(
        FMOD::ReverbI *const this,
        const FMOD_REVERB_PROPERTIES *prop_source)
{
  __m128 v2; // xmm1
  float v3; // xmm0_4
  __m128 v4; // xmm0
  float v5; // xmm0_4
  __m128 v6; // xmm3
  float v7; // xmm1_4
  __m128 v8; // xmm1
  __m128 v9; // xmm3
  float v10; // xmm1_4
  __m128 v11; // xmm1
  __m128 v12; // xmm4
  float v13; // xmm3_4
  __m128 v14; // xmm3
  __m128 v15; // xmm4
  float v16; // xmm3_4
  __m128 v17; // xmm3
  __m128 v18; // xmm4
  float v19; // xmm3_4
  __m128 v20; // xmm3
  __m128 v21; // xmm4
  float v22; // xmm3_4
  __m128 v23; // xmm3
  __m128 v24; // xmm4
  float v25; // xmm3_4
  __m128 v26; // xmm3
  __m128 v27; // xmm4
  float v28; // xmm3_4
  __m128 v29; // xmm3
  __m128 v30; // xmm4
  float v31; // xmm3_4
  __m128 v32; // xmm3
  __m128 v33; // xmm3
  __m128 v34; // xmm0
  __m128 v35; // xmm2
  float v36; // xmm0_4
  __m128 v37; // xmm0

  v2.m128_i32[0] = LODWORD(prop_source->DecayTime);
  v3 = 100.0;
  if ( prop_source->DecayTime >= 100.0 )
  {
    v4 = _mm_cmpge_ss((__m128)0x469C4000u, v2);
    LODWORD(v3) = _mm_andnot_ps(v4, (__m128)0x469C4000u).m128_u32[0] | v2.m128_i32[0] & v4.m128_i32[0];
  }
  this->mProperties.DecayTime = v3;
  v5 = 0.0;
  v6.m128_i32[0] = LODWORD(prop_source->EarlyDelay);
  v7 = 0.0;
  if ( v6.m128_f32[0] >= 0.0 )
  {
    v8 = _mm_cmpge_ss((__m128)0x43960000u, v6);
    LODWORD(v7) = _mm_andnot_ps(v8, (__m128)0x43960000u).m128_u32[0] | v6.m128_i32[0] & v8.m128_i32[0];
  }
  v9.m128_i32[0] = LODWORD(prop_source->LateDelay);
  this->mProperties.EarlyDelay = v7;
  v10 = 0.0;
  if ( v9.m128_f32[0] >= 0.0 )
  {
    v11 = _mm_cmpge_ss((__m128)0x42C80000u, v9);
    LODWORD(v10) = _mm_andnot_ps(v11, (__m128)0x42C80000u).m128_u32[0] | v9.m128_i32[0] & v11.m128_i32[0];
  }
  this->mProperties.LateDelay = v10;
  v12.m128_i32[0] = LODWORD(prop_source->HFReference);
  v13 = 20.0;
  if ( v12.m128_f32[0] >= 20.0 )
  {
    v14 = _mm_cmpge_ss((__m128)0x469C4000u, v12);
    LODWORD(v13) = _mm_andnot_ps(v14, (__m128)0x469C4000u).m128_u32[0] | v12.m128_i32[0] & v14.m128_i32[0];
  }
  this->mProperties.HFReference = v13;
  v15.m128_i32[0] = LODWORD(prop_source->HFDecayRatio);
  v16 = 10.0;
  if ( v15.m128_f32[0] >= 10.0 )
  {
    v17 = _mm_cmpge_ss((__m128)0x42C80000u, v15);
    LODWORD(v16) = _mm_andnot_ps(v17, (__m128)0x42C80000u).m128_u32[0] | v15.m128_i32[0] & v17.m128_i32[0];
  }
  v18.m128_i32[0] = LODWORD(prop_source->Diffusion);
  this->mProperties.HFDecayRatio = v16;
  v19 = 0.0;
  if ( v18.m128_f32[0] >= 0.0 )
  {
    v20 = _mm_cmpge_ss((__m128)0x42C80000u, v18);
    LODWORD(v19) = _mm_andnot_ps(v20, (__m128)0x42C80000u).m128_u32[0] | v18.m128_i32[0] & v20.m128_i32[0];
  }
  v21.m128_i32[0] = LODWORD(prop_source->Density);
  this->mProperties.Diffusion = v19;
  v22 = 0.0;
  if ( v21.m128_f32[0] >= 0.0 )
  {
    v23 = _mm_cmpge_ss((__m128)0x42C80000u, v21);
    LODWORD(v22) = _mm_andnot_ps(v23, (__m128)0x42C80000u).m128_u32[0] | v21.m128_i32[0] & v23.m128_i32[0];
  }
  v24.m128_i32[0] = LODWORD(prop_source->LowShelfFrequency);
  this->mProperties.Density = v22;
  v25 = 20.0;
  if ( v24.m128_f32[0] >= 20.0 )
  {
    v26 = _mm_cmpge_ss((__m128)0x447A0000u, v24);
    LODWORD(v25) = _mm_andnot_ps(v26, (__m128)0x447A0000u).m128_u32[0] | v24.m128_i32[0] & v26.m128_i32[0];
  }
  this->mProperties.LowShelfFrequency = v25;
  v27.m128_i32[0] = LODWORD(prop_source->LowShelfGain);
  v28 = -36.0;
  if ( v27.m128_f32[0] >= -36.0 )
  {
    v29 = _mm_cmpge_ss((__m128)0x41400000u, v27);
    LODWORD(v28) = _mm_andnot_ps(v29, (__m128)0x41400000u).m128_u32[0] | v27.m128_i32[0] & v29.m128_i32[0];
  }
  v30.m128_i32[0] = LODWORD(prop_source->HighCut);
  this->mProperties.LowShelfGain = v28;
  v31 = 20.0;
  if ( v30.m128_f32[0] >= 20.0 )
  {
    v32 = _mm_cmpge_ss((__m128)0x469C4000u, v30);
    LODWORD(v31) = _mm_andnot_ps(v32, (__m128)0x469C4000u).m128_u32[0] | v30.m128_i32[0] & v32.m128_i32[0];
  }
  this->mProperties.HighCut = v31;
  v33.m128_i32[0] = LODWORD(prop_source->EarlyLateMix);
  if ( v33.m128_f32[0] >= 0.0 )
  {
    v34 = _mm_cmpge_ss((__m128)0x42C80000u, v33);
    LODWORD(v5) = _mm_andnot_ps(v34, (__m128)0x42C80000u).m128_u32[0] | v33.m128_i32[0] & v34.m128_i32[0];
  }
  this->mProperties.EarlyLateMix = v5;
  v35.m128_i32[0] = LODWORD(prop_source->WetLevel);
  v36 = -80.0;
  if ( v35.m128_f32[0] >= -80.0 )
  {
    v37 = _mm_cmpge_ss((__m128)0x41A00000u, v35);
    LODWORD(v36) = _mm_andnot_ps(v37, (__m128)0x41A00000u).m128_u32[0] | v35.m128_i32[0] & v37.m128_i32[0];
  }
  this->mProperties.WetLevel = v36;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f7850 | Name: _ZN4FMOD7ReverbI4initEPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::ReverbI::init(FMOD::ReverbI *const this, FMOD::SystemI *system)
{
  FMOD_RESULT_0 result; // eax
  FMOD_REVERB_PROPERTIES prop; // [rsp+0h] [rbp-38h] BYREF

  this->mSystem = system;
  prop.DecayTime = 1000.0;
  prop.EarlyDelay = 7.0;
  prop.LateDelay = 11.0;
  prop.HFReference = 5000.0;
  prop.HFDecayRatio = 100.0;
  prop.Diffusion = 100.0;
  prop.Density = 100.0;
  prop.LowShelfFrequency = 250.0;
  prop.LowShelfGain = 0.0;
  prop.HighCut = 20.0;
  prop.EarlyLateMix = 96.0;
  prop.WetLevel = -80.0;
  FMOD::ReverbI::release(this, 0);
  result = FMOD::ReverbI::setProperties(this, &prop);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    this->mPosition.z = 0.0;
    this->mPosition.y = 0.0;
    this->mPosition.x = 0.0;
    this->mMinRadius = 0.0;
    this->mMaxRadius = 0.0;
    this->mMinMaxDistance = 0.0;
    this->mGain = 0.0;
  }
  return result;
}


// Address: 0x21f7910 | Name: _ZN4FMOD7ReverbI13getPropertiesEP22FMOD_REVERB_PROPERTIES
FMOD_RESULT_0 __fastcall FMOD::ReverbI::getProperties(FMOD::ReverbI *const this, FMOD_REVERB_PROPERTIES *properties)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( properties )
  {
    *properties = this->mProperties;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21f7950 | Name: _ZN4FMOD7ReverbI9setActiveEb
FMOD_RESULT_0 __fastcall FMOD::ReverbI::setActive(FMOD::ReverbI *const this, bool active)
{
  this->mActive = active;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f7960 | Name: _ZN4FMOD7ReverbI9getActiveEPb
FMOD_RESULT_0 __fastcall FMOD::ReverbI::getActive(FMOD::ReverbI *const this, bool *active)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( active )
  {
    *active = this->mActive;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21f7980 | Name: _ZN4FMOD7ReverbI11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::ReverbI::setUserData(FMOD::ReverbI *const this, void *userdata)
{
  this->mUserData = userdata;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f7990 | Name: _ZN4FMOD7ReverbI11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::ReverbI::getUserData(FMOD::ReverbI *const this, void **userdata)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( userdata )
  {
    *userdata = this->mUserData;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21f79b0 | Name: _ZN4FMOD7ReverbI21calculateDistanceGainEP11FMOD_VECTORPfS3_
void __fastcall FMOD::ReverbI::calculateDistanceGain(
        FMOD::ReverbI *const this,
        FMOD_VECTOR *p,
        float *linear_gain,
        float *linear_coeff)
{
  float v4; // xmm1_4
  float mMinRadius; // xmm0_4
  float v6; // xmm2_4
  float v7; // xmm0_4
  float mMinMaxDistance; // xmm2_4
  float v9; // xmm1_4
  float *linear_gaina; // [rsp+10h] [rbp-18h]
  float *linear_coeffa; // [rsp+18h] [rbp-10h]

  v4 = fsqrt(
         (float)((float)((float)(p->x - this->mPosition.x) * (float)(p->x - this->mPosition.x))
               + (float)((float)(p->y - this->mPosition.y) * (float)(p->y - this->mPosition.y)))
       + (float)((float)(p->z - this->mPosition.z) * (float)(p->z - this->mPosition.z)));
  mMinRadius = this->mMinRadius;
  if ( mMinRadius >= v4 )
    goto LABEL_5;
  if ( v4 >= this->mMaxRadius )
  {
    v6 = 0.0;
    v7 = 0.0;
    goto LABEL_6;
  }
  mMinMaxDistance = this->mMinMaxDistance;
  if ( mMinMaxDistance > 0.0 )
  {
    linear_coeffa = linear_coeff;
    linear_gaina = linear_gain;
    v9 = (float)(v4 - mMinRadius) / mMinMaxDistance;
    v7 = powf(10.0, v9 * -3.0);
    v6 = 1.0 - v9;
    linear_gain = linear_gaina;
    linear_coeff = linear_coeffa;
  }
  else
  {
LABEL_5:
    v6 = 1.0;
    v7 = 1.0;
  }
LABEL_6:
  if ( linear_gain )
    *linear_gain = v7;
  if ( linear_coeff )
    *linear_coeff = v6;
}


// Address: 0x21f7ad0 | Name: _ZN4FMOD7ReverbI12sumRoomPropsEP22FMOD_REVERB_PROPERTIESS2_f
void __fastcall FMOD::ReverbI::sumRoomProps(
        FMOD_REVERB_PROPERTIES *accprops,
        FMOD_REVERB_PROPERTIES *addprops,
        float a3,
        float factor)
{
  if ( accprops )
  {
    if ( addprops )
      accprops->WetLevel = (float)(expf(0.2 * addprops->WetLevel) * a3) + accprops->WetLevel;
  }
}


// Address: 0x21f7b20 | Name: _ZN4FMOD7ReverbI8sumPropsEP22FMOD_REVERB_PROPERTIESS2_f
void __fastcall FMOD::ReverbI::sumProps(
        FMOD_REVERB_PROPERTIES *accprops,
        FMOD_REVERB_PROPERTIES *addprops,
        float a3,
        float factor)
{
  float HFReference; // xmm0_4
  float v6; // xmm0_4
  float LowShelfFrequency; // xmm0_4
  float v8; // xmm0_4
  float HighCut; // xmm0_4
  float v10; // xmm0_4

  if ( accprops && addprops )
  {
    accprops->DecayTime = (float)(addprops->DecayTime * a3) + accprops->DecayTime;
    accprops->EarlyDelay = (float)(addprops->EarlyDelay * a3) + accprops->EarlyDelay;
    accprops->LateDelay = (float)(addprops->LateDelay * a3) + accprops->LateDelay;
    HFReference = addprops->HFReference;
    if ( HFReference <= 0.0 )
      v6 = 0.0;
    else
      v6 = logf(HFReference) * a3;
    accprops->HFReference = v6 + accprops->HFReference;
    accprops->HFDecayRatio = (float)(addprops->HFDecayRatio * a3) + accprops->HFDecayRatio;
    accprops->Diffusion = (float)(addprops->Diffusion * a3) + accprops->Diffusion;
    accprops->Density = (float)(addprops->Density * a3) + accprops->Density;
    LowShelfFrequency = addprops->LowShelfFrequency;
    if ( LowShelfFrequency <= 0.0 )
      v8 = 0.0;
    else
      v8 = logf(LowShelfFrequency) * a3;
    accprops->LowShelfFrequency = v8 + accprops->LowShelfFrequency;
    accprops->LowShelfGain = (float)(expf(0.2 * addprops->LowShelfGain) * a3) + accprops->LowShelfGain;
    HighCut = addprops->HighCut;
    if ( HighCut <= 0.0 )
      v10 = 0.0;
    else
      v10 = logf(HighCut) * a3;
    accprops->HighCut = v10 + accprops->HighCut;
    accprops->EarlyLateMix = (float)(a3 * addprops->Diffusion) + accprops->EarlyLateMix;
    accprops->WetLevel = (float)(expf(0.2 * addprops->WetLevel) * a3) + accprops->WetLevel;
  }
}


// Address: 0x21f7cd0 | Name: _ZN4FMOD7ReverbI11factorPropsEP22FMOD_REVERB_PROPERTIESS2_f
void __fastcall FMOD::ReverbI::factorProps(
        FMOD_REVERB_PROPERTIES *dest,
        FMOD_REVERB_PROPERTIES *src,
        float a3,
        float factor)
{
  unsigned int v6; // esi
  FMOD_REVERB_PROPERTIES *v7; // rbx
  __int64 v8; // rcx
  _DWORD *v9; // rdi
  float LowShelfGain; // xmm0_4
  float v11; // xmm0_4
  float WetLevel; // xmm0_4
  float v13; // xmm0_4

  v6 = 48;
  v7 = dest;
  if ( ((unsigned __int8)dest & 1) != 0 )
  {
    dest = (FMOD_REVERB_PROPERTIES *)((char *)dest + 1);
    LOBYTE(v7->DecayTime) = 0;
    LOBYTE(v6) = 47;
    if ( (((_BYTE)v7 + 1) & 2) == 0 )
      goto LABEL_3;
  }
  else if ( ((unsigned __int8)dest & 2) == 0 )
  {
    goto LABEL_3;
  }
  dest = (FMOD_REVERB_PROPERTIES *)((char *)dest + 2);
  v6 -= 2;
  HIWORD(dest[-1].WetLevel) = 0;
LABEL_3:
  if ( ((unsigned __int8)dest & 4) != 0 )
  {
    dest->DecayTime = 0.0;
    v6 -= 4;
    dest = (FMOD_REVERB_PROPERTIES *)((char *)dest + 4);
  }
  v8 = v6 >> 3;
  memset(dest, 0, 8 * v8);
  v9 = (_DWORD *)(&dest->DecayTime + 2 * v8);
  if ( (v6 & 4) != 0 )
    *v9++ = 0;
  if ( (v6 & 2) != 0 )
  {
    v9 = (_DWORD *)((char *)v9 + 2);
    *((_WORD *)v9 - 1) = 0;
  }
  if ( (v6 & 1) != 0 )
    *(_BYTE *)v9 = 0;
  if ( v7 && src )
  {
    v7->DecayTime = src->DecayTime * a3;
    v7->EarlyDelay = src->EarlyDelay * a3;
    v7->LateDelay = src->LateDelay * a3;
    v7->HFReference = expf(a3 * src->HFReference);
    v7->HFDecayRatio = src->HFDecayRatio * a3;
    v7->Diffusion = src->Diffusion * a3;
    v7->Density = src->Density * a3;
    v7->LowShelfFrequency = expf(src->LowShelfFrequency * a3);
    LowShelfGain = src->LowShelfGain;
    if ( LowShelfGain <= 0.0 )
      v11 = -80.0;
    else
      v11 = logf(LowShelfGain * a3) * 5.0;
    v7->LowShelfGain = v11;
    v7->HighCut = expf(a3 * src->HighCut);
    v7->EarlyLateMix = src->EarlyLateMix * a3;
    WetLevel = src->WetLevel;
    if ( WetLevel <= 0.0 )
      v13 = -80.0;
    else
      v13 = logf(WetLevel * a3) * 5.0;
    v7->WetLevel = v13;
  }
}


