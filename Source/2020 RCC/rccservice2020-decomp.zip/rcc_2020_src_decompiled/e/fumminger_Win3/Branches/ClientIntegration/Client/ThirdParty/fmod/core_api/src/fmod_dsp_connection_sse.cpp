// Address: 0x221ab10 | Name: FMOD_DSP_Connection_MixMonoToMono_SSE
void __fastcall FMOD_DSP_Connection_MixMonoToMono_SSE(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float v7; // xmm1_4
  unsigned int v8; // r9d
  __m128 v9; // xmm2
  unsigned int v10; // r8d
  float *v11; // rcx
  float *v12; // rax
  __m128 v13; // xmm0
  __int64 v14; // rax
  unsigned int i; // edx
  float v16; // xmm0_4
  unsigned int v17; // r8d
  float *v18; // rax
  float *v19; // rcx
  __m128 v20; // xmm0
  __int64 v21; // rax
  unsigned int j; // edx
  float v23; // xmm0_4

  v7 = *mixmatrix;
  v8 = length >> 2;
  v9 = _mm_shuffle_ps((__m128)*(unsigned int *)mixmatrix, (__m128)*(unsigned int *)mixmatrix, 0);
  if ( writedontmix )
  {
    if ( v8 )
    {
      v10 = length >> 2;
      v11 = outbuffer;
      v12 = inbuffer;
      do
      {
        v13 = *(__m128 *)v12;
        v11 += 4;
        v12 += 4;
        *((__m128 *)v11 - 1) = _mm_mul_ps(v13, v9);
        --v10;
      }
      while ( v10 );
      v14 = 16 * (v8 - 1 + 1LL);
      inbuffer = (float *)((char *)inbuffer + v14);
      outbuffer = (float *)((char *)outbuffer + v14);
    }
    for ( i = length & 3; i; --i )
    {
      v16 = *inbuffer;
      ++outbuffer;
      ++inbuffer;
      *(outbuffer - 1) = v16 * v7;
    }
  }
  else
  {
    if ( v8 )
    {
      v17 = length >> 2;
      v18 = outbuffer;
      v19 = inbuffer;
      do
      {
        v20 = *(__m128 *)v19;
        v18 += 4;
        v19 += 4;
        *((__m128 *)v18 - 1) = _mm_add_ps(_mm_mul_ps(v20, v9), *(__m128 *)(v18 - 4));
        --v17;
      }
      while ( v17 );
      v21 = 16 * (v8 - 1 + 1LL);
      inbuffer = (float *)((char *)inbuffer + v21);
      outbuffer = (float *)((char *)outbuffer + v21);
    }
    for ( j = length & 3; j; --j )
    {
      v23 = *inbuffer;
      ++outbuffer;
      ++inbuffer;
      *(outbuffer - 1) = (float)(v23 * v7) + *(outbuffer - 1);
    }
  }
}


// Address: 0x221ac10 | Name: FMOD_DSP_Connection_MixMonoToStereo_SSE
void __fastcall FMOD_DSP_Connection_MixMonoToStereo_SSE(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float v7; // xmm3_4
  __m128 v8; // xmm4
  unsigned int v9; // r9d
  __m128 v10; // xmm2
  __m128 v11; // xmm2
  unsigned int v12; // r8d
  float *v13; // rax
  float *v14; // rcx
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  __m128 v17; // xmm0
  __int64 v18; // rcx
  unsigned int j; // edx
  float v20; // xmm0_4
  float v21; // xmm1_4
  unsigned int v22; // r8d
  float *v23; // rax
  float *v24; // rcx
  __m128 v25; // xmm0
  __int64 v26; // rcx
  unsigned int i; // edx
  float v28; // xmm0_4

  v7 = *mixmatrix;
  v8 = (__m128)*((unsigned int *)mixmatrix + 32);
  v9 = length >> 2;
  v10 = _mm_unpacklo_ps((__m128)*(unsigned int *)mixmatrix, v8);
  v11 = _mm_movelh_ps(v10, v10);
  if ( writedontmix )
  {
    if ( v9 )
    {
      v22 = length >> 2;
      v23 = outbuffer;
      v24 = inbuffer;
      do
      {
        v25 = *(__m128 *)v24;
        v23 += 8;
        v24 += 4;
        *((__m128 *)v23 - 2) = _mm_mul_ps(_mm_unpacklo_ps(v25, v25), v11);
        *((__m128 *)v23 - 1) = _mm_mul_ps(_mm_unpackhi_ps(v25, v25), v11);
        --v22;
      }
      while ( v22 );
      v26 = v9 - 1 + 1LL;
      outbuffer += 8 * v26;
      inbuffer += 4 * v26;
    }
    for ( i = length & 3; i; --i )
    {
      v28 = *inbuffer;
      outbuffer += 2;
      ++inbuffer;
      *(outbuffer - 1) = v28 * v8.m128_f32[0];
      *(outbuffer - 2) = v28 * v7;
    }
  }
  else
  {
    v12 = length >> 2;
    v13 = outbuffer;
    v14 = inbuffer;
    if ( v9 )
    {
      do
      {
        v15 = *(__m128 *)v14;
        v13 += 8;
        v14 += 4;
        v16 = _mm_unpacklo_ps(v15, v15);
        v17 = _mm_add_ps(_mm_mul_ps(_mm_unpackhi_ps(v15, v15), v11), *(__m128 *)(v13 - 4));
        *((__m128 *)v13 - 2) = _mm_add_ps(_mm_mul_ps(v16, v11), *(__m128 *)(v13 - 8));
        *((__m128 *)v13 - 1) = v17;
        --v12;
      }
      while ( v12 );
      v18 = v9 - 1 + 1LL;
      outbuffer += 8 * v18;
      inbuffer += 4 * v18;
    }
    for ( j = length & 3; j; --j )
    {
      v20 = *inbuffer;
      outbuffer += 2;
      ++inbuffer;
      v21 = (float)(v20 * v7) + *(outbuffer - 2);
      *(outbuffer - 1) = (float)(v20 * v8.m128_f32[0]) + *(outbuffer - 1);
      *(outbuffer - 2) = v21;
    }
  }
}


// Address: 0x221ad70 | Name: FMOD_DSP_Connection_MixStereoToStereo_SSE
void __fastcall FMOD_DSP_Connection_MixStereoToStereo_SSE(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float v7; // xmm3_4
  __m128 v8; // xmm4
  unsigned int v9; // r9d
  __m128 v10; // xmm0
  __m128 v11; // xmm0
  unsigned int v12; // r8d
  float *v13; // rax
  float *v14; // rcx
  __m128 v15; // xmm2
  __m128 v16; // xmm1
  __int64 v17; // rax
  unsigned int j; // edx
  float v19; // xmm0_4
  unsigned int v20; // r8d
  float *v21; // rcx
  float *v22; // rax
  __m128 v23; // xmm2
  __m128 v24; // xmm1
  __int64 v25; // rax
  unsigned int i; // edx
  float v27; // xmm0_4

  v7 = *mixmatrix;
  v8 = (__m128)*((unsigned int *)mixmatrix + 33);
  v9 = length >> 2;
  v10 = _mm_unpacklo_ps((__m128)*(unsigned int *)mixmatrix, v8);
  v11 = _mm_movelh_ps(v10, v10);
  if ( writedontmix )
  {
    if ( v9 )
    {
      v20 = length >> 2;
      v21 = outbuffer;
      v22 = inbuffer;
      do
      {
        v23 = *(__m128 *)v22;
        v21 += 8;
        v22 += 8;
        v24 = _mm_mul_ps(*(__m128 *)(v22 - 4), v11);
        *((__m128 *)v21 - 2) = _mm_mul_ps(v23, v11);
        *((__m128 *)v21 - 1) = v24;
        --v20;
      }
      while ( v20 );
      v25 = 32 * (v9 - 1 + 1LL);
      inbuffer = (float *)((char *)inbuffer + v25);
      outbuffer = (float *)((char *)outbuffer + v25);
    }
    for ( i = length & 3; i; --i )
    {
      v27 = *inbuffer;
      outbuffer += 2;
      inbuffer += 2;
      *(outbuffer - 2) = v27 * v7;
      *(outbuffer - 1) = *(inbuffer - 1) * v8.m128_f32[0];
    }
  }
  else
  {
    v12 = length >> 2;
    v13 = outbuffer;
    v14 = inbuffer;
    if ( v9 )
    {
      do
      {
        v15 = *(__m128 *)v14;
        v13 += 8;
        v14 += 8;
        v16 = _mm_add_ps(_mm_mul_ps(*(__m128 *)(v14 - 4), v11), *(__m128 *)(v13 - 4));
        *((__m128 *)v13 - 2) = _mm_add_ps(_mm_mul_ps(v15, v11), *(__m128 *)(v13 - 8));
        *((__m128 *)v13 - 1) = v16;
        --v12;
      }
      while ( v12 );
      v17 = 32 * (v9 - 1 + 1LL);
      inbuffer = (float *)((char *)inbuffer + v17);
      outbuffer = (float *)((char *)outbuffer + v17);
    }
    for ( j = length & 3; j; --j )
    {
      v19 = *inbuffer;
      outbuffer += 2;
      inbuffer += 2;
      *(outbuffer - 2) = (float)(v19 * v7) + *(outbuffer - 2);
      *(outbuffer - 1) = (float)(*(inbuffer - 1) * v8.m128_f32[0]) + *(outbuffer - 1);
    }
  }
}


// Address: 0x221aeb0 | Name: FMOD_DSP_Connection_MixMonoTo51_SSE
void __fastcall FMOD_DSP_Connection_MixMonoTo51_SSE(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  unsigned int v7; // eax
  __m128 v8; // xmm8
  __m128 v9; // xmm7
  __m128 v10; // xmm2
  __m128 v11; // xmm1
  __m128 v12; // xmm8
  __m128 v13; // xmm2
  __int64 v14; // r9
  float *v15; // rcx
  float *v16; // rax
  __m128 v17; // xmm0
  __m128 v18; // xmm6
  __m128 v19; // xmm5
  __m128 v20; // xmm4
  __m128 v21; // xmm3
  __int64 v22; // r9
  unsigned int v23; // edx
  float *v24; // rax
  __m128 v25; // xmm4
  __m128 v26; // xmm5
  __m128 v27; // xmm3
  __int64 v28; // r9
  float *v29; // rcx
  float *v30; // rax
  __m128 v31; // xmm0
  __int64 v32; // r9
  unsigned int v33; // edx
  float *v34; // rax
  __m128 v35; // xmm0
  __m128 v36; // xmm3

  v7 = length >> 2;
  v8 = _mm_unpacklo_ps((__m128)*((unsigned int *)mixmatrix + 64), (__m128)*((unsigned int *)mixmatrix + 96));
  v9 = _mm_unpacklo_ps((__m128)*((unsigned int *)mixmatrix + 128), (__m128)*((unsigned int *)mixmatrix + 160));
  v10 = _mm_unpacklo_ps((__m128)*(unsigned int *)mixmatrix, (__m128)*((unsigned int *)mixmatrix + 32));
  v11 = _mm_movelh_ps(v10, v8);
  v12 = _mm_movelh_ps(v8, v9);
  v13 = _mm_movelh_ps(v9, v10);
  if ( writedontmix )
  {
    if ( v7 )
    {
      v28 = v7 - 1;
      v29 = inbuffer;
      v30 = outbuffer;
      do
      {
        v31 = *(__m128 *)v29;
        v30 += 24;
        v29 += 4;
        *((__m128 *)v30 - 6) = _mm_mul_ps(_mm_shuffle_ps(v31, v31, 0), v11);
        *((__m128 *)v30 - 5) = _mm_mul_ps(_mm_shuffle_ps(v31, v31, 80), v13);
        *((__m128 *)v30 - 4) = _mm_mul_ps(_mm_shuffle_ps(v31, v31, 85), v12);
        *((__m128 *)v30 - 3) = _mm_mul_ps(_mm_shuffle_ps(v31, v31, 170), v11);
        *((__m128 *)v30 - 2) = _mm_mul_ps(_mm_shuffle_ps(v31, v31, 250), v13);
        *((__m128 *)v30 - 1) = _mm_mul_ps(_mm_shuffle_ps(v31, v31, 255), v12);
      }
      while ( v30 != &outbuffer[24 * v28 + 24] );
      v32 = v28 + 1;
      inbuffer += 4 * v32;
      outbuffer += 24 * v32;
    }
    v33 = length & 3;
    if ( v33 )
    {
      v34 = &outbuffer[6 * v33];
      do
      {
        v35 = (__m128)*(unsigned int *)inbuffer;
        outbuffer += 6;
        ++inbuffer;
        v36 = _mm_shuffle_ps(v35, v35, 0);
        _mm_storel_ps((double *)outbuffer - 1, _mm_mul_ps(v36, v13));
        *(__m128 *)(outbuffer - 6) = _mm_mul_ps(v36, v11);
      }
      while ( outbuffer != v34 );
    }
  }
  else
  {
    if ( v7 )
    {
      v14 = v7 - 1;
      v15 = inbuffer;
      v16 = outbuffer;
      do
      {
        v17 = *(__m128 *)v15;
        v16 += 24;
        v15 += 4;
        v18 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v17, v17, 80), v13), *(__m128 *)(v16 - 20));
        v19 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v17, v17, 85), v12), *(__m128 *)(v16 - 16));
        v20 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v17, v17, 170), v11), *(__m128 *)(v16 - 12));
        *((__m128 *)v16 - 6) = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v17, v17, 0), v11), *(__m128 *)(v16 - 24));
        v21 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v17, v17, 250), v13), *(__m128 *)(v16 - 8));
        *((__m128 *)v16 - 5) = v18;
        *((__m128 *)v16 - 4) = v19;
        *((__m128 *)v16 - 3) = v20;
        *((__m128 *)v16 - 2) = v21;
        *((__m128 *)v16 - 1) = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v17, v17, 255), v12), *(__m128 *)(v16 - 4));
      }
      while ( v16 != &outbuffer[24 * v14 + 24] );
      v22 = v14 + 1;
      inbuffer += 4 * v22;
      outbuffer += 24 * v22;
    }
    v23 = length & 3;
    if ( v23 )
    {
      v24 = &outbuffer[6 * v23];
      do
      {
        v25 = (__m128)*(unsigned int *)inbuffer;
        outbuffer += 6;
        ++inbuffer;
        v26 = _mm_shuffle_ps(v25, v25, 0);
        v27 = _mm_add_ps(*(__m128 *)(outbuffer - 6), _mm_mul_ps(v26, v11));
        _mm_storel_ps((double *)outbuffer - 1, _mm_add_ps(*(__m128 *)(outbuffer - 2), _mm_mul_ps(v26, v13)));
        *(__m128 *)(outbuffer - 6) = v27;
      }
      while ( outbuffer != v24 );
    }
  }
}


// Address: 0x221b110 | Name: FMOD_DSP_Connection_Mix51To51_Diagonal_SSE
void __fastcall FMOD_DSP_Connection_Mix51To51_Diagonal_SSE(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  unsigned int v7; // eax
  __m128 v8; // xmm2
  __m128 v9; // xmm7
  __m128 v10; // xmm1
  __m128 v11; // xmm0
  __m128 v12; // xmm2
  __m128 v13; // xmm1
  __int64 v14; // r9
  float *v15; // rcx
  float *v16; // rax
  __m128 v17; // xmm8
  __m128 v18; // xmm4
  __m128 v19; // xmm7
  __m128 v20; // xmm3
  __m128 v21; // xmm6
  __m128 v22; // xmm5
  __m128 v23; // xmm4
  __int64 v24; // rax
  unsigned int v25; // edx
  float *v26; // rax
  __m128 v27; // xmm5
  __m128 v28; // xmm2
  __int64 v29; // r9
  float *v30; // rcx
  float *v31; // rax
  __m128 v32; // xmm8
  __m128 v33; // xmm7
  __m128 v34; // xmm6
  __m128 v35; // xmm5
  __m128 v36; // xmm3
  __m128 v37; // xmm4
  __int64 v38; // rax
  unsigned int v39; // edx
  float *v40; // rax
  __m128 v41; // xmm3
  __m128 v42; // xmm2

  v7 = length >> 2;
  v8 = _mm_unpacklo_ps((__m128)*((unsigned int *)mixmatrix + 66), (__m128)*((unsigned int *)mixmatrix + 99));
  v9 = _mm_unpacklo_ps((__m128)*((unsigned int *)mixmatrix + 132), (__m128)*((unsigned int *)mixmatrix + 165));
  v10 = _mm_unpacklo_ps((__m128)*(unsigned int *)mixmatrix, (__m128)*((unsigned int *)mixmatrix + 33));
  v11 = _mm_movelh_ps(v10, v8);
  v12 = _mm_movelh_ps(v8, v9);
  v13 = _mm_movelh_ps(v9, v10);
  if ( writedontmix )
  {
    if ( v7 )
    {
      v29 = v7 - 1;
      v30 = outbuffer;
      v31 = inbuffer;
      do
      {
        v32 = *(__m128 *)v31;
        v31 += 24;
        v30 += 24;
        v33 = _mm_mul_ps(*(__m128 *)(v31 - 20), v13);
        v34 = _mm_mul_ps(*(__m128 *)(v31 - 16), v12);
        v35 = _mm_mul_ps(*(__m128 *)(v31 - 12), v11);
        v36 = *(__m128 *)(v31 - 4);
        v37 = _mm_mul_ps(*(__m128 *)(v31 - 8), v13);
        *((__m128 *)v30 - 6) = _mm_mul_ps(v32, v11);
        *((__m128 *)v30 - 5) = v33;
        *((__m128 *)v30 - 4) = v34;
        *((__m128 *)v30 - 3) = v35;
        *((__m128 *)v30 - 2) = v37;
        *((__m128 *)v30 - 1) = _mm_mul_ps(v36, v12);
      }
      while ( v31 != &inbuffer[24 * v29 + 24] );
      v38 = 32 * (3 * v29 + 3);
      outbuffer = (float *)((char *)outbuffer + v38);
      inbuffer = (float *)((char *)inbuffer + v38);
    }
    v39 = length & 3;
    if ( v39 )
    {
      v40 = &inbuffer[6 * v39];
      do
      {
        v41 = *(__m128 *)inbuffer;
        inbuffer += 6;
        outbuffer += 6;
        v42 = _mm_mul_ps(*(__m128 *)(inbuffer - 2), v13);
        *(__m128 *)(outbuffer - 6) = _mm_mul_ps(v41, v11);
        _mm_storel_ps((double *)outbuffer - 1, v42);
      }
      while ( inbuffer != v40 );
    }
  }
  else
  {
    if ( v7 )
    {
      v14 = v7 - 1;
      v15 = inbuffer;
      v16 = outbuffer;
      do
      {
        v17 = *(__m128 *)v15;
        v15 += 24;
        v16 += 24;
        v18 = _mm_mul_ps(*(__m128 *)(v15 - 8), v13);
        v19 = _mm_add_ps(_mm_mul_ps(*(__m128 *)(v15 - 20), v13), *(__m128 *)(v16 - 20));
        v20 = _mm_mul_ps(*(__m128 *)(v15 - 4), v12);
        v21 = _mm_add_ps(_mm_mul_ps(*(__m128 *)(v15 - 16), v12), *(__m128 *)(v16 - 16));
        v22 = _mm_add_ps(_mm_mul_ps(*(__m128 *)(v15 - 12), v11), *(__m128 *)(v16 - 12));
        *((__m128 *)v16 - 6) = _mm_add_ps(_mm_mul_ps(v17, v11), *(__m128 *)(v16 - 24));
        v23 = _mm_add_ps(v18, *(__m128 *)(v16 - 8));
        *((__m128 *)v16 - 5) = v19;
        *((__m128 *)v16 - 4) = v21;
        *((__m128 *)v16 - 3) = v22;
        *((__m128 *)v16 - 2) = v23;
        *((__m128 *)v16 - 1) = _mm_add_ps(v20, *(__m128 *)(v16 - 4));
      }
      while ( v15 != &inbuffer[24 * v14 + 24] );
      v24 = 32 * (3 * v14 + 3);
      outbuffer = (float *)((char *)outbuffer + v24);
      inbuffer = (float *)((char *)inbuffer + v24);
    }
    v25 = length & 3;
    if ( v25 )
    {
      v26 = &inbuffer[6 * v25];
      do
      {
        v27 = *(__m128 *)inbuffer;
        inbuffer += 6;
        outbuffer += 6;
        v28 = _mm_add_ps(*(__m128 *)(outbuffer - 2), _mm_mul_ps(*(__m128 *)(inbuffer - 2), v13));
        *(__m128 *)(outbuffer - 6) = _mm_add_ps(*(__m128 *)(outbuffer - 6), _mm_mul_ps(v27, v11));
        _mm_storel_ps((double *)outbuffer - 1, v28);
      }
      while ( inbuffer != v26 );
    }
  }
}


