// Address: 0x21cdf20 | Name: _ZN4FMOD17ProfileRemoteFile18getAsyncReadBufferEPKNS_19ProfilePacketHeaderEPPc
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::getAsyncReadBuffer(
        FMOD::ProfileRemoteFile *const this,
        const FMOD::ProfilePacketHeader *packet,
        char **buffer)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( packet->size <= (unsigned int)&stru_10020 )
  {
    *buffer = this->mPacketReadBuffer;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21cdf40 | Name: _ZN4FMOD17ProfileRemoteFile15clientConnectedEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::clientConnected(
        FMOD::ProfileRemoteFile *const this,
        FMOD::ProfileClient *client)
{
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ProfileInterface *, __int64, __int64, _QWORD, FMOD::ProfileClient *))this->mProfile->_vptr_ProfileInterface
          + 2))(
           this->mProfile,
           10,
           255,
           0,
           client);
}


// Address: 0x21cdf60 | Name: _ZN4FMOD17ProfileRemoteFile18clientDisconnectedEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::clientDisconnected(
        FMOD::ProfileRemoteFile *const this,
        FMOD::ProfileClient *client)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cdf90 | Name: _ZN4FMOD17ProfileRemoteFile30clientStartRequestingDataAsyncEPNS_13ProfileClientEhh
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::clientStartRequestingDataAsync(
        FMOD::ProfileRemoteFile *const this,
        FMOD::ProfileClient *client,
        unsigned __int8 type,
        unsigned __int8 subtype)
{
  FMOD_OS_CRITICALSECTION *mCallerLock; // rbp

  mCallerLock = this->mCallerLock;
  FMOD_OS_CriticalSection_Enter(mCallerLock);
  ++this->mClientConnectedCount;
  FMOD_OS_CriticalSection_Leave(mCallerLock);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ce080 | Name: _ZN4FMOD17ProfileRemoteFile7releaseEv
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::release(FMOD::ProfileRemoteFile *const this)
{
  int mSize; // edx
  unsigned int *mData; // rax
  int v4; // r13d
  signed int v5; // ecx
  unsigned int *v6; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v7; // rdi
  __int64 v8; // r12
  FMOD_OS_SEMAPHORE **v9; // r14
  FMOD_RESULT_0 result; // eax
  int v11; // eax
  int v12; // esi
  unsigned int *v13; // r8
  __int64 v14; // r9
  __int64 v15; // rdx
  int v16; // eax
  unsigned int *v17; // rdx
  int v18; // r13d
  signed int next; // ecx
  unsigned int *v20; // rdx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v21; // rdi
  __int64 v22; // rbp
  FMOD::ProfileFileEntryRemote *value; // r14
  FMOD_OS_FILE *mFileHandle; // rdi
  int v25; // eax
  int v26; // esi
  unsigned int *v27; // r8
  __int64 v28; // r9
  __int64 v29; // rdx
  char *mFileReadBuffer; // rsi

  FMOD_OS_CriticalSection_Free(this->mCallerLock, 0);
  mSize = this->mLocalFiles.mBuckets.mSize;
  if ( !mSize )
  {
LABEL_14:
    v16 = this->mRemoteFiles.mBuckets.mSize;
    if ( !v16 )
      goto LABEL_31;
    goto LABEL_15;
  }
  mData = this->mLocalFiles.mBuckets.mData;
  v4 = 0;
  v5 = *mData;
  v6 = mData + 1;
  if ( v5 == -1 )
  {
    while ( ++v4 != mSize )
    {
      v5 = *v6++;
      if ( v5 != -1 )
        goto LABEL_4;
    }
    v16 = this->mRemoteFiles.mBuckets.mSize;
    if ( !v16 )
      goto LABEL_31;
LABEL_15:
    v17 = this->mRemoteFiles.mBuckets.mData;
    v18 = 0;
    next = *v17;
    v20 = v17 + 1;
    if ( next != -1 )
    {
      v18 = 0;
LABEL_17:
      v21 = this->mRemoteFiles.mNodes.mData;
      while ( 1 )
      {
        v22 = next;
        value = v21[v22].value;
        mFileHandle = value->mFileHandle;
        if ( mFileHandle )
        {
          result = FMOD_OS_File_Close(mFileHandle);
          if ( result )
            return result;
        }
        FMOD::MemPool::free(
          off_286F358->gSystemMemPool,
          value,
          "../../../core_api/src/fmod_profile_remotefile.cpp",
          106);
        v21 = this->mRemoteFiles.mNodes.mData;
        next = v21[v22].next;
        if ( next == -1 )
        {
          v25 = v18 + 1;
          v26 = this->mRemoteFiles.mBuckets.mSize;
          if ( v18 == -1 )
            v25 = 0;
          if ( v25 == v26 )
            goto LABEL_31;
          v27 = this->mRemoteFiles.mBuckets.mData;
          v28 = v25;
          next = v27[v28];
          v29 = (__int64)&v27[v28 + 1];
          if ( next == -1 )
          {
            while ( v26 != ++v25 )
            {
              v29 += 4;
              next = *(_DWORD *)(v29 - 4);
              if ( next != -1 )
                goto LABEL_27;
            }
            goto LABEL_31;
          }
LABEL_27:
          v18 = v25;
        }
      }
    }
    while ( ++v18 != v16 )
    {
      next = *v20++;
      if ( next != -1 )
        goto LABEL_17;
    }
LABEL_31:
    mFileReadBuffer = this->mFileReadBuffer;
    if ( mFileReadBuffer )
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        mFileReadBuffer,
        "../../../core_api/src/fmod_profile_remotefile.cpp",
        183);
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      this->mPacketReadBuffer,
      "../../../core_api/src/fmod_profile_remotefile.cpp",
      186);
    (*((void (__fastcall **)(FMOD::ProfileRemoteFile *const))this->_vptr_ProfileModule + 12))(this);
    FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_profile_remotefile.cpp", 188);
    return FMOD_RESULT::FMOD_OK_0;
  }
  v4 = 0;
LABEL_4:
  v7 = this->mLocalFiles.mNodes.mData;
  while ( 1 )
  {
    v8 = v5;
    v9 = (FMOD_OS_SEMAPHORE **)v7[v8].value;
    result = FMOD_OS_Semaphore_Free(v9[1]);
    if ( result )
      return result;
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v9, "../../../core_api/src/fmod_profile_remotefile.cpp", 64);
    v7 = this->mLocalFiles.mNodes.mData;
    v5 = v7[v8].next;
    if ( v5 == -1 )
    {
      v11 = v4 + 1;
      v12 = this->mLocalFiles.mBuckets.mSize;
      if ( v4 == -1 )
        v11 = 0;
      if ( v11 == v12 )
        goto LABEL_14;
      v13 = this->mLocalFiles.mBuckets.mData;
      v14 = v11;
      v5 = v13[v14];
      v15 = (__int64)&v13[v14 + 1];
      if ( v5 == -1 )
      {
        while ( ++v11 != v12 )
        {
          v15 += 4;
          v5 = *(_DWORD *)(v15 - 4);
          if ( v5 != -1 )
            goto LABEL_38;
        }
        goto LABEL_14;
      }
LABEL_38:
      v4 = v11;
    }
  }
}


// Address: 0x21ce330 | Name: _ZN4FMOD17ProfileRemoteFile29clientStopRequestingDataAsyncEPNS_13ProfileClientEhh
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::clientStopRequestingDataAsync(
        FMOD::ProfileRemoteFile *const this,
        FMOD::ProfileClient *client,
        unsigned __int8 type,
        unsigned __int8 subtype)
{
  FMOD_RESULT_0 v4; // r12d
  FMOD_OS_CRITICALSECTION *mCallerLock; // rbx
  bool v7; // zf
  int mSize; // edx
  unsigned int *mData; // rax
  int v11; // r14d
  signed int next; // ecx
  unsigned int *v13; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v14; // rdi
  __int64 v15; // r13
  FMOD::ProfileFileEntryLocal *value; // rax
  FMOD_OS_SEMAPHORE *mSema; // rdi
  int v18; // eax
  int v19; // esi
  unsigned int *v20; // r8
  __int64 v21; // r9
  __int64 v22; // rdx
  int v23; // eax
  unsigned int *v24; // rdx
  int v25; // r14d
  signed int v26; // ecx
  unsigned int *v27; // rdx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v28; // rdi
  __int64 v29; // r13
  FMOD::ProfileFileEntryRemote *v30; // r15
  FMOD_OS_FILE *mFileHandle; // rdi
  FMOD_RESULT_0 v32; // eax
  int v33; // eax
  int v34; // esi
  unsigned int *v35; // r8
  __int64 v36; // r9
  __int64 v37; // rdx
  bool v38; // cc
  int v39; // eax
  int mCapacity; // eax
  unsigned int *v41; // rsi

  v4 = FMOD_RESULT::FMOD_OK_0;
  mCallerLock = this->mCallerLock;
  FMOD_OS_CriticalSection_Enter(mCallerLock);
  v7 = this->mClientConnectedCount-- == 1;
  if ( v7 )
  {
    mSize = this->mLocalFiles.mBuckets.mSize;
    if ( mSize )
    {
      mData = this->mLocalFiles.mBuckets.mData;
      v11 = 0;
      next = *mData;
      v13 = mData + 1;
      if ( next == -1 )
      {
        while ( mSize != ++v11 )
        {
          next = *v13++;
          if ( next != -1 )
            goto LABEL_6;
        }
      }
      else
      {
        v11 = 0;
LABEL_6:
        v14 = this->mLocalFiles.mNodes.mData;
        while ( 1 )
        {
          do
          {
            v15 = next;
            value = v14[v15].value;
            mSema = value->mSema;
            value->mFileResult = FMOD::FMOD_PROFILE_REMOTEFILE_RESULT::FMOD_PROFILE_REMOTEFILE_RESULT_ERR_CONNECTION;
            FMOD_OS_Semaphore_Signal(mSema);
            v14 = this->mLocalFiles.mNodes.mData;
            next = v14[v15].next;
          }
          while ( next != -1 );
          v18 = v11 + 1;
          v19 = this->mLocalFiles.mBuckets.mSize;
          if ( v11 == -1 )
            v18 = 0;
          if ( v18 == v19 )
            break;
          v20 = this->mLocalFiles.mBuckets.mData;
          v21 = v18;
          next = v20[v21];
          v22 = (__int64)&v20[v21 + 1];
          if ( next == -1 )
          {
            while ( ++v18 != v19 )
            {
              v22 += 4;
              next = *(_DWORD *)(v22 - 4);
              if ( next != -1 )
                goto LABEL_42;
            }
            break;
          }
LABEL_42:
          v11 = v18;
        }
      }
    }
    v23 = this->mRemoteFiles.mBuckets.mSize;
    if ( v23 )
    {
      v24 = this->mRemoteFiles.mBuckets.mData;
      v25 = 0;
      v26 = *v24;
      v27 = v24 + 1;
      if ( v26 == -1 )
      {
        while ( ++v25 != v23 )
        {
          v26 = *v27++;
          if ( v26 != -1 )
            goto LABEL_18;
        }
      }
      else
      {
        v25 = 0;
LABEL_18:
        v28 = this->mRemoteFiles.mNodes.mData;
        while ( 1 )
        {
          do
          {
            v29 = v26;
            v30 = v28[v29].value;
            mFileHandle = v30->mFileHandle;
            if ( mFileHandle )
            {
              v32 = FMOD_OS_File_Close(mFileHandle);
              if ( v32 )
              {
                v4 = v32;
                goto LABEL_2;
              }
            }
            FMOD::MemPool::free(
              off_286F358->gSystemMemPool,
              v30,
              "../../../core_api/src/fmod_profile_remotefile.cpp",
              106);
            v28 = this->mRemoteFiles.mNodes.mData;
            v26 = v28[v29].next;
          }
          while ( v26 != -1 );
          v33 = v25 + 1;
          v34 = this->mRemoteFiles.mBuckets.mSize;
          if ( v25 == -1 )
            v33 = 0;
          if ( v33 == v34 )
            goto LABEL_29;
          v35 = this->mRemoteFiles.mBuckets.mData;
          v36 = v33;
          v26 = v35[v36];
          v37 = (__int64)&v35[v36 + 1];
          if ( v26 == -1 )
            break;
LABEL_41:
          v25 = v33;
        }
        while ( ++v33 != v34 )
        {
          v37 += 4;
          v26 = *(_DWORD *)(v37 - 4);
          if ( v26 != -1 )
            goto LABEL_41;
        }
      }
    }
LABEL_29:
    v7 = this->mRemoteFiles.mBuckets.mCapacity == 0;
    v38 = this->mRemoteFiles.mBuckets.mCapacity <= 0;
    this->mRemoteFiles.mBuckets.mSize = 0;
    if ( !v7 )
    {
      if ( !v38 )
      {
        v41 = this->mRemoteFiles.mBuckets.mData;
        if ( v41 )
          FMOD::MemPool::free(off_286F358->gSystemMemPool, v41, "../../../core_api/src/fmod_memory.h", 244);
      }
      this->mRemoteFiles.mBuckets.mData = 0;
      this->mRemoteFiles.mBuckets.mCapacity = 0;
    }
    v39 = this->mRemoteFiles.mNodes.mSize;
    if ( v39 < 0 )
      memset(&this->mRemoteFiles.mNodes.mData[v39], 0, 16LL * -v39);
    mCapacity = this->mRemoteFiles.mNodes.mCapacity;
    this->mRemoteFiles.mNodes.mSize = 0;
    if ( !mCapacity
      || (v4 = FMOD::DynamicArray<FMOD::HashMap<int,FMOD::ProfileFileEntryRemote *,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote *>,FMOD::AlignedAllocator<1>>::reallocate(
                 &this->mRemoteFiles.mNodes,
                 0)) == FMOD_RESULT::FMOD_OK_0 )
    {
      this->mRemoteFiles.mFreeList = -1;
      this->mRemoteFiles.mNodeCount = 0;
      v4 = FMOD_RESULT::FMOD_OK_0;
    }
  }
LABEL_2:
  FMOD_OS_CriticalSection_Leave(mCallerLock);
  return v4;
}


// Address: 0x21ceed0 | Name: _ZN4FMOD17ProfileRemoteFile6createEPNS_7ProfileE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::create(FMOD::Profile *profile)
{
  char *v2; // rax
  char *v3; // rbx
  char *v4; // rax
  FMOD::Global *v5; // rax
  FMOD::MemPool *gSystemMemPool; // rdi
  void *v7; // r13
  FMOD_RESULT_0 v8; // r12d
  FMOD_RESULT_0 v10; // eax

  v2 = (char *)FMOD::MemPool::alloc(
                 off_286F358->gSystemMemPool,
                 176,
                 "../../../core_api/src/fmod_profile_remotefile.cpp",
                 123,
                 0,
                 0);
  v3 = v2;
  if ( v2 )
  {
    v4 = v2 + 8;
    *((_QWORD *)v3 + 3) = 0;
    *((_QWORD *)v3 + 4) = 0;
    *((_QWORD *)v3 + 2) = v4;
    *((_QWORD *)v3 + 1) = v4;
    *((_QWORD *)v3 + 10) = 0;
    *((_DWORD *)v3 + 22) = 0;
    *((_DWORD *)v3 + 23) = 0;
    *((_QWORD *)v3 + 12) = 0;
    *((_DWORD *)v3 + 26) = 0;
    *((_DWORD *)v3 + 27) = 0;
    *((_DWORD *)v3 + 28) = -1;
    *(_QWORD *)v3 = off_29B0F30;
    v5 = off_286F358;
    *((_DWORD *)v3 + 29) = 0;
    *((_QWORD *)v3 + 15) = 0;
    *((_DWORD *)v3 + 32) = 0;
    *((_DWORD *)v3 + 33) = 0;
    gSystemMemPool = v5->gSystemMemPool;
    *((_QWORD *)v3 + 17) = 0;
    *((_DWORD *)v3 + 36) = 0;
    *((_DWORD *)v3 + 37) = 0;
    *((_DWORD *)v3 + 38) = -1;
    *((_DWORD *)v3 + 39) = 0;
    v7 = FMOD::MemPool::alloc(
           gSystemMemPool,
           (int)&stru_10020,
           "../../../core_api/src/fmod_profile_remotefile.cpp",
           131,
           0,
           0);
    *((_QWORD *)v3 + 5) = v7;
    if ( v7 )
    {
      *((_QWORD *)v3 + 6) = 0;
      *((_DWORD *)v3 + 16) = 0;
      *((_QWORD *)v3 + 4) = profile;
      *((_DWORD *)v3 + 17) = 0;
      *((_DWORD *)v3 + 18) = 1;
      *((_QWORD *)v3 + 20) = 0;
      *((_QWORD *)v3 + 21) = 0;
      v8 = FMOD_OS_CriticalSection_Create((FMOD_OS_CRITICALSECTION **)v3 + 7, 0);
      if ( v8 == FMOD_RESULT::FMOD_OK_0 )
      {
        v10 = (*((unsigned int (__fastcall **)(FMOD::Profile *, char *))profile->_vptr_ProfileInterface + 1))(
                profile,
                v3);
        if ( v10 == FMOD_RESULT::FMOD_OK_0 )
          return v8;
        v8 = v10;
      }
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v7, "../../../core_api/src/fmod_autocleanup.h", 190);
    }
    else
    {
      v8 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
    (*(void (__fastcall **)(char *))(*(_QWORD *)v3 + 96LL))(v3);
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v3, "../../../core_api/src/fmod_autocleanup.h", 204);
    return v8;
  }
  return FMOD_RESULT::FMOD_ERR_MEMORY_0;
}


// Address: 0x21cf0e0 | Name: _ZN4FMOD17ProfileRemoteFile11setCallbackEPF11FMOD_RESULTPKcjPvES4_
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::setCallback(
        FMOD::ProfileRemoteFile *const this,
        FMOD::ProfileRemoteFileCallback callback,
        void *userdata)
{
  FMOD_OS_CRITICALSECTION *mCallerLock; // rbp

  mCallerLock = this->mCallerLock;
  FMOD_OS_CriticalSection_Enter(mCallerLock);
  this->mCallback = callback;
  this->mCallbackUserdata = userdata;
  FMOD_OS_CriticalSection_Leave(mCallerLock);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cf130 | Name: _ZN4FMOD17ProfileRemoteFile16fileOpenResponseEPNS_35ProfilePacketRemoteFileOpenResponseEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::fileOpenResponse(
        FMOD::ProfileRemoteFile *const this,
        struct {FMOD::ProfilePacketHeader hdr;int fileindex;unsigned int result;unsigned int length;} *response,
        FMOD::ProfileClient *fromclient)
{
  FMOD_OS_CRITICALSECTION *mCallerLock; // rbx
  int mSize; // eax
  int fileindex; // edx
  __int64 v6; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // rcx
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *i; // rax
  __int64 next; // rax
  FMOD::ProfileFileEntryLocal *value; // rax
  FMOD_OS_SEMAPHORE *mSema; // rdi

  mCallerLock = this->mCallerLock;
  FMOD_OS_CriticalSection_Enter(mCallerLock);
  if ( !this->mLocalFiles.mNodeCount )
    goto LABEL_8;
  mSize = this->mLocalFiles.mBuckets.mSize;
  if ( !mSize )
    goto LABEL_8;
  fileindex = response->fileindex;
  v6 = (int)this->mLocalFiles.mBuckets.mData[fileindex & (mSize - 1)];
  if ( (_DWORD)v6 == -1 )
    goto LABEL_8;
  mData = this->mLocalFiles.mNodes.mData;
  for ( i = &mData[v6]; fileindex != i->key; i = &mData[next] )
  {
    next = (int)i->next;
    if ( (_DWORD)next == -1 )
      goto LABEL_8;
  }
  value = i->value;
  if ( !value )
  {
LABEL_8:
    FMOD_OS_CriticalSection_Leave(mCallerLock);
    return FMOD_RESULT::FMOD_OK_0;
  }
  mSema = value->mSema;
  value->mFileResult = response->result;
  value->mFileLength = response->length;
  FMOD_OS_Semaphore_Signal(mSema);
  FMOD_OS_CriticalSection_Leave(mCallerLock);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cf1e0 | Name: _ZN4FMOD17ProfileRemoteFile8fileReadEPvS1_jjPj
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::fileRead(
        FMOD::ProfileRemoteFile *const this,
        void *filehandle,
        void *buffer,
        unsigned int size,
        unsigned int position,
        unsigned int *read)
{
  FMOD_RESULT_0 result; // eax
  FMOD_OS_CRITICALSECTION *mCallerLock; // r13
  unsigned int v10; // ecx
  unsigned int v11; // r8d
  int v12; // eax
  FMOD::ProfileInterface *mProfile; // rdi
  unsigned int (__fastcall **vptr_ProfileInterface)(FMOD::ProfileInterface *, FMOD::ProfilePacketRemoteFileReadRequest *, _QWORD); // rax
  FMOD_OS_CRITICALSECTION *v15; // rbp
  unsigned int v16; // edx
  unsigned int v17; // eax
  FMOD_RESULT_0 v18; // r12d
  unsigned int readb; // [rsp+8h] [rbp-60h]
  unsigned int sizeb; // [rsp+10h] [rbp-58h]
  unsigned int *positiona; // [rsp+18h] [rbp-50h]
  FMOD::ProfilePacketRemoteFileReadRequest packet; // [rsp+20h] [rbp-48h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( filehandle && size <= 0x10000 )
  {
    mCallerLock = this->mCallerLock;
    *read = 0;
    FMOD_OS_CriticalSection_Enter(mCallerLock);
    v10 = size;
    v11 = position;
    if ( this->mClientConnectedCount )
    {
      *((_DWORD *)filehandle + 10) = size;
      *((_QWORD *)filehandle + 4) = buffer;
      *((_DWORD *)filehandle + 11) = 0;
      *((_DWORD *)filehandle + 12) = 0;
      positiona = read;
      sizeb = v11;
      readb = v10;
      FMOD_OS_CriticalSection_Leave(mCallerLock);
      v12 = *((_DWORD *)filehandle + 4);
      mProfile = this->mProfile;
      *(_DWORD *)&packet.hdr.type = 522;
      *(_QWORD *)&packet.hdr.size = 0;
      packet.fileindex = v12;
      vptr_ProfileInterface = (unsigned int (__fastcall **)(FMOD::ProfileInterface *, FMOD::ProfilePacketRemoteFileReadRequest *, _QWORD))mProfile->_vptr_ProfileInterface;
      packet.hdr.size = 24;
      packet.position = sizeb;
      packet.length = readb;
      result = (*vptr_ProfileInterface)(mProfile, &packet, 0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        FMOD_OS_Semaphore_Wait(*((FMOD_OS_SEMAPHORE **)filehandle + 1));
        v15 = this->mCallerLock;
        FMOD_OS_CriticalSection_Enter(v15);
        if ( *((void **)filehandle + 4) == buffer
          && (v16 = *((_DWORD *)filehandle + 10), v16 == readb)
          && (v17 = *((_DWORD *)filehandle + 11), v16 >= v17) )
        {
          v18 = FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
          if ( !*((_DWORD *)filehandle + 6) && !*((_DWORD *)filehandle + 12) )
          {
            *positiona = v17;
            v18 = *((_DWORD *)filehandle + 11) < v16 ? FMOD_RESULT::FMOD_ERR_FILE_EOF_0 : FMOD_RESULT::FMOD_OK_0;
          }
          *((_QWORD *)filehandle + 4) = 0;
          *((_DWORD *)filehandle + 10) = 0;
          *((_DWORD *)filehandle + 11) = 0;
          *((_DWORD *)filehandle + 12) = 0;
          FMOD_OS_CriticalSection_Leave(v15);
          return v18;
        }
        else
        {
          FMOD_OS_CriticalSection_Leave(v15);
          return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
        }
      }
    }
    else
    {
      FMOD_OS_CriticalSection_Leave(mCallerLock);
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    }
  }
  return result;
}


// Address: 0x21cf380 | Name: _ZN4FMOD17ProfileRemoteFile16fileReadResponseEPNS_35ProfilePacketRemoteFileReadResponseEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::fileReadResponse(
        FMOD::ProfileRemoteFile *const this,
        struct {FMOD::ProfilePacketHeader hdr;int fileindex;unsigned int result;unsigned int position;unsigned int bytesRequested;unsigned int bytesDelivered;} *response,
        FMOD::ProfileClient *fromclient)
{
  FMOD_OS_CRITICALSECTION *mCallerLock; // r12
  int mSize; // eax
  FMOD_RESULT_0 v5; // ebp
  int fileindex; // edx
  __int64 v7; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // rcx
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *i; // rax
  __int64 next; // rax
  FMOD::ProfileFileEntryLocal *value; // rbx
  unsigned int bytesRequested; // eax
  size_t bytesDelivered; // rdx
  unsigned int v15; // eax

  mCallerLock = this->mCallerLock;
  FMOD_OS_CriticalSection_Enter(mCallerLock);
  if ( !this->mLocalFiles.mNodeCount )
    goto LABEL_8;
  mSize = this->mLocalFiles.mBuckets.mSize;
  v5 = FMOD_RESULT::FMOD_OK_0;
  if ( !mSize )
    goto LABEL_9;
  fileindex = response->fileindex;
  v7 = (int)this->mLocalFiles.mBuckets.mData[fileindex & (mSize - 1)];
  if ( (_DWORD)v7 == -1 )
    goto LABEL_9;
  mData = this->mLocalFiles.mNodes.mData;
  for ( i = &mData[v7]; fileindex != i->key; i = &mData[next] )
  {
    next = (int)i->next;
    if ( (_DWORD)next == -1 )
      goto LABEL_8;
  }
  value = i->value;
  if ( !value )
  {
LABEL_8:
    v5 = FMOD_RESULT::FMOD_OK_0;
    goto LABEL_9;
  }
  bytesRequested = response->bytesRequested;
  v5 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( bytesRequested == value->mReadBytesRequested )
  {
    bytesDelivered = response->bytesDelivered;
    if ( bytesRequested >= (unsigned int)bytesDelivered )
    {
      v15 = response->result;
      if ( v15 )
      {
        value->mReadResult = v15;
      }
      else
      {
        memcpy_0(value->mReadData, &response[1], bytesDelivered);
        value->mReadBytesReceived = response->bytesDelivered;
      }
      v5 = FMOD_RESULT::FMOD_OK_0;
      FMOD_OS_Semaphore_Signal(value->mSema);
    }
  }
LABEL_9:
  FMOD_OS_CriticalSection_Leave(mCallerLock);
  return v5;
}


// Address: 0x21cf460 | Name: _ZN4FMOD17ProfileRemoteFile9fileCloseEPv
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::fileClose(FMOD::ProfileRemoteFile *const this, void *filehandle)
{
  FMOD_RESULT_0 v3; // ebp
  FMOD_OS_CRITICALSECTION *mCallerLock; // r14
  int v6; // ebx
  int mSize; // eax
  signed int *v8; // rdi
  signed int v9; // eax
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // rdx
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v11; // rsi
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v12; // rax
  __int64 next; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v15; // rcx
  signed int *p_next; // rsi
  unsigned int v17; // edx
  FMOD::ProfileInterface *mProfile; // rdi
  unsigned int (__fastcall **vptr_ProfileInterface)(FMOD::ProfileInterface *, FMOD::ProfilePacketRemoteFileCloseRequest *, _QWORD); // rax
  FMOD::ProfilePacketRemoteFileCloseRequest packet; // [rsp+0h] [rbp-38h] BYREF

  v3 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( filehandle )
  {
    mCallerLock = this->mCallerLock;
    FMOD_OS_CriticalSection_Enter(mCallerLock);
    v6 = *((_DWORD *)filehandle + 4);
    if ( this->mLocalFiles.mNodeCount )
    {
      mSize = this->mLocalFiles.mBuckets.mSize;
      if ( mSize )
      {
        v8 = (signed int *)&this->mLocalFiles.mBuckets.mData[v6 & (mSize - 1)];
        v9 = *v8;
        if ( *v8 != -1 )
        {
          mData = this->mLocalFiles.mNodes.mData;
          v11 = &mData[v9];
          if ( v6 != v11->key )
          {
            v12 = &mData[v9];
            do
            {
              next = (int)v12->next;
              if ( (_DWORD)next == -1 )
                goto LABEL_9;
              v12 = &mData[next];
            }
            while ( v6 != v12->key );
            if ( filehandle != v12->value )
            {
LABEL_9:
              v3 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
              goto LABEL_10;
            }
            while ( 1 )
            {
              v9 = v11->next;
              if ( v9 == -1 )
                break;
              v15 = &mData[v9];
              if ( v6 == v15->key )
              {
                p_next = (signed int *)&v11->next;
                goto LABEL_14;
              }
              v11 = &mData[v9];
            }
LABEL_15:
            v3 = FMOD_OS_Semaphore_Free(*((FMOD_OS_SEMAPHORE **)filehandle + 1));
            if ( v3 == FMOD_RESULT::FMOD_OK_0 )
            {
              FMOD::MemPool::free(
                off_286F358->gSystemMemPool,
                filehandle,
                "../../../core_api/src/fmod_profile_remotefile.cpp",
                64);
              FMOD_OS_CriticalSection_Leave(mCallerLock);
              mProfile = this->mProfile;
              *(_QWORD *)&packet.hdr.type = 1034;
              *(_QWORD *)&packet.hdr.size = 16;
              vptr_ProfileInterface = (unsigned int (__fastcall **)(FMOD::ProfileInterface *, FMOD::ProfilePacketRemoteFileCloseRequest *, _QWORD))mProfile->_vptr_ProfileInterface;
              packet.fileindex = v6;
              return (*vptr_ProfileInterface)(mProfile, &packet, 0);
            }
            goto LABEL_10;
          }
          if ( filehandle == v11->value )
          {
            v15 = &mData[v9];
            p_next = v8;
LABEL_14:
            v17 = v15->next;
            v15->value = 0;
            *p_next = v17;
            v15->next = this->mLocalFiles.mFreeList;
            --this->mLocalFiles.mNodeCount;
            this->mLocalFiles.mFreeList = v9;
            goto LABEL_15;
          }
        }
      }
    }
LABEL_10:
    FMOD_OS_CriticalSection_Leave(mCallerLock);
  }
  return v3;
}


// Address: 0x21cf5e0 | Name: _ZN4FMOD17ProfileRemoteFile16fileCloseProcessEPNS_35ProfilePacketRemoteFileCloseRequestEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::fileCloseProcess(
        FMOD::ProfileRemoteFile *const this,
        struct {FMOD::ProfilePacketHeader hdr;int fileindex;} *request,
        FMOD::ProfileClient *fromclient)
{
  FMOD_OS_CRITICALSECTION *mCallerLock; // rbx
  int mSize; // eax
  FMOD_RESULT_0 v6; // r13d
  int fileindex; // edx
  __int64 v8; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // rcx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *i; // rax
  __int64 next; // rax
  FMOD_OS_FILE **value; // r14
  FMOD::ProfileRemoteFileCallback mCallback; // rax
  int v15; // eax
  int v16; // esi
  signed int *p_next; // r8
  signed int v18; // edx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v19; // rdi
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v20; // rcx
  FMOD_OS_FILE *v21; // rdi
  signed int v22; // ecx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v23; // rax

  mCallerLock = this->mCallerLock;
  FMOD_OS_CriticalSection_Enter(mCallerLock);
  if ( !this->mRemoteFiles.mNodeCount )
    goto LABEL_8;
  mSize = this->mRemoteFiles.mBuckets.mSize;
  v6 = FMOD_RESULT::FMOD_OK_0;
  if ( !mSize )
    goto LABEL_9;
  fileindex = request->fileindex;
  v8 = (int)this->mRemoteFiles.mBuckets.mData[fileindex & (mSize - 1)];
  if ( (_DWORD)v8 == -1 )
    goto LABEL_9;
  mData = this->mRemoteFiles.mNodes.mData;
  for ( i = &mData[v8]; fileindex != i->key; i = &mData[next] )
  {
    next = (int)i->next;
    if ( (_DWORD)next == -1 )
      goto LABEL_8;
  }
  value = (FMOD_OS_FILE **)i->value;
  if ( !value )
  {
LABEL_8:
    v6 = FMOD_RESULT::FMOD_OK_0;
    goto LABEL_9;
  }
  FMOD_OS_File_Close(value[2]);
  mCallback = this->mCallback;
  value[2] = 0;
  if ( mCallback )
    mCallback((const char *)value + 28, 1u, this->mCallbackUserdata);
  if ( this->mRemoteFiles.mNodeCount )
  {
    v15 = this->mRemoteFiles.mBuckets.mSize;
    v6 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    if ( !v15 )
      goto LABEL_9;
    v16 = request->fileindex;
    p_next = (signed int *)&this->mRemoteFiles.mBuckets.mData[v16 & (v15 - 1)];
    v18 = *p_next;
    if ( *p_next != -1 )
    {
      v19 = this->mRemoteFiles.mNodes.mData;
      v20 = &v19[v18];
      if ( v16 == v20->key )
      {
        v23 = &v19[v18];
LABEL_25:
        v22 = v23->next;
        v23->value = 0;
        *p_next = v22;
        v23->next = this->mRemoteFiles.mFreeList;
        this->mRemoteFiles.mFreeList = v18;
        --this->mRemoteFiles.mNodeCount;
      }
      else
      {
        while ( 1 )
        {
          v18 = v20->next;
          if ( v18 == -1 )
            break;
          v23 = &v19[v18];
          if ( v16 == v23->key )
          {
            p_next = (signed int *)&v20->next;
            goto LABEL_25;
          }
          v20 = &v19[v18];
        }
      }
    }
  }
  v21 = value[2];
  if ( !v21 || (v6 = FMOD_OS_File_Close(v21)) == FMOD_RESULT::FMOD_OK_0 )
  {
    v6 = FMOD_RESULT::FMOD_OK_0;
    FMOD::MemPool::free(off_286F358->gSystemMemPool, value, "../../../core_api/src/fmod_profile_remotefile.cpp", 106);
  }
LABEL_9:
  FMOD_OS_CriticalSection_Leave(mCallerLock);
  return v6;
}


// Address: 0x21cf7b0 | Name: _ZN4FMOD17ProfileRemoteFile28ensureFileReadBufferCapacityEi
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::ensureFileReadBufferCapacity(
        FMOD::ProfileRemoteFile *const this,
        int lengthRequired)
{
  FMOD_RESULT_0 v2; // edx
  char *mFileReadBuffer; // rsi
  char *v5; // rax

  v2 = FMOD_RESULT::FMOD_OK_0;
  if ( this->mFileReadBufferLength < lengthRequired )
  {
    mFileReadBuffer = this->mFileReadBuffer;
    if ( mFileReadBuffer )
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        mFileReadBuffer,
        "../../../core_api/src/fmod_profile_remotefile.cpp",
        649);
    v5 = (char *)FMOD::MemPool::alloc(
                   off_286F358->gSystemMemPool,
                   lengthRequired,
                   "../../../core_api/src/fmod_profile_remotefile.cpp",
                   652,
                   0,
                   0);
    this->mFileReadBuffer = v5;
    v2 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    if ( v5 )
    {
      this->mFileReadBufferLength = lengthRequired;
      LOBYTE(v2) = 0;
    }
  }
  return v2;
}


// Address: 0x21cf830 | Name: _ZN4FMOD17ProfileRemoteFile15fileReadProcessEPNS_34ProfilePacketRemoteFileReadRequestEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::fileReadProcess(
        FMOD::ProfileRemoteFile *const this,
        struct {FMOD::ProfilePacketHeader hdr;int fileindex;unsigned int position;unsigned int length;} *request,
        FMOD::ProfileClient *fromclient)
{
  FMOD_RESULT_0 result; // eax
  unsigned int length; // esi
  char *mFileReadBuffer; // r14
  int fileindex; // eax
  FMOD_OS_CRITICALSECTION *mCallerLock; // r12
  unsigned int v11; // eax
  int mSize; // eax
  int v13; // edx
  __int64 v14; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // rcx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v16; // rax
  __int64 next; // rax
  FMOD::ProfileFileEntryRemote *value; // r15
  unsigned int v19; // edx
  FMOD_OS_FILE *mFileHandle; // rdi
  unsigned int v21; // eax
  unsigned int actualAmountRead[15]; // [rsp+Ch] [rbp-3Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  length = request->length;
  if ( length <= 0x8000000 )
  {
    result = FMOD::ProfileRemoteFile::ensureFileReadBufferCapacity(this, length + 33);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mFileReadBuffer = this->mFileReadBuffer;
      *((_QWORD *)mFileReadBuffer + 1) = 0;
      *((_QWORD *)mFileReadBuffer + 2) = 0;
      *((_QWORD *)mFileReadBuffer + 3) = 0;
      *(_QWORD *)mFileReadBuffer = 0;
      mFileReadBuffer[8] = 10;
      mFileReadBuffer[9] = 3;
      fileindex = request->fileindex;
      mCallerLock = this->mCallerLock;
      *(_DWORD *)mFileReadBuffer = 32;
      *((_DWORD *)mFileReadBuffer + 3) = fileindex;
      *((_DWORD *)mFileReadBuffer + 5) = request->position;
      v11 = request->length;
      *((_DWORD *)mFileReadBuffer + 7) = 0;
      *((_DWORD *)mFileReadBuffer + 4) = 3;
      *((_DWORD *)mFileReadBuffer + 6) = v11;
      FMOD_OS_CriticalSection_Enter(mCallerLock);
      if ( this->mRemoteFiles.mNodeCount )
      {
        mSize = this->mRemoteFiles.mBuckets.mSize;
        if ( mSize )
        {
          v13 = request->fileindex;
          v14 = (int)this->mRemoteFiles.mBuckets.mData[v13 & (mSize - 1)];
          if ( (_DWORD)v14 != -1 )
          {
            mData = this->mRemoteFiles.mNodes.mData;
            v16 = &mData[v14];
            if ( v13 == v16->key )
            {
LABEL_12:
              value = v16->value;
              if ( value && FMOD_OS_File_Seek(value->mFileHandle, request->position) == FMOD_RESULT::FMOD_OK_0 )
              {
                v19 = request->length;
                mFileHandle = value->mFileHandle;
                actualAmountRead[0] = 0;
                if ( (FMOD_OS_File_Read(mFileHandle, mFileReadBuffer + 32, v19, actualAmountRead) & 0xFFFFFFEF) == 0 )
                {
                  v21 = actualAmountRead[0];
                  *((_DWORD *)mFileReadBuffer + 4) = 0;
                  *(_DWORD *)mFileReadBuffer += v21;
                  *((_DWORD *)mFileReadBuffer + 7) = v21;
                }
              }
            }
            else
            {
              while ( 1 )
              {
                next = (int)v16->next;
                if ( (_DWORD)next == -1 )
                  break;
                v16 = &mData[next];
                if ( v13 == v16->key )
                  goto LABEL_12;
              }
            }
          }
        }
      }
      FMOD_OS_CriticalSection_Leave(mCallerLock);
      return (*this->mProfile->_vptr_ProfileInterface)(this->mProfile, mFileReadBuffer, fromclient);
    }
  }
  return result;
}


// Address: 0x21cfc50 | Name: _ZN4FMOD17ProfileRemoteFile15fileOpenProcessEPNS_34ProfilePacketRemoteFileOpenRequestEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::fileOpenProcess(
        FMOD::ProfileRemoteFile *const this,
        struct {FMOD::ProfilePacketHeader hdr;int fileindex;unsigned int flags;char filename[256];} *request,
        FMOD::ProfileClient *fromclient)
{
  bool v6; // zf
  int fileindex; // eax
  FMOD_RESULT_0 v8; // ebp
  char *filename; // rbp
  FMOD_OS_CRITICALSECTION *mCallerLock; // r14
  FMOD::ProfileRemoteFileCallback mCallback; // rax
  int mSize; // eax
  FMOD::ProfileFileEntryRemote *v14; // rax
  FMOD::ProfileFileEntryRemote *v15; // r15
  char *mFilename; // rdi
  int v17; // eax
  int mNodeCount; // edx
  unsigned int v19; // eax
  int v20; // edx
  __int64 v21; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // rcx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v23; // rax
  __int64 next; // rax
  FMOD_RESULT_0 v25; // eax
  int v26; // ecx
  unsigned int v27; // eax
  unsigned int *p_next; // rcx
  __int64 v29; // rdx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v30; // rsi
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v31; // rdx
  unsigned int v32; // ecx
  unsigned int mFreeList; // edx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v34; // rax
  int v35; // esi
  int v36; // esi
  int mCapacity; // esi
  int v38; // ebx
  int v39; // eax
  int v40; // edx
  int v41; // eax
  int v42; // esi
  int v43; // eax
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v44; // rax
  unsigned int *v45; // [rsp+8h] [rbp-80h]
  unsigned int actualFileSize; // [rsp+14h] [rbp-74h] BYREF
  FMOD_OS_FILE *actualFileHandle; // [rsp+18h] [rbp-70h] BYREF
  unsigned __int64 v48; // [rsp+20h] [rbp-68h]
  FMOD::ProfileFileEntryRemote *v49; // [rsp+28h] [rbp-60h]
  FMOD::ProfilePacketRemoteFileOpenResponse response; // [rsp+30h] [rbp-58h] BYREF

  v6 = request->hdr.version == 0;
  fileindex = request->fileindex;
  *(_DWORD *)&response.hdr.type = 266;
  *(_QWORD *)&response.hdr.size = 24;
  *(_QWORD *)&response.result = 0;
  response.fileindex = fileindex;
  if ( v6 )
  {
    filename = request->filename;
    if ( FMOD_OS_File_Open(request->filename, FMOD_FILE_MODE::FMOD_FILE_MODE_READ, &actualFileSize, &actualFileHandle) )
    {
      response.result = 3;
      return (*this->mProfile->_vptr_ProfileInterface)(this->mProfile, &response, fromclient);
    }
    mCallerLock = this->mCallerLock;
    FMOD_OS_CriticalSection_Enter(mCallerLock);
    mCallback = this->mCallback;
    if ( mCallback )
      mCallback(filename, 0, this->mCallbackUserdata);
    if ( this->mRemoteFiles.mNodeCount )
    {
      mSize = this->mRemoteFiles.mBuckets.mSize;
      if ( mSize )
      {
        v20 = request->fileindex;
        v21 = (int)this->mRemoteFiles.mBuckets.mData[v20 & (mSize - 1)];
        if ( (_DWORD)v21 != -1 )
        {
          mData = this->mRemoteFiles.mNodes.mData;
          v23 = &mData[v21];
          if ( v23->key == v20 )
          {
LABEL_22:
            v25 = FMOD_OS_File_Close(actualFileHandle);
            if ( v25 == FMOD_RESULT::FMOD_OK_0 )
            {
              response.result = 3;
LABEL_24:
              FMOD_OS_CriticalSection_Leave(mCallerLock);
              return (*this->mProfile->_vptr_ProfileInterface)(this->mProfile, &response, fromclient);
            }
            v8 = v25;
LABEL_14:
            FMOD_OS_CriticalSection_Leave(mCallerLock);
            return v8;
          }
          while ( 1 )
          {
            next = (int)v23->next;
            if ( (_DWORD)next == -1 )
              break;
            v23 = &mData[next];
            if ( v20 == v23->key )
              goto LABEL_22;
          }
        }
      }
    }
    response.length = actualFileSize;
    v14 = (FMOD::ProfileFileEntryRemote *)FMOD::MemPool::alloc(
                                            off_286F358->gSystemMemPool,
                                            288,
                                            "../../../core_api/src/fmod_profile_remotefile.cpp",
                                            358,
                                            0,
                                            0);
    v15 = v14;
    if ( !v14 )
    {
      v8 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
      goto LABEL_14;
    }
    v14->mFileHandle = 0;
    v14->mFileLength = 0;
    mFilename = v14->mFilename;
    v17 = request->fileindex;
    v15->mClient = this;
    v15->mFileIndex = v17;
    FMOD_strcpy_safe(mFilename, filename, 256);
    mNodeCount = this->mRemoteFiles.mNodeCount;
    v15->mFileLength = actualFileSize;
    v15->mFileHandle = actualFileHandle;
    if ( mNodeCount != -1 )
    {
      v8 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      v19 = abs32(this->mRemoteFiles.mNodes.mCapacity);
      if ( v19 != this->mRemoteFiles.mBuckets.mSize )
        goto LABEL_14;
      v26 = v19;
      if ( mNodeCount == v19 )
      {
        v36 = 2 * v19;
        if ( (int)(2 * v19) < 4 )
          v36 = 4;
        v8 = FMOD::HashMap<int,FMOD::ProfileFileEntryRemote *,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote *>,FMOD::HashMapDefaultHash,unsigned int>::rehash(
               &this->mRemoteFiles,
               v36);
        if ( v8 )
          goto LABEL_14;
        v26 = this->mRemoteFiles.mBuckets.mSize;
      }
      if ( v26 )
      {
        v27 = request->fileindex;
        p_next = &this->mRemoteFiles.mBuckets.mData[v27 & (v26 - 1)];
        v29 = (int)*p_next;
        if ( (_DWORD)v29 != -1 )
        {
          v30 = this->mRemoteFiles.mNodes.mData;
          v31 = &v30[v29];
          if ( v27 == v31->key )
            goto LABEL_21;
          while ( 1 )
          {
            v32 = v31->next;
            if ( v32 == -1 )
              break;
            v31 = &v30[v32];
            if ( v27 == v31->key )
              goto LABEL_21;
          }
          p_next = &v31->next;
        }
        mFreeList = this->mRemoteFiles.mFreeList;
        if ( mFreeList == -1 )
        {
          mCapacity = this->mRemoteFiles.mNodes.mCapacity;
          v38 = this->mRemoteFiles.mNodes.mSize;
          v48 = v27 | 0xFFFFFFFF00000000LL;
          v39 = this->mRemoteFiles.mNodes.mCapacity;
          v49 = v15;
          v40 = v38 + 1;
          v41 = ((mCapacity >> 31) ^ v39) - (mCapacity >> 31);
          if ( v38 + 1 > v41 )
          {
            v42 = 4;
            v8 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
            v43 = (int)(float)((float)v41 * 1.5);
            if ( v43 >= v40 )
              v40 = v43;
            if ( v40 > 3 )
              v42 = v40;
            if ( v38 > v42 )
              goto LABEL_14;
            v45 = p_next;
            v8 = FMOD::DynamicArray<FMOD::HashMap<int,FMOD::ProfileFileEntryRemote *,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote *>,FMOD::AlignedAllocator<1>>::reallocate(
                   &this->mRemoteFiles.mNodes,
                   v42);
            p_next = v45;
            if ( v8 )
              goto LABEL_14;
          }
          v44 = &this->mRemoteFiles.mNodes.mData[this->mRemoteFiles.mNodes.mSize];
          *(_QWORD *)&v44->key = v48;
          v44->value = v49;
          ++this->mRemoteFiles.mNodes.mSize;
          *p_next = v38;
        }
        else
        {
          v34 = &this->mRemoteFiles.mNodes.mData[mFreeList];
          this->mRemoteFiles.mFreeList = v34->next;
          v34->next = -1;
          v35 = request->fileindex;
          v34->value = v15;
          v34->key = v35;
          *p_next = mFreeList;
        }
        ++this->mRemoteFiles.mNodeCount;
        goto LABEL_24;
      }
    }
LABEL_21:
    v8 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    goto LABEL_14;
  }
  response.result = 2;
  return (*this->mProfile->_vptr_ProfileInterface)(this->mProfile, &response, fromclient);
}


// Address: 0x21d0030 | Name: _ZN4FMOD17ProfileRemoteFile15readPacketAsyncEPKNS_19ProfilePacketHeaderEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::readPacketAsync(
        FMOD::ProfileRemoteFile *const this,
        const FMOD::ProfilePacketHeader *packet,
        FMOD::ProfileClient *fromclient)
{
  unsigned __int8 subtype; // al

  subtype = packet->subtype;
  switch ( subtype )
  {
    case 0u:
      return FMOD::ProfileRemoteFile::fileOpenProcess(
               this,
               (struct {FMOD::ProfilePacketHeader hdr;int fileindex;unsigned int flags;char filename[256];} *)packet,
               fromclient);
    case 1u:
      return FMOD::ProfileRemoteFile::fileOpenResponse(
               this,
               (struct {FMOD::ProfilePacketHeader hdr;int fileindex;unsigned int result;unsigned int length;} *)packet,
               fromclient);
    case 2u:
      return FMOD::ProfileRemoteFile::fileReadProcess(
               this,
               (struct {FMOD::ProfilePacketHeader hdr;int fileindex;unsigned int position;unsigned int length;} *)packet,
               fromclient);
    case 3u:
      return FMOD::ProfileRemoteFile::fileReadResponse(
               this,
               (struct {FMOD::ProfilePacketHeader hdr;int fileindex;unsigned int result;unsigned int position;unsigned int bytesRequested;unsigned int bytesDelivered;} *)packet,
               fromclient);
    case 4u:
      return FMOD::ProfileRemoteFile::fileCloseProcess(
               this,
               (struct {FMOD::ProfilePacketHeader hdr;int fileindex;} *)packet,
               fromclient);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d0160 | Name: _ZN4FMOD17ProfileRemoteFile8fileOpenEPKcPjPPv
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::fileOpen(
        FMOD::ProfileRemoteFile *const this,
        const char *name_or_data,
        unsigned int *filesize,
        void **filehandle)
{
  const char *v5; // rbx
  int v6; // eax
  FMOD_OS_CRITICALSECTION *mCallerLock; // r12
  int mNextLocalID; // r15d
  char *v9; // rax
  FMOD::ProfileFileEntryLocal *v10; // r14
  FMOD_RESULT_0 v11; // r13d
  int mNodeCount; // ecx
  int v14; // eax
  unsigned int *p_next; // r10
  __int64 v16; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v17; // rcx
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v18; // rax
  unsigned int next; // edx
  unsigned int mFreeList; // eax
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v21; // rdx
  FMOD::ProfileInterface *mProfile; // rdi
  FMOD_OS_CRITICALSECTION *v23; // rbx
  int v24; // eax
  int mFileIndex; // esi
  signed int *v26; // r8
  signed int v27; // edx
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v28; // rdi
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v29; // rcx
  int v30; // r8d
  FMOD_RESULT_0 v31; // eax
  __int64 v32; // rax
  int mSize; // r8d
  __int64 i; // rax
  int v35; // edx
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // rdi
  __int64 v37; // rsi
  unsigned int *j; // rcx
  __int64 v39; // rdx
  signed int v40; // ecx
  int v41; // ecx
  int mCapacity; // eax
  int v43; // edx
  int v44; // eax
  int v45; // eax
  int v46; // r15d
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v47; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v48; // r13
  __int64 v49; // rdx
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v50; // rsi
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v51; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v52; // rax
  int newSize; // [rsp+14h] [rbp-164h]
  int newSizea; // [rsp+14h] [rbp-164h]
  unsigned int *v57; // [rsp+18h] [rbp-160h]
  unsigned int *v58; // [rsp+18h] [rbp-160h]
  _BYTE newindex[272]; // [rsp+20h] [rbp-158h] OVERLAPPED BYREF
  int v60; // [rsp+130h] [rbp-48h]

  v5 = name_or_data;
  v6 = FMOD_strncmp(name_or_data, "fmod:///remote/", 15);
  mCallerLock = this->mCallerLock;
  if ( !v6 )
    v5 = name_or_data + 15;
  FMOD_OS_CriticalSection_Enter(this->mCallerLock);
  if ( !this->mClientConnectedCount )
  {
    v11 = FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0;
    goto LABEL_6;
  }
  mNextLocalID = this->mNextLocalID;
  this->mNextLocalID = mNextLocalID + 1;
  v9 = (char *)FMOD::MemPool::alloc(
                 off_286F358->gSystemMemPool,
                 312,
                 "../../../core_api/src/fmod_profile_remotefile.cpp",
                 272,
                 0,
                 0);
  v10 = (FMOD::ProfileFileEntryLocal *)v9;
  if ( !v9 )
    goto LABEL_25;
  *((_QWORD *)v9 + 1) = 0;
  *((_DWORD *)v9 + 5) = 0;
  *((_DWORD *)v9 + 6) = 0;
  *((_QWORD *)v9 + 4) = 0;
  *((_DWORD *)v9 + 10) = 0;
  *((_DWORD *)v9 + 11) = 0;
  *((_DWORD *)v9 + 12) = 0;
  *(_QWORD *)v9 = this;
  *((_DWORD *)v9 + 4) = mNextLocalID;
  FMOD_strcpy_safe(v9 + 52, v5, 256);
  v11 = FMOD_OS_Semaphore_Create(&v10->mSema);
  if ( v11 == FMOD_RESULT::FMOD_OK_0 )
  {
    mNodeCount = this->mLocalFiles.mNodeCount;
    if ( mNodeCount == -1 )
      goto LABEL_24;
    v11 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    v14 = abs32(this->mLocalFiles.mNodes.mCapacity);
    if ( v14 != this->mLocalFiles.mBuckets.mSize )
      goto LABEL_6;
    if ( mNodeCount == v14 )
    {
      v30 = 2 * mNodeCount;
      if ( 2 * mNodeCount < 4 )
        v30 = 4;
      if ( mNodeCount >= v30 || mNodeCount != this->mLocalFiles.mNodes.mSize || this->mLocalFiles.mFreeList != -1 )
        goto LABEL_24;
      newSize = v30;
      v11 = FMOD::DynamicArray<FMOD::HashMap<int,FMOD::ProfileFileEntryLocal *,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal *>,FMOD::AlignedAllocator<1>>::reserve(
              &this->mLocalFiles.mNodes,
              v30);
      if ( v11 )
        goto LABEL_6;
      v31 = FMOD::DynamicArray<unsigned int,FMOD::ArrayConstruct_Fast_Uninit,FMOD::AlignedAllocator<1>>::resize(
              &this->mLocalFiles.mBuckets,
              newSize);
      if ( v31 )
      {
        v11 = v31;
        goto LABEL_6;
      }
      v32 = 0;
      do
        this->mLocalFiles.mBuckets.mData[v32++] = -1;
      while ( newSize > (int)v32 );
      mSize = this->mLocalFiles.mNodes.mSize;
      for ( i = 0; mSize > (int)i; ++i )
      {
        v35 = this->mLocalFiles.mBuckets.mSize;
        mData = this->mLocalFiles.mNodes.mData;
        v37 = i;
        if ( !v35 )
          goto LABEL_24;
        for ( j = &this->mLocalFiles.mBuckets.mData[mData[i].key & (v35 - 1)]; ; j = &mData[v39].next )
        {
          v39 = (int)*j;
          if ( (_DWORD)v39 == -1 )
            break;
        }
        *j = i;
        this->mLocalFiles.mNodes.mData[v37].next = -1;
      }
      v14 = this->mLocalFiles.mBuckets.mSize;
    }
    if ( !v14 )
    {
LABEL_24:
      v11 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      goto LABEL_6;
    }
    p_next = &this->mLocalFiles.mBuckets.mData[mNextLocalID & (v14 - 1)];
    v16 = (int)*p_next;
    if ( (_DWORD)v16 != -1 )
    {
      v17 = this->mLocalFiles.mNodes.mData;
      v18 = &v17[v16];
      if ( mNextLocalID == v18->key )
        goto LABEL_24;
      while ( 1 )
      {
        next = v18->next;
        if ( next == -1 )
          break;
        v18 = &v17[next];
        if ( mNextLocalID == v18->key )
          goto LABEL_24;
      }
      p_next = &v18->next;
    }
    mFreeList = this->mLocalFiles.mFreeList;
    if ( mFreeList != -1 )
    {
      v21 = &this->mLocalFiles.mNodes.mData[mFreeList];
      this->mLocalFiles.mFreeList = v21->next;
      v21->next = -1;
      v21->key = mNextLocalID;
      v21->value = v10;
      *p_next = mFreeList;
      goto LABEL_21;
    }
    v41 = this->mLocalFiles.mNodes.mSize;
    *(_DWORD *)&newindex[4] = -1;
    mCapacity = this->mLocalFiles.mNodes.mCapacity;
    *(_DWORD *)newindex = mNextLocalID;
    *(_QWORD *)&newindex[8] = v10;
    v43 = v41 + 1;
    newSizea = v41;
    v44 = ((this->mLocalFiles.mNodes.mCapacity >> 31) ^ mCapacity) - (this->mLocalFiles.mNodes.mCapacity >> 31);
    if ( v41 + 1 <= v44 )
    {
LABEL_68:
      v51 = &this->mLocalFiles.mNodes.mData[this->mLocalFiles.mNodes.mSize];
      *(_QWORD *)&v51->key = *(_QWORD *)newindex;
      v51->value = *(FMOD::ProfileFileEntryLocal **)&newindex[8];
      ++this->mLocalFiles.mNodes.mSize;
      *p_next = newSizea;
LABEL_21:
      ++this->mLocalFiles.mNodeCount;
      FMOD_OS_CriticalSection_Leave(mCallerLock);
      memset(newindex, 0, sizeof(newindex));
      v60 = 0;
      *(_DWORD *)newindex = 276;
      newindex[8] = 10;
      FMOD_strcpy_safe(&newindex[20], v5, 256);
      mProfile = this->mProfile;
      *(_DWORD *)&newindex[12] = v10->mFileIndex;
      v11 = (*mProfile->_vptr_ProfileInterface)(mProfile, newindex, 0);
      if ( v11 )
        return v11;
      FMOD_OS_Semaphore_Wait(v10->mSema);
      if ( v10->mFileResult == FMOD::FMOD_PROFILE_REMOTEFILE_RESULT::FMOD_PROFILE_REMOTEFILE_RESULT_OK )
      {
        *filesize = v10->mFileLength;
        *filehandle = v10;
        return v11;
      }
      v23 = this->mCallerLock;
      FMOD_OS_CriticalSection_Enter(v23);
      if ( this->mLocalFiles.mNodeCount )
      {
        v24 = this->mLocalFiles.mBuckets.mSize;
        v11 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
        if ( !v24 )
        {
LABEL_36:
          FMOD_OS_CriticalSection_Leave(v23);
          return v11;
        }
        mFileIndex = v10->mFileIndex;
        v26 = (signed int *)&this->mLocalFiles.mBuckets.mData[mFileIndex & (v24 - 1)];
        v27 = *v26;
        if ( *v26 != -1 )
        {
          v28 = this->mLocalFiles.mNodes.mData;
          v29 = &v28[v27];
          if ( mFileIndex == v29->key )
          {
            v52 = &v28[v27];
LABEL_53:
            v40 = v52->next;
            v52->value = 0;
            *v26 = v40;
            v52->next = this->mLocalFiles.mFreeList;
            this->mLocalFiles.mFreeList = v27;
            --this->mLocalFiles.mNodeCount;
          }
          else
          {
            while ( 1 )
            {
              v27 = v29->next;
              if ( v27 == -1 )
                break;
              v52 = &v28[v27];
              if ( mFileIndex == v52->key )
              {
                v26 = (signed int *)&v29->next;
                goto LABEL_53;
              }
              v29 = &v28[v27];
            }
          }
        }
      }
      v11 = FMOD_OS_Semaphore_Free(v10->mSema);
      if ( v11 == FMOD_RESULT::FMOD_OK_0 )
      {
        v11 = FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0;
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v10, "../../../core_api/src/fmod_profile_remotefile.cpp", 64);
      }
      goto LABEL_36;
    }
    v11 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    v45 = (int)(float)((float)v44 * 1.5);
    if ( v45 >= v43 )
      v43 = v45;
    if ( v43 <= 3 )
      v43 = 4;
    v46 = v43;
    if ( v41 > v43 )
      goto LABEL_6;
    if ( (unsigned int)(16 * v43 - 1) <= 0x3FFFFFFE )
    {
      v57 = p_next;
      v47 = (FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *)FMOD::MemPool::alloc(off_286F358->gSystemMemPool, 16 * v43, "../../../core_api/src/fmod_memory.h", 232, 0, 0);
      v48 = v47;
      p_next = v57;
      if ( v47 )
      {
        v49 = this->mLocalFiles.mNodes.mSize;
        if ( (_DWORD)v49 )
        {
          memcpy_0(v47, this->mLocalFiles.mNodes.mData, 16 * v49);
          p_next = v57;
        }
        if ( this->mLocalFiles.mNodes.mCapacity > 0 )
        {
          v50 = this->mLocalFiles.mNodes.mData;
          if ( v50 )
          {
            v58 = p_next;
            FMOD::MemPool::free(off_286F358->gSystemMemPool, v50, "../../../core_api/src/fmod_memory.h", 244);
            p_next = v58;
          }
        }
        this->mLocalFiles.mNodes.mData = v48;
        this->mLocalFiles.mNodes.mCapacity = v46;
        goto LABEL_68;
      }
    }
LABEL_25:
    v11 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
LABEL_6:
  FMOD_OS_CriticalSection_Leave(mCallerLock);
  return v11;
}


