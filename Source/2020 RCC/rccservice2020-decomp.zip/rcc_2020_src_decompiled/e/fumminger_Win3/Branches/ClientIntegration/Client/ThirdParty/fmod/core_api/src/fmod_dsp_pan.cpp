// Address: 0x21d78e0 | Name: _ZN4FMOD9DSPPanner16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPPanner::getDescriptionEx()
{
  if ( !byte_2AD9540 )
  {
    memset(&stru_2AD9D80, 0, sizeof(stru_2AD9D80));
    stru_2AD9D80.type = FMOD_DSP_PARAMETER_TYPE_INT;
    FMOD_strcpy_safe(stru_2AD9D80.name, "Panning Mode", 16);
    FMOD_strcpy_safe(stru_2AD9D80.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD9D80.floatdesc.min = 0x200000000LL;
    stru_2AD9D80.description = "Output speaker mode";
    memset(&stru_2AD9D20, 0, sizeof(stru_2AD9D20));
    *(_OWORD *)(&stru_2AD9D80.datadesc + 2) = 2u;
    FMOD_strcpy_safe(stru_2AD9D20.name, "Stereo Position", 16);
    FMOD_strcpy_safe(stru_2AD9D20.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD9D20.floatdesc.min = 0x42C80000C2C80000LL;
    stru_2AD9D20.description = "Stereo pan position";
    memset(&stru_2AD9CC0, 0, sizeof(stru_2AD9CC0));
    stru_2AD9D20.intdesc.defaultval = 0;
    stru_2AD9D20.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    FMOD_strcpy_safe(stru_2AD9CC0.name, "Surr. Direction", 16);
    FMOD_strcpy_safe(stru_2AD9CC0.label, "Deg.", 16);
    *(_QWORD *)&stru_2AD9CC0.floatdesc.min = 0x43340000C3340000LL;
    stru_2AD9CC0.description = "Surround pan direction";
    memset(&stru_2AD9C60, 0, sizeof(stru_2AD9C60));
    stru_2AD9CC0.intdesc.defaultval = 0;
    stru_2AD9CC0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    FMOD_strcpy_safe(stru_2AD9C60.name, "Surr. Extent", 16);
    FMOD_strcpy_safe(stru_2AD9C60.label, "Deg.", 16);
    *(_QWORD *)&stru_2AD9C60.floatdesc.min = 0x43B4000000000000LL;
    stru_2AD9C60.description = "Surround pan extent";
    memset(&stru_2AD9C00, 0, sizeof(stru_2AD9C00));
    stru_2AD9C60.intdesc.defaultval = 1135869952;
    stru_2AD9C60.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    FMOD_strcpy_safe(stru_2AD9C00.name, "Surr. Rotation", 16);
    FMOD_strcpy_safe(stru_2AD9C00.label, "Deg.", 16);
    *(_QWORD *)&stru_2AD9C00.floatdesc.min = 0x43340000C3340000LL;
    stru_2AD9C00.description = "Surround pan rotation";
    memset(&stru_2AD9BA0, 0, sizeof(stru_2AD9BA0));
    stru_2AD9C00.intdesc.defaultval = 0;
    stru_2AD9C00.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    FMOD_strcpy_safe(stru_2AD9BA0.name, "Surr. LFE Level", 16);
    FMOD_strcpy_safe(stru_2AD9BA0.label, "dB", 16);
    *(_QWORD *)&stru_2AD9BA0.floatdesc.min = 0x41A00000C2A00000LL;
    stru_2AD9BA0.description = "Surround pan LFE level";
    memset(&stru_2AD9B40, 0, sizeof(stru_2AD9B40));
    stru_2AD9BA0.intdesc.defaultval = 0;
    stru_2AD9BA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    stru_2AD9B40.type = FMOD_DSP_PARAMETER_TYPE_INT;
    FMOD_strcpy_safe(stru_2AD9B40.name, "Stereo-Surround Mode", 16);
    FMOD_strcpy_safe(stru_2AD9B40.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD9B40.floatdesc.min = 0x100000000LL;
    stru_2AD9B40.description = "Stereo-To-Surround Mode";
    memset(&stru_2AD9AE0, 0, sizeof(stru_2AD9AE0));
    *(_OWORD *)(&stru_2AD9B40.datadesc + 2) = 1u;
    FMOD_strcpy_safe(stru_2AD9AE0.name, "Surr. Stereo Separation", 16);
    FMOD_strcpy_safe(stru_2AD9AE0.label, "Deg.", 16);
    *(_QWORD *)&stru_2AD9AE0.floatdesc.min = 0x43340000C3340000LL;
    stru_2AD9AE0.description = "Stereo-To-Surround Stereo Separation";
    memset(&stru_2AD9A80, 0, sizeof(stru_2AD9A80));
    stru_2AD9AE0.intdesc.defaultval = 1114636288;
    stru_2AD9AE0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    FMOD_strcpy_safe(stru_2AD9A80.name, "Surr. Stereo Axis", 16);
    FMOD_strcpy_safe(stru_2AD9A80.label, "Deg.", 16);
    *(_QWORD *)&stru_2AD9A80.floatdesc.min = 0x43340000C3340000LL;
    stru_2AD9A80.description = "Stereo-To-Surround Stereo Axis";
    memset(&stru_2AD9A20, 0, sizeof(stru_2AD9A20));
    stru_2AD9A80.intdesc.defaultval = 0;
    stru_2AD9A80.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    stru_2AD9A20.type = FMOD_DSP_PARAMETER_TYPE_INT;
    FMOD_strcpy_safe(stru_2AD9A20.name, "Surr. Speakers Enabled", 16);
    FMOD_strcpy_safe(stru_2AD9A20.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD9A20.floatdesc.min = 0xFFF00000000LL;
    stru_2AD9A20.description = "Surround Speakers Enabled";
    memset(&stru_2AD99C0, 0, sizeof(stru_2AD99C0));
    *(_OWORD *)(&stru_2AD9A20.datadesc + 2) = 0xFFFu;
    stru_2AD99C0.type = FMOD_DSP_PARAMETER_TYPE_DATA;
    FMOD_strcpy_safe(stru_2AD99C0.name, "3D Position", 16);
    FMOD_strcpy_safe(stru_2AD99C0.label, "Deg.", 16);
    stru_2AD99C0.intdesc.min = -5;
    stru_2AD99C0.description = "3D Position";
    memset(&stru_2AD9960, 0, sizeof(stru_2AD9960));
    stru_2AD9960.type = FMOD_DSP_PARAMETER_TYPE_INT;
    FMOD_strcpy_safe(stru_2AD9960.name, "3D Rolloff", 16);
    FMOD_strcpy_safe(stru_2AD9960.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD9960.floatdesc.min = 0x400000000LL;
    stru_2AD9960.description = "3D Rolloff";
    memset(&stru_2AD9900, 0, sizeof(stru_2AD9900));
    *(_OWORD *)(&stru_2AD9960.datadesc + 2) = 0u;
    FMOD_strcpy_safe(stru_2AD9900.name, "3D Min Distance", 16);
    FMOD_strcpy_safe(stru_2AD9900.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD9900.floatdesc.min = 0x5D5E0B6B00000000LL;
    stru_2AD9900.description = "3D Min Distance";
    memset(&stru_2AD98A0, 0, sizeof(stru_2AD98A0));
    stru_2AD9900.intdesc.defaultval = 1065353216;
    stru_2AD9900.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    FMOD_strcpy_safe(stru_2AD98A0.name, "3D Max Distance", 16);
    FMOD_strcpy_safe(stru_2AD98A0.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD98A0.floatdesc.min = 0x5D5E0B6B00000000LL;
    stru_2AD98A0.description = "3D Max Distance";
    memset(&stru_2AD9840, 0, sizeof(stru_2AD9840));
    stru_2AD98A0.intdesc.defaultval = 1101004800;
    stru_2AD98A0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    stru_2AD9840.type = FMOD_DSP_PARAMETER_TYPE_INT;
    FMOD_strcpy_safe(stru_2AD9840.name, "3D Extent Mode", 16);
    FMOD_strcpy_safe(stru_2AD9840.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD9840.floatdesc.min = 0x200000000LL;
    stru_2AD9840.description = "3D Extent Mode";
    memset(&stru_2AD97E0, 0, sizeof(stru_2AD97E0));
    *(_OWORD *)(&stru_2AD9840.datadesc + 2) = 0u;
    FMOD_strcpy_safe(stru_2AD97E0.name, "3D Sound Size", 16);
    FMOD_strcpy_safe(stru_2AD97E0.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD97E0.floatdesc.min = 0x5D5E0B6B00000000LL;
    stru_2AD97E0.description = "3D Sound Size";
    memset(&stru_2AD9780, 0, sizeof(stru_2AD9780));
    stru_2AD97E0.intdesc.defaultval = 0;
    stru_2AD97E0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    FMOD_strcpy_safe(stru_2AD9780.name, "3D Min Extent", 16);
    FMOD_strcpy_safe(stru_2AD9780.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD9780.floatdesc.min = 0x43B4000000000000LL;
    stru_2AD9780.description = "3D Min Extent";
    memset(&stru_2AD9720, 0, sizeof(stru_2AD9720));
    stru_2AD9780.intdesc.defaultval = 0;
    stru_2AD9780.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    FMOD_strcpy_safe(stru_2AD9720.name, "3D Pan Blend", 16);
    FMOD_strcpy_safe(stru_2AD9720.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD9720.floatdesc.min = 0x3F80000000000000LL;
    stru_2AD9720.description = "3D Pan Blend";
    memset(&stru_2AD96C0, 0, sizeof(stru_2AD96C0));
    stru_2AD9720.intdesc.defaultval = 0;
    stru_2AD9720.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    stru_2AD96C0.type = FMOD_DSP_PARAMETER_TYPE_INT;
    FMOD_strcpy_safe(stru_2AD96C0.name, "LFE Upmix Enabled", 16);
    FMOD_strcpy_safe(stru_2AD96C0.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD96C0.floatdesc.min = 0x100000000LL;
    stru_2AD96C0.description = "LFE Upmix Enabled";
    memset(&stru_2AD9660, 0, sizeof(stru_2AD9660));
    *(_OWORD *)(&stru_2AD96C0.datadesc + 2) = 0u;
    stru_2AD9660.type = FMOD_DSP_PARAMETER_TYPE_DATA;
    FMOD_strcpy_safe(stru_2AD9660.name, "Overall Gain", 16);
    FMOD_strcpy_safe(stru_2AD9660.label, (const char *)&uri_string, 16);
    stru_2AD9660.intdesc.min = -1;
    stru_2AD9660.description = "Overall Gain";
    memset(&stru_2AD9600, 0, sizeof(stru_2AD9600));
    stru_2AD9600.type = FMOD_DSP_PARAMETER_TYPE_INT;
    FMOD_strcpy_safe(stru_2AD9600.name, "Output Speaker Mode", 16);
    FMOD_strcpy_safe(stru_2AD9600.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD9600.floatdesc.min = 0x800000000LL;
    stru_2AD9600.description = "Target speaker mode for surround panning";
    memset(&stru_2AD95A0, 0, sizeof(stru_2AD95A0));
    *(_OWORD *)(&stru_2AD9600.datadesc + 2) = 0u;
    FMOD_strcpy_safe(stru_2AD95A0.name, "Height Blend", 16);
    FMOD_strcpy_safe(stru_2AD95A0.label, (const char *)&uri_string, 16);
    *(_QWORD *)&stru_2AD95A0.floatdesc.min = 0x3F800000BF800000LL;
    stru_2AD95A0.intdesc.defaultval = 0;
    stru_2AD95A0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    stru_2AD95A0.description = "Surround pan height blend";
    *(&stru_2AD9560.mHandle + 1) = 27;
    stru_2AD9560.mSize = 1056;
    stru_2AD9560.mDescription = &stru_286ABE0;
    stru_2AD9560.mCommand = FMOD::DSPPanner::commandCallback;
    stru_2AD9560.mCommandMask = 67;
  }
  return &stru_2AD9560;
}


// Address: 0x21d8440 | Name: _ZN4FMOD9DSPPanner15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::releaseInternal(FMOD::DSPPanner *const this)
{
  _QWORD *v1; // rdx
  FMOD::ChannelLayout *v3; // rdi
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelLayout *v5; // rdi
  FMOD::ChannelLayout *v6; // rdi
  FMOD::DSPConnectionI *v7; // rsi

  v1 = (_QWORD *)*((_QWORD *)this + 103);
  *v1 = *((_QWORD *)this + 102);
  *(_QWORD *)(*((_QWORD *)this + 102) + 8LL) = v1;
  *((_QWORD *)this + 103) = (char *)this + 816;
  *((_QWORD *)this + 102) = (char *)this + 816;
  v3 = (FMOD::ChannelLayout *)*((_QWORD *)this + 72);
  if ( v3 )
  {
    result = FMOD::ChannelLayout::close(v3);
    if ( result )
      return result;
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      *((void **)this + 72),
      "../../../core_api/src/fmod_dsp_pan.cpp",
      287);
    *((_QWORD *)this + 72) = 0;
  }
  v5 = (FMOD::ChannelLayout *)*((_QWORD *)this + 73);
  if ( v5 )
  {
    result = FMOD::ChannelLayout::close(v5);
    if ( result )
      return result;
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      *((void **)this + 73),
      "../../../core_api/src/fmod_dsp_pan.cpp",
      296);
    *((_QWORD *)this + 73) = 0;
  }
  v6 = (FMOD::ChannelLayout *)*((_QWORD *)this + 74);
  if ( v6 )
  {
    result = FMOD::ChannelLayout::close(v6);
    if ( result )
      return result;
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      *((void **)this + 74),
      "../../../core_api/src/fmod_dsp_pan.cpp",
      305);
    *((_QWORD *)this + 74) = 0;
  }
  v7 = (FMOD::DSPConnectionI *)*((_QWORD *)this + 66);
  result = FMOD_RESULT::FMOD_OK_0;
  if ( v7 )
  {
    result = FMOD::ExpandingPool<FMOD::DSPConnectionI>::free(
               (FMOD::ExpandingPool<FMOD::DSPConnectionI> *const)(*((_QWORD *)this + 22) + 1776LL),
               v7,
               1);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      *((_QWORD *)this + 66) = 0;
  }
  return result;
}


// Address: 0x21d85b0 | Name: _ZN4FMOD9DSPPanner15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPPanner::releaseInternal((FMOD::DSPPanner *const)dsp_state->instance);
}


// Address: 0x21d85c0 | Name: _ZN4FMOD9DSPPanner13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::resetInternal(FMOD::DSPPanner *const this)
{
  *((_BYTE *)this + 537) = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d85d0 | Name: _ZN4FMOD9DSPPanner13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPPanner::resetInternal((FMOD::DSPPanner *const)dsp_state->instance);
}


// Address: 0x21d85e0 | Name: _ZNK4FMOD9DSPPanner18inputChannelLayoutEv
const FMOD::ChannelLayout *__fastcall FMOD::DSPPanner::inputChannelLayout(const FMOD::DSPPanner *const this)
{
  const FMOD::ChannelLayout *layout; // [rsp+8h] [rbp-10h] BYREF

  FMOD::SystemI::getChannelLayout(*((FMOD::SystemI *const *)this + 22), *((FMOD_SPEAKERMODE_0 *)this + 140), &layout);
  return layout;
}


// Address: 0x21d8610 | Name: _ZNK4FMOD9DSPPanner17systemSpeakerModeEv
FMOD_SPEAKERMODE_0 __fastcall FMOD::DSPPanner::systemSpeakerMode(const FMOD::DSPPanner *const this)
{
  return *(_DWORD *)(*((_QWORD *)this + 22) + 71708LL);
}


// Address: 0x21d8620 | Name: _ZNK4FMOD9DSPPanner17outputSpeakerModeEPNS_20DSPPanner_ParametersE
FMOD_SPEAKERMODE_0 __fastcall FMOD::DSPPanner::outputSpeakerMode(
        const FMOD::DSPPanner *const this,
        FMOD::DSPPanner_Parameters *params)
{
  FMOD_SPEAKERMODE_0 result; // eax

  if ( params->mPanningMode == FMOD_DSP_PAN_MODE_MONO )
    return FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0;
  if ( params->mPanningMode == FMOD_DSP_PAN_MODE_STEREO )
    return FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0;
  result = params->mSurroundSpeakerMode;
  if ( result == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
    return FMOD::DSPPanner::systemSpeakerMode(this);
  return result;
}


// Address: 0x21d8650 | Name: _ZN4FMOD9DSPPanner23speakerModeChannelCountE16FMOD_SPEAKERMODE
int __fastcall FMOD::DSPPanner::speakerModeChannelCount(FMOD::DSPPanner *const this, FMOD_SPEAKERMODE_0 format)
{
  FMOD::SystemI *v2; // rdi
  int speakerCount[3]; // [rsp+Ch] [rbp-Ch] BYREF

  v2 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  speakerCount[0] = 0;
  FMOD::SystemI::getSpeakerModeChannels(v2, format, speakerCount);
  return speakerCount[0];
}


// Address: 0x21d8680 | Name: _ZN4FMOD9DSPPanner25pannerParametersAffectMixE16FMOD_SPEAKERMODEi
bool __fastcall FMOD::DSPPanner::pannerParametersAffectMix(
        FMOD::DSPPanner *const this,
        FMOD_SPEAKERMODE_0 inmode,
        int inchannels)
{
  int v3; // eax
  _BOOL4 v4; // eax
  int v5; // ebx
  unsigned int v6; // r13d

  if ( *((float *)this + 166) == 0.0 )
  {
    v3 = *((_DWORD *)this + 150);
    switch ( v3 )
    {
      case 1:
        if ( inmode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
        {
          LOBYTE(v4) = *((float *)this + 152) != 0.0;
          return v4;
        }
        break;
      case 2:
        v5 = 0;
        v6 = FMOD::ChannelLayout::speakerMaskToLayoutMask(*((_DWORD *)this + 169), *((FMOD_SPEAKERMODE_0 *)this + 151));
        while ( v5 < FMOD::DSPPanner::speakerModeChannelCount(this, *((FMOD_SPEAKERMODE_0 *)this + 151)) )
        {
          if ( (v6 & (1 << v5)) == 0 )
            goto LABEL_5;
          ++v5;
        }
        if ( (inmode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0
           || *(_DWORD *)(*((_QWORD *)this + 22) + 71708LL) == inmode)
          && *((float *)this + 154) == 360.0
          && *((float *)this + 155) == 0.0 )
        {
          LOBYTE(v4) = *((float *)this + 156) != 0.0;
          return v4;
        }
        break;
      case 0:
        return inmode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0;
    }
  }
LABEL_5:
  LOBYTE(v4) = 1;
  return v4;
}


// Address: 0x21d87a0 | Name: _ZNK4FMOD9DSPPanner20sumSurroundPanMatrixEPKNS_13ChannelLayoutEPfifffff32FMOD_DSP_PAN_2D_STEREO_MODE_TYPEff
void __fastcall FMOD::DSPPanner::sumSurroundPanMatrix(
        const FMOD::DSPPanner *const this,
        const FMOD::ChannelLayout *outputLayout,
        float *matrix,
        int matrixHop,
        float direction,
        float extent,
        float rotation,
        float stereoSeparation,
        float stereoAxis,
        FMOD_DSP_PAN_2D_STEREO_MODE_TYPE stereoMode,
        float lfe,
        float gain)
{
  float *v12; // r12
  int v15; // eax
  const FMOD::ChannelLayout *v16; // rax
  int v17; // esi
  float v18; // xmm7_4
  float v19; // xmm3_4
  float v20; // xmm2_4
  float directiona; // [rsp+Ch] [rbp-2Ch]

  v12 = matrix;
  v15 = *((_DWORD *)this + 140);
  if ( v15 == 2 )
  {
    v17 = matrixHop;
    v19 = gain;
    v20 = lfe;
  }
  else
  {
    if ( v15 != 3 )
    {
      v16 = FMOD::DSPPanner::inputChannelLayout(this);
      FMOD::ChannelLayout::sumSurroundMatrix(
        v16,
        outputLayout,
        direction,
        extent,
        rotation,
        lfe,
        gain,
        matrixHop,
        v12,
        FMOD_DSP_PAN_SURROUND_FLAGS::FMOD_DSP_PAN_SURROUND_DEFAULT);
      return;
    }
    if ( stereoMode != FMOD_DSP_PAN_2D_STEREO_MODE_DISCRETE )
    {
      FMOD::ChannelLayout::sumStereoToSurroundMatrix(
        outputLayout,
        direction,
        extent,
        rotation,
        lfe,
        gain,
        matrixHop,
        matrix);
      return;
    }
    directiona = lfe / 1.4142135;
    FMOD::ChannelLayout::sumSurroundMatrixMono(
      outputLayout,
      stereoAxis - (float)(0.5 * stereoSeparation),
      0.0,
      lfe / 1.4142135,
      gain,
      matrixHop,
      matrix);
    matrix = v12 + 1;
    v17 = matrixHop;
    v18 = (float)(0.5 * stereoSeparation) + stereoAxis;
    extent = 0.0;
    v19 = gain;
    v20 = directiona;
    direction = v18;
  }
  FMOD::ChannelLayout::sumSurroundMatrixMono(outputLayout, direction, extent, v20, v19, v17, matrix);
}


// Address: 0x21d88f0 | Name: _ZN4FMOD9DSPPanner23calculate3DDistanceGainEf
float __fastcall FMOD::DSPPanner::calculate3DDistanceGain(
        FMOD::DSPPanner *const this,
        double a2,
        float distance,
        double a4,
        double a5,
        float a6)
{
  float gain[3]; // [rsp+Ch] [rbp-Ch] BYREF

  FMOD::getRolloffGain(
    *((FMOD_DSP_PAN_3D_ROLLOFF_TYPE *)this + 161),
    *((float *)this + 162),
    *((float *)this + 163),
    *(float *)((char *)&stru_11358.r_offset + *((_QWORD *)this + 22)),
    gain,
    a6);
  return gain[0];
}


// Address: 0x21d8940 | Name: _ZNK4FMOD9DSPPanner31extentFor3DDistanceAndSoundSizeEff
float __fastcall FMOD::DSPPanner::extentFor3DDistanceAndSoundSize(
        const FMOD::DSPPanner *const this,
        float a2,
        float distance,
        float soundsize)
{
  if ( distance <= 0.0 || (float)(5.0 * distance) <= a2 )
    return 0.0;
  else
    return 360.0 / (float)((float)((float)((float)(a2 * a2) / (float)(distance * distance)) * 4.0) + 1.0);
}


// Address: 0x21d8990 | Name: _ZN4FMOD9DSPPanner17calculate3DExtentEf
float __fastcall FMOD::DSPPanner::calculate3DExtent(FMOD::DSPPanner *const this, float a2, float distance)
{
  float v3; // xmm2_4
  int v4; // eax
  float v6; // xmm1_4
  float v7; // [rsp+Ch] [rbp-Ch]

  v3 = a2;
  v4 = *((_DWORD *)this + 164);
  if ( v4 )
  {
    if ( v4 != 1 )
      return 0.0;
    v7 = *((float *)this + 167);
    v3 = a2;
    if ( v7 > FMOD::DSPPanner::extentFor3DDistanceAndSoundSize(this, a2, *((float *)this + 165), a2) )
      return *((float *)this + 167);
    v6 = *((float *)this + 165);
  }
  else
  {
    v6 = *((float *)this + 162) + *((float *)this + 162);
  }
  return FMOD::DSPPanner::extentFor3DDistanceAndSoundSize(this, v3, v6, v3);
}


// Address: 0x21d8a30 | Name: _ZN4FMOD9DSPPanner25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPPanner::setParameterFloatInternal(
        FMOD::DSPPanner *const this,
        int index,
        float a3,
        float value)
{
  _QWORD *v4; // rdx
  __int64 v5; // rcx
  __int64 v6; // rdx

  switch ( index )
  {
    case 1:
      if ( a3 == *((float *)this + 212) )
        return 0;
      *((float *)this + 212) = a3;
      break;
    case 2:
      if ( a3 == *((float *)this + 213) )
        return 0;
      *((float *)this + 213) = a3;
      break;
    case 3:
      if ( a3 == *((float *)this + 214) )
        return 0;
      *((float *)this + 214) = a3;
      break;
    case 4:
      if ( a3 == *((float *)this + 215) )
        return 0;
      *((float *)this + 215) = a3;
      break;
    case 5:
      if ( a3 == *((float *)this + 216) )
        return 0;
      *((float *)this + 216) = a3;
      break;
    case 7:
      if ( a3 == *((float *)this + 218) )
        return 0;
      *((float *)this + 218) = a3;
      break;
    case 8:
      if ( a3 == *((float *)this + 219) )
        return 0;
      *((float *)this + 219) = a3;
      break;
    case 12:
      if ( a3 == *((float *)this + 222) )
        return 0;
      *((float *)this + 222) = a3;
      break;
    case 13:
      if ( a3 == *((float *)this + 223) )
        return 0;
      *((float *)this + 223) = a3;
      break;
    case 15:
      if ( a3 == *((float *)this + 225) )
        return 0;
      *((float *)this + 225) = a3;
      break;
    case 16:
      if ( a3 == *((float *)this + 227) )
        return 0;
      *((float *)this + 227) = a3;
      break;
    case 17:
      if ( a3 == *((float *)this + 226) )
        return 0;
      *((float *)this + 226) = a3;
      break;
    case 21:
      if ( a3 == *((float *)this + 220) )
        return 0;
      *((float *)this + 220) = a3;
      break;
    default:
      return 31;
  }
  v4 = (_QWORD *)*((_QWORD *)this + 103);
  v5 = *((_QWORD *)this + 102);
  *((_BYTE *)this + 536) = 1;
  *v4 = v5;
  *(_QWORD *)(*((_QWORD *)this + 102) + 8LL) = v4;
  v6 = *((_QWORD *)this + 22);
  *((_QWORD *)this + 103) = (char *)this + 816;
  *((_QWORD *)this + 103) = *(_QWORD *)(v6 + 69568);
  *((_QWORD *)this + 102) = v6 + 69560;
  *(_QWORD *)(v6 + 69568) = (char *)this + 816;
  **((_QWORD **)this + 103) = (char *)this + 816;
  return 0;
}


// Address: 0x21d8c60 | Name: _ZN4FMOD9DSPPanner25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPPanner::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPPanner::setParameterFloatInternal((FMOD::DSPPanner *const)dsp_state->instance, index, a3, value);
}


// Address: 0x21d8c70 | Name: _ZN4FMOD9DSPPanner25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::getParameterFloatInternal(
        FMOD::DSPPanner *const this,
        int index,
        float *value,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( value )
  {
    switch ( index )
    {
      case 1:
        *value = *((float *)this + 212);
        goto LABEL_6;
      case 2:
        *value = *((float *)this + 213);
        goto LABEL_6;
      case 3:
        *value = *((float *)this + 214);
        goto LABEL_6;
      case 4:
        *value = *((float *)this + 215);
        goto LABEL_6;
      case 5:
        *value = *((float *)this + 216);
        goto LABEL_6;
      case 7:
        *value = *((float *)this + 218);
        goto LABEL_6;
      case 8:
        *value = *((float *)this + 219);
        goto LABEL_6;
      case 12:
        *value = *((float *)this + 222);
        goto LABEL_6;
      case 13:
        *value = *((float *)this + 223);
        goto LABEL_6;
      case 15:
        *value = *((float *)this + 225);
        goto LABEL_6;
      case 16:
        *value = *((float *)this + 227);
        goto LABEL_6;
      case 17:
        *value = *((float *)this + 226);
        goto LABEL_6;
      case 21:
        *value = *((float *)this + 220);
LABEL_6:
        if ( valuestr )
        {
          *valuestr = 0;
          result = FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          result = FMOD_RESULT::FMOD_OK_0;
        }
        break;
      default:
        result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        break;
    }
  }
  return result;
}


// Address: 0x21d8db0 | Name: _ZN4FMOD9DSPPanner25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPPanner::getParameterFloatInternal((FMOD::DSPPanner *const)dsp_state->instance, index, value, valuestr);
}


// Address: 0x21d8dc0 | Name: _ZN4FMOD9DSPPanner23setParameterIntInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::setParameterIntInternal(FMOD::DSPPanner *const this, int index, int value)
{
  FMOD_RESULT_0 result; // eax
  _QWORD *v4; // rdx
  __int64 v5; // rcx
  __int64 v6; // rdx
  char v7; // dl

  switch ( index )
  {
    case 0:
      result = FMOD_RESULT::FMOD_OK_0;
      if ( *((_DWORD *)this + 210) != value )
      {
        *((_DWORD *)this + 210) = value;
        goto LABEL_4;
      }
      break;
    case 6:
      result = FMOD_RESULT::FMOD_OK_0;
      if ( *((_DWORD *)this + 217) != value )
      {
        *((_DWORD *)this + 217) = value;
        goto LABEL_4;
      }
      break;
    case 9:
      result = FMOD_RESULT::FMOD_OK_0;
      if ( *((_DWORD *)this + 229) != value )
      {
        *((_DWORD *)this + 229) = value;
        goto LABEL_4;
      }
      break;
    case 11:
      result = FMOD_RESULT::FMOD_OK_0;
      if ( *((_DWORD *)this + 221) != value )
      {
        *((_DWORD *)this + 221) = value;
        goto LABEL_4;
      }
      break;
    case 14:
      result = FMOD_RESULT::FMOD_OK_0;
      if ( *((_DWORD *)this + 224) != value )
      {
        *((_DWORD *)this + 224) = value;
        goto LABEL_4;
      }
      break;
    case 18:
      v7 = value != 0;
      result = FMOD_RESULT::FMOD_OK_0;
      if ( *((_BYTE *)this + 912) != v7 )
      {
        *((_BYTE *)this + 912) = v7;
        goto LABEL_4;
      }
      break;
    case 20:
      result = FMOD_RESULT::FMOD_OK_0;
      if ( *((_DWORD *)this + 211) != value )
      {
        *((_DWORD *)this + 211) = value;
LABEL_4:
        v4 = (_QWORD *)*((_QWORD *)this + 103);
        v5 = *((_QWORD *)this + 102);
        *((_BYTE *)this + 536) = 1;
        *v4 = v5;
        *(_QWORD *)(*((_QWORD *)this + 102) + 8LL) = v4;
        v6 = *((_QWORD *)this + 22);
        *((_QWORD *)this + 103) = (char *)this + 816;
        *((_QWORD *)this + 103) = *(_QWORD *)(v6 + 69568);
        *((_QWORD *)this + 102) = v6 + 69560;
        *(_QWORD *)(v6 + 69568) = (char *)this + 816;
        **((_QWORD **)this + 103) = (char *)this + 816;
        result = FMOD_RESULT::FMOD_OK_0;
      }
      break;
    default:
      result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      break;
  }
  return result;
}


// Address: 0x21d8f10 | Name: _ZN4FMOD9DSPPanner23setParameterIntCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::setParameterIntCallback(FMOD_DSP_STATE *dsp_state, int index, int value)
{
  return FMOD::DSPPanner::setParameterIntInternal((FMOD::DSPPanner *const)dsp_state->instance, index, value);
}


// Address: 0x21d8f20 | Name: _ZN4FMOD9DSPPanner23getParameterIntInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::getParameterIntInternal(
        FMOD::DSPPanner *const this,
        int index,
        int *value,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( value )
  {
    switch ( index )
    {
      case 0:
        *value = *((_DWORD *)this + 210);
        goto LABEL_6;
      case 6:
        *value = *((_DWORD *)this + 217);
        goto LABEL_6;
      case 9:
        *value = *((_DWORD *)this + 229);
        goto LABEL_6;
      case 11:
        *value = *((_DWORD *)this + 221);
        goto LABEL_6;
      case 14:
        *value = *((_DWORD *)this + 224);
        goto LABEL_6;
      case 18:
        *value = *((unsigned __int8 *)this + 912);
        goto LABEL_6;
      case 20:
        *value = *((_DWORD *)this + 211);
LABEL_6:
        if ( valuestr )
        {
          *valuestr = 0;
          result = FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          result = FMOD_RESULT::FMOD_OK_0;
        }
        break;
      default:
        result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        break;
    }
  }
  return result;
}


// Address: 0x21d8fe0 | Name: _ZN4FMOD9DSPPanner23getParameterIntCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::getParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int *value,
        char *valuestr)
{
  return FMOD::DSPPanner::getParameterIntInternal((FMOD::DSPPanner *const)dsp_state->instance, index, value, valuestr);
}


// Address: 0x21d8ff0 | Name: _ZN4FMOD9DSPPanner21calculateListenerInfoEPK37FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTIPNS_22DSPPanner_ListenerInfoE
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::calculateListenerInfo(
        FMOD::DSPPanner *const this,
        const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *attributes3d,
        FMOD::DSPPanner_ListenerInfo *outinfo)
{
  FMOD::DSPPanner_ListenerInfo *v3; // rdi
  unsigned int v5; // esi
  __int64 v6; // rcx
  _DWORD *v7; // rdi
  int numlisteners; // ebx
  float *v9; // r15
  const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *v10; // r14
  int v11; // r12d
  int v12; // ecx
  int v13; // eax
  __int64 v14; // rsi
  int v15; // edi
  float v16; // xmm2_4
  int *v17; // rax
  __int64 v18; // rdi
  float v19; // xmm3_4
  float x; // xmm0_4
  float z; // xmm1_4
  float v22; // xmm0_4
  float v23; // xmm0_4
  float v24; // xmm1_4
  float v25; // xmm0_4
  FMOD::DSPPanner_ListenerInfo *v27; // r12
  __int64 v28; // r15
  __int64 v29; // r14
  char *v30; // rdx
  char *v31; // rax
  float v32; // xmm0_4
  const FMOD_VECTOR *v33; // rcx
  float v34; // xmm1_4
  float v35; // xmm0_4
  float v36; // xmm0_4
  float v37; // xmm1_4
  FMOD::DSPPanner_ListenerInfo *direction; // [rsp+8h] [rbp-90h]
  FMOD::DSPPanner_ListenerInfo *directiona; // [rsp+8h] [rbp-90h]
  const FMOD_VECTOR *directionb; // [rsp+8h] [rbp-90h]
  char *distance; // [rsp+10h] [rbp-88h]
  float listenerDist[8]; // [rsp+20h] [rbp-78h] BYREF
  int listenerSortedList[22]; // [rsp+40h] [rbp-58h] BYREF

  v3 = outinfo;
  v5 = 128;
  if ( ((unsigned __int8)outinfo & 1) == 0 )
  {
    if ( ((unsigned __int8)outinfo & 2) == 0 )
      goto LABEL_3;
LABEL_40:
    v3 = (FMOD::DSPPanner_ListenerInfo *)((char *)v3 + 2);
    v5 -= 2;
    HIWORD(v3[-1].m3DDistance) = 0;
    if ( ((unsigned __int8)v3 & 4) == 0 )
      goto LABEL_4;
    goto LABEL_41;
  }
  v3 = (FMOD::DSPPanner_ListenerInfo *)((char *)&outinfo->mWeight + 1);
  LOBYTE(outinfo->mWeight) = 0;
  LOBYTE(v5) = 127;
  if ( (((_BYTE)outinfo + 1) & 2) != 0 )
    goto LABEL_40;
LABEL_3:
  if ( ((unsigned __int8)v3 & 4) == 0 )
    goto LABEL_4;
LABEL_41:
  v3->mWeight = 0.0;
  v5 -= 4;
  v3 = (FMOD::DSPPanner_ListenerInfo *)((char *)v3 + 4);
LABEL_4:
  v6 = v5 >> 3;
  memset(v3, 0, 8 * v6);
  v7 = (_DWORD *)(&v3->mWeight + 2 * v6);
  if ( (v5 & 4) != 0 )
    *v7++ = 0;
  if ( (v5 & 2) != 0 )
  {
    v7 = (_DWORD *)((char *)v7 + 2);
    *((_WORD *)v7 - 1) = 0;
  }
  if ( (v5 & 1) != 0 )
    *(_BYTE *)v7 = 0;
  numlisteners = attributes3d->numlisteners;
  if ( attributes3d->numlisteners == 1 )
  {
    v19 = fsqrt(
            (float)((float)(attributes3d->relative[0].position.x * attributes3d->relative[0].position.x)
                  + (float)(attributes3d->relative[0].position.y * attributes3d->relative[0].position.y))
          + (float)(attributes3d->relative[0].position.z * attributes3d->relative[0].position.z));
    x = attributes3d->relative[0].position.x;
    z = attributes3d->relative[0].position.z;
    if ( x != 0.0 || z != 0.0 )
    {
      direction = outinfo;
      v22 = atan2f(x, z);
      outinfo = direction;
      direction->m3DAngle = (float)(v22 * 180.0) / 3.1415927;
    }
    v23 = attributes3d->relative[0].forward.x;
    v24 = attributes3d->relative[0].forward.z;
    if ( v23 != 0.0 || v24 != 0.0 )
    {
      directiona = outinfo;
      v25 = atan2f(v23, v24);
      outinfo = directiona;
      directiona->m3DOrientation = (float)(v25 * 180.0) / 3.1415927;
    }
    outinfo->m3DDistance = v19;
    outinfo->mWeight = 1.0;
  }
  else if ( numlisteners > 0 )
  {
    listenerDist[0] = fsqrt(
                        (float)((float)(attributes3d->relative[0].position.x * attributes3d->relative[0].position.x)
                              + (float)(attributes3d->relative[0].position.y * attributes3d->relative[0].position.y))
                      + (float)(attributes3d->relative[0].position.z * attributes3d->relative[0].position.z));
    v9 = &listenerDist[1];
    v10 = attributes3d;
    v11 = 0;
    v12 = 0;
    while ( 1 )
    {
      v13 = v11 - 1;
      if ( v12 <= v11 - 1 )
      {
        do
        {
          v14 = v13;
          v15 = v13-- + 1;
          listenerSortedList[v15] = listenerSortedList[v14];
        }
        while ( v13 != v12 - 1 );
      }
      listenerSortedList[v12] = v11++;
      if ( v11 == numlisteners )
        break;
      v16 = fsqrt(
              (float)((float)(v10->relative[1].position.x * v10->relative[1].position.x)
                    + (float)(v10->relative[1].position.y * v10->relative[1].position.y))
            + (float)(v10->relative[1].position.z * v10->relative[1].position.z));
      *v9 = v16;
      if ( v11 <= 0 || listenerDist[listenerSortedList[0]] > v16 )
      {
        v12 = 0;
        v10 = (const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *)((char *)v10 + 48);
        ++v9;
      }
      else
      {
        v17 = &listenerSortedList[1];
        v12 = 0;
        do
        {
          if ( ++v12 == v11 )
            break;
          v18 = *v17++;
        }
        while ( listenerDist[v18] <= v16 );
        v10 = (const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *)((char *)v10 + 48);
        ++v9;
      }
    }
    v27 = outinfo;
    v28 = 0;
    do
    {
      v29 = listenerSortedList[v28];
      v30 = (char *)attributes3d + 48 * v29;
      v31 = v30 + 16;
      v32 = *((float *)v30 + 1);
      v33 = (const FMOD_VECTOR *)(v30 + 28);
      v34 = *((float *)v30 + 3);
      if ( v32 != 0.0 || v34 != 0.0 )
      {
        distance = v30 + 16;
        directionb = (const FMOD_VECTOR *)(v30 + 28);
        v35 = atan2f(v32, v34);
        v31 = distance;
        v33 = directionb;
        v27->m3DAngle = (float)(v35 * 180.0) / 3.1415927;
      }
      v36 = *((float *)v31 + 3);
      v37 = v33->z;
      if ( v36 != 0.0 || v37 != 0.0 )
        v27->m3DOrientation = (float)(atan2f(v36, v37) * 180.0) / 3.1415927;
      ++v28;
      ++v27;
      v27[-1].m3DDistance = listenerDist[v29];
      v27[-1].mWeight = attributes3d->weight[v29];
    }
    while ( numlisteners > (int)v28 );
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d9440 | Name: _ZN4FMOD9DSPPanner24setParameterDataInternalEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::setParameterDataInternal(
        FMOD::DSPPanner *const this,
        int index,
        void *data,
        unsigned int length)
{
  FMOD_RESULT_0 result; // eax
  int v6; // ebp
  _QWORD *v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // rdx
  FMOD::DSPPanner_ListenerInfo newListeners[8]; // [rsp+0h] [rbp-A8h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index == 10 )
  {
    if ( length == 468 )
    {
      result = FMOD::DSPPanner::calculateListenerInfo(
                 this,
                 (const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *)data,
                 newListeners);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v6 = *(_DWORD *)data;
        if ( *((_DWORD *)this + 230) == v6 && !memcmp(newListeners, (char *)this + 924, 16LL * v6) )
        {
          return FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          *((_DWORD *)this + 230) = v6;
          memcpy_0((char *)this + 924, newListeners, 16LL * v6);
          v7 = (_QWORD *)*((_QWORD *)this + 103);
          v8 = *((_QWORD *)this + 102);
          *((_BYTE *)this + 536) = 1;
          *v7 = v8;
          *(_QWORD *)(*((_QWORD *)this + 102) + 8LL) = v7;
          v9 = *((_QWORD *)this + 22);
          *((_QWORD *)this + 103) = (char *)this + 816;
          *((_QWORD *)this + 103) = *(_QWORD *)(v9 + 69568);
          *((_QWORD *)this + 102) = v9 + 69560;
          *(_QWORD *)(v9 + 69568) = (char *)this + 816;
          **((_QWORD **)this + 103) = (char *)this + 816;
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  else if ( index == 19 )
  {
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21d9560 | Name: _ZN4FMOD9DSPPanner24setParameterDataCallbackEP14FMOD_DSP_STATEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::setParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void *data,
        unsigned int length)
{
  return FMOD::DSPPanner::setParameterDataInternal((FMOD::DSPPanner *const)dsp_state->instance, index, data, length);
}


// Address: 0x21d9570 | Name: _ZN4FMOD9DSPPanner24getParameterDataInternalEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::getParameterDataInternal(
        FMOD::DSPPanner *const this,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  float v5; // xmm4_4

  if ( index != 19 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  FMOD::getRolloffGain(
    *((FMOD_DSP_PAN_3D_ROLLOFF_TYPE *)this + 221),
    *((float *)this + 222),
    *((float *)this + 223),
    *(float *)((char *)&stru_11358.r_offset + *((_QWORD *)this + 22)),
    (float *)this + 136,
    v5);
  *((float *)this + 136) = (float)(1.0 - *((float *)this + 226))
                         + (float)(*((float *)this + 226) * *((float *)this + 136));
  *data = (char *)this + 544;
  *length = 8;
  if ( valuestr )
    *valuestr = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d9640 | Name: _ZN4FMOD9DSPPanner24getParameterDataCallbackEP14FMOD_DSP_STATEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::getParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  return FMOD::DSPPanner::getParameterDataInternal(
           (FMOD::DSPPanner *const)dsp_state->instance,
           index,
           data,
           length,
           valuestr);
}


// Address: 0x21d9650 | Name: _ZN4FMOD9DSPPanner16updateParametersEPNS_20DSPPanner_ParametersEbb
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::updateParameters(
        FMOD::DSPPanner *const this,
        FMOD::DSPPanner_Parameters *newparams,
        bool frommixer,
        bool calcpanmatrix)
{
  float v4; // xmm1_4
  float v5; // xmm2_4
  double v6; // xmm3_8
  FMOD::DSPPanner_Parameters *v7; // r10
  bool deferred; // r12
  FMOD::DSPPanner_Parameters *v10; // rbp
  bool v12; // r11
  int v13; // eax
  bool v14; // r15
  bool v15; // r14
  _WORD *v16; // rdi
  unsigned int v17; // eax
  __int64 v18; // rdx
  __int64 v19; // rcx
  _DWORD *v20; // rdi
  _DWORD *v21; // rsi
  FMOD_SPEAKERMODE_0 v22; // esi
  int v23; // eax
  FMOD::ChannelLayout *v24; // rdi
  bool v25; // r11
  FMOD::DSPPanner_Parameters *v26; // r10
  FMOD_RESULT_0 result; // eax
  const FMOD::ChannelLayout *v28; // rbp
  FMOD::ChannelLayout *v29; // rdi
  int v30; // eax
  FMOD_SPEAKERMODE_0 v31; // eax
  float v32; // xmm0_4
  int v33; // eax
  float v34; // xmm4_4
  double v35; // xmm2_8
  int v36; // edx
  float v37; // xmm4_4
  FMOD::DSPPanner *v38; // r14
  double v39; // xmm3_8
  __int64 v40; // r13
  float v41; // xmm1_4
  float v42; // xmm0_4
  float v43; // xmm5_4
  __int64 v44; // r13
  float *v45; // r14
  float v46; // xmm6_4
  FMOD_SPEAKERMODE_0 v47; // esi
  FMOD::SystemI *v48; // rdi
  unsigned int v49; // ebp
  __int64 v50; // rax
  FMOD::ChannelLayout *v51; // rdi
  FMOD::ChannelLayout *v52; // rdi
  FMOD::ChannelLayout *v53; // rdi
  const FMOD::ChannelLayout *v54; // rsi
  FMOD::ChannelLayout *v55; // rdi
  float v56; // xmm1_4
  const FMOD::ChannelLayout *v57; // rax
  float *v58; // rsi
  const FMOD::ChannelLayout *v59; // rax
  __int16 mPanningMode; // dx
  FMOD_DSP_PAN_MODE_TYPE v61; // edx
  int v62; // r8d
  float v63; // xmm2_4
  float *v64; // rcx
  int v65; // edx
  float *v66; // rdi
  __int64 v67; // rax
  float v68; // xmm1_4
  float v69; // xmm0_4
  float v70; // xmm1_4
  int v71; // esi
  float *v72; // rcx
  float *v73; // rax
  float *v74; // rdx
  float v75; // xmm0_4
  _DWORD *v76; // rax
  bool v77; // r14
  _DWORD *v78; // rax
  bool v79; // r13
  float v80; // xmm10_4
  float v81; // xmm8_4
  float v82; // xmm10_4
  float v83; // xmm9_4
  float v84; // xmm6_4
  float v85; // xmm6_4
  float v86; // xmm10_4
  float v87; // xmm8_4
  float v88; // xmm9_4
  float v89; // xmm0_4
  FMOD::ChannelLayout *v90; // rax
  FMOD::ChannelLayout *v91; // rax
  bool topToTopGain; // [rsp+14h] [rbp-2B4h]
  bool topToTopGaina; // [rsp+14h] [rbp-2B4h]
  bool topToTopGainc; // [rsp+14h] [rbp-2B4h]
  bool topToTopGaind; // [rsp+14h] [rbp-2B4h]
  float topToTopGainb; // [rsp+14h] [rbp-2B4h]
  float topToTopGaine; // [rsp+14h] [rbp-2B4h]
  float topToTopGainf; // [rsp+14h] [rbp-2B4h]
  FMOD::DSPPanner_Parameters *lfe; // [rsp+18h] [rbp-2B0h]
  FMOD::DSPPanner_Parameters *lfea; // [rsp+18h] [rbp-2B0h]
  FMOD::DSPPanner_Parameters *lfec; // [rsp+18h] [rbp-2B0h]
  float lfeb; // [rsp+18h] [rbp-2B0h]
  float lfeGain; // [rsp+2Ch] [rbp-29Ch]
  float distanceGains[8]; // [rsp+30h] [rbp-298h] BYREF
  _OWORD matrix_mem[39]; // [rsp+50h] [rbp-278h] BYREF

  v7 = (FMOD::DSPPanner_Parameters *)((char *)this + 600);
  deferred = !frommixer;
  v10 = newparams;
  if ( (FMOD::DSPPanner_Parameters *)((char *)this + 600) == newparams )
  {
    v15 = !frommixer;
    v14 = !frommixer;
    v12 = !frommixer;
    goto LABEL_19;
  }
  v12 = 1;
  if ( *((_DWORD *)this + 150) == newparams->mPanningMode && *((_DWORD *)this + 151) == newparams->mSurroundSpeakerMode )
    v12 = !frommixer;
  if ( *((float *)this + 156) == newparams->mSurroundLFELevel )
  {
    v13 = *((_DWORD *)this + 170);
    v14 = !frommixer;
    if ( v13 != newparams->mNumListeners )
      goto LABEL_5;
  }
  else
  {
    v13 = *((_DWORD *)this + 170);
    v14 = 1;
    if ( v13 != newparams->mNumListeners )
      goto LABEL_5;
  }
  if ( *((float *)this + 162) == newparams->m3DMinDistance
    && *((float *)this + 163) == newparams->m3DMaxDistance
    && *((_DWORD *)this + 164) == newparams->m3DExtentMode
    && *((float *)this + 165) == newparams->m3DSoundSize
    && *((float *)this + 167) == newparams->m3DMinExtent
    && *((_DWORD *)this + 161) == newparams->m3DRolloff )
  {
    topToTopGaind = v12;
    v30 = memcmp((char *)this + 684, newparams->mListeners, 16LL * v13);
    v12 = topToTopGaind;
    if ( v30 )
      calcpanmatrix = 1;
    v7 = (FMOD::DSPPanner_Parameters *)((char *)this + 600);
    goto LABEL_6;
  }
LABEL_5:
  calcpanmatrix = 1;
LABEL_6:
  v15 = 1;
  if ( *((_DWORD *)this + 169) == newparams->mEnabledSpeakers
    && *((_DWORD *)this + 151) == newparams->mSurroundSpeakerMode )
  {
    v15 = deferred;
  }
  v16 = v7;
  v17 = 212;
  if ( ((unsigned __int8)v7 & 1) != 0 )
  {
    v16 = (_WORD *)((char *)&v7->mPanningMode + 1);
    newparams = (FMOD::DSPPanner_Parameters *)((char *)newparams + 1);
    *((_BYTE *)this + 600) = v10->mPanningMode;
    v17 = 211;
  }
  if ( ((unsigned __int8)v16 & 2) != 0 )
  {
    mPanningMode = newparams->mPanningMode;
    ++v16;
    newparams = (FMOD::DSPPanner_Parameters *)((char *)newparams + 2);
    v17 -= 2;
    *(v16 - 1) = mPanningMode;
  }
  if ( ((unsigned __int8)v16 & 4) != 0 )
  {
    v61 = newparams->mPanningMode;
    v16 += 2;
    newparams = (FMOD::DSPPanner_Parameters *)((char *)newparams + 4);
    v17 -= 4;
    *((_DWORD *)v16 - 1) = v61;
  }
  v18 = 0;
  v19 = v17 >> 3;
  qmemcpy(v16, newparams, 8 * v19);
  v21 = (_DWORD *)((char *)newparams + 8 * v19);
  v20 = &v16[4 * v19];
  if ( (v17 & 4) != 0 )
  {
    *v20 = *v21;
    v18 = 4;
  }
  if ( (v17 & 2) != 0 )
  {
    *(_WORD *)((char *)v20 + v18) = *(_WORD *)((char *)v21 + v18);
    v18 += 2;
  }
  if ( (v17 & 1) != 0 )
    *((_BYTE *)v20 + v18) = *((_BYTE *)v21 + v18);
LABEL_19:
  v22 = *((_DWORD *)this + 141);
  if ( *((_DWORD *)this + 140) == v22 )
  {
    if ( !deferred )
      goto LABEL_38;
    v22 = *((_DWORD *)this + 140);
  }
  else
  {
    *((_DWORD *)this + 140) = v22;
  }
  lfe = v7;
  topToTopGain = v12;
  v23 = FMOD::DSPPanner::speakerModeChannelCount(this, v22);
  v24 = (FMOD::ChannelLayout *)*((_QWORD *)this + 74);
  *((_DWORD *)this + 138) = v23;
  v25 = topToTopGain;
  v26 = lfe;
  if ( v24 )
  {
    result = FMOD::ChannelLayout::close(v24);
    v25 = topToTopGain;
    v26 = lfe;
    if ( result )
      return result;
  }
  lfea = v26;
  topToTopGaina = v25;
  v28 = FMOD::DSPPanner::inputChannelLayout(this);
  v12 = topToTopGaina;
  v7 = lfea;
  if ( v28->mPositionableHeightSpeakerCount )
  {
    v29 = (FMOD::ChannelLayout *)*((_QWORD *)this + 74);
    if ( !v29 )
    {
      v29 = (FMOD::ChannelLayout *)FMOD::MemPool::alloc(
                                     off_286F358->gSystemMemPool,
                                     192,
                                     "../../../core_api/src/fmod_dsp_pan.cpp",
                                     1440,
                                     0,
                                     0);
      *((_QWORD *)this + 74) = v29;
      result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
      if ( !v29 )
        return result;
      v7 = lfea;
      v12 = topToTopGaina;
    }
    lfec = v7;
    topToTopGainc = v12;
    result = FMOD::ChannelLayout::initFromLayout(v29, v28, 0xFFFFFFFF, 1);
    v12 = topToTopGainc;
    v7 = lfec;
    if ( result )
      return result;
  }
LABEL_38:
  if ( v12 )
  {
    v31 = FMOD::DSPPanner::outputSpeakerMode(this, v7);
    *((_DWORD *)this + 139) = FMOD::DSPPanner::speakerModeChannelCount(this, v31);
  }
  if ( v14 )
  {
    v4 = *((float *)this + 156);
    if ( v4 > -80.0 )
    {
      v4 = v4 / 20.0;
      v32 = powf(10.0, v4);
    }
    else
    {
      v32 = 0.0;
    }
    *((float *)this + 135) = v32;
  }
  if ( v15 )
  {
    v47 = *((_DWORD *)this + 151);
    v48 = (FMOD::SystemI *)*((_QWORD *)this + 22);
    *(_QWORD *)&matrix_mem[0] = 0;
    result = FMOD::SystemI::getChannelLayout(v48, v47, (const FMOD::ChannelLayout **)matrix_mem);
    if ( result )
      return result;
    v49 = FMOD::ChannelLayout::speakerMaskToLayoutMask(*((_DWORD *)this + 169), *((FMOD_SPEAKERMODE_0 *)this + 151));
    v50 = *(_QWORD *)&matrix_mem[0];
    if ( (((1 << **(_DWORD **)&matrix_mem[0]) - 1) & v49) != (1 << **(_DWORD **)&matrix_mem[0]) - 1 )
    {
      v51 = (FMOD::ChannelLayout *)*((_QWORD *)this + 72);
      if ( v51 )
      {
        result = FMOD::ChannelLayout::close(v51);
        if ( result )
          return result;
        v52 = (FMOD::ChannelLayout *)*((_QWORD *)this + 72);
      }
      else
      {
        v90 = (FMOD::ChannelLayout *)FMOD::MemPool::alloc(
                                       off_286F358->gSystemMemPool,
                                       192,
                                       "../../../core_api/src/fmod_dsp_pan.cpp",
                                       1477,
                                       0,
                                       0);
        *((_QWORD *)this + 72) = v90;
        v52 = v90;
        if ( !v90 )
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
      result = FMOD::ChannelLayout::initFromLayout(v52, *(const FMOD::ChannelLayout **)&matrix_mem[0], v49, 0);
      if ( result )
        return result;
      v50 = *((_QWORD *)this + 72);
    }
    v53 = (FMOD::ChannelLayout *)*((_QWORD *)this + 73);
    *((_QWORD *)this + 71) = v50;
    if ( v53 )
    {
      result = FMOD::ChannelLayout::close(v53);
      if ( result )
        return result;
    }
    v54 = (const FMOD::ChannelLayout *)*((_QWORD *)this + 71);
    if ( !v54->mPositionableHeightSpeakerCount )
      goto LABEL_45;
    v55 = (FMOD::ChannelLayout *)*((_QWORD *)this + 73);
    if ( v55 )
      goto LABEL_74;
    v91 = (FMOD::ChannelLayout *)FMOD::MemPool::alloc(
                                   off_286F358->gSystemMemPool,
                                   192,
                                   "../../../core_api/src/fmod_dsp_pan.cpp",
                                   1493,
                                   0,
                                   0);
    *((_QWORD *)this + 73) = v91;
    if ( v91 )
    {
      v54 = (const FMOD::ChannelLayout *)*((_QWORD *)this + 71);
      v55 = v91;
LABEL_74:
      result = FMOD::ChannelLayout::initFromLayout(v55, v54, v49, 1);
      if ( result )
        return result;
      goto LABEL_45;
    }
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
LABEL_45:
  result = FMOD_RESULT::FMOD_OK_0;
  if ( calcpanmatrix )
  {
    v33 = *((_DWORD *)this + 150);
    if ( v33 )
    {
      if ( v33 == 1 )
      {
        v56 = 0.0;
        if ( FMOD::DSPPanner::inputChannelLayout(this)->mLowFrequencyChannelIndex >= 0 )
          v56 = 0.70710677;
        FMOD::ChannelLayout::clearMatrix(*((_DWORD *)this + 138), 2, 12, (float *)matrix_mem);
        topToTopGaine = *((float *)this + 152);
        v57 = FMOD::DSPPanner::inputChannelLayout(this);
        FMOD::ChannelLayout::sumStereoMatrix(v57, topToTopGaine, v56, 1.0, 12, (float *)matrix_mem);
        v58 = (float *)matrix_mem;
      }
      else
      {
        lfeGain = *((float *)this + 135);
        if ( FMOD::DSPPanner::inputChannelLayout(this)->mLowFrequencyChannelIndex == -1
          && *(int *)(*((_QWORD *)this + 71) + 152LL) >= 0 )
        {
          if ( *((_BYTE *)this + 672) )
            lfeGain = *((float *)this + 135);
          else
            lfeGain = 0.0;
        }
        FMOD::ChannelLayout::clearMatrix(12, 12, 12, (float *)matrix_mem);
        *(_QWORD *)&v35 = *((unsigned int *)this + 166);
        if ( *(float *)&v35 > 0.0 )
        {
          v36 = *((_DWORD *)this + 170);
          if ( v36 == 1 )
          {
            topToTopGainf = FMOD::DSPPanner::calculate3DDistanceGain(
                              this,
                              COERCE_DOUBLE((unsigned __int64)*((_DWORD *)this + 174)),
                              v4,
                              v35,
                              v6,
                              v34);
            v89 = FMOD::DSPPanner::calculate3DExtent(this, *((float *)this + 174), v4);
            FMOD::DSPPanner::sumSurroundPanMatrix(
              this,
              *((const FMOD::ChannelLayout **)this + 71),
              (float *)matrix_mem,
              12,
              *((float *)this + 172),
              v89,
              *((float *)this + 173),
              *((float *)this + 158),
              *((float *)this + 159),
              FMOD_DSP_PAN_2D_STEREO_MODE_DISTRIBUTED,
              lfeGain,
              topToTopGainf * *((float *)this + 166));
            LODWORD(v35) = *((_DWORD *)this + 166);
          }
          else
          {
            memset(distanceGains, 0, sizeof(distanceGains));
            if ( v36 > 0 )
            {
              v37 = 1.0;
              v38 = this;
              v39 = 0.0;
              lfeb = 0.0;
              v40 = 0;
              do
              {
                v41 = *((float *)v38 + 171);
                topToTopGainb = v41;
                if ( v41 > 0.0 )
                {
                  v42 = FMOD::DSPPanner::calculate3DDistanceGain(
                          this,
                          COERCE_DOUBLE((unsigned __int64)*((_DWORD *)v38 + 174)),
                          v41,
                          v35,
                          v39,
                          v37);
                  *(_QWORD *)&v39 = LODWORD(v39);
                  HIDWORD(v35) = 0;
                  v36 = *((_DWORD *)this + 170);
                  *(float *)&v35 = 1.0 - *(float *)&v39;
                  v41 = v41 * v42;
                  v43 = fminf(topToTopGainb, 1.0 - *(float *)&v39);
                  distanceGains[v40] = topToTopGainb * v42;
                  *(float *)&v39 = *(float *)&v39 + v43;
                  lfeb = (float)(v42 * v43) + lfeb;
                }
                v38 = (FMOD::DSPPanner *)((char *)v38 + 16);
                ++v40;
              }
              while ( (int)v40 < v36 );
              if ( lfeb == 0.0 )
              {
                LODWORD(v35) = *((_DWORD *)this + 166);
              }
              else
              {
                v44 = 0;
                v45 = (float *)this;
                if ( v36 > 0 )
                {
                  do
                  {
                    v46 = distanceGains[v44];
                    if ( v46 != 0.0 )
                    {
                      v41 = FMOD::DSPPanner::calculate3DExtent(this, v45[174], v41);
                      FMOD::DSPPanner::sumSurroundPanMatrix(
                        this,
                        *((const FMOD::ChannelLayout **)this + 71),
                        (float *)matrix_mem,
                        12,
                        v45[172],
                        v41,
                        v45[173],
                        *((float *)this + 158),
                        *((float *)this + 159),
                        FMOD_DSP_PAN_2D_STEREO_MODE_DISTRIBUTED,
                        lfeGain,
                        v46);
                    }
                    v45 += 4;
                    ++v44;
                  }
                  while ( *((_DWORD *)this + 170) > (int)v44 );
                }
                v62 = *((_DWORD *)this + 139);
                v63 = 0.0;
                if ( v62 > 0 )
                {
                  v64 = (float *)&matrix_mem[3];
                  v65 = *((_DWORD *)this + 138);
                  v63 = 0.0;
                  v66 = (float *)matrix_mem;
                  while ( 1 )
                  {
                    if ( v65 > 0 )
                    {
                      v67 = 0;
                      do
                      {
                        v68 = v66[v67++];
                        v63 = v63 + (float)(v68 * v68);
                      }
                      while ( v65 > (int)v67 );
                    }
                    v66 = v64;
                    if ( v64 == (float *)&matrix_mem[3 * (unsigned int)(v62 - 1) + 3] )
                      break;
                    v64 += 12;
                  }
                }
                v69 = fsqrt(v63);
                LODWORD(v35) = *((_DWORD *)this + 166);
                v70 = (float)(lfeb / v69) * *(float *)&v35;
                if ( v62 > 0 )
                {
                  v71 = *((_DWORD *)this + 138);
                  v72 = (float *)&matrix_mem[3];
                  v73 = (float *)matrix_mem;
                  while ( 1 )
                  {
                    if ( v71 > 0 )
                    {
                      v74 = &v73[v71 - 1 + 1];
                      do
                      {
                        v75 = *v73++;
                        *(v73 - 1) = v75 * v70;
                      }
                      while ( v74 != v73 );
                    }
                    v73 = v72;
                    if ( v72 == (float *)&matrix_mem[3 * (unsigned int)(v62 - 1) + 3] )
                      break;
                    v72 += 12;
                  }
                }
              }
            }
          }
        }
        if ( *(float *)&v35 < 1.0 )
        {
          v76 = (_DWORD *)*((_QWORD *)this + 74);
          if ( v76 )
            v77 = *v76 != 0;
          else
            v77 = 0;
          v78 = (_DWORD *)*((_QWORD *)this + 73);
          if ( v78 )
            v79 = *v78 != 0;
          else
            v79 = 0;
          if ( v77 && (v80 = *((float *)this + 160), v80 < 0.0) )
          {
            v81 = -v80;
            v82 = v80 + 1.0;
          }
          else
          {
            v81 = 0.0;
            v82 = 1.0;
          }
          if ( v79 )
          {
            v83 = *((float *)this + 160);
            v84 = 1.0;
            if ( v83 <= 0.0 )
              v83 = 0.0;
            else
              v84 = 1.0 - v83;
          }
          else
          {
            v84 = 1.0;
            v83 = 0.0;
          }
          v85 = v84 * (float)(1.0 - *(float *)&v35);
          v86 = v82 * (float)(1.0 - *(float *)&v35);
          v87 = v81 * (float)(1.0 - *(float *)&v35);
          v88 = v83 * (float)(1.0 - *(float *)&v35);
          if ( v85 != 0.0 )
            FMOD::DSPPanner::sumSurroundPanMatrix(
              this,
              *((const FMOD::ChannelLayout **)this + 71),
              (float *)matrix_mem,
              12,
              *((float *)this + 153),
              *((float *)this + 154),
              *((float *)this + 155),
              *((float *)this + 158),
              *((float *)this + 159),
              *((FMOD_DSP_PAN_2D_STEREO_MODE_TYPE *)this + 157),
              lfeGain,
              v85);
          if ( v88 != 0.0 && v79 )
            FMOD::DSPPanner::sumSurroundPanMatrix(
              this,
              *((const FMOD::ChannelLayout **)this + 73),
              (float *)matrix_mem,
              12,
              *((float *)this + 153),
              *((float *)this + 154),
              *((float *)this + 155),
              *((float *)this + 158),
              *((float *)this + 159),
              *((FMOD_DSP_PAN_2D_STEREO_MODE_TYPE *)this + 157),
              lfeGain,
              v88);
          if ( v87 != 0.0 && v77 )
            FMOD::ChannelLayout::sumSurroundMatrix(
              *((const FMOD::ChannelLayout **)this + 74),
              *((const FMOD::ChannelLayout **)this + 71),
              *((float *)this + 153),
              *((float *)this + 154),
              *((float *)this + 155),
              0.0,
              v87,
              12,
              (float *)matrix_mem,
              FMOD_DSP_PAN_SURROUND_FLAGS::FMOD_DSP_PAN_SURROUND_DEFAULT);
          if ( v79 && v86 != 0.0 && v77 )
            FMOD::ChannelLayout::sumSurroundMatrix(
              *((const FMOD::ChannelLayout **)this + 74),
              *((const FMOD::ChannelLayout **)this + 73),
              *((float *)this + 153),
              *((float *)this + 154),
              *((float *)this + 155),
              0.0,
              v86,
              12,
              (float *)matrix_mem,
              FMOD_DSP_PAN_SURROUND_FLAGS::FMOD_DSP_PAN_SURROUND_DEFAULT);
        }
        v58 = (float *)matrix_mem;
      }
    }
    else
    {
      v58 = 0;
      if ( (unsigned int)(*((_DWORD *)this + 140) - 2) > 1 )
      {
        if ( fsqrt((float)FMOD::DSPPanner::inputChannelLayout(this)->mSortedPositionableSpeakerCount) > 1.0 )
          FMOD::DSPPanner::inputChannelLayout(this);
        FMOD::ChannelLayout::clearMatrix(*((_DWORD *)this + 138), 1, 12, (float *)matrix_mem);
        v59 = FMOD::DSPPanner::inputChannelLayout(this);
        FMOD::ChannelLayout::sumMonoMatrix(v59, 1.0, v5, (float *)matrix_mem);
        v58 = (float *)matrix_mem;
      }
    }
    return FMOD::DSPConnectionI::setMixMatrix(
             *((FMOD::DSPConnectionI *const *)this + 66),
             v58,
             *((_DWORD *)this + 139),
             *((_DWORD *)this + 138),
             12,
             *(_QWORD *)(*((_QWORD *)this + 66) + 64LL) == 0
           ? FMOD_RESULT::FMOD_OK_0
           : FMOD_RESULT::FMOD_ERR_TOOMANYCHANNELS_0,
             deferred);
  }
  return result;
}


// Address: 0x21da4f0 | Name: _ZN4FMOD9DSPPanner14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::createInternal(FMOD::DSPPanner *const this)
{
  double v1; // xmm1_8
  FMOD_RESULT_0 result; // eax
  FMOD_SPEAKERMODE_0 v3; // eax
  __int64 v4; // rbp
  int v5; // ebx
  __int64 v6; // rax
  _DWORD *v7; // rdx
  FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI attributes; // [rsp+0h] [rbp-1F8h] BYREF

  result = FMOD::ExpandingPool<FMOD::DSPConnectionI>::alloc(
             (FMOD::ExpandingPool<FMOD::DSPConnectionI> *const)(*((_QWORD *)this + 22) + 1776LL),
             (FMOD::DSPConnectionI **)this + 66,
             1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    FMOD::DSPConnectionI::reset(*((FMOD::DSPConnectionI *const *)this + 66), 1, 1);
    v3 = FMOD::DSPPanner::systemSpeakerMode(this);
    result = FMOD::SystemI::getChannelLayout(
               *((FMOD::SystemI *const *)this + 22),
               v3,
               (const FMOD::ChannelLayout **)this + 71);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      *((_WORD *)this + 46) |= 0x20u;
      v4 = 0;
      v5 = 0;
      *((_QWORD *)this + 104) = this;
      *((_QWORD *)this + 103) = (char *)this + 816;
      *((_QWORD *)this + 102) = (char *)this + 816;
      v6 = *((_QWORD *)this + 30);
      if ( *(int *)(v6 + 96) <= 0 )
      {
LABEL_13:
        memset(&attributes, 0, 0x1D0u);
        *((_DWORD *)this + 230) = 1;
        attributes.numlisteners = 1;
        attributes.absolute.up.z = 0.0;
        result = FMOD::DSPPanner::calculateListenerInfo(
                   this,
                   &attributes,
                   (FMOD::DSPPanner_ListenerInfo *)((char *)this + 924));
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          *((_DWORD *)this + 141) = FMOD::DSPPanner::systemSpeakerMode(this);
          *((_BYTE *)this + 536) = 0;
          return FMOD::DSPPanner::updateParameters(this, (FMOD::DSPPanner_Parameters *)((char *)this + 840), 0, 0);
        }
        return result;
      }
      while ( 1 )
      {
        v7 = *(_DWORD **)(*(_QWORD *)(v6 + 104) + v4);
        if ( !*v7 )
          break;
        if ( *v7 == 1 )
        {
          result = FMOD::DSPI::setParameterInt((FMOD::DSPI *const)this, v5, v7[14]);
          if ( result )
            return result;
LABEL_8:
          v6 = *((_QWORD *)this + 30);
        }
        ++v5;
        v4 += 8;
        if ( *(_DWORD *)(v6 + 96) <= v5 )
          goto LABEL_13;
      }
      result = FMOD::DSPI::setParameterFloat((FMOD::DSPI *const)this, v5, (__m128i)(unsigned int)v7[14], v1);
      if ( result )
        return result;
      goto LABEL_8;
    }
  }
  return result;
}


// Address: 0x21da680 | Name: _ZN4FMOD9DSPPanner14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPPanner::createInternal((FMOD::DSPPanner *const)dsp_state->instance);
}


// Address: 0x21da690 | Name: _ZN4FMOD9DSPPanner15commandInternalEjPv
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::commandInternal(
        FMOD::DSPPanner *const this,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *data)
{
  FMOD_RESULT_0 result; // eax
  int v5; // eax
  FMOD_SPEAKERMODE_0 v6; // eax
  int v7; // eax
  FMOD::DSPPanner_Parameters *v8; // rsi
  __int64 v9; // rax
  int v10; // eax
  FMOD::DSPQueueCmd_UpdateParameters *v11; // rdx
  char *v12; // rsi
  unsigned int v13; // eax
  FMOD::DSPQueueCmd_UpdateParameters *v14; // rdi
  __int64 v15; // rdx
  __int64 v16; // rcx
  FMOD::DSPQueueCmd *v17; // rdi
  char *v18; // rsi
  _QWORD *v19; // rdx
  __int64 v20; // rax
  int v21; // edx
  __int16 v22; // dx
  FMOD::DSPQueueCmd_UpdateParameters *cmd; // [rsp+18h] [rbp-10h] BYREF

  if ( type == 1 )
  {
    v5 = *((unsigned __int16 *)this + 144);
    if ( !(_WORD)v5 )
    {
      v6 = *((_DWORD *)this + 141);
      goto LABEL_8;
    }
    v20 = (unsigned int)(v5 - 1);
    if ( (unsigned int)v20 > 0xB )
    {
      *((_DWORD *)this + 141) = 1;
    }
    else
    {
      v6 = dword_595FA0[v20];
      *((_DWORD *)this + 141) = v6;
      if ( v6 != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
        goto LABEL_8;
    }
    v6 = FMOD::DSPPanner::systemSpeakerMode(this);
    *((_DWORD *)this + 141) = v6;
LABEL_8:
    if ( *((_DWORD *)this + 140) != v6 || *((_BYTE *)this + 537) )
    {
      result = FMOD::DSPPanner::updateParameters(this, (FMOD::DSPPanner_Parameters *)((char *)this + 600), 1, 1);
      if ( result )
        return result;
      if ( *((_BYTE *)this + 537) )
      {
        result = FMOD::DSPConnectionI::reset(*((FMOD::DSPConnectionI *const *)this + 66), 0, 1);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
          *((_BYTE *)this + 537) = 0;
        return result;
      }
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( type == 2 )
  {
    v7 = *((unsigned __int16 *)this + 144);
    v8 = (FMOD::DSPPanner_Parameters *)((char *)data + 16);
    if ( (_WORD)v7 )
    {
      v9 = (unsigned int)(v7 - 1);
      if ( (unsigned int)v9 > 0xB )
      {
        *((_DWORD *)this + 141) = 1;
      }
      else
      {
        v10 = dword_595FA0[v9];
        *((_DWORD *)this + 141) = v10;
        if ( v10 != 1 )
          return FMOD::DSPPanner::updateParameters(this, v8, 1, 1);
      }
      *((_DWORD *)this + 141) = FMOD::DSPPanner::systemSpeakerMode(this);
    }
    return FMOD::DSPPanner::updateParameters(this, v8, 1, 1);
  }
  if ( type != 64 || !*((_BYTE *)this + 536) )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD::SystemI::lockDSPQueueCmd(*((FMOD::SystemI *const *)this + 22), (void **)&cmd, 228, 1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v11 = cmd;
    v12 = (char *)this + 840;
    v13 = 212;
    v14 = cmd + 1;
    *(_BYTE *)&cmd->FMOD::DSPQueueCmd = 7;
    v11->mThis = (FMOD::DSPI *)this;
    if ( ((unsigned __int8)v14 & 1) != 0 )
    {
      v14 = (FMOD::DSPQueueCmd_UpdateParameters *)((char *)v11 + 17);
      v12 = (char *)this + 841;
      *(_BYTE *)&v11[1].FMOD::DSPQueueCmd = *((_BYTE *)this + 840);
      v13 = 211;
    }
    if ( ((unsigned __int8)v14 & 2) != 0 )
    {
      v22 = *(_WORD *)v12;
      v14 = (FMOD::DSPQueueCmd_UpdateParameters *)((char *)v14 + 2);
      v12 += 2;
      v13 -= 2;
      HIWORD(v14[-1].mThis) = v22;
    }
    if ( ((unsigned __int8)v14 & 4) != 0 )
    {
      v21 = *(_DWORD *)v12;
      v14 = (FMOD::DSPQueueCmd_UpdateParameters *)((char *)v14 + 4);
      v12 += 4;
      v13 -= 4;
      HIDWORD(v14[-1].mThis) = v21;
    }
    v15 = 0;
    v16 = v13 >> 3;
    qmemcpy(v14, v12, 8 * v16);
    v18 = &v12[8 * v16];
    v17 = (FMOD::DSPQueueCmd *)v14 + 2 * v16;
    if ( (v13 & 4) != 0 )
    {
      *v17 = *(FMOD::DSPQueueCmd *)v18;
      v15 = 4;
    }
    if ( (v13 & 2) != 0 )
    {
      *(_WORD *)((char *)v17 + v15) = *(_WORD *)&v18[v15];
      v15 += 2;
    }
    if ( (v13 & 1) != 0 )
      *((_BYTE *)v17 + v15) = v18[v15];
    FMOD::SystemI::unlockDSPQueueCmd(*((FMOD::SystemI *const *)this + 22), cmd, 1);
    v19 = (_QWORD *)*((_QWORD *)this + 103);
    *v19 = *((_QWORD *)this + 102);
    *(_QWORD *)(*((_QWORD *)this + 102) + 8LL) = v19;
    *((_QWORD *)this + 103) = (char *)this + 816;
    *((_QWORD *)this + 102) = (char *)this + 816;
    *((_BYTE *)this + 536) = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21da930 | Name: _ZN4FMOD9DSPPanner15processInternalEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::processInternal(
        FMOD::DSPPanner *const this,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  int v8; // r9d
  int v9; // r13d
  FMOD_SPEAKERMODE_0 speakermode; // eax
  char v11; // cl
  FMOD::DSPConnectionI *v12; // rdi
  FMOD_RESULT_0 result; // eax
  __int64 v14; // r13
  FMOD_SPEAKERMODE_0 v15; // r15d
  int v16; // eax
  int *buffernumchannels; // rdx
  int inchannels; // [rsp+1Ch] [rbp-3Ch]

  if ( op == FMOD_DSP_PROCESS_QUERY )
  {
    result = FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
    if ( !inputsidle )
    {
      v14 = *((_QWORD *)this + 66);
      if ( length || (result = FMOD::DSPPanner::commandInternal(this, 1u, 0)) == FMOD_RESULT::FMOD_OK_0 )
      {
        v15 = FMOD::DSPPanner::outputSpeakerMode(this, (FMOD::DSPPanner_Parameters *)((char *)this + 600));
        v16 = FMOD::DSPPanner::speakerModeChannelCount(this, v15);
        if ( outbufferarray )
        {
          buffernumchannels = outbufferarray->buffernumchannels;
          outbufferarray->speakermode = v15;
          *buffernumchannels = v16;
        }
        if ( !length )
          return FMOD_RESULT::FMOD_OK_0;
        if ( FMOD::DSPPanner::pannerParametersAffectMix(
               this,
               inbufferarray->speakermode,
               *inbufferarray->buffernumchannels) )
        {
          return FMOD_RESULT::FMOD_OK_0;
        }
        if ( *(_QWORD *)(v14 + 64) )
          return FMOD_RESULT::FMOD_OK_0;
        if ( *(float *)(v14 + 128) != 1.0 )
          return FMOD_RESULT::FMOD_OK_0;
        result = FMOD_RESULT::FMOD_ERR_DSP_DONTPROCESS_0;
        if ( *(float *)(v14 + 104) != 1.0 )
          return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  else
  {
    v8 = *inbufferarray->buffernumchannels;
    v9 = *outbufferarray->buffernumchannels;
    speakermode = inbufferarray->speakermode;
    if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
    {
      inchannels = *inbufferarray->buffernumchannels;
      speakermode = FMOD::DSPPanner::systemSpeakerMode(this);
      v8 = inchannels;
    }
    *((_DWORD *)this + 141) = speakermode;
    v11 = 1;
    v12 = (FMOD::DSPConnectionI *)*((_QWORD *)this + 66);
    if ( outbufferarray->speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
      v11 = inbufferarray->speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
    result = FMOD::DSPConnectionI::mix(v12, *outbufferarray->buffers, *inbufferarray->buffers, v11, v9, v8, length, 1);
    if ( result == FMOD_RESULT::FMOD_OK_0 && *outbufferarray->buffernumchannels != v9 )
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  }
  return result;
}


// Address: 0x21daaa0 | Name: _ZN4FMOD9DSPPanner15processCallbackEP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS3_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::processCallback(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  return FMOD::DSPPanner::processInternal(
           (FMOD::DSPPanner *const)dsp_state->instance,
           length,
           inbufferarray,
           outbufferarray,
           inputsidle,
           op);
}


// Address: 0x21daab0 | Name: _ZN4FMOD9DSPPanner15commandCallbackEP14FMOD_DSP_STATEjPvS3_
FMOD_RESULT_0 __fastcall FMOD::DSPPanner::commandCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *commandData1,
        void *a4)
{
  return FMOD::DSPPanner::commandInternal((FMOD::DSPPanner *const)dsp_state->instance, type, commandData1);
}


