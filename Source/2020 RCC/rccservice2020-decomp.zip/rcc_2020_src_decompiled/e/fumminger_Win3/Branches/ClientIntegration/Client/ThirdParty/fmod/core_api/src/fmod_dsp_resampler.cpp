// Address: 0x21dfae0 | Name: _ZN4FMOD12DSPResampler12setFrequencyEf
__int64 __fastcall FMOD::DSPResampler::setFrequency(FMOD::DSPResampler *const this, float a2, float frequency)
{
  FMOD::DSPResampler_NODMA *mNoDMA; // rax

  mNoDMA = this->mNoDMA;
  if ( a2 < 0.0 )
  {
    this->mDirection = DSPSOURCE_SPEEDDIR_BACKWARDS;
    a2 = -a2;
  }
  else
  {
    this->mDirection = DSPSOURCE_SPEEDDIR_FORWARDS;
  }
  mNoDMA->mFrequency = a2;
  return 0;
}


// Address: 0x21dfb30 | Name: _ZN4FMOD12DSPResampler19setPositionInternalE14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::setPositionInternal(FMOD::DSPResampler *const this, FMOD_UINT32_32 pcm)
{
  this->mResampleBufferPos = 0;
  this->mResampleFinishPos = 0x7FFFFFFF;
  this->mResamplePosition.mValue = 0;
  this->mResampleFilled = 0;
  this->mPosition = pcm;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21dfb70 | Name: _ZN4FMOD12DSPResampler19getPositionInternalEP14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::getPositionInternal(FMOD::DSPResampler *const this, FMOD_UINT32_32 *pcm)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( pcm )
  {
    pcm->mHi = this->mPosition.mHi;
    pcm->mLo = this->mResamplePosition.mLo;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21dfb90 | Name: _ZN4FMOD12DSPResampler11getFinishedEPb
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::getFinished(FMOD::DSPResampler *const this, bool *finished)
{
  unsigned int v2; // eax

  v2 = 0;
  if ( (this->mJob.mFlags & 0x400) == 0 )
    v2 = *(_DWORD *)((char *)&stru_11610.r_offset + (unsigned __int64)this->mSystem);
  if ( v2 < this->mNoDMA->mFinishTick || this->mJob.mQueuedForDisconnect )
  {
    *finished = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    *finished = 1;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21dfbd0 | Name: _ZN4FMOD12DSPResampler11setFinishedEbbb
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::setFinished(
        FMOD::DSPResampler *const this,
        bool finished,
        bool force,
        bool fromthread)
{
  FMOD::DSPResampler_NODMA *mNoDMA; // rax
  FMOD::SystemI *mSystem; // rbp

  if ( !finished )
  {
    this->mNoDMA->mFinishTick = -1;
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( force )
  {
    mSystem = this->mSystem;
    if ( mSystem )
    {
      FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
      this->mNoDMA->mFinishTick = 0;
      FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
      return FMOD_RESULT::FMOD_OK_0;
    }
    mNoDMA = this->mNoDMA;
  }
  else
  {
    mNoDMA = this->mNoDMA;
    if ( mNoDMA->mFinishTick - 1 <= 0xFFFFFFFD )
      return FMOD_RESULT::FMOD_OK_0;
    if ( (this->mJob.mFlags & 0x400) == 0 )
    {
      mNoDMA->mFinishTick = *(_DWORD *)((char *)&stru_11610.r_offset + (unsigned __int64)this->mSystem) + 1;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  mNoDMA->mFinishTick = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21dfca0 | Name: _ZN4FMOD12DSPResampler16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPResampler::getDescriptionEx()
{
  *(&stru_2ADB680.mHandle + 1) = 1001;
  stru_2ADB680.mDescription = &stru_286B080;
  stru_2ADB680.mSize = 704;
  return &stru_2ADB680;
}


// Address: 0x21dfcc0 | Name: _ZN4FMOD12DSPResamplerC2Ev
void __fastcall FMOD::DSPResampler::DSPResampler(FMOD::DSPResampler *const this)
{
  FMOD::DSPI::DSPI(this);
  this->mResampleBufferMemory = 0;
  this->mResampleBuffer = 0;
  this->mTargetFrequency = 0.0;
  this->mResampleBufferPos = 0;
  this->mResampleFinishPos = 0x7FFFFFFF;
  this->mResampleFilled = 0;
  this->mResamplePosition.mValue = 0;
  this->_vptr_DSPI = (int (**)(...))off_29B1170;
  this->mPosition.mValue = 0;
  this->mNoDMA = 0;
}


// Address: 0x21dfd40 | Name: _ZN4FMOD12DSPResampler14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::createInternal(FMOD::DSPResampler *const this)
{
  void *mParameter; // rbp
  FMOD::SystemI *mSystem; // rdi
  int mResampleBlockLength; // edx
  FMOD_DSP_RESAMPLER_0 resamplerMethod; // eax
  FMOD_RESULT_0 result; // eax
  int mDSPMaxOutputChannels; // esi
  FMOD_SOUND_FORMAT_0 v8; // ecx
  int v9; // eax
  unsigned int v10; // edx
  bool v11; // zf
  unsigned int v12; // eax
  int v13; // eax
  void *v14; // rdx
  unsigned int bufferSize[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  mParameter = this->mDescription.mParameter;
  if ( !this->mMemory )
    this->mMemory = this;
  FMOD::DSPSource::createInternal(this);
  mSystem = this->mSystem;
  mResampleBlockLength = this->mResampleBlockLength;
  resamplerMethod = mSystem->mAdvancedSettings.resamplerMethod;
  this->mTargetFrequency = (float)mSystem->mDSPSampleRate;
  this->mResampleMethod = resamplerMethod;
  if ( !mResampleBlockLength )
  {
    if ( !mParameter || (mResampleBlockLength = *(_DWORD *)mParameter) == 0 )
    {
      result = FMOD::SystemI::getDSPBufferSize(mSystem, bufferSize, 0);
      if ( result )
        return result;
      mResampleBlockLength = bufferSize[0];
    }
    this->mResampleBlockLength = mResampleBlockLength;
  }
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( mResampleBlockLength > 7 )
  {
    this->mResampleBufferLength = mResampleBlockLength;
    if ( mParameter )
    {
      mDSPMaxOutputChannels = *((_DWORD *)mParameter + 1);
      if ( !mDSPMaxOutputChannels )
        mDSPMaxOutputChannels = this->mSystem->mDSPMaxOutputChannels;
      v8 = *((_DWORD *)mParameter + 2);
      result = FMOD_RESULT::FMOD_ERR_FORMAT_0;
      this->mOutputFormat = v8;
      if ( (unsigned int)v8 > FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0 )
        return result;
      if ( v8 )
      {
        if ( v8 == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0 )
        {
          v13 = 3;
          goto LABEL_27;
        }
        if ( v8 <= FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0 )
        {
          if ( v8 == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0 )
          {
            v9 = 2;
LABEL_20:
            v10 = (mDSPMaxOutputChannels * v9 * (mResampleBlockLength + 8) + 15) & 0xFFFFFFF0;
            v11 = this->mResampleBuffer == 0;
            this->mResampleBufferLengthBytes = v10;
            if ( !v11 || !mParameter )
              goto LABEL_21;
LABEL_28:
            if ( *((_BYTE *)mParameter + 12) )
            {
              v14 = FMOD::MemPool::calloc(
                      off_286F358->gSystemMemPool,
                      v10 + 16,
                      "../../../core_api/src/fmod_dsp_resampler.cpp",
                      202,
                      0);
              this->mResampleBufferMemory = v14;
              result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
              if ( !v14 )
                return result;
              this->mResampleBuffer = (void *)(((unsigned __int64)v14 + 15) & 0xFFFFFFFFFFFFFFF0LL);
            }
LABEL_21:
            this->mResampleBufferPos = 0;
            this->mResampleFinishPos = 0x7FFFFFFF;
            this->mJob.mInfo.mMixOffset = 0;
            v12 = this->mResampleBlockLength;
            this->mResampleFilled = 0;
            this->mPosition.mValue = 0;
            this->mResamplePosition.mValue = 0;
            this->mJobTick = 1;
            this->mJob.mInfo.mMixLength = v12;
            this->mNoDMA->mFinishTick = 0;
            return FMOD_RESULT::FMOD_OK_0;
          }
          v13 = 1;
LABEL_27:
          v10 = (mDSPMaxOutputChannels * v13 * (mResampleBlockLength + 8) + 15) & 0xFFFFFFF0;
          v11 = this->mResampleBuffer == 0;
          this->mResampleBufferLengthBytes = v10;
          if ( !v11 )
            goto LABEL_21;
          goto LABEL_28;
        }
        if ( v8 == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0 )
        {
          v13 = 4;
          goto LABEL_27;
        }
LABEL_24:
        v9 = 4;
        goto LABEL_20;
      }
    }
    else
    {
      mDSPMaxOutputChannels = this->mSystem->mDSPMaxOutputChannels;
    }
    this->mOutputFormat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
    goto LABEL_24;
  }
  return result;
}


// Address: 0x21dffb0 | Name: _ZN4FMOD12DSPResampler14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPResampler::createInternal((FMOD::DSPResampler *const)dsp_state->instance);
}


// Address: 0x21dffc0 | Name: _ZN4FMOD12DSPResampler15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::releaseInternal(FMOD::DSPResampler *const this)
{
  void *mResampleBufferMemory; // rsi

  mResampleBufferMemory = this->mResampleBufferMemory;
  if ( mResampleBufferMemory )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      mResampleBufferMemory,
      "../../../core_api/src/fmod_dsp_resampler.cpp",
      249);
    this->mResampleBufferMemory = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e0010 | Name: _ZN4FMOD12DSPResampler15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPResampler::releaseInternal((FMOD::DSPResampler *const)dsp_state->instance);
}


// Address: 0x21e0020 | Name: _ZN4FMOD12DSPResampler8resampleEPfiPv17FMOD_SOUND_FORMATP12FMOD_UINT64PP12FMOD_SINT64Pi18FMOD_DSP_RESAMPLER
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::resample(
        float *out,
        int outlength,
        void *src,
        FMOD_SOUND_FORMAT_0 srcformat,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed,
        int channels,
        FMOD_DSP_RESAMPLER_0 resampleMethod)
{
  if ( speed->mValue == 0x100000000LL && !position->mLo )
  {
    FMOD_Resampler_NoInterp(out, outlength, src, srcformat, position, speed, channels);
    return FMOD_RESULT::FMOD_OK_0;
  }
  switch ( resampleMethod )
  {
    case FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_CUBIC_0:
      FMOD_Resampler_Cubic(out, outlength, src, srcformat, position, speed, channels);
      return FMOD_RESULT::FMOD_OK_0;
    case FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_SPLINE_0:
      FMOD_Resampler_Spline(out, outlength, src, srcformat, position, speed, channels);
      return FMOD_RESULT::FMOD_OK_0;
    case FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_NOINTERP_0:
      FMOD_Resampler_NoInterp(out, outlength, src, srcformat, position, speed, channels);
      return FMOD_RESULT::FMOD_OK_0;
    default:
      FMOD_Resampler_Linear(out, outlength, src, srcformat, position, speed, channels);
      return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21e00c0 | Name: _ZN4FMOD12DSPResampler4fillEPvPji
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::fill(
        FMOD::DSPResampler *const this,
        void *outbuffer,
        unsigned int *length,
        int channels)
{
  FMOD::DSPJob *mJobHead; // rdi
  FMOD::SystemI *tick; // rax
  unsigned int v8; // r12d
  unsigned int v9; // ebx
  FMOD::DSPI *mDSP; // rbp
  FMOD_SPEAKERMODE_0 v11; // edx
  int mNumJobs; // eax
  int v13; // esi
  FMOD_RESULT_0 v14; // ebx
  FMOD_RESULT_0 v15; // eax
  FMOD::FMOD_RESAMPLE_CALLBACK mFillCallback; // rax
  FMOD::DSPBuffer *p_mBuffer; // r14
  int mChannels; // r8d
  FMOD::DSPBuffer *v20; // rdi
  FMOD_SOUND_FORMAT_0 mOutputFormat; // ebp
  float *v22; // rax
  __int64 count; // [rsp+18h] [rbp-110h]
  int v25; // [rsp+2Ch] [rbp-FCh]
  FMOD::DSPJobList joblist; // [rsp+30h] [rbp-F8h] BYREF
  int outchannels[46]; // [rsp+70h] [rbp-B8h] BYREF

  this->mState.instance = this;
  mJobHead = this->mJobHead;
  if ( mJobHead )
  {
    tick = this->mSystem;
    v8 = *length;
    joblist.mNumJobs = 0;
    joblist.mDirty = 0;
    joblist.mChanged = 0;
    joblist.mLocal = 0;
    v9 = channels - 1;
    joblist.mSystem = tick;
    joblist.mNumExecutingJobs = 0;
    joblist.mMaxJobs = 16;
    joblist.mJob = (FMOD::DSPJobEntry *)outchannels;
    joblist.mJobMemory = outchannels;
    LODWORD(tick) = this->mJobTick;
    joblist.mJobExpand = 0;
    this->mJobTick = (_DWORD)tick + 1;
    FMOD::DSPJob::runClockTree(mJobHead, &joblist, &mJobHead->mDelayClock, v8, 0, v8, (int)tick, 0);
    count = 0;
    if ( joblist.mNumJobs > 0 )
    {
      do
      {
        mDSP = joblist.mJob[count].mJob->mDSP;
        while ( 1 )
        {
          v11 = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
          if ( v9 <= 0xB )
            v11 = dword_5961A0[v9];
          if ( FMOD::DSPI::runJob(mDSP, v8, v11, channels) == FMOD_RESULT::FMOD_OK_0 )
            break;
          v15 = FMOD::SystemI::expandDSPBufferPool(this->mSystem);
          if ( v15 )
            return v15;
        }
        mNumJobs = joblist.mNumJobs;
        if ( joblist.mNumJobs - 1 == (_DWORD)count )
        {
          p_mBuffer = &mDSP->mBuffer;
          if ( FMOD::DSPBuffer::get(&mDSP->mBuffer) )
          {
            mChannels = mDSP->mBuffer.mChannels;
            v20 = &mDSP->mBuffer;
            mOutputFormat = this->mOutputFormat;
            v25 = v8 * mChannels;
            v22 = FMOD::DSPBuffer::get(v20);
            FMOD::DSPI::convert(
              outbuffer,
              v22,
              mOutputFormat,
              FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0,
              v25,
              1,
              1,
              1.0,
              0);
          }
          else
          {
            memset(outbuffer, 0, 4LL * mDSP->mBuffer.mChannels * v8);
          }
          FMOD::DSPBuffer::release(p_mBuffer);
          mNumJobs = joblist.mNumJobs;
        }
        v13 = count++;
      }
      while ( v13 + 1 < mNumJobs );
    }
    v14 = FMOD_RESULT::FMOD_OK_0;
    FMOD::DSPBuffer::release(&this->mBuffer);
  }
  else
  {
    mFillCallback = this->mFillCallback;
    v14 = FMOD_RESULT::FMOD_OK_0;
    if ( mFillCallback )
    {
      outchannels[0] = channels;
      v15 = mFillCallback(&this->mState, (float *)outbuffer, 0, length, outchannels);
      if ( v15 == FMOD_RESULT::FMOD_ERR_FILE_EOF_0 && (this->mNoDMA->mMode & 2) != 0 && this->mLoopCount )
        return FMOD_RESULT::FMOD_OK_0;
      return v15;
    }
  }
  return v14;
}


// Address: 0x21e0320 | Name: _ZN4FMOD12DSPResampler12readInternalEPfPij
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::readInternal(
        FMOD::DSPResampler *const this,
        float *outbuffer,
        int *outchannels,
        unsigned int length)
{
  int mChannels; // r12d
  int v5; // eax
  float v6; // xmm0_4
  float mTargetFrequency; // xmm1_4
  signed int v8; // r13d
  signed int mResampleFilled; // esi
  int v10; // r15d
  size_t v11; // r14
  int mHi; // eax
  __int64 mResampleFinishPos; // rdx
  int v14; // esi
  char v15; // r10
  FMOD_SINT64 v16; // rcx
  unsigned __int64 v17; // rdx
  signed int v18; // ecx
  signed int v19; // r11d
  int v20; // r11d
  unsigned int mLo; // edx
  FMOD_SOUND_FORMAT_0 mOutputFormat; // ecx
  int v23; // eax
  signed int v24; // r11d
  unsigned int v25; // eax
  unsigned int mResampleBufferLength; // edx
  FMOD_RESULT_0 result; // eax
  bool v28; // zf
  unsigned int v29; // edx
  FMOD::DSPResampler_NODMA *mNoDMA; // rax
  unsigned int mLength; // ecx
  unsigned int mLoopStart; // edx
  unsigned __int64 v33; // rsi
  FMOD_UINT64 v34; // rdx
  int mLoopCount; // esi
  signed int v36; // edx
  unsigned int bytespersample; // [rsp+10h] [rbp-98h]
  char endreached; // [rsp+14h] [rbp-94h]
  __int64 v40; // [rsp+30h] [rbp-78h]
  __int64 v41; // [rsp+38h] [rbp-70h]
  int v42; // [rsp+40h] [rbp-68h]
  FMOD_SINT64P speed; // [rsp+50h] [rbp-58h] BYREF
  FMOD_UINT64P absPosition; // [rsp+60h] [rbp-48h] BYREF

  mChannels = this->mDescription.mChannels;
  speed.mValue = 0;
  if ( !(_WORD)mChannels )
    mChannels = *outchannels;
  switch ( this->mOutputFormat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      v5 = 2;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      v5 = 3;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      v5 = 4;
      break;
    default:
      v5 = 1;
      break;
  }
  bytespersample = mChannels * v5;
  v6 = (*((float (__fastcall **)(FMOD::DSPResampler *const))this->_vptr_DSPI + 10))(this);
  mTargetFrequency = this->mTargetFrequency;
  if ( v6 == mTargetFrequency )
  {
    speed.mValue = 0x100000000LL;
    v40 = 0x100000000LL;
  }
  else
  {
    v40 = -1;
    speed.mValue = (unsigned int)(int)(float)((float)(v6 / mTargetFrequency) * 4294967300.0);
    if ( (unsigned __int64)speed.mValue > 0x100 )
      v40 = (unsigned int)(int)(float)((float)(mTargetFrequency / v6) * 4294967300.0);
  }
  v8 = length;
  if ( (int)length > 0 )
  {
    mResampleFilled = this->mResampleFilled;
    v10 = 0;
    v11 = (int)(8 * bytespersample);
    v41 = v40 >> 32;
    while ( 1 )
    {
      mHi = this->mResamplePosition.mHi;
      if ( mHi >= mResampleFilled )
        goto LABEL_20;
      if ( speed.mValue <= 256 )
      {
        v20 = 0;
        v15 = 0;
      }
      else
      {
        mResampleFinishPos = this->mResampleFinishPos;
        v14 = mResampleFilled - 4;
        v15 = 1;
        if ( v14 < (int)mResampleFinishPos )
        {
          mResampleFinishPos = (unsigned int)v14;
          v15 = 0;
        }
        v16 = (mResampleFinishPos << 32) - this->mResamplePosition.mValue;
        if ( v16 <= 0 )
        {
LABEL_36:
          v24 = v8;
          if ( v15 )
          {
LABEL_37:
            memset(&outbuffer[mChannels * v10], 0, 4LL * mChannels * v24);
            (*((void (__fastcall **)(FMOD::DSPResampler *const, __int64, _QWORD, __int64))this->_vptr_DSPI + 5))(
              this,
              1,
              0,
              1);
            this->mResampleFilled = 0;
            this->mResamplePosition.mValue = 0;
            this->mResampleFinishPos = 0;
            break;
          }
          goto LABEL_19;
        }
        v17 = ((unsigned int)v16 * v41
             + v40 * SHIDWORD(v16)
             + 0xFFFFFFFFLL
             + (((unsigned int)v16 * (unsigned __int64)(unsigned int)v40) >> 32)) >> 32;
        v18 = ((unsigned int)v16 * v41
             + v40 * SHIDWORD(v16)
             + 0xFFFFFFFFLL
             + (((unsigned int)v16 * (unsigned __int64)(unsigned int)v40) >> 32)) >> 32;
        if ( v8 >= (int)v17 )
        {
          if ( (int)v17 <= 0 )
            goto LABEL_36;
        }
        else
        {
          v18 = v8;
          v15 = 0;
        }
        v19 = v8;
        v8 = v18;
        v20 = v19 - v18;
      }
      mLo = this->mResamplePosition.mLo;
      absPosition.mHi = mHi + 8;
      mOutputFormat = this->mOutputFormat;
      v23 = mChannels * v10;
      absPosition.mLo = mLo;
      v42 = v20;
      endreached = v15;
      v10 += v8;
      FMOD::DSPResampler::resample(
        &outbuffer[v23],
        v8,
        this->mResampleBuffer,
        mOutputFormat,
        &absPosition,
        &speed,
        mChannels,
        this->mResampleMethod);
      v24 = v42;
      this->mResamplePosition.mHi = absPosition.mHi - 8;
      this->mResamplePosition.mLo = absPosition.mLo;
      if ( endreached )
        goto LABEL_37;
      if ( v42 <= 0 )
        break;
LABEL_19:
      mResampleFilled = this->mResampleFilled;
      v8 = v24;
LABEL_20:
      if ( mResampleFilled )
      {
        memmove(this->mResampleBuffer, (char *)this->mResampleBuffer + bytespersample * mResampleFilled, v11);
        v25 = this->mResampleFinishPos;
        v29 = this->mResampleFilled;
        this->mResamplePosition.mHi -= v29;
        if ( v25 != 0x7FFFFFFF )
        {
          v25 -= v29;
          this->mResampleFinishPos = v25;
        }
        this->mResampleFilled = 0;
      }
      else
      {
        v25 = this->mResampleFinishPos;
      }
      mResampleBufferLength = this->mResampleBufferLength;
      absPosition.mLo = mResampleBufferLength;
      if ( v25 == 0x7FFFFFFF )
      {
        result = FMOD::DSPResampler::fill(
                   this,
                   (char *)this->mResampleBuffer + v11,
                   (unsigned int *)&absPosition,
                   mChannels);
        if ( result != FMOD_RESULT::FMOD_ERR_FILE_EOF_0 && result )
          return result;
      }
      else
      {
        memset((char *)this->mResampleBuffer + v11, 0, bytespersample * mResampleBufferLength);
        result = FMOD_RESULT::FMOD_OK_0;
      }
      this->mMixerFlags |= 0x20u;
      mResampleFilled = absPosition.mLo;
      if ( this->mResampleBufferLength < absPosition.mLo )
        return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      v28 = this->mResampleFinishPos == 0x7FFFFFFF;
      this->mResampleFilled = absPosition.mLo;
      if ( v28 && result == FMOD_RESULT::FMOD_ERR_FILE_EOF_0 )
        this->mResampleFinishPos = mResampleFilled;
    }
  }
  mNoDMA = this->mNoDMA;
  mLength = this->mLength;
  mLoopStart = mNoDMA->mLoopStart;
  if ( mLength < mLoopStart + mNoDMA->mLoopLength )
    mNoDMA->mLoopLength = mLength - mLoopStart;
  if ( this->mDirection == DSPSOURCE_SPEEDDIR_BACKWARDS )
  {
    mLoopCount = 0;
    if ( (mNoDMA->mMode & 2) != 0 )
    {
      mLoopCount = this->mLoopCount;
      if ( mLoopCount )
        mLoopCount = mLoopStart;
    }
    this->mPosition.mValue -= speed.mValue * length;
    v36 = this->mPosition.mHi;
    if ( mLoopCount >= v36 )
    {
      if ( (mNoDMA->mMode & 2) != 0 || mLength == -1 )
        this->mPosition.mHi = mNoDMA->mLoopLength + v36;
      else
        this->mPosition.mHi = 0;
    }
    goto LABEL_51;
  }
  if ( mLength < mLoopStart + mNoDMA->mLoopLength )
    mNoDMA->mLoopLength = mLength - mLoopStart;
  if ( (mNoDMA->mMode & 2) != 0 && this->mLoopCount )
    v33 = ((unsigned __int64)(mNoDMA->mLoopLength + mLoopStart - 1) << 32) | 0xFFFFFFFF;
  else
    v33 = ((unsigned __int64)(mLength - 1) << 32) | 0xFFFFFFFF;
  v34 = this->mPosition.mValue + speed.mValue * length;
  this->mPosition.mValue = v34;
  if ( v34 <= v33 )
  {
LABEL_51:
    *outchannels = mChannels;
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( (mNoDMA->mMode & 2) == 0 && mLength != -1 )
  {
    this->mPosition.mHi = mLength;
    goto LABEL_51;
  }
  this->mPosition.mHi -= mNoDMA->mLoopLength;
  *outchannels = mChannels;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e08d0 | Name: _ZN4FMOD12DSPResampler14shouldIProcessEij
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::shouldIProcess(
        FMOD::DSPResampler *const this,
        FMOD_BOOL inputsidle,
        unsigned int length)
{
  FMOD_RESULT_0 result; // eax
  int (**vptr_DSPI)(...); // rax

  result = FMOD_RESULT::FMOD_OK_0;
  if ( this->mJob.mDelayClock.mStopNow && !length )
  {
    vptr_DSPI = this->_vptr_DSPI;
    this->mJob.mDelayClock.mStopNow = 0;
    vptr_DSPI[5](this, 1, length, 1);
    return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
  }
  return result;
}


// Address: 0x21e0910 | Name: _ZN4FMOD12DSPResampler15processInternalEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::processInternal(
        FMOD::DSPResampler *const this,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  float *v8; // rsi
  FMOD_RESULT_0 result; // eax
  int mChannels; // eax
  __int64 v12; // rax
  FMOD_SPEAKERMODE_0 v13; // eax
  FMOD::DSPJob *mJobHead; // rax
  FMOD::DSPI *mDSP; // rax
  __int64 (__fastcall *mProcess)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // r10
  FMOD_RESULT_0 v17; // eax
  int mDSPMaxOutputChannels; // edx
  FMOD_RESULT_0 v19; // ecx
  int numoutputs[11]; // [rsp+1Ch] [rbp-2Ch] BYREF

  if ( op != FMOD_DSP_PROCESS_QUERY )
  {
    v8 = *outbufferarray->buffers;
    numoutputs[0] = *outbufferarray->buffernumchannels;
    return FMOD::DSPResampler::readInternal(this, v8, numoutputs, length);
  }
  result = FMOD::DSPResampler::shouldIProcess(this, inputsidle, length);
  if ( result == FMOD_RESULT::FMOD_OK_0 && inbufferarray )
  {
    if ( !outbufferarray )
      return FMOD_RESULT::FMOD_OK_0;
    if ( this->mFillCallback )
    {
      mChannels = this->mDescription.mChannels;
      *outbufferarray->buffernumchannels = mChannels;
      v12 = (unsigned int)(mChannels - 1);
      if ( (unsigned int)v12 <= 0xB )
      {
        v13 = dword_5961A0[v12];
        if ( v13 != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
          outbufferarray->speakermode = v13;
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    FMOD::DSPI::getNumOutputsInternal(this->mJobHead->mDSP, numoutputs, 0, 0);
    mJobHead = this->mJobHead;
    if ( mJobHead
      && (mDSP = mJobHead->mDSP,
          (mProcess = (__int64 (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))mDSP->mProcess) != 0)
      && !numoutputs[0] )
    {
      mDSP->mState.instance = mDSP;
      v17 = (unsigned int)mProcess(&mDSP->mState, length, inbufferarray, outbufferarray, (unsigned int)inputsidle, 1);
      mDSPMaxOutputChannels = this->mDescription.mChannels;
      v19 = v17;
      if ( !(_WORD)mDSPMaxOutputChannels )
        mDSPMaxOutputChannels = this->mSystem->mDSPMaxOutputChannels;
      result = FMOD_RESULT::FMOD_ERR_DSP_DONTPROCESS_0;
      if ( *outbufferarray->buffernumchannels == mDSPMaxOutputChannels )
        return v19;
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_DSP_DONTPROCESS_0;
    }
  }
  return result;
}


// Address: 0x21e0a70 | Name: _ZN4FMOD12DSPResampler15processCallbackEP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS3_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::processCallback(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  return FMOD::DSPResampler::processInternal(
           (FMOD::DSPResampler *const)dsp_state->instance,
           length,
           inbufferarray,
           outbufferarray,
           inputsidle,
           op);
}


// Address: 0x21e0a80 | Name: _ZN4FMOD12DSPResampler12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return (*(FMOD_RESULT_0 (__fastcall **)(void *, float *, int *, unsigned int, int))(*(_QWORD *)dsp_state->instance
                                                                                    + 72LL))(
           dsp_state->instance,
           outbuffer,
           outchannels,
           length,
           inchannels);
}


// Address: 0x21e0aa0 | Name: _ZN4FMOD12DSPResampler22shouldIProcessCallbackEP14FMOD_DSP_STATEijji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPResampler::shouldIProcessCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD_BOOL inputsidle,
        unsigned int length,
        FMOD_CHANNELMASK a4,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  return FMOD::DSPResampler::shouldIProcess((FMOD::DSPResampler *const)dsp_state->instance, inputsidle, length);
}


