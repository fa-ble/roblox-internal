// Address: 0x221f570 | Name: _ZN4FMOD11ChannelReal4initEiPNS_7SystemIEPNS_6OutputE
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::init(
        FMOD::ChannelReal *const this,
        int index,
        FMOD::SystemI *system,
        FMOD::Output *output)
{
  this->mSound = 0;
  this->mFlags = 0;
  this->mMode = 0;
  this->mPosition.mValue = 0;
  this->mDirection = 0;
  this->mLoopCount = -1;
  this->mOutput = output;
  this->mSystem = system;
  this->mIndex = index;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f5b0 | Name: _ZN4FMOD11ChannelReal5closeEv
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::close(FMOD::ChannelReal *const this)
{
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *const))this->_vptr_ChannelReal + 10))(this);
}


// Address: 0x221f5c0 | Name: _ZN4FMOD11ChannelReal5allocEv
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::alloc(FMOD::ChannelReal *const this)
{
  FMOD::ChannelPool *mPool; // rax

  mPool = this->mPool;
  this->mPosition.mValue = 0;
  if ( mPool )
    ++mPool->mChannelsUsed;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f5e0 | Name: _ZN4FMOD11ChannelReal5allocEPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::alloc(FMOD::ChannelReal *const this, FMOD::DSPI *dsp)
{
  FMOD::ChannelPool *mPool; // rax

  mPool = this->mPool;
  if ( mPool )
    ++mPool->mChannelsUsed;
  this->mPosition.mValue = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f600 | Name: _ZN4FMOD11ChannelReal6updateEi
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::update(FMOD::ChannelReal *const this, int delta_ms)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f610 | Name: _ZN4FMOD11ChannelReal12updateStreamEv
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::updateStream(FMOD::ChannelReal *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f620 | Name: _ZN4FMOD11ChannelReal5startEv
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::start(FMOD::ChannelReal *const this)
{
  FMOD::CHANNELREAL_FLAG mFlags; // eax

  mFlags = this->mFlags;
  LOBYTE(mFlags) = mFlags & 0x6F;
  this->mFlags = mFlags | 0x40;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f630 | Name: _ZN4FMOD11ChannelReal4stopEv
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::stop(FMOD::ChannelReal *const this)
{
  FMOD::ChannelPool *mPool; // rax
  FMOD::CHANNELREAL_FLAG v2; // eax

  mPool = this->mPool;
  if ( mPool )
    --mPool->mChannelsUsed;
  v2 = this->mFlags & 0xFFFDFE8F;
  LOBYTE(v2) = this->mFlags & 0xF | 0x80;
  this->mFlags = v2;
  (*((void (__fastcall **)(FMOD::ChannelReal *const))this->_vptr_ChannelReal + 26))(this);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f660 | Name: _ZN4FMOD11ChannelReal9setPausedEb
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::setPaused(FMOD::ChannelReal *const this, bool paused)
{
  if ( paused )
    this->mFlags |= 0x20u;
  else
    this->mFlags &= ~0x20u;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f680 | Name: _ZN4FMOD11ChannelReal9getPausedEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::getPaused(FMOD::ChannelReal *const this, bool *paused)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( paused )
  {
    *paused = (this->mFlags & 0x20) != 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x221f6a0 | Name: _ZN4FMOD11ChannelReal9setVolumeEf
__int64 __fastcall FMOD::ChannelReal::setVolume(FMOD::ChannelReal *const this, double a2, float volume)
{
  return 0;
}


// Address: 0x221f6b0 | Name: _ZN4FMOD11ChannelReal12setFrequencyEf
__int64 __fastcall FMOD::ChannelReal::setFrequency(FMOD::ChannelReal *const this, double a2, float frequency)
{
  return 0;
}


// Address: 0x221f6c0 | Name: _ZN4FMOD11ChannelReal6setPanEff
__int64 __fastcall FMOD::ChannelReal::setPan(FMOD::ChannelReal *const this, double a2, float pan, float fbpan)
{
  return 0;
}


// Address: 0x221f6d0 | Name: _ZN4FMOD11ChannelReal11setPositionE14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::setPosition(FMOD::ChannelReal *const this, FMOD_UINT32_32 pcm)
{
  this->mPosition = pcm;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f6e0 | Name: _ZN4FMOD11ChannelReal11getPositionEP14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::getPosition(FMOD::ChannelReal *const this, FMOD_UINT32_32 *pcm)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( pcm )
  {
    pcm->mValue = (FMOD_UINT64)this->mPosition;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x221f700 | Name: _ZN4FMOD11ChannelReal13setLoopPointsEjj
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::setLoopPoints(
        FMOD::ChannelReal *const this,
        unsigned int loopstart,
        unsigned int looplength)
{
  FMOD::SoundI *mSound; // rcx
  FMOD_RESULT_0 result; // eax
  unsigned int mLength; // ecx

  mSound = this->mSound;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( mSound )
  {
    mLength = mSound->mLength;
    if ( mLength > loopstart && mLength >= loopstart + looplength )
    {
      this->mLoopStart = loopstart;
      this->mLoopLength = looplength;
      LOBYTE(result) = 0;
    }
  }
  return result;
}


// Address: 0x221f740 | Name: _ZN4FMOD11ChannelReal12setLoopCountEi
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::setLoopCount(FMOD::ChannelReal *const this, int loopcount)
{
  this->mLoopCount = loopcount;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f750 | Name: _ZN4FMOD11ChannelReal12getLoopCountEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::getLoopCount(FMOD::ChannelReal *const this, int *loopcount)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( loopcount )
  {
    *loopcount = this->mLoopCount;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x221f770 | Name: _ZN4FMOD11ChannelReal14setLowPassGainEf
__int64 __fastcall FMOD::ChannelReal::setLowPassGain(FMOD::ChannelReal *const this, double a2, float gain)
{
  return 0;
}


// Address: 0x221f780 | Name: _ZN4FMOD11ChannelReal19setReverbPropertiesEif
__int64 __fastcall FMOD::ChannelReal::setReverbProperties(
        FMOD::ChannelReal *const this,
        int instance,
        double a3,
        float wet)
{
  return 0;
}


// Address: 0x221f790 | Name: _ZN4FMOD11ChannelReal9isPlayingEPbb
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::isPlaying(
        FMOD::ChannelReal *const this,
        bool *isplaying,
        bool includethreadlatency)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( isplaying )
  {
    if ( (this->mFlags & 0x50) != 0 )
    {
      *isplaying = 1;
      LOBYTE(result) = 0;
    }
    else
    {
      *isplaying = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x221f7c0 | Name: _ZN4FMOD11ChannelReal9isVirtualEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::isVirtual(FMOD::ChannelReal *const this, bool *isvirtual)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( isvirtual )
  {
    *isvirtual = 0;
    LOBYTE(result) = 0;
  }
  return result;
}


// Address: 0x221f7e0 | Name: _ZN4FMOD11ChannelReal7setModeEj
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::setMode(FMOD::ChannelReal *const this, FMOD_MODE mode)
{
  FMOD_MODE mMode; // eax
  FMOD_MODE v3; // eax
  FMOD::ChannelI *mParent; // rax

  mMode = this->mMode;
  if ( (mode & 7) != 0 )
  {
    mMode &= 0xFFFFFFF8;
    if ( (mode & 1) != 0 )
    {
      mMode |= 1u;
      this->mMode = mMode;
    }
    else if ( (mode & 2) != 0 )
    {
      mMode |= 2u;
      this->mMode = mMode;
    }
    else
    {
      if ( (mode & 4) != 0 )
        mMode |= 4u;
      this->mMode = mMode;
    }
  }
  if ( (mode & 0x40000) != 0 )
  {
    mMode = mMode & 0xFFF3FFFF | 0x40000;
    this->mMode = mMode;
  }
  else if ( (mode & 0x80000) != 0 )
  {
    mMode = mMode & 0xFFF3FFFF | 0x80000;
    this->mMode = mMode;
  }
  if ( (mode & 0x100000) != 0 )
  {
    mMode = mMode & 0xFB0FFFFF | 0x100000;
    this->mMode = mMode;
  }
  else if ( (mode & 0x200000) != 0 )
  {
    mMode = mMode & 0xFB0FFFFF | 0x200000;
    this->mMode = mMode;
  }
  else if ( (mode & 0x400000) != 0 )
  {
    mMode = mMode & 0xFB0FFFFF | 0x400000;
    this->mMode = mMode;
  }
  else if ( (mode & 0x800000) != 0 )
  {
    mMode = mMode & 0xFB0FFFFF | 0x800000;
    this->mMode = mMode;
  }
  else if ( (mode & 0x4000000) != 0 )
  {
    mMode = mMode & 0xFB0FFFFF | 0x4000000;
    this->mMode = mMode;
  }
  if ( (mode & 0x40000000) != 0 )
  {
    v3 = mMode | 0x40000000;
    this->mMode = v3;
    if ( (mode & 0x80000000) == 0 )
    {
LABEL_10:
      this->mMode = v3 & 0x7FFFFFFF;
      goto LABEL_11;
    }
  }
  else
  {
    v3 = mMode & 0xBFFFFFFF;
    this->mMode = v3;
    if ( (mode & 0x80000000) == 0 )
      goto LABEL_10;
  }
  this->mMode = v3 | 0x80000000;
LABEL_11:
  if ( (mode & 8) != 0 )
  {
    mParent = this->mParent;
    if ( mParent )
    {
      this->mMode = this->mMode & 0xFFFFFFE7 | 8;
      mParent->mVolume3D = 1.0;
      mParent->mDirectOcclusion = 0.0;
      mParent->mConeVolume3D = 1.0;
      mParent->mPitch3D = 1.0;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( (mode & 0x10) == 0 )
    return FMOD_RESULT::FMOD_OK_0;
  this->mMode = this->mMode & 0xFFFFFFE7 | 0x10;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f990 | Name: _ZN4FMOD11ChannelReal13setFinishTickEv
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::setFinishTick(FMOD::ChannelReal *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f9c0 | Name: _ZN4FMOD11ChannelRealC2Ev
void __fastcall FMOD::ChannelReal::ChannelReal(FMOD::ChannelReal *const this)
{
  this->mSound = 0;
  this->mSystem = 0;
  this->mOutput = 0;
  this->mPool = 0;
  this->mLoopCount = -1;
  this->mMinFrequency = 100.0;
  this->mMaxFrequency = 1000000.0;
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2270;
}


