// Address: 0x2261a80 | Name: _Z23FMOD_OS_Output_RegisterPN4FMOD13PluginFactoryE
FMOD_RESULT_0 __fastcall FMOD_OS_Output_Register(FMOD::PluginFactory *pluginfactory)
{
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *Description; // rax
  FMOD_RESULT_0 result; // eax
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *v3; // rax

  Description = FMOD::OutputALSA::getDescriptionEx();
  result = FMOD::PluginFactory::registerOutput(pluginfactory, Description, 0, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v3 = FMOD::OutputPulseAudio::getDescriptionEx();
    return FMOD::PluginFactory::registerOutput(pluginfactory, v3, 0, 0);
  }
  return result;
}


// Address: 0x2261ac0 | Name: _Z31FMOD_OS_Output_CheckALSASupportv
FMOD_RESULT_0 __cdecl FMOD_OS_Output_CheckALSASupport()
{
  FMOD_OS_LIBRARY *library; // [rsp+8h] [rbp-10h] BYREF

  library = 0;
  if ( FMOD_OS_Library_Load("libasound.so.2", &library) )
    return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  else
    return FMOD_OS_Library_Free(library);
}


// Address: 0x2261b10 | Name: _Z25FMOD_OS_Output_GetDefaultP15FMOD_OUTPUTTYPE
FMOD_RESULT_0 __fastcall FMOD_OS_Output_GetDefault(FMOD_OUTPUTTYPE_0 *outputType)
{
  if ( !getenv("FMOD_ALSA_DEVICE") )
  {
    if ( !system("pulseaudio --check > /dev/null 2>&1") )
      goto LABEL_9;
    if ( FMOD_OS_Output_CheckALSASupport() )
      goto LABEL_4;
LABEL_7:
    *outputType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_ALSA_0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( FMOD_OS_Output_CheckALSASupport() == FMOD_RESULT::FMOD_OK_0 )
    goto LABEL_7;
  if ( !system("pulseaudio --check > /dev/null 2>&1") )
  {
LABEL_9:
    *outputType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_PULSEAUDIO_0;
    return FMOD_RESULT::FMOD_OK_0;
  }
LABEL_4:
  *outputType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_NOSOUND_0;
  return FMOD_RESULT::FMOD_OK_0;
}


