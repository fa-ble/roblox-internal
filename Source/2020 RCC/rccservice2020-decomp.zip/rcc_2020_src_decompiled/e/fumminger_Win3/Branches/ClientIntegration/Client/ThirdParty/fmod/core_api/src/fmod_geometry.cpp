// Address: 0x21fe980 | Name: _ZN4FMOD8Geometry7releaseEv
FMOD_RESULT_0 __fastcall FMOD::Geometry::release(FMOD::Geometry *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::release(geometryi);
  return result;
}


// Address: 0x21fe9b0 | Name: _ZN4FMOD8Geometry10addPolygonEffbiPK11FMOD_VECTORPi
FMOD_RESULT_0 __fastcall FMOD::Geometry::addPolygon(
        FMOD::Geometry *const this,
        float directocclusion,
        float reverbocclusion,
        bool doublesided,
        int numvertices,
        const FMOD_VECTOR *vertices,
        int *polygonindex)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+18h] [rbp-30h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::addPolygon(
             geometryi,
             directocclusion,
             reverbocclusion,
             doublesided,
             numvertices,
             vertices,
             polygonindex);
  return result;
}


// Address: 0x21fea10 | Name: _ZN4FMOD8Geometry14getNumPolygonsEPi
FMOD_RESULT_0 __fastcall FMOD::Geometry::getNumPolygons(FMOD::Geometry *const this, int *numpolygons)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::getNumPolygons(geometryi, numpolygons);
  return result;
}


// Address: 0x21fea40 | Name: _ZN4FMOD8Geometry14getMaxPolygonsEPiS1_
FMOD_RESULT_0 __fastcall FMOD::Geometry::getMaxPolygons(FMOD::Geometry *const this, int *maxpolygons, int *maxvertices)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::getMaxPolygons(geometryi, maxpolygons, maxvertices);
  return result;
}


// Address: 0x21fea80 | Name: _ZN4FMOD8Geometry21getPolygonNumVerticesEiPi
FMOD_RESULT_0 __fastcall FMOD::Geometry::getPolygonNumVertices(FMOD::Geometry *const this, int index, int *numvertices)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::getPolygonNumVertices(geometryi, index, numvertices);
  return result;
}


// Address: 0x21feab0 | Name: _ZN4FMOD8Geometry16setPolygonVertexEiiPK11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::Geometry::setPolygonVertex(
        FMOD::Geometry *const this,
        int index,
        int vertexindex,
        const FMOD_VECTOR *vertex)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::setPolygonVertex(geometryi, index, vertexindex, vertex);
  return result;
}


// Address: 0x21feaf0 | Name: _ZN4FMOD8Geometry16getPolygonVertexEiiP11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::Geometry::getPolygonVertex(
        FMOD::Geometry *const this,
        int index,
        int vertexindex,
        FMOD_VECTOR *vertex)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::getPolygonVertex(geometryi, index, vertexindex, vertex);
  return result;
}


// Address: 0x21feb30 | Name: _ZN4FMOD8Geometry20setPolygonAttributesEiffb
FMOD_RESULT_0 __fastcall FMOD::Geometry::setPolygonAttributes(
        FMOD::Geometry *const this,
        int index,
        float directocclusion,
        float reverbocclusion,
        bool doublesided)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+18h] [rbp-20h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::setPolygonAttributes(geometryi, index, directocclusion, reverbocclusion, doublesided);
  return result;
}


// Address: 0x21feb80 | Name: _ZN4FMOD8Geometry20getPolygonAttributesEiPfS1_Pb
FMOD_RESULT_0 __fastcall FMOD::Geometry::getPolygonAttributes(
        FMOD::Geometry *const this,
        int index,
        float *directocclusion,
        float *reverbocclusion,
        bool *doublesided)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-30h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::getPolygonAttributes(geometryi, index, directocclusion, reverbocclusion, doublesided);
  return result;
}


// Address: 0x21febd0 | Name: _ZN4FMOD8Geometry9setActiveEb
FMOD_RESULT_0 __fastcall FMOD::Geometry::setActive(FMOD::Geometry *const this, bool active)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::setActive(geometryi, active);
  return result;
}


// Address: 0x21fec00 | Name: _ZN4FMOD8Geometry9getActiveEPb
FMOD_RESULT_0 __fastcall FMOD::Geometry::getActive(FMOD::Geometry *const this, bool *active)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::getActive(geometryi, active);
  return result;
}


// Address: 0x21fec30 | Name: _ZN4FMOD8Geometry11setRotationEPK11FMOD_VECTORS3_
FMOD_RESULT_0 __fastcall FMOD::Geometry::setRotation(
        FMOD::Geometry *const this,
        const FMOD_VECTOR *forward,
        const FMOD_VECTOR *up)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::setRotation(geometryi, forward, up);
  return result;
}


// Address: 0x21fec70 | Name: _ZN4FMOD8Geometry11getRotationEP11FMOD_VECTORS2_
FMOD_RESULT_0 __fastcall FMOD::Geometry::getRotation(FMOD::Geometry *const this, FMOD_VECTOR *forward, FMOD_VECTOR *up)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::getRotation(geometryi, forward, up);
  return result;
}


// Address: 0x21fecb0 | Name: _ZN4FMOD8Geometry11setPositionEPK11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::Geometry::setPosition(FMOD::Geometry *const this, const FMOD_VECTOR *position)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::setPosition(geometryi, position);
  return result;
}


// Address: 0x21fece0 | Name: _ZN4FMOD8Geometry11getPositionEP11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::Geometry::getPosition(FMOD::Geometry *const this, FMOD_VECTOR *position)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::getPosition(geometryi, position);
  return result;
}


// Address: 0x21fed10 | Name: _ZN4FMOD8Geometry8setScaleEPK11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::Geometry::setScale(FMOD::Geometry *const this, const FMOD_VECTOR *scale)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::setScale(geometryi, scale);
  return result;
}


// Address: 0x21fed40 | Name: _ZN4FMOD8Geometry8getScaleEP11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::Geometry::getScale(FMOD::Geometry *const this, FMOD_VECTOR *scale)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::getScale(geometryi, scale);
  return result;
}


// Address: 0x21fed70 | Name: _ZN4FMOD8Geometry4saveEPvPi
FMOD_RESULT_0 __fastcall FMOD::Geometry::save(FMOD::Geometry *const this, void *data, int *datasize)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::save(geometryi, data, datasize);
  return result;
}


// Address: 0x21fedb0 | Name: _ZN4FMOD8Geometry11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::Geometry::setUserData(FMOD::Geometry *const this, void *_userdata)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::setUserData(geometryi, _userdata);
  return result;
}


// Address: 0x21fede0 | Name: _ZN4FMOD8Geometry11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::Geometry::getUserData(FMOD::Geometry *const this, void **_userdata)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *geometryi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::GeometryI::validate(this, &geometryi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::GeometryI::getUserData(geometryi, _userdata);
  return result;
}


