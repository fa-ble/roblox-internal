// Address: 0x21f3a10 | Name: _ZN4FMOD14DSPTransceiver25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPTransceiver::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  if ( index != 1 )
    return 31;
  *((float *)dsp_state->instance + 185) = a3;
  return 0;
}


// Address: 0x21f3a30 | Name: _ZN4FMOD14DSPTransceiver23setParameterIntCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::setParameterIntCallback(FMOD_DSP_STATE *dsp_state, int index, int value)
{
  _DWORD *instance; // rax

  instance = dsp_state->instance;
  if ( index == 2 )
  {
    instance[183] = value;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else if ( index == 3 )
  {
    instance[186] = value;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
}


// Address: 0x21f3a70 | Name: _ZN4FMOD14DSPTransceiver24setParameterBoolCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::setParameterBoolCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        FMOD_BOOL value)
{
  if ( index )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *((_DWORD *)dsp_state->instance + 184) = value;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f3a90 | Name: _ZN4FMOD14DSPTransceiver24setParameterDataCallbackEP14FMOD_DSP_STATEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::setParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void *data,
        unsigned int length)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index == 4 )
    return FMOD_RESULT::FMOD_OK_0;
  return result;
}


// Address: 0x21f3ab0 | Name: _ZN4FMOD14DSPTransceiver24getParameterDataCallbackEP14FMOD_DSP_STATEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::getParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax
  float *instance; // rbx
  float v7; // xmm1_4
  float v8; // xmm0_4
  void **dataa; // [rsp+8h] [rbp-20h]
  unsigned int *lengtha; // [rsp+10h] [rbp-18h]
  char *valuestra; // [rsp+18h] [rbp-10h]

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  instance = (float *)dsp_state->instance;
  if ( index == 4 )
  {
    v7 = instance[185];
    if ( v7 > -80.0 )
    {
      valuestra = valuestr;
      lengtha = length;
      dataa = data;
      v8 = powf(10.0, v7 / 20.0);
      data = dataa;
      length = lengtha;
      valuestr = valuestra;
    }
    else
    {
      v8 = 0.0;
    }
    instance[188] = v8;
    *data = instance + 187;
    *length = 8;
    if ( valuestr )
      *valuestr = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21f3b60 | Name: _ZN4FMOD14DSPTransceiver13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  char *instance; // rbx
  float v2; // xmm1_4
  float v3; // xmm0_4

  instance = (char *)dsp_state->instance;
  v2 = *((float *)dsp_state->instance + 185);
  *((float *)dsp_state->instance + 135) = v2;
  if ( v2 > -80.0 )
    v3 = powf(10.0, v2 / 20.0);
  else
    v3 = 0.0;
  FMOD::DSPConnectionI::setMix((FMOD::DSPConnectionI *const)(instance + 560), v3, 0, 0, 0);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f3bc0 | Name: _ZN4FMOD14DSPTransceiver25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  FMOD_RESULT_0 v4; // ebx
  float v6; // xmm0_4

  v4 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index != 1 )
    return v4;
  v6 = *((float *)dsp_state->instance + 185);
  v4 = FMOD_RESULT::FMOD_OK_0;
  *value = v6;
  if ( !valuestr )
    return v4;
  LOBYTE(index) = 32;
  FMOD_snprintf(valuestr, index, "%.1f dB", v6);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f3c10 | Name: _ZN4FMOD14DSPTransceiver23getParameterIntCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::getParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int *value,
        char *valuestr)
{
  _DWORD *instance; // rcx
  int v6; // ecx
  int v8; // ecx

  instance = dsp_state->instance;
  if ( index == 2 )
  {
    v8 = instance[183];
    *value = v8;
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    FMOD_snprintf(valuestr, 32, "%d", v8);
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( index == 3 )
    {
      v6 = instance[186];
      *value = v6;
      if ( valuestr )
        FMOD_strcpy_safe(valuestr, off_286B760[v6 + 1], 32);
      return FMOD_RESULT::FMOD_OK_0;
    }
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
}


// Address: 0x21f3ca0 | Name: _ZN4FMOD14DSPTransceiver24getParameterBoolCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::getParameterBoolCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        FMOD_BOOL *value,
        char *valuestr)
{
  FMOD_RESULT_0 v4; // ebx
  __int64 v6; // rax

  v4 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index )
    return v4;
  v6 = *((int *)dsp_state->instance + 184);
  v4 = FMOD_RESULT::FMOD_OK_0;
  *value = v6;
  if ( !valuestr )
    return v4;
  FMOD_strcpy_safe(valuestr, off_286B780[v6], 32);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f3cf0 | Name: _ZN4FMOD14DSPTransceiver16sysCloseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::sysCloseCallback(FMOD_DSP_STATE *dsp_state)
{
  __int64 systemobject; // rdx
  bool v2; // zf
  FMOD_RESULT_0 result; // eax
  FMOD::DSPTransceiverChannel *v5; // rsi
  int v6; // edx
  FMOD::DSPTransceiverChannel **v7; // rax

  systemobject = dsp_state->systemobject;
  v2 = FMOD::DSPTransceiver::sRefCount[systemobject] == 1;
  if ( --FMOD::DSPTransceiver::sRefCount[systemobject] < 0 )
  {
    FMOD::DSPTransceiver::sRefCount[systemobject] = 0;
  }
  else if ( !v2 )
  {
    return FMOD_RESULT::FMOD_OK_0;
  }
  v5 = FMOD::DSPTransceiver::sChannel[systemobject];
  if ( !v5 )
    return FMOD_RESULT::FMOD_OK_0;
  FMOD::MemPool::free(off_286F358->gSystemMemPool, v5, "../../../core_api/src/fmod_dsp_transceiver.cpp", 991);
  v6 = 0;
  FMOD::DSPTransceiver::sChannel[dsp_state->systemobject] = 0;
  v7 = (FMOD::DSPTransceiverChannel **)FMOD::DSPTransceiver::sRefCount;
  do
  {
    v6 += *(_DWORD *)v7;
    v7 = (FMOD::DSPTransceiverChannel **)((char *)v7 + 4);
  }
  while ( v7 != FMOD::DSPTransceiver::sChannel );
  if ( v6 )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD_OS_CriticalSection_Free(FMOD::DSPTransceiver::sCriticalSection, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    FMOD::DSPTransceiver::sCriticalSection = 0;
  return result;
}


// Address: 0x21f3db0 | Name: _ZN4FMOD14DSPTransceiver16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPTransceiver::getDescriptionEx()
{
  memset(&stru_2ADBF00, 0, sizeof(stru_2ADBF00));
  strcpy(stru_2ADBF00.name, "Transmit mode");
  stru_2ADBF00.type = FMOD_DSP_PARAMETER_TYPE_BOOL;
  stru_2ADBF00.description = "Receiver or transmitter";
  stru_2ADBF00.booldesc.valuenames = off_286B780;
  memset(&stru_2ADBEA0, 0, sizeof(stru_2ADBEA0));
  *(_QWORD *)stru_2ADBEA0.name = 0x6C6576654CLL;
  *(_QWORD *)stru_2ADBEA0.label = 16996;
  *(_QWORD *)&stru_2ADBEA0.floatdesc.min = 0x41200000C2A00000LL;
  stru_2ADBEA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2ADBEA0.description = "Receiving or transmitting gain";
  memset(&stru_2ADBDE0, 0, sizeof(stru_2ADBDE0));
  strcpy(stru_2ADBDE0.name, "Channel");
  stru_2ADBDE0.type = FMOD_DSP_PARAMETER_TYPE_INT;
  stru_2ADBDE0.intdesc.max = 31;
  stru_2ADBDE0.description = "Transmit channel";
  memset(&stru_2ADBE40, 0, sizeof(stru_2ADBE40));
  stru_2ADBE40.intdesc.valuenames = off_286B760;
  qmemcpy(stru_2ADBE40.name, "Speaker Mode", 12);
  stru_2ADBE40.type = FMOD_DSP_PARAMETER_TYPE_INT;
  stru_2ADBE40.description = "Speaker mode";
  *(_QWORD *)&stru_2ADBE40.floatdesc.min = 0x2FFFFFFFFLL;
  stru_2ADBE40.intdesc.defaultval = -1;
  memset(&stru_2ADBD80, 0, sizeof(stru_2ADBD80));
  stru_2ADBD80.type = FMOD_DSP_PARAMETER_TYPE_DATA;
  qmemcpy(stru_2ADBD80.name, "Overall Gain", 12);
  stru_2ADBD80.description = "Overall Gain";
  stru_2ADBD80.intdesc.min = -1;
  *(&stru_2ADBCC0.mHandle + 1) = 34;
  stru_2ADBCC0.mSize = 760;
  stru_2ADBCC0.mDescription = &stru_286B640;
  stru_2ADBCC0.mCommandMask = 1;
  stru_2ADBCC0.mCommand = FMOD::DSPTransceiver::commandCallback;
  return &stru_2ADBCC0;
}


// Address: 0x21f3fb0 | Name: _ZN4FMOD21DSPTransceiverChannel4initEii
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiverChannel::init(
        FMOD::DSPTransceiverChannel *const this,
        int blocksize,
        int channels)
{
  __int64 i; // rax

  this->mBlockSize = blocksize;
  for ( i = 0; i != 6; i += 2 )
  {
    *(float **)((char *)this->mBufferMemory + 4 * i) = 0;
    this->mBuffer[0][i + 1] = 0;
    this->mBuffer[0][i] = 0;
    *(int *)((char *)this->mBufferRef + 2 * i) = 0;
    this->mBufferDirty[0][i + 1] = 0;
    this->mBufferDirty[0][i] = 0;
  }
  this->mBackBufferIndex = 1;
  this->mBufferChannels[0] = 1;
  LOBYTE(i) = 0;
  this->mBufferChannels[1] = 2;
  this->mBufferChannels[2] = channels;
  return (int)i;
}


// Address: 0x21f4010 | Name: _ZN4FMOD14DSPTransceiver15sysInitCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::sysInitCallback(FMOD_DSP_STATE *dsp_state)
{
  __int64 systemobject; // rax
  int v3; // r12d
  FMOD_RESULT_0 result; // eax
  __int64 v5; // rbx
  FMOD::DSPTransceiverChannel *v6; // rdi
  __int64 v7; // rbx
  FMOD::DSPTransceiverChannel *v8; // rdi
  FMOD::DSPTransceiverChannel **v9; // rax
  int v10; // edx
  unsigned int blocksize; // [rsp+8h] [rbp-30h] BYREF
  FMOD_SPEAKERMODE_0 speakermode[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  systemobject = dsp_state->systemobject;
  v3 = FMOD::DSPTransceiver::sRefCount[systemobject];
  if ( v3 )
    goto LABEL_2;
  result = dsp_state->functions->getblocksize(dsp_state, &blocksize);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = dsp_state->functions->getspeakermode(dsp_state, speakermode, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( speakermode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
      {
        v3 = 5;
      }
      else if ( speakermode[0] <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
      {
        if ( speakermode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
        {
LABEL_12:
          v3 = 2;
          goto LABEL_13;
        }
        if ( speakermode[0] > FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
          v3 = 4;
        else
          v3 = speakermode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0;
      }
      else if ( speakermode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
      {
        v3 = 8;
      }
      else if ( speakermode[0] < FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
      {
        v3 = 6;
      }
      else
      {
        if ( speakermode[0] != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
        {
          if ( speakermode[0] != 1000 )
            goto LABEL_13;
          goto LABEL_12;
        }
        v3 = 12;
      }
LABEL_13:
      v5 = dsp_state->systemobject;
      FMOD::DSPTransceiver::sChannel[v5] = (FMOD::DSPTransceiverChannel *)FMOD::MemPool::calloc(
                                                                            off_286F358->gSystemMemPool,
                                                                            3584,
                                                                            "../../../core_api/src/fmod_dsp_transceiver.cpp",
                                                                            942,
                                                                            0);
      v6 = FMOD::DSPTransceiver::sChannel[dsp_state->systemobject];
      if ( !v6 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      v7 = 0;
      while ( 1 )
      {
        v8 = &v6[v7++];
        FMOD::DSPTransceiverChannel::init(v8, blocksize, v3);
        if ( v7 == 32 )
          break;
        v6 = FMOD::DSPTransceiver::sChannel[dsp_state->systemobject];
      }
      v9 = (FMOD::DSPTransceiverChannel **)FMOD::DSPTransceiver::sRefCount;
      v10 = 0;
      do
      {
        v10 += *(_DWORD *)v9;
        v9 = (FMOD::DSPTransceiverChannel **)((char *)v9 + 4);
      }
      while ( v9 != FMOD::DSPTransceiver::sChannel );
      if ( v10
        || (result = FMOD_OS_CriticalSection_Create(&FMOD::DSPTransceiver::sCriticalSection, 0)) == FMOD_RESULT::FMOD_OK_0 )
      {
        systemobject = dsp_state->systemobject;
        v3 = FMOD::DSPTransceiver::sRefCount[systemobject];
LABEL_2:
        FMOD::DSPTransceiver::sRefCount[systemobject] = v3 + 1;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21f41d0 | Name: _ZN4FMOD21DSPTransceiverChannel22updateBufferAllocationER32FMOD_DSP_TRANSCEIVER_SPEAKERMODEi
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiverChannel::updateBufferAllocation(
        FMOD::DSPTransceiverChannel *const this,
        FMOD_DSP_TRANSCEIVER_SPEAKERMODE *const speakermode,
        int refcount_change)
{
  __int64 v4; // rax
  char *v5; // rcx
  bool v6; // zf
  bool v7; // sf
  float **v8; // r12
  FMOD_RESULT_0 result; // eax
  float *v10; // rsi
  int v11; // edx
  int v12; // ecx
  float *v13; // rax
  __int64 v14; // rdx
  float *v15; // rcx
  __int64 v16; // rsi

  SLODWORD(v4) = *speakermode;
  if ( *speakermode == FMOD_DSP_TRANSCEIVER_SPEAKERMODE_AUTO )
    return FMOD_RESULT::FMOD_OK_0;
  if ( (_DWORD)v4 == 2 )
  {
    v12 = this->mBufferChannels[2];
    if ( v12 == 2 )
    {
      *speakermode = FMOD_DSP_TRANSCEIVER_SPEAKERMODE_STEREO;
      LOBYTE(v4) = 1;
    }
    else if ( v12 == 1 )
    {
      *speakermode = FMOD_DSP_TRANSCEIVER_SPEAKERMODE_MONO;
      LODWORD(v4) = 0;
    }
  }
  v4 = (int)v4;
  v5 = (char *)this + 4 * (int)v4;
  v6 = refcount_change + *((_DWORD *)v5 + 18) == 0;
  v7 = refcount_change + *((_DWORD *)v5 + 18) < 0;
  *((_DWORD *)v5 + 18) += refcount_change;
  if ( v7 )
  {
    *((_DWORD *)v5 + 18) = 0;
  }
  else if ( !v6 )
  {
    goto LABEL_5;
  }
  v10 = this->mBufferMemory[(int)v4];
  if ( v10 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v10, "../../../core_api/src/fmod_dsp_transceiver.cpp", 220);
    v4 = *(int *)speakermode;
    this->mBufferMemory[v4] = 0;
    this->mBuffer[v4][0] = 0;
    this->mBuffer[v4][1] = 0;
    v11 = this->mBufferRef[v4];
    this->mBufferDirty[v4][1] = 0;
    this->mBufferDirty[v4][0] = 0;
  }
  else
  {
    v11 = *((_DWORD *)v5 + 18);
  }
  if ( !v11 )
    return FMOD_RESULT::FMOD_OK_0;
LABEL_5:
  v8 = &this->mBufferMemory[v4];
  if ( *v8 )
    return FMOD_RESULT::FMOD_OK_0;
  v13 = (float *)FMOD::MemPool::calloc(
                   off_286F358->gSystemMemPool,
                   this->mBufferChannels[v4] * 8 * this->mBlockSize,
                   "../../../core_api/src/fmod_dsp_transceiver.cpp",
                   229,
                   0);
  v14 = *(int *)speakermode;
  *v8 = v13;
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v15 = this->mBufferMemory[v14];
  if ( v15 )
  {
    v16 = this->mBlockSize * this->mBufferChannels[v14];
    this->mBuffer[v14][0] = v15;
    this->mBuffer[v14][1] = &v15[v16];
    this->mBufferDirty[v14][1] = 0;
    this->mBufferDirty[v14][0] = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21f4350 | Name: _ZN4FMOD21DSPTransceiverChannel4flipEv
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiverChannel::flip(FMOD::DSPTransceiverChannel *const this)
{
  int v1; // eax

  v1 = 1 - this->mBackBufferIndex;
  this->mBackBufferIndex = v1;
  this->mBufferDirty[0][v1] = 0;
  this->mBufferDirty[1][v1] = 0;
  this->mBufferDirty[2][v1] = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f4370 | Name: _ZN4FMOD14DSPTransceiver14sysMixCallbackEP14FMOD_DSP_STATEi
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::sysMixCallback(FMOD_DSP_STATE *dsp_state, int stage)
{
  FMOD_RESULT_0 result; // eax
  __int64 v4; // rbx
  FMOD_OS_CRITICALSECTION *v5; // r15
  int systemobject; // edx
  int v7; // ebp
  FMOD_RESULT_0 v8; // eax
  __int64 v9; // rbx
  FMOD_OS_CRITICALSECTION *v10; // rbp
  __int64 v11; // rdi
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-4Ch]
  FMOD_SPEAKERMODE_0 speakermode[15]; // [rsp+1Ch] [rbp-3Ch] BYREF

  if ( !stage )
  {
    v4 = 0;
    v5 = FMOD::DSPTransceiver::sCriticalSection;
    FMOD_OS_CriticalSection_Enter(FMOD::DSPTransceiver::sCriticalSection);
    systemobject = dsp_state->systemobject;
    while ( 1 )
    {
      while ( 1 )
      {
        v7 = FMOD::DSPTransceiver::sChannel[systemobject][v4].mBufferChannels[2];
        if ( !v7 )
          break;
        if ( ++v4 == 32 )
          goto LABEL_16;
      }
      v8 = dsp_state->functions->getspeakermode(dsp_state, speakermode, 0);
      if ( v8 )
      {
        __result = v8;
        FMOD_OS_CriticalSection_Leave(v5);
        return __result;
      }
      if ( speakermode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
      {
        v7 = 5;
        goto LABEL_15;
      }
      if ( speakermode[0] <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
        break;
      if ( speakermode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
      {
        v7 = 8;
        goto LABEL_15;
      }
      if ( speakermode[0] < FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
      {
        v7 = 6;
        goto LABEL_15;
      }
      if ( speakermode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
      {
        v7 = 12;
        goto LABEL_15;
      }
      if ( speakermode[0] == 1000 )
        goto LABEL_14;
LABEL_15:
      systemobject = dsp_state->systemobject;
      FMOD::DSPTransceiver::sChannel[systemobject][v4++].mBufferChannels[2] = v7;
      if ( v4 == 32 )
      {
LABEL_16:
        FMOD_OS_CriticalSection_Leave(v5);
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
    if ( speakermode[0] != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
    {
      if ( speakermode[0] > FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
        v7 = 4;
      else
        v7 = speakermode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0;
      goto LABEL_15;
    }
LABEL_14:
    v7 = 2;
    goto LABEL_15;
  }
  result = FMOD_RESULT::FMOD_OK_0;
  if ( stage == 1 )
  {
    v9 = 0;
    v10 = FMOD::DSPTransceiver::sCriticalSection;
    FMOD_OS_CriticalSection_Enter(FMOD::DSPTransceiver::sCriticalSection);
    do
    {
      v11 = v9;
      v9 += 112;
      FMOD::DSPTransceiverChannel::flip((FMOD::DSPTransceiverChannel *)((char *)FMOD::DSPTransceiver::sChannel[dsp_state->systemobject]
                                                                      + v11));
    }
    while ( v9 != 3584 );
    FMOD_OS_CriticalSection_Leave(v10);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21f4550 | Name: _ZN4FMOD14DSPTransceiver15commandInternalEj
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::commandInternal(
        FMOD::DSPTransceiver *const this,
        FMOD::FMOD_DSP_COMMAND_TYPE type)
{
  float v3; // xmm1_4
  float v4; // xmm0_4
  FMOD_OS_CRITICALSECTION *v5; // rbp
  FMOD_DSP_TRANSCEIVER_SPEAKERMODE *v6; // rsi
  int v7; // eax
  int v8; // eax
  int v9; // edx
  unsigned __int64 v10; // rbp
  unsigned __int64 v11; // rbp
  int v12; // ecx
  FMOD_OS_CRITICALSECTION *v13; // r12
  FMOD_OS_CRITICALSECTION *v14; // r12
  unsigned int blocksize; // [rsp+0h] [rbp-34h] BYREF
  FMOD_DSP_TRANSCEIVER_SPEAKERMODE oldspeakermode[12]; // [rsp+4h] [rbp-30h] BYREF

  if ( type != 1 )
    return FMOD_RESULT::FMOD_OK_0;
  if ( !*((_DWORD *)this + 134) )
  {
    (*(void (__fastcall **)(_QWORD, FMOD_DSP_TRANSCEIVER_SPEAKERMODE *, _QWORD))(**(_QWORD **)(*((_QWORD *)this + 22)
                                                                                             + 71176LL)
                                                                               + 216LL))(
      *(_QWORD *)(*((_QWORD *)this + 22) + 71176LL),
      oldspeakermode,
      0);
    v10 = *(_QWORD *)oldspeakermode;
    (*(void (__fastcall **)(char *, unsigned int *))(*((_QWORD *)this + 28) + 32LL))((char *)this + 184, &blocksize);
    v11 = v10 >> 20;
    if ( qword_2ADBCA0 > v11 || blocksize + qword_2ADBCA0 < v11 )
      *((_BYTE *)this + 728) = 1;
    qword_2ADBCA0 = v11;
  }
  v3 = *((float *)this + 185);
  if ( v3 != *((float *)this + 135) )
  {
    *((float *)this + 135) = v3;
    if ( v3 > -80.0 )
      v4 = powf(10.0, v3 / 20.0);
    else
      v4 = 0.0;
    FMOD::DSPConnectionI::setMix((FMOD::DSPConnectionI *const)((char *)this + 560), v4, 0x40u, 0, 0);
  }
  if ( *((_DWORD *)this + 184) != *((_DWORD *)this + 134) )
  {
    v5 = FMOD::DSPTransceiver::sCriticalSection;
    FMOD_OS_CriticalSection_Enter(FMOD::DSPTransceiver::sCriticalSection);
    v6 = (FMOD_DSP_TRANSCEIVER_SPEAKERMODE *)((char *)this + 552);
    if ( *((_DWORD *)this + 184) == 1 )
      FMOD::DSPTransceiverChannel::updateBufferAllocation(
        &FMOD::DSPTransceiver::sChannel[*((int *)this + 58)][*((int *)this + 133)],
        v6,
        1);
    else
      FMOD::DSPTransceiverChannel::updateBufferAllocation(
        &FMOD::DSPTransceiver::sChannel[*((int *)this + 58)][*((int *)this + 133)],
        v6,
        -1);
    *((_DWORD *)this + 134) = *((_DWORD *)this + 184);
    FMOD_OS_CriticalSection_Leave(v5);
  }
  v7 = *((_DWORD *)this + 183);
  if ( v7 != *((_DWORD *)this + 133) )
  {
    if ( *((_DWORD *)this + 134) == 1 )
    {
      v14 = FMOD::DSPTransceiver::sCriticalSection;
      FMOD_OS_CriticalSection_Enter(FMOD::DSPTransceiver::sCriticalSection);
      FMOD::DSPTransceiverChannel::updateBufferAllocation(
        &FMOD::DSPTransceiver::sChannel[*((int *)this + 58)][*((int *)this + 133)],
        (FMOD_DSP_TRANSCEIVER_SPEAKERMODE *const)this + 138,
        -1);
      FMOD::DSPTransceiverChannel::updateBufferAllocation(
        &FMOD::DSPTransceiver::sChannel[*((int *)this + 58)][*((int *)this + 183)],
        (FMOD_DSP_TRANSCEIVER_SPEAKERMODE *const)this + 138,
        1);
      FMOD_OS_CriticalSection_Leave(v14);
      v7 = *((_DWORD *)this + 183);
    }
    *((_DWORD *)this + 133) = v7;
  }
  v8 = *((_DWORD *)this + 186);
  v9 = *((_DWORD *)this + 138);
  if ( v8 != *((_DWORD *)this + 136) || v9 == -1 )
  {
    oldspeakermode[0] = *((FMOD_DSP_TRANSCEIVER_SPEAKERMODE *)this + 138);
    if ( v8 != -1 )
    {
      *((_DWORD *)this + 138) = v8;
LABEL_19:
      if ( *((_DWORD *)this + 134) == 1 && v9 != *((_DWORD *)this + 138) )
      {
        v13 = FMOD::DSPTransceiver::sCriticalSection;
        FMOD_OS_CriticalSection_Enter(FMOD::DSPTransceiver::sCriticalSection);
        FMOD::DSPTransceiverChannel::updateBufferAllocation(
          &FMOD::DSPTransceiver::sChannel[*((int *)this + 58)][*((int *)this + 133)],
          oldspeakermode,
          -1);
        FMOD::DSPTransceiverChannel::updateBufferAllocation(
          &FMOD::DSPTransceiver::sChannel[*((int *)this + 58)][*((int *)this + 133)],
          (FMOD_DSP_TRANSCEIVER_SPEAKERMODE *const)this + 138,
          1);
        FMOD_OS_CriticalSection_Leave(v13);
        v8 = *((_DWORD *)this + 186);
      }
      *((_DWORD *)this + 136) = v8;
      return FMOD_RESULT::FMOD_OK_0;
    }
    v12 = *((_DWORD *)this + 137);
LABEL_33:
    *((_DWORD *)this + 138) = v12;
    goto LABEL_19;
  }
  if ( v8 == -1 )
  {
    v12 = *((_DWORD *)this + 137);
    if ( v9 != v12 )
    {
      oldspeakermode[0] = *((FMOD_DSP_TRANSCEIVER_SPEAKERMODE *)this + 138);
      goto LABEL_33;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f4900 | Name: _ZN4FMOD14DSPTransceiver15commandCallbackEP14FMOD_DSP_STATEjPvS3_
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::commandCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *commanddata1,
        void *commanddata2)
{
  return FMOD::DSPTransceiver::commandInternal((FMOD::DSPTransceiver *const)dsp_state->instance, type);
}


// Address: 0x21f4910 | Name: _ZN4FMOD14DSPTransceiver4initEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::init(FMOD::DSPTransceiver *const this, FMOD_DSP_STATE *dsp_state)
{
  float v2; // xmm1_4
  FMOD::SystemI *v3; // rsi
  char *v4; // rdi

  v3 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  *((_DWORD *)this + 134) = 0;
  v4 = (char *)this + 560;
  *((_DWORD *)v4 + 44) = 0;
  *((_DWORD *)v4 - 7) = 0;
  *((_DWORD *)v4 - 5) = 0;
  *((_DWORD *)v4 + 43) = 0;
  *((_DWORD *)v4 - 2) = -1;
  *((_DWORD *)v4 + 45) = 0;
  *((_DWORD *)v4 - 3) = -1;
  *((_DWORD *)v4 - 4) = -1;
  *((_DWORD *)v4 + 47) = 1065353216;
  *((_DWORD *)v4 + 46) = -1;
  v4[168] = 1;
  FMOD::DSPConnectionI::init((FMOD::DSPConnectionI *const)v4, v3, 1.0, v2);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f49a0 | Name: _ZN4FMOD14DSPTransceiver14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::createCallback(FMOD_DSP_STATE *dsp_state)
{
  double v1; // xmm1_8
  __int64 v2; // rbp
  int v3; // ebx
  FMOD::DSPI *instance; // r12
  const FMOD_DSP_DESCRIPTION *mDescription; // rdx
  FMOD_DSP_PARAMETER_DESC *v6; // rcx
  FMOD_RESULT_0 result; // eax

  v2 = 0;
  v3 = 0;
  instance = (FMOD::DSPI *)dsp_state->instance;
  mDescription = (const FMOD_DSP_DESCRIPTION *)*((_QWORD *)dsp_state->instance + 30);
  if ( mDescription->numparameters > 0 )
  {
    while ( 1 )
    {
      v6 = mDescription->paramdesc[v2];
      if ( v6->type == FMOD_DSP_PARAMETER_TYPE_FLOAT )
        break;
      if ( v6->type == FMOD_DSP_PARAMETER_TYPE_INT )
      {
        result = FMOD::DSPI::setParameterInt(instance, v3, v6->intdesc.defaultval);
        if ( result )
          return result;
LABEL_7:
        mDescription = instance->mDescription.mDescription;
        ++v3;
        ++v2;
        if ( mDescription->numparameters <= v3 )
          return FMOD::DSPTransceiver::init((FMOD::DSPTransceiver *const)instance, dsp_state);
      }
      else
      {
        ++v3;
        ++v2;
        if ( mDescription->numparameters <= v3 )
          return FMOD::DSPTransceiver::init((FMOD::DSPTransceiver *const)instance, dsp_state);
      }
    }
    result = FMOD::DSPI::setParameterFloat(instance, v3, (__m128i)(unsigned int)v6->intdesc.defaultval, v1);
    if ( result )
      return result;
    goto LABEL_7;
  }
  return FMOD::DSPTransceiver::init((FMOD::DSPTransceiver *const)instance, dsp_state);
}


// Address: 0x21f4a50 | Name: _ZN4FMOD14DSPTransceiver7destroyEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::destroy(FMOD::DSPTransceiver *const this, FMOD_DSP_STATE *dsp)
{
  FMOD_RESULT_0 v2; // ebp
  FMOD_OS_CRITICALSECTION *v4; // r12
  FMOD_RESULT_0 updated; // ebx

  v2 = FMOD_RESULT::FMOD_OK_0;
  if ( *((_DWORD *)this + 134) != 1 )
    return v2;
  v4 = FMOD::DSPTransceiver::sCriticalSection;
  FMOD_OS_CriticalSection_Enter(FMOD::DSPTransceiver::sCriticalSection);
  updated = FMOD::DSPTransceiverChannel::updateBufferAllocation(
              &FMOD::DSPTransceiver::sChannel[*((int *)this + 58)][*((int *)this + 183)],
              (FMOD_DSP_TRANSCEIVER_SPEAKERMODE *const)this + 138,
              -1);
  if ( updated )
  {
    FMOD_OS_CriticalSection_Leave(v4);
    return updated;
  }
  FMOD_OS_CriticalSection_Leave(v4);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f4af0 | Name: _ZN4FMOD14DSPTransceiver15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPTransceiver::destroy((FMOD::DSPTransceiver *const)dsp_state->instance, dsp_state);
}


// Address: 0x21f4b00 | Name: _ZN4FMOD14DSPTransceiver12queryProcessEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::queryProcess(
        FMOD::DSPTransceiver *const this,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle)
{
  int v5; // edx
  int v6; // eax
  __int64 v7; // rdx
  FMOD::DSPTransceiverChannel *v8; // rdx
  int v9; // ecx
  int v10; // ecx
  FMOD_RESULT_0 result; // eax

  if ( !outbufferarray )
    return FMOD_RESULT::FMOD_OK_0;
  outbufferarray->speakermode = inbufferarray->speakermode;
  v5 = *inbufferarray->buffernumchannels;
  *outbufferarray->buffernumchannels = v5;
  v6 = 0;
  if ( v5 != 1 )
    v6 = (v5 != 2) + 1;
  v7 = *((int *)this + 133);
  *((_DWORD *)this + 137) = v6;
  v8 = &FMOD::DSPTransceiver::sChannel[*((int *)this + 58)][v7];
  if ( !inputsidle )
    return FMOD_RESULT::FMOD_OK_0;
  v9 = *((_DWORD *)this + 134);
  if ( v9 )
  {
    result = FMOD_RESULT::FMOD_OK_0;
    if ( v9 == 1 )
      return FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
  }
  else
  {
    v10 = 1 - v8->mBackBufferIndex;
    result = FMOD_RESULT::FMOD_OK_0;
    if ( !v8->mBufferDirty[0][v10] && !v8->mBufferDirty[1][v10] )
      return !v8->mBufferDirty[2][v10] ? 0xB : 0;
  }
  return result;
}


// Address: 0x21f4bb0 | Name: _ZN4FMOD14DSPTransceiver7processEPfiS1_iji
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::process(
        FMOD::DSPTransceiver *const this,
        float *inbuffer,
        int inchannels,
        float *outbuffer,
        int outchannels,
        unsigned int frames,
        FMOD_BOOL inputsidle)
{
  float v7; // xmm1_4
  FMOD::DSPTransceiverChannel *v11; // rbx
  FMOD::SystemI *v12; // rsi
  int v14; // r9d
  __int64 v15; // r15
  __int64 v16; // rdx
  __int64 v17; // rax
  __int64 v18; // rax
  float *v19; // r11
  float v20; // xmm1_4
  int v22; // eax
  float *v23; // r14
  float v24; // xmm0_4
  FMOD::DSPConnectionI *v25; // [rsp+18h] [rbp-100h]
  float *frontbuffer; // [rsp+20h] [rbp-F8h]
  float *frontbufferb; // [rsp+20h] [rbp-F8h]
  __int64 speakermode; // [rsp+28h] [rbp-F0h]
  FMOD::DSPConnectionI connection; // [rsp+30h] [rbp-E8h] BYREF

  v11 = &FMOD::DSPTransceiver::sChannel[*((int *)this + 58)][*((int *)this + 133)];
  if ( *((_DWORD *)this + 134) == 1 )
  {
    v22 = *((_DWORD *)this + 138);
    if ( v22 == -1 )
    {
      v22 = 0;
      if ( inchannels != 1 )
        v22 = (inchannels != 2) + 1;
    }
    speakermode = v22;
    frontbuffer = (float *)(2LL * v22);
    v23 = v11->mBufferMemory[(_QWORD)frontbuffer + v11->mBackBufferIndex + 2 + 1];
    memcpy_0(outbuffer, inbuffer, 4LL * frames * inchannels);
    if ( v23 )
    {
      FMOD::DSPConnectionI::mix(
        (FMOD::DSPConnectionI *const)((char *)this + 560),
        v23,
        inbuffer,
        0,
        v11->mBufferChannels[speakermode],
        inchannels,
        frames,
        *((_BYTE *)frontbuffer + (_QWORD)v11 + v11->mBackBufferIndex + 100) ^ 1);
      *((_BYTE *)frontbuffer + (_QWORD)v11 + v11->mBackBufferIndex + 100) = 1;
    }
  }
  else
  {
    connection.mMixMatrixCurrent.mOutChannels = 0;
    v12 = (FMOD::SystemI *)*((_QWORD *)this + 22);
    connection.mInputNode.mNodePrev = &connection.mInputNode;
    connection.mInputNode.mNodeNext = &connection.mInputNode;
    connection.mOutputNode.mNodePrev = &connection.mOutputNode;
    connection.mOutputNode.mNodeNext = &connection.mOutputNode;
    connection.mUserData.mMixMatrixUser.mInChannels = 0;
    connection.mMixMatrix.mOutChannels = 0;
    connection.mMixMatrixCurrent.mInChannels = 0;
    connection.mUserData.mMixMatrixUser.mOutChannels = 0;
    connection.mInputNode.mNodeData = 0;
    connection.mOutputNode.mNodeData = 0;
    connection.mMixMatrix.mData = 0;
    connection.mMixMatrix.mInChannels = 0;
    memset(&connection.mMixMatrixCurrent.mData, 0, 24);
    connection.mUserData.mMixMatrixUser.mData = 0;
    connection.mSystem = 0;
    FMOD::DSPConnectionI::init(&connection, v12, 1.0, v7);
    v14 = inchannels;
    v15 = 0;
    FMOD::DSPConnectionI::mix(&connection, outbuffer, inbuffer, 0, outchannels, v14, frames, 1);
    v25 = (FMOD::DSPConnectionI *)((char *)this + 560);
    do
    {
      v16 = (int)v15;
      v17 = 1 - v11->mBackBufferIndex;
      if ( v11->mBufferDirty[v16][v17] )
      {
        v18 = v17 + v16 * 2 + 2;
        v19 = v11->mBufferMemory[v18 + 1];
        if ( v19 )
        {
          if ( *((_BYTE *)this + 728) )
          {
            v20 = *((float *)this + 135);
            if ( v20 > -80.0 )
            {
              frontbufferb = v11->mBufferMemory[v18 + 1];
              v24 = powf(10.0, v20 / 20.0);
              FMOD::DSPConnectionI::setMix(v25, v24, 0x40u, 0, 1);
              v19 = frontbufferb;
            }
          }
          FMOD::DSPConnectionI::mix(v25, outbuffer, v19, 0, outchannels, v11->mBufferChannels[v15], frames, 0);
        }
      }
      ++v15;
    }
    while ( v15 != 3 );
    *((_BYTE *)this + 728) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f4ed0 | Name: _ZN4FMOD14DSPTransceiver15processCallbackEP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS3_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPTransceiver::processCallback(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  FMOD::DSPTransceiver *instance; // r14
  FMOD_OS_CRITICALSECTION *v10; // rbx
  FMOD_RESULT_0 Process; // ebp

  instance = (FMOD::DSPTransceiver *)dsp_state->instance;
  v10 = FMOD::DSPTransceiver::sCriticalSection;
  FMOD_OS_CriticalSection_Enter(FMOD::DSPTransceiver::sCriticalSection);
  if ( op == FMOD_DSP_PROCESS_QUERY )
    Process = FMOD::DSPTransceiver::queryProcess(instance, length, inbufferarray, outbufferarray, inputsidle);
  else
    Process = FMOD::DSPTransceiver::process(
                instance,
                *inbufferarray->buffers,
                *inbufferarray->buffernumchannels,
                *outbufferarray->buffers,
                *outbufferarray->buffernumchannels,
                length,
                inputsidle);
  FMOD_OS_CriticalSection_Leave(v10);
  return Process;
}


