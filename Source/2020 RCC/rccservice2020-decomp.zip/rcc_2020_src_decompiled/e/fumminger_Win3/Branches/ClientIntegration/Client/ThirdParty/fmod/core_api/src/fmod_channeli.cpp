// Address: 0x21b1ff0 | Name: _ZN4FMOD8ChannelI15getSystemObjectEPPNS_6SystemE
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getSystemObject(FMOD::ChannelI *const this, FMOD::System **system)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( system )
  {
    *system = (FMOD::System *)this->mSystem;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b2010 | Name: _ZN4FMOD8ChannelI9getPausedEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getPaused(FMOD::ChannelI *const this, bool *paused)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( paused )
  {
    LOBYTE(result) = 30;
    if ( this->mRealChannel )
    {
      *paused = this->mFlags & 1;
      *paused = *paused;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21b2040 | Name: _ZN4FMOD8ChannelI9getVolumeEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getVolume(FMOD::ChannelI *const this, float *volume)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( volume )
  {
    LOBYTE(result) = 30;
    if ( this->mRealChannel )
    {
      LOBYTE(result) = 0;
      *volume = this->mVolume;
    }
  }
  return result;
}


// Address: 0x21b2070 | Name: _ZN4FMOD8ChannelI14setLowPassGainEf
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setLowPassGain(FMOD::ChannelI *const this, __m128i a2, float gain)
{
  FMOD::ChannelReal *mRealChannel; // rax
  double v4; // xmm1_8
  int (**vptr_ChannelReal)(...); // rdx

  mRealChannel = this->mRealChannel;
  if ( !mRealChannel || !this->mChannelGroupParent )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( (_mm_cvtsi128_si32(a2) & 0x7F800000) == 0x7F800000 )
    return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  v4 = 0.0;
  if ( *(float *)a2.m128i_i32 >= 0.0 )
  {
    HIDWORD(v4) = 0;
    *(float *)&v4 = fminf(1.0, *(float *)a2.m128i_i32);
  }
  vptr_ChannelReal = mRealChannel->_vptr_ChannelReal;
  this->mLowPassGain = *(float *)&v4;
  return (FMOD_RESULT_0)vptr_ChannelReal[21](mRealChannel, v4, v4);
}


// Address: 0x21b2100 | Name: _ZN4FMOD8ChannelI14getLowPassGainEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getLowPassGain(FMOD::ChannelI *const this, float *gain)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( this->mRealChannel )
  {
    LOBYTE(result) = 31;
    if ( gain )
    {
      LOBYTE(result) = 0;
      *gain = this->mLowPassGain;
    }
  }
  return result;
}


// Address: 0x21b2130 | Name: _ZN4FMOD8ChannelI22updateReverbConnectionEi
FMOD_RESULT_0 __fastcall FMOD::ChannelI::updateReverbConnection(FMOD::ChannelI *const this, int instance)
{
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, float))this->mRealChannel->_vptr_ChannelReal + 22))(
           this->mRealChannel,
           this->mReverbLevel[instance]);
}


// Address: 0x21b2160 | Name: _ZN4FMOD8ChannelI9isVirtualEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::isVirtual(FMOD::ChannelI *const this, bool *isvirtual)
{
  FMOD::ChannelReal *mRealChannel; // rdi

  if ( !isvirtual )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *))mRealChannel->_vptr_ChannelReal + 24))(mRealChannel);
  *isvirtual = 0;
  return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x21b21a0 | Name: _ZN4FMOD8ChannelI16updateAudibilityEv
FMOD_RESULT_0 __fastcall FMOD::ChannelI::updateAudibility(FMOD::ChannelI *const this)
{
  this->mFlags |= 0x1000000u;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b21b0 | Name: _ZN4FMOD8ChannelI11getDSPClockEPyS1_
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getDSPClock(
        FMOD::ChannelI *const this,
        FMOD_CLOCKTIME *dspclock,
        FMOD_CLOCKTIME *parentclock)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *v5; // rax
  FMOD::ChannelGroupI *mChannelGroupParent; // rdi
  FMOD::DSPI *dsptail; // [rsp+0h] [rbp-28h] BYREF
  FMOD::DSPI *parentTail[4]; // [rsp+8h] [rbp-20h] BYREF

  if ( !dspclock )
    goto LABEL_5;
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI
            + 36))(
             this,
             4294967293LL,
             &dsptail);
  if ( result )
    return result;
  v5 = dsptail;
  if ( dsptail )
  {
LABEL_4:
    *dspclock = v5->mJob.mDelayClock.mClockNext;
LABEL_5:
    if ( !parentclock )
      return FMOD_RESULT::FMOD_OK_0;
    mChannelGroupParent = this->mChannelGroupParent;
    parentTail[0] = 0;
    if ( mChannelGroupParent )
    {
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **))mChannelGroupParent->_vptr_ChannelControlI
                + 36))(
                 mChannelGroupParent,
                 4294967293LL,
                 parentTail);
      if ( result )
        return result;
      if ( parentTail[0] )
      {
        *parentclock = parentTail[0]->mJob.mDelayClock.mClockNext;
        return result;
      }
    }
    return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
  }
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI
            + 36))(
             this,
             0xFFFFFFFFLL,
             parentTail);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v5 = parentTail[0];
    if ( !parentTail[0] )
      return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
    goto LABEL_4;
  }
  return result;
}


// Address: 0x21b2280 | Name: _ZN4FMOD8ChannelI7setModeEj
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setMode(FMOD::ChannelI *const this, FMOD_MODE mode)
{
  FMOD_RESULT_0 v2; // ebp
  FMOD::ChannelReal *mRealChannel; // rdi
  FMOD_MODE mMode; // r13d
  FMOD_MODE v6; // edx
  float v7; // xmm0_4
  int (**vptr_ChannelControlI)(...); // rax
  FMOD_VECTOR pos; // [rsp+0h] [rbp-38h] BYREF

  v2 = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  mRealChannel = this->mRealChannel;
  if ( !mRealChannel )
    return v2;
  if ( !this->mChannelGroupParent )
    return v2;
  mMode = mRealChannel->mMode;
  v2 = (*((unsigned int (**)(void))mRealChannel->_vptr_ChannelReal + 25))();
  if ( v2 )
    return v2;
  if ( (mMode & 8) == 0 && (mode & 8) != 0 )
  {
    v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, _QWORD, float))this->_vptr_ChannelControlI + 4))(
           this,
           0,
           this->mVolume);
    if ( v2 )
      return v2;
    (*((void (__fastcall **)(FMOD::ChannelI *const, float *, _QWORD, _QWORD, _QWORD, _QWORD))this->_vptr_ChannelControlI
     + 25))(
      this,
      this->mMixMatrix.mData,
      (unsigned int)this->mMixMatrix.mOutChannels,
      (unsigned int)this->mMixMatrix.mInChannels,
      0,
      0);
    v6 = mode ^ mMode;
    goto LABEL_9;
  }
  if ( ((mMode & 0x10) != 0 || (mode & 0x10) == 0) && (v6 = mMode ^ mode, ((mMode ^ mode) & 0x4F00000) == 0)
    || (v7 = this->mPosition3D.x + 1.0,
        pos = this->mPosition3D,
        vptr_ChannelControlI = this->_vptr_ChannelControlI,
        this->mPosition3D.x = v7,
        v2 = vptr_ChannelControlI[40](this, &pos, &this->mVelocity3D),
        v6 = mode ^ mMode,
        v2 == FMOD_RESULT::FMOD_OK_0) )
  {
LABEL_9:
    v2 = FMOD_RESULT::FMOD_OK_0;
    if ( (v6 & 0x40000000) != 0 )
    {
      if ( (mode & 0x40000000) != 0 )
        (*((void (__fastcall **)(FMOD::ChannelI *const, __int64, float, float))this->_vptr_ChannelControlI + 51))(
          this,
          1,
          this->mUserDirectOcclusion,
          this->mUserReverbOcclusion);
      else
        this->mFlags |= 4u;
    }
  }
  return v2;
}


// Address: 0x21b23f0 | Name: _ZN4FMOD8ChannelI7getModeEPj
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getMode(FMOD::ChannelI *const this, FMOD_MODE *mode)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rdx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( mode )
  {
    mRealChannel = this->mRealChannel;
    LOBYTE(result) = 30;
    if ( mRealChannel )
    {
      *mode = mRealChannel->mMode;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21b2420 | Name: _ZN4FMOD8ChannelI17setMixLevelsInputEPfi
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setMixLevelsInput(FMOD::ChannelI *const this, float *levels, int numlevels)
{
  __int64 v3; // xmm0_8
  FMOD::ChannelReal *mRealChannel; // rcx
  FMOD_RESULT_0 result; // eax
  FMOD::SoundI *mSound; // rdi
  int mChannels; // r10d
  __int64 v9; // r8
  int v10; // eax
  float *v11; // r9
  float *v12; // r8
  FMOD::DSPI *mDSP; // rcx
  float matrix[1026]; // [rsp+0h] [rbp-1008h] BYREF

  mRealChannel = this->mRealChannel;
  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( mRealChannel && this->mChannelGroupParent )
  {
    mSound = mRealChannel->mSound;
    if ( mSound )
    {
      mChannels = mSound->mChannels;
    }
    else
    {
      mDSP = mRealChannel->mDSP;
      if ( !mDSP )
        return result;
      mChannels = mDSP->mDescription.mChannels;
    }
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( numlevels > 0 )
    {
      v9 = 0;
      do
      {
        if ( (LODWORD(levels[v9]) & 0x7F800000) == 0x7F800000 )
          return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
        ++v9;
      }
      while ( numlevels > (int)v9 );
      v10 = 0;
      v11 = levels;
      v12 = matrix;
      memset(matrix, 0, 0x1000u);
      if ( mChannels > 0 )
      {
        do
        {
          v3 = 1065353216;
          if ( numlevels > v10 )
            v3 = *(unsigned int *)v11;
          ++v10;
          *(_DWORD *)v12 = v3;
          ++v11;
          v12 += 33;
        }
        while ( v10 != mChannels );
      }
      return (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, float *, _QWORD, _QWORD, __int64, __int64, double, double))this->_vptr_ChannelControlI
              + 25))(
               this,
               matrix,
               (unsigned int)mChannels,
               (unsigned int)mChannels,
               32,
               1,
               *(double *)&v3,
               COERCE_DOUBLE(1065353216));
    }
  }
  return result;
}


// Address: 0x21b2530 | Name: _ZN4FMOD8ChannelI12setMixMatrixEPfiiib
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setMixMatrix(
        FMOD::ChannelI *const this,
        float *matrix,
        int outchannels,
        int inchannels,
        int inchannel_hop,
        bool updatematrix)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rdx
  bool virt; // [rsp+17h] [rbp-41h] BYREF
  FMOD::DSPFader *fader; // [rsp+18h] [rbp-40h] BYREF

  virt = 0;
  result = FMOD::ChannelControlI::setMixMatrix(this, matrix, outchannels, inchannels, inchannel_hop, updatematrix);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mRealChannel = this->mRealChannel;
    result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    if ( mRealChannel )
    {
      if ( this->mChannelGroupParent )
      {
        if ( updatematrix && (mRealChannel->mMode & 0x10) != 0 )
          return FMOD_RESULT::FMOD_OK_0;
        (*((void (__fastcall **)(FMOD::ChannelI *const, bool *))this->_vptr_ChannelControlI + 62))(this, &virt);
        if ( virt )
        {
          return FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, __int64, FMOD::DSPFader **))this->_vptr_ChannelControlI
                    + 36))(
                     this,
                     4294967294LL,
                     &fader);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
            return FMOD::DSPFader::setMixMatrix(
                     fader,
                     matrix,
                     outchannels,
                     inchannels,
                     inchannel_hop,
                     (this->mFlags & 0xC0000) == 0 ? FMOD_RESULT::FMOD_ERR_TOOMANYCHANNELS_0 : FMOD_RESULT::FMOD_OK_0,
                     (HIWORD(this->mRealChannel->mFlags) ^ 1) & 1);
        }
      }
    }
  }
  return result;
}


// Address: 0x21b2610 | Name: _ZN4FMOD8ChannelI14updateDSPUnitsEPNS_4DSPIES2_
FMOD_RESULT_0 __fastcall FMOD::ChannelI::updateDSPUnits(
        FMOD::ChannelI *const this,
        FMOD::DSPI *newdsphead,
        FMOD::DSPI *newdsptail)
{
  float v3; // xmm1_4
  FMOD::DSPI *mDSPHead; // r12
  FMOD::DSPI *mDSPTail; // r14
  FMOD::DSPFader *mDSPFader; // r13
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *v9; // r8
  bool v10; // bp
  FMOD::ChannelReal *mRealChannel; // rdi
  FMOD::DSPI *dsphead; // [rsp+8h] [rbp-60h]
  bool paused; // [rsp+1Eh] [rbp-4Ah] BYREF
  bool delay_stopchannels; // [rsp+1Fh] [rbp-49h] BYREF
  FMOD_CLOCKTIME delay_start; // [rsp+20h] [rbp-48h] BYREF
  FMOD_CLOCKTIME delay_end[8]; // [rsp+28h] [rbp-40h] BYREF

  mDSPHead = this->mDSPHead;
  mDSPTail = this->mDSPTail;
  mDSPFader = this->mDSPFader;
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, bool *))this->_vptr_ChannelControlI + 3))(
             this,
             &paused);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v9 = mDSPHead;
    this->mDSPFader = mDSPFader;
    if ( newdsphead )
      v9 = newdsphead;
    if ( !newdsptail )
      newdsptail = mDSPTail;
    this->mDSPHead = v9;
    dsphead = v9;
    this->mDSPTail = newdsptail;
    if ( newdsphead )
    {
      v10 = paused;
      result = FMOD::DSPI::getDelay(mDSPHead, &delay_start, delay_end, &delay_stopchannels);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD::DSPI::setDelay(dsphead, delay_start, delay_end[0], delay_stopchannels);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = FMOD::DSPI::setPitch(dsphead, v3, 1);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = FMOD::DSPI::setActive(dsphead, !v10, 1);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              result = FMOD::DSPI::setDelay(mDSPHead, 0, 0, 0);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                result = FMOD::DSPI::setPitch(mDSPHead, v3, 1);
                if ( result == FMOD_RESULT::FMOD_OK_0
                  && (mDSPHead == (FMOD::DSPI *)mDSPFader
                   || (result = FMOD::DSPI::setActive(mDSPHead, 1, 1)) == FMOD_RESULT::FMOD_OK_0) )
                {
                  mRealChannel = this->mRealChannel;
                  if ( !mRealChannel )
                    return FMOD_RESULT::FMOD_OK_0;
                  if ( !paused )
                    return FMOD_RESULT::FMOD_OK_0;
                  result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, __int64, double))mRealChannel->_vptr_ChannelReal
                            + 11))(
                             mRealChannel,
                             1,
                             COERCE_DOUBLE(1065353216));
                  if ( result == FMOD_RESULT::FMOD_OK_0 )
                    return FMOD_RESULT::FMOD_OK_0;
                }
              }
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21b2770 | Name: _ZN4FMOD8ChannelI17getNumSubChannelsEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getNumSubChannels(FMOD::ChannelI *const this, int *numchannels)
{
  FMOD::ChannelReal *mRealChannel; // rax
  FMOD::SoundI *mSound; // rdi
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *mDSP; // rdx

  mRealChannel = this->mRealChannel;
  if ( !mRealChannel || !this->mChannelGroupParent )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  mSound = mRealChannel->mSound;
  if ( mSound )
    return FMOD::SoundI::getCodecChannels(mSound, numchannels);
  mDSP = mRealChannel->mDSP;
  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( mDSP )
  {
    *numchannels = mDSP->mDescription.mChannels;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b27c0 | Name: _ZN4FMOD8ChannelI22set3DOcclusionInternalEffb
char __fastcall FMOD::ChannelI::set3DOcclusionInternal(
        FMOD::ChannelI *const this,
        float a2,
        float direct,
        float reverb,
        bool resettarget)
{
  FMOD::ChannelReal *mRealChannel; // rdx
  char result; // al
  float v7; // xmm2_4
  float v8; // xmm4_4

  mRealChannel = this->mRealChannel;
  result = 30;
  if ( mRealChannel )
  {
    if ( this->mChannelGroupParent )
    {
      result = 40;
      if ( (mRealChannel->mMode & 0x10) != 0 )
      {
        v7 = 0.0;
        if ( a2 >= 0.0 || (v8 = 0.0, a2 > 1.0) )
          v8 = fminf(1.0, a2);
        this->mDirectOcclusion = v8;
        if ( direct >= 0.0 || direct > 1.0 )
          v7 = fminf(1.0, direct);
        result = 0;
        this->mReverbOcclusion = v7;
        if ( resettarget )
        {
          this->mDirectOcclusionTarget = v8;
          this->mReverbOcclusionTarget = v7;
        }
      }
    }
  }
  return result;
}


// Address: 0x21b2860 | Name: _ZN4FMOD8ChannelI14set3DOcclusionEff
FMOD_RESULT_0 __fastcall FMOD::ChannelI::set3DOcclusion(
        FMOD::ChannelI *const this,
        __m128i a2,
        __m128i direct,
        float reverb)
{
  FMOD::ChannelReal *mRealChannel; // rdx
  FMOD_RESULT_0 result; // eax
  float v6; // xmm2_4
  float v7; // xmm0_4
  int (**vptr_ChannelControlI)(...); // rax

  mRealChannel = this->mRealChannel;
  if ( !mRealChannel || !this->mChannelGroupParent )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
  if ( (mRealChannel->mMode & 0x10) != 0 )
  {
    if ( (_mm_cvtsi128_si32(a2) & 0x7F800000) == 0x7F800000 || (_mm_cvtsi128_si32(direct) & 0x7F800000) == 0x7F800000 )
    {
      return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
    }
    else
    {
      v6 = 0.0;
      if ( *(float *)a2.m128i_i32 < 0.0 && *(float *)a2.m128i_i32 <= 1.0 )
        v7 = 0.0;
      else
        v7 = fminf(1.0, *(float *)a2.m128i_i32);
      this->mUserDirectOcclusion = v7;
      if ( *(float *)direct.m128i_i32 >= 0.0 || *(float *)direct.m128i_i32 > 1.0 )
        v6 = fminf(1.0, *(float *)direct.m128i_i32);
      vptr_ChannelControlI = this->_vptr_ChannelControlI;
      this->mUserReverbOcclusion = v6;
      return (FMOD_RESULT_0)vptr_ChannelControlI[51](this, 0, this->mDirectOcclusion, this->mReverbOcclusion);
    }
  }
  return result;
}


// Address: 0x21b2940 | Name: _ZN4FMOD8ChannelI14get3DOcclusionEPfS1_
FMOD_RESULT_0 __fastcall FMOD::ChannelI::get3DOcclusion(
        FMOD::ChannelI *const this,
        float *directOcclusion,
        float *reverbOcclusion)
{
  FMOD::ChannelReal *mRealChannel; // rcx
  FMOD_RESULT_0 result; // eax

  mRealChannel = this->mRealChannel;
  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( mRealChannel )
  {
    if ( this->mChannelGroupParent )
    {
      LOBYTE(result) = 40;
      if ( (mRealChannel->mMode & 0x10) != 0 )
      {
        if ( directOcclusion )
          *directOcclusion = this->mUserDirectOcclusion;
        if ( reverbOcclusion )
          *reverbOcclusion = this->mUserReverbOcclusion;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21b29a0 | Name: _ZN4FMOD8ChannelI11setCallbackEPF11FMOD_RESULTP19FMOD_CHANNELCONTROL24FMOD_CHANNELCONTROL_TYPE33FMOD_CHANNELCONTROL_CALLBACK_TYPEPvS6_E
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setCallback(FMOD::ChannelI *const this, FMOD_CHANNELCONTROL_CALLBACK callback)
{
  if ( this->mRealChannel && this->mChannelGroupParent )
    return FMOD::ChannelControlI::setCallback(this, callback);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x21b29d0 | Name: _ZN4FMOD8ChannelI9setVolumeEfb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setVolume(
        FMOD::ChannelI *const this,
        float a2,
        float volume,
        bool forceupdatepos)
{
  FMOD::ChannelReal *mRealChannel; // rdi
  bool v6; // zf
  float mVolume; // xmm1_4
  double v8; // xmm0_8
  FMOD_RESULT_0 result; // eax

  if ( (LODWORD(a2) & 0x7F800000) == 0x7F800000 )
    return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  mRealChannel = this->mRealChannel;
  if ( !mRealChannel || !this->mDSPFader )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  v6 = (this->mFlags & 2) == 0;
  mVolume = this->mVolume;
  v8 = 0.0;
  this->mVolume = a2;
  if ( v6 )
    *(_QWORD *)&v8 = LODWORD(a2);
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, double))mRealChannel->_vptr_ChannelReal + 13))(
             mRealChannel,
             v8);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( a2 != mVolume || forceupdatepos )
    {
      result = FMOD_RESULT::FMOD_OK_0;
      if ( (this->mRealChannel->mFlags & 0x10000) == 0 )
        return FMOD::ChannelControlI::update(this, 0, 0, forceupdatepos);
    }
    else
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21b2ac0 | Name: _ZN4FMOD8ChannelI18setMixLevelsOutputEffffffff
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setMixLevelsOutput(
        FMOD::ChannelI *const this,
        float a2,
        float frontleft,
        float frontright,
        float center,
        float lfe,
        float surroundleft,
        float surroundright,
        __m128i backleft)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rdx
  FMOD::SoundI *mSound; // rcx
  int mChannels; // esi
  FMOD_CHANNELORDER_0 mDefaultChannelOrder; // edx
  FMOD_SPEAKERMODE_0 mSpeakerMode; // eax
  __int64 mDSPMaxOutputChannels; // rdx
  FMOD::DSPI *mDSP; // rdx
  int numinputlevels; // [rsp+1Ch] [rbp-101Ch] BYREF
  float levels[1030]; // [rsp+20h] [rbp-1018h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  if ( (LODWORD(surroundleft) & 0x7F800000) != 0x7F800000
    && (LODWORD(surroundright) & 0x7F800000) != 0x7F800000
    && (_mm_cvtsi128_si32(backleft) & 0x7F800000) != 0x7F800000 )
  {
    mRealChannel = this->mRealChannel;
    result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    if ( mRealChannel )
    {
      if ( this->mChannelGroupParent )
      {
        mSound = mRealChannel->mSound;
        if ( mSound )
        {
          mChannels = mSound->mChannels;
          mDefaultChannelOrder = mSound->mDefaultChannelOrder;
        }
        else
        {
          mDSP = mRealChannel->mDSP;
          if ( !mDSP )
            return result;
          mChannels = mDSP->mDescription.mChannels;
          mDefaultChannelOrder = FMOD_CHANNELORDER::FMOD_CHANNELORDER_DEFAULT_0;
        }
        result = FMOD::DSPI::calculateSpeakerLevels(
                   a2,
                   frontleft,
                   frontright,
                   center,
                   lfe,
                   surroundleft,
                   surroundright,
                   *(float *)backleft.m128i_i32,
                   this->mSpeakerMode,
                   mChannels,
                   mDefaultChannelOrder,
                   levels,
                   &numinputlevels);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          mSpeakerMode = this->mSpeakerMode;
          if ( mSpeakerMode == 1000 || mSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
            mDSPMaxOutputChannels = 2;
          else
            mDSPMaxOutputChannels = (unsigned int)this->mSystem->mDSPMaxOutputChannels;
          return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelI *const, float *, __int64, _QWORD, _QWORD, __int64))this->_vptr_ChannelControlI
                  + 25))(
                   this,
                   levels,
                   mDSPMaxOutputChannels,
                   (unsigned int)numinputlevels,
                   0,
                   1);
        }
      }
    }
  }
  return result;
}


// Address: 0x21b2c00 | Name: _ZN4FMOD8ChannelI18setMixLevelsOutputEffffffff_0
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setMixLevelsOutput(
        FMOD::ChannelI *const this,
        float a2,
        float frontleft,
        __m128i frontright,
        __m128i center,
        __m128i lfe,
        float surroundleft,
        float surroundright,
        __m128i backleft)
{
  if ( (LODWORD(a2) & 0x7F800000) == 0x7F800000
    || (LODWORD(frontleft) & 0x7F800000) == 0x7F800000
    || (_mm_cvtsi128_si32(frontright) & 0x7F800000) == 0x7F800000
    || (_mm_cvtsi128_si32(center) & 0x7F800000) == 0x7F800000
    || (_mm_cvtsi128_si32(lfe) & 0x7F800000) == 0x7F800000 )
  {
    return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  }
  else
  {
    return FMOD::ChannelI::setMixLevelsOutput(
             this,
             a2,
             frontleft,
             *(float *)frontright.m128i_i32,
             *(float *)center.m128i_i32,
             *(float *)lfe.m128i_i32,
             surroundleft,
             surroundright,
             backleft);
  }
}


// Address: 0x21b2c90 | Name: _ZN4FMOD8ChannelI19setReverbPropertiesEif
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setReverbProperties(
        FMOD::ChannelI *const this,
        unsigned int instance,
        double a3,
        float wet)
{
  FMOD::ChannelReal *mRealChannel; // rdx
  FMOD_RESULT_0 result; // eax

  mRealChannel = this->mRealChannel;
  if ( !mRealChannel || !this->mChannelGroupParent )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  result = FMOD_RESULT::FMOD_ERR_REVERB_CHANNELGROUP_0;
  if ( (mRealChannel->mFlags & 0x10000) == 0 )
  {
    result = FMOD::ChannelControlI::setReverbProperties(this, instance, wet);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelI *const, _QWORD))this->_vptr_ChannelControlI + 15))(
               this,
               instance);
  }
  return result;
}


// Address: 0x21b2cf0 | Name: _ZN4FMOD8ChannelI9isPlayingEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::isPlaying(FMOD::ChannelI *const this, bool *isplaying)
{
  FMOD_RESULT_0 result; // eax
  char *mRealChannel; // rdi
  FMOD::ChannelReal *v5; // rax
  bool v6; // zf
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::SystemI *mSystem; // rcx
  FMOD::SoundI *mSound; // rdx
  FMOD::LinkedListNode *v10; // rax
  FMOD::SoundGroupI *mSoundGroup; // rdx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( isplaying )
  {
    mRealChannel = (char *)this->mRealChannel;
    *isplaying = 0;
    LOBYTE(result) = 30;
    if ( mRealChannel )
    {
      if ( mRealChannel[60] < 0 )
        return FMOD_RESULT::FMOD_OK_0;
      result = (*(unsigned int (__fastcall **)(char *, bool *, _QWORD))(*(_QWORD *)mRealChannel + 184LL))(
                 mRealChannel,
                 isplaying,
                 0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( !*isplaying )
        {
          v5 = this->mRealChannel;
          if ( (v5->mFlags & 0x10000) == 0 )
          {
            v6 = this->mSortedListNode.mNodeData == 0;
            this->mListPosition = -1;
            if ( !v6 )
            {
              mNodePrev = this->mSortedListNode.mNodePrev;
              mNodePrev->mNodeNext = this->mSortedListNode.mNodeNext;
              this->mSortedListNode.mNodeNext->mNodePrev = mNodePrev;
              mSystem = this->mSystem;
              this->mSortedListNode.mNodePriority = -1;
              this->mSortedListNode.mNodePrev = &this->mSortedListNode;
              this->mSortedListNode.mNodePrev = mSystem->mChannelSortedListHead.mNodePrev;
              this->mSortedListNode.mNodeNext = &mSystem->mChannelSortedListHead;
              mSystem->mChannelSortedListHead.mNodePrev = &this->mSortedListNode;
              this->mSortedListNode.mNodePrev->mNodeNext = &this->mSortedListNode;
              this->mSortedListNode.mNodeData = this;
            }
            if ( this->mSoundGroupSortedListNode.mNodeData )
            {
              mSound = v5->mSound;
              if ( mSound )
              {
                v10 = this->mSoundGroupSortedListNode.mNodePrev;
                mSoundGroup = mSound->mSoundGroup;
                v10->mNodeNext = this->mSoundGroupSortedListNode.mNodeNext;
                this->mSoundGroupSortedListNode.mNodeNext->mNodePrev = v10;
                this->mSoundGroupSortedListNode.mNodePriority = -1;
                this->mSoundGroupSortedListNode.mNodePrev = &this->mSoundGroupSortedListNode;
                this->mSoundGroupSortedListNode.mNodePrev = mSoundGroup->mChannelListHead.mNodePrev;
                this->mSoundGroupSortedListNode.mNodeNext = &mSoundGroup->mChannelListHead;
                mSoundGroup->mChannelListHead.mNodePrev = &this->mSoundGroupSortedListNode;
                this->mSoundGroupSortedListNode.mNodePrev->mNodeNext = &this->mSoundGroupSortedListNode;
                this->mSoundGroupSortedListNode.mNodeData = this;
                return FMOD_RESULT::FMOD_OK_0;
              }
            }
          }
        }
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21b2e60 | Name: _ZN4FMOD8ChannelI8validateEPNS_7ChannelEPPS0_PNS_15SystemLockScopeE
FMOD_RESULT_0 __fastcall FMOD::ChannelI::validate(
        FMOD::Channel *channel,
        FMOD::ChannelI **channeli,
        FMOD::SystemLockScope *lockScope)
{
  FMOD_RESULT_0 result; // eax
  __int64 v4; // r12
  FMOD::SystemI *v5; // r14
  FMOD::ChannelI *mChannel; // rcx
  unsigned int v7; // r13d
  FMOD::ChannelI *v8; // rcx
  FMOD_UINT_NATIVE mHandleCurrent; // rax
  FMOD::SystemI *sys; // [rsp+18h] [rbp-30h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channeli )
  {
    *channeli = 0;
    v4 = (unsigned __int16)((unsigned int)channel >> 1);
    if ( !(unsigned __int16)((unsigned int)channel >> 1)
      || FMOD::SystemI::getInstance((unsigned int)channel >> 29, &sys) )
    {
      return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    }
    v5 = sys;
    result = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
    mChannel = sys->mChannel;
    if ( !mChannel )
      return result;
    v7 = ((unsigned int)channel >> 17) & 0xFFF;
    if ( (signed int)v7 >= sys->mNumChannels )
      return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    if ( lockScope )
    {
      LOBYTE(result) = 28;
      if ( lockScope->mSystem )
        return result;
      result = FMOD::SystemI::enterMainUpdateLock(sys);
      if ( result )
        return result;
      mChannel = sys->mChannel;
      lockScope->mSystem = v5;
    }
    v8 = &mChannel[v7];
    if ( (_DWORD)v4 == 0xFFFF || (mHandleCurrent = v8->mHandleCurrent, mHandleCurrent == (unsigned int)channel) )
    {
      *channeli = v8;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      return (unsigned __int64)(unsigned __int16)(mHandleCurrent >> 1) - v4 < 2 ? 30 : 3;
    }
  }
  return result;
}


// Address: 0x21b2f60 | Name: _ZN4FMOD8ChannelI16returnToFreeListEv
FMOD_RESULT_0 __fastcall FMOD::ChannelI::returnToFreeList(FMOD::ChannelI *const this)
{
  FMOD::SystemI *mSystem; // rdx
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::LinkedListNode *mNodeNext; // rcx
  FMOD::LinkedListNode *v5; // rax
  FMOD::LinkedListNode *v6; // rsi
  FMOD::LinkedListNode *v7; // rcx
  FMOD::LinkedListNode *v8; // rcx

  mSystem = this->mSystem;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( mSystem )
  {
    mNodePrev = this->mSortedListNode.mNodePrev;
    mNodePrev->mNodeNext = this->mSortedListNode.mNodeNext;
    this->mSortedListNode.mNodeNext->mNodePrev = mNodePrev;
    mNodeNext = this->mSoundGroupSortedListNode.mNodeNext;
    this->mSortedListNode.mNodePriority = -1;
    this->mSortedListNode.mNodeData = 0;
    this->mSortedListNode.mNodeNext = &this->mSortedListNode;
    this->mSortedListNode.mNodePrev = &this->mSortedListNode;
    v5 = this->mSoundGroupSortedListNode.mNodePrev;
    v5->mNodeNext = mNodeNext;
    v6 = this->mNodeNext;
    this->mSoundGroupSortedListNode.mNodeNext->mNodePrev = v5;
    v7 = this->mNodePrev;
    this->mSoundGroupSortedListNode.mNodePriority = -1;
    this->mSoundGroupSortedListNode.mNodeData = 0;
    this->mSoundGroupSortedListNode.mNodeNext = &this->mSoundGroupSortedListNode;
    this->mSoundGroupSortedListNode.mNodePrev = &this->mSoundGroupSortedListNode;
    v7->mNodeNext = v6;
    this->mNodeNext->mNodePrev = v7;
    this->mNodeNext = &this->FMOD::LinkedListNode;
    v8 = mSystem->mChannelFreeListHead.mNodeNext;
    this->mNodePrev = &mSystem->mChannelFreeListHead.FMOD::LinkedListNode;
    this->mNodeNext = v8;
    v8->mNodePrev = &this->FMOD::LinkedListNode;
    this->mNodePrev->FMOD::LinkedListNode::mNodeNext = &this->FMOD::LinkedListNode;
    --mSystem->mNumChannelsPlaying;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b3060 | Name: _ZN4FMOD8ChannelI14referenceStampEb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::referenceStamp(FMOD::ChannelI *const this, bool newstamp)
{
  FMOD_UINT_NATIVE mHandleCurrent; // rdx
  unsigned int v3; // eax
  __int64 v4; // r8
  int v5; // ecx
  unsigned int v6; // ecx
  int v7; // edx
  unsigned int v8; // eax

  mHandleCurrent = this->mHandleCurrent;
  v3 = (unsigned int)mHandleCurrent >> 29;
  v4 = (mHandleCurrent >> 17) & 0xFFF;
  if ( newstamp )
    v5 = (unsigned __int16)(mHandleCurrent >> 1);
  else
    v5 = (unsigned __int16)((unsigned __int64)this->mHandleOriginal >> 1);
  v6 = v5 + 1;
  v7 = 2;
  if ( v6 <= 0xFFFE )
    v7 = 2 * v6;
  v8 = v7 | ((_DWORD)v4 << 17) | (v3 << 29) | 1;
  this->mHandleCurrent = v8;
  if ( newstamp )
    this->mHandleOriginal = v8;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b30e0 | Name: _ZN4FMOD8ChannelI14getRealChannelEPPNS_11ChannelRealE
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getRealChannel(FMOD::ChannelI *const this, FMOD::ChannelReal **realchan)
{
  bool v2; // zf
  FMOD::ChannelReal *mRealChannel; // rax

  v2 = (*this->mRealChannel->_vptr_ChannelReal)(this->mRealChannel) == 0;
  mRealChannel = this->mRealChannel;
  if ( v2 )
    *realchan = mRealChannel;
  else
    *realchan = *(FMOD::ChannelReal **)&mRealChannel[1].mDirection;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b3340 | Name: _ZN4FMOD8ChannelI4initEiPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::ChannelI::init(FMOD::ChannelI *const this, int index, FMOD::SystemI *system)
{
  int v4; // eax
  unsigned int v5; // eax
  FMOD::FMOD_DSP_DESCRIPTION_EX *Description; // rax
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *v9; // rdx
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-50h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_EX description_ex; // [rsp+10h] [rbp-48h] BYREF

  v4 = *(_DWORD *)((char *)&stru_115E0.r_offset + (_QWORD)system);
  this->mIndex = index;
  this->mSystem = system;
  dspi = 0;
  v5 = (index << 17) & 0x1FFE0000 | (v4 << 29) | 2;
  this->mHandleOriginal = v5;
  this->mHandleCurrent = v5;
  Description = FMOD::DSPFader::getDescriptionEx();
  mSystem = this->mSystem;
  description_ex = *Description;
  description_ex.mName = "Channel Fader";
  result = FMOD::SystemI::createDSP(mSystem, &description_ex, 0, &dspi, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v9 = dspi;
    this->mDSPFader = (FMOD::DSPFader *)dspi;
    this->mDSPTail = v9;
    this->mDSPHead = v9;
    v9->mJob.mFlags |= 0x180u;
  }
  return result;
}


// Address: 0x21b3410 | Name: _ZN4FMOD8ChannelI5allocEPNS_6SoundIEb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::alloc(FMOD::ChannelI *const this, FMOD::SoundI *sound, bool reset)
{
  FMOD::ChannelReal *mRealChannel; // rcx
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *mSystem; // rdx
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // eax
  float mMaxDistance; // xmm0_4
  FMOD_VECTOR *mRolloffPoint; // rax
  float mConeOutsideAngle; // xmm0_4
  float mConeOutsideVolume; // xmm0_4
  float distanceFilterCenterFreq; // xmm0_4
  FMOD_MODE mMode; // eax
  unsigned int mLength; // eax
  FMOD::DSPI *mDSPHead; // rdi
  FMOD::SoundI *mSubSoundParent; // rdx
  FMOD::DSPI *dsptail; // [rsp+8h] [rbp-30h] BYREF

  if ( reset )
  {
    mRealChannel = this->mRealChannel;
    this->mSyncPointCurrent = 0;
    this->mNumDSPs = 1;
    this->mDSP = 0;
    this->mUserData = 0;
    mSystem = this->mSystem;
    if ( (mRealChannel->mFlags & 0x10000) == 0 )
      this->mSpeakerMode = mSystem->mSpeakerMode;
    mFlags = this->mFlags;
    this->mMinDistance = sound->mMinDistance;
    this->mVirtualDSPTick = 0;
    this->mLowPassGain = 1.0;
    mMaxDistance = sound->mMaxDistance;
    this->mPitch = 1.0;
    this->mMaxDistance = mMaxDistance;
    this->mVolume3D = 1.0;
    this->mFlags = mFlags & 0xFEEDFFD8;
    mRolloffPoint = sound->mRolloffPoint;
    this->mConeInsideAngle = sound->mConeInsideAngle;
    this->mConeVolume3D = 1.0;
    this->mPitch3D = 1.0;
    mConeOutsideAngle = sound->mConeOutsideAngle;
    this->mDirectOcclusion = 0.0;
    this->mConeOutsideAngle = mConeOutsideAngle;
    this->mDistance = 0.0;
    mConeOutsideVolume = sound->mConeOutsideVolume;
    this->mRolloffPoint = mRolloffPoint;
    LODWORD(mRolloffPoint) = sound->mNumRolloffPoints;
    this->mConeOutsideVolume = mConeOutsideVolume;
    distanceFilterCenterFreq = mSystem->mAdvancedSettings.distanceFilterCenterFreq;
    this->mConeOrientation.x = 0.0;
    this->mConeOrientation.y = 0.0;
    this->mDistanceFilterCentreFreq = distanceFilterCenterFreq;
    this->mConeOrientation.z = 1.0;
    this->mNumRolloffPoints = (int)mRolloffPoint;
    this->m3DLevel = 1.0;
    this->m3DDopplerLevel = 1.0;
    this->mAngleToListener = 0.0;
    this->mDistanceFilterCustomLevel = 0.0;
    this->mDSPDirectVolume = 1.0;
    this->mDSPSendVolume = 0.0;
    this->mReverbLevel[0] = 1.0;
    this->mReverbConnection[0] = 0;
    this->mReverbLevel[1] = 1.0;
    this->mReverbConnection[1] = 0;
    this->mReverbLevel[2] = 1.0;
    this->mReverbConnection[2] = 0;
    this->mReverbLevel[3] = 1.0;
    this->mReverbConnection[3] = 0;
    this->mDelayClockStart = 0;
    this->mDelayClockEnd = 0;
    this->mDelayClockStopChannels = 0;
  }
  else
  {
    mRealChannel = this->mRealChannel;
    result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    if ( !mRealChannel )
      return result;
  }
  mMode = sound->mMode;
  mRealChannel->mSound = sound;
  mRealChannel->mDSP = 0;
  mRealChannel->mMode = mMode;
  mRealChannel->mLoopStart = sound->mLoopStart;
  mRealChannel->mLoopLength = sound->mLoopLength;
  mRealChannel->mLoopCount = sound->mLoopCount;
  mLength = sound->mLength;
  mRealChannel->mParent = this;
  mRealChannel->mLength = mLength;
  _InterlockedAnd((volatile signed __int32 *)&sound->mFlags, 0xFFFFF7FF);
  result = FMOD::DSPI::setActive(this->mDSPHead, 0, 1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( !reset )
      goto LABEL_15;
    mDSPHead = this->mDSPHead;
    if ( (this->mRealChannel->mFlags & 0x10000) != 0 )
      mDSPHead->mJob.mFlags |= 0x400u;
    result = FMOD::DSPI::disconnectFrom(mDSPHead, 0, 0, FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::DSPFader::hardReset(this->mDSPFader);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **))this->mChannelGroupParent->FMOD::ChannelControlI::_vptr_ChannelControlI
                  + 36))(
                   this->mChannelGroupParent,
                   4294967293LL,
                   &dsptail);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = FMOD::DSPI::addInput(
                     dsptail,
                     this->mDSPHead,
                     0,
                     FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                     0,
                     0);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
LABEL_15:
            result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *))this->mRealChannel->_vptr_ChannelReal + 5))(this->mRealChannel);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              _InterlockedOr((volatile signed __int32 *)&sound->mFlags, 4u);
              mSubSoundParent = sound->mSubSoundParent;
              if ( mSubSoundParent )
                _InterlockedOr((volatile signed __int32 *)&mSubSoundParent->mFlags, 4u);
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21b3730 | Name: _ZN4FMOD8ChannelI5allocEPNS_4DSPIEb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::alloc(FMOD::ChannelI *const this, FMOD::DSPI *dsp, bool reset)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rax
  FMOD::SystemI *mSystem; // rdx
  FMOD_SPEAKERMODE_0 mSpeakerMode; // eax
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // eax
  FMOD::DSPI *dsptail; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( this->mRealChannel )
  {
    dsp->mChannelOwner = this;
    mRealChannel = this->mRealChannel;
    mRealChannel->mSound = 0;
    mRealChannel->mDSP = dsp;
    mRealChannel->mLoopStart = 0;
    mRealChannel->mLoopLength = -1;
    mRealChannel->mLoopCount = -1;
    mRealChannel->mMode = 8;
    mRealChannel->mParent = this;
    if ( reset )
    {
      mSystem = this->mSystem;
      this->mSyncPointCurrent = 0;
      this->mNumDSPs = 1;
      this->mDSP = 0;
      this->mUserData = 0;
      mSpeakerMode = mSystem->mSpeakerMode;
      this->mDistanceFilterCentreFreq = mSystem->mAdvancedSettings.distanceFilterCenterFreq;
      this->mVirtualDSPTick = 0;
      this->mLowPassGain = 1.0;
      this->mPitch = 1.0;
      this->mVolume3D = 1.0;
      this->mSpeakerMode = mSpeakerMode;
      mFlags = this->mFlags;
      this->mConeVolume3D = 1.0;
      this->mPitch3D = 1.0;
      this->mDirectOcclusion = 0.0;
      this->mMinDistance = 1.0;
      this->mMaxDistance = 10000.0;
      this->mDistance = 0.0;
      this->mConeInsideAngle = 360.0;
      this->mFlags = mFlags & 0xFEEDFFD8;
      this->mConeOutsideAngle = 360.0;
      this->mConeOutsideVolume = 1.0;
      this->mConeOrientation.x = 0.0;
      this->mConeOrientation.y = 0.0;
      this->mConeOrientation.z = 1.0;
      this->mRolloffPoint = 0;
      this->mNumRolloffPoints = 0;
      this->m3DLevel = 1.0;
      this->m3DDopplerLevel = 1.0;
      this->mAngleToListener = 0.0;
      this->mDistanceFilterCustomLevel = 0.0;
      this->mDSPDirectVolume = 1.0;
      this->mDSPSendVolume = 0.0;
      this->mReverbLevel[0] = 1.0;
      this->mReverbConnection[0] = 0;
      this->mReverbLevel[1] = 1.0;
      this->mReverbConnection[1] = 0;
      this->mReverbLevel[2] = 1.0;
      this->mReverbConnection[2] = 0;
      this->mReverbLevel[3] = 1.0;
      this->mReverbConnection[3] = 0;
      this->mDelayClockStart = 0;
      this->mDelayClockEnd = 0;
      this->mDelayClockStopChannels = 0;
      result = FMOD::DSPI::setActive(this->mDSPHead, 0, 1);
      if ( result )
        return result;
      result = FMOD::DSPI::disconnectFrom(this->mDSPHead, 0, 0, FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
      if ( result )
        return result;
      result = FMOD::DSPFader::hardReset(this->mDSPFader);
      if ( result )
        return result;
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **))this->mChannelGroupParent->FMOD::ChannelControlI::_vptr_ChannelControlI
                + 36))(
                 this->mChannelGroupParent,
                 4294967293LL,
                 &dsptail);
      if ( result )
        return result;
      result = FMOD::DSPI::addInput(
                 dsptail,
                 this->mDSPHead,
                 0,
                 FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                 0,
                 0);
      if ( result )
        return result;
    }
    else
    {
      result = FMOD::DSPI::setActive(this->mDSPHead, 0, 1);
      if ( result )
        return result;
    }
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, FMOD::DSPI *))this->mRealChannel->_vptr_ChannelReal + 6))(
             this->mRealChannel,
             dsp);
  }
  return result;
}


// Address: 0x21b39e0 | Name: _ZN4FMOD8ChannelI5startEv
FMOD_RESULT_0 __fastcall FMOD::ChannelI::start(FMOD::ChannelI *const this)
{
  FMOD::ChannelReal *mRealChannel; // rdi

  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *))mRealChannel->_vptr_ChannelReal + 7))(mRealChannel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x21b3a00 | Name: _ZN4FMOD8ChannelI12updateStreamEv
FMOD_RESULT_0 __fastcall FMOD::ChannelI::updateStream(FMOD::ChannelI *const this)
{
  FMOD::ChannelReal *mRealChannel; // rdi

  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *))mRealChannel->_vptr_ChannelReal + 9))(mRealChannel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x21b3a20 | Name: _ZN4FMOD8ChannelI12getFrequencyEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getFrequency(FMOD::ChannelI *const this, float *frequency)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( frequency )
  {
    LOBYTE(result) = 30;
    if ( this->mRealChannel )
    {
      LOBYTE(result) = 0;
      *frequency = this->mFrequency;
    }
  }
  return result;
}


// Address: 0x21b3a50 | Name: _ZN4FMOD8ChannelI11getPriorityEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getPriority(FMOD::ChannelI *const this, int *priority)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( priority )
  {
    *priority = this->mPriority;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b3a70 | Name: _ZN4FMOD8ChannelI22get3DOcclusionInternalEPfS1_
FMOD_RESULT_0 __fastcall FMOD::ChannelI::get3DOcclusionInternal(
        FMOD::ChannelI *const this,
        float *directOcclusion,
        float *reverbOcclusion)
{
  FMOD::ChannelReal *mRealChannel; // rcx
  FMOD_RESULT_0 result; // eax

  mRealChannel = this->mRealChannel;
  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( mRealChannel )
  {
    LOBYTE(result) = 40;
    if ( (mRealChannel->mMode & 0x10) != 0 )
    {
      if ( directOcclusion )
        *directOcclusion = this->mDirectOcclusion;
      if ( reverbOcclusion )
        *reverbOcclusion = this->mReverbOcclusion;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21b3ac0 | Name: _ZN4FMOD8ChannelI16moveChannelGroupEPNS_13ChannelGroupIES2_b
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::ChannelI::moveChannelGroup(
        FMOD::ChannelI *const this,
        FMOD::ChannelGroupI *oldchannelgroup,
        FMOD::ChannelGroupI *newchannelgroup,
        bool forcedspreconnect)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *dsptail[4]; // [rsp+8h] [rbp-20h] BYREF

  if ( oldchannelgroup == newchannelgroup && !forcedspreconnect )
    return FMOD_RESULT::FMOD_OK_0;
  if ( !oldchannelgroup
    || (result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **))oldchannelgroup->_vptr_ChannelControlI
                  + 36))(
                   oldchannelgroup,
                   4294967293LL,
                   dsptail)) == FMOD_RESULT::FMOD_OK_0
    && (!dsptail[0]
     || (result = FMOD::DSPI::disconnectFrom(
                    dsptail[0],
                    this->mDSPHead,
                    0,
                    FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0)) == FMOD_RESULT::FMOD_OK_0) )
  {
    if ( !newchannelgroup )
      return FMOD_RESULT::FMOD_OK_0;
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **, bool))newchannelgroup->_vptr_ChannelControlI
              + 36))(
               newchannelgroup,
               4294967293LL,
               dsptail,
               forcedspreconnect);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( !dsptail[0] )
        return FMOD_RESULT::FMOD_OK_0;
      result = FMOD::DSPI::addInput(
                 dsptail[0],
                 this->mDSPHead,
                 0,
                 FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                 0,
                 0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21b3b80 | Name: _ZN4FMOD8ChannelI15getChannelGroupEPPNS_13ChannelGroupIE
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getChannelGroup(
        FMOD::ChannelI *const this,
        FMOD::ChannelGroupI **channelgroup)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroup )
  {
    *channelgroup = this->mChannelGroupParent;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b3ba0 | Name: _ZN4FMOD8ChannelI21getAudibilityInternalEPfb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getAudibilityInternal(
        FMOD::ChannelI *const this,
        float *audibility,
        bool usefadevolume)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rcx
  FMOD::ChannelGroupI *mChannelGroupParent; // r8
  float v6; // xmm0_4
  float v7; // xmm0_4
  float v8; // xmm0_4
  FMOD::SoundI *mSound; // rax
  float v10; // xmm0_4
  float mPeakVolume; // xmm1_4
  float m3DLevel; // xmm1_4
  float mSoundGroupFadeVolume; // xmm0_4

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( audibility )
  {
    mRealChannel = this->mRealChannel;
    LOBYTE(result) = 30;
    if ( mRealChannel )
    {
      mChannelGroupParent = this->mChannelGroupParent;
      if ( mChannelGroupParent )
      {
        if ( (this->mFlags & 0x800002) != 0 )
        {
          *audibility = 0.0;
          LOBYTE(result) = 0;
        }
        else
        {
          if ( (mRealChannel->mMode & 0x10) != 0 )
          {
            m3DLevel = this->m3DLevel;
            mSoundGroupFadeVolume = 1.0;
            if ( m3DLevel < 1.0 )
            {
              if ( usefadevolume )
                mSoundGroupFadeVolume = this->mSoundGroupFadeVolume;
              v7 = (float)((float)(mSoundGroupFadeVolume
                                 * (float)((float)((float)((float)((float)(this->mVolume3D * m3DLevel)
                                                                 + (float)(1.0 - m3DLevel))
                                                         * (float)((float)(this->mConeVolume3D * m3DLevel)
                                                                 + (float)(1.0 - m3DLevel)))
                                                 * (float)((float)((float)(1.0 - this->mDirectOcclusion) * m3DLevel)
                                                         + (float)(1.0 - m3DLevel)))
                                         * (float)((float)((float)(1.0 - this->mUserDirectOcclusion) * m3DLevel)
                                                 + (float)(1.0 - m3DLevel))))
                         * (float)((float)(m3DLevel * mChannelGroupParent->mRealDirectOcclusionVolume)
                                 + (float)(1.0 - m3DLevel)))
                 * mChannelGroupParent->mAudibility;
              *audibility = v7;
            }
            else
            {
              if ( usefadevolume )
                mSoundGroupFadeVolume = this->mSoundGroupFadeVolume;
              v7 = (float)((float)(mSoundGroupFadeVolume
                                 * (float)((float)((float)(this->mVolume3D * this->mConeVolume3D)
                                                 * (float)(1.0 - this->mDirectOcclusion))
                                         * (float)(1.0 - this->mUserDirectOcclusion)))
                         * mChannelGroupParent->mRealDirectOcclusionVolume)
                 * mChannelGroupParent->mAudibility;
              *audibility = v7;
            }
          }
          else
          {
            v6 = 1.0;
            if ( usefadevolume )
              v6 = this->mSoundGroupFadeVolume;
            v7 = v6 * mChannelGroupParent->mAudibility;
            *audibility = v7;
          }
          v8 = v7 * this->mDSPDirectVolume;
          mSound = mRealChannel->mSound;
          *audibility = v8;
          v10 = v8 + this->mDSPSendVolume;
          *audibility = v10;
          if ( mSound )
          {
            mPeakVolume = mSound->mPeakVolume;
            if ( mPeakVolume != 0.0 )
              v10 = v10 * mPeakVolume;
          }
          result = FMOD_RESULT::FMOD_OK_0;
          *audibility = fabs(v10);
        }
      }
    }
  }
  return result;
}


// Address: 0x21b3d70 | Name: _ZN4FMOD8ChannelI13getAudibilityEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getAudibility(FMOD::ChannelI *const this, float *audibility)
{
  return FMOD::ChannelI::getAudibilityInternal(this, audibility, 1);
}


// Address: 0x21b3d80 | Name: _ZN4FMOD8ChannelI15getCurrentSoundEPPNS_6SoundIE
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getCurrentSound(FMOD::ChannelI *const this, FMOD::SoundI **sound)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( sound )
  {
    mRealChannel = this->mRealChannel;
    if ( mRealChannel )
    {
      *sound = mRealChannel->mSound;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      *sound = 0;
      return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    }
  }
  return result;
}


// Address: 0x21b3dc0 | Name: _ZN4FMOD8ChannelI13getCurrentDSPEPPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getCurrentDSP(FMOD::ChannelI *const this, FMOD::DSPI **dsp)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp )
  {
    mRealChannel = this->mRealChannel;
    if ( mRealChannel )
    {
      *dsp = mRealChannel->mDSP;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      *dsp = 0;
      return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    }
  }
  return result;
}


// Address: 0x21b3e00 | Name: _ZN4FMOD8ChannelI8getIndexEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getIndex(FMOD::ChannelI *const this, int *index)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index )
  {
    *index = this->mIndex;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b3e20 | Name: _ZN4FMOD8ChannelI11getPositionEPjj
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getPosition(
        FMOD::ChannelI *const this,
        unsigned int *position,
        FMOD_TIMEUNIT postype)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rcx
  FMOD::SoundI *mSound; // rsi
  int mFormat; // r12d
  int mChannels; // ebp
  unsigned __int64 v9; // rax
  __int64 v10; // rdx
  FMOD::DSPI *mDSP; // rsi
  char postypea; // [rsp+8h] [rbp-30h]
  float frequency; // [rsp+Ch] [rbp-2Ch]
  FMOD_UINT32_32 pcm; // [rsp+10h] [rbp-28h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( position )
  {
    mRealChannel = this->mRealChannel;
    LOBYTE(result) = 30;
    if ( mRealChannel )
    {
      if ( (postype & 7) == 0 )
        return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *))mRealChannel->_vptr_ChannelReal + 28))(this->mRealChannel);
      mSound = mRealChannel->mSound;
      if ( mSound )
      {
        mFormat = mSound->mFormat;
        mChannels = mSound->mChannels;
        frequency = mSound->mDefaultFrequency;
      }
      else
      {
        mDSP = mRealChannel->mDSP;
        if ( !mDSP )
          return result;
        mChannels = mDSP->mDescription.mChannels;
        mFormat = 5;
        frequency = (float)this->mSystem->mDSPSampleRate;
      }
      postypea = postype;
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, FMOD_UINT32_32 *))mRealChannel->_vptr_ChannelReal
                + 17))(
                 mRealChannel,
                 &pcm);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( (postypea & 4) != 0 )
        {
          LODWORD(v9) = pcm.mHi;
          switch ( mFormat )
          {
            case 1:
              v10 = 8;
              goto LABEL_15;
            case 2:
              v10 = 16;
              goto LABEL_15;
            case 3:
              v10 = 24;
              goto LABEL_15;
            case 4:
            case 5:
              v10 = 32;
LABEL_15:
              v9 = (v10 * (unsigned __int64)pcm.mHi) >> 3;
              break;
            default:
              break;
          }
          *position = v9 * mChannels;
          return FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          if ( (postypea & 1) != 0 )
            *position = (int)(float)((float)((float)((float)(int)pcm.mHi / frequency) * 1000.0) + 0.5);
          else
            *position = pcm.mHi;
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x21b3f90 | Name: _ZN4FMOD8ChannelI16updateSyncPointsEb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::updateSyncPoints(FMOD::ChannelI *const this, bool seeking)
{
  FMOD::SoundI *mSound; // rbp
  FMOD::SyncPoint **mSyncPointHead; // rax
  FMOD::SyncPoint *mSyncPointCurrent; // rax
  float mFrequency; // xmm1_4
  FMOD::SyncPoint *v6; // rax
  unsigned int v7; // edx
  FMOD::SyncPoint *v8; // rax
  FMOD::SyncPoint *v9; // rax
  bool v10; // zf
  FMOD::SyncPoint *v11; // rax
  FMOD::SyncPoint *v12; // rax
  FMOD_RESULT_0 result; // eax
  bool v14; // r12
  FMOD::SyncPoint *v15; // rax
  FMOD::SyncPoint *mNodeNext; // r13
  FMOD::SyncPoint *mNodePrev; // r13
  unsigned int position[11]; // [rsp+1Ch] [rbp-2Ch] BYREF

  mSound = this->mRealChannel->mSound;
  if ( !mSound )
    return FMOD_RESULT::FMOD_OK_0;
  mSyncPointHead = (FMOD::SyncPoint **)mSound->mSyncPointHead;
  if ( !mSyncPointHead || !mSound->mNumSyncPoints )
  {
    mSyncPointCurrent = this->mSyncPointCurrent;
    goto LABEL_5;
  }
  if ( !this->mSyncPointCurrent )
  {
    mSyncPointCurrent = *mSyncPointHead;
    this->mSyncPointCurrent = mSyncPointCurrent;
LABEL_5:
    if ( !mSyncPointCurrent )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( FMOD::ChannelI::getPosition(this, position, 2u) )
  {
LABEL_20:
    v7 = position[0];
  }
  else
  {
    mFrequency = this->mFrequency;
    if ( !seeking )
    {
      if ( mFrequency > 0.0 && (v14 = 1, this->mSyncPointLastPos > position[0]) )
      {
        do
        {
LABEL_30:
          while ( 1 )
          {
            if ( mFrequency <= 0.0 || (v15 = this->mSyncPointCurrent, HIDWORD(v15->mSound) >= position[0]) )
            {
              if ( mFrequency >= 0.0 || (v15 = this->mSyncPointCurrent, HIDWORD(v15->mSound) <= position[0]) )
              {
                if ( !v14 )
                  goto LABEL_20;
                v15 = this->mSyncPointCurrent;
              }
              if ( mFrequency <= 0.0 )
                break;
            }
            if ( mSound->mSyncPointTail != v15 )
            {
              mNodeNext = (FMOD::SyncPoint *)v15->mNodeNext;
              if ( (!mSound->mSubSoundShared || LOWORD(v15->mOffset) == mSound->mSubSoundIndex) && this->mCallback )
              {
                result = FMOD::ChannelControlI::executeCallback(
                           this,
                           (FMOD_CHANNELCONTROL *)this->mHandleCurrent,
                           FMOD_CHANNELCONTROL_TYPE::FMOD_CHANNELCONTROL_CHANNEL_0,
                           FMOD_CHANNELCONTROL_CALLBACK_TYPE::FMOD_CHANNELCONTROL_CALLBACK_SYNCPOINT_0,
                           (void *)HIWORD(v15->mOffset),
                           0);
                if ( result )
                  return result;
                mFrequency = this->mFrequency;
              }
              this->mSyncPointCurrent = mNodeNext;
            }
            if ( v14 && this->mSyncPointCurrent == mSound->mSyncPointTail )
            {
              v14 = 0;
              this->mSyncPointCurrent = (FMOD::SyncPoint *)mSound->mSyncPointHead->mNodeNext;
            }
          }
          if ( mSound->mSyncPointHead != v15 )
          {
            mNodePrev = (FMOD::SyncPoint *)v15->mNodePrev;
            if ( (!mSound->mSubSoundShared || LOWORD(v15->mOffset) == mSound->mSubSoundIndex) && this->mCallback )
            {
              result = FMOD::ChannelControlI::executeCallback(
                         this,
                         (FMOD_CHANNELCONTROL *)this->mHandleCurrent,
                         FMOD_CHANNELCONTROL_TYPE::FMOD_CHANNELCONTROL_CHANNEL_0,
                         FMOD_CHANNELCONTROL_CALLBACK_TYPE::FMOD_CHANNELCONTROL_CALLBACK_SYNCPOINT_0,
                         (void *)HIWORD(v15->mOffset),
                         0);
              if ( result )
                return result;
              mFrequency = this->mFrequency;
            }
            this->mSyncPointCurrent = mNodePrev;
          }
        }
        while ( !v14 || this->mSyncPointCurrent != mSound->mSyncPointHead );
        this->mSyncPointCurrent = (FMOD::SyncPoint *)mSound->mSyncPointTail->mNodePrev;
      }
      else if ( mFrequency < 0.0 )
      {
        v14 = this->mSyncPointLastPos < position[0];
        goto LABEL_30;
      }
      v14 = 0;
      goto LABEL_30;
    }
    if ( mFrequency <= 0.0 )
      v6 = (FMOD::SyncPoint *)mSound->mSyncPointTail->mNodePrev;
    else
      v6 = (FMOD::SyncPoint *)mSound->mSyncPointHead->mNodeNext;
    this->mSyncPointCurrent = v6;
    v7 = position[0];
    do
    {
      while ( mFrequency > 0.0 )
      {
        v8 = this->mSyncPointCurrent;
        if ( HIDWORD(v8->mSound) >= v7 )
          break;
        v9 = (FMOD::SyncPoint *)v8->mNodeNext;
        v10 = v9 == mSound->mSyncPointTail;
        this->mSyncPointCurrent = v9;
        if ( v10 )
          goto LABEL_21;
      }
      if ( mFrequency >= 0.0 )
        break;
      v11 = this->mSyncPointCurrent;
      if ( HIDWORD(v11->mSound) <= v7 )
        break;
      if ( mFrequency > 0.0 )
        break;
      v12 = (FMOD::SyncPoint *)v11->mNodePrev;
      v10 = v12 == mSound->mSyncPointHead;
      this->mSyncPointCurrent = v12;
    }
    while ( !v10 );
  }
LABEL_21:
  this->mSyncPointLastPos = v7;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b42e0 | Name: _ZN4FMOD8ChannelI12setFrequencyEf
__int64 __fastcall FMOD::ChannelI::setFrequency(FMOD::ChannelI *const this, float a2, float frequency)
{
  __int64 result; // rax
  FMOD::ChannelReal *mRealChannel; // rdi
  int (**vptr_ChannelReal)(...); // rax
  float oldfrequency; // [rsp+Ch] [rbp-Ch]

  result = 29;
  if ( (LODWORD(a2) & 0x7F800000) != 0x7F800000 )
  {
    mRealChannel = this->mRealChannel;
    result = 30;
    if ( mRealChannel )
    {
      if ( this->mChannelGroupParent )
      {
        vptr_ChannelReal = mRealChannel->_vptr_ChannelReal;
        oldfrequency = this->mFrequency;
        this->mFrequency = fminf(mRealChannel->mMaxFrequency, fmaxf(mRealChannel->mMinFrequency, a2));
        result = ((__int64 (*)(void))vptr_ChannelReal[14])();
        if ( !(_DWORD)result )
        {
          if ( this->mSyncPointCurrent )
          {
            if ( oldfrequency < 0.0 && this->mFrequency > 0.0 || oldfrequency > 0.0 && this->mFrequency < 0.0 )
            {
              FMOD::ChannelI::updateSyncPoints(this, 1);
              return 0;
            }
            else
            {
              return 0;
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21b43c0 | Name: _ZN4FMOD8ChannelI11setDefaultsEv
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setDefaults(FMOD::ChannelI *const this)
{
  float v1; // xmm1_4
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rdx
  FMOD::SoundI *mSound; // rax
  int mDefaultPriority; // edx
  FMOD_CHANNELORDER_0 mDefaultChannelOrder; // ebp
  float mDefaultFrequency; // xmm0_4
  _BOOL4 v8; // edx
  FMOD_SPEAKERMODE_0 v9; // ecx
  int v10; // edx
  FMOD::DSPI *dsphead; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  mRealChannel = this->mRealChannel;
  if ( mRealChannel && this->mChannelGroupParent )
  {
    mSound = mRealChannel->mSound;
    if ( mSound )
    {
      mDefaultPriority = mSound->mDefaultPriority;
      mDefaultChannelOrder = mSound->mDefaultChannelOrder;
      mDefaultFrequency = mSound->mDefaultFrequency;
    }
    else
    {
      result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      if ( !mRealChannel->mDSP )
        return result;
      mDefaultChannelOrder = FMOD_CHANNELORDER::FMOD_CHANNELORDER_DEFAULT_0;
      mDefaultPriority = 128;
      mDefaultFrequency = (float)this->mSystem->mDSPSampleRate;
    }
    this->mPriority = mDefaultPriority;
    this->mDirectOcclusion = 0.0;
    this->mDirectOcclusionTarget = 0.0;
    this->mUserDirectOcclusion = 0.0;
    this->mReverbOcclusion = 0.0;
    this->mReverbOcclusionTarget = 0.0;
    this->mUserReverbOcclusion = 0.0;
    this->mDirectOcclusionRateOfChange = 0.0;
    this->mReverbOcclusionRateOfChange = 0.0;
    FMOD::ChannelI::setFrequency(this, mDefaultFrequency, v1);
    (*((void (__fastcall **)(FMOD::ChannelI *const, _QWORD, float))this->_vptr_ChannelControlI + 4))(this, 0, 1.0);
    (*((void (__fastcall **)(FMOD::ChannelI *const, float))this->_vptr_ChannelControlI + 9))(this, 1.0);
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI
              + 36))(
               this,
               0xFFFFFFFFLL,
               &dsphead);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( mDefaultChannelOrder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLMONO_0 )
      {
        v9 = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0;
        v10 = 1;
      }
      else
      {
        v8 = mDefaultChannelOrder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLSTEREO_0;
        v9 = 3 * v8;
        v10 = 2 * v8;
      }
      return FMOD::DSPI::setChannelFormat(dsphead, 0, v10, v9);
    }
  }
  return result;
}


// Address: 0x21b4510 | Name: _ZN4FMOD8ChannelI8setPitchEf
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setPitch(FMOD::ChannelI *const this, double a2, float pitch)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *dsphead; // [rsp+18h] [rbp-10h] BYREF

  result = FMOD::ChannelControlI::setPitch(this, pitch);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, _QWORD, FMOD::DSPI **))this->_vptr_ChannelControlI
              + 36))(
               this,
               0,
               &dsphead);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::DSPI::setPitch(dsphead, pitch, 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        return (unsigned int)FMOD::ChannelI::setFrequency(this, this->mFrequency, pitch);
    }
  }
  return result;
}


// Address: 0x21b4580 | Name: _ZN4FMOD8ChannelI23setChannelGroupInternalEPNS_13ChannelGroupIEbb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setChannelGroupInternal(
        FMOD::ChannelI *const this,
        FMOD::ChannelGroupI *channelgroup,
        bool resetattributes,
        bool forcedspreconnect)
{
  float v4; // xmm1_4
  FMOD::ChannelGroupI *mChannelGroupParent; // rdi
  FMOD::LinkedListNode *mNodeNext; // r9
  FMOD::LinkedListNode *p_mChannelGroupNode; // rax
  FMOD::LinkedListNode *mNodePrev; // r8
  FMOD::LinkedListNode *v10; // r8
  FMOD_RESULT_0 result; // eax

  mChannelGroupParent = this->mChannelGroupParent;
  if ( mChannelGroupParent )
  {
    mNodeNext = this->mChannelGroupNode.mNodeNext;
    p_mChannelGroupNode = &this->mChannelGroupNode;
    mNodePrev = this->mChannelGroupNode.mNodePrev;
    if ( &this->mChannelGroupNode == mNodeNext && p_mChannelGroupNode == mNodePrev )
      return FMOD_RESULT::FMOD_OK_0;
    --mChannelGroupParent->mNumChannels;
    mNodePrev->mNodeNext = mNodeNext;
    this->mChannelGroupNode.mNodeNext->mNodePrev = mNodePrev;
    this->mChannelGroupNode.mNodePrev = p_mChannelGroupNode;
    this->mChannelGroupNode.mNodeNext = p_mChannelGroupNode;
  }
  this->mChannelGroupParent = channelgroup;
  this->mChannelGroupNode.mNodeData = this;
  if ( !channelgroup )
    return FMOD_RESULT::FMOD_OK_0;
  v10 = channelgroup->mChannelHead.mNodeNext;
  this->mChannelGroupNode.mNodePrev = &channelgroup->mChannelHead;
  this->mChannelGroupNode.mNodeNext = v10;
  v10->mNodePrev = &this->mChannelGroupNode;
  this->mChannelGroupNode.mNodePrev->mNodeNext = &this->mChannelGroupNode;
  ++channelgroup->mNumChannels;
  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( !this->mRealChannel )
    return result;
  if ( !resetattributes )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD::ChannelI::moveChannelGroup(this, mChannelGroupParent, channelgroup, forcedspreconnect);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, _QWORD))this->_vptr_ChannelControlI + 11))(
               this,
               (this->mFlags >> 1) & 1);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, _QWORD))this->_vptr_ChannelControlI + 2))(
                 this,
                 this->mFlags & 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        (*((void (__fastcall **)(FMOD::ChannelI *const, _QWORD, float))this->_vptr_ChannelControlI + 4))(
          this,
          0,
          this->mVolume);
        if ( (this->mRealChannel->mMode & 0x10) == 0 )
          (*((void (__fastcall **)(FMOD::ChannelI *const, float *, _QWORD, _QWORD, _QWORD, _QWORD))this->_vptr_ChannelControlI
           + 25))(
            this,
            this->mMixMatrix.mData,
            (unsigned int)this->mMixMatrix.mOutChannels,
            (unsigned int)this->mMixMatrix.mInChannels,
            0,
            0);
        FMOD::ChannelI::setFrequency(this, this->mFrequency, v4);
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21b46d0 | Name: _ZN4FMOD8ChannelI15setChannelGroupEPNS_13ChannelGroupIE
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setChannelGroup(FMOD::ChannelI *const this, FMOD::ChannelGroupI *channelgroup)
{
  if ( channelgroup )
    return FMOD::ChannelI::setChannelGroupInternal(this, channelgroup, 1, 0);
  else
    return FMOD::ChannelI::setChannelGroupInternal(this, this->mSystem->mMasterChannelGroup, 1, 0);
}


// Address: 0x21b4700 | Name: _ZN4FMOD8ChannelI6stopExEj
FMOD_RESULT_0 __fastcall FMOD::ChannelI::stopEx(FMOD::ChannelI *const this, FMOD::FMOD_CHANNEL_STOPFLAG stopflag)
{
  FMOD::ChannelReal *mRealChannel; // rax
  char v4; // bp
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *mDSPHead; // rdi
  FMOD::ChannelReal *v7; // r12
  FMOD::SoundI *mSound; // rax
  int mNumAudible; // ecx
  unsigned int v10; // eax
  FMOD::SoundI *v11; // rdi
  FMOD::SystemI *mSystem; // rdi
  float *mData; // rsi
  FMOD::DSPI *mDSPFader; // rax
  FMOD::DSPI **mDSP; // rsi
  FMOD::ChannelReal *v16; // rax
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // eax

  mRealChannel = this->mRealChannel;
  if ( !mRealChannel )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( SLOBYTE(mRealChannel->mFlags) < 0 )
    return FMOD_RESULT::FMOD_OK_0;
  v4 = stopflag;
  if ( (stopflag & 0x40) != 0 )
    FMOD::ChannelI::updateSyncPoints(this, 0);
  if ( (stopflag & 4) != 0 )
  {
LABEL_10:
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *))this->mRealChannel->_vptr_ChannelReal + 10))(this->mRealChannel);
    if ( result )
      return result;
    if ( (stopflag & 0x10) != 0 )
    {
      result = FMOD::ChannelI::setChannelGroupInternal(this, 0, 0, 0);
      if ( result )
        return result;
    }
    v7 = this->mRealChannel;
    mSound = v7->mSound;
    if ( mSound )
    {
      mNumAudible = mSound->mNumAudible;
      mSound->mNumAudible = mNumAudible - 1;
      if ( mNumAudible == 1 )
        mSound->mLastAudibleDSPTick = *(_DWORD *)((char *)&stru_11610.r_offset + (unsigned __int64)this->mSystem);
    }
    if ( (stopflag & 2) != 0 )
    {
      result = FMOD::ChannelI::returnToFreeList(this);
      if ( result )
        return result;
      mFlags = this->mFlags;
      this->mListPosition = -1;
      v7 = this->mRealChannel;
      v10 = mFlags & 0xFFFEFFFF;
    }
    else
    {
      v10 = this->mFlags;
    }
    this->mFlags = v10 & 0xFFFBFFFF;
    if ( (stopflag & 8) != 0 && this->mCallback )
    {
      result = FMOD::ChannelControlI::executeCallback(
                 this,
                 (FMOD_CHANNELCONTROL *)this->mHandleCurrent,
                 FMOD_CHANNELCONTROL_TYPE::FMOD_CHANNELCONTROL_CHANNEL_0,
                 FMOD_CHANNELCONTROL_CALLBACK_TYPE::FMOD_CHANNELCONTROL_CALLBACK_END_0,
                 0,
                 0);
      if ( result )
        return result;
      v16 = this->mRealChannel;
      if ( (v16->mFlags & 0x40) != 0 && v16 == v7 )
      {
LABEL_22:
        if ( (stopflag & 4) == 0 )
        {
          mData = this->mMixMatrix.mData;
          mDSPFader = (FMOD::DSPI *)this->mDSPFader;
          this->mDSPTail = mDSPFader;
          this->mDSPHead = mDSPFader;
          if ( mData )
          {
            FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, mData, (const char *)&uri_string, 0);
            this->mMixMatrix.mData = 0;
          }
          mDSP = this->mDSP;
          if ( mDSP )
          {
            FMOD::MemPool::free(
              (FMOD::MemPool *const)((char *)&stru_10818 + (unsigned __int64)this->mSystem),
              mDSP,
              (const char *)&uri_string,
              0);
            this->mDSP = 0;
          }
        }
        if ( this->mListPosition == -1 && (this->mFlags & 0x40000) == 0 && v4 >= 0 )
        {
          this->mRealChannel = 0;
          if ( (v4 & 4) == 0 )
          {
            result = FMOD::ChannelControlI::setCallback(this, 0);
            if ( result )
              return result;
            this->mSyncPointCurrent = 0;
          }
          if ( (v4 & 1) != 0 )
            return FMOD::ChannelI::referenceStamp(this, 0);
        }
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
    else if ( (v7->mFlags & 0x40) != 0 )
    {
      goto LABEL_22;
    }
    v11 = v7->mSound;
    if ( v11 && (*v11->_vptr_SoundI)(v11) )
    {
      FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
      mSystem = this->mSystem;
      v7->mSound = 0;
      v7->mDSP = 0;
      v7->mParent = 0;
      FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
    }
    else
    {
      v7->mSound = 0;
      v7->mDSP = 0;
      v7->mParent = 0;
    }
    goto LABEL_22;
  }
  (*((void (__fastcall **)(FMOD::ChannelI *const, _QWORD, _QWORD, _QWORD))this->_vptr_ChannelControlI + 28))(
    this,
    0,
    0,
    0);
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, _QWORD, __int64))this->_vptr_ChannelControlI + 32))(
             this,
             0,
             -1048576);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, _QWORD))this->_vptr_ChannelControlI + 35))(this, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mDSPHead = this->mDSPHead;
      if ( mDSPHead )
      {
        FMOD::DSPI::setActive(mDSPHead, 0, 1);
        FMOD::DSPI::disconnectAll(this->mDSPHead, 0, 1);
      }
      goto LABEL_10;
    }
  }
  return result;
}


// Address: 0x21b4a60 | Name: _ZN4FMOD8ChannelI5closeEv
FMOD_RESULT_0 __fastcall FMOD::ChannelI::close(FMOD::ChannelI *const this)
{
  FMOD::DSPFader *mDSPFader; // rdi
  __int64 v3; // rax
  FMOD_RESULT_0 result; // eax

  FMOD::ChannelI::stopEx(this, 0x53u);
  mDSPFader = this->mDSPFader;
  if ( mDSPFader )
  {
    v3 = *(_QWORD *)mDSPFader;
    *((_WORD *)mDSPFader + 46) &= 0xFE7Fu;
    result = (*(unsigned int (**)(void))(v3 + 16))();
    if ( result )
      return result;
    this->mDSPFader = 0;
  }
  this->mDSPHead = 0;
  this->mDSPTail = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b4ab0 | Name: _ZN4FMOD8ChannelI4stopEv
FMOD_RESULT_0 __fastcall FMOD::ChannelI::stop(FMOD::ChannelI *const this)
{
  return FMOD::ChannelI::stopEx(this, 0x5Bu);
}


// Address: 0x21b4ac0 | Name: _ZN4FMOD8ChannelI11setPositionEjj
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setPosition(
        FMOD::ChannelI *const this,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  unsigned __int64 v3; // r13
  double v4; // xmm0_8
  double v5; // xmm1_8
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rdi
  FMOD::SoundI *mSound; // rax
  unsigned int *v12; // rax
  __int64 v13; // rdx
  __int64 mChannels; // rcx
  FMOD::DSPI *mDSP; // rax
  unsigned __int64 v16; // rsi
  unsigned __int64 v17; // rtt
  unsigned int length[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  mRealChannel = this->mRealChannel;
  if ( !mRealChannel )
    return result;
  if ( !this->mChannelGroupParent )
    return result;
  LOBYTE(result) = 68;
  if ( (postype & 0x600) != 0 )
    return result;
  mSound = mRealChannel->mSound;
  if ( mSound && (postype & 0x10) == 0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::SoundI *, unsigned int *))mSound->_vptr_SoundI + 19))(
               mRealChannel->mSound,
               length);
    if ( result )
      return result;
    result = FMOD_RESULT::FMOD_ERR_INVALID_POSITION_0;
    if ( length[0] <= position )
      return result;
    mRealChannel = this->mRealChannel;
  }
  if ( (postype & 7) == 0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, _QWORD, _QWORD, _QWORD))mRealChannel->_vptr_ChannelReal
              + 27))(
               mRealChannel,
               position,
               postype,
               0);
    if ( result )
      return result;
    return FMOD::ChannelI::updateSyncPoints(this, 1);
  }
  v12 = (unsigned int *)mRealChannel->mSound;
  if ( v12 )
  {
    v13 = v12[10];
    mChannels = v12[26];
    *(_QWORD *)&v5 = v12[27];
  }
  else
  {
    mDSP = mRealChannel->mDSP;
    if ( !mDSP )
      return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    mChannels = mDSP->mDescription.mChannels;
    v13 = 5;
    *(float *)&v5 = (float)this->mSystem->mDSPSampleRate;
  }
  if ( (postype & 2) != 0 )
  {
    v3 = (unsigned __int64)position << 32;
  }
  else if ( (postype & 4) != 0 )
  {
    if ( (_DWORD)mChannels )
    {
      switch ( (int)v13 )
      {
        case 1:
          v16 = 8;
          goto LABEL_28;
        case 2:
          v16 = 16;
          goto LABEL_28;
        case 3:
          v16 = 24;
          goto LABEL_28;
        case 4:
        case 5:
          v16 = 32;
LABEL_28:
          v17 = 8LL * position;
          v13 = (unsigned int)(v17 / v16) % (unsigned int)mChannels;
          v3 = (unsigned __int64)((unsigned int)(v17 / v16) / (unsigned int)mChannels) << 32;
          break;
        default:
          v3 = (unsigned __int64)position << 32;
          break;
      }
    }
    v3 &= 0xFFFFFFFF00000000LL;
  }
  else if ( (postype & 1) != 0 )
  {
    *(float *)&v4 = (float)((float)((float)(int)position / 1000.0) * *(float *)&v5) + 0.5;
    v3 = (unsigned __int64)(unsigned int)(int)*(float *)&v4 << 32;
  }
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, unsigned __int64, __int64, __int64, double, double))mRealChannel->_vptr_ChannelReal
            + 16))(
             mRealChannel,
             v3,
             v13,
             mChannels,
             v4,
             v5);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::ChannelI::updateSyncPoints(this, 1);
  return result;
}


// Address: 0x21b4c90 | Name: _ZN4FMOD8ChannelI4playEPNS_4DSPIEPNS_13ChannelGroupIEbbb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::play(
        FMOD::ChannelI *const this,
        FMOD::DSPI *dsp,
        FMOD::ChannelGroupI *channelgroup,
        bool paused,
        bool reset,
        bool startmuted)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rdx
  int (**vptr_ChannelControlI)(...); // rax
  int (**v14)(...); // rax
  FMOD::SystemI *mSystem; // rcx
  int (**v16)(...); // rax
  FMOD_MODE mode; // [rsp+Ch] [rbp-3Ch] BYREF
  FMOD_VECTOR vel; // [rsp+10h] [rbp-38h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
  {
    if ( !channelgroup && (mRealChannel->mFlags & 0x10000) == 0 )
      channelgroup = this->mSystem->mMasterChannelGroup;
    result = FMOD::ChannelI::setChannelGroupInternal(this, channelgroup, 0, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::ChannelI::alloc(this, dsp, reset);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        vptr_ChannelControlI = this->_vptr_ChannelControlI;
        this->mFlags |= 0x40000u;
        result = vptr_ChannelControlI[2](this, 1);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          if ( startmuted )
          {
            this->mSoundGroupFadeVolume = 0.0;
            this->mSoundGroupFadeTarget = 0.0;
          }
          else
          {
            this->mSoundGroupFadeVolume = 1.0;
            this->mSoundGroupFadeTarget = 1.0;
          }
          if ( !reset )
          {
            result = FMOD::ChannelI::start(this);
            if ( result )
              return result;
            goto LABEL_11;
          }
          result = FMOD::ChannelI::setDefaults(this);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = FMOD::ChannelI::setPosition(this, 0, 2u);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              result = FMOD::ChannelI::start(this);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                v14 = this->_vptr_ChannelControlI;
                mode = 0;
                v14[19](this, &mode);
                if ( (mode & 0x10) == 0
                  || (mSystem = this->mSystem,
                      v16 = this->_vptr_ChannelControlI,
                      vel.x = 0.0,
                      vel.y = 0.0,
                      vel.z = 0.0,
                      (result = v16[40](this, (__int64)mSystem->mListener, &vel)) == FMOD_RESULT::FMOD_OK_0) )
                {
LABEL_11:
                  result = FMOD_RESULT::FMOD_OK_0;
                  if ( !paused )
                    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelI *const, _QWORD))this->_vptr_ChannelControlI
                            + 2))(
                             this,
                             0);
                }
              }
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21b4e30 | Name: _ZN4FMOD8ChannelI4playEPNS_6SoundIEPNS_13ChannelGroupIEbbb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::play(
        FMOD::ChannelI *const this,
        FMOD::SoundI *sound,
        FMOD::ChannelGroupI *channelgroup,
        bool paused,
        bool reset,
        bool startmuted)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rdi
  FMOD::ChannelGroupI *mMasterChannelGroup; // r12
  int (**vptr_ChannelControlI)(...); // rax
  bool v12; // r8
  bool v13; // r8
  FMOD::SyncPoint *mSyncPointHead; // rax
  FMOD::SyncPoint *v15; // rax
  FMOD::SoundGroupI *mSoundGroup; // rax
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::SystemI *mSystem; // rcx
  FMOD::LinkedListNode *mNodeNext; // rdx
  FMOD::SystemI *v20; // rcx
  int (**v21)(...); // rax
  bool v23; // [rsp+8h] [rbp-50h]
  FMOD_MODE mode; // [rsp+14h] [rbp-44h] BYREF
  FMOD::DSPI *dsphead; // [rsp+18h] [rbp-40h] BYREF
  FMOD_VECTOR vel; // [rsp+20h] [rbp-38h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( sound )
  {
    mRealChannel = this->mRealChannel;
    LOBYTE(result) = 30;
    if ( mRealChannel )
    {
      LOBYTE(result) = 60;
      if ( !sound->mNumSubSounds )
      {
        mMasterChannelGroup = channelgroup;
        if ( !channelgroup && (mRealChannel->mFlags & 0x10000) == 0 )
          mMasterChannelGroup = this->mSystem->mMasterChannelGroup;
        result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, _QWORD, FMOD::DSPI **))this->_vptr_ChannelControlI
                  + 36))(
                   this,
                   0,
                   &dsphead);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          if ( dsphead )
            dsphead->mChannelOwner = this;
          result = FMOD::ChannelI::setChannelGroupInternal(this, mMasterChannelGroup, 0, 0);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = FMOD::ChannelI::alloc(this, sound, reset);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              vptr_ChannelControlI = this->_vptr_ChannelControlI;
              this->mFlags |= 0x40000u;
              result = vptr_ChannelControlI[2](this, 1);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                v12 = reset;
                if ( !reset
                  || (!startmuted
                    ? (this->mSoundGroupFadeVolume = 1.0, this->mSoundGroupFadeTarget = 1.0)
                    : (this->mSoundGroupFadeVolume = 0.0, this->mSoundGroupFadeTarget = 0.0),
                      (result = FMOD::ChannelI::setDefaults(this)) == FMOD_RESULT::FMOD_OK_0
                   && (result = FMOD::ChannelI::setPosition(this, 0, 2u), v12 = reset, result == FMOD_RESULT::FMOD_OK_0)) )
                {
                  v23 = v12;
                  result = FMOD::ChannelI::start(this);
                  v13 = v23;
                  if ( result == FMOD_RESULT::FMOD_OK_0 )
                  {
                    ++sound->mNumAudible;
                    if ( sound->mSoundGroup && (this->mRealChannel->mFlags & 0x10000) == 0 )
                    {
                      FMOD_OS_CriticalSection_Enter(off_286F358->gSoundListCrit);
                      mSoundGroup = sound->mSoundGroup;
                      mNodePrev = mSoundGroup->mNodePrev;
                      mNodePrev->mNodeNext = mSoundGroup->mNodeNext;
                      mSoundGroup->mNodeNext->mNodePrev = mNodePrev;
                      mSystem = this->mSystem;
                      mSoundGroup->mNodeNext = mSoundGroup;
                      mNodeNext = mSystem->mSoundGroupUsedHead.mNodeNext;
                      mSoundGroup->mNodePrev = &mSystem->mSoundGroupUsedHead;
                      mSoundGroup->mNodeNext = mNodeNext;
                      mNodeNext->mNodePrev = mSoundGroup;
                      mSoundGroup->mNodePrev->FMOD::LinkedListNode::mNodeNext = mSoundGroup;
                      FMOD_OS_CriticalSection_Leave(off_286F358->gSoundListCrit);
                      v13 = v23;
                    }
                    if ( !v13 )
                      goto LABEL_22;
                    (*((void (__fastcall **)(FMOD::SoundI *, FMOD_MODE *))sound->_vptr_SoundI + 36))(sound, &mode);
                    if ( (mode & 0x10) == 0
                      || (v20 = this->mSystem,
                          v21 = this->_vptr_ChannelControlI,
                          vel.x = 0.0,
                          vel.y = 0.0,
                          vel.z = 0.0,
                          (result = v21[40](this, (__int64)v20->mListener, &vel)) == FMOD_RESULT::FMOD_OK_0) )
                    {
                      if ( (this->mSystem->mMasterChannelGroup->mFlags & 2) == 0
                        || (this->mRealChannel->mFlags & 0x10000) != 0
                        || (result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, _QWORD))this->_vptr_ChannelControlI
                                      + 11))(
                                       this,
                                       (this->mFlags >> 1) & 1)) == FMOD_RESULT::FMOD_OK_0 )
                      {
LABEL_22:
                        mSyncPointHead = sound->mSyncPointHead;
                        if ( mSyncPointHead && sound->mNumSyncPoints )
                        {
                          v15 = (FMOD::SyncPoint *)mSyncPointHead->mNodeNext;
                          this->mSyncPointLastPos = 0;
                          this->mSyncPointCurrent = v15;
                        }
                        result = FMOD_RESULT::FMOD_OK_0;
                        if ( !paused )
                          return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelI *const, _QWORD))this->_vptr_ChannelControlI
                                  + 2))(
                                   this,
                                   0);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21b5150 | Name: _ZN4FMOD8ChannelI12setLoopCountEi
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setLoopCount(FMOD::ChannelI *const this, int loopcount)
{
  FMOD::ChannelReal *mRealChannel; // rdx
  FMOD_RESULT_0 result; // eax

  mRealChannel = this->mRealChannel;
  if ( !mRealChannel || !this->mChannelGroupParent )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( loopcount >= -1 )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *))mRealChannel->_vptr_ChannelReal + 19))(this->mRealChannel);
  return result;
}


// Address: 0x21b5190 | Name: _ZN4FMOD8ChannelI12getLoopCountEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getLoopCount(FMOD::ChannelI *const this, int *loopcount)
{
  FMOD::ChannelReal *mRealChannel; // rdi

  if ( !loopcount )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mRealChannel = this->mRealChannel;
  if ( mRealChannel )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *))mRealChannel->_vptr_ChannelReal + 20))(mRealChannel);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x21b51d0 | Name: _ZN4FMOD8ChannelI13setLoopPointsEjjjj
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setLoopPoints(
        FMOD::ChannelI *const this,
        unsigned int loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int loopend,
        FMOD_TIMEUNIT loopendtype)
{
  FMOD::ChannelReal *mRealChannel; // r9
  FMOD_RESULT_0 result; // eax
  FMOD::SoundI *mSound; // rdi
  FMOD_SOUND_FORMAT_0 mFormat; // edx
  unsigned int v9; // edi
  unsigned __int64 v10; // r8
  unsigned int mChannels; // r10d
  unsigned __int64 v12; // r11

  mRealChannel = this->mRealChannel;
  if ( !mRealChannel || !this->mChannelGroupParent )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( loopstarttype - 1 > 1 )
  {
    result = FMOD_RESULT::FMOD_ERR_FORMAT_0;
    if ( loopstarttype != 4 )
      return result;
  }
  if ( loopendtype - 1 > 1 )
  {
    result = FMOD_RESULT::FMOD_ERR_FORMAT_0;
    if ( loopendtype != 4 )
      return result;
  }
  mSound = mRealChannel->mSound;
  if ( !mSound )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( loopstarttype != 2 )
  {
    if ( loopstarttype == 4 )
    {
      mChannels = mSound->mChannels;
      if ( mChannels )
      {
        switch ( mSound->mFormat )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v12 = 8;
            goto LABEL_32;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v12 = 16;
            goto LABEL_32;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v12 = 24;
            goto LABEL_32;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v12 = 32;
LABEL_32:
            *(_QWORD *)&loopstart = (unsigned int)(8 * (unsigned __int64)loopstart / v12) / mChannels;
            break;
          default:
            goto LABEL_14;
        }
        goto LABEL_14;
      }
    }
    else if ( loopstarttype == 1 )
    {
      *(_QWORD *)&loopstart = (unsigned int)(int)(float)((float)((float)((float)(int)loopstart / 1000.0)
                                                               * mSound->mDefaultFrequency)
                                                       + 0.5);
      goto LABEL_14;
    }
    *(_QWORD *)&loopstart = 0;
  }
LABEL_14:
  if ( loopendtype != 2 )
  {
    if ( loopendtype == 4 )
    {
      mFormat = mSound->mFormat;
      v9 = mSound->mChannels;
      result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      if ( !v9 )
        return result;
      switch ( mFormat )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
          v10 = 8;
          goto LABEL_25;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          v10 = 16;
          goto LABEL_25;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          v10 = 24;
          goto LABEL_25;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          v10 = 32;
LABEL_25:
          loopend = (unsigned int)(8 * (unsigned __int64)loopend / v10) / v9;
          break;
        default:
          break;
      }
    }
    else
    {
      result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      if ( loopendtype != 1 )
        return result;
      loopend = (int)(float)((float)((float)((float)(int)loopend / 1000.0) * mSound->mDefaultFrequency) + 0.5);
    }
  }
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( loopstart < loopend )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, _QWORD, _QWORD))mRealChannel->_vptr_ChannelReal + 18))(
             mRealChannel,
             *(_QWORD *)&loopstart,
             loopend - loopstart + 1);
  return result;
}


// Address: 0x21b53a0 | Name: _ZN4FMOD8ChannelI14setChannelInfoEPNS_17FMOD_CHANNEL_INFOE
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setChannelInfo(FMOD::ChannelI *const this, FMOD::FMOD_CHANNEL_INFO *info)
{
  float v2; // xmm1_4
  unsigned int v4; // ebp
  __int64 v6; // rsi
  FMOD_RESULT_0 result; // eax
  bool isvirtual[25]; // [rsp+Fh] [rbp-19h] BYREF

  v4 = 0;
  (*((void (__fastcall **)(FMOD::ChannelI *const, _QWORD))this->_vptr_ChannelControlI + 18))(this, info->mMode);
  FMOD::ChannelI::setFrequency(this, this->mFrequency, v2);
  (*((void (__fastcall **)(FMOD::ChannelI *const, float))this->_vptr_ChannelControlI + 9))(this, this->mPitch);
  FMOD::ChannelI::setLoopPoints(this, info->mLoopStart, 2u, info->mLoopEnd, 2u);
  FMOD::ChannelI::setLoopCount(this, info->mLoopCount);
  FMOD::ChannelI::setPosition(this, info->mPCM, 2u);
  (*((void (__fastcall **)(FMOD::ChannelI *const, _QWORD, float))this->_vptr_ChannelControlI + 4))(
    this,
    0,
    this->mVolume);
  do
  {
    v6 = v4++;
    (*((void (__fastcall **)(FMOD::ChannelI *const, __int64))this->_vptr_ChannelControlI + 15))(this, v6);
  }
  while ( v4 != 4 );
  if ( !this->mCallback
    || ((*((void (__fastcall **)(FMOD::ChannelI *const, bool *))this->_vptr_ChannelControlI + 62))(this, isvirtual),
        (result = FMOD::ChannelControlI::executeCallback(
                    this,
                    (FMOD_CHANNELCONTROL *)this->mHandleCurrent,
                    FMOD_CHANNELCONTROL_TYPE::FMOD_CHANNELCONTROL_CHANNEL_0,
                    FMOD_CHANNELCONTROL_CALLBACK_TYPE::FMOD_CHANNELCONTROL_CALLBACK_VIRTUALVOICE_0,
                    (void *)isvirtual[0],
                    0)) == FMOD_RESULT::FMOD_OK_0) )
  {
    (*((void (__fastcall **)(FMOD::ChannelReal *))info->mRealChannel->_vptr_ChannelReal + 26))(info->mRealChannel);
    info->mRealChannel->mFlags &= ~0x8000u;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b54a0 | Name: _ZN4FMOD8ChannelI13getLoopPointsEPjjS1_j
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getLoopPoints(
        FMOD::ChannelI *const this,
        unsigned int *loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int *loopend,
        FMOD_TIMEUNIT loopendtype)
{
  FMOD::ChannelReal *mRealChannel; // rdi
  FMOD_RESULT_0 result; // eax
  FMOD::SoundI *mSound; // r9
  __int64 v8; // rdx
  __int64 mLoopStart; // rax
  __int64 v10; // rdx
  __int64 v11; // rax
  unsigned __int64 v12; // rax

  mRealChannel = this->mRealChannel;
  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( mRealChannel )
  {
    if ( loopstarttype - 1 <= 1 || (result = FMOD_RESULT::FMOD_ERR_FORMAT_0, loopstarttype == 4) )
    {
      if ( loopendtype - 1 <= 1 || (result = FMOD_RESULT::FMOD_ERR_FORMAT_0, loopendtype == 4) )
      {
        mSound = mRealChannel->mSound;
        result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        if ( mSound )
        {
          if ( loopstart )
          {
            switch ( loopstarttype )
            {
              case 2u:
                *loopstart = mRealChannel->mLoopStart;
                break;
              case 4u:
                mLoopStart = mRealChannel->mLoopStart;
                switch ( mSound->mFormat )
                {
                  case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
                    v10 = 8;
                    goto LABEL_23;
                  case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
                    v10 = 16;
                    goto LABEL_23;
                  case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
                    v10 = 24;
                    goto LABEL_23;
                  case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
                  case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
                    v10 = 32;
LABEL_23:
                    LODWORD(mLoopStart) = (unsigned __int64)(mLoopStart * v10) >> 3;
                    break;
                  default:
                    break;
                }
                *loopstart = mSound->mChannels * mLoopStart;
                break;
              case 1u:
                *loopstart = (int)(float)((float)((float)((float)(int)mRealChannel->mLoopStart * 1000.0)
                                                / mSound->mDefaultFrequency)
                                        + 0.5);
                break;
            }
          }
          if ( loopend )
          {
            v8 = mRealChannel->mLoopLength + mRealChannel->mLoopStart - 1;
            if ( loopendtype == 2 )
            {
              *loopend = v8;
              return FMOD_RESULT::FMOD_OK_0;
            }
            else if ( loopendtype == 4 )
            {
              switch ( mSound->mFormat )
              {
                case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
                  v11 = 8;
                  goto LABEL_30;
                case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
                  v11 = 16;
                  goto LABEL_30;
                case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
                  v11 = 24;
                  goto LABEL_30;
                case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
                case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
                  v11 = 32;
LABEL_30:
                  v12 = (unsigned __int64)(v8 * v11) >> 3;
                  break;
                default:
                  LODWORD(v12) = mRealChannel->mLoopLength + mRealChannel->mLoopStart - 1;
                  break;
              }
              *loopend = mSound->mChannels * v12;
              return FMOD_RESULT::FMOD_OK_0;
            }
            else
            {
              result = FMOD_RESULT::FMOD_OK_0;
              if ( loopendtype == 1 )
                *loopend = (int)(float)((float)((float)((float)(int)v8 * 1000.0) / mSound->mDefaultFrequency) + 0.5);
            }
          }
          else
          {
            return FMOD_RESULT::FMOD_OK_0;
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21b5630 | Name: _ZN4FMOD8ChannelI14getChannelInfoEPNS_17FMOD_CHANNEL_INFOE
FMOD_RESULT_0 __fastcall FMOD::ChannelI::getChannelInfo(FMOD::ChannelI *const this, FMOD::FMOD_CHANNEL_INFO *info)
{
  FMOD::ChannelReal *realchannel; // [rsp+8h] [rbp-20h] BYREF

  realchannel = 0;
  FMOD::ChannelI::getRealChannel(this, &realchannel);
  info->mRealChannel = realchannel;
  (*((void (__fastcall **)(FMOD::ChannelI *const, FMOD::FMOD_CHANNEL_INFO *))this->_vptr_ChannelControlI + 19))(
    this,
    info);
  FMOD::ChannelI::getPosition(this, &info->mPCM, 2u);
  FMOD::ChannelI::getLoopPoints(this, &info->mLoopStart, 2u, &info->mLoopEnd, 2u);
  FMOD::ChannelI::getLoopCount(this, &info->mLoopCount);
  (*((void (__fastcall **)(FMOD::ChannelI *const, bool *))this->_vptr_ChannelControlI + 3))(this, &info->mPaused);
  info->mRealChannel->mFlags |= 0x8000u;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b56d0 | Name: _ZN4FMOD8ChannelI12forceVirtualEb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::forceVirtual(FMOD::ChannelI *const this, bool force)
{
  FMOD_RESULT_0 result; // eax
  FMOD::FMOD_CHANNELCONTROL_FLAG v3; // edx
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // edx
  unsigned int mDSPTick; // esi
  int mVirtualDSPTick; // ecx
  FMOD::FMOD_CHANNELCONTROL_FLAG v7; // ebp
  bool v8; // zf
  FMOD::ChannelReal *mRealChannel; // rax
  FMOD::SoundI *mSound; // r13
  FMOD::DSPI *mDSP; // r14
  FMOD::ChannelGroupI *mChannelGroupParent; // r15
  int (**vptr_ChannelControlI)(...); // rax
  bool isvirtual; // [rsp+6h] [rbp-62h] BYREF
  bool playing; // [rsp+7h] [rbp-61h] BYREF
  FMOD::ChannelReal *emuchannelreal; // [rsp+8h] [rbp-60h] BYREF
  FMOD::FMOD_CHANNEL_INFO realinfo; // [rsp+10h] [rbp-58h] BYREF

  if ( force )
  {
    if ( (this->mFlags & 0x200000) != 0 )
      return FMOD_RESULT::FMOD_OK_0;
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, bool *))this->_vptr_ChannelControlI + 21))(
               this,
               &playing);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mFlags = this->mFlags;
      if ( (mFlags & 0x20000) != 0 || !playing )
        return FMOD_RESULT::FMOD_OK_0;
      mDSPTick = this->mSystem->mOutput->mDSPTick;
      mVirtualDSPTick = this->mVirtualDSPTick;
      if ( !mVirtualDSPTick )
      {
        this->mVirtualDSPTick = mDSPTick;
        this->mFlags = mFlags | 0x1000000;
        return result;
      }
      if ( mDSPTick == mVirtualDSPTick || mVirtualDSPTick + 1 == mDSPTick )
      {
        this->mFlags = mFlags | 0x1000000;
        return FMOD_RESULT::FMOD_OK_0;
      }
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, bool *))this->_vptr_ChannelControlI + 62))(
                 this,
                 &isvirtual);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v7 = this->mFlags;
        this->mVirtualDSPTick = 0;
        v8 = !isvirtual;
        this->mFlags = v7 | 0x20000;
        if ( !v8 )
          return FMOD_RESULT::FMOD_OK_0;
        mRealChannel = this->mRealChannel;
        if ( !mRealChannel )
          return FMOD_RESULT::FMOD_OK_0;
        mSound = mRealChannel->mSound;
        mDSP = mRealChannel->mDSP;
        result = FMOD::Output::getFreeChannel(this->mSystem->mEmulated, &emuchannelreal, 0);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          mChannelGroupParent = this->mChannelGroupParent;
          FMOD::ChannelI::getChannelInfo(this, &realinfo);
          FMOD::ChannelI::stopEx(this, 4u);
          this->mRealChannel = emuchannelreal;
          if ( mSound )
          {
            FMOD::ChannelI::play(this, mSound, mChannelGroupParent, 1, 0, 0);
          }
          else
          {
            if ( !mDSP )
            {
LABEL_21:
              if ( (v7 & 0x40000) != 0 )
              {
                this->mFlags |= 0x10000u;
                return FMOD_RESULT::FMOD_OK_0;
              }
              return FMOD_RESULT::FMOD_OK_0;
            }
            FMOD::ChannelI::play(this, mDSP, mChannelGroupParent, 1, 0, 0);
          }
          FMOD::ChannelI::setChannelInfo(this, &realinfo);
          vptr_ChannelControlI = this->_vptr_ChannelControlI;
          this->mFlags &= ~0x40000u;
          vptr_ChannelControlI[2](this, realinfo.mPaused);
          goto LABEL_21;
        }
      }
    }
  }
  else
  {
    v3 = this->mFlags;
    result = FMOD_RESULT::FMOD_OK_0;
    this->mVirtualDSPTick = 0;
    if ( (v3 & 0x20000) != 0 )
      this->mFlags = v3 & 0xFFFDFFFF;
  }
  return result;
}


// Address: 0x21b58d0 | Name: _ZN4FMOD8ChannelI14updatePositionEv
FMOD_RESULT_0 __fastcall FMOD::ChannelI::updatePosition(FMOD::ChannelI *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *mRealChannel; // rdx
  FMOD::SoundI *mSound; // rbp
  FMOD::ChannelGroupI *mChannelGroupParent; // rax
  float v6; // xmm2_4
  float v7; // xmm0_4
  float v8; // xmm1_4
  FMOD::SystemI *mSystem; // rax
  int v10; // eax
  int mPriority; // esi
  unsigned int mListPosition; // eax
  unsigned int mSoundGroupListPosition; // r9d
  int v14; // ecx
  int v15; // esi
  unsigned int v16; // edx
  unsigned int v17; // ecx
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::SortedLinkedListNode *p_mSortedListNode; // rdi
  FMOD::SystemI *v20; // r8
  FMOD::LinkedListNode *p_mChannelSortedListHead; // rsi
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *v23; // rdx
  FMOD::SoundGroupI *mSoundGroup; // rsi
  FMOD::LinkedListNode *v25; // rax
  FMOD::SortedLinkedListNode *p_mSoundGroupSortedListNode; // rdi
  FMOD::LinkedListNode *p_mChannelListHead; // rdx
  FMOD::LinkedListNode *v28; // rax
  FMOD::LinkedListNode *v29; // rdx
  FMOD::LinkedListNode *v30; // rax
  FMOD::LinkedListNode *v31; // rax
  float audibilitysoundgroup[7]; // [rsp+1Ch] [rbp-1Ch] BYREF

  result = FMOD_RESULT::FMOD_OK_0;
  if ( (this->mFlags & 0x40000) == 0 )
  {
    mRealChannel = this->mRealChannel;
    LOBYTE(result) = 30;
    if ( mRealChannel )
    {
      if ( this->mChannelGroupParent )
      {
        if ( (mRealChannel->mFlags & 0x10000) != 0 )
          return FMOD_RESULT::FMOD_OK_0;
        mSound = mRealChannel->mSound;
        FMOD::ChannelI::getAudibilityInternal(this, audibilitysoundgroup, 0);
        mChannelGroupParent = this->mChannelGroupParent;
        v6 = this->mSoundGroupFadeVolume * audibilitysoundgroup[0];
        v7 = (float)((float)(1.0 - this->mDirectOcclusion) * (float)(1.0 - this->mUserDirectOcclusion))
           * mChannelGroupParent->mRealDirectOcclusionVolume;
        v8 = (float)((float)(1.0 - this->mReverbOcclusion) * (float)(1.0 - this->mUserReverbOcclusion))
           * mChannelGroupParent->mRealReverbOcclusionVolume;
        mSystem = this->mSystem;
        if ( mSystem->mAdvancedSettings.vol0virtualvol < v6 )
          LOBYTE(v10) = 0;
        else
          v10 = (mSystem->mFlags >> 17) & 1;
        if ( v8 > 0.0 && v7 == 0.0 )
          LOBYTE(v10) = 0;
        mPriority = this->mPriority;
        if ( mPriority )
          LOBYTE(mPriority) = v10;
        FMOD::ChannelI::forceVirtual(this, mPriority);
        mListPosition = this->mListPosition;
        mSoundGroupListPosition = this->mSoundGroupListPosition;
        v14 = 10001 * this->mPriority + 10000;
        v15 = (int)(float)(10000.0 * audibilitysoundgroup[0]);
        v16 = v14 - (int)(float)((float)(v6 * 0.1) * 10000.0);
        this->mListPosition = v16;
        v17 = v14 - v15;
        this->mSoundGroupListPosition = v17;
        if ( mListPosition != v16 )
        {
          mNodePrev = this->mSortedListNode.mNodePrev;
          p_mSortedListNode = &this->mSortedListNode;
          v20 = this->mSystem;
          mNodePrev->mNodeNext = this->mSortedListNode.mNodeNext;
          this->mSortedListNode.mNodeNext->mNodePrev = mNodePrev;
          this->mSortedListNode.mNodePrev = &this->mSortedListNode;
          p_mChannelSortedListHead = &v20->mChannelSortedListHead;
          this->mSortedListNode.mNodeNext = &this->mSortedListNode;
          this->mSortedListNode.mNodePriority = -1;
          this->mSortedListNode.mNodeData = 0;
          mNodeNext = v20->mChannelSortedListHead.mNodeNext;
          do
          {
            if ( v16 < LODWORD(mNodeNext[1].mNodeNext) )
            {
              this->mSortedListNode.mNodePriority = v16;
              v23 = mNodeNext->mNodePrev;
              this->mSortedListNode.mNodeNext = mNodeNext;
              this->mSortedListNode.mNodePrev = v23;
              mNodeNext->mNodePrev = p_mSortedListNode;
              this->mSortedListNode.mNodePrev->mNodeNext = p_mSortedListNode;
              goto LABEL_19;
            }
            mNodeNext = mNodeNext->mNodeNext;
          }
          while ( p_mChannelSortedListHead != mNodeNext->mNodePrev );
          v30 = v20->mChannelSortedListHead.mNodePrev;
          this->mSortedListNode.mNodePriority = v16;
          this->mSortedListNode.mNodeNext = p_mChannelSortedListHead;
          this->mSortedListNode.mNodePrev = v30;
          v20->mChannelSortedListHead.mNodePrev = p_mSortedListNode;
          this->mSortedListNode.mNodePrev->mNodeNext = p_mSortedListNode;
LABEL_19:
          this->mSortedListNode.mNodeData = this;
        }
        if ( !mSound )
          return FMOD_RESULT::FMOD_OK_0;
        mSoundGroup = mSound->mSoundGroup;
        if ( !mSoundGroup || mSoundGroupListPosition == v17 )
        {
          return FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          v25 = this->mSoundGroupSortedListNode.mNodePrev;
          p_mSoundGroupSortedListNode = &this->mSoundGroupSortedListNode;
          v25->mNodeNext = this->mSoundGroupSortedListNode.mNodeNext;
          this->mSoundGroupSortedListNode.mNodeNext->mNodePrev = v25;
          this->mSoundGroupSortedListNode.mNodePrev = &this->mSoundGroupSortedListNode;
          p_mChannelListHead = &mSoundGroup->mChannelListHead;
          this->mSoundGroupSortedListNode.mNodeNext = &this->mSoundGroupSortedListNode;
          this->mSoundGroupSortedListNode.mNodePriority = -1;
          this->mSoundGroupSortedListNode.mNodeData = 0;
          v28 = mSoundGroup->mChannelListHead.mNodeNext;
          do
          {
            if ( v17 < LODWORD(v28[1].mNodeNext) )
            {
              v29 = v28->mNodePrev;
              this->mSoundGroupSortedListNode.mNodePriority = v17;
              this->mSoundGroupSortedListNode.mNodeNext = v28;
              this->mSoundGroupSortedListNode.mNodePrev = v29;
              v28->mNodePrev = p_mSoundGroupSortedListNode;
              this->mSoundGroupSortedListNode.mNodePrev->mNodeNext = p_mSoundGroupSortedListNode;
              goto LABEL_27;
            }
            v28 = v28->mNodeNext;
          }
          while ( p_mChannelListHead != v28->mNodePrev );
          v31 = mSoundGroup->mChannelListHead.mNodePrev;
          this->mSoundGroupSortedListNode.mNodePriority = v17;
          this->mSoundGroupSortedListNode.mNodeNext = p_mChannelListHead;
          this->mSoundGroupSortedListNode.mNodePrev = v31;
          mSoundGroup->mChannelListHead.mNodePrev = p_mSoundGroupSortedListNode;
          this->mSoundGroupSortedListNode.mNodePrev->mNodeNext = p_mSoundGroupSortedListNode;
LABEL_27:
          this->mSoundGroupSortedListNode.mNodeData = this;
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x21b5bf0 | Name: _ZN4FMOD8ChannelI6updateEib
FMOD_RESULT_0 __fastcall FMOD::ChannelI::update(FMOD::ChannelI *const this, int delta_ms, bool updategeometrynow)
{
  FMOD_RESULT_0 result; // eax
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // eax
  char v7; // dl
  char *mRealChannel; // rdi
  FMOD::FMOD_CHANNELCONTROL_FLAG v9; // ecx
  FMOD::SystemI *mSystem; // rax
  int mNumListeners; // edx
  FMOD::SystemI *v12; // rdx
  bool paused; // [rsp+Bh] [rbp-2Dh] BYREF
  FMOD_MODE mode[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  result = FMOD::ChannelControlI::update(this, delta_ms, updategeometrynow, 0);
  if ( result )
    return result;
  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( !this->mRealChannel )
    return result;
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, bool *))this->_vptr_ChannelControlI + 3))(
             this,
             &paused);
  if ( result )
    return result;
  if ( paused )
  {
    mFlags = this->mFlags;
    goto LABEL_6;
  }
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, bool *))this->mRealChannel->_vptr_ChannelReal + 12))(
             this->mRealChannel,
             &paused);
  if ( result )
    return result;
  mFlags = this->mFlags;
  if ( paused || (mFlags & 0x40000) != 0 )
  {
LABEL_6:
    if ( (mFlags & 0x400000) != 0 )
    {
      if ( (mFlags & 0x20000) == 0 )
      {
        this->mFlags = mFlags & 0xFF7BFFFF | 0x800000;
        result = FMOD::ChannelI::updatePosition(this);
        if ( result )
          return result;
        mFlags = this->mFlags;
      }
    }
    else
    {
      mFlags |= 0x400000u;
      this->mFlags = mFlags;
    }
    goto LABEL_8;
  }
  mFlags &= 0xFF3FFFFF;
  this->mFlags = mFlags;
LABEL_8:
  if ( (mFlags & 0x40000) != 0 )
    return FMOD_RESULT::FMOD_OK_0;
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( (mode[0] & 8) != 0 )
      goto LABEL_16;
    v7 = 1;
    if ( !updategeometrynow )
      v7 = (this->mRealChannel->mFlags & 0x60) == 96;
    result = FMOD::ChannelControlI::update3D(this, delta_ms, v7);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
LABEL_16:
      result = FMOD::ChannelI::updateSyncPoints(this, 0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        mRealChannel = (char *)this->mRealChannel;
        if ( mRealChannel && mRealChannel[60] < 0 )
          return FMOD_RESULT::FMOD_OK_0;
        result = (*(unsigned int (__fastcall **)(char *, _QWORD))(*(_QWORD *)mRealChannel + 64LL))(
                   mRealChannel,
                   (unsigned int)delta_ms);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          v9 = this->mFlags;
          if ( (v9 & 0x1000004) != 0 )
            goto LABEL_34;
          mSystem = this->mSystem;
          mNumListeners = mSystem->mNumListeners;
          if ( mNumListeners <= 0 )
            return FMOD_RESULT::FMOD_OK_0;
          if ( mSystem->mListener[0].mMoved )
          {
LABEL_34:
            this->mFlags = v9 & 0xFEFFFFFB;
            return FMOD::ChannelI::updatePosition(this);
          }
          v12 = (FMOD::SystemI *)((char *)mSystem + 112 * (unsigned int)(mNumListeners - 1));
          while ( mSystem != v12 )
          {
            mSystem = (FMOD::SystemI *)((char *)mSystem + 112);
            if ( mSystem->mListener[0].mMoved )
              goto LABEL_34;
          }
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x21b5de0 | Name: _ZN4FMOD8ChannelI10set3DLevelEf
FMOD_RESULT_0 __fastcall FMOD::ChannelI::set3DLevel(FMOD::ChannelI *const this, __m128i a2, float level)
{
  FMOD::ChannelReal *mRealChannel; // rdx
  FMOD_RESULT_0 result; // eax
  bool v5; // zf

  mRealChannel = this->mRealChannel;
  if ( !mRealChannel || !this->mChannelGroupParent )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
  if ( (mRealChannel->mMode & 0x10) != 0 )
  {
    if ( (_mm_cvtsi128_si32(a2) & 0x7F800000) == 0x7F800000 )
    {
      return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
    }
    else if ( *(float *)a2.m128i_i32 > 1.0 || *(float *)a2.m128i_i32 < 0.0 )
    {
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
    else
    {
      v5 = (mRealChannel->mFlags & 0x20) == 0;
      LODWORD(this->m3DLevel) = a2.m128i_i32[0];
      if ( v5 || *(float *)a2.m128i_i32 >= 1.0 )
        return FMOD_RESULT::FMOD_OK_0;
      else
        return FMOD::ChannelI::update(this, 0, 0);
    }
  }
  return result;
}


// Address: 0x21b5e80 | Name: _ZN4FMOD8ChannelI9setPausedEb
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setPaused(FMOD::ChannelI *const this, bool paused)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelGroupI *mChannelGroupParent; // rdx
  bool v5; // bp
  FMOD::DSPI *v6; // rdi
  FMOD::DSPI *mDSPHead; // rax
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // eax
  FMOD::FMOD_CHANNELCONTROL_FLAG v9; // eax
  FMOD::DSPI *mDSPFader; // rdi
  FMOD_MODE mode[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( !this->mRealChannel )
    return result;
  mChannelGroupParent = this->mChannelGroupParent;
  if ( !mChannelGroupParent )
    return result;
  v5 = paused;
  if ( paused )
  {
    this->mFlags |= 1u;
  }
  else
  {
    this->mFlags &= ~1u;
    if ( (mChannelGroupParent->mFlags & 0x10) != 0 )
    {
      v5 = 1;
    }
    else
    {
      mFlags = this->mFlags;
      if ( (mFlags & 0x40000) != 0 )
      {
        mode[0] = 0;
        this->mFlags = mFlags & 0xFFFBFFFF;
        FMOD::ChannelI::updatePosition(this);
        (*((void (__fastcall **)(FMOD::ChannelI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(this, mode);
        if ( (mode[0] & 0x10) != 0 )
        {
          this->mFlags |= 0x80000u;
          FMOD::ChannelI::update(this, 0, 1);
          this->mFlags &= ~0x80000u;
        }
      }
    }
  }
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 62))(
             this,
             mode);
  if ( result )
    return result;
  if ( (this->mChannelGroupParent->FMOD::ChannelControlI::mFlags & 0x10) == 0 && v5 && !LOBYTE(mode[0]) )
  {
    result = FMOD::DSPI::setActive(this->mDSPHead, 0, 1);
    if ( result )
      return result;
    mDSPFader = (FMOD::DSPI *)this->mDSPFader;
    if ( mDSPFader != this->mDSPHead )
    {
      result = FMOD::DSPI::setActive(mDSPFader, 0, 1);
      if ( result )
        return result;
    }
  }
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelReal *, bool))this->mRealChannel->_vptr_ChannelReal + 11))(
             this->mRealChannel,
             v5);
  if ( result )
    return result;
  if ( (this->mChannelGroupParent->FMOD::ChannelControlI::mFlags & 0x10) != 0 )
  {
    if ( v5 )
      return FMOD_RESULT::FMOD_OK_0;
    goto LABEL_24;
  }
  if ( v5 )
    return FMOD_RESULT::FMOD_OK_0;
  if ( LOBYTE(mode[0]) )
    goto LABEL_24;
  v6 = (FMOD::DSPI *)this->mDSPFader;
  mDSPHead = this->mDSPHead;
  if ( v6 != mDSPHead )
  {
    result = FMOD::DSPI::setActive(v6, 1, 1);
    if ( result )
      return result;
    mDSPHead = this->mDSPHead;
  }
  result = FMOD::DSPI::setActive(mDSPHead, 1, 1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
LABEL_24:
    v9 = this->mFlags;
    if ( (v9 & 0x800000) != 0 )
    {
      this->mFlags = v9 & 0xFF3FFFFF;
      return FMOD::ChannelI::updatePosition(this);
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b6080 | Name: _ZN4FMOD8ChannelI11setPriorityEi
FMOD_RESULT_0 __fastcall FMOD::ChannelI::setPriority(FMOD::ChannelI *const this, int priority)
{
  if ( (unsigned int)priority > 0x100 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  this->mPriority = priority;
  return FMOD::ChannelI::updatePosition(this);
}


