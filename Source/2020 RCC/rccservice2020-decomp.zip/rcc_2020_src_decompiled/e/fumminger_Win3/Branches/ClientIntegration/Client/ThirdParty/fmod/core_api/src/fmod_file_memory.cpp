// Address: 0x21f1d30 | Name: _ZN4FMOD10MemoryFile10reallyOpenEPKcPj
FMOD_RESULT_0 __fastcall FMOD::MemoryFile::reallyOpen(
        FMOD::MemoryFile *const this,
        const char *name_or_data,
        unsigned int *filesize)
{
  volatile unsigned int mFlags; // eax

  mFlags = this->mFlags;
  this->mMem = (void *)name_or_data;
  this->mPosition = 0;
  this->mFlags = mFlags & 0xFFFFFFFD;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f1d60 | Name: _ZN4FMOD10MemoryFile11reallyCloseEv
FMOD_RESULT_0 __fastcall FMOD::MemoryFile::reallyClose(FMOD::MemoryFile *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f1d70 | Name: _ZN4FMOD10MemoryFile10reallySeekEj
FMOD_RESULT_0 __fastcall FMOD::MemoryFile::reallySeek(FMOD::MemoryFile *const this, unsigned int pos)
{
  unsigned int mFileSize; // eax

  mFileSize = this->mFileSize;
  this->mPosition = pos;
  if ( pos > mFileSize )
    this->mPosition = mFileSize;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f1d90 | Name: _ZN4FMOD10MemoryFile14readPtrAdvanceEPPvj
FMOD_RESULT_0 __fastcall FMOD::MemoryFile::readPtrAdvance(
        FMOD::MemoryFile *const this,
        void **pointer,
        unsigned int size)
{
  __int64 mPosition; // rcx
  FMOD_RESULT_0 result; // eax
  unsigned int v5; // edx

  mPosition = this->mPosition;
  result = FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
  v5 = mPosition + size;
  if ( v5 <= this->mFileSize )
  {
    LOBYTE(result) = 0;
    *pointer = (char *)this->mMem + mPosition;
    this->mPosition = v5;
  }
  return result;
}


// Address: 0x21f1e10 | Name: _ZN4FMOD10MemoryFile10reallyReadEPvjPj
FMOD_RESULT_0 __fastcall FMOD::MemoryFile::reallyRead(
        FMOD::MemoryFile *const this,
        void *buffer,
        unsigned int size,
        unsigned int *read)
{
  FMOD_RESULT_0 v5; // r12d
  unsigned int v6; // ebp
  unsigned int mPosition; // r8d
  unsigned int mFileSize; // eax

  v5 = FMOD_RESULT::FMOD_OK_0;
  v6 = size;
  mPosition = this->mPosition;
  mFileSize = this->mFileSize;
  if ( size + mPosition > mFileSize )
  {
    LOBYTE(v5) = 16;
    v6 = mFileSize - mPosition;
  }
  memcpy_0(buffer, (char *)this->mMem + mPosition, v6);
  *read = v6;
  this->mPosition += v6;
  return v5;
}


// Address: 0x21f1e70 | Name: _ZN4FMOD10MemoryFile4initEPNS_7SystemIEjiPv
FMOD_RESULT_0 __fastcall FMOD::MemoryFile::init(
        FMOD::MemoryFile *const this,
        FMOD::SystemI *system,
        unsigned int filesize,
        int blocksize,
        void *data)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::File::init(this, system, filesize, blocksize);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    this->mPosition = 0;
    this->mMem = data;
  }
  return result;
}


