// Address: 0x2219f90 | Name: FMOD_DSP_Connection_MixMonoTo71_AVX
// positive sp value has been detected, the output may be wrong!
void __fastcall FMOD_DSP_Connection_MixMonoTo71_AVX(
        float *in,
        float *out,
        unsigned int len,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  __int64 v26; // rcx
  __int64 v29; // rdx
  __int64 v34; // rcx
  int v39; // [rsp+0h] [rbp-8h]

  __asm { vxorps  xmm0, xmm0, xmm0 }
  __asm
  {
    vbroadcastss ymm8, dword ptr [mixmatrix]
    vbroadcastss ymm7, dword ptr [mixmatrix+80h]
    vblendps ymm0, ymm0, ymm8, 1
    vbroadcastss ymm6, dword ptr [mixmatrix+100h]
  }
  __asm
  {
    vbroadcastss ymm5, dword ptr [mixmatrix+180h]
    vblendps ymm0, ymm0, ymm7, 2
    vbroadcastss ymm4, dword ptr [mixmatrix+200h]
    vbroadcastss ymm3, dword ptr [mixmatrix+280h]
    vblendps ymm0, ymm0, ymm6, 4
    vbroadcastss ymm2, dword ptr [mixmatrix+300h]
    vbroadcastss ymm1, dword ptr [mixmatrix+380h]
    vblendps ymm0, ymm0, ymm5, 8
    vblendps ymm0, ymm0, ymm4, 10h
    vblendps ymm0, ymm0, ymm3, 20h ; ' '
    vblendps ymm0, ymm0, ymm2, 40h ; '@'
    vblendps ymm0, ymm0, ymm1, 80h
  }
  if ( !v39 )
  {
    if ( len )
    {
      v26 = 4LL * (len - 1) + 4;
      _RAX = 0;
      do
      {
        __asm { vbroadcastss ymm1, dword ptr [in+rax] }
        v29 = (unsigned int)(2 * _RAX);
        _RAX += 4;
        __asm { vmulps  ymm1, ymm1, ymm0 }
        _RDX = &out[v29];
        __asm
        {
          vmovups ymm2, ymmword ptr [rdx]
          vaddps  ymm1, ymm2, ymm1
          vmovups ymmword ptr [rdx], ymm1
        }
      }
      while ( _RAX != v26 );
    }
    goto LABEL_5;
  }
  if ( !len )
  {
LABEL_5:
    __asm { vzeroupper }
    return;
  }
  v34 = 4LL * (len - 1) + 4;
  _RAX = 0;
  do
  {
    __asm { vbroadcastss ymm1, dword ptr [in+rax] }
    _RDX = (unsigned int)(2 * _RAX);
    _RAX += 4;
    __asm
    {
      vmulps  ymm1, ymm1, ymm0
      vmovups ymmword ptr [out+rdx*4], ymm1
    }
  }
  while ( _RAX != v34 );
  __asm { vzeroupper }
}


// Address: 0x221a0a0 | Name: FMOD_DSP_Connection_Mix71To71_Diagonal_AVX
// positive sp value has been detected, the output may be wrong!
void __fastcall FMOD_DSP_Connection_Mix71To71_Diagonal_AVX(
        float *in,
        float *out,
        unsigned int len,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  unsigned int v26; // eax
  unsigned int v27; // eax
  int v100; // [rsp+0h] [rbp-8h]

  __asm { vxorps  xmm0, xmm0, xmm0 }
  __asm
  {
    vmovups ymm8, ymmword ptr [mixmatrix]
    vmovups ymm7, ymmword ptr [mixmatrix+80h]
    vblendps ymm0, ymm0, ymm8, 1
    vmovups ymm6, ymmword ptr [mixmatrix+100h]
  }
  __asm
  {
    vmovups ymm5, ymmword ptr [mixmatrix+180h]
    vblendps ymm0, ymm0, ymm7, 2
    vmovups ymm4, ymmword ptr [mixmatrix+200h]
    vmovups ymm3, ymmword ptr [mixmatrix+280h]
    vblendps ymm0, ymm0, ymm6, 4
    vmovups ymm2, ymmword ptr [mixmatrix+300h]
    vmovups ymm1, ymmword ptr [mixmatrix+380h]
    vblendps ymm0, ymm0, ymm5, 8
    vblendps ymm0, ymm0, ymm4, 10h
    vblendps ymm0, ymm0, ymm3, 20h ; ' '
    vblendps ymm0, ymm0, ymm2, 40h ; '@'
    vblendps ymm0, ymm0, ymm1, 80h
  }
  if ( !v100 )
  {
    if ( len )
    {
      v26 = 0;
      while ( 2 )
      {
        switch ( ((_BYTE)len - 1 - (_BYTE)v26) & 7 )
        {
          case 0:
            goto LABEL_25;
          case 1:
            goto LABEL_24;
          case 2:
            goto LABEL_23;
          case 3:
            goto LABEL_22;
          case 4:
            goto LABEL_21;
          case 5:
            goto LABEL_20;
          case 6:
            goto LABEL_19;
          case 7:
            _RCX = 8 * v26++;
            _RCX *= 4;
            __asm { vmovups ymm1, ymmword ptr [in+rcx] }
            _RCX = (char *)out + _RCX;
            __asm
            {
              vmovups ymm2, ymmword ptr [rcx]
              vmulps  ymm1, ymm1, ymm0
              vaddps  ymm1, ymm2, ymm1
              vmovups ymmword ptr [rcx], ymm1
            }
LABEL_19:
            _RCX = 8 * v26++;
            _RCX *= 4;
            __asm { vmovups ymm1, ymmword ptr [in+rcx] }
            _RCX = (char *)out + _RCX;
            __asm
            {
              vmovups ymm2, ymmword ptr [rcx]
              vmulps  ymm1, ymm1, ymm0
              vaddps  ymm1, ymm2, ymm1
              vmovups ymmword ptr [rcx], ymm1
            }
LABEL_20:
            _RCX = 8 * v26++;
            _RCX *= 4;
            __asm { vmovups ymm1, ymmword ptr [in+rcx] }
            _RCX = (char *)out + _RCX;
            __asm
            {
              vmovups ymm2, ymmword ptr [rcx]
              vmulps  ymm1, ymm1, ymm0
              vaddps  ymm1, ymm2, ymm1
              vmovups ymmword ptr [rcx], ymm1
            }
LABEL_21:
            _RCX = 8 * v26++;
            _RCX *= 4;
            __asm { vmovups ymm1, ymmword ptr [in+rcx] }
            _RCX = (char *)out + _RCX;
            __asm
            {
              vmovups ymm2, ymmword ptr [rcx]
              vmulps  ymm1, ymm1, ymm0
              vaddps  ymm1, ymm2, ymm1
              vmovups ymmword ptr [rcx], ymm1
            }
LABEL_22:
            _RCX = 8 * v26++;
            _RCX *= 4;
            __asm { vmovups ymm1, ymmword ptr [in+rcx] }
            _RCX = (char *)out + _RCX;
            __asm
            {
              vmovups ymm2, ymmword ptr [rcx]
              vmulps  ymm1, ymm1, ymm0
              vaddps  ymm1, ymm2, ymm1
              vmovups ymmword ptr [rcx], ymm1
            }
LABEL_23:
            _RCX = 8 * v26++;
            _RCX *= 4;
            __asm { vmovups ymm1, ymmword ptr [in+rcx] }
            _RCX = (char *)out + _RCX;
            __asm
            {
              vmovups ymm2, ymmword ptr [rcx]
              vmulps  ymm1, ymm1, ymm0
              vaddps  ymm1, ymm2, ymm1
              vmovups ymmword ptr [rcx], ymm1
            }
LABEL_24:
            _RCX = 8 * v26++;
            _RCX *= 4;
            __asm { vmovups ymm1, ymmword ptr [in+rcx] }
            _RCX = (char *)out + _RCX;
            __asm
            {
              vmovups ymm2, ymmword ptr [rcx]
              vmulps  ymm1, ymm1, ymm0
              vaddps  ymm1, ymm2, ymm1
              vmovups ymmword ptr [rcx], ymm1
            }
LABEL_25:
            _RCX = 8 * v26++;
            _RCX *= 4;
            __asm { vmovups ymm1, ymmword ptr [in+rcx] }
            _RCX = (char *)out + _RCX;
            __asm
            {
              vmovups ymm2, ymmword ptr [rcx]
              vmulps  ymm1, ymm1, ymm0
              vaddps  ymm1, ymm2, ymm1
              vmovups ymmword ptr [rcx], ymm1
            }
            if ( len > v26 )
              continue;
            __asm { vzeroupper }
            break;
        }
        return;
      }
    }
LABEL_6:
    __asm { vzeroupper }
    return;
  }
  if ( !len )
    goto LABEL_6;
  v27 = 0;
  while ( 2 )
  {
    switch ( ((_BYTE)len - 1 - (_BYTE)v27) & 7 )
    {
      case 0:
        goto LABEL_16;
      case 1:
        goto LABEL_15;
      case 2:
        goto LABEL_14;
      case 3:
        goto LABEL_13;
      case 4:
        goto LABEL_12;
      case 5:
        goto LABEL_11;
      case 6:
        goto LABEL_10;
      case 7:
        _RCX = 8 * v27++;
        _RCX *= 4;
        __asm
        {
          vmovups ymm1, ymmword ptr [in+rcx]
          vmulps  ymm1, ymm1, ymm0
          vmovups ymmword ptr [out+rcx], ymm1
        }
LABEL_10:
        _RCX = 8 * v27++;
        _RCX *= 4;
        __asm
        {
          vmovups ymm1, ymmword ptr [in+rcx]
          vmulps  ymm1, ymm1, ymm0
          vmovups ymmword ptr [out+rcx], ymm1
        }
LABEL_11:
        _RCX = 8 * v27++;
        _RCX *= 4;
        __asm
        {
          vmovups ymm1, ymmword ptr [in+rcx]
          vmulps  ymm1, ymm1, ymm0
          vmovups ymmword ptr [out+rcx], ymm1
        }
LABEL_12:
        _RCX = 8 * v27++;
        _RCX *= 4;
        __asm
        {
          vmovups ymm1, ymmword ptr [in+rcx]
          vmulps  ymm1, ymm1, ymm0
          vmovups ymmword ptr [out+rcx], ymm1
        }
LABEL_13:
        _RCX = 8 * v27++;
        _RCX *= 4;
        __asm
        {
          vmovups ymm1, ymmword ptr [in+rcx]
          vmulps  ymm1, ymm1, ymm0
          vmovups ymmword ptr [out+rcx], ymm1
        }
LABEL_14:
        _RCX = 8 * v27++;
        _RCX *= 4;
        __asm
        {
          vmovups ymm1, ymmword ptr [in+rcx]
          vmulps  ymm1, ymm1, ymm0
          vmovups ymmword ptr [out+rcx], ymm1
        }
LABEL_15:
        _RCX = 8 * v27++;
        _RCX *= 4;
        __asm
        {
          vmovups ymm1, ymmword ptr [in+rcx]
          vmulps  ymm1, ymm1, ymm0
          vmovups ymmword ptr [out+rcx], ymm1
        }
LABEL_16:
        _RCX = 8 * v27++;
        _RCX *= 4;
        __asm
        {
          vmovups ymm1, ymmword ptr [in+rcx]
          vmulps  ymm1, ymm1, ymm0
          vmovups ymmword ptr [out+rcx], ymm1
        }
        if ( len > v27 )
          continue;
        __asm { vzeroupper }
        break;
    }
    break;
  }
}


// Address: 0x221a3c0 | Name: FMOD_DSP_Connection_Mix71To71_Full_AVX
// positive sp value has been detected, the output may be wrong!
void __fastcall FMOD_DSP_Connection_Mix71To71_Full_AVX(
        float *in,
        float *out,
        unsigned int len,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  int v17; // eax
  int v44; // eax

  __asm
  {
    vmovups ymm2, ymmword ptr [mixmatrix]
    vmovups ymm3, ymmword ptr [mixmatrix+80h]
  }
  __asm
  {
    vmovups ymm4, ymmword ptr [mixmatrix+100h]
    vmovups ymm5, ymmword ptr [mixmatrix+180h]
    vmovups ymm6, ymmword ptr [mixmatrix+200h]
    vmovups ymm7, ymmword ptr [mixmatrix+280h]
    vmovups ymm8, ymmword ptr [mixmatrix+300h]
    vmovups ymm9, ymmword ptr [mixmatrix+380h]
  }
  if ( !writedontmix )
  {
    v17 = 0;
    if ( len )
    {
      do
      {
        _RCX = (unsigned int)(8 * v17++);
        _RCX *= 4;
        __asm { vmovups ymm0, ymmword ptr [in+rcx] }
        _R8 = (char *)out + _RCX;
        _RCX = (char *)out + _RCX + 16;
        __asm
        {
          vdpps   ymm10, ymm0, ymm3, 0F1h
          vdpps   ymm11, ymm0, ymm7, 0F4h
          vdpps   ymm13, ymm0, ymm2, 0F1h
          vdpps   ymm12, ymm0, ymm4, 0F2h
          vdpps   ymm1, ymm0, ymm5, 0F2h
          vdpps   ymm15, ymm0, ymm6, 0F4h
          vdpps   ymm14, ymm0, ymm8, 0F8h
          vdpps   ymm0, ymm0, ymm9, 0F8h
          vorps   ymm1, ymm10, ymm1
          vorps   ymm14, ymm15, ymm14
          vorps   ymm12, ymm13, ymm12
          vorps   ymm0, ymm11, ymm0
          vorps   ymm12, ymm12, ymm14
          vorps   ymm0, ymm1, ymm0
          vunpcklps ymm1, ymm12, ymm0
          vunpckhps ymm0, ymm12, ymm0
          vmovaps xmm11, xmm1
          vmovaps xmm10, xmm0
          vextractf128 xmm1, ymm1, 1
          vextractf128 xmm0, ymm0, 1
          vaddps  xmm1, xmm11, xmm1
          vaddps  xmm0, xmm10, xmm0
          vaddps  xmm1, xmm1, xmmword ptr [r8]
          vaddps  xmm0, xmm0, xmmword ptr [rcx]
          vmovaps xmmword ptr [r8], xmm1
          vmovaps xmmword ptr [rcx], xmm0
        }
      }
      while ( v17 != len );
    }
    goto LABEL_4;
  }
  if ( !len )
  {
LABEL_4:
    __asm { vzeroupper }
    return;
  }
  v44 = 0;
  do
  {
    _R8 = (unsigned int)(8 * v44++);
    _RCX = 4 * _R8;
    __asm
    {
      vmovups ymm0, ymmword ptr [in+rcx]
      vdpps   ymm10, ymm0, ymm3, 0F1h
      vdpps   ymm11, ymm0, ymm7, 0F4h
      vdpps   ymm13, ymm0, ymm2, 0F1h
      vdpps   ymm12, ymm0, ymm4, 0F2h
      vdpps   ymm1, ymm0, ymm5, 0F2h
      vdpps   ymm15, ymm0, ymm6, 0F4h
      vdpps   ymm14, ymm0, ymm8, 0F8h
      vdpps   ymm0, ymm0, ymm9, 0F8h
      vorps   ymm1, ymm10, ymm1
      vorps   ymm14, ymm15, ymm14
      vorps   ymm12, ymm13, ymm12
      vorps   ymm0, ymm11, ymm0
      vorps   ymm12, ymm12, ymm14
      vorps   ymm0, ymm1, ymm0
      vunpcklps ymm1, ymm12, ymm0
      vunpckhps ymm0, ymm12, ymm0
      vmovaps xmm11, xmm1
      vmovaps xmm10, xmm0
      vextractf128 xmm1, ymm1, 1
      vextractf128 xmm0, ymm0, 1
      vaddps  xmm1, xmm11, xmm1
      vaddps  xmm0, xmm10, xmm0
      vmovaps xmmword ptr [out+r8*4], xmm1
      vmovaps xmmword ptr [out+rcx+10h], xmm0
    }
  }
  while ( v44 != len );
  __asm { vzeroupper }
}


// Address: 0x221a580 | Name: FMOD_DSP_Connection_MixStereoTo71_AVX
// positive sp value has been detected, the output may be wrong!
void __fastcall FMOD_DSP_Connection_MixStereoTo71_AVX(
        float *in,
        float *out,
        unsigned int len,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  int v41; // eax
  __int64 v45; // rcx
  int v52; // eax

  __asm
  {
    vbroadcastss ymm0, dword ptr [mixmatrix+384h]
    vbroadcastss ymm14, dword ptr [mixmatrix]
    vbroadcastss ymm15, dword ptr [mixmatrix+80h]
  }
  __asm
  {
    vbroadcastss ymm13, dword ptr [mixmatrix+100h]
    vbroadcastss ymm12, dword ptr [mixmatrix+180h]
    vbroadcastss ymm11, dword ptr [mixmatrix+200h]
    vbroadcastss ymm10, dword ptr [mixmatrix+280h]
    vbroadcastss ymm9, dword ptr [mixmatrix+300h]
    vbroadcastss ymm8, dword ptr [mixmatrix+380h]
    vbroadcastss ymm7, dword ptr [mixmatrix+4]
    vbroadcastss ymm6, dword ptr [mixmatrix+84h]
    vbroadcastss ymm5, dword ptr [mixmatrix+104h]
    vbroadcastss ymm4, dword ptr [mixmatrix+184h]
    vbroadcastss ymm3, dword ptr [mixmatrix+204h]
    vbroadcastss ymm2, dword ptr [mixmatrix+284h]
    vbroadcastss ymm1, dword ptr [mixmatrix+304h]
    vmovaps [rsp-10h+var_20], ymm0
    vxorps  xmm0, xmm0, xmm0
    vblendps ymm14, ymm0, ymm14, 1
    vblendps ymm0, ymm0, ymm7, 1
    vblendps ymm14, ymm14, ymm15, 2
    vblendps ymm6, ymm0, ymm6, 2
    vblendps ymm13, ymm14, ymm13, 4
    vblendps ymm5, ymm6, ymm5, 4
    vblendps ymm12, ymm13, ymm12, 8
    vblendps ymm4, ymm5, ymm4, 8
    vblendps ymm11, ymm12, ymm11, 10h
    vblendps ymm3, ymm4, ymm3, 10h
    vblendps ymm10, ymm11, ymm10, 20h ; ' '
    vblendps ymm2, ymm3, ymm2, 20h ; ' '
    vblendps ymm9, ymm10, ymm9, 40h ; '@'
    vblendps ymm1, ymm2, ymm1, 40h ; '@'
    vblendps ymm8, ymm9, ymm8, 80h
    vblendps ymm1, ymm1, [rsp-10h+var_20], 80h
  }
  if ( !writedontmix )
  {
    v41 = 0;
    if ( len )
    {
      do
      {
        _RCX = 4LL * (unsigned int)(2 * v41);
        __asm
        {
          vbroadcastss ymm3, dword ptr [in+rcx]
          vbroadcastss ymm2, dword ptr [in+rcx+4]
        }
        v45 = (unsigned int)(8 * v41++);
        __asm { vmulps  ymm3, ymm3, ymm8 }
        _RCX = &out[v45];
        __asm
        {
          vmulps  ymm2, ymm2, ymm1
          vmovups ymm0, ymmword ptr [rcx]
          vaddps  ymm0, ymm0, ymm3
          vaddps  ymm0, ymm0, ymm2
          vmovups ymmword ptr [rcx], ymm0
        }
      }
      while ( v41 != len );
    }
    goto LABEL_4;
  }
  if ( !len )
  {
LABEL_4:
    __asm { vzeroupper }
    return;
  }
  v52 = 0;
  do
  {
    _RCX = 4LL * (unsigned int)(2 * v52);
    __asm
    {
      vbroadcastss ymm2, dword ptr [in+rcx]
      vbroadcastss ymm0, dword ptr [in+rcx+4]
    }
    _RCX = (unsigned int)(8 * v52++);
    __asm { vmulps  ymm2, ymm2, ymm8 }
    __asm
    {
      vmulps  ymm0, ymm0, ymm1
      vaddps  ymm0, ymm2, ymm0
      vmovups ymmword ptr [out+rcx*4], ymm0
    }
  }
  while ( v52 != len );
  __asm { vzeroupper }
}


// Address: 0x221a720 | Name: FMOD_DSP_Connection_MixStereoToStereo_AVX
// positive sp value has been detected, the output may be wrong!
void __fastcall FMOD_DSP_Connection_MixStereoToStereo_AVX(
        float *in,
        float *out,
        unsigned int len,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  __int64 v11; // rax
  int v12; // ecx
  unsigned int v18; // r9d
  unsigned int v32; // r8d
  int v33; // ecx
  _UNKNOWN *retaddr; // [rsp+Ch] [rbp+8h]

  __asm
  {
    vbroadcastss ymm1, dword ptr [mixmatrix]
    vbroadcastss ymm0, dword ptr [mixmatrix+84h]
  }
  __asm { vunpcklps ymm0, ymm1, ymm0 }
  if ( writedontmix )
  {
    if ( (int)len <= 3 )
    {
      _RAX = 0;
      v33 = 0;
    }
    else
    {
      _RAX = 0;
      do
      {
        __asm
        {
          vmovups ymm1, ymmword ptr [in+rax]
          vmulps  ymm1, ymm1, ymm0
          vmovups ymmword ptr [out+rax], ymm1
        }
        _RAX += 32;
      }
      while ( _RAX != 32 * (((len - 4) >> 2) + 1LL) );
      v32 = ((len - 4) >> 2) + 1;
      v33 = 4 * v32;
      _RAX = 4LL * (int)(8 * v32);
    }
    *((_DWORD *)&retaddr - 5) = len - v33;
    __asm
    {
      vbroadcastss xmm1, [rsp-10h+var_4]
      vpcmpgtd xmm2, xmm1, cs:xmmword_596700
      vpcmpgtd xmm1, xmm1, cs:xmmword_5966F0
      vmovdqa xmm2, xmm2
      vinsertf128 ymm1, ymm2, xmm1, 1
      vmaskmovps ymm2, ymm1, ymmword ptr [in+rax]
      vmulps  ymm0, ymm2, ymm0
      vmaskmovps ymmword ptr [out+rax], ymm1, ymm0
      vzeroupper
    }
  }
  else
  {
    v11 = 0;
    v12 = 0;
    if ( (int)len > 3 )
    {
      _RAX = 0;
      do
      {
        __asm { vmovups ymm1, ymmword ptr [in+rax] }
        _RCX = &out[_RAX];
        _RAX += 8;
        __asm
        {
          vmulps  ymm1, ymm1, ymm0
          vmovups ymm2, ymmword ptr [rcx]
          vaddps  ymm1, ymm2, ymm1
          vmovups ymmword ptr [rcx], ymm1
        }
      }
      while ( _RAX != 8 * (((len - 4) >> 2) + 1LL) );
      v18 = ((len - 4) >> 2) + 1;
      v12 = 4 * v18;
      v11 = (int)(8 * v18);
    }
    _RSI = &out[v11];
    *((_DWORD *)&retaddr - 5) = len - v12;
    __asm
    {
      vbroadcastss xmm1, [rsp-10h+var_4]
      vpcmpgtd xmm2, xmm1, cs:xmmword_596700
      vpcmpgtd xmm1, xmm1, cs:xmmword_5966F0
      vmovdqa xmm2, xmm2
      vinsertf128 ymm1, ymm2, xmm1, 1
      vmaskmovps ymm3, ymm1, ymmword ptr [in+rax]
      vmaskmovps ymm2, ymm1, ymmword ptr [rsi]
      vmulps  ymm0, ymm3, ymm0
      vaddps  ymm0, ymm2, ymm0
      vmaskmovps ymmword ptr [rsi], ymm1, ymm0
      vzeroupper
    }
  }
}


// Address: 0x221a880 | Name: FMOD_DSP_Connection_MixMonoToMono_AVX
// positive sp value has been detected, the output may be wrong!
void __fastcall FMOD_DSP_Connection_MixMonoToMono_AVX(
        float *in,
        float *out,
        unsigned int len,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  __int64 v9; // rax
  signed int v10; // ecx
  signed int v29; // ecx
  _UNKNOWN *retaddr; // [rsp+Ch] [rbp+8h]

  __asm { vbroadcastss ymm0, dword ptr [mixmatrix] }
  if ( writedontmix )
  {
    if ( (int)len <= 7 )
    {
      _RAX = 0;
      v29 = 0;
    }
    else
    {
      _RAX = 0;
      do
      {
        __asm
        {
          vmovups ymm1, ymmword ptr [in+rax]
          vmulps  ymm1, ymm1, ymm0
          vmovups ymmword ptr [out+rax], ymm1
        }
        _RAX += 32;
      }
      while ( _RAX != 32 * (((len - 8) >> 3) + 1LL) );
      v29 = 8 * ((len - 8) >> 3) + 8;
      _RAX = 4LL * v29;
    }
    *((_DWORD *)&retaddr - 5) = len - v29;
    __asm
    {
      vbroadcastss xmm1, [rsp-10h+var_4]
      vpcmpgtd xmm2, xmm1, cs:xmmword_5966E0
      vpcmpgtd xmm1, xmm1, cs:xmmword_5966D0
      vmovdqa xmm2, xmm2
      vinsertf128 ymm1, ymm2, xmm1, 1
      vmaskmovps ymm2, ymm1, ymmword ptr [in+rax]
      vmulps  ymm0, ymm2, ymm0
      vmaskmovps ymmword ptr [out+rax], ymm1, ymm0
      vzeroupper
    }
  }
  else
  {
    v9 = 0;
    v10 = 0;
    if ( (int)len > 7 )
    {
      _RAX = 0;
      do
      {
        __asm { vmovups ymm1, ymmword ptr [in+rax] }
        _RCX = &out[_RAX];
        _RAX += 8;
        __asm
        {
          vmulps  ymm1, ymm1, ymm0
          vmovups ymm2, ymmword ptr [rcx]
          vaddps  ymm1, ymm2, ymm1
          vmovups ymmword ptr [rcx], ymm1
        }
      }
      while ( _RAX != 8 * (((len - 8) >> 3) + 1LL) );
      v10 = 8 * ((len - 8) >> 3) + 8;
      v9 = v10;
    }
    _RSI = &out[v9];
    *((_DWORD *)&retaddr - 5) = len - v10;
    __asm
    {
      vbroadcastss xmm1, [rsp-10h+var_4]
      vpcmpgtd xmm2, xmm1, cs:xmmword_5966E0
      vpcmpgtd xmm1, xmm1, cs:xmmword_5966D0
      vmovdqa xmm2, xmm2
      vinsertf128 ymm1, ymm2, xmm1, 1
      vmaskmovps ymm3, ymm1, ymmword ptr [in+rax]
      vmaskmovps ymm2, ymm1, ymmword ptr [rsi]
      vmulps  ymm0, ymm3, ymm0
      vaddps  ymm0, ymm2, ymm0
      vmaskmovps ymmword ptr [rsi], ymm1, ymm0
      vzeroupper
    }
  }
}


// Address: 0x221a9d0 | Name: FMOD_DSP_Connection_CopyMixMatrix_AVX
// positive sp value has been detected, the output may be wrong!
void __fastcall FMOD_DSP_Connection_CopyMixMatrix_AVX(
        FMOD::DSPMatrix *const srcMatrix,
        int outchannels,
        int inchannels,
        float (*dstMemory)[32])
{
  __int64 mOutChannels; // r11
  float *mData; // r8
  int v11; // esi
  float *v14; // rdx
  __int64 v22; // r11
  _UNKNOWN *retaddr; // [rsp+Ch] [rbp+8h]

  mOutChannels = srcMatrix->mOutChannels;
  mData = srcMatrix->mData;
  v11 = (__int16)mOutChannels;
  if ( srcMatrix->mInChannels <= inchannels )
    inchannels = srcMatrix->mInChannels;
  *((_DWORD *)&retaddr - 5) = inchannels;
  __asm { vbroadcastss xmm0, [rsp-10h+var_4] }
  if ( (__int16)mOutChannels <= 0 )
  {
    v11 = 0;
LABEL_7:
    __asm { vxorps  xmm0, xmm0, xmm0 }
    _RAX = &(*dstMemory)[32 * (__int64)v11 + 8];
    do
    {
      ++v11;
      __asm { vmovups ymmword ptr [rax-20h], ymm0 }
      _RAX += 32;
      __asm
      {
        vmovups ymmword ptr [rax-80h], ymm0
        vmovups ymmword ptr [rax-60h], ymm0
        vmovups ymmword ptr [rax-40h], ymm0
      }
    }
    while ( v11 <= 31 );
    goto LABEL_9;
  }
  __asm { vpcmpgtd xmm4, xmm0, cs:xmmword_5966C0 }
  v14 = mData;
  __asm { vpcmpgtd xmm1, xmm0, cs:xmmword_5966B0 }
  _R10 = &(*dstMemory)[8];
  _R9 = &(*dstMemory)[16];
  __asm
  {
    vpcmpgtd xmm3, xmm0, cs:xmmword_5966A0
    vmovdqa xmm4, xmm4
  }
  __asm { vpcmpgtd xmm5, xmm0, cs:xmmword_596680 }
  _R8 = &(*dstMemory)[24];
  v22 = 4 * mOutChannels;
  __asm
  {
    vinsertf128 ymm4, ymm4, xmm1, 1
    vmovdqa xmm3, xmm3
    vpcmpgtd xmm1, xmm0, cs:xmmword_596690
  }
  _RAX = 0;
  __asm
  {
    vmovdqa xmm2, xmm1
    vinsertf128 ymm3, ymm3, xmm1, 1
    vpcmpgtd xmm1, xmm0, cs:xmmword_596670
    vpcmpgtd xmm0, xmm0, cs:xmmword_596660
    vinsertf128 ymm2, ymm2, xmm5, 1
    vmovdqa xmm1, xmm1
    vinsertf128 ymm1, ymm1, xmm0, 1
  }
  do
  {
    __asm
    {
      vmaskmovps ymm0, ymm4, ymmword ptr [rdx]
      vmovups ymmword ptr [dstMemory+rax], ymm0
      vmaskmovps ymm0, ymm3, ymmword ptr [rdx+20h]
      vmovups ymmword ptr [r10+rax], ymm0
      vmaskmovps ymm0, ymm2, ymmword ptr [rdx+40h]
      vmovups ymmword ptr [r9+rax], ymm0
      vmaskmovps ymm0, ymm1, ymmword ptr [rdx+60h]
    }
    v14 = (float *)((char *)v14 + v22);
    __asm { vmovups ymmword ptr [r8+rax], ymm0 }
    _RAX += 128;
  }
  while ( _RAX != ((unsigned int)(v11 - 1) + 1LL) << 7 );
  if ( v11 <= 31 )
    goto LABEL_7;
LABEL_9:
  __asm { vzeroupper }
}


