// Address: 0x2251f20 | Name: _ZN4FMOD12DSPWaveTable19setPositionInternalE14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::setPositionInternal(FMOD::DSPWaveTable *const this, FMOD_UINT32_32 pcm)
{
  if ( this->mSound->mLength <= pcm.mHi )
    pcm.mHi = this->mSound->mLength;
  this->mPosition = pcm;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2251f50 | Name: _ZN4FMOD12DSPWaveTable19getPositionInternalEP14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::getPositionInternal(FMOD::DSPWaveTable *const this, FMOD_UINT32_32 *pcm)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( pcm )
  {
    pcm->mValue = (FMOD_UINT64)this->mPosition;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2251f70 | Name: _ZN4FMOD12DSPWaveTable12setFrequencyEf
__int64 __fastcall FMOD::DSPWaveTable::setFrequency(FMOD::DSPWaveTable *const this, float a2, float frequency)
{
  if ( a2 < 0.0 )
  {
    this->mDirection = DSPSOURCE_SPEEDDIR_BACKWARDS;
    this->mFrequency = -a2;
    return 0;
  }
  else
  {
    if ( this->mSound )
    {
      if ( (this->mChannel->mMode & 4) == 0 )
        this->mDirection = DSPSOURCE_SPEEDDIR_FORWARDS;
    }
    this->mFrequency = a2;
    return 0;
  }
}


// Address: 0x2251fd0 | Name: _ZN4FMOD12DSPWaveTable27getCodecContextInfoCallbackEP16FMOD_CODEC_STATEiPjS3_S3_Pv
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::getCodecContextInfoCallback(
        FMOD_CODEC_STATE *a1,
        int a2,
        unsigned int *contextSize,
        unsigned int *pcmFrameSize,
        FMOD_MEMORY_TYPE *a5,
        void *a6)
{
  if ( contextSize )
    *contextSize = 0;
  if ( pcmFrameSize )
    *pcmFrameSize = -1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2251ff0 | Name: _ZN4FMOD12DSPWaveTable11getFinishedEPb
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::getFinished(FMOD::DSPWaveTable *const this, bool *finished)
{
  if ( (this->mJob.mFlags & 0x400) != 0 )
    *finished = this->mFinishTick == 0;
  else
    *finished = *(_DWORD *)((char *)&stru_11610.r_offset + (unsigned __int64)this->mSystem) >= this->mFinishTick;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2252020 | Name: _ZN4FMOD12DSPWaveTable11setFinishedEbbb
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::setFinished(
        FMOD::DSPWaveTable *const this,
        bool finished,
        bool force,
        bool fromthread)
{
  FMOD::SystemI *mSystem; // rbp
  unsigned int v6; // eax

  if ( finished )
  {
    if ( force )
    {
      mSystem = this->mSystem;
      if ( fromthread || !mSystem )
      {
        this->mFinishTick = 0;
      }
      else
      {
        FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
        this->mFinishTick = 0;
        FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( this->mFinishTick - 1 <= 0xFFFFFFFD )
      return FMOD_RESULT::FMOD_OK_0;
    v6 = 0;
    if ( (this->mJob.mFlags & 0x400) == 0 )
      v6 = *(_DWORD *)((char *)&stru_11610.r_offset + (unsigned __int64)this->mSystem) + 1;
    this->mFinishTick = v6;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    this->mFinishTick = -1;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x22520d0 | Name: _ZN4FMOD12DSPWaveTable16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPWaveTable::getDescriptionEx()
{
  *(&stru_2B05980.mHandle + 1) = 1000;
  stru_2B05980.mDescription = &stru_286F8A0;
  stru_2B05980.mSize = 608;
  return &stru_2B05980;
}


// Address: 0x22520f0 | Name: _ZN4FMOD12DSPWaveTable19getCodecDescriptionEv
FMOD::FMOD_CODEC_DESCRIPTION_EX *__cdecl FMOD::DSPWaveTable::getCodecDescription()
{
  stru_2B058A0.getcontextinfo = FMOD::DSPWaveTable::getCodecContextInfoCallback;
  return &stru_2B058A0;
}


// Address: 0x2252110 | Name: _ZN4FMOD12DSPWaveTable14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::createInternal(FMOD::DSPWaveTable *const this)
{
  FMOD::SystemI *mSystem; // rax
  float mDSPSampleRate; // xmm0_4

  mSystem = this->mSystem;
  this->mFrequency = 0.0;
  mDSPSampleRate = (float)mSystem->mDSPSampleRate;
  LODWORD(mSystem) = mSystem->mAdvancedSettings.resamplerMethod;
  this->mTargetFrequency = mDSPSampleRate;
  this->mDirection = DSPSOURCE_SPEEDDIR_FORWARDS;
  this->mFinishTick = -1;
  this->mResampleMethod = (int)mSystem;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2252160 | Name: _ZN4FMOD12DSPWaveTable14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPWaveTable::createInternal((FMOD::DSPWaveTable *const)dsp_state->instance);
}


// Address: 0x2252170 | Name: _ZN4FMOD12DSPWaveTable15processInternalEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::processInternal(
        FMOD::DSPWaveTable *const this,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  FMOD::SoundI *v7; // rcx
  FMOD_RESULT_0 result; // eax
  int mNewLoopCount; // eax
  unsigned int mLoopCountIncrement; // edx
  float mTargetFrequency; // xmm3_4
  float v12; // xmm0_4
  float v13; // xmm1_4
  int v14; // r13d
  unsigned int i; // r14d
  unsigned __int64 v16; // rdx
  unsigned __int64 v17; // rdx
  unsigned __int64 v18; // rdi
  bool v19; // cf
  FMOD_UINT64 v20; // rdi
  unsigned __int64 v21; // rdx
  unsigned int v22; // r11d
  int v23; // r12d
  unsigned int v24; // r11d
  unsigned int v25; // r15d
  FMOD_DSP_RESAMPLER_0 mResampleMethod; // edx
  FMOD_UINT64 v27; // rdx
  FMOD::ChannelSoftware *mChannel; // r8
  FMOD::DSPSOURCE_SPEEDDIR mDirection; // edi
  FMOD_UINT64 mValue; // rsi
  FMOD_MODE mMode; // eax
  unsigned int mLength; // edx
  int mChannels; // ecx
  size_t v34; // rdx
  float *v35; // rdi
  __int64 v36; // rax
  __int64 v37; // rax
  int mLoopCount; // edi
  FMOD::ChannelSoftware *v39; // rcx
  unsigned int mHi; // eax
  unsigned int mLoopLength; // edx
  __int64 mLoopStart; // r8
  FMOD::ChannelSoftware *v43; // rdx
  unsigned int v44; // eax
  __int64 v45; // rax
  FMOD::SoundI *mSound; // rax
  __int64 v47; // rax
  FMOD_SPEAKERMODE_0 v48; // eax
  int (**vptr_DSPI)(...); // rax
  float *outbuffer; // [rsp+8h] [rbp-C0h]
  int (**readbuffer)(...); // [rsp+10h] [rbp-B8h]
  FMOD_SINT64P invspeed; // [rsp+30h] [rbp-98h]
  char mode; // [rsp+38h] [rbp-90h]
  unsigned int soundlength; // [rsp+3Ch] [rbp-8Ch]
  FMOD::SampleSoftware *samplesoftware; // [rsp+60h] [rbp-68h]
  FMOD_SINT64P speed; // [rsp+70h] [rbp-58h] BYREF
  FMOD_UINT64P pos; // [rsp+80h] [rbp-48h] BYREF

  if ( op == FMOD_DSP_PROCESS_QUERY )
  {
    if ( outbufferarray )
    {
      mSound = this->mSound;
      *outbufferarray->buffernumchannels = mSound->mChannels;
      v47 = (unsigned int)(mSound->mChannels - 1);
      if ( (unsigned int)v47 <= 0xB )
      {
        v48 = dword_597000[v47];
        if ( v48 != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
          outbufferarray->speakermode = v48;
      }
    }
    if ( this->mJob.mDelayClock.mStopNow && !length )
    {
      vptr_DSPI = this->_vptr_DSPI;
      this->mJob.mDelayClock.mStopNow = 0;
      vptr_DSPI[5](this, 1, 0, 1, inputsidle);
      return FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
    }
  }
  else
  {
    outbuffer = *outbufferarray->buffers;
    v7 = this->mSound;
    samplesoftware = (FMOD::SampleSoftware *)v7;
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( !v7 )
      return result;
    soundlength = v7->mLength;
    readbuffer = v7[1]._vptr_SoundI;
    if ( readbuffer )
    {
      mNewLoopCount = this->mNewLoopCount;
      if ( mNewLoopCount >= -1 )
      {
        mLoopCountIncrement = this->mLoopCountIncrement;
        if ( mLoopCountIncrement > this->mLoopCountIncrementPrev )
        {
          this->mLoopCount = mNewLoopCount;
          this->mNewLoopCount = -2;
          this->mLoopCountIncrementPrev = mLoopCountIncrement;
        }
      }
      mTargetFrequency = this->mTargetFrequency;
      invspeed.mValue = -1;
      v12 = (float)((float)(int)this->mJob.mDelayClock.mRealPitch * 0.00000095367432) * this->mFrequency;
      v13 = (float)(v12 / mTargetFrequency) * 4294967300.0;
      if ( (unsigned int)(int)v13 > 0x100uLL )
        invspeed.mValue = (unsigned int)(int)(float)((float)(mTargetFrequency / v12) * 4294967300.0);
      if ( length )
      {
        v14 = 0;
        for ( i = length; ; i = v25 )
        {
          mChannel = this->mChannel;
          mDirection = this->mDirection;
          mValue = this->mPosition.mValue;
          speed.mValue = (unsigned int)(int)v13;
          mMode = mChannel->mMode;
          pos.mValue = mValue;
          mode = mMode;
          if ( mDirection == DSPSOURCE_SPEEDDIR_BACKWARDS )
            speed.mValue = -(__int64)(unsigned int)(int)v13;
          if ( (unsigned int)(int)v13 > 0x100uLL )
          {
            LODWORD(v16) = 0;
            if ( mDirection == DSPSOURCE_SPEEDDIR_BACKWARDS )
            {
              LODWORD(v20) = pos.mHi;
              if ( (mMode & 6) != 0 )
              {
                if ( this->mLoopCount )
                {
                  mLoopStart = mChannel->mLoopStart;
                  if ( pos.mHi >= (unsigned int)mLoopStart )
                  {
                    LODWORD(v16) = mValue;
                    v20 = (mValue - (mLoopStart << 32)) >> 32;
                  }
                }
              }
              if ( soundlength < (unsigned int)v20 )
              {
                LODWORD(v16) = pos.mLo;
                LODWORD(v20) = pos.mHi;
              }
            }
            else
            {
              if ( (mMode & 6) != 0 && this->mLoopCount )
                v17 = (unsigned __int64)(mChannel->mLoopStart + mChannel->mLoopLength) << 32;
              else
                v17 = (unsigned __int64)v7->mLength << 32;
              v18 = v17 - mValue;
              v19 = mValue < v17;
              v16 = 0;
              if ( v19 )
                v16 = v18;
              LODWORD(v20) = soundlength - pos.mHi;
              if ( soundlength >= pos.mHi + HIDWORD(v16) )
                LODWORD(v20) = HIDWORD(v16);
            }
            v21 = (invspeed.mValue * (unsigned int)v20
                 + (unsigned int)v16 * (invspeed.mValue >> 32)
                 + 0xFFFFFFFFLL
                 + (((unsigned int)v16 * (unsigned __int64)invspeed.mLo) >> 32)) >> 32;
            if ( v21 > i )
            {
              v24 = 0;
              v23 = 0;
            }
            else
            {
              v22 = i;
              v23 = 2;
              i = v21;
              v24 = v22 - v21;
            }
            v25 = v24;
          }
          else
          {
            v25 = 0;
            v23 = 0;
          }
          mResampleMethod = this->mResampleMethod;
          if ( mResampleMethod == FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_LINEAR_0 )
            goto LABEL_34;
          if ( mResampleMethod <= FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_LINEAR_0 )
          {
            if ( mResampleMethod != FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_NOINTERP_0 )
              goto LABEL_34;
            FMOD_Resampler_NoInterp(
              &outbuffer[v7->mChannels * v14],
              i,
              readbuffer,
              v7->mFormat,
              &pos,
              &speed,
              v7->mChannels);
          }
          else
          {
            if ( mResampleMethod != FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_CUBIC_0 )
            {
              if ( mResampleMethod == FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_SPLINE_0 )
              {
                FMOD_Resampler_Spline(
                  &outbuffer[v7->mChannels * v14],
                  i,
                  readbuffer,
                  v7->mFormat,
                  &pos,
                  &speed,
                  v7->mChannels);
                goto LABEL_27;
              }
LABEL_34:
              FMOD_Resampler_Linear(
                &outbuffer[v7->mChannels * v14],
                i,
                readbuffer,
                v7->mFormat,
                &pos,
                &speed,
                v7->mChannels);
              goto LABEL_27;
            }
            FMOD_Resampler_Cubic(
              &outbuffer[v7->mChannels * v14],
              i,
              readbuffer,
              v7->mFormat,
              &pos,
              &speed,
              v7->mChannels);
          }
LABEL_27:
          v27 = pos.mValue;
          v14 += i;
          this->mPosition.mValue = pos.mValue;
          if ( v23 == 2 )
          {
            if ( (mode & 4) != 0 && this->mLoopCount )
            {
              if ( this->mDirection )
              {
                v45 = this->mChannel->mLoopStart;
                this->mDirection = DSPSOURCE_SPEEDDIR_FORWARDS;
                v37 = v45 << 33;
              }
              else
              {
                v36 = this->mChannel->mLoopStart + this->mChannel->mLoopLength;
                this->mDirection = DSPSOURCE_SPEEDDIR_BACKWARDS;
                v37 = v36 << 32;
                v27 -= v37;
              }
              this->mPosition.mValue = v37 - v27;
              if ( (this->mPosition.mHi & 0x80000000) != 0 )
                this->mPosition.mHi = 0;
            }
            else
            {
              if ( (mode & 2) == 0 || (mLoopCount = this->mLoopCount) == 0 )
              {
                mLength = samplesoftware->mLength;
                this->mPosition.mLo = 0;
                this->mPosition.mHi = mLength;
                mChannels = this->mSound->mChannels;
                v34 = 4LL * mChannels * v25;
                v35 = &outbuffer[mChannels * v14];
                goto LABEL_36;
              }
              if ( this->mDirection == DSPSOURCE_SPEEDDIR_BACKWARDS )
              {
                v43 = this->mChannel;
                v44 = this->mPosition.mHi + v43->mLoopLength;
                for ( this->mPosition.mHi = v44; v43->mLoopStart > v44; this->mPosition.mHi = v44 )
                  v44 += v43->mLoopLength;
              }
              else
              {
                v39 = this->mChannel;
                mHi = this->mPosition.mHi;
                mLoopLength = v39->mLoopLength;
                if ( mHi < mLoopLength )
                {
                  this->mPosition.mHi = 0;
                  mHi = 0;
                  goto LABEL_55;
                }
                do
                {
                  mHi -= mLoopLength;
                  this->mPosition.mHi = mHi;
LABEL_55:
                  mLoopLength = v39->mLoopLength;
                }
                while ( mLoopLength + v39->mLoopStart <= mHi );
              }
              if ( mLoopCount > 0 )
                this->mLoopCount = mLoopCount - 1;
            }
          }
          if ( !v25 )
            return FMOD_RESULT::FMOD_OK_0;
          v7 = this->mSound;
        }
      }
    }
    else
    {
      v35 = outbuffer;
      v34 = length * 4LL * v7->mChannels;
LABEL_36:
      memset(v35, 0, v34);
      (*((void (__fastcall **)(FMOD::DSPWaveTable *const, __int64, _QWORD, __int64))this->_vptr_DSPI + 5))(
        this,
        1,
        0,
        1);
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2252880 | Name: _ZN4FMOD12DSPWaveTable15processCallbackEP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS3_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::processCallback(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  return FMOD::DSPWaveTable::processInternal(
           (FMOD::DSPWaveTable *const)dsp_state->instance,
           length,
           inbufferarray,
           outbufferarray,
           inputsidle,
           op);
}


// Address: 0x2252890 | Name: _ZN4FMOD12DSPWaveTable13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::resetInternal(FMOD::DSPWaveTable *const this)
{
  this->mPosition.mValue = 0;
  this->mJob.mInfo.mMixLength = 0;
  this->mDirection = DSPSOURCE_SPEEDDIR_FORWARDS;
  this->mSound = 0;
  this->mChannel = 0;
  this->mFinishTick = -1;
  this->mJob.mInfo.mMixOffset = 0;
  this->mJob.mDelayClock.mDelayEndShadow = 0;
  this->mJob.mDelayClock.mDelayStartShadow = 0;
  this->mJob.mDelayClock.mDelayEnd = 0;
  this->mJob.mDelayClock.mDelayStart = 0;
  this->mJob.mDelayClock.mClockNext = 0;
  this->mJob.mDelayClock.mClock = 0;
  this->mJob.mDelayClock.mRealPitch = 0x100000;
  this->mJob.mDelayClock.mPitch = 0x100000;
  this->mJob.mDelayClock.mStopChannelsShadow = 0;
  this->mJob.mDelayClock.mStopChannels = 0;
  this->mJob.mDelayClock.mStopNow = 0;
  this->mJob.mDelayClock.mDelayParent = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2252930 | Name: _ZN4FMOD12DSPWaveTable13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPWaveTable::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPWaveTable::resetInternal((FMOD::DSPWaveTable *const)dsp_state->instance);
}


