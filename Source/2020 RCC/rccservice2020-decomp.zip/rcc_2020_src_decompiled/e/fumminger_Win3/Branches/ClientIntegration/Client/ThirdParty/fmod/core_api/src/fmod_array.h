// Address: 0x21c6b40 | Name: _ZN4FMOD12DynamicArrayINS_7HashMapIiPNS_9DSPReturnENS_19ArrayConstruct_AutoIS3_EENS_18HashMapDefaultHashEjE4NodeES5_NS_16AlignedAllocatorILi1EEEE10reallocateEi
FMOD_RESULT_0 __fastcall FMOD::DynamicArray<FMOD::HashMap<int,FMOD::DSPReturn *,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::AlignedAllocator<1>>::reallocate(
        FMOD::DynamicArray<FMOD::HashMap<int,FMOD::DSPReturn*>::Node,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::AlignedAllocator<1> > *const this,
        int newCapacity)
{
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v2; // r12
  int v5; // esi
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v6; // rax
  __int64 mSize; // rdx

  v2 = 0;
  if ( newCapacity )
  {
    v5 = 16 * newCapacity;
    if ( (unsigned int)(v5 - 1) > 0x3FFFFFFE )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v6 = (FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *)FMOD::MemPool::alloc(off_286F358->gSystemMemPool, v5, "../../../core_api/src/fmod_memory.h", 232, 0, 0);
    v2 = v6;
    if ( !v6 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    mSize = this->mSize;
    if ( (_DWORD)mSize )
      memcpy_0(v6, this->mData, 16 * mSize);
  }
  if ( this->mCapacity > 0 )
  {
    if ( this->mData )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, this->mData, "../../../core_api/src/fmod_memory.h", 244);
  }
  this->mCapacity = newCapacity;
  this->mData = v2;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cdfc0 | Name: _ZN4FMOD12DynamicArrayINS_7HashMapIiPNS_22ProfileFileEntryRemoteENS_19ArrayConstruct_AutoIS3_EENS_18HashMapDefaultHashEjE4NodeES5_NS_16AlignedAllocatorILi1EEEE10reallocateEi
FMOD_RESULT_0 __fastcall FMOD::DynamicArray<FMOD::HashMap<int,FMOD::ProfileFileEntryRemote *,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote *>,FMOD::AlignedAllocator<1>>::reallocate(
        FMOD::DynamicArray<FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*>::Node,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::AlignedAllocator<1> > *const this,
        int newCapacity)
{
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v2; // r12
  int v5; // esi
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v6; // rax
  __int64 mSize; // rdx

  v2 = 0;
  if ( newCapacity )
  {
    v5 = 16 * newCapacity;
    if ( (unsigned int)(v5 - 1) > 0x3FFFFFFE )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v6 = (FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *)FMOD::MemPool::alloc(off_286F358->gSystemMemPool, v5, "../../../core_api/src/fmod_memory.h", 232, 0, 0);
    v2 = v6;
    if ( !v6 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    mSize = this->mSize;
    if ( (_DWORD)mSize )
      memcpy_0(v6, this->mData, 16 * mSize);
  }
  if ( this->mCapacity > 0 )
  {
    if ( this->mData )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, this->mData, "../../../core_api/src/fmod_memory.h", 244);
  }
  this->mCapacity = newCapacity;
  this->mData = v2;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cf9a0 | Name: _ZN4FMOD12DynamicArrayIjNS_26ArrayConstruct_Fast_UninitENS_16AlignedAllocatorILi1EEEE6resizeEi
FMOD_RESULT_0 __fastcall FMOD::DynamicArray<unsigned int,FMOD::ArrayConstruct_Fast_Uninit,FMOD::AlignedAllocator<1>>::resize(
        FMOD::DynamicArray<unsigned int,FMOD::ArrayConstruct_Fast_Uninit,FMOD::AlignedAllocator<1> > *const this,
        int newSize)
{
  FMOD_RESULT_0 result; // eax
  void *v4; // r12
  __int64 mSize; // rax
  int v6; // esi

  if ( newSize <= (int)abs32(this->mCapacity) )
    goto LABEL_11;
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( newSize >= this->mSize )
  {
    v6 = 4 * newSize;
    if ( (unsigned int)(v6 - 1) > 0x3FFFFFFE )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v4 = FMOD::MemPool::alloc(off_286F358->gSystemMemPool, v6, "../../../core_api/src/fmod_memory.h", 232, 0, 0);
    if ( !v4 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    mSize = this->mSize;
    if ( (_DWORD)mSize )
      memcpy_0(v4, this->mData, 4 * mSize);
    if ( this->mCapacity > 0 )
    {
      if ( this->mData )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, this->mData, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mData = (unsigned int *)v4;
    this->mCapacity = newSize;
LABEL_11:
    this->mSize = newSize;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21d0080 | Name: _ZN4FMOD12DynamicArrayINS_7HashMapIiPNS_21ProfileFileEntryLocalENS_19ArrayConstruct_AutoIS3_EENS_18HashMapDefaultHashEjE4NodeES5_NS_16AlignedAllocatorILi1EEEE7reserveEi
FMOD_RESULT_0 __fastcall FMOD::DynamicArray<FMOD::HashMap<int,FMOD::ProfileFileEntryLocal *,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal *>,FMOD::AlignedAllocator<1>>::reserve(
        FMOD::DynamicArray<FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*>::Node,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::AlignedAllocator<1> > *const this,
        int newCapacity)
{
  FMOD_RESULT_0 result; // eax
  int v4; // esi
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v5; // r12
  int mSize; // eax

  result = FMOD_RESULT::FMOD_OK_0;
  if ( newCapacity > (int)abs32(this->mCapacity) )
  {
    LOBYTE(result) = 28;
    if ( newCapacity >= this->mSize )
    {
      v4 = 16 * newCapacity;
      if ( (unsigned int)(v4 - 1) <= 0x3FFFFFFE
        && (v5 = (FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *)FMOD::MemPool::alloc(off_286F358->gSystemMemPool, v4, "../../../core_api/src/fmod_memory.h", 232, 0, 0)) != 0 )
      {
        mSize = this->mSize;
        if ( mSize )
          memcpy_0(v5, this->mData, 16LL * mSize);
        if ( this->mCapacity > 0 )
        {
          if ( this->mData )
            FMOD::MemPool::free(off_286F358->gSystemMemPool, this->mData, "../../../core_api/src/fmod_memory.h", 244);
        }
        this->mCapacity = newCapacity;
        this->mData = v5;
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
    }
  }
  return result;
}


// Address: 0x220d660 | Name: _ZN4FMOD12DynamicArrayINS_7HashMapIiPNS_9DSPReturnENS_19ArrayConstruct_AutoIS3_EENS_18HashMapDefaultHashEjE4NodeES5_NS_16AlignedAllocatorILi1EEEE7reserveEi
FMOD_RESULT_0 __fastcall FMOD::DynamicArray<FMOD::HashMap<int,FMOD::DSPReturn *,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::AlignedAllocator<1>>::reserve(
        FMOD::DynamicArray<FMOD::HashMap<int,FMOD::DSPReturn*>::Node,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::AlignedAllocator<1> > *const this,
        int newCapacity)
{
  FMOD_RESULT_0 result; // eax
  int v4; // esi
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v5; // r12
  int mSize; // eax

  result = FMOD_RESULT::FMOD_OK_0;
  if ( newCapacity > (int)abs32(this->mCapacity) )
  {
    LOBYTE(result) = 28;
    if ( newCapacity >= this->mSize )
    {
      v4 = 16 * newCapacity;
      if ( (unsigned int)(v4 - 1) <= 0x3FFFFFFE
        && (v5 = (FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *)FMOD::MemPool::alloc(off_286F358->gSystemMemPool, v4, "../../../core_api/src/fmod_memory.h", 232, 0, 0)) != 0 )
      {
        mSize = this->mSize;
        if ( mSize )
          memcpy_0(v5, this->mData, 16LL * mSize);
        if ( this->mCapacity > 0 )
        {
          if ( this->mData )
            FMOD::MemPool::free(off_286F358->gSystemMemPool, this->mData, "../../../core_api/src/fmod_memory.h", 244);
        }
        this->mCapacity = newCapacity;
        this->mData = v5;
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
    }
  }
  return result;
}


