// Address: 0x222b900 | Name: _ZN4FMOD7DSPEcho16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPEcho::getDescriptionEx()
{
  memset(&stru_2B04940, 0, sizeof(stru_2B04940));
  FMOD_strcpy_safe(stru_2B04940.name, "Delay", 16);
  FMOD_strcpy_safe(stru_2B04940.label, "ms", 16);
  *(_QWORD *)&stru_2B04940.floatdesc.min = 0x459C400040A00000LL;
  stru_2B04940.description = "Echo delay in ms.  5 to 5000.  Default = 500.";
  memset(&stru_2B048E0, 0, sizeof(stru_2B048E0));
  stru_2B04940.intdesc.defaultval = 1140457472;
  stru_2B04940.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B048E0.name, "Feedback", 16);
  FMOD_strcpy_safe(stru_2B048E0.label, "%", 16);
  *(_QWORD *)&stru_2B048E0.floatdesc.min = 0x42C8000000000000LL;
  stru_2B048E0.description = "Echo decay per delay.  0 to 100.  100.0 = No decay, 0.0 = total decay.  Default = 50.0";
  memset(&stru_2B04880, 0, sizeof(stru_2B04880));
  stru_2B048E0.intdesc.defaultval = 1112014848;
  stru_2B048E0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B04880.name, "DryLevel", 16);
  FMOD_strcpy_safe(stru_2B04880.label, "dB", 16);
  *(_QWORD *)&stru_2B04880.floatdesc.min = 0x41200000C2A00000LL;
  stru_2B04880.description = "Volume of original signal to pass to output.  -80.0f to 10.0f. Default = 0.0.";
  memset(&stru_2B04820, 0, sizeof(stru_2B04820));
  stru_2B04880.intdesc.defaultval = 0;
  stru_2B04880.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B04820.name, "WetLevel", 16);
  FMOD_strcpy_safe(stru_2B04820.label, "dB", 16);
  *(_QWORD *)&stru_2B04820.floatdesc.min = 0x41200000C2A00000LL;
  stru_2B04820.intdesc.defaultval = 0;
  stru_2B04820.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B04820.description = "Volume of echo delay signal to pass to output.  -80.0f to 10.0f. Default = 0.0.";
  *(&stru_2B047E0.mHandle + 1) = 6;
  stru_2B047E0.mSize = 648;
  stru_2B047E0.mDescription = &stru_286EF80;
  stru_2B047E0.mCommand = FMOD::DSPEcho::commandCallback;
  stru_2B047E0.mCommandMask = 3;
  return &stru_2B047E0;
}


// Address: 0x222bb40 | Name: _ZN4FMOD18circularBufferCopyEPviiS0_iii
void __fastcall FMOD::circularBufferCopy(
        void *destinationBuffer,
        int destinationSize,
        int destinationOffset,
        void *sourceBuffer,
        int sourceSize,
        int sourceOffset,
        int copyLength)
{
  int v10; // r14d
  int v11; // eax
  int v12; // ecx
  int v13; // eax
  int v14; // ecx
  int v15; // r15d

  v10 = copyLength;
  if ( copyLength )
  {
    while ( 1 )
    {
      v11 = sourceOffset + v10;
      v12 = destinationOffset + v10;
      if ( sourceOffset + v10 > sourceSize )
        v11 = sourceSize;
      v13 = v11 - sourceOffset;
      if ( v12 > destinationSize )
        v12 = destinationSize;
      v14 = v12 - destinationOffset;
      if ( v14 <= v13 )
        v13 = v14;
      v15 = v13;
      memcpy_0((char *)destinationBuffer + destinationOffset, (char *)sourceBuffer + sourceOffset, v13);
      sourceOffset += v15;
      if ( sourceOffset >= 0 )
        goto LABEL_12;
      do
        sourceOffset += sourceSize;
      while ( sourceOffset < 0 );
      if ( sourceSize <= sourceOffset )
        break;
LABEL_13:
      destinationOffset += v15;
      if ( destinationOffset < 0 )
      {
        do
          destinationOffset += destinationSize;
        while ( destinationOffset < 0 );
        if ( destinationSize > destinationOffset )
          goto LABEL_18;
        goto LABEL_16;
      }
      while ( destinationSize <= destinationOffset )
LABEL_16:
        destinationOffset -= destinationSize;
LABEL_18:
      v10 -= v15;
      if ( !v10 )
        return;
    }
    while ( 1 )
    {
      sourceOffset -= sourceSize;
LABEL_12:
      if ( sourceSize > sourceOffset )
        goto LABEL_13;
    }
  }
}


// Address: 0x222bc00 | Name: _ZN4FMOD20circularBufferFadeInEPsiiii
void __fastcall FMOD::circularBufferFadeIn(
        __int16 *buffer,
        int channels,
        int bufferLengthInSamples,
        int sampleOffset,
        int fadeLengthInSamples)
{
  int v5; // ebp
  __int16 *v7; // r10
  float v8; // xmm4_4
  int v9; // edi
  int v10; // edi
  int v11; // r11d
  __int16 *v12; // rax
  int v13; // ecx
  float v14; // xmm0_4

  v5 = fadeLengthInSamples;
  v7 = &buffer[channels * sampleOffset];
  if ( fadeLengthInSamples )
  {
    v8 = 1.0 / (float)(fadeLengthInSamples + 1);
    while ( 1 )
    {
      v9 = sampleOffset + v5;
      if ( sampleOffset + v5 > bufferLengthInSamples )
        v9 = bufferLengthInSamples;
      v10 = v9 - sampleOffset;
      v11 = v10 - 1;
      if ( v10 )
      {
        do
        {
          if ( channels > 0 )
          {
            v12 = v7;
            do
            {
              LOWORD(v13) = 0x7FFF;
              v14 = (float)*v12 * (float)(v8 * 0.000030518509);
              if ( v14 <= 1.0 )
              {
                LOWORD(v13) = 0x8000;
                if ( v14 >= -1.0 )
                  v13 = (int)(float)(v14 * 32767.0);
              }
              *v12++ = v13;
            }
            while ( v12 != &v7[channels - 1 + 1] );
            v7 += (unsigned int)(channels - 1) + 1;
          }
          --v11;
          v8 = v8 + (float)(1.0 / (float)(fadeLengthInSamples + 1));
        }
        while ( v11 != -1 );
      }
      v5 -= v10;
      if ( !v5 )
        break;
      sampleOffset = 0;
      v7 = buffer;
    }
  }
}


// Address: 0x222bcf0 | Name: _ZN4FMOD7DSPEcho14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::createInternal(FMOD::DSPEcho *const this)
{
  double v1; // xmm1_8
  __int64 v2; // r12
  int v3; // ebx
  __int64 v4; // rax
  int v5; // edx
  FMOD_RESULT_0 result; // eax
  float v7; // xmm0_4
  float v8; // xmm1_4
  float v9; // xmm0_4
  float v10; // xmm1_4
  float v11; // xmm0_4
  float v12; // xmm1_4
  float v13; // xmm4_4
  float v14; // xmm0_4
  float v15; // xmm0_4
  float v16; // xmm0_4
  float v17; // [rsp+8h] [rbp-20h]

  v2 = 0;
  v3 = 0;
  v4 = *((_QWORD *)this + 30);
  *((_DWORD *)this + 153) = 1;
  *((_DWORD *)this + 115) = 1;
  *((_DWORD *)this + 144) = 0;
  *((_DWORD *)this + 145) = 0;
  *((_QWORD *)this + 70) = 0;
  v5 = *(_DWORD *)(v4 + 96);
  *((_QWORD *)this + 71) = 0;
  *((_DWORD *)this + 146) = 0;
  *((_DWORD *)this + 150) = 0;
  if ( v5 > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v3,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v4 + 104) + v2) + 56LL),
                 v1);
      if ( result )
        break;
      v4 = *((_QWORD *)this + 30);
      ++v3;
      v2 += 8;
      if ( *(_DWORD *)(v4 + 96) <= v3 )
        goto LABEL_6;
    }
  }
  else
  {
LABEL_6:
    *((_DWORD *)this + 132) = *((_DWORD *)this + 156);
    v7 = *((float *)this + 157);
    *((float *)this + 133) = v7;
    v8 = *((float *)this + 159);
    *((float *)this + 135) = v8;
    *((float *)this + 134) = v7 / 100.0;
    v9 = 0.0;
    if ( v8 > -80.0 )
      v9 = powf(10.0, v8 / 20.0);
    v10 = *((float *)this + 160);
    *((float *)this + 136) = v9;
    v11 = 0.0;
    *((float *)this + 137) = v10;
    if ( v10 > -80.0 )
      v11 = powf(10.0, v10 / 20.0);
    v12 = *((float *)this + 134);
    *((float *)this + 138) = v11;
    if ( v12 >= 1.0 )
    {
      v15 = -1.0;
    }
    else
    {
      v13 = *((float *)this + 137) + 100.0;
      if ( v12 > 0.0 )
      {
        v17 = *((float *)this + 137) + 100.0;
        v16 = log10f(v12);
        v13 = v17;
        v14 = v16 * 20.0;
      }
      else
      {
        v14 = -80.0;
      }
      v15 = (float)((float)(1.0 - (float)(v13 / v14)) * *((float *)this + 132)) / 1000.0;
    }
    *((float *)this + 155) = v15;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x222bf20 | Name: _ZN4FMOD7DSPEcho14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPEcho::createInternal((FMOD::DSPEcho *const)dsp_state->instance);
}


// Address: 0x222bf30 | Name: _ZN4FMOD7DSPEcho15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::releaseInternal(FMOD::DSPEcho *const this)
{
  void *v1; // rsi

  v1 = (void *)*((_QWORD *)this + 71);
  if ( v1 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_dsp_echo.cpp", 345);
    *((_QWORD *)this + 70) = 0;
    *((_QWORD *)this + 71) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222bf80 | Name: _ZN4FMOD7DSPEcho15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPEcho::releaseInternal((FMOD::DSPEcho *const)dsp_state->instance);
}


// Address: 0x222bf90 | Name: _ZN4FMOD7DSPEcho22shouldIProcessInternalEiji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::shouldIProcessInternal(
        FMOD::DSPEcho *const this,
        FMOD_BOOL inputsidle,
        unsigned int length,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  float v5; // xmm0_4
  unsigned int v6; // ecx
  FMOD_RESULT_0 result; // eax

  v5 = *((float *)this + 155);
  if ( v5 < 0.0 )
    return FMOD_RESULT::FMOD_OK_0;
  if ( inputsidle )
  {
    v6 = *((_DWORD *)this + 154);
    result = FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
    if ( !v6 )
      return result;
  }
  else
  {
    v6 = (int)(float)((float)*(int *)(*((_QWORD *)this + 22) + 1696LL) * v5);
    *((_DWORD *)this + 154) = v6;
  }
  if ( length < v6 )
    *((_DWORD *)this + 154) = v6 - length;
  else
    *((_DWORD *)this + 154) = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222c010 | Name: _ZN4FMOD7DSPEcho22shouldIProcessCallbackEP14FMOD_DSP_STATEijji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::shouldIProcessCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD_BOOL inputsidle,
        unsigned int length,
        FMOD_CHANNELMASK a4,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  return FMOD::DSPEcho::shouldIProcessInternal(
           (FMOD::DSPEcho *const)dsp_state->instance,
           inputsidle,
           length,
           inchannels,
           speakermode);
}


// Address: 0x222c020 | Name: _ZN4FMOD7DSPEcho14processAndRampEPPfS2_PvPjS4_jfffS4_iS4_S4_
__int64 __fastcall FMOD::DSPEcho::processAndRamp(
        FMOD::DSPEcho *const this,
        float **outbuffer_out,
        float **inbuffer_out,
        char *delaybuffermem,
        unsigned int *delayread_out,
        unsigned int *delaywrite_out,
        float wetmix,
        float drymix,
        float feedback,
        signed int delaybufferlen,
        unsigned int *length_out,
        int channels,
        unsigned int *rampsamplesleft,
        unsigned int *delayread_previous_out)
{
  int v14; // r12d
  int v15; // r13d
  int v16; // ebp
  float *v17; // r10
  float *v18; // r9
  int v19; // ebx
  __int64 v20; // r14
  __int64 v21; // r15
  __int64 v22; // r14
  signed int v23; // ecx
  unsigned int v24; // edx
  unsigned int v25; // ecx
  unsigned int v26; // edx
  unsigned int v27; // edx
  unsigned int v28; // edx
  char *v29; // rdi
  char *v30; // r8
  char *v31; // rsi
  __int64 v32; // rdx
  int v33; // ecx
  float v34; // xmm3_4
  float v35; // xmm6_4
  float v36; // xmm3_4
  unsigned int rampSamplesLeft; // [rsp+0h] [rbp-64h]
  unsigned int length; // [rsp+4h] [rbp-60h]
  unsigned int len; // [rsp+8h] [rbp-5Ch]

  v14 = *delaywrite_out;
  length = *length_out;
  v15 = *delayread_out;
  v16 = *delayread_previous_out;
  v17 = *inbuffer_out;
  v18 = *outbuffer_out;
  v19 = *rampsamplesleft;
  if ( *length_out && v19 )
  {
    v20 = (unsigned int)(channels - 1) + 1LL;
    v21 = 4 * v20;
    v22 = 2 * v20;
    while ( 1 )
    {
      v23 = length + v16;
      v24 = length + v15;
      if ( length + v16 > delaybufferlen )
        v23 = delaybufferlen;
      v25 = v23 - v16;
      if ( v24 > delaybufferlen )
        v24 = delaybufferlen;
      v26 = v24 - v15;
      if ( v25 > v26 )
        v25 = v26;
      v27 = length + v14;
      if ( v25 > v19 )
        v25 = v19;
      if ( v27 > delaybufferlen )
        v27 = delaybufferlen;
      v28 = v27 - v14;
      if ( v25 <= v28 )
        v28 = v25;
      len = v28;
      v29 = &delaybuffermem[2 * channels * v15];
      v30 = &delaybuffermem[2 * channels * v14];
      v31 = &delaybuffermem[2 * channels * v16];
      if ( v28 )
        break;
      rampSamplesLeft = v19;
LABEL_41:
      length -= len;
      v19 = rampSamplesLeft;
      if ( !rampSamplesLeft || !length )
        goto LABEL_43;
    }
    rampSamplesLeft = v19 - v28;
    while ( 1 )
    {
      if ( channels > 0 )
      {
        v32 = 0;
        do
        {
          LOWORD(v33) = 0x7FFF;
          v34 = (float)((float)((float)*(__int16 *)&v29[2 * v32] * (float)(1.0 - (float)((float)v19 * 0.00048828125)))
                      + (float)((float)*(__int16 *)&v31[2 * v32] * (float)((float)v19 * 0.00048828125)))
              * 0.000030518509;
          v35 = v34 * wetmix;
          v36 = (float)(v34 * feedback) + v17[v32];
          v18[v32] = (float)(v17[v32] * drymix) + v35;
          if ( v36 <= 1.0 )
          {
            LOWORD(v33) = 0x8000;
            if ( v36 >= -1.0 )
              v33 = (int)(float)(v36 * 32767.0);
          }
          *(_WORD *)&v30[2 * v32++] = v33;
        }
        while ( channels > (int)v32 );
        v17 = (float *)((char *)v17 + v21);
        v29 += v22;
        v31 += v22;
        v18 = (float *)((char *)v18 + v21);
        v30 += v22;
      }
      if ( ++v16 >= 0 )
        goto LABEL_29;
      do
        v16 += delaybufferlen;
      while ( v16 < 0 );
      if ( v16 >= delaybufferlen )
        break;
LABEL_30:
      if ( ++v15 >= 0 )
        goto LABEL_34;
      do
        v15 += delaybufferlen;
      while ( v15 < 0 );
      while ( v15 >= delaybufferlen )
      {
        v15 -= delaybufferlen;
LABEL_34:
        ;
      }
      if ( ++v14 < 0 )
      {
        do
          v14 += delaybufferlen;
        while ( v14 < 0 );
        if ( v14 < delaybufferlen )
          goto LABEL_40;
        goto LABEL_38;
      }
      while ( v14 >= delaybufferlen )
LABEL_38:
        v14 -= delaybufferlen;
LABEL_40:
      if ( --v19 == rampSamplesLeft )
        goto LABEL_41;
    }
    while ( 1 )
    {
      v16 -= delaybufferlen;
LABEL_29:
      if ( v16 < delaybufferlen )
        goto LABEL_30;
    }
  }
  rampSamplesLeft = *rampsamplesleft;
LABEL_43:
  *delayread_out = v15;
  *delaywrite_out = v14;
  *delayread_previous_out = v16;
  *rampsamplesleft = rampSamplesLeft;
  *inbuffer_out = v17;
  *outbuffer_out = v18;
  *length_out = length;
  return 0;
}


// Address: 0x222c2d0 | Name: _ZN4FMOD7DSPEcho23calculateDelayInSamplesEv
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::calculateDelayInSamples(FMOD::DSPEcho *const this)
{
  *((_DWORD *)this + 146) = ((int)(float)((float)((float)(*((float *)this + 132) / 1000.0)
                                                * (float)*(int *)(*((_QWORD *)this + 22) + 1696LL))
                                        + 0.5)
                           + 7)
                          & 0xFFFFFFF8;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222c310 | Name: _ZN4FMOD7DSPEcho13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::resetInternal(FMOD::DSPEcho *const this)
{
  int v1; // eax
  void *v3; // rdi

  v1 = *((_DWORD *)this + 146);
  if ( !v1 )
  {
    FMOD::DSPEcho::calculateDelayInSamples(this);
    v1 = *((_DWORD *)this + 146);
  }
  v3 = (void *)*((_QWORD *)this + 70);
  *((_DWORD *)this + 148) = 0;
  *((_DWORD *)this + 147) = v1;
  *((_DWORD *)this + 150) = 0;
  if ( v3 )
    memset(v3, 0, *((unsigned int *)this + 144));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222c370 | Name: _ZN4FMOD7DSPEcho13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPEcho::resetInternal((FMOD::DSPEcho *const)dsp_state->instance);
}


// Address: 0x222c380 | Name: _ZN4FMOD7DSPEcho16reallocateBufferEj
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::reallocateBuffer(FMOD::DSPEcho *const this, unsigned int minimumSampleCount)
{
  int v2; // ebp
  unsigned int v3; // eax
  void *v4; // rsi
  unsigned int v5; // ecx
  int v6; // ecx
  FMOD::Global *v7; // rax
  int v8; // ecx
  void *v9; // rax

  v2 = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  if ( minimumSampleCount )
  {
    *((_DWORD *)this + 146) = minimumSampleCount;
  }
  else
  {
    FMOD::DSPEcho::calculateDelayInSamples(this);
    minimumSampleCount = *((_DWORD *)this + 146);
  }
  v3 = minimumSampleCount + v2 / 2 + 127;
  v4 = (void *)*((_QWORD *)this + 71);
  v5 = (v3 / (v2 / 2) * (v2 / 2) + 7) & 0xFFFFFFF8;
  *((_DWORD *)this + 145) = v5;
  v6 = *((_DWORD *)this + 153) * v5;
  *((_DWORD *)this + 144) = v6;
  if ( v4 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v4, "../../../core_api/src/fmod_dsp_echo.cpp", 735);
    v6 = *((_DWORD *)this + 144);
  }
  v7 = off_286F358;
  v8 = 2 * v6;
  *((_DWORD *)this + 144) = v8;
  v9 = FMOD::MemPool::calloc(v7->gSystemMemPool, v8 + 16, "../../../core_api/src/fmod_dsp_echo.cpp", 744, 0);
  *((_QWORD *)this + 71) = v9;
  *((_QWORD *)this + 70) = ((unsigned __int64)v9 + 15) & 0xFFFFFFFFFFFFFFF0LL;
  if ( v9 )
  {
    *((_DWORD *)this + 115) = *((_DWORD *)this + 153);
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    *((_DWORD *)this + 145) = 0;
    *((_DWORD *)this + 144) = 0;
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
}


// Address: 0x222c490 | Name: _ZN4FMOD7DSPEcho12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::readInternal(
        FMOD::DSPEcho *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  bool v6; // zf
  unsigned int v7; // eax
  bool v8; // cc
  FMOD_RESULT_0 result; // eax
  unsigned int v10; // eax
  unsigned int lengtha; // [rsp+2Ch] [rbp-2Ch] BYREF
  float *outbuffera; // [rsp+30h] [rbp-28h] BYREF
  float *inbuffera; // [rsp+38h] [rbp-20h] BYREF
  unsigned int rampSamplesLeft[3]; // [rsp+4Ch] [rbp-Ch] BYREF

  v6 = *((_DWORD *)this + 153) == inchannels;
  v7 = *((_DWORD *)this + 150);
  inbuffera = inbuffer;
  outbuffera = outbuffer;
  lengtha = length;
  rampSamplesLeft[0] = v7;
  if ( !v6 )
  {
    v8 = inchannels <= *((_DWORD *)this + 115);
    *((_DWORD *)this + 153) = inchannels;
    if ( !v8 )
    {
      result = FMOD::DSPEcho::reallocateBuffer(this, *((_DWORD *)this + 146));
      if ( result )
        return result;
    }
    result = FMOD::DSPEcho::resetInternal(this);
    if ( result )
      return result;
    v7 = rampSamplesLeft[0];
  }
  if ( !v7 )
  {
    v10 = lengtha;
    if ( !lengtha )
    {
LABEL_7:
      *((_DWORD *)this + 150) = rampSamplesLeft[0];
      return FMOD_RESULT::FMOD_OK_0;
    }
LABEL_13:
    ((void (__fastcall *)(float *, float *, _QWORD, _QWORD, _QWORD, char *, float, float, float, char *, _DWORD, unsigned int, _DWORD))FMOD_Optimised_Routines.FMOD_DSPEcho_Process)(
      outbuffera,
      inbuffera,
      *((_QWORD *)this + 70),
      *((unsigned int *)this + 148),
      *((unsigned int *)this + 147),
      (char *)this + 592,
      *((float *)this + 138),
      *((float *)this + 136),
      *((float *)this + 134),
      (char *)this + 588,
      *((_DWORD *)this + 145),
      v10,
      *((_DWORD *)this + 153));
    *((_DWORD *)this + 150) = rampSamplesLeft[0];
    return FMOD_RESULT::FMOD_OK_0;
  }
  result = (unsigned int)FMOD::DSPEcho::processAndRamp(
                           this,
                           &outbuffera,
                           &inbuffera,
                           *((char **)this + 70),
                           (unsigned int *)this + 148,
                           (unsigned int *)this + 147,
                           *((float *)this + 138),
                           *((float *)this + 136),
                           *((float *)this + 134),
                           *((_DWORD *)this + 145),
                           &lengtha,
                           *((_DWORD *)this + 153),
                           rampSamplesLeft,
                           (unsigned int *)this + 149);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v10 = lengtha;
    if ( !lengtha )
      goto LABEL_7;
    goto LABEL_13;
  }
  return result;
}


// Address: 0x222c620 | Name: _ZN4FMOD7DSPEcho12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPEcho::readInternal(
           (FMOD::DSPEcho *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x222c630 | Name: _ZN4FMOD7DSPEcho15commandInternalEj
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::commandInternal(FMOD::DSPEcho *const this, FMOD::FMOD_DSP_COMMAND_TYPE type)
{
  FMOD_RESULT_0 result; // eax
  float v3; // xmm1_4
  int v4; // ebp
  int v5; // eax
  float v6; // xmm0_4
  float v7; // xmm1_4
  float v8; // xmm0_4
  float v9; // xmm1_4
  float v10; // xmm0_4
  float v11; // xmm0_4
  float v12; // xmm1_4
  float v13; // xmm0_4
  float v14; // xmm0_4
  unsigned int v15; // esi
  float v16; // xmm0_4
  float v17; // xmm3_4
  float v18; // xmm0_4
  float v19; // xmm2_4
  bool v20; // zf
  unsigned int v21; // esi
  signed int v22; // r12d
  int v23; // r14d
  int i; // eax
  __int16 *v25; // rax
  void *v26; // r13
  int copyLength; // r15d
  FMOD_RESULT_0 v28; // edx
  int v29; // r10d
  bool v30; // sf
  FMOD_RESULT_0 v31; // r14d
  int v32; // edx
  int v33; // r12d
  int v34; // eax
  float v35; // xmm0_4
  int v36; // eax
  FMOD_RESULT_0 v37; // eax
  __int16 *previousEchoBuffer; // [rsp+10h] [rbp-48h]
  int newWritePos; // [rsp+1Ch] [rbp-3Ch]

  if ( type == 2 )
  {
    v6 = *((float *)this + 157);
    if ( v6 != *((float *)this + 133) )
    {
      *((float *)this + 133) = v6;
      v11 = v6 / 100.0;
      *((float *)this + 134) = v11;
      if ( v11 >= 1.0 )
      {
        v14 = -1.0;
      }
      else
      {
        v12 = *((float *)this + 137) + 100.0;
        if ( v11 > 0.0 )
          v13 = log10f(v11) * 20.0;
        else
          v13 = -80.0;
        v14 = (float)(*((float *)this + 132) * (float)(1.0 - (float)(v12 / v13))) / 1000.0;
      }
      *((float *)this + 155) = v14;
    }
    v7 = *((float *)this + 159);
    if ( v7 != *((float *)this + 135) )
    {
      *((float *)this + 135) = v7;
      if ( v7 > -80.0 )
        v8 = powf(10.0, v7 / 20.0);
      else
        v8 = 0.0;
      *((float *)this + 136) = v8;
    }
    v9 = *((float *)this + 160);
    if ( v9 == *((float *)this + 137) )
      return FMOD_RESULT::FMOD_OK_0;
    *((float *)this + 137) = v9;
    if ( v9 > -80.0 )
      v10 = powf(10.0, v9 / 20.0);
    else
      v10 = 0.0;
    *((float *)this + 138) = v10;
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( type != 1 )
    return FMOD_RESULT::FMOD_OK_0;
  v3 = *((float *)this + 156);
  v4 = *((_DWORD *)this + 150);
  if ( v3 != *((float *)this + 132) && !v4 )
  {
    v16 = *((float *)this + 134);
    *((float *)this + 132) = v3;
    if ( v16 >= 1.0 )
    {
      v19 = -1.0;
    }
    else
    {
      v17 = *((float *)this + 137) + 100.0;
      if ( v16 > 0.0 )
      {
        v35 = log10f(v16);
        v3 = *((float *)this + 132);
        v18 = v35 * 20.0;
      }
      else
      {
        v18 = -80.0;
      }
      v19 = (float)((float)(1.0 - (float)(v17 / v18)) * v3) / 1000.0;
    }
    v5 = *((_DWORD *)this + 115);
    v20 = *((_DWORD *)this + 153) == v5;
    *((float *)this + 155) = v19;
    if ( !v20 )
      goto LABEL_24;
    FMOD::DSPEcho::calculateDelayInSamples(this);
    v21 = *((_DWORD *)this + 146);
    v22 = *((_DWORD *)this + 145);
    if ( v22 >= v21 + 128 )
    {
      v28 = *((_DWORD *)this + 148);
      v34 = *((_DWORD *)this + 147) - v21;
      for ( *((_DWORD *)this + 149) = v28; v34 < 0; v34 += v22 )
        ;
      while ( v22 <= v34 )
        v34 -= v22;
      *((_DWORD *)this + 148) = v34;
    }
    else
    {
      v23 = 0;
      if ( v22 )
      {
        for ( i = *((_DWORD *)this + 147) - *((_DWORD *)this + 148); i < 0; i += v22 )
          ;
        while ( v22 <= i )
          i -= v22;
        v23 = i;
      }
      v25 = (__int16 *)*((_QWORD *)this + 70);
      v26 = (void *)*((_QWORD *)this + 71);
      *((_QWORD *)this + 71) = 0;
      copyLength = *((_DWORD *)this + 144);
      previousEchoBuffer = v25;
      result = FMOD::DSPEcho::reallocateBuffer(this, v21);
      v28 = result;
      if ( result )
        return result;
      if ( v26 )
      {
        v29 = *((_DWORD *)this + 146);
        if ( v23 )
          v28 = *((_DWORD *)this + 146) - v23;
        v30 = v29 - v22 < 0;
        v31 = v28;
        v32 = *((_DWORD *)this + 145);
        v33 = v29 - v22;
        if ( v30 )
        {
          do
            v33 += v32;
          while ( v33 < 0 );
        }
        for ( ; v33 >= v32; v33 -= v32 )
          ;
        newWritePos = *((_DWORD *)this + 146);
        FMOD::circularBufferCopy(
          *((void **)this + 70),
          *((_DWORD *)this + 144),
          2 * v33 * *((_DWORD *)this + 153),
          previousEchoBuffer,
          copyLength,
          2 * *((_DWORD *)this + 153) * *((_DWORD *)this + 147),
          copyLength);
        FMOD::circularBufferFadeIn(*((__int16 **)this + 70), *((_DWORD *)this + 153), *((_DWORD *)this + 145), v33, 128);
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v26, "../../../core_api/src/fmod_dsp_echo.cpp", 844);
        *((_DWORD *)this + 148) = 0;
        v28 = v31;
        *((_DWORD *)this + 149) = v31;
        v34 = 0;
        *((_DWORD *)this + 147) = newWritePos;
      }
      else
      {
        v36 = *((_DWORD *)this + 146);
        *((_DWORD *)this + 148) = 0;
        *((_DWORD *)this + 147) = v36;
        v37 = v36 - v23;
        if ( v23 )
          v28 = v37;
        v34 = 0;
        *((_DWORD *)this + 149) = v28;
      }
    }
    if ( v34 != v28 )
      v4 = 2048;
  }
  v5 = *((_DWORD *)this + 115);
  if ( *((_DWORD *)this + 153) == v5 && *((_QWORD *)this + 70) )
    goto LABEL_9;
LABEL_24:
  v15 = *((_DWORD *)this + 146);
  *((_DWORD *)this + 153) = v5;
  result = FMOD::DSPEcho::reallocateBuffer(this, v15);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD::DSPEcho::resetInternal(this);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v4 = 0;
LABEL_9:
      *((_DWORD *)this + 150) = v4;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x222cb40 | Name: _ZN4FMOD7DSPEcho15commandCallbackEP14FMOD_DSP_STATEjPvS3_
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::commandCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *commanddata1,
        void *commanddata2)
{
  return FMOD::DSPEcho::commandInternal((FMOD::DSPEcho *const)dsp_state->instance, type);
}


// Address: 0x222cb50 | Name: _ZN4FMOD7DSPEcho25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPEcho::setParameterFloatInternal(FMOD::DSPI *this, int index, float a3, float value)
{
  FMOD_RESULT_0 v5; // ebx
  FMOD::DSPQueueCmd_UpdateParameters *v7; // rsi
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 v9; // eax
  FMOD::DSPQueueCmd_UpdateParameters *cmd; // [rsp+8h] [rbp-20h] BYREF

  if ( index == 1 )
  {
    *((float *)this + 157) = a3;
  }
  else if ( index <= 1 )
  {
    if ( index )
      return 31;
    *((float *)this + 156) = a3;
  }
  else
  {
    if ( index != 2 )
    {
      if ( index == 3 )
      {
        *((float *)this + 160) = a3;
        goto LABEL_6;
      }
      return 31;
    }
    *((float *)this + 159) = a3;
  }
LABEL_6:
  v5 = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 16, 1);
  if ( v5 )
    return (unsigned int)v5;
  v7 = cmd;
  mSystem = this->mSystem;
  cmd->mThis = this;
  *(_BYTE *)&v7->FMOD::DSPQueueCmd = 7;
  v9 = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v7, 1);
  if ( v9 )
    return (unsigned int)v9;
  return (unsigned int)v5;
}


// Address: 0x222cc10 | Name: _ZN4FMOD7DSPEcho25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPEcho::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPEcho::setParameterFloatInternal((FMOD::DSPI *)dsp_state->instance, index, a3, value);
}


// Address: 0x222cc20 | Name: _ZN4FMOD7DSPEcho25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::getParameterFloatInternal(
        FMOD::DSPEcho *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v4; // xmm0_4

  if ( index == 1 )
  {
    *value = *((float *)this + 157);
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    v4 = *((float *)this + 157);
    goto LABEL_7;
  }
  if ( index > 1 )
  {
    if ( index == 2 )
    {
      *value = *((float *)this + 159);
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
      v4 = *((float *)this + 159);
    }
    else
    {
      if ( index != 3 )
        return FMOD_RESULT::FMOD_OK_0;
      *value = *((float *)this + 160);
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
      v4 = *((float *)this + 160);
    }
LABEL_7:
    sprintf(valuestr, "%.1f", v4);
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( index )
    return FMOD_RESULT::FMOD_OK_0;
  *value = *((float *)this + 156);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  sprintf(valuestr, "%.02f", *((float *)this + 156));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222ccf0 | Name: _ZN4FMOD7DSPEcho25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPEcho::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPEcho::getParameterFloatInternal((FMOD::DSPEcho *const)dsp_state->instance, index, value, valuestr);
}


