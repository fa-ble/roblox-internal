// Address: 0x225b9d0 | Name: _ZN4FMOD27FMOD_OggVorbis_ReadCallbackEPvmmS0_
size_t __fastcall FMOD::FMOD_OggVorbis_ReadCallback(void *ptr, size_t size, size_t nmemb, void *datasource)
{
  FMOD_RESULT_0 v4; // eax
  size_t v5; // rdx
  unsigned int rd[3]; // [rsp+Ch] [rbp-Ch] BYREF

  v4 = FMOD::File::read((FMOD::File *const)datasource, ptr, size, nmemb, rd);
  v5 = -1;
  if ( (v4 & 0xFFFFFFEF) == 0 )
    return rd[0];
  return v5;
}


// Address: 0x225ba10 | Name: _ZN4FMOD27FMOD_OggVorbis_SeekCallbackEPvxi
int __fastcall FMOD::FMOD_OggVorbis_SeekCallback(void *datasource, ogg_int64_t_1 offset, int whence)
{
  if ( (*((_DWORD *)datasource + 101) & 1) != 0 )
    return FMOD::File::seek((FMOD::File *const)datasource, offset, (char)whence);
  else
    return -1;
}


// Address: 0x225ba30 | Name: _ZN4FMOD27FMOD_OggVorbis_TellCallbackEPv
ogg_int32_t __fastcall FMOD::FMOD_OggVorbis_TellCallback(void *datasource)
{
  unsigned int pos[3]; // [rsp+Ch] [rbp-Ch] BYREF

  FMOD::File::tell((FMOD::File *const)datasource, pos);
  return pos[0];
}


// Address: 0x225ba50 | Name: FMOD_OggVorbis_Malloc
void *__fastcall FMOD_OggVorbis_Malloc(void *context, int size)
{
  void *result; // rax

  result = FMOD::MemPool::alloc(
             off_286F358->gSystemMemPool,
             size,
             "../../../core_api/src/fmod_codec_oggvorbis.cpp",
             21,
             0,
             0);
  if ( result )
  {
    if ( context )
      *((_DWORD *)context + 326) += size;
  }
  return result;
}


// Address: 0x225baa0 | Name: FMOD_OggVorbis_Calloc
void *__fastcall FMOD_OggVorbis_Calloc(void *context, int count, int size)
{
  int v3; // ebx
  void *result; // rax

  v3 = size * count;
  result = FMOD::MemPool::calloc(
             off_286F358->gSystemMemPool,
             size * count,
             "../../../core_api/src/fmod_codec_oggvorbis.cpp",
             34,
             0);
  if ( result )
  {
    if ( context )
      *((_DWORD *)context + 326) += v3;
  }
  return result;
}


// Address: 0x225baf0 | Name: FMOD_OggVorbis_ReAlloc
void *__fastcall FMOD_OggVorbis_ReAlloc(void *context, void *ptr, int size)
{
  void *result; // rax

  result = FMOD::MemPool::realloc(
             off_286F358->gSystemMemPool,
             ptr,
             size,
             "../../../core_api/src/fmod_codec_oggvorbis.cpp",
             60,
             0);
  if ( result )
  {
    if ( context )
      *((_DWORD *)context + 326) += size;
  }
  return result;
}


// Address: 0x225bb40 | Name: FMOD_OggVorbis_Free
void __fastcall FMOD_OggVorbis_Free(void *context, void *ptr)
{
  FMOD::MemPool::free(off_286F358->gSystemMemPool, ptr, "../../../core_api/src/fmod_codec_oggvorbis.cpp", 82);
}


// Address: 0x225bb70 | Name: _ZN4FMOD14CodecOggVorbis16getDescriptionExEv
FMOD::FMOD_CODEC_DESCRIPTION_EX *__cdecl FMOD::CodecOggVorbis::getDescriptionEx()
{
  stru_2B060C0.version = 65792;
  stru_2B060C0.timeunits = 2;
  stru_2B060C0.mType = FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_OGGVORBIS_0;
  stru_2B060C0.mSize = 1312;
  stru_2B060C0.name = "FMOD Ogg Vorbis Codec";
  stru_2B060C0.open = FMOD::CodecOggVorbis::openInternal;
  stru_2B060C0.close = FMOD::CodecOggVorbis::closeInternal;
  stru_2B060C0.read = FMOD::CodecOggVorbis::readInternal;
  stru_2B060C0.setposition = FMOD::CodecOggVorbis::setPositionInternal;
  return &stru_2B060C0;
}


// Address: 0x225bbf0 | Name: _ZN4FMOD14CodecOggVorbis13closeInternalEv
FMOD_RESULT_0 __fastcall FMOD::CodecOggVorbis::closeInternal(FMOD::CodecOggVorbis *const this)
{
  this->mVf.datasource = 0;
  FMOD_ov_clear(this, &this->mVf);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225bc20 | Name: j__ZN4FMOD14CodecOggVorbis13closeInternalEv
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecOggVorbis::closeInternal(FMOD_CODEC_STATE *codec)
{
  return _ZN4FMOD14CodecOggVorbis13closeInternalEv((FMOD::CodecOggVorbis *const)codec);
}


// Address: 0x225bc30 | Name: _ZN4FMOD14CodecOggVorbis12readInternalEPvjPj
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::CodecOggVorbis::readInternal(
        FMOD::CodecOggVorbis *const this,
        void *buffer,
        unsigned int samples_in,
        unsigned int *samples_out)
{
  char *v5; // rbx
  FMOD_CODEC_WAVEFORMAT *waveformat; // rax
  int channels; // ecx
  __int64 v8; // rax
  int v9; // eax
  vorbis_comment *v10; // rax
  vorbis_comment *v11; // r15
  __int64 v12; // r14
  int v13; // ebx
  const char *v14; // rcx
  char v15; // r8
  const char *v16; // r9
  const char *v17; // r12
  FMOD_CODEC_METADATA_CALLBACK metadata; // r13
  int v19; // eax
  FMOD_RESULT_0 result; // eax
  FMOD_CODEC_WAVEFORMAT *v21; // rdx
  unsigned int v22; // ecx
  char *v23; // r8
  __int16 v24; // si
  __int16 v25; // dx
  __int16 v26; // ax
  __int16 v27; // cx
  __int16 v28; // di
  char *v29; // r10
  __int16 v30; // r8
  __int16 v31; // dx
  __int16 v32; // ax
  __int16 v33; // si
  __int16 v34; // cx
  __int16 v35; // di
  __int16 v36; // r9
  unsigned __int64 v37; // rsi
  char *value; // [rsp+18h] [rbp-50h]
  unsigned int bytesread; // [rsp+2Ch] [rbp-3Ch]

  v5 = (char *)buffer;
  waveformat = this->waveformat;
  channels = waveformat->channels;
  switch ( waveformat->format )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      v8 = 8;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      v8 = 16;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      v8 = 24;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      v8 = 32;
LABEL_3:
      *(_QWORD *)&samples_in = (v8 * (unsigned __int64)samples_in) >> 3;
      break;
    default:
      break;
  }
  bytesread = FMOD_ov_read(this, &this->mVf, (char *)buffer, samples_in * channels, 0, 2, 1, 0);
  if ( (int)bytesread <= 0 )
  {
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( bytesread == -131 )
      return result;
    LOBYTE(result) = 38;
    if ( bytesread == -139 )
      return result;
    LOBYTE(result) = 16;
    if ( bytesread != -3 )
      return result;
    bytesread = 0;
  }
  v9 = this->waveformat->channels;
  if ( v9 == 6 )
  {
    v23 = (char *)buffer + bytesread;
    if ( buffer < v23 )
    {
      do
      {
        v24 = *((_WORD *)v5 + 1);
        v25 = *((_WORD *)v5 + 3);
        v5 += 12;
        v26 = *((_WORD *)v5 - 2);
        v27 = *((_WORD *)v5 - 1);
        v28 = *((_WORD *)v5 - 4);
        *((_WORD *)v5 - 2) = v25;
        *((_WORD *)v5 - 4) = v24;
        *((_WORD *)v5 - 3) = v27;
        *((_WORD *)v5 - 1) = v26;
        *((_WORD *)v5 - 5) = v28;
      }
      while ( v5 < v23 );
    }
  }
  else if ( v9 == 8 )
  {
    v29 = (char *)buffer + bytesread;
    if ( buffer < v29 )
    {
      do
      {
        v30 = *((_WORD *)v5 + 1);
        v31 = *((_WORD *)v5 + 3);
        v5 += 16;
        v32 = *((_WORD *)v5 - 4);
        v33 = *((_WORD *)v5 - 3);
        v34 = *((_WORD *)v5 - 2);
        v35 = *((_WORD *)v5 - 1);
        v36 = *((_WORD *)v5 - 6);
        *((_WORD *)v5 - 2) = v31;
        *((_WORD *)v5 - 6) = v30;
        *((_WORD *)v5 - 4) = v33;
        *((_WORD *)v5 - 1) = v32;
        *((_WORD *)v5 - 5) = v35;
        *((_WORD *)v5 - 3) = v34;
        *((_WORD *)v5 - 7) = v36;
      }
      while ( v5 < v29 );
    }
  }
  v10 = FMOD_ov_comment(&this->mVf, -1);
  v11 = v10;
  if ( v10 && v10->comments )
  {
    v12 = 0;
    v13 = 0;
    if ( v10->comments > 0 )
    {
      do
      {
        v14 = v11->user_comments[v12];
        v15 = *v14;
        v16 = v14;
        if ( *v14 && v15 != 61 )
        {
          do
            v15 = *++v16;
          while ( *v16 != 61 && v15 );
        }
        v17 = "NONAME";
        if ( v15 == 61 )
        {
          v17 = v11->user_comments[v12];
          *v16 = 0;
          v14 = v16 + 1;
        }
        metadata = this->metadata;
        value = (char *)v14;
        ++v13;
        ++v12;
        v19 = FMOD_strlen(v14);
        metadata(
          this,
          FMOD_TAGTYPE::FMOD_TAGTYPE_VORBISCOMMENT,
          (char *)v17,
          value,
          v19 + 1,
          FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING_UTF8,
          1);
      }
      while ( v11->comments > v13 );
    }
    FMOD_vorbis_comment_clear(this, v11);
  }
  result = FMOD_RESULT::FMOD_OK_0;
  if ( samples_out )
  {
    v21 = this->waveformat;
    v22 = v21->channels;
    if ( v22 )
    {
      switch ( v21->format )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
          v37 = 8;
          goto LABEL_37;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          v37 = 16;
          goto LABEL_37;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          v37 = 24;
          goto LABEL_37;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          v37 = 32;
LABEL_37:
          *samples_out = (unsigned int)(8 * (unsigned __int64)bytesread / v37) / v22;
          result = FMOD_RESULT::FMOD_OK_0;
          break;
        default:
          *samples_out = bytesread;
          result = FMOD_RESULT::FMOD_OK_0;
          break;
      }
    }
  }
  return result;
}


// Address: 0x225bf40 | Name: j__ZN4FMOD14CodecOggVorbis12readInternalEPvjPj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecOggVorbis::readInternal(
        FMOD_CODEC_STATE *codec,
        void *buffer,
        unsigned int samples_in,
        unsigned int *samples_out)
{
  return _ZN4FMOD14CodecOggVorbis12readInternalEPvjPj(
           (FMOD::CodecOggVorbis *const)codec,
           buffer,
           samples_in,
           samples_out);
}


// Address: 0x225bf50 | Name: _ZN4FMOD14CodecOggVorbis19setPositionInternalEijj
FMOD_RESULT_0 __fastcall FMOD::CodecOggVorbis::setPositionInternal(
        FMOD::CodecOggVorbis *const this,
        int subsound,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  int v5; // eax
  FMOD_RESULT_0 v6; // ecx

  v5 = FMOD_ov_pcm_seek(this, &this->mVf, position);
  v6 = FMOD_RESULT::FMOD_OK_0;
  if ( v5 < 0 )
  {
    LOBYTE(v6) = 38;
    if ( v5 != -139 )
    {
      LOBYTE(v6) = 14;
      if ( !position )
        return this->mVf.pcm_offset != 0 ? 0xE : 0;
    }
  }
  return v6;
}


// Address: 0x225bfa0 | Name: j__ZN4FMOD14CodecOggVorbis19setPositionInternalEijj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecOggVorbis::setPositionInternal(
        FMOD_CODEC_STATE *codec,
        int subsound,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  return _ZN4FMOD14CodecOggVorbis19setPositionInternalEijj(
           (FMOD::CodecOggVorbis *const)codec,
           subsound,
           position,
           postype);
}


// Address: 0x225bfb0 | Name: _ZN4FMOD14CodecOggVorbis18readVorbisCommentsEv
FMOD_RESULT_0 __fastcall FMOD::CodecOggVorbis::readVorbisComments(FMOD::CodecOggVorbis *const this)
{
  vorbis_comment *v1; // rax
  vorbis_comment *v2; // rbp
  __int64 v3; // rbx
  char *v4; // rsi
  char i; // dl
  FMOD_RESULT_0 result; // eax
  int v7; // eax

  v1 = FMOD_ov_comment(&this->mVf, -1);
  v2 = v1;
  if ( !v1 || v1->comments <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  v3 = 0;
  while ( 1 )
  {
    if ( v2->comment_lengths[v3] )
    {
      v4 = v2->user_comments[v3];
      for ( i = *v4; *v4 != 61; i = *++v4 )
      {
        if ( !i )
          break;
      }
      if ( i == 61 )
      {
        *v4 = 0;
        v7 = FMOD_strlen(v4 + 1);
        result = FMOD::Codec::metaData(
                   this,
                   FMOD_TAGTYPE::FMOD_TAGTYPE_VORBISCOMMENT,
                   v2->user_comments[v3],
                   v4 + 1,
                   v7 + 1,
                   FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING_UTF8,
                   0);
        if ( result )
          break;
      }
    }
    if ( v2->comments <= (int)++v3 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225c080 | Name: _ZN4FMOD14CodecOggVorbis12openInternalEjP22FMOD_CREATESOUNDEXINFO
FMOD_RESULT_0 __fastcall FMOD::CodecOggVorbis::openInternal(
        FMOD::CodecOggVorbis *const this,
        FMOD_MODE usermode,
        FMOD_CREATESOUNDEXINFO *userexinfo)
{
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 v5; // eax
  FMOD::WAVE_FORMATEXTENSIBLE *mSrcFormat; // rsi
  char v7; // r12
  unsigned int v8; // edx
  OggVorbis_File_0 *p_mVf; // rdi
  __int64 v10; // rcx
  void **v11; // rdi
  int v12; // eax
  int v13; // edx
  vorbis_info_0 *v14; // r13
  int channels; // edx
  unsigned int v16; // eax
  int rate; // edx
  FMOD_CODEC_WAVEFORMAT *waveformat; // rax
  int v19; // r12d
  ogg_int32_t v20; // eax
  FMOD_CODEC_WAVEFORMAT *v21; // rdx
  ogg_int32_t v22; // r13d
  int v23; // esi
  int v24; // eax
  char wave[12]; // [rsp+20h] [rbp-308h] BYREF
  unsigned int lengthbytes; // [rsp+2Ch] [rbp-2FCh] BYREF
  FMOD::WAVE_CHUNK chunk; // [rsp+30h] [rbp-2F8h] BYREF
  ov_callbacks_0 callbacks; // [rsp+40h] [rbp-2E8h]
  FMOD_CODEC_WAVEFORMAT tempwaveformat; // [rsp+60h] [rbp-2C8h] BYREF
  FMOD::CodecWav tempwav; // [rsp+A0h] [rbp-288h] BYREF

  this->mType = FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_OGGVORBIS_0;
  this->mDecoder = 0;
  this->mDecoderContext = 0;
  this->mDecoderContextMemory = 0;
  this->mPCMBufferMemory = 0;
  callbacks.read_func = FMOD::FMOD_OggVorbis_ReadCallback;
  this->mWaveFormatMemory = 0;
  this->mMetadata = 0;
  this->numsubsounds = 0;
  this->waveformat = 0;
  callbacks.seek_func = FMOD::FMOD_OggVorbis_SeekCallback;
  this->waveformatversion = 3;
  this->mSrcDataOffset = 0;
  lengthbytes = 0;
  callbacks.close_func = 0;
  callbacks.tell_func = FMOD::FMOD_OggVorbis_TellCallback;
  this->fileread = (FMOD_FILE_READ_CALLBACK)FMOD::Codec::defaultFileRead;
  this->fileseek = (FMOD_FILE_SEEK_CALLBACK)FMOD::Codec::defaultFileSeek;
  this->metadata = FMOD::Codec::defaultMetaData;
  memset(&tempwav, 0, sizeof(tempwav));
  memset(&tempwaveformat, 0, sizeof(tempwaveformat));
  tempwav.mFile = this->mFile;
  tempwav.waveformat = &tempwaveformat;
  tempwav.mSrcDataOffset = -1;
  result = FMOD::File::read(tempwav.mFile, &chunk, 1u, 8u, 0);
  if ( result )
    return result;
  if ( !FMOD_strncmp((const char *)&chunk, "RIFF", 4) )
  {
    result = FMOD::File::read(this->mFile, wave, 1u, 4u, 0);
    if ( result )
      return result;
    if ( !FMOD_strncmp(wave, "WAVE", 4) )
    {
      v5 = FMOD::CodecWav::parseChunk(&tempwav, chunk.size);
      mSrcFormat = tempwav.mSrcFormat;
      if ( v5 == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( !tempwav.mSrcFormat )
        {
LABEL_13:
          if ( tempwav.mSyncPoint && tempwav.mSyncPoint != this->mSyncPoint )
          {
            FMOD::MemPool::free(
              off_286F358->gSystemMemPool,
              tempwav.mSyncPoint,
              "../../../core_api/src/fmod_codec_oggvorbis.cpp",
              339);
            tempwav.mSyncPoint = 0;
          }
          goto LABEL_6;
        }
        if ( tempwav.mSrcDataOffset != -1 )
        {
LABEL_12:
          FMOD::MemPool::free(
            off_286F358->gSystemMemPool,
            mSrcFormat,
            "../../../core_api/src/fmod_codec_oggvorbis.cpp",
            334);
          tempwav.mSrcFormat = 0;
          goto LABEL_13;
        }
        if ( tempwav.mSrcFormat->Format.wFormatTag != 26448 )
        {
          FMOD::MemPool::free(
            off_286F358->gSystemMemPool,
            tempwav.mSrcFormat,
            "../../../core_api/src/fmod_codec_oggvorbis.cpp",
            320);
          tempwav.mSrcFormat = 0;
          if ( tempwav.mSyncPoint && tempwav.mSyncPoint != this->mSyncPoint )
          {
            FMOD::MemPool::free(
              off_286F358->gSystemMemPool,
              tempwav.mSyncPoint,
              "../../../core_api/src/fmod_codec_oggvorbis.cpp",
              325);
            return FMOD_RESULT::FMOD_ERR_FORMAT_0;
          }
          return FMOD_RESULT::FMOD_ERR_FORMAT_0;
        }
        waveformat = tempwav.waveformat;
        this->mSrcDataOffset = -1;
        lengthbytes = waveformat->lengthbytes;
        *(_QWORD *)this->mLoopPoints = *(_QWORD *)tempwav.mLoopPoints;
        this->mSyncPoint = tempwav.mSyncPoint;
        this->mNumSyncPoints = tempwav.mNumSyncPoints;
      }
      if ( !mSrcFormat )
        goto LABEL_13;
      goto LABEL_12;
    }
  }
LABEL_6:
  FMOD::File::seek(this->mFile, this->mSrcDataOffset, 0);
  result = FMOD::File::read(this->mFile, &tempwav, 1u, 4u, 0);
  if ( result )
    return result;
  if ( FMOD_strncmp((const char *)&tempwav, "OggS", 4) )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  if ( !FMOD::CodecOggVorbis::gInitialized )
  {
    FMOD_vorbis_window_init();
    FMOD::CodecOggVorbis::gInitialized = 1;
  }
  if ( lengthbytes )
  {
    v7 = 0;
  }
  else
  {
    v7 = 1;
    result = (*((unsigned int (__fastcall **)(FMOD::File *, unsigned int *))this->mFile->_vptr_File + 3))(
               this->mFile,
               &lengthbytes);
    if ( result )
      return result;
  }
  result = FMOD::File::seek(this->mFile, this->mSrcDataOffset, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v8 = 816;
    p_mVf = &this->mVf;
    if ( (((_BYTE)this - 96) & 1) != 0 )
    {
      LOBYTE(this->mVf.datasource) = 0;
      p_mVf = (OggVorbis_File_0 *)((char *)&this->mVf.datasource + 1);
      LOBYTE(v8) = 47;
    }
    if ( ((unsigned __int8)p_mVf & 2) != 0 )
    {
      p_mVf = (OggVorbis_File_0 *)((char *)p_mVf + 2);
      v8 -= 2;
      HIWORD(p_mVf[-1].callbacks.tell_func) = 0;
    }
    if ( ((unsigned __int8)p_mVf & 4) != 0 )
    {
      LODWORD(p_mVf->datasource) = 0;
      v8 -= 4;
      p_mVf = (OggVorbis_File_0 *)((char *)p_mVf + 4);
    }
    v10 = v8 >> 3;
    memset(p_mVf, 0, 8 * v10);
    v11 = &p_mVf->datasource + v10;
    if ( (v8 & 4) != 0 )
    {
      *(_DWORD *)v11 = 0;
      v11 = (void **)((char *)v11 + 4);
    }
    if ( (v8 & 2) != 0 )
    {
      v11 = (void **)((char *)v11 + 2);
      *((_WORD *)v11 - 1) = 0;
    }
    if ( (v8 & 1) != 0 )
      *(_BYTE *)v11 = 0;
    v12 = FMOD_ov_open_callbacks(this, this->mFile, &this->mVf, 0, 0, callbacks);
    v13 = v12;
    if ( v12 < 0 )
    {
      if ( v12 == -134 )
        return FMOD_RESULT::FMOD_ERR_FORMAT_0;
      result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
      if ( v13 != -139 )
        return FMOD_RESULT::FMOD_ERR_FORMAT_0;
    }
    else
    {
      v14 = FMOD_ov_info(&this->mVf, -1);
      result = FMOD::CodecOggVorbis::readVorbisComments(this);
      if ( result )
        return result;
      channels = v14->channels;
      this->mWaveFormat.format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
      this->waveformat = &this->mWaveFormat;
      v16 = lengthbytes;
      this->mWaveFormat.channels = channels;
      rate = v14->rate;
      this->mWaveFormat.lengthbytes = v16;
      this->mWaveFormat.frequency = rate;
      if ( v7 && v16 != -1 )
        this->mWaveFormat.lengthbytes = v16 - this->mSrcDataOffset;
      if ( (this->mFile->mFlags & 1) != 0 )
      {
        v19 = 0;
        v20 = FMOD_ov_streams(&this->mVf);
        v21 = this->waveformat;
        v22 = v20;
        v21->lengthpcm = 0;
        if ( v20 > 0 )
        {
          do
          {
            v23 = v19++;
            v24 = FMOD_ov_pcm_total(&this->mVf, v23);
            v21 = this->waveformat;
            v21->lengthpcm += v24;
          }
          while ( v19 != v22 );
        }
        if ( !v21->lengthpcm )
          return FMOD_RESULT::FMOD_ERR_FORMAT_0;
      }
      else
      {
        this->mWaveFormat.lengthpcm = -1;
      }
      if ( !this->mSrcDataOffset )
        this->mSrcDataOffset = FMOD_ov_raw_tell(&this->mVf);
      this->numsubsounds = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x225c680 | Name: j__ZN4FMOD14CodecOggVorbis12openInternalEjP22FMOD_CREATESOUNDEXINFO
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecOggVorbis::openInternal(
        FMOD_CODEC_STATE *codec,
        FMOD_MODE usermode,
        FMOD_CREATESOUNDEXINFO *userexinfo)
{
  return _ZN4FMOD14CodecOggVorbis12openInternalEjP22FMOD_CREATESOUNDEXINFO(
           (FMOD::CodecOggVorbis *const)codec,
           usermode,
           userexinfo);
}


