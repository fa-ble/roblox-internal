// Address: 0x21bfcb0 | Name: _ZN4FMOD14DSPConnectionI8validateEPNS_13DSPConnectionEPPS0_PNS_15SystemLockScopeE
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::validate(
        FMOD::DSPConnection *dspconnection,
        FMOD::DSPConnectionI **dspconnectioni,
        FMOD::SystemLockScope *lockScope)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v4; // rbx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dspconnectioni )
  {
    LOBYTE(result) = 30;
    if ( dspconnection )
    {
      LOBYTE(result) = 0;
      *dspconnectioni = (FMOD::DSPConnectionI *)dspconnection;
      if ( lockScope )
      {
        LOBYTE(result) = 28;
        v4 = *(FMOD::SystemI **)&dspconnection->gap0;
        if ( !lockScope->mSystem )
        {
          if ( v4 )
          {
            result = FMOD::SystemI::enterMainUpdateLock(v4);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
              lockScope->mSystem = v4;
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21bfd70 | Name: _ZN4FMOD14DSPConnectionI4initEPNS_7SystemIEf
__int64 __fastcall FMOD::DSPConnectionI::init(
        FMOD::DSPConnectionI *const this,
        FMOD::SystemI *system,
        float a3,
        float level)
{
  this->mInputNode.mNodePrev = &this->mInputNode;
  this->mInputNode.mNodeNext = &this->mInputNode;
  this->mSystem = system;
  this->mInputNode.mNodeData = 0;
  this->mOutputNode.mNodeData = 0;
  this->mOutputNode.mNodePrev = &this->mOutputNode;
  this->mOutputNode.mNodeNext = &this->mOutputNode;
  FMOD::DSPConnectionI::clearInputOutputNodes(this);
  this->mRampCount = 0;
  this->mNewRampCount = 0;
  this->mFadeTarget = 1.0;
  this->mFadeCount = 0;
  this->mFlags = 0;
  this->mFadeValue = 1.0;
  this->mUserData.mUserData = 0;
  this->mUserData.mShadowRampCount = 0;
  this->mOldVolume = a3;
  this->mVolume = a3;
  this->mUserData.mShadowVolume = a3;
  return 0;
}


// Address: 0x21bfe20 | Name: _ZN4FMOD14DSPConnectionI12freeFromPoolEv
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::freeFromPool(FMOD::DSPConnectionI *const this)
{
  FMOD::SystemI *mSystem; // rsi
  FMOD::DSPMatrix *p_mMixMatrixUser; // rdi

  this->mInputUnit = 0;
  mSystem = this->mSystem;
  this->mOutputUnit = 0;
  p_mMixMatrixUser = &this->mUserData.mMixMatrixUser;
  *(_DWORD *)(&p_mMixMatrixUser[-2].mOutChannels + 1) = 0;
  FMOD::DSPMatrix::reset(p_mMixMatrixUser, mSystem);
  FMOD::DSPMatrix::reset(&this->mMixMatrix, this->mSystem);
  FMOD::DSPMatrix::reset(&this->mMixMatrixCurrent, this->mSystem);
  FMOD::DSPConnectionI::clearInputOutputNodes(this);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21bfe70 | Name: _ZN4FMOD14DSPConnectionI8getInputEPPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::getInput(FMOD::DSPConnectionI *const this, FMOD::DSPI **input)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *mInputUnit; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( input )
  {
    mInputUnit = this->mInputUnit;
    if ( mInputUnit )
    {
      *input = mInputUnit;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      *input = 0;
      return FMOD_RESULT::FMOD_ERR_NOTREADY_0;
    }
  }
  return result;
}


// Address: 0x21bfea0 | Name: _ZN4FMOD14DSPConnectionI9getOutputEPPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::getOutput(FMOD::DSPConnectionI *const this, FMOD::DSPI **output)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *mOutputUnit; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( output )
  {
    mOutputUnit = this->mOutputUnit;
    if ( mOutputUnit )
    {
      *output = mOutputUnit;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      *output = 0;
      return FMOD_RESULT::FMOD_ERR_NOTREADY_0;
    }
  }
  return result;
}


// Address: 0x21bfed0 | Name: _ZN4FMOD14DSPConnectionI8setUnityEfb
__int64 __fastcall FMOD::DSPConnectionI::setUnity(
        FMOD::DSPConnectionI *const this,
        float a2,
        float volume,
        bool deferred)
{
  FMOD::SystemI *mSystem; // rsi
  FMOD::SystemI *v6; // rdi
  FMOD_RESULT_0 v7; // ebp
  FMOD::DSPQueueCmd_SetUnity *v8; // rsi
  FMOD::SystemI *v9; // rdi
  FMOD_RESULT_0 v10; // eax
  float *mData; // rsi
  float *v12; // rsi
  FMOD::DSPQueueCmd_SetUnity *cmd; // [rsp+18h] [rbp-20h] BYREF

  if ( !deferred )
  {
    mData = this->mMixMatrix.mData;
    if ( mData )
      FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, mData, (const char *)&uri_string, 0);
    v12 = this->mMixMatrixCurrent.mData;
    this->mMixMatrix.mData = 0;
    if ( v12 )
      FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, v12, (const char *)&uri_string, 0);
    this->mVolume = a2;
    this->mMixMatrixCurrent.mData = 0;
    this->mRampCount = 0;
    this->mOldVolume = a2;
    this->mNewRampCount = 0;
    return 0;
  }
  if ( !this->mUserData.mMixMatrixUser.mData && a2 == this->mUserData.mShadowVolume && !this->mUserData.mShadowRampCount )
    return 0;
  mSystem = this->mSystem;
  this->mUserData.mShadowVolume = a2;
  this->mUserData.mShadowRampCount = 0;
  this->mUserData.mUserData = 0;
  FMOD::DSPMatrix::reset(&this->mUserData.mMixMatrixUser, mSystem);
  v6 = this->mSystem;
  this->mUserData.mMixMatrixUser.mData = 0;
  v7 = FMOD::SystemI::lockDSPQueueCmd(v6, (void **)&cmd, 24, 1);
  if ( v7 == FMOD_RESULT::FMOD_OK_0 )
  {
    v8 = cmd;
    v9 = this->mSystem;
    cmd->mVolume = a2;
    *(_BYTE *)&v8->FMOD::DSPQueueCmd = 11;
    v8->mConnection = this;
    v10 = FMOD::SystemI::unlockDSPQueueCmd(v9, v8, 1);
    if ( v10 )
      return (unsigned int)v10;
  }
  return (unsigned int)v7;
}


// Address: 0x21c0040 | Name: _ZN4FMOD14DSPConnectionI18setCurrentToTargetEv
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::setCurrentToTarget(FMOD::DSPConnectionI *const this)
{
  float *mData; // rcx
  int v2; // edx
  float *v3; // rsi
  __int64 v4; // rax
  float mVolume; // xmm0_4

  mData = this->mMixMatrix.mData;
  if ( mData )
  {
    v2 = this->mMixMatrix.mOutChannels * this->mMixMatrix.mInChannels;
    if ( v2 > 0 )
    {
      v3 = this->mMixMatrixCurrent.mData;
      v4 = 0;
      do
      {
        v3[v4] = mData[v4] * this->mVolume;
        ++v4;
      }
      while ( v2 > (int)v4 );
    }
  }
  mVolume = this->mVolume;
  this->mRampCount = 0;
  this->mOldVolume = mVolume;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c0090 | Name: _ZN4FMOD14DSPConnectionI5resetEbb
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::reset(
        FMOD::DSPConnectionI *const this,
        bool hardreset,
        bool resetuserdata)
{
  float mVolume; // xmm0_4
  FMOD::SystemI *mSystem; // rsi
  FMOD::DSPMatrix *p_mMixMatrix; // rdi
  FMOD::SystemI *v9; // rsi

  if ( hardreset )
  {
    mSystem = this->mSystem;
    this->mVolume = 1.0;
    p_mMixMatrix = &this->mMixMatrix;
    HIDWORD(p_mMixMatrix[4].mData) = 0;
    FMOD::DSPMatrix::reset(p_mMixMatrix, mSystem);
    FMOD::DSPMatrix::reset(&this->mMixMatrixCurrent, this->mSystem);
    if ( resetuserdata )
    {
      v9 = this->mSystem;
      this->mUserData.mShadowRampCount = 0;
      this->mUserData.mShadowVolume = 1.0;
      this->mUserData.mUserData = 0;
      FMOD::DSPMatrix::reset(&this->mUserData.mMixMatrixUser, v9);
    }
  }
  mVolume = this->mVolume;
  this->mFlags = 0;
  this->mOldVolume = mVolume;
  this->mRampCount = 0;
  this->mNewRampCount = 0;
  this->mFadeCount = 0;
  this->mFadeValue = 1.0;
  this->mFadeTarget = 1.0;
  FMOD::DSPConnectionI::setCurrentToTarget(this);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c0150 | Name: _ZN4FMOD14DSPConnectionI16getDefaultMatrixEPA32_fbiif
// local variable allocation has failed, the output may be wrong!
__int64 __fastcall FMOD::DSPConnectionI::getDefaultMatrix(
        float (*mixmatrix)[32],
        bool directmapping,
        int outchannels,
        int inchannels,
        float value)
{
  float *v6; // r15
  int v7; // r13d
  int v8; // r12d
  int v9; // ebx
  float *v10; // rax
  float *v11; // rdx
  int v13; // edx
  int v14; // ebp
  int v15; // r14d
  float *v16; // rcx
  int v17; // r10d
  int v18; // r9d
  __int64 v19; // rdi
  int v20; // eax
  int v21; // edx
  int v22; // ecx
  int v23; // ecx
  __int64 v24; // rdx
  _BYTE FMOD_sqrt_oo_n[256]; // [rsp+10h] [rbp-138h] OVERLAPPED BYREF

  v6 = (float *)mixmatrix;
  v7 = inchannels;
  v8 = -1;
  *(_DWORD *)FMOD_sqrt_oo_n = 0;
  *(_DWORD *)&FMOD_sqrt_oo_n[4] = 1;
  *(_DWORD *)&FMOD_sqrt_oo_n[8] = 3;
  *(_DWORD *)&FMOD_sqrt_oo_n[12] = 7;
  *(_DWORD *)&FMOD_sqrt_oo_n[16] = 51;
  *(_DWORD *)&FMOD_sqrt_oo_n[20] = 55;
  *(_DWORD *)&FMOD_sqrt_oo_n[24] = 63;
  *(_DWORD *)&FMOD_sqrt_oo_n[28] = 247;
  *(_DWORD *)&FMOD_sqrt_oo_n[32] = 255;
  if ( outchannels <= 8 )
    v8 = *(_DWORD *)&FMOD_sqrt_oo_n[4 * outchannels];
  *(_DWORD *)FMOD_sqrt_oo_n = 0;
  *(_DWORD *)&FMOD_sqrt_oo_n[4] = 1;
  *(_DWORD *)&FMOD_sqrt_oo_n[8] = 3;
  *(_DWORD *)&FMOD_sqrt_oo_n[12] = 7;
  v9 = -1;
  *(_DWORD *)&FMOD_sqrt_oo_n[16] = 51;
  *(_DWORD *)&FMOD_sqrt_oo_n[20] = 55;
  *(_DWORD *)&FMOD_sqrt_oo_n[24] = 63;
  *(_DWORD *)&FMOD_sqrt_oo_n[28] = 247;
  *(_DWORD *)&FMOD_sqrt_oo_n[32] = 255;
  if ( inchannels <= 8 )
    v9 = *(_DWORD *)&FMOD_sqrt_oo_n[4 * inchannels];
  if ( inchannels == outchannels || directmapping )
  {
    if ( outchannels > 0 )
    {
      v10 = (float *)mixmatrix;
      v11 = &(*mixmatrix)[33 * (outchannels - 1) + 33];
      do
      {
        *v10 = value;
        v10 += 33;
      }
      while ( v10 != v11 );
    }
  }
  else if ( outchannels == 1 )
  {
    *(_DWORD *)FMOD_sqrt_oo_n = 1065353216;
    *(_DWORD *)&FMOD_sqrt_oo_n[4] = 1060439283;
    *(_DWORD *)&FMOD_sqrt_oo_n[8] = 1058262330;
    *(_DWORD *)&FMOD_sqrt_oo_n[12] = 1056964608;
    *(_DWORD *)&FMOD_sqrt_oo_n[16] = 1055193390;
    *(_DWORD *)&FMOD_sqrt_oo_n[20] = 1053885932;
    *(_DWORD *)&FMOD_sqrt_oo_n[24] = 1052869775;
    *(_DWORD *)&FMOD_sqrt_oo_n[28] = 1052050675;
    if ( inchannels > 0 )
    {
      v21 = 0;
      v22 = 0;
      do
        v21 -= ((((v9 & 0xFFFFFFF7) >> v22++) & 1) == 0) - 1;
      while ( v21 < v7 && v22 <= 7 );
      v23 = 0;
      v24 = v21 - 1;
      do
      {
        if ( (v9 & (1 << v23)) != 8 )
          *v6 = *(float *)&FMOD_sqrt_oo_n[4 * v24] * value;
        ++v23;
        ++v6;
      }
      while ( v23 <= 7 && v7 > v23 );
    }
  }
  else
  {
    if ( inchannels == 12 )
    {
      v13 = 8;
      v14 = 7;
      v7 = 8;
    }
    else
    {
      v13 = 2;
      v14 = 7;
      if ( inchannels > 8 )
        v14 = 1;
      else
        v13 = inchannels;
    }
    v15 = 8;
    if ( outchannels <= 8 )
      v15 = outchannels;
    memset(FMOD_sqrt_oo_n, 0, sizeof(FMOD_sqrt_oo_n));
    FMOD::FMOD_DefaultMatrix_Unpack((float *)FMOD_sqrt_oo_n, v15, v13);
    if ( v15 > 0 )
    {
      v16 = (float *)mixmatrix;
      v17 = 0;
      v18 = 0;
      do
      {
        while ( !_bittest(&v8, v17 + v18) )
          ++v18;
        if ( v7 > 0 )
        {
          v19 = 0;
          v20 = 0;
          do
          {
            while ( !_bittest(&v9, v20 + v19) )
              ++v20;
            v16[v19] = *(float *)&FMOD_sqrt_oo_n[32 * v17 + 32 * v18 + 4 * (v14 & (v20 + (int)v19))] * value;
            ++v19;
          }
          while ( v19 != (unsigned int)(v7 - 1) + 1LL );
        }
        ++v17;
        v16 += 32;
      }
      while ( v17 != v15 );
    }
  }
  return 0;
}


// Address: 0x21c0420 | Name: _ZN4FMOD14DSPConnectionI10mixAndRampEPfS1_biijffi
__int64 __fastcall FMOD::DSPConnectionI::mixAndRamp(
        FMOD::DSPConnectionI *const this,
        float *outbuffer,
        float *inbuffer,
        bool directmapping,
        int outchannels,
        int inchannels,
        float oldvolume,
        float volume,
        unsigned int length,
        int writedontmix)
{
  FMOD::DSPConnectionI *v11; // r13
  float *v13; // rbx
  signed int mRampCount; // r14d
  signed int mFadeCount; // eax
  float v17; // xmm6_4
  float *mData; // r10
  int mOutChannels; // edi
  int mInChannels; // r9d
  int v21; // eax
  int v22; // esi
  float *v23; // rcx
  int v24; // r11d
  int v25; // edx
  __int64 v26; // r8
  float *v27; // r14
  int v28; // r13d
  int v29; // ebx
  float *v30; // r10
  __int64 v31; // rax
  float *v32; // rsi
  float v33; // xmm0_4
  int v34; // ecx
  __int64 v35; // r14
  int v36; // r10d
  __int64 v37; // rax
  float *v38; // rdx
  int v39; // edi
  __int64 v40; // rax
  unsigned int v41; // r8d
  float *v42; // r9
  float *v43; // rsi
  unsigned int v44; // edi
  __int64 v45; // rdx
  float v46; // xmm2_4
  float *v47; // rcx
  float *v48; // r10
  float v49; // xmm3_4
  float v50; // xmm1_4
  unsigned __int64 v51; // rax
  float v52; // xmm0_4
  int v53; // r11d
  float *v54; // rdi
  int v55; // edx
  int v56; // r9d
  float *v57; // rsi
  __int64 v58; // rax
  float *v59; // rcx
  unsigned int v60; // eax
  float v62; // xmm3_4
  float *v63; // rcx
  _BYTE *v64; // r8
  float *v65; // r10
  float v66; // xmm9_4
  float v67; // xmm2_4
  unsigned __int64 v68; // rax
  float v69; // xmm1_4
  float v70; // xmm0_4
  float mFadeValue; // xmm3_4
  float *v72; // rcx
  _BYTE *v73; // r10
  float *v74; // r11
  float v75; // xmm9_4
  float v76; // xmm2_4
  unsigned __int64 v77; // rax
  float v78; // xmm1_4
  float v79; // xmm0_4
  _BYTE *v80; // r10
  float *v81; // rcx
  float *v82; // r11
  float v83; // xmm2_4
  unsigned __int64 v84; // rax
  float v85; // xmm1_4
  float v86; // xmm0_4
  float v87; // xmm2_4
  float *v88; // rcx
  float *v89; // r8
  float v90; // xmm3_4
  float v91; // xmm1_4
  unsigned __int64 v92; // rax
  float v93; // xmm0_4
  float *v94; // rcx
  float *v95; // r10
  float v96; // xmm1_4
  unsigned __int64 v97; // rax
  float v98; // xmm0_4
  float *v99; // rcx
  float *v100; // r8
  float v101; // xmm1_4
  unsigned __int64 v102; // rax
  float v103; // xmm0_4
  _BYTE *v104; // r8
  float *v105; // rcx
  float *v106; // r10
  float v107; // xmm2_4
  unsigned __int64 v108; // rax
  float v109; // xmm1_4
  float v110; // xmm0_4
  _BYTE *v111; // rcx
  float *v112; // rdx
  unsigned __int64 v113; // rax
  _DWORD *v114; // rax
  _BYTE *i; // rcx
  _DWORD *v116; // rdx
  FMOD::DSPConnectionI *v118; // [rsp+10h] [rbp-2068h]
  signed int v119; // [rsp+10h] [rbp-2068h]
  signed int value; // [rsp+20h] [rbp-2058h]
  float *v122; // [rsp+28h] [rbp-2050h]
  char v123; // [rsp+33h] [rbp-2045h]
  int v124; // [rsp+34h] [rbp-2044h]
  int v125; // [rsp+38h] [rbp-2040h]
  bool v126[8]; // [rsp+38h] [rbp-2040h]
  unsigned int v127; // [rsp+48h] [rbp-2030h]
  _BYTE s[128]; // [rsp+50h] [rbp-2028h] BYREF
  _BYTE v129[3968]; // [rsp+D0h] [rbp-1FA8h] BYREF
  float v130[32][32]; // [rsp+1050h] [rbp-1028h] BYREF

  v11 = this;
  v13 = inbuffer;
  mRampCount = this->mRampCount;
  memset(v130, 0, sizeof(v130));
  mFadeCount = this->mFadeCount;
  v127 = mFadeCount;
  if ( mFadeCount )
  {
    v123 = 1;
    v17 = (float)(this->mFadeTarget - this->mFadeValue) / (float)mFadeCount;
  }
  else
  {
    v17 = 0.0;
    v123 = 0;
  }
  mData = this->mMixMatrixCurrent.mData;
  v122 = mData;
  if ( mData )
  {
    mOutChannels = this->mMixMatrixCurrent.mOutChannels;
    mInChannels = v11->mMixMatrixCurrent.mInChannels;
    v21 = outchannels;
    v22 = inchannels;
    if ( mOutChannels <= outchannels )
      v21 = mOutChannels;
    if ( mInChannels <= inchannels )
      v22 = v11->mMixMatrixCurrent.mInChannels;
    v125 = v21;
    v124 = v22;
    if ( v21 > 0 )
    {
      v23 = v130[0];
      value = mRampCount;
      v118 = v11;
      v24 = 0;
      v25 = 0;
      v26 = (unsigned int)(v22 - 1) + 1LL;
      v27 = mData;
      v28 = v22;
      v29 = v21;
      do
      {
        if ( v28 > 0 )
        {
          v30 = &v27[v24];
          v31 = 0;
          do
          {
            v32 = &DSPMatrixError;
            if ( mOutChannels > v25 && mInChannels > (int)v31 )
              v32 = v30;
            ++v30;
            v23[v31++] = *v32;
          }
          while ( v31 != v26 );
        }
        ++v25;
        v23 += 32;
        v24 += mInChannels;
      }
      while ( v25 != v29 );
      mRampCount = value;
      v11 = v118;
      v13 = inbuffer;
    }
    if ( mRampCount )
    {
      v33 = 1.0 / (float)mRampCount;
      if ( outchannels > v125 || inchannels > v124 )
      {
        memset(s, 0, 128LL * outchannels);
        v33 = 1.0 / (float)mRampCount;
      }
      if ( v125 > 0 )
      {
        v119 = mRampCount;
        v34 = 0;
        v35 = 0;
        do
        {
          if ( v124 > 0 )
          {
            v36 = v11->mMixMatrix.mOutChannels;
            v37 = 0;
            do
            {
              v38 = &DSPMatrixError;
              if ( v36 > v34 )
              {
                v39 = v11->mMixMatrix.mInChannels;
                if ( v39 > (int)v37 )
                  v38 = &v11->mMixMatrix.mData[v34 * v39 + (int)v37];
              }
              *(float *)&s[4 * v37 + v35 * 128] = (float)((float)(*v38 * volume) - v130[v35][v37]) * v33;
              ++v37;
            }
            while ( v37 != (unsigned int)(v124 - 1) + 1LL );
          }
          ++v34;
          ++v35;
        }
        while ( v34 != v125 );
        mRampCount = v119;
      }
    }
  }
  else if ( oldvolume == volume || !mRampCount )
  {
    FMOD::DSPConnectionI::getDefaultMatrix(v130, directmapping, outchannels, inchannels, volume);
    if ( outchannels > 0 )
    {
      v114 = s;
      for ( i = v129; ; i += 128 )
      {
        if ( inchannels > 0 )
        {
          v116 = &v114[inchannels - 1 + 1];
          do
            *v114++ = 0;
          while ( v114 != v116 );
        }
        v114 = i;
        if ( i == &v129[128 * (unsigned __int64)(unsigned int)(outchannels - 1)] )
          break;
      }
    }
    v122 = this->mMixMatrixCurrent.mData;
  }
  else
  {
    FMOD::DSPConnectionI::getDefaultMatrix(v130, directmapping, outchannels, inchannels, 1.0);
    if ( outchannels > 0 )
    {
      v111 = s;
      v112 = v130[0];
      do
      {
        if ( inchannels > 0 )
        {
          v113 = 0;
          do
          {
            *(float *)&v111[v113] = (float)((float)(v112[v113 / 4] * volume) - (float)(v112[v113 / 4] * oldvolume))
                                  * (float)(1.0 / (float)mRampCount);
            v113 += 4LL;
          }
          while ( v113 != 4LL * (unsigned int)(inchannels - 1) + 4 );
        }
        v112 += 32;
        v111 += 128;
      }
      while ( v112 != v130[(unsigned __int64)(unsigned int)(outchannels - 1) + 1] );
    }
    FMOD::DSPConnectionI::getDefaultMatrix(v130, directmapping, outchannels, inchannels, oldvolume);
    v122 = this->mMixMatrixCurrent.mData;
  }
  if ( length )
  {
    v40 = (unsigned int)(outchannels - 1);
    v41 = v127;
    v42 = outbuffer;
    v43 = v130[v40 + 1];
    v44 = length;
    *(_QWORD *)v126 = 4 * v40 + 4;
    v45 = 4LL * (unsigned int)(inchannels - 1) + 4;
    while ( 1 )
    {
      if ( mRampCount )
      {
        if ( v41 )
        {
          mFadeValue = v11->mFadeValue;
          --v41;
          v11->mFadeValue = v17 + mFadeValue;
          if ( writedontmix )
          {
            if ( outchannels > 0 )
            {
              v80 = s;
              v81 = v130[0];
              v82 = v42;
              if ( inchannels > 0 )
              {
LABEL_85:
                v83 = 0.0;
                v84 = 0;
                do
                {
                  v85 = v81[v84 / 4];
                  v86 = (float)(v13[v84 / 4] * v85) * mFadeValue;
                  v81[v84 / 4] = v85 + *(float *)&v80[v84];
                  v84 += 4LL;
                  v83 = v83 + v86;
                }
                while ( v45 != v84 );
                goto LABEL_87;
              }
              while ( 1 )
              {
                v83 = 0.0;
LABEL_87:
                v81 += 32;
                ++v82;
                v80 += 128;
                *(v82 - 1) = v83;
                if ( v81 == v43 )
                  break;
                if ( inchannels > 0 )
                  goto LABEL_85;
              }
LABEL_81:
              v42 = (float *)((char *)v42 + *(_QWORD *)v126);
            }
          }
          else if ( outchannels > 0 )
          {
            v72 = v130[0];
            v73 = s;
            v74 = v42;
            do
            {
              v75 = *v74;
              if ( inchannels <= 0 )
              {
                v76 = 0.0;
              }
              else
              {
                v76 = 0.0;
                v77 = 0;
                do
                {
                  v78 = v72[v77 / 4];
                  v79 = (float)(v13[v77 / 4] * v78) * mFadeValue;
                  v72[v77 / 4] = v78 + *(float *)&v73[v77];
                  v77 += 4LL;
                  v76 = v76 + v79;
                }
                while ( v77 != v45 );
              }
              v72 += 32;
              ++v74;
              v73 += 128;
              *(v74 - 1) = v76 + v75;
            }
            while ( v72 != v43 );
            goto LABEL_81;
          }
          --mRampCount;
          goto LABEL_42;
        }
        v62 = v11->mFadeValue;
        if ( writedontmix )
        {
          if ( outchannels > 0 )
          {
            v104 = s;
            v105 = v130[0];
            v106 = v42;
            if ( inchannels > 0 )
            {
LABEL_114:
              v107 = 0.0;
              v108 = 0;
              do
              {
                v109 = v105[v108 / 4];
                v110 = (float)(v13[v108 / 4] * v109) * v62;
                v105[v108 / 4] = v109 + *(float *)&v104[v108];
                v108 += 4LL;
                v107 = v107 + v110;
              }
              while ( v45 != v108 );
              goto LABEL_116;
            }
            while ( 1 )
            {
              v107 = 0.0;
LABEL_116:
              v105 += 32;
              ++v106;
              v104 += 128;
              *(v106 - 1) = v107;
              if ( v105 == v43 )
                break;
              if ( inchannels > 0 )
                goto LABEL_114;
            }
LABEL_72:
            v42 = (float *)((char *)v42 + *(_QWORD *)v126);
          }
        }
        else if ( outchannels > 0 )
        {
          v63 = v130[0];
          v64 = s;
          v65 = v42;
          do
          {
            v66 = *v65;
            if ( inchannels <= 0 )
            {
              v67 = 0.0;
            }
            else
            {
              v67 = 0.0;
              v68 = 0;
              do
              {
                v69 = v63[v68 / 4];
                v70 = (float)(v13[v68 / 4] * v69) * v62;
                v63[v68 / 4] = v69 + *(float *)&v64[v68];
                v68 += 4LL;
                v67 = v67 + v70;
              }
              while ( v45 != v68 );
            }
            v63 += 32;
            ++v65;
            v64 += 128;
            *(v65 - 1) = v67 + v66;
          }
          while ( v63 != v43 );
          goto LABEL_72;
        }
        --mRampCount;
        v41 = 0;
        goto LABEL_42;
      }
      if ( v41 )
      {
        v46 = v11->mFadeValue;
        --v41;
        v11->mFadeValue = v17 + v46;
        if ( writedontmix )
        {
          if ( outchannels <= 0 )
            goto LABEL_42;
          v94 = v130[0];
          v95 = v42;
          if ( inchannels > 0 )
          {
LABEL_99:
            v96 = 0.0;
            v97 = 0;
            do
            {
              v98 = v13[v97 / 4] * v94[v97 / 4];
              v97 += 4LL;
              v96 = v96 + (float)(v98 * v46);
            }
            while ( v45 != v97 );
            goto LABEL_101;
          }
          while ( 1 )
          {
            v96 = 0.0;
LABEL_101:
            v94 += 32;
            *v95++ = v96;
            if ( v94 == v43 )
              goto LABEL_41;
            if ( inchannels > 0 )
              goto LABEL_99;
          }
        }
        v47 = v130[0];
        v48 = v42;
        if ( outchannels > 0 )
        {
          do
          {
            v49 = *v48;
            if ( inchannels <= 0 )
            {
              v50 = 0.0;
            }
            else
            {
              v50 = 0.0;
              v51 = 0;
              do
              {
                v52 = v13[v51 / 4] * v47[v51 / 4];
                v51 += 4LL;
                v50 = v50 + (float)(v52 * v46);
              }
              while ( v45 != v51 );
            }
            v47 += 32;
            *v48++ = v50 + v49;
          }
          while ( v47 != v43 );
LABEL_41:
          v42 = (float *)((char *)v42 + *(_QWORD *)v126);
        }
      }
      else
      {
        v87 = v11->mFadeValue;
        if ( writedontmix )
        {
          if ( outchannels <= 0 )
          {
LABEL_132:
            v41 = 0;
            mRampCount = 0;
            goto LABEL_42;
          }
          v99 = v130[0];
          v100 = v42;
          if ( inchannels > 0 )
          {
LABEL_107:
            v101 = 0.0;
            v102 = 0;
            do
            {
              v103 = v13[v102 / 4] * v99[v102 / 4];
              v102 += 4LL;
              v101 = v101 + (float)(v103 * v87);
            }
            while ( v45 != v102 );
            goto LABEL_109;
          }
          while ( 1 )
          {
            v101 = 0.0;
LABEL_109:
            v99 += 32;
            *v100++ = v101;
            if ( v99 == v43 )
              break;
            if ( inchannels > 0 )
              goto LABEL_107;
          }
        }
        else
        {
          v88 = v130[0];
          v89 = v42;
          if ( outchannels <= 0 )
            goto LABEL_132;
          do
          {
            v90 = *v89;
            if ( inchannels <= 0 )
            {
              v91 = 0.0;
            }
            else
            {
              v91 = 0.0;
              v92 = 0;
              do
              {
                v93 = v13[v92 / 4] * v88[v92 / 4];
                v92 += 4LL;
                v91 = v91 + (float)(v93 * v87);
              }
              while ( v45 != v92 );
            }
            v88 += 32;
            *v89++ = v91 + v90;
          }
          while ( v88 != v43 );
        }
        v42 = (float *)((char *)v42 + *(_QWORD *)v126);
        v41 = 0;
        mRampCount = 0;
      }
LABEL_42:
      v13 += inchannels;
      if ( !--v44 )
      {
        v127 = v41;
        break;
      }
    }
  }
  v11->mRampCount = mRampCount;
  v11->mFadeCount = v127;
  if ( !v122 )
    goto LABEL_59;
  if ( outchannels > 0 )
  {
    v53 = v11->mMixMatrixCurrent.mOutChannels;
    if ( v11->mMixMatrixCurrent.mOutChannels > 0 )
    {
      v54 = v130[0];
      v55 = 0;
      do
      {
        if ( inchannels > 0 )
        {
          v56 = v11->mMixMatrixCurrent.mInChannels;
          if ( v11->mMixMatrixCurrent.mInChannels > 0 )
          {
            v57 = &v122[v56 * v55];
            v58 = 0;
            do
            {
              v59 = &DSPMatrixError;
              if ( v53 > v55 && v56 > (int)v58 )
                v59 = v57;
              *v59 = v54[v58];
              if ( v58 == inchannels - 1 )
                break;
              ++v58;
              ++v57;
            }
            while ( v58 != (unsigned int)(v56 - 1) + 1LL );
          }
        }
        if ( ++v55 == outchannels )
          break;
        v54 += 32;
      }
      while ( v55 < v53 );
    }
  }
  if ( !mRampCount )
  {
    FMOD::DSPConnectionI::setCurrentToTarget(v11);
    v60 = v11->mFadeCount;
  }
  else
  {
LABEL_59:
    v60 = v127;
  }
  if ( !v60 && v123 )
    v11->mFadeValue = v11->mFadeTarget;
  return 0;
}


// Address: 0x21c0e00 | Name: _ZN4FMOD14DSPConnectionI6rampToEj
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::rampTo(FMOD::DSPConnectionI *const this, unsigned int rampcount)
{
  float *mData; // rbp
  float *v3; // r13
  int mOutChannels; // r11d
  int mInChannels; // r9d
  int v6; // r12d
  int v7; // r8d
  float v8; // xmm1_4
  float *v9; // rcx
  int i; // eax
  float *v11; // rdx
  float v12; // xmm0_4
  float *v13; // rdx
  float v14; // xmm0_4
  int v15; // r10d

  mData = this->mMixMatrixCurrent.mData;
  if ( !mData )
    return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
  v3 = this->mMixMatrix.mData;
  if ( !v3 )
    return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
  if ( !rampcount )
    return FMOD::DSPConnectionI::setCurrentToTarget(this);
  mOutChannels = this->mMixMatrix.mOutChannels;
  if ( mOutChannels <= 0 )
    return FMOD::DSPConnectionI::setCurrentToTarget(this);
  mInChannels = this->mMixMatrix.mInChannels;
  v6 = 0;
  v7 = 0;
  v8 = 0.0;
  do
  {
    if ( mInChannels > 0 )
    {
      v9 = &v3[v6];
      for ( i = 0; i < mInChannels; ++i )
      {
        v11 = &DSPMatrixError;
        if ( mOutChannels > v7 && i < mInChannels )
          v11 = v9;
        v12 = *v11;
        v13 = &DSPMatrixError;
        v14 = v12 * this->mVolume;
        if ( v7 < this->mMixMatrixCurrent.mOutChannels )
        {
          v15 = this->mMixMatrixCurrent.mInChannels;
          if ( v15 > i )
            v13 = &mData[i + v7 * v15];
        }
        ++v9;
        v8 = v8 + fabs((float)(v14 - *v13) * (float)(1.0 / (float)(int)rampcount));
      }
    }
    ++v7;
    v6 += mInChannels;
  }
  while ( mOutChannels > v7 );
  if ( (v8 < 0.000001 || rampcount != 64) && (v8 <= 0.0 || rampcount == 64) )
    return FMOD::DSPConnectionI::setCurrentToTarget(this);
  this->mRampCount = rampcount;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c0f30 | Name: _ZN4FMOD14DSPConnectionI13checkDiagonalEiiPf
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::checkDiagonal(
        FMOD::DSPConnectionI *const this,
        int outchannels,
        int inchannels,
        float *mixmatrix)
{
  int v4; // r8d
  __int64 v5; // rax
  float v6; // xmm0_4
  bool v7; // di
  FMOD_RESULT_0 result; // eax
  float *v9; // rdx
  float *i; // rax
  float v11; // xmm2_4
  float v12; // xmm1_4
  float v13; // xmm3_4
  float v14; // xmm2_4
  float v15; // xmm3_4
  float v16; // xmm1_4
  float v17; // xmm2_4
  float v18; // xmm3_4
  float v19; // xmm2_4
  float v20; // xmm3_4
  float v21; // xmm2_4
  float v22; // xmm1_4
  float v23; // xmm2_4
  float v24; // xmm2_4
  float v25; // xmm13_4
  float v26; // xmm3_4

  if ( outchannels == 2 )
  {
    result = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
    if ( fabs(mixmatrix[1]) <= 0.000019999999 )
      return 9 * (fabs(mixmatrix[32]) > 0.000019999999);
    return result;
  }
  if ( outchannels == 8 )
  {
    v9 = mixmatrix + 256;
    for ( i = mixmatrix; ; i += 33 )
    {
      v26 = *mixmatrix;
      if ( *mixmatrix >= 0.0 )
      {
        v11 = mixmatrix[1];
        if ( v11 >= 0.0 )
          goto LABEL_20;
      }
      else
      {
        v26 = -v26;
        v11 = mixmatrix[1];
        if ( v11 >= 0.0 )
          goto LABEL_20;
      }
      v11 = -v11;
LABEL_20:
      v12 = v26 + v11;
      v13 = mixmatrix[2];
      if ( v13 < 0.0 )
        v13 = -v13;
      v14 = mixmatrix[3];
      v15 = v13 + v12;
      if ( v14 < 0.0 )
        v14 = -v14;
      v16 = mixmatrix[4];
      v17 = v14 + v15;
      if ( v16 < 0.0 )
        v16 = -v16;
      v18 = mixmatrix[5];
      v19 = v17 + v16;
      if ( v18 < 0.0 )
        v18 = -v18;
      v20 = v18 + v19;
      v21 = mixmatrix[6];
      if ( v21 < 0.0 )
        v21 = -v21;
      v22 = mixmatrix[7];
      v23 = v21 + v20;
      if ( v22 < 0.0 )
        v22 = -v22;
      v24 = v23 + v22;
      v25 = *i;
      if ( *i < 0.0 )
        v25 = -*i;
      if ( (float)(v24 - v25) > 0.000019999999 )
        return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
      mixmatrix += 32;
      if ( mixmatrix == v9 )
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  if ( outchannels <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  v4 = 0;
  while ( inchannels <= 0 )
  {
LABEL_13:
    if ( ++v4 == outchannels )
      return FMOD_RESULT::FMOD_OK_0;
  }
  v5 = 0;
  while ( 1 )
  {
    if ( v4 != (_DWORD)v5 )
    {
      v6 = mixmatrix[32 * v4 + v5];
      v7 = v6 < -0.000019999999;
      if ( v6 >= 0.0 )
        v7 = v6 > 0.000019999999;
      if ( v7 )
        return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
    }
    if ( inchannels <= (int)++v5 )
      goto LABEL_13;
  }
}


// Address: 0x21c1190 | Name: _ZN4FMOD14DSPConnectionI3mixEPfS1_biiji
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::mix(
        FMOD::DSPConnectionI *const this,
        float *outbuffer,
        float *inbuffer,
        bool directmapping,
        int outchannels,
        int inchannels,
        unsigned int length,
        int writedontmix)
{
  double v8; // xmm1_8
  float *v9; // r14
  double v11; // xmm2_8
  double v12; // xmm3_8
  unsigned int mNewRampCount; // esi
  unsigned int mRampCount; // r10d
  unsigned int mFadeCount; // eax
  int v19; // eax
  double v20; // xmm2_8
  double v21; // xmm0_8
  int mOutChannels; // r15d
  __int64 v23; // rdx
  const _FMOD_Optimised_Routines *v24; // r15
  float *v26; // r8
  int v27; // eax
  int mInChannels; // edx
  __int64 v29; // rdi
  float *v30; // rsi
  unsigned __int64 v31; // rdx
  __int16 v32; // ax
  int v33; // [rsp+10h] [rbp-1048h]
  unsigned int v34; // [rsp+14h] [rbp-1044h]
  float mFadeValue; // [rsp+14h] [rbp-1044h]
  float *mData; // [rsp+18h] [rbp-1040h]
  float s[32][32]; // [rsp+30h] [rbp-1028h] BYREF

  v9 = inbuffer;
  *(_QWORD *)&v11 = LODWORD(this->mVolume);
  *(_QWORD *)&v12 = LODWORD(this->mOldVolume);
  this->mOldVolume = *(float *)&v11;
  if ( !inbuffer || !length )
    return FMOD_RESULT::FMOD_OK_0;
  mNewRampCount = this->mNewRampCount;
  if ( *(float *)&v12 != *(float *)&v11 || mNewRampCount )
  {
    if ( this->mMixMatrixCurrent.mData )
    {
      FMOD::DSPConnectionI::rampTo(this, mNewRampCount);
      mRampCount = this->mRampCount;
      *(_QWORD *)&v12 = LODWORD(v12);
      *(_QWORD *)&v11 = LODWORD(v11);
    }
    else
    {
      this->mRampCount = mNewRampCount;
      mRampCount = mNewRampCount;
    }
    this->mFlags |= 8u;
    this->mNewRampCount = 0;
    if ( !mRampCount )
      goto LABEL_42;
    goto LABEL_7;
  }
  mRampCount = this->mRampCount;
  if ( mRampCount )
  {
    if ( !this->mMixMatrixCurrent.mData )
    {
      this->mRampCount = 0;
      goto LABEL_42;
    }
LABEL_7:
    mFadeCount = this->mFadeCount;
    goto LABEL_8;
  }
LABEL_42:
  mFadeCount = this->mFadeCount;
  if ( !mFadeCount )
    goto LABEL_16;
  if ( this->mFadeValue == this->mFadeTarget )
    goto LABEL_44;
  mRampCount = 0;
LABEL_8:
  if ( mRampCount >= mFadeCount )
    mFadeCount = mRampCount;
  if ( mFadeCount > length )
    mFadeCount = length;
  v8 = v11;
  v33 = mRampCount;
  v34 = mFadeCount;
  FMOD::DSPConnectionI::mixAndRamp(
    this,
    outbuffer,
    v9,
    directmapping,
    outchannels,
    inchannels,
    *(float *)&v12,
    *(float *)&v11,
    mFadeCount,
    writedontmix);
  length -= v34;
  *(_QWORD *)&v12 = LODWORD(v12);
  outbuffer += outchannels * v34;
  v9 += inchannels * v34;
  v19 = this->mRampCount;
  if ( v19 && v33 )
  {
    this->mNewRampCount = v19;
    *(float *)&v8 = (float)v33;
    this->mOldVolume = (float)((float)((float)v19 * *(float *)&v12) + (float)((float)(v33 - v19) * *(float *)&v11))
                     / (float)v33;
  }
  mFadeCount = this->mFadeCount;
  this->mFlags |= 8u;
  if ( mFadeCount && this->mFadeTarget == this->mFadeValue )
  {
LABEL_44:
    if ( mFadeCount < length )
      this->mFadeCount = 0;
    else
      this->mFadeCount = mFadeCount - length;
    this->mFlags |= 8u;
  }
LABEL_16:
  *(_QWORD *)&v20 = COERCE_UNSIGNED_INT(fabs(*(float *)&v11));
  *(_QWORD *)&v21 = 933741996;
  if ( *(float *)&v20 < 0.000019999999 )
  {
    if ( length && writedontmix )
      memset(outbuffer, 0, 4LL * length * outchannels);
  }
  else
  {
    if ( !length )
      return FMOD_RESULT::FMOD_OK_0;
    if ( this->mMixMatrixCurrent.mData )
    {
      mOutChannels = this->mMixMatrixCurrent.mOutChannels;
      if ( outchannels < mOutChannels )
        v23 = 32 * outchannels;
      else
        v23 = 32 * mOutChannels;
      mFadeValue = this->mFadeValue;
      mData = this->mMixMatrixCurrent.mData;
      memset(s, 0, 4 * v23);
      *(_QWORD *)&v8 = LODWORD(mFadeValue);
      if ( outchannels > 0 && mOutChannels > 0 )
      {
        v26 = s[0];
        v27 = 0;
        do
        {
          if ( inchannels > 0 )
          {
            mInChannels = this->mMixMatrixCurrent.mInChannels;
            if ( this->mMixMatrixCurrent.mInChannels > 0 )
            {
              v29 = 4LL * (unsigned int)(mInChannels - 1) + 4;
              v30 = &mData[v27 * mInChannels];
              v31 = 0;
              do
              {
                *(_QWORD *)&v21 = LODWORD(v30[v31 / 4]);
                *(float *)&v21 = *(float *)&v21 * mFadeValue;
                v26[v31 / 4] = *(float *)&v21;
                if ( v31 == 4LL * (unsigned int)(inchannels - 1) )
                  break;
                v31 += 4LL;
              }
              while ( v31 != v29 );
            }
          }
          if ( ++v27 == outchannels )
            break;
          v26 += 32;
        }
        while ( v27 < mOutChannels );
      }
    }
    else
    {
      memset(s, 0, 128LL * outchannels);
      *(_QWORD *)&v21 = LODWORD(this->mFadeValue);
      *(float *)&v21 = *(float *)&v21 * this->mVolume;
      FMOD::DSPConnectionI::getDefaultMatrix(s, directmapping, outchannels, inchannels, *(float *)&v21);
    }
    v24 = &FMOD_Optimised_Routines;
    if ( ((FMOD_Optimised_Routines.RequiredMixBufferAlignment - 1) & ((unsigned int)v9 | (unsigned int)outbuffer)) != 0 )
      v24 = &FMOD_Optimised_Routines_NoOpt;
    if ( outchannels == 1 && inchannels == 1 )
    {
      ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_MixMonoToMono)(
        v9,
        outbuffer,
        length,
        s[0],
        1,
        1,
        v21,
        v8,
        v20,
        v12,
        writedontmix);
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( outchannels == 2 )
    {
      if ( (unsigned int)(inchannels - 1) <= 1 )
      {
        if ( inchannels == 1 )
        {
          ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_MixMonoToStereo)(
            v9,
            outbuffer,
            length,
            s[0],
            1,
            2,
            v21,
            v8,
            v20,
            v12,
            writedontmix);
        }
        else if ( FMOD::DSPConnectionI::checkDiagonal(this, 2, 2, s[0]) )
        {
          ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_MixStereoToStereo_Full)(
            v9,
            outbuffer,
            length,
            s[0],
            2,
            2,
            v21,
            v8,
            v20,
            v12,
            writedontmix);
        }
        else
        {
          ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_MixStereoToStereo_Diagonal)(
            v9,
            outbuffer,
            length,
            s[0],
            2,
            2,
            v21,
            v8,
            v20,
            v12,
            writedontmix);
        }
        return FMOD_RESULT::FMOD_OK_0;
      }
      goto LABEL_56;
    }
    if ( outchannels != 6 )
    {
      if ( outchannels == 8 && ((unsigned int)(inchannels - 1) <= 1 || inchannels == 8) )
      {
        switch ( inchannels )
        {
          case 1:
            ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_MixMonoTo71)(
              v9,
              outbuffer,
              length,
              s[0],
              1,
              8,
              v21,
              v8,
              v20,
              v12,
              writedontmix);
            break;
          case 2:
            ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_MixStereoTo71)(
              v9,
              outbuffer,
              length,
              s[0],
              2,
              8,
              v21,
              v8,
              v20,
              v12,
              writedontmix);
            break;
          case 8:
            if ( FMOD::DSPConnectionI::checkDiagonal(this, 8, 8, s[0]) )
              ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_Mix71To71_Full)(
                v9,
                outbuffer,
                length,
                s[0],
                8,
                8,
                v21,
                v8,
                v20,
                v12,
                writedontmix);
            else
              ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_Mix71To71_Diagonal)(
                v9,
                outbuffer,
                length,
                s[0],
                8,
                8,
                v21,
                v8,
                v20,
                v12,
                writedontmix);
            break;
        }
        return FMOD_RESULT::FMOD_OK_0;
      }
LABEL_56:
      ((void (__fastcall *)(float *, float *, _QWORD, float *, _QWORD, _QWORD, double, double, double, double, int))v24->FMOD_DSP_Connection_Mix_Generic)(
        v9,
        outbuffer,
        length,
        s[0],
        (unsigned int)inchannels,
        (unsigned int)outchannels,
        v21,
        v8,
        v20,
        v12,
        writedontmix);
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( (unsigned int)(inchannels - 1) > 1 && inchannels != 6 )
      goto LABEL_56;
    switch ( inchannels )
    {
      case 1:
        ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_MixMonoTo51)(
          v9,
          outbuffer,
          length,
          s[0],
          1,
          6,
          v21,
          v8,
          v20,
          v12,
          writedontmix);
        break;
      case 2:
        ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_MixStereoTo51)(
          v9,
          outbuffer,
          length,
          s[0],
          2,
          6,
          v21,
          v8,
          v20,
          v12,
          writedontmix);
        break;
      case 6:
        if ( FMOD::DSPConnectionI::checkDiagonal(this, 6, 6, s[0]) )
        {
          v32 = this->mMixMatrixCurrent.mOutChannels;
          if ( v32 == 1 )
          {
            ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_Mix51To51_OneRow)(
              v9,
              outbuffer,
              length,
              s[0],
              6,
              6,
              v21,
              v8,
              v20,
              v12,
              writedontmix);
          }
          else if ( v32 == 2 )
          {
            ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_Mix51To51_TwoRow)(
              v9,
              outbuffer,
              length,
              s[0],
              6,
              6,
              v21,
              v8,
              v20,
              v12,
              writedontmix);
          }
          else
          {
            ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_Mix51To51_Full)(
              v9,
              outbuffer,
              length,
              s[0],
              6,
              6,
              v21,
              v8,
              v20,
              v12,
              writedontmix);
          }
        }
        else
        {
          ((void (__fastcall *)(float *, float *, _QWORD, float *, __int64, __int64, double, double, double, double, int))v24->FMOD_DSP_Connection_Mix51To51_Diagonal)(
            v9,
            outbuffer,
            length,
            s[0],
            6,
            6,
            v21,
            v8,
            v20,
            v12,
            writedontmix);
        }
        break;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c18d0 | Name: _ZN4FMOD23FMOD_DSPConnectionI_MixEP18FMOD_DSPCONNECTIONPfS2_iiji
FMOD_RESULT_0 __fastcall FMOD::FMOD_DSPConnectionI_Mix(
        FMOD_DSPCONNECTION *connection_in,
        float *outbuffer,
        float *inbuffer,
        int outchannels,
        int inchannels,
        unsigned int length,
        int writedontmix)
{
  return FMOD::DSPConnectionI::mix(
           (FMOD::DSPConnectionI *const)connection_in,
           outbuffer,
           inbuffer,
           0,
           outchannels,
           inchannels,
           length,
           writedontmix);
}


// Address: 0x21c1900 | Name: _ZN4FMOD14DSPConnectionI9checkMonoEii
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::checkMono(
        FMOD::DSPConnectionI *const this,
        int outchannels,
        int inchannels)
{
  int v3; // r8d
  int v4; // eax
  float *v5; // rcx
  int mInChannels; // r9d

  if ( inchannels == 1 || outchannels <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  v3 = 0;
  while ( inchannels <= 1 )
  {
LABEL_13:
    if ( ++v3 == outchannels )
      return FMOD_RESULT::FMOD_OK_0;
  }
  v4 = 1;
  while ( 1 )
  {
    v5 = &DSPMatrixError;
    if ( v3 < this->mMixMatrix.mOutChannels )
    {
      mInChannels = this->mMixMatrix.mInChannels;
      if ( mInChannels > v4 )
        v5 = &this->mMixMatrix.mData[v4 + v3 * mInChannels];
    }
    if ( *v5 != 0.0 )
      return FMOD_RESULT::FMOD_ERR_TOOMANYCHANNELS_0;
    if ( ++v4 == inchannels )
      goto LABEL_13;
  }
}


// Address: 0x21c1980 | Name: _ZN4FMOD14DSPConnectionI12resizeMatrixEPfS1_ii
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::resizeMatrix(
        FMOD::DSPConnectionI *const this,
        float *mixmatrixdata,
        float *mixmatrixcurrentdata,
        int inchannels,
        int outchannels)
{
  __int16 v6; // r13
  __int16 v7; // r12
  float *mData; // rsi
  float *v10; // rsi
  int mInChannels; // ecx
  int mOutChannels; // eax
  int v13; // ecx
  float *v14; // rdx
  __int64 v15; // rax

  v6 = outchannels;
  v7 = inchannels;
  mData = this->mMixMatrix.mData;
  if ( mData )
    FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, mData, (const char *)&uri_string, 0);
  v10 = this->mMixMatrixCurrent.mData;
  this->mMixMatrix.mInChannels = v7;
  this->mMixMatrix.mOutChannels = v6;
  this->mMixMatrix.mData = mixmatrixdata;
  if ( v10 )
  {
    FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, v10, (const char *)&uri_string, 0);
    mInChannels = this->mMixMatrix.mInChannels;
    mOutChannels = this->mMixMatrix.mOutChannels;
  }
  else
  {
    mOutChannels = v6;
    mInChannels = v7;
  }
  v13 = mOutChannels * mInChannels;
  this->mMixMatrixCurrent.mInChannels = v7;
  this->mMixMatrixCurrent.mOutChannels = v6;
  this->mMixMatrixCurrent.mData = mixmatrixcurrentdata;
  if ( v13 > 0 )
  {
    v14 = this->mMixMatrix.mData;
    v15 = 0;
    do
    {
      mixmatrixcurrentdata[v15] = v14[v15] * this->mOldVolume;
      ++v15;
    }
    while ( v13 > (int)v15 );
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c1a50 | Name: _ZN4FMOD14DSPConnectionI12setMixMatrixEPfiiiib
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::setMixMatrix(
        FMOD::DSPConnectionI *const this,
        float *matrix,
        int outchannels,
        int inchannels,
        int inchannel_hop,
        int rampcount,
        bool deferred)
{
  float v7; // xmm1_4
  int v10; // r12d
  FMOD::SystemI *mSystem; // rdx
  float *v15; // rax
  FMOD_RESULT_0 v16; // ecx
  float *mData; // rsi
  float *v18; // rax
  FMOD::SystemI *v19; // rax
  FMOD::DSPMatrix *p_mMixMatrixUser; // r9
  float *v22; // rsi
  float *v23; // rsi
  bool v24; // zf
  int v25; // eax
  float *v26; // rax
  float mShadowVolume; // xmm0_4
  FMOD::DSPQueueCmd_UpdateMixMatrix *v28; // rsi
  FMOD::SystemI *v29; // rdi
  FMOD_RESULT_0 v30; // eax
  float *v31; // rax
  bool mixmatrixcurrentdata; // [rsp+10h] [rbp-78h]
  float *mixmatrixcurrentdataa; // [rsp+10h] [rbp-78h]
  int result; // [rsp+18h] [rbp-70h]
  float *ptr; // [rsp+20h] [rbp-68h]
  float *ptra; // [rsp+20h] [rbp-68h]
  FMOD::DSPQueueCmd_UpdateMixMatrix *cmd; // [rsp+38h] [rbp-50h] BYREF
  FMOD::DSPMatrix v39; // [rsp+40h] [rbp-48h] BYREF

  v10 = outchannels;
  if ( inchannels >= outchannels )
    v10 = inchannels;
  if ( matrix )
  {
    if ( deferred )
    {
      mixmatrixcurrentdata = 1;
      if ( inchannels <= this->mUserData.mMixMatrixUser.mInChannels
        && outchannels <= this->mUserData.mMixMatrixUser.mOutChannels )
      {
        mixmatrixcurrentdata = this->mUserData.mMixMatrixUser.mData == 0;
      }
      mSystem = this->mSystem;
      v39.mInChannels = 0;
      v39.mData = 0;
      v39.mOutChannels = 0;
      result = 4 * v10 * outchannels;
      v15 = (float *)FMOD::MemPool::alloc(&mSystem->mDSPLevelsPool, result, (const char *)&uri_string, 0, 0, 0);
      ptr = v15;
      if ( v15 )
      {
        v39.mData = v15;
        v39.mInChannels = v10;
        v39.mOutChannels = outchannels;
        v16 = FMOD::DSPMatrix::set(&v39, matrix, outchannels, inchannels, inchannel_hop);
        if ( v16 )
          return v16;
        if ( !mixmatrixcurrentdata )
        {
          p_mMixMatrixUser = &this->mUserData.mMixMatrixUser;
          if ( &this->mUserData.mMixMatrixUser == &v39
            || (mixmatrixcurrentdataa = 0,
                *(_DWORD *)&v39.mInChannels == *(_DWORD *)&this->mUserData.mMixMatrixUser.mInChannels)
            && (v25 = memcmp(v39.mData, this->mUserData.mMixMatrixUser.mData, 4 * v39.mOutChannels * v39.mInChannels),
                p_mMixMatrixUser = &this->mUserData.mMixMatrixUser,
                !v25) )
          {
            FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, ptr, (const char *)&uri_string, 0);
            return FMOD_RESULT::FMOD_OK_0;
          }
          goto LABEL_16;
        }
        mData = this->mUserData.mMixMatrixUser.mData;
        if ( mData )
          FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, mData, (const char *)&uri_string, 0);
        v18 = (float *)FMOD::MemPool::alloc(&this->mSystem->mDSPLevelsPool, result, (const char *)&uri_string, 0, 0, 0);
        if ( v18 )
        {
          this->mUserData.mMixMatrixUser.mData = v18;
          v19 = this->mSystem;
          this->mUserData.mMixMatrixUser.mInChannels = v10;
          this->mUserData.mMixMatrixUser.mOutChannels = outchannels;
          mixmatrixcurrentdataa = (float *)FMOD::MemPool::alloc(
                                             &v19->mDSPLevelsPool,
                                             result,
                                             (const char *)&uri_string,
                                             0,
                                             0,
                                             0);
          if ( mixmatrixcurrentdataa )
          {
            p_mMixMatrixUser = &this->mUserData.mMixMatrixUser;
LABEL_16:
            v16 = FMOD::DSPMatrix::set(p_mMixMatrixUser, matrix, outchannels, inchannels, inchannel_hop);
            if ( v16 == FMOD_RESULT::FMOD_OK_0 )
            {
              v16 = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 40, 1);
              if ( v16 == FMOD_RESULT::FMOD_OK_0 )
              {
                v28 = cmd;
                v29 = this->mSystem;
                *(_BYTE *)&cmd->FMOD::DSPQueueCmd = 10;
                v28->mConnection = this;
                v28->mMatrixData = ptr;
                v28->mOutChannels = outchannels;
                v28->mInChannels = v10;
                v28->mMatrixCurrentData = mixmatrixcurrentdataa;
                v28->mRampCount = rampcount;
                v30 = FMOD::SystemI::unlockDSPQueueCmd(v29, v28, 1);
                v16 = FMOD_RESULT::FMOD_OK_0;
                if ( v30 )
                  return v30;
              }
            }
            return v16;
          }
        }
      }
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
    v22 = this->mMixMatrix.mData;
    if ( !v22 )
      goto LABEL_29;
    if ( inchannels > this->mMixMatrix.mInChannels || outchannels > this->mMixMatrix.mOutChannels )
    {
      FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, v22, (const char *)&uri_string, 0);
      v23 = this->mMixMatrixCurrent.mData;
      this->mMixMatrix.mInChannels = 0;
      this->mMixMatrix.mOutChannels = 0;
      this->mMixMatrix.mData = 0;
      if ( !v23
        || (FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, v23, (const char *)&uri_string, 0),
            v24 = this->mMixMatrix.mData == 0,
            this->mMixMatrixCurrent.mInChannels = 0,
            this->mMixMatrixCurrent.mOutChannels = 0,
            this->mMixMatrixCurrent.mData = 0,
            v24) )
      {
LABEL_29:
        v26 = (float *)FMOD::MemPool::alloc(
                         &this->mSystem->mDSPLevelsPool,
                         4 * v10 * outchannels,
                         (const char *)&uri_string,
                         0,
                         0,
                         0);
        if ( !v26 )
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        ptra = v26;
        v31 = (float *)FMOD::MemPool::alloc(
                         &this->mSystem->mDSPLevelsPool,
                         4 * v10 * outchannels,
                         (const char *)&uri_string,
                         0,
                         0,
                         0);
        if ( !v31 )
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        this->mMixMatrix.mInChannels = v10;
        this->mMixMatrix.mOutChannels = outchannels;
        this->mMixMatrixCurrent.mInChannels = v10;
        this->mMixMatrixCurrent.mOutChannels = outchannels;
        this->mMixMatrix.mData = ptra;
        this->mMixMatrixCurrent.mData = v31;
        if ( rampcount )
          memset(v31, 0, 4LL * v10 * outchannels);
      }
    }
    v16 = FMOD::DSPMatrix::set(&this->mMixMatrix, matrix, outchannels, inchannels, inchannel_hop);
    if ( v16 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD::DSPConnectionI::rampTo(this, rampcount);
  }
  else
  {
    if ( deferred )
      mShadowVolume = this->mUserData.mShadowVolume;
    else
      mShadowVolume = this->mVolume;
    return (unsigned int)FMOD::DSPConnectionI::setUnity(this, mShadowVolume, v7, deferred);
  }
  return v16;
}


// Address: 0x21c1f00 | Name: _ZN4FMOD14DSPConnectionI12getMixMatrixEPfPiS2_i
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::getMixMatrix(
        FMOD::DSPConnectionI *const this,
        float *matrix,
        int *outchannels,
        int *inchannels,
        int inchannel_hop)
{
  return FMOD::DSPMatrix::get(&this->mUserData.mMixMatrixUser, matrix, outchannels, inchannels, inchannel_hop);
}


// Address: 0x21c1f10 | Name: _ZN4FMOD14DSPConnectionI7getTypeEP23FMOD_DSPCONNECTION_TYPE
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::getType(
        FMOD::DSPConnectionI *const this,
        FMOD_DSPCONNECTION_TYPE_0 *type)
{
  FMOD_RESULT_0 result; // eax
  unsigned int mFlags; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( type )
  {
    mFlags = this->mFlags;
    if ( (mFlags & 5) == 5 )
    {
      *type = FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SEND_SIDECHAIN_0;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else if ( (mFlags & 1) != 0 )
    {
      *type = FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SIDECHAIN_0;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else if ( (mFlags & 4) != 0 )
    {
      *type = FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SEND_0;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      *type = FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21c1f70 | Name: _ZN4FMOD14DSPConnectionI14setMixInternalEfib
__int64 __fastcall FMOD::DSPConnectionI::setMixInternal(
        FMOD::DSPConnectionI *const this,
        float volume,
        unsigned int rampcount,
        bool rampfrom0)
{
  bool v4; // zf

  if ( rampfrom0 )
  {
    this->mVolume = volume;
    v4 = volume == 0.0;
    this->mOldVolume = 0.0;
  }
  else
  {
    if ( volume == this->mVolume )
      return 0;
    v4 = volume == this->mOldVolume;
    this->mVolume = volume;
  }
  if ( v4 )
  {
    this->mNewRampCount = 0;
    return 0;
  }
  this->mNewRampCount = rampcount;
  if ( rampcount )
    return 0;
  FMOD::DSPConnectionI::setCurrentToTarget(this);
  return 0;
}


// Address: 0x21c1ff0 | Name: _ZN4FMOD14DSPConnectionI6setMixEfibb
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::setMix(
        FMOD::DSPConnectionI *const this,
        float volume,
        unsigned int rampcount,
        bool deferred,
        bool rampfrom0)
{
  FMOD_RESULT_0 result; // eax
  float v9; // xmm1_4
  FMOD::DSPQueueCmd_FaderSetVolume *v10; // rsi
  FMOD::SystemI *mSystem; // rdi
  FMOD::DSPQueueCmd_FaderSetVolume *cmd; // [rsp+18h] [rbp-20h] BYREF

  if ( volume != this->mUserData.mShadowVolume
    || this->mUserData.mShadowRampCount != rampcount
    || (result = FMOD_RESULT::FMOD_OK_0, rampfrom0) )
  {
    if ( deferred )
    {
      result = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 32, 1);
      if ( result )
        return result;
      v10 = cmd;
      mSystem = this->mSystem;
      cmd->mVolume = volume;
      *(_BYTE *)&v10->FMOD::DSPQueueCmd = 13;
      v10->mThis = this;
      v10->mRampCount = rampcount;
      v10->mRampFrom0 = rampfrom0;
      result = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v10, 1);
      v9 = volume;
      if ( result )
        return result;
    }
    else
    {
      result = (unsigned int)FMOD::DSPConnectionI::setMixInternal(this, volume, rampcount, rampfrom0);
      v9 = volume;
      if ( result )
        return result;
    }
    this->mUserData.mShadowVolume = v9;
    this->mUserData.mShadowRampCount = rampcount;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21c20c0 | Name: _ZN4FMOD14DSPConnectionI6getMixEPf
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::getMix(FMOD::DSPConnectionI *const this, float *volume)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( volume )
  {
    LOBYTE(result) = 0;
    *volume = this->mUserData.mShadowVolume;
  }
  return result;
}


// Address: 0x21c20e0 | Name: _ZN4FMOD14DSPConnectionI11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::setUserData(FMOD::DSPConnectionI *const this, void *userdata)
{
  this->mUserData.mUserData = userdata;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c20f0 | Name: _ZN4FMOD14DSPConnectionI11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::getUserData(FMOD::DSPConnectionI *const this, void **userdata)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( userdata )
  {
    *userdata = this->mUserData.mUserData;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21c2110 | Name: _ZN4FMOD14DSPConnectionI4copyEPS0_b
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::copy(
        FMOD::DSPConnectionI *const this,
        FMOD::DSPConnectionI *source,
        bool copymatrices)
{
  float mFadeValue; // xmm0_4
  unsigned int mFadeCount; // eax
  FMOD_RESULT_0 result; // eax

  this->mVolume = source->mVolume;
  this->mOldVolume = source->mOldVolume;
  if ( !copymatrices
    || (result = FMOD::DSPMatrix::copy(&this->mMixMatrix, this->mSystem, &source->mMixMatrix)) == FMOD_RESULT::FMOD_OK_0
    && (result = FMOD::DSPMatrix::copy(&this->mMixMatrixCurrent, this->mSystem, &source->mMixMatrixCurrent)) == FMOD_RESULT::FMOD_OK_0 )
  {
    mFadeValue = source->mFadeValue;
    this->mRampCount = source->mRampCount;
    mFadeCount = source->mFadeCount;
    this->mFadeValue = mFadeValue;
    this->mFadeTarget = source->mFadeTarget;
    this->mFadeCount = mFadeCount;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21c21a0 | Name: _ZN4FMOD14DSPConnectionI14resetFadeStateEv
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::resetFadeState(FMOD::DSPConnectionI *const this)
{
  this->mFadeCount = 0;
  this->mFadeValue = 1.0;
  this->mFadeTarget = 1.0;
  return FMOD_RESULT::FMOD_OK_0;
}


