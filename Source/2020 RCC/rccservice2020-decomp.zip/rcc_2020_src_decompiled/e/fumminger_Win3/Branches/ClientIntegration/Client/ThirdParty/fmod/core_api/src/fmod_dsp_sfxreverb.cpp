// Address: 0x21d5cb0 | Name: _ZN4FMOD12DSPSfxReverb16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPSfxReverb::getDescriptionEx()
{
  memset(&stru_2AD94E0, 0, sizeof(stru_2AD94E0));
  FMOD_strcpy_safe(stru_2AD94E0.name, "Decay Time", 16);
  FMOD_strcpy_safe(stru_2AD94E0.label, "ms", 16);
  *(_QWORD *)&stru_2AD94E0.floatdesc.min = 0x469C400042C80000LL;
  stru_2AD94E0.description = "Decay Time";
  memset(&stru_2AD9480, 0, sizeof(stru_2AD9480));
  stru_2AD94E0.intdesc.defaultval = 1153138688;
  stru_2AD94E0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD9480.name, "Early Delay", 16);
  FMOD_strcpy_safe(stru_2AD9480.label, "ms", 16);
  *(_QWORD *)&stru_2AD9480.floatdesc.min = 0x4396000000000000LL;
  stru_2AD9480.description = "Early Delay";
  memset(&stru_2AD9420, 0, sizeof(stru_2AD9420));
  stru_2AD9480.intdesc.defaultval = 1101004800;
  stru_2AD9480.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD9420.name, "Late Delay", 16);
  FMOD_strcpy_safe(stru_2AD9420.label, "ms", 16);
  *(_QWORD *)&stru_2AD9420.floatdesc.min = 0x42C8000000000000LL;
  stru_2AD9420.description = "Late Delay";
  memset(&stru_2AD93C0, 0, sizeof(stru_2AD93C0));
  stru_2AD9420.intdesc.defaultval = 1109393408;
  stru_2AD9420.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD93C0.name, "HF Reference", 16);
  FMOD_strcpy_safe(stru_2AD93C0.label, "Hz", 16);
  *(_QWORD *)&stru_2AD93C0.floatdesc.min = 0x469C400041A00000LL;
  stru_2AD93C0.description = "HF Reference";
  memset(&stru_2AD9360, 0, sizeof(stru_2AD9360));
  stru_2AD93C0.intdesc.defaultval = 1167867904;
  stru_2AD93C0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD9360.name, "HF Decay Ratio", 16);
  FMOD_strcpy_safe(stru_2AD9360.label, "%", 16);
  *(_QWORD *)&stru_2AD9360.floatdesc.min = 0x4348000041200000LL;
  stru_2AD9360.description = "HF Decay Ratio";
  memset(&stru_2AD9300, 0, sizeof(stru_2AD9300));
  stru_2AD9360.intdesc.defaultval = 1112014848;
  stru_2AD9360.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD9300.name, "Diffusion", 16);
  FMOD_strcpy_safe(stru_2AD9300.label, "%", 16);
  *(_QWORD *)&stru_2AD9300.floatdesc.min = 0x42C8000000000000LL;
  stru_2AD9300.description = "Diffusion";
  memset(&stru_2AD92A0, 0, sizeof(stru_2AD92A0));
  stru_2AD9300.intdesc.defaultval = 1120403456;
  stru_2AD9300.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD92A0.name, "Density", 16);
  FMOD_strcpy_safe(stru_2AD92A0.label, "%", 16);
  *(_QWORD *)&stru_2AD92A0.floatdesc.min = 0x42C8000000000000LL;
  stru_2AD92A0.description = "Density";
  memset(&stru_2AD9240, 0, sizeof(stru_2AD9240));
  stru_2AD92A0.intdesc.defaultval = 1120403456;
  stru_2AD92A0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD9240.name, "Low Shelf Frequency", 16);
  FMOD_strcpy_safe(stru_2AD9240.label, "Hz", 16);
  *(_QWORD *)&stru_2AD9240.floatdesc.min = 0x447A000041A00000LL;
  stru_2AD9240.description = "Low Shelf Frequency";
  memset(&stru_2AD91E0, 0, sizeof(stru_2AD91E0));
  stru_2AD9240.intdesc.defaultval = 1132068864;
  stru_2AD9240.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD91E0.name, "Low Shelf Gain", 16);
  FMOD_strcpy_safe(stru_2AD91E0.label, "dB", 16);
  *(_QWORD *)&stru_2AD91E0.floatdesc.min = 0x41400000C2400000LL;
  stru_2AD91E0.description = "Low Shelf Gain";
  memset(&stru_2AD9180, 0, sizeof(stru_2AD9180));
  stru_2AD91E0.intdesc.defaultval = 0;
  stru_2AD91E0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD9180.name, "High Cut", 16);
  FMOD_strcpy_safe(stru_2AD9180.label, "Hz", 16);
  *(_QWORD *)&stru_2AD9180.floatdesc.min = 0x469C400041A00000LL;
  stru_2AD9180.description = "High Cut";
  memset(&stru_2AD9120, 0, sizeof(stru_2AD9120));
  stru_2AD9180.intdesc.defaultval = 1184645120;
  stru_2AD9180.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD9120.name, "Early/Late Mix", 16);
  FMOD_strcpy_safe(stru_2AD9120.label, "%", 16);
  *(_QWORD *)&stru_2AD9120.floatdesc.min = 0x42C8000000000000LL;
  stru_2AD9120.description = "Early/Late Mix";
  memset(&stru_2AD90C0, 0, sizeof(stru_2AD90C0));
  stru_2AD9120.intdesc.defaultval = 1112014848;
  stru_2AD9120.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD90C0.name, "Wet Level", 16);
  FMOD_strcpy_safe(stru_2AD90C0.label, "dB", 16);
  *(_QWORD *)&stru_2AD90C0.floatdesc.min = 0x41A00000C2A00000LL;
  stru_2AD90C0.description = "Wet Level";
  memset(&stru_2AD9060, 0, sizeof(stru_2AD9060));
  stru_2AD90C0.intdesc.defaultval = -1061158912;
  stru_2AD90C0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD9060.name, "Dry Level", 16);
  FMOD_strcpy_safe(stru_2AD9060.label, "dB", 16);
  *(_QWORD *)&stru_2AD9060.floatdesc.min = 0x41A00000C2A00000LL;
  stru_2AD9060.intdesc.defaultval = 0;
  stru_2AD9060.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AD9060.description = "Dry Level";
  stru_2AD9020.mSize = 2184;
  *(&stru_2AD9020.mHandle + 1) = 19;
  stru_2AD9020.mDescription = &stru_286AA80;
  stru_2AD9020.mCommand = FMOD::DSPSfxReverb::commandCallback;
  stru_2AD9020.mCommandMask = 2;
  return &stru_2AD9020;
}


// Address: 0x21d6340 | Name: _ZN4FMOD12DSPSfxReverb15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::releaseInternal(FMOD::DSPSfxReverb *const this)
{
  ASfxDsp::close((ASfxDsp *const)((char *)this + 528));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d6360 | Name: _ZN4FMOD12DSPSfxReverb15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPSfxReverb::releaseInternal((FMOD::DSPSfxReverb *const)dsp_state->instance);
}


// Address: 0x21d6370 | Name: _ZN4FMOD12DSPSfxReverb13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::resetInternal(FMOD::DSPSfxReverb *const this)
{
  if ( ASfxDsp::UpdateBufferSize((ASfxDsp *const)((char *)this + 528), *(_DWORD *)(*((_QWORD *)this + 22) + 1704LL)) )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  ASfxDsp::ClearBuffers((ASfxDsp *const)((char *)this + 528));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d63b0 | Name: _ZN4FMOD12DSPSfxReverb13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPSfxReverb::resetInternal((FMOD::DSPSfxReverb *const)dsp_state->instance);
}


// Address: 0x21d63c0 | Name: _ZN4FMOD12DSPSfxReverb22shouldIProcessInternalEiji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::shouldIProcessInternal(
        FMOD::DSPSfxReverb *const this,
        FMOD_BOOL inputsidle,
        unsigned int length,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  float v5; // xmm0_4
  unsigned int v6; // ecx
  FMOD_RESULT_0 result; // eax

  if ( !inputsidle )
  {
    v5 = *((float *)this + 529);
    if ( v5 <= -80.0 )
    {
      v6 = *((_DWORD *)this + 531);
      if ( v6 <= length )
        goto LABEL_5;
LABEL_8:
      *((_DWORD *)this + 531) = v6 - length;
      return FMOD_RESULT::FMOD_OK_0;
    }
    v6 = (int)(float)((float)((float)((float)(v5 + 100.0) * *((float *)this + 518)) * 0.000016666667)
                    * (float)*((int *)this + 530));
    *((_DWORD *)this + 531) = v6;
LABEL_4:
    if ( v6 <= length )
    {
LABEL_5:
      *((_DWORD *)this + 531) = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
    goto LABEL_8;
  }
  v6 = *((_DWORD *)this + 531);
  result = FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
  if ( v6 )
    goto LABEL_4;
  return result;
}


// Address: 0x21d6460 | Name: _ZN4FMOD12DSPSfxReverb22shouldIProcessCallbackEP14FMOD_DSP_STATEijji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::shouldIProcessCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD_BOOL inputsidle,
        unsigned int length,
        FMOD_CHANNELMASK a4,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  return FMOD::DSPSfxReverb::shouldIProcessInternal(
           (FMOD::DSPSfxReverb *const)dsp_state->instance,
           inputsidle,
           length,
           inchannels,
           speakermode);
}


// Address: 0x21d6470 | Name: _ZN4FMOD12DSPSfxReverb12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::readInternal(
        FMOD::DSPSfxReverb *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  unsigned int v7; // ecx
  unsigned int v8; // r8d
  unsigned int i; // eax
  __int64 v10; // r9

  if ( *((_DWORD *)this + 531) )
  {
    ASfxDsp::DoDSPProcessing(
      (ASfxDsp *const)((char *)this + 528),
      inbuffer,
      outbuffer,
      inchannels,
      length,
      (float)*((int *)this + 530),
      *((float *)this + 545));
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( inchannels > 0 )
    {
      v7 = inchannels * length;
      v8 = 0;
      do
      {
        for ( i = v8; i < v7; outbuffer[v10] = inbuffer[v10] * *((float *)this + 545) )
        {
          v10 = i;
          i += inchannels;
        }
        ++v8;
      }
      while ( v8 != inchannels );
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21d6500 | Name: _ZN4FMOD12DSPSfxReverb12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPSfxReverb::readInternal(
           (FMOD::DSPSfxReverb *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x21d6510 | Name: _ZN4FMOD12DSPSfxReverb25setParameterFloatInternalEifb
__int64 __fastcall FMOD::DSPSfxReverb::setParameterFloatInternal(
        FMOD::DSPI *this,
        int index,
        float value,
        bool sendCommand)
{
  FMOD_RESULT_0 v5; // ebx
  __int64 result; // rax
  float v7; // xmm0_4
  FMOD::DSPQueueCmd_UpdateParameters *v8; // rsi
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 v10; // eax
  bool v11; // [rsp+Ch] [rbp-2Ch]
  FMOD::DSPQueueCmd_UpdateParameters *cmd; // [rsp+18h] [rbp-20h] BYREF

  switch ( index )
  {
    case 0:
      *((float *)this + 532) = value;
      goto LABEL_3;
    case 1:
      *((float *)this + 533) = value;
      goto LABEL_3;
    case 2:
      *((float *)this + 534) = value;
      goto LABEL_3;
    case 3:
      *((float *)this + 535) = value;
      goto LABEL_3;
    case 4:
      *((float *)this + 536) = value;
      goto LABEL_3;
    case 5:
      *((float *)this + 537) = value;
      goto LABEL_3;
    case 6:
      *((float *)this + 538) = value;
      goto LABEL_3;
    case 7:
      *((float *)this + 539) = value;
      goto LABEL_3;
    case 8:
      *((float *)this + 540) = value;
      goto LABEL_3;
    case 9:
      *((float *)this + 541) = value;
      goto LABEL_3;
    case 10:
      *((float *)this + 542) = value;
      goto LABEL_3;
    case 11:
      *((float *)this + 543) = value;
      goto LABEL_3;
    case 12:
      *((float *)this + 544) = value;
      if ( value > -80.0 )
      {
        v11 = sendCommand;
        v7 = powf(10.0, value / 20.0);
        sendCommand = v11;
      }
      else
      {
        v7 = 0.0;
      }
      *((float *)this + 545) = v7;
LABEL_3:
      v5 = FMOD_RESULT::FMOD_OK_0;
      if ( !sendCommand )
        goto LABEL_4;
      v5 = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 16, 1);
      if ( v5 )
        goto LABEL_4;
      v8 = cmd;
      mSystem = this->mSystem;
      cmd->mThis = this;
      *(_BYTE *)&v8->FMOD::DSPQueueCmd = 7;
      v10 = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v8, 1);
      if ( v10 )
        v5 = v10;
      result = (unsigned int)v5;
      break;
    default:
      v5 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
LABEL_4:
      result = (unsigned int)v5;
      break;
  }
  return result;
}


// Address: 0x21d66b0 | Name: _ZN4FMOD12DSPSfxReverb25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPSfxReverb::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPSfxReverb::setParameterFloatInternal((FMOD::DSPI *)dsp_state->instance, index, a3, 1);
}


// Address: 0x21d66c0 | Name: _ZN4FMOD12DSPSfxReverb25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::getParameterFloatInternal(
        FMOD::DSPSfxReverb *const this,
        int index,
        float *value,
        char *valuestr)
{
  int v4; // edx
  float v5; // xmm0_4
  FMOD_RESULT_0 result; // eax

  switch ( index )
  {
    case 0:
      if ( value )
        *value = *((float *)this + 518);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 518);
      goto LABEL_10;
    case 1:
      if ( value )
        *value = *((float *)this + 519);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 519);
      goto LABEL_10;
    case 2:
      if ( value )
        *value = *((float *)this + 520);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 520);
      goto LABEL_10;
    case 3:
      if ( value )
        *value = *((float *)this + 521);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 521);
      goto LABEL_10;
    case 4:
      if ( value )
        *value = *((float *)this + 522);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 522);
      goto LABEL_10;
    case 5:
      if ( value )
        *value = *((float *)this + 523);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 523);
      goto LABEL_10;
    case 6:
      if ( value )
        *value = *((float *)this + 524);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 524);
      goto LABEL_10;
    case 7:
      if ( value )
        *value = *((float *)this + 525);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 525);
      goto LABEL_10;
    case 8:
      if ( value )
        *value = *((float *)this + 526);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 526);
      goto LABEL_10;
    case 9:
      if ( value )
        *value = *((float *)this + 527);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 527);
      goto LABEL_10;
    case 10:
      if ( value )
        *value = *((float *)this + 528);
      if ( !valuestr )
        goto LABEL_11;
      v4 = (int)*((float *)this + 528);
      goto LABEL_56;
    case 11:
      if ( value )
        *value = *((float *)this + 529);
      if ( !valuestr )
        goto LABEL_11;
      v4 = (int)*((float *)this + 529);
LABEL_56:
      sprintf(valuestr, "%d", v4);
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case 12:
      if ( value )
        *value = *((float *)this + 544);
      if ( !valuestr )
        goto LABEL_11;
      v5 = *((float *)this + 544);
LABEL_10:
      sprintf(valuestr, "%f", v5);
LABEL_11:
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    default:
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  return result;
}


// Address: 0x21d6910 | Name: _ZN4FMOD12DSPSfxReverb25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPSfxReverb::getParameterFloatInternal(
           (FMOD::DSPSfxReverb *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x21d6920 | Name: _ZN4FMOD12DSPSfxReverb29Calculate1stOrderLowpassCoeffEfffPf
__int64 __fastcall FMOD::DSPSfxReverb::Calculate1stOrderLowpassCoeff(
        FMOD::DSPSfxReverb *const this,
        float a2,
        float gain,
        float cutoff,
        float sampleRate,
        float *pK)
{
  float v7; // xmm0_4
  __m128 v8; // xmm1
  __m128 v9; // xmm2
  float v10; // xmm0_4
  float c; // [rsp+4h] [rbp-14h]
  float v12; // [rsp+Ch] [rbp-Ch]

  if ( a2 > 1.0 )
    goto LABEL_2;
  if ( a2 == 1.0 )
    goto LABEL_2;
  v12 = a2 * a2;
  c = (float)(a2 * a2) - 1.0;
  v7 = cosf((float)(gain * 6.2831855) / cutoff);
  v8 = (__m128)0x3F800000u;
  v8.m128_f32[0] = (float)(1.0 - (float)(v7 * v12)) + (float)(1.0 - (float)(v7 * v12));
  v9 = v8;
  v9.m128_f32[0] = (float)(v8.m128_f32[0] * v8.m128_f32[0]) - (float)((float)(4.0 * c) * c);
  v10 = (float)(fsqrt(COERCE_FLOAT(_mm_cmpge_ss(v9, (__m128)0LL).m128_u32[0] & v9.m128_i32[0])) - v8.m128_f32[0])
      / (float)(c + c);
  *pK = v10;
  if ( v10 < 0.0 )
  {
LABEL_2:
    *pK = 0.0;
    return 0;
  }
  if ( v10 <= 0.99000001 )
    return 0;
  *pK = 0.99000001;
  return 0;
}


// Address: 0x21d6a40 | Name: _ZN4FMOD12DSPSfxReverb10SetHighCutEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetHighCut(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float v2; // xmm3_4
  float HighCut; // xmm0_4
  int min; // xmm1_4
  bool result; // al
  float K[3]; // [rsp+Ch] [rbp-Ch] BYREF

  HighCut = pProps->HighCut;
  min = stru_2AD9180.intdesc.min;
  if ( stru_2AD9180.floatdesc.min > HighCut || (min = stru_2AD9180.intdesc.max, HighCut > stru_2AD9180.floatdesc.max) )
  {
    pProps->HighCut = *(float *)&min;
    HighCut = *(float *)&min;
  }
  *((float *)this + 527) = HighCut;
  result = FMOD::DSPSfxReverb::Calculate1stOrderLowpassCoeff(
             this,
             0.84139514,
             pProps->HighCut,
             (float)*((int *)this + 530),
             v2,
             K);
  *((float *)this + 140) = 1.0 - K[0];
  return result;
}


// Address: 0x21d6ac0 | Name: _ZN4FMOD12DSPSfxReverb23CalculateLowShelfCoeffsEfffPfS1_S1_S1_S1_
__int64 __fastcall FMOD::DSPSfxReverb::CalculateLowShelfCoeffs(
        FMOD::DSPSfxReverb *const this,
        float gain,
        float cutoff,
        float sampleRate,
        float *a0,
        float *a1,
        float *a2,
        float *b1,
        float *b2)
{
  float v13; // xmm0_4
  float v15; // xmm5_4
  float K; // [rsp+8h] [rbp-30h]

  K = tanf((float)(cutoff * 3.1415927) / sampleRate);
  v13 = expf(gain * 0.057564627);
  v15 = 1.0 / (float)((float)((float)((float)(K / v13) + 1.4142135) * (float)(K / v13)) + 1.0);
  *a0 = (float)((float)((float)(K + 1.4142135) * K) + 1.0) * v15;
  *a1 = (float)((float)((float)(K * K) - 1.0) * v15) + (float)((float)((float)(K * K) - 1.0) * v15);
  *a2 = (float)((float)((float)(K - 1.4142135) * K) + 1.0) * v15;
  *b1 = (float)((float)((float)((float)(K / v13) * (float)(K / v13)) - 1.0) * -2.0) * v15;
  *b2 = (float)-(float)((float)((float)((float)(K / v13) - 1.4142135) * (float)(K / v13)) + 1.0) * v15;
  return 0;
}


// Address: 0x21d6be0 | Name: _ZN4FMOD12DSPSfxReverb15SetLowShelfGainEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetLowShelfGain(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float LowShelfGain; // xmm0_4
  int min; // xmm1_4

  LowShelfGain = pProps->LowShelfGain;
  min = stru_2AD91E0.intdesc.min;
  if ( stru_2AD91E0.floatdesc.min > LowShelfGain
    || (min = stru_2AD91E0.intdesc.max, LowShelfGain > stru_2AD91E0.floatdesc.max) )
  {
    LODWORD(pProps->LowShelfGain) = min;
    LowShelfGain = *(float *)&min;
  }
  *((float *)this + 152) = LowShelfGain;
  return FMOD::DSPSfxReverb::CalculateLowShelfCoeffs(
           this,
           LowShelfGain,
           pProps->LowShelfFrequency,
           (float)*((int *)this + 530),
           (float *)this + 147,
           (float *)this + 148,
           (float *)this + 149,
           (float *)this + 150,
           (float *)this + 151);
}


// Address: 0x21d6c50 | Name: _ZN4FMOD12DSPSfxReverb24CalculateHighShelfCoeffsEfffPfS1_S1_S1_S1_
__int64 __fastcall FMOD::DSPSfxReverb::CalculateHighShelfCoeffs(
        FMOD::DSPSfxReverb *const this,
        float gain,
        float cutoff,
        float sampleRate,
        float *a0,
        float *a1,
        float *a2,
        float *b1,
        float *b2)
{
  float temp_a1; // [rsp+8h] [rbp-20h] BYREF
  float temp_b1[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  FMOD::DSPSfxReverb::CalculateLowShelfCoeffs(
    this,
    gain,
    (float)(0.5 * sampleRate) - cutoff,
    sampleRate,
    a0,
    &temp_a1,
    a2,
    temp_b1,
    b2);
  *(_DWORD *)a1 = LODWORD(temp_a1) ^ 0x80000000;
  *b1 = -temp_b1[0];
  return 0;
}


// Address: 0x21d6cb0 | Name: _ZN4FMOD12DSPSfxReverb15SetEarlyLateMixEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetEarlyLateMix(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float EarlyLateMix; // xmm0_4
  int min; // xmm1_4
  float WetLevel; // xmm1_4
  float v5; // xmm7_4
  float v6; // xmm2_4
  float v7; // xmm1_4
  float v8; // xmm0_4
  int v9; // ecx
  float v10; // xmm2_4
  float v11; // xmm1_4
  float *v12; // rax
  float v13; // xmm0_4
  float v14; // xmm1_4
  float v15; // xmm1_4

  EarlyLateMix = pProps->EarlyLateMix;
  min = stru_2AD9120.intdesc.min;
  if ( stru_2AD9120.floatdesc.min > EarlyLateMix
    || (min = stru_2AD9120.intdesc.max, EarlyLateMix > stru_2AD9120.floatdesc.max) )
  {
    LODWORD(pProps->EarlyLateMix) = min;
    EarlyLateMix = *(float *)&min;
  }
  *((float *)this + 528) = EarlyLateMix;
  WetLevel = pProps->WetLevel;
  v5 = 0.0;
  if ( WetLevel > -80.0 )
    v5 = powf(10.0, WetLevel / 20.0);
  v6 = pProps->EarlyLateMix / 100.0;
  v7 = 1.0 - v6;
  v8 = fsqrt(2.0 / (float)((float)(v6 * v6) + (float)(v7 * v7)));
  v9 = *((_DWORD *)this + 319);
  v10 = (float)(v6 * v8) * v5;
  *((float *)this + 303) = (float)((float)(v7 * v8) * v5) * 0.35355338;
  if ( v9 <= 0 )
  {
    v11 = 0.0;
  }
  else
  {
    v11 = 0.0;
    v12 = (float *)this;
    do
    {
      v13 = v12[266];
      ++v12;
      v11 = v11 + (float)(v13 * v13);
    }
    while ( v12 != (float *)((char *)this + 4 * (unsigned int)(v9 - 1) + 4) );
  }
  v14 = v11 / (float)v9;
  if ( v14 == 1.0 )
  {
    v15 = 1.0;
  }
  else
  {
    v15 = (float)(v14 / (float)(1.0 - v14)) + 1.0;
    if ( v15 <= 0.0 )
      goto LABEL_11;
  }
  v10 = v10 / fsqrt(v15);
LABEL_11:
  *((float *)this + 304) = 0.35355338 * v10;
  return 0;
}


// Address: 0x21d6ee0 | Name: _ZN4FMOD12DSPSfxReverb11SetWetLevelEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetWetLevel(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float WetLevel; // xmm0_4
  int min; // xmm1_4

  WetLevel = pProps->WetLevel;
  min = stru_2AD90C0.intdesc.min;
  if ( stru_2AD90C0.floatdesc.min > WetLevel || (min = stru_2AD90C0.intdesc.max, WetLevel > stru_2AD90C0.floatdesc.max) )
  {
    LODWORD(pProps->WetLevel) = min;
    WetLevel = *(float *)&min;
  }
  *((float *)this + 529) = WetLevel;
  return FMOD::DSPSfxReverb::SetEarlyLateMix(this, pProps);
}


// Address: 0x21d6f20 | Name: _ZN4FMOD12DSPSfxReverb12SetDecayTimeEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetDecayTime(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float DecayTime; // xmm0_4
  int min; // xmm1_4
  int v4; // eax
  float *v5; // rbx
  int v6; // ebp
  int v7; // r14d
  float v8; // xmm0_4
  float v9; // xmm0_4
  float attenuationDB; // [rsp+8h] [rbp-40h]
  float K[11]; // [rsp+1Ch] [rbp-2Ch] BYREF

  DecayTime = pProps->DecayTime;
  min = stru_2AD94E0.intdesc.min;
  if ( stru_2AD94E0.floatdesc.min > pProps->DecayTime
    || (min = stru_2AD94E0.intdesc.max, DecayTime > stru_2AD94E0.floatdesc.max) )
  {
    LODWORD(pProps->DecayTime) = min;
    DecayTime = *(float *)&min;
  }
  v4 = *((_DWORD *)this + 319);
  *((float *)this + 518) = DecayTime;
  if ( v4 <= 0 )
  {
    LOBYTE(v7) = 0;
  }
  else
  {
    v5 = (float *)this;
    v6 = 0;
    v7 = 0;
    do
    {
      v8 = pProps->DecayTime;
      if ( v8 != 0.0 )
      {
        attenuationDB = (float)(-60.0 / (float)(v8 / 1000.0)) * v5[336];
        v5[266] = powf(10.0, attenuationDB / 20.0);
        v9 = powf(
               10.0,
               (float)((float)((float)(-60.0
                                     / (float)((float)(pProps->HFDecayRatio / 100.0)
                                             * (float)(pProps->DecayTime / 1000.0)))
                             * v5[336])
                     - attenuationDB)
             / 20.0);
        v7 |= FMOD::DSPSfxReverb::Calculate1stOrderLowpassCoeff(
                this,
                v9,
                pProps->HFReference,
                (float)*((int *)this + 530),
                0.0,
                K);
        v5[155] = 1.0 - K[0];
      }
      ++v6;
      ++v5;
    }
    while ( *((_DWORD *)this + 319) > v6 );
  }
  FMOD::DSPSfxReverb::SetEarlyLateMix(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  return v7;
}


// Address: 0x21d70c0 | Name: _ZN4FMOD12DSPSfxReverb19SetDelayLineLengthsEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetDelayLineLengths(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float v2; // xmm5_4

  ASfxDsp::SetLateDelays((ASfxDsp *const)((char *)this + 528), 1.3200001, 0.0015, 1.47, (float)*((int *)this + 530), v2);
  return FMOD::DSPSfxReverb::SetDecayTime(this, pProps);
}


// Address: 0x21d7170 | Name: _ZN4FMOD12DSPSfxReverb15SetHFDecayRatioEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetHFDecayRatio(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float HFDecayRatio; // xmm0_4
  int min; // xmm1_4

  HFDecayRatio = pProps->HFDecayRatio;
  min = stru_2AD9360.intdesc.min;
  if ( stru_2AD9360.floatdesc.min > HFDecayRatio
    || (min = stru_2AD9360.intdesc.max, HFDecayRatio > stru_2AD9360.floatdesc.max) )
  {
    LODWORD(pProps->HFDecayRatio) = min;
    HFDecayRatio = *(float *)&min;
  }
  *((float *)this + 522) = HFDecayRatio;
  return FMOD::DSPSfxReverb::SetDecayTime(this, pProps);
}


// Address: 0x21d71b0 | Name: _ZN4FMOD12DSPSfxReverb12SetLateDelayEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetLateDelay(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float v2; // xmm4_4
  float LateDelay; // xmm0_4
  int min; // xmm1_4

  LateDelay = pProps->LateDelay;
  min = stru_2AD9420.intdesc.min;
  if ( stru_2AD9420.floatdesc.min > LateDelay
    || (min = stru_2AD9420.intdesc.max, LateDelay > stru_2AD9420.floatdesc.max) )
  {
    pProps->LateDelay = *(float *)&min;
    LateDelay = *(float *)&min;
  }
  *((float *)this + 520) = LateDelay;
  ASfxDsp::SetLate_EarlyLateDelayTaps(
    (ASfxDsp *const)((char *)this + 528),
    0.0187,
    1.29,
    (float)*((int *)this + 530),
    v2);
  return 0;
}


// Address: 0x21d7230 | Name: _ZN4FMOD12DSPSfxReverb13SetEarlyDelayEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetEarlyDelay(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float EarlyDelay; // xmm0_4
  int min; // xmm1_4
  int v4; // eax

  EarlyDelay = pProps->EarlyDelay;
  min = stru_2AD9480.intdesc.min;
  if ( stru_2AD9480.floatdesc.min > EarlyDelay
    || (min = stru_2AD9480.intdesc.max, EarlyDelay > stru_2AD9480.floatdesc.max) )
  {
    LODWORD(pProps->EarlyDelay) = min;
    EarlyDelay = *(float *)&min;
  }
  *((float *)this + 519) = EarlyDelay;
  *((float *)this + 422) = EarlyDelay * 0.001;
  v4 = (int)(float)((float)((float)*((int *)this + 530) * EarlyDelay) * 0.001);
  if ( !v4 )
    v4 = 1;
  *((_DWORD *)this + 431) = v4;
  FMOD::DSPSfxReverb::SetLateDelay(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  return 0;
}


// Address: 0x21d72c0 | Name: _ZN4FMOD12DSPSfxReverb12SetDiffusionEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetDiffusion(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float v2; // xmm0_4
  int min; // xmm1_4
  float v4; // xmm0_4
  float diffusion; // [rsp+Ch] [rbp-Ch]

  v2 = pProps->Diffusion;
  min = stru_2AD9300.intdesc.min;
  if ( stru_2AD9300.floatdesc.min > v2 || (min = stru_2AD9300.intdesc.max, v2 > stru_2AD9300.floatdesc.max) )
  {
    LODWORD(pProps->Diffusion) = min;
    v2 = *(float *)&min;
  }
  *((float *)this + 523) = v2;
  diffusion = (float)((float)(0.0099999998 * pProps->Diffusion) * 3.1415927) * 0.25;
  *((float *)this + 298) = tanf(diffusion);
  v4 = cosf(diffusion);
  *((float *)this + 313) = powf(v4, (float)*((int *)this + 516));
  return 0;
}


// Address: 0x21d7360 | Name: _ZN4FMOD12DSPSfxReverb10SetDensityEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetDensity(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float Density; // xmm0_4
  int min; // xmm1_4

  Density = pProps->Density;
  min = stru_2AD92A0.intdesc.min;
  if ( stru_2AD92A0.floatdesc.min > Density || (min = stru_2AD92A0.intdesc.max, Density > stru_2AD92A0.floatdesc.max) )
  {
    LODWORD(pProps->Density) = min;
    Density = *(float *)&min;
  }
  *((float *)this + 524) = Density;
  return FMOD::DSPSfxReverb::SetDelayLineLengths(this, pProps);
}


// Address: 0x21d73a0 | Name: _ZN4FMOD12DSPSfxReverb14SetHFReferenceEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetHFReference(FMOD::DSPSfxReverb *const this, FMOD_REVERB_PROPERTIES *pProps)
{
  float HFReference; // xmm0_4
  int min; // xmm1_4

  HFReference = pProps->HFReference;
  min = stru_2AD93C0.intdesc.min;
  if ( stru_2AD93C0.floatdesc.min > HFReference
    || (min = stru_2AD93C0.intdesc.max, HFReference > stru_2AD93C0.floatdesc.max) )
  {
    LODWORD(pProps->HFReference) = min;
    HFReference = *(float *)&min;
  }
  *((float *)this + 521) = HFReference;
  FMOD::DSPSfxReverb::SetDecayTime(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  return 0;
}


// Address: 0x21d73f0 | Name: _ZN4FMOD12DSPSfxReverb20SetLowShelfFrequencyEP22FMOD_REVERB_PROPERTIES
bool __fastcall FMOD::DSPSfxReverb::SetLowShelfFrequency(
        FMOD::DSPSfxReverb *const this,
        FMOD_REVERB_PROPERTIES *pProps)
{
  float LowShelfFrequency; // xmm0_4
  int min; // xmm1_4

  LowShelfFrequency = pProps->LowShelfFrequency;
  min = stru_2AD9240.intdesc.min;
  if ( stru_2AD9240.floatdesc.min > LowShelfFrequency
    || (min = stru_2AD9240.intdesc.max, LowShelfFrequency > stru_2AD9240.floatdesc.max) )
  {
    LODWORD(pProps->LowShelfFrequency) = min;
    LowShelfFrequency = *(float *)&min;
  }
  *((float *)this + 525) = LowShelfFrequency;
  FMOD::DSPSfxReverb::SetLowShelfGain(this, pProps);
  return 0;
}


// Address: 0x21d7430 | Name: _ZN4FMOD12DSPSfxReverb14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::createInternal(FMOD::DSPSfxReverb *const this)
{
  float v1; // xmm1_4
  FMOD_RESULT_0 result; // eax
  __int64 v3; // rax
  int v4; // esi
  __int64 v5; // rax
  __int64 v6; // r12
  int v7; // ebp
  __int64 v8; // rax
  __int64 v9; // rdx

  if ( this != (FMOD::DSPSfxReverb *const)-2120LL )
    *((_DWORD *)this + 530) = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  *((_DWORD *)this + 531) = 0;
  if ( ASfxDsp::init((ASfxDsp *const)((char *)this + 528), v1) )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v3 = *((_QWORD *)this + 22);
  v4 = *(_DWORD *)(v3 + 1704);
  *((_QWORD *)this + 69) = v3;
  if ( ASfxDsp::UpdateBufferSize((ASfxDsp *const)((char *)this + 528), v4) )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  *((_DWORD *)this + 319) = 8;
  *((_DWORD *)this + 516) = 3;
  ASfxDsp::ClearBuffers((ASfxDsp *const)((char *)this + 528));
  v5 = *((_QWORD *)this + 30);
  v6 = 0;
  v7 = 0;
  if ( *(int *)(v5 + 96) <= 0 )
  {
LABEL_10:
    v8 = *((_QWORD *)this + 271);
    *((_QWORD *)this + 259) = *((_QWORD *)this + 266);
    v9 = *((_QWORD *)this + 267);
    *((_QWORD *)this + 264) = v8;
    *((_QWORD *)this + 260) = v9;
    *((_QWORD *)this + 261) = *((_QWORD *)this + 268);
    *((_QWORD *)this + 262) = *((_QWORD *)this + 269);
    *((_QWORD *)this + 263) = *((_QWORD *)this + 270);
    FMOD::DSPSfxReverb::SetDecayTime(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
    FMOD::DSPSfxReverb::SetEarlyDelay(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
    FMOD::DSPSfxReverb::SetLateDelay(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
    FMOD::DSPSfxReverb::SetHFReference(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
    FMOD::DSPSfxReverb::SetHFDecayRatio(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
    FMOD::DSPSfxReverb::SetDiffusion(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
    FMOD::DSPSfxReverb::SetDensity(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
    FMOD::DSPSfxReverb::SetLowShelfFrequency(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
    FMOD::DSPSfxReverb::SetHighCut(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
    FMOD::DSPSfxReverb::SetWetLevel(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    while ( 1 )
    {
      result = (unsigned int)FMOD::DSPSfxReverb::setParameterFloatInternal(
                               (FMOD::DSPI *)this,
                               v7,
                               *(float *)(*(_QWORD *)(*(_QWORD *)(v5 + 104) + v6) + 56LL),
                               0);
      if ( result )
        break;
      v5 = *((_QWORD *)this + 30);
      ++v7;
      v6 += 8;
      if ( *(_DWORD *)(v5 + 96) <= v7 )
        goto LABEL_10;
    }
  }
  return result;
}


// Address: 0x21d75f0 | Name: _ZN4FMOD12DSPSfxReverb14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPSfxReverb::createInternal((FMOD::DSPSfxReverb *const)dsp_state->instance);
}


// Address: 0x21d7600 | Name: _ZN4FMOD12DSPSfxReverb15commandInternalEj
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::commandInternal(
        FMOD::DSPSfxReverb *const this,
        FMOD::FMOD_DSP_COMMAND_TYPE type)
{
  float v2; // xmm0_4
  float v3; // xmm0_4
  float v4; // xmm0_4
  float v5; // xmm0_4
  float v6; // xmm0_4
  float v7; // xmm0_4
  float v8; // xmm0_4
  float v9; // xmm0_4
  float v10; // xmm0_4
  float v11; // xmm0_4
  float v12; // xmm0_4
  float v13; // xmm0_4

  if ( type != 2 )
    return FMOD_RESULT::FMOD_OK_0;
  v2 = *((float *)this + 532);
  if ( v2 != *((float *)this + 518) )
  {
    *((float *)this + 518) = v2;
    FMOD::DSPSfxReverb::SetDecayTime(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v3 = *((float *)this + 533);
  if ( v3 != *((float *)this + 519) )
  {
    *((float *)this + 519) = v3;
    FMOD::DSPSfxReverb::SetEarlyDelay(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v4 = *((float *)this + 534);
  if ( v4 != *((float *)this + 520) )
  {
    *((float *)this + 520) = v4;
    FMOD::DSPSfxReverb::SetLateDelay(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v5 = *((float *)this + 535);
  if ( v5 != *((float *)this + 521) )
  {
    *((float *)this + 521) = v5;
    FMOD::DSPSfxReverb::SetHFReference(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v6 = *((float *)this + 536);
  if ( v6 != *((float *)this + 522) )
  {
    *((float *)this + 522) = v6;
    FMOD::DSPSfxReverb::SetHFDecayRatio(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v7 = *((float *)this + 537);
  if ( v7 != *((float *)this + 523) )
  {
    *((float *)this + 523) = v7;
    FMOD::DSPSfxReverb::SetDiffusion(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v8 = *((float *)this + 538);
  if ( v8 != *((float *)this + 524) )
  {
    *((float *)this + 524) = v8;
    FMOD::DSPSfxReverb::SetDensity(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v9 = *((float *)this + 539);
  if ( v9 != *((float *)this + 525) )
  {
    *((float *)this + 525) = v9;
    FMOD::DSPSfxReverb::SetLowShelfFrequency(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v10 = *((float *)this + 540);
  if ( v10 != *((float *)this + 526) )
  {
    *((float *)this + 526) = v10;
    FMOD::DSPSfxReverb::SetLowShelfGain(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v11 = *((float *)this + 541);
  if ( v11 != *((float *)this + 527) )
  {
    *((float *)this + 527) = v11;
    FMOD::DSPSfxReverb::SetHighCut(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v12 = *((float *)this + 542);
  if ( v12 != *((float *)this + 528) )
  {
    *((float *)this + 528) = v12;
    FMOD::DSPSfxReverb::SetEarlyLateMix(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  v13 = *((float *)this + 543);
  if ( v13 != *((float *)this + 529) )
  {
    *((float *)this + 529) = v13;
    FMOD::DSPSfxReverb::SetWetLevel(this, (FMOD_REVERB_PROPERTIES *)((char *)this + 2072));
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d78d0 | Name: _ZN4FMOD12DSPSfxReverb15commandCallbackEP14FMOD_DSP_STATEjPvS3_
FMOD_RESULT_0 __fastcall FMOD::DSPSfxReverb::commandCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *commanddata1,
        void *commanddata2)
{
  return FMOD::DSPSfxReverb::commandInternal((FMOD::DSPSfxReverb *const)dsp_state->instance, type);
}


