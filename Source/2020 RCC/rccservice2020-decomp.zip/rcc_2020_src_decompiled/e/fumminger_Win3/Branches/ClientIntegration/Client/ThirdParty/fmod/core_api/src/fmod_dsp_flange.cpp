// Address: 0x2201e30 | Name: _ZN4FMOD9DSPFlange16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPFlange::getDescriptionEx()
{
  memset(&stru_2ADC640, 0, sizeof(stru_2ADC640));
  FMOD_strcpy_safe(stru_2ADC640.name, "Mix", 16);
  FMOD_strcpy_safe(stru_2ADC640.label, "%", 16);
  *(_QWORD *)&stru_2ADC640.floatdesc.min = 0x42C8000000000000LL;
  stru_2ADC640.description = "Percentage of wet signal in mix.  0.0 to 100.0. Default = 50.0.";
  memset(&stru_2ADC5E0, 0, sizeof(stru_2ADC5E0));
  stru_2ADC640.intdesc.defaultval = 1112014848;
  stru_2ADC640.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2ADC5E0.name, "Depth", 16);
  FMOD_strcpy_safe(stru_2ADC5E0.label, (const char *)&uri_string, 16);
  stru_2ADC5E0.description = "Flange depth in ms.  0.01 to 1.0.  Default = 1.0.";
  memset(&stru_2ADC580, 0, sizeof(stru_2ADC580));
  stru_2ADC5E0.intdesc.defaultval = 1065353216;
  *(_QWORD *)&stru_2ADC5E0.floatdesc.min = 0x3F8000003C23D70ALL;
  stru_2ADC5E0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2ADC580.name, "Rate", 16);
  FMOD_strcpy_safe(stru_2ADC580.label, "Hz", 16);
  *(_QWORD *)&stru_2ADC580.floatdesc.min = 0x41A0000000000000LL;
  stru_2ADC580.intdesc.defaultval = 1036831949;
  stru_2ADC580.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2ADC580.description = "Flange speed in Hz.  0.0 to 20.0.  Default = 0.1.";
  *(&stru_2ADC540.mHandle + 1) = 8;
  stru_2ADC540.mSize = 33384;
  stru_2ADC540.mDescription = &stru_286B9A0;
  return &stru_2ADC540;
}


// Address: 0x2201fe0 | Name: _ZN4FMOD9DSPFlange15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::releaseInternal(FMOD::DSPFlange *const this)
{
  void *v1; // rsi

  v1 = (void *)*((_QWORD *)this + 69);
  if ( v1 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_dsp_flange.cpp", 192);
    *((_QWORD *)this + 70) = 0;
    *((_QWORD *)this + 69) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2202030 | Name: _ZN4FMOD9DSPFlange15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPFlange::releaseInternal((FMOD::DSPFlange *const)dsp_state->instance);
}


// Address: 0x2202040 | Name: _ZN4FMOD9DSPFlange13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::resetInternal(FMOD::DSPFlange *const this)
{
  void *v2; // rdi
  float v3; // xmm2_4
  float v4; // xmm2_4
  float v5; // xmm1_4
  float v6; // xmm3_4
  float v7; // xmm0_4
  float v8; // xmm2_4
  float v9; // xmm0_4

  *((_DWORD *)this + 145) = 0;
  *((_DWORD *)this + 144) = 0;
  v2 = (void *)*((_QWORD *)this + 70);
  if ( v2 )
    memset(v2, 0, *((unsigned int *)this + 143));
  v3 = *((float *)this + 8344);
  *((float *)this + 133) = v3;
  v4 = v3 * 0.0099999998;
  v5 = *((float *)this + 8343);
  *((float *)this + 132) = v5;
  v6 = *((float *)this + 8345);
  *((float *)this + 136) = v6;
  v7 = 1.0 - v4;
  *((float *)this + 134) = v4;
  v8 = (float)*((int *)this + 149);
  *((float *)this + 135) = v7;
  v9 = (float)((float)((float)(40.0 * v5) * v8) / 1000.0) * (float)(v5 * 0.5);
  if ( v9 >= 4.0 )
  {
    *((float *)this + 147) = v9;
  }
  else
  {
    *((_DWORD *)this + 147) = 1082130432;
    v9 = 4.0;
  }
  *((float *)this + 148) = v9;
  *((float *)this + 146) = v6 / v8;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2202140 | Name: _ZN4FMOD9DSPFlange14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::createInternal(FMOD::DSPFlange *const this)
{
  double v1; // xmm1_8
  float v2; // xmm0_4
  float *v3; // rbp
  int i; // ebx
  __int64 v5; // rax
  __int64 v6; // rbp
  int v7; // ebx
  FMOD_RESULT_0 result; // eax

  v2 = 1.0;
  v3 = (float *)((char *)this + 604);
  for ( i = 0; ; v2 = cosf((float)((float)i * 1.5707964) * 0.00012207031) )
  {
    ++i;
    *v3++ = v2;
    if ( i == 0x2000 )
      break;
  }
  if ( this != (FMOD::DSPFlange *const)-596LL )
    *((_DWORD *)this + 149) = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  v5 = *((_QWORD *)this + 30);
  v6 = 0;
  v7 = 0;
  *((_DWORD *)this + 150) = 0;
  *((_QWORD *)this + 70) = 0;
  *((_DWORD *)this + 142) = 0;
  *((_DWORD *)this + 143) = 0;
  if ( *(int *)(v5 + 96) > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v7,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v5 + 104) + v6) + 56LL),
                 v1);
      if ( result )
        break;
      v5 = *((_QWORD *)this + 30);
      ++v7;
      v6 += 8;
      if ( *(_DWORD *)(v5 + 96) <= v7 )
        goto LABEL_11;
    }
  }
  else
  {
LABEL_11:
    FMOD::DSPFlange::resetInternal(this);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2202240 | Name: _ZN4FMOD9DSPFlange14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPFlange::createInternal((FMOD::DSPFlange *const)dsp_state->instance);
}


// Address: 0x2202250 | Name: _ZN4FMOD9DSPFlange13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPFlange::resetInternal((FMOD::DSPFlange *const)dsp_state->instance);
}


// Address: 0x2202260 | Name: _ZN4FMOD9DSPFlange16reallocateBufferEv
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::reallocateBuffer(FMOD::DSPFlange *const this)
{
  void *v2; // rsi
  unsigned int v3; // ecx
  unsigned int v4; // ecx
  int v5; // esi
  FMOD::MemPool *gSystemMemPool; // rdi
  void *v7; // rdx
  FMOD_RESULT_0 result; // eax
  unsigned int blocksize[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  v2 = (void *)*((_QWORD *)this + 69);
  if ( v2 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v2, "../../../core_api/src/fmod_dsp_flange.cpp", 262);
    *((_QWORD *)this + 70) = 0;
    *((_QWORD *)this + 69) = 0;
  }
  FMOD::SystemI::getDSPBufferSize(*((FMOD::SystemI *const *)this + 22), blocksize, 0);
  v3 = 2;
  if ( (int)(float)((float)*((int *)this + 149) * 40.0) / 1000 / blocksize[0] + 1 > 1 )
    v3 = (int)(float)((float)*((int *)this + 149) * 40.0) / 1000 / blocksize[0] + 1;
  v4 = blocksize[0] * v3;
  v5 = v4 * 2 * *((_DWORD *)this + 150);
  gSystemMemPool = off_286F358->gSystemMemPool;
  *((_DWORD *)this + 142) = v4;
  *((_DWORD *)this + 143) = v5;
  v7 = FMOD::MemPool::calloc(gSystemMemPool, v5 + 16, "../../../core_api/src/fmod_dsp_flange.cpp", 285, 0);
  *((_QWORD *)this + 69) = v7;
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v7 )
  {
    *((_QWORD *)this + 70) = ((unsigned __int64)v7 + 15) & 0xFFFFFFFFFFFFFFF0LL;
    FMOD::DSPFlange::resetInternal(this);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2202370 | Name: _ZN4FMOD9DSPFlange12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::readInternal(
        FMOD::DSPFlange *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  int v6; // r10d
  FMOD_RESULT_0 result; // eax
  unsigned int v11; // r14d
  float v12; // xmm7_4
  float v13; // xmm2_4
  float v14; // xmm1_4
  float v15; // xmm3_4
  float v16; // xmm1_4
  float v17; // xmm0_4
  float v18; // xmm1_4
  __m128 v19; // xmm0
  __m128 v20; // xmm2
  int v21; // r15d
  unsigned int v22; // r11d
  __int64 v23; // r13
  __int64 v24; // r9
  float *v25; // rdx
  unsigned int v26; // eax
  __int64 v27; // rcx
  float v28; // xmm0_4
  float v29; // xmm10_4
  int v30; // edi
  int v31; // r9d
  float v32; // xmm2_4
  float v33; // xmm0_4
  float v34; // xmm1_4
  signed int v35; // eax
  int v36; // edx
  float v37; // xmm0_4
  float v38; // xmm0_4
  int v39; // r15d
  float v40; // xmm4_4
  __int64 v41; // rcx
  __int16 *v42; // rax
  __int64 v43; // rdx
  __int64 v44; // rcx
  float v45; // xmm0_4
  int v46; // r8d
  float v47; // xmm1_4
  float v48; // xmm0_4
  unsigned int length_remaining; // [rsp+Ch] [rbp-4Ch]

  v6 = inchannels;
  if ( *((_DWORD *)this + 150) == inchannels
    || (*((_DWORD *)this + 150) = inchannels,
        result = FMOD::DSPFlange::reallocateBuffer(this),
        v6 = inchannels,
        result == FMOD_RESULT::FMOD_OK_0) )
  {
    v11 = *((_DWORD *)this + 142);
    LODWORD(v12) = COERCE_INT((float)(int)v11) - 1;
    if ( !inbuffer )
      return FMOD_RESULT::FMOD_OK_0;
    v13 = *((float *)this + 8343);
    if ( v13 == *((float *)this + 132) )
    {
      v48 = *((float *)this + 8344);
      v18 = *((float *)this + 8345);
      if ( v48 == *((float *)this + 133) && v18 == *((float *)this + 136) )
      {
LABEL_7:
        if ( length )
        {
          do
          {
            v21 = *((_DWORD *)this + 144);
            length_remaining = 0;
            v22 = length + v21;
            if ( v11 < length + v21 )
            {
              v22 = v11;
              length_remaining = length - (v11 - v21);
              length = v11 - v21;
            }
            v23 = v6 * length;
            if ( (_DWORD)v23 )
            {
              v24 = *((_QWORD *)this + 70);
              v25 = inbuffer;
              v26 = v21 * v6;
              do
              {
                v27 = v26++;
                v28 = *v25++ * 16384.0;
                *(_WORD *)(v24 + 2 * v27) = (int)v28;
              }
              while ( v26 != (_DWORD)v23 + v21 * v6 );
            }
            if ( length )
            {
              v29 = (float)v21;
              v30 = 0;
              v31 = 0;
              do
              {
                v32 = *((float *)this + 147);
                v33 = *((float *)this + 148);
                if ( (float)(v32 - 0.015625) <= v33 )
                {
                  if ( v33 > (float)(v32 + 0.015625) )
                    v32 = v33 - 0.015625;
                }
                else
                {
                  v32 = v33 + 0.015625;
                }
                v34 = *((float *)this + 145);
                *((float *)this + 148) = v32;
                v35 = abs32((int)(float)(v34 * 32768.0)) & 0x7FFF;
                v36 = v35 >> 13;
                if ( v35 >> 13 == 2 )
                {
                  v37 = -*((float *)this + v35 - 16233);
                }
                else if ( v36 == 3 )
                {
                  v37 = *((float *)this + 0x7FFF - v35 + 151);
                }
                else if ( v36 == 1 )
                {
                  v37 = -*((float *)this + 0x3FFF - v35 + 151);
                }
                else
                {
                  v37 = *((float *)this + v35 + 151);
                }
                v38 = (float)((float)((float)((float)(v37 - 1.0) * 0.5) * v32) + v29) + (float)v31;
                if ( v38 < 0.0 )
                {
                  v38 = v38 + v12;
                }
                else if ( v38 > v12 )
                {
                  v38 = v38 - v12;
                }
                v39 = v30 + v6;
                v40 = v38 - (float)(int)v38;
                if ( v6 > 0 )
                {
                  v39 = v30 + v6;
                  v41 = v6 * (int)v38;
                  v42 = (__int16 *)(*((_QWORD *)this + 70) + 2 * v41);
                  v43 = (int)(v6 * (((int)v38 + 1) % v11)) - v41;
                  do
                  {
                    v44 = v30++;
                    v45 = (float)*v42;
                    v46 = v42[v43];
                    ++v42;
                    outbuffer[v44] = (float)((float)((float)((float)(v45 * 0.000061035156) * (float)(1.0 - v40))
                                                   + (float)((float)((float)v46 * 0.000061035156) * v40))
                                           * *((float *)this + 134))
                                   + (float)(inbuffer[v44] * *((float *)this + 135));
                  }
                  while ( v39 != v30 );
                  v34 = *((float *)this + 145);
                }
                v47 = v34 + *((float *)this + 146);
                if ( v47 > 1.0 )
                  v47 = v47 - 1.0;
                ++v31;
                *((float *)this + 145) = v47;
                v30 = v39;
              }
              while ( v31 != length );
            }
            *((_DWORD *)this + 144) = v22;
            inbuffer += v23;
            outbuffer += *outchannels * length;
            if ( v11 <= v22 )
              *((_DWORD *)this + 144) = 0;
            length = length_remaining;
          }
          while ( length_remaining );
        }
        return FMOD_RESULT::FMOD_OK_0;
      }
      *((float *)this + 132) = v13;
      v15 = (float)*((int *)this + 149);
      *((float *)this + 133) = v48;
      *((float *)this + 136) = v18;
      *((float *)this + 134) = 0.0099999998 * v48;
      *((float *)this + 135) = 1.0 - (float)(0.0099999998 * v48);
    }
    else
    {
      v14 = *((float *)this + 8344);
      v15 = (float)*((int *)this + 149);
      *((float *)this + 133) = v14;
      v16 = v14 * 0.0099999998;
      *((float *)this + 132) = v13;
      v17 = 1.0 - v16;
      *((float *)this + 134) = v16;
      v18 = *((float *)this + 8345);
      *((float *)this + 136) = v18;
      *((float *)this + 135) = v17;
      v19 = (__m128)0x42200000u;
      v19.m128_f32[0] = (float)((float)((float)(40.0 * v13) * v15) / 1000.0) * (float)(v13 * 0.5);
      v20 = _mm_cmplt_ss(v19, (__m128)0x40800000u);
      *((_DWORD *)this + 147) = _mm_andnot_ps(v20, v19).m128_u32[0] | v20.m128_i32[0] & 0x40800000;
    }
    *((float *)this + 146) = v18 / v15;
    goto LABEL_7;
  }
  return result;
}


// Address: 0x2202860 | Name: _ZN4FMOD9DSPFlange12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPFlange::readInternal(
           (FMOD::DSPFlange *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x2202870 | Name: _ZN4FMOD9DSPFlange25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPFlange::setParameterFloatInternal(
        FMOD::DSPFlange *const this,
        int index,
        float a3,
        float value)
{
  if ( index == 1 )
  {
    *((float *)this + 8343) = a3;
    return 0;
  }
  else if ( index == 2 )
  {
    *((float *)this + 8345) = a3;
    return 0;
  }
  else
  {
    if ( !index )
      *((float *)this + 8344) = a3;
    return 0;
  }
}


// Address: 0x22028c0 | Name: _ZN4FMOD9DSPFlange25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPFlange::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPFlange::setParameterFloatInternal((FMOD::DSPFlange *const)dsp_state->instance, index, a3, value);
}


// Address: 0x22028d0 | Name: _ZN4FMOD9DSPFlange25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::getParameterFloatInternal(
        FMOD::DSPFlange *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v5; // xmm0_4

  if ( index == 1 )
  {
    *value = *((float *)this + 8343);
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    v5 = *((float *)this + 8343);
  }
  else
  {
    if ( index != 2 )
    {
      if ( !index )
      {
        *value = *((float *)this + 8344);
        if ( valuestr )
        {
          sprintf(valuestr, "%.1f", *((float *)this + 8344));
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    *value = *((float *)this + 8345);
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    v5 = *((float *)this + 8345);
  }
  sprintf(valuestr, "%.02f", v5);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2202990 | Name: _ZN4FMOD9DSPFlange25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPFlange::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPFlange::getParameterFloatInternal((FMOD::DSPFlange *const)dsp_state->instance, index, value, valuestr);
}


