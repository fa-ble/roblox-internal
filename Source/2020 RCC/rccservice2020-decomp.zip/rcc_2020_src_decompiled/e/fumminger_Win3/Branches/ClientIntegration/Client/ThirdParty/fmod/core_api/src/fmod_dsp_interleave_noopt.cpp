// Address: 0x2251d80 | Name: FMOD_DSP_Deinterleave_NoOpt
void __fastcall FMOD_DSP_Deinterleave_NoOpt(
        float *inbuffer,
        float **outbuffer,
        int inchannels,
        int outchannels,
        unsigned int length)
{
  int v10; // edi
  unsigned __int64 v11; // rsi
  __int64 v12; // r8
  float **v13; // rdx
  unsigned int v14; // eax
  __int64 v15; // rcx
  int v16; // r10d
  unsigned __int64 v17; // rcx
  float *v18; // rdx
  __int64 v19; // r11
  float v20; // xmm1_4
  float *v21; // r8
  unsigned int v22; // eax
  __int64 v23; // r9
  float *v24; // rax
  float mixmatrix[32][32]; // [rsp+0h] [rbp-1038h] BYREF

  if ( inchannels == outchannels )
  {
    if ( length )
    {
      v10 = inchannels;
      v11 = 0;
      v12 = 4LL * (length - 1) + 4;
      do
      {
        if ( inchannels > 0 )
        {
          v13 = outbuffer;
          v14 = v10 - inchannels;
          do
          {
            v15 = v14++;
            (*v13++)[v11 / 4] = inbuffer[v15];
          }
          while ( v10 != v14 );
        }
        v11 += 4LL;
        v10 += inchannels;
      }
      while ( v11 != v12 );
    }
  }
  else
  {
    memset(mixmatrix, 0, 128LL * outchannels);
    FMOD::DSPConnectionI::getDefaultMatrix(mixmatrix, 0, outchannels, inchannels, 1.0);
    if ( length )
    {
      v16 = inchannels;
      v17 = 0;
      do
      {
        if ( outchannels > 0 )
        {
          v18 = mixmatrix[0];
          v19 = 0;
          do
          {
            if ( inchannels <= 0 )
            {
              v20 = 0.0;
            }
            else
            {
              v20 = 0.0;
              v21 = v18;
              v22 = v16 - inchannels;
              do
              {
                v23 = v22++;
                v20 = v20 + (float)(inbuffer[v23] * *v21++);
              }
              while ( v16 != v22 );
            }
            v24 = outbuffer[v19++];
            v18 += 32;
            v24[v17 / 4] = v20;
          }
          while ( outchannels > (int)v19 );
        }
        v17 += 4LL;
        v16 += inchannels;
      }
      while ( v17 != 4LL * (length - 1) + 4 );
    }
  }
}


// Address: 0x2251ec0 | Name: FMOD_DSP_Interleave_NoOpt
void __fastcall FMOD_DSP_Interleave_NoOpt(float **inbuffer, float *outbuffer, int channels, unsigned int length)
{
  int v4; // r10d
  __int64 v5; // r9
  __int64 v6; // r11
  float **v7; // rcx
  unsigned int v8; // eax
  __int64 v9; // r8
  float v10; // xmm0_4
  __int64 v11; // r8

  if ( length )
  {
    v4 = channels;
    v5 = 0;
    v6 = 4LL * (length - 1) + 4;
    do
    {
      if ( channels > 0 )
      {
        v7 = inbuffer;
        v8 = v4 - channels;
        do
        {
          v9 = (__int64)*v7++;
          v10 = *(float *)(v9 + v5);
          v11 = v8++;
          outbuffer[v11] = v10;
        }
        while ( v4 != v8 );
      }
      v5 += 4;
      v4 += channels;
    }
    while ( v5 != v6 );
  }
}


