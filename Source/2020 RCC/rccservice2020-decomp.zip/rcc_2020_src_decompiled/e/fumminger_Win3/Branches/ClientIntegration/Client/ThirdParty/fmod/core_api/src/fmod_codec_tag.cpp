// Address: 0x21f2480 | Name: _ZN4FMOD8CodecTag16getDescriptionExEv
FMOD::FMOD_CODEC_DESCRIPTION_EX *__cdecl FMOD::CodecTag::getDescriptionEx()
{
  stru_2ADBA00.version = 65792;
  stru_2ADBA00.timeunits = 2;
  stru_2ADBA00.mType = 1000;
  stru_2ADBA00.mSize = 416;
  stru_2ADBA00.name = "FMOD Tag Reader Codec";
  stru_2ADBA00.open = FMOD::CodecTag::openInternal;
  return &stru_2ADBA00;
}


// Address: 0x21f24d0 | Name: _ZN4FMOD8CodecTag9readID3v1Ev
FMOD_RESULT_0 __fastcall FMOD::CodecTag::readID3v1(FMOD::CodecTag *const this)
{
  __int64 v1; // rax
  __int64 v3; // rdx
  FMOD::File *mFile; // rdi
  char *v5; // rax
  FMOD_RESULT_0 v6; // ebp
  __int64 v8; // rax
  __int64 v9; // rdx
  FMOD::File *v10; // rdi
  char *v11; // rax
  __int64 v12; // rax
  __int64 v13; // rdx
  FMOD::File *v14; // rdi
  char *v15; // rax
  int v16; // eax
  int v17; // eax
  int v18; // eax
  int v19; // eax
  int v20; // eax
  int v21; // eax
  int v22; // eax
  unsigned int itemsread; // [rsp+1Ch] [rbp-5Ch] BYREF
  char tmp[16]; // [rsp+20h] [rbp-58h] BYREF
  char value[72]; // [rsp+30h] [rbp-48h] BYREF

  LODWORD(v1) = 0;
  do
  {
    v3 = (unsigned int)v1;
    v1 = (unsigned int)(v1 + 8);
    *(_QWORD *)&value[v3] = 0;
  }
  while ( (unsigned int)v1 < 0x18 );
  mFile = this->mFile;
  v5 = &value[v1];
  *(_DWORD *)v5 = 0;
  v5[6] = 0;
  *((_WORD *)v5 + 2) = 0;
  v6 = FMOD::File::read(mFile, value, 1u, 0x1Eu, &itemsread);
  if ( v6 == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( itemsread != 30 )
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    if ( FMOD_strlen(value) )
    {
      v20 = FMOD_strlen(value);
      FMOD::Codec::metaData(
        this,
        FMOD_TAGTYPE::FMOD_TAGTYPE_ID3V1,
        "TITLE",
        value,
        v20 + 1,
        FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
        0);
    }
    LODWORD(v8) = 0;
    do
    {
      v9 = (unsigned int)v8;
      v8 = (unsigned int)(v8 + 8);
      *(_QWORD *)&value[v9] = 0;
    }
    while ( (unsigned int)v8 < 0x18 );
    v10 = this->mFile;
    v11 = &value[v8];
    *((_WORD *)v11 + 2) = 0;
    *(_DWORD *)v11 = 0;
    v11[6] = 0;
    v6 = FMOD::File::read(v10, value, 1u, 0x1Eu, &itemsread);
    if ( v6 == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( itemsread != 30 )
        return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
      if ( FMOD_strlen(value) )
      {
        v21 = FMOD_strlen(value);
        FMOD::Codec::metaData(
          this,
          FMOD_TAGTYPE::FMOD_TAGTYPE_ID3V1,
          "ARTIST",
          value,
          v21 + 1,
          FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
          0);
      }
      LODWORD(v12) = 0;
      do
      {
        v13 = (unsigned int)v12;
        v12 = (unsigned int)(v12 + 8);
        *(_QWORD *)&value[v13] = 0;
      }
      while ( (unsigned int)v12 < 0x18 );
      v14 = this->mFile;
      v15 = &value[v12];
      *(_DWORD *)v15 = 0;
      *((_WORD *)v15 + 2) = 0;
      v15[6] = 0;
      v6 = FMOD::File::read(v14, value, 1u, 0x1Eu, &itemsread);
      if ( v6 == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( itemsread != 30 )
          return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
        if ( FMOD_strlen(value) )
        {
          v22 = FMOD_strlen(value);
          FMOD::Codec::metaData(
            this,
            FMOD_TAGTYPE::FMOD_TAGTYPE_ID3V1,
            "ALBUM",
            value,
            v22 + 1,
            FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
            0);
        }
        memset(value, 0, 0x1Fu);
        v6 = FMOD::File::read(this->mFile, value, 1u, 4u, &itemsread);
        if ( v6 == FMOD_RESULT::FMOD_OK_0 )
        {
          if ( itemsread != 4 )
            return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
          if ( FMOD_strlen(value) )
          {
            v16 = FMOD_strlen(value);
            FMOD::Codec::metaData(
              this,
              FMOD_TAGTYPE::FMOD_TAGTYPE_ID3V1,
              "YEAR",
              value,
              v16 + 1,
              FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
              0);
          }
          memset(value, 0, 0x1Fu);
          v6 = FMOD::File::read(this->mFile, value, 1u, 0x1Eu, &itemsread);
          if ( v6 == FMOD_RESULT::FMOD_OK_0 )
          {
            if ( itemsread != 30 )
              return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
            if ( FMOD_strlen(value) )
            {
              v17 = FMOD_strlen(value);
              FMOD::Codec::metaData(
                this,
                FMOD_TAGTYPE::FMOD_TAGTYPE_ID3V1,
                "COMMENT",
                value,
                v17 + 1,
                FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                0);
            }
            if ( !value[28] && value[29] )
            {
              sprintf(tmp, "%d", (unsigned __int8)value[29]);
              v18 = FMOD_strlen(tmp);
              FMOD::Codec::metaData(
                this,
                FMOD_TAGTYPE::FMOD_TAGTYPE_ID3V1,
                "TRACK",
                tmp,
                v18 + 1,
                FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                0);
            }
            memset(value, 0, 0x1Fu);
            v6 = FMOD::File::read(this->mFile, value, 1u, 1u, &itemsread);
            if ( v6 == FMOD_RESULT::FMOD_OK_0 )
            {
              if ( itemsread == 1 )
              {
                sprintf(tmp, "%d", (unsigned __int8)value[0]);
                v19 = FMOD_strlen(tmp);
                FMOD::Codec::metaData(
                  this,
                  FMOD_TAGTYPE::FMOD_TAGTYPE_ID3V1,
                  "GENRE",
                  tmp,
                  v19 + 1,
                  FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING,
                  0);
                return v6;
              }
              return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
            }
          }
        }
      }
    }
  }
  return v6;
}


// Address: 0x21f28a0 | Name: _ZN4FMOD8CodecTag9readID3v2Ev
FMOD_RESULT_0 __fastcall FMOD::CodecTag::readID3v2(FMOD::CodecTag *const this)
{
  FMOD_RESULT_0 result; // eax
  unsigned int v3; // r13d
  int v4; // r12d
  unsigned int v5; // r14d
  FMOD::File *mFile; // rdi
  int v7; // r10d
  int v8; // eax
  unsigned int v9; // r13d
  unsigned int v10; // r12d
  unsigned __int8 *v11; // rax
  unsigned __int8 *v12; // r15
  FMOD::File *v13; // rdi
  FMOD_TAGDATATYPE v14; // r9d
  __int64 v15; // rdx
  size_t v16; // r12
  unsigned int tagoff; // [rsp+14h] [rbp-84h]
  int wavdatapos; // [rsp+28h] [rbp-70h]
  FMOD_TAGDATATYPE datatype; // [rsp+2Ch] [rbp-6Ch]
  unsigned __int8 flags; // [rsp+3Bh] [rbp-5Dh] BYREF
  unsigned __int16 version; // [rsp+3Ch] [rbp-5Ch] BYREF
  unsigned __int16 tagdataflags; // [rsp+3Eh] [rbp-5Ah] BYREF
  unsigned __int8 size[8]; // [rsp+40h] [rbp-58h] BYREF
  unsigned int filepos; // [rsp+48h] [rbp-50h] BYREF
  unsigned int itemsread; // [rsp+4Ch] [rbp-4Ch] BYREF
  char tagdataid[72]; // [rsp+50h] [rbp-48h] BYREF

  result = FMOD::File::tell(this->mFile, &filepos);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v3 = filepos;
    result = FMOD::File::read(this->mFile, &version, 1u, 2u, &itemsread);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( itemsread != 2 )
        return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
      result = FMOD::File::read(this->mFile, &flags, 1u, 1u, &itemsread);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( itemsread != 1 )
          return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
        result = FMOD::File::read(this->mFile, size, 1u, 4u, &itemsread);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          if ( itemsread != 4 )
            return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
          tagoff = 10;
          v4 = (size[2] << 7) + (size[0] << 21) + (size[1] << 14) + size[3];
          if ( (flags & 0x10) != 0 )
            v4 += 10;
          v5 = v4;
          wavdatapos = v4 + v3 + 7;
          while ( 1 )
          {
            tagdataid[4] = 0;
            tagdataid[3] = 0;
            tagdataid[2] = 0;
            tagdataid[1] = 0;
            tagdataid[0] = 0;
            mFile = this->mFile;
            if ( version <= 2u )
            {
              result = FMOD::File::read(mFile, tagdataid, 3u, 1u, &itemsread);
              if ( result )
                return result;
              if ( itemsread != 1 )
                return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
              result = FMOD::File::read(this->mFile, size, 3u, 1u, &itemsread);
              if ( result )
                return result;
              if ( itemsread != 1 )
                return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
              v9 = size[2] | (size[1] << 8) | (size[0] << 16);
            }
            else
            {
              result = FMOD::File::read(mFile, tagdataid, 4u, 1u, &itemsread);
              if ( result )
                return result;
              if ( itemsread != 1 )
                return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
              result = FMOD::File::read(this->mFile, size, 4u, 1u, &itemsread);
              if ( result )
                return result;
              if ( itemsread != 1 )
                return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
              result = FMOD::File::read(this->mFile, &tagdataflags, 2u, 1u, &itemsread);
              if ( result )
                return result;
              if ( itemsread != 1 )
                return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
              if ( version == 3 )
              {
                v7 = (size[0] << 24) + (size[1] << 16) + size[3];
                v8 = size[2] << 8;
              }
              else
              {
                v7 = (size[0] << 21) + (size[1] << 14) + size[3];
                v8 = size[2] << 7;
              }
              v9 = v7 + v8;
            }
            if ( (unsigned __int8)(tagdataid[0] - 32) > 0x5Fu && tagdataid[0]
              || (unsigned __int8)(tagdataid[1] - 32) > 0x5Fu && tagdataid[1]
              || (unsigned __int8)(tagdataid[2] - 32) > 0x5Fu && tagdataid[2]
              || (unsigned __int8)(tagdataid[3] - 32) > 0x5Fu && tagdataid[3] )
            {
              if ( v9 )
                goto LABEL_33;
            }
            else if ( v9 )
            {
              if ( v9 <= 0xFFFFF )
              {
                v10 = v9;
                v11 = (unsigned __int8 *)FMOD::MemPool::alloc(
                                           off_286F358->gSystemMemPool,
                                           v9,
                                           "../../../core_api/src/fmod_codec_tag.cpp",
                                           637,
                                           0,
                                           0);
                v12 = v11;
                v13 = this->mFile;
                if ( !v11 )
                {
                  FMOD::File::seek(v13, wavdatapos, 0);
                  return FMOD_RESULT::FMOD_ERR_MEMORY_0;
                }
                result = FMOD::File::read(v13, v11, 1u, v9, &itemsread);
                if ( result )
                  return result;
                if ( itemsread != v9 )
                {
                  FMOD::MemPool::free(off_286F358->gSystemMemPool, v12, "../../../core_api/src/fmod_codec_tag.cpp", 650);
                  return FMOD_RESULT::FMOD_OK_0;
                }
                v14 = FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_BINARY;
                if ( tagdataid[0] == 84 )
                {
                  v15 = *v12;
                  if ( (unsigned __int8)v15 <= 3u )
                    v14 = dword_5963B0[v15];
                  v16 = itemsread - 1;
                  datatype = v14;
                  memmove(v12, v12 + 1, v16);
                  v12[v16] = 0;
                  v14 = datatype;
                  v10 = v9 - 1;
                }
                FMOD::Codec::metaData(this, FMOD_TAGTYPE::FMOD_TAGTYPE_ID3V2, tagdataid, v12, v10, v14, 0);
                FMOD::MemPool::free(off_286F358->gSystemMemPool, v12, "../../../core_api/src/fmod_codec_tag.cpp", 688);
                goto LABEL_15;
              }
LABEL_33:
              result = FMOD::File::seek(this->mFile, v9, 1);
              if ( result )
                return result;
            }
LABEL_15:
            tagoff += v9 + 10;
            if ( v5 <= tagoff )
              return FMOD::File::seek(this->mFile, wavdatapos, 0);
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21f2d80 | Name: _ZN4FMOD8CodecTag19readID3v2FromFooterEv
FMOD_RESULT_0 __fastcall FMOD::CodecTag::readID3v2FromFooter(FMOD::CodecTag *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD::File *mFile; // rdi
  int v4; // eax
  int v5; // ebp
  unsigned __int8 flags; // [rsp+Dh] [rbp-2Bh] BYREF
  unsigned __int16 version; // [rsp+Eh] [rbp-2Ah] BYREF
  char size[8]; // [rsp+10h] [rbp-28h] BYREF
  unsigned int itemsread; // [rsp+18h] [rbp-20h] BYREF
  unsigned int filepos[7]; // [rsp+1Ch] [rbp-1Ch] BYREF

  result = FMOD::File::read(this->mFile, &version, 1u, 2u, &itemsread);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( itemsread != 2 )
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    result = FMOD::File::read(this->mFile, &flags, 1u, 1u, &itemsread);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( itemsread != 1 )
        return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
      result = FMOD::File::read(this->mFile, size, 1u, 4u, &itemsread);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( itemsread != 4 )
          return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
        mFile = this->mFile;
        v4 = size[3] + (size[1] << 14) + (size[0] << 21) + (size[2] << 7);
        if ( (flags & 0x10) != 0 )
          v4 += 10;
        result = FMOD::File::seek(mFile, 3 - v4, 1);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = FMOD::File::tell(this->mFile, filepos);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            v5 = filepos[0] - 3;
            result = FMOD::CodecTag::readID3v2(this);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
              return FMOD::File::seek(this->mFile, v5, 0);
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21f2eb0 | Name: _ZN4FMOD8CodecTag8readTagsEv
FMOD_RESULT_0 __fastcall FMOD::CodecTag::readTags(FMOD::CodecTag *const this)
{
  unsigned int i; // r13d
  FMOD_RESULT_0 result; // eax
  unsigned int v4; // ebp
  unsigned int j; // r14d
  int v6; // eax
  FMOD::File *mFile; // rdi
  unsigned int filepos; // [rsp+8h] [rbp-50h] BYREF
  unsigned int itemsread; // [rsp+Ch] [rbp-4Ch] BYREF
  char header[72]; // [rsp+10h] [rbp-48h] BYREF

  for ( i = 0; ; i = v4 )
  {
    v4 = i - 128;
    if ( FMOD::File::seek(this->mFile, i - 128, 2) )
      break;
    result = FMOD::File::read(this->mFile, header, 1u, 3u, &itemsread);
    if ( result )
      return result;
    if ( itemsread != 3 )
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    if ( FMOD_strncmp(header, "TAG", 3) )
    {
      result = FMOD::File::seek(this->mFile, i - 10, 2);
      if ( result )
      {
        if ( result != FMOD_RESULT::FMOD_ERR_FILE_COULDNOTSEEK_0 )
          return result;
        break;
      }
      result = FMOD::File::read(this->mFile, header, 1u, 3u, &itemsread);
      if ( result )
        return result;
      if ( itemsread != 3 )
        return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
      if ( FMOD_strncmp(header, "3DI", 3) )
        break;
      result = FMOD::CodecTag::readID3v2FromFooter(this);
      if ( result )
        return result;
      result = FMOD::File::tell(this->mFile, &filepos);
      if ( result )
        return result;
      v4 = filepos;
    }
    else
    {
      result = FMOD::CodecTag::readID3v1(this);
      if ( result )
        return result;
      result = FMOD::File::tell(this->mFile, &filepos);
      if ( result )
        return result;
      if ( filepos <= 0x80 )
        break;
    }
  }
  result = FMOD::File::seek(this->mFile, 0, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    for ( j = 0; ; j = filepos )
    {
      result = FMOD::File::read(this->mFile, header, 1u, 0x10u, &itemsread);
      if ( result )
        break;
      if ( itemsread != 16 )
        return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
      if ( FMOD_strncmp(header, "TAG", 3) )
      {
        v6 = FMOD_strncmp(header, "ID3", 3);
        mFile = this->mFile;
        if ( v6 )
          return FMOD::File::seek(mFile, j, 0);
        result = FMOD::File::seek(mFile, -13, 1);
        if ( result )
          return result;
        result = FMOD::CodecTag::readID3v2(this);
        if ( result )
          return result;
      }
      else
      {
        result = FMOD::File::seek(this->mFile, -13, 1);
        if ( result )
          return result;
        result = FMOD::CodecTag::readID3v1(this);
        if ( result )
          return result;
      }
      result = FMOD::File::tell(this->mFile, &filepos);
      if ( result )
        return result;
    }
  }
  return result;
}


// Address: 0x21f3140 | Name: _ZN4FMOD8CodecTag12openInternalEjP22FMOD_CREATESOUNDEXINFO
FMOD_RESULT_0 __fastcall FMOD::CodecTag::openInternal(
        FMOD::CodecTag *const this,
        FMOD_MODE usermode,
        FMOD_CREATESOUNDEXINFO *userexinfo)
{
  FMOD_RESULT_0 result; // eax
  unsigned int startoffset; // [rsp+8h] [rbp-10h] BYREF
  unsigned int filepos[3]; // [rsp+Ch] [rbp-Ch] BYREF

  this->mType = 1000;
  this->mDecoder = 0;
  this->mDecoderContext = 0;
  this->mDecoderContextMemory = 0;
  this->mPCMBufferMemory = 0;
  this->fileread = (FMOD_FILE_READ_CALLBACK)FMOD::Codec::defaultFileRead;
  this->mWaveFormatMemory = 0;
  this->mMetadata = 0;
  this->numsubsounds = 0;
  this->waveformat = 0;
  this->fileseek = (FMOD_FILE_SEEK_CALLBACK)FMOD::Codec::defaultFileSeek;
  this->waveformatversion = 3;
  this->metadata = FMOD::Codec::defaultMetaData;
  if ( FMOD::CodecTag::readTags(this) )
    return FMOD::File::seek(this->mFile, 0, 0);
  result = FMOD::File::tell(this->mFile, filepos);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD::File::getStartOffset(this->mFile, &startoffset);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::File::setStartOffset(this->mFile, startoffset + filepos[0]);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        return FMOD::File::seek(this->mFile, 0, 0);
    }
  }
  return result;
}


// Address: 0x21f3240 | Name: j__ZN4FMOD8CodecTag12openInternalEjP22FMOD_CREATESOUNDEXINFO
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecTag::openInternal(
        FMOD_CODEC_STATE *codec,
        FMOD_MODE usermode,
        FMOD_CREATESOUNDEXINFO *userexinfo)
{
  return _ZN4FMOD8CodecTag12openInternalEjP22FMOD_CREATESOUNDEXINFO((FMOD::CodecTag *const)codec, usermode, userexinfo);
}


