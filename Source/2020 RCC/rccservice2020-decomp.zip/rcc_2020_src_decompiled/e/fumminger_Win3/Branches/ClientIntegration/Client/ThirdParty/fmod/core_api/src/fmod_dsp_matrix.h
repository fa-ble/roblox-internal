// Address: 0x21b3130 | Name: _ZN4FMOD8ChannelIC2Ev
void __fastcall FMOD::ChannelI::ChannelI(FMOD::ChannelI *const this)
{
  this->mMixMatrix.mInChannels = 0;
  this->mMixMatrix.mData = 0;
  this->mGainModifierHead.mNodePrev = &this->mGainModifierHead;
  this->mGainModifierHead.FMOD::ChannelControlI::mNodeNext = &this->mGainModifierHead;
  this->mMixMatrix.mOutChannels = 0;
  this->mGainModifierHead.mNodeData = 0;
  this->mVolume = 1.0;
  this->mNodePrev = &this->FMOD::LinkedListNode;
  this->mNodeNext = &this->FMOD::LinkedListNode;
  this->mSoundGroupFadeVolume = 1.0;
  this->mNodeData = 0;
  this->mSortedListNode.mNodeData = 0;
  this->mSortedListNode.mNodePriority = -1;
  this->mSoundGroupSortedListNode.mNodeData = 0;
  this->mSoundGroupSortedListNode.mNodePriority = -1;
  this->_vptr_ChannelControlI = (int (**)(...))&off_29B0A70;
  this->mChannelGroupNode.mNodeData = 0;
  this->mSystem = 0;
  this->mHandleCurrent = 0;
  this->mSortedListNode.mNodePrev = &this->mSortedListNode;
  this->mSortedListNode.mNodeNext = &this->mSortedListNode;
  this->mHandleOriginal = 0;
  this->mRealChannel = 0;
  this->mSoundGroupSortedListNode.mNodePrev = &this->mSoundGroupSortedListNode;
  this->mSoundGroupSortedListNode.mNodeNext = &this->mSoundGroupSortedListNode;
  this->mPriority = 128;
  this->mListPosition = -1;
  this->mChannelGroupNode.mNodePrev = &this->mChannelGroupNode;
  this->mChannelGroupNode.mNodeNext = &this->mChannelGroupNode;
  this->mIndex = 0;
  this->mDSP = 0;
  this->mSoundGroupFadeTarget = 1.0;
  this->mPitch = 1.0;
  this->mFrequency = 44100.0;
  this->mMaxDistance = 1000000000.0;
  this->mVolume3D = 1.0;
  this->mRolloffPoint = 0;
  this->mPitch3D = 1.0;
  this->mNumRolloffPoints = 0;
  this->mConeVolume3D = 1.0;
  this->mFlags = 0;
  this->mDirectOcclusion = 0.0;
  this->mDistanceFilterCentreFreq = 1500.0;
  this->mPosition3D.x = 0.0;
  this->mDelayClockStart = 0;
  this->mPosition3D.y = 0.0;
  this->mDelayClockEnd = 0;
  this->mPosition3D.z = 0.0;
  this->mDelayClockStopChannels = 0;
  this->mVelocity3D.x = 0.0;
  this->mVelocity3D.y = 0.0;
  this->mVelocity3D.z = 0.0;
  this->mMinDistance = 1.0;
  this->mLowPassGain = 1.0;
  this->mDistanceFilterCustomLevel = 0.0;
  FMOD::ChannelControlI::setCallback(this, 0);
}


// Address: 0x21e4eb0 | Name: _ZN4FMOD13ChannelGroupIC2Ev
void __fastcall FMOD::ChannelGroupI::ChannelGroupI(FMOD::ChannelGroupI *const this)
{
  this->mMixMatrix.mInChannels = 0;
  this->mGainModifierHead.mNodePrev = &this->mGainModifierHead;
  this->mGainModifierHead.mNodeNext = &this->mGainModifierHead;
  this->mRealVolume = 1.0;
  this->mMixMatrix.mData = 0;
  this->mVolume = 1.0;
  this->mMixMatrix.mOutChannels = 0;
  this->mRealPitch = 1.0;
  this->mGainModifierHead.mNodeData = 0;
  this->mPitch = 1.0;
  this->mNode.mNodeData = 0;
  this->mAudibility = 1.0;
  this->_vptr_ChannelControlI = (int (**)(...))&off_29B1210;
  this->mGroupHead.mNodeData = 0;
  this->mNode.mNodePrev = &this->mNode;
  this->mNode.mNodeNext = &this->mNode;
  this->mChannelHead.mNodeData = 0;
  this->mSystemUpdateListNode.mNodeData = 0;
  this->mGroupHead.mNodePrev = &this->mGroupHead;
  this->mGroupHead.mNodeNext = &this->mGroupHead;
  this->mGeometryTask.mNodeData = 0;
  this->mMagic = -899895835;
  this->mChannelHead.mNodePrev = &this->mChannelHead;
  this->mChannelHead.mNodeNext = &this->mChannelHead;
  this->mFlags = 0;
  this->mPortId = -1;
  this->mSystemUpdateListNode.mNodePrev = &this->mSystemUpdateListNode;
  this->mSystemUpdateListNode.mNodeNext = &this->mSystemUpdateListNode;
  this->mPortPassthru = 0;
  this->mGeometryTask.mNodePrev = &this->mGeometryTask;
  this->mGeometryTask.mNodeNext = &this->mGeometryTask;
  this->mDSPDirectVolume = 1.0;
  this->mDSPReturn = 0;
  this->mDSPSendVolume = 0.0;
  this->mDSPHead = 0;
  this->mDSPTail = 0;
  this->mDSPFader = 0;
  this->mVolume3D = 1.0;
  this->mDSP = 0;
  this->mConeVolume3D = 1.0;
  this->mPitch3D = 1.0;
  this->mMaxDistance = 10000.0;
  this->mDirectOcclusion = 0.0;
  this->mRolloffPoint = 0;
  this->mReverbOcclusion = 0.0;
  this->mNumRolloffPoints = 0;
  this->mRealDirectOcclusionVolume = 1.0;
  this->mRealReverbOcclusionVolume = 1.0;
  this->mMinDistance = 1.0;
  this->mDistance = 0.0;
  this->mConeInsideAngle = 360.0;
  this->mConeOutsideAngle = 360.0;
  this->mConeOutsideVolume = 1.0;
  this->mConeOrientation.x = 0.0;
  this->mConeOrientation.y = 0.0;
  this->mConeOrientation.z = 1.0;
  this->m3DLevel = 1.0;
  this->m3DDopplerLevel = 1.0;
  this->mAngleToListener = 0.0;
}


