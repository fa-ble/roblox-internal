// Address: 0x2220360 | Name: _ZN4FMOD13PluginFactory9setSystemEPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::setSystem(FMOD::PluginFactory *const this, FMOD::SystemI *system)
{
  this->mSystem = system;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2220370 | Name: _ZN4FMOD13PluginFactory9getSystemEPPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getSystem(FMOD::PluginFactory *const this, FMOD::SystemI **system)
{
  *system = this->mSystem;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2220380 | Name: _ZN4FMOD13PluginFactory13setPluginPathEPKc
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::setPluginPath(FMOD::PluginFactory *const this, const char *path)
{
  int v2; // eax
  int v3; // edx

  v2 = FMOD_strlen(path);
  HIWORD(v3) = 0;
  if ( v2 > 255 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  LOWORD(v3) = 256;
  FMOD_strcpy_safe(this->mPluginPath, path, v3);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22203d0 | Name: _ZN4FMOD13PluginFactory13registerCodecEPNS_25FMOD_CODEC_DESCRIPTION_EXEPjjPNS_14PluginListInfoE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::registerCodec(
        FMOD::PluginFactory *const this,
        FMOD::FMOD_CODEC_DESCRIPTION_EX *description,
        unsigned int *handle,
        unsigned int priority,
        FMOD::PluginListInfo *info)
{
  FMOD_RESULT_0 result; // eax
  void *v9; // rax
  const char *name; // rdx
  FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *p_mCodecHead; // rcx
  FMOD::LinkedListNode *mNodeNext; // rsi
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::LinkedListNode *v14; // rdx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( description )
  {
    v9 = FMOD::MemPool::calloc(off_286F358->gSystemMemPool, 256, "../../../core_api/src/fmod_pluginfactory.cpp", 761, 0);
    if ( v9 )
    {
      name = description->name;
      *((_QWORD *)v9 + 1) = v9;
      *(_QWORD *)v9 = v9;
      *((_QWORD *)v9 + 2) = 0;
      *((_DWORD *)v9 + 6) = -1;
      *((_QWORD *)v9 + 31) = info;
      *((_QWORD *)v9 + 4) = name;
      *((_DWORD *)v9 + 10) = description->version;
      *((_DWORD *)v9 + 12) = description->timeunits;
      *((_DWORD *)v9 + 11) = description->defaultasstream;
      *((_QWORD *)v9 + 7) = description->open;
      *((_QWORD *)v9 + 8) = description->close;
      *((_QWORD *)v9 + 9) = description->read;
      *((_QWORD *)v9 + 10) = description->getlength;
      *((_QWORD *)v9 + 11) = description->setposition;
      *((_QWORD *)v9 + 12) = description->getposition;
      *((_QWORD *)v9 + 13) = description->soundcreate;
      *((_QWORD *)v9 + 14) = description->getwaveformat;
      *((_DWORD *)v9 + 30) = description->mType;
      *((_DWORD *)v9 + 31) = description->mSize;
      *((_QWORD *)v9 + 16) = description->mModule;
      *((_DWORD *)v9 + 35) = description->mPoolType;
      *((_QWORD *)v9 + 19) = description->reset;
      *((_QWORD *)v9 + 20) = description->canpoint;
      *((_QWORD *)v9 + 21) = description->getmusicnumchannels;
      *((_QWORD *)v9 + 22) = description->setmusicchannelvolume;
      *((_QWORD *)v9 + 23) = description->getmusicchannelvolume;
      *((_QWORD *)v9 + 24) = description->update;
      *((_QWORD *)v9 + 25) = description->setmusicspeed;
      *((_QWORD *)v9 + 26) = description->getmusicspeed;
      *((_QWORD *)v9 + 27) = description->getmetadata;
      *((_QWORD *)v9 + 28) = description->getcontextinfo;
      *((_QWORD *)v9 + 29) = description->setupcontext;
      *((_QWORD *)v9 + 30) = description->cleanupcontext;
      LODWORD(name) = this->mCurrentPluginHandle;
      this->mCurrentPluginHandle = (_DWORD)name + 1;
      *((_DWORD *)v9 + 34) = (_DWORD)name;
      p_mCodecHead = &this->mCodecHead;
      *((_QWORD *)v9 + 18) = description->init;
      mNodeNext = this->mCodecHead.mNodeNext;
      do
      {
        if ( priority < LODWORD(mNodeNext[1].mNodeNext) )
        {
          mNodePrev = mNodeNext->mNodePrev;
          *((_DWORD *)v9 + 6) = priority;
          *(_QWORD *)v9 = mNodeNext;
          *((_QWORD *)v9 + 1) = mNodePrev;
          mNodeNext->mNodePrev = (FMOD::LinkedListNode *)v9;
          **((_QWORD **)v9 + 1) = v9;
          goto LABEL_7;
        }
        mNodeNext = mNodeNext->mNodeNext;
      }
      while ( p_mCodecHead != mNodeNext->mNodePrev );
      v14 = this->mCodecHead.mNodePrev;
      *((_DWORD *)v9 + 6) = priority;
      *(_QWORD *)v9 = p_mCodecHead;
      *((_QWORD *)v9 + 1) = v14;
      this->mCodecHead.mNodePrev = (FMOD::LinkedListNode *)v9;
      **((_QWORD **)v9 + 1) = v9;
LABEL_7:
      if ( handle )
        *handle = *((_DWORD *)v9 + 34);
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
  }
  return result;
}


// Address: 0x2220620 | Name: _ZN4FMOD13PluginFactory13registerCodecEP22FMOD_CODEC_DESCRIPTIONPjjPNS_14PluginListInfoE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::registerCodec(
        FMOD::PluginFactory *const this,
        FMOD_CODEC_DESCRIPTION *description,
        unsigned int *handle,
        unsigned int priority,
        FMOD::PluginListInfo *info)
{
  FMOD_RESULT_0 result; // eax
  void *v9; // rax
  const char *name; // rdx
  FMOD_CODEC_GETWAVEFORMAT_CALLBACK_0 getwaveformat; // rdx
  FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *p_mCodecHead; // rcx
  FMOD::LinkedListNode *mNodeNext; // rsi
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::LinkedListNode *v15; // rdx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( description )
  {
    v9 = FMOD::MemPool::calloc(off_286F358->gSystemMemPool, 256, "../../../core_api/src/fmod_pluginfactory.cpp", 826, 0);
    if ( v9 )
    {
      name = description->name;
      *((_QWORD *)v9 + 1) = v9;
      *(_QWORD *)v9 = v9;
      *((_QWORD *)v9 + 2) = 0;
      *((_DWORD *)v9 + 6) = -1;
      *((_QWORD *)v9 + 31) = info;
      *((_QWORD *)v9 + 4) = name;
      *((_DWORD *)v9 + 10) = description->version;
      *((_DWORD *)v9 + 12) = description->timeunits;
      *((_DWORD *)v9 + 11) = description->defaultasstream;
      *((_QWORD *)v9 + 7) = description->open;
      *((_QWORD *)v9 + 8) = description->close;
      *((_QWORD *)v9 + 9) = description->read;
      *((_QWORD *)v9 + 10) = description->getlength;
      *((_QWORD *)v9 + 11) = description->setposition;
      *((_QWORD *)v9 + 12) = description->getposition;
      *((_QWORD *)v9 + 13) = description->soundcreate;
      getwaveformat = description->getwaveformat;
      *((_DWORD *)v9 + 30) = 0;
      *((_DWORD *)v9 + 31) = 416;
      *((_QWORD *)v9 + 14) = getwaveformat;
      LODWORD(getwaveformat) = this->mCurrentPluginHandle;
      this->mCurrentPluginHandle = (_DWORD)getwaveformat + 1;
      *((_DWORD *)v9 + 34) = (_DWORD)getwaveformat;
      p_mCodecHead = &this->mCodecHead;
      mNodeNext = this->mCodecHead.mNodeNext;
      do
      {
        if ( priority < LODWORD(mNodeNext[1].mNodeNext) )
        {
          mNodePrev = mNodeNext->mNodePrev;
          *((_DWORD *)v9 + 6) = priority;
          *(_QWORD *)v9 = mNodeNext;
          *((_QWORD *)v9 + 1) = mNodePrev;
          mNodeNext->mNodePrev = (FMOD::LinkedListNode *)v9;
          **((_QWORD **)v9 + 1) = v9;
          goto LABEL_7;
        }
        mNodeNext = mNodeNext->mNodeNext;
      }
      while ( p_mCodecHead != mNodeNext->mNodePrev );
      v15 = this->mCodecHead.mNodePrev;
      *((_DWORD *)v9 + 6) = priority;
      *(_QWORD *)v9 = p_mCodecHead;
      *((_QWORD *)v9 + 1) = v15;
      this->mCodecHead.mNodePrev = (FMOD::LinkedListNode *)v9;
      **((_QWORD **)v9 + 1) = v9;
LABEL_7:
      if ( handle )
        *handle = *((_DWORD *)v9 + 34);
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
  }
  return result;
}


// Address: 0x22207b0 | Name: _ZN4FMOD13PluginFactory11registerDSPEPNS_23FMOD_DSP_DESCRIPTION_EXEPK20FMOD_DSP_DESCRIPTIONPjPNS_14PluginListInfoE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::registerDSP(
        FMOD::PluginFactory *const this,
        FMOD::FMOD_DSP_DESCRIPTION_EX *description_ex,
        const FMOD_DSP_DESCRIPTION_0 *description,
        unsigned int *handle,
        FMOD::PluginListInfo *info)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *v10; // rax
  FMOD::LinkedListNode *v11; // rbp
  FMOD::LinkedListNode *v12; // r10
  FMOD::LinkedListNode *v13; // r9
  char *mDescription; // rax
  _WORD *v15; // rdi
  const FMOD_DSP_DESCRIPTION_0 *v16; // rsi
  unsigned int v17; // edx
  __int64 v18; // rcx
  __int64 v19; // rcx
  unsigned int *v20; // rdi
  unsigned int *v21; // rsi
  int numparameters; // edx
  char *v23; // rsi
  __int64 v24; // rcx
  _QWORD *v25; // rsi
  FMOD_DSP_PARAMETER_DESC *v26; // rdx
  FMOD::SystemI *mSystem; // rax
  int v28; // ecx
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::SystemI *v30; // r15
  bool mInitialized; // bl
  FMOD::LinkedListNode *mNodePrev; // rax
  unsigned int mCurrentPluginHandle; // eax
  FMOD::LinkedListNode *v34; // rdx
  __int64 mNodeNext_low; // rdx
  unsigned int v36; // ecx
  __int16 pluginsdkversion; // cx
  FMOD::LinkedListNode *v38; // [rsp+0h] [rbp-88h]
  FMOD::LinkedListNode *v39; // [rsp+0h] [rbp-88h]
  FMOD::LinkedListNode *v40; // [rsp+0h] [rbp-88h]
  FMOD::LinkedListNode *v41; // [rsp+0h] [rbp-88h]
  FMOD::LinkedListNode *v42; // [rsp+8h] [rbp-80h]
  FMOD::LinkedListNode *v43; // [rsp+8h] [rbp-80h]
  FMOD::LinkedListNode *v44; // [rsp+8h] [rbp-80h]
  FMOD_DSP_STATE state_dummy; // [rsp+10h] [rbp-78h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !description_ex )
    return result;
  if ( description_ex->mDescription )
  {
    LOBYTE(result) = 56;
    if ( description_ex->mDescription->pluginsdkversion > 0x6E )
      return result;
  }
  if ( description )
  {
    result = FMOD_RESULT::FMOD_ERR_PLUGIN_VERSION_0;
    if ( description->pluginsdkversion > 0x6E )
      return result;
  }
  v10 = (FMOD::LinkedListNode *)FMOD::MemPool::calloc(
                                  off_286F358->gSystemMemPool,
                                  128,
                                  "../../../core_api/src/fmod_pluginfactory.cpp",
                                  885,
                                  0);
  v11 = v10;
  if ( !v10 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v12 = v10 + 3;
  v13 = v10 + 4;
  v10[3].mNodeData = 0;
  v10[4].mNodeData = 0;
  v10[3].mNodePrev = v10 + 3;
  v10[3].mNodeNext = v10 + 3;
  v10[4].mNodePrev = v10 + 4;
  v10[4].mNodeNext = v10 + 4;
  mDescription = (char *)description_ex->mDescription;
  *(FMOD::FMOD_DSP_DESCRIPTION_EX *)&v11->mNodeNext = *description_ex;
  if ( description )
  {
    v42 = v13;
    v38 = v12;
    mDescription = (char *)FMOD::MemPool::calloc(
                             off_286F358->gSystemMemPool,
                             104 * description->numparameters + 216,
                             "../../../core_api/src/fmod_pluginfactory.cpp",
                             900,
                             0);
    if ( mDescription )
    {
      v15 = mDescription;
      v16 = description;
      v12 = v38;
      v13 = v42;
      if ( description->pluginsdkversion > 0x69 )
      {
        v17 = 216;
        if ( ((unsigned __int8)mDescription & 1) != 0 )
        {
          v15 = mDescription + 1;
          v16 = (const FMOD_DSP_DESCRIPTION_0 *)((char *)&description->pluginsdkversion + 1);
          *mDescription = description->pluginsdkversion;
          v17 = 215;
        }
      }
      else
      {
        v17 = 192;
        if ( ((unsigned __int8)mDescription & 1) != 0 )
        {
          v15 = mDescription + 1;
          v16 = (const FMOD_DSP_DESCRIPTION_0 *)((char *)&description->pluginsdkversion + 1);
          *mDescription = description->pluginsdkversion;
          v17 = 191;
        }
      }
      if ( ((unsigned __int8)v15 & 2) != 0 )
      {
        pluginsdkversion = v16->pluginsdkversion;
        ++v15;
        v16 = (const FMOD_DSP_DESCRIPTION_0 *)((char *)v16 + 2);
        v17 -= 2;
        *(v15 - 1) = pluginsdkversion;
      }
      if ( ((unsigned __int8)v15 & 4) != 0 )
      {
        v36 = v16->pluginsdkversion;
        v15 += 2;
        v16 = (const FMOD_DSP_DESCRIPTION_0 *)((char *)v16 + 4);
        v17 -= 4;
        *((_DWORD *)v15 - 1) = v36;
      }
      v18 = v17 >> 3;
      qmemcpy(v15, v16, 8 * v18);
      v21 = &v16->pluginsdkversion + 2 * v18;
      v20 = (unsigned int *)&v15[4 * v18];
      v19 = 0;
      if ( (v17 & 4) != 0 )
      {
        *v20 = *v21;
        v19 = 4;
      }
      if ( (v17 & 2) != 0 )
      {
        *(_WORD *)((char *)v20 + v19) = *(_WORD *)((char *)v21 + v19);
        v19 += 2;
      }
      if ( (v17 & 1) != 0 )
        *((_BYTE *)v20 + v19) = *((_BYTE *)v21 + v19);
      numparameters = description->numparameters;
      v23 = mDescription + 216;
      v24 = 0;
      *((_QWORD *)mDescription + 13) = mDescription + 216;
      if ( numparameters > 0 )
      {
        while ( 1 )
        {
          *(_QWORD *)&v23[8 * v24] = &v23[96 * v24 + 8 * numparameters];
          v25 = *(_QWORD **)(*((_QWORD *)mDescription + 13) + 8 * v24);
          v26 = description->paramdesc[v24];
          *v25 = *(_QWORD *)&v26->type;
          v25[1] = *(_QWORD *)&v26->name[4];
          v25[2] = *(_QWORD *)&v26->name[12];
          v25[3] = *(_QWORD *)&v26->label[4];
          v25[4] = *(_QWORD *)&v26->label[12];
          v25[5] = v26->description;
          v25[6] = *(_QWORD *)&v26->floatdesc.min;
          v25[7] = v26->booldesc.valuenames;
          v25[8] = v26->intdesc.valuenames;
          v25[9] = *((_QWORD *)&v26->datadesc + 3);
          v25[10] = v26->floatdesc.mapping.piecewiselinearmapping.pointparamvalues;
          v25[11] = v26->floatdesc.mapping.piecewiselinearmapping.pointpositions;
          numparameters = description->numparameters;
          if ( numparameters <= (int)++v24 )
            break;
          v23 = (char *)*((_QWORD *)mDescription + 13);
        }
      }
      v11->mNodeNext = (FMOD::LinkedListNode *)mDescription;
      LOBYTE(v11[2].mNodeData) = 1;
      goto LABEL_28;
    }
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
LABEL_28:
  if ( *((_QWORD *)mDescription + 24) )
  {
    v43 = v13;
    v39 = v12;
    memset(&state_dummy, 0, sizeof(state_dummy));
    mSystem = this->mSystem;
    v28 = *(_DWORD *)((char *)&stru_115E0.r_offset + (_QWORD)mSystem);
    state_dummy.functions = &mSystem->mDSPFunctions;
    mNodeNext = v11->mNodeNext;
    state_dummy.systemobject = v28;
    result = ((unsigned int (__fastcall *)(FMOD_DSP_STATE *))mNodeNext[8].mNodeNext)(&state_dummy);
    v12 = v39;
    v13 = v43;
    if ( result )
      return result;
    mDescription = (char *)v11->mNodeNext;
  }
  if ( *((_QWORD *)mDescription + 26) )
  {
    v30 = this->mSystem;
    mInitialized = v30->mInitialized;
    if ( mInitialized )
    {
      v44 = v13;
      v41 = v12;
      FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
      v13 = v44;
      v12 = v41;
    }
    mNodePrev = v11[4].mNodePrev;
    mNodePrev->mNodeNext = v11[4].mNodeNext;
    v11[4].mNodeNext->mNodePrev = mNodePrev;
    v11[4].mNodePrev = v13;
    v11[4].mNodePrev = this->mDSPHead.mMixCallbackNode.mNodePrev;
    v11[4].mNodeNext = &this->mDSPHead.mMixCallbackNode;
    this->mDSPHead.mMixCallbackNode.mNodePrev = v13;
    v11[4].mNodePrev->mNodeNext = v13;
    v11[4].mNodeData = v11;
    if ( mInitialized )
    {
      v40 = v12;
      FMOD::SystemI::leaveCrit(v30, FMOD_SYSTEM_CRIT_DSPMIXER);
      v12 = v40;
    }
  }
  mCurrentPluginHandle = this->mCurrentPluginHandle;
  v11[5].mNodeNext = (FMOD::LinkedListNode *)info;
  this->mCurrentPluginHandle = mCurrentPluginHandle + 1;
  v34 = this->mDSPHead.mPluginFactoryNode.mNodePrev;
  HIDWORD(v11->mNodeData) = mCurrentPluginHandle;
  v11[3].mNodePrev = v34;
  v11[3].mNodeNext = &this->mDSPHead.mPluginFactoryNode;
  this->mDSPHead.mPluginFactoryNode.mNodePrev = v12;
  v11[3].mNodePrev->mNodeNext = v12;
  mNodeNext_low = SLODWORD(v11[1].mNodeNext);
  v11[3].mNodeData = v11;
  if ( (unsigned int)(mNodeNext_low - 37) > 0x7FFFFFDA && (_DWORD)mNodeNext_low )
    this->mBuiltInDSPs[mNodeNext_low] = (FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *)v11;
  if ( handle )
    *handle = mCurrentPluginHandle;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2220c20 | Name: _ZN4FMOD13PluginFactory11registerDSPEP20FMOD_DSP_DESCRIPTIONPjPNS_14PluginListInfoE13FMOD_DSP_TYPE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::registerDSP(
        FMOD::PluginFactory *this,
        FMOD_DSP_DESCRIPTION *description,
        unsigned int *handle,
        FMOD::PluginListInfo *info,
        unsigned int a5)
{
  FMOD::FMOD_DSP_DESCRIPTION_EX descriptionex; // [rsp+0h] [rbp-48h] BYREF

  memset(&descriptionex, 0, sizeof(descriptionex));
  *(&descriptionex.mHandle + 1) = a5;
  descriptionex.mSize = 528;
  return FMOD::PluginFactory::registerDSP(this, &descriptionex, description, handle, info);
}


// Address: 0x2220c70 | Name: _ZN4FMOD13PluginFactory14registerOutputEPKNS_26FMOD_OUTPUT_DESCRIPTION_EXEPjPNS_14PluginListInfoE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::registerOutput(
        FMOD::PluginFactory *const this,
        const FMOD::FMOD_OUTPUT_DESCRIPTION_EX *description,
        unsigned int *handle,
        FMOD::PluginListInfo *info)
{
  FMOD_RESULT_0 result; // eax
  const FMOD::FMOD_OUTPUT_DESCRIPTION_EX *v5; // rbx
  FMOD::LinkedListNode *v9; // rax
  FMOD::LinkedListNode *v10; // rdi
  unsigned int v11; // edx
  __int64 v12; // rcx
  __int64 v13; // rcx
  unsigned int *v14; // rdi
  unsigned int *v15; // rsi
  unsigned int mCurrentPluginHandle; // edx
  FMOD::LinkedListNode *mNodePrev; // rcx
  unsigned int v18; // ecx
  __int16 apiversion; // cx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v5 = description;
  if ( description )
  {
    LOBYTE(result) = 56;
    if ( description->apiversion == 4 )
    {
      v9 = (FMOD::LinkedListNode *)FMOD::MemPool::calloc(
                                     off_286F358->gSystemMemPool,
                                     296,
                                     "../../../core_api/src/fmod_pluginfactory.cpp",
                                     1012,
                                     0);
      if ( v9 )
      {
        v10 = v9 + 1;
        v9->mNodePrev = v9;
        v9->mNodeNext = v9;
        v9->mNodeData = 0;
        v11 = 264;
        if ( (((_BYTE)v9 + 24) & 1) != 0 )
        {
          v10 = (FMOD::LinkedListNode *)((char *)v9 + 25);
          description = (const FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)description + 1);
          LOBYTE(v9[1].mNodeNext) = v5->apiversion;
          v11 = 263;
        }
        if ( ((unsigned __int8)v10 & 2) != 0 )
        {
          apiversion = description->apiversion;
          v10 = (FMOD::LinkedListNode *)((char *)v10 + 2);
          description = (const FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)description + 2);
          v11 -= 2;
          HIWORD(v10[-1].mNodeData) = apiversion;
        }
        if ( ((unsigned __int8)v10 & 4) != 0 )
        {
          v18 = description->apiversion;
          v10 = (FMOD::LinkedListNode *)((char *)v10 + 4);
          description = (const FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)description + 4);
          v11 -= 4;
          HIDWORD(v10[-1].mNodeData) = v18;
        }
        v12 = v11 >> 3;
        qmemcpy(v10, description, 8 * v12);
        v15 = &description->apiversion + 2 * v12;
        v14 = (unsigned int *)((char *)v10 + 8 * v12);
        v13 = 0;
        if ( (v11 & 4) != 0 )
        {
          *v14 = *v15;
          v13 = 4;
        }
        if ( (v11 & 2) != 0 )
        {
          *(_WORD *)((char *)v14 + v13) = *(_WORD *)((char *)v15 + v13);
          v13 += 2;
        }
        if ( (v11 & 1) != 0 )
          *((_BYTE *)v14 + v13) = *((_BYTE *)v15 + v13);
        mCurrentPluginHandle = this->mCurrentPluginHandle;
        v9[12].mNodeNext = (FMOD::LinkedListNode *)info;
        this->mCurrentPluginHandle = mCurrentPluginHandle + 1;
        mNodePrev = this->mOutputHead.mNodePrev;
        LODWORD(v9[9].mNodeNext) = mCurrentPluginHandle;
        v9->mNodePrev = mNodePrev;
        v9->mNodeNext = &this->mOutputHead;
        this->mOutputHead.mNodePrev = v9;
        v9->mNodePrev->mNodeNext = v9;
        if ( handle )
          *handle = mCurrentPluginHandle;
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
    }
  }
  return result;
}


// Address: 0x2220df0 | Name: _ZN4FMOD13PluginFactory14registerOutputEPK23FMOD_OUTPUT_DESCRIPTIONPjPNS_14PluginListInfoE15FMOD_OUTPUTTYPE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::registerOutput(
        FMOD::PluginFactory *const this,
        const FMOD_OUTPUT_DESCRIPTION_4 *description,
        unsigned int *handle,
        FMOD::PluginListInfo *info,
        FMOD_OUTPUTTYPE_0 type)
{
  FMOD_RESULT_0 result; // eax
  const FMOD_OUTPUT_DESCRIPTION_4 *v6; // rbx
  FMOD::LinkedListNode *v11; // rax
  FMOD::LinkedListNode *v12; // rdi
  unsigned int v13; // edx
  __int64 v14; // rcx
  __int64 v15; // rcx
  unsigned int *v16; // rdi
  unsigned int *v17; // rsi
  unsigned int mCurrentPluginHandle; // edx
  FMOD::LinkedListNode *mNodePrev; // rcx
  unsigned int v20; // ecx
  __int16 apiversion; // cx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v6 = description;
  if ( description )
  {
    LOBYTE(result) = 56;
    if ( description->apiversion == 4 )
    {
      v11 = (FMOD::LinkedListNode *)FMOD::MemPool::calloc(
                                      off_286F358->gSystemMemPool,
                                      296,
                                      "../../../core_api/src/fmod_pluginfactory.cpp",
                                      1052,
                                      0);
      if ( v11 )
      {
        v12 = v11 + 1;
        v11->mNodePrev = v11;
        v11->mNodeNext = v11;
        v11->mNodeData = 0;
        v13 = 176;
        if ( (((_BYTE)v11 + 24) & 1) != 0 )
        {
          v12 = (FMOD::LinkedListNode *)((char *)v11 + 25);
          description = (const FMOD_OUTPUT_DESCRIPTION_4 *)((char *)description + 1);
          LOBYTE(v11[1].mNodeNext) = v6->apiversion;
          v13 = 175;
        }
        if ( ((unsigned __int8)v12 & 2) != 0 )
        {
          apiversion = description->apiversion;
          v12 = (FMOD::LinkedListNode *)((char *)v12 + 2);
          description = (const FMOD_OUTPUT_DESCRIPTION_4 *)((char *)description + 2);
          v13 -= 2;
          HIWORD(v12[-1].mNodeData) = apiversion;
        }
        if ( ((unsigned __int8)v12 & 4) != 0 )
        {
          v20 = description->apiversion;
          v12 = (FMOD::LinkedListNode *)((char *)v12 + 4);
          description = (const FMOD_OUTPUT_DESCRIPTION_4 *)((char *)description + 4);
          v13 -= 4;
          HIDWORD(v12[-1].mNodeData) = v20;
        }
        v14 = v13 >> 3;
        qmemcpy(v12, description, 8 * v14);
        v17 = &description->apiversion + 2 * v14;
        v16 = (unsigned int *)((char *)v12 + 8 * v14);
        v15 = 0;
        if ( (v13 & 4) != 0 )
        {
          *v16 = *v17;
          v15 = 4;
        }
        if ( (v13 & 2) != 0 )
        {
          *(_WORD *)((char *)v16 + v15) = *(_WORD *)((char *)v17 + v15);
          v15 += 2;
        }
        if ( (v13 & 1) != 0 )
          *((_BYTE *)v16 + v15) = *((_BYTE *)v17 + v15);
        mCurrentPluginHandle = this->mCurrentPluginHandle;
        v11[12].mNodeNext = (FMOD::LinkedListNode *)info;
        LODWORD(v11[8].mNodePrev) = type;
        HIDWORD(v11[8].mNodePrev) = 1144;
        this->mCurrentPluginHandle = mCurrentPluginHandle + 1;
        mNodePrev = this->mOutputHead.mNodePrev;
        LODWORD(v11[9].mNodeNext) = mCurrentPluginHandle;
        v11->mNodePrev = mNodePrev;
        v11->mNodeNext = &this->mOutputHead;
        this->mOutputHead.mNodePrev = v11;
        v11->mNodePrev->mNodeNext = v11;
        if ( handle )
          *handle = mCurrentPluginHandle;
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
    }
  }
  return result;
}


// Address: 0x2220f80 | Name: _ZN4FMOD13PluginFactory12getNumCodecsEPi
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getNumCodecs(FMOD::PluginFactory *const this, int *numcodecs)
{
  FMOD_RESULT_0 result; // eax
  FMOD::PluginFactory *mNodeNext; // rax
  int i; // edx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numcodecs )
  {
    mNodeNext = (FMOD::PluginFactory *)this->mCodecHead.mNodeNext;
    for ( i = 0; &this->mCodecHead != (FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *)mNodeNext; ++i )
      mNodeNext = *(FMOD::PluginFactory **)mNodeNext->mPluginPath;
    *numcodecs = i;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2220fc0 | Name: _ZN4FMOD13PluginFactory10getNumDSPsEPi
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getNumDSPs(FMOD::PluginFactory *const this, int *numdsps)
{
  FMOD_RESULT_0 result; // eax
  FMOD::PluginFactory *mNodeNext; // rax
  int i; // edx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numdsps )
  {
    mNodeNext = (FMOD::PluginFactory *)this->mDSPHead.mPluginFactoryNode.mNodeNext;
    for ( i = 0; &this->mDSPHead.mPluginFactoryNode != (FMOD::LinkedListNode *)mNodeNext; ++i )
      mNodeNext = *(FMOD::PluginFactory **)mNodeNext->mPluginPath;
    *numdsps = i;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2221000 | Name: _ZN4FMOD13PluginFactory13getNumOutputsEPi
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getNumOutputs(FMOD::PluginFactory *const this, int *numoutputs)
{
  FMOD_RESULT_0 result; // eax
  FMOD::PluginFactory *mNodeNext; // rax
  int i; // edx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numoutputs )
  {
    mNodeNext = (FMOD::PluginFactory *)this->mOutputHead.mNodeNext;
    for ( i = 0; &this->mOutputHead != (FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN *)mNodeNext; ++i )
      mNodeNext = *(FMOD::PluginFactory **)mNodeNext->mPluginPath;
    *numoutputs = i;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2221040 | Name: _ZN4FMOD13PluginFactory14getCodecHandleEiPj
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getCodecHandle(
        FMOD::PluginFactory *const this,
        int index,
        unsigned int *handle)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rcx
  FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *p_mCodecHead; // r8

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( handle )
  {
    if ( index >= 0 )
    {
      mNodeNext = this->mCodecHead.mNodeNext;
      p_mCodecHead = &this->mCodecHead;
      if ( &this->mCodecHead != mNodeNext )
      {
        if ( index )
        {
          mNodeNext = mNodeNext->mNodeNext;
          if ( p_mCodecHead == mNodeNext )
            return result;
          while ( --index )
          {
            mNodeNext = mNodeNext->mNodeNext;
            if ( p_mCodecHead == mNodeNext )
              return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
          }
        }
        if ( mNodeNext )
        {
          *handle = (unsigned int)mNodeNext[5].mNodeData;
          return FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x22210b0 | Name: _ZN4FMOD13PluginFactory12getDSPHandleEiPj
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getDSPHandle(
        FMOD::PluginFactory *const this,
        int index,
        unsigned int *handle)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *v4; // r8
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *p_mPluginFactoryNode; // rcx
  _DWORD *mNodeData; // rcx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( handle )
  {
    v4 = 0;
    if ( index < 0 )
      goto LABEL_10;
    mNodeNext = this->mDSPHead.mPluginFactoryNode.mNodeNext;
    p_mPluginFactoryNode = &this->mDSPHead.mPluginFactoryNode;
    if ( &this->mDSPHead.mPluginFactoryNode == mNodeNext )
      goto LABEL_10;
    if ( index )
    {
      mNodeNext = mNodeNext->mNodeNext;
      if ( p_mPluginFactoryNode == mNodeNext )
      {
LABEL_10:
        mNodeData = v4->mNodeData;
        result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        if ( mNodeData )
        {
          *handle = mNodeData[5];
          return FMOD_RESULT::FMOD_OK_0;
        }
        return result;
      }
      while ( --index )
      {
        mNodeNext = mNodeNext->mNodeNext;
        if ( p_mPluginFactoryNode == mNodeNext )
        {
          v4 = 0;
          goto LABEL_10;
        }
      }
    }
    v4 = mNodeNext;
    goto LABEL_10;
  }
  return result;
}


// Address: 0x2221120 | Name: _ZN4FMOD13PluginFactory15getOutputHandleEiPj
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getOutputHandle(
        FMOD::PluginFactory *const this,
        int index,
        unsigned int *handle)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rcx
  FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN *p_mOutputHead; // r8

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( handle )
  {
    if ( index >= 0 )
    {
      mNodeNext = this->mOutputHead.mNodeNext;
      p_mOutputHead = &this->mOutputHead;
      if ( &this->mOutputHead != mNodeNext )
      {
        if ( index )
        {
          mNodeNext = mNodeNext->mNodeNext;
          if ( p_mOutputHead == mNodeNext )
            return result;
          while ( --index )
          {
            mNodeNext = mNodeNext->mNodeNext;
            if ( p_mOutputHead == mNodeNext )
              return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
          }
        }
        if ( mNodeNext )
        {
          *handle = (unsigned int)mNodeNext[9].mNodeNext;
          return FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x2221190 | Name: _ZN4FMOD13PluginFactory8getCodecEjPPNS_29FMOD_CODEC_DESCRIPTION_PLUGINE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getCodec(
        FMOD::PluginFactory *const this,
        unsigned int handle,
        FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN **codecdesc)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( codecdesc )
  {
    *codecdesc = 0;
    mNodeNext = this->mCodecHead.mNodeNext;
    if ( &this->mCodecHead == mNodeNext )
    {
      return FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
    }
    else
    {
      while ( LODWORD(mNodeNext[5].mNodeData) != handle )
      {
        mNodeNext = mNodeNext->mNodeNext;
        if ( &this->mCodecHead == mNodeNext )
          return FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
      }
      *codecdesc = (FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *)mNodeNext;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x22211f0 | Name: _ZN4FMOD13PluginFactory6getDSPEjPPNS_27FMOD_DSP_DESCRIPTION_PLUGINE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getDSP(
        FMOD::PluginFactory *const this,
        unsigned int handle,
        FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **dspdesc)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *mNodeData; // rcx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dspdesc )
  {
    *dspdesc = 0;
    mNodeNext = this->mDSPHead.mPluginFactoryNode.mNodeNext;
    if ( &this->mDSPHead.mPluginFactoryNode == mNodeNext )
    {
      return FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
    }
    else
    {
      while ( 1 )
      {
        mNodeData = (FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *)mNodeNext->mNodeData;
        if ( mNodeData->mDescription.mHandle == handle )
          break;
        mNodeNext = mNodeNext->mNodeNext;
        if ( &this->mDSPHead.mPluginFactoryNode == mNodeNext )
          return FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
      }
      *dspdesc = mNodeData;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2221250 | Name: _ZN4FMOD13PluginFactory12getDSPByTypeE13FMOD_DSP_TYPEPPNS_27FMOD_DSP_DESCRIPTION_PLUGINE
char __fastcall FMOD::PluginFactory::getDSPByType(
        FMOD::PluginFactory *this,
        FMOD_DSP_TYPE a2,
        FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **a3)
{
  char result; // al
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *v4; // rcx

  result = 54;
  v4 = this->mBuiltInDSPs[a2];
  if ( v4 )
  {
    *a3 = v4;
    return 0;
  }
  return result;
}


// Address: 0x2221270 | Name: _ZN4FMOD13PluginFactory9getOutputEjPPNS_30FMOD_OUTPUT_DESCRIPTION_PLUGINE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getOutput(
        FMOD::PluginFactory *const this,
        unsigned int handle,
        FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN **outputdesc)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( outputdesc )
  {
    *outputdesc = 0;
    mNodeNext = this->mOutputHead.mNodeNext;
    if ( &this->mOutputHead == mNodeNext )
    {
      return FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
    }
    else
    {
      while ( LODWORD(mNodeNext[9].mNodeNext) != handle )
      {
        mNodeNext = mNodeNext->mNodeNext;
        if ( &this->mOutputHead == mNodeNext )
          return FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
      }
      *outputdesc = (FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN *)mNodeNext;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x22212d0 | Name: _ZN4FMOD13PluginFactory20unloadPluginInternalEjb
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::unloadPluginInternal(
        FMOD::PluginFactory *const this,
        unsigned int handle,
        bool fromclose)
{
  FMOD_RESULT_0 result; // eax
  FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN *v5; // rsi
  FMOD_OS_LIBRARY *v6; // rdi
  FMOD::LinkedListNode *v7; // rax
  FMOD_RESULT_0 v8; // edx
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *v9; // rsi
  FMOD::SystemI *mSystem; // rax
  int v11; // ecx
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  FMOD::SystemI *v13; // rbp
  FMOD::LinkedListNode *v14; // rcx
  FMOD::LinkedListNode *v15; // rdx
  __int64 v16; // rax
  FMOD_OS_LIBRARY *mModule; // rdi
  FMOD::LinkedListNode *v18; // rdx
  bool v19; // zf
  FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *v20; // rsi
  FMOD_OS_LIBRARY *v21; // rdi
  FMOD::LinkedListNode *v22; // rax
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *v23; // rax
  FMOD::LinkedListNode *mNodeNext; // rsi
  FMOD::LinkedListNode *mNodePrev; // rcx
  FMOD::LinkedListNode *p_mMixCallbackNode; // rdx
  FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN *output; // [rsp+8h] [rbp-70h] BYREF
  FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *codec; // [rsp+10h] [rbp-68h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *dsp; // [rsp+18h] [rbp-60h] BYREF
  FMOD_DSP_STATE state_dummy; // [rsp+20h] [rbp-58h] BYREF

  result = FMOD::PluginFactory::getOutput(this, handle, &output);
  if ( result )
  {
    if ( result != FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0 )
      return result;
    result = FMOD::PluginFactory::getCodec(this, handle, &codec);
    if ( result )
    {
      if ( result != FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0 )
        return result;
      v8 = FMOD::PluginFactory::getDSP(this, handle, &dsp);
      if ( v8 )
      {
        result = FMOD_RESULT::FMOD_OK_0;
        if ( v8 != FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0 )
          return v8;
      }
      else
      {
        v9 = dsp;
        if ( !dsp->mRefCount || (result = FMOD_RESULT::FMOD_ERR_DSP_INUSE_0, fromclose) )
        {
          if ( dsp->mDescription.mDescription->sys_deregister )
          {
            memset(&state_dummy, 0, sizeof(state_dummy));
            mSystem = this->mSystem;
            v11 = *(_DWORD *)((char *)&stru_115E0.r_offset + (_QWORD)mSystem);
            state_dummy.functions = &mSystem->mDSPFunctions;
            mDescription = dsp->mDescription.mDescription;
            state_dummy.systemobject = v11;
            result = mDescription->sys_deregister(&state_dummy);
            if ( result )
              return result;
            v9 = dsp;
          }
          if ( v9->mDescription.mDescription->sys_mix )
          {
            v13 = this->mSystem;
            if ( v13->mInitialized )
            {
              FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
              v23 = dsp;
              mNodeNext = dsp->mMixCallbackNode.mNodeNext;
              mNodePrev = dsp->mMixCallbackNode.mNodePrev;
              p_mMixCallbackNode = &dsp->mMixCallbackNode;
              dsp->mMixCallbackNode.mNodeData = 0;
              mNodePrev->mNodeNext = mNodeNext;
              v23->mMixCallbackNode.mNodeNext->mNodePrev = mNodePrev;
              v23->mMixCallbackNode.mNodePrev = p_mMixCallbackNode;
              v23->mMixCallbackNode.mNodeNext = p_mMixCallbackNode;
              FMOD::SystemI::leaveCrit(v13, FMOD_SYSTEM_CRIT_DSPMIXER);
              v9 = dsp;
            }
            else
            {
              v14 = v9->mMixCallbackNode.mNodeNext;
              v15 = v9->mMixCallbackNode.mNodePrev;
              v9->mMixCallbackNode.mNodeData = 0;
              v15->mNodeNext = v14;
              v9->mMixCallbackNode.mNodeNext->mNodePrev = v15;
              v9->mMixCallbackNode.mNodePrev = &v9->mMixCallbackNode;
              v9->mMixCallbackNode.mNodeNext = &v9->mMixCallbackNode;
            }
          }
          v16 = *((int *)&v9->mDescription.mHandle + 1);
          if ( (unsigned int)(v16 - 37) > 0x7FFFFFDA && (_DWORD)v16 )
            this->mBuiltInDSPs[v16] = 0;
          mModule = (FMOD_OS_LIBRARY *)v9->mDescription.mModule;
          if ( mModule )
          {
            FMOD_OS_Library_Free(mModule);
            v9 = dsp;
          }
          v18 = v9->mPluginFactoryNode.mNodePrev;
          v19 = !v9->mDynamicDesc;
          v18->mNodeNext = v9->mPluginFactoryNode.mNodeNext;
          v9->mPluginFactoryNode.mNodeNext->mNodePrev = v18;
          v9->mPluginFactoryNode.mNodePrev = &v9->mPluginFactoryNode;
          v9->mPluginFactoryNode.mNodeNext = &v9->mPluginFactoryNode;
          if ( !v19 )
          {
            FMOD::MemPool::free(
              off_286F358->gSystemMemPool,
              (void *)v9->mDescription.mDescription,
              "../../../core_api/src/fmod_pluginfactory.cpp",
              729);
            v9 = dsp;
          }
          FMOD::MemPool::free(off_286F358->gSystemMemPool, v9, "../../../core_api/src/fmod_pluginfactory.cpp", 732);
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
    else
    {
      v20 = codec;
      v21 = codec->mDescription.mModule;
      if ( v21 )
      {
        FMOD_OS_Library_Free(v21);
        v20 = codec;
      }
      v22 = v20->mNodePrev;
      v22->mNodeNext = v20->mNodeNext;
      v20->mNodeNext->mNodePrev = v22;
      v20->mNodePrev = v20;
      v20->mNodeNext = v20;
      v20->mNodePriority = -1;
      v20->mNodeData = 0;
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v20, "../../../core_api/src/fmod_pluginfactory.cpp", 676);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  else
  {
    v5 = output;
    v6 = output->mDescription.mModule;
    if ( v6 )
    {
      FMOD_OS_Library_Free(v6);
      v5 = output;
    }
    v7 = v5->mNodePrev;
    v7->mNodeNext = v5->mNodeNext;
    v5->mNodeNext->mNodePrev = v7;
    v5->mNodePrev = v5;
    v5->mNodeNext = v5;
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v5, "../../../core_api/src/fmod_pluginfactory.cpp", 659);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x22215b0 | Name: _ZN4FMOD13PluginFactory17getPluginListInfoEj
FMOD::PluginListInfo *__fastcall FMOD::PluginFactory::getPluginListInfo(
        FMOD::PluginFactory *const this,
        unsigned int handle)
{
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *dsp; // [rsp+8h] [rbp-30h] BYREF
  FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN *output; // [rsp+10h] [rbp-28h] BYREF
  FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *codec; // [rsp+18h] [rbp-20h] BYREF

  if ( FMOD::PluginFactory::getDSP(this, handle, &dsp) == FMOD_RESULT::FMOD_OK_0 )
    return dsp->mInfo;
  if ( FMOD::PluginFactory::getOutput(this, handle, &output) == FMOD_RESULT::FMOD_OK_0 )
    return output->mInfo;
  if ( FMOD::PluginFactory::getCodec(this, handle, &codec) )
    return 0;
  return codec->mInfo;
}


// Address: 0x2221650 | Name: _ZN4FMOD13PluginFactory12unloadPluginEjb
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::unloadPlugin(
        FMOD::PluginFactory *const this,
        unsigned int handle,
        bool fromClose)
{
  FMOD::PluginListInfo *PluginListInfo; // rax
  FMOD::PluginListInfo *v6; // r14
  unsigned int *mHandles; // rcx
  FMOD_RESULT_0 result; // eax
  int v9; // eax
  __int64 v10; // rbx
  unsigned __int64 v11; // rbp
  unsigned int v12; // esi

  PluginListInfo = FMOD::PluginFactory::getPluginListInfo(this, handle);
  v6 = PluginListInfo;
  if ( !PluginListInfo )
    return FMOD::PluginFactory::unloadPluginInternal(this, handle, fromClose);
  mHandles = PluginListInfo->mHandles;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( *mHandles == handle )
  {
    v9 = v6->mCount - 1;
    if ( v9 >= 0 )
    {
      v10 = 4LL * v9;
      v11 = 4 * (v9 - (unsigned __int64)(unsigned int)v9);
      while ( 1 )
      {
        v12 = mHandles[(unsigned __int64)v10 / 4];
        if ( v12 )
        {
          result = FMOD::PluginFactory::unloadPluginInternal(this, v12, fromClose);
          if ( result )
            return result;
          mHandles = v6->mHandles;
          mHandles[(unsigned __int64)v10 / 4] = 0;
          if ( v10 == v11 )
            break;
        }
        else if ( v10 == v11 )
        {
          break;
        }
        v10 -= 4;
      }
    }
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v6, "../../../core_api/src/fmod_pluginfactory.cpp", 620);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2221730 | Name: _ZN4FMOD13PluginFactory7releaseEb
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::release(FMOD::PluginFactory *const this, bool fromclose)
{
  FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *p_mCodecHead; // rbp
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *p_mPluginFactoryNode; // rbp
  _DWORD *mNodeData; // rax
  FMOD::LinkedListNode *v7; // rax
  FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN *p_mOutputHead; // rbp
  FMOD::LinkedListNode *v9; // rax

  p_mCodecHead = &this->mCodecHead;
  while ( 1 )
  {
    mNodeNext = this->mCodecHead.mNodeNext;
    if ( mNodeNext == p_mCodecHead && this->mCodecHead.mNodePrev == p_mCodecHead )
      break;
    if ( !mNodeNext )
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    result = FMOD::PluginFactory::unloadPlugin(this, (unsigned int)mNodeNext[5].mNodeData, fromclose);
    if ( result )
      return result;
  }
  p_mPluginFactoryNode = &this->mDSPHead.mPluginFactoryNode;
  while ( 1 )
  {
    v7 = this->mDSPHead.mPluginFactoryNode.mNodeNext;
    if ( v7 == p_mPluginFactoryNode && this->mDSPHead.mPluginFactoryNode.mNodePrev == p_mPluginFactoryNode )
      break;
    mNodeData = v7->mNodeData;
    if ( !mNodeData )
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    result = FMOD::PluginFactory::unloadPlugin(this, mNodeData[5], fromclose);
    if ( result )
      return result;
  }
  p_mOutputHead = &this->mOutputHead;
  while ( 1 )
  {
    v9 = this->mOutputHead.mNodeNext;
    if ( v9 != p_mOutputHead )
    {
      if ( !v9 )
        return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      goto LABEL_13;
    }
    if ( this->mOutputHead.mNodePrev == p_mOutputHead )
      break;
LABEL_13:
    result = FMOD::PluginFactory::unloadPlugin(this, (unsigned int)v9[9].mNodeNext, fromclose);
    if ( result )
      return result;
  }
  FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_pluginfactory.cpp", 110);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2221850 | Name: _ZN4FMOD13PluginFactory10loadPluginEPKcPjbj
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::loadPlugin(
        FMOD::PluginFactory *const this,
        const char *dllname_in,
        unsigned int *handle,
        bool calledinternally,
        unsigned int priority)
{
  unsigned int *p_dummyhandle; // rbx
  unsigned int v7; // edx
  FMOD_RESULT_0 v8; // ebx
  FMOD_PLUGINLIST *v10; // rax
  FMOD_PLUGINLIST *v11; // rbp
  FMOD_PLUGINLIST *v12; // rdx
  int v13; // esi
  FMOD_PLUGINLIST *v14; // rcx
  FMOD::PluginListInfo *v15; // rax
  FMOD::PluginListInfo *v16; // r9
  unsigned int *mHandles; // rax
  __int64 v18; // r14
  FMOD_PLUGINTYPE_0 type; // edx
  FMOD_RESULT_0 ProcAddress; // eax
  FMOD_CODEC_DESCRIPTION *v21; // rax
  FMOD::FMOD_CODEC_DESCRIPTION_EX *v22; // rax
  FMOD_DSP_DESCRIPTION *v23; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v24; // rax
  const FMOD_OUTPUT_DESCRIPTION_4 *v25; // rax
  const FMOD::FMOD_OUTPUT_DESCRIPTION_EX *v26; // rax
  FMOD::PluginListInfo *v27; // [rsp+8h] [rbp-10A0h]
  FMOD::PluginListInfo *v28; // [rsp+8h] [rbp-10A0h]
  unsigned int dummyhandle; // [rsp+14h] [rbp-1094h] BYREF
  FMOD_PLUGINLIST *(*getpluginlist)(void); // [rsp+18h] [rbp-1090h] BYREF
  FMOD_CODEC_DESCRIPTION *(*getcodecdesc)(void); // [rsp+20h] [rbp-1088h] BYREF
  FMOD::FMOD_CODEC_DESCRIPTION_EX *(*getcodecdescex)(void); // [rsp+28h] [rbp-1080h] BYREF
  FMOD_DSP_DESCRIPTION *(*getdspdesc)(void); // [rsp+30h] [rbp-1078h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_EX *(*getdspdescex)(void); // [rsp+38h] [rbp-1070h] BYREF
  FMOD_OUTPUT_DESCRIPTION *(*getoutputdesc)(void); // [rsp+40h] [rbp-1068h] BYREF
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *(*getoutputdescex)(void); // [rsp+48h] [rbp-1060h] BYREF
  FMOD::LoadPluginScope scope; // [rsp+50h] [rbp-1058h] BYREF
  char path[2048]; // [rsp+70h] [rbp-1038h] BYREF
  char dllname[2104]; // [rsp+870h] [rbp-838h] BYREF

  p_dummyhandle = handle;
  scope.pluginfactory = this;
  scope.firsthandle = 0;
  scope.dllhandle = 0;
  getpluginlist = 0;
  if ( !handle )
    p_dummyhandle = &dummyhandle;
  getcodecdesc = 0;
  scope.outhandle = p_dummyhandle;
  *p_dummyhandle = 0;
  getcodecdescex = 0;
  getdspdesc = 0;
  getdspdescex = 0;
  getoutputdesc = 0;
  getoutputdescex = 0;
  if ( !dllname_in )
  {
    v7 = 0;
    goto LABEL_6;
  }
  if ( !FMOD_strlen(dllname_in) )
  {
    v7 = *scope.outhandle;
LABEL_6:
    v8 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    goto LABEL_7;
  }
  dllname[0] = 0;
  path[0] = 0;
  FMOD_strcpy_safe(dllname, dllname_in, 2048);
  FMOD_strcpy_safe(path, this->mPluginPath, 2048);
  if ( FMOD_strlen(path) && path[FMOD_strlen(path) - 1] != 92 && path[FMOD_strlen(path) - 1] != 47 )
    FMOD_strcat_safe(path, "/", 2048);
  FMOD_strcat_safe(path, dllname, 2048);
  if ( FMOD_OS_Library_Load(path, &scope.dllhandle) )
  {
    ProcAddress = FMOD_OS_Library_Load(dllname, &scope.dllhandle);
    if ( ProcAddress )
    {
LABEL_39:
      v8 = ProcAddress;
      v7 = *scope.outhandle;
      goto LABEL_7;
    }
  }
  if ( FMOD_OS_Library_GetProcAddress(scope.dllhandle, "FMODGetPluginDescriptionList", (void **)&getpluginlist) == FMOD_RESULT::FMOD_OK_0 )
  {
    v10 = getpluginlist();
    v11 = v10;
    if ( v10->type == FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_MAX_0 || (v12 = v10, v13 = 1, !v10->description) )
    {
      v8 = FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
      v7 = *scope.outhandle;
      goto LABEL_7;
    }
    while ( 1 )
    {
      v14 = v12;
      if ( v12[1].type == FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_MAX_0 )
        break;
      ++v12;
      if ( !v14[1].description )
        break;
      ++v13;
    }
    v15 = (FMOD::PluginListInfo *)FMOD::MemPool::calloc(
                                    off_286F358->gSystemMemPool,
                                    4 * v13 + 16,
                                    "../../../core_api/src/fmod_pluginfactory.cpp",
                                    328,
                                    0);
    v16 = v15;
    if ( !v15 )
    {
      v8 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
      v7 = *scope.outhandle;
      goto LABEL_7;
    }
    v15->mCount = v13;
    mHandles = (unsigned int *)&v15[1];
    v18 = 0;
    v16->mHandles = mHandles;
    while ( 1 )
    {
      type = v11->type;
      if ( v11->type == FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_CODEC_0 )
      {
        v28 = v16;
        ProcAddress = FMOD::PluginFactory::registerCodec(
                        this,
                        (FMOD_CODEC_DESCRIPTION *)v11->description,
                        &mHandles[v18],
                        priority,
                        v16);
        if ( ProcAddress )
          goto LABEL_39;
      }
      else
      {
        if ( type != FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_DSP_0 )
        {
          if ( type == FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_OUTPUT_0 )
          {
            v27 = v16;
            ProcAddress = FMOD::PluginFactory::registerOutput(
                            this,
                            (const FMOD_OUTPUT_DESCRIPTION_4 *)v11->description,
                            &mHandles[v18],
                            v16,
                            FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_UNKNOWN_0);
            v16 = v27;
            if ( ProcAddress )
              goto LABEL_39;
            mHandles = v27->mHandles;
          }
          goto LABEL_23;
        }
        v28 = v16;
        ProcAddress = FMOD::PluginFactory::registerDSP(
                        this,
                        (FMOD_DSP_DESCRIPTION *)v11->description,
                        &mHandles[v18],
                        v16,
                        0);
        if ( ProcAddress )
          goto LABEL_39;
      }
      v16 = v28;
      mHandles = v28->mHandles;
LABEL_23:
      ++v18;
      ++v11;
      scope.firsthandle = *mHandles;
      if ( v13 <= (int)v18 )
      {
        *p_dummyhandle = *mHandles;
        v8 = FMOD_RESULT::FMOD_OK_0;
        v7 = *scope.outhandle;
        goto LABEL_7;
      }
    }
  }
  if ( FMOD_OS_Library_GetProcAddress(scope.dllhandle, "FMODGetCodecDescription", (void **)&getcodecdesc) == FMOD_RESULT::FMOD_OK_0 )
  {
    v21 = getcodecdesc();
    v8 = FMOD::PluginFactory::registerCodec(this, v21, p_dummyhandle, priority, 0);
    v7 = *scope.outhandle;
    goto LABEL_7;
  }
  if ( FMOD_OS_Library_GetProcAddress(scope.dllhandle, "FMODGetCodecDescriptionEx", (void **)&getcodecdescex) == FMOD_RESULT::FMOD_OK_0 )
  {
    v22 = getcodecdescex();
    v8 = FMOD::PluginFactory::registerCodec(this, v22, p_dummyhandle, priority, 0);
    v7 = *scope.outhandle;
    goto LABEL_7;
  }
  if ( FMOD_OS_Library_GetProcAddress(scope.dllhandle, "FMODGetDSPDescription", (void **)&getdspdesc) )
  {
    if ( FMOD_OS_Library_GetProcAddress(scope.dllhandle, "FMODGetDSPDescriptionEx", (void **)&getdspdescex) )
    {
      if ( FMOD_OS_Library_GetProcAddress(scope.dllhandle, "FMODGetOutputDescription", (void **)&getoutputdesc) )
      {
        ProcAddress = FMOD_OS_Library_GetProcAddress(
                        scope.dllhandle,
                        "FMODGetOutputDescriptionEx",
                        (void **)&getoutputdescex);
        if ( ProcAddress )
          goto LABEL_39;
        v26 = getoutputdescex();
        v8 = FMOD::PluginFactory::registerOutput(this, v26, p_dummyhandle, 0);
        v7 = *scope.outhandle;
      }
      else
      {
        v25 = getoutputdesc();
        v8 = FMOD::PluginFactory::registerOutput(
               this,
               v25,
               p_dummyhandle,
               0,
               FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_UNKNOWN_0);
        v7 = *scope.outhandle;
      }
    }
    else
    {
      v24 = getdspdescex();
      v8 = FMOD::PluginFactory::registerDSP(this, v24, 0, p_dummyhandle, 0);
      v7 = *scope.outhandle;
    }
  }
  else
  {
    v23 = getdspdesc();
    v8 = FMOD::PluginFactory::registerDSP(this, v23, p_dummyhandle, 0, 0);
    v7 = *scope.outhandle;
  }
LABEL_7:
  if ( !v7 )
  {
    if ( scope.firsthandle )
    {
      FMOD::PluginFactory::unloadPlugin(scope.pluginfactory, scope.firsthandle, 0);
    }
    else if ( scope.dllhandle )
    {
      FMOD_OS_Library_Free(scope.dllhandle);
    }
  }
  return v8;
}


// Address: 0x2221d80 | Name: _ZN4FMOD13PluginFactory13tryLoadPluginEPKcPjbj
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::tryLoadPlugin(
        FMOD::PluginFactory *const this,
        const char *dllname,
        unsigned int *handle,
        bool calledinternally,
        unsigned int priority)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::PluginFactory::loadPlugin(this, dllname, handle, calledinternally, priority);
  if ( result == FMOD_RESULT::FMOD_ERR_FILE_BAD_0 || result == FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0 )
    return FMOD_RESULT::FMOD_OK_0;
  return result;
}


// Address: 0x2221db0 | Name: _ZN4FMOD13PluginFactory19getNumNestedPluginsEjPi
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getNumNestedPlugins(
        FMOD::PluginFactory *const this,
        unsigned int handle,
        int *count)
{
  FMOD_RESULT_0 result; // eax
  FMOD::PluginListInfo *PluginListInfo; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( count )
  {
    PluginListInfo = FMOD::PluginFactory::getPluginListInfo(this, handle);
    if ( PluginListInfo )
    {
      *count = PluginListInfo->mCount;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      *count = 1;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2221de0 | Name: _ZN4FMOD13PluginFactory15getNestedPluginEjiPj
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::getNestedPlugin(
        FMOD::PluginFactory *const this,
        unsigned int handle,
        int index,
        unsigned int *nestedHandle)
{
  FMOD::PluginListInfo *PluginListInfo; // rax

  if ( !nestedHandle || index < 0 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  PluginListInfo = FMOD::PluginFactory::getPluginListInfo(this, handle);
  if ( PluginListInfo )
  {
    if ( index >= PluginListInfo->mCount )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    *nestedHandle = PluginListInfo->mHandles[index];
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( index )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    *nestedHandle = handle;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x2221e50 | Name: _ZN4FMOD13PluginFactory11createCodecEPNS_25FMOD_CODEC_DESCRIPTION_EXEPPNS_5CodecE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::createCodec(
        FMOD::PluginFactory *const this,
        FMOD::FMOD_CODEC_DESCRIPTION_EX *codecdesc,
        FMOD::Codec **codec)
{
  FMOD_RESULT_0 result; // eax
  int mSize; // eax
  int v7; // esi
  _DWORD *v8; // rax
  _DWORD *v9; // r8
  char *v10; // rdi
  FMOD::FMOD_CODEC_DESCRIPTION_EX *v11; // rsi
  unsigned int v12; // eax
  __int64 v13; // rdx
  __int64 v14; // rcx
  char *v15; // rdi
  const char **v16; // rsi
  int v17; // edx
  __int16 name; // dx

  if ( !codecdesc || !codec )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mSize = codecdesc->mSize;
  v7 = 416;
  if ( mSize > 415 )
    v7 = mSize;
  v8 = FMOD::MemPool::calloc(off_286F358->gSystemMemPool, v7, "../../../core_api/src/fmod_pluginfactory.cpp", 1494, 0);
  v9 = v8;
  if ( !v8 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v8[20] = 0;
  *((_QWORD *)v8 + 40) = 0;
  v10 = (char *)(v8 + 22);
  *((_QWORD *)v8 + 41) = 0;
  *((_QWORD *)v8 + 42) = 0;
  v11 = codecdesc;
  *((_QWORD *)v8 + 46) = 0;
  *((_QWORD *)v8 + 43) = 0;
  v8[88] = 0;
  v8[89] = 0;
  *((_QWORD *)v8 + 50) = 0;
  *((_QWORD *)v8 + 5) = FMOD::Codec::defaultFileRead;
  *((_QWORD *)v8 + 6) = FMOD::Codec::defaultFileSeek;
  *((_QWORD *)v8 + 7) = FMOD::Codec::defaultMetaData;
  v12 = 216;
  if ( (((_BYTE)v9 + 88) & 1) != 0 )
  {
    v10 = (char *)v9 + 89;
    v11 = (FMOD::FMOD_CODEC_DESCRIPTION_EX *)((char *)&codecdesc->name + 1);
    *((_BYTE *)v9 + 88) = codecdesc->name;
    v12 = 215;
  }
  if ( ((unsigned __int8)v10 & 2) != 0 )
  {
    name = (__int16)v11->name;
    v10 += 2;
    v11 = (FMOD::FMOD_CODEC_DESCRIPTION_EX *)((char *)v11 + 2);
    v12 -= 2;
    *((_WORD *)v10 - 1) = name;
  }
  if ( ((unsigned __int8)v10 & 4) != 0 )
  {
    v17 = (int)v11->name;
    v10 += 4;
    v11 = (FMOD::FMOD_CODEC_DESCRIPTION_EX *)((char *)v11 + 4);
    v12 -= 4;
    *((_DWORD *)v10 - 1) = v17;
  }
  v13 = 0;
  v14 = v12 >> 3;
  qmemcpy(v10, v11, 8 * v14);
  v16 = &v11->name + v14;
  v15 = &v10[8 * v14];
  if ( (v12 & 4) != 0 )
  {
    *(_DWORD *)v15 = *(_DWORD *)v16;
    v13 = 4;
    if ( (v12 & 2) == 0 )
    {
LABEL_16:
      if ( (v12 & 1) == 0 )
        goto LABEL_17;
LABEL_19:
      v15[v13] = *((_BYTE *)v16 + v13);
      *codec = (FMOD::Codec *)v9;
      result = FMOD_RESULT::FMOD_OK_0;
      if ( !*((_QWORD *)v9 + 21) )
        goto LABEL_18;
      return result;
    }
  }
  else if ( (v12 & 2) == 0 )
  {
    goto LABEL_16;
  }
  *(_WORD *)&v15[v13] = *(_WORD *)((char *)v16 + v13);
  v13 += 2;
  if ( (v12 & 1) != 0 )
    goto LABEL_19;
LABEL_17:
  *codec = (FMOD::Codec *)v9;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( !*((_QWORD *)v9 + 21) )
LABEL_18:
    *((_QWORD *)v9 + 21) = FMOD::Codec::defaultGetWaveFormat;
  return result;
}


// Address: 0x2222050 | Name: _ZN4FMOD13PluginFactory9createDSPEPNS_23FMOD_DSP_DESCRIPTION_EXEPK20FMOD_DSP_DESCRIPTIONPPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::createDSP(
        FMOD::PluginFactory *const this,
        FMOD::FMOD_DSP_DESCRIPTION_EX *dspdesc_ex,
        const FMOD_DSP_DESCRIPTION_0 *dspdesc,
        FMOD::DSPI **dsp)
{
  FMOD_RESULT_0 result; // eax
  FMOD::FMOD_DSP_DESCRIPTION_EX *p_dspdesc_internal; // rbx
  char v8; // r13
  int mSize; // edx
  unsigned __int64 v10; // r12
  FMOD::SystemI *mSystem; // rax
  FMOD::DSPI *v12; // rdi
  FMOD_DSP_STATE_FUNCTIONS *p_mDSPFunctions; // rdx
  int numparameters; // esi
  FMOD_DSP_DESCRIPTION *v16; // rax
  _WORD *v17; // rdi
  const FMOD_DSP_DESCRIPTION_0 *v18; // rsi
  unsigned int v19; // edx
  __int64 v20; // rcx
  __int64 v21; // rcx
  unsigned int *v22; // rdi
  unsigned int *v23; // rsi
  __int64 v24; // rcx
  FMOD_DSP_PARAMETER_DESC **paramdesc; // rsi
  __int64 v26; // r9
  FMOD_DSP_PARAMETER_DESC *v27; // rsi
  FMOD_DSP_PARAMETER_DESC *v28; // r8
  bool v29; // zf
  int v30; // esi
  void *v31; // rax
  void *v32; // r8
  FMOD::SystemI *v33; // rax
  FMOD_DSP_STATE_FUNCTIONS *v34; // rdx
  FMOD_RESULT_0 v35; // ebx
  int v36; // esi
  void *v37; // rax
  unsigned int v38; // ecx
  __int16 pluginsdkversion; // cx
  void *newdspmemorya; // [rsp+8h] [rbp-80h]
  void *newdspmemory; // [rsp+8h] [rbp-80h]
  void *newdspmemoryb; // [rsp+8h] [rbp-80h]
  FMOD::FMOD_DSP_DESCRIPTION_EX dspdesc_internal; // [rsp+10h] [rbp-78h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !dsp )
    return result;
  p_dspdesc_internal = dspdesc_ex;
  if ( dspdesc_ex )
  {
    v8 = 0;
    if ( !dspdesc_ex->mName && dspdesc_ex->mDescription )
      dspdesc_ex->mName = dspdesc_ex->mDescription->name;
  }
  else
  {
    if ( !dspdesc )
      return result;
    numparameters = dspdesc->numparameters;
    memset(&dspdesc_internal, 0, sizeof(dspdesc_internal));
    v16 = (FMOD_DSP_DESCRIPTION *)FMOD::MemPool::calloc(
                                    off_286F358->gSystemMemPool,
                                    104 * numparameters + 216,
                                    "../../../core_api/src/fmod_pluginfactory.cpp",
                                    1553,
                                    0);
    if ( !v16 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    dspdesc_internal.mDescription = v16;
    dspdesc_internal.mSize = 528;
    v17 = v16;
    v18 = dspdesc;
    v19 = 216;
    if ( ((unsigned __int8)v16 & 1) != 0 )
    {
      v17 = (_WORD *)((char *)&v16->pluginsdkversion + 1);
      v18 = (const FMOD_DSP_DESCRIPTION_0 *)((char *)&dspdesc->pluginsdkversion + 1);
      LOBYTE(v16->pluginsdkversion) = dspdesc->pluginsdkversion;
      v19 = 215;
    }
    if ( ((unsigned __int8)v17 & 2) != 0 )
    {
      pluginsdkversion = v18->pluginsdkversion;
      ++v17;
      v18 = (const FMOD_DSP_DESCRIPTION_0 *)((char *)v18 + 2);
      v19 -= 2;
      *(v17 - 1) = pluginsdkversion;
    }
    if ( ((unsigned __int8)v17 & 4) != 0 )
    {
      v38 = v18->pluginsdkversion;
      v17 += 2;
      v18 = (const FMOD_DSP_DESCRIPTION_0 *)((char *)v18 + 4);
      v19 -= 4;
      *((_DWORD *)v17 - 1) = v38;
    }
    v20 = v19 >> 3;
    qmemcpy(v17, v18, 8 * v20);
    v23 = &v18->pluginsdkversion + 2 * v20;
    v22 = (unsigned int *)&v17[4 * v20];
    v21 = 0;
    if ( (v19 & 4) != 0 )
    {
      *v22 = *v23;
      v21 = 4;
    }
    if ( (v19 & 2) != 0 )
    {
      *(_WORD *)((char *)v22 + v21) = *(_WORD *)((char *)v23 + v21);
      v21 += 2;
    }
    if ( (v19 & 1) != 0 )
      *((_BYTE *)v22 + v21) = *((_BYTE *)v23 + v21);
    v24 = dspdesc->numparameters;
    paramdesc = (FMOD_DSP_PARAMETER_DESC **)&v16[1];
    v26 = 0;
    v16->paramdesc = (FMOD_DSP_PARAMETER_DESC **)&v16[1];
    if ( (int)v24 > 0 )
    {
      while ( 1 )
      {
        paramdesc[v26] = (FMOD_DSP_PARAMETER_DESC *)(&paramdesc[12 * v26] + v24);
        v27 = v16->paramdesc[v26];
        v28 = dspdesc->paramdesc[v26];
        *(_QWORD *)&v27->type = *(_QWORD *)&v28->type;
        *(_QWORD *)&v27->name[4] = *(_QWORD *)&v28->name[4];
        *(_QWORD *)&v27->name[12] = *(_QWORD *)&v28->name[12];
        *(_QWORD *)&v27->label[4] = *(_QWORD *)&v28->label[4];
        *(_QWORD *)&v27->label[12] = *(_QWORD *)&v28->label[12];
        v27->description = v28->description;
        *(_QWORD *)&v27->floatdesc.min = *(_QWORD *)&v28->floatdesc.min;
        v27->booldesc.valuenames = v28->booldesc.valuenames;
        v27->intdesc.valuenames = v28->intdesc.valuenames;
        *((_QWORD *)&v27->datadesc + 3) = *((_QWORD *)&v28->datadesc + 3);
        v27->floatdesc.mapping.piecewiselinearmapping.pointparamvalues = v28->floatdesc.mapping.piecewiselinearmapping.pointparamvalues;
        v27->floatdesc.mapping.piecewiselinearmapping.pointpositions = v28->floatdesc.mapping.piecewiselinearmapping.pointpositions;
        v24 = dspdesc->numparameters;
        if ( (int)v24 <= (int)++v26 )
          break;
        paramdesc = v16->paramdesc;
      }
    }
    v29 = v16->process == 0;
    dspdesc_internal.mName = dspdesc_internal.mDescription->name;
    if ( v29 )
    {
      v16->numinputbuffers = 1;
      v16->numoutputbuffers = 1;
    }
    v8 = 1;
    p_dspdesc_internal = &dspdesc_internal;
  }
  mSize = p_dspdesc_internal->mSize;
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( mSize < 0 )
    return result;
  v10 = (unsigned __int64)*dsp;
  if ( *dsp )
  {
    mSystem = this->mSystem;
    v12 = *dsp;
    p_mDSPFunctions = &mSystem->mDSPFunctions;
    *(_QWORD *)(v10 + 176) = mSystem;
    LODWORD(mSystem) = *(_DWORD *)((char *)&stru_115E0.r_offset + (_QWORD)mSystem);
    *(_QWORD *)(v10 + 224) = p_mDSPFunctions;
    *(_DWORD *)(v10 + 232) = (_DWORD)mSystem;
    result = FMOD::DSPI::alloc(v12, p_dspdesc_internal);
    if ( result )
      return result;
    goto LABEL_29;
  }
  if ( *(&p_dspdesc_internal->mHandle + 1) != 1001 )
  {
    v30 = mSize + 16;
    if ( mSize <= 527 )
    {
      v30 = 544;
      mSize = 528;
    }
    p_dspdesc_internal->mSize = mSize;
    v31 = FMOD::MemPool::calloc(
            off_286F358->gSystemMemPool,
            v30,
            "../../../core_api/src/fmod_pluginfactory.cpp",
            1649,
            0);
    v32 = v31;
    if ( v31 )
    {
      v10 = ((unsigned __int64)v31 + 15) & 0xFFFFFFFFFFFFFFF0LL;
      if ( v10 )
      {
        newdspmemorya = v31;
        FMOD::DSPI::DSPI((FMOD::DSPI *const)(((unsigned __int64)v31 + 15) & 0xFFFFFFFFFFFFFFF0LL));
        v32 = newdspmemorya;
      }
      goto LABEL_40;
    }
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
  v36 = mSize + 16;
  if ( mSize <= 727 )
  {
    v36 = 744;
    mSize = 728;
  }
  p_dspdesc_internal->mSize = mSize;
  v37 = FMOD::MemPool::calloc(off_286F358->gSystemMemPool, v36, "../../../core_api/src/fmod_pluginfactory.cpp", 1627, 0);
  v32 = v37;
  if ( !v37 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v10 = ((unsigned __int64)v37 + 15) & 0xFFFFFFFFFFFFFFF0LL;
  if ( v10 )
  {
    newdspmemoryb = v37;
    FMOD::DSPResampler::DSPResampler((FMOD::DSPResampler *const)(((unsigned __int64)v37 + 15) & 0xFFFFFFFFFFFFFFF0LL));
    *(_QWORD *)(v10 + 704) = 0;
    *(_QWORD *)(v10 + 712) = 0;
    *(_QWORD *)(v10 + 720) = 0;
    v32 = newdspmemoryb;
    *(_QWORD *)v10 = off_29B10F0;
    *(_QWORD *)(v10 + 696) = v10 + 704;
  }
LABEL_40:
  v33 = this->mSystem;
  *(_QWORD *)(v10 + 312) = v32;
  newdspmemory = v32;
  v34 = &v33->mDSPFunctions;
  *(_QWORD *)(v10 + 176) = v33;
  LODWORD(v33) = *(_DWORD *)((char *)&stru_115E0.r_offset + (_QWORD)v33);
  *(_QWORD *)(v10 + 224) = v34;
  *(_DWORD *)(v10 + 232) = (_DWORD)v33;
  v35 = FMOD::DSPI::alloc((FMOD::DSPI *const)v10, p_dspdesc_internal);
  if ( v35 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, newdspmemory, "../../../core_api/src/fmod_pluginfactory.cpp", 1678);
    return v35;
  }
LABEL_29:
  if ( v8 )
    *(_WORD *)(v10 + 92) |= 2u;
  *dsp = (FMOD::DSPI *)v10;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22224d0 | Name: _ZN4FMOD13PluginFactory12createOutputEPNS_26FMOD_OUTPUT_DESCRIPTION_EXEPPNS_6OutputE
FMOD_RESULT_0 __fastcall FMOD::PluginFactory::createOutput(
        FMOD::PluginFactory *const this,
        FMOD::FMOD_OUTPUT_DESCRIPTION_EX *outputdesc,
        FMOD::Output **output)
{
  int mSize; // edx
  int v7; // esi
  FMOD::Output *v8; // rax
  FMOD::Output *v9; // rbx
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *p_mDescription; // rdi
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *v11; // rsi
  unsigned int v12; // edx
  __int64 v13; // rcx
  __int64 v14; // rcx
  unsigned int *v15; // rdi
  unsigned int *v16; // rsi
  __int16 apiversion; // cx
  unsigned int v19; // ecx

  mSize = outputdesc->mSize;
  v7 = 1144;
  if ( mSize > 1143 )
    v7 = mSize;
  v8 = (FMOD::Output *)FMOD::MemPool::calloc(
                         off_286F358->gSystemMemPool,
                         v7,
                         "../../../core_api/src/fmod_pluginfactory.cpp",
                         1707,
                         0);
  v9 = v8;
  if ( v8 )
  {
    FMOD::Output::Output(v8);
    p_mDescription = &v9->mDescription;
    v11 = outputdesc;
    v12 = 264;
    if ( (((_BYTE)v9 + 112) & 1) != 0 )
    {
      p_mDescription = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)&v9->mDescription.apiversion + 1);
      v11 = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)&outputdesc->apiversion + 1);
      LOBYTE(v12) = 7;
      LOBYTE(v9->mDescription.apiversion) = outputdesc->apiversion;
    }
    if ( ((unsigned __int8)p_mDescription & 2) != 0 )
    {
      apiversion = v11->apiversion;
      p_mDescription = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)p_mDescription + 2);
      v11 = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)v11 + 2);
      v12 -= 2;
      HIWORD(p_mDescription[-1].record_unlock) = apiversion;
    }
    if ( ((unsigned __int8)p_mDescription & 4) != 0 )
    {
      v19 = v11->apiversion;
      p_mDescription = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)p_mDescription + 4);
      v11 = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)v11 + 4);
      v12 -= 4;
      HIDWORD(p_mDescription[-1].record_unlock) = v19;
    }
    v13 = v12 >> 3;
    qmemcpy(p_mDescription, v11, 8 * v13);
    v16 = &v11->apiversion + 2 * v13;
    v15 = &p_mDescription->apiversion + 2 * v13;
    v14 = 0;
    if ( (v12 & 4) != 0 )
    {
      *v15 = *v16;
      v14 = 4;
      if ( (v12 & 2) == 0 )
      {
LABEL_12:
        if ( (v12 & 1) == 0 )
        {
LABEL_13:
          v9->mSystem = this->mSystem;
          v9->readfrommixer = FMOD::Output::mixCallback;
          v9->copyport = FMOD::Output::copyPortCallback;
          v9->requestreset = FMOD::Output::requestResetCallback;
          v9->alloc = FMOD::SystemI::pluginAlloc;
          v9->free = FMOD::SystemI::pluginFree;
          v9->log = FMOD::SystemI::pluginLog;
          *output = v9;
          return FMOD_RESULT::FMOD_OK_0;
        }
LABEL_14:
        *((_BYTE *)v15 + v14) = *((_BYTE *)v16 + v14);
        goto LABEL_13;
      }
    }
    else if ( (v12 & 2) == 0 )
    {
      goto LABEL_12;
    }
    *(_WORD *)((char *)v15 + v14) = *(_WORD *)((char *)v16 + v14);
    v14 += 2;
    if ( (v12 & 1) == 0 )
      goto LABEL_13;
    goto LABEL_14;
  }
  *output = 0;
  return FMOD_RESULT::FMOD_ERR_MEMORY_0;
}


