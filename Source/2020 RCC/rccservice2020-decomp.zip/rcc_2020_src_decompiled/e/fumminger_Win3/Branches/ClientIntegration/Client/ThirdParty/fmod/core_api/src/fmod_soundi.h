// Address: 0x21ee630 | Name: _ZN4FMOD6SoundI19getSamplesFromBytesEjPji17FMOD_SOUND_FORMAT
FMOD_RESULT_0 __fastcall FMOD::SoundI::getSamplesFromBytes(
        unsigned int bytes,
        unsigned int *samples,
        int channels,
        FMOD_SOUND_FORMAT_0 format)
{
  FMOD_RESULT_0 result; // eax
  unsigned __int64 v5; // rcx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channels )
  {
    switch ( format )
    {
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
        v5 = 8;
        goto LABEL_4;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
        v5 = 16;
        goto LABEL_4;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
        v5 = 24;
        goto LABEL_4;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
        v5 = 32;
LABEL_4:
        *samples = (unsigned int)(8 * (unsigned __int64)bytes / v5) / channels;
        result = FMOD_RESULT::FMOD_OK_0;
        break;
      default:
        *samples = bytes;
        result = FMOD_RESULT::FMOD_OK_0;
        break;
    }
  }
  return result;
}


// Address: 0x21ee6c0 | Name: _ZN4FMOD6SoundI17getBitsFromFormatE17FMOD_SOUND_FORMATPi
FMOD_RESULT_0 __fastcall FMOD::SoundI::getBitsFromFormat(FMOD_SOUND_FORMAT_0 format, int *bits)
{
  FMOD_RESULT_0 result; // eax

  switch ( format )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      *bits = 8;
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      *bits = 16;
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      *bits = 24;
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      *bits = 32;
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    default:
      *bits = 0;
      result = FMOD_RESULT::FMOD_OK_0;
      break;
  }
  return result;
}


// Address: 0x21f7070 | Name: _ZN4FMOD6SoundI8isStreamEv
bool __fastcall FMOD::SoundI::isStream(FMOD::SoundI *const this)
{
  return 0;
}


