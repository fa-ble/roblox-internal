// Address: 0x222a840 | Name: FMOD_DSPThreeEQ_filterArray12dB_SSE
void __fastcall FMOD_DSPThreeEQ_filterArray12dB_SSE(
        float *out,
        float *in,
        int length,
        int stride,
        int channel,
        FMOD::BiquadFilter (*lowpass1)[32],
        float lowgain,
        float midgain,
        float highgain,
        FMOD::BiquadFilter (*lowpass2)[32],
        FMOD::BiquadFilter (*highpass1)[32],
        FMOD::BiquadFilter (*highpass2)[32])
{
  __int64 v12; // r8
  const FMOD::BiquadCoefficients *mCoefficients; // rbx
  __m128 *v14; // r9
  __m128 *v15; // r13
  __m128 *v16; // r11
  __m128 *v17; // r12
  const FMOD::BiquadCoefficients *v18; // rbp
  __m128 v19; // xmm6
  __m128 b0_low; // xmm11
  __m128 v21; // xmm12
  __m128 *v22; // rbp
  __m128 v23; // xmm11
  __m128 *v24; // rbx
  __m128 v25; // xmm8
  __m128 v26; // xmm13
  __m128 v27; // xmm11
  __m128 v28; // xmm14
  __m128 v29; // xmm4
  __m128 v30; // xmm3
  __m128 v31; // xmm5
  __m128 v32; // xmm0
  __m128 v33; // xmm6
  __m128 v34; // xmm7
  __m128 v35; // xmm5
  __m128 v36; // xmm0
  __m128 v37; // xmm9
  __m128 v38; // xmm8
  __m128 v39; // xmm9
  __m128 v40; // xmm7
  __int64 v41; // rax
  int v42; // r8d
  __int64 v43; // r10
  float *v44; // rsi
  __m128 v45; // xmm10
  __m128 v46; // xmm3
  __m128 v47; // xmm0
  __m128 v48; // xmm4
  __m128 v49; // xmm0
  __m128 v50; // xmm3
  __m128 v51; // xmm0
  __m128 v52; // xmm4
  __m128 v53; // xmm3
  __m128 v54; // xmm15
  __m128 v55; // xmm10
  __m128 v56; // xmm12
  __m128 v57; // xmm12
  __m128 v58; // xmm0
  __m128 v60; // [rsp+10h] [rbp-48h]

  v12 = channel;
  mCoefficients = (*lowpass1)[0].mCoefficients;
  v14 = (__m128 *)&(*lowpass1)[v12];
  v15 = (__m128 *)(*highpass1)[0].mCoefficients;
  v16 = (__m128 *)&(*highpass1)[v12];
  v17 = (__m128 *)(*highpass2)[0].mCoefficients;
  v18 = (*lowpass2)[0].mCoefficients;
  v19 = *(__m128 *)mCoefficients->coeff;
  b0_low = (__m128)LODWORD(v18->b0);
  v21 = *(__m128 *)v18->coeff;
  v22 = (__m128 *)&(*highpass2)[v12];
  v23 = _mm_unpacklo_ps(b0_low, (__m128)LODWORD(mCoefficients->b0));
  v24 = (__m128 *)&(*lowpass2)[v12];
  v25 = _mm_movelh_ps(*v14, *v14);
  v26 = *v15;
  v27 = _mm_movelh_ps(v23, _mm_unpacklo_ps((__m128)v15[1].m128_u32[0], (__m128)v17[1].m128_u32[0]));
  v28 = *v17;
  v29 = _mm_movelh_ps(*v16, *v16);
  v30 = _mm_movelh_ps(*v22, *v22);
  v31 = _mm_hadd_ps((__m128)0LL, _mm_mul_ps(v19, v25));
  v60 = v19;
  v32 = _mm_hadd_ps(_mm_mul_ps(*v15, v29), _mm_mul_ps(*v17, v30));
  v33 = _mm_movelh_ps(*v24, *v24);
  v34 = _mm_add_ps(
          _mm_shuffle_ps(v31, v32, 136),
          _mm_shuffle_ps((__m128)*(unsigned int *)in, (__m128)*(unsigned int *)in, 0));
  v35 = _mm_add_ps(_mm_shuffle_ps(v31, v32, 221), _mm_mul_ps(v27, v34));
  v36 = _mm_moveldup_ps(v25);
  v37 = _mm_movehdup_ps(v34);
  v38 = _mm_unpackhi_ps(v37, _mm_moveldup_ps(v30));
  v39 = _mm_unpacklo_ps(v37, v36);
  v40 = _mm_unpackhi_ps(_mm_moveldup_ps(v34), _mm_moveldup_ps(v29));
  if ( length <= 1 )
  {
    v55 = v35;
  }
  else
  {
    v41 = 0;
    v42 = 1;
    v43 = stride;
    v44 = &in[v43];
    while ( 1 )
    {
      v45 = (__m128)*(unsigned int *)((char *)v44 + v41);
      ++v42;
      v46 = _mm_hadd_ps(_mm_mul_ps(v26, v40), _mm_mul_ps(v28, v38));
      v47 = _mm_hadd_ps(_mm_mul_ps(v21, v33), _mm_mul_ps(v60, v39));
      v48 = _mm_shuffle_ps(v47, v46, 221);
      v49 = _mm_shuffle_ps(v47, v46, 136);
      v50 = v35;
      v50.m128_f32[0] = v45.m128_f32[0];
      v51 = _mm_add_ps(v49, _mm_shuffle_ps(v50, v45, 2));
      v52 = _mm_add_ps(v48, _mm_mul_ps(v27, v51));
      v53 = _mm_moveldup_ps(v51);
      v40 = _mm_unpackhi_ps(v53, _mm_moveldup_ps(v40));
      v33 = _mm_unpacklo_ps(v53, _mm_moveldup_ps(v33));
      v54 = _mm_movehdup_ps(v51);
      v55 = v52;
      v38 = _mm_unpackhi_ps(v54, _mm_moveldup_ps(v38));
      v39 = _mm_unpacklo_ps(v54, _mm_moveldup_ps(v39));
      *(float *)((char *)out + v41) = (float)((float)(_mm_shuffle_ps(v35, v35, 85).m128_f32[0] * lowgain)
                                            - (float)(v52.m128_f32[0] * midgain))
                                    + (float)(_mm_shuffle_ps(v35, v35, 255).m128_f32[0] * highgain);
      v41 += v43 * 4;
      if ( v42 == length )
        break;
      v35 = v52;
    }
  }
  v56 = _mm_mul_ps(v21, v33);
  v57 = _mm_hadd_ps(v56, v56);
  v58 = _mm_shuffle_ps(v57, v57, 136);
  v58.m128_f32[0] = v58.m128_f32[0] + _mm_shuffle_ps(v55, v55, 2).m128_f32[0];
  out[stride * (length - 1)] = (float)((float)(_mm_shuffle_ps(v55, v55, 85).m128_f32[0] * lowgain)
                                     - (float)((float)(_mm_shuffle_ps(v57, v57, 221).m128_f32[0]
                                                     + (float)(v27.m128_f32[0] * v33.m128_f32[0]))
                                             * midgain))
                             + (float)(_mm_shuffle_ps(v55, v55, 255).m128_f32[0] * highgain);
  _mm_storel_ps((double *)v14->m128_u64, v39);
  _mm_storel_ps((double *)v16->m128_u64, v40);
  _mm_storel_ps((double *)v22->m128_u64, v38);
  _mm_storel_ps((double *)v24->m128_u64, _mm_unpacklo_ps(_mm_moveldup_ps(v58), _mm_moveldup_ps(v33)));
}


// Address: 0x222aaf0 | Name: FMOD_DSPThreeEQ_filterArray24dB_SSE
void __fastcall FMOD_DSPThreeEQ_filterArray24dB_SSE(
        float *out,
        float *in,
        int length,
        int stride,
        int channel,
        FMOD::BiquadFilter (*lowpass1)[32],
        float lowgain,
        float midgain,
        float highgain,
        FMOD::BiquadFilter (*lowpass2)[32],
        FMOD::BiquadFilter (*highpass1)[32],
        FMOD::BiquadFilter (*highpass2)[32])
{
  const FMOD::BiquadCoefficients *mCoefficients; // rax
  const FMOD::BiquadCoefficients *v13; // r12
  const FMOD::BiquadCoefficients *v14; // r13
  const FMOD::BiquadCoefficients *v15; // rbp
  __m128 v16; // xmm7
  __m128 v17; // xmm10
  __int64 v18; // rax
  __m128 v19; // xmm5
  __m128 *v20; // r14
  __m128 v21; // xmm10
  double *p_w1; // r15
  __m128 v23; // xmm11
  __m128 *v25; // rbp
  __m128 *v26; // r13
  __m128 *v27; // rbx
  __m128 *v28; // r12
  __m128 *v29; // r11
  __m128 v30; // xmm9
  __m128 v31; // xmm0
  __m128 v32; // xmm6
  __m128 v33; // xmm8
  __m128 v34; // xmm14
  __m128 v35; // xmm15
  __m128 v36; // xmm5
  __m128 v37; // xmm4
  __m128 v38; // xmm0
  __m128 v39; // xmm1
  __m128 v40; // xmm7
  __m128 v41; // xmm3
  __m128 v42; // xmm1
  __m128 v43; // xmm0
  __m128 v44; // xmm7
  __m128 v45; // xmm1
  __m128 v46; // xmm12
  __m128 v47; // xmm7
  __m128 v48; // xmm13
  __m128 v49; // xmm12
  __m128 v50; // xmm0
  __m128 v51; // xmm6
  __m128 v52; // xmm3
  __m128 v53; // xmm0
  __m128 v54; // xmm9
  __m128 v55; // xmm8
  __m128 v56; // xmm9
  __m128 v57; // xmm6
  __int64 v58; // rax
  int v59; // r8d
  __int64 v60; // r9
  float *v61; // rsi
  __m128 v62; // xmm15
  __m128 v63; // xmm1
  __m128 v64; // xmm0
  __m128 v65; // xmm14
  __m128 v66; // xmm2
  __m128 v67; // xmm0
  __m128 v68; // xmm2
  __m128 v69; // xmm1
  __m128 v70; // xmm0
  __m128 v71; // xmm14
  __m128 v72; // xmm1
  __m128 v73; // xmm0
  __m128 v74; // xmm2
  __m128 v75; // xmm0
  __m128 v76; // xmm2
  __m128 v77; // xmm1
  __m128 v78; // xmm15
  __m128 v79; // xmm14
  __m128 v80; // xmm1
  __m128 v81; // xmm1
  __m128 v82; // xmm0
  __m128 v83; // xmm2
  __m128 v84; // xmm2
  __m128 v85; // xmm3
  __m128 coeff_3; // [rsp+0h] [rbp-A8h]
  __m128 coeff_4; // [rsp+10h] [rbp-98h]
  __m128 coeff_5; // [rsp+20h] [rbp-88h]
  float v89; // [rsp+30h] [rbp-78h]
  __int64 channela; // [rsp+68h] [rbp-40h]

  mCoefficients = (*lowpass1)[0].mCoefficients;
  v13 = (*highpass2)[0].mCoefficients;
  v14 = (*highpass1)[0].mCoefficients;
  v15 = (*lowpass2)[0].mCoefficients;
  v16 = *(__m128 *)mCoefficients->coeff;
  coeff_5 = *(__m128 *)v13->coeff;
  v17 = _mm_unpacklo_ps((__m128)LODWORD(v15->b0), (__m128)LODWORD(mCoefficients->b0));
  channela = channel;
  v18 = channel;
  v19 = *(__m128 *)v14->coeff;
  v20 = (__m128 *)&(*highpass2)[v18];
  v21 = _mm_movelh_ps(v17, _mm_unpacklo_ps((__m128)LODWORD(v14->b0), (__m128)LODWORD(v13->b0)));
  p_w1 = (double *)&(*lowpass1)[v18].w1;
  v23 = *(__m128 *)v15->coeff;
  v25 = (__m128 *)&(*highpass2)[v18 + 32];
  v26 = (__m128 *)&(*lowpass1)[v18 + 32];
  v27 = (__m128 *)&(*lowpass2)[v18];
  v28 = (__m128 *)&(*highpass1)[v18 + 32];
  v29 = (__m128 *)&(*lowpass2)[v18 + 32];
  coeff_4 = v19;
  v30 = _mm_movelh_ps((__m128)(*lowpass1)[v18], (__m128)(*lowpass1)[v18]);
  v31 = _mm_mul_ps(v19, v30);
  v32 = _mm_movelh_ps(*v20, *v20);
  v33 = _mm_movelh_ps(*v26, *v26);
  v34 = _mm_movelh_ps(*v28, *v28);
  v35 = _mm_movelh_ps(*v25, *v25);
  v36 = _mm_movelh_ps(*v27, *v27);
  v89 = lowgain;
  v37 = _mm_movelh_ps(*v29, *v29);
  coeff_3 = v16;
  v38 = _mm_hadd_ps(v31, _mm_mul_ps(coeff_5, v32));
  v39 = _mm_hadd_ps((__m128)0LL, _mm_mul_ps(v16, v30));
  v40 = _mm_shuffle_ps(v39, v38, 136);
  v41 = _mm_hadd_ps((__m128)0LL, _mm_mul_ps(coeff_3, v33));
  v42 = _mm_shuffle_ps(v39, v38, 221);
  v43 = _mm_moveldup_ps(v30);
  v44 = _mm_add_ps(v40, _mm_shuffle_ps((__m128)*(unsigned int *)in, (__m128)*(unsigned int *)in, 0));
  v45 = _mm_add_ps(v42, _mm_mul_ps(v21, v44));
  v46 = _mm_movehdup_ps(v44);
  v47 = _mm_unpackhi_ps(_mm_moveldup_ps(v44), v43);
  v48 = _mm_unpacklo_ps(v46, v43);
  v49 = _mm_unpackhi_ps(v46, _mm_moveldup_ps(v32));
  v50 = _mm_hadd_ps(_mm_mul_ps(coeff_4, v34), _mm_mul_ps(coeff_5, v35));
  v51 = _mm_add_ps(_mm_shuffle_ps(v41, v50, 136), v45);
  v52 = _mm_add_ps(_mm_shuffle_ps(v41, v50, 221), _mm_mul_ps(v21, v51));
  v53 = _mm_moveldup_ps(v33);
  v54 = _mm_movehdup_ps(v51);
  v55 = _mm_unpackhi_ps(v54, _mm_moveldup_ps(v35));
  v56 = _mm_unpacklo_ps(v54, v53);
  v57 = _mm_unpackhi_ps(_mm_moveldup_ps(v51), _mm_moveldup_ps(v34));
  if ( length <= 1 )
  {
    v79 = v52;
  }
  else
  {
    v58 = 0;
    v59 = 1;
    v60 = stride;
    v61 = &in[v60];
    while ( 1 )
    {
      v62 = (__m128)*(unsigned int *)((char *)v61 + v58);
      ++v59;
      v63 = _mm_hadd_ps(_mm_mul_ps(coeff_4, v47), _mm_mul_ps(coeff_5, v49));
      v64 = _mm_hadd_ps(_mm_mul_ps(v23, v36), _mm_mul_ps(coeff_3, v48));
      v65 = _mm_shuffle_ps(v64, v63, 221);
      v66 = v52;
      v66.m128_f32[0] = v62.m128_f32[0];
      v67 = _mm_add_ps(_mm_shuffle_ps(v64, v63, 136), _mm_shuffle_ps(v66, v62, 2));
      v68 = _mm_mul_ps(v21, v67);
      v69 = _mm_moveldup_ps(v67);
      v70 = _mm_movehdup_ps(v67);
      v71 = _mm_add_ps(v65, v68);
      v36 = _mm_unpacklo_ps(v69, _mm_moveldup_ps(v36));
      v48 = _mm_unpacklo_ps(v70, _mm_moveldup_ps(v48));
      v47 = _mm_unpackhi_ps(v69, _mm_moveldup_ps(v47));
      v49 = _mm_unpackhi_ps(v70, _mm_moveldup_ps(v49));
      v72 = _mm_hadd_ps(_mm_mul_ps(coeff_4, v57), _mm_mul_ps(coeff_5, v55));
      v73 = _mm_hadd_ps(_mm_mul_ps(v23, v37), _mm_mul_ps(coeff_3, v56));
      v74 = _mm_shuffle_ps(v73, v72, 221);
      v75 = _mm_add_ps(_mm_shuffle_ps(v73, v72, 136), v71);
      v76 = _mm_add_ps(v74, _mm_mul_ps(v21, v75));
      v77 = _mm_moveldup_ps(v75);
      v57 = _mm_unpackhi_ps(v77, _mm_moveldup_ps(v57));
      v37 = _mm_unpacklo_ps(v77, _mm_moveldup_ps(v37));
      v78 = _mm_movehdup_ps(v75);
      v79 = v76;
      v55 = _mm_unpackhi_ps(v78, _mm_moveldup_ps(v55));
      v56 = _mm_unpacklo_ps(v78, _mm_moveldup_ps(v56));
      *(float *)((char *)out + v58) = (float)((float)(v76.m128_f32[0] * midgain)
                                            + (float)(_mm_shuffle_ps(v52, v52, 85).m128_f32[0] * v89))
                                    + (float)(_mm_shuffle_ps(v52, v52, 255).m128_f32[0] * highgain);
      v58 += v60 * 4;
      if ( v59 == length )
        break;
      v52 = v76;
    }
  }
  v80 = _mm_mul_ps(v23, v36);
  v81 = _mm_hadd_ps(v80, v80);
  v82 = _mm_shuffle_ps(v81, v81, 136);
  v82.m128_f32[0] = v82.m128_f32[0] + _mm_shuffle_ps(v79, v79, 2).m128_f32[0];
  v83 = _mm_mul_ps(v23, v37);
  v84 = _mm_hadd_ps(v83, v83);
  v85 = _mm_shuffle_ps(v84, v84, 136);
  v85.m128_f32[0] = v85.m128_f32[0]
                  + (float)(_mm_shuffle_ps(v81, v81, 221).m128_f32[0] + (float)(v21.m128_f32[0] * v82.m128_f32[0]));
  out[stride * (length - 1)] = (float)((float)((float)(_mm_shuffle_ps(v84, v84, 221).m128_f32[0]
                                                     + (float)(v21.m128_f32[0] * v85.m128_f32[0]))
                                             * midgain)
                                     + (float)(_mm_shuffle_ps(v79, v79, 85).m128_f32[0] * v89))
                             + (float)(_mm_shuffle_ps(v79, v79, 255).m128_f32[0] * highgain);
  _mm_storel_ps(p_w1, v48);
  _mm_storel_ps((double *)&(*highpass1)[channela].w1, v47);
  _mm_storel_ps((double *)v20->m128_u64, v49);
  _mm_storel_ps((double *)v26->m128_u64, v56);
  _mm_storel_ps((double *)v28->m128_u64, v57);
  _mm_storel_ps((double *)v25->m128_u64, v55);
  _mm_storel_ps((double *)v27->m128_u64, _mm_unpacklo_ps(_mm_moveldup_ps(v82), _mm_moveldup_ps(v36)));
  _mm_storel_ps((double *)v29->m128_u64, _mm_unpacklo_ps(_mm_moveldup_ps(v85), _mm_moveldup_ps(v37)));
}


// Address: 0x222af50 | Name: FMOD_DSPThreeEQ_filterArray48dB_SSE
void __fastcall FMOD_DSPThreeEQ_filterArray48dB_SSE(
        float *out,
        float *in,
        int length,
        int stride,
        int channel,
        FMOD::BiquadFilter (*lowpass1)[32],
        float lowgain,
        float midgain,
        float highgain,
        FMOD::BiquadFilter (*lowpass2)[32],
        FMOD::BiquadFilter (*highpass1)[32],
        FMOD::BiquadFilter (*highpass2)[32])
{
  __int64 v12; // r8
  __m128 *mCoefficients; // r12
  __m128 *v15; // r10
  __m128 *v16; // r15
  const FMOD::BiquadCoefficients *v17; // r13
  const FMOD::BiquadCoefficients *v18; // rbp
  const FMOD::BiquadCoefficients *v19; // r11
  __m128 v20; // xmm6
  const FMOD::BiquadCoefficients *v21; // rbx
  __m128 v22; // xmm4
  __m128 v23; // xmm5
  __m128 v24; // xmm3
  __m128 v25; // xmm4
  __m128 v26; // xmm3
  double *p_w1; // r15
  __m128 v28; // xmm3
  __m128 b0_low; // xmm4
  double *v30; // r13
  __m128 v31; // xmm10
  __m128 v32; // xmm11
  __m128 v33; // xmm4
  double *v34; // r12
  __m128 v35; // xmm11
  __m128 v36; // xmm4
  FMOD::BiquadFilter *v37; // rbx
  __m128 v38; // xmm6
  __m128 v39; // xmm10
  __m128 v40; // xmm3
  double *v41; // rbp
  __m128 v42; // xmm3
  __m128 v43; // xmm4
  double *v44; // r11
  double *v45; // r9
  __m128 v46; // xmm9
  __m128 v47; // xmm4
  double *v48; // r10
  __m128 v49; // xmm0
  __m128 v50; // xmm7
  __m128 v51; // xmm3
  __m128 v52; // xmm11
  __m128 *v53; // r9
  __m128 v54; // xmm14
  __m128 v55; // xmm6
  __m128 v56; // xmm14
  double *v57; // r13
  __m128 v58; // xmm6
  __m128 v59; // xmm5
  __m128 v60; // xmm15
  __m128 v61; // xmm5
  __m128 v62; // xmm3
  __m128 v63; // xmm4
  __m128 v64; // xmm12
  double *v65; // rsi
  __m128 v66; // xmm8
  __m128 v67; // xmm9
  __m128 v68; // xmm13
  __m128 v69; // xmm7
  __m128 v70; // xmm4
  __m128 v71; // xmm0
  __m128 v72; // xmm3
  __m128 v73; // xmm4
  __m128 v74; // xmm3
  __m128 v75; // xmm1
  __m128 v76; // xmm12
  __m128 v77; // xmm13
  __m128 v78; // xmm12
  __m128 v79; // xmm4
  __m128 v80; // xmm0
  __m128 v81; // xmm1
  __m128 v82; // xmm3
  __m128 v83; // xmm2
  __m128 v84; // xmm11
  __m128 v85; // xmm10
  __m128 v86; // xmm1
  __m128 v87; // xmm0
  __m128 v88; // xmm5
  __m128 v89; // xmm8
  __m128 v90; // xmm7
  __m128 v91; // xmm1
  __m128 v92; // xmm9
  __m128 v93; // xmm5
  __m128 v94; // xmm8
  __m128 v95; // xmm0
  __m128 v96; // xmm4
  __m128 v97; // xmm3
  __m128 v98; // xmm6
  __m128 v99; // xmm7
  __m128 v100; // xmm4
  __m128 v101; // xmm6
  __int64 v102; // rax
  int v103; // ecx
  __int64 v104; // r8
  float *v105; // r14
  __m128 v106; // xmm14
  __m128 v107; // xmm1
  __m128 v108; // xmm0
  __m128 v109; // xmm2
  __m128 v110; // xmm0
  __m128 v111; // xmm1
  __m128 v112; // xmm0
  __m128 v113; // xmm1
  __m128 v114; // xmm14
  __m128 v115; // xmm15
  __m128 v116; // xmm1
  __m128 v117; // xmm0
  __m128 v118; // xmm15
  __m128 v119; // xmm1
  __m128 v120; // xmm2
  __m128 v121; // xmm14
  __m128 v122; // xmm1
  __m128 v123; // xmm0
  __m128 v124; // xmm14
  __m128 v125; // xmm1
  __m128 v126; // xmm15
  __m128 v127; // xmm1
  __m128 v128; // xmm2
  __m128 v129; // xmm0
  __m128 v130; // xmm2
  __m128 v131; // xmm1
  __m128 v132; // xmm14
  __m128 v133; // xmm4
  __m128 v134; // xmm1
  __m128 v135; // xmm0
  __m128 v136; // xmm0
  __m128 v137; // xmm0
  __m128 v138; // xmm3
  __m128 v139; // xmm15
  __m128 v140; // xmm1
  __m128 v141; // xmm1
  __m128 v142; // xmm3
  __m128 v143; // xmm0
  __m128 v144; // xmm3
  __m128 v145; // xmm0
  __m128 v146; // xmm2
  __m128 v147; // xmm2
  __m128 feedback_1; // [rsp+0h] [rbp-1F8h] BYREF
  __m128 feedback_4; // [rsp+10h] [rbp-1E8h] BYREF
  __m128 feedback_A; // [rsp+20h] [rbp-1D8h] BYREF
  __m128 b_F9AB; // [rsp+30h] [rbp-1C8h] BYREF
  __m128 b_D345; // [rsp+40h] [rbp-1B8h] BYREF
  __m128 feedback_C; // [rsp+50h] [rbp-1A8h] BYREF
  __m128 feedback_E; // [rsp+60h] [rbp-198h] BYREF
  __m128 feedback_F; // [rsp+70h] [rbp-188h] BYREF
  __m128 coeff_4; // [rsp+80h] [rbp-178h]
  __m128 coeff_F; // [rsp+90h] [rbp-168h]
  __m128 feedback_D; // [rsp+A0h] [rbp-158h] BYREF
  __m128 coeff_3; // [rsp+B0h] [rbp-148h]
  __m128 coeff_5; // [rsp+C0h] [rbp-138h]
  __m128 coeff_9; // [rsp+D0h] [rbp-128h]
  __m128 coeff_A; // [rsp+E0h] [rbp-118h]
  __m128 coeff_B; // [rsp+F0h] [rbp-108h]
  __m128 coeff_D; // [rsp+100h] [rbp-F8h]
  __m128 v165; // [rsp+110h] [rbp-E8h]
  __int128 lowgaina; // [rsp+120h] [rbp-D8h]
  __int128 v167; // [rsp+130h] [rbp-C8h]
  __m128 v168; // [rsp+140h] [rbp-B8h] BYREF
  __m128 v169; // [rsp+150h] [rbp-A8h] BYREF
  __m128 v170; // [rsp+160h] [rbp-98h] BYREF
  __m128 v171; // [rsp+170h] [rbp-88h] BYREF
  int stridea; // [rsp+184h] [rbp-74h]
  double *v173; // [rsp+188h] [rbp-70h]
  double *v174; // [rsp+190h] [rbp-68h]
  double *v175; // [rsp+198h] [rbp-60h]
  double *v176; // [rsp+1A0h] [rbp-58h]
  double *v177; // [rsp+1A8h] [rbp-50h]
  double *v178; // [rsp+1B0h] [rbp-48h]
  double *v179; // [rsp+1B8h] [rbp-40h]

  v12 = channel;
  mCoefficients = (__m128 *)(*lowpass1)[0].mCoefficients;
  v15 = (__m128 *)(*lowpass1)[64].mCoefficients;
  stridea = stride;
  *(float *)&lowgaina = lowgain;
  v16 = (__m128 *)(*highpass1)[0].mCoefficients;
  v17 = (*lowpass2)[0].mCoefficients;
  v18 = (*highpass1)[64].mCoefficients;
  v19 = (*lowpass2)[64].mCoefficients;
  v20 = *(__m128 *)(*highpass2)[0].mCoefficients->coeff;
  v21 = (*highpass2)[64].mCoefficients;
  v22 = *(__m128 *)v17->coeff;
  coeff_3 = *mCoefficients;
  coeff_D = v22;
  coeff_5 = v20;
  v23 = *(__m128 *)v18->coeff;
  v24 = *(__m128 *)v21->coeff;
  v25 = *(__m128 *)v19->coeff;
  coeff_4 = *v16;
  coeff_A = v23;
  coeff_B = v24;
  coeff_9 = *v15;
  coeff_F = v25;
  v26 = (__m128)v16[1].m128_u32[0];
  p_w1 = (double *)&(*highpass2)[v12 + 32].w1;
  v28 = _mm_unpacklo_ps(v26, (__m128)LODWORD((*highpass2)[0].mCoefficients->b0));
  b0_low = (__m128)LODWORD(v17->b0);
  v30 = (double *)&(*lowpass1)[v12 + 64].w1;
  v31 = *(__m128 *)p_w1;
  v32 = b0_low;
  v33 = (__m128)mCoefficients[1].m128_u32[0];
  v173 = v30;
  v34 = (double *)&(*lowpass1)[v12].w1;
  v35 = _mm_unpacklo_ps(v32, v33);
  v36 = (__m128)LODWORD(v21->b0);
  v37 = &(*highpass2)[v12];
  v38 = (__m128)(*lowpass1)[v12];
  v39 = _mm_movelh_ps(v31, v31);
  b_D345 = v35;
  feedback_1 = v38;
  _mm_storel_ps((double *)&b_D345.m128_u64[1], v28);
  v40 = (__m128)LODWORD(v18->b0);
  v41 = (double *)&(*highpass1)[v12].w1;
  v42 = _mm_unpacklo_ps(v40, v36);
  v43 = (__m128)LODWORD(v19->b0);
  v44 = (double *)&(*lowpass1)[v12 + 32].w1;
  v45 = (double *)&(*lowpass1)[v12 + 96].w1;
  v46 = v43;
  v47 = (__m128)v15[1].m128_u32[0];
  v48 = (double *)&(*highpass1)[v12 + 32].w1;
  v49 = *(__m128 *)v44;
  v176 = v45;
  v50 = *(__m128 *)v48;
  b_F9AB = _mm_unpacklo_ps(v46, v47);
  v165 = v49;
  _mm_storel_ps((double *)&b_F9AB.m128_u64[1], v42);
  feedback_4 = v49;
  v168 = v50;
  v51 = *(__m128 *)v30;
  v52 = *(__m128 *)v45;
  v53 = (__m128 *)&(*lowpass2)[v12 + 32];
  v174 = (double *)&(*highpass1)[v12 + 64].w1;
  v54 = *(__m128 *)v174;
  v55 = (__m128)(*highpass1)[v12];
  v175 = (double *)&(*highpass2)[v12 + 64].w1;
  v56 = _mm_movelh_ps(v54, v54);
  v57 = (double *)&(*lowpass2)[v12 + 96].w1;
  v58 = _mm_movelh_ps(v55, v55);
  v59 = (__m128)(*highpass2)[v12];
  v60 = _mm_movelh_ps((__m128)v37[64], (__m128)v37[64]);
  feedback_A = v51;
  v61 = _mm_movelh_ps(v59, v59);
  v169 = v52;
  _mm_storel_ps((double *)&v168.m128_u64[1], v50);
  _mm_storel_ps((double *)&v169.m128_u64[1], v52);
  v177 = (double *)&(*highpass1)[v12 + 96].w1;
  v62 = *(__m128 *)v177;
  v63 = (__m128)(*highpass2)[v12 + 96];
  v178 = (double *)&(*highpass2)[v12 + 96].w1;
  v179 = (double *)&(*lowpass2)[v12].w1;
  v64 = (__m128)(*lowpass2)[v12];
  v65 = (double *)&(*lowpass2)[v12 + 64].w1;
  v170 = v62;
  v171 = v63;
  feedback_C = v64;
  _mm_storel_ps((double *)&feedback_1.m128_u64[1], feedback_1);
  _mm_storel_ps((double *)&v170.m128_u64[1], v62);
  _mm_storel_ps((double *)&v171.m128_u64[1], v63);
  _mm_storel_ps((double *)&feedback_C.m128_u64[1], v64);
  v66 = *(__m128 *)v65;
  v67 = *(__m128 *)v57;
  v69 = feedback_A;
  feedback_D = *v53;
  v68 = feedback_D;
  feedback_E = v66;
  feedback_F = v67;
  _mm_storel_ps((double *)&feedback_4.m128_u64[1], v165);
  _mm_storel_ps((double *)&feedback_A.m128_u64[1], v69);
  _mm_storel_ps((double *)&feedback_D.m128_u64[1], v68);
  v70 = (__m128)(unsigned int)lowgaina;
  _mm_storel_ps((double *)&feedback_F.m128_u64[1], v67);
  *(float *)&lowgaina = midgain;
  *(float *)&v167 = highgain;
  v165 = v70;
  _mm_storel_ps((double *)&feedback_E.m128_u64[1], v66);
  lowgaina = LODWORD(midgain);
  v167 = (unsigned int)v167;
  v71 = _mm_hadd_ps(_mm_mul_ps(coeff_4, v58), _mm_mul_ps(coeff_5, v61));
  v72 = _mm_hadd_ps((__m128)0LL, _mm_mul_ps(feedback_1, coeff_3));
  v73 = _mm_shuffle_ps(v72, v71, 136);
  v74 = _mm_shuffle_ps(v72, v71, 221);
  v75 = _mm_add_ps(v73, _mm_shuffle_ps((__m128)*(unsigned int *)in, (__m128)*(unsigned int *)in, 0));
  v76 = _mm_movehdup_ps(v75);
  v77 = _mm_unpacklo_ps(v76, _mm_moveldup_ps(feedback_1));
  v78 = _mm_unpackhi_ps(v76, _mm_moveldup_ps(v61));
  feedback_1 = _mm_unpackhi_ps(_mm_moveldup_ps(v75), _mm_moveldup_ps(v58));
  v79 = _mm_hadd_ps((__m128)0LL, _mm_mul_ps(coeff_3, feedback_4));
  v80 = _mm_hadd_ps(_mm_mul_ps(coeff_4, v168), _mm_mul_ps(coeff_5, v39));
  v81 = _mm_add_ps(_mm_shuffle_ps(v79, v80, 136), _mm_add_ps(v74, _mm_mul_ps(b_D345, v75)));
  v82 = _mm_movehdup_ps(v81);
  v83 = _mm_add_ps(_mm_shuffle_ps(v79, v80, 221), _mm_mul_ps(b_D345, v81));
  v84 = _mm_unpacklo_ps(v82, _mm_moveldup_ps(feedback_4));
  feedback_4 = _mm_unpackhi_ps(_mm_moveldup_ps(v81), _mm_moveldup_ps(v168));
  v85 = _mm_unpackhi_ps(v82, _mm_moveldup_ps(v39));
  v86 = _mm_hadd_ps((__m128)0LL, _mm_mul_ps(feedback_A, coeff_9));
  v87 = _mm_hadd_ps(_mm_mul_ps(coeff_A, v56), _mm_mul_ps(coeff_B, v60));
  v88 = _mm_add_ps(_mm_shuffle_ps(v86, v87, 136), v83);
  v89 = _mm_movehdup_ps(v88);
  v90 = _mm_hadd_ps((__m128)0LL, _mm_mul_ps(coeff_9, v169));
  v91 = _mm_add_ps(_mm_shuffle_ps(v86, v87, 221), _mm_mul_ps(b_F9AB, v88));
  v92 = _mm_unpacklo_ps(v89, _mm_moveldup_ps(feedback_A));
  v93 = _mm_unpackhi_ps(_mm_moveldup_ps(v88), _mm_moveldup_ps(v56));
  v94 = _mm_unpackhi_ps(v89, _mm_moveldup_ps(v60));
  v95 = _mm_hadd_ps(_mm_mul_ps(coeff_A, v170), _mm_mul_ps(coeff_B, v171));
  v96 = _mm_add_ps(_mm_shuffle_ps(v90, v95, 136), v91);
  v97 = _mm_add_ps(_mm_shuffle_ps(v90, v95, 221), _mm_mul_ps(b_F9AB, v96));
  v98 = _mm_movehdup_ps(v96);
  v99 = _mm_unpacklo_ps(v98, _mm_moveldup_ps(v169));
  v100 = _mm_unpackhi_ps(_mm_moveldup_ps(v96), _mm_moveldup_ps(v170));
  v101 = _mm_unpackhi_ps(v98, _mm_moveldup_ps(v171));
  if ( length <= 1 )
  {
    v132 = v97;
  }
  else
  {
    v102 = 0;
    v103 = 1;
    feedback_A = v100;
    v104 = stridea;
    v105 = &in[v104];
    while ( 1 )
    {
      v106 = (__m128)*(unsigned int *)((char *)v105 + v102);
      ++v103;
      v107 = _mm_hadd_ps(_mm_mul_ps(coeff_4, feedback_1), _mm_mul_ps(coeff_5, v78));
      v108 = _mm_hadd_ps(_mm_mul_ps(coeff_D, feedback_C), _mm_mul_ps(coeff_3, v77));
      v109 = _mm_shuffle_ps(v108, v107, 221);
      v110 = _mm_shuffle_ps(v108, v107, 136);
      v111 = v97;
      v111.m128_f32[0] = v106.m128_f32[0];
      v112 = _mm_add_ps(v110, _mm_shuffle_ps(v111, v106, 2));
      v113 = _mm_moveldup_ps(v112);
      v114 = _mm_movehdup_ps(v112);
      feedback_C = _mm_unpacklo_ps(v113, _mm_moveldup_ps(feedback_C));
      v77 = _mm_unpacklo_ps(v114, _mm_moveldup_ps(v77));
      v78 = _mm_unpackhi_ps(v114, _mm_moveldup_ps(v78));
      feedback_1 = _mm_unpackhi_ps(v113, _mm_moveldup_ps(feedback_1));
      v115 = _mm_hadd_ps(_mm_mul_ps(coeff_D, feedback_D), _mm_mul_ps(coeff_3, v84));
      v116 = _mm_hadd_ps(_mm_mul_ps(coeff_4, feedback_4), _mm_mul_ps(coeff_5, v85));
      v117 = _mm_add_ps(_mm_shuffle_ps(v115, v116, 136), _mm_add_ps(v109, _mm_mul_ps(b_D345, v112)));
      v118 = _mm_add_ps(_mm_shuffle_ps(v115, v116, 221), _mm_mul_ps(b_D345, v117));
      v119 = _mm_moveldup_ps(v117);
      v120 = _mm_movehdup_ps(v117);
      feedback_D = _mm_unpacklo_ps(v119, _mm_moveldup_ps(feedback_D));
      v85 = _mm_unpackhi_ps(v120, _mm_moveldup_ps(v85));
      v84 = _mm_unpacklo_ps(v120, _mm_moveldup_ps(v84));
      feedback_4 = _mm_unpackhi_ps(v119, _mm_moveldup_ps(feedback_4));
      v121 = _mm_hadd_ps(_mm_mul_ps(coeff_F, feedback_E), _mm_mul_ps(coeff_9, v92));
      v122 = _mm_hadd_ps(_mm_mul_ps(coeff_A, v93), _mm_mul_ps(coeff_B, v94));
      v123 = _mm_add_ps(_mm_shuffle_ps(v121, v122, 136), v118);
      v124 = _mm_add_ps(_mm_shuffle_ps(v121, v122, 221), _mm_mul_ps(b_F9AB, v123));
      v125 = _mm_moveldup_ps(v123);
      feedback_E = _mm_unpacklo_ps(v125, _mm_moveldup_ps(feedback_E));
      v126 = _mm_movehdup_ps(v123);
      v94 = _mm_unpackhi_ps(v126, _mm_moveldup_ps(v94));
      v92 = _mm_unpacklo_ps(v126, _mm_moveldup_ps(v92));
      v93 = _mm_unpackhi_ps(v125, _mm_moveldup_ps(v93));
      v127 = _mm_hadd_ps(_mm_mul_ps(coeff_A, feedback_A), _mm_mul_ps(coeff_B, v101));
      v128 = _mm_hadd_ps(_mm_mul_ps(coeff_F, feedback_F), _mm_mul_ps(coeff_9, v99));
      v129 = _mm_add_ps(_mm_shuffle_ps(v128, v127, 136), v124);
      v130 = _mm_add_ps(_mm_shuffle_ps(v128, v127, 221), _mm_mul_ps(b_F9AB, v129));
      v131 = _mm_moveldup_ps(v129);
      v132 = v130;
      feedback_F = _mm_unpacklo_ps(v131, _mm_moveldup_ps(feedback_F));
      v133 = _mm_movehdup_ps(v129);
      v101 = _mm_unpackhi_ps(v133, _mm_moveldup_ps(v101));
      v99 = _mm_unpacklo_ps(v133, _mm_moveldup_ps(v99));
      feedback_A = _mm_unpackhi_ps(v131, _mm_moveldup_ps(feedback_A));
      *(float *)((char *)out + v102) = (float)((float)(v130.m128_f32[0] * *(float *)&lowgaina)
                                             + (float)(_mm_shuffle_ps(v97, v97, 85).m128_f32[0] * v165.m128_f32[0]))
                                     + (float)(_mm_shuffle_ps(v97, v97, 255).m128_f32[0] * *(float *)&v167);
      v102 += v104 * 4;
      if ( v103 == length )
        break;
      v97 = v130;
    }
    v100 = feedback_A;
  }
  v134 = _mm_hadd_ps(_mm_mul_ps(feedback_C, coeff_D), (__m128)0LL);
  v135 = _mm_shuffle_ps(v134, v134, 136);
  v135.m128_f32[0] = v135.m128_f32[0] + _mm_shuffle_ps(v132, v132, 2).m128_f32[0];
  v134.m128_f32[0] = _mm_shuffle_ps(v134, v134, 221).m128_f32[0] + (float)(b_D345.m128_f32[0] * v135.m128_f32[0]);
  feedback_A = _mm_unpacklo_ps(_mm_moveldup_ps(v135), _mm_moveldup_ps(feedback_C));
  v136 = _mm_mul_ps(coeff_D, feedback_D);
  v137 = _mm_hadd_ps(v136, v136);
  v138 = _mm_shuffle_ps(v137, v137, 136);
  v138.m128_f32[0] = v138.m128_f32[0] + v134.m128_f32[0];
  v139 = _mm_unpacklo_ps(_mm_moveldup_ps(v138), _mm_moveldup_ps(feedback_D));
  v137.m128_f32[0] = _mm_shuffle_ps(v137, v137, 221).m128_f32[0] + (float)(b_D345.m128_f32[0] * v138.m128_f32[0]);
  v140 = _mm_mul_ps(coeff_F, feedback_E);
  v141 = _mm_hadd_ps(v140, v140);
  v142 = _mm_shuffle_ps(v141, v141, 136);
  v142.m128_f32[0] = v142.m128_f32[0] + v137.m128_f32[0];
  v143 = _mm_mul_ps(coeff_F, feedback_F);
  v141.m128_f32[0] = _mm_shuffle_ps(v141, v141, 221).m128_f32[0] + (float)(b_F9AB.m128_f32[0] * v142.m128_f32[0]);
  v144 = _mm_unpacklo_ps(_mm_moveldup_ps(v142), _mm_moveldup_ps(feedback_E));
  v145 = _mm_hadd_ps(v143, v143);
  v146 = _mm_shuffle_ps(v145, v145, 136);
  v146.m128_f32[0] = v146.m128_f32[0] + v141.m128_f32[0];
  v141.m128_f32[0] = b_F9AB.m128_f32[0] * v146.m128_f32[0];
  v147 = _mm_unpacklo_ps(_mm_moveldup_ps(v146), _mm_moveldup_ps(feedback_F));
  out[stridea * (length - 1)] = (float)((float)((float)(_mm_shuffle_ps(v145, v145, 221).m128_f32[0] + v141.m128_f32[0])
                                              * *(float *)&lowgaina)
                                      + (float)(_mm_shuffle_ps(v132, v132, 85).m128_f32[0] * v165.m128_f32[0]))
                              + (float)(_mm_shuffle_ps(v132, v132, 255).m128_f32[0] * *(float *)&v167);
  _mm_storel_ps(v34, v77);
  _mm_storel_ps(v41, feedback_1);
  _mm_storel_ps((double *)&v37->w1, v78);
  _mm_storel_ps(v44, v84);
  _mm_storel_ps(v48, feedback_4);
  _mm_storel_ps(p_w1, v85);
  _mm_storel_ps(v173, v92);
  _mm_storel_ps(v174, v93);
  _mm_storel_ps(v175, v94);
  _mm_storel_ps(v176, v99);
  _mm_storel_ps(v177, v100);
  _mm_storel_ps(v178, v101);
  _mm_storel_ps(v179, feedback_A);
  _mm_storel_ps((double *)v53->m128_u64, v139);
  _mm_storel_ps(v65, v144);
  _mm_storel_ps(v57, v147);
}


