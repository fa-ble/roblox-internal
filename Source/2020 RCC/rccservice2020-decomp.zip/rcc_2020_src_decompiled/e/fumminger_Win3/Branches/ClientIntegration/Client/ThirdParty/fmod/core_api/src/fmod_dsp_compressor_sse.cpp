// Address: 0x221c5a0 | Name: FMOD_DSP_Compressor_1channel_SSE
void __fastcall FMOD_DSP_Compressor_1channel_SSE(
        float *in,
        float *out,
        __m128 *analysis,
        int length,
        float *envelopeStage1,
        float *envelope,
        __m128 gainExponent,
        __m128 gainMakeup,
        __m128 attackTime,
        __m128 releaseTime,
        __m128 envelopeThreshold,
        __m128 inverseEnvelopeThreshold)
{
  float *v13; // r14
  float *v14; // r15
  float *v15; // r13
  __m128 *v16; // r12
  float *v17; // rbx
  __m128 v18; // xmm1
  float *v20; // r15
  float *v21; // rbx
  __int64 v22; // rax
  float v23; // xmm5_4
  __m128 v24; // xmm0
  __m128 v25; // xmm4
  __int64 v26; // rdx
  __m128 v27; // xmm0
  __m128 v28; // xmm7
  __m128 v29; // xmm0
  __int64 v30; // rax
  int v31; // eax
  __int64 v32; // rbp
  float v33; // xmm0_4
  float v34; // xmm0_4
  __m128 v35; // xmm0
  __m128 v36; // xmm4
  float v37; // xmm0_4
  __m128 v38; // [rsp+10h] [rbp-E8h]
  __m128 x; // [rsp+20h] [rbp-D8h]
  __m128 v40; // [rsp+30h] [rbp-C8h]
  __m128 v41; // [rsp+40h] [rbp-B8h]
  float gainMakeupa; // [rsp+58h] [rbp-A0h]
  float envelopeThresholda; // [rsp+5Ch] [rbp-9Ch]
  float gainExponenta; // [rsp+68h] [rbp-90h]
  float inverseEnvelopeThresholda; // [rsp+6Ch] [rbp-8Ch]
  unsigned int v46; // [rsp+70h] [rbp-88h]
  __m128 envelopes; // [rsp+A0h] [rbp-58h]
  __m128 powers; // [rsp+B0h] [rbp-48h]

  v13 = in;
  v14 = envelopeStage1;
  v15 = out;
  v16 = analysis;
  v17 = envelope;
  v38 = _mm_shuffle_ps(inverseEnvelopeThreshold, inverseEnvelopeThreshold, 0);
  gainMakeupa = gainMakeup.m128_f32[0];
  gainExponenta = gainExponent.m128_f32[0];
  v18 = (__m128)*(unsigned int *)envelope;
  envelopeThresholda = envelopeThreshold.m128_f32[0];
  x = _mm_shuffle_ps(gainExponent, gainExponent, 0);
  inverseEnvelopeThresholda = inverseEnvelopeThreshold.m128_f32[0];
  envelopes.m128_f32[3] = *envelope;
  v40 = _mm_shuffle_ps(envelopeThreshold, envelopeThreshold, 0);
  v41 = _mm_shuffle_ps(gainMakeup, gainMakeup, 0);
  if ( length <= 3 )
  {
    v31 = 0;
  }
  else
  {
    v20 = in;
    v46 = (unsigned int)(length - 4) >> 2;
    v21 = out;
    while ( 1 )
    {
      v22 = 0;
      v23 = *envelopeStage1;
      powers = _mm_mul_ps(*v16, *v16);
      while ( 1 )
      {
        v24.m128_i32[0] = powers.m128_i32[v22];
        v25 = _mm_cmplt_ss(v18, v24);
        v25.m128_i32[0] = _mm_andnot_ps(v25, releaseTime).m128_u32[0] | attackTime.m128_i32[0] & v25.m128_i32[0];
        v23 = v23 + (float)((float)(v24.m128_f32[0] - v23) * v25.m128_f32[0]);
        envelopes.m128_f32[v22] = (float)((float)(v23 - v18.m128_f32[0]) * v25.m128_f32[0]) + v18.m128_f32[0];
        if ( v22 == 3 )
          break;
        v26 = (int)v22++;
        v18 = (__m128)envelopes.m128_u32[v26];
      }
      v27 = envelopes;
      v21 += 4;
      ++v16;
      v20 += 4;
      v28 = _mm_cmplt_ps(v40, envelopes);
      *envelopeStage1 = v23;
      v29 = am_pow_eps(_mm_mul_ps(v27, v38), x, attackTime);
      releaseTime = (__m128)releaseTime.m128_u32[0];
      attackTime = (__m128)attackTime.m128_u32[0];
      *((__m128 *)v21 - 1) = _mm_mul_ps(
                               *(__m128 *)(v20 - 4),
                               _mm_mul_ps(
                                 _mm_xor_ps(_mm_and_ps(_mm_xor_ps(v29, (__m128)stru_3E5460), v28), (__m128)stru_3E5460),
                                 v41));
      if ( v20 == &in[4 * v46 + 4] )
        break;
      v18 = (__m128)envelopes.m128_u32[3];
    }
    v14 = envelopeStage1;
    v17 = envelope;
    v18 = (__m128)envelopes.m128_u32[3];
    v30 = 16 * (v46 + 1LL);
    v15 = &out[(unsigned __int64)v30 / 4];
    v13 = &in[(unsigned __int64)v30 / 4];
    v16 = &analysis[(unsigned __int64)v30 / 0x10];
    v31 = 4 * v46 + 4;
  }
  *v17 = v18.m128_f32[0];
  if ( length > v31 )
  {
    v32 = (__int64)&v13[length - 1 - v31 + 1];
    while ( 1 )
    {
      v35.m128_f32[0] = v16->m128_f32[0] * v16->m128_f32[0];
      v36 = _mm_cmplt_ss(v18, v35);
      v36.m128_i32[0] = _mm_andnot_ps(v36, releaseTime).m128_u32[0] | attackTime.m128_i32[0] & v36.m128_i32[0];
      v35.m128_f32[0] = (float)((float)(v35.m128_f32[0] - *v14) * v36.m128_f32[0]) + *v14;
      *v14 = v35.m128_f32[0];
      v37 = (float)((float)(v35.m128_f32[0] - v18.m128_f32[0]) * v36.m128_f32[0]) + v18.m128_f32[0];
      *v17 = v37;
      if ( v37 <= envelopeThresholda )
      {
        v33 = gainMakeupa;
      }
      else
      {
        v33 = powf(v37 * inverseEnvelopeThresholda, gainExponenta) * gainMakeupa;
        releaseTime = (__m128)releaseTime.m128_u32[0];
      }
      v34 = v33 * *v13++;
      ++v15;
      v16 = (__m128 *)((char *)v16 + 4);
      *(v15 - 1) = v34;
      if ( v13 == (float *)v32 )
        break;
      v18 = (__m128)*(unsigned int *)v17;
    }
  }
}


// Address: 0x221c8d0 | Name: FMOD_DSP_Compressor_2channel_SSE
void __fastcall FMOD_DSP_Compressor_2channel_SSE(
        float *in,
        float *out,
        __m128 *analysis,
        int length,
        float *envelopeStage1,
        float *envelope,
        __m128 gainExponent,
        __m128 gainMakeup,
        __m128 attackTime,
        __m128 releaseTime,
        __m128 envelopeThreshold,
        __m128 inverseEnvelopeThreshold)
{
  float *v13; // r14
  float *v14; // r13
  __m128 *v15; // r12
  float *v16; // rbp
  float *v17; // rbx
  __m128 v18; // xmm1
  float *v19; // rbp
  float *v21; // rbx
  __int64 v22; // rax
  float v23; // xmm5_4
  __m128 v24; // xmm0
  __m128 v25; // xmm4
  __int64 v26; // rdx
  __m128 v27; // xmm0
  __m128 v28; // xmm7
  __m128 v29; // xmm0
  __m128 v30; // xmm0
  __m128 v31; // xmm1
  __int64 v32; // rax
  int v33; // eax
  __int64 v34; // r15
  float v35; // xmm0_4
  float v36; // xmm1_4
  float v37; // xmm1_4
  float v38; // xmm0_4
  __m128 v39; // xmm0
  __m128 v40; // xmm4
  float v41; // xmm0_4
  __m128 v42; // [rsp+10h] [rbp-E8h]
  __m128 x; // [rsp+20h] [rbp-D8h]
  __m128 v44; // [rsp+30h] [rbp-C8h]
  __m128 v45; // [rsp+40h] [rbp-B8h]
  float gainMakeupa; // [rsp+58h] [rbp-A0h]
  float envelopeThresholda; // [rsp+5Ch] [rbp-9Ch]
  float gainExponenta; // [rsp+68h] [rbp-90h]
  float inverseEnvelopeThresholda; // [rsp+6Ch] [rbp-8Ch]
  unsigned int v50; // [rsp+70h] [rbp-88h]
  __m128 envelopes; // [rsp+A0h] [rbp-58h]
  __m128 powers; // [rsp+B0h] [rbp-48h]

  v13 = in;
  v14 = out;
  v15 = analysis;
  v16 = envelopeStage1;
  v17 = envelope;
  v42 = _mm_shuffle_ps(inverseEnvelopeThreshold, inverseEnvelopeThreshold, 0);
  gainMakeupa = gainMakeup.m128_f32[0];
  gainExponenta = gainExponent.m128_f32[0];
  v18 = (__m128)*(unsigned int *)envelope;
  envelopeThresholda = envelopeThreshold.m128_f32[0];
  x = _mm_shuffle_ps(gainExponent, gainExponent, 0);
  inverseEnvelopeThresholda = inverseEnvelopeThreshold.m128_f32[0];
  envelopes.m128_f32[3] = *envelope;
  v44 = _mm_shuffle_ps(envelopeThreshold, envelopeThreshold, 0);
  v45 = _mm_shuffle_ps(gainMakeup, gainMakeup, 0);
  if ( length <= 3 )
  {
    v33 = 0;
  }
  else
  {
    v19 = in;
    v50 = (unsigned int)(length - 4) >> 2;
    v21 = out;
    while ( 1 )
    {
      v22 = 0;
      v23 = *envelopeStage1;
      powers = _mm_hadd_ps(_mm_mul_ps(*v15, *v15), _mm_mul_ps(v15[1], v15[1]));
      while ( 1 )
      {
        v24.m128_i32[0] = powers.m128_i32[v22];
        v25 = _mm_cmplt_ss(v18, v24);
        v25.m128_i32[0] = _mm_andnot_ps(v25, releaseTime).m128_u32[0] | attackTime.m128_i32[0] & v25.m128_i32[0];
        v23 = v23 + (float)((float)(v24.m128_f32[0] - v23) * v25.m128_f32[0]);
        envelopes.m128_f32[v22] = (float)((float)(v23 - v18.m128_f32[0]) * v25.m128_f32[0]) + v18.m128_f32[0];
        if ( v22 == 3 )
          break;
        v26 = (int)v22++;
        v18 = (__m128)envelopes.m128_u32[v26];
      }
      v27 = envelopes;
      v21 += 8;
      v15 += 2;
      v19 += 8;
      v28 = _mm_cmplt_ps(v44, envelopes);
      *envelopeStage1 = v23;
      v29 = am_pow_eps(_mm_mul_ps(v27, v42), x, attackTime);
      releaseTime = (__m128)releaseTime.m128_u32[0];
      attackTime = (__m128)attackTime.m128_u32[0];
      v30 = _mm_mul_ps(_mm_xor_ps(_mm_and_ps(_mm_xor_ps(v29, (__m128)stru_3E5460), v28), (__m128)stru_3E5460), v45);
      v31 = _mm_mul_ps(*(__m128 *)(v19 - 4), _mm_unpackhi_ps(v30, v30));
      *((__m128 *)v21 - 2) = _mm_mul_ps(*(__m128 *)(v19 - 8), _mm_unpacklo_ps(v30, v30));
      *((__m128 *)v21 - 1) = v31;
      if ( v19 == &in[8 * v50 + 8] )
        break;
      v18 = (__m128)envelopes.m128_u32[3];
    }
    v16 = envelopeStage1;
    v17 = envelope;
    v18 = (__m128)envelopes.m128_u32[3];
    v32 = 32 * (v50 + 1LL);
    v14 = &out[(unsigned __int64)v32 / 4];
    v13 = &in[(unsigned __int64)v32 / 4];
    v15 = &analysis[(unsigned __int64)v32 / 0x10];
    v33 = 4 * v50 + 4;
  }
  *v17 = v18.m128_f32[0];
  if ( length > v33 )
  {
    v34 = (__int64)&v13[2 * (length - 1 - v33) + 2];
    while ( 1 )
    {
      v39.m128_f32[0] = (float)(v15->m128_f32[1] * v15->m128_f32[1]) + (float)(v15->m128_f32[0] * v15->m128_f32[0]);
      v40 = _mm_cmplt_ss(v18, v39);
      v40.m128_i32[0] = _mm_andnot_ps(v40, releaseTime).m128_u32[0] | attackTime.m128_i32[0] & v40.m128_i32[0];
      v39.m128_f32[0] = (float)((float)(v39.m128_f32[0] - *v16) * v40.m128_f32[0]) + *v16;
      *v16 = v39.m128_f32[0];
      v41 = (float)((float)(v39.m128_f32[0] - v18.m128_f32[0]) * v40.m128_f32[0]) + v18.m128_f32[0];
      *v17 = v41;
      if ( v41 <= envelopeThresholda )
      {
        v35 = gainMakeupa;
      }
      else
      {
        v35 = powf(v41 * inverseEnvelopeThresholda, gainExponenta) * gainMakeupa;
        releaseTime = (__m128)releaseTime.m128_u32[0];
      }
      v36 = *v13;
      v13 += 2;
      v14 += 2;
      v37 = v36 * v35;
      v15 = (__m128 *)((char *)v15 + 8);
      v38 = v35 * *(v13 - 1);
      *(v14 - 2) = v37;
      *(v14 - 1) = v38;
      if ( v13 == (float *)v34 )
        break;
      v18 = (__m128)*(unsigned int *)v17;
    }
  }
}


// Address: 0x221cc40 | Name: FMOD_DSP_Compressor_6channel_SSE
void __fastcall FMOD_DSP_Compressor_6channel_SSE(
        float *in,
        float *out,
        __m128 *analysis,
        int length,
        float *envelopeStage1,
        float *envelope,
        __m128 gainExponent,
        __m128 gainMakeup,
        float attackTime,
        __m128 releaseTime,
        __m128 envelopeThreshold,
        __m128 inverseEnvelopeThreshold)
{
  float *v13; // r15
  float *v14; // r14
  float *v16; // r13
  __m128 v19; // xmm1
  _OWORD *v20; // r11
  __m128 *p_envelopes; // r10
  float *v22; // rcx
  float *v23; // rbx
  __m128 *v24; // rdi
  __int64 v25; // rax
  __m128 v26; // xmm5
  __m128 v27; // xmm0
  __m128 v28; // xmm7
  float v29; // xmm5_4
  __m128 v30; // xmm0
  __m128 v31; // xmm4
  __int64 v32; // r9
  __m128 v33; // xmm0
  __m128 v34; // xmm2
  __m128 v35; // xmm0
  __m128 v36; // xmm5
  __m128 v37; // xmm4
  __m128 v38; // xmm1
  __m128 v39; // xmm0
  __m128 v40; // xmm7
  __m128 v41; // xmm6
  int v42; // eax
  float v43; // xmm5_4
  float *v44; // r15
  float v45; // xmm0_4
  float v46; // xmm1_4
  float v47; // xmm1_4
  float v48; // xmm0_4
  __m128 v49; // xmm0
  __m128 v50; // xmm4
  float v51; // xmm0_4
  float v52; // xmm0_4
  float v53; // [rsp+0h] [rbp-F8h]
  float v54; // [rsp+1Ch] [rbp-DCh]
  float *outa; // [rsp+28h] [rbp-D0h]
  _OWORD *v56; // [rsp+30h] [rbp-C8h]
  __m128 *v57; // [rsp+38h] [rbp-C0h]
  __m128 v58; // [rsp+40h] [rbp-B8h]
  __m128 x; // [rsp+50h] [rbp-A8h]
  __m128 v60; // [rsp+60h] [rbp-98h]
  __m128 v61; // [rsp+70h] [rbp-88h]
  float gainExponenta; // [rsp+80h] [rbp-78h]
  float inverseEnvelopeThresholda; // [rsp+84h] [rbp-74h]
  __int64 v64; // [rsp+88h] [rbp-70h]
  unsigned int v65; // [rsp+90h] [rbp-68h]
  __int32 gainMakeupa; // [rsp+98h] [rbp-60h]
  float envelopeThresholda; // [rsp+9Ch] [rbp-5Ch]
  __m128 envelopes; // [rsp+A0h] [rbp-58h] BYREF
  _OWORD powers[4]; // [rsp+B0h] [rbp-48h] BYREF

  v13 = in;
  v14 = out;
  v16 = (float *)analysis;
  v58 = _mm_shuffle_ps(inverseEnvelopeThreshold, inverseEnvelopeThreshold, 0);
  gainMakeupa = gainMakeup.m128_i32[0];
  gainExponenta = gainExponent.m128_f32[0];
  v19 = (__m128)*(unsigned int *)envelope;
  envelopeThresholda = envelopeThreshold.m128_f32[0];
  x = _mm_shuffle_ps(gainExponent, gainExponent, 0);
  inverseEnvelopeThresholda = inverseEnvelopeThreshold.m128_f32[0];
  envelopes.m128_f32[3] = *envelope;
  v60 = _mm_shuffle_ps(envelopeThreshold, envelopeThreshold, 0);
  v61 = _mm_shuffle_ps(gainMakeup, gainMakeup, 0);
  if ( length <= 3 )
  {
    v23 = in;
    v42 = 0;
  }
  else
  {
    v20 = powers;
    p_envelopes = &envelopes;
    v22 = out;
    v65 = (unsigned int)(length - 4) >> 2;
    v64 = 8 * (3LL * v65 + 3);
    v23 = &in[v64];
    v24 = analysis;
    while ( 1 )
    {
      v25 = 0;
      v26 = _mm_hadd_ps(_mm_mul_ps(*v24, *v24), _mm_mul_ps(v24[1], v24[1]));
      v27 = _mm_hadd_ps(_mm_mul_ps(v24[2], v24[2]), _mm_mul_ps(v24[3], v24[3]));
      v28 = _mm_hadd_ps(_mm_mul_ps(v24[4], v24[4]), _mm_mul_ps(v24[5], v24[5]));
      powers[0] = _mm_add_ps(
                    _mm_movehl_ps(v28, v26),
                    _mm_hadd_ps(_mm_movelh_ps(v26, v27), _mm_shuffle_ps(v28, v27, 228)));
      v29 = *envelopeStage1;
      while ( 1 )
      {
        v30.m128_i32[0] = *((_DWORD *)v20 + v25);
        v31 = _mm_cmplt_ss(v19, v30);
        v31.m128_i32[0] = _mm_andnot_ps(v31, releaseTime).m128_u32[0] | LODWORD(attackTime) & v31.m128_i32[0];
        v29 = v29 + (float)((float)(v30.m128_f32[0] - v29) * v31.m128_f32[0]);
        p_envelopes->m128_f32[v25] = (float)((float)(v29 - v19.m128_f32[0]) * v31.m128_f32[0]) + v19.m128_f32[0];
        if ( v25 == 3 )
          break;
        v32 = (int)v25++;
        v19 = (__m128)envelopes.m128_u32[v32];
      }
      v33 = envelopes;
      v13 += 24;
      outa = v22;
      v54 = attackTime;
      v57 = p_envelopes;
      v56 = v20;
      v34 = _mm_cmplt_ps(v60, envelopes);
      *envelopeStage1 = v29;
      v35 = am_pow_eps(_mm_mul_ps(v33, v58), x, v34);
      v22 = outa + 24;
      v24 += 6;
      v36 = *(__m128 *)(v13 - 12);
      v37 = *(__m128 *)(v13 - 8);
      v38 = *(__m128 *)(v13 - 4);
      v39 = _mm_mul_ps(_mm_xor_ps(_mm_and_ps(_mm_xor_ps(v35, (__m128)stru_3E5460), v34), (__m128)stru_3E5460), v61);
      releaseTime = (__m128)releaseTime.m128_u32[0];
      attackTime = v54;
      v40 = _mm_mul_ps(*(__m128 *)(v13 - 20), _mm_shuffle_ps(v39, v39, 5));
      v41 = _mm_mul_ps(*(__m128 *)(v13 - 16), _mm_shuffle_ps(v39, v39, 85));
      *(__m128 *)outa = _mm_mul_ps(*(__m128 *)(v13 - 24), _mm_shuffle_ps(v39, v39, 0));
      *((__m128 *)outa + 1) = v40;
      *((__m128 *)outa + 2) = v41;
      *((__m128 *)outa + 3) = _mm_mul_ps(v36, _mm_shuffle_ps(v39, v39, 170));
      *((__m128 *)outa + 4) = _mm_mul_ps(v37, _mm_shuffle_ps(v39, v39, 175));
      *((__m128 *)outa + 5) = _mm_mul_ps(v38, _mm_shuffle_ps(v39, v39, 255));
      if ( v13 == v23 )
        break;
      v19 = (__m128)envelopes.m128_u32[3];
      v20 = v56;
      p_envelopes = v57;
    }
    v19 = (__m128)envelopes.m128_u32[3];
    v14 = &out[v64];
    v16 = (float *)((char *)v16 + v64 * 4);
    v42 = 4 * v65 + 4;
  }
  *envelope = v19.m128_f32[0];
  if ( length > v42 )
  {
    v43 = *(float *)&gainMakeupa;
    v44 = &v23[6 * (length - 1 - v42) + 6];
    while ( 1 )
    {
      v49.m128_f32[0] = (float)(v16[5] * v16[5])
                      + (float)((float)(v16[4] * v16[4])
                              + (float)((float)(v16[3] * v16[3])
                                      + (float)((float)(v16[2] * v16[2])
                                              + (float)((float)(v16[1] * v16[1]) + (float)(*v16 * *v16)))));
      v50 = _mm_cmplt_ss(v19, v49);
      v50.m128_i32[0] = _mm_andnot_ps(v50, releaseTime).m128_u32[0] | LODWORD(attackTime) & v50.m128_i32[0];
      v49.m128_f32[0] = (float)((float)(v49.m128_f32[0] - *envelopeStage1) * v50.m128_f32[0]) + *envelopeStage1;
      *envelopeStage1 = v49.m128_f32[0];
      v51 = (float)((float)(v49.m128_f32[0] - v19.m128_f32[0]) * v50.m128_f32[0]) + v19.m128_f32[0];
      *envelope = v51;
      if ( v51 <= envelopeThresholda )
      {
        v45 = v43;
      }
      else
      {
        v53 = v43;
        v52 = powf(v51 * inverseEnvelopeThresholda, gainExponenta);
        v43 = v53;
        v45 = v52 * v53;
        releaseTime = (__m128)releaseTime.m128_u32[0];
      }
      v46 = *v23;
      v23 += 6;
      v14 += 6;
      v16 += 6;
      *(v14 - 6) = v46 * v45;
      *(v14 - 5) = *(v23 - 5) * v45;
      *(v14 - 4) = *(v23 - 4) * v45;
      *(v14 - 3) = *(v23 - 3) * v45;
      v47 = *(v23 - 2) * v45;
      v48 = v45 * *(v23 - 1);
      *(v14 - 2) = v47;
      *(v14 - 1) = v48;
      if ( v23 == v44 )
        break;
      v19 = (__m128)*(unsigned int *)envelope;
    }
  }
}


// Address: 0x221d0f0 | Name: FMOD_DSP_Compressor_8channel_SSE
void __fastcall FMOD_DSP_Compressor_8channel_SSE(
        float *in,
        float *out,
        __m128 *analysis,
        int length,
        float *envelopeStage1,
        float *envelope,
        __m128 gainExponent,
        __m128 gainMakeup,
        __m128 attackTime,
        __m128 releaseTime,
        __m128 envelopeThreshold,
        __m128 inverseEnvelopeThreshold)
{
  float *v13; // r14
  float *v14; // r13
  float *v15; // rbp
  float *v16; // rbx
  __m128 v17; // xmm1
  float *v18; // rbp
  float *v19; // r15
  __m128 *v21; // rbx
  __int64 v22; // rax
  float v23; // xmm5_4
  __m128 v24; // xmm0
  __m128 v25; // xmm4
  __int64 v26; // rdx
  __m128 v27; // xmm0
  __m128 v28; // xmm7
  __m128 v29; // xmm0
  __m128 v30; // xmm7
  __m128 v31; // xmm6
  __m128 v32; // xmm5
  __m128 v33; // xmm0
  __m128 v34; // xmm4
  __m128 v35; // xmm1
  __m128 v36; // xmm13
  __m128 v37; // xmm12
  __m128 v38; // xmm11
  __m128 v39; // xmm0
  __m128 v40; // xmm9
  __m128 v41; // xmm8
  __int64 v42; // rax
  int v43; // eax
  float *v44; // r12
  float v45; // xmm5_4
  __int64 v46; // r15
  float v47; // xmm0_4
  float v48; // xmm1_4
  float v49; // xmm1_4
  float v50; // xmm0_4
  __m128 v51; // xmm0
  __m128 v52; // xmm4
  float v53; // xmm0_4
  float v54; // xmm0_4
  __m128 v55; // [rsp+0h] [rbp-F8h]
  float v56; // [rsp+0h] [rbp-F8h]
  __m128 v57; // [rsp+10h] [rbp-E8h]
  __m128 x; // [rsp+20h] [rbp-D8h]
  __m128 v59; // [rsp+30h] [rbp-C8h]
  __m128 v60; // [rsp+40h] [rbp-B8h]
  float gainExponenta; // [rsp+60h] [rbp-98h]
  float inverseEnvelopeThresholda; // [rsp+64h] [rbp-94h]
  float *v63; // [rsp+68h] [rbp-90h]
  unsigned int v64; // [rsp+70h] [rbp-88h]
  __int32 gainMakeupa; // [rsp+78h] [rbp-80h]
  float envelopeThresholda; // [rsp+7Ch] [rbp-7Ch]
  __m128 envelopes; // [rsp+A0h] [rbp-58h]
  __m128 powers; // [rsp+B0h] [rbp-48h]

  v13 = out;
  v14 = (float *)analysis;
  v15 = envelopeStage1;
  v16 = envelope;
  v57 = _mm_shuffle_ps(inverseEnvelopeThreshold, inverseEnvelopeThreshold, 0);
  v63 = in;
  gainMakeupa = gainMakeup.m128_i32[0];
  gainExponenta = gainExponent.m128_f32[0];
  v17 = (__m128)*(unsigned int *)envelope;
  envelopeThresholda = envelopeThreshold.m128_f32[0];
  x = _mm_shuffle_ps(gainExponent, gainExponent, 0);
  inverseEnvelopeThresholda = inverseEnvelopeThreshold.m128_f32[0];
  envelopes.m128_f32[3] = *envelope;
  v59 = _mm_shuffle_ps(envelopeThreshold, envelopeThreshold, 0);
  v60 = _mm_shuffle_ps(gainMakeup, gainMakeup, 0);
  if ( length <= 3 )
  {
    v43 = 0;
  }
  else
  {
    v18 = out;
    v19 = in;
    v64 = (unsigned int)(length - 4) >> 2;
    v21 = analysis;
    while ( 1 )
    {
      v22 = 0;
      v23 = *envelopeStage1;
      powers = _mm_hadd_ps(
                 _mm_hadd_ps(
                   _mm_hadd_ps(_mm_mul_ps(*v21, *v21), _mm_mul_ps(v21[1], v21[1])),
                   _mm_hadd_ps(_mm_mul_ps(v21[2], v21[2]), _mm_mul_ps(v21[3], v21[3]))),
                 _mm_hadd_ps(
                   _mm_hadd_ps(_mm_mul_ps(v21[4], v21[4]), _mm_mul_ps(v21[5], v21[5])),
                   _mm_hadd_ps(_mm_mul_ps(v21[6], v21[6]), _mm_mul_ps(v21[7], v21[7]))));
      while ( 1 )
      {
        v24.m128_i32[0] = powers.m128_i32[v22];
        v25 = _mm_cmplt_ss(v17, v24);
        v25.m128_i32[0] = _mm_andnot_ps(v25, releaseTime).m128_u32[0] | attackTime.m128_i32[0] & v25.m128_i32[0];
        v23 = v23 + (float)((float)(v24.m128_f32[0] - v23) * v25.m128_f32[0]);
        envelopes.m128_f32[v22] = (float)((float)(v23 - v17.m128_f32[0]) * v25.m128_f32[0]) + v17.m128_f32[0];
        if ( v22 == 3 )
          break;
        v26 = (int)v22++;
        v17 = (__m128)envelopes.m128_u32[v26];
      }
      v27 = envelopes;
      v18 += 32;
      v21 += 8;
      v19 += 32;
      v28 = _mm_cmplt_ps(v59, envelopes);
      *envelopeStage1 = v23;
      v55 = v28;
      v29 = am_pow_eps(_mm_mul_ps(v27, v57), x, attackTime);
      v30 = *(__m128 *)(v19 - 20);
      v31 = *(__m128 *)(v19 - 16);
      v32 = *(__m128 *)(v19 - 12);
      v33 = _mm_mul_ps(_mm_xor_ps(_mm_and_ps(_mm_xor_ps(v29, (__m128)stru_3E5460), v55), (__m128)stru_3E5460), v60);
      v34 = *(__m128 *)(v19 - 8);
      v35 = *(__m128 *)(v19 - 4);
      releaseTime = (__m128)releaseTime.m128_u32[0];
      attackTime = (__m128)attackTime.m128_u32[0];
      v36 = _mm_shuffle_ps(v33, v33, 0);
      v37 = _mm_shuffle_ps(v33, v33, 85);
      v38 = _mm_shuffle_ps(v33, v33, 170);
      v39 = _mm_shuffle_ps(v33, v33, 255);
      v40 = _mm_mul_ps(*(__m128 *)(v19 - 28), v36);
      v41 = _mm_mul_ps(*(__m128 *)(v19 - 24), v37);
      *((__m128 *)v18 - 8) = _mm_mul_ps(*(__m128 *)(v19 - 32), v36);
      *((__m128 *)v18 - 7) = v40;
      *((__m128 *)v18 - 6) = v41;
      *((__m128 *)v18 - 5) = _mm_mul_ps(v30, v37);
      *((__m128 *)v18 - 4) = _mm_mul_ps(v31, v38);
      *((__m128 *)v18 - 3) = _mm_mul_ps(v32, v38);
      *((__m128 *)v18 - 2) = _mm_mul_ps(v34, v39);
      *((__m128 *)v18 - 1) = _mm_mul_ps(v35, v39);
      if ( v19 == &in[32 * (unsigned __int64)v64 + 32] )
        break;
      v17 = (__m128)envelopes.m128_u32[3];
    }
    v15 = envelopeStage1;
    v16 = envelope;
    v17 = (__m128)envelopes.m128_u32[3];
    v42 = (v64 + 1LL) << 7;
    v63 = (float *)((char *)in + v42);
    v13 = (float *)((char *)out + v42);
    v14 = (float *)((char *)analysis->m128_f32 + v42);
    v43 = 4 * v64 + 4;
  }
  *v16 = v17.m128_f32[0];
  if ( length > v43 )
  {
    v44 = v63;
    v45 = *(float *)&gainMakeupa;
    v46 = (__int64)&v63[8 * (length - 1 - v43) + 8];
    while ( 1 )
    {
      v51.m128_f32[0] = (float)(v14[7] * v14[7])
                      + (float)((float)(v14[6] * v14[6])
                              + (float)((float)(v14[5] * v14[5])
                                      + (float)((float)(v14[4] * v14[4])
                                              + (float)((float)(v14[3] * v14[3])
                                                      + (float)((float)(v14[2] * v14[2])
                                                              + (float)((float)(v14[1] * v14[1]) + (float)(*v14 * *v14)))))));
      v52 = _mm_cmplt_ss(v17, v51);
      v52.m128_i32[0] = _mm_andnot_ps(v52, releaseTime).m128_u32[0] | attackTime.m128_i32[0] & v52.m128_i32[0];
      v51.m128_f32[0] = (float)((float)(v51.m128_f32[0] - *v15) * v52.m128_f32[0]) + *v15;
      *v15 = v51.m128_f32[0];
      v53 = (float)((float)(v51.m128_f32[0] - v17.m128_f32[0]) * v52.m128_f32[0]) + v17.m128_f32[0];
      *v16 = v53;
      if ( v53 <= envelopeThresholda )
      {
        v47 = v45;
      }
      else
      {
        v56 = v45;
        v54 = powf(v53 * inverseEnvelopeThresholda, gainExponenta);
        v45 = v56;
        v47 = v54 * v56;
        releaseTime = (__m128)releaseTime.m128_u32[0];
      }
      v48 = *v44;
      v44 += 8;
      v13 += 8;
      v14 += 8;
      *(v13 - 8) = v48 * v47;
      *(v13 - 7) = *(v44 - 7) * v47;
      *(v13 - 6) = *(v44 - 6) * v47;
      *(v13 - 5) = *(v44 - 5) * v47;
      *(v13 - 4) = *(v44 - 4) * v47;
      *(v13 - 3) = *(v44 - 3) * v47;
      v49 = *(v44 - 2) * v47;
      v50 = v47 * *(v44 - 1);
      *(v13 - 2) = v49;
      *(v13 - 1) = v50;
      if ( v44 == (float *)v46 )
        break;
      v17 = (__m128)*(unsigned int *)v16;
    }
  }
}


