// Address: 0x221ef50 | Name: _ZN4FMOD11ChannelPoolC2Ev
void __fastcall FMOD::ChannelPool::ChannelPool(FMOD::ChannelPool *const this)
{
  this->mChannel = 0;
  this->mNumChannels = 0;
  this->mChannelsUsed = 0;
  this->mSystem = 0;
  this->mOutput = 0;
}


// Address: 0x221ef80 | Name: _ZN4FMOD11ChannelPool4initEPNS_7SystemIEPNS_6OutputEi
FMOD_RESULT_0 __fastcall FMOD::ChannelPool::init(
        FMOD::ChannelPool *const this,
        FMOD::SystemI *system,
        FMOD::Output *output,
        int numchannels)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal **v7; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numchannels >= 0 )
  {
    if ( !numchannels
      || (v7 = (FMOD::ChannelReal **)FMOD::MemPool::calloc(
                                       off_286F358->gSystemMemPool,
                                       8 * numchannels,
                                       "../../../core_api/src/fmod_channelpool.cpp",
                                       56,
                                       0),
          (this->mChannel = v7) != 0) )
    {
      this->mNumChannels = numchannels;
      this->mSystem = system;
      result = FMOD_RESULT::FMOD_OK_0;
      this->mOutput = output;
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
  }
  return result;
}


// Address: 0x221f000 | Name: _ZN4FMOD11ChannelPool7releaseEv
FMOD_RESULT_0 __fastcall FMOD::ChannelPool::release(FMOD::ChannelPool *const this)
{
  FMOD::ChannelReal **mChannel; // rsi
  __int64 v3; // rbp
  int v4; // ebx
  FMOD::ChannelReal *v5; // rdi

  mChannel = this->mChannel;
  if ( mChannel )
  {
    if ( this->mNumChannels > 0 )
    {
      v3 = 0;
      v4 = 0;
      do
      {
        v5 = mChannel[v3];
        if ( v5 )
        {
          (*((void (__fastcall **)(FMOD::ChannelReal *))v5->_vptr_ChannelReal + 4))(v5);
          mChannel = this->mChannel;
        }
        ++v4;
        ++v3;
      }
      while ( this->mNumChannels > v4 );
    }
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mChannel, "../../../core_api/src/fmod_channelpool.cpp", 96);
  }
  FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_channelpool.cpp", 99);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f0a0 | Name: _ZN4FMOD11ChannelPool15allocateChannelEPPNS_11ChannelRealEib
FMOD_RESULT_0 __fastcall FMOD::ChannelPool::allocateChannel(
        FMOD::ChannelPool *const this,
        FMOD::ChannelReal **realchannel,
        int index,
        bool ignorereserved)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelReal *v5; // rdx
  unsigned int v6; // eax
  __int64 v8; // rbx
  FMOD::ChannelReal *v9; // rbp
  FMOD::CHANNELREAL_FLAG mFlags; // eax
  FMOD::ChannelReal *v11; // rdx
  FMOD::CHANNELREAL_FLAG v12; // eax
  bool playing[57]; // [rsp+Fh] [rbp-39h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( realchannel )
  {
    if ( index == -1 )
    {
      if ( this->mNumChannels > 0 )
      {
        v8 = 0;
        do
        {
          v9 = this->mChannel[v8];
          mFlags = v9->mFlags;
          if ( (mFlags & 0x8110) == 0
            && ((mFlags & 0x1000) == 0 || ignorereserved)
            && !(*((unsigned int (__fastcall **)(FMOD::ChannelReal *, bool *, __int64))v9->_vptr_ChannelReal + 23))(
                  this->mChannel[v8],
                  playing,
                  1)
            && !playing[0] )
          {
            v9->mFlags = v9->mFlags & 0xFFFFEE6F | 0x110;
            *realchannel = v9;
            return FMOD_RESULT::FMOD_OK_0;
          }
          ++v8;
        }
        while ( this->mNumChannels > (int)v8 );
        v5 = *realchannel;
        if ( *realchannel )
          goto LABEL_6;
        return FMOD_RESULT::FMOD_ERR_CHANNEL_ALLOC_0;
      }
    }
    else if ( index >= 0 && index < this->mNumChannels )
    {
      v11 = this->mChannel[index];
      v12 = v11->mFlags;
      LOBYTE(v12) = v12 & 0x7F;
      v11->mFlags = v12 | 0x110;
      *realchannel = v11;
      return FMOD_RESULT::FMOD_OK_0;
    }
    v5 = *realchannel;
    if ( *realchannel )
    {
LABEL_6:
      v6 = v5->mFlags & 0xFFFFFEEF;
      LOBYTE(v6) = v5->mFlags & 0x6F | 0x80;
      v5->mFlags = v6;
      return FMOD_RESULT::FMOD_ERR_CHANNEL_ALLOC_0;
    }
    return FMOD_RESULT::FMOD_ERR_CHANNEL_ALLOC_0;
  }
  return result;
}


// Address: 0x221f1d0 | Name: _ZN4FMOD11ChannelPool14getNumChannelsEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelPool::getNumChannels(FMOD::ChannelPool *const this, int *numchannels)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numchannels )
  {
    *numchannels = this->mNumChannels;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x221f1f0 | Name: _ZN4FMOD11ChannelPool15getChannelsUsedEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelPool::getChannelsUsed(FMOD::ChannelPool *const this, int *numchannels)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numchannels )
  {
    *numchannels = this->mChannelsUsed;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x221f210 | Name: _ZN4FMOD11ChannelPool10setChannelEiPNS_11ChannelRealE
FMOD_RESULT_0 __fastcall FMOD::ChannelPool::setChannel(
        FMOD::ChannelPool *const this,
        int index,
        FMOD::ChannelReal *channel)
{
  FMOD::Output *mOutput; // rcx
  FMOD::ChannelReal **v5; // rax

  if ( !channel || index < 0 || index >= this->mNumChannels )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  this->mChannel[index] = channel;
  mOutput = this->mOutput;
  v5 = &this->mChannel[index];
  (*v5)->mPool = this;
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelReal *, int, FMOD::SystemI *, FMOD::Output *))(*v5)->_vptr_ChannelReal
          + 3))(
           *v5,
           index,
           this->mSystem,
           mOutput);
}


// Address: 0x221f260 | Name: _ZN4FMOD11ChannelPool10getChannelEiPPNS_11ChannelRealE
FMOD_RESULT_0 __fastcall FMOD::ChannelPool::getChannel(
        FMOD::ChannelPool *const this,
        int index,
        FMOD::ChannelReal **channel)
{
  FMOD_RESULT_0 result; // eax

  if ( !channel || index < 0 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index < this->mNumChannels )
  {
    *channel = this->mChannel[index];
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


