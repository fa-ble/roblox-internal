// Address: 0x223b110 | Name: _ZN4FMOD12DSPNormalize16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPNormalize::getDescriptionEx()
{
  memset(&stru_2B05220, 0, sizeof(stru_2B05220));
  FMOD_strcpy_safe(stru_2B05220.name, "Fade in time", 16);
  FMOD_strcpy_safe(stru_2B05220.label, "seconds", 16);
  *(_QWORD *)&stru_2B05220.floatdesc.min = 0x469C400000000000LL;
  stru_2B05220.description = "Time to ramp the silence to full in ms.  0.0 to 20000.0. Default = 5000.0.";
  memset(&stru_2B051C0, 0, sizeof(stru_2B051C0));
  stru_2B05220.intdesc.defaultval = 1167867904;
  stru_2B05220.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B051C0.name, "Lowest volume", 16);
  FMOD_strcpy_safe(stru_2B051C0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2B051C0.floatdesc.min = 0x3F80000000000000LL;
  stru_2B051C0.description = "Lower volume range threshold to ignore.  0.0 to 1.0.  Default = 0.1.  Raise higher to stop "
                             "amplification of very quiet signals.";
  memset(&stru_2B05160, 0, sizeof(stru_2B05160));
  stru_2B051C0.intdesc.defaultval = 1036831949;
  stru_2B051C0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B05160.name, "Maximum amp", 16);
  FMOD_strcpy_safe(stru_2B05160.label, "x", 16);
  *(_QWORD *)&stru_2B05160.floatdesc.min = 0x47C3500000000000LL;
  stru_2B05160.intdesc.defaultval = 1101004800;
  stru_2B05160.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B05160.description = "Maximum amplification allowed.  1.0 to 100000.0.  Default = 20.0.  1.0 = no amplifaction, h"
                             "igher values allow more boost.";
  *(&stru_2B05120.mHandle + 1) = 10;
  stru_2B05120.mSize = 560;
  stru_2B05120.mDescription = &stru_286F360;
  return &stru_2B05120;
}


// Address: 0x223b2b0 | Name: _ZN4FMOD12DSPNormalize14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPNormalize::createInternal(FMOD::DSPNormalize *const this)
{
  double v1; // xmm1_8
  __int64 v2; // rbp
  __int64 v3; // rax
  int v4; // ebx
  __int64 v5; // rax
  FMOD_RESULT_0 result; // eax

  v2 = 0;
  v3 = *((_QWORD *)this + 22);
  v4 = 0;
  *((_DWORD *)this + 133) = 1065353216;
  *((_DWORD *)this + 132) = 1065353216;
  *((_DWORD *)this + 134) = *(_DWORD *)(v3 + 1696);
  v5 = *((_QWORD *)this + 30);
  if ( *(int *)(v5 + 96) <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    result = FMOD::DSPI::setParameterFloat(
               (FMOD::DSPI *const)this,
               v4,
               (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v5 + 104) + v2) + 56LL),
               v1);
    if ( result )
      break;
    v5 = *((_QWORD *)this + 30);
    ++v4;
    v2 += 8;
    if ( *(_DWORD *)(v5 + 96) <= v4 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x223b340 | Name: _ZN4FMOD12DSPNormalize14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPNormalize::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPNormalize::createInternal((FMOD::DSPNormalize *const)dsp_state->instance);
}


// Address: 0x223b350 | Name: _ZN4FMOD12DSPNormalize15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPNormalize::releaseInternal(FMOD::DSPNormalize *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223b360 | Name: _ZN4FMOD12DSPNormalize15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPNormalize::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPNormalize::releaseInternal((FMOD::DSPNormalize *const)dsp_state->instance);
}


// Address: 0x223b370 | Name: _ZN4FMOD12DSPNormalize13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPNormalize::resetInternal(FMOD::DSPNormalize *const this)
{
  *((_DWORD *)this + 133) = 1065353216;
  *((_DWORD *)this + 132) = 1065353216;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223b390 | Name: _ZN4FMOD12DSPNormalize13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPNormalize::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPNormalize::resetInternal((FMOD::DSPNormalize *const)dsp_state->instance);
}


// Address: 0x223b3a0 | Name: _ZN4FMOD12DSPNormalize12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPNormalize::readInternal(
        FMOD::DSPNormalize *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float v6; // xmm4_4
  float v7; // xmm3_4
  float v8; // xmm5_4
  int v9; // r10d
  int i; // r11d
  float v11; // xmm1_4
  int j; // eax
  float v13; // xmm0_4
  int v14; // eax
  float v15; // xmm7_4
  __int64 v16; // r9

  v6 = *((float *)this + 138);
  v7 = *((float *)this + 136);
  v8 = *((float *)this + 137);
  if ( inbuffer && length )
  {
    v9 = 0;
    for ( i = 0; i != length; ++i )
    {
      v11 = *((float *)this + 132) - v6;
      if ( v7 > v11 )
      {
        *((float *)this + 132) = v7;
        v11 = v7;
      }
      else
      {
        *((float *)this + 132) = v11;
      }
      if ( inchannels )
      {
        for ( j = 0; j != inchannels; ++j )
        {
          v13 = fabs(inbuffer[v9 + j]);
          if ( v13 > v11 )
          {
            *((float *)this + 132) = v13;
            v11 = v13;
          }
        }
      }
      v14 = 0;
      v15 = fminf(v8, 1.0 / v11);
      if ( inchannels )
      {
        do
        {
          v16 = (unsigned int)(v9 + v14++);
          outbuffer[v16] = inbuffer[v16] * v15;
        }
        while ( v14 != inchannels );
      }
      v9 += inchannels;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223b480 | Name: _ZN4FMOD12DSPNormalize12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPNormalize::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPNormalize::readInternal(
           (FMOD::DSPNormalize *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x223b490 | Name: _ZN4FMOD12DSPNormalize25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPNormalize::setParameterFloatInternal(
        FMOD::DSPNormalize *const this,
        int index,
        float a3,
        float value)
{
  if ( index == 1 )
  {
    *((float *)this + 136) = a3;
    a3 = *((float *)this + 135);
  }
  else
  {
    if ( index == 2 )
    {
      *((float *)this + 137) = a3;
      goto LABEL_4;
    }
    if ( index )
    {
LABEL_4:
      a3 = *((float *)this + 135);
      goto LABEL_5;
    }
    *((float *)this + 135) = a3;
  }
LABEL_5:
  if ( a3 == 0.0 )
    *((_DWORD *)this + 138) = 1065353216;
  else
    *((float *)this + 138) = 1.0 / (float)((float)((float)*((int *)this + 134) * a3) / 1000.0);
  return 0;
}


// Address: 0x223b530 | Name: _ZN4FMOD12DSPNormalize25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPNormalize::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPNormalize::setParameterFloatInternal((FMOD::DSPNormalize *const)dsp_state->instance, index, a3, value);
}


// Address: 0x223b540 | Name: _ZN4FMOD12DSPNormalize25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPNormalize::getParameterFloatInternal(
        FMOD::DSPNormalize *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v5; // xmm0_4

  if ( index == 1 )
  {
    *value = *((float *)this + 136);
    if ( valuestr )
    {
      v5 = *((float *)this + 136);
      goto LABEL_9;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( index == 2 )
  {
    *value = *((float *)this + 137);
    if ( valuestr )
    {
      v5 = *((float *)this + 137);
      goto LABEL_9;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( index )
    return FMOD_RESULT::FMOD_OK_0;
  *value = *((float *)this + 135);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  v5 = *((float *)this + 135);
LABEL_9:
  sprintf(valuestr, "%.02f", v5);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223b5e0 | Name: _ZN4FMOD12DSPNormalize25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPNormalize::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPNormalize::getParameterFloatInternal(
           (FMOD::DSPNormalize *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


