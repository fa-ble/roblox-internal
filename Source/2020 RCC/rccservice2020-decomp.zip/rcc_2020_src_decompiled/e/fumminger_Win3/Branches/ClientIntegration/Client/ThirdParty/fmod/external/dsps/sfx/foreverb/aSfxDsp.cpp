// Address: 0x2267de0 | Name: _ZN7ASfxDsp12NextPowerOf2Ei
int __fastcall ASfxDsp::NextPowerOf2(ASfxDsp *const this, int delaySamples)
{
  return 1 << ((int)(float)(logf((float)delaySamples) / 0.69314718) + 1);
}


// Address: 0x2267e10 | Name: _ZN7ASfxDsp20DeallocateLateDelaysEv
void __fastcall ASfxDsp::DeallocateLateDelays(ASfxDsp *const this)
{
  __int64 i; // rbx
  float *v2; // rsi

  for ( i = 0; i != 8; ++i )
  {
    v2 = this->mLateDelays[i];
    if ( v2 )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v2, "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp", 237);
    this->mLateDelays[i] = 0;
  }
}


// Address: 0x2267e70 | Name: _ZN7ASfxDsp18AllocateLateDelaysEiPff
__int64 __fastcall ASfxDsp::AllocateLateDelays(ASfxDsp *const this, int numDelays, float *delaySec, float sampleRate)
{
  ASfxDsp *v4; // r12
  ASfxDsp *v6; // rbx
  int PowerOf2; // ebp
  float *v8; // rax

  v4 = this;
  v6 = this;
  ASfxDsp::DeallocateLateDelays(this);
  while ( 1 )
  {
    PowerOf2 = ASfxDsp::NextPowerOf2(this, (int)(float)(sampleRate * *delaySec) + 1);
    v8 = (float *)FMOD::MemPool::calloc(
                    off_286F358->gSystemMemPool,
                    4 * PowerOf2,
                    "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp",
                    140,
                    0);
    v4->mLateDelays[0] = v8;
    if ( !v8 )
      break;
    v6->mLateDelaySamplesAllocated[0] = PowerOf2;
    v6->mLateWritePointer[0] = 0;
    v6->mLateMask[0] = PowerOf2 - 1;
    ++delaySec;
    v4 = (ASfxDsp *)((char *)v4 + 8);
    v6 = (ASfxDsp *)((char *)v6 + 4);
    if ( v6 == (ASfxDsp *const)&this->mRoomHF )
      return 0;
  }
  return 4503;
}


// Address: 0x2267f60 | Name: _ZN7ASfxDsp23DeallocateAllpassDelaysEv
void __fastcall ASfxDsp::DeallocateAllpassDelays(ASfxDsp *const this)
{
  __int64 i; // rbx
  float *v2; // rsi

  for ( i = 0; i != 2; ++i )
  {
    v2 = this->mAllpassDelays[i];
    if ( v2 )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v2, "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp", 250);
    this->mAllpassDelays[i] = 0;
  }
}


// Address: 0x2267fc0 | Name: _ZN7ASfxDsp21AllocateAllpassDelaysEiPff
__int64 __fastcall ASfxDsp::AllocateAllpassDelays(
        ASfxDsp *const this,
        int numDelays,
        float *delaySec,
        float sampleRate)
{
  ASfxDsp *v5; // rbp
  __int64 v6; // rbx
  int PowerOf2; // r12d
  float *v8; // rax

  v5 = this;
  v6 = 0;
  ASfxDsp::DeallocateAllpassDelays(this);
  while ( 1 )
  {
    PowerOf2 = ASfxDsp::NextPowerOf2(this, (int)(float)(sampleRate * delaySec[v6]) + 1);
    v8 = (float *)FMOD::MemPool::calloc(
                    off_286F358->gSystemMemPool,
                    4 * PowerOf2,
                    "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp",
                    191,
                    0);
    this->mAllpassDelays[v6] = v8;
    if ( !v8 )
      break;
    v5->mAllpassSamplesAllocated[0] = PowerOf2;
    ++v6;
    v5->mAllpassMask[0] = PowerOf2 - 1;
    v5->mAllpassWritePointer[0] = 0;
    v5 = (ASfxDsp *)((char *)v5 + 4);
    if ( v6 == 2 )
      return 0;
  }
  return 4500;
}


// Address: 0x2268090 | Name: _ZN7ASfxDsp20DeallocateEarlyDelayEv
void __fastcall ASfxDsp::DeallocateEarlyDelay(ASfxDsp *const this)
{
  float *mEarlyDelay; // rsi

  mEarlyDelay = this->mEarlyDelay;
  if ( mEarlyDelay )
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      mEarlyDelay,
      "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp",
      261);
  this->mEarlyDelay = 0;
}


// Address: 0x22680d0 | Name: _ZN7ASfxDsp18AllocateEarlyDelayEff
__int16 __fastcall ASfxDsp::AllocateEarlyDelay(ASfxDsp *const this, float a2, float delaySec, float sampleRate)
{
  int PowerOf2; // ebp
  float *v5; // rdx
  __int16 result; // ax

  PowerOf2 = ASfxDsp::NextPowerOf2(this, (int)(float)(a2 * delaySec) + 1);
  ASfxDsp::DeallocateEarlyDelay(this);
  v5 = (float *)FMOD::MemPool::calloc(
                  off_286F358->gSystemMemPool,
                  4 * PowerOf2,
                  "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp",
                  214,
                  0);
  this->mEarlyDelay = v5;
  result = 4502;
  if ( v5 )
  {
    this->mEarlyDelaySamplesAllocated = PowerOf2;
    this->mEarlyMask = PowerOf2 - 1;
    return 0;
  }
  return result;
}


// Address: 0x2268150 | Name: _ZN7ASfxDsp24DeallocateEarlyLateDelayEv
void __fastcall ASfxDsp::DeallocateEarlyLateDelay(ASfxDsp *const this)
{
  float *mEarlyLateDelay; // rsi

  mEarlyLateDelay = this->mEarlyLateDelay;
  if ( mEarlyLateDelay )
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      mEarlyLateDelay,
      "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp",
      271);
  this->mEarlyLateDelay = 0;
}


// Address: 0x2268190 | Name: _ZN7ASfxDsp5closeEv
void __fastcall ASfxDsp::close(ASfxDsp *const this)
{
  if ( this->mInBuffMemory )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      this->mInBuffMemory,
      "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp",
      115);
    this->mInBuff = 0;
    this->mInBuffMemory = 0;
  }
  ASfxDsp::DeallocateLateDelays(this);
  ASfxDsp::DeallocateEarlyLateDelay(this);
  ASfxDsp::DeallocateAllpassDelays(this);
  ASfxDsp::DeallocateEarlyDelay(this);
}


// Address: 0x22681f0 | Name: _ZN7ASfxDsp22AllocateEarlyLateDelayEPff
__int16 __fastcall ASfxDsp::AllocateEarlyLateDelay(ASfxDsp *const this, float *delaySec, float a3, float sampleRate)
{
  int PowerOf2; // ebp
  float *v5; // rdx
  __int16 result; // ax

  PowerOf2 = ASfxDsp::NextPowerOf2(
               this,
               (int)(float)((float)((float)(delaySec[8] + 0.40000001) - delaySec[1]) * a3) + 1);
  ASfxDsp::DeallocateEarlyLateDelay(this);
  v5 = (float *)FMOD::MemPool::calloc(
                  off_286F358->gSystemMemPool,
                  4 * PowerOf2,
                  "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp",
                  167,
                  0);
  this->mEarlyLateDelay = v5;
  result = 4501;
  if ( v5 )
  {
    this->mEarlyLateSamplesAllocated = PowerOf2;
    this->mEarlyLateMask = PowerOf2 - 1;
    return 0;
  }
  return result;
}


// Address: 0x2268280 | Name: _ZN7ASfxDsp16UpdateBufferSizeEi
int __fastcall ASfxDsp::UpdateBufferSize(ASfxDsp *const this, int newMaxBlockSize)
{
  float *v2; // rdx
  int result; // eax

  if ( this->mNumAllocatedInBuffSamples == newMaxBlockSize )
    return 0;
  this->mNumAllocatedInBuffSamples = newMaxBlockSize;
  if ( this->mInBuffMemory )
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      this->mInBuffMemory,
      "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp",
      293);
  v2 = (float *)FMOD::MemPool::alloc(
                  off_286F358->gSystemMemPool,
                  4 * newMaxBlockSize + 16,
                  "../../../external/dsps/sfx/foreverb/aSfxDsp.cpp",
                  296,
                  0,
                  0);
  this->mInBuffMemory = v2;
  result = 4505;
  if ( v2 )
  {
    LOWORD(result) = 0;
    this->mInBuff = (float *)(((unsigned __int64)v2 + 15) & 0xFFFFFFFFFFFFFFF0LL);
  }
  return result;
}


// Address: 0x2268320 | Name: _ZN7ASfxDsp11ClearInBuffEv
void __fastcall ASfxDsp::ClearInBuff(ASfxDsp *const this)
{
  float *mInBuff; // rdx
  int mNumAllocatedInBuffSamples; // ecx
  __int64 v3; // rax

  mInBuff = this->mInBuff;
  if ( mInBuff )
  {
    mNumAllocatedInBuffSamples = this->mNumAllocatedInBuffSamples;
    if ( mNumAllocatedInBuffSamples > 0 )
    {
      v3 = 0;
      do
        mInBuff[v3++] = 0.0;
      while ( mNumAllocatedInBuffSamples > (int)v3 );
    }
  }
}


// Address: 0x2268350 | Name: _ZN7ASfxDsp26ClearReverbInternalBuffersEv
void __fastcall ASfxDsp::ClearReverbInternalBuffers(ASfxDsp *const this)
{
  __int64 i; // rsi
  float *v3; // rdx
  int v4; // ecx
  __int64 v5; // rax
  int mEarlyLateSamplesAllocated; // edx
  float *mEarlyLateDelay; // rcx
  __int64 v8; // rax
  int mEarlyDelaySamplesAllocated; // edx
  float *mEarlyDelay; // rcx
  __int64 v11; // rax
  int v12; // edx
  float *v13; // rcx
  __int64 v14; // rax
  int v15; // edx
  float *v16; // rcx
  __int64 v17; // rax
  float *mzDecayHF; // rax
  unsigned int v19; // edx
  float *mMatrix; // rdi
  __int64 v21; // rcx
  float *v22; // rdi

  for ( i = 0; i != 8; ++i )
  {
    v3 = this->mLateDelays[i];
    if ( v3 )
    {
      v4 = this->mLateDelaySamplesAllocated[i];
      if ( v4 > 0 )
      {
        v5 = 0;
        do
          v3[v5++] = 0.0;
        while ( v4 > (int)v5 );
      }
    }
  }
  mEarlyLateSamplesAllocated = this->mEarlyLateSamplesAllocated;
  if ( mEarlyLateSamplesAllocated > 0 )
  {
    mEarlyLateDelay = this->mEarlyLateDelay;
    v8 = 0;
    do
      mEarlyLateDelay[v8++] = 0.0;
    while ( mEarlyLateSamplesAllocated > (int)v8 );
  }
  mEarlyDelaySamplesAllocated = this->mEarlyDelaySamplesAllocated;
  if ( mEarlyDelaySamplesAllocated > 0 )
  {
    mEarlyDelay = this->mEarlyDelay;
    v11 = 0;
    do
      mEarlyDelay[v11++] = 0.0;
    while ( mEarlyDelaySamplesAllocated > (int)v11 );
  }
  v12 = this->mAllpassSamplesAllocated[0];
  if ( v12 > 0 )
  {
    v13 = this->mAllpassDelays[0];
    v14 = 0;
    do
      v13[v14++] = 0.0;
    while ( v12 > (int)v14 );
  }
  v15 = this->mAllpassSamplesAllocated[1];
  if ( v15 > 0 )
  {
    v16 = this->mAllpassDelays[1];
    v17 = 0;
    do
      v16[v17++] = 0.0;
    while ( v15 > (int)v17 );
  }
  mzDecayHF = this->mzDecayHF;
  v19 = 96;
  *(_QWORD *)mzDecayHF = 0;
  *((_QWORD *)mzDecayHF + 1) = 0;
  *((_QWORD *)mzDecayHF + 2) = 0;
  *((_QWORD *)mzDecayHF + 3) = 0;
  mMatrix = this->mMatrix;
  if ( ((unsigned __int8)mMatrix & 1) == 0 )
  {
    if ( ((unsigned __int8)mMatrix & 2) == 0 )
      goto LABEL_21;
LABEL_30:
    mMatrix = (float *)((char *)mMatrix + 2);
    v19 -= 2;
    *((_WORD *)mMatrix - 1) = 0;
    if ( ((unsigned __int8)mMatrix & 4) == 0 )
      goto LABEL_22;
    goto LABEL_31;
  }
  *(_BYTE *)mMatrix = 0;
  mMatrix = (float *)((char *)mMatrix + 1);
  LOBYTE(v19) = 95;
  if ( ((unsigned __int8)mMatrix & 2) != 0 )
    goto LABEL_30;
LABEL_21:
  if ( ((unsigned __int8)mMatrix & 4) == 0 )
    goto LABEL_22;
LABEL_31:
  *mMatrix = 0.0;
  v19 -= 4;
  ++mMatrix;
LABEL_22:
  v21 = v19 >> 3;
  memset(mMatrix, 0, 8 * v21);
  v22 = &mMatrix[2 * v21];
  if ( (v19 & 4) != 0 )
    *v22++ = 0.0;
  if ( (v19 & 2) != 0 )
  {
    v22 = (float *)((char *)v22 + 2);
    *((_WORD *)v22 - 1) = 0;
  }
  if ( (v19 & 1) != 0 )
    *(_BYTE *)v22 = 0;
  this->mzRoomHF0 = 0.0;
  this->mzRoomHF1 = 0.0;
  this->mzRoomLF0 = 0.0;
  this->mzRoomLF1 = 0.0;
}


// Address: 0x2268500 | Name: _ZN7ASfxDsp12ClearBuffersEv
void __fastcall ASfxDsp::ClearBuffers(ASfxDsp *const this)
{
  ASfxDsp::ClearInBuff(this);
  ASfxDsp::ClearReverbInternalBuffers(this);
}


// Address: 0x2268520 | Name: _ZN7ASfxDsp17BlockProcessInputEjiPff
void __fastcall ASfxDsp::BlockProcessInput(
        ASfxDsp *const this,
        unsigned int sampframes,
        int channels,
        float *inAudio,
        float rate)
{
  float *v5; // rdi
  float *v6; // r9
  __int64 v7; // r10
  unsigned int v8; // eax
  unsigned int v9; // r8d
  float v10; // xmm0_4
  __int64 v11; // rsi
  unsigned int v12; // esi
  float *mInBuff; // rax
  float *v14; // rdx
  float v15; // xmm0_4
  unsigned int v16; // esi
  float *v17; // rax
  int v18; // edx
  float v19; // xmm0_4

  switch ( channels )
  {
    case 1:
      memmove(this->mInBuff, inAudio, 4LL * sampframes);
      break;
    case 6:
      v12 = sampframes >> 2;
      mInBuff = this->mInBuff;
      if ( v12 )
      {
        v14 = &inAudio[24 * v12];
        do
        {
          v15 = *inAudio;
          inAudio += 24;
          mInBuff += 4;
          *(mInBuff - 4) = (float)((float)((float)((float)(v15 + *(inAudio - 23)) + *(inAudio - 22)) + *(inAudio - 21))
                                 + *(inAudio - 20))
                         + *(inAudio - 19);
          *(mInBuff - 3) = (float)((float)((float)((float)(*(inAudio - 18) + *(inAudio - 17)) + *(inAudio - 16))
                                         + *(inAudio - 15))
                                 + *(inAudio - 14))
                         + *(inAudio - 13);
          *(mInBuff - 2) = (float)((float)((float)((float)(*(inAudio - 12) + *(inAudio - 11)) + *(inAudio - 10))
                                         + *(inAudio - 9))
                                 + *(inAudio - 8))
                         + *(inAudio - 7);
          *(mInBuff - 1) = (float)((float)((float)((float)(*(inAudio - 6) + *(inAudio - 5)) + *(inAudio - 4))
                                         + *(inAudio - 3))
                                 + *(inAudio - 2))
                         + *(inAudio - 1);
        }
        while ( inAudio != v14 );
      }
      break;
    case 8:
      v16 = sampframes >> 2;
      v17 = this->mInBuff;
      if ( v16 )
      {
        v18 = 0;
        do
        {
          v19 = *inAudio;
          ++v18;
          inAudio += 32;
          v17 += 4;
          *(v17 - 4) = (float)((float)((float)((float)((float)((float)(v19 + *(inAudio - 31)) + *(inAudio - 30))
                                                     + *(inAudio - 29))
                                             + *(inAudio - 28))
                                     + *(inAudio - 27))
                             + *(inAudio - 26))
                     + *(inAudio - 25);
          *(v17 - 3) = (float)((float)((float)((float)((float)((float)(*(inAudio - 24) + *(inAudio - 23))
                                                             + *(inAudio - 22))
                                                     + *(inAudio - 21))
                                             + *(inAudio - 20))
                                     + *(inAudio - 19))
                             + *(inAudio - 18))
                     + *(inAudio - 17);
          *(v17 - 2) = (float)((float)((float)((float)((float)((float)(*(inAudio - 16) + *(inAudio - 15))
                                                             + *(inAudio - 14))
                                                     + *(inAudio - 13))
                                             + *(inAudio - 12))
                                     + *(inAudio - 11))
                             + *(inAudio - 10))
                     + *(inAudio - 9);
          *(v17 - 1) = (float)((float)((float)((float)((float)((float)(*(inAudio - 8) + *(inAudio - 7)) + *(inAudio - 6))
                                                     + *(inAudio - 5))
                                             + *(inAudio - 4))
                                     + *(inAudio - 3))
                             + *(inAudio - 2))
                     + *(inAudio - 1);
        }
        while ( v18 != v16 );
      }
      break;
    default:
      if ( sampframes )
      {
        v5 = this->mInBuff;
        v6 = v5 + 1;
        v7 = (__int64)&v5[sampframes];
        v8 = 0;
        while ( 1 )
        {
          *v5 = 0.0;
          v9 = channels + v8;
          v10 = 0.0;
          if ( channels > 0 )
          {
            do
            {
              v11 = v8++;
              v10 = v10 + inAudio[v11];
              *v5 = v10;
            }
            while ( v8 != v9 );
          }
          v5 = v6;
          v8 = v9;
          if ( v6 == (float *)v7 )
            break;
          ++v6;
        }
      }
      break;
  }
}


// Address: 0x2268750 | Name: _ZN7ASfxDsp15DoDSPProcessingEPfS0_ijff
void __fastcall ASfxDsp::DoDSPProcessing(
        ASfxDsp *const this,
        float *inAudio,
        float *outAudio,
        int channels,
        unsigned int l_sampframes,
        float rate,
        float drymix)
{
  int mEarlyLateWritePointer; // r8d
  ASfxDsp *v10; // rax
  __int64 v11; // rdx
  int mEarlyLateMask; // edi
  float v13; // xmm3_4
  int v14; // esi
  int v15; // ecx
  ASfxDsp *v16; // rdx
  ASfxDsp *v17; // rax
  int v18; // r9d
  float v19; // xmm0_4
  float v20; // xmm2_4
  int v21; // esi
  int v22; // r8d
  int v23; // edi
  int v24; // ecx
  float v25; // xmm0_4
  float v26; // xmm2_4
  float mLRgain; // xmm0_4
  float mOldLRgain; // xmm2_4
  float mERgain; // xmm0_4
  float mOldERgain; // xmm2_4
  float mRoomHF; // xmm0_4
  float mOldRoomHF; // xmm2_4
  float mHadamard; // xmm0_4
  float mOldHadamard; // xmm2_4
  float mDiffusionScale; // xmm0_4
  float mOldDiffusionScale; // xmm2_4
  int v37; // eax
  float *mEarlyLateDelay; // r13
  int v39; // r14d
  float *mEarlyDelay; // r15
  float *mzDecayHF; // r8
  float *mMatrix; // r9
  int v43; // r10d
  float mLatchRoomHF; // xmm6_4
  float mLatchHadamard; // xmm7_4
  float mLatchDiffusionScale; // xmm11_4
  bool v47; // zf
  float v48; // xmm8_4
  float v49; // xmm0_4
  float v50; // xmm0_4
  float v51; // xmm6_4
  float v52; // xmm8_4
  float v53; // xmm0_4
  float v54; // xmm6_4
  int v55; // ecx
  int v56; // edx
  float mLatchERgain; // xmm0_4
  float v58; // xmm8_4
  int v59; // edx
  float v60; // xmm8_4
  ASfxDsp *v61; // rdx
  int v62; // edi
  int v63; // ecx
  int v64; // esi
  __int64 v65; // rdi
  float v66; // xmm0_4
  __int64 i; // rdx
  int v68; // ecx
  ASfxDsp *v69; // rsi
  ASfxDsp *v70; // rdx
  float *v71; // r11
  __int64 v72; // rcx
  bool mLRgainChanged; // r15
  float v74; // xmm10_4
  float v75; // xmm9_4
  float v76; // xmm6_4
  int v77; // r10d
  int v78; // edi
  float v79; // xmm0_4
  float v80; // xmm8_4
  int v81; // r12d
  float v82; // xmm0_4
  float v83; // xmm0_4
  float v84; // xmm6_4
  float v85; // xmm0_4
  float v86; // xmm6_4
  float v87; // xmm0_4
  int v88; // edi
  int v89; // edi
  float v90; // xmm0_4
  int v91; // edi
  int v92; // r11d
  float v93; // xmm15_4
  float v94; // xmm8_4
  float v95; // xmm14_4
  float v96; // xmm9_4
  float v97; // xmm0_4
  float v98; // xmm14_4
  float v99; // xmm13_4
  float v100; // xmm11_4
  float v101; // xmm12_4
  float v102; // xmm6_4
  float v103; // xmm10_4
  float v104; // xmm10_4
  float v105; // xmm6_4
  float v106; // xmm15_4
  float v107; // xmm8_4
  float v108; // xmm12_4
  float v109; // xmm0_4
  float v110; // xmm10_4
  float v111; // xmm11_4
  __int64 v112; // rdx
  int v113; // edi
  float v114; // xmm6_4
  float v115; // xmm0_4
  int v116; // r10d
  __int64 v117; // rcx
  char *v118; // rsi
  int v119; // edx
  __int64 v120; // rdx
  float v121; // [rsp+0h] [rbp-108h]
  __int64 v122; // [rsp+0h] [rbp-108h]
  int drymixa; // [rsp+Ch] [rbp-FCh]
  int mEarlyWritePointer; // [rsp+10h] [rbp-F8h]
  int v125; // [rsp+14h] [rbp-F4h]
  int mNumLateReverbDelays; // [rsp+24h] [rbp-E4h]
  float *v128; // [rsp+28h] [rbp-E0h]
  float *v129; // [rsp+38h] [rbp-D0h]
  float *mInBuff; // [rsp+40h] [rbp-C8h]
  bool mRoomHFChanged; // [rsp+4Fh] [rbp-B9h]
  bool mHadamardChanged; // [rsp+50h] [rbp-B8h]
  bool mDiffusionScaleChanged; // [rsp+51h] [rbp-B7h]
  bool mERgainChanged; // [rsp+52h] [rbp-B6h]
  bool v135; // [rsp+53h] [rbp-B5h]
  int mEarlyMask; // [rsp+54h] [rbp-B4h]
  float *v137; // [rsp+58h] [rbp-B0h]
  float *v138; // [rsp+60h] [rbp-A8h]
  float *v139; // [rsp+68h] [rbp-A0h]
  float *v140; // [rsp+70h] [rbp-98h]
  float *v141; // [rsp+78h] [rbp-90h]
  float *v142; // [rsp+80h] [rbp-88h]
  float *v143; // [rsp+88h] [rbp-80h]
  float eruOut[22]; // [rsp+B0h] [rbp-58h]

  v121 = 1.0 / (float)(int)l_sampframes;
  ASfxDsp::BlockProcessInput(this, l_sampframes, channels, inAudio, rate);
  mEarlyLateWritePointer = this->mEarlyLateWritePointer;
  v10 = this;
  v11 = 0;
  mEarlyLateMask = this->mEarlyLateMask;
  v13 = v121;
  do
  {
    while ( 1 )
    {
      v14 = v10->mEarlyLateSamples[0];
      v10->mEarlyLateReadPointer[0] = mEarlyLateMask & (v14 + mEarlyLateWritePointer - 1);
      v15 = v10->mOldEarlyLateSamples[0];
      if ( v14 == v15 )
        break;
      this->mEarlyLateChanged[v11++] = 1;
      v10->mOldEarlyLateSamples[0] = v14;
      v10 = (ASfxDsp *)((char *)v10 + 4);
      v10->mEarlyLateReadPointer[8] = mEarlyLateMask & (mEarlyLateWritePointer + v15 - 1);
      if ( v11 == 9 )
        goto LABEL_5;
    }
    this->mEarlyLateChanged[v11++] = 0;
    v10 = (ASfxDsp *)((char *)v10 + 4);
  }
  while ( v11 != 9 );
LABEL_5:
  v16 = this;
  v17 = this;
  v18 = 8;
  do
  {
    while ( 1 )
    {
      v21 = v17->mLateDelayLenSamples[0];
      v22 = v17->mLateWritePointer[0];
      v23 = v17->mLateMask[0];
      v17->mLateReadPointer[0] = v23 & (v21 + v22 - 1);
      v17->mLateReadPointerB[0] = v23 & (v22 + v17->mLateDelayLenBSamples[0] - 1);
      v24 = v17->mOldLateDelayLenSamples[0];
      if ( v21 == v24 )
      {
        v16->mLateChanged[0] = 0;
      }
      else
      {
        v16->mLateChanged[0] = 1;
        v17->mOldLateDelayLenSamples[0] = v21;
        v17->mOldLateReadPointer[0] = v23 & (v22 + v24 - 1);
      }
      v25 = v17->mFeedback[0];
      v26 = v17->mOldFeedback[0];
      v17->mLatchFeedback[0] = v25;
      if ( v25 == v26 )
      {
        v17->mPrevFeedback[0] = v25;
      }
      else
      {
        if ( !v16->mLateChanged[0] )
        {
          v16->mLateChanged[0] = 1;
          v17->mOldLateReadPointer[0] = v17->mLateMask[0]
                                      & (v17->mLateWritePointer[0] + v17->mOldLateDelayLenSamples[0] - 1);
        }
        v17->mPrevFeedback[0] = v26;
        v17->mOldFeedback[0] = v25;
      }
      v19 = v17->mDecayHF[0];
      v17->mLatchDecayHF[0] = v19;
      v17->mLatchOneMinusDecayHF[0] = 1.0 - v19;
      v20 = v17->mOldDecayHF[0];
      if ( v19 != v20 )
        break;
      v16->mDecayHFChanged[0] = 0;
      v17 = (ASfxDsp *)((char *)v17 + 4);
      v16 = (ASfxDsp *)((char *)v16 + 1);
      if ( !--v18 )
        goto LABEL_17;
    }
    v16->mDecayHFChanged[0] = 1;
    v17 = (ASfxDsp *)((char *)v17 + 4);
    v17->mLatchOneMinusDecayHF[7] = v20;
    v17->mPrevDecayHF[7] = v19;
    v16 = (ASfxDsp *)((char *)v16 + 1);
    --v18;
  }
  while ( v18 );
LABEL_17:
  mLRgain = this->mLRgain;
  mOldLRgain = this->mOldLRgain;
  this->mLatchLRgain = mLRgain;
  if ( mLRgain == mOldLRgain )
  {
    this->mLRgainChanged = 0;
  }
  else
  {
    this->mPrevLRgain = mOldLRgain;
    this->mLRgainChanged = 1;
    this->mOldLRgain = mLRgain;
  }
  mERgain = this->mERgain;
  mOldERgain = this->mOldERgain;
  this->mLatchERgain = mERgain;
  if ( mERgain == mOldERgain )
  {
    this->mERgainChanged = 0;
  }
  else
  {
    this->mPrevERgain = mOldERgain;
    this->mERgainChanged = 1;
    this->mOldERgain = mERgain;
  }
  mRoomHF = this->mRoomHF;
  mOldRoomHF = this->mOldRoomHF;
  this->mLatchRoomHF = mRoomHF;
  if ( mRoomHF == mOldRoomHF )
  {
    this->mRoomHFChanged = 0;
  }
  else
  {
    this->mPrevRoomHF = mOldRoomHF;
    this->mRoomHFChanged = 1;
    this->mOldRoomHF = mRoomHF;
  }
  mHadamard = this->mHadamard;
  mOldHadamard = this->mOldHadamard;
  this->mLatchHadamard = mHadamard;
  if ( mHadamard == mOldHadamard )
  {
    this->mHadamardChanged = 0;
  }
  else
  {
    this->mPrevHadamard = mOldHadamard;
    this->mHadamardChanged = 1;
    this->mOldHadamard = mHadamard;
  }
  mDiffusionScale = this->mDiffusionScale;
  mOldDiffusionScale = this->mOldDiffusionScale;
  this->mLatchDiffusionScale = mDiffusionScale;
  if ( mDiffusionScale == mOldDiffusionScale )
  {
    this->mDiffusionScaleChanged = 0;
  }
  else
  {
    this->mPrevDiffusionScale = mOldDiffusionScale;
    this->mDiffusionScaleChanged = 1;
    this->mOldDiffusionScale = mDiffusionScale;
  }
  v37 = 8 / channels;
  if ( l_sampframes )
  {
    mEarlyLateDelay = this->mEarlyLateDelay;
    v39 = 0;
    mEarlyDelay = this->mEarlyDelay;
    mzDecayHF = this->mzDecayHF;
    mMatrix = this->mMatrix;
    mInBuff = this->mInBuff;
    mRoomHFChanged = this->mRoomHFChanged;
    mHadamardChanged = this->mHadamardChanged;
    mDiffusionScaleChanged = this->mDiffusionScaleChanged;
    drymixa = this->mEarlyLateWritePointer;
    v125 = this->mEarlyLateMask;
    mERgainChanged = this->mERgainChanged;
    v135 = this->mEarlyLateChanged[0];
    mEarlyWritePointer = this->mEarlyWritePointer;
    mEarlyMask = this->mEarlyMask;
    mNumLateReverbDelays = this->mNumLateReverbDelays;
    v128 = this->mLateDelays[0];
    v137 = this->mLateDelays[1];
    v138 = this->mLateDelays[2];
    v139 = this->mLateDelays[3];
    v122 = 0;
    v140 = this->mLateDelays[4];
    v141 = this->mLateDelays[5];
    v142 = this->mLateDelays[6];
    v143 = this->mLateDelays[7];
    do
    {
      v43 = l_sampframes - v122;
      if ( mRoomHFChanged )
        mLatchRoomHF = (float)((float)((float)v43 * this->mPrevRoomHF) + (float)((float)(int)v122 * this->mLatchRoomHF))
                     * v13;
      else
        mLatchRoomHF = this->mLatchRoomHF;
      if ( mHadamardChanged )
        mLatchHadamard = (float)((float)((float)v43 * this->mPrevHadamard)
                               + (float)((float)(int)v122 * this->mLatchHadamard))
                       * v13;
      else
        mLatchHadamard = this->mLatchHadamard;
      if ( mDiffusionScaleChanged )
        mLatchDiffusionScale = (float)((float)((float)v43 * this->mPrevDiffusionScale)
                                     + (float)((float)(int)v122 * this->mLatchDiffusionScale))
                             * v13;
      else
        mLatchDiffusionScale = this->mLatchDiffusionScale;
      v47 = this->mRoomLF == 0.0;
      v48 = (float)(1.0 - mLatchRoomHF) * this->mzRoomHF1;
      v49 = (float)(mInBuff[v122] * mLatchRoomHF) + (float)(this->mzRoomHF0 * (float)(1.0 - mLatchRoomHF));
      this->mzRoomHF0 = v49;
      v50 = (float)(v49 * mLatchRoomHF) + v48;
      this->mzRoomHF1 = v50;
      if ( !v47 )
      {
        v51 = this->mRoomLFcoeffs.a0 * v50;
        v52 = this->mRoomLFcoeffs.a1 * v50;
        v53 = v50 * this->mRoomLFcoeffs.a2;
        v54 = v51 + this->mzRoomLF0;
        this->mzRoomLF0 = (float)(v52 + this->mzRoomLF1) + (float)(this->mRoomLFcoeffs.b1 * v54);
        this->mzRoomLF1 = v53 + (float)(this->mRoomLFcoeffs.b2 * v54);
        v50 = v54;
      }
      drymixa = v125 & (drymixa - 1);
      v55 = this->mEarlyLateReadPointer[0];
      mEarlyLateDelay[drymixa] = v50;
      v56 = v125 & (v55 - 1);
      this->mEarlyLateReadPointer[0] = v56;
      if ( mERgainChanged )
        mLatchERgain = (float)((float)((float)v43 * this->mPrevERgain) + (float)((float)(int)v122 * this->mLatchERgain))
                     * v13;
      else
        mLatchERgain = this->mLatchERgain;
      v58 = mEarlyLateDelay[v56] * mLatchERgain;
      if ( v135 )
      {
        v59 = v125 & (this->mOldEarlyLateReadPointer[0] - 1);
        this->mOldEarlyLateReadPointer[0] = v59;
        v58 = (float)((float)(v58 * (float)(int)v122)
                    + (float)((float)v43 * (float)(mLatchERgain * mEarlyLateDelay[v59])))
            * v13;
      }
      v60 = v58 + 9.9999997e-21;
      v61 = this;
      while ( 1 )
      {
        v62 = v61->mAllpassMask[0];
        v63 = v62 & (v61->mAllpassWritePointer[0] - 1);
        v64 = v62 & (v61->mAllpassReadPointer[0] - 1);
        v61->mAllpassWritePointer[0] = v63;
        v61->mAllpassReadPointer[0] = v64;
        v65 = *(_QWORD *)(2LL * (_QWORD)v61 - (_QWORD)this + 1472);
        v61 = (ASfxDsp *)((char *)v61 + 4);
        v66 = *(float *)(v65 + 4LL * v64) - (float)(this->mAllpassGain * v60);
        *(float *)(v65 + 4LL * v63) = (float)(this->mAllpassGain * v66) + v60;
        if ( v61 == (ASfxDsp *)&this->mInBuff )
          break;
        v60 = v66;
      }
      eruOut[0] = v66;
      mEarlyWritePointer = mEarlyMask & (mEarlyWritePointer - 1);
      mEarlyDelay[mEarlyWritePointer] = v66;
      for ( i = 0; i != 7; ++i )
      {
        v68 = mEarlyMask & (this->mEarlyReadPointer[i] - 1);
        this->mEarlyReadPointer[i] = v68;
        eruOut[i + 1] = mEarlyDelay[v68];
      }
      if ( mNumLateReverbDelays > 0 )
      {
        v69 = this;
        v129 = mEarlyDelay;
        v70 = this;
        v71 = v128;
        v72 = 0;
        mLRgainChanged = this->mLRgainChanged;
        v74 = (float)v43;
        v75 = (float)(int)v122;
        while ( 1 )
        {
          v89 = v125 & (v70->mEarlyLateReadPointer[1] - 1);
          v70->mEarlyLateReadPointer[1] = v89;
          v90 = mEarlyLateDelay[v89];
          if ( v69->mEarlyLateChanged[1] )
          {
            v91 = v125 & (v70->mOldEarlyLateReadPointer[1] - 1);
            v70->mOldEarlyLateReadPointer[1] = v91;
            v90 = (float)((float)(v90 * v75) + (float)(mEarlyLateDelay[v91] * v74)) * v13;
          }
          if ( mLRgainChanged )
            v76 = (float)((float)((float)(this->mPrevLRgain * v74) + (float)(this->mLatchLRgain * v75)) * v13) * v90;
          else
            v76 = this->mLatchLRgain * v90;
          v77 = v70->mLateMask[0];
          v78 = v77 & (v70->mLateReadPointer[0] - 1);
          v70->mLateReadPointer[0] = v78;
          if ( v69->mLateChanged[0] )
          {
            v79 = v70->mPrevFeedback[0];
            v80 = v70->mLatchFeedback[0];
            v81 = v77 & (v70->mOldLateReadPointer[0] - 1);
            v70->mOldLateReadPointer[0] = v81;
            v82 = (float)((float)((float)((float)(v79 * v71[v81]) * v74) + (float)((float)(v80 * v71[v78]) * v75)) * v13)
                + v76;
          }
          else
          {
            v82 = (float)(v70->mLatchFeedback[0] * v71[v78]) + v76;
          }
          v83 = v82 * mLatchDiffusionScale;
          v84 = 1.0e-15;
          if ( (v72 & 1) == 0 )
            v84 = -1.0e-15;
          v85 = v83 + v84;
          if ( v69->mDecayHFChanged[0] )
          {
            v86 = (float)((float)(v70->mPrevDecayHF[0] * v74) + (float)(v70->mLatchDecayHF[0] * v75)) * v13;
            v87 = (float)(v85 * v86) + (float)(mzDecayHF[v72] * (float)(1.0 - v86));
          }
          else
          {
            v87 = (float)(v85 * v70->mLatchDecayHF[0]) + (float)(mzDecayHF[v72] * v70->mLatchOneMinusDecayHF[0]);
          }
          mzDecayHF[v72] = v87;
          v88 = v70->mLateWritePointer[0];
          ++v72;
          v70 = (ASfxDsp *)((char *)v70 + 4);
          v69 = (ASfxDsp *)((char *)v69 + 1);
          v70->mLateMask[7] = v77 & (v88 - 1);
          if ( mNumLateReverbDelays <= (int)v72 )
            break;
          v71 = this->mLateDelays[v72];
        }
        mEarlyDelay = v129;
      }
      v92 = 0;
      v93 = (float)(mzDecayHF[1] * mLatchHadamard) + *mzDecayHF;
      *mMatrix = v93;
      v94 = mzDecayHF[1] - (float)(*mzDecayHF * mLatchHadamard);
      mMatrix[1] = v94;
      v95 = (float)(mzDecayHF[3] * mLatchHadamard) + mzDecayHF[2];
      mMatrix[2] = v95;
      v96 = (float)(mLatchHadamard * v95) + v93;
      v97 = mzDecayHF[3] - (float)(mzDecayHF[2] * mLatchHadamard);
      v98 = v95 - (float)(v93 * mLatchHadamard);
      mMatrix[3] = v97;
      v99 = (float)(mzDecayHF[5] * mLatchHadamard) + mzDecayHF[4];
      mMatrix[4] = v99;
      v100 = mzDecayHF[5] - (float)(mzDecayHF[4] * mLatchHadamard);
      mMatrix[5] = v100;
      v101 = (float)(mzDecayHF[7] * mLatchHadamard) + mzDecayHF[6];
      mMatrix[6] = v101;
      v102 = mzDecayHF[6] * mLatchHadamard;
      v103 = mzDecayHF[7];
      mMatrix[8] = v96;
      mMatrix[10] = v98;
      v104 = v103 - v102;
      mMatrix[7] = v104;
      v105 = (float)(mLatchHadamard * v97) + v94;
      mMatrix[9] = v105;
      v106 = v97 - (float)(v94 * mLatchHadamard);
      mMatrix[11] = v106;
      v107 = (float)(mLatchHadamard * v101) + v99;
      v108 = v101 - (float)(v99 * mLatchHadamard);
      v109 = (float)(mLatchHadamard * v104) + v100;
      mMatrix[12] = v107;
      mMatrix[14] = v108;
      v110 = v104 - (float)(v100 * mLatchHadamard);
      mMatrix[13] = v109;
      mMatrix[15] = v110;
      mMatrix[16] = (float)(mLatchHadamard * v107) + v96;
      v111 = (float)(mLatchHadamard * v109) + v105;
      mMatrix[17] = v111;
      v112 = this->mLateWritePointer[0];
      mMatrix[18] = (float)(mLatchHadamard * v108) + v98;
      mMatrix[20] = v107 - (float)(v96 * mLatchHadamard);
      mMatrix[22] = v108 - (float)(v98 * mLatchHadamard);
      mMatrix[21] = v109 - (float)(v105 * mLatchHadamard);
      mMatrix[23] = v110 - (float)(mLatchHadamard * v106);
      mMatrix[19] = (float)(mLatchHadamard * v110) + v106;
      v128[v112] = v111;
      v137[this->mLateWritePointer[1]] = mMatrix[18];
      v138[this->mLateWritePointer[2]] = mMatrix[19];
      v139[this->mLateWritePointer[3]] = mMatrix[20];
      v140[this->mLateWritePointer[4]] = mMatrix[21];
      v141[this->mLateWritePointer[5]] = mMatrix[22];
      v142[this->mLateWritePointer[6]] = mMatrix[23];
      for ( v143[this->mLateWritePointer[7]] = mMatrix[16]; channels > v92; ++v92 )
      {
        v113 = v92;
        if ( v37 <= 0 )
        {
          v114 = 0.0;
          v115 = 0.0;
        }
        else
        {
          v114 = 0.0;
          v115 = 0.0;
          v116 = 0;
          do
          {
            v117 = v113;
            ++v116;
            v113 += channels;
            v118 = (char *)this + 4 * v117;
            v114 = v114 + eruOut[v117];
            v119 = *((_DWORD *)v118 + 246) & (*((_DWORD *)v118 + 278) - 1);
            *((_DWORD *)v118 + 278) = v119;
            v115 = v115 + this->mLateDelays[v117][v119];
          }
          while ( v116 != v37 );
        }
        v120 = (unsigned int)(v39 + v92);
        if ( drymix == 0.0 )
          outAudio[v120] = v115 + v114;
        else
          outAudio[v120] = (float)((float)(inAudio[v120] * drymix) + v114) + v115;
      }
      ++v122;
      v39 += channels;
    }
    while ( l_sampframes > (unsigned int)v122 );
    this->mEarlyLateWritePointer = drymixa;
    this->mEarlyWritePointer = mEarlyWritePointer;
  }
}


// Address: 0x2269540 | Name: _ZN7ASfxDsp26SetLate_EarlyLateDelayTapsEffff
void __fastcall ASfxDsp::SetLate_EarlyLateDelayTaps(
        ASfxDsp *const this,
        float a2,
        float refPlusRevDelaySec,
        float nextLengthSec,
        float delayRatio,
        float rate)
{
  int v6; // eax
  __int64 i; // rax
  float v8; // xmm4_4

  this->mEarlyLateSec[1] = a2;
  v6 = (int)(float)(a2 * delayRatio);
  if ( !v6 )
    v6 = 1;
  this->mEarlyLateSamples[1] = v6;
  for ( i = 0; i != 7; ++i )
  {
    v8 = a2 + refPlusRevDelaySec;
    refPlusRevDelaySec = refPlusRevDelaySec * nextLengthSec;
    this->mEarlyLateSec[i + 2] = v8;
    this->mEarlyLateSamples[i + 2] = (int)(float)(v8 * delayRatio);
  }
}


// Address: 0x22695a0 | Name: _ZN7ASfxDsp16SetAllpassDelaysEf
void __fastcall ASfxDsp::SetAllpassDelays(ASfxDsp *const this, float a2, float rate)
{
  int v3; // eax
  int v4; // eax

  this->mAllpassDelayLenSec[0] = 0.0059000002;
  this->mAllpassDelayLenSec[1] = 0.0077;
  v3 = (int)(float)(0.0059000002 * a2);
  this->mAllpassDelayLenSamples[0] = v3;
  this->mAllpassReadPointer[0] = v3 - 1;
  v4 = (int)(float)(0.0077 * a2);
  this->mAllpassDelayLenSamples[1] = v4;
  this->mAllpassReadPointer[1] = v4 - 1;
}


// Address: 0x22695f0 | Name: _ZN7ASfxDsp13SetEarlyDelayEfff
void __fastcall ASfxDsp::SetEarlyDelay(
        ASfxDsp *const this,
        float a2,
        float nextLengthSec,
        float delayRatio,
        float rate)
{
  int v5; // eax
  float v6; // xmm3_4
  float v7; // xmm3_4

  v5 = 7;
  do
  {
    v6 = a2;
    this->mEarlyDelayLenSec[0] = a2;
    this = (ASfxDsp *const)((char *)this + 4);
    a2 = a2 * nextLengthSec;
    v7 = v6 * delayRatio;
    LODWORD(this->mEarlyDelayLenSec[6]) = (int)v7;
    this->mEarlyWritePointer = (int)v7 - 1;
    --v5;
  }
  while ( v5 );
}


// Address: 0x2269630 | Name: _ZN7ASfxDsp13SetLateDelaysEfffff
void __fastcall ASfxDsp::SetLateDelays(
        ASfxDsp *const this,
        __m128 a2,
        float nextLengthSec,
        __m128 delayRatio,
        float nextLengthBSec,
        float delayRatioB,
        float rate)
{
  int v7; // edx
  __m128 v8; // xmm5
  int v9; // esi
  int v10; // ecx
  int v11; // eax

  delayRatio.m128_f32[0] = delayRatio.m128_f32[0] * delayRatioB;
  v7 = 0;
  do
  {
    v8 = a2;
    delayRatio = _mm_unpacklo_ps(delayRatio, delayRatio);
    v9 = this->mLateWritePointer[0];
    v10 = this->mLateMask[0];
    ++v7;
    v8.m128_f32[0] = a2.m128_f32[0] * delayRatioB;
    LODWORD(this->mLateDelayLenSec[0]) = a2.m128_i32[0];
    this = (ASfxDsp *const)((char *)this + 4);
    a2.m128_f32[0] = a2.m128_f32[0] * nextLengthSec;
    v11 = (int)(_mm_unpacklo_ps(v8, v8).m128_f32[0] + 0.5);
    *(double *)v8.m128_u64 = delayRatio.m128_f32[0];
    delayRatio.m128_f32[0] = delayRatio.m128_f32[0] * nextLengthBSec;
    *(double *)v8.m128_u64 = *(double *)v8.m128_u64 + 0.5;
    LODWORD(this->mLateDelayLenSec[7]) = v11;
    this->mLateWritePointer[7] = v10 & (v11 + v9 - 1);
    this->mOldLateDelayLenSamples[7] = (int)*(double *)v8.m128_u64;
    this->mOldLateReadPointer[7] = v10 & (v9 + (int)*(double *)v8.m128_u64 - 1);
  }
  while ( v7 != 8 );
}


// Address: 0x22696c0 | Name: _ZN7ASfxDsp17ZeroWritePointersEv
void __fastcall ASfxDsp::ZeroWritePointers(ASfxDsp *const this)
{
  __int64 v1; // rax

  this->mEarlyWritePointer = 0;
  this->mEarlyLateWritePointer = 0;
  v1 = 0;
  this->mAllpassWritePointer[0] = 0;
  this->mAllpassWritePointer[1] = 0;
  do
    this->mLateWritePointer[v1++] = 0;
  while ( v1 != 8 );
}


// Address: 0x2269710 | Name: _ZN7ASfxDsp4initEf
__int16 __fastcall ASfxDsp::init(ASfxDsp *const this, float a2, float rate)
{
  float v3; // xmm4_4
  __int64 i; // rax
  float v5; // xmm5_4
  __int64 j; // rax
  int LateDelays; // eax
  int v8; // edx
  ASfxDsp *v9; // rax

  this->mEarlyLateDelay = 0;
  this->mEarlyDelay = 0;
  ASfxDsp::ZeroWritePointers(this);
  this->mEarlyLateSec[0] = 0.039999999;
  this->mEarlyLateSamples[0] = (int)(float)(0.039999999 * a2);
  ASfxDsp::SetLate_EarlyLateDelayTaps(this, 0.059999999, 0.0187, 1.29, a2, v3);
  for ( i = 0; i != 36; i += 4 )
    *(int *)((char *)this->mOldEarlyLateSamples + i) = *(int *)((char *)this->mEarlyLateSamples + i);
  LOBYTE(i) = 0;
  do
  {
    *(int *)((char *)this->mLateMask + i) = 0;
    i += 4;
  }
  while ( i != 32 );
  ASfxDsp::SetEarlyDelay(this, 0.0049999999, 1.59, a2, a2);
  ASfxDsp::SetAllpassDelays(this, a2, 1.59);
  ASfxDsp::SetLateDelays(this, (__m128)0x3D79DB23u, 1.3200001, (__m128)0x3AC49BA6u, 1.47, a2, v5);
  for ( j = 0; j != 8; ++j )
  {
    this->mOldLateDelayLenSamples[j] = this->mLateDelayLenSamples[j];
    this->mLateChanged[j] = 0;
    this->mDecayHFChanged[j] = 0;
  }
  LateDelays = ASfxDsp::AllocateLateDelays(this, 8, this->mLateDelayLenSec, a2);
  if ( !LateDelays )
  {
    LOWORD(LateDelays) = ASfxDsp::AllocateEarlyLateDelay(this, this->mEarlyLateSec, a2, 1.3200001);
    if ( !LateDelays )
    {
      LateDelays = ASfxDsp::AllocateAllpassDelays(this, 2, this->mAllpassDelayLenSec, a2);
      if ( !LateDelays )
      {
        LOWORD(LateDelays) = ASfxDsp::AllocateEarlyDelay(this, this->mEarlyDelayLenSec[6], a2, 0.0015);
        if ( !LateDelays )
        {
          this->mNumAllocatedInBuffSamples = 0;
          this->mInBuffMemory = 0;
          this->mInBuff = 0;
          v8 = 0;
          this->mMatrix = (float *)(((unsigned __int64)&this->mMatrixMem[3] + 3) & 0xFFFFFFFFFFFFFFF0LL);
          this->mzDecayHF = (float *)(((unsigned __int64)&this->mzDecayHFMem[3] + 3) & 0xFFFFFFFFFFFFFFF0LL);
          v9 = this;
          do
          {
            ++v8;
            v9->mFeedback[0] = 0.31999999;
            v9->mLatchFeedback[0] = 0.31999999;
            v9->mPrevFeedback[0] = 0.31999999;
            v9->mOldFeedback[0] = 0.31999999;
            v9 = (ASfxDsp *)((char *)v9 + 4);
            v9->mzRoomLF1 = 0.40000001;
            v9->mPrevDecayHF[7] = 0.40000001;
            v9->mLatchOneMinusDecayHF[7] = 0.40000001;
            *(_DWORD *)&v9->mDecayHFChanged[4] = 1053609165;
            v9->mLatchDecayHF[7] = 0.60000002;
          }
          while ( v8 != 8 );
          *(_QWORD *)&this->mRoomLFcoeffs.a0 = 0;
          this->mHadamard = 1.0;
          this->mLatchHadamard = 1.0;
          this->mPrevHadamard = 1.0;
          this->mOldHadamard = 1.0;
          this->mLatchDiffusionScale = 1.0;
          this->mPrevDiffusionScale = 1.0;
          this->mOldDiffusionScale = 1.0;
          this->mRoomHF = 0.98000002;
          this->mLatchRoomHF = 0.98000002;
          this->mPrevRoomHF = 0.98000002;
          this->mOldRoomHF = 0.98000002;
          this->mRoomHFChanged = 0;
          *(_QWORD *)&this->mRoomLFcoeffs.a2 = 0;
          this->mRoomLFcoeffs.b2 = 0.0;
          this->mRoomLFcoeffs.a0 = 1.0;
          this->mRoomLF = 0.0;
          this->mDiffusionScale = 0.25;
          this->mAllpassGain = 0.63;
          this->mLRgain = 0.0;
          this->mLatchLRgain = 0.0;
          this->mOldLRgain = 0.0;
          this->mPrevLRgain = 0.0;
          this->mLRgainChanged = 0;
          this->mERgain = 0.0;
          this->mLatchERgain = 0.0;
          this->mOldERgain = 0.0;
          this->mPrevERgain = 0.0;
          this->mERgainChanged = 0;
          ASfxDsp::ClearReverbInternalBuffers(this);
          LOWORD(LateDelays) = 0;
        }
      }
    }
  }
  return LateDelays;
}


