// Address: 0x224d1c0 | Name: _ZN4FMOD13DSPOscillator16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPOscillator::getDescriptionEx()
{
  memset(&stru_2B05800, 0, sizeof(stru_2B05800));
  stru_2B05800.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2B05800.name, "Oscillator type", 16);
  FMOD_strcpy_safe(stru_2B05800.label, (const char *)&uri_string, 16);
  stru_2B05800.description = "Select a waveform type";
  *(_OWORD *)&stru_2B05800.floatdesc.min = 0x500000000uLL;
  stru_2B05800.intdesc.valuenames = off_286F860;
  memset(&stru_2B057A0, 0, sizeof(stru_2B057A0));
  FMOD_strcpy_safe(stru_2B057A0.name, "Frequency", 16);
  FMOD_strcpy_safe(stru_2B057A0.label, "hz", 16);
  *(_QWORD *)&stru_2B057A0.floatdesc.min = 0x46ABE0003F800000LL;
  stru_2B057A0.intdesc.defaultval = 1130102784;
  stru_2B057A0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B057A0.description = "Playback frequency of tone, for example music note A above middle C is 440.0.";
  *(&stru_2B05760.mHandle + 1) = 2;
  stru_2B05760.mSize = 568;
  stru_2B05760.mDescription = &stru_286F760;
  return &stru_2B05760;
}


// Address: 0x224d300 | Name: _ZN4FMOD13DSPOscillator14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPOscillator::createInternal(FMOD::DSPOscillator *const this)
{
  double v1; // xmm1_8
  __int64 v2; // rbp
  _DWORD *v3; // rdx
  int v4; // ebx
  unsigned int v5; // esi
  unsigned int v6; // ecx
  int v7; // eax
  int v8; // eax
  __int64 v9; // rdx
  _DWORD *v10; // rcx
  FMOD_RESULT_0 result; // eax

  v2 = 0;
  v3 = (_DWORD *)*((_QWORD *)this + 22);
  v4 = 0;
  *((_DWORD *)this + 133) = 1;
  v5 = v3[17853];
  v6 = *(_DWORD *)((char *)&stru_116E8.r_offset + (_QWORD)v3)
     ^ (*(_DWORD *)((char *)&stru_116E8.r_offset + (_QWORD)v3) << 11);
  *(_DWORD *)((char *)&stru_116E8.r_offset + (_QWORD)v3) = v3[17851];
  v7 = v3[17852];
  v3[17852] = v5;
  v3[17851] = v7;
  v8 = (v6 >> 8) ^ v6 ^ v5 ^ (v5 >> 19);
  v3[17853] = v8;
  *((_DWORD *)this + 135) = v8;
  *((_DWORD *)this + 136) = ~v8;
  *((_DWORD *)this + 138) = -1474208055 * ~v8;
  v9 = *((_QWORD *)this + 30);
  *((_DWORD *)this + 137) = 572572263 * v8;
  if ( *(int *)(v9 + 96) > 0 )
  {
    while ( 1 )
    {
      v10 = *(_DWORD **)(*(_QWORD *)(v9 + 104) + v2);
      if ( !*v10 )
        break;
      if ( *v10 == 1 )
      {
        result = FMOD::DSPI::setParameterInt((FMOD::DSPI *const)this, v4, v10[14]);
        if ( result )
          return result;
LABEL_7:
        v9 = *((_QWORD *)this + 30);
        ++v4;
        v2 += 8;
        if ( *(_DWORD *)(v9 + 96) <= v4 )
          return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        ++v4;
        v2 += 8;
        if ( *(_DWORD *)(v9 + 96) <= v4 )
          return FMOD_RESULT::FMOD_OK_0;
      }
    }
    result = FMOD::DSPI::setParameterFloat((FMOD::DSPI *const)this, v4, (__m128i)(unsigned int)v10[14], v1);
    if ( result )
      return result;
    goto LABEL_7;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224d410 | Name: _ZN4FMOD13DSPOscillator14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPOscillator::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPOscillator::createInternal((FMOD::DSPOscillator *const)dsp_state->instance);
}


// Address: 0x224d420 | Name: _ZN4FMOD13DSPOscillator15processInternalEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPOscillator::processInternal(
        FMOD::DSPOscillator *const this,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  float v8; // xmm2_4
  __int64 v9; // r13
  float *v10; // rbp
  int v11; // eax
  __int64 v12; // r13
  unsigned int v13; // edi
  unsigned int v14; // r9d
  unsigned int v15; // r8d
  unsigned int v16; // ecx
  int v17; // esi
  unsigned int v18; // eax
  __int64 v20; // r13
  int n; // eax
  int v22; // edx
  int v23; // edx
  float v24; // xmm0_4
  __int64 v25; // r14
  int i; // r13d
  float v27; // xmm0_4
  __int64 v28; // r13
  int k; // eax
  float v30; // xmm0_4
  __int64 v31; // r13
  int m; // eax
  float v33; // xmm0_4
  __int64 v34; // r13
  int j; // eax
  float v36; // xmm0_4
  int v37; // edx

  if ( op == FMOD_DSP_PROCESS_QUERY )
  {
    if ( outbufferarray )
      *outbufferarray->buffernumchannels = 1;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    v8 = *((float *)this + 141);
    v9 = *(unsigned int *)outbufferarray->buffernumchannels;
    v10 = *outbufferarray->buffers;
    v11 = *((_DWORD *)this + 139);
    if ( *((_DWORD *)this + 132) != v11 )
    {
      *((_DWORD *)this + 132) = v11;
      *((_DWORD *)this + 134) = 0;
    }
    if ( (unsigned int)v9 > 1 )
      memset(v10, 0, 4LL * (unsigned int)v9 * length);
    switch ( *((_DWORD *)this + 132) )
    {
      case 0:
        if ( length )
        {
          v25 = 4 * v9;
          for ( i = 0; i != length; ++i )
          {
            *v10 = sinf(*((float *)this + 134));
            v27 = (float)(v8 * 6.2831855) + *((float *)this + 134);
            if ( v27 >= 6.2831855 )
              v27 = v27 - 6.2831855;
            v10 = (float *)((char *)v10 + v25);
            *((float *)this + 134) = v27;
          }
        }
        break;
      case 1:
        if ( length )
        {
          v34 = 4 * v9;
          for ( j = 0; j != length; ++j )
          {
            v37 = *((_DWORD *)this + 133);
            *v10 = (float)v37;
            v36 = *((float *)this + 134) + v8;
            if ( v36 >= 1.0 )
            {
              v36 = v36 - 1.0;
              *((_DWORD *)this + 133) = -v37;
            }
            *((float *)this + 134) = v36;
            v10 = (float *)((char *)v10 + v34);
          }
        }
        break;
      case 2:
        if ( length )
        {
          v28 = 4 * v9;
          for ( k = 0; k != length; ++k )
          {
            *v10 = (float)(*((float *)this + 134) + *((float *)this + 134)) - 1.0;
            v30 = *((float *)this + 134) + v8;
            if ( v30 >= 1.0 )
              v30 = v30 - 1.0;
            v10 = (float *)((char *)v10 + v28);
            *((float *)this + 134) = v30;
          }
        }
        break;
      case 3:
        if ( length )
        {
          v31 = 4 * v9;
          for ( m = 0; m != length; ++m )
          {
            *v10 = (float)(*((float *)this + 134) * -2.0) + 1.0;
            v33 = *((float *)this + 134) + v8;
            if ( v33 >= 1.0 )
              v33 = v33 - 1.0;
            v10 = (float *)((char *)v10 + v31);
            *((float *)this + 134) = v33;
          }
        }
        break;
      case 4:
        if ( length )
        {
          v20 = 4 * v9;
          for ( n = 0; n != length; ++n )
          {
            v23 = *((_DWORD *)this + 133);
            *v10 = *((float *)this + 134);
            v24 = (float)((float)((float)v23 * v8) + (float)((float)v23 * v8)) + *((float *)this + 134);
            *((float *)this + 134) = v24;
            if ( v24 > 1.0 || v24 < -1.0 )
            {
              v22 = -v23;
              *((_DWORD *)this + 133) = v22;
              *((float *)this + 134) = (float)(v24 + (float)((float)v22 * v8)) + (float)((float)v22 * v8);
            }
            v10 = (float *)((char *)v10 + v20);
          }
        }
        break;
      case 5:
        if ( length )
        {
          v12 = 4 * v9;
          v13 = *((_DWORD *)this + 135);
          v14 = *((_DWORD *)this + 136);
          v15 = *((_DWORD *)this + 137);
          v16 = *((_DWORD *)this + 138);
          v17 = 0;
          while ( 1 )
          {
            ++v17;
            v18 = ((v13 ^ (v13 << 11)) >> 8) ^ v13 ^ (v13 << 11) ^ v16 ^ (v16 >> 19);
            *v10 = (float)((float)((float)(v18 & 0x7FFFFFFF) * 4.6566129e-10)
                         + (float)((float)(v18 & 0x7FFFFFFF) * 4.6566129e-10))
                 - 1.0;
            v10 = (float *)((char *)v10 + v12);
            if ( v17 == length )
              break;
            v13 = v14;
            v14 = v15;
            v15 = v16;
            v16 = v18;
          }
          *((_DWORD *)this + 135) = v14;
          *((_DWORD *)this + 136) = v15;
          *((_DWORD *)this + 137) = v16;
          *((_DWORD *)this + 138) = v18;
        }
        break;
      default:
        return FMOD_RESULT::FMOD_OK_0;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x224d7c0 | Name: _ZN4FMOD13DSPOscillator15processCallbackEP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS3_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPOscillator::processCallback(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  return FMOD::DSPOscillator::processInternal(
           (FMOD::DSPOscillator *const)dsp_state->instance,
           length,
           inbufferarray,
           outbufferarray,
           inputsidle,
           op);
}


// Address: 0x224d7d0 | Name: _ZN4FMOD13DSPOscillator23setParameterIntInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPOscillator::setParameterIntInternal(
        FMOD::DSPOscillator *const this,
        int index,
        int value)
{
  if ( !index )
    *((_DWORD *)this + 139) = value;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224d7e0 | Name: _ZN4FMOD13DSPOscillator23setParameterIntCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPOscillator::setParameterIntCallback(FMOD_DSP_STATE *dsp_state, int index, int value)
{
  return FMOD::DSPOscillator::setParameterIntInternal((FMOD::DSPOscillator *const)dsp_state->instance, index, value);
}


// Address: 0x224d7f0 | Name: _ZN4FMOD13DSPOscillator23getParameterIntInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPOscillator::getParameterIntInternal(
        FMOD::DSPOscillator *const this,
        int index,
        int *value,
        char *valuestr)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // eax

  v4 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index )
    return v4;
  v6 = 6;
  if ( *((int *)this + 139) <= 6 )
    v6 = *((_DWORD *)this + 139);
  if ( v6 >= 0 )
    index = v6;
  v4 = FMOD_RESULT::FMOD_OK_0;
  *value = index;
  if ( !valuestr )
    return v4;
  FMOD_strcpy_safe(valuestr, off_286F860[*((int *)this + 132)], 32);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224d850 | Name: _ZN4FMOD13DSPOscillator23getParameterIntCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPOscillator::getParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int *value,
        char *valuestr)
{
  return FMOD::DSPOscillator::getParameterIntInternal(
           (FMOD::DSPOscillator *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x224d860 | Name: _ZN4FMOD13DSPOscillator25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPOscillator::setParameterFloatInternal(
        FMOD::DSPOscillator *const this,
        int index,
        float a3,
        float value)
{
  if ( index == 1 )
    *((float *)this + 140) = a3;
  else
    a3 = *((float *)this + 140);
  *((float *)this + 141) = a3 / (float)*(int *)(*((_QWORD *)this + 22) + 1696LL);
  return 0;
}


// Address: 0x224d8a0 | Name: _ZN4FMOD13DSPOscillator25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPOscillator::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPOscillator::setParameterFloatInternal(
           (FMOD::DSPOscillator *const)dsp_state->instance,
           index,
           a3,
           value);
}


// Address: 0x224d8b0 | Name: _ZN4FMOD13DSPOscillator25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPOscillator::getParameterFloatInternal(
        FMOD::DSPOscillator *const this,
        int index,
        float *value,
        char *valuestr)
{
  if ( index != 1 )
    return FMOD_RESULT::FMOD_OK_0;
  *value = *((float *)this + 140);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  sprintf(valuestr, "%.02f", *((float *)this + 140));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224d900 | Name: _ZN4FMOD13DSPOscillator25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPOscillator::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPOscillator::getParameterFloatInternal(
           (FMOD::DSPOscillator *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


