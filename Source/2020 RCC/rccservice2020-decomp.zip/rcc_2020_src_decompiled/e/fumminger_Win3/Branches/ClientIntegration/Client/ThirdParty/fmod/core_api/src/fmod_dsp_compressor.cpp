// Address: 0x2238ad0 | Name: _ZN4FMOD13DSPCompressor16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPCompressor::getDescriptionEx()
{
  memset(&stru_2B04C20, 0, sizeof(stru_2B04C20));
  FMOD_strcpy_safe(stru_2B04C20.name, "Threshold", 16);
  FMOD_strcpy_safe(stru_2B04C20.label, "dB", 16);
  stru_2B04C20.description = "Compressor threshold [-60dB, 0dB]  Default = 0dB.";
  memset(&stru_2B04BC0, 0, sizeof(stru_2B04BC0));
  *(_QWORD *)&stru_2B04C20.floatdesc.min = 3262119936LL;
  stru_2B04C20.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B04C20.intdesc.defaultval = 0;
  FMOD_strcpy_safe(stru_2B04BC0.name, "Ratio", 16);
  FMOD_strcpy_safe(stru_2B04BC0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2B04BC0.floatdesc.min = 0x424800003F800000LL;
  stru_2B04BC0.description = "Compressor ratio. [1,50]  Default = 2.5.";
  memset(&stru_2B04B60, 0, sizeof(stru_2B04B60));
  stru_2B04BC0.intdesc.defaultval = 1075838976;
  stru_2B04BC0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B04B60.name, "Attack", 16);
  FMOD_strcpy_safe(stru_2B04B60.label, "ms", 16);
  *(_QWORD *)&stru_2B04B60.floatdesc.min = 0x43FA00003DCCCCCDLL;
  stru_2B04B60.description = "Compressor attack time. [0.1ms,500ms]  Default = 20ms.";
  memset(&stru_2B04B00, 0, sizeof(stru_2B04B00));
  stru_2B04B60.intdesc.defaultval = 1101004800;
  stru_2B04B60.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B04B00.name, "Release", 16);
  FMOD_strcpy_safe(stru_2B04B00.label, "ms", 16);
  *(_QWORD *)&stru_2B04B00.floatdesc.min = 0x459C400041200000LL;
  stru_2B04B00.description = "Compressor release time. [10ms,5000ms]  Default = 200ms.";
  memset(&stru_2B04AA0, 0, sizeof(stru_2B04AA0));
  stru_2B04B00.intdesc.defaultval = 1128792064;
  stru_2B04B00.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B04AA0.name, "Make up gain", 16);
  FMOD_strcpy_safe(stru_2B04AA0.label, "dB", 16);
  stru_2B04AA0.description = "Compressor make up gain [-30dB, 30dB]  Default = 0dB.";
  memset(&stru_2B04A40, 0, sizeof(stru_2B04A40));
  stru_2B04AA0.intdesc.defaultval = 0;
  *(_QWORD *)&stru_2B04AA0.floatdesc.min = 0x41F00000C1F00000LL;
  stru_2B04AA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B04A40.type = FMOD_DSP_PARAMETER_TYPE_DATA;
  FMOD_strcpy_safe(stru_2B04A40.name, "Use sidechain", 16);
  FMOD_strcpy_safe(stru_2B04A40.label, (const char *)&uri_string, 16);
  stru_2B04A40.intdesc.min = -3;
  stru_2B04A40.description = "Analyse the sidechain signal instead of the input signal.";
  memset(&stru_2B049E0, 0, sizeof(stru_2B049E0));
  stru_2B049E0.type = FMOD_DSP_PARAMETER_TYPE_BOOL;
  FMOD_strcpy_safe(stru_2B049E0.name, "Linked", 16);
  FMOD_strcpy_safe(stru_2B049E0.label, (const char *)&uri_string, 16);
  stru_2B049E0.intdesc.min = 1;
  stru_2B049E0.booldesc.valuenames = 0;
  *(&stru_2B049A0.mHandle + 1) = 18;
  stru_2B049A0.mSize = 880;
  stru_2B049E0.description = "input signal [TRUE = summed together, FALSE = use each channel separately].  Default = TRUE.";
  stru_2B049A0.mDescription = &stru_286F240;
  return &stru_2B049A0;
}


// Address: 0x2238e50 | Name: _ZN4FMOD13DSPCompressor13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::resetInternal(FMOD::DSPCompressor *const this)
{
  char *v2; // rdi
  unsigned int v3; // esi
  __int64 v4; // rcx
  char *v5; // rdi
  char *v6; // rdi
  unsigned int v7; // esi
  __int64 v8; // rcx
  char *v9; // rdi

  v2 = (char *)this + 548;
  v3 = 128;
  if ( ((unsigned __int8)v2 & 1) == 0 )
  {
    if ( ((unsigned __int8)v2 & 2) == 0 )
      goto LABEL_3;
LABEL_21:
    v2 += 2;
    v3 -= 2;
    *((_WORD *)v2 - 1) = 0;
    if ( ((unsigned __int8)v2 & 4) == 0 )
      goto LABEL_4;
    goto LABEL_22;
  }
  v2 = (char *)this + 549;
  *((_BYTE *)this + 548) = 0;
  LOBYTE(v3) = 127;
  if ( (((_BYTE)this + 37) & 2) != 0 )
    goto LABEL_21;
LABEL_3:
  if ( ((unsigned __int8)v2 & 4) == 0 )
    goto LABEL_4;
LABEL_22:
  *(_DWORD *)v2 = 0;
  v3 -= 4;
  v2 += 4;
LABEL_4:
  v4 = v3 >> 3;
  memset(v2, 0, 8 * v4);
  v5 = &v2[8 * v4];
  if ( (v3 & 4) != 0 )
  {
    *(_DWORD *)v5 = 0;
    v5 += 4;
  }
  if ( (v3 & 2) != 0 )
  {
    v5 += 2;
    *((_WORD *)v5 - 1) = 0;
  }
  if ( (v3 & 1) != 0 )
    *v5 = 0;
  v6 = (char *)this + 676;
  v7 = 128;
  if ( (((_BYTE)this - 92) & 1) == 0 )
  {
    if ( (((_BYTE)this - 92) & 2) == 0 )
      goto LABEL_12;
LABEL_24:
    v6 += 2;
    v7 -= 2;
    *((_WORD *)v6 - 1) = 0;
    if ( ((unsigned __int8)v6 & 4) == 0 )
      goto LABEL_13;
    goto LABEL_25;
  }
  v6 = (char *)this + 677;
  *((_BYTE *)this + 676) = 0;
  LOBYTE(v7) = 127;
  if ( (((_BYTE)this - 91) & 2) != 0 )
    goto LABEL_24;
LABEL_12:
  if ( ((unsigned __int8)v6 & 4) == 0 )
    goto LABEL_13;
LABEL_25:
  *(_DWORD *)v6 = 0;
  v7 -= 4;
  v6 += 4;
LABEL_13:
  v8 = v7 >> 3;
  memset(v6, 0, 8 * v8);
  v9 = &v6[8 * v8];
  if ( (v7 & 4) != 0 )
  {
    *(_DWORD *)v9 = 0;
    v9 += 4;
  }
  if ( (v7 & 2) != 0 )
  {
    v9 += 2;
    *((_WORD *)v9 - 1) = 0;
  }
  if ( (v7 & 1) != 0 )
    *v9 = 0;
  *((_QWORD *)this + 105) = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2238fd0 | Name: _ZN4FMOD13DSPCompressor14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::createInternal(FMOD::DSPCompressor *const this)
{
  double v1; // xmm1_8
  __int64 v2; // rbp
  __int64 v3; // rdx
  int i; // ebx
  _DWORD *v5; // rcx
  int v6; // esi

  v2 = 0;
  v3 = *((_QWORD *)this + 30);
  for ( i = 0; *(_DWORD *)(v3 + 96) > i; v2 += 8 )
  {
    while ( 1 )
    {
      v5 = *(_DWORD **)(*(_QWORD *)(v3 + 104) + v2);
      if ( *v5 )
        break;
      v6 = i++;
      v2 += 8;
      FMOD::DSPI::setParameterFloat((FMOD::DSPI *const)this, v6, (__m128i)(unsigned int)v5[14], v1);
      v3 = *((_QWORD *)this + 30);
      if ( *(_DWORD *)(v3 + 96) <= i )
        goto LABEL_8;
    }
    if ( *v5 == 2 )
    {
      FMOD::DSPI::setParameterBool((FMOD::DSPI *const)this, i, v5[12] != 0);
      v3 = *((_QWORD *)this + 30);
    }
    ++i;
  }
LABEL_8:
  FMOD::DSPCompressor::resetInternal(this);
  *((_BYTE *)this + 828) = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2239070 | Name: _ZN4FMOD13DSPCompressor14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPCompressor::createInternal((FMOD::DSPCompressor *const)dsp_state->instance);
}


// Address: 0x2239080 | Name: _ZN4FMOD13DSPCompressor13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPCompressor::resetInternal((FMOD::DSPCompressor *const)dsp_state->instance);
}


// Address: 0x2239090 | Name: _ZN4FMOD13DSPCompressor12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::readInternal(
        FMOD::DSPCompressor *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  __int64 v7; // r8
  float v9; // xmm1_4
  float v10; // xmm0_4
  float v11; // xmm0_4
  int v12; // eax
  bool v13; // zf
  float v14; // xmm0_4
  float v15; // xmm0_4
  __int64 v16; // rax
  float v17; // xmm1_4
  float v18; // xmm0_4
  unsigned __int64 v19; // rbp
  float *v20; // r12
  __int64 v21; // rcx
  float *v22; // rdi
  float *v23; // rsi
  float *v24; // rbx
  float v25; // xmm3_4
  float v26; // xmm0_4
  float v27; // xmm0_4
  float v28; // xmm0_4
  float v29; // xmm0_4
  float v30; // xmm1_4
  __int64 v31; // rax
  float v32; // xmm1_4
  float v33; // xmm0_4
  float v34; // xmm2_4
  float v35; // xmm1_4
  float v36; // xmm1_4
  bool v37; // cc
  float v38; // xmm0_4
  __int64 j; // rax
  int i; // r15d
  unsigned int v41; // esi
  FMOD_RESULT_0 result; // eax
  float *v43; // rax
  __int64 v44; // rax
  signed __int64 v45; // rdx
  char *v46; // rbp
  float v47; // xmm2_4
  float v48; // xmm0_4
  __int64 v49; // rax
  int v50; // eax
  unsigned __int64 v51; // rax
  float v52; // xmm4_4
  __int64 v53; // r12
  float *v54; // rbp
  float *v55; // rdx
  float *v56; // r12
  __int64 v57; // rax
  float v58; // xmm0_4
  float v59; // [rsp+10h] [rbp-78h]
  float v60; // [rsp+10h] [rbp-78h]
  float *analysisbuffer; // [rsp+28h] [rbp-60h]
  unsigned int base; // [rsp+38h] [rbp-50h]
  unsigned int sample; // [rsp+3Ch] [rbp-4Ch]
  unsigned __int64 idleEndClock[8]; // [rsp+48h] [rbp-40h] BYREF

  if ( !inbuffer )
    return FMOD_RESULT::FMOD_OK_0;
  v7 = *((unsigned int *)this + 212);
  analysisbuffer = inbuffer;
  if ( (_DWORD)v7 )
  {
    v43 = (float *)*((_QWORD *)this + 26);
    if ( !v43 )
      v43 = inbuffer;
    analysisbuffer = v43;
  }
  v9 = *((float *)this + 214);
  if ( v9 != *((float *)this + 132) || *((_BYTE *)this + 828) )
  {
    *((float *)this + 132) = v9;
    v10 = powf(10.0, v9 / 10.0);
    *((float *)this + 133) = v10;
    *((float *)this + 134) = 1.0 / v10;
  }
  v11 = *((float *)this + 215);
  if ( v11 != *((float *)this + 135) || *((_BYTE *)this + 828) )
  {
    v12 = *((_DWORD *)this + 218);
    *((float *)this + 135) = v11;
    v13 = *((_DWORD *)this + 208) == v12;
    *((float *)this + 136) = (float)((float)(1.0 / v11) - 1.0) * 0.5;
    if ( v13 )
      goto LABEL_47;
  }
  else
  {
    v12 = *((_DWORD *)this + 218);
    if ( *((_DWORD *)this + 208) == v12 )
    {
LABEL_47:
      if ( !*((_BYTE *)this + 828) )
        goto LABEL_9;
    }
  }
  *((_DWORD *)this + 208) = v12;
LABEL_9:
  v14 = *((float *)this + 213);
  if ( v14 != *((float *)this + 201) || *((_BYTE *)this + 828) )
  {
    v31 = *((_QWORD *)this + 22);
    *((float *)this + 201) = v14;
    *((float *)this + 202) = 1.0 - expf(-3.11127 / (float)((float)(v14 / 1000.0) * (float)*(int *)(v31 + 1696)));
  }
  v15 = *((float *)this + 216);
  if ( v15 != *((float *)this + 203) || *((_BYTE *)this + 828) )
  {
    v16 = *((_QWORD *)this + 22);
    *((float *)this + 203) = v15;
    *((float *)this + 204) = 1.0 - expf(-3.11127 / (float)((float)(v15 / 1000.0) * (float)*(int *)(v16 + 1696)));
  }
  v17 = *((float *)this + 217);
  if ( v17 != *((float *)this + 205) || *((_BYTE *)this + 828) )
  {
    *((float *)this + 205) = v17;
    if ( v17 > -80.0 )
      v18 = powf(10.0, v17 / 20.0);
    else
      v18 = 0.0;
    *((float *)this + 206) = v18;
  }
  v13 = *((_QWORD *)this + 105) == 0;
  *((_BYTE *)this + 828) = 0;
  if ( v13 )
  {
    if ( inchannels != 8 )
      goto LABEL_21;
    goto LABEL_60;
  }
  v44 = *((_QWORD *)this + 28);
  idleEndClock[0] = 0;
  result = (*(unsigned int (__fastcall **)(char *, unsigned __int64 *, _QWORD, _QWORD, __int64, int *))(v44 + 64))(
             (char *)this + 184,
             idleEndClock,
             0,
             0,
             v7,
             outchannels);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v45 = idleEndClock[0] - *((_QWORD *)this + 105);
    v46 = (char *)this + 676;
    if ( v45 < 0 )
    {
      v51 = v45 & 1 | ((idleEndClock[0] - *((_QWORD *)this + 105)) >> 1);
      v47 = (float)(int)v51 + (float)(int)v51;
    }
    else
    {
      v47 = (float)(int)v45;
    }
    v59 = *((float *)this + 204);
    v48 = powf(1.0 - v59, v47);
    if ( inchannels > 0 )
    {
      v49 = 0;
      do
      {
        *((float *)this + v49 + 137) = (float)(*((float *)this + v49 + 137) * v48)
                                     + (float)(*(float *)&v46[4 * v49] * (float)((float)(v59 * v47) * v48));
        *(float *)&v46[4 * v49] = *(float *)&v46[4 * v49] * v48;
        ++v49;
      }
      while ( inchannels > (int)v49 );
    }
    *((_QWORD *)this + 105) = 0;
    if ( inchannels != 8 )
    {
LABEL_21:
      if ( inchannels == 6 )
      {
        if ( *((_DWORD *)this + 208) )
        {
          FMOD_Optimised_Routines.FMOD_DSPCompressor_6channel(
            inbuffer,
            outbuffer,
            analysisbuffer,
            length,
            (float *)((char *)this + 676),
            (float *)((char *)this + 548),
            *((float *)this + 136),
            *((float *)this + 206),
            *((float *)this + 202),
            *((float *)this + 204),
            *((float *)this + 133),
            *((float *)this + 134));
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
      else
      {
        if ( inchannels == 2 )
        {
          if ( *((_DWORD *)this + 208) )
          {
            FMOD_Optimised_Routines.FMOD_DSPCompressor_2channel(
              inbuffer,
              outbuffer,
              analysisbuffer,
              length,
              (float *)((char *)this + 676),
              (float *)((char *)this + 548),
              *((float *)this + 136),
              *((float *)this + 206),
              *((float *)this + 202),
              *((float *)this + 204),
              *((float *)this + 133),
              *((float *)this + 134));
            return FMOD_RESULT::FMOD_OK_0;
          }
          goto LABEL_24;
        }
        v50 = *((_DWORD *)this + 208);
        if ( inchannels == 1 )
        {
          if ( v50 )
          {
            FMOD_Optimised_Routines.FMOD_DSPCompressor_1channel(
              inbuffer,
              outbuffer,
              analysisbuffer,
              length,
              (float *)((char *)this + 676),
              (float *)((char *)this + 548),
              *((float *)this + 136),
              *((float *)this + 206),
              *((float *)this + 202),
              *((float *)this + 204),
              *((float *)this + 133),
              *((float *)this + 134));
            return FMOD_RESULT::FMOD_OK_0;
          }
          goto LABEL_24;
        }
        if ( v50 )
        {
          if ( length )
          {
            v52 = 0.0;
            v41 = 0;
            for ( i = 0; i != length; ++i )
            {
              v53 = v41;
              v54 = &inbuffer[v53];
              v55 = &analysisbuffer[v53];
              v56 = &outbuffer[v53];
              if ( inchannels <= 0 )
              {
                v32 = v52;
                v33 = *((float *)this + 137);
                if ( v52 <= v33 )
                  goto LABEL_79;
              }
              else
              {
                v32 = v52;
                v57 = 0;
                do
                {
                  v58 = v55[v57++];
                  v32 = v32 + (float)(v58 * v58);
                }
                while ( inchannels > (int)v57 );
                v33 = *((float *)this + 137);
                if ( v32 <= v33 )
                {
LABEL_79:
                  v34 = *((float *)this + 204);
                  goto LABEL_37;
                }
              }
              v34 = *((float *)this + 202);
LABEL_37:
              v35 = (float)((float)(v32 - *((float *)this + 169)) * v34) + *((float *)this + 169);
              *((float *)this + 169) = v35;
              v36 = (float)((float)(v35 - v33) * v34) + v33;
              v37 = v36 <= *((float *)this + 133);
              *((float *)this + 137) = v36;
              if ( v37 )
              {
                v38 = *((float *)this + 206);
              }
              else
              {
                v60 = v52;
                v38 = powf(v36 * *((float *)this + 134), *((float *)this + 136)) * *((float *)this + 206);
                v52 = v60;
              }
              for ( j = 0; inchannels > (int)j; ++j )
                v56[j] = v54[j] * v38;
              v41 += inchannels;
            }
          }
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
LABEL_24:
      if ( length )
      {
        base = 0;
        sample = 0;
        do
        {
          v19 = 0;
          v20 = (float *)((char *)this + 548);
          v21 = base;
          v22 = &inbuffer[v21];
          v23 = &analysisbuffer[v21];
          v24 = &outbuffer[v21];
          if ( inchannels > 0 )
          {
            do
            {
              v29 = v23[v19 / 4] * v23[v19 / 4];
              v30 = *v20;
              if ( v29 > *v20 )
                v25 = *((float *)this + 202);
              else
                v25 = *((float *)this + 204);
              v26 = (float)((float)(v29 - v20[32]) * v25) + v20[32];
              v20[32] = v26;
              v27 = (float)((float)(v26 - v30) * v25) + v30;
              *v20 = v27;
              if ( v27 > *((float *)this + 133) )
                v28 = powf(v27 * *((float *)this + 134), *((float *)this + 136)) * *((float *)this + 206);
              else
                v28 = *((float *)this + 206);
              ++v20;
              v24[v19 / 4] = v28 * v22[v19 / 4];
              v19 += 4LL;
            }
            while ( v19 != 4LL * (unsigned int)(inchannels - 1) + 4 );
          }
          ++sample;
          base += inchannels;
        }
        while ( sample != length );
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
LABEL_60:
    if ( *((_DWORD *)this + 208) )
    {
      FMOD_Optimised_Routines.FMOD_DSPCompressor_8channel(
        inbuffer,
        outbuffer,
        analysisbuffer,
        length,
        (float *)((char *)this + 676),
        (float *)((char *)this + 548),
        *((float *)this + 136),
        *((float *)this + 206),
        *((float *)this + 202),
        *((float *)this + 204),
        *((float *)this + 133),
        *((float *)this + 134));
      return FMOD_RESULT::FMOD_OK_0;
    }
    goto LABEL_24;
  }
  return result;
}


// Address: 0x2239930 | Name: _ZN4FMOD13DSPCompressor12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPCompressor::readInternal(
           (FMOD::DSPCompressor *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x2239940 | Name: _ZN4FMOD13DSPCompressor22shouldIProcessInternalEiji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::shouldIProcessInternal(
        FMOD::DSPCompressor *const this,
        FMOD_BOOL inputsidle,
        unsigned int length,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  FMOD_RESULT_0 v5; // ebx
  FMOD_RESULT_0 v7; // eax

  v5 = FMOD_RESULT::FMOD_OK_0;
  if ( !inputsidle )
    return v5;
  LOBYTE(v5) = 6;
  if ( *((_QWORD *)this + 105) )
    return v5;
  v7 = (*(unsigned int (__fastcall **)(char *, char *, _QWORD, _QWORD, FMOD_SPEAKERMODE_0))(*((_QWORD *)this + 28) + 64LL))(
         (char *)this + 184,
         (char *)this + 840,
         0,
         0,
         speakermode);
  if ( v7 )
    return v7;
  return v5;
}


// Address: 0x2239990 | Name: _ZN4FMOD13DSPCompressor22shouldIProcessCallbackEP14FMOD_DSP_STATEijji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::shouldIProcessCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD_BOOL inputsidle,
        unsigned int length,
        FMOD_CHANNELMASK a4,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  return FMOD::DSPCompressor::shouldIProcessInternal(
           (FMOD::DSPCompressor *const)dsp_state->instance,
           inputsidle,
           length,
           inchannels,
           speakermode);
}


// Address: 0x22399a0 | Name: _ZN4FMOD13DSPCompressor25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPCompressor::setParameterFloatInternal(
        FMOD::DSPCompressor *const this,
        int index,
        float a3,
        float value)
{
  __int64 result; // rax

  switch ( index )
  {
    case 0:
      *((float *)this + 214) = a3;
      result = 0;
      break;
    case 1:
      *((float *)this + 215) = a3;
      result = 0;
      break;
    case 2:
      *((float *)this + 213) = a3;
      result = 0;
      break;
    case 3:
      *((float *)this + 216) = a3;
      result = 0;
      break;
    case 4:
      *((float *)this + 217) = a3;
      result = 0;
      break;
    default:
      result = 31;
      break;
  }
  return result;
}


// Address: 0x2239a20 | Name: _ZN4FMOD13DSPCompressor25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPCompressor::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPCompressor::setParameterFloatInternal(
           (FMOD::DSPCompressor *const)dsp_state->instance,
           index,
           a3,
           value);
}


// Address: 0x2239a30 | Name: _ZN4FMOD13DSPCompressor25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::getParameterFloatInternal(
        FMOD::DSPCompressor *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v4; // xmm0_4

  switch ( index )
  {
    case 0:
      *value = *((float *)this + 214);
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
      v4 = *((float *)this + 214);
      break;
    case 1:
      *value = *((float *)this + 215);
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
      v4 = *((float *)this + 215);
      break;
    case 2:
      *value = *((float *)this + 213);
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
      v4 = *((float *)this + 213);
      break;
    case 3:
      *value = *((float *)this + 216);
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
      v4 = *((float *)this + 216);
      break;
    case 4:
      *value = *((float *)this + 217);
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
      v4 = *((float *)this + 217);
      break;
    default:
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  sprintf(valuestr, "%.02f", v4);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2239b20 | Name: _ZN4FMOD13DSPCompressor25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPCompressor::getParameterFloatInternal(
           (FMOD::DSPCompressor *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x2239b30 | Name: _ZN4FMOD13DSPCompressor24setParameterBoolInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::setParameterBoolInternal(
        FMOD::DSPCompressor *const this,
        int index,
        FMOD_BOOL value)
{
  if ( index != 6 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *((_DWORD *)this + 218) = value;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2239b50 | Name: _ZN4FMOD13DSPCompressor24setParameterBoolCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::setParameterBoolCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        FMOD_BOOL value)
{
  return FMOD::DSPCompressor::setParameterBoolInternal((FMOD::DSPCompressor *const)dsp_state->instance, index, value);
}


// Address: 0x2239b60 | Name: _ZN4FMOD13DSPCompressor24getParameterBoolInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::getParameterBoolInternal(
        FMOD::DSPCompressor *const this,
        int index,
        FMOD_BOOL *value,
        char *valuestr)
{
  const char *v5; // rsi

  if ( index != 6 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *value = *((_DWORD *)this + 218);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  v5 = "TRUE";
  if ( !*((_DWORD *)this + 218) )
    v5 = "FALSE";
  strcpy(valuestr, v5);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2239bc0 | Name: _ZN4FMOD13DSPCompressor24getParameterBoolCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::getParameterBoolCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        FMOD_BOOL *value,
        char *valuestr)
{
  return FMOD::DSPCompressor::getParameterBoolInternal(
           (FMOD::DSPCompressor *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x2239bd0 | Name: _ZN4FMOD13DSPCompressor24setParameterDataInternalEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::setParameterDataInternal(
        FMOD::DSPCompressor *const this,
        int index,
        void *data,
        unsigned int length)
{
  if ( index != 5 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *((_DWORD *)this + 212) = *(_DWORD *)data;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2239bf0 | Name: _ZN4FMOD13DSPCompressor24setParameterDataCallbackEP14FMOD_DSP_STATEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::setParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void *data,
        unsigned int length)
{
  return FMOD::DSPCompressor::setParameterDataInternal(
           (FMOD::DSPCompressor *const)dsp_state->instance,
           index,
           data,
           length);
}


// Address: 0x2239c00 | Name: _ZN4FMOD13DSPCompressor24getParameterDataInternalEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::getParameterDataInternal(
        FMOD::DSPCompressor *const this,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  const char *v5; // rsi

  if ( index != 5 )
    return FMOD_RESULT::FMOD_OK_0;
  *data = (char *)this + 848;
  *length = 4;
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  v5 = "true";
  if ( !*((_DWORD *)this + 212) )
    v5 = "false";
  strcpy(valuestr, v5);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2239c60 | Name: _ZN4FMOD13DSPCompressor24getParameterDataCallbackEP14FMOD_DSP_STATEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPCompressor::getParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  return FMOD::DSPCompressor::getParameterDataInternal(
           (FMOD::DSPCompressor *const)dsp_state->instance,
           index,
           data,
           length,
           valuestr);
}


