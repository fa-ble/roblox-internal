// Address: 0x2254b90 | Name: MultibandEQ_Process_12dB_NoOpt
void __fastcall MultibandEQ_Process_12dB_NoOpt(
        const float *inBuffer,
        float *outBuffer,
        unsigned int length,
        const float *coefficient,
        const float *coefficientDelta,
        float *state,
        int stride)
{
  float v7; // xmm10_4
  float v8; // xmm11_4
  float v9; // xmm12_4
  float v10; // xmm13_4
  float v11; // xmm14_4
  float v12; // xmm15_4
  float v13; // xmm0_4
  float v14; // xmm2_4
  float v15; // xmm5_4
  float v16; // xmm9_4
  float v17; // xmm8_4
  float v18; // xmm7_4
  float v19; // xmm6_4
  __int64 v20; // rax
  float v21; // xmm1_4
  float v22; // xmm3_4
  float v23; // xmm4_4
  float v24; // xmm1_4
  float v25; // xmm0_4
  float v26; // xmm2_4
  float v27; // xmm2_4
  float v28; // xmm3_4
  float b0; // [rsp+0h] [rbp-10h]
  float b1; // [rsp+4h] [rbp-Ch]
  float b2; // [rsp+8h] [rbp-8h]
  float a1; // [rsp+Ch] [rbp-4h]

  b0 = *coefficient;
  b1 = coefficient[1];
  b2 = coefficient[2];
  a1 = coefficient[3];
  v7 = coefficient[4];
  v8 = *coefficientDelta;
  v9 = coefficientDelta[1];
  v10 = coefficientDelta[2];
  v11 = coefficientDelta[3];
  v12 = coefficientDelta[4];
  v13 = *state;
  v14 = state[1];
  if ( length )
  {
    v15 = 0.0;
    v16 = 0.0;
    v17 = 0.0;
    v18 = 0.0;
    v19 = 0.0;
    v20 = 4LL * stride;
    do
    {
      v21 = b0 + v19;
      v22 = *inBuffer;
      inBuffer = (const float *)((char *)inBuffer + v20);
      v23 = a1 + v16;
      v19 = v19 + v8;
      v16 = v16 + v11;
      v24 = (float)(v21 * v22) + v13;
      v25 = b1 + v18;
      v18 = v18 + v9;
      *outBuffer = v24;
      outBuffer = (float *)((char *)outBuffer + v20);
      --length;
      v13 = (float)((float)(v25 * v22) - (float)(v23 * v24)) + v14;
      v26 = b2 + v17;
      v17 = v17 + v10;
      v27 = v26 * v22;
      v28 = v7 + v15;
      v15 = v15 + v12;
      v14 = v27 - (float)(v28 * v24);
    }
    while ( length );
  }
  *state = v13;
  state[1] = v14;
}


// Address: 0x2254cb0 | Name: MultibandEQ_Process_24dB_NoOpt
void __fastcall MultibandEQ_Process_24dB_NoOpt(
        const float *inBuffer,
        float *outBuffer,
        unsigned int length,
        const float *coefficient,
        const float *coefficientDelta,
        float *state,
        int stride)
{
  float v7; // xmm2_4
  float v8; // xmm4_4
  float v9; // xmm1_4
  float v10; // xmm3_4
  float v11; // xmm6_4
  float v12; // xmm10_4
  float v13; // xmm9_4
  float v14; // xmm8_4
  float v15; // xmm7_4
  __int64 v16; // rax
  float v17; // xmm15_4
  float v18; // xmm5_4
  float v19; // xmm14_4
  float v20; // xmm13_4
  float v21; // xmm12_4
  float v22; // xmm0_4
  float v23; // xmm15_4
  float v24; // xmm11_4
  float b0; // [rsp+0h] [rbp-28h]
  float b1; // [rsp+4h] [rbp-24h]
  float b2; // [rsp+8h] [rbp-20h]
  float a1; // [rsp+Ch] [rbp-1Ch]
  float a2; // [rsp+10h] [rbp-18h]
  float b0D; // [rsp+14h] [rbp-14h]
  float b1D; // [rsp+18h] [rbp-10h]
  float b2D; // [rsp+1Ch] [rbp-Ch]
  float a1D; // [rsp+20h] [rbp-8h]
  float a2D; // [rsp+24h] [rbp-4h]

  b0 = *coefficient;
  b1 = coefficient[1];
  b2 = coefficient[2];
  a1 = coefficient[3];
  a2 = coefficient[4];
  b0D = *coefficientDelta;
  b1D = coefficientDelta[1];
  b2D = coefficientDelta[2];
  a1D = coefficientDelta[3];
  a2D = coefficientDelta[4];
  v7 = *state;
  v8 = state[1];
  v9 = state[2];
  v10 = state[3];
  if ( length )
  {
    v11 = 0.0;
    v12 = 0.0;
    v13 = 0.0;
    v14 = 0.0;
    v15 = 0.0;
    v16 = 4LL * stride;
    do
    {
      v17 = b0 + v15;
      v18 = *inBuffer;
      inBuffer = (const float *)((char *)inBuffer + v16);
      v19 = b1 + v14;
      v20 = a1 + v12;
      v21 = b2 + v13;
      v15 = v15 + b0D;
      v14 = v14 + b1D;
      v13 = v13 + b2D;
      v22 = (float)(v17 * v18) + v7;
      v12 = v12 + a1D;
      v23 = (float)(v17 * v22) + v9;
      v24 = a2 + v11;
      v11 = v11 + a2D;
      *outBuffer = v23;
      outBuffer = (float *)((char *)outBuffer + v16);
      v7 = (float)((float)(v19 * v18) - (float)(v20 * v22)) + v8;
      --length;
      v9 = (float)((float)(v19 * v22) - (float)(v20 * v23)) + v10;
      v8 = (float)(v18 * v21) - (float)(v24 * v22);
      v10 = (float)(v22 * v21) - (float)(v24 * v23);
    }
    while ( length );
  }
  *state = v7;
  state[1] = v8;
  state[2] = v9;
  state[3] = v10;
}


// Address: 0x2254e60 | Name: MultibandEQ_Process_48dB_NoOpt
void __fastcall MultibandEQ_Process_48dB_NoOpt(
        const float *inBuffer,
        float *outBuffer,
        unsigned int length,
        const float *coefficient,
        const float *coefficientDelta,
        float *state,
        int stride)
{
  float v7; // xmm11_4
  float v8; // xmm14_4
  float v9; // xmm13_4
  float v10; // xmm12_4
  float v11; // xmm3_4
  float v12; // xmm10_4
  float v13; // xmm2_4
  float v14; // xmm9_4
  __int64 v15; // rax
  float v16; // xmm1_4
  float v17; // xmm7_4
  float v18; // xmm0_4
  float v19; // xmm5_4
  float v20; // xmm1_4
  float v21; // xmm0_4
  float v22; // xmm8_4
  float b0R; // [rsp+0h] [rbp-3Ch]
  __int64 b1R; // [rsp+4h] [rbp-38h]
  __int64 a1R; // [rsp+Ch] [rbp-30h]
  float b0; // [rsp+14h] [rbp-28h]
  float b1; // [rsp+18h] [rbp-24h]
  float b2; // [rsp+1Ch] [rbp-20h]
  float a1; // [rsp+20h] [rbp-1Ch]
  float a2; // [rsp+24h] [rbp-18h]
  float b0D; // [rsp+28h] [rbp-14h]
  float b1D; // [rsp+2Ch] [rbp-10h]
  float b2D; // [rsp+30h] [rbp-Ch]
  float a1D; // [rsp+34h] [rbp-8h]
  float a2D; // [rsp+38h] [rbp-4h]

  b0 = *coefficient;
  b1 = coefficient[1];
  b2 = coefficient[2];
  a1 = coefficient[3];
  a2 = coefficient[4];
  b0D = *coefficientDelta;
  b1D = coefficientDelta[1];
  b2D = coefficientDelta[2];
  a1D = coefficientDelta[3];
  a2D = coefficientDelta[4];
  v7 = *state;
  v8 = state[1];
  v9 = state[2];
  v10 = state[3];
  v11 = state[4];
  v12 = state[5];
  v13 = state[6];
  v14 = state[7];
  if ( length )
  {
    a1R = 0;
    v15 = 4LL * stride;
    b1R = 0;
    b0R = 0.0;
    do
    {
      v16 = *inBuffer;
      inBuffer = (const float *)((char *)inBuffer + v15);
      v17 = b1 + *(float *)&b1R;
      v18 = (float)((float)(b0 + b0R) * v16) + v7;
      v7 = (float)((float)((float)(b1 + *(float *)&b1R) * v16) - (float)((float)(a1 + *(float *)&a1R) * v18)) + v8;
      v19 = b2 + *((float *)&b1R + 1);
      v8 = (float)(v16 * (float)(b2 + *((float *)&b1R + 1))) - (float)((float)(a2 + *((float *)&a1R + 1)) * v18);
      v20 = (float)((float)(b0 + b0R) * v18) + v9;
      v9 = (float)((float)(v18 * (float)(b1 + *(float *)&b1R)) - (float)((float)(a1 + *(float *)&a1R) * v20)) + v10;
      v10 = (float)(v18 * (float)(b2 + *((float *)&b1R + 1))) - (float)((float)(a2 + *((float *)&a1R + 1)) * v20);
      v21 = (float)((float)(b0 + b0R) * v20) + v11;
      v22 = (float)((float)(b0 + b0R) * v21) + v13;
      *outBuffer = v22;
      outBuffer = (float *)((char *)outBuffer + v15);
      v11 = (float)((float)((float)(b1 + *(float *)&b1R) * v20) - (float)((float)(a1 + *(float *)&a1R) * v21)) + v12;
      --length;
      *(float *)&b1R = *(float *)&b1R + b1D;
      v13 = (float)((float)(v17 * v21) - (float)((float)(a1 + *(float *)&a1R) * v22)) + v14;
      v12 = (float)(v20 * (float)(b2 + *((float *)&b1R + 1))) - (float)((float)(a2 + *((float *)&a1R + 1)) * v21);
      *((float *)&b1R + 1) = *((float *)&b1R + 1) + b2D;
      v14 = (float)(v19 * v21) - (float)((float)(a2 + *((float *)&a1R + 1)) * v22);
      *((float *)&a1R + 1) = *((float *)&a1R + 1) + a2D;
      b0R = b0R + b0D;
      *(float *)&a1R = *(float *)&a1R + a1D;
    }
    while ( length );
  }
  *state = v7;
  state[1] = v8;
  state[2] = v9;
  state[3] = v10;
  state[4] = v11;
  state[5] = v12;
  state[6] = v13;
  state[7] = v14;
}


// Address: 0x2255110 | Name: MultibandEQ_Release
FMOD_RESULT_0 __fastcall MultibandEQ_Release(FMOD_DSP_STATE *state)
{
  char *plugindata; // r12
  __int64 i; // rbx
  void *v4; // rdi

  plugindata = (char *)state->plugindata;
  if ( plugindata )
  {
    for ( i = 0; i != 440; i += 88 )
    {
      v4 = *(void **)&plugindata[i + 176];
      if ( v4 )
        state->functions->free(v4, 0, "../../../core_api/src/fmod_dsp_multiband_eq.cpp");
    }
    state->functions->free(state->plugindata, 0, "../../../core_api/src/fmod_dsp_multiband_eq.cpp");
    state->plugindata = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2255170 | Name: MultibandEQ_SetParameterFloat
__int64 __fastcall MultibandEQ_SetParameterFloat(FMOD_DSP_STATE *state, int index, float a3, float value)
{
  float *plugindata; // rax

  plugindata = (float *)state->plugindata;
  switch ( index )
  {
    case 1:
      plugindata[1] = a3;
      ++*((_DWORD *)plugindata + 4);
      return 0;
    case 2:
      plugindata[2] = a3;
      ++*((_DWORD *)plugindata + 4);
      return 0;
    case 3:
      plugindata[3] = a3;
      ++*((_DWORD *)plugindata + 4);
      return 0;
    default:
      switch ( index )
      {
        case 5:
          ++*((_DWORD *)plugindata + 9);
          plugindata[6] = a3;
          break;
        case 6:
          plugindata[7] = a3;
          ++*((_DWORD *)plugindata + 9);
          break;
        case 7:
          plugindata[8] = a3;
          ++*((_DWORD *)plugindata + 9);
          break;
        case 9:
          plugindata[11] = a3;
          ++*((_DWORD *)plugindata + 14);
          break;
        case 10:
          plugindata[12] = a3;
          ++*((_DWORD *)plugindata + 14);
          break;
        case 11:
          plugindata[13] = a3;
          ++*((_DWORD *)plugindata + 14);
          break;
        case 13:
          plugindata[16] = a3;
          ++*((_DWORD *)plugindata + 19);
          break;
        case 14:
          plugindata[17] = a3;
          ++*((_DWORD *)plugindata + 19);
          break;
        case 15:
          plugindata[18] = a3;
          ++*((_DWORD *)plugindata + 19);
          break;
        case 17:
          plugindata[21] = a3;
          ++*((_DWORD *)plugindata + 24);
          break;
        case 18:
          plugindata[22] = a3;
          ++*((_DWORD *)plugindata + 24);
          break;
        case 19:
          plugindata[23] = a3;
          ++*((_DWORD *)plugindata + 24);
          break;
      }
      return 0;
  }
}


// Address: 0x22552f0 | Name: MultibandEQ_SetParameterInt
FMOD_RESULT_0 __fastcall MultibandEQ_SetParameterInt(FMOD_DSP_STATE *state, int index, int value)
{
  _DWORD *plugindata; // rax

  plugindata = state->plugindata;
  if ( index )
  {
    switch ( index )
    {
      case 4:
        plugindata[5] = value;
        ++plugindata[9];
        return FMOD_RESULT::FMOD_OK_0;
      case 8:
        plugindata[10] = value;
        ++plugindata[14];
        return FMOD_RESULT::FMOD_OK_0;
      case 12:
        plugindata[15] = value;
        ++plugindata[19];
        return FMOD_RESULT::FMOD_OK_0;
      case 16:
        plugindata[20] = value;
        ++plugindata[24];
        return FMOD_RESULT::FMOD_OK_0;
      default:
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  else
  {
    *plugindata = value;
    ++plugindata[4];
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x2255370 | Name: MultibandEQ_GetParameterInt
FMOD_RESULT_0 __fastcall MultibandEQ_GetParameterInt(FMOD_DSP_STATE *state, int index, int *value, char *valueStr)
{
  int *plugindata; // rax

  plugindata = (int *)state->plugindata;
  if ( index )
  {
    switch ( index )
    {
      case 4:
        *value = plugindata[5];
        break;
      case 8:
        *value = plugindata[10];
        break;
      case 12:
        *value = plugindata[15];
        break;
      case 16:
        *value = plugindata[20];
        break;
    }
  }
  else
  {
    *value = *plugindata;
  }
  if ( valueStr )
    sprintf(valueStr, "%d", *value);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22553f0 | Name: MultibandEQ_GetParameterFloat
FMOD_RESULT_0 __fastcall MultibandEQ_GetParameterFloat(FMOD_DSP_STATE *state, int index, float *value, char *valueStr)
{
  float *plugindata; // rax

  plugindata = (float *)state->plugindata;
  switch ( index )
  {
    case 1:
      *value = plugindata[1];
      break;
    case 2:
      *value = plugindata[2];
      break;
    case 3:
      *value = plugindata[3];
      break;
    case 5:
      *value = plugindata[6];
      break;
    case 6:
      *value = plugindata[7];
      break;
    case 7:
      *value = plugindata[8];
      break;
    case 9:
      *value = plugindata[11];
      break;
    case 10:
      *value = plugindata[12];
      break;
    case 11:
      *value = plugindata[13];
      break;
    case 13:
      *value = plugindata[16];
      break;
    case 14:
      *value = plugindata[17];
      break;
    case 15:
      *value = plugindata[18];
      break;
    case 17:
      *value = plugindata[21];
      break;
    case 18:
      *value = plugindata[22];
      break;
    case 19:
      *value = plugindata[23];
      break;
  }
  if ( valueStr )
    sprintf(valueStr, "%.02f", *value);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22555a0 | Name: MultibandEQ_Reset
FMOD_RESULT_0 __fastcall MultibandEQ_Reset(FMOD_DSP_STATE *state)
{
  __int64 v1; // rbx
  _DWORD *plugindata; // rbp
  void *v3; // rdi

  v1 = 0;
  plugindata = state->plugindata;
  do
  {
    v3 = *(void **)&plugindata[v1 + 44];
    if ( v3 )
      memset(v3, 0, 32LL * plugindata[v1 + 43]);
    v1 += 22;
  }
  while ( v1 != 110 );
  plugindata[46] = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2255600 | Name: _Z33MultibandEQ_CalculateCoefficients33FMOD_DSP_MULTIBAND_EQ_FILTER_TYPEfiffPf
void __fastcall MultibandEQ_CalculateCoefficients(
        FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE filter,
        float frequency,
        int sampleRate,
        float overallQ,
        float gain,
        float *coefficients)
{
  float v6; // xmm5_4
  float v8; // xmm3_4
  float v9; // xmm4_4
  float v10; // xmm3_4
  float v11; // xmm4_4
  float v12; // xmm7_4
  float v13; // xmm2_4
  float v14; // xmm1_4
  float v15; // xmm0_4
  float v16; // xmm4_4
  float v17; // xmm3_4
  float v18; // xmm4_4
  float v19; // xmm5_4
  float v20; // xmm2_4
  float v21; // xmm0_4
  float v22; // xmm5_4
  float v23; // xmm7_4
  float v24; // xmm0_4
  float v25; // xmm3_4
  float v26; // xmm4_4
  float v27; // xmm1_4
  float v28; // xmm0_4
  float v29; // xmm6_4
  float v30; // xmm1_4
  float v31; // xmm5_4
  float v32; // xmm7_4
  float v33; // xmm1_4
  float v34; // xmm3_4
  float v35; // xmm4_4
  float v36; // xmm1_4
  float v37; // xmm0_4
  float v38; // xmm6_4
  float v39; // xmm1_4
  float v40; // xmm0_4
  float v41; // xmm4_4
  float v42; // xmm6_4
  float v43; // xmm5_4
  float v44; // xmm2_4
  float v45; // xmm4_4
  float v46; // xmm1_4
  float v47; // xmm6_4
  float v48; // xmm5_4
  float sin_omega; // [rsp+0h] [rbp-30h]
  float sin_omegaa; // [rsp+0h] [rbp-30h]
  float sin_omegab; // [rsp+0h] [rbp-30h]
  float Q; // [rsp+8h] [rbp-28h]
  float cosx; // [rsp+10h] [rbp-20h] BYREF
  float sinx[7]; // [rsp+14h] [rbp-1Ch] BYREF

  v6 = overallQ;
  v8 = frequency / (float)((float)sampleRate * 0.5);
  if ( v8 < 0.001 )
  {
    v10 = 0.99999505;
    v9 = 0.0031415878;
    goto LABEL_7;
  }
  if ( v8 > 0.99900001 )
  {
    v10 = -0.99999505;
    v9 = 0.003141549;
LABEL_7:
    if ( filter == FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_HIGHPASS_24DB )
      goto LABEL_4;
    goto LABEL_8;
  }
  sincosf(v8 * 3.1415927, sinx, &cosx);
  v9 = sinx[0];
  v10 = cosx;
  v6 = overallQ;
  if ( filter == FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_HIGHPASS_24DB )
  {
LABEL_4:
    v6 = fsqrt(v6);
    goto LABEL_5;
  }
LABEL_8:
  if ( filter == FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_LOWPASS_24DB )
    goto LABEL_4;
  if ( filter == FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_HIGHPASS_48DB
    || filter == FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_LOWPASS_48DB )
  {
    v6 = fsqrt(fsqrt(v6));
  }
LABEL_5:
  switch ( filter )
  {
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_LOWPASS_12DB:
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_LOWPASS_24DB:
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_LOWPASS_48DB:
      v20 = 1.0 - v10;
      v18 = v9 / (float)(v6 + v6);
      v19 = 1.0 / (float)(v18 + 1.0);
      v14 = (float)(0.5 * (float)(1.0 - v10)) * v19;
      goto LABEL_16;
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_HIGHPASS_12DB:
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_HIGHPASS_24DB:
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_HIGHPASS_48DB:
      v18 = v9 / (float)(v6 + v6);
      v19 = 1.0 / (float)(v18 + 1.0);
      v20 = -(float)(v10 + 1.0);
      v14 = (float)(0.5 * (float)(v10 + 1.0)) * v19;
LABEL_16:
      v21 = 1.0 - v18;
      v13 = v20 * v19;
      v16 = v14;
      v15 = v21 * v19;
      v17 = (float)(v10 * -2.0) * v19;
      break;
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_LOWSHELF:
      sin_omega = v9;
      v22 = powf(10.0, gain / 40.0);
      v23 = fsqrt(v22 + v22) * sin_omega;
      v24 = (float)(v22 - 1.0) * v10;
      v25 = v10 * (float)(v22 + 1.0);
      v26 = (float)(v22 + 1.0) - v24;
      v27 = v24 + (float)(v22 + 1.0);
      v28 = v27 - v23;
      v29 = 1.0 / (float)(v27 + v23);
      v30 = v26;
      v13 = (float)((float)((float)(v22 - 1.0) - v25) * (float)(v22 + v22)) * v29;
      v16 = (float)((float)(v26 - v23) * v22) * v29;
      v14 = (float)((float)(v30 + v23) * v22) * v29;
      v17 = (float)((float)(v25 + (float)(v22 - 1.0)) * -2.0) * v29;
      v15 = v28 * v29;
      break;
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_HIGHSHELF:
      sin_omegaa = v9;
      v31 = powf(10.0, gain / 40.0);
      v32 = fsqrt(v31 + v31) * sin_omegaa;
      v33 = (float)(v31 - 1.0) * v10;
      v34 = v10 * (float)(v31 + 1.0);
      v35 = (float)(v31 + 1.0) + v33;
      v36 = (float)(v31 + 1.0) - v33;
      v37 = v36 - v32;
      v38 = 1.0 / (float)(v36 + v32);
      v39 = v35;
      v13 = (float)((float)(-2.0 * v31) * (float)((float)(v31 - 1.0) + v34)) * v38;
      v16 = (float)((float)(v35 - v32) * v31) * v38;
      v14 = (float)((float)(v39 + v32) * v31) * v38;
      v17 = (float)((float)((float)(v31 - 1.0) - v34) + (float)((float)(v31 - 1.0) - v34)) * v38;
      v15 = v37 * v38;
      break;
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_PEAKING:
      Q = v6;
      sin_omegab = v9;
      v40 = powf(10.0, gain / 40.0);
      v41 = sin_omegab / (float)(Q + Q);
      v42 = v41 / v40;
      v43 = 1.0 / (float)((float)(v41 / v40) + 1.0);
      v13 = (float)(-2.0 * v10) * v43;
      v14 = (float)((float)(v41 * v40) + 1.0) * v43;
      v16 = (float)(1.0 - (float)(v41 * v40)) * v43;
      v15 = (float)(1.0 - v42) * v43;
      v17 = v13;
      break;
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_BANDPASS:
      v47 = v9 / (float)(v6 + v6);
      v48 = 1.0 / (float)(v47 + 1.0);
      v13 = 0.0 * v48;
      v14 = v47 * v48;
      v16 = (float)-v47 * v48;
      v17 = (float)(v10 * -2.0) * v48;
      v15 = (float)(1.0 - v47) * v48;
      break;
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_NOTCH:
      v11 = v9 / (float)(v6 + v6);
      v12 = 1.0 / (float)(v11 + 1.0);
      v13 = (float)(-2.0 * v10) * v12;
      v14 = v12;
      v15 = (float)(1.0 - v11) * v12;
      v16 = v12;
      v17 = v13;
      break;
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_ALLPASS:
      v44 = v9 / (float)(v6 + v6);
      v45 = v44 + 1.0;
      v46 = 1.0 - v44;
      v13 = (float)(-2.0 * v10) * (float)(1.0 / (float)(v44 + 1.0));
      v14 = v46 * (float)(1.0 / v45);
      v16 = v45 * (float)(1.0 / v45);
      v17 = v13;
      v15 = v14;
      break;
    default:
      v15 = 0.0;
      v14 = 1.0;
      v17 = 0.0;
      v16 = 0.0;
      v13 = 0.0;
      break;
  }
  coefficients[1] = v13;
  coefficients[2] = v16;
  coefficients[3] = v17;
  coefficients[4] = v15;
  *coefficients = v14;
}


// Address: 0x2255c60 | Name: MultibandEQ_Process
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall MultibandEQ_Process(
        FMOD_DSP_STATE *state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inBufferArray,
        FMOD_DSP_BUFFER_ARRAY *outBufferArray,
        FMOD_BOOL inputsIdle,
        FMOD_DSP_PROCESS_OPERATION operation)
{
  int v7; // ebx
  char *plugindata; // r13
  MultibandEQ_State::MixerState *mMixer; // r12
  float *mState; // rdi
  int mStateCount; // eax
  __int64 v12; // rax
  int mUpdateCount; // r15d
  int v14; // eax
  FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE v15; // eax
  FMOD_DSP_STATE_FUNCTIONS *functions; // rax
  __int64 v17; // rax
  float *mCoefTarget; // rbp
  FMOD_DSP_STATE_FUNCTIONS *v19; // rax
  float v20; // xmm1_4
  float *v21; // rax
  float v22; // xmm0_4
  float *v23; // r12
  float *mCoef; // r14
  unsigned __int64 v25; // r15
  float *v26; // rsi
  float *v27; // rdi
  __int64 v28; // r9
  int v29; // eax
  __int64 v30; // rdx
  __int64 v31; // rsi
  float v32; // eax
  char v33; // dl
  int v36; // [rsp+10h] [rbp-78h]
  __int64 v37; // [rsp+18h] [rbp-70h]
  MultibandEQ_State *eq; // [rsp+20h] [rbp-68h]
  float *source; // [rsp+30h] [rbp-58h]
  float *destination; // [rsp+38h] [rbp-50h]
  int sampleRate; // [rsp+48h] [rbp-40h] BYREF
  unsigned int v42[15]; // [rsp+4Ch] [rbp-3Ch] BYREF

  eq = (MultibandEQ_State *)state->plugindata;
  if ( operation != FMOD_DSP_PROCESS_QUERY )
  {
    v36 = 5;
    v7 = *inBufferArray->buffernumchannels;
    source = *inBufferArray->buffers;
    destination = *outBufferArray->buffers;
    plugindata = (char *)state->plugindata;
    mMixer = eq->mMixer;
    while ( 1 )
    {
      if ( v7 != mMixer->mStateCount )
      {
        mState = mMixer->mState;
        mMixer->mStateCount = v7;
        mStateCount = v7;
        if ( mState )
        {
          ((void (__fastcall *)(float *, _QWORD, const char *, FMOD_DSP_BUFFER_ARRAY *, _QWORD))state->functions->free)(
            mState,
            0,
            "../../../core_api/src/fmod_dsp_multiband_eq.cpp",
            outBufferArray,
            *(_QWORD *)&inputsIdle);
          mStateCount = mMixer->mStateCount;
        }
        v12 = ((__int64 (__fastcall *)(_QWORD, _QWORD, const char *, FMOD_DSP_BUFFER_ARRAY *, _QWORD))state->functions->alloc)(
                (unsigned int)(32 * mStateCount),
                0,
                "../../../core_api/src/fmod_dsp_multiband_eq.cpp",
                outBufferArray,
                *(_QWORD *)&inputsIdle);
        mMixer->mState = (float *)v12;
        if ( !v12 )
        {
          LODWORD(v17) = 38;
          return (int)v17;
        }
      }
      mUpdateCount = mMixer->mUpdateCount;
      v14 = *((_DWORD *)plugindata + 4);
      if ( mUpdateCount == v14 )
        goto LABEL_16;
      mMixer->mUpdateCount = v14;
      v15 = *(_DWORD *)plugindata;
      if ( *(_DWORD *)plugindata == 6
        || v15 == FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_LOWPASS_48DB )
      {
        mMixer->Process = MultibandEQ_Process_48dB_NoOpt;
      }
      else if ( v15 == FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_HIGHPASS_24DB
             || v15 == FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_LOWPASS_24DB )
      {
        mMixer->Process = MultibandEQ_Process_24dB_NoOpt;
      }
      else
      {
        mMixer->Process = MultibandEQ_Process_12dB_NoOpt;
      }
      functions = state->functions;
      sampleRate = 0;
      LODWORD(v17) = ((__int64 (__fastcall *)(FMOD_DSP_STATE *, int *, const FMOD_DSP_BUFFER_ARRAY *, FMOD_DSP_BUFFER_ARRAY *, _QWORD))functions->getsamplerate)(
                       state,
                       &sampleRate,
                       inBufferArray,
                       outBufferArray,
                       *(_QWORD *)&inputsIdle);
      if ( (_DWORD)v17 )
        return (int)v17;
      mCoefTarget = mMixer->mCoefTarget;
      MultibandEQ_CalculateCoefficients(
        *(FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE *)plugindata,
        *((float *)plugindata + 1),
        sampleRate,
        *((float *)plugindata + 2),
        *((float *)plugindata + 3),
        mMixer->mCoefTarget);
      if ( mUpdateCount )
      {
        v19 = state->functions;
        v42[0] = 0;
        LODWORD(v17) = v19->getblocksize(state, v42);
        if ( (_DWORD)v17 )
          return (int)v17;
        LODWORD(inBufferArray) = 5;
        v20 = (float)(int)v42[0];
        v21 = (float *)mMixer;
        do
        {
          v22 = v21[12];
          ++v21;
          v21[6] = (float)(v22 - v21[1]) / v20;
          inBufferArray = (const FMOD_DSP_BUFFER_ARRAY *)(unsigned int)((_DWORD)inBufferArray - 1);
        }
        while ( (_DWORD)inBufferArray );
LABEL_16:
        plugindata += 20;
        ++mMixer;
        if ( !--v36 )
          goto LABEL_17;
      }
      else
      {
        v31 = *(_QWORD *)mMixer->mCoefTarget;
        plugindata += 20;
        ++mMixer;
        *(_QWORD *)mMixer[-1].mCoef = v31;
        *(_QWORD *)&mMixer[-1].mCoef[2] = *((_QWORD *)mCoefTarget + 1);
        v32 = mCoefTarget[4];
        *(_QWORD *)mMixer[-1].mCoefDelta = 0;
        *(_QWORD *)&mMixer[-1].mCoefDelta[2] = 0;
        mMixer[-1].mCoefDelta[4] = 0.0;
        mMixer[-1].mCoef[4] = v32;
        if ( !--v36 )
        {
LABEL_17:
          v23 = source;
          v37 = 0;
          mCoef = eq->mMixer[0].mCoef;
          do
          {
            if ( eq->mMain[v37].mFilter )
            {
              v25 = 0;
              if ( v7 > 0 )
              {
                do
                {
                  v26 = &destination[v25 / 4];
                  v27 = &v23[v25 / 4];
                  v28 = *((_QWORD *)mCoef + 8) + 8 * v25;
                  v25 += 4LL;
                  (*((void (__fastcall **)(float *, float *, _QWORD, float *, float *, __int64, int))mCoef - 1))(
                    v27,
                    v26,
                    length,
                    mCoef,
                    mCoef + 5,
                    v28,
                    v7);
                }
                while ( v25 != 4LL * (unsigned int)(v7 - 1) + 4 );
              }
              v29 = *((_DWORD *)mCoef + 14);
              v23 = destination;
              *(_QWORD *)mCoef = *((_QWORD *)mCoef + 5);
              v30 = *((_QWORD *)mCoef + 6);
              *((_DWORD *)mCoef + 4) = v29;
              *((_QWORD *)mCoef + 1) = v30;
              *(_QWORD *)(mCoef + 5) = 0;
              *(_QWORD *)(mCoef + 7) = 0;
              mCoef[9] = 0.0;
            }
            ++v37;
            mCoef += 22;
          }
          while ( v37 != 5 );
          LODWORD(v17) = 0;
          return (int)v17;
        }
      }
    }
  }
  v17 = 0;
  v33 = 1;
  do
  {
    if ( *(FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE *)((char *)&eq->mMain[0].mFilter + v17) )
      v33 = 0;
    v17 += 20;
  }
  while ( v17 != 100 );
  if ( v33 || (LOBYTE(v17) = 0, inputsIdle) )
    LODWORD(v17) = 6;
  return (int)v17;
}


// Address: 0x2255fc0 | Name: _Z23MultibandEQ_UnwrapPhaseiPff
void __fastcall MultibandEQ_UnwrapPhase(int count, float *phase, float a3, float range)
{
  int v4; // edx
  __int64 v5; // rax
  float v6; // xmm5_4
  float v7; // xmm2_4
  float v8; // xmm4_4
  float v9; // xmm3_4

  if ( count - 1 <= 0 )
  {
    v9 = a3 * 0.0;
  }
  else
  {
    v4 = 0;
    v5 = 0;
    v6 = (float)0;
    do
    {
      v7 = phase[v5];
      v8 = phase[v5 + 1];
      v9 = v6 * a3;
      phase[v5] = (float)(v6 * a3) + v7;
      if ( fabs(v8 - v7) > (float)(0.5 * a3) )
      {
        v4 = v4 + 2 * (v7 > v8) - 1;
        v6 = (float)v4;
        v9 = a3 * (float)v4;
      }
      ++v5;
    }
    while ( count - 1 > (int)v5 );
  }
  phase[count - 1] = v9 + phase[count - 1];
}


// Address: 0x2256060 | Name: _Z29MultibandEQ_CalculateResponse33FMOD_DSP_MULTIBAND_EQ_FILTER_TYPEPKfiiS1_PfS2_
void __fastcall MultibandEQ_CalculateResponse(
        FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE filter,
        const float *coefficients,
        int sampleRate,
        int count,
        const float *frequency,
        float *magnitude,
        float *phase)
{
  float v7; // xmm1_4
  unsigned __int64 v11; // rbx
  __int64 v12; // r14
  float v13; // xmm5_4
  float v14; // xmm1_4
  float v15; // xmm4_4
  float v16; // xmm2_4
  float v17; // xmm4_4
  float v18; // xmm0_4
  float v19; // xmm3_4
  float v20; // xmm6_4
  float v21; // xmm0_4
  float v22; // xmm5_4
  float v23; // xmm2_4
  float v24; // xmm3_4
  float v25; // xmm0_4
  float v26; // xmm0_4
  float rolloffMultiply; // [rsp+4h] [rbp-74h]
  float b0; // [rsp+Ch] [rbp-6Ch]
  float b1; // [rsp+10h] [rbp-68h]
  float b2; // [rsp+14h] [rbp-64h]
  float a1; // [rsp+18h] [rbp-60h]
  float a2; // [rsp+1Ch] [rbp-5Ch]
  float nyquist; // [rsp+20h] [rbp-58h]
  float unwrapRange; // [rsp+2Ch] [rbp-4Ch]
  float cosx; // [rsp+38h] [rbp-40h] BYREF
  float sinx[15]; // [rsp+3Ch] [rbp-3Ch] BYREF

  b0 = *coefficients;
  b1 = coefficients[1];
  b2 = coefficients[2];
  a1 = coefficients[3];
  a2 = coefficients[4];
  switch ( filter )
  {
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_HIGHPASS_24DB:
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_LOWPASS_24DB:
      unwrapRange = 720.0;
      rolloffMultiply = 2.0;
      break;
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_HIGHPASS_48DB:
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_LOWPASS_48DB:
      unwrapRange = 1440.0;
      rolloffMultiply = 4.0;
      break;
    case FMOD_DSP_MULTIBAND_EQ_FILTER_TYPE::FMOD_DSP_MULTIBAND_EQ_FILTER_NOTCH:
      unwrapRange = 0.0;
      break;
    default:
      unwrapRange = 360.0;
      rolloffMultiply = 1.0;
      break;
  }
  nyquist = (float)sampleRate * 0.5;
  if ( count > 0 )
  {
    v11 = 0;
    v12 = 4LL * (unsigned int)(count - 1) + 4;
    do
    {
      v26 = frequency[v11 / 4] / nyquist;
      if ( v26 >= 0.000099999997 )
      {
        if ( v26 > 0.99989998 )
        {
          v14 = -0.00031414826;
          v13 = -0.99999994;
        }
        else
        {
          sincosf(v26 * -3.1415927, sinx, &cosx);
          v13 = cosx;
          v14 = sinx[0];
        }
      }
      else
      {
        v14 = -0.00031415926;
        v13 = 0.99999994;
      }
      v15 = (float)(b2 * v13) + b1;
      v16 = (float)(v15 * v14) + (float)((float)(b2 * v14) * v13);
      v17 = (float)((float)(v15 * v13) - (float)((float)(b2 * v14) * v14)) + b0;
      v18 = (float)(a2 * v13) + a1;
      v19 = (float)(v18 * v14) + (float)((float)(a2 * v14) * v13);
      v20 = v16 * v19;
      v21 = (float)((float)(v18 * v13) - (float)(v14 * (float)(a2 * v14))) + 1.0;
      v22 = (float)(v21 * v21) + (float)(v19 * v19);
      v23 = (float)((float)(v16 * v21) - (float)(v19 * v17)) / v22;
      v7 = (float)((float)(v17 * v21) + v20) / v22;
      v24 = fsqrt((float)(v7 * v7) + (float)(v23 * v23));
      if ( v24 > 0.0 )
        v25 = log10f(v24) * 20.0;
      else
        v25 = -80.0;
      magnitude[v11 / 4] = v25 * rolloffMultiply;
      phase[v11 / 4] = (float)((float)(atan2f(v23, v7) * 180.0) / 3.1415927) * rolloffMultiply;
      v11 += 4LL;
    }
    while ( v11 != v12 );
  }
  if ( unwrapRange != 0.0 )
    MultibandEQ_UnwrapPhase(count, phase, unwrapRange, v7);
}


// Address: 0x2256430 | Name: FMOD_MultibandEQ_GetDescription
FMOD_DSP_DESCRIPTION_0 *__cdecl FMOD_MultibandEQ_GetDescription()
{
  if ( !(_BYTE)byte_2B05F40 && __cxa_guard_acquire(&byte_2B05F40) )
  {
    stru_28703E0.description = "Type of filter, affects how all other parameters are interpreted";
    __cxa_guard_release(&byte_2B05F40);
  }
  *(_QWORD *)(&stru_28703E0.datadesc + 1) = 0x10000000CLL;
  stru_28703E0.intdesc.valuenames = off_2870360;
  if ( !(_BYTE)byte_2B05F38 && __cxa_guard_acquire(&byte_2B05F38) )
  {
    stru_2870300.description = "Significant frequency for the filter type";
    __cxa_guard_release(&byte_2B05F38);
  }
  *(_QWORD *)&stru_2870300.floatdesc.min = 0x46ABE00041A00000LL;
  stru_2870300.intdesc.defaultval = 1174011904;
  stru_2870300.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05F30 && __cxa_guard_acquire(&byte_2B05F30) )
  {
    stru_28702A0.description = "Quality factor";
    __cxa_guard_release(&byte_2B05F30);
  }
  *(_QWORD *)&stru_28702A0.floatdesc.min = 0x412000003DCCCCCDLL;
  stru_28702A0.intdesc.defaultval = 1060437492;
  stru_28702A0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05F28 && __cxa_guard_acquire(&byte_2B05F28) )
  {
    stru_2870240.description = "Boost or attenuation [high/low shelf and peaking only]";
    __cxa_guard_release(&byte_2B05F28);
  }
  *(_QWORD *)&stru_2870240.floatdesc.min = 0x41F00000C1F00000LL;
  stru_2870240.intdesc.defaultval = 0;
  stru_2870240.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05F20 && __cxa_guard_acquire(&byte_2B05F20) )
  {
    stru_28701E0.description = "Type of filter, affects how all other parameters are interpreted";
    __cxa_guard_release(&byte_2B05F20);
  }
  *(_QWORD *)(&stru_28701E0.datadesc + 1) = 12;
  stru_28701E0.intdesc.valuenames = off_2870360;
  if ( !(_BYTE)byte_2B05F18 && __cxa_guard_acquire(&byte_2B05F18) )
  {
    stru_2870180.description = "Significant frequency for the filter type";
    __cxa_guard_release(&byte_2B05F18);
  }
  *(_QWORD *)&stru_2870180.floatdesc.min = 0x46ABE00041A00000LL;
  stru_2870180.intdesc.defaultval = 1174011904;
  stru_2870180.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05F10 && __cxa_guard_acquire(&byte_2B05F10) )
  {
    stru_2870120.description = "Quality factor";
    __cxa_guard_release(&byte_2B05F10);
  }
  *(_QWORD *)&stru_2870120.floatdesc.min = 0x412000003DCCCCCDLL;
  stru_2870120.intdesc.defaultval = 1060437492;
  stru_2870120.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05F08 && __cxa_guard_acquire(&byte_2B05F08) )
  {
    stru_28700C0.description = "Boost or attenuation [high/low shelf and peaking only]";
    __cxa_guard_release(&byte_2B05F08);
  }
  *(_QWORD *)&stru_28700C0.floatdesc.min = 0x41F00000C1F00000LL;
  stru_28700C0.intdesc.defaultval = 0;
  stru_28700C0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05F00 && __cxa_guard_acquire(&byte_2B05F00) )
  {
    stru_2870060.description = "Type of filter, affects how all other parameters are interpreted";
    __cxa_guard_release(&byte_2B05F00);
  }
  *(_QWORD *)(&stru_2870060.datadesc + 1) = 12;
  stru_2870060.intdesc.valuenames = off_2870360;
  if ( !(_BYTE)byte_2B05EF8 && __cxa_guard_acquire(&byte_2B05EF8) )
  {
    stru_2870000.description = "Significant frequency for the filter type";
    __cxa_guard_release(&byte_2B05EF8);
  }
  *(_QWORD *)&stru_2870000.floatdesc.min = 0x46ABE00041A00000LL;
  stru_2870000.intdesc.defaultval = 1174011904;
  stru_2870000.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05EF0 && __cxa_guard_acquire(&byte_2B05EF0) )
  {
    stru_286FFA0.description = "Quality factor";
    __cxa_guard_release(&byte_2B05EF0);
  }
  *(_QWORD *)&stru_286FFA0.floatdesc.min = 0x412000003DCCCCCDLL;
  stru_286FFA0.intdesc.defaultval = 1060437492;
  stru_286FFA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05EE8 && __cxa_guard_acquire(&byte_2B05EE8) )
  {
    stru_286FF40.description = "Boost or attenuation [high/low shelf and peaking only]";
    __cxa_guard_release(&byte_2B05EE8);
  }
  *(_QWORD *)&stru_286FF40.floatdesc.min = 0x41F00000C1F00000LL;
  stru_286FF40.intdesc.defaultval = 0;
  stru_286FF40.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05EE0 && __cxa_guard_acquire(&byte_2B05EE0) )
  {
    stru_286FEE0.description = "Type of filter, affects how all other parameters are interpreted";
    __cxa_guard_release(&byte_2B05EE0);
  }
  *(_QWORD *)(&stru_286FEE0.datadesc + 1) = 12;
  stru_286FEE0.intdesc.valuenames = off_2870360;
  if ( !(_BYTE)byte_2B05ED8 && __cxa_guard_acquire(&byte_2B05ED8) )
  {
    stru_286FE80.description = "Significant frequency for the filter type";
    __cxa_guard_release(&byte_2B05ED8);
  }
  *(_QWORD *)&stru_286FE80.floatdesc.min = 0x46ABE00041A00000LL;
  stru_286FE80.intdesc.defaultval = 1174011904;
  stru_286FE80.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05ED0 && __cxa_guard_acquire(&byte_2B05ED0) )
  {
    stru_286FE20.description = "Quality factor";
    __cxa_guard_release(&byte_2B05ED0);
  }
  *(_QWORD *)&stru_286FE20.floatdesc.min = 0x412000003DCCCCCDLL;
  stru_286FE20.intdesc.defaultval = 1060437492;
  stru_286FE20.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05EC8 && __cxa_guard_acquire(&byte_2B05EC8) )
  {
    stru_286FDC0.description = "Boost or attenuation [high/low shelf and peaking only]";
    __cxa_guard_release(&byte_2B05EC8);
  }
  *(_QWORD *)&stru_286FDC0.floatdesc.min = 0x41F00000C1F00000LL;
  stru_286FDC0.intdesc.defaultval = 0;
  stru_286FDC0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05EC0 && __cxa_guard_acquire(&byte_2B05EC0) )
  {
    stru_286FD60.description = "Type of filter, affects how all other parameters are interpreted";
    __cxa_guard_release(&byte_2B05EC0);
  }
  *(_QWORD *)(&stru_286FD60.datadesc + 1) = 12;
  stru_286FD60.intdesc.valuenames = off_2870360;
  if ( !(_BYTE)byte_2B05EB8 && __cxa_guard_acquire(&byte_2B05EB8) )
  {
    stru_286FD00.description = "Significant frequency for the filter type";
    __cxa_guard_release(&byte_2B05EB8);
  }
  *(_QWORD *)&stru_286FD00.floatdesc.min = 0x46ABE00041A00000LL;
  stru_286FD00.intdesc.defaultval = 1174011904;
  stru_286FD00.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05EB0 && __cxa_guard_acquire(&byte_2B05EB0) )
  {
    stru_286FCA0.description = "Quality factor";
    __cxa_guard_release(&byte_2B05EB0);
  }
  *(_QWORD *)&stru_286FCA0.floatdesc.min = 0x412000003DCCCCCDLL;
  stru_286FCA0.intdesc.defaultval = 1060437492;
  stru_286FCA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  if ( !(_BYTE)byte_2B05EA8 && __cxa_guard_acquire(&byte_2B05EA8) )
  {
    stru_286FC40.description = "Boost or attenuation [high/low shelf and peaking only]";
    __cxa_guard_release(&byte_2B05EA8);
  }
  *(_QWORD *)&stru_286FC40.floatdesc.min = 0x41F00000C1F00000LL;
  stru_286FC40.intdesc.defaultval = 0;
  stru_286FC40.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  stru_286FB60.paramdesc = off_286FAC0;
  stru_286FB60.numparameters = 20;
  stru_286FB60.create = MultibandEQ_Create;
  stru_286FB60.release = MultibandEQ_Release;
  stru_286FB60.reset = MultibandEQ_Reset;
  stru_286FB60.process = MultibandEQ_Process;
  stru_286FB60.setparameterfloat = (FMOD_DSP_SETPARAM_FLOAT_CALLBACK_0)MultibandEQ_SetParameterFloat;
  stru_286FB60.setparameterint = MultibandEQ_SetParameterInt;
  stru_286FB60.getparameterfloat = MultibandEQ_GetParameterFloat;
  stru_286FB60.getparameterint = MultibandEQ_GetParameterInt;
  return &stru_286FB60;
}


// Address: 0x2256d30 | Name: MultibandEQ_Create
FMOD_RESULT_0 __fastcall MultibandEQ_Create(FMOD_DSP_STATE *state)
{
  __int64 v2; // rdi
  FMOD_RESULT_0 result; // eax
  unsigned int v4; // edx
  __int64 v5; // rcx
  _DWORD *v6; // rdi
  FMOD_DSP_DESCRIPTION_0 *Description; // rbp
  __int64 v8; // rbx
  float *v9; // rax

  v2 = state->functions->alloc(544, 0, "../../../core_api/src/fmod_dsp_multiband_eq.cpp");
  state->plugindata = (void *)v2;
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v2 )
  {
    v4 = 544;
    if ( (v2 & 1) != 0 )
    {
      *(_BYTE *)v2 = 0;
      LOBYTE(v4) = 31;
      ++v2;
    }
    if ( (v2 & 2) != 0 )
    {
      v2 += 2;
      v4 -= 2;
      *(_WORD *)(v2 - 2) = 0;
    }
    if ( (v2 & 4) != 0 )
    {
      *(_DWORD *)v2 = 0;
      v4 -= 4;
      v2 += 4;
    }
    v5 = v4 >> 3;
    memset((void *)v2, 0, 8 * v5);
    v6 = (_DWORD *)(v2 + 8 * v5);
    if ( (v4 & 4) != 0 )
    {
      *v6++ = 0;
      if ( (v4 & 2) == 0 )
      {
LABEL_10:
        if ( (v4 & 1) == 0 )
          goto LABEL_11;
        goto LABEL_21;
      }
    }
    else if ( (v4 & 2) == 0 )
    {
      goto LABEL_10;
    }
    v6 = (_DWORD *)((char *)v6 + 2);
    *((_WORD *)v6 - 1) = 0;
    if ( (v4 & 1) == 0 )
    {
LABEL_11:
      Description = FMOD_MultibandEQ_GetDescription();
      v8 = 0;
      if ( Description->numparameters <= 0 )
        return FMOD_RESULT::FMOD_OK_0;
      while ( 1 )
      {
        v9 = (float *)Description->paramdesc[v8];
        if ( *(_DWORD *)v9 )
        {
          if ( *(_DWORD *)v9 != 1 )
            goto LABEL_14;
          result = Description->setparameterint(state, v8, *((_DWORD *)v9 + 14));
          if ( result )
            return result;
          if ( (int)++v8 >= Description->numparameters )
            return FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          result = Description->setparameterfloat(state, v8, v9[14]);
          if ( result )
            return result;
LABEL_14:
          if ( (int)++v8 >= Description->numparameters )
            return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
LABEL_21:
    *(_BYTE *)v6 = 0;
    goto LABEL_11;
  }
  return result;
}


