// Address: 0x21ad810 | Name: _ZN4FMOD14ChannelControl15getSystemObjectEPPNS_6SystemE
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getSystemObject(FMOD::ChannelControl *const this, FMOD::System **system)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, 0);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = (*channelcontroli->_vptr_ChannelControlI)(channelcontroli, system);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, system);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getSystemObject",
      _buffer);
  }
  return v2;
}


// Address: 0x21ad8d0 | Name: _ZN4FMOD14ChannelControl4stopEv
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::stop(FMOD::ChannelControl *const this)
{
  FMOD_RESULT_1 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v1
     || (v1 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *))channelcontroli->_vptr_ChannelControlI + 1))(channelcontroli)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      v1,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::stop",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x21ad970 | Name: _ZN4FMOD14ChannelControl9setPausedEb
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::setPaused(FMOD::ChannelControl *const this, bool paused)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, bool))channelcontroli->_vptr_ChannelControlI + 2))(
                channelcontroli,
                paused)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, paused);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      (const char *)&info_ptr.row_pointers + 3,
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ada30 | Name: _ZN4FMOD14ChannelControl9getPausedEPb
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getPaused(FMOD::ChannelControl *const this, bool *paused)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, bool *))channelcontroli->_vptr_ChannelControlI
               + 3))(
                channelcontroli,
                paused)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, paused);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getPaused",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21adae0 | Name: _ZN4FMOD14ChannelControl9setVolumeEf
__int64 __fastcall FMOD::ChannelControl::setVolume(FMOD::ChannelControl *const this, float a2, float volume)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v3
     || (v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, _QWORD, float, float))channelcontroli->_vptr_ChannelControlI
               + 4))(
                channelcontroli,
                0,
                a2,
                volume)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, volume);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setVolume",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21adba0 | Name: _ZN4FMOD14ChannelControl9getVolumeEPf
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getVolume(FMOD::ChannelControl *const this, float *volume)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *))channelcontroli->_vptr_ChannelControlI
               + 5))(
                channelcontroli,
                volume)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, volume);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getVolume",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21adc50 | Name: _ZN4FMOD14ChannelControl13setVolumeRampEb
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::setVolumeRamp(FMOD::ChannelControl *const this, bool ramp)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, bool))channelcontroli->_vptr_ChannelControlI + 6))(
                channelcontroli,
                ramp)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, ramp);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setVolumeRamp",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21add10 | Name: _ZN4FMOD14ChannelControl13getVolumeRampEPb
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getVolumeRamp(FMOD::ChannelControl *const this, bool *ramp)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, bool *))channelcontroli->_vptr_ChannelControlI
               + 7))(
                channelcontroli,
                ramp)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, ramp);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getVolumeRamp",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21addc0 | Name: _ZN4FMOD14ChannelControl13getAudibilityEPf
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getAudibility(FMOD::ChannelControl *const this, float *audibility)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *))channelcontroli->_vptr_ChannelControlI
               + 8))(
                channelcontroli,
                audibility)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, audibility);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getAudibility",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ade70 | Name: _ZN4FMOD14ChannelControl8setPitchEf
__int64 __fastcall FMOD::ChannelControl::setPitch(FMOD::ChannelControl *const this, float a2, float pitch)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v3
     || (v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float, float))channelcontroli->_vptr_ChannelControlI
               + 9))(
                channelcontroli,
                a2,
                pitch)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, pitch);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setPitch",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21adf30 | Name: _ZN4FMOD14ChannelControl8getPitchEPf
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getPitch(FMOD::ChannelControl *const this, float *pitch)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *))channelcontroli->_vptr_ChannelControlI
               + 10))(
                channelcontroli,
                pitch)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, pitch);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getPitch",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21adfe0 | Name: _ZN4FMOD14ChannelControl7setMuteEb
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::setMute(FMOD::ChannelControl *const this, bool mute)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, bool))channelcontroli->_vptr_ChannelControlI + 11))(
                channelcontroli,
                mute)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, mute);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setMute",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ae0a0 | Name: _ZN4FMOD14ChannelControl7getMuteEPb
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getMute(FMOD::ChannelControl *const this, bool *mute)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, bool *))channelcontroli->_vptr_ChannelControlI
               + 12))(
                channelcontroli,
                mute)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, mute);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getMute",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ae150 | Name: _ZN4FMOD14ChannelControl19setReverbPropertiesEif
__int64 __fastcall FMOD::ChannelControl::setReverbProperties(
        FMOD::ChannelControl *const this,
        unsigned int instance,
        float a3,
        float wet)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, _QWORD, float, float))channelcontroli->_vptr_ChannelControlI
               + 13))(
                channelcontroli,
                instance,
                a3,
                wet)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, instance);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), wet);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setReverbProperties",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v4;
}


// Address: 0x21ae260 | Name: _ZN4FMOD14ChannelControl19getReverbPropertiesEiPf
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getReverbProperties(
        FMOD::ChannelControl *const this,
        int instance,
        float *wet)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, _QWORD, float *))channelcontroli->_vptr_ChannelControlI
               + 14))(
                channelcontroli,
                (unsigned int)instance,
                wet)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, instance);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), wet);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getReverbProperties",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21ae360 | Name: _ZN4FMOD14ChannelControl14setLowPassGainEf
__int64 __fastcall FMOD::ChannelControl::setLowPassGain(FMOD::ChannelControl *const this, float a2, float gain)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v3
     || (v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float, float))channelcontroli->_vptr_ChannelControlI
               + 16))(
                channelcontroli,
                a2,
                gain)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, gain);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setLowPassGain",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21ae420 | Name: _ZN4FMOD14ChannelControl14getLowPassGainEPf
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getLowPassGain(FMOD::ChannelControl *const this, float *gain)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *))channelcontroli->_vptr_ChannelControlI
               + 17))(
                channelcontroli,
                gain)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, gain);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getLowPassGain",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ae4d0 | Name: _ZN4FMOD14ChannelControl7setModeEj
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::setMode(FMOD::ChannelControl *const this, FMOD_MODE mode)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, _QWORD))channelcontroli->_vptr_ChannelControlI
               + 18))(
                channelcontroli,
                mode)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, mode);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setMode",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ae580 | Name: _ZN4FMOD14ChannelControl7getModeEPj
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getMode(FMOD::ChannelControl *const this, FMOD_MODE *mode)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, FMOD_MODE *))channelcontroli->_vptr_ChannelControlI
               + 19))(
                channelcontroli,
                mode)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, mode);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getMode",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ae630 | Name: _ZN4FMOD14ChannelControl11setCallbackEPF11FMOD_RESULTP19FMOD_CHANNELCONTROL24FMOD_CHANNELCONTROL_TYPE33FMOD_CHANNELCONTROL_CALLBACK_TYPEPvS6_E
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::setCallback(
        FMOD::ChannelControl *const this,
        FMOD_CHANNELCONTROL_CALLBACK_0 callback)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, FMOD_CHANNELCONTROL_CALLBACK_0))channelcontroli->_vptr_ChannelControlI
               + 20))(
                channelcontroli,
                callback)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, callback != 0);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setCallback",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ae6f0 | Name: _ZN4FMOD14ChannelControl9isPlayingEPb
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::isPlaying(FMOD::ChannelControl *const this, bool *isplaying)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  if ( isplaying )
    *isplaying = 0;
  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, bool *))channelcontroli->_vptr_ChannelControlI
               + 21))(
                channelcontroli,
                isplaying)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, isplaying);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::isPlaying",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21ae7b0 | Name: _ZN4FMOD14ChannelControl6setPanEf
__int64 __fastcall FMOD::ChannelControl::setPan(FMOD::ChannelControl *const this, float a2, float pan)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v3
     || (v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float, float))channelcontroli->_vptr_ChannelControlI
               + 22))(
                channelcontroli,
                a2,
                pan)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, pan);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setPan",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21ae870 | Name: _ZN4FMOD14ChannelControl18setMixLevelsOutputEffffffff
__int64 __fastcall FMOD::ChannelControl::setMixLevelsOutput(
        FMOD::ChannelControl *const this,
        float a2,
        float frontleft,
        float frontright,
        float center,
        float lfe,
        float surroundleft,
        float surroundright,
        float backleft)
{
  FMOD_RESULT_0 v9; // ebp
  int v11; // r14d
  int v12; // r14d
  int v13; // r14d
  int v14; // r14d
  int v15; // r14d
  int v16; // r14d
  int v17; // r14d
  int v18; // r14d
  int v19; // r14d
  int v20; // r14d
  int v21; // r14d
  int v22; // r14d
  int v23; // r14d
  int v24; // eax
  FMOD::SystemLockScope lockScope; // [rsp+20h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+28h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+30h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v9 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v9
     || (v9 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float, float, float, float, float, float, float, float))channelcontroli->_vptr_ChannelControlI
               + 23))(
                channelcontroli,
                a2,
                frontleft,
                frontright,
                center,
                lfe,
                surroundleft,
                surroundright,
                backleft)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, frontleft);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ") + v11;
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, frontleft) + v12;
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ") + v13;
    v15 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, frontleft) + v14;
    v16 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ") + v15;
    v17 = FMOD::FMOD_FormatArg(&_buffer[v16], 256 - v16, frontleft) + v16;
    v18 = FMOD::FMOD_FormatArg(&_buffer[v17], 256 - v17, ", ") + v17;
    v19 = FMOD::FMOD_FormatArg(&_buffer[v18], 256 - v18, frontleft) + v18;
    v20 = FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, ", ") + v19;
    v21 = FMOD::FMOD_FormatArg(&_buffer[v20], 256 - v20, frontleft) + v20;
    v22 = FMOD::FMOD_FormatArg(&_buffer[v21], 256 - v21, ", ") + v21;
    v23 = FMOD::FMOD_FormatArg(&_buffer[v22], 256 - v22, frontleft) + v22;
    v24 = FMOD::FMOD_FormatArg(&_buffer[v23], 256 - v23, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v24 + v23], 256 - (v24 + v23), frontleft);
    FMOD_ReportError(
      v9,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setMixLevelsOutput",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v9;
}


// Address: 0x21aeb10 | Name: _ZN4FMOD14ChannelControl17setMixLevelsInputEPfi
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::setMixLevelsInput(
        FMOD::ChannelControl *const this,
        float *levels,
        int numlevels)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *, _QWORD))channelcontroli->_vptr_ChannelControlI
               + 24))(
                channelcontroli,
                levels,
                (unsigned int)numlevels)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, levels);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), numlevels);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setMixLevelsInput",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21aec20 | Name: _ZN4FMOD14ChannelControl12setMixMatrixEPfiii
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::setMixMatrix(
        FMOD::ChannelControl *const this,
        float *matrix,
        int outchannels,
        int inchannels,
        int matrixhop)
{
  FMOD_RESULT_1 v7; // r13d
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r14d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v7
     || (v7 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *, _QWORD, _QWORD, _QWORD, __int64))channelcontroli->_vptr_ChannelControlI
               + 25))(
                channelcontroli,
                matrix,
                (unsigned int)outchannels,
                (unsigned int)inchannels,
                (unsigned int)matrixhop,
                1)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, matrix);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), outchannels);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = v11 + FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, inchannels);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), matrixhop);
    FMOD_ReportError(
      v7,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setMixMatrix",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v7;
}


// Address: 0x21aedc0 | Name: _ZN4FMOD14ChannelControl12getMixMatrixEPfPiS2_i
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getMixMatrix(
        FMOD::ChannelControl *const this,
        float *matrix,
        int *outchannels,
        int *inchannels,
        int matrixhop)
{
  FMOD_RESULT_1 v7; // r13d
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r14d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v7
     || (v7 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *, int *, int *, _QWORD))channelcontroli->_vptr_ChannelControlI
               + 26))(
                channelcontroli,
                matrix,
                outchannels,
                inchannels,
                (unsigned int)matrixhop)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, matrix);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), outchannels);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = v11 + FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, inchannels);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), matrixhop);
    FMOD_ReportError(
      v7,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getMixMatrix",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v7;
}


// Address: 0x21aef50 | Name: _ZN4FMOD14ChannelControl11getDSPClockEPyS1_
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getDSPClock(
        FMOD::ChannelControl *const this,
        unsigned __int64 *dspclock,
        unsigned __int64 *parentclock)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, 0);
  if ( v4 )
    goto LABEL_2;
  v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, unsigned __int64 *, unsigned __int64 *))channelcontroli->_vptr_ChannelControlI
        + 27))(
         channelcontroli,
         dspclock,
         parentclock);
  if ( v4 )
    goto LABEL_2;
  if ( dspclock )
    *dspclock >>= 20;
  if ( parentclock )
    *parentclock >>= 20;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, 0);
  if ( v4 )
  {
LABEL_2:
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, dspclock);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), parentclock);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
        this,
        "ChannelControl::getDSPClock",
        _buffer);
    }
  }
  return v4;
}


// Address: 0x21af070 | Name: _ZN4FMOD14ChannelControl8setDelayEyyb
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::setDelay(
        FMOD::ChannelControl *const this,
        unsigned __int64 dspclock_start,
        unsigned __int64 dspclock_end,
        bool stopchannels)
{
  unsigned __int64 v5; // r13
  FMOD_RESULT_1 v7; // ebx
  int v9; // eax
  int v10; // r12d
  int v11; // eax
  int v12; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  v5 = dspclock_start;
  lockScope.mSystem = 0;
  v7 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( v7
    || (v5 = dspclock_start << 20,
        dspclock_end <<= 20,
        (v7 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, unsigned __int64, unsigned __int64, bool))channelcontroli->_vptr_ChannelControlI
               + 28))(
                channelcontroli,
                dspclock_start << 20,
                dspclock_end,
                stopchannels)) != FMOD_RESULT::FMOD_OK_0) )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v12 = FMOD::FMOD_FormatArg(_buffer, 256, v5);
      v9 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
      v10 = v9 + v12 + FMOD::FMOD_FormatArg(&_buffer[v9 + v12], 256 - (v9 + v12), dspclock_end);
      v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v11 + v10], 256 - (v11 + v10), stopchannels);
      FMOD_ReportError(
        v7,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
        this,
        "ChannelControl::setDelay",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v7;
}


// Address: 0x21af1d0 | Name: _ZN4FMOD14ChannelControl8getDelayEPyS1_Pb
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getDelay(
        FMOD::ChannelControl *const this,
        unsigned __int64 *dspclock_start,
        unsigned __int64 *dspclock_end,
        bool *stopchannels)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( v6
    || (v6 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, unsigned __int64 *, unsigned __int64 *, bool *))channelcontroli->_vptr_ChannelControlI
              + 29))(
               channelcontroli,
               dspclock_start,
               dspclock_end,
               stopchannels)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v11 = FMOD::FMOD_FormatArg(_buffer, 256, dspclock_start);
      v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
      v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), dspclock_end);
      v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), stopchannels);
      FMOD_ReportError(
        v6,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
        this,
        "ChannelControl::getDelay",
        _buffer);
    }
  }
  else
  {
    if ( dspclock_start )
      *dspclock_start >>= 20;
    if ( dspclock_end )
      *dspclock_end >>= 20;
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21af330 | Name: _ZN4FMOD14ChannelControl12addFadePointEyf
__int64 __fastcall FMOD::ChannelControl::addFadePoint(
        FMOD::ChannelControl *const this,
        unsigned __int64 dspclock,
        float a3,
        float volume)
{
  unsigned __int64 v4; // r12
  FMOD_RESULT_0 v5; // ebx
  int v7; // r12d
  int v8; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  v4 = dspclock;
  lockScope.mSystem = 0;
  v5 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( v5
    || (v4 = dspclock << 20,
        (v5 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, unsigned __int64, float, float))channelcontroli->_vptr_ChannelControlI
               + 30))(
                channelcontroli,
                dspclock << 20,
                a3,
                volume)) != FMOD_RESULT::FMOD_OK_0) )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v7 = FMOD::FMOD_FormatArg(_buffer, 256, v4);
      v8 = FMOD::FMOD_FormatArg(&_buffer[v7], 256 - v7, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v8 + v7], 256 - (v8 + v7), volume);
      FMOD_ReportError(
        v5,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
        this,
        "ChannelControl::addFadePoint",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v5;
}


// Address: 0x21af440 | Name: _ZN4FMOD14ChannelControl16setFadePointRampEyf
__int64 __fastcall FMOD::ChannelControl::setFadePointRamp(
        FMOD::ChannelControl *const this,
        unsigned __int64 dspclock,
        float a3,
        float volume)
{
  unsigned __int64 v4; // r12
  FMOD_RESULT_0 v5; // ebx
  int v7; // r12d
  int v8; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  v4 = dspclock;
  lockScope.mSystem = 0;
  v5 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( v5
    || (v4 = dspclock << 20,
        (v5 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, unsigned __int64, float, float))channelcontroli->_vptr_ChannelControlI
               + 31))(
                channelcontroli,
                dspclock << 20,
                a3,
                volume)) != FMOD_RESULT::FMOD_OK_0) )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v7 = FMOD::FMOD_FormatArg(_buffer, 256, v4);
      v8 = FMOD::FMOD_FormatArg(&_buffer[v7], 256 - v7, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v8 + v7], 256 - (v8 + v7), volume);
      FMOD_ReportError(
        v5,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
        this,
        "ChannelControl::setFadePointRamp",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v5;
}


// Address: 0x21af550 | Name: _ZN4FMOD14ChannelControl16removeFadePointsEyy
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::removeFadePoints(
        FMOD::ChannelControl *const this,
        unsigned __int64 dspclock_start,
        unsigned __int64 dspclock_end)
{
  unsigned __int64 v3; // r13
  FMOD_RESULT_1 v5; // ebx
  int v7; // r13d
  int v8; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  v3 = dspclock_start;
  lockScope.mSystem = 0;
  v5 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( v5
    || (v3 = dspclock_start << 20,
        dspclock_end <<= 20,
        (v5 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, unsigned __int64, unsigned __int64))channelcontroli->_vptr_ChannelControlI
               + 32))(
                channelcontroli,
                dspclock_start << 20,
                dspclock_end)) != FMOD_RESULT::FMOD_OK_0) )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v7 = FMOD::FMOD_FormatArg(_buffer, 256, v3);
      v8 = FMOD::FMOD_FormatArg(&_buffer[v7], 256 - v7, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v8 + v7], 256 - (v8 + v7), dspclock_end);
      FMOD_ReportError(
        v5,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
        this,
        "ChannelControl::removeFadePoints",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v5;
}


// Address: 0x21af660 | Name: _ZN4FMOD14ChannelControl13getFadePointsEPjPyPf
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getFadePoints(
        FMOD::ChannelControl *const this,
        unsigned int *numpoints,
        unsigned __int64 *point_dspclock,
        float *point_volume)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r12d
  int v10; // eax
  FMOD_RESULT_1 v11; // eax
  unsigned __int64 *v12; // rdx
  unsigned __int64 *v13; // rax
  int v14; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( v6 )
  {
LABEL_2:
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v14 = FMOD::FMOD_FormatArg(_buffer, 256, numpoints);
      v8 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, ", ");
      v9 = v8 + v14 + FMOD::FMOD_FormatArg(&_buffer[v8 + v14], 256 - (v8 + v14), point_dspclock);
      v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), point_volume);
      FMOD_ReportError(
        v6,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
        this,
        "ChannelControl::getFadePoints",
        _buffer);
    }
    goto LABEL_4;
  }
  v11 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, unsigned int *, unsigned __int64 *, float *))channelcontroli->_vptr_ChannelControlI
         + 33))(
          channelcontroli,
          numpoints,
          point_dspclock,
          point_volume);
  if ( v11 || !point_dspclock )
  {
    if ( v11 == FMOD_RESULT::FMOD_OK_0 )
    {
      v6 = FMOD_RESULT::FMOD_OK_0;
      goto LABEL_4;
    }
    v6 = v11;
    goto LABEL_2;
  }
  if ( *numpoints )
  {
    v12 = point_dspclock;
    v13 = &point_dspclock[*numpoints];
    do
      *v12++ >>= 20;
    while ( v12 != v13 );
  }
LABEL_4:
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21af7f0 | Name: _ZN4FMOD14ChannelControl6getDSPEiPPNS_3DSPE
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getDSP(FMOD::ChannelControl *const this, int index, FMOD::DSP **dsp)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, _QWORD, FMOD::DSP **))channelcontroli->_vptr_ChannelControlI
               + 36))(
                channelcontroli,
                (unsigned int)index,
                dsp)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), dsp);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getDSP",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21af900 | Name: _ZN4FMOD14ChannelControl6addDSPEiPNS_3DSPE
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::addDSP(FMOD::ChannelControl *const this, int index, FMOD::DSP *dsp)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, _QWORD, FMOD::DSP *))channelcontroli->_vptr_ChannelControlI
               + 34))(
                channelcontroli,
                (unsigned int)index,
                dsp)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), dsp);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::addDSP",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21afa10 | Name: _ZN4FMOD14ChannelControl9removeDSPEPNS_3DSPE
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::removeDSP(FMOD::ChannelControl *const this, FMOD::DSP *dsp)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, FMOD::DSP *))channelcontroli->_vptr_ChannelControlI
               + 35))(
                channelcontroli,
                dsp)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, dsp);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::removeDSP",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21afac0 | Name: _ZN4FMOD14ChannelControl10getNumDSPsEPi
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getNumDSPs(FMOD::ChannelControl *const this, int *numdsps)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, int *))channelcontroli->_vptr_ChannelControlI
               + 37))(
                channelcontroli,
                numdsps)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numdsps);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getNumDSPs",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21afb70 | Name: _ZN4FMOD14ChannelControl11setDSPIndexEPNS_3DSPEi
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::setDSPIndex(FMOD::ChannelControl *const this, FMOD::DSP *dsp, int index)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, FMOD::DSP *, _QWORD))channelcontroli->_vptr_ChannelControlI
               + 38))(
                channelcontroli,
                dsp,
                (unsigned int)index)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, dsp);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), index);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setDSPIndex",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21afc80 | Name: _ZN4FMOD14ChannelControl11getDSPIndexEPNS_3DSPEPi
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getDSPIndex(
        FMOD::ChannelControl *const this,
        FMOD::DSP *dsp,
        int *index)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, FMOD::DSP *, int *))channelcontroli->_vptr_ChannelControlI
               + 39))(
                channelcontroli,
                dsp,
                index)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, dsp);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), index);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getDSPIndex",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21afd90 | Name: _ZN4FMOD14ChannelControl15set3DAttributesEPK11FMOD_VECTORS3_
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::set3DAttributes(
        FMOD::ChannelControl *const this,
        const FMOD_VECTOR *pos,
        const FMOD_VECTOR *vel)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, const FMOD_VECTOR *, const FMOD_VECTOR *))channelcontroli->_vptr_ChannelControlI
               + 40))(
                channelcontroli,
                pos,
                vel)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, pos);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), vel);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::set3DAttributes",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21afea0 | Name: _ZN4FMOD14ChannelControl15get3DAttributesEP11FMOD_VECTORS2_
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::get3DAttributes(
        FMOD::ChannelControl *const this,
        FMOD_VECTOR *pos,
        FMOD_VECTOR *vel)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, FMOD_VECTOR *, FMOD_VECTOR *))channelcontroli->_vptr_ChannelControlI
               + 41))(
                channelcontroli,
                pos,
                vel)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, pos);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), vel);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::get3DAttributes",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21affb0 | Name: _ZN4FMOD14ChannelControl19set3DMinMaxDistanceEff
__int64 __fastcall FMOD::ChannelControl::set3DMinMaxDistance(
        FMOD::ChannelControl *const this,
        float a2,
        float mindistance,
        float maxdistance)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float, float, float))channelcontroli->_vptr_ChannelControlI
               + 42))(
                channelcontroli,
                a2,
                mindistance,
                maxdistance)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, mindistance);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), mindistance);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::set3DMinMaxDistance",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v4;
}


// Address: 0x21b00d0 | Name: _ZN4FMOD14ChannelControl19get3DMinMaxDistanceEPfS1_
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::get3DMinMaxDistance(
        FMOD::ChannelControl *const this,
        float *mindistance,
        float *maxdistance)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *, float *))channelcontroli->_vptr_ChannelControlI
               + 43))(
                channelcontroli,
                mindistance,
                maxdistance)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, mindistance);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), maxdistance);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::get3DMinMaxDistance",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21b01e0 | Name: _ZN4FMOD14ChannelControl17set3DConeSettingsEfff
__int64 __fastcall FMOD::ChannelControl::set3DConeSettings(
        FMOD::ChannelControl *const this,
        float a2,
        float insideconeangle,
        float outsideconeangle,
        float outsidevolume)
{
  FMOD_RESULT_0 v5; // ebx
  int v7; // r14d
  int v8; // r14d
  int v9; // r14d
  int v10; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v5 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v5
     || (v5 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float, float, float, float))channelcontroli->_vptr_ChannelControlI
               + 44))(
                channelcontroli,
                a2,
                insideconeangle,
                outsideconeangle,
                outsidevolume)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v7 = FMOD::FMOD_FormatArg(_buffer, 256, insideconeangle);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v7], 256 - v7, ", ") + v7;
    v9 = FMOD::FMOD_FormatArg(&_buffer[v8], 256 - v8, insideconeangle) + v8;
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), insideconeangle);
    FMOD_ReportError(
      v5,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::set3DConeSettings",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v5;
}


// Address: 0x21b0340 | Name: _ZN4FMOD14ChannelControl17get3DConeSettingsEPfS1_S1_
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::get3DConeSettings(
        FMOD::ChannelControl *const this,
        float *insideconeangle,
        float *outsideconeangle,
        float *outsidevolume)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v6
     || (v6 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *, float *, float *))channelcontroli->_vptr_ChannelControlI
               + 45))(
                channelcontroli,
                insideconeangle,
                outsideconeangle,
                outsidevolume)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, insideconeangle);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), outsideconeangle);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), outsidevolume);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::get3DConeSettings",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21b0490 | Name: _ZN4FMOD14ChannelControl20set3DConeOrientationEP11FMOD_VECTOR
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::set3DConeOrientation(
        FMOD::ChannelControl *const this,
        FMOD_VECTOR *orientation)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, FMOD_VECTOR *))channelcontroli->_vptr_ChannelControlI
               + 46))(
                channelcontroli,
                orientation)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, orientation);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::set3DConeOrientation",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b0540 | Name: _ZN4FMOD14ChannelControl20get3DConeOrientationEP11FMOD_VECTOR
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::get3DConeOrientation(
        FMOD::ChannelControl *const this,
        FMOD_VECTOR *orientation)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, FMOD_VECTOR *))channelcontroli->_vptr_ChannelControlI
               + 47))(
                channelcontroli,
                orientation)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, orientation);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::get3DConeOrientation",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b05f0 | Name: _ZN4FMOD14ChannelControl18set3DCustomRolloffEP11FMOD_VECTORi
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::set3DCustomRolloff(
        FMOD::ChannelControl *const this,
        FMOD_VECTOR *points,
        int numpoints)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, FMOD_VECTOR *, _QWORD))channelcontroli->_vptr_ChannelControlI
               + 48))(
                channelcontroli,
                points,
                (unsigned int)numpoints)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, points);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), numpoints);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::set3DCustomRolloff",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21b0700 | Name: _ZN4FMOD14ChannelControl18get3DCustomRolloffEPP11FMOD_VECTORPi
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::get3DCustomRolloff(
        FMOD::ChannelControl *const this,
        FMOD_VECTOR **points,
        int *numpoints)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, FMOD_VECTOR **, int *))channelcontroli->_vptr_ChannelControlI
               + 49))(
                channelcontroli,
                points,
                numpoints)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, points);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), numpoints);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::get3DCustomRolloff",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21b0810 | Name: _ZN4FMOD14ChannelControl14set3DOcclusionEff
__int64 __fastcall FMOD::ChannelControl::set3DOcclusion(
        FMOD::ChannelControl *const this,
        float a2,
        float directocclusion,
        float reverbocclusion)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float, float, float))channelcontroli->_vptr_ChannelControlI
               + 50))(
                channelcontroli,
                a2,
                directocclusion,
                reverbocclusion)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, directocclusion);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), directocclusion);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::set3DOcclusion",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v4;
}


// Address: 0x21b0930 | Name: _ZN4FMOD14ChannelControl14get3DOcclusionEPfS1_
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::get3DOcclusion(
        FMOD::ChannelControl *const this,
        float *directocclusion,
        float *reverbocclusion)
{
  FMOD_RESULT_1 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v4
     || (v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *, float *))channelcontroli->_vptr_ChannelControlI
               + 52))(
                channelcontroli,
                directocclusion,
                reverbocclusion)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, directocclusion);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), reverbocclusion);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::get3DOcclusion",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21b0a40 | Name: _ZN4FMOD14ChannelControl11set3DSpreadEf
__int64 __fastcall FMOD::ChannelControl::set3DSpread(FMOD::ChannelControl *const this, float a2, float angle)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v3
     || (v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float, float))channelcontroli->_vptr_ChannelControlI
               + 53))(
                channelcontroli,
                a2,
                angle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, angle);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::set3DSpread",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21b0b00 | Name: _ZN4FMOD14ChannelControl11get3DSpreadEPf
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::get3DSpread(FMOD::ChannelControl *const this, float *angle)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *))channelcontroli->_vptr_ChannelControlI
               + 54))(
                channelcontroli,
                angle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, angle);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::get3DSpread",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b0bb0 | Name: _ZN4FMOD14ChannelControl10set3DLevelEf
__int64 __fastcall FMOD::ChannelControl::set3DLevel(FMOD::ChannelControl *const this, float a2, float level)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v3
     || (v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float, float))channelcontroli->_vptr_ChannelControlI
               + 55))(
                channelcontroli,
                a2,
                level)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, level);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::set3DLevel",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21b0c70 | Name: _ZN4FMOD14ChannelControl10get3DLevelEPf
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::get3DLevel(FMOD::ChannelControl *const this, float *level)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *))channelcontroli->_vptr_ChannelControlI
               + 56))(
                channelcontroli,
                level)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, level);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::get3DLevel",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b0d20 | Name: _ZN4FMOD14ChannelControl17set3DDopplerLevelEf
__int64 __fastcall FMOD::ChannelControl::set3DDopplerLevel(FMOD::ChannelControl *const this, float a2, float level)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v3
     || (v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float, float))channelcontroli->_vptr_ChannelControlI
               + 57))(
                channelcontroli,
                a2,
                level)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, level);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::set3DDopplerLevel",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21b0de0 | Name: _ZN4FMOD14ChannelControl17get3DDopplerLevelEPf
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::get3DDopplerLevel(FMOD::ChannelControl *const this, float *level)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, float *))channelcontroli->_vptr_ChannelControlI
               + 58))(
                channelcontroli,
                level)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, level);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::get3DDopplerLevel",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b0e90 | Name: _ZN4FMOD14ChannelControl19set3DDistanceFilterEbff
__int64 __fastcall FMOD::ChannelControl::set3DDistanceFilter(
        FMOD::ChannelControl *const this,
        bool custom,
        float a3,
        float customLevel,
        float centerFreq)
{
  FMOD_RESULT_0 v5; // ebx
  int v7; // r14d
  int v8; // r14d
  int v9; // r14d
  int v10; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v5 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v5
     || (v5 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, bool, float, float, float))channelcontroli->_vptr_ChannelControlI
               + 59))(
                channelcontroli,
                custom,
                a3,
                customLevel,
                centerFreq)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v7 = FMOD::FMOD_FormatArg(_buffer, 256, custom);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v7], 256 - v7, ", ") + v7;
    v9 = FMOD::FMOD_FormatArg(&_buffer[v8], 256 - v8, customLevel) + v8;
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), customLevel);
    FMOD_ReportError(
      v5,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::set3DDistanceFilter",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v5;
}


// Address: 0x21b0fe0 | Name: _ZN4FMOD14ChannelControl19get3DDistanceFilterEPbPfS2_
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::get3DDistanceFilter(
        FMOD::ChannelControl *const this,
        bool *custom,
        float *customLevel,
        float *centerFreq)
{
  FMOD_RESULT_1 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v6
     || (v6 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *, bool *, float *, float *))channelcontroli->_vptr_ChannelControlI
               + 60))(
                channelcontroli,
                custom,
                customLevel,
                centerFreq)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, custom);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), customLevel);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), centerFreq);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::get3DDistanceFilter",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x21b1130 | Name: _ZN4FMOD14ChannelControl11setUserDataEPv
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::setUserData(FMOD::ChannelControl *const this, void *userdata)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2 || (v2 = FMOD::ChannelControlI::setUserData(channelcontroli, userdata)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, userdata);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::setUserData",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b11e0 | Name: _ZN4FMOD14ChannelControl11getUserDataEPPv
FMOD_RESULT_1 __fastcall FMOD::ChannelControl::getUserData(FMOD::ChannelControl *const this, void **userdata)
{
  FMOD_RESULT_1 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelControlI *channelcontroli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelControlI::validate(this, &channelcontroli, &lockScope);
  if ( (v2 || (v2 = FMOD::ChannelControlI::getUserData(channelcontroli, userdata)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, userdata);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELCONTROL,
      this,
      "ChannelControl::getUserData",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


