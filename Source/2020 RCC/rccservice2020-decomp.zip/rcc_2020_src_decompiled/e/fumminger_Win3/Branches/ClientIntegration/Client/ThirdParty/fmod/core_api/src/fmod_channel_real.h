// Address: 0x221f530 | Name: _ZN4FMOD11ChannelReal8isStreamEv
bool __fastcall FMOD::ChannelReal::isStream(FMOD::ChannelReal *const this)
{
  return 0;
}


// Address: 0x221f540 | Name: _ZN4FMOD11ChannelRealD2Ev
void __fastcall FMOD::ChannelReal::~ChannelReal(FMOD::ChannelReal *const this)
{
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2270;
}


// Address: 0x221f550 | Name: _ZN4FMOD11ChannelReal13setPositionExEjjb
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::setPositionEx(
        FMOD::ChannelReal *const this,
        unsigned int position,
        FMOD_TIMEUNIT postype,
        bool fromasync)
{
  return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
}


// Address: 0x221f560 | Name: _ZN4FMOD11ChannelReal13getPositionExEPjj
FMOD_RESULT_0 __fastcall FMOD::ChannelReal::getPositionEx(
        FMOD::ChannelReal *const this,
        unsigned int *position,
        FMOD_TIMEUNIT postype)
{
  return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
}


// Address: 0x221f9a0 | Name: _ZN4FMOD11ChannelRealD0Ev
void __fastcall FMOD::ChannelReal::~ChannelReal(FMOD::ChannelReal *const this)
{
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2270;
  operator delete(this);
}


// Address: 0x221fa30 | Name: _ZN4FMOD15ChannelEmulatedD2Ev
void __fastcall FMOD::ChannelEmulated::~ChannelEmulated(FMOD::ChannelEmulated *const this)
{
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2270;
}


// Address: 0x221fa40 | Name: _ZN4FMOD15ChannelEmulatedD0Ev
void __fastcall FMOD::ChannelEmulated::~ChannelEmulated(FMOD::ChannelEmulated *const this)
{
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2270;
  operator delete(this);
}


// Address: 0x222ce00 | Name: _ZN4FMOD13ChannelStreamD2Ev
void __fastcall FMOD::ChannelStream::~ChannelStream(FMOD::ChannelStream *const this)
{
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2270;
}


// Address: 0x222ce10 | Name: _ZN4FMOD13ChannelStreamD0Ev
void __fastcall FMOD::ChannelStream::~ChannelStream(FMOD::ChannelStream *const this)
{
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2270;
  operator delete(this);
}


