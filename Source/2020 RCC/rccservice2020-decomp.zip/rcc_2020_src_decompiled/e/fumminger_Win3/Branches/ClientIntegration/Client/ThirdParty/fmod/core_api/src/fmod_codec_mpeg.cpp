// Address: 0x21d0d90 | Name: _ZN4FMOD9CodecMPEG16getDescriptionExEv
FMOD::FMOD_CODEC_DESCRIPTION_EX *__cdecl FMOD::CodecMPEG::getDescriptionEx()
{
  stru_2AD7A80.version = 65792;
  stru_2AD7A80.timeunits = 10;
  stru_2AD7A80.mType = FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_MPEG_0;
  stru_2AD7A80.mPoolType = FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_MPEG;
  stru_2AD7A80.name = "FMOD MPEG Codec";
  stru_2AD7A80.mSize = 616;
  stru_2AD7A80.open = FMOD::CodecMPEG::openInternal;
  stru_2AD7A80.close = FMOD::CodecMPEG::closeInternal;
  stru_2AD7A80.read = FMOD::CodecMPEG::readInternal;
  stru_2AD7A80.setposition = FMOD::CodecMPEG::setPositionInternal;
  stru_2AD7A80.soundcreate = FMOD::CodecMPEG::soundCreateInternal;
  stru_2AD7A80.reset = FMOD::CodecMPEG::resetCallback;
  stru_2AD7A80.getcontextinfo = FMOD::CodecMPEG::getContextInfoInternal;
  stru_2AD7A80.setupcontext = FMOD::CodecMPEG::setupContextInternal;
  return &stru_2AD7A80;
}


// Address: 0x21d0e50 | Name: _ZN4FMOD9CodecMPEG10makeTablesEi
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::makeTables(int scaleval)
{
  int v1; // ebp
  float **v2; // r12
  float i; // xmm0_4
  float *v4; // r15
  int j; // r14d
  float *v6; // rax
  int v7; // edi
  float *v8; // r9
  __int64 k; // rdx
  float v10; // xmm0_4
  int *v11; // rcx
  float v12; // xmm0_4

  v1 = 0;
  v2 = FMOD::CodecMPEG::gPnts;
  for ( i = 0.99879545; ; i = cosf(3.1415927 / (float)(64 >> v1)) )
  {
    v4 = *v2;
    for ( j = 0; ; i = cosf((float)((float)((float)((float)j + (float)j) + 1.0) * 3.1415927) / (float)(64 >> v1)) )
    {
      ++j;
      *v4++ = 1.0 / (float)(i + i);
      if ( 16 >> v1 <= j )
        break;
    }
    ++v1;
    ++v2;
    if ( v1 == 5 )
      break;
  }
  v6 = (float *)(((unsigned __int64)&FMOD::CodecMPEG::gDecWinMem[3] + 3) & 0xFFFFFFFFFFFFFFF0LL);
  v7 = -scaleval;
  v8 = v6 + 528;
  qword_2AD84C8 = v6;
  for ( k = 0; k != 256; ++k )
  {
    if ( v6 < v8 )
    {
      v10 = (float)((float)FMOD::CodecMPEG::gIntWinBase[k] * 0.000015258789) * (float)v7;
      *v6 = v10;
      v6[16] = v10;
    }
    if ( (k & 0x1F) == 0x1F )
      v6 -= 1023;
    if ( (k & 0x3F) == 0x3F )
      v7 = -v7;
    v6 += 32;
  }
  v11 = &FMOD::CodecMPEG::gIntWinBase[256];
  do
  {
    if ( v6 < v8 )
    {
      v12 = (float)((float)*v11 * 0.000015258789) * (float)v7;
      *v6 = v12;
      v6[16] = v12;
    }
    if ( (k & 0x1F) == 0x1F )
      v6 -= 1023;
    if ( (k & 0x3F) == 0x3F )
      v7 = -v7;
    LODWORD(k) = k + 1;
    v6 += 32;
    --v11;
  }
  while ( (_DWORD)k != 512 );
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d1040 | Name: _ZN4FMOD9CodecMPEG7initAllEv
FMOD_RESULT_0 __cdecl FMOD::CodecMPEG::initAll()
{
  FMOD_RESULT_0 result; // eax

  qword_2AD84C8 = (float *)(((unsigned __int64)&FMOD::CodecMPEG::gDecWinMem[3] + 3) & 0xFFFFFFFFFFFFFFF0LL);
  result = FMOD::CodecMPEG::makeTables(1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::CodecMPEG::initLayer3(32);
  return result;
}


// Address: 0x21d1080 | Name: _ZN4FMOD9CodecMPEG12getPCMLengthEv
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::getPCMLength(FMOD::CodecMPEG *const this)
{
  unsigned int mPCMFrameLength; // r15d
  FMOD_RESULT_0 result; // eax
  FMOD_CODEC_WAVEFORMAT *waveformat; // rax
  unsigned int v5; // ebp
  unsigned int v6; // r13d
  unsigned int mNumFrames; // edx
  unsigned int *v8; // rsi
  unsigned int v9; // edx
  unsigned int *mFrameOffset; // rax
  FMOD_CODEC_WAVEFORMAT *v11; // rcx
  __int64 v12; // rdx
  FMOD::File *mFile; // rdi
  unsigned int oldpos; // [rsp+4h] [rbp-44h] BYREF
  unsigned int header; // [rsp+8h] [rbp-40h] BYREF
  int framesize[15]; // [rsp+Ch] [rbp-3Ch] BYREF

  mPCMFrameLength = this->mPCMFrameLength;
  result = FMOD::File::tell(this->mFile, &oldpos);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    waveformat = this->waveformat;
    this->mNumFrames = 0;
    waveformat->lengthpcm = 0;
    if ( waveformat->lengthbytes )
    {
      v5 = 0;
      v6 = 0;
      while ( FMOD::File::read(this->mFile, &header, 1u, 4u, 0) == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( FMOD::CodecMPEG::decodeHeader(this, &header, 0, 0, framesize)
          || (v11 = this->waveformat, v5 + framesize[0] >= v11->lengthbytes) )
        {
          FMOD::File::seek(this->mFile, -3, 1);
          if ( v5 >= this->waveformat->lengthbytes )
            break;
        }
        else
        {
          mNumFrames = this->mNumFrames;
          if ( mNumFrames > v6 )
          {
            mFrameOffset = this->mFrameOffset;
          }
          else
          {
            v8 = this->mFrameOffset;
            v9 = mNumFrames + 1000;
            this->mNumFrames = v9;
            mFrameOffset = (unsigned int *)FMOD::MemPool::realloc(
                                             off_286F358->gSystemMemPool,
                                             v8,
                                             4 * v9,
                                             "../../../core_api/src/fmod_codec_mpeg.cpp",
                                             273,
                                             0);
            this->mFrameOffset = mFrameOffset;
            if ( !mFrameOffset )
              return FMOD_RESULT::FMOD_ERR_MEMORY_0;
            v11 = this->waveformat;
          }
          v12 = v6;
          mFile = this->mFile;
          ++v6;
          mFrameOffset[v12] = v5;
          v11->lengthpcm += mPCMFrameLength;
          v5 += framesize[0] + 4;
          if ( FMOD::File::seek(mFile, framesize[0], 1) || v5 >= this->waveformat->lengthbytes )
            break;
        }
      }
    }
    else
    {
      v6 = 0;
    }
    result = FMOD::File::seek(this->mFile, oldpos, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      this->mNumFrames = v6;
  }
  return result;
}


// Address: 0x21d1230 | Name: _ZN4FMOD9CodecMPEG12openInternalEjP22FMOD_CREATESOUNDEXINFO
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::openInternal(
        FMOD::CodecMPEG *const this,
        FMOD_MODE usermode,
        FMOD_CREATESOUNDEXINFO *userexinfo)
{
  FMOD_RESULT_0 result; // eax
  unsigned int v4; // ebp
  unsigned int v5; // ebx
  unsigned int v6; // r15d
  unsigned int mSrcDataOffset; // esi
  int v8; // r15d
  FMOD_RESULT_0 v9; // eax
  FMOD::WAVE_FORMATEXTENSIBLE *mSrcFormat; // rsi
  int wFormatTag; // edx
  int name; // r10d
  int v13; // r8d
  FMOD::CodecMPEG *v14; // r15
  FMOD::CodecMPEG_Context *mContext; // rax
  unsigned int v16; // edx
  FMOD_CODEC_WAVEFORMAT *p_mWaveFormat; // rdi
  __int64 v18; // rcx
  const char **v19; // rdi
  unsigned int v20; // eax
  bool v21; // zf
  unsigned int v22; // ecx
  FMOD_CODEC_WAVEFORMAT *waveformat; // rax
  FMOD_SOUND_FORMAT_0 format; // ebx
  int v25; // esi
  FMOD::File *mFile; // rdi
  unsigned int v27; // ecx
  FMOD::File *v28; // rdi
  FMOD_CODEC_WAVEFORMAT *v29; // rax
  unsigned int v30; // edx
  unsigned int *mFrameOffset; // rsi
  FMOD_CODEC_WAVEFORMAT *v32; // rax
  FMOD_CODEC_WAVEFORMAT *v33; // rsi
  int v34; // eax
  __int16 usermodea; // [rsp+10h] [rbp-4988h]
  bool manualsizecalc; // [rsp+1Bh] [rbp-497Dh]
  int lastchannels; // [rsp+1Ch] [rbp-497Ch]
  char header[4]; // [rsp+20h] [rbp-4978h] BYREF
  char wave[4]; // [rsp+30h] [rbp-4968h] BYREF
  unsigned int lengthbytes; // [rsp+3Ch] [rbp-495Ch] BYREF
  FMOD::WAVE_CHUNK chunk; // [rsp+40h] [rbp-4958h] BYREF
  FMOD_CODEC_WAVEFORMAT tempwaveformat; // [rsp+50h] [rbp-4948h] BYREF
  FMOD::CodecWav_0 tempwav; // [rsp+90h] [rbp-4908h] BYREF
  _QWORD v44[1748]; // [rsp+1290h] [rbp-3708h] BYREF
  int v45; // [rsp+4934h] [rbp-64h]
  int v46; // [rsp+4958h] [rbp-40h]

  this->mType = FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_MPEG_0;
  this->mDecoder = 0;
  this->mDecoderContext = 0;
  this->mDecoderContextMemory = 0;
  this->mPCMBufferMemory = 0;
  this->fileread = (FMOD_FILE_READ_CALLBACK)FMOD::Codec::defaultFileRead;
  this->mWaveFormatMemory = 0;
  this->mMetadata = 0;
  this->numsubsounds = 0;
  this->waveformat = 0;
  this->fileseek = (FMOD_FILE_SEEK_CALLBACK)FMOD::Codec::defaultFileSeek;
  this->waveformatversion = 3;
  this->mSrcDataOffset = 0;
  usermodea = usermode;
  lengthbytes = 0;
  this->metadata = FMOD::Codec::defaultMetaData;
  memset(&tempwav, 0, sizeof(tempwav));
  tempwav.mSrcDataOffset = -1;
  tempwav.waveformat = &tempwaveformat;
  memset(&tempwaveformat, 0, sizeof(tempwaveformat));
  tempwav.mFile = this->mFile;
  result = FMOD::File::read(tempwav.mFile, &chunk, 1u, 8u, 0);
  if ( result )
    return result;
  if ( !FMOD_strncmp((const char *)&chunk, "RIFF", 4) )
  {
    result = FMOD::File::read(this->mFile, wave, 1u, 4u, 0);
    if ( result )
      return result;
    if ( !FMOD_strncmp(wave, "WAVE", 4) )
    {
      v9 = FMOD::CodecWav::parseChunk(&tempwav, chunk.size);
      mSrcFormat = tempwav.mSrcFormat;
      if ( v9 )
      {
        if ( !tempwav.mSrcFormat )
          goto LABEL_4;
      }
      else
      {
        if ( !tempwav.mSrcFormat )
          goto LABEL_4;
        if ( tempwav.mSrcDataOffset != -1 )
        {
          wFormatTag = tempwav.mSrcFormat->Format.wFormatTag;
          if ( wFormatTag != 85 && wFormatTag != 80 )
          {
            FMOD::MemPool::free(
              off_286F358->gSystemMemPool,
              tempwav.mSrcFormat,
              "../../../core_api/src/fmod_codec_mpeg.cpp",
              392);
            return FMOD_RESULT::FMOD_ERR_FORMAT_0;
          }
          this->mSrcDataOffset = tempwav.mSrcDataOffset;
          lengthbytes = tempwav.waveformat->lengthbytes;
          *(_QWORD *)this->mLoopPoints = *(_QWORD *)tempwav.mLoopPoints;
          this->mSyncPoint = tempwav.mSyncPoint;
          this->mNumSyncPoints = tempwav.mNumSyncPoints;
          FMOD::MemPool::free(off_286F358->gSystemMemPool, mSrcFormat, "../../../core_api/src/fmod_codec_mpeg.cpp", 392);
          goto LABEL_4;
        }
      }
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        tempwav.mSrcFormat,
        "../../../core_api/src/fmod_codec_mpeg.cpp",
        402);
    }
  }
LABEL_4:
  v4 = lengthbytes;
  if ( lengthbytes )
  {
    manualsizecalc = 0;
  }
  else
  {
    result = (*((unsigned int (__fastcall **)(FMOD::File *, unsigned int *))this->mFile->_vptr_File + 3))(
               this->mFile,
               &lengthbytes);
    if ( result )
      return result;
    v4 = lengthbytes;
    manualsizecalc = 1;
  }
  memset(&tempwav, 0, 0x48D0u);
  this->mContext = (FMOD::CodecMPEG_Context *)&tempwav;
  this->mHasXingNumFrames = 0;
  this->mHasXingToc = 0;
  v44[584] = v44;
  v5 = 0;
  v46 = -1;
  v45 = 1;
  v6 = v4;
  while ( 2 )
  {
    if ( v6 > 0x1000 && (usermodea & 0x8000) == 0 )
      v6 = 4096;
    if ( v5 >= v6 )
    {
LABEL_24:
      this->mContext = 0;
      return FMOD_RESULT::FMOD_ERR_FORMAT_0;
    }
    mSrcDataOffset = this->mSrcDataOffset;
    while ( 1 )
    {
      result = FMOD::File::seek(this->mFile, mSrcDataOffset, 0);
      if ( result != FMOD_RESULT::FMOD_ERR_FILE_COULDNOTSEEK_0 )
      {
        if ( result )
          goto LABEL_23;
        result = FMOD::File::read(this->mFile, header, 1u, 4u, 0);
        if ( result )
          return result;
        this->mContext->mLayer = 0;
        if ( FMOD::CodecMPEG::decodeHeader(this, header, (int *)&tempwaveformat, (int *)&chunk, (int *)wave) == FMOD_RESULT::FMOD_OK_0 )
          break;
      }
      ++v5;
      mSrcDataOffset = this->mSrcDataOffset + 1;
      this->mSrcDataOffset = mSrcDataOffset;
      if ( v5 >= v6 )
        goto LABEL_24;
    }
    result = FMOD::File::seek(this->mFile, *(int *)wave, 1);
    if ( result )
      return result;
    result = FMOD::File::read(this->mFile, header, 1u, 4u, 0);
    if ( result == FMOD_RESULT::FMOD_ERR_FILE_EOF_0 )
    {
      name = (int)tempwaveformat.name;
      v13 = *(_DWORD *)chunk.id;
      v14 = this;
    }
    else
    {
      v8 = (int)tempwaveformat.name;
      lastchannels = *(_DWORD *)chunk.id;
      if ( result )
      {
LABEL_23:
        this->mContext = 0;
        return result;
      }
      if ( FMOD::CodecMPEG::decodeHeader(this, header, (int *)&tempwaveformat, (int *)&chunk, 0)
        || LODWORD(tempwaveformat.name) != v8
        || *(_DWORD *)chunk.id != lastchannels )
      {
        ++this->mSrcDataOffset;
        v6 = lengthbytes;
        continue;
      }
      v14 = this;
      v13 = lastchannels;
      name = (int)tempwaveformat.name;
    }
    break;
  }
  mContext = v14->mContext;
  v16 = 56;
  p_mWaveFormat = &v14->mWaveFormat;
  mContext->mFrameSizeOld = -1;
  mContext->mSynthBo = 1;
  mContext->mLayer = 0;
  if ( (((_BYTE)v14 - 88) & 1) != 0 )
  {
    LOBYTE(v14->mWaveFormat.name) = 0;
    p_mWaveFormat = (FMOD_CODEC_WAVEFORMAT *)((char *)&v14->mWaveFormat.name + 1);
    LOBYTE(v16) = 55;
  }
  if ( ((unsigned __int8)p_mWaveFormat & 2) != 0 )
  {
    p_mWaveFormat = (FMOD_CODEC_WAVEFORMAT *)((char *)p_mWaveFormat + 2);
    v16 -= 2;
    HIWORD(p_mWaveFormat[-1].peakvolume) = 0;
  }
  if ( ((unsigned __int8)p_mWaveFormat & 4) != 0 )
  {
    LODWORD(p_mWaveFormat->name) = 0;
    v16 -= 4;
    p_mWaveFormat = (FMOD_CODEC_WAVEFORMAT *)((char *)p_mWaveFormat + 4);
  }
  v18 = v16 >> 3;
  memset(p_mWaveFormat, 0, 8 * v18);
  v19 = &p_mWaveFormat->name + v18;
  if ( (v16 & 4) != 0 )
  {
    *(_DWORD *)v19 = 0;
    v19 = (const char **)((char *)v19 + 4);
  }
  if ( (v16 & 2) != 0 )
  {
    v19 = (const char **)((char *)v19 + 2);
    *((_WORD *)v19 - 1) = 0;
  }
  if ( (v16 & 1) != 0 )
    *(_BYTE *)v19 = 0;
  *(_DWORD *)wave += 4;
  v20 = lengthbytes;
  v14->waveformat = &v14->mWaveFormat;
  v14->mWaveFormat.frequency = name;
  v14->mWaveFormat.channels = v13;
  v21 = !FMOD::CodecMPEG::gInitialized;
  v14->mWaveFormat.lengthbytes = v20;
  if ( v21 )
  {
    FMOD::CodecMPEG::initAll();
    FMOD::CodecMPEG::gInitialized = 1;
  }
  result = FMOD::File::seek(v14->mFile, v14->mSrcDataOffset, 0);
  if ( result
    || (result = FMOD::File::read(v14->mFile, in, 1u, *(unsigned int *)wave, 0)) != FMOD_RESULT::FMOD_OK_0
    || FMOD::CodecMPEG::decodeXingHeader(v14, in, v14->mXingToc, &v14->mNumFrames) == FMOD_RESULT::FMOD_OK_0
    && (v22 = *(_DWORD *)wave,
        v14->mSrcDataOffset += *(_DWORD *)wave,
        (result = FMOD::File::read(v14->mFile, in, 1u, v22, 0)) != FMOD_RESULT::FMOD_OK_0) )
  {
    v14->mContext = 0;
    return result;
  }
  waveformat = v14->waveformat;
  format = waveformat->format;
  waveformat->format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
  FMOD::CodecMPEG::decodeFrame(v14, in, out, &v14->mPCMFrameLength);
  v25 = v14->mSrcDataOffset;
  mFile = v14->mFile;
  v14->waveformat->format = format;
  result = FMOD::File::seek(mFile, v25, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( !v14->mPCMFrameLength )
      v14->mPCMFrameLength = 1152;
    v27 = (*(_DWORD *)wave + 1) & 0xFFFFFFFE;
    *(_DWORD *)wave = v27;
    if ( (usermodea & 0x4000) != 0 )
    {
      v28 = v14->mFile;
      if ( (v28->mFlags & 1) != 0 )
      {
        FMOD::File::seek(v28, v14->mSrcDataOffset, 0);
        result = FMOD::CodecMPEG::getPCMLength(v14);
        if ( result )
          return result;
        goto LABEL_61;
      }
    }
    v33 = v14->waveformat;
    v34 = v33->lengthbytes;
    if ( v34 != -1 )
    {
      if ( !v14->mHasXingNumFrames )
      {
        v33->lengthpcm = v14->mPCMFrameLength * ((v27 + v34 - 1) / v27 + 1);
        v14->mFlags &= ~1u;
LABEL_61:
        if ( manualsizecalc )
        {
          v29 = v14->waveformat;
          v30 = v29->lengthbytes;
          if ( v30 != -1 )
            v29->lengthbytes = v30 - v14->mSrcDataOffset;
        }
        mFrameOffset = v14->mFrameOffset;
        if ( mFrameOffset )
        {
          if ( (usermodea & 0x4000) == 0 )
          {
            FMOD::MemPool::free(
              off_286F358->gSystemMemPool,
              mFrameOffset,
              "../../../core_api/src/fmod_codec_mpeg.cpp",
              640);
            v14->mFrameOffset = 0;
            v14->mNumFrames = 0;
          }
        }
        v32 = v14->waveformat;
        v14->mContext = 0;
        v32->format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
        v32->pcmblocksize = 1152;
        return FMOD::CodecMPEG::resetFrame(v14);
      }
      v34 = 1152 * v14->mNumFrames;
    }
    v33->lengthpcm = v34;
    goto LABEL_61;
  }
  return result;
}


// Address: 0x21d1a50 | Name: j__ZN4FMOD9CodecMPEG12openInternalEjP22FMOD_CREATESOUNDEXINFO
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::openInternal(
        FMOD_CODEC_STATE *codec,
        FMOD_MODE usermode,
        FMOD_CREATESOUNDEXINFO *userexinfo)
{
  return _ZN4FMOD9CodecMPEG12openInternalEjP22FMOD_CREATESOUNDEXINFO(
           (FMOD::CodecMPEG *const)codec,
           usermode,
           userexinfo);
}


// Address: 0x21d1a60 | Name: _ZN4FMOD9CodecMPEG13closeInternalEv
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::closeInternal(FMOD::CodecMPEG *const this)
{
  unsigned int *mFrameOffset; // rsi

  mFrameOffset = this->mFrameOffset;
  if ( mFrameOffset )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mFrameOffset, "../../../core_api/src/fmod_codec_mpeg.cpp", 669);
    this->mFrameOffset = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d1ab0 | Name: j__ZN4FMOD9CodecMPEG13closeInternalEv
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::closeInternal(FMOD_CODEC_STATE *codec)
{
  return _ZN4FMOD9CodecMPEG13closeInternalEv((FMOD::CodecMPEG *const)codec);
}


// Address: 0x21d1ac0 | Name: _ZN4FMOD9CodecMPEG12readInternalEPvjPj
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::readInternal(
        FMOD::CodecMPEG *const this,
        void *buffer,
        unsigned int samples_in,
        unsigned int *samples_out)
{
  FMOD::CodecMPEG *v4; // rbx
  int *p_mpegrate; // r13
  int channels; // eax
  FMOD_RESULT_0 v7; // r12d
  unsigned __int32 v8; // eax
  FMOD::File *mFile; // rdi
  int *v10; // rax
  FMOD::File *v11; // rdi
  FMOD_RESULT_0 v12; // r10d
  FMOD_RESULT_0 v13; // eax
  FMOD_CODEC_WAVEFORMAT *waveformat; // rcx
  __int64 v15; // rax
  int *v16; // rax
  FMOD::CodecMPEG *v17; // r13
  int *v18; // rbx
  int *v19; // rax
  int retriesa; // [rsp+14h] [rbp-784h]
  int retries; // [rsp+14h] [rbp-784h]
  int channel; // [rsp+28h] [rbp-770h]
  int numstreams; // [rsp+2Ch] [rbp-76Ch]
  FMOD::CodecMPEG_Context *context_original; // [rsp+30h] [rbp-768h]
  int mpegchannels; // [rsp+4Ch] [rbp-74Ch] BYREF
  int mpegrate; // [rsp+50h] [rbp-748h] BYREF
  int framesize; // [rsp+54h] [rbp-744h] BYREF
  unsigned int oldpos; // [rsp+58h] [rbp-740h] BYREF
  float rate; // [rsp+5Ch] [rbp-73Ch] BYREF
  char readbuffer[1848]; // [rsp+60h] [rbp-738h] BYREF

  v4 = this;
  channel = 0;
  context_original = this->mContext;
  p_mpegrate = &mpegrate;
  channels = this->waveformat->channels;
  *samples_out = 0;
  numstreams = (channels + 1) / 2;
  do
  {
    mpegchannels = 0;
    mpegrate = 0;
    framesize = 0;
    memset(readbuffer, 0, 0x700u);
    if ( numstreams > 1 )
      v4->mContext = &context_original[channel / 2];
    v16 = p_mpegrate;
    v17 = v4;
    retries = 0;
    v18 = v16;
    while ( 1 )
    {
      v7 = FMOD::File::read(v17->mFile, readbuffer, 1u, 4u, 0);
      if ( v7 )
      {
LABEL_34:
        v19 = v18;
        v4 = v17;
        v12 = v7;
        p_mpegrate = v19;
        waveformat = v4->waveformat;
        goto LABEL_15;
      }
      if ( !retries )
      {
        if ( FMOD::CodecMPEG::decodeHeader(v17, readbuffer, v18, &mpegchannels, &framesize) == FMOD_RESULT::FMOD_OK_0 )
          break;
        goto LABEL_29;
      }
      v17->mContext->mLayer = 0;
      if ( FMOD::CodecMPEG::decodeHeader(v17, readbuffer, v18, &mpegchannels, &framesize) == FMOD_RESULT::FMOD_OK_0 )
      {
        v7 = FMOD::File::tell(v17->mFile, &oldpos);
        if ( v7 )
          goto LABEL_34;
        v7 = FMOD::File::seek(v17->mFile, framesize, 1);
        if ( v7 )
          goto LABEL_34;
        v7 = FMOD::File::read(v17->mFile, &rate, 1u, 4u, 0);
        if ( v7 )
          goto LABEL_34;
        v8 = _byteswap_ulong(LODWORD(rate));
        rate = *(float *)&v8;
        if ( (v8 & 0xFFE00000) == 0xFFE00000 )
        {
          if ( v17->mContext->mFrame.lay != 4 - ((v8 >> 17) & 3) )
            v7 = FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
        }
        else
        {
          v7 = FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
        }
        mFile = v17->mFile;
        if ( (mFile->mFlags & 1) != 0 )
          FMOD::File::seek(mFile, oldpos, 0);
        if ( v7 == FMOD_RESULT::FMOD_OK_0 )
          break;
      }
LABEL_29:
      if ( FMOD_strncmp(readbuffer, "TAG", 3) )
      {
        Roblox_SetCodecParsingAnomaly(v17, 1);
        return FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
      }
      FMOD::File::seek(v17->mFile, 124, 1);
      ++retries;
    }
    v10 = v18;
    v4 = v17;
    v11 = v17->mFile;
    p_mpegrate = v10;
    v12 = FMOD::File::read(v11, &readbuffer[4], 1u, framesize, 0);
    if ( v12 )
      break;
    v13 = FMOD::CodecMPEG::decodeFrame(v4, (unsigned __int8 *)readbuffer, buffer, (unsigned int *)&rate);
    waveformat = v4->waveformat;
    v12 = FMOD_RESULT::FMOD_OK_0;
    if ( v13 )
      mpegchannels = waveformat->channels;
    *samples_out += LODWORD(rate) / numstreams;
LABEL_15:
    if ( mpegrate && mpegrate != waveformat->frequency )
    {
      retriesa = v12;
      rate = (float)mpegrate;
      FMOD::Codec::metaData(
        v4,
        FMOD_TAGTYPE::FMOD_TAGTYPE_FMOD,
        "Sample Rate Change",
        &rate,
        4u,
        FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_FLOAT,
        1);
      waveformat = v4->waveformat;
      v12 = retriesa;
      waveformat->frequency = mpegrate;
    }
    v15 = 1;
    if ( mpegchannels )
      v15 = mpegchannels;
    channel += v15;
    if ( buffer )
      buffer = (char *)buffer + 2 * v15;
  }
  while ( channel < waveformat->channels );
  v4->mContext = context_original;
  return v12;
}


// Address: 0x21d1e90 | Name: j__ZN4FMOD9CodecMPEG12readInternalEPvjPj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::readInternal(
        FMOD_CODEC_STATE *codec,
        void *buffer,
        unsigned int samples_in,
        unsigned int *samples_out)
{
  return _ZN4FMOD9CodecMPEG12readInternalEPvjPj((FMOD::CodecMPEG *const)codec, buffer, samples_in, samples_out);
}


// Address: 0x21d1ea0 | Name: _ZN4FMOD9CodecMPEG19setPositionInternalEijj
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::setPositionInternal(
        FMOD::CodecMPEG *const this,
        int subsound,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  unsigned int mPCMFrameLength; // edi
  unsigned int v6; // ebx
  __int64 v7; // rcx
  unsigned int v8; // eax
  unsigned int *mFrameOffset; // rax
  unsigned int mNumFrames; // edx
  int v11; // eax
  signed int lengthbytes; // edi
  unsigned int mSrcDataOffset; // esi
  unsigned int v14; // eax
  FMOD_RESULT_0 result; // eax
  FMOD::FMOD_CODEC_FLAG mFlags; // eax
  unsigned int v17; // r12d
  unsigned int v18; // esi
  unsigned int v19; // edx
  bool v20; // cf
  FMOD_CODEC_WAVEFORMAT *waveformat; // rax
  float v22; // xmm1_4
  float v23; // xmm2_4
  int v24; // edx
  float v25; // xmm0_4
  float v26; // xmm1_4
  FMOD_CODEC_WAVEFORMAT *v27; // r8
  int v28; // eax
  int v29; // edx
  unsigned int v30; // esi
  int v31; // eax
  unsigned int read[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  if ( postype == 8 )
    return FMOD::File::seek(this->mFile, this->mSrcDataOffset + position, 0);
  mPCMFrameLength = this->mPCMFrameLength;
  v6 = 0;
  v7 = position / mPCMFrameLength;
  if ( position )
  {
    v8 = (this->mFlags & 2) == 0 ? 9 : 3;
    if ( v8 > (unsigned int)v7 )
      v8 = position / mPCMFrameLength;
    v7 = (unsigned int)v7 - v8;
    v6 = mPCMFrameLength * v8 + position % mPCMFrameLength;
  }
  if ( (this->mMode & 0x4000) != 0 )
  {
    mFrameOffset = this->mFrameOffset;
    if ( mFrameOffset )
    {
      mNumFrames = this->mNumFrames;
      if ( (unsigned int)v7 > mNumFrames )
        v7 = mNumFrames - 1;
      v11 = mFrameOffset[v7];
      lengthbytes = this->waveformat->lengthbytes;
      goto LABEL_11;
    }
  }
  if ( this->mHasXingToc )
  {
    waveformat = this->waveformat;
    v22 = 0.0;
    if ( position <= v6 )
      goto LABEL_40;
    v22 = (float)((float)(int)(position - v6) / (float)(int)waveformat->lengthpcm) * 100.0;
    if ( v22 < 0.0 )
    {
      v22 = 0.0;
      v23 = (float)this->mXingToc[0];
      v24 = 0;
      goto LABEL_33;
    }
    if ( v22 <= 100.0 )
    {
LABEL_40:
      v24 = (int)v22;
      if ( (int)v22 <= 99 )
      {
        v23 = (float)this->mXingToc[v24];
        if ( v24 == 99 )
        {
          v26 = v22 - 99.0;
          v25 = 256.0;
          goto LABEL_34;
        }
LABEL_33:
        v25 = (float)*((unsigned __int8 *)&this->numsubsounds + v24 + 513);
        v26 = v22 - (float)v24;
LABEL_34:
        lengthbytes = waveformat->lengthbytes;
        v11 = (int)(float)((float)((float)((float)((float)(v25 - v23) * v26) + v23) * 0.00390625) * (float)lengthbytes);
        goto LABEL_11;
      }
      v26 = v22 - 99.0;
    }
    else
    {
      v26 = 1.0;
    }
    v25 = 256.0;
    v23 = (float)this->mXingToc[99];
    goto LABEL_34;
  }
  if ( position <= v6 )
  {
    lengthbytes = this->waveformat->lengthbytes;
    v11 = 0;
  }
  else
  {
    v27 = this->waveformat;
    v28 = v27->lengthpcm / mPCMFrameLength;
    lengthbytes = v27->lengthbytes;
    v29 = v28 - 1;
    v30 = v28;
    v31 = 0;
    if ( (this->mFlags & 2) == 0 )
      v31 = v29;
    v11 = v7 * ((lengthbytes + v31) / v30);
  }
LABEL_11:
  mSrcDataOffset = this->mSrcDataOffset;
  v14 = mSrcDataOffset + v11;
  if ( v14 <= mSrcDataOffset + lengthbytes )
    mSrcDataOffset = v14;
  result = FMOD::File::seek(this->mFile, mSrcDataOffset, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mFlags = this->mFlags;
    if ( (mFlags & 2) == 0 )
      this->mFlags = mFlags | 4;
    while ( v6 )
    {
      v17 = 1152;
      if ( v6 < 0x480 )
        v17 = v6;
      read[0] = 0;
      result = FMOD::Codec::read(this, 0, v17, read);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v18 = read[0];
        if ( !read[0] )
        {
          read[0] = v17;
          v18 = v17;
        }
        v19 = v6 - v18;
        v20 = v6 < v18;
        v6 = 0;
        if ( !v20 )
          v6 = v19;
        if ( this->mPCMBuffer && this->mPCMBufferLength || v6 >= v18 )
          continue;
      }
      goto LABEL_27;
    }
    result = FMOD_RESULT::FMOD_OK_0;
LABEL_27:
    this->mFlags &= ~4u;
  }
  return result;
}


// Address: 0x21d2160 | Name: j__ZN4FMOD9CodecMPEG19setPositionInternalEijj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::setPositionInternal(
        FMOD_CODEC_STATE *codec,
        int subsound,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  return _ZN4FMOD9CodecMPEG19setPositionInternalEijj((FMOD::CodecMPEG *const)codec, subsound, position, postype);
}


// Address: 0x21d2170 | Name: _ZN4FMOD9CodecMPEG22getContextInfoInternalEiPjS1_S1_Pv
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::getContextInfoInternal(
        FMOD::CodecMPEG *const this,
        int numchannels,
        unsigned int *contextsize,
        unsigned int *pcmframesize,
        FMOD_MEMORY_TYPE *memtype,
        void *dspcodecpool_contextdata)
{
  unsigned int *contextsizea; // [rsp+10h] [rbp-18h]
  unsigned int *pcmframesizea; // [rsp+18h] [rbp-10h]

  if ( !FMOD::CodecMPEG::gInitialized )
  {
    pcmframesizea = pcmframesize;
    contextsizea = contextsize;
    FMOD::CodecMPEG::initAll();
    FMOD::CodecMPEG::gInitialized = 1;
    pcmframesize = pcmframesizea;
    contextsize = contextsizea;
  }
  if ( contextsize )
    *contextsize = 18640 * ((numchannels + 1) / 2);
  if ( pcmframesize )
    *pcmframesize = 1152;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d21e0 | Name: j__ZN4FMOD9CodecMPEG22getContextInfoInternalEiPjS1_S1_Pv
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::getContextInfoInternal(
        FMOD_CODEC_STATE *codec,
        int numchannels,
        unsigned int *contextsize,
        unsigned int *pcmframesize,
        FMOD_MEMORY_TYPE *memtype,
        void *dspcodecpool_contextdata)
{
  return _ZN4FMOD9CodecMPEG22getContextInfoInternalEiPjS1_S1_Pv(
           (FMOD::CodecMPEG *const)codec,
           numchannels,
           contextsize,
           pcmframesize,
           memtype,
           dspcodecpool_contextdata);
}


// Address: 0x21d21f0 | Name: _ZN4FMOD9CodecMPEG20setupContextInternalEiiiPvPNS_5CodecES1_
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::setupContextInternal(
        FMOD::CodecMPEG *const this,
        int numchannels,
        int frequency,
        int subsound,
        void *contextmemory,
        FMOD::Codec_0 *sourcecodec,
        void *dspcodecpool_contextdata)
{
  this->mContext = (FMOD::CodecMPEG_Context *)contextmemory;
  this->mPCMFrameLength = 1152;
  this->mChannels = numchannels;
  return FMOD::CodecMPEG::resetFrame(this);
}


// Address: 0x21d2210 | Name: j__ZN4FMOD9CodecMPEG20setupContextInternalEiiiPvPNS_5CodecES1_
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::setupContextInternal(
        FMOD_CODEC_STATE *codec,
        int numchannels,
        int frequency,
        int subsound,
        void *contextmemory,
        FMOD::Codec_0 *sourcecodec,
        void *dspcodecpool_contextdata)
{
  return _ZN4FMOD9CodecMPEG20setupContextInternalEiiiPvPNS_5CodecES1_(
           (FMOD::CodecMPEG *const)codec,
           numchannels,
           frequency,
           subsound,
           contextmemory,
           sourcecodec,
           dspcodecpool_contextdata);
}


// Address: 0x21d2220 | Name: _ZN4FMOD9CodecMPEG19soundCreateInternalEiP10FMOD_SOUND
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::soundCreateInternal(
        FMOD::CodecMPEG *const this,
        int subsound,
        FMOD_SOUND *sound)
{
  int mNumSyncPoints; // edx
  FMOD::SyncPointNamed *mSyncPoint; // rax
  __int64 v6; // rbp
  int v7; // ebx
  char *v9; // rax

  mNumSyncPoints = this->mNumSyncPoints;
  if ( mNumSyncPoints )
  {
    mSyncPoint = this->mSyncPoint;
    if ( mSyncPoint )
    {
      v6 = 0;
      v7 = 0;
      if ( mNumSyncPoints > 0 )
      {
        while ( 1 )
        {
          v9 = (char *)mSyncPoint + v6;
          ++v7;
          v6 += 312;
          (*(void (__fastcall **)(FMOD_SOUND *, _QWORD, __int64, _QWORD, _QWORD, _QWORD, _DWORD))(*(_QWORD *)sound
                                                                                                + 264LL))(
            sound,
            *((unsigned int *)v9 + 11),
            2,
            *(_QWORD *)(v9 + 28),
            0,
            0,
            0);
          if ( this->mNumSyncPoints <= v7 )
            break;
          mSyncPoint = this->mSyncPoint;
        }
      }
      FMOD::SoundI::syncPointFixIndicies((FMOD::SoundI *const)sound);
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        this->mSyncPoint,
        "../../../core_api/src/fmod_codec_mpeg.cpp",
        1136);
      this->mSyncPoint = 0;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d22f0 | Name: j__ZN4FMOD9CodecMPEG19soundCreateInternalEiP10FMOD_SOUND
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::soundCreateInternal(FMOD_CODEC_STATE *codec, int subsound, FMOD_SOUND *sound)
{
  return _ZN4FMOD9CodecMPEG19soundCreateInternalEiP10FMOD_SOUND((FMOD::CodecMPEG *const)codec, subsound, sound);
}


