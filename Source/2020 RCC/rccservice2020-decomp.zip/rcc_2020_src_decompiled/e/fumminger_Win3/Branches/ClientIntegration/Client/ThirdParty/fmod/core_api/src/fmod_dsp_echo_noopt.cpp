// Address: 0x21c5760 | Name: FMOD_DSP_Echo_Process_NoOpt
void __fastcall FMOD_DSP_Echo_Process_NoOpt(
        float *outbuffer,
        float *inbuffer,
        __int16 *delaybuffermem,
        int delayread_in,
        int delaywrite_in,
        unsigned int *delayread_out,
        float wetmix,
        float drymix,
        float feedback,
        unsigned int *delaywrite_out,
        signed int delaybufferlen,
        int length_in,
        int channels)
{
  int v16; // r14d
  __int64 v17; // r13
  int v18; // r15d
  __int64 v19; // rbx
  signed int v20; // eax
  unsigned int v21; // r12d
  int v22; // eax
  int v23; // r12d
  __int16 *v24; // r9
  __int16 *v25; // r10
  float *v26; // rdi
  float *v27; // rsi
  int v28; // r11d
  __int64 v29; // rax
  int v30; // ecx
  float v31; // xmm0_4
  float v32; // xmm3_4
  float v33; // xmm0_4
  __int64 v34; // rax
  int v35; // ebp
  signed int v36; // eax
  unsigned int v37; // r10d
  int v38; // eax
  int v39; // r10d
  __int64 v40; // rax
  int v41; // r9d
  float v42; // xmm0_4
  float v43; // xmm3_4
  float v44; // xmm0_4
  __int64 v45; // rax
  int v46; // eax
  int v47; // eax
  int v48; // r14d
  signed int v49; // r8d
  unsigned int v50; // r13d
  int v51; // r8d
  int v52; // r13d
  __int16 *v53; // r9
  __int16 *v54; // rbx
  float *v55; // r11
  float *v56; // r10
  __int64 v57; // r8
  __int16 *v58; // r12
  float v59; // xmm3_4
  int v60; // ebp
  float v61; // xmm11_4
  float v62; // xmm0_4
  float v63; // xmm1_4
  float v64; // xmm2_4
  float v65; // xmm11_4
  float v66; // xmm0_4
  __int64 v67; // r8
  int v68; // r12d
  signed int v70; // eax
  unsigned int v71; // ebp
  int v72; // eax
  int v73; // ebp
  __int16 *v74; // r10
  __int16 *v75; // rax
  float *v76; // r9
  __int64 v77; // r15
  __int16 *v78; // rbx
  float *v79; // rcx
  float v80; // xmm13_4
  float v81; // xmm12_4
  float v82; // xmm7_4
  float v83; // xmm3_4
  float v84; // xmm5_4
  float v85; // xmm2_4
  int v86; // r11d
  float v87; // xmm8_4
  float v88; // xmm15_4
  float v89; // xmm7_4
  float v90; // xmm4_4
  float v91; // xmm6_4
  float v92; // xmm8_4
  float v93; // xmm2_4
  float v94; // xmm15_4
  float v95; // xmm5_4
  float v96; // xmm8_4
  float v97; // xmm15_4
  float v98; // xmm4_4
  float v99; // xmm15_4
  float v100; // xmm3_4
  float v101; // xmm8_4
  float v102; // xmm15_4
  float v103; // xmm2_4
  int v104; // ecx
  int v105; // eax
  int v106; // r12d
  signed int v110; // eax
  unsigned int v111; // ebp
  int v112; // eax
  int v113; // ebp
  __int16 *v114; // r9
  __int16 *v115; // r10
  float *v116; // rcx
  float *v117; // rax
  int v118; // r11d
  float v119; // xmm5_4
  float v120; // xmm4_4
  float v121; // xmm15_4
  float v122; // xmm6_4
  float v123; // xmm3_4
  float v124; // xmm7_4
  float v125; // xmm2_4
  float v126; // xmm1_4
  float v127; // xmm0_4
  int v128; // ebx
  float v129; // xmm0_4
  float v130; // xmm6_4
  float v131; // xmm5_4
  float v132; // xmm4_4
  float v133; // xmm3_4
  float v134; // xmm2_4
  float v135; // xmm15_4
  float v136; // xmm1_4
  float v137; // xmm8_4
  float v138; // xmm15_4
  float v139; // xmm0_4
  __int64 v140; // rax
  int v141; // ecx
  int v142; // eax
  float *in1; // [rsp+0h] [rbp-60h]
  float in1a; // [rsp+0h] [rbp-60h]
  float in1b; // [rsp+0h] [rbp-60h]
  float *in2; // [rsp+8h] [rbp-58h]
  float in2a; // [rsp+8h] [rbp-58h]
  float in2b; // [rsp+8h] [rbp-58h]
  float in3; // [rsp+10h] [rbp-50h]
  float in3a; // [rsp+10h] [rbp-50h]
  float in4; // [rsp+18h] [rbp-48h]
  float in5; // [rsp+1Ch] [rbp-44h]
  float in6; // [rsp+20h] [rbp-40h]
  float in7; // [rsp+24h] [rbp-3Ch]

  v16 = delayread_in;
  switch ( channels )
  {
    case 1:
      if ( !length_in )
        goto LABEL_34;
      v35 = length_in;
      while ( 1 )
      {
        v36 = v35 + delayread_in;
        v37 = v35 + delaywrite_in;
        if ( v35 + delayread_in > (unsigned int)delaybufferlen )
          v36 = delaybufferlen;
        v38 = v36 - delayread_in;
        if ( v37 > delaybufferlen )
          v37 = delaybufferlen;
        v39 = v37 - delaywrite_in;
        if ( v39 > v38 )
          v39 = v38;
        if ( v39 > 0 )
        {
          v40 = 0;
          do
          {
            LOWORD(v41) = 0x7FFF;
            v42 = (float)delaybuffermem[(unsigned int)delayread_in + v40] * 0.000030518509;
            v43 = v42 * wetmix;
            v44 = (float)(v42 * feedback) + inbuffer[v40];
            outbuffer[v40] = (float)(inbuffer[v40] * drymix) + v43;
            if ( v44 <= 1.0 )
            {
              LOWORD(v41) = 0x8000;
              if ( v44 >= -1.0 )
                v41 = (int)(float)(v44 * 32767.0);
            }
            delaybuffermem[(unsigned int)delaywrite_in + v40++] = v41;
          }
          while ( v39 > (int)v40 );
          v45 = 4LL * (unsigned int)(v39 - 1) + 4;
          inbuffer = (float *)((char *)inbuffer + v45);
          outbuffer = (float *)((char *)outbuffer + v45);
        }
        delayread_in += v39;
        if ( delayread_in >= 0 )
          goto LABEL_54;
        do
          delayread_in += delaybufferlen;
        while ( delayread_in < 0 );
        if ( delayread_in >= delaybufferlen )
          break;
LABEL_55:
        v46 = v39 + delaywrite_in;
        if ( v39 + delaywrite_in < 0 )
        {
          do
            v46 += delaybufferlen;
          while ( v46 < 0 );
          if ( v46 < delaybufferlen )
            goto LABEL_60;
          goto LABEL_58;
        }
        while ( v46 >= delaybufferlen )
LABEL_58:
          v46 -= delaybufferlen;
LABEL_60:
        v35 -= v39;
        delaywrite_in = v46;
        if ( !v35 )
        {
          v16 = delayread_in;
          goto LABEL_34;
        }
      }
      while ( 1 )
      {
        delayread_in -= delaybufferlen;
LABEL_54:
        if ( delayread_in < delaybufferlen )
          goto LABEL_55;
      }
    case 2:
      if ( !length_in )
        goto LABEL_34;
      v47 = delaywrite_in;
      v48 = length_in;
      while ( 1 )
      {
        v49 = v48 + delayread_in;
        v50 = v48 + v47;
        if ( v48 + delayread_in > (unsigned int)delaybufferlen )
          v49 = delaybufferlen;
        v51 = v49 - delayread_in;
        if ( v50 > delaybufferlen )
          v50 = delaybufferlen;
        v52 = v50 - v47;
        if ( v52 > v51 )
          v52 = v51;
        v53 = &delaybuffermem[2 * delayread_in];
        v54 = &delaybuffermem[2 * v47];
        if ( v52 > 0 )
        {
          v55 = inbuffer;
          v56 = outbuffer;
          v57 = (unsigned int)(v52 - 1) + 1LL;
          v58 = &v53[2 * v57];
          do
          {
            v59 = v55[1];
            LOWORD(v60) = 0x7FFF;
            v61 = (float)*v53 * 0.000030518509;
            v62 = (float)v53[1] * 0.000030518509;
            v63 = (float)(v61 * feedback) + *v55;
            v64 = (float)(*v55 * drymix) + (float)(v61 * wetmix);
            v65 = v62 * wetmix;
            *v56 = v64;
            v66 = (float)(v62 * feedback) + v59;
            v56[1] = (float)(v59 * drymix) + v65;
            if ( v63 <= 1.0 )
            {
              LOWORD(v60) = 0x8000;
              if ( v63 >= -1.0 )
                v60 = (int)(float)(v63 * 32767.0);
            }
            *v54 = v60;
            LOWORD(v60) = 0x7FFF;
            if ( v66 <= 1.0 )
            {
              LOWORD(v60) = 0x8000;
              if ( v66 >= -1.0 )
                v60 = (int)(float)(v66 * 32767.0);
            }
            v53 += 2;
            v54[1] = v60;
            v55 += 2;
            v56 += 2;
            v54 += 2;
          }
          while ( v53 != v58 );
          v67 = 8 * v57;
          inbuffer = (float *)((char *)inbuffer + v67);
          outbuffer = (float *)((char *)outbuffer + v67);
        }
        delayread_in += v52;
        if ( delayread_in >= 0 )
          goto LABEL_84;
        do
          delayread_in += delaybufferlen;
        while ( delayread_in < 0 );
        if ( delayread_in >= delaybufferlen )
          break;
LABEL_85:
        v47 += v52;
        if ( v47 < 0 )
        {
          do
            v47 += delaybufferlen;
          while ( v47 < 0 );
          if ( v47 < delaybufferlen )
            goto LABEL_90;
          goto LABEL_88;
        }
        while ( v47 >= delaybufferlen )
LABEL_88:
          v47 -= delaybufferlen;
LABEL_90:
        v48 -= v52;
        if ( !v48 )
        {
          v16 = delayread_in;
          delaywrite_in = v47;
          goto LABEL_34;
        }
      }
      while ( 1 )
      {
        delayread_in -= delaybufferlen;
LABEL_84:
        if ( delayread_in < delaybufferlen )
          goto LABEL_85;
      }
    case 6:
      if ( !length_in )
        goto LABEL_34;
      v68 = length_in;
      while ( 1 )
      {
        v70 = v68 + v16;
        v71 = v68 + delaywrite_in;
        if ( v68 + v16 > (unsigned int)delaybufferlen )
          v70 = delaybufferlen;
        v72 = v70 - v16;
        if ( v71 > delaybufferlen )
          v71 = delaybufferlen;
        v73 = v71 - delaywrite_in;
        if ( v73 > v72 )
          v73 = v72;
        v74 = &delaybuffermem[6 * v16];
        v75 = &delaybuffermem[6 * delaywrite_in];
        if ( v73 > 0 )
        {
          v76 = inbuffer;
          v77 = (unsigned int)(v73 - 1) + 1LL;
          v78 = &v75[6 * v77];
          v79 = outbuffer;
          do
          {
            in1a = v76[3];
            in2a = v76[4];
            in3 = v76[5];
            v80 = v76[1];
            v81 = v76[2];
            v82 = (float)*v74 * 0.000030518509;
            v83 = (float)v74[4];
            v84 = (float)v74[2] * 0.000030518509;
            v85 = (float)v74[5];
            LOWORD(v86) = 0x7FFF;
            v87 = (float)(*v76 * drymix) + (float)(v82 * wetmix);
            v88 = (float)v74[1] * 0.000030518509;
            v89 = (float)(v82 * feedback) + *v76;
            v90 = (float)v74[3] * 0.000030518509;
            *v79 = v87;
            v91 = (float)(v88 * feedback) + v80;
            v92 = (float)(v80 * drymix) + (float)(v88 * wetmix);
            v93 = v85 * 0.000030518509;
            v94 = v84 * wetmix;
            v79[1] = v92;
            v95 = (float)(v84 * feedback) + v81;
            v96 = (float)(v81 * drymix) + v94;
            v97 = v90;
            v79[2] = v96;
            v98 = (float)(v90 * feedback) + in1a;
            v79[3] = (float)(in1a * drymix) + (float)(v97 * wetmix);
            v99 = v83 * 0.000030518509;
            v100 = (float)((float)(v83 * 0.000030518509) * feedback) + in2a;
            v101 = (float)(in2a * drymix) + (float)(v99 * wetmix);
            v102 = v93 * wetmix;
            v79[4] = v101;
            v103 = (float)(v93 * feedback) + in3;
            v79[5] = (float)(in3 * drymix) + v102;
            if ( v89 <= 1.0 )
            {
              LOWORD(v86) = 0x8000;
              if ( v89 >= -1.0 )
                v86 = (int)(float)(v89 * 32767.0);
            }
            *v75 = v86;
            LOWORD(v86) = 0x7FFF;
            if ( v91 <= 1.0 )
            {
              LOWORD(v86) = 0x8000;
              if ( v91 >= -1.0 )
                v86 = (int)(float)(v91 * 32767.0);
            }
            v75[1] = v86;
            LOWORD(v86) = 0x7FFF;
            if ( v95 <= 1.0 )
            {
              LOWORD(v86) = 0x8000;
              if ( v95 >= -1.0 )
                v86 = (int)(float)(v95 * 32767.0);
            }
            v75[2] = v86;
            LOWORD(v86) = 0x7FFF;
            if ( v98 <= 1.0 )
            {
              LOWORD(v86) = 0x8000;
              if ( v98 >= -1.0 )
                v86 = (int)(float)(v98 * 32767.0);
            }
            v75[3] = v86;
            LOWORD(v86) = 0x7FFF;
            if ( v100 <= 1.0 )
            {
              LOWORD(v86) = 0x8000;
              if ( v100 >= -1.0 )
                v86 = (int)(float)(v100 * 32767.0);
            }
            v75[4] = v86;
            LOWORD(v86) = 0x7FFF;
            if ( v103 <= 1.0 )
            {
              LOWORD(v86) = 0x8000;
              if ( v103 >= -1.0 )
                v86 = (int)(float)(v103 * 32767.0);
            }
            v75[5] = v86;
            v75 += 6;
            v76 += 6;
            v79 += 6;
            v74 += 6;
          }
          while ( v75 != v78 );
          inbuffer += 6 * v77;
          outbuffer += 6 * v77;
        }
        v104 = v73 + v16;
        if ( v73 + v16 >= 0 )
          goto LABEL_126;
        do
          v104 += delaybufferlen;
        while ( v104 < 0 );
        if ( v104 >= delaybufferlen )
          break;
LABEL_127:
        v16 = v104;
        v105 = v73 + delaywrite_in;
        if ( v73 + delaywrite_in < 0 )
        {
          do
            v105 += delaybufferlen;
          while ( v105 < 0 );
          if ( v105 < delaybufferlen )
            goto LABEL_132;
          goto LABEL_130;
        }
        while ( v105 >= delaybufferlen )
LABEL_130:
          v105 -= delaybufferlen;
LABEL_132:
        v68 -= v73;
        delaywrite_in = v105;
        if ( !v68 )
          goto LABEL_34;
      }
      while ( 1 )
      {
        v104 -= delaybufferlen;
LABEL_126:
        if ( v104 < delaybufferlen )
          goto LABEL_127;
      }
    case 8:
      if ( !length_in )
        goto LABEL_34;
      v106 = length_in;
      while ( 1 )
      {
        v110 = v106 + v16;
        v111 = v106 + delaywrite_in;
        if ( v106 + v16 > (unsigned int)delaybufferlen )
          v110 = delaybufferlen;
        v112 = v110 - v16;
        if ( v111 > delaybufferlen )
          v111 = delaybufferlen;
        v113 = v111 - delaywrite_in;
        if ( v113 > v112 )
          v113 = v112;
        v114 = &delaybuffermem[8 * v16];
        v115 = &delaybuffermem[8 * delaywrite_in];
        if ( v113 > 0 )
        {
          v116 = inbuffer;
          v117 = outbuffer;
          v118 = 0;
          do
          {
            in1b = v116[1];
            in2b = v116[2];
            in3a = v116[3];
            in4 = v116[4];
            in6 = v116[6];
            v119 = (float)v114[2];
            in5 = v116[5];
            v120 = (float)v114[3];
            in7 = v116[7];
            v121 = (float)*v114 * 0.000030518509;
            v122 = (float)v114[1] * 0.000030518509;
            v123 = (float)v114[4];
            v124 = (float)(v121 * feedback) + *v116;
            v125 = (float)v114[5];
            v126 = (float)v114[6];
            v128 = v114[7];
            *v117 = (float)(*v116 * drymix) + (float)(v121 * wetmix);
            v127 = (float)v128;
            LOWORD(v128) = 0x7FFF;
            v117[1] = (float)(in1b * drymix) + (float)(v122 * wetmix);
            v129 = v127 * 0.000030518509;
            v117[2] = (float)(in2b * drymix) + (float)((float)(v119 * 0.000030518509) * wetmix);
            v117[3] = (float)(in3a * drymix) + (float)((float)(v120 * 0.000030518509) * wetmix);
            v117[4] = (float)(in4 * drymix) + (float)((float)(v123 * 0.000030518509) * wetmix);
            v117[5] = (float)(in5 * drymix) + (float)((float)(v125 * 0.000030518509) * wetmix);
            v130 = (float)(v122 * feedback) + in1b;
            v131 = (float)((float)(v119 * 0.000030518509) * feedback) + in2b;
            v132 = (float)((float)(v120 * 0.000030518509) * feedback) + in3a;
            v133 = (float)((float)(v123 * 0.000030518509) * feedback) + in4;
            v134 = (float)((float)(v125 * 0.000030518509) * feedback) + in5;
            v135 = v126 * 0.000030518509;
            v136 = (float)((float)(v126 * 0.000030518509) * feedback) + in6;
            v137 = (float)(in6 * drymix) + (float)(v135 * wetmix);
            v138 = v129 * wetmix;
            v117[6] = v137;
            v139 = (float)(v129 * feedback) + in7;
            v117[7] = (float)(in7 * drymix) + v138;
            if ( v124 <= 1.0 )
            {
              LOWORD(v128) = 0x8000;
              if ( v124 >= -1.0 )
                v128 = (int)(float)(v124 * 32767.0);
            }
            *v115 = v128;
            LOWORD(v128) = 0x7FFF;
            if ( v130 <= 1.0 )
            {
              LOWORD(v128) = 0x8000;
              if ( v130 >= -1.0 )
                v128 = (int)(float)(v130 * 32767.0);
            }
            v115[1] = v128;
            LOWORD(v128) = 0x7FFF;
            if ( v131 <= 1.0 )
            {
              LOWORD(v128) = 0x8000;
              if ( v131 >= -1.0 )
                v128 = (int)(float)(v131 * 32767.0);
            }
            v115[2] = v128;
            LOWORD(v128) = 0x7FFF;
            if ( v132 <= 1.0 )
            {
              LOWORD(v128) = 0x8000;
              if ( v132 >= -1.0 )
                v128 = (int)(float)(v132 * 32767.0);
            }
            v115[3] = v128;
            LOWORD(v128) = 0x7FFF;
            if ( v133 <= 1.0 )
            {
              LOWORD(v128) = 0x8000;
              if ( v133 >= -1.0 )
                v128 = (int)(float)(v133 * 32767.0);
            }
            v115[4] = v128;
            LOWORD(v128) = 0x7FFF;
            if ( v134 <= 1.0 )
            {
              LOWORD(v128) = 0x8000;
              if ( v134 >= -1.0 )
                v128 = (int)(float)(v134 * 32767.0);
            }
            v115[5] = v128;
            LOWORD(v128) = 0x7FFF;
            if ( v136 <= 1.0 )
            {
              LOWORD(v128) = 0x8000;
              if ( v136 >= -1.0 )
                v128 = (int)(float)(v136 * 32767.0);
            }
            v115[6] = v128;
            LOWORD(v128) = 0x7FFF;
            if ( v139 <= 1.0 )
            {
              LOWORD(v128) = 0x8000;
              if ( v139 >= -1.0 )
                v128 = (int)(float)(v139 * 32767.0);
            }
            ++v118;
            v115[7] = v128;
            v116 += 8;
            v117 += 8;
            v114 += 8;
            v115 += 8;
          }
          while ( v118 != v113 );
          v140 = 32 * ((unsigned int)(v113 - 1) + 1LL);
          inbuffer = (float *)((char *)inbuffer + v140);
          outbuffer = (float *)((char *)outbuffer + v140);
        }
        v141 = v113 + v16;
        if ( v113 + v16 >= 0 )
          goto LABEL_174;
        do
          v141 += delaybufferlen;
        while ( v141 < 0 );
        if ( v141 >= delaybufferlen )
          break;
LABEL_175:
        v16 = v141;
        v142 = v113 + delaywrite_in;
        if ( v113 + delaywrite_in < 0 )
        {
          do
            v142 += delaybufferlen;
          while ( v142 < 0 );
          if ( v142 < delaybufferlen )
            goto LABEL_180;
          goto LABEL_178;
        }
        while ( v142 >= delaybufferlen )
LABEL_178:
          v142 -= delaybufferlen;
LABEL_180:
        v106 -= v113;
        delaywrite_in = v142;
        if ( !v106 )
          goto LABEL_34;
      }
      while ( 1 )
      {
        v141 -= delaybufferlen;
LABEL_174:
        if ( v141 < delaybufferlen )
          goto LABEL_175;
      }
  }
  v17 = 4LL * channels;
  if ( length_in )
  {
    v18 = length_in;
    v19 = 2LL * channels;
    in1 = outbuffer;
    in2 = inbuffer;
    while ( 1 )
    {
      v20 = v18 + v16;
      v21 = v18 + delaywrite_in;
      if ( v18 + v16 > (unsigned int)delaybufferlen )
        v20 = delaybufferlen;
      v22 = v20 - v16;
      if ( v21 > delaybufferlen )
        v21 = delaybufferlen;
      v23 = v21 - delaywrite_in;
      if ( v23 > v22 )
        v23 = v22;
      v24 = &delaybuffermem[channels * v16];
      v25 = &delaybuffermem[channels * delaywrite_in];
      if ( v23 > 0 )
      {
        v26 = in2;
        v27 = in1;
        v28 = 0;
        do
        {
          if ( channels > 0 )
          {
            v29 = 0;
            do
            {
              LOWORD(v30) = 0x7FFF;
              v31 = (float)v24[v29] * 0.000030518509;
              v32 = v31 * wetmix;
              v33 = (float)(v31 * feedback) + v26[v29];
              v27[v29] = (float)(v26[v29] * drymix) + v32;
              if ( v33 <= 1.0 )
              {
                LOWORD(v30) = 0x8000;
                if ( v33 >= -1.0 )
                  v30 = (int)(float)(v33 * 32767.0);
              }
              v25[v29++] = v30;
            }
            while ( channels > (int)v29 );
          }
          ++v28;
          v26 = (float *)((char *)v26 + v17);
          v27 = (float *)((char *)v27 + v17);
          v24 = (__int16 *)((char *)v24 + v19);
          v25 = (__int16 *)((char *)v25 + v19);
        }
        while ( v28 != v23 );
        v34 = v17 * ((unsigned int)(v23 - 1) + 1LL);
        in2 = (float *)((char *)in2 + v34);
        in1 = (float *)((char *)in1 + v34);
      }
      v16 += v23;
      if ( v16 >= 0 )
        goto LABEL_27;
      do
        v16 += delaybufferlen;
      while ( v16 < 0 );
      if ( v16 >= delaybufferlen )
        break;
LABEL_28:
      delaywrite_in += v23;
      if ( delaywrite_in < 0 )
      {
        do
          delaywrite_in += delaybufferlen;
        while ( delaywrite_in < 0 );
        if ( delaywrite_in < delaybufferlen )
          goto LABEL_33;
        goto LABEL_31;
      }
      while ( delaywrite_in >= delaybufferlen )
LABEL_31:
        delaywrite_in -= delaybufferlen;
LABEL_33:
      v18 -= v23;
      if ( !v18 )
        goto LABEL_34;
    }
    while ( 1 )
    {
      v16 -= delaybufferlen;
LABEL_27:
      if ( v16 < delaybufferlen )
        goto LABEL_28;
    }
  }
LABEL_34:
  *delayread_out = v16;
  *delaywrite_out = delaywrite_in;
}


