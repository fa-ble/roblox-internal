// Address: 0x21f2300 | Name: _ZN4FMOD8DiskFile10reallyOpenEPKcPj
FMOD_RESULT_0 __fastcall FMOD::DiskFile::reallyOpen(FMOD::DiskFile *const this, const char *name, unsigned int *size)
{
  return FMOD_OS_File_Open(name, FMOD_FILE_MODE::FMOD_FILE_MODE_READ, size, &this->mHandle);
}


// Address: 0x21f2320 | Name: _ZN4FMOD8DiskFile11reallyCloseEv
FMOD_RESULT_0 __fastcall FMOD::DiskFile::reallyClose(FMOD::DiskFile *const this)
{
  return FMOD_OS_File_Close(this->mHandle);
}


// Address: 0x21f2330 | Name: _ZN4FMOD8DiskFile10reallyReadEPvjPj
FMOD_RESULT_0 __fastcall FMOD::DiskFile::reallyRead(
        FMOD::DiskFile *const this,
        void *buffer,
        unsigned int size,
        unsigned int *bytesRead)
{
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 v9; // ebx

  mSystem = this->mSystem;
  if ( !mSystem || !FMOD::Thread::isCurrentThreadInTable(mSystem->mThreadId) )
    return FMOD_OS_File_Read(this->mHandle, buffer, size, bytesRead);
  FMOD_File_SetDiskBusy(1);
  v9 = FMOD_OS_File_Read(this->mHandle, buffer, size, bytesRead);
  FMOD_File_SetDiskBusy(0);
  return v9;
}


// Address: 0x21f23c0 | Name: _ZN4FMOD8DiskFile10reallySeekEj
FMOD_RESULT_0 __fastcall FMOD::DiskFile::reallySeek(FMOD::DiskFile *const this, unsigned int pos)
{
  return FMOD_OS_File_Seek(this->mHandle, pos);
}


