// Address: 0x21eb380 | Name: _ZN4FMOD8DSPFader13calcMixOffsetEPNS_8DSPClockEy
FMOD_SINT64 __fastcall FMOD::DSPFader::calcMixOffset(
        FMOD::DSPFader *const this,
        FMOD::DSPClock *parentclock,
        FMOD_CLOCKTIME fadePoint)
{
  FMOD_CLOCKRATE mRealPitch; // eax
  FMOD_CLOCKTIME mClock; // rsi
  unsigned __int64 v5; // rcx
  bool v6; // zf
  unsigned __int64 v7; // r8
  FMOD_CLOCKTIME v8; // rax

  mRealPitch = parentclock->mRealPitch;
  mClock = parentclock->mClock;
  v5 = 1;
  v6 = mRealPitch == 0;
  v7 = mRealPitch;
  v8 = *((_QWORD *)this + 3);
  if ( !v6 )
    v5 = v7;
  if ( mClock >= v8 )
    v8 = mClock;
  if ( fadePoint >= v8 )
    return (fadePoint - v8) / v5;
  else
    return -(__int64)((v8 - fadePoint) / v5);
}


// Address: 0x21eb3c0 | Name: _ZN4FMOD8DSPFader15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPFader::releaseInternal(FMOD::DSPFader *const this)
{
  FMOD::DSPConnectionI *v1; // rsi
  FMOD_RESULT_0 result; // eax

  v1 = (FMOD::DSPConnectionI *)*((_QWORD *)this + 66);
  result = FMOD_RESULT::FMOD_OK_0;
  if ( v1 )
  {
    result = FMOD::ExpandingPool<FMOD::DSPConnectionI>::free(
               (FMOD::ExpandingPool<FMOD::DSPConnectionI> *const)(*((_QWORD *)this + 22) + 1776LL),
               v1,
               1);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      *((_QWORD *)this + 66) = 0;
  }
  return result;
}


// Address: 0x21eb400 | Name: FMOD::Fader_Release
FMOD_RESULT_0 __fastcall FMOD::Fader_Release(FMOD_DSP_STATE *state)
{
  return FMOD::DSPFader::releaseInternal((FMOD::DSPFader *const)state->instance);
}


// Address: 0x21eb410 | Name: _ZN4FMOD8DSPFader13resetInternalEbb
FMOD_RESULT_0 __fastcall FMOD::DSPFader::resetInternal(FMOD::DSPFader *const this, bool hardreset, bool resetuserdata)
{
  *((_WORD *)this + 46) |= 0x20u;
  *((_DWORD *)this + 138) = 1065353216;
  FMOD::DSPConnectionI::reset(*((FMOD::DSPConnectionI *const *)this + 66), hardreset, resetuserdata);
  *((_WORD *)this + 83) = 0;
  *((_WORD *)this + 82) = 0;
  *((_DWORD *)this + 150) = 0;
  *((_QWORD *)this + 74) = 0;
  *((_DWORD *)this + 154) = 0;
  *((_QWORD *)this + 76) = 0;
  *((_DWORD *)this + 158) = 0;
  *((_QWORD *)this + 78) = 0;
  *((_DWORD *)this + 162) = 0;
  *((_QWORD *)this + 80) = 0;
  *((_DWORD *)this + 164) = 1;
  *((_DWORD *)this + 165) = 0;
  *((_DWORD *)this + 166) = 1065353216;
  *((_DWORD *)this + 167) = 1;
  if ( hardreset )
  {
    *((_QWORD *)this + 67) = 0;
    *((_QWORD *)this + 9) = 0;
    *((_QWORD *)this + 8) = 0;
    *((_QWORD *)this + 4) = 0;
    *((_QWORD *)this + 3) = 0;
    *((_QWORD *)this + 2) = 0;
    *((_QWORD *)this + 1) = 0;
    *((_DWORD *)this + 11) = 0x100000;
    *((_DWORD *)this + 10) = 0x100000;
    *((_BYTE *)this + 80) = 0;
    *((_BYTE *)this + 48) = 0;
    *((_BYTE *)this + 49) = 0;
    *((_QWORD *)this + 7) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21eb540 | Name: _ZN4FMOD8DSPFader14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPFader::createInternal(FMOD::DSPFader *const this)
{
  char *v1; // rbp
  FMOD_RESULT_0 result; // eax

  v1 = (char *)this + 560;
  if ( this != (FMOD::DSPFader *const)-560LL )
  {
    *((_QWORD *)this + 72) = 0;
    *((_QWORD *)this + 71) = v1;
    *((_QWORD *)this + 70) = v1;
    *((_QWORD *)this + 73) = -1;
  }
  result = FMOD::ExpandingPool<FMOD::DSPConnectionI>::alloc(
             (FMOD::ExpandingPool<FMOD::DSPConnectionI> *const)(*((_QWORD *)this + 22) + 1776LL),
             (FMOD::DSPConnectionI **)this + 66,
             1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    *((_QWORD *)this + 73) = -1;
    *((_QWORD *)this + 70) = v1;
    *((_QWORD *)this + 71) = v1;
    *((_QWORD *)this + 72) = 0;
    *((_DWORD *)this + 164) = 0;
    *((_DWORD *)this + 165) = 0;
    *((_DWORD *)this + 166) = 1065353216;
    *((_DWORD *)this + 167) = 1;
    *((_DWORD *)this + 138) = 1065353216;
    *((_DWORD *)this + 139) = 0;
    return FMOD::DSPFader::resetInternal(this, 1, 1);
  }
  return result;
}


// Address: 0x21eb620 | Name: FMOD::Fader_Create
FMOD_RESULT_0 __fastcall FMOD::Fader_Create(FMOD_DSP_STATE *state)
{
  return FMOD::DSPFader::createInternal((FMOD::DSPFader *const)state->instance);
}


// Address: 0x21eb630 | Name: _ZN4FMOD8DSPFader9hardResetEv
FMOD_RESULT_0 __fastcall FMOD::DSPFader::hardReset(FMOD::DSPFader *const this)
{
  __int64 v2; // rax
  FMOD::SystemI *v3; // rdi
  FMOD_RESULT_0 v4; // ebp
  FMOD::DSPQueueCmd_FaderResetAndClear *v6; // rsi
  FMOD::SystemI *v7; // rdi
  FMOD_RESULT_0 v8; // eax
  FMOD::DSPQueueCmd_FaderResetAndClear *cmd; // [rsp+8h] [rbp-20h] BYREF

  if ( (*((_BYTE *)this + 93) & 4) != 0 )
    return FMOD::DSPFader::resetInternal(this, 1, 1);
  FMOD::DSPMatrix::reset((FMOD::DSPMatrix *const)(*((_QWORD *)this + 66) + 152LL), *((FMOD::SystemI **)this + 22));
  v2 = *((_QWORD *)this + 66);
  v3 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  *(_DWORD *)(v2 + 148) = 0;
  *(_DWORD *)(v2 + 144) = 1065353216;
  v4 = FMOD::SystemI::lockDSPQueueCmd(v3, (void **)&cmd, 24, 1);
  if ( v4 )
    return v4;
  v6 = cmd;
  v7 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  cmd->mFader = this;
  *(_BYTE *)&v6->FMOD::DSPQueueCmd = 18;
  v8 = FMOD::SystemI::unlockDSPQueueCmd(v7, v6, 1);
  if ( v8 )
    return v8;
  return v4;
}


// Address: 0x21eb6f0 | Name: FMOD::Fader_Reset
FMOD_RESULT_0 __fastcall FMOD::Fader_Reset(FMOD_DSP_STATE *state)
{
  return FMOD::DSPFader::resetInternal((FMOD::DSPFader *const)state->instance, 0, 0);
}


// Address: 0x21eb700 | Name: _ZN4FMOD8DSPFader26shuffleAndUpdatePointCacheEv
FMOD_RESULT_0 __fastcall FMOD::DSPFader::shuffleAndUpdatePointCache(FMOD::DSPFader *const this)
{
  FMOD::SystemI *v2; // rbp
  char v3; // di
  char *v4; // rax
  unsigned __int64 v5; // rdx
  char *v6; // rcx
  FMOD::DSPFader *v7; // rdx
  int v8; // esi
  int v9; // r8d

  v2 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  if ( v2 )
  {
    FMOD::SystemI::enterCrit(*((FMOD::SystemI *const *)this + 22), FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
    v3 = 1;
  }
  else
  {
    v3 = 0;
  }
  v4 = (char *)*((_QWORD *)this + 70);
  v5 = *((_QWORD *)this + 80);
  v6 = (char *)this + 560;
  *((_DWORD *)this + 150) = *((_DWORD *)this + 162);
  for ( *((_QWORD *)this + 74) = v5; v6 != v4 && v5 >= *((_QWORD *)v4 + 3); v4 = *(char **)v4 )
    ;
  v7 = this;
  v8 = 3;
  v9 = 1;
  do
  {
    if ( v6 == v4 )
    {
      *((_QWORD *)v7 + 76) = 0;
      *((_DWORD *)v7 + 154) = 0;
      v4 = (char *)this + 560;
    }
    else
    {
      ++v9;
      *((_QWORD *)v7 + 76) = *((_QWORD *)v4 + 3);
      *((_DWORD *)v7 + 154) = *((_DWORD *)v4 + 4);
      v4 = *(char **)v4;
    }
    v7 = (FMOD::DSPFader *)((char *)v7 + 16);
    --v8;
  }
  while ( v8 );
  *((_DWORD *)this + 165) = v9;
  *((_DWORD *)this + 164) = 1;
  if ( !v3 || !v2 )
    return FMOD_RESULT::FMOD_OK_0;
  FMOD::SystemI::leaveCrit(v2, FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21eb870 | Name: _ZN4FMOD8DSPFader7processEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPFader::process(
        FMOD::DSPFader *const this,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  __m128 v6; // xmm0
  float **buffers; // rax
  float **v10; // rax
  __int64 v11; // r12
  unsigned __int64 v12; // r14
  unsigned int v13; // ebp
  int v14; // r13d
  __int64 v15; // r14
  int v16; // r15d
  __int64 v17; // rdi
  __int64 v18; // r10
  unsigned int v19; // r12d
  char v20; // cl
  FMOD_RESULT_0 v21; // eax
  int v22; // eax
  __int64 v23; // r10
  __int64 v24; // rdx
  __int64 v25; // rax
  __int64 v26; // rcx
  float v27; // xmm3_4
  float v28; // xmm1_4
  unsigned int v29; // eax
  float v30; // xmm1_4
  __m128 v31; // xmm2
  FMOD_RESULT_0 v32; // eax
  unsigned __int64 v33; // r12
  unsigned int v34; // eax
  FMOD::DSPConnectionI *v35; // rdi
  float mOldVolume; // xmm1_4
  float mVolume; // xmm2_4
  __int64 v38; // rax
  __int64 lengtha; // [rsp+18h] [rbp-A0h]
  FMOD::DSPClock *parentclock; // [rsp+20h] [rbp-98h]
  float *outbuffer; // [rsp+28h] [rbp-90h]
  FMOD_RESULT_0 result; // [rsp+30h] [rbp-88h]
  int outchannels; // [rsp+38h] [rbp-80h]
  int inchannels; // [rsp+3Ch] [rbp-7Ch]
  float *inbuffer; // [rsp+40h] [rbp-78h]
  FMOD_DSP_BUFFER_ARRAY *outbufferarraya; // [rsp+50h] [rbp-68h]
  __int64 pointMixOffsets[11]; // [rsp+60h] [rbp-58h]

  if ( !inbufferarray )
  {
    inchannels = 0;
    if ( outbufferarray )
      goto LABEL_3;
LABEL_65:
    outchannels = 0;
    goto LABEL_4;
  }
  inchannels = *inbufferarray->buffernumchannels;
  if ( !outbufferarray )
    goto LABEL_65;
LABEL_3:
  outchannels = *outbufferarray->buffernumchannels;
LABEL_4:
  if ( inbufferarray && (buffers = inbufferarray->buffers) != 0 )
    inbuffer = *buffers;
  else
    inbuffer = 0;
  if ( outbufferarray && (v10 = outbufferarray->buffers) != 0 )
    outbuffer = *v10;
  else
    outbuffer = 0;
  if ( op != FMOD_DSP_PROCESS_QUERY )
  {
    v11 = *((unsigned __int16 *)this + 82);
    v12 = 0;
    v13 = *((unsigned __int16 *)this + 83);
    parentclock = (FMOD::DSPClock *)*((_QWORD *)this + 68);
    v14 = (unsigned __int16)v11;
    do
    {
      pointMixOffsets[v12 / 8] = FMOD::DSPFader::calcMixOffset(
                                   this,
                                   parentclock,
                                   *(_QWORD *)((char *)this + 2 * v12 + 592));
      v12 += 8LL;
    }
    while ( v12 != 32 );
    memset(outbuffer, 0, 4LL * outchannels * v11);
    v15 = 0;
    memset(
      &outbuffer[outchannels * (v13 + (unsigned __int16)v11)],
      0,
      (length - v13 - (unsigned __int16)v11) * 4LL * outchannels);
    outbufferarraya = outbufferarray;
    result = FMOD_RESULT::FMOD_OK_0;
    v16 = 0;
    while ( 1 )
    {
      v22 = *((_DWORD *)this + 165);
      if ( !v22 )
        break;
      v23 = pointMixOffsets[v16];
      if ( v15 < v23 )
      {
        v17 = *((_QWORD *)this + 66);
        v18 = v23 - v15;
        if ( v18 > v13 )
          LODWORD(v18) = v13;
        v6 = (__m128)*(unsigned int *)(v17 + 116);
        v19 = v18;
        v13 -= v18;
        *(_DWORD *)(v17 + 120) = v6.m128_i32[0];
        *(_DWORD *)(v17 + 112) = 0;
        v18 = (unsigned int)v18;
        goto LABEL_16;
      }
      if ( v16 > 2 )
      {
        v33 = 0;
        FMOD::DSPFader::shuffleAndUpdatePointCache(this);
        do
        {
          pointMixOffsets[v33 / 8] = FMOD::DSPFader::calcMixOffset(
                                       this,
                                       parentclock,
                                       *(_QWORD *)((char *)this + 2 * v33 + 592));
          v33 += 8LL;
        }
        while ( v33 != 32 );
        v22 = *((_DWORD *)this + 165);
        v24 = 0;
        v16 = 1;
      }
      else
      {
        v24 = v16++;
      }
      if ( v22 <= v16 )
      {
        v17 = *((_QWORD *)this + 66);
        v6 = (__m128)*((unsigned int *)this + 4 * (int)v24 + 150);
        *(_DWORD *)(v17 + 116) = v6.m128_i32[0];
        goto LABEL_15;
      }
      v25 = pointMixOffsets[v16];
      if ( v25 < 0 )
      {
        v17 = *((_QWORD *)this + 66);
        v18 = 0;
        v19 = 0;
        v6 = (__m128)*((unsigned int *)this + 4 * v16 + 150);
        *(_DWORD *)(v17 + 116) = v6.m128_i32[0];
        *(_DWORD *)(v17 + 112) = 0;
        *(_DWORD *)(v17 + 120) = v6.m128_i32[0];
      }
      else
      {
        v26 = pointMixOffsets[v24];
        v19 = v13;
        v6.m128_f32[0] = (float)(v15 - v26);
        v27 = *((float *)this + 4 * v24 + 150);
        v28 = (float)(v25 - v26);
        if ( v15 > v26 )
          LODWORD(v26) = v15;
        v17 = *((_QWORD *)this + 66);
        v29 = v25 - v26;
        if ( v29 <= v13 )
          v19 = v29;
        v13 -= v19;
        v18 = v19;
        v6.m128_f32[0] = v6.m128_f32[0] / v28;
        v30 = fminf(1.0, v6.m128_f32[0]);
        v31 = _mm_cmpge_ss(v6, (__m128)0LL);
        v6 = (__m128)*((unsigned int *)this + 4 * v16 + 150);
        *(_DWORD *)(v17 + 120) = v6.m128_i32[0];
        *(_DWORD *)(v17 + 112) = v29;
        *(float *)(v17 + 116) = (float)((float)(v6.m128_f32[0] - v27)
                                      * COERCE_FLOAT(_mm_andnot_ps(v31, (__m128)0LL).m128_u32[0] | LODWORD(v30)
                                                                                                 & v31.m128_i32[0]))
                              + v27;
        *((_DWORD *)this + 138) = v6.m128_i32[0];
        if ( v29 <= v19 )
          goto LABEL_17;
        v6.m128_f32[0] = (float)((float)(v6.m128_f32[0] - *(float *)(v17 + 116))
                               * (float)((float)(int)v19 / (float)(int)v29))
                       + *(float *)(v17 + 116);
      }
LABEL_16:
      *((_DWORD *)this + 138) = v6.m128_i32[0];
LABEL_17:
      if ( v19 )
      {
        v20 = 1;
        if ( outbufferarraya->speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
          v20 = inbufferarray->speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
        lengtha = v18;
        v21 = FMOD::DSPConnectionI::mix(
                (FMOD::DSPConnectionI *const)v17,
                &outbuffer[v14 * outchannels],
                &inbuffer[v14 * inchannels],
                v20,
                outchannels,
                inchannels,
                v19,
                1);
        v18 = lengtha;
        result = v21;
      }
      v14 += v19;
      v15 += v18;
      if ( !v13 )
        return result;
    }
    v17 = *((_QWORD *)this + 66);
    v6 = (__m128)*(unsigned int *)(v17 + 116);
LABEL_15:
    *(_DWORD *)(v17 + 120) = v6.m128_i32[0];
    v18 = v13;
    v19 = v13;
    *(_DWORD *)(v17 + 112) = 0;
    v13 = 0;
    goto LABEL_16;
  }
  v34 = *((_DWORD *)this + 114) & 0xFFFFFFEF;
  *((_DWORD *)this + 114) = v34;
  if ( inputsidle )
  {
    if ( *(float *)(*((_QWORD *)this + 66) + 104LL) != *(float *)(*((_QWORD *)this + 66) + 128LL) )
    {
      *((_DWORD *)this + 114) = v34 | 0x10;
      return FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
    }
    return FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
  }
  v35 = (FMOD::DSPConnectionI *)*((_QWORD *)this + 66);
  if ( v35->mMixMatrix.mData )
  {
    *outbufferarray->buffernumchannels = v35->mMixMatrix.mOutChannels;
    outbufferarray->speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
  }
  if ( *((int *)this + 165) > 0 || v35->mFadeValue != 1.0 || v35->mMixMatrixCurrent.mData )
    return FMOD_RESULT::FMOD_OK_0;
  mOldVolume = v35->mOldVolume;
  mVolume = v35->mVolume;
  if ( mOldVolume != 1.0 || (v32 = FMOD_RESULT::FMOD_ERR_DSP_DONTPROCESS_0, mVolume != 1.0) )
  {
    if ( mVolume != 0.0 )
      return FMOD_RESULT::FMOD_OK_0;
    if ( v35->mNewRampCount )
    {
LABEL_61:
      v32 = FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
      if ( mOldVolume == 0.0 )
        return v32;
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( mOldVolume != 0.0 )
    {
      FMOD::DSPConnectionI::setCurrentToTarget(v35);
      v38 = *((_QWORD *)this + 66);
      *(_DWORD *)(v38 + 124) |= 8u;
      mOldVolume = *(float *)(v38 + 104);
      if ( *(float *)(v38 + 128) != 0.0 )
        return FMOD_RESULT::FMOD_OK_0;
      goto LABEL_61;
    }
    return FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
  }
  return v32;
}


// Address: 0x21ebe10 | Name: FMOD::Fader_Process
FMOD_RESULT_0 __fastcall FMOD::Fader_Process(
        FMOD_DSP_STATE *state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  return FMOD::DSPFader::process(
           (FMOD::DSPFader *const)state->instance,
           length,
           inbufferarray,
           outbufferarray,
           inputsidle,
           op);
}


// Address: 0x21ebe20 | Name: _ZN4FMOD8DSPFader16removeFadePointsEyyb
FMOD_RESULT_0 __fastcall FMOD::DSPFader::removeFadePoints(
        FMOD::DSPFader *const this,
        FMOD_CLOCKTIME dspclock_start,
        FMOD_CLOCKTIME dspclock_end,
        bool protect)
{
  char v4; // r13
  FMOD::SystemI *v6; // r14
  FMOD_RESULT_0 updated; // r12d
  FMOD::DSPFader *v9; // rax
  char v10; // r9
  FMOD_CLOCKTIME v11; // rcx
  FMOD::DSPFader *v12; // r8
  FMOD::DSPFader **v13; // rcx
  __int64 v14; // rcx
  FMOD::DSPConnectionI *v15; // rdi
  FMOD_CLOCKTIME dspclock_enda; // [rsp+8h] [rbp-30h]

  v4 = 0;
  v6 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  if ( protect && v6 )
  {
    dspclock_enda = dspclock_end;
    v4 = 1;
    FMOD::SystemI::enterCrit(*((FMOD::SystemI *const *)this + 22), FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
    dspclock_end = dspclock_enda;
  }
  updated = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dspclock_start <= dspclock_end )
  {
    v9 = (FMOD::DSPFader *)*((_QWORD *)this + 70);
    v10 = 0;
    while ( v9 != (FMOD::DSPFader *const)((char *)this + 560) )
    {
      v11 = *((_QWORD *)v9 + 3);
      v12 = *(FMOD::DSPFader **)v9;
      if ( dspclock_start <= v11 && dspclock_end >= v11 )
      {
        v13 = (FMOD::DSPFader **)*((_QWORD *)v9 + 1);
        v10 = 1;
        *v13 = v12;
        *(_QWORD *)(*(_QWORD *)v9 + 8LL) = v13;
        v14 = *((_QWORD *)this + 22);
        *((_QWORD *)v9 + 1) = v9;
        *((_QWORD *)v9 + 3) = -1;
        *((_QWORD *)v9 + 2) = 0;
        *((_QWORD *)v9 + 1) = *(unsigned __int64 *)((char *)&stru_107E8.r_offset + v14);
        *(_QWORD *)v9 = v14 + 67552;
        *(unsigned __int64 *)((char *)&stru_107E8.r_offset + v14) = (unsigned __int64)v9;
        **((_QWORD **)v9 + 1) = v9;
      }
      v9 = v12;
    }
    if ( v10 )
      *((_DWORD *)this + 164) = 1;
    if ( !dspclock_start && dspclock_end == -1048576 && (v15 = (FMOD::DSPConnectionI *)*((_QWORD *)this + 66)) != 0 )
    {
      if ( (*((_BYTE *)this + 93) & 4) != 0 )
        FMOD::DSPConnectionI::resetFadeState(v15);
      else
        *((_BYTE *)this + 672) = 1;
      *((_DWORD *)this + 166) = 1065353216;
    }
    else if ( v10 )
    {
      updated = FMOD::DSPFader::updateMaxFadeValue(this);
      if ( updated )
        goto LABEL_3;
    }
    *((_DWORD *)this + 167) = 0;
    updated = FMOD_RESULT::FMOD_OK_0;
  }
LABEL_3:
  if ( !v4 || !v6 )
    return updated;
  FMOD::SystemI::leaveCrit(v6, FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
  return updated;
}


// Address: 0x21ebfd0 | Name: _ZN4FMOD8DSPFader12addFadePointEyf
__int64 __fastcall FMOD::DSPFader::addFadePoint(
        FMOD::DSPFader *const this,
        FMOD::LinkedListNode *dspclock,
        float a3,
        float volume)
{
  FMOD::SystemI *v5; // r13
  char v6; // r14
  FMOD::SystemI *v7; // rdi
  FMOD::DSPFadePoint *mNodeNext; // rbx
  FMOD_RESULT_0 v9; // r15d
  char *v10; // rdx
  bool v11; // cl
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::LinkedListNode *v13; // rax
  FMOD::LinkedListNode *v14; // rdx
  FMOD::LinkedListNode *v16; // rax
  __int64 v17; // rax

  v5 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  if ( v5 )
  {
    v6 = 1;
    FMOD::SystemI::enterCrit(v5, FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
    v7 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  }
  else
  {
    v6 = 0;
    v7 = 0;
  }
  mNodeNext = (FMOD::DSPFadePoint *)v7->mDSPFadePointHead.mNodeNext;
  if ( mNodeNext != &v7->mDSPFadePointHead
    || (v9 = FMOD::SystemI::expandFadePointPool(v7)) == FMOD_RESULT::FMOD_OK_0
    && (v17 = *((_QWORD *)this + 22),
        v9 = FMOD_RESULT::FMOD_ERR_INTERNAL_0,
        mNodeNext = *(FMOD::DSPFadePoint **)(v17 + 67552),
        mNodeNext != (FMOD::DSPFadePoint *)(v17 + 67552)) )
  {
    v9 = FMOD::DSPFader::removeFadePoints(this, (FMOD_CLOCKTIME)dspclock, (FMOD_CLOCKTIME)dspclock, 0);
    if ( v9 == FMOD_RESULT::FMOD_OK_0 )
    {
      v10 = (char *)this + 560;
      v11 = 0;
      if ( (FMOD::DSPFader *const)((char *)this + 560) == *((FMOD::DSPFader *const *)this + 70) )
        v11 = v10 == *((char **)this + 71);
      mNodePrev = mNodeNext->mNodePrev;
      mNodePrev->mNodeNext = mNodeNext->mNodeNext;
      mNodeNext->mNodeNext->mNodePrev = mNodePrev;
      mNodeNext->mNodePrev = mNodeNext;
      mNodeNext->mNodeNext = mNodeNext;
      mNodeNext->mNodePriority = -1;
      mNodeNext->mNodeData = 0;
      v13 = (FMOD::LinkedListNode *)*((_QWORD *)this + 70);
      do
      {
        if ( dspclock < v13[1].mNodeNext )
        {
          v14 = v13->mNodePrev;
          mNodeNext->mNodePriority = (FMOD_UINT64)dspclock;
          mNodeNext->mNodeNext = v13;
          mNodeNext->mNodePrev = v14;
          v13->mNodePrev = mNodeNext;
          mNodeNext->mNodePrev->FMOD::SortedLinkedListNode64::FMOD::LinkedListNode::mNodeNext = mNodeNext;
          goto LABEL_11;
        }
        v13 = v13->mNodeNext;
      }
      while ( v10 != (char *)v13->mNodePrev );
      v16 = (FMOD::LinkedListNode *)*((_QWORD *)this + 71);
      mNodeNext->mNodePriority = (FMOD_UINT64)dspclock;
      mNodeNext->mNodeNext = (FMOD::LinkedListNode *)v10;
      mNodeNext->mNodePrev = v16;
      *((_QWORD *)this + 71) = mNodeNext;
      mNodeNext->mNodePrev->FMOD::SortedLinkedListNode64::FMOD::LinkedListNode::mNodeNext = mNodeNext;
LABEL_11:
      mNodeNext->mNodeData = (void *)LODWORD(a3);
      if ( v11 )
        *((float *)this + 166) = a3;
      else
        *((float *)this + 166) = fmaxf(*((float *)this + 166), a3);
      *((_DWORD *)this + 164) = 1;
      *((_DWORD *)this + 167) = 0;
      v9 = FMOD_RESULT::FMOD_OK_0;
    }
  }
  if ( v6 && v5 )
    FMOD::SystemI::leaveCrit(v5, FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
  return (unsigned int)v9;
}


// Address: 0x21ec1e0 | Name: _ZN4FMOD8DSPFader30updatePointCacheAndRemoveNodesEv
FMOD_RESULT_0 __fastcall FMOD::DSPFader::updatePointCacheAndRemoveNodes(FMOD::DSPFader *const this)
{
  float v1; // xmm1_4
  FMOD::SystemI *v2; // rax
  char *v3; // rbx
  char *v4; // r12
  char *v5; // rcx
  char *v6; // r14
  char v7; // r13
  int v8; // ebp
  __int64 v9; // rax
  char *v10; // rax
  char *v11; // rax
  _QWORD *v12; // rax
  __int64 v13; // rax
  char v14; // r12
  __int64 v15; // rax
  __int64 v16; // rax
  char *v17; // rax
  FMOD_RESULT_0 updated; // ebx
  __int64 v19; // rax
  FMOD::LinkedListNode *v20; // rdx
  __int64 v21; // r12
  FMOD::LinkedListNode *v22; // rbp
  FMOD_RESULT_0 v24; // eax
  float lastVolume; // [rsp+Ch] [rbp-4Ch]
  float firstVolume; // [rsp+10h] [rbp-48h]
  char v27; // [rsp+17h] [rbp-41h]
  FMOD::SystemI *v28; // [rsp+18h] [rbp-40h]

  v2 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  v28 = v2;
  if ( v2 )
  {
    FMOD::SystemI::enterCrit(v2, FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
    v27 = 1;
  }
  else
  {
    v27 = 0;
  }
  v3 = (char *)*((_QWORD *)this + 70);
  v4 = (char *)this + 560;
  if ( (char *)this + 560 == v3 )
  {
    if ( v4 == *((char **)this + 71) )
    {
      *((_DWORD *)this + 165) = 0;
      *((_DWORD *)this + 164) = 0;
      firstVolume = 1.0;
      v14 = 0;
      lastVolume = 1.0;
      v8 = 0;
      goto LABEL_17;
    }
    v5 = (char *)this + 560;
    v3 = (char *)this + 560;
  }
  else
  {
    v5 = *(char **)v3;
  }
  v6 = v5;
  v7 = 0;
  v8 = 0;
  firstVolume = 1.0;
  lastVolume = 1.0;
  while ( 1 )
  {
    v11 = v3;
    if ( v4 != v6 )
      v11 = v6;
    if ( FMOD::DSPFader::calcMixOffset(this, *((FMOD::DSPClock **)this + 68), *((_QWORD *)v11 + 3)) < 0 )
      break;
    v9 = v8++;
    v10 = (char *)this + 16 * v9;
    *((_QWORD *)v10 + 74) = *((_QWORD *)v3 + 3);
    *((_DWORD *)v10 + 150) = *((_DWORD *)v3 + 4);
    if ( v4 == v6 )
      goto LABEL_15;
LABEL_7:
    if ( v8 > 3 )
      goto LABEL_15;
    v3 = v6;
    v6 = *(char **)v6;
  }
  v1 = *((float *)v3 + 4);
  lastVolume = v1;
  if ( !v7 )
    firstVolume = *((float *)v3 + 4);
  v12 = (_QWORD *)*((_QWORD *)v3 + 1);
  v7 = 1;
  *v12 = *(_QWORD *)v3;
  *(_QWORD *)(*(_QWORD *)v3 + 8LL) = v12;
  v13 = *((_QWORD *)this + 22);
  *((_QWORD *)v3 + 1) = v3;
  *((_QWORD *)v3 + 3) = -1;
  *((_QWORD *)v3 + 2) = 0;
  *((_QWORD *)v3 + 1) = *(unsigned __int64 *)((char *)&stru_107E8.r_offset + v13);
  *(_QWORD *)v3 = v13 + 67552;
  *(unsigned __int64 *)((char *)&stru_107E8.r_offset + v13) = (unsigned __int64)v3;
  **((_QWORD **)v3 + 1) = v3;
  if ( v4 != v6 )
    goto LABEL_7;
LABEL_15:
  *((_DWORD *)this + 165) = v8;
  *((_DWORD *)this + 164) = 0;
  v14 = v7 & (v8 == 0);
  if ( v14 )
  {
    v15 = *((_QWORD *)this + 66);
    v8 = 0;
    *(_DWORD *)(v15 + 112) = 0;
    *(float *)(v15 + 116) = lastVolume;
    *(float *)(v15 + 120) = lastVolume;
    *((float *)this + 166) = lastVolume;
    goto LABEL_17;
  }
  if ( v7 )
  {
    updated = FMOD::DSPFader::updateMaxFadeValue(this);
    if ( updated )
      goto LABEL_24;
  }
  if ( v8 > 3 )
  {
    updated = FMOD_RESULT::FMOD_OK_0;
    goto LABEL_29;
  }
  do
  {
LABEL_17:
    v16 = v8++;
    v17 = (char *)this + 16 * v16;
    *((_QWORD *)v17 + 74) = 0;
    *((_DWORD *)v17 + 150) = 0;
  }
  while ( v8 <= 3 );
  updated = FMOD_RESULT::FMOD_OK_0;
  if ( !v14 )
    goto LABEL_24;
  if ( firstVolume != *((float *)this + 138) || lastVolume == firstVolume )
    goto LABEL_32;
  v19 = *((_QWORD *)this + 68);
  v20 = (FMOD::LinkedListNode *)*((_QWORD *)this + 3);
  v21 = *(unsigned int *)(v19 + 36);
  if ( *(_QWORD *)v19 >= (unsigned __int64)v20 )
    v20 = *(FMOD::LinkedListNode **)v19;
  v22 = v20;
  updated = (unsigned int)FMOD::DSPFader::addFadePoint(this, v20, firstVolume, v1);
  if ( updated
    || (updated = (unsigned int)FMOD::DSPFader::addFadePoint(
                                  this,
                                  (FMOD::LinkedListNode *)((char *)v22 + 64 * v21),
                                  lastVolume,
                                  v1)) != FMOD_RESULT::FMOD_OK_0 )
  {
LABEL_24:
    if ( v27 )
      goto LABEL_30;
  }
  else
  {
    v24 = FMOD::DSPFader::updatePointCacheAndRemoveNodes(this);
    if ( v24 )
    {
      updated = v24;
      goto LABEL_24;
    }
LABEL_32:
    updated = FMOD_RESULT::FMOD_OK_0;
    *((float *)this + 138) = lastVolume;
LABEL_29:
    if ( v27 )
    {
LABEL_30:
      if ( v28 )
        FMOD::SystemI::leaveCrit(v28, FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
    }
  }
  return updated;
}


// Address: 0x21ec520 | Name: _ZN4FMOD8DSPFader6preMixEv
FMOD_RESULT_0 __fastcall FMOD::DSPFader::preMix(FMOD::DSPFader *const this)
{
  FMOD::SystemI *v1; // rbp
  char v2; // r12
  __int64 v3; // rax
  __int64 v4; // rax
  _BOOL4 v5; // eax
  int v7; // eax
  __int64 v8; // rax

  v1 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  if ( v1 )
  {
    v2 = 1;
    FMOD::SystemI::enterCrit(*((FMOD::SystemI *const *)this + 22), FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
  }
  else
  {
    v2 = 0;
  }
  if ( *((_BYTE *)this + 672) )
  {
    FMOD::DSPConnectionI::resetFadeState(*((FMOD::DSPConnectionI *const *)this + 66));
    *((_BYTE *)this + 672) = 0;
  }
  if ( (*((_BYTE *)this + 456) & 0x10) == 0 )
  {
    v3 = *((_QWORD *)this + 67);
    if ( v3 )
      goto LABEL_7;
LABEL_20:
    *((_QWORD *)this + 67) = (char *)this + 8;
    v8 = *((_QWORD *)this + 7);
    *((_QWORD *)this + 68) = v8;
    if ( v8 )
      goto LABEL_8;
LABEL_21:
    *((_QWORD *)this + 68) = *((_QWORD *)this + 7);
    goto LABEL_8;
  }
  FMOD::DSPConnectionI::setCurrentToTarget(*((FMOD::DSPConnectionI *const *)this + 66));
  v3 = *((_QWORD *)this + 67);
  *((_DWORD *)this + 114) &= ~0x10u;
  if ( !v3 )
    goto LABEL_20;
LABEL_7:
  v4 = *(_QWORD *)(v3 + 48);
  *((_QWORD *)this + 68) = v4;
  if ( !v4 )
    goto LABEL_21;
LABEL_8:
  if ( *((_DWORD *)this + 164)
    || (v7 = *((_DWORD *)this + 165), v7 > 0)
    && FMOD::DSPFader::calcMixOffset(this, *((FMOD::DSPClock **)this + 68), *((_QWORD *)this + 2 * (v7 != 1) + 74)) < 0 )
  {
    FMOD::DSPFader::updatePointCacheAndRemoveNodes(this);
  }
  v5 = 0;
  if ( (FMOD::DSPFader *const)((char *)this + 560) == *((FMOD::DSPFader *const *)this + 70) )
    v5 = (FMOD::DSPFader *const)((char *)this + 560) == *((FMOD::DSPFader *const *)this + 71);
  *((_DWORD *)this + 167) = v5;
  if ( !v2 || !v1 )
    return FMOD_RESULT::FMOD_OK_0;
  FMOD::SystemI::leaveCrit(v1, FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ec6c0 | Name: FMOD::Fader_Command
FMOD_RESULT_0 __fastcall FMOD::Fader_Command(
        FMOD_DSP_STATE *state,
        FMOD::FMOD_DSP_COMMAND_TYPE command,
        void *commanddata1,
        void *commanddata2)
{
  if ( command == 1 )
    return FMOD::DSPFader::preMix((FMOD::DSPFader *const)state->instance);
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ec6e0 | Name: _ZN4FMOD8DSPFader16setFadePointRampEyf
__int64 __fastcall FMOD::DSPFader::setFadePointRamp(
        FMOD::DSPFader *const this,
        FMOD_CLOCKTIME dspclock,
        float a3,
        float volume)
{
  FMOD::SystemI *v5; // rbx
  char v6; // r13
  FMOD_CLOCKTIME v7; // rsi
  FMOD::LinkedListNode *v8; // rbp
  FMOD::DSPFader *v9; // rcx
  float v10; // xmm1_4
  float v11; // xmm0_4
  FMOD_CLOCKTIME v12; // rdx
  FMOD::DSPFader *v13; // rax
  unsigned int v14; // r15d
  __int64 v16; // rax
  __int64 v17; // rsi
  float v18; // xmm1_4
  __int64 v19; // rdx
  float v20; // xmm3_4

  v5 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  if ( v5 )
  {
    v6 = 1;
    FMOD::SystemI::enterCrit(v5, FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
  }
  else
  {
    v6 = 0;
  }
  if ( dspclock >> 20 <= 0x3F )
  {
    v8 = 0;
    v7 = 0;
  }
  else
  {
    v7 = (dspclock >> 20) - 64;
    v8 = (FMOD::LinkedListNode *)(v7 << 20);
  }
  v9 = (FMOD::DSPFader *)*((_QWORD *)this + 70);
  v10 = *((float *)this + 138);
  if ( v9 == (FMOD::DSPFader *const)((char *)this + 560) || (v11 = *((float *)v9 + 4), v7 <= *((_QWORD *)v9 + 3) >> 20) )
  {
    v11 = *((float *)this + 138);
  }
  else
  {
    while ( 1 )
    {
      v13 = *(FMOD::DSPFader **)v9;
      if ( *(FMOD::DSPFader *const *)v9 == (FMOD::DSPFader *const)((char *)this + 560) )
        break;
      v11 = *((float *)v13 + 4);
      v12 = *((_QWORD *)v13 + 3) >> 20;
      if ( v7 <= v12 )
      {
        v16 = *((_QWORD *)v9 + 3) >> 20;
        v17 = v7 - v16;
        if ( v17 < 0 )
          v18 = (float)(v17 & 1 | (unsigned int)((unsigned __int64)v17 >> 1))
              + (float)(v17 & 1 | (unsigned int)((unsigned __int64)v17 >> 1));
        else
          v18 = (float)(int)v17;
        v19 = v12 - v16;
        if ( v19 < 0 )
          v20 = (float)(v19 & 1 | (unsigned int)((unsigned __int64)v19 >> 1))
              + (float)(v19 & 1 | (unsigned int)((unsigned __int64)v19 >> 1));
        else
          v20 = (float)(int)v19;
        v10 = fmaxf(v18 / v20, 0.0);
        v11 = (float)((float)(v11 - *((float *)v9 + 4)) * v10) + *((float *)v9 + 4);
        break;
      }
      v9 = *(FMOD::DSPFader **)v9;
    }
  }
  v14 = FMOD::DSPFader::removeFadePoints(this, (FMOD_CLOCKTIME)v8, 0xFFFFFFFFFFF00000LL, 0);
  if ( !v14 )
  {
    v14 = FMOD::DSPFader::addFadePoint(this, v8, v11, v10);
    if ( !v14 )
      v14 = FMOD::DSPFader::addFadePoint(this, (FMOD::LinkedListNode *)dspclock, a3, v10);
  }
  if ( v6 && v5 )
    FMOD::SystemI::leaveCrit(v5, FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
  return v14;
}


// Address: 0x21ec8c0 | Name: _ZN4FMOD8DSPFader13getFadePointsEPjPyPf
FMOD_RESULT_0 __fastcall FMOD::DSPFader::getFadePoints(
        FMOD::DSPFader *const this,
        unsigned int *numpoints,
        FMOD_CLOCKTIME *point_dspclock,
        float *point_volume)
{
  FMOD::SystemI *v7; // r13
  char v8; // si
  FMOD_RESULT_0 v9; // r15d
  float *v10; // r9
  FMOD::DSPFader *v11; // rax
  unsigned int v12; // r8d
  unsigned int v13; // ecx
  __int64 i; // rax

  v7 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  if ( v7 )
  {
    FMOD::SystemI::enterCrit(*((FMOD::SystemI *const *)this + 22), FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
    v8 = 1;
  }
  else
  {
    v8 = 0;
  }
  v9 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !numpoints )
    goto LABEL_17;
  v10 = (float *)*((_QWORD *)this + 70);
  if ( (float *)((char *)this + 560) == v10 )
  {
    v12 = 0;
  }
  else
  {
    v11 = (FMOD::DSPFader *)*((_QWORD *)this + 70);
    v12 = 0;
    do
    {
      v11 = *(FMOD::DSPFader **)v11;
      ++v12;
    }
    while ( (FMOD::DSPFader *const)((char *)this + 560) != v11 );
  }
  if ( point_dspclock || point_volume )
  {
    v13 = *numpoints;
    if ( v12 < *numpoints )
    {
      *numpoints = v12;
      v13 = v12;
    }
    for ( i = 0; v13 > (unsigned int)i; v10 = *(float **)v10 )
    {
      if ( point_dspclock )
        point_dspclock[i] = *((_QWORD *)v10 + 3);
      if ( point_volume )
        point_volume[i] = v10[4];
      ++i;
    }
    v9 = FMOD_RESULT::FMOD_OK_0;
LABEL_17:
    if ( !v8 )
      return v9;
    goto LABEL_21;
  }
  v9 = FMOD_RESULT::FMOD_OK_0;
  *numpoints = v12;
  if ( !v8 )
    return v9;
LABEL_21:
  if ( v7 )
    FMOD::SystemI::leaveCrit(v7, FMOD_SYSTEM_CRIT_DSPFADEPOINTS);
  return v9;
}


// Address: 0x21ec9e0 | Name: _ZN4FMOD8DSPFader15setHeadDSPClockEPNS_8DSPClockEb
FMOD_RESULT_0 __fastcall FMOD::DSPFader::setHeadDSPClock(
        FMOD::DSPFader *const this,
        FMOD::DSPClock *clock,
        bool protect)
{
  FMOD_RESULT_0 v5; // ebp
  FMOD::DSPQueueCmd_SetHeadClock *v8; // rsi
  FMOD::SystemI *v9; // rdi
  FMOD_RESULT_0 v10; // eax
  FMOD::DSPQueueCmd_SetHeadClock *cmd; // [rsp+8h] [rbp-30h] BYREF

  if ( (*((_BYTE *)this + 93) & 4) != 0 )
  {
    *((_QWORD *)this + 67) = clock;
    return FMOD_RESULT::FMOD_OK_0;
  }
  v5 = FMOD::SystemI::lockDSPQueueCmd(*((FMOD::SystemI *const *)this + 22), (void **)&cmd, 24, protect);
  if ( v5 )
    return v5;
  v8 = cmd;
  v9 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  cmd->mFader = this;
  v8->mHeadClock = clock;
  *(_BYTE *)&v8->FMOD::DSPQueueCmd = 16;
  v10 = FMOD::SystemI::unlockDSPQueueCmd(v9, v8, protect);
  if ( v10 )
    return v10;
  return v5;
}


// Address: 0x21eca70 | Name: _ZN4FMOD8DSPFader6setMixEfibb
FMOD_RESULT_0 __fastcall FMOD::DSPFader::setMix(
        FMOD::DSPConnectionI *const *this,
        float volume,
        unsigned int rampcount,
        bool deferred,
        bool rampfrom0)
{
  return FMOD::DSPConnectionI::setMix(*(this + 66), volume, rampcount, deferred, rampfrom0);
}


// Address: 0x21eca90 | Name: _ZN4FMOD8DSPFader12setMixMatrixEPfiiiib
FMOD_RESULT_0 __fastcall FMOD::DSPFader::setMixMatrix(
        FMOD::DSPFader *const this,
        float *matrix,
        int outchannels,
        int inchannels,
        int inchannel_hop,
        int rampcount,
        bool deferred)
{
  return FMOD::DSPConnectionI::setMixMatrix(
           *((FMOD::DSPConnectionI *const *)this + 66),
           matrix,
           outchannels,
           inchannels,
           inchannel_hop,
           rampcount,
           deferred);
}


// Address: 0x21ecab0 | Name: _ZN4FMOD8DSPFader12setRampFrom0Ev
FMOD_RESULT_0 __fastcall FMOD::DSPFader::setRampFrom0(FMOD::DSPFader *const this)
{
  return FMOD::DSPConnectionI::setMix(
           *((FMOD::DSPConnectionI *const *)this + 66),
           *(float *)(*((_QWORD *)this + 66) + 144LL),
           0x40u,
           ((*((_WORD *)this + 46) >> 10) ^ 1) & 1,
           1);
}


// Address: 0x21ecae0 | Name: _ZN4FMOD8DSPFader25setParameterFloatInternalEif
FMOD_RESULT_0 __fastcall FMOD::DSPFader::setParameterFloatInternal(
        FMOD::DSPFader *const this,
        int index,
        float a3,
        float value)
{
  float v4; // xmm0_4

  if ( index )
    return FMOD_RESULT::FMOD_OK_0;
  *((float *)this + 139) = a3;
  if ( a3 > -80.0 )
    v4 = powf(10.0, a3 / 20.0);
  else
    v4 = 0.0;
  return FMOD::DSPConnectionI::setMix(*((FMOD::DSPConnectionI *const *)this + 66), v4, 0x40u, 1, 0);
}


// Address: 0x21ecb50 | Name: FMOD::Fader_SetParameterFloat
FMOD_RESULT_0 __fastcall FMOD::Fader_SetParameterFloat(FMOD_DSP_STATE *state, int index, float a3, float value)
{
  return FMOD::DSPFader::setParameterFloatInternal((FMOD::DSPFader *const)state->instance, index, a3, value);
}


// Address: 0x21ecb60 | Name: _ZN4FMOD8DSPFader25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPFader::getParameterFloatInternal(
        FMOD::DSPFader *const this,
        int index,
        float *value,
        char *valueStr)
{
  if ( !index )
    *value = *((float *)this + 139);
  if ( valueStr )
    sprintf(valueStr, "%.02f", *value);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ecbb0 | Name: FMOD::Fader_GetParameterFloat
FMOD_RESULT_0 __fastcall FMOD::Fader_GetParameterFloat(FMOD_DSP_STATE *state, int index, float *value, char *valueStr)
{
  return FMOD::DSPFader::getParameterFloatInternal((FMOD::DSPFader *const)state->instance, index, value, valueStr);
}


// Address: 0x21ecbc0 | Name: _ZN4FMOD8DSPFader24setParameterDataInternalEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPFader::setParameterDataInternal(
        FMOD::DSPFader *const this,
        int index,
        void *data,
        unsigned int length)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_OK_0;
  if ( index != 1 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  return result;
}


// Address: 0x21ecbd0 | Name: FMOD::Fader_SetParameterData
FMOD_RESULT_0 __fastcall FMOD::Fader_SetParameterData(
        FMOD_DSP_STATE *state,
        int index,
        void *data,
        unsigned int length)
{
  return FMOD::DSPFader::setParameterDataInternal((FMOD::DSPFader *const)state->instance, index, data, length);
}


// Address: 0x21ecbe0 | Name: _ZN4FMOD8DSPFader24getParameterDataInternalEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPFader::getParameterDataInternal(
        FMOD::DSPFader *const this,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax
  float v6; // xmm1_4
  float v7; // xmm0_4
  void **dataa; // [rsp+8h] [rbp-20h]
  unsigned int *lengtha; // [rsp+10h] [rbp-18h]
  char *valuestra; // [rsp+18h] [rbp-10h]

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index == 1 )
  {
    v6 = *((float *)this + 139);
    if ( v6 > -80.0 )
    {
      valuestra = valuestr;
      lengtha = length;
      dataa = data;
      v7 = powf(10.0, v6 / 20.0);
      data = dataa;
      length = lengtha;
      valuestr = valuestra;
    }
    else
    {
      v7 = 0.0;
    }
    *((float *)this + 170) = v7;
    *((_DWORD *)this + 171) = 0;
    *data = (char *)this + 680;
    *length = 8;
    if ( valuestr )
      *valuestr = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21ecc90 | Name: FMOD::Fader_GetParameterData
FMOD_RESULT_0 __fastcall FMOD::Fader_GetParameterData(
        FMOD_DSP_STATE *state,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  return FMOD::DSPFader::getParameterDataInternal((FMOD::DSPFader *const)state->instance, index, data, length, valuestr);
}


// Address: 0x21ecca0 | Name: _ZN4FMOD8DSPFader16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPFader::getDescriptionEx()
{
  *(_QWORD *)&stru_286B3E0.floatdesc.min = 0x41200000C2A00000LL;
  stru_286B3E0.intdesc.defaultval = 0;
  stru_286B3E0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_LINEAR;
  stru_286B2A0.paramdesc = off_286B280;
  stru_286B380.intdesc.min = -1;
  stru_286B2A0.numparameters = 2;
  stru_286B2A0.create = FMOD::Fader_Create;
  stru_286B2A0.release = FMOD::Fader_Release;
  stru_286B2A0.reset = FMOD::Fader_Reset;
  stru_286B2A0.process = FMOD::Fader_Process;
  stru_286B2A0.setparameterfloat = (FMOD_DSP_SETPARAM_FLOAT_CALLBACK_0)FMOD::Fader_SetParameterFloat;
  stru_286B2A0.getparameterfloat = FMOD::Fader_GetParameterFloat;
  stru_286B2A0.setparameterdata = FMOD::Fader_SetParameterData;
  stru_286B2A0.getparameterdata = FMOD::Fader_GetParameterData;
  stru_286B240.mCommand = FMOD::Fader_Command;
  stru_286B240.mCommandMask = 1;
  return &stru_286B240;
}


