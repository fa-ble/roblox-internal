// Address: 0x221bab0 | Name: FMOD::UpdateMeteringInfo_SSE
void __fastcall FMOD::UpdateMeteringInfo_SSE(
        const float *buffer,
        int length,
        int channels,
        float *peaks,
        float *accumulatedSquares)
{
  int v5; // esi
  unsigned int v6; // r9d
  unsigned int v7; // eax
  __int64 v8; // r10
  float v9; // xmm0_4
  __int64 v10; // r10
  float *v11; // r11
  float *v12; // r10
  float v13; // xmm1_4
  float v14; // xmm0_4
  __m128 v15; // xmm0
  __m128 v16; // xmm4
  int v17; // edx
  const float *v18; // rax
  __m128 v19; // xmm1
  __m128 v20; // xmm3
  float v21; // xmm3_4
  float v22; // xmm5_4
  float v23; // xmm4_4
  int v24; // esi
  float j; // xmm1_4
  float v26; // xmm7_4
  __m128 v27; // xmm0
  __m128 v28; // xmm4
  int v29; // edx
  const float *v30; // rax
  __m128 v31; // xmm1
  __m128 v32; // xmm3
  __m128 v33; // xmm1
  __m128 v34; // xmm3
  float v35; // xmm4_4
  __m128 v36; // xmm2
  float v37; // xmm4_4
  __m128 v38; // xmm5
  float v39; // xmm4_4
  __m128 v40; // xmm2
  float v41; // xmm6_4
  float v42; // xmm3_4
  float v43; // xmm5_4
  float v44; // xmm7_4
  float v45; // xmm7_4
  __m128 v46; // xmm3
  __m128 v47; // xmm0
  __m128 v48; // xmm12
  __m128 v49; // xmm11
  __m128 v50; // xmm10
  __m128 v51; // xmm1
  const float *v52; // rax
  __m128 v53; // xmm6
  __m128 v54; // xmm5
  __m128 v55; // xmm4
  __m128 v56; // xmm9
  __m128 v57; // xmm8
  __m128 v58; // xmm7
  __m128 v59; // xmm2
  __m128 v60; // xmm1
  float v61; // xmm6_4
  float v62; // xmm5_4
  float v63; // xmm4_4
  float v64; // xmm3_4
  float v65; // xmm2_4
  float v66; // xmm1_4
  float v67; // xmm0_4
  float v68; // xmm6_4
  float v69; // xmm0_4
  float v70; // xmm5_4
  float v71; // xmm0_4
  float v72; // xmm4_4
  float v73; // xmm0_4
  float v74; // xmm3_4
  float v75; // xmm0_4
  float v76; // xmm2_4
  float v77; // xmm0_4
  float v78; // xmm1_4
  __m128 v79; // xmm1
  __m128 v80; // xmm0
  __m128 v81; // xmm8
  __m128 i; // xmm7
  __m128 v83; // xmm4
  __m128 v84; // xmm3
  __m128 v85; // xmm6
  __m128 v86; // xmm5
  __m128 v87; // xmm3
  __m128 squarestemp; // [rsp+10h] [rbp-18h]
  __m128 squarestempa; // [rsp+10h] [rbp-18h]

  if ( channels != 1 )
  {
    switch ( channels )
    {
      case 2:
        v27 = *(__m128 *)flt_596740;
        if ( length >> 1 )
        {
          v28 = 0;
          v29 = length >> 1;
          v30 = buffer;
          do
          {
            v31 = *(__m128 *)v30;
            v30 += 4;
            --v29;
            v32 = _mm_and_ps(v31, *(__m128 *)dword_596750);
            v28 = _mm_add_ps(v28, _mm_mul_ps(v31, v31));
            v27 = _mm_xor_ps(v27, _mm_and_ps(_mm_cmplt_ps(v27, v32), _mm_xor_ps(v32, v27)));
          }
          while ( v29 );
          buffer += 4 * (unsigned int)((length >> 1) - 1) + 4;
        }
        else
        {
          v28 = 0;
        }
        squarestempa = v28;
        v33.m128_i32[0] = v27.m128_i32[0];
        v34 = (__m128)*(unsigned int *)peaks;
        v35 = fmaxf(v34.m128_f32[0], v27.m128_f32[0]);
        v34.m128_f32[0] = fmaxf(v34.m128_f32[0], v27.m128_f32[2]);
        v36 = _mm_cmplt_ss((__m128)v27.m128_u32[2], v33);
        v33.m128_i32[0] = v27.m128_i32[1];
        v27.m128_f32[0] = v35;
        v37 = _mm_andnot_ps(v36, v34).m128_f32[0];
        v38 = (__m128)*((unsigned int *)peaks + 1);
        v34.m128_f32[0] = fmaxf(v38.m128_f32[0], v27.m128_f32[1]);
        v38.m128_f32[0] = fmaxf(v38.m128_f32[0], v27.m128_f32[3]);
        LODWORD(v39) = LODWORD(v37) | v27.m128_i32[0] & v36.m128_i32[0];
        v40 = _mm_cmplt_ss((__m128)v27.m128_u32[3], v33);
        v41 = (float)(squarestempa.m128_f32[0] + squarestempa.m128_f32[2]) + *accumulatedSquares;
        LODWORD(v42) = _mm_andnot_ps(v40, v38).m128_u32[0] | v34.m128_i32[0] & v40.m128_i32[0];
        v43 = (float)(squarestempa.m128_f32[1] + squarestempa.m128_f32[3]) + accumulatedSquares[1];
        if ( (length & 1) != 0 )
        {
          v44 = fabs(*buffer);
          v41 = v41 + (float)(v44 * v44);
          v39 = fmaxf(v44, v39);
          v45 = fabs(buffer[1]);
          v43 = v43 + (float)(v45 * v45);
          v42 = fmaxf(v45, v42);
        }
        *peaks = v39;
        peaks[1] = v42;
        *accumulatedSquares = v41;
        accumulatedSquares[1] = v43;
        break;
      case 6:
        v46 = *(__m128 *)peaks;
        v47 = *(__m128 *)(peaks + 4);
        v48 = *(__m128 *)accumulatedSquares;
        v49 = *(__m128 *)(accumulatedSquares + 4);
        if ( length >> 1 )
        {
          v50 = 0;
          v51 = 0;
          v52 = &buffer[12 * ((length >> 1) - 1) + 12];
          do
          {
            v53 = *(__m128 *)buffer;
            buffer += 12;
            v54 = *(__m128 *)(buffer - 8);
            v55 = *(__m128 *)(buffer - 4);
            v56 = _mm_and_ps(v53, *(__m128 *)dword_596750);
            v57 = _mm_and_ps(v54, *(__m128 *)dword_596750);
            v58 = _mm_and_ps(v55, *(__m128 *)dword_596750);
            v48 = _mm_add_ps(v48, _mm_mul_ps(v53, v53));
            v49 = _mm_add_ps(v49, _mm_mul_ps(v54, v54));
            v46 = _mm_xor_ps(v46, _mm_and_ps(_mm_cmplt_ps(v46, v56), _mm_xor_ps(v56, v46)));
            v47 = _mm_xor_ps(v47, _mm_and_ps(_mm_cmplt_ps(v47, v57), _mm_xor_ps(v57, v47)));
            v50 = _mm_add_ps(v50, _mm_mul_ps(v55, v55));
            v51 = _mm_xor_ps(v51, _mm_and_ps(_mm_cmplt_ps(v51, v58), _mm_xor_ps(v58, v51)));
          }
          while ( buffer != v52 );
        }
        else
        {
          v50 = 0;
          v52 = buffer;
          v51 = 0;
        }
        v59 = _mm_shuffle_ps(v47, v51, 78);
        v60 = _mm_shuffle_ps(v51, v51, 14);
        *(__m128 *)peaks = _mm_xor_ps(_mm_and_ps(_mm_cmplt_ps(v46, v59), _mm_xor_ps(v59, v46)), v46);
        _mm_storel_ps((double *)peaks + 2, _mm_xor_ps(_mm_and_ps(_mm_cmplt_ps(v47, v60), _mm_xor_ps(v60, v47)), v47));
        *(__m128 *)accumulatedSquares = _mm_add_ps(_mm_shuffle_ps(v49, v50, 78), v48);
        _mm_storel_ps((double *)accumulatedSquares + 2, _mm_add_ps(_mm_shuffle_ps(v50, v50, 14), v49));
        if ( (length & 1) != 0 )
        {
          v61 = fabs(*v52);
          v62 = fabs(v52[1]);
          v63 = fabs(v52[2]);
          v64 = fabs(v52[3]);
          v65 = fabs(v52[4]);
          v66 = fabs(v52[5]);
          v67 = fmaxf(v61, *peaks);
          v68 = (float)(v61 * v61) + *accumulatedSquares;
          *peaks = v67;
          v69 = fmaxf(v62, peaks[1]);
          *accumulatedSquares = v68;
          v70 = (float)(v62 * v62) + accumulatedSquares[1];
          peaks[1] = v69;
          v71 = fmaxf(v63, peaks[2]);
          accumulatedSquares[1] = v70;
          v72 = (float)(v63 * v63) + accumulatedSquares[2];
          peaks[2] = v71;
          v73 = fmaxf(v64, peaks[3]);
          accumulatedSquares[2] = v72;
          v74 = (float)(v64 * v64) + accumulatedSquares[3];
          peaks[3] = v73;
          v75 = fmaxf(v65, peaks[4]);
          accumulatedSquares[3] = v74;
          v76 = (float)(v65 * v65) + accumulatedSquares[4];
          peaks[4] = v75;
          v77 = fmaxf(v66, peaks[5]);
          accumulatedSquares[4] = v76;
          v78 = (float)(v66 * v66) + accumulatedSquares[5];
          peaks[5] = v77;
          accumulatedSquares[5] = v78;
        }
        break;
      case 8:
        v79 = *(__m128 *)peaks;
        v80 = *(__m128 *)(peaks + 4);
        v81 = *(__m128 *)accumulatedSquares;
        for ( i = *(__m128 *)(accumulatedSquares + 4);
              length;
              v80 = _mm_xor_ps(v80, _mm_and_ps(_mm_cmplt_ps(v80, v86), _mm_xor_ps(v86, v80))) )
        {
          buffer += 8;
          v83 = *(__m128 *)(buffer - 8);
          v84 = *(__m128 *)(buffer - 4);
          --length;
          v85 = _mm_and_ps(v83, *(__m128 *)dword_596750);
          v86 = _mm_and_ps(v84, *(__m128 *)dword_596750);
          v81 = _mm_add_ps(v81, _mm_mul_ps(v83, v83));
          v79 = _mm_xor_ps(v79, _mm_and_ps(_mm_cmplt_ps(v79, v85), _mm_xor_ps(v85, v79)));
          i = _mm_add_ps(i, _mm_mul_ps(v84, v84));
        }
        *(__m128 *)peaks = v79;
        *((__m128 *)peaks + 1) = v80;
        *(__m128 *)accumulatedSquares = v81;
        *((__m128 *)accumulatedSquares + 1) = i;
        break;
      default:
        v5 = channels * length;
        if ( v5 )
        {
          v6 = 0;
          v7 = 0;
          do
          {
            v8 = v6++;
            v9 = fabs(buffer[v8]);
            v10 = v7;
            v11 = &peaks[v10];
            v12 = &accumulatedSquares[v10];
            v13 = fmaxf(v9, *v11);
            v14 = (float)(v9 * v9) + *v12;
            *v11 = v13;
            *v12 = v14;
            v7 = (v7 + 1) & ((int)(v7 + 1 - channels) >> 31);
          }
          while ( v5 != v6 );
        }
        break;
    }
    return;
  }
  v15 = *(__m128 *)flt_596740;
  if ( length >> 2 )
  {
    v16 = 0;
    v17 = length >> 2;
    v18 = buffer;
    do
    {
      v19 = *(__m128 *)v18;
      v18 += 4;
      --v17;
      v20 = _mm_and_ps(v19, *(__m128 *)dword_596750);
      v16 = _mm_add_ps(v16, _mm_mul_ps(v19, v19));
      v15 = _mm_xor_ps(v15, _mm_and_ps(_mm_cmplt_ps(v15, v20), _mm_xor_ps(v20, v15)));
    }
    while ( v17 );
    buffer += 4 * (unsigned int)((length >> 2) - 1) + 4;
  }
  else
  {
    v16 = 0;
  }
  squarestemp = v16;
  v21 = *peaks;
  if ( v15.m128_f32[0] <= v15.m128_f32[1] )
  {
    v22 = v15.m128_f32[3];
    if ( v15.m128_f32[1] <= v15.m128_f32[2] )
    {
      if ( v15.m128_f32[2] > v15.m128_f32[3] )
      {
LABEL_17:
        if ( v15.m128_f32[1] > v15.m128_f32[2] )
          goto LABEL_18;
        goto LABEL_54;
      }
    }
    else if ( v15.m128_f32[1] > v15.m128_f32[3] )
    {
      goto LABEL_17;
    }
LABEL_24:
    v23 = v22;
LABEL_25:
    if ( v21 > v23 )
      goto LABEL_29;
    if ( v15.m128_f32[0] <= v15.m128_f32[1] )
      goto LABEL_19;
    if ( v15.m128_f32[0] <= v15.m128_f32[2] )
      goto LABEL_62;
LABEL_28:
    v21 = fmaxf(v15.m128_f32[0], v22);
    goto LABEL_29;
  }
  if ( v15.m128_f32[0] <= v15.m128_f32[2] )
  {
    v22 = v15.m128_f32[3];
    if ( v15.m128_f32[2] <= v15.m128_f32[3] )
      goto LABEL_24;
    if ( v15.m128_f32[0] <= v15.m128_f32[2] )
    {
LABEL_54:
      v23 = v15.m128_f32[2];
      goto LABEL_25;
    }
    if ( v15.m128_f32[0] <= v15.m128_f32[1] )
    {
LABEL_18:
      if ( v21 > v15.m128_f32[1] )
        goto LABEL_29;
LABEL_19:
      if ( v15.m128_f32[1] > v15.m128_f32[2] )
        goto LABEL_20;
LABEL_62:
      v21 = v22;
      if ( v15.m128_f32[2] <= v22 )
        goto LABEL_29;
      if ( v15.m128_f32[0] > v15.m128_f32[1] )
      {
        v87 = _mm_cmplt_ss((__m128)v15.m128_u32[2], v15);
        LODWORD(v21) = _mm_andnot_ps(v87, (__m128)v15.m128_u32[2]).m128_u32[0]
                     | COERCE_UNSIGNED_INT(fmaxf(v15.m128_f32[0], v15.m128_f32[1])) & v87.m128_i32[0];
        goto LABEL_29;
      }
      goto LABEL_21;
    }
LABEL_48:
    if ( v21 > v15.m128_f32[0] )
      goto LABEL_29;
    goto LABEL_28;
  }
  v22 = v15.m128_f32[3];
  if ( v15.m128_f32[0] > v15.m128_f32[3] )
    goto LABEL_48;
  if ( v21 > v15.m128_f32[3] )
    goto LABEL_29;
  if ( v15.m128_f32[0] > v15.m128_f32[1] )
    goto LABEL_28;
LABEL_20:
  v21 = v22;
  if ( v15.m128_f32[1] > v22 )
LABEL_21:
    v21 = fmaxf(v15.m128_f32[1], v15.m128_f32[2]);
LABEL_29:
  v24 = length & 3;
  for ( j = (float)((float)((float)(squarestemp.m128_f32[0] + squarestemp.m128_f32[1]) + squarestemp.m128_f32[2])
                  + squarestemp.m128_f32[3])
          + *accumulatedSquares; v24; v21 = fmaxf(v26, v21) )
  {
    ++buffer;
    --v24;
    v26 = fabs(*(buffer - 1));
    j = j + (float)(v26 * v26);
  }
  *accumulatedSquares = j;
  *peaks = v21;
}


