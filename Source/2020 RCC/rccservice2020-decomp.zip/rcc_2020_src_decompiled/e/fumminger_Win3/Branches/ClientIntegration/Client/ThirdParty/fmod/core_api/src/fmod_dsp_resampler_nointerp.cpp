// Address: 0x21eabc0 | Name: FMOD_Resampler_NoInterp
void __fastcall FMOD_Resampler_NoInterp(
        float *out,
        int outlength,
        void *src,
        FMOD_SOUND_FORMAT_0 srcformat,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed,
        int channels)
{
  FMOD_UINT64 v8; // r8
  int v9; // r11d
  float *v10; // rax
  FMOD_SINT64 v11; // r10
  FMOD_SINT64 v12; // r12
  FMOD_UINT64 v13; // rcx
  FMOD_UINT64 v14; // r8
  float v15; // xmm4_4
  float v16; // xmm3_4
  FMOD_UINT64 v17; // rbp
  float v18; // xmm2_4
  FMOD_UINT64 v19; // rbp
  float v20; // xmm1_4
  int v21; // esi
  FMOD_SINT64 v22; // r8
  FMOD_UINT64 v23; // rax
  FMOD_SINT64 v24; // r11
  FMOD_UINT64 v25; // r10
  float *v26; // rcx
  unsigned int v27; // eax
  unsigned int v28; // r9d
  __int64 v29; // r8
  FMOD_SINT64 v30; // r11
  FMOD_UINT64 v31; // r10
  float *v32; // rcx
  unsigned int v33; // eax
  unsigned int v34; // r9d
  __int64 v35; // r8
  FMOD_SINT64 v36; // r11
  FMOD_UINT64 v37; // r10
  float *v38; // rcx
  unsigned int v39; // eax
  unsigned int v40; // r9d
  __int64 v41; // r8
  FMOD_SINT64 v42; // r13
  FMOD_UINT64 v43; // r12
  float *v44; // rcx
  unsigned int v45; // r9d
  unsigned int v46; // r8d
  __int64 v47; // rax
  FMOD_SINT64 v48; // r11
  FMOD_UINT64 v49; // r10
  float *v50; // rcx
  unsigned int v51; // eax
  unsigned int v52; // r9d
  __int64 v53; // r8
  FMOD_UINT64 v54; // r8
  int v55; // r11d
  float *v56; // rax
  FMOD_SINT64 v57; // r10
  FMOD_SINT64 v58; // r12
  FMOD_UINT64 v59; // rcx
  FMOD_UINT64 v60; // r8
  int v61; // xmm3_4
  int v62; // xmm2_4
  FMOD_UINT64 v63; // rbp
  int v64; // xmm1_4
  FMOD_UINT64 v65; // rbp
  int v66; // xmm0_4
  int v67; // esi
  FMOD_SINT64 v68; // r8
  FMOD_UINT64 v69; // rax
  FMOD_UINT64 v70; // r13
  int v71; // r11d
  float *v72; // rcx
  FMOD_SINT64 v73; // r10
  FMOD_SINT64 v74; // rbp
  FMOD_UINT64 v75; // r8
  FMOD_UINT64 v76; // r13
  unsigned __int8 *v77; // r14
  int v78; // eax
  int v79; // r15d
  float v80; // xmm4_4
  unsigned __int8 *v81; // r14
  int v82; // eax
  int v83; // r15d
  float v84; // xmm3_4
  FMOD_UINT64 v85; // rax
  float v86; // xmm2_4
  unsigned __int8 *v87; // r14
  int v88; // r15d
  int v89; // esi
  FMOD_SINT64 v90; // r10
  FMOD_UINT64 v91; // r9
  unsigned __int8 *v92; // rcx
  FMOD_UINT64 mValue; // r8
  int v94; // r11d
  float *v95; // rax
  FMOD_SINT64 v96; // r10
  FMOD_SINT64 v97; // r12
  FMOD_UINT64 v98; // rcx
  FMOD_UINT64 v99; // r8
  int v100; // ebp
  float v101; // xmm4_4
  int v102; // ebp
  float v103; // xmm3_4
  FMOD_UINT64 v104; // rbp
  float v105; // xmm2_4
  FMOD_UINT64 v106; // rbp
  int v107; // esi
  FMOD_SINT64 v108; // r8
  FMOD_UINT64 v109; // rax
  void (*FMOD_Resampler_NoInterp_PCM16_Mono)(float *, int, void *, FMOD_UINT64P *, FMOD_SINT64P *); // rax

  switch ( srcformat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      if ( channels == 1 )
      {
        if ( outlength >> 2 )
        {
          mValue = position->mValue;
          v94 = outlength >> 2;
          v95 = out;
          v96 = 2 * speed->mValue;
          v97 = 4 * speed->mValue;
          v98 = mValue + speed->mValue;
          do
          {
            v99 = v96 + mValue;
            v95 += 4;
            v100 = *((char *)src + position->mHi);
            position->mValue = v98;
            v101 = (float)v100;
            v102 = *((char *)src + HIDWORD(v98));
            position->mValue = v99;
            v103 = (float)v102;
            v104 = HIDWORD(v99);
            mValue = v96 + v99;
            v105 = (float)*((char *)src + v104);
            v106 = v96 + v98;
            v98 += v97;
            position->mValue = v106;
            LODWORD(v106) = *((char *)src + HIDWORD(v106));
            position->mValue = mValue;
            *(v95 - 4) = v101 * 0.0078125;
            *(v95 - 3) = v103 * 0.0078125;
            *(v95 - 2) = v105 * 0.0078125;
            *(v95 - 1) = (float)(int)v106 * 0.0078125;
            --v94;
          }
          while ( v94 );
          out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
        }
        v107 = outlength & 3;
        if ( v107 )
        {
          v108 = speed->mValue;
          v109 = position->mValue + speed->mValue;
          do
          {
            *out++ = (float)*((char *)src + position->mHi) * 0.0078125;
            position->mValue = v109;
            v109 += v108;
            --v107;
          }
          while ( v107 );
        }
      }
      else if ( outlength )
      {
        v30 = speed->mValue;
        v31 = position->mValue + speed->mValue;
        do
        {
          if ( channels > 0 )
          {
            v32 = out;
            v33 = channels * position->mHi;
            v34 = channels + v33;
            do
            {
              v35 = v33++;
              *v32++ = (float)*((char *)src + v35) * 0.0078125;
            }
            while ( v33 != v34 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v31;
          v31 += v30;
          --outlength;
        }
        while ( outlength );
      }
      return;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      if ( channels == 1 )
      {
        FMOD_Resampler_NoInterp_PCM16_Mono = FMOD_Optimised_Routines.FMOD_Resampler_NoInterp_PCM16_Mono;
LABEL_81:
        FMOD_Resampler_NoInterp_PCM16_Mono(out, outlength, src, position, speed);
        return;
      }
      if ( channels == 2 )
      {
        FMOD_Resampler_NoInterp_PCM16_Mono = FMOD_Optimised_Routines.FMOD_Resampler_NoInterp_PCM16_Stereo;
        goto LABEL_81;
      }
      if ( outlength )
      {
        v36 = speed->mValue;
        v37 = position->mValue + speed->mValue;
        do
        {
          if ( channels > 0 )
          {
            v38 = out;
            v39 = channels * position->mHi;
            v40 = channels + v39;
            do
            {
              v41 = v39++;
              *v38++ = (float)*((__int16 *)src + v41) * 0.000030517578;
            }
            while ( v39 != v40 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v37;
          v37 += v36;
          --outlength;
        }
        while ( outlength );
      }
      return;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      if ( channels == 1 )
      {
        if ( outlength >> 2 )
        {
          v70 = position->mValue;
          v71 = outlength >> 2;
          v72 = out;
          v73 = 2 * speed->mValue;
          v74 = 4 * speed->mValue;
          v75 = position->mValue + speed->mValue;
          do
          {
            v76 = v73 + v70;
            v77 = (unsigned __int8 *)src + 3 * position->mHi;
            v78 = v77[1];
            v79 = *v77;
            LODWORD(v77) = v77[2];
            position->mValue = v75;
            v80 = (float)((((_DWORD)v77 << 24) | (v79 << 8) | (v78 << 16)) >> 8);
            v81 = (unsigned __int8 *)src + 3 * HIDWORD(v75);
            v82 = v81[1];
            v83 = *v81;
            LODWORD(v81) = v81[2];
            position->mValue = v76;
            v84 = (float)((((_DWORD)v81 << 24) | (v83 << 8) | (v82 << 16)) >> 8);
            v85 = v76;
            v70 = v73 + v76;
            v86 = (float)(((*((unsigned __int8 *)src + 3 * HIDWORD(v85) + 2) << 24)
                         | (*((unsigned __int8 *)src + 3 * HIDWORD(v85)) << 8)
                         | (*((unsigned __int8 *)src + 3 * HIDWORD(v85) + 1) << 16)) >> 8);
            position->mValue = v73 + v75;
            v87 = (unsigned __int8 *)src + 3 * ((v73 + v75) >> 32);
            LODWORD(v85) = v87[1];
            v88 = *v87;
            LODWORD(v87) = v87[2];
            position->mValue = v70;
            *v72 = v80 * 0.00000011920929;
            v72[1] = v84 * 0.00000011920929;
            v72 += 4;
            *(v72 - 2) = v86 * 0.00000011920929;
            *(v72 - 1) = (float)((((_DWORD)v87 << 24) | (v88 << 8) | ((_DWORD)v85 << 16)) >> 8) * 0.00000011920929;
            v75 += v74;
            --v71;
          }
          while ( v71 );
          out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
        }
        v89 = outlength & 3;
        if ( v89 )
        {
          v90 = speed->mValue;
          v91 = position->mValue + speed->mValue;
          do
          {
            ++out;
            v92 = (unsigned __int8 *)src + 3 * position->mHi;
            *(out - 1) = (float)(((v92[2] << 24) | (*v92 << 8) | (v92[1] << 16)) >> 8) * 0.00000011920929;
            position->mValue = v91;
            v91 += v90;
            --v89;
          }
          while ( v89 );
        }
      }
      else if ( outlength )
      {
        v42 = speed->mValue;
        v43 = position->mValue + speed->mValue;
        do
        {
          if ( channels > 0 )
          {
            v44 = out;
            v45 = channels * position->mHi;
            v46 = channels + v45;
            do
            {
              v47 = v45++;
              *v44++ = (float)(((*((unsigned __int8 *)src + 3 * v47 + 2) << 24)
                              | (*((unsigned __int8 *)src + 3 * v47) << 8)
                              | (*((unsigned __int8 *)src + 3 * v47 + 1) << 16)) >> 8)
                     * 0.00000011920929;
            }
            while ( v45 != v46 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v43;
          v43 += v42;
          --outlength;
        }
        while ( outlength );
      }
      return;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      if ( channels == 1 )
      {
        if ( outlength >> 2 )
        {
          v8 = position->mValue;
          v9 = outlength >> 2;
          v10 = out;
          v11 = 2 * speed->mValue;
          v12 = 4 * speed->mValue;
          v13 = v8 + speed->mValue;
          do
          {
            v14 = v11 + v8;
            v10 += 4;
            v15 = (float)*((int *)src + position->mHi);
            position->mValue = v13;
            v16 = (float)*((int *)src + HIDWORD(v13));
            position->mValue = v14;
            v17 = HIDWORD(v14);
            v8 = v11 + v14;
            v18 = (float)*((int *)src + v17);
            v19 = v11 + v13;
            v13 += v12;
            position->mValue = v19;
            v20 = (float)*((int *)src + HIDWORD(v19)) * 4.6566129e-10;
            position->mValue = v8;
            *(v10 - 4) = v15 * 4.6566129e-10;
            *(v10 - 3) = v16 * 4.6566129e-10;
            *(v10 - 2) = v18 * 4.6566129e-10;
            *(v10 - 1) = v20;
            --v9;
          }
          while ( v9 );
          out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
        }
        v21 = outlength & 3;
        if ( v21 )
        {
          v22 = speed->mValue;
          v23 = position->mValue + speed->mValue;
          do
          {
            *out++ = (float)*((int *)src + position->mHi) * 4.6566129e-10;
            position->mValue = v23;
            v23 += v22;
            --v21;
          }
          while ( v21 );
        }
      }
      else if ( outlength )
      {
        v48 = speed->mValue;
        v49 = position->mValue + speed->mValue;
        do
        {
          if ( channels > 0 )
          {
            v50 = out;
            v51 = channels * position->mHi;
            v52 = channels + v51;
            do
            {
              v53 = v51++;
              *v50++ = (float)*((int *)src + v53) * 4.6566129e-10;
            }
            while ( v51 != v52 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v49;
          v49 += v48;
          --outlength;
        }
        while ( outlength );
      }
      return;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      if ( channels == 1 )
      {
        if ( outlength >> 2 )
        {
          v54 = position->mValue;
          v55 = outlength >> 2;
          v56 = out;
          v57 = 2 * speed->mValue;
          v58 = 4 * speed->mValue;
          v59 = v54 + speed->mValue;
          do
          {
            v60 = v57 + v54;
            v56 += 4;
            v61 = *((_DWORD *)src + position->mHi);
            position->mValue = v59;
            v62 = *((_DWORD *)src + HIDWORD(v59));
            position->mValue = v60;
            v63 = HIDWORD(v60);
            v54 = v57 + v60;
            v64 = *((_DWORD *)src + v63);
            v65 = v57 + v59;
            v59 += v58;
            position->mValue = v65;
            v66 = *((_DWORD *)src + HIDWORD(v65));
            position->mValue = v54;
            *((_DWORD *)v56 - 4) = v61;
            *((_DWORD *)v56 - 3) = v62;
            *((_DWORD *)v56 - 2) = v64;
            *((_DWORD *)v56 - 1) = v66;
            --v55;
          }
          while ( v55 );
          out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
        }
        v67 = outlength & 3;
        if ( v67 )
        {
          v68 = speed->mValue;
          v69 = position->mValue + speed->mValue;
          do
          {
            *out++ = *((float *)src + position->mHi);
            position->mValue = v69;
            v69 += v68;
            --v67;
          }
          while ( v67 );
        }
      }
      else if ( outlength )
      {
        v24 = speed->mValue;
        v25 = position->mValue + speed->mValue;
        do
        {
          if ( channels > 0 )
          {
            v26 = out;
            v27 = channels * position->mHi;
            v28 = channels + v27;
            do
            {
              v29 = v27++;
              *v26++ = *((float *)src + v29);
            }
            while ( v27 != v28 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v25;
          v25 += v24;
          --outlength;
        }
        while ( outlength );
      }
      return;
    default:
      return;
  }
}


