// Address: 0x2265320 | Name: FMOD::init_mparams
int __fastcall FMOD::init_mparams(FMOD::malloc_params *mparams)
{
  bool v1; // zf
  int result; // eax

  v1 = mparams->magic == 0;
  mparams->mmap_threshold = -1;
  mparams->trim_threshold = -1;
  mparams->default_mflags = 0;
  if ( v1 )
  {
    mparams->magic = 1482184792;
    stru_2B06460.mflags = 0;
  }
  mparams->page_size = 4096;
  mparams->granularity = 4096;
  return result;
}


// Address: 0x2265360 | Name: _ZN4FMOD23create_mspace_with_baseEPvmiPFS0_iS0_ES0_
FMOD::mspace __fastcall FMOD::create_mspace_with_base(
        void *base,
        size_t capacity,
        int locked,
        void *(*morecore)(int, void *),
        void *morecoreuserdata)
{
  FMOD::mspace result; // rax
  __int64 v10; // r11
  char *v11; // r11
  unsigned int v12; // esi
  _DWORD *v13; // rdi
  __int64 v14; // rcx
  _DWORD *v15; // rdi
  size_t page_size; // rdx
  size_t magic; // rcx
  int v18; // r9d
  size_t granularity; // rdx
  __int64 v20; // rdx
  __int64 v21; // rdx
  __int64 v22; // rax
  char *v23; // rdx
  unsigned __int64 v24; // rsi
  __int64 v25; // rax
  FMOD::malloc_params mparams; // [rsp+0h] [rbp-58h] BYREF

  memset(&mparams, 0, sizeof(mparams));
  FMOD::init_mparams(&mparams);
  mparams.page_size = capacity;
  mparams.trim_threshold = -1;
  if ( capacity <= 0x420 )
  {
    result = 0;
    goto LABEL_19;
  }
  result = 0;
  if ( capacity < -(__int64)(capacity + 1056) )
  {
    v10 = 0;
    if ( (((_BYTE)base + 16) & 0xF) != 0 )
      v10 = -(char)((_BYTE)base + 16) & 0xF;
    v11 = (char *)base + v10;
    v12 = 976;
    v13 = v11 + 16;
    if ( (((_BYTE)v11 + 16) & 1) != 0 )
    {
      v11[16] = 0;
      v13 = v11 + 17;
      LOBYTE(v12) = -49;
    }
    if ( ((unsigned __int8)v13 & 2) != 0 )
    {
      v13 = (_DWORD *)((char *)v13 + 2);
      v12 -= 2;
      *((_WORD *)v13 - 1) = 0;
    }
    if ( ((unsigned __int8)v13 & 4) != 0 )
    {
      *v13 = 0;
      v12 -= 4;
      ++v13;
    }
    v14 = v12 >> 3;
    memset(v13, 0, 8 * v14);
    v15 = &v13[2 * v14];
    if ( (v12 & 4) != 0 )
    {
      *v15++ = 0;
      if ( (v12 & 2) == 0 )
      {
LABEL_13:
        if ( (v12 & 1) == 0 )
          goto LABEL_14;
        goto LABEL_20;
      }
    }
    else if ( (v12 & 2) == 0 )
    {
      goto LABEL_13;
    }
    v15 = (_DWORD *)((char *)v15 + 2);
    *((_WORD *)v15 - 1) = 0;
    if ( (v12 & 1) == 0 )
    {
LABEL_14:
      page_size = mparams.page_size;
      magic = mparams.magic;
      v18 = 0;
      *((_QWORD *)v11 + 1) = 979;
      *((_QWORD *)v11 + 5) = base;
      *((_QWORD *)v11 + 111) = base;
      *((_QWORD *)v11 + 109) = capacity;
      *((_QWORD *)v11 + 116) = page_size;
      granularity = mparams.granularity;
      *((_QWORD *)v11 + 115) = magic;
      *((_QWORD *)v11 + 108) = capacity;
      *((_QWORD *)v11 + 112) = capacity;
      *((_QWORD *)v11 + 9) = magic;
      *((_QWORD *)v11 + 117) = granularity;
      *((_QWORD *)v11 + 118) = mparams.mmap_threshold;
      *((_QWORD *)v11 + 119) = mparams.trim_threshold;
      LODWORD(granularity) = mparams.default_mflags;
      *((_QWORD *)v11 + 120) = *(_QWORD *)&mparams.default_mflags;
      *((_DWORD *)v11 + 220) = granularity | 4;
      do
      {
        v20 = (unsigned int)(2 * v18++);
        v21 = (__int64)&v11[8 * v20 + 80];
        *(_QWORD *)(v21 + 24) = v21;
        *(_QWORD *)(v21 + 16) = v21;
      }
      while ( v18 != 32 );
      v22 = 0;
      if ( (((_BYTE)v11 - 32) & 0xF) != 0 )
        v22 = -((_DWORD)v11 + 992) & 0xF;
      v23 = &v11[v22 + 976];
      v24 = (_BYTE *)base - (v11 + 976) + capacity - 80 - v22;
      v25 = *((_QWORD *)v11 + 119);
      *((_QWORD *)v11 + 7) = v23;
      *((_QWORD *)v11 + 4) = v24;
      *((_QWORD *)v23 + 1) = v24 | 1;
      *(_QWORD *)&v23[v24 + 8] = 80;
      *((_QWORD *)v11 + 8) = v25;
      *((_DWORD *)v11 + 228) = 8;
      result = v11 + 16;
      goto LABEL_19;
    }
LABEL_20:
    *(_BYTE *)v15 = 0;
    goto LABEL_14;
  }
LABEL_19:
  *((_QWORD *)result + 119) = morecore;
  *((_QWORD *)result + 120) = morecoreuserdata;
  return result;
}


// Address: 0x22655c0 | Name: _ZN4FMOD13mspace_mallocEPvm
void *__fastcall FMOD::mspace_malloc(FMOD::mspace msp, size_t bytes)
{
  FMOD::malloc_params *v3; // r12
  int v4; // edi
  size_t v5; // rbp
  size_t v6; // rcx
  int v7; // eax
  int v8; // edx
  int v9; // ecx
  char *v10; // rdx
  __int64 v11; // rax
  unsigned __int64 v12; // rsi
  __int64 v13; // rcx
  void *result; // rax
  size_t v15; // rax
  size_t v16; // rax
  __int64 v17; // rsi
  unsigned __int64 v18; // rcx
  unsigned __int64 v19; // r12
  unsigned __int64 v20; // rdi
  int v21; // r11d
  size_t v22; // rdx
  __int64 v23; // rax
  size_t v24; // rcx
  unsigned int v25; // esi
  int v26; // ecx
  unsigned int v27; // esi
  int v28; // r9d
  unsigned int v29; // eax
  int v30; // ecx
  unsigned int v31; // eax
  int v32; // ecx
  char *v33; // rsi
  unsigned __int64 v34; // r9
  unsigned int v35; // ecx
  unsigned __int64 v36; // rsi
  size_t v37; // rcx
  size_t v38; // rbp
  int v39; // r10d
  size_t v40; // rdx
  __int64 v41; // rdi
  __int64 v42; // rcx
  char *v43; // r8
  char v44; // cl
  char *v45; // rdx
  size_t v46; // rdx
  __int64 v47; // rdx
  size_t v48; // rax
  unsigned __int64 v49; // rax
  unsigned __int64 v50; // r9
  _QWORD *v51; // rsi
  int v52; // ecx
  unsigned int v53; // r13d
  _QWORD *v54; // r8
  _QWORD *v55; // rax
  size_t i; // r10
  unsigned __int64 v57; // rdx
  _QWORD *v58; // rdx
  _QWORD *v59; // rdx
  size_t v60; // r8
  unsigned __int64 v61; // r10
  size_t v62; // rsi
  _QWORD *v63; // rdx
  unsigned __int64 v64; // rdi
  unsigned __int64 v65; // rcx
  unsigned int v66; // ecx
  char *v67; // r10
  unsigned __int64 v68; // rcx
  unsigned __int64 v69; // rdi
  unsigned __int64 v70; // rdi
  size_t v71; // r9
  unsigned __int64 v72; // rdx
  unsigned __int64 *v73; // r12
  __int64 v74; // r12
  unsigned __int64 v75; // r14
  int v76; // r9d
  unsigned int v77; // ecx
  unsigned int v78; // r8d
  unsigned int v79; // eax
  int v80; // ecx
  unsigned int v81; // eax
  unsigned __int64 v82; // rcx
  unsigned __int64 v83; // rax
  unsigned __int64 v84; // r8
  unsigned __int64 v85; // rsi
  unsigned __int64 v86; // r13
  size_t v87; // r11
  _QWORD *v88; // rsi
  unsigned __int64 v89; // r10
  unsigned __int64 v90; // rcx
  unsigned int v91; // ecx
  char *v92; // r13
  unsigned __int64 v93; // rcx
  unsigned __int64 v94; // r9
  unsigned __int64 v95; // r9
  size_t v96; // r8
  unsigned __int64 v97; // r13
  unsigned __int64 v98; // rax
  unsigned __int64 v99; // rax
  bool v100; // cc
  unsigned __int64 v101; // rsi
  unsigned __int64 *v102; // rcx
  char *v103; // rdx
  __int64 v104; // rdi
  char *v105; // rdx
  __int64 v106; // rdi
  unsigned __int64 v107; // rdx
  __int64 v108; // rax
  _QWORD *v109; // rcx
  int v110; // edi
  __int64 v111; // rax
  __int64 v112; // rdi
  __int64 v113; // r9
  __int64 v114; // rax
  _QWORD *v115; // rax
  unsigned __int64 v116; // rcx
  char *v117; // rax
  unsigned __int64 v118; // r8
  unsigned __int64 v119; // rcx
  int v120; // edi
  char *v121; // rdx
  size_t v122; // r14
  size_t v123; // r14
  __int64 v124; // rdi
  __int64 v125; // rax
  unsigned __int64 v126; // r14
  __int64 v127; // rsi
  __int64 v128; // rax
  __int64 v129; // rax
  __int64 v130; // rdx
  __int64 v131; // rdi
  size_t v132; // r9
  size_t v133; // r8
  __int64 v134; // rdx
  __int64 v135; // rcx
  unsigned __int64 v136; // rdx
  unsigned __int64 v137; // rcx
  unsigned __int64 v138; // rsi
  unsigned __int64 v139; // r10
  char *v140; // r11
  unsigned __int64 v141; // rcx
  size_t v142; // rcx
  int v143; // edi
  char *v144; // rdx
  int v145; // esi
  char *v146; // rcx
  unsigned __int64 v147; // rax
  unsigned int v148; // edi
  int v149; // eax
  unsigned int v150; // edx
  int v151; // eax
  unsigned int v152; // eax
  __int64 v153; // rax
  unsigned int v154; // ecx
  int v155; // edx
  char v156; // cl
  unsigned __int64 v157; // rdx
  __int64 v158; // rdi
  unsigned __int64 v159; // rcx
  __int64 v160; // rcx
  unsigned __int64 v161; // rax
  unsigned __int64 v162; // rcx
  __int64 v163; // rax
  int v164; // eax
  unsigned int v165; // ecx
  unsigned int v166; // edx
  int v167; // eax
  unsigned int v168; // esi
  unsigned int v169; // eax
  int v170; // ecx
  unsigned int v171; // eax
  unsigned __int64 v172; // rcx
  int v173; // r9d
  char *v174; // rdx
  int v175; // edi
  char *v176; // rcx
  __int64 v177; // rax
  int v178; // ecx
  __int64 v179; // rax
  char *v180; // rdx
  char *v181; // rdx
  __int64 v182; // rax
  char *v183; // rcx
  __int64 v184; // r14
  char *v185; // rdx
  __int64 v186; // rax
  unsigned __int64 v187; // r12
  unsigned int v188; // esi
  int v189; // eax
  unsigned int v190; // edx
  int v191; // eax
  unsigned int v192; // eax
  unsigned __int64 v193; // rdx
  unsigned int v194; // r10d
  int v195; // edx
  unsigned int v196; // edi
  int v197; // edx
  unsigned int v198; // edx
  __int64 v199; // rdx
  unsigned int v200; // ecx
  int v201; // r10d
  __int64 v202; // rdx
  _QWORD *v203; // r14
  _QWORD *v204; // rcx
  _QWORD *v205; // r13
  size_t v206; // rdx
  unsigned int v207; // edi
  int v208; // edx
  unsigned int v209; // esi
  int v210; // edx
  unsigned int v211; // edx
  __int64 v212; // rdx
  unsigned int v213; // ecx
  int v214; // esi
  unsigned __int64 v215; // rsi
  char v216; // cl
  size_t v217; // rcx
  size_t v218; // rdi
  __int64 v219; // rdi
  unsigned __int64 v220; // rcx
  unsigned __int64 v221; // rdx
  size_t v222; // rdx
  __int64 v223; // rsi
  __int64 v224; // rcx
  char *v225; // r9
  char v226; // cl
  char *v227; // rdx
  unsigned __int64 v228; // rdi
  char v229; // cl
  unsigned __int64 v230; // rcx
  unsigned __int64 v231; // r10
  __int64 v232; // r10
  unsigned __int64 v233; // rcx
  unsigned __int64 v234; // rdx
  _QWORD *v235; // rsi
  unsigned __int64 v236; // r10
  unsigned __int64 v237; // rcx
  unsigned int v238; // ecx
  char *v239; // r11
  unsigned __int64 v240; // rcx
  unsigned __int64 v241; // r10
  unsigned __int64 v242; // r10
  __int64 v243; // rdx
  unsigned __int64 v244; // r14
  __int64 v245; // rax
  FMOD::malloc_chunk *v246; // r13
  size_t trim_threshold; // rax
  _QWORD *v248; // r15
  _QWORD *v249; // rcx
  _QWORD *v250; // r14
  size_t v251; // r8
  size_t v252; // r8
  _QWORD *v253; // rcx
  _QWORD *v254; // r11
  _QWORD *v255; // rbp

  v3 = (FMOD::malloc_params *)((char *)msp + 904);
  if ( msp != (FMOD::mspace)-904LL && !*((_QWORD *)msp + 114) )
    FMOD::init_mparams((FMOD::malloc_params *)((char *)msp + 904));
  if ( bytes <= 0xE8 )
  {
    if ( bytes <= 0x16 )
    {
      v4 = *(_DWORD *)msp;
      LOBYTE(v6) = 4;
      v8 = 4;
      v5 = 32;
      v7 = *(_DWORD *)msp >> 4;
      if ( (v7 & 3) != 0 )
        goto LABEL_7;
    }
    else
    {
      v4 = *(_DWORD *)msp;
      v5 = (bytes + 23) & 0xFFFFFFFFFFFFFFF0LL;
      v6 = v5 >> 3;
      v7 = *(_DWORD *)msp >> (v5 >> 3);
      v8 = v5 >> 3;
      if ( (v7 & 3) != 0 )
      {
LABEL_7:
        v9 = v8 + !(v7 & 1);
        v10 = (char *)msp + 8 * (unsigned int)(2 * v9) + 64;
        v11 = *((_QWORD *)msp + (unsigned int)(2 * v9) + 10);
        v12 = *(_QWORD *)(v11 + 16);
        if ( v10 == (char *)v12 )
        {
          *(_DWORD *)msp = v4 & __ROL4__(-2, v9);
        }
        else if ( v12 >= *((_QWORD *)msp + 3) )
        {
          *((_QWORD *)msp + (unsigned int)(2 * v9) + 10) = v12;
          *(_QWORD *)(v12 + 24) = v10;
        }
        v13 = (unsigned int)(8 * v9);
        *(_QWORD *)(v11 + 8) = (unsigned int)v13 | 3;
        *(_QWORD *)(v11 + v13 + 8) |= 1uLL;
        return (void *)(v11 + 16);
      }
    }
    v22 = *((_QWORD *)msp + 1);
    if ( v5 <= v22 )
      goto LABEL_27;
    if ( v7 )
    {
      v25 = ((v7 << v6) & ((2 * (1 << v6)) | (-2 * (1 << v6))) & -((v7 << v6) & ((2 * (1 << v6)) | (-2 * (1 << v6)))))
          - 1;
      v26 = (v25 >> 12) & 0x10;
      v27 = v25 >> v26;
      v28 = ((v27 >> 5) & 8) + v26;
      v29 = v27 >> ((v27 >> 5) & 8);
      v30 = (v29 >> 2) & 4;
      v31 = v29 >> v30;
      v32 = ((v31 >> ((v31 >> 1) & 2) >> 1) & 1)
          + ((v31 >> 1) & 2)
          + v28
          + v30
          + (v31 >> ((v31 >> 1) & 2) >> (((v31 >> ((v31 >> 1) & 2)) & 2) != 0));
      v33 = (char *)msp + 8 * (unsigned int)(2 * v32) + 64;
      v23 = *((_QWORD *)msp + (unsigned int)(2 * v32) + 10);
      v34 = *(_QWORD *)(v23 + 16);
      if ( v33 == (char *)v34 )
      {
        *(_DWORD *)msp = v4 & ~(1 << v32);
      }
      else if ( v34 >= *((_QWORD *)msp + 3) )
      {
        *((_QWORD *)msp + (unsigned int)(2 * v32) + 10) = v34;
        *(_QWORD *)(v34 + 24) = v33;
      }
      v35 = 8 * v32;
      v36 = v35 - v5;
      if ( v36 <= 0x1F )
      {
        *(_QWORD *)(v23 + 8) = v35 | 3;
        *(_QWORD *)(v23 + v35 + 8) |= 1uLL;
      }
      else
      {
        v37 = v5;
        v38 = v23 + v5;
        *(_QWORD *)(v23 + 8) = v37 | 3;
        *(_QWORD *)(v38 + 8) = v36 | 1;
        *(_QWORD *)(v38 + v36) = v36;
        if ( v22 )
        {
          v39 = *(_DWORD *)msp;
          v40 = v22 >> 3;
          v41 = *((_QWORD *)msp + 4);
          v42 = (unsigned int)(2 * v40);
          v43 = (char *)msp + 8 * v42 + 64;
          if ( _bittest(&v39, v40) )
          {
            v45 = (char *)*((_QWORD *)msp + v42 + 10);
            if ( (unsigned __int64)v45 < *((_QWORD *)msp + 3) )
              v45 = (char *)msp + 8 * v42 + 64;
          }
          else
          {
            v44 = v40;
            v45 = v43;
            *(_DWORD *)msp = v39 | (1 << v44);
          }
          *((_QWORD *)v43 + 2) = v41;
          *((_QWORD *)v45 + 3) = v41;
          *(_QWORD *)(v41 + 16) = v45;
          *(_QWORD *)(v41 + 24) = v43;
        }
        *((_QWORD *)msp + 1) = v36;
        *((_QWORD *)msp + 4) = v38;
      }
      return (void *)(v23 + 16);
    }
    v76 = *((_DWORD *)msp + 1);
    v15 = *((_QWORD *)msp + 1);
    if ( v76 )
    {
      v77 = (((v76 & (unsigned int)-v76) - 1) >> 12) & 0x10;
      v78 = ((((v76 & (unsigned int)-v76) - 1) >> v77 >> 5) & 8) + v77;
      v79 = ((v76 & (unsigned int)-v76) - 1) >> v77 >> ((((v76 & (unsigned int)-v76) - 1) >> v77 >> 5) & 8);
      v80 = (v79 >> 2) & 4;
      v81 = v79 >> v80;
      v83 = *((_QWORD *)msp
            + ((v81 >> ((v81 >> 1) & 2) >> 1) & 1)
            + ((v81 >> 1) & 2)
            + v78
            + v80
            + (v81 >> ((v81 >> 1) & 2) >> (((v81 >> ((v81 >> 1) & 2)) & 2) != 0))
            + 74);
      v82 = v83;
      v84 = (*(_QWORD *)(v83 + 8) & 0xFFFFFFFFFFFFFFFCLL) - v5;
      while ( 1 )
      {
        v85 = *(_QWORD *)(v82 + 32);
        if ( !v85 )
        {
          v85 = *(_QWORD *)(v82 + 40);
          if ( !v85 )
            break;
        }
        if ( (*(_QWORD *)(v85 + 8) & 0xFFFFFFFFFFFFFFFCLL) - v5 < v84 )
        {
          v84 = (*(_QWORD *)(v85 + 8) & 0xFFFFFFFFFFFFFFFCLL) - v5;
          v83 = v85;
        }
        v82 = v85;
      }
      v86 = *((_QWORD *)msp + 3);
      if ( v86 <= v83 )
      {
        v87 = v83 + v5;
        if ( v83 + v5 > v83 )
        {
          v88 = *(_QWORD **)(v83 + 24);
          v89 = *(_QWORD *)(v83 + 48);
          if ( (_QWORD *)v83 == v88 )
          {
            v88 = *(_QWORD **)(v83 + 40);
            v248 = (_QWORD *)(v83 + 40);
            if ( v88 || (v88 = *(_QWORD **)(v83 + 32), v248 = (_QWORD *)(v83 + 32), v88) )
            {
              while ( 1 )
              {
                v249 = (_QWORD *)v88[5];
                v250 = v88 + 5;
                if ( !v249 )
                {
                  v249 = (_QWORD *)v88[4];
                  v250 = v88 + 4;
                  if ( !v249 )
                    break;
                }
                v88 = v249;
                v248 = v250;
              }
              if ( v86 <= (unsigned __int64)v248 )
                *v248 = 0;
            }
          }
          else
          {
            v90 = *(_QWORD *)(v83 + 16);
            if ( v86 <= v90 )
            {
              *(_QWORD *)(v90 + 24) = v88;
              v88[2] = v90;
            }
          }
          if ( v89 )
          {
            v91 = *(_DWORD *)(v83 + 56);
            v92 = (char *)msp + 8 * v91;
            if ( v83 == *((_QWORD *)v92 + 74) )
            {
              *((_QWORD *)v92 + 74) = v88;
              if ( !v88 )
              {
                *((_DWORD *)msp + 1) = v76 & __ROL4__(-2, v91);
                goto LABEL_123;
              }
              v93 = *((_QWORD *)msp + 3);
              goto LABEL_116;
            }
            v93 = *((_QWORD *)msp + 3);
            if ( v89 >= v93 )
            {
              if ( v83 == *(_QWORD *)(v89 + 32) )
                *(_QWORD *)(v89 + 32) = v88;
              else
                *(_QWORD *)(v89 + 40) = v88;
            }
            if ( v88 )
            {
LABEL_116:
              if ( (unsigned __int64)v88 >= v93 )
              {
                v94 = *(_QWORD *)(v83 + 32);
                v88[6] = v89;
                if ( v94 && v94 >= v93 )
                {
                  v88[4] = v94;
                  *(_QWORD *)(v94 + 48) = v88;
                }
                v95 = *(_QWORD *)(v83 + 40);
                if ( v95 && v95 >= v93 )
                {
                  v88[5] = v95;
                  *(_QWORD *)(v95 + 48) = v88;
                }
              }
            }
          }
LABEL_123:
          if ( v84 > 0x1F )
          {
            *(_QWORD *)(v83 + 8) = v5 | 3;
            *(_QWORD *)(v87 + 8) = v84 | 1;
            *(_QWORD *)(v87 + v84) = v84;
            if ( v22 )
            {
              v222 = v22 >> 3;
              v223 = *((_QWORD *)msp + 4);
              v224 = (unsigned int)(2 * v222);
              v225 = (char *)msp + 8 * v224 + 64;
              if ( _bittest(&v4, v222) )
              {
                v227 = (char *)*((_QWORD *)msp + v224 + 10);
                if ( (unsigned __int64)v227 < *((_QWORD *)msp + 3) )
                  v227 = (char *)msp + 8 * v224 + 64;
              }
              else
              {
                v226 = v222;
                v227 = v225;
                *(_DWORD *)msp = v4 | (1 << v226);
              }
              *((_QWORD *)v225 + 2) = v223;
              *((_QWORD *)v227 + 3) = v223;
              *(_QWORD *)(v223 + 16) = v227;
              *(_QWORD *)(v223 + 24) = v225;
            }
            *((_QWORD *)msp + 1) = v84;
            *((_QWORD *)msp + 4) = v87;
          }
          else
          {
            v96 = v5 + v84;
            *(_QWORD *)(v83 + 8) = v96 | 3;
            *(_QWORD *)(v83 + v96 + 8) |= 1uLL;
          }
          result = (void *)(v83 + 16);
          if ( result )
            return result;
          goto LABEL_25;
        }
      }
      v15 = *((_QWORD *)msp + 1);
    }
LABEL_14:
    if ( v5 <= v15 )
      goto LABEL_26;
    goto LABEL_15;
  }
  if ( bytes > 0xFFFFFFFFFFFFFF7FLL )
  {
    v15 = *((_QWORD *)msp + 1);
    v5 = -1;
    goto LABEL_14;
  }
  v21 = *((_DWORD *)msp + 1);
  v5 = (bytes + 23) & 0xFFFFFFFFFFFFFFF0LL;
  if ( !v21 )
    goto LABEL_25;
  v49 = v5 >> 8;
  v50 = -(__int64)v5;
  if ( v5 >> 8 )
  {
    if ( v49 > 0xFFFF )
    {
      v51 = (_QWORD *)*((_QWORD *)msp + 105);
      LOBYTE(v52) = 0;
      LOBYTE(v53) = 31;
      if ( !v51 )
        goto LABEL_205;
      goto LABEL_47;
    }
    v188 = ((unsigned int)(v49 - 256) >> 16) & 8;
    v189 = (_DWORD)v49 << (((unsigned int)(v49 - 256) >> 16) & 8);
    v190 = v188 + (((unsigned int)(v189 - 4096) >> 16) & 4);
    v191 = v189 << (((unsigned int)(v189 - 4096) >> 16) & 4);
    v192 = ((unsigned int)(v191 << (((unsigned int)(v191 - 0x4000) >> 16) & 2)) >> 15)
         - (v190
          + (((unsigned int)(v191 - 0x4000) >> 16) & 2));
    v53 = ((v5 >> ((unsigned __int8)v192 + 21)) & 1) + 2 * v192 + 28;
    v51 = (_QWORD *)*((_QWORD *)msp + v53 + 74);
    if ( !v51 )
      goto LABEL_205;
    LOBYTE(v52) = 0;
    if ( ((v5 >> ((unsigned __int8)v192 + 21)) & 1) + 2 * v192 == 3 )
      goto LABEL_47;
  }
  else
  {
    v51 = (_QWORD *)*((_QWORD *)msp + 74);
    v53 = 0;
    if ( !v51 )
      goto LABEL_205;
  }
  v52 = 57 - (v53 >> 1);
LABEL_47:
  v54 = 0;
  v55 = 0;
  for ( i = v5 << v52; ; i *= 2LL )
  {
    v57 = (v51[1] & 0xFFFFFFFFFFFFFFFCLL) - v5;
    if ( v57 < v50 )
      break;
LABEL_52:
    v58 = (_QWORD *)v51[5];
    v51 = (_QWORD *)v51[(i >> 63) + 4];
    if ( v58 != v51 && v58 )
      v54 = v58;
    if ( !v51 )
      goto LABEL_56;
  }
  if ( v57 )
  {
    v50 = (v51[1] & 0xFFFFFFFFFFFFFFFCLL) - v5;
    v55 = v51;
    goto LABEL_52;
  }
  v54 = v51;
  v50 = 0;
  v55 = v51;
LABEL_56:
  if ( v55 || v54 )
  {
LABEL_57:
    if ( v54 )
    {
      while ( 1 )
      {
        if ( (v54[1] & 0xFFFFFFFFFFFFFFFCLL) - v5 < v50 )
        {
          v50 = (v54[1] & 0xFFFFFFFFFFFFFFFCLL) - v5;
          v55 = v54;
        }
        v59 = (_QWORD *)v54[4];
        if ( !v59 )
        {
          v59 = (_QWORD *)v54[5];
          if ( !v59 )
            break;
        }
        v54 = v59;
      }
    }
    if ( !v55 )
      goto LABEL_25;
    v60 = *((_QWORD *)msp + 1);
    if ( v50 >= v60 - v5 )
      goto LABEL_87;
    v61 = *((_QWORD *)msp + 3);
    if ( v61 > (unsigned __int64)v55 )
      goto LABEL_87;
    v62 = (size_t)v55 + v5;
    if ( (_QWORD *)((char *)v55 + v5) <= v55 )
      goto LABEL_87;
    v63 = (_QWORD *)v55[3];
    v64 = v55[6];
    if ( v55 == v63 )
    {
      v63 = (_QWORD *)v55[5];
      v203 = v55 + 5;
      if ( v63 || (v63 = (_QWORD *)v55[4], v203 = v55 + 4, v63) )
      {
        while ( 1 )
        {
          v204 = (_QWORD *)v63[5];
          v205 = v63 + 5;
          if ( !v204 )
          {
            v204 = (_QWORD *)v63[4];
            v205 = v63 + 4;
            if ( !v204 )
              break;
          }
          v63 = v204;
          v203 = v205;
        }
        if ( v61 <= (unsigned __int64)v203 )
          *v203 = 0;
      }
    }
    else
    {
      v65 = v55[2];
      if ( v61 <= v65 )
      {
        *(_QWORD *)(v65 + 24) = v63;
        v63[2] = v65;
      }
    }
    if ( v64 )
    {
      v66 = *((_DWORD *)v55 + 14);
      v67 = (char *)msp + 8 * v66;
      if ( v55 != *((_QWORD **)v67 + 74) )
      {
        v68 = *((_QWORD *)msp + 3);
        if ( v64 >= v68 )
        {
          if ( v55 == *(_QWORD **)(v64 + 32) )
            *(_QWORD *)(v64 + 32) = v63;
          else
            *(_QWORD *)(v64 + 40) = v63;
        }
        if ( !v63 )
          goto LABEL_84;
        goto LABEL_77;
      }
      *((_QWORD *)v67 + 74) = v63;
      if ( v63 )
      {
        v68 = *((_QWORD *)msp + 3);
LABEL_77:
        if ( (unsigned __int64)v63 >= v68 )
        {
          v63[6] = v64;
          v69 = v55[4];
          if ( v69 && v69 >= v68 )
          {
            v63[4] = v69;
            *(_QWORD *)(v69 + 48) = v63;
          }
          v70 = v55[5];
          if ( v70 && v70 >= v68 )
          {
            v63[5] = v70;
            *(_QWORD *)(v70 + 48) = v63;
          }
        }
        goto LABEL_84;
      }
      *((_DWORD *)msp + 1) = v21 & __ROL4__(-2, v66);
    }
LABEL_84:
    if ( v50 > 0x1F )
    {
      v172 = v50 >> 3;
      v55[1] = v5 | 3;
      *(_QWORD *)(v62 + 8) = v50 | 1;
      *(_QWORD *)(v62 + v50) = v50;
      if ( v50 >> 3 > 0x1F )
      {
        v193 = v50 >> 8;
        if ( v50 >> 8 > 0xFFFF )
        {
          v200 = 31;
          v199 = 31;
        }
        else
        {
          v194 = ((unsigned int)(v193 - 256) >> 16) & 8;
          v195 = (_DWORD)v193 << (((unsigned int)(v193 - 256) >> 16) & 8);
          v196 = v194 + (((unsigned int)(v195 - 4096) >> 16) & 4);
          v197 = v195 << (((unsigned int)(v195 - 4096) >> 16) & 4);
          v198 = ((unsigned int)(v197 << (((unsigned int)(v197 - 0x4000) >> 16) & 2)) >> 15)
               - (v196
                + (((unsigned int)(v197 - 0x4000) >> 16) & 2));
          v199 = ((v50 >> ((unsigned __int8)v198 + 21)) & 1) + 2 * v198 + 28;
          v200 = v199;
        }
        v201 = *((_DWORD *)msp + 1);
        *(_DWORD *)(v62 + 56) = v199;
        *(_QWORD *)(v62 + 40) = 0;
        *(_QWORD *)(v62 + 32) = 0;
        if ( _bittest(&v201, v200) )
        {
          v228 = *((_QWORD *)msp + (unsigned int)v199 + 74);
          v229 = 0;
          if ( (_DWORD)v199 != 31 )
            v229 = 57 - ((unsigned int)v199 >> 1);
          v230 = v50 << v229;
          while ( 1 )
          {
            if ( v50 == (*(_QWORD *)(v228 + 8) & 0xFFFFFFFFFFFFFFFCLL) )
            {
              v233 = *((_QWORD *)msp + 3);
              v234 = *(_QWORD *)(v228 + 16);
              if ( v233 <= v228 && v234 >= v233 )
              {
                *(_QWORD *)(v234 + 24) = v62;
                *(_QWORD *)(v228 + 16) = v62;
                *(_QWORD *)(v62 + 16) = v234;
                *(_QWORD *)(v62 + 24) = v228;
                *(_QWORD *)(v62 + 48) = 0;
              }
              goto LABEL_86;
            }
            v231 = v230;
            v230 *= 2LL;
            v232 = (v231 >> 63) + 4;
            if ( !*(_QWORD *)(v228 + 8 * v232) )
              break;
            v228 = *(_QWORD *)(v228 + 8 * v232);
          }
          if ( *((_QWORD *)msp + 3) <= v228 + 8 * v232 )
          {
            *(_QWORD *)(v228 + 8 * v232) = v62;
            *(_QWORD *)(v62 + 48) = v228;
            *(_QWORD *)(v62 + 24) = v62;
            *(_QWORD *)(v62 + 16) = v62;
          }
        }
        else
        {
          v202 = v199 + 74;
          *((_DWORD *)msp + 1) = v201 | (1 << v200);
          *((_QWORD *)msp + v202) = v62;
          *(_QWORD *)(v62 + 24) = v62;
          *(_QWORD *)(v62 + 16) = v62;
          *(_QWORD *)(v62 + 48) = (char *)msp + 8 * v202;
        }
      }
      else
      {
        v173 = *(_DWORD *)msp;
        v174 = (char *)msp + 8 * (unsigned int)(2 * v172) + 64;
        if ( _bittest(&v173, v172) )
        {
          v176 = (char *)*((_QWORD *)msp + (unsigned int)(2 * v172) + 10);
          if ( (unsigned __int64)v176 < *((_QWORD *)msp + 3) )
            v176 = v174;
        }
        else
        {
          v175 = 1 << v172;
          v176 = (char *)msp + 8 * (unsigned int)(2 * v172) + 64;
          *(_DWORD *)msp = v173 | v175;
        }
        *((_QWORD *)v174 + 2) = v62;
        *((_QWORD *)v176 + 3) = v62;
        *(_QWORD *)(v62 + 16) = v176;
        *(_QWORD *)(v62 + 24) = v174;
      }
    }
    else
    {
      v71 = v5 + v50;
      v55[1] = v71 | 3;
      *(_QWORD *)((char *)v55 + v71 + 8) |= 1uLL;
    }
LABEL_86:
    result = v55 + 2;
    if ( result )
      return result;
LABEL_87:
    v15 = v60;
    goto LABEL_14;
  }
LABEL_205:
  v164 = v21 & (-2 << v53);
  if ( v164 )
  {
    v165 = (((v164 & (unsigned int)-v164) - 1) >> 12) & 0x10;
    v166 = ((v164 & (unsigned int)-v164) - 1) >> v165;
    v167 = (v166 >> 5) & 8;
    v168 = v167 + v165;
    v169 = v166 >> v167;
    v170 = (v169 >> 2) & 4;
    v171 = v169 >> v170;
    v54 = (_QWORD *)*((_QWORD *)msp
                    + ((v171 >> ((v171 >> 1) & 2) >> 1) & 1)
                    + ((v171 >> 1) & 2)
                    + v168
                    + v170
                    + (v171 >> ((v171 >> 1) & 2) >> (((v171 >> ((v171 >> 1) & 2)) & 2) != 0))
                    + 74);
    v55 = 0;
    goto LABEL_57;
  }
LABEL_25:
  v15 = *((_QWORD *)msp + 1);
  if ( v5 <= v15 )
  {
LABEL_26:
    v22 = v15;
LABEL_27:
    v23 = *((_QWORD *)msp + 4);
    v24 = v22 - v5;
    if ( v22 - v5 > 0x1F )
    {
      v46 = v23 + v5;
      *((_QWORD *)msp + 1) = v24;
      *((_QWORD *)msp + 4) = v23 + v5;
      *(_QWORD *)(v46 + 8) = v24 | 1;
      *(_QWORD *)(v46 + v24) = v24;
      *(_QWORD *)(v23 + 8) = v5 | 3;
    }
    else
    {
      *((_QWORD *)msp + 1) = 0;
      *((_QWORD *)msp + 4) = 0;
      *(_QWORD *)(v23 + 8) = v22 | 3;
      *(_QWORD *)(v23 + v22 + 8) |= 1uLL;
    }
    return (void *)(v23 + 16);
  }
LABEL_15:
  v16 = *((_QWORD *)msp + 2);
  if ( v5 < v16 )
  {
    v47 = *((_QWORD *)msp + 5);
    v48 = v16 - v5;
    *((_QWORD *)msp + 2) = v48;
    *((_QWORD *)msp + 5) = v47 + v5;
    *(_QWORD *)(v47 + v5 + 8) = v48 | 1;
    *(_QWORD *)(v47 + 8) = v5 | 3;
    return (void *)(v47 + 16);
  }
  if ( !*((_QWORD *)msp + 119) )
    return 0;
  if ( v3 && !*((_QWORD *)msp + 114) )
    FMOD::init_mparams(v3);
  if ( (*((_BYTE *)msp + 864) & 4) != 0 )
  {
    v17 = *((_QWORD *)msp + 115);
    v18 = *((_QWORD *)msp + 114);
    goto LABEL_22;
  }
  v72 = *((_QWORD *)msp + 5);
  if ( v72 )
  {
    v73 = (unsigned __int64 *)((char *)msp + 872);
    while ( v72 < *v73 || v72 >= v73[1] + *v73 )
    {
      v73 = (unsigned __int64 *)v73[2];
      if ( !v73 )
        goto LABEL_93;
    }
    v17 = *((_QWORD *)msp + 115);
    v75 = -v17 & (v5 + v17 + 81 - *((_QWORD *)msp + 2));
    if ( v75 <= 0x7FFFFFFFFFFFFFFELL )
    {
      v97 = (*((__int64 (__fastcall **)(_QWORD, _QWORD))msp + 119))((unsigned int)v75, *((_QWORD *)msp + 120));
      if ( v97 != v73[1] + *v73 )
        goto LABEL_222;
      if ( v97 == -1 )
      {
LABEL_212:
        v17 = *((_QWORD *)msp + 115);
        goto LABEL_213;
      }
      goto LABEL_134;
    }
LABEL_213:
    v18 = *((_QWORD *)msp + 114);
LABEL_97:
    *((_DWORD *)msp + 216) |= 4u;
LABEL_22:
    v19 = v18 * (v5 / v18 + 1) + 80;
    v20 = -v17 & (v19 + v17 + 1);
    if ( v20 > 0x7FFFFFFFFFFFFFFELL )
      return 0;
    v97 = (*((__int64 (__fastcall **)(unsigned __int64, _QWORD, size_t))msp + 119))(
            v20,
            *((_QWORD *)msp + 120),
            v5 % v18);
    v98 = (*((__int64 (__fastcall **)(_QWORD, _QWORD))msp + 119))(0, *((_QWORD *)msp + 120));
    if ( v97 == -1 )
      return 0;
    if ( v98 == -1 )
      return 0;
    if ( v97 >= v98 )
      return 0;
    v75 = v98 - v97;
    if ( v19 >= v98 - v97 )
      return 0;
    goto LABEL_134;
  }
LABEL_93:
  v74 = (*((__int64 (__fastcall **)(_QWORD, _QWORD))msp + 119))(0, *((_QWORD *)msp + 120));
  v17 = *((_QWORD *)msp + 115);
  if ( v74 == -1 )
    goto LABEL_213;
  v18 = *((_QWORD *)msp + 114);
  v75 = -v17 & (v5 + v17 + 81);
  if ( ((v18 - 1) & v74) != 0 )
    v75 = (-(__int64)v18 & (v74 + v18)) + v75 - v74;
  if ( v75 > 0x7FFFFFFFFFFFFFFELL )
    goto LABEL_97;
  v97 = (*((__int64 (__fastcall **)(_QWORD, _QWORD))msp + 119))((unsigned int)v75, *((_QWORD *)msp + 120));
  if ( v74 == v97 )
    goto LABEL_134;
LABEL_222:
  if ( v97 == -1 )
    goto LABEL_212;
  if ( v5 + 81 > v75 )
  {
    v187 = -*((_QWORD *)msp + 115) & (v5 + *((_QWORD *)msp + 115) + 81 - v75);
    if ( v187 <= 0x7FFFFFFFFFFFFFFELL )
    {
      if ( (*((__int64 (__fastcall **)(_QWORD, _QWORD))msp + 119))((unsigned int)v187, *((_QWORD *)msp + 120)) != -1 )
      {
        v75 += v187;
        goto LABEL_134;
      }
      (*((void (__fastcall **)(_QWORD, _QWORD))msp + 119))((unsigned int)-(int)v75, *((_QWORD *)msp + 120));
      v17 = *((_QWORD *)msp + 115);
      v18 = *((_QWORD *)msp + 114);
      goto LABEL_97;
    }
  }
LABEL_134:
  v99 = *((_QWORD *)msp + 106) + v75;
  v100 = v99 <= *((_QWORD *)msp + 107);
  *((_QWORD *)msp + 106) = v99;
  if ( !v100 )
    *((_QWORD *)msp + 107) = v99;
  v101 = *((_QWORD *)msp + 5);
  v102 = (unsigned __int64 *)((char *)msp + 872);
  v103 = (char *)msp + 872;
  if ( !v101 )
  {
    v177 = *((_QWORD *)msp + 113);
    *((_QWORD *)msp + 3) = v97;
    v178 = 0;
    *((_QWORD *)msp + 109) = v97;
    *((_QWORD *)msp + 110) = v75;
    *((_DWORD *)msp + 224) = 0;
    *((_QWORD *)msp + 7) = v177;
    do
    {
      v179 = (unsigned int)(2 * v178++);
      v180 = (char *)msp + 8 * v179 + 64;
      *((_QWORD *)v180 + 3) = v180;
      *((_QWORD *)v180 + 2) = v180;
    }
    while ( v178 != 32 );
    if ( msp == &stru_2B06460 )
    {
      v244 = v75 - 80;
      v245 = 0;
      if ( (((_BYTE)v97 + 16) & 0xF) != 0 )
        v245 = -((_DWORD)v97 + 16) & 0xF;
      v122 = v244 - v245;
      v246 = (FMOD::malloc_chunk *)(v245 + v97);
      stru_2B06460.top = v246;
      stru_2B06460.topsize = v122;
      v246->head = v122 | 1;
      trim_threshold = stru_2B06460.mparams.trim_threshold;
      *(size_t *)((char *)&v246->head + v122) = 80;
      stru_2B06460.trim_check = trim_threshold;
    }
    else
    {
      v181 = (char *)msp + (*((_QWORD *)msp - 1) & 0xFFFFFFFFFFFFFFFCLL) - 16;
      v182 = 0;
      v183 = (char *)msp + (*((_QWORD *)msp - 1) & 0xFFFFFFFFFFFFFFFCLL);
      v184 = v97 - (_QWORD)v181 + v75 - 80;
      if ( ((unsigned __int8)v183 & 0xF) != 0 )
        v182 = -(int)v183 & 0xF;
      v122 = v184 - v182;
      v185 = &v181[v182];
      *((_QWORD *)msp + 5) = v185;
      *((_QWORD *)msp + 2) = v122;
      *((_QWORD *)v185 + 1) = v122 | 1;
      v186 = *((_QWORD *)msp + 117);
      *(_QWORD *)&v185[v122 + 8] = 80;
      *((_QWORD *)msp + 6) = v186;
    }
    goto LABEL_161;
  }
  while ( 1 )
  {
    v104 = *((_QWORD *)v103 + 1);
    if ( v97 == *(_QWORD *)v103 + v104 )
      break;
    v103 = (char *)*((_QWORD *)v103 + 2);
    if ( !v103 )
      goto LABEL_139;
  }
  if ( (v103[24] & 8) == 0 && v101 >= *(_QWORD *)v103 && v101 < v97 )
  {
    v124 = v75 + v104;
    v125 = 0;
    v126 = *((_QWORD *)msp + 2) + v75;
    *((_QWORD *)v103 + 1) = v124;
    if ( (((_BYTE)v101 + 16) & 0xF) != 0 )
      v125 = -((_DWORD)v101 + 16) & 0xF;
    v122 = v126 - v125;
    v127 = v125 + v101;
    *((_QWORD *)msp + 5) = v127;
    *((_QWORD *)msp + 2) = v122;
    *(_QWORD *)(v127 + 8) = v122 | 1;
    v128 = *((_QWORD *)msp + 117);
    *(_QWORD *)(v127 + v122 + 8) = 80;
    *((_QWORD *)msp + 6) = v128;
    goto LABEL_161;
  }
LABEL_139:
  if ( v97 < *((_QWORD *)msp + 3) )
    *((_QWORD *)msp + 3) = v97;
  v105 = (char *)msp + 872;
  while ( 2 )
  {
    v106 = *(_QWORD *)v105;
    if ( *(_QWORD *)v105 == v97 + v75 )
    {
      if ( (v105[24] & 8) != 0 )
        break;
      *((_QWORD *)v105 + 1) += v75;
      *(_QWORD *)v105 = v97;
      v129 = 0;
      if ( (((_BYTE)v97 + 16) & 0xF) != 0 )
        v129 = -((_DWORD)v97 + 16) & 0xF;
      v23 = v97 + v129;
      v130 = 0;
      if ( (((_BYTE)v106 + 16) & 0xF) != 0 )
        v130 = -(char)(v106 + 16) & 0xF;
      v131 = v130 + v106;
      v132 = v23 + v5;
      v133 = v131 - v23 - v5;
      *(_QWORD *)(v23 + 8) = v5 | 3;
      if ( v101 == v131 )
      {
        v251 = *((_QWORD *)msp + 2) + v133;
        *((_QWORD *)msp + 5) = v132;
        *((_QWORD *)msp + 2) = v251;
        *(_QWORD *)(v132 + 8) = v251 | 1;
        return (void *)(v23 + 16);
      }
      if ( v131 == *((_QWORD *)msp + 4) )
      {
        v252 = *((_QWORD *)msp + 1) + v133;
        *((_QWORD *)msp + 4) = v132;
        *((_QWORD *)msp + 1) = v252;
        *(_QWORD *)(v132 + 8) = v252 | 1;
        *(_QWORD *)(v132 + v252) = v252;
        return (void *)(v23 + 16);
      }
      v134 = *(_QWORD *)(v131 + 8);
      v135 = v134;
      if ( (v134 & 2) != 0 )
      {
LABEL_185:
        *(_QWORD *)(v131 + 8) = v135 & 0xFFFFFFFFFFFFFFFELL;
        v142 = v133 >> 3;
        *(_QWORD *)(v132 + 8) = v133 | 1;
        *(_QWORD *)(v132 + v133) = v133;
        if ( v133 >> 3 > 0x1F )
        {
          v206 = v133 >> 8;
          if ( v133 >> 8 > 0xFFFF )
          {
            v213 = 31;
            v212 = 31;
          }
          else
          {
            v207 = ((unsigned int)(v206 - 256) >> 16) & 8;
            v208 = (_DWORD)v206 << (((unsigned int)(v206 - 256) >> 16) & 8);
            v209 = v207 + (((unsigned int)(v208 - 4096) >> 16) & 4);
            v210 = v208 << (((unsigned int)(v208 - 4096) >> 16) & 4);
            v211 = ((unsigned int)(v210 << (((unsigned int)(v210 - 0x4000) >> 16) & 2)) >> 15)
                 - (v209
                  + (((unsigned int)(v210 - 0x4000) >> 16) & 2));
            v212 = ((v133 >> ((unsigned __int8)v211 + 21)) & 1) + 2 * v211 + 28;
            v213 = v212;
          }
          v214 = *((_DWORD *)msp + 1);
          *(_DWORD *)(v132 + 56) = v212;
          *(_QWORD *)(v132 + 40) = 0;
          *(_QWORD *)(v132 + 32) = 0;
          if ( _bittest(&v214, v213) )
          {
            v215 = *((_QWORD *)msp + (unsigned int)v212 + 74);
            v216 = 0;
            if ( (_DWORD)v212 != 31 )
              v216 = 57 - ((unsigned int)v212 >> 1);
            v217 = v133 << v216;
            while ( 1 )
            {
              if ( v133 == (*(_QWORD *)(v215 + 8) & 0xFFFFFFFFFFFFFFFCLL) )
              {
                v220 = *((_QWORD *)msp + 3);
                v221 = *(_QWORD *)(v215 + 16);
                if ( v220 <= v215 && v221 >= v220 )
                {
                  *(_QWORD *)(v221 + 24) = v132;
                  *(_QWORD *)(v215 + 16) = v132;
                  *(_QWORD *)(v132 + 16) = v221;
                  *(_QWORD *)(v132 + 24) = v215;
                  *(_QWORD *)(v132 + 48) = 0;
                }
                return (void *)(v23 + 16);
              }
              v218 = v217;
              v217 *= 2LL;
              v219 = (v218 >> 63) + 4;
              if ( !*(_QWORD *)(v215 + 8 * v219) )
                break;
              v215 = *(_QWORD *)(v215 + 8 * v219);
            }
            if ( *((_QWORD *)msp + 3) <= v215 + 8 * v219 )
            {
              *(_QWORD *)(v215 + 8 * v219) = v132;
              *(_QWORD *)(v132 + 48) = v215;
              *(_QWORD *)(v132 + 24) = v132;
              *(_QWORD *)(v132 + 16) = v132;
            }
          }
          else
          {
            v243 = v212 + 74;
            *((_DWORD *)msp + 1) = v214 | (1 << v213);
            *((_QWORD *)msp + v243) = v132;
            *(_QWORD *)(v132 + 24) = v132;
            *(_QWORD *)(v132 + 16) = v132;
            *(_QWORD *)(v132 + 48) = (char *)msp + 8 * v243;
          }
        }
        else
        {
          v143 = *(_DWORD *)msp;
          v144 = (char *)msp + 8 * (unsigned int)(2 * v142) + 64;
          if ( _bittest(&v143, v142) )
          {
            v146 = (char *)*((_QWORD *)msp + (unsigned int)(2 * v142) + 10);
            if ( (unsigned __int64)v146 < *((_QWORD *)msp + 3) )
              v146 = v144;
          }
          else
          {
            v145 = 1 << v142;
            v146 = (char *)msp + 8 * (unsigned int)(2 * v142) + 64;
            *(_DWORD *)msp = v143 | v145;
          }
          *((_QWORD *)v144 + 2) = v132;
          *((_QWORD *)v146 + 3) = v132;
          *(_QWORD *)(v132 + 16) = v146;
          *(_QWORD *)(v132 + 24) = v144;
        }
        return (void *)(v23 + 16);
      }
      v136 = v134 & 0xFFFFFFFFFFFFFFFCLL;
      v137 = v136 >> 3;
      if ( v136 >> 3 > 0x1F )
      {
        v235 = *(_QWORD **)(v131 + 24);
        v236 = *(_QWORD *)(v131 + 48);
        if ( (_QWORD *)v131 == v235 )
        {
          v235 = *(_QWORD **)(v131 + 40);
          v253 = (_QWORD *)(v131 + 40);
          if ( v235 || (v235 = *(_QWORD **)(v131 + 32), v253 = (_QWORD *)(v131 + 32), v235) )
          {
            while ( 1 )
            {
              v254 = (_QWORD *)v235[5];
              v255 = v235 + 5;
              if ( !v254 )
              {
                v254 = (_QWORD *)v235[4];
                v255 = v235 + 4;
                if ( !v254 )
                  break;
              }
              v235 = v254;
              v253 = v255;
            }
            if ( *((_QWORD *)msp + 3) <= (unsigned __int64)v253 )
              *v253 = 0;
          }
        }
        else
        {
          v237 = *(_QWORD *)(v131 + 16);
          if ( v237 >= *((_QWORD *)msp + 3) )
          {
            *(_QWORD *)(v237 + 24) = v235;
            v235[2] = v237;
          }
        }
        if ( !v236 )
          goto LABEL_184;
        v238 = *(_DWORD *)(v131 + 56);
        v239 = (char *)msp + 8 * v238;
        if ( v131 == *((_QWORD *)v239 + 74) )
        {
          *((_QWORD *)v239 + 74) = v235;
          if ( !v235 )
          {
            *((_DWORD *)msp + 1) &= __ROL4__(-2, v238);
            goto LABEL_184;
          }
          v240 = *((_QWORD *)msp + 3);
        }
        else
        {
          v240 = *((_QWORD *)msp + 3);
          if ( v236 >= v240 )
          {
            if ( v131 == *(_QWORD *)(v236 + 32) )
              *(_QWORD *)(v236 + 32) = v235;
            else
              *(_QWORD *)(v236 + 40) = v235;
          }
          if ( !v235 )
            goto LABEL_184;
        }
        if ( v240 <= (unsigned __int64)v235 )
        {
          v235[6] = v236;
          v241 = *(_QWORD *)(v131 + 32);
          if ( v241 && v240 <= v241 )
          {
            v235[4] = v241;
            *(_QWORD *)(v241 + 48) = v235;
          }
          v242 = *(_QWORD *)(v131 + 40);
          if ( v242 && v240 <= v242 )
          {
            v235[5] = v242;
            *(_QWORD *)(v242 + 48) = v235;
          }
        }
        goto LABEL_184;
      }
      v138 = *(_QWORD *)(v131 + 16);
      v139 = *(_QWORD *)(v131 + 24);
      if ( v138 == v139 )
      {
        *(_DWORD *)msp &= __ROL4__(-2, v137);
        goto LABEL_184;
      }
      v140 = (char *)msp + 8 * (unsigned int)(2 * v137) + 64;
      v141 = *((_QWORD *)msp + 3);
      if ( (char *)v138 != v140 )
      {
        if ( v138 < v141 )
          goto LABEL_184;
        if ( (char *)v139 == v140 )
        {
LABEL_183:
          *(_QWORD *)(v138 + 24) = v139;
          *(_QWORD *)(v139 + 16) = v138;
          goto LABEL_184;
        }
      }
      if ( v139 >= v141 )
        goto LABEL_183;
LABEL_184:
      v131 += v136;
      v133 += v136;
      v135 = *(_QWORD *)(v131 + 8);
      goto LABEL_185;
    }
    v105 = (char *)*((_QWORD *)v105 + 2);
    if ( v105 )
      continue;
    break;
  }
  while ( 1 )
  {
    if ( v101 >= *v102 )
    {
      v107 = v102[1] + *v102;
      if ( v101 < v107 )
        break;
    }
    v102 = (unsigned __int64 *)v102[2];
    if ( !v102 )
    {
      v107 = 0x10102464C457FLL;
      break;
    }
  }
  v108 = 0;
  if ( (((_BYTE)v107 - 79) & 0xF) != 0 )
    v108 = (79 - (_DWORD)v107) & 0xF;
  v109 = (_QWORD *)(v108 + v107 - 95);
  v110 = v97 + 16;
  if ( (unsigned __int64)v109 < v101 + 32 )
    v109 = (_QWORD *)v101;
  v111 = 0;
  if ( (v110 & 0xF) != 0 )
    v111 = -v110 & 0xF;
  v112 = v97 + v111;
  v113 = v75 - 80 - v111;
  *((_QWORD *)msp + 2) = v113;
  *((_QWORD *)msp + 5) = v97 + v111;
  *(_QWORD *)(v112 + 8) = v113 | 1;
  *(_QWORD *)(v112 + v113 + 8) = 80;
  *((_QWORD *)msp + 6) = *((_QWORD *)msp + 117);
  v114 = *((_QWORD *)msp + 109);
  v109[1] = 51;
  v109[2] = v114;
  v109[3] = *((_QWORD *)msp + 110);
  v109[4] = *((_QWORD *)msp + 111);
  v109[5] = *((_QWORD *)msp + 112);
  v115 = v109 + 7;
  *((_QWORD *)msp + 109) = v97;
  *((_QWORD *)msp + 110) = v75;
  *((_DWORD *)msp + 224) = 0;
  *((_QWORD *)msp + 111) = v109 + 2;
  do
    *v115++ = 11;
  while ( v107 > (unsigned __int64)v115 );
  if ( (_QWORD *)v101 == v109 )
  {
LABEL_202:
    v122 = *((_QWORD *)msp + 2);
    goto LABEL_161;
  }
  v116 = (unsigned __int64)v109 - v101;
  v117 = (char *)(v101 + v116);
  v118 = v116;
  *((_QWORD *)v117 + 1) &= ~1uLL;
  *(_QWORD *)(v101 + 8) = v116 | 1;
  *(_QWORD *)v117 = v116;
  v119 = v116 >> 3;
  if ( v119 <= 0x1F )
  {
    v120 = *(_DWORD *)msp;
    if ( _bittest(&v120, v119) )
    {
      v121 = (char *)*((_QWORD *)msp + (unsigned int)(2 * v119) + 10);
      if ( (unsigned __int64)v121 < *((_QWORD *)msp + 3) )
        v121 = (char *)msp + 8 * (unsigned int)(2 * v119) + 64;
    }
    else
    {
      *(_DWORD *)msp = v120 | (1 << v119);
      v121 = (char *)msp + 8 * (unsigned int)(2 * v119) + 64;
    }
    v122 = *((_QWORD *)msp + 2);
    *((_QWORD *)msp + (unsigned int)(2 * v119) + 10) = v101;
    *((_QWORD *)v121 + 3) = v101;
    *(_QWORD *)(v101 + 16) = v121;
    *(_QWORD *)(v101 + 24) = (char *)msp + 8 * (unsigned int)(2 * v119) + 64;
    goto LABEL_161;
  }
  v147 = v118 >> 8;
  if ( v118 >> 8 > 0xFFFF )
  {
    v154 = 31;
    v153 = 31;
  }
  else
  {
    v148 = ((unsigned int)(v147 - 256) >> 16) & 8;
    v149 = (_DWORD)v147 << (((unsigned int)(v147 - 256) >> 16) & 8);
    v150 = v148 + (((unsigned int)(v149 - 4096) >> 16) & 4);
    v151 = v149 << (((unsigned int)(v149 - 4096) >> 16) & 4);
    v152 = ((unsigned int)(v151 << (((unsigned int)(v151 - 0x4000) >> 16) & 2)) >> 15)
         - (v150
          + (((unsigned int)(v151 - 0x4000) >> 16) & 2));
    v153 = ((v118 >> ((unsigned __int8)v152 + 21)) & 1) + 2 * v152 + 28;
    v154 = v153;
  }
  v155 = *((_DWORD *)msp + 1);
  *(_DWORD *)(v101 + 56) = v153;
  *(_QWORD *)(v101 + 40) = 0;
  *(_QWORD *)(v101 + 32) = 0;
  if ( !_bittest(&v155, v154) )
  {
    v163 = v153 + 74;
    *((_DWORD *)msp + 1) = v155 | (1 << v154);
    *((_QWORD *)msp + v163) = v101;
    *(_QWORD *)(v101 + 24) = v101;
    *(_QWORD *)(v101 + 16) = v101;
    *(_QWORD *)(v101 + 48) = (char *)msp + 8 * v163;
    goto LABEL_202;
  }
  v156 = 0;
  v157 = *((_QWORD *)msp + (unsigned int)v153 + 74);
  if ( (_DWORD)v153 != 31 )
    v156 = 57 - ((unsigned int)v153 >> 1);
  v158 = v118 << v156;
  while ( 1 )
  {
    if ( v118 == (*(_QWORD *)(v157 + 8) & 0xFFFFFFFFFFFFFFFCLL) )
    {
      v161 = *((_QWORD *)msp + 3);
      v162 = *(_QWORD *)(v157 + 16);
      if ( v161 <= v157 && v162 >= v161 )
      {
        *(_QWORD *)(v162 + 24) = v101;
        v122 = *((_QWORD *)msp + 2);
        *(_QWORD *)(v157 + 16) = v101;
        *(_QWORD *)(v101 + 16) = v162;
        *(_QWORD *)(v101 + 24) = v157;
        *(_QWORD *)(v101 + 48) = 0;
        goto LABEL_161;
      }
      goto LABEL_202;
    }
    v159 = v158;
    v158 *= 2;
    v160 = (v159 >> 63) + 4;
    if ( !*(_QWORD *)(v157 + 8 * v160) )
      break;
    v157 = *(_QWORD *)(v157 + 8 * v160);
  }
  if ( *((_QWORD *)msp + 3) > v157 + 8 * v160 )
    goto LABEL_202;
  *(_QWORD *)(v157 + 8 * v160) = v101;
  v122 = *((_QWORD *)msp + 2);
  *(_QWORD *)(v101 + 48) = v157;
  *(_QWORD *)(v101 + 24) = v101;
  *(_QWORD *)(v101 + 16) = v101;
LABEL_161:
  if ( v5 < v122 )
  {
    v23 = *((_QWORD *)msp + 5);
    v123 = v122 - v5;
    *((_QWORD *)msp + 2) = v123;
    *((_QWORD *)msp + 5) = v23 + v5;
    *(_QWORD *)(v23 + v5 + 8) = v123 | 1;
    *(_QWORD *)(v23 + 8) = v5 | 3;
    return (void *)(v23 + 16);
  }
  return 0;
}


// Address: 0x2266d60 | Name: FMOD::ialloc
void **__fastcall FMOD::ialloc(FMOD::mstate m, size_t n_elements, size_t *sizes, int opts, void **chunks)
{
  void **v7; // r12
  void **result; // rax
  __int64 v9; // rsi
  size_t *v10; // r8
  size_t *v11; // rax
  size_t v12; // rcx
  unsigned __int64 v13; // rdx
  size_t v14; // r15
  _QWORD *v15; // rax
  _QWORD *v16; // r10
  size_t v17; // rcx
  char *v18; // rbx
  unsigned __int64 v19; // rbp
  __int64 v20; // rax
  __int64 v21; // rdx
  __int64 v22; // rdx
  unsigned __int64 v23; // rcx
  unsigned __int64 v24; // rcx
  char optsa; // [rsp+0h] [rbp-58h]
  _QWORD *optsb; // [rsp+0h] [rbp-58h]
  size_t contents_size; // [rsp+8h] [rbp-50h]
  size_t contents_sizea; // [rsp+8h] [rbp-50h]
  size_t array_size; // [rsp+10h] [rbp-48h]
  _QWORD *mem; // [rsp+18h] [rbp-40h]

  v7 = chunks;
  optsa = opts;
  if ( chunks )
  {
    result = chunks;
    if ( !n_elements )
      return result;
    v9 = -8;
    array_size = 0;
  }
  else
  {
    if ( !n_elements )
      return (void **)FMOD::mspace_malloc(m, 0);
    if ( 8 * n_elements <= 0x16 )
    {
      v9 = 24;
      array_size = 32;
    }
    else
    {
      array_size = (8 * n_elements + 23) & 0xFFFFFFFFFFFFFFF0LL;
      v9 = array_size - 8;
    }
  }
  if ( (opts & 1) != 0 )
  {
    v14 = 32;
    if ( *sizes > 0x16 )
      v14 = (*sizes + 23) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = n_elements * v14;
  }
  else
  {
    v10 = &sizes[n_elements];
    v11 = sizes;
    v12 = 0;
    do
    {
      v13 = 32;
      if ( *v11 > 0x16 )
        v13 = (*v11 + 23) & 0xFFFFFFFFFFFFFFF0LL;
      ++v11;
      v12 += v13;
    }
    while ( v11 != v10 );
    v14 = 0;
  }
  contents_size = v12;
  v15 = FMOD::mspace_malloc(m, v12 + v9);
  v16 = v15;
  if ( !v15 )
    return 0;
  v17 = contents_size;
  if ( m != (FMOD::mstate)-904LL && !m->mparams.page_size )
  {
    mem = v15;
    FMOD::init_mparams(&m->mparams);
    v16 = mem;
    v17 = contents_size;
  }
  v18 = (char *)(v16 - 2);
  v19 = *(v16 - 1) & 0xFFFFFFFFFFFFFFFCLL;
  if ( (optsa & 2) != 0 )
  {
    contents_sizea = v17;
    optsb = v16;
    memset(v16, 0, v19 - 8 - array_size);
    v17 = contents_sizea;
    v16 = optsb;
  }
  if ( !v7 )
  {
    *(_QWORD *)&v18[v17 + 8] = (v19 - v17) | 3;
    v7 = (void **)&v18[v17 + 16];
    v19 = v17;
  }
  *v7 = v16;
  if ( n_elements != 1 )
  {
    v20 = 1;
    v21 = 0;
    while ( 1 )
    {
      if ( v14 )
      {
        v22 = v14 | 3;
        v23 = v14;
      }
      else
      {
        v24 = *(size_t *)((char *)sizes + v21);
        if ( v24 <= 0x16 )
        {
          v22 = 35;
          v23 = 32;
        }
        else
        {
          v23 = (v24 + 23) & 0xFFFFFFFFFFFFFFF0LL;
          v22 = v23 | 3;
        }
      }
      *((_QWORD *)v18 + 1) = v22;
      v18 += v23;
      v19 -= v23;
      v7[v20] = v18 + 16;
      if ( v20 * 8 + 8 == 8 * n_elements )
        break;
      v21 = v20 * 8;
      ++v20;
    }
  }
  result = v7;
  *((_QWORD *)v18 + 1) = v19 | 3;
  return result;
}


// Address: 0x2266fe0 | Name: _ZN4FMOD11mspace_freeEPvS0_
void __fastcall FMOD::mspace_free(FMOD::mspace msp, void *mem)
{
  char *v3; // rbx
  FMOD::malloc_params *v4; // rdi
  unsigned __int64 v5; // rdi
  __int64 v6; // rcx
  unsigned __int64 v7; // rdx
  char *v8; // rax
  unsigned __int64 v9; // rcx
  unsigned __int64 v10; // rcx
  char *v11; // rsi
  unsigned __int64 v12; // r8
  unsigned __int64 v13; // rcx
  unsigned int v14; // ecx
  char *v15; // rdi
  unsigned __int64 v16; // rcx
  unsigned __int64 v17; // rdi
  unsigned __int64 v18; // rdi
  __int64 v19; // rcx
  char *v20; // rsi
  unsigned __int64 v21; // rcx
  unsigned __int64 v22; // rcx
  char *v23; // rsi
  unsigned __int64 v24; // rdi
  unsigned __int64 v25; // rcx
  unsigned int v26; // ecx
  char **v27; // r8
  unsigned __int64 v28; // rcx
  unsigned __int64 v29; // rdi
  unsigned __int64 v30; // rax
  char *v31; // rax
  unsigned __int64 v32; // rcx
  int v33; // esi
  char *v34; // rdx
  unsigned __int64 v35; // rax
  unsigned int v36; // ecx
  __int64 v37; // rax
  int v38; // esi
  unsigned __int64 v39; // rsi
  char v40; // cl
  unsigned __int64 v41; // rcx
  unsigned __int64 v42; // rdi
  __int64 v43; // rdi
  unsigned __int64 v44; // rax
  unsigned __int64 v45; // rdx
  unsigned __int64 v46; // rsi
  unsigned __int64 v47; // r8
  char *v48; // rcx
  unsigned int v49; // edi
  int v50; // eax
  unsigned int v51; // esi
  int v52; // eax
  unsigned int v53; // eax
  unsigned __int64 v54; // rdi
  unsigned __int64 v55; // r8
  unsigned __int64 v56; // r9
  char *v57; // rcx
  __int64 v58; // rax
  unsigned __int64 v59; // rcx
  unsigned __int64 v60; // rdx
  bool v61; // zf
  unsigned __int64 v62; // rdx
  _QWORD *v63; // r10
  char *v64; // rcx
  _QWORD *v65; // r9
  _QWORD *v66; // r9
  char *v67; // rcx
  _QWORD *v68; // r8

  if ( !mem )
    return;
  v3 = (char *)mem - 16;
  v4 = (FMOD::malloc_params *)((char *)msp + 904);
  if ( v4 && !*((_QWORD *)msp + 114) )
    FMOD::init_mparams(v4);
  v5 = *((_QWORD *)msp + 3);
  if ( (unsigned __int64)v3 < v5 )
    return;
  v6 = *((_QWORD *)mem - 1);
  if ( (v6 & 2) == 0 )
    return;
  v7 = v6 & 0xFFFFFFFFFFFFFFFCLL;
  v8 = &v3[v6 & 0xFFFFFFFFFFFFFFFCLL];
  if ( (v6 & 1) == 0 )
  {
    v9 = *((_QWORD *)mem - 2);
    v3 -= v9;
    v7 += v9;
    if ( v5 > (unsigned __int64)v3 )
      return;
    if ( v3 == *((char **)msp + 4) )
    {
      if ( (*((_QWORD *)v8 + 1) & 3LL) == 3 )
      {
        v59 = *((_QWORD *)v8 + 1) & 0xFFFFFFFFFFFFFFFELL;
        *((_QWORD *)msp + 1) = v7;
        *((_QWORD *)v8 + 1) = v59;
        *((_QWORD *)v3 + 1) = v7 | 1;
        *(_QWORD *)&v3[v7] = v7;
        return;
      }
    }
    else
    {
      v10 = v9 >> 3;
      if ( v10 <= 0x1F )
      {
        v46 = *((_QWORD *)v3 + 2);
        v47 = *((_QWORD *)v3 + 3);
        if ( v46 == v47 )
        {
          *(_DWORD *)msp &= __ROL4__(-2, v10);
          goto LABEL_27;
        }
        v48 = (char *)msp + 8 * (unsigned int)(2 * v10) + 64;
        if ( v48 == (char *)v46 )
          goto LABEL_75;
        if ( v5 > v46 )
          goto LABEL_27;
        if ( (char *)v47 != v48 )
        {
LABEL_75:
          if ( v5 > v47 )
            goto LABEL_27;
        }
        *(_QWORD *)(v46 + 24) = v47;
        *(_QWORD *)(v47 + 16) = v46;
        goto LABEL_27;
      }
      v11 = (char *)*((_QWORD *)v3 + 3);
      v12 = *((_QWORD *)v3 + 6);
      if ( v3 == v11 )
      {
        v11 = (char *)*((_QWORD *)v3 + 5);
        v63 = v3 + 40;
        if ( v11 || (v11 = (char *)*((_QWORD *)v3 + 4), v63 = v3 + 32, v11) )
        {
          while ( 1 )
          {
            v64 = (char *)*((_QWORD *)v11 + 5);
            v65 = v11 + 40;
            if ( !v64 )
            {
              v64 = (char *)*((_QWORD *)v11 + 4);
              v65 = v11 + 32;
              if ( !v64 )
                break;
            }
            v11 = v64;
            v63 = v65;
          }
          if ( v5 <= (unsigned __int64)v63 )
            *v63 = 0;
        }
      }
      else
      {
        v13 = *((_QWORD *)v3 + 2);
        if ( v5 <= v13 )
        {
          *(_QWORD *)(v13 + 24) = v11;
          *((_QWORD *)v11 + 2) = v13;
        }
      }
      if ( v12 )
      {
        v14 = *((_DWORD *)v3 + 14);
        v15 = (char *)msp + 8 * v14;
        if ( v3 == *((char **)v15 + 74) )
        {
          *((_QWORD *)v15 + 74) = v11;
          if ( !v11 )
          {
            *((_DWORD *)msp + 1) &= __ROL4__(-2, v14);
            goto LABEL_27;
          }
          v16 = *((_QWORD *)msp + 3);
          goto LABEL_20;
        }
        v16 = *((_QWORD *)msp + 3);
        if ( v12 >= v16 )
        {
          if ( v3 == *(char **)(v12 + 32) )
            *(_QWORD *)(v12 + 32) = v11;
          else
            *(_QWORD *)(v12 + 40) = v11;
        }
        if ( v11 )
        {
LABEL_20:
          if ( (unsigned __int64)v11 >= v16 )
          {
            v17 = *((_QWORD *)v3 + 4);
            *((_QWORD *)v11 + 6) = v12;
            if ( v17 && v17 >= v16 )
            {
              *((_QWORD *)v11 + 4) = v17;
              *(_QWORD *)(v17 + 48) = v11;
            }
            v18 = *((_QWORD *)v3 + 5);
            if ( v18 && v18 >= v16 )
            {
              *((_QWORD *)v11 + 5) = v18;
              *(_QWORD *)(v18 + 48) = v11;
            }
          }
        }
      }
    }
  }
LABEL_27:
  if ( v3 >= v8 )
    return;
  v19 = *((_QWORD *)v8 + 1);
  if ( (v19 & 1) == 0 )
    return;
  if ( (v19 & 2) == 0 )
  {
    if ( *((char **)msp + 5) == v8 )
    {
      v60 = *((_QWORD *)msp + 2) + v7;
      *((_QWORD *)msp + 5) = v3;
      *((_QWORD *)msp + 2) = v60;
      v61 = *((_QWORD *)msp + 4) == (_QWORD)v3;
      *((_QWORD *)v3 + 1) = v60 | 1;
      if ( v61 )
      {
        *((_QWORD *)msp + 4) = 0;
        *((_QWORD *)msp + 1) = 0;
      }
      return;
    }
    v20 = (char *)*((_QWORD *)msp + 4);
    if ( v20 == v8 )
    {
      v62 = *((_QWORD *)msp + 1) + v7;
      *((_QWORD *)msp + 4) = v3;
      *((_QWORD *)msp + 1) = v62;
      *((_QWORD *)v3 + 1) = v62 | 1;
      *(_QWORD *)&v3[v62] = v62;
      return;
    }
    v21 = v19 & 0xFFFFFFFFFFFFFFFCLL;
    v7 += v21;
    v22 = v21 >> 3;
    if ( v22 <= 0x1F )
    {
      v54 = *((_QWORD *)v8 + 2);
      v55 = *((_QWORD *)v8 + 3);
      if ( v54 == v55 )
      {
        *(_DWORD *)msp &= __ROL4__(-2, v22);
        v31 = v20;
      }
      else
      {
        v56 = *((_QWORD *)msp + 3);
        v57 = (char *)msp + 8 * (unsigned int)(2 * v22) + 64;
        if ( v57 != (char *)v54 )
        {
          v31 = (char *)*((_QWORD *)msp + 4);
          if ( v54 < v56 )
            goto LABEL_50;
          if ( (char *)v55 == v57 )
            goto LABEL_84;
        }
        if ( v55 >= v56 )
        {
LABEL_84:
          *(_QWORD *)(v54 + 24) = v55;
          *(_QWORD *)(v55 + 16) = v54;
        }
        v31 = v20;
      }
    }
    else
    {
      v23 = (char *)*((_QWORD *)v8 + 3);
      v24 = *((_QWORD *)v8 + 6);
      if ( v8 == v23 )
      {
        v23 = (char *)*((_QWORD *)v8 + 5);
        v66 = v8 + 40;
        if ( v23 || (v23 = (char *)*((_QWORD *)v8 + 4), v66 = v8 + 32, v23) )
        {
          while ( 1 )
          {
            v67 = (char *)*((_QWORD *)v23 + 5);
            v68 = v23 + 40;
            if ( !v67 )
            {
              v67 = (char *)*((_QWORD *)v23 + 4);
              v68 = v23 + 32;
              if ( !v67 )
                break;
            }
            v23 = v67;
            v66 = v68;
          }
          if ( *((_QWORD *)msp + 3) <= (unsigned __int64)v66 )
            *v66 = 0;
        }
      }
      else
      {
        v25 = *((_QWORD *)v8 + 2);
        if ( v25 >= *((_QWORD *)msp + 3) )
        {
          *(_QWORD *)(v25 + 24) = v23;
          *((_QWORD *)v23 + 2) = v25;
        }
      }
      if ( !v24 )
        goto LABEL_49;
      v26 = *((_DWORD *)v8 + 14);
      v27 = (char **)((char *)msp + 8 * v26);
      if ( v8 != v27[74] )
      {
        v28 = *((_QWORD *)msp + 3);
        if ( v24 >= v28 )
        {
          if ( v8 == *(char **)(v24 + 32) )
            *(_QWORD *)(v24 + 32) = v23;
          else
            *(_QWORD *)(v24 + 40) = v23;
        }
        if ( !v23 )
          goto LABEL_49;
        goto LABEL_42;
      }
      v27[74] = v23;
      if ( v23 )
      {
        v28 = *((_QWORD *)msp + 3);
LABEL_42:
        if ( (unsigned __int64)v23 >= v28 )
        {
          *((_QWORD *)v23 + 6) = v24;
          v29 = *((_QWORD *)v8 + 4);
          if ( v29 && v28 <= v29 )
          {
            *((_QWORD *)v23 + 4) = v29;
            *(_QWORD *)(v29 + 48) = v23;
          }
          v30 = *((_QWORD *)v8 + 5);
          if ( v30 && v28 <= v30 )
          {
            *((_QWORD *)v23 + 5) = v30;
            *(_QWORD *)(v30 + 48) = v23;
          }
        }
LABEL_49:
        v31 = (char *)*((_QWORD *)msp + 4);
        goto LABEL_50;
      }
      *((_DWORD *)msp + 1) &= __ROL4__(-2, v26);
      v31 = (char *)*((_QWORD *)msp + 4);
    }
LABEL_50:
    *((_QWORD *)v3 + 1) = v7 | 1;
    *(_QWORD *)&v3[v7] = v7;
    if ( v3 == v31 )
    {
      *((_QWORD *)msp + 1) = v7;
      return;
    }
    goto LABEL_54;
  }
  *((_QWORD *)v8 + 1) = v19 & 0xFFFFFFFFFFFFFFFELL;
  *((_QWORD *)v3 + 1) = v7 | 1;
  *(_QWORD *)&v3[v7] = v7;
LABEL_54:
  v32 = v7 >> 3;
  if ( v7 >> 3 > 0x1F )
  {
    v35 = v7 >> 8;
    if ( v7 >> 8 <= 0xFFFF )
    {
      v49 = ((unsigned int)(v35 - 256) >> 16) & 8;
      v50 = (_DWORD)v35 << (((unsigned int)(v35 - 256) >> 16) & 8);
      v51 = v49 + (((unsigned int)(v50 - 4096) >> 16) & 4);
      v52 = v50 << (((unsigned int)(v50 - 4096) >> 16) & 4);
      v53 = ((unsigned int)(v52 << (((unsigned int)(v52 - 0x4000) >> 16) & 2)) >> 15)
          - (v51
           + (((unsigned int)(v52 - 0x4000) >> 16) & 2));
      v37 = ((v7 >> ((unsigned __int8)v53 + 21)) & 1) + 2 * v53 + 28;
      v36 = v37;
    }
    else
    {
      v36 = 31;
      v37 = 31;
    }
    v38 = *((_DWORD *)msp + 1);
    *((_DWORD *)v3 + 14) = v37;
    *((_QWORD *)v3 + 5) = 0;
    *((_QWORD *)v3 + 4) = 0;
    if ( _bittest(&v38, v36) )
    {
      v39 = *((_QWORD *)msp + (unsigned int)v37 + 74);
      v40 = 0;
      if ( (_DWORD)v37 != 31 )
        v40 = 57 - ((unsigned int)v37 >> 1);
      v41 = v7 << v40;
      while ( 1 )
      {
        if ( (*(_QWORD *)(v39 + 8) & 0xFFFFFFFFFFFFFFFCLL) == v7 )
        {
          v44 = *((_QWORD *)msp + 3);
          v45 = *(_QWORD *)(v39 + 16);
          if ( v39 >= v44 && v45 >= v44 )
          {
            *(_QWORD *)(v45 + 24) = v3;
            *(_QWORD *)(v39 + 16) = v3;
            *((_QWORD *)v3 + 2) = v45;
            *((_QWORD *)v3 + 3) = v39;
            *((_QWORD *)v3 + 6) = 0;
          }
          return;
        }
        v42 = v41;
        v41 *= 2LL;
        v43 = (v42 >> 63) + 4;
        if ( !*(_QWORD *)(v39 + 8 * v43) )
          break;
        v39 = *(_QWORD *)(v39 + 8 * v43);
      }
      if ( *((_QWORD *)msp + 3) <= v39 + 8 * v43 )
      {
        *(_QWORD *)(v39 + 8 * v43) = v3;
        *((_QWORD *)v3 + 6) = v39;
        *((_QWORD *)v3 + 3) = v3;
        *((_QWORD *)v3 + 2) = v3;
      }
    }
    else
    {
      v58 = v37 + 74;
      *((_DWORD *)msp + 1) = v38 | (1 << v36);
      *((_QWORD *)msp + v58) = v3;
      *((_QWORD *)v3 + 3) = v3;
      *((_QWORD *)v3 + 2) = v3;
      *((_QWORD *)v3 + 6) = (char *)msp + 8 * v58;
    }
  }
  else
  {
    v33 = *(_DWORD *)msp;
    if ( _bittest(&v33, v32) )
    {
      v34 = (char *)*((_QWORD *)msp + (unsigned int)(2 * v32) + 10);
      if ( (unsigned __int64)v34 < *((_QWORD *)msp + 3) )
        v34 = (char *)msp + 8 * (unsigned int)(2 * v32) + 64;
    }
    else
    {
      *(_DWORD *)msp = v33 | (1 << v32);
      v34 = (char *)msp + 8 * (unsigned int)(2 * v32) + 64;
    }
    *((_QWORD *)msp + (unsigned int)(2 * v32) + 10) = v3;
    *((_QWORD *)v34 + 3) = v3;
    *((_QWORD *)v3 + 2) = v34;
    *((_QWORD *)v3 + 3) = (char *)msp + 8 * (unsigned int)(2 * v32) + 64;
  }
}


// Address: 0x2267690 | Name: _ZN4FMOD13mspace_callocEPvmm
void *__fastcall FMOD::mspace_calloc(FMOD::mspace msp, size_t n_elements, size_t elem_size)
{
  size_t v3; // rbx
  void *v4; // rax
  void *v5; // rbp

  v3 = 0;
  if ( n_elements )
  {
    v3 = elem_size * n_elements;
    if ( ((elem_size | n_elements) & 0xFFFFFFFFFFFF0000LL) != 0 && v3 / n_elements != elem_size )
      v3 = -1;
  }
  v4 = FMOD::mspace_malloc(msp, v3);
  v5 = v4;
  if ( v4 )
    memset(v4, 0, v3);
  return v5;
}


// Address: 0x2267700 | Name: _ZN4FMOD14mspace_reallocEPvS0_m
void *__fastcall FMOD::mspace_realloc(FMOD::mspace msp, void *oldmem, size_t bytes)
{
  FMOD::malloc_params *v6; // rdi
  char *v7; // rdx
  __int64 v8; // rcx
  unsigned __int64 v9; // r13
  char *v10; // rsi
  size_t v11; // rax
  unsigned __int64 v12; // rdi
  void *v14; // rax
  void *v15; // r14
  size_t v16; // r13
  size_t v17; // rdx
  char *v18; // rsi
  size_t v19; // rsi
  size_t v20; // rsi

  if ( !oldmem )
    return FMOD::mspace_malloc(msp, bytes);
  if ( bytes > 0xFFFFFFFFFFFFFF7FLL )
    return 0;
  v6 = (FMOD::malloc_params *)((char *)msp + 904);
  if ( v6 && !*((_QWORD *)msp + 114) )
  {
    FMOD::init_mparams(v6);
    v7 = (char *)oldmem - 16;
    v8 = *((_QWORD *)oldmem - 1);
    if ( (char *)oldmem - 16 < (char *)*((_QWORD *)msp + 3) )
      return 0;
  }
  else
  {
    v7 = (char *)oldmem - 16;
    v8 = *((_QWORD *)oldmem - 1);
    if ( (char *)oldmem - 16 < (char *)*((_QWORD *)msp + 3) )
      return 0;
  }
  if ( (v8 & 2) == 0 )
    return 0;
  v9 = v8 & 0xFFFFFFFFFFFFFFFCLL;
  v10 = &v7[v8 & 0xFFFFFFFFFFFFFFFCLL];
  if ( v7 >= v10 || (v10[8] & 1) == 0 )
    return 0;
  v11 = 32;
  if ( bytes <= 0x16 )
  {
    if ( v9 >= 0x20 )
      goto LABEL_11;
LABEL_18:
    if ( v10 != *((char **)msp + 5) )
      goto LABEL_19;
    v19 = *((_QWORD *)msp + 2) + v9;
    if ( v11 >= v19 )
      goto LABEL_19;
    v20 = v19 - v11;
    *((_QWORD *)oldmem - 1) = v11 | v8 & 1 | 2;
    *(_QWORD *)&v7[v11 + 8] = v20 | 1;
    *((_QWORD *)msp + 5) = &v7[v11];
    *((_QWORD *)msp + 2) = v20;
LABEL_12:
    if ( v7 )
      return oldmem;
LABEL_19:
    v14 = FMOD::mspace_malloc(msp, bytes);
    v15 = v14;
    if ( v14 )
    {
      v16 = v9 - 8;
      v17 = bytes;
      if ( v16 <= bytes )
        v17 = v16;
      memcpy_0(v14, oldmem, v17);
      FMOD::mspace_free(msp, oldmem);
      return v15;
    }
    return 0;
  }
  v11 = (bytes + 23) & 0xFFFFFFFFFFFFFFF0LL;
  if ( v9 < v11 )
    goto LABEL_18;
LABEL_11:
  v12 = v9 - v11;
  if ( v9 - v11 <= 0x1F )
    goto LABEL_12;
  v18 = &v7[v11];
  *((_QWORD *)oldmem - 1) = v11 | v8 & 1 | 2;
  *((_QWORD *)v18 + 1) = v12 | 3;
  *(_QWORD *)&v18[v12 + 8] |= 1uLL;
  if ( !v7 )
    goto LABEL_19;
  if ( &v7[v11] == (char *)-16LL )
    return oldmem;
  FMOD::mspace_free(msp, &v7[v11 + 16]);
  return oldmem;
}


// Address: 0x22678b0 | Name: _ZN4FMOD15mspace_memalignEPvmm
void *__fastcall FMOD::mspace_memalign(FMOD::mspace msp, size_t alignment, size_t bytes)
{
  size_t v3; // rax
  size_t v4; // rbx
  size_t v5; // r14
  unsigned __int64 v6; // rax
  _QWORD *v7; // rsi
  char *v8; // r13
  __int64 v9; // rax
  char *v10; // rbx
  unsigned __int64 v11; // rdx
  char *v12; // rbx
  __int64 v14; // rax
  __int64 v15; // rbx
  unsigned __int64 v16; // rax
  unsigned __int64 v17; // [rsp+8h] [rbp-30h]

  if ( alignment <= 0x10 )
    return FMOD::mspace_malloc(msp, bytes);
  v3 = -160;
  v4 = 32;
  if ( alignment > 0x1F )
  {
    if ( (alignment & (alignment - 1)) != 0 )
    {
      if ( alignment != 32 )
      {
        do
          v4 *= 2LL;
        while ( alignment > v4 );
        v3 = -128LL - v4;
      }
    }
    else
    {
      LOBYTE(v3) = 0x80;
      v4 = alignment;
      v3 -= alignment;
    }
  }
  if ( bytes >= v3 )
    return 0;
  v5 = 32;
  if ( bytes > 0x16 )
    v5 = (bytes + 23) & 0xFFFFFFFFFFFFFFF0LL;
  v6 = (unsigned __int64)FMOD::mspace_malloc(msp, v4 + v5 + 24);
  v7 = (_QWORD *)v6;
  if ( !v6 )
    return 0;
  v8 = (char *)(v6 - 16);
  if ( msp != (FMOD::mspace)-904LL && !*((_QWORD *)msp + 114) )
  {
    v17 = v6;
    FMOD::init_mparams((FMOD::malloc_params *)((char *)msp + 904));
    v7 = (_QWORD *)v17;
    if ( !(v17 % v4) )
      goto LABEL_14;
LABEL_22:
    v14 = (-(__int64)v4 & ((unsigned __int64)v7 + v4 - 1)) - 16;
    v15 = v14 + v4;
    if ( (unsigned __int64)(v14 - (_QWORD)v8) > 0x1F )
      v15 = v14;
    v16 = (*(v7 - 1) & 0xFFFFFFFFFFFFFFFCLL) - (v15 - (_QWORD)v8);
    *(_QWORD *)(v15 + 8) = v16 | *(_QWORD *)(v15 + 8) & 1LL | 2;
    *(_QWORD *)(v15 + v16 + 8) |= 1uLL;
    *(v7 - 1) = (v15 - (_QWORD)v8) | *(v7 - 1) & 1LL | 2;
    *(_QWORD *)(v15 + 8) |= 1uLL;
    v8 = (char *)v15;
    goto LABEL_15;
  }
  if ( v6 % v4 )
    goto LABEL_22;
LABEL_14:
  v7 = 0;
LABEL_15:
  v9 = *((_QWORD *)v8 + 1);
  v10 = 0;
  if ( (v9 & 0xFFFFFFFFFFFFFFFCLL) > v5 + 32 )
  {
    v11 = (v9 & 0xFFFFFFFFFFFFFFFCLL) - v5;
    v12 = &v8[v5];
    *((_QWORD *)v8 + 1) = v5 | v9 & 1 | 2;
    *((_QWORD *)v12 + 1) = v11 | 3;
    *(_QWORD *)&v12[v11 + 8] |= 1uLL;
    v10 = &v8[v5 + 16];
  }
  if ( v7 )
    FMOD::mspace_free(msp, v7);
  if ( v10 )
    FMOD::mspace_free(msp, v10);
  return v8 + 16;
}


// Address: 0x2267ab0 | Name: _ZN4FMOD25mspace_independent_callocEPvmmPS0_
void **__fastcall FMOD::mspace_independent_calloc(FMOD::mspace msp, size_t n_elements, size_t elem_size, void **chunks)
{
  size_t sz[2]; // [rsp+8h] [rbp-10h] BYREF

  sz[0] = elem_size;
  return FMOD::ialloc((FMOD::mstate)msp, n_elements, sz, 3, chunks);
}


// Address: 0x2267ad0 | Name: _ZN4FMOD27mspace_independent_comallocEPvmPmPS0_
void **__fastcall FMOD::mspace_independent_comalloc(FMOD::mspace msp, size_t n_elements, size_t *sizes, void **chunks)
{
  return FMOD::ialloc((FMOD::mstate)msp, n_elements, sizes, 0, chunks);
}


// Address: 0x2267ae0 | Name: _ZN4FMOD11mspace_trimEPvm
int __fastcall FMOD::mspace_trim(FMOD::mspace msp, size_t pad)
{
  FMOD::malloc_params *v3; // rdi
  unsigned __int64 v4; // rcx
  size_t v5; // rdi
  size_t v6; // rsi
  unsigned __int64 v7; // r8
  unsigned __int64 *v8; // rax
  unsigned __int64 *v9; // rbp
  unsigned __int64 v10; // r12
  unsigned __int64 v11; // r13
  __int64 v13; // r12
  unsigned __int64 v14; // rax
  unsigned __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rax
  __int64 v18; // rax
  __int64 v19; // rdx
  __int64 v20; // rax
  __int64 v21; // rcx

  v3 = (FMOD::malloc_params *)((char *)msp + 904);
  if ( v3 && !*((_QWORD *)msp + 114) )
    FMOD::init_mparams(v3);
  if ( pad > 0xFFFFFFFFFFFFFF7FLL )
    return 0;
  v4 = *((_QWORD *)msp + 5);
  if ( !v4 )
    return 0;
  v5 = *((_QWORD *)msp + 2);
  v6 = pad + 80;
  if ( v6 >= v5 )
    goto LABEL_16;
  v7 = *((_QWORD *)msp + 115);
  v8 = (unsigned __int64 *)((char *)msp + 872);
  while ( v4 < *v8 || v4 >= v8[1] + *v8 )
  {
    v8 = (unsigned __int64 *)v8[2];
    if ( !v8 )
    {
      v9 = 0;
      goto LABEL_12;
    }
  }
  v9 = v8;
LABEL_12:
  if ( (v9[3] & 8) != 0 )
    goto LABEL_16;
  v10 = v7 * ((v5 + v7 - 1 - v6) / v7 - 1);
  if ( v10 > 0x7FFFFFFFFFFFFFFELL )
    LODWORD(v10) = -(int)v7;
  v11 = (*((__int64 (__fastcall **)(_QWORD, _QWORD, size_t))msp + 119))(
          0,
          *((_QWORD *)msp + 120),
          (v5 + v7 - 1 - v6) % v7);
  if ( v11 != v9[1] + *v9
    || (v13 = (*((__int64 (__fastcall **)(_QWORD, _QWORD))msp + 119))((unsigned int)-(int)v10, *((_QWORD *)msp + 120)),
        v14 = (*((__int64 (__fastcall **)(_QWORD, _QWORD))msp + 119))(0, *((_QWORD *)msp + 120)),
        v11 <= v14)
    || v13 == -1
    || (v15 = v11 - v14, v11 == v14) )
  {
LABEL_16:
    *((_QWORD *)msp + 6) = -1;
    return 0;
  }
  v16 = *((_QWORD *)msp + 5);
  v17 = *((_QWORD *)msp + 2);
  v9[1] -= v15;
  *((_QWORD *)msp + 106) -= v15;
  v18 = v17 - v15;
  v19 = 0;
  if ( (((_BYTE)v16 + 16) & 0xF) != 0 )
    v19 = -(char)(v16 + 16) & 0xF;
  v20 = v18 - v19;
  v21 = v19 + v16;
  *((_QWORD *)msp + 2) = v20;
  *((_QWORD *)msp + 5) = v21;
  *(_QWORD *)(v21 + 8) = v20 | 1;
  *(_QWORD *)(v21 + v20 + 8) = 80;
  *((_QWORD *)msp + 6) = *((_QWORD *)msp + 117);
  return 1;
}


// Address: 0x2267c90 | Name: _ZN4FMOD16mspace_footprintEPv
size_t __fastcall FMOD::mspace_footprint(FMOD::mspace msp)
{
  return *((_QWORD *)msp + 106);
}


// Address: 0x2267ca0 | Name: _ZN4FMOD20mspace_max_footprintEPv
size_t __fastcall FMOD::mspace_max_footprint(FMOD::mspace msp)
{
  return *((_QWORD *)msp + 107);
}


// Address: 0x2267cb0 | Name: _ZN4FMOD16mspace_chunksizeEPv
size_t __fastcall FMOD::mspace_chunksize(void *mem)
{
  return *((_QWORD *)mem - 1) & 0xFFFFFFFFFFFFFFFCLL;
}


// Address: 0x2267cc0 | Name: _ZN4FMOD15mspace_mallinfoEPv
FMOD::mallinfo *__fastcall FMOD::mspace_mallinfo(FMOD::mallinfo *__return_ptr retstr, FMOD::mspace msp)
{
  __int64 v3; // rbx
  size_t v4; // rdi
  unsigned __int64 *v5; // r13
  size_t v6; // r12
  size_t v7; // rbp
  size_t v8; // r9
  unsigned __int64 v9; // r10
  __int64 v10; // rdx
  __int64 v11; // rax
  bool v12; // cf
  unsigned __int64 v13; // rdx
  __int64 v14; // rcx
  unsigned __int64 v15; // r8
  __int64 v16; // rax

  memset(retstr, 0, sizeof(FMOD::mallinfo));
  if ( msp != (FMOD::mspace)-904LL && !*((_QWORD *)msp + 114) )
    FMOD::init_mparams((FMOD::malloc_params *)((char *)msp + 904));
  v3 = *((_QWORD *)msp + 5);
  if ( v3 )
  {
    v4 = *((_QWORD *)msp + 2);
    v5 = (unsigned __int64 *)((char *)msp + 872);
    v6 = 1;
    v7 = v4 + 80;
    v8 = v4 + 80;
    do
    {
      v9 = *v5;
      v10 = 0;
      v11 = *v5 + 16;
      if ( (v11 & 0xF) != 0 )
        v10 = -(char)v11 & 0xF;
      v12 = __CFADD__(v9, v10);
      v13 = v9 + v10;
      if ( !v12 )
      {
        do
        {
          if ( v13 >= v5[1] + v9 )
            break;
          if ( v3 == v13 )
            break;
          v14 = *(_QWORD *)(v13 + 8);
          if ( v14 == 11 )
            break;
          v15 = v14 & 0xFFFFFFFFFFFFFFFCLL;
          v8 += v14 & 0xFFFFFFFFFFFFFFFCLL;
          if ( (v14 & 2) == 0 )
          {
            v7 += v15;
            ++v6;
          }
          v13 += v15;
        }
        while ( v9 <= v13 );
      }
      v5 = (unsigned __int64 *)v5[2];
    }
    while ( v5 );
    v16 = *((_QWORD *)msp + 106);
    retstr->arena = v8;
    retstr->ordblks = v6;
    retstr->fordblks = v7;
    retstr->keepcost = v4;
    retstr->uordblks = v16 - v7;
    retstr->hblkhd = v16 - v8;
    retstr->usmblks = *((_QWORD *)msp + 107);
  }
  return retstr;
}


