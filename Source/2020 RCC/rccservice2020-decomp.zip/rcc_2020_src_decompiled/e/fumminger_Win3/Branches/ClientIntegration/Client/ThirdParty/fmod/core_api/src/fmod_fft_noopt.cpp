// Address: 0x225f5f0 | Name: FMOD_FFT_IDFT_conjugate_pair_dit_NoOpt
void __fastcall FMOD_FFT_IDFT_conjugate_pair_dit_NoOpt(float *out, float *root_table, int N)
{
  int v4; // r14d
  int v5; // edx
  int v6; // r14d
  float *v7; // r12
  float *v8; // r13
  float *v9; // r15
  float *v10; // rcx
  float *v11; // r9
  float *v12; // r8
  __int64 v13; // rax
  float v14; // xmm0_4
  float v15; // xmm9_4
  float v16; // xmm4_4
  float v17; // xmm7_4
  float v18; // xmm1_4
  float v19; // xmm3_4
  float v20; // xmm5_4
  float v21; // xmm2_4
  float v22; // xmm0_4
  float v23; // xmm6_4
  float v24; // xmm3_4
  float v25; // xmm2_4
  float v26; // xmm4_4
  float v27; // xmm1_4
  float v28; // xmm0_4
  float v29; // xmm7_4
  float v30; // xmm13_4
  float v31; // xmm14_4
  float v32; // xmm9_4
  float v33; // xmm12_4
  float v34; // xmm13_4
  float v35; // xmm6_4
  float v36; // xmm5_4
  float v37; // xmm2_4
  float v38; // xmm14_4
  float v39; // xmm7_4
  float v40; // xmm3_4
  float v41; // xmm14_4
  float v42; // xmm0_4
  float v43; // xmm7_4
  float v44; // xmm1_4
  float v45; // xmm15_4
  float v46; // xmm8_4
  float v47; // xmm6_4
  float v48; // xmm4_4
  float v49; // xmm2_4
  float v50; // xmm10_4
  float v51; // xmm3_4
  float v52; // xmm1_4
  float v53; // xmm0_4
  float v54; // xmm8_4
  float v55; // xmm14_4
  float v56; // xmm0_4
  float v57; // xmm10_4
  float v58; // xmm12_4
  float v59; // xmm0_4
  float v60; // xmm14_4
  float v61; // xmm15_4
  float v62; // xmm11_4
  float v63; // xmm15_4
  float v64; // xmm10_4
  float v65; // xmm0_4
  float v66; // xmm12_4
  float v67; // xmm15_4
  float v68; // xmm13_4
  float v69; // xmm9_4
  float v70; // xmm15_4
  float v71; // xmm13_4
  float v72; // xmm8_4
  float v73; // xmm11_4
  float v74; // xmm0_4
  float v75; // xmm11_4
  float v76; // xmm7_4
  float v77; // xmm0_4
  float v78; // xmm8_4
  float v79; // xmm6_4
  float v80; // xmm5_4
  float v81; // xmm6_4
  float v82; // xmm0_4
  float v83; // xmm9_4
  float v84; // xmm7_4
  float v85; // xmm5_4
  float v86; // xmm3_4
  float v87; // xmm4_4
  float v88; // xmm10_4
  float v89; // xmm2_4
  float v90; // xmm6_4
  float v91; // xmm10_4
  float v92; // xmm5_4
  float v93; // xmm0_4
  float v94; // xmm8_4
  float v95; // xmm10_4
  float v96; // xmm14_4
  float v97; // xmm10_4
  float v98; // xmm12_4
  float v99; // xmm10_4
  float v100; // xmm0_4
  float v101; // xmm1_4
  float v102; // xmm10_4
  float v103; // xmm9_4
  float v104; // xmm4_4
  float v105; // xmm1_4
  float v106; // xmm10_4
  float v107; // xmm0_4
  float v108; // xmm4_4
  float v109; // xmm15_4
  float v110; // xmm9_4
  float v111; // xmm11_4
  float v112; // xmm4_4
  float v113; // xmm13_4
  float v114; // xmm3_4
  float v115; // xmm0_4
  float v116; // xmm3_4
  float v117; // xmm1_4
  float v118; // xmm2_4
  float v119; // xmm5_4
  float v120; // xmm0_4
  float v121; // xmm5_4
  float v122; // xmm2_4
  float v123; // xmm4_4
  float v124; // xmm3_4
  float v125; // xmm8_4
  float v126; // xmm11_4
  float v127; // xmm7_4
  float v128; // xmm6_4
  float v129; // xmm9_4
  float v130; // xmm7_4
  float v131; // xmm1_4
  float v132; // xmm7_4
  float v133; // xmm7_4
  float v134; // xmm11_4
  float v135; // xmm15_4
  float v136; // xmm6_4
  float v137; // xmm7_4
  float v138; // xmm2_4
  float v139; // xmm6_4
  float v140; // xmm14_4
  float v141; // xmm1_4
  float v142; // xmm8_4
  float v143; // xmm6_4
  float v144; // xmm5_4
  float v145; // xmm14_4
  float v146; // xmm13_4
  float v147; // xmm9_4
  float v148; // xmm4_4
  float v149; // xmm8_4
  float v150; // xmm5_4
  float v151; // xmm3_4
  float v152; // xmm4_4
  float v153; // xmm12_4
  float v154; // xmm0_4
  float v155; // xmm10_4
  float v156; // xmm4_4
  float v157; // xmm12_4
  float v158; // xmm14_4
  float v159; // xmm15_4
  float v160; // xmm9_4
  float v161; // xmm15_4
  float v162; // xmm8_4
  float v163; // xmm5_4
  float v164; // xmm10_4
  float v165; // xmm12_4
  float v166; // xmm4_4
  float v167; // xmm3_4
  float v168; // xmm13_4
  float v169; // xmm10_4
  float v170; // xmm8_4
  float v171; // xmm11_4
  float v172; // xmm7_4
  float v173; // xmm4_4
  float v174; // xmm2_4
  float v175; // xmm8_4
  float v176; // xmm3_4
  float v177; // [rsp+0h] [rbp-A8h]
  float v178; // [rsp+0h] [rbp-A8h]
  float v179; // [rsp+0h] [rbp-A8h]
  float v180; // [rsp+8h] [rbp-A0h]
  float v181; // [rsp+8h] [rbp-A0h]
  __int64 v182; // [rsp+10h] [rbp-98h]
  float v183; // [rsp+10h] [rbp-98h]
  float v184; // [rsp+10h] [rbp-98h]
  float v185; // [rsp+10h] [rbp-98h]
  float v186; // [rsp+1Ch] [rbp-8Ch]
  float v187; // [rsp+1Ch] [rbp-8Ch]
  float v188; // [rsp+20h] [rbp-88h]
  float v189; // [rsp+24h] [rbp-84h]
  float v190; // [rsp+24h] [rbp-84h]
  float v191; // [rsp+28h] [rbp-80h]
  float v192; // [rsp+28h] [rbp-80h]
  float v193; // [rsp+2Ch] [rbp-7Ch]
  float v194; // [rsp+2Ch] [rbp-7Ch]
  float v195; // [rsp+30h] [rbp-78h]
  float v196; // [rsp+30h] [rbp-78h]
  float v197; // [rsp+34h] [rbp-74h]
  float v198; // [rsp+34h] [rbp-74h]
  float v199; // [rsp+38h] [rbp-70h]
  float v200; // [rsp+38h] [rbp-70h]
  float v201; // [rsp+3Ch] [rbp-6Ch]
  float v202; // [rsp+3Ch] [rbp-6Ch]
  float v203; // [rsp+40h] [rbp-68h]
  float v204; // [rsp+40h] [rbp-68h]
  float v205; // [rsp+44h] [rbp-64h]
  float v206; // [rsp+44h] [rbp-64h]
  float v207; // [rsp+48h] [rbp-60h]
  float v208; // [rsp+48h] [rbp-60h]
  float v209; // [rsp+4Ch] [rbp-5Ch]
  float v210; // [rsp+4Ch] [rbp-5Ch]
  float v211; // [rsp+50h] [rbp-58h]
  float v212; // [rsp+54h] [rbp-54h]
  float v213; // [rsp+58h] [rbp-50h]
  float v214; // [rsp+58h] [rbp-50h]
  float v215; // [rsp+5Ch] [rbp-4Ch]
  float v216; // [rsp+5Ch] [rbp-4Ch]
  float v217; // [rsp+60h] [rbp-48h]
  float v218; // [rsp+60h] [rbp-48h]
  float v219; // [rsp+64h] [rbp-44h]
  float v220; // [rsp+68h] [rbp-40h]
  float v221; // [rsp+6Ch] [rbp-3Ch]

  if ( N == 8 )
  {
    v133 = out[2];
    v134 = *out - v133;
    v135 = *out + v133;
    v136 = out[10];
    v137 = out[8] + v136;
    v138 = out[8] - v136;
    v139 = out[12];
    v140 = out[14];
    v141 = v139 - v140;
    v142 = out[4];
    v143 = v139 + v140;
    v144 = out[3];
    v145 = out[6] + v142;
    v146 = out[1] + v144;
    v147 = out[1] - v144;
    v148 = out[11];
    v149 = v142 - out[6];
    v150 = out[9] + v148;
    v151 = out[9] - v148;
    v152 = out[13];
    v153 = out[15];
    v154 = v152 - v153;
    v155 = out[5];
    v156 = v152 + v153;
    v157 = out[7] + v155;
    v185 = v135 - v145;
    v158 = v145 + v135;
    v159 = v147;
    v160 = v147 - v149;
    v161 = v159 + v149;
    v162 = v150;
    v163 = v150 - v156;
    v187 = v146 - v157;
    v164 = v155 - out[7];
    v165 = v157 + v146;
    v179 = v162 + v156;
    v166 = v138 + v151;
    v167 = v151 - v138;
    v168 = v134 - v164;
    v169 = v164 + v134;
    v170 = v166;
    v171 = v137 + v143;
    v172 = v137 - v143;
    v173 = (float)((float)(v141 + v166) - v154) * 0.70710677;
    v174 = (float)((float)(v141 + v167) + v154) * 0.70710677;
    v175 = (float)((float)(v170 - v141) + v154) * 0.70710677;
    v176 = (float)((float)(v167 - v141) - v154) * 0.70710677;
    *out = v158 + v171;
    out[1] = v179 + v165;
    out[2] = v169 + v173;
    out[3] = v160 + v174;
    out[4] = v185 + v163;
    out[5] = v187 - v172;
    out[6] = v168 + v176;
    out[8] = v158 - v171;
    out[10] = v169 - v173;
    out[11] = v160 - v174;
    out[13] = v172 + v187;
    out[14] = v168 - v176;
    out[7] = v161 - v175;
    out[9] = v165 - v179;
    out[15] = v175 + v161;
    out[12] = v185 - v163;
  }
  else if ( N == 16 )
  {
    v30 = out[1];
    v31 = out[3];
    v32 = v30 - v31;
    v33 = out[8];
    v34 = v30 + v31;
    v35 = out[11];
    v36 = out[12];
    v37 = out[17];
    v191 = out[10] + v33;
    v38 = out[9];
    v39 = v38 - v35;
    v40 = out[13];
    v41 = v38 + v35;
    v42 = out[25];
    v203 = v39;
    v195 = out[14] + v36;
    v43 = out[18] + out[16];
    v205 = v36 - out[14];
    v44 = out[24];
    v180 = out[15] + v40;
    v45 = out[2] + *out;
    v46 = out[4];
    v47 = out[19] + v37;
    v177 = v40 - out[15];
    v193 = v41;
    v48 = v37 - out[19];
    v49 = out[27] + v42;
    v50 = out[5];
    v201 = v33 - out[10];
    v51 = out[26] + v44;
    v52 = v44 - out[26];
    v189 = v42 - out[27];
    v53 = out[6] + v46;
    v54 = v46 - out[6];
    v55 = v53;
    v56 = out[7] + v50;
    v57 = v50 - out[7];
    v58 = v56;
    v59 = v45 - v55;
    v60 = v55 + v45;
    v61 = *out - out[2];
    v62 = v61 + v57;
    v63 = v61 - v57;
    v197 = v59;
    v64 = out[21] + out[23];
    v65 = v34 - v58;
    v66 = v58 + v34;
    v183 = v63;
    v67 = v32;
    v68 = v32 + v54;
    v199 = v65;
    v69 = out[21] - out[23];
    v70 = v67 - v54;
    v207 = v68;
    v71 = v62;
    v72 = out[20] - out[22];
    v73 = out[20] + out[22];
    v74 = v43 - v73;
    v75 = v73 + v43;
    v76 = v48 + v72;
    v219 = v74;
    v77 = v47;
    v215 = v48 - v72;
    v78 = out[29] + out[31];
    v221 = v76;
    v209 = v47 + v64;
    v79 = out[16] - out[18];
    v80 = v79 + v69;
    v220 = v77 - v64;
    v81 = v79 - v69;
    v82 = v189;
    v83 = out[28] + out[30];
    v213 = v80;
    v84 = v51 - v83;
    v85 = out[29] - out[31];
    v186 = v81;
    v86 = v51 + v83;
    v87 = out[28] - out[30];
    v88 = v49;
    v89 = v49 + v78;
    v90 = v88 - v78;
    v188 = v52 - v85;
    v190 = v189 + v87;
    v91 = v52 + v85;
    v92 = v82 - v87;
    v217 = v91;
    v93 = v180 + v193;
    v94 = v193 - v180;
    v95 = v60;
    v96 = v60 + (float)(v191 + v195);
    v181 = v95 - (float)(v191 + v195);
    v97 = v66;
    v98 = v66 + v93;
    v99 = v97 - v93;
    v100 = v199 - (float)(v191 - v195);
    v101 = v199 + (float)(v191 - v195);
    v192 = v99;
    v200 = v100;
    v196 = v101;
    v194 = v197 - v94;
    v198 = v94 + v197;
    v102 = (float)((float)(v205 + (float)(v201 + v203)) - v177) * 0.70710677;
    v103 = (float)((float)(v205 + (float)(v203 - v201)) + v177) * 0.70710677;
    v104 = v71 - v102;
    v105 = (float)((float)((float)(v203 - v201) - v205) - v177) * 0.70710677;
    v106 = v102 + v71;
    v107 = (float)((float)((float)(v201 + v203) - v205) + v177) * 0.70710677;
    v178 = v104;
    v108 = v70;
    v109 = v70 + v103;
    v202 = v108 - v103;
    v204 = v183 - v105;
    v110 = v75;
    v111 = v75 - v86;
    v184 = v105 + v183;
    v112 = v207 - v107;
    v113 = v207 + v107;
    v208 = v110 + v86;
    v114 = v209 - v89;
    v206 = v112;
    v210 = v209 + v89;
    v211 = v111;
    v212 = v114;
    v115 = (float)(-0.38268346 * v213) + (float)(v215 * 0.9238795);
    v116 = (float)(v217 * 0.9238795) - (float)(v92 * 0.38268346);
    v117 = (float)(0.38268346 * v217) + (float)(v92 * 0.9238795);
    v118 = (float)((float)(v213 * 0.9238795) - (float)(v215 * -0.38268346)) - v116;
    v214 = (float)((float)(v213 * 0.9238795) - (float)(v215 * -0.38268346)) + v116;
    v119 = v115;
    v218 = v118;
    v120 = v115 - v117;
    v216 = v119 + v117;
    v121 = (float)((float)(v84 + (float)(v219 + v220)) - v90) * 0.70710677;
    v122 = (float)((float)((float)(v219 + v220) - v84) + v90) * 0.70710677;
    v123 = (float)((float)(v84 + (float)(v220 - v219)) + v90) * 0.70710677;
    v124 = (float)((float)((float)(v220 - v219) - v84) - v90) * 0.70710677;
    v125 = (float)(v188 * 0.38268343) - (float)(v190 * 0.9238795);
    v126 = (float)(0.9238795 * v188) + (float)(0.38268343 * v190);
    v127 = (float)(v186 * 0.38268343) - (float)(v221 * -0.9238795);
    v128 = v127 - v125;
    v129 = v127 + v125;
    v130 = (float)(-0.9238795 * v186) + (float)(v221 * 0.38268343);
    *out = v208 + v96;
    v131 = v130 - v126;
    v132 = v130 + v126;
    out[1] = v210 + v98;
    out[2] = v214 + v106;
    out[3] = v216 + v109;
    out[4] = v198 + v121;
    out[5] = v200 + v123;
    out[6] = v184 + v129;
    out[7] = v206 + v132;
    out[8] = v181 + v212;
    out[9] = v192 - v211;
    out[10] = v178 + v120;
    out[11] = v202 - v218;
    out[12] = v194 + v124;
    out[13] = v196 - v122;
    out[14] = v204 + v131;
    out[17] = v98 - v210;
    out[19] = v109 - v216;
    out[16] = v96 - v208;
    out[15] = v113 - v128;
    out[18] = v106 - v214;
    out[20] = v198 - v121;
    out[21] = v200 - v123;
    out[22] = v184 - v129;
    out[23] = v206 - v132;
    out[24] = v181 - v212;
    out[25] = v192 + v211;
    out[26] = v178 - v120;
    out[27] = v202 + v218;
    out[28] = v194 - v124;
    out[29] = v122 + v196;
    out[31] = v128 + v113;
    out[30] = v204 - v131;
  }
  else
  {
    v4 = N + 3;
    v5 = N / 2;
    if ( N >= 0 )
      v4 = N;
    v6 = v4 >> 2;
    v7 = &out[2 * v5];
    v182 = 2 * v5;
    v8 = &out[6 * v6];
    FMOD_FFT_IDFT_conjugate_pair_dit_NoOpt(out, &root_table[2 * v6], v5);
    v9 = &root_table[2 * v6 + 2 * (N / 8)];
    FMOD_FFT_IDFT_conjugate_pair_dit_NoOpt(v7, v9, v6);
    FMOD_FFT_IDFT_conjugate_pair_dit_NoOpt(v8, v9, v6);
    if ( v6 > 0 )
    {
      v10 = &out[2 * v6 + 1];
      v11 = &out[v182 + 1];
      v12 = &out[6 * v6 + 1];
      v13 = 0;
      do
      {
        v14 = root_table[2 * v13 + 1];
        v10 += 2;
        v11 += 2;
        v12 += 2;
        v15 = v7[2 * v13 + 1];
        v16 = root_table[2 * v13];
        v17 = v7[2 * v13];
        v18 = (float)((float)-v14 * v17) + (float)(v15 * v16);
        v19 = (float)(v16 * v17) - (float)(v15 * (float)-v14);
        v20 = out[2 * v13 + 1];
        v21 = (float)(v8[2 * v13] * v16) - (float)(v8[2 * v13 + 1] * v14);
        v22 = (float)(v14 * v8[2 * v13]) + (float)(v16 * v8[2 * v13 + 1]);
        v23 = v19 + v21;
        v24 = v19 - v21;
        v25 = *(v10 - 3);
        v26 = v18 + v22;
        v27 = v18 - v22;
        v28 = *(v10 - 2);
        v29 = out[2 * v13] - v23;
        out[2 * v13] = out[2 * v13] + v23;
        out[2 * v13++ + 1] = v20 + v26;
        *(v10 - 3) = v25 + v27;
        *(v10 - 2) = v28 - v24;
        *(v11 - 3) = v29;
        *(v11 - 2) = v20 - v26;
        *(v12 - 3) = v25 - v27;
        *(v12 - 2) = v24 + v28;
      }
      while ( v6 > (int)v13 );
    }
  }
}


// Address: 0x2260270 | Name: FMOD_FFT_Real_DFT_Postprocess_NoOpt
void __fastcall FMOD_FFT_Real_DFT_Postprocess_NoOpt(float *in, float *out, float *table, int N)
{
  float v4; // xmm0_4
  int v5; // r9d
  float v6; // xmm0_4
  __int64 v7; // r10
  unsigned __int64 v8; // rax
  float *v9; // r8
  float v10; // xmm2_4
  float v11; // xmm3_4
  float v12; // xmm6_4
  float v13; // xmm9_4
  float v14; // xmm0_4
  float v15; // xmm3_4
  float v16; // xmm2_4
  float v17; // xmm12_4
  float v18; // xmm3_4
  float v19; // xmm1_4
  float v20; // xmm12_4
  float v21; // xmm2_4
  float v22; // xmm1_4
  float v23; // xmm12_4
  float v24; // xmm6_4
  float *v25; // rax
  float *v26; // rdx
  float v27; // xmm0_4

  v4 = *in + in[1];
  out[1] = 0.0;
  v5 = 2 * (N / 2);
  *out = v4;
  v6 = *in - in[1];
  out[v5 + 1] = 0.0;
  out[v5] = v6;
  if ( N / 2 > 1 )
  {
    v7 = (unsigned int)(N / 2 - 2);
    v8 = 0;
    v9 = &in[v5 - 1];
    do
    {
      v10 = table[v8 / 4 + 2];
      v9 -= 2;
      v11 = table[v8 / 4 + 3];
      v12 = v11 * 0.5;
      v13 = in[v8 / 4 + 3];
      v14 = (float)(1.0 - v10) * 0.5;
      v15 = (float)-v11 * 0.5;
      v16 = (float)(v10 + 1.0) * 0.5;
      v17 = v13 * v15;
      v18 = v15 * in[v8 / 4 + 2];
      v19 = (float)(in[v8 / 4 + 2] * v14) - v17;
      v20 = v9[1] * v16;
      v21 = v16 * v9[2];
      v22 = v19 + v20;
      v23 = v9[2] * v12;
      v24 = v12 * v9[1];
      out[v8 / 4 + 2] = v22 + v23;
      out[v8 / 4 + 3] = (float)((float)((float)(v14 * v13) + v18) + v24) - v21;
      v8 += 8LL;
    }
    while ( v8 != 8 * v7 + 8 );
    v25 = out + 2;
    v26 = &out[2 * N - 1];
    do
    {
      v27 = *v25;
      v25 += 2;
      v26 -= 2;
      v26[1] = v27;
      v26[2] = -*(v25 - 1);
    }
    while ( v25 != &out[2 * v7 + 4] );
  }
}


// Address: 0x22603f0 | Name: FMOD_FFT_DFT_conjugate_pair_dit_NoOpt
void __fastcall FMOD_FFT_DFT_conjugate_pair_dit_NoOpt(float *out, float *root_table, int N)
{
  int v4; // r14d
  int v5; // edx
  int v6; // r14d
  float *v7; // r12
  float *v8; // r13
  float *v9; // r15
  float *v10; // rcx
  float *v11; // r9
  float *v12; // r8
  __int64 v13; // rax
  float v14; // xmm9_4
  float v15; // xmm4_4
  float v16; // xmm1_4
  float v17; // xmm2_4
  float v18; // xmm9_4
  float v19; // xmm0_4
  float v20; // xmm1_4
  float v21; // xmm6_4
  float v22; // xmm3_4
  float v23; // xmm5_4
  float v24; // xmm2_4
  float v25; // xmm0_4
  float v26; // xmm6_4
  float v27; // xmm3_4
  float v28; // xmm2_4
  float v29; // xmm4_4
  float v30; // xmm1_4
  float v31; // xmm0_4
  float v32; // xmm7_4
  float v33; // xmm13_4
  float v34; // xmm14_4
  float v35; // xmm12_4
  float v36; // xmm9_4
  float v37; // xmm13_4
  float v38; // xmm7_4
  float v39; // xmm6_4
  float v40; // xmm3_4
  float v41; // xmm14_4
  float v42; // xmm4_4
  float v43; // xmm5_4
  float v44; // xmm14_4
  float v45; // xmm2_4
  float v46; // xmm0_4
  float v47; // xmm1_4
  float v48; // xmm6_4
  float v49; // xmm15_4
  float v50; // xmm5_4
  float v51; // xmm8_4
  float v52; // xmm10_4
  float v53; // xmm7_4
  float v54; // xmm6_4
  float v55; // xmm3_4
  float v56; // xmm1_4
  float v57; // xmm4_4
  float v58; // xmm2_4
  float v59; // xmm0_4
  float v60; // xmm8_4
  float v61; // xmm14_4
  float v62; // xmm0_4
  float v63; // xmm10_4
  float v64; // xmm12_4
  float v65; // xmm0_4
  float v66; // xmm14_4
  float v67; // xmm0_4
  float v68; // xmm12_4
  float v69; // xmm13_4
  float v70; // xmm11_4
  float v71; // xmm13_4
  float v72; // xmm10_4
  float v73; // xmm13_4
  float v74; // xmm9_4
  float v75; // xmm13_4
  float v76; // xmm8_4
  float v77; // xmm15_4
  float v78; // xmm13_4
  float v79; // xmm11_4
  float v80; // xmm9_4
  float v81; // xmm0_4
  float v82; // xmm11_4
  float v83; // xmm0_4
  float v84; // xmm6_4
  float v85; // xmm0_4
  float v86; // xmm10_4
  float v87; // xmm7_4
  float v88; // xmm9_4
  float v89; // xmm8_4
  float v90; // xmm9_4
  float v91; // xmm4_4
  float v92; // xmm0_4
  float v93; // xmm5_4
  float v94; // xmm6_4
  float v95; // xmm3_4
  float v96; // xmm7_4
  float v97; // xmm6_4
  float v98; // xmm2_4
  float v99; // xmm6_4
  float v100; // xmm9_4
  float v101; // xmm0_4
  float v102; // xmm4_4
  float v103; // xmm5_4
  float v104; // xmm8_4
  float v105; // xmm14_4
  float v106; // xmm8_4
  float v107; // xmm12_4
  float v108; // xmm1_4
  float v109; // xmm1_4
  float v110; // xmm5_4
  float v111; // xmm0_4
  float v112; // xmm13_4
  float v113; // xmm4_4
  float v114; // xmm8_4
  float v115; // xmm4_4
  float v116; // xmm8_4
  float v117; // xmm5_4
  float v118; // xmm8_4
  float v119; // xmm15_4
  float v120; // xmm5_4
  float v121; // xmm4_4
  float v122; // xmm11_4
  float v123; // xmm15_4
  float v124; // xmm1_4
  float v125; // xmm3_4
  float v126; // xmm2_4
  float v127; // xmm1_4
  float v128; // xmm3_4
  float v129; // xmm5_4
  float v130; // xmm9_4
  float v131; // xmm4_4
  float v132; // xmm3_4
  float v133; // xmm2_4
  float v134; // xmm7_4
  float v135; // xmm10_4
  float v136; // xmm0_4
  float v137; // xmm6_4
  float v138; // xmm1_4
  float v139; // xmm15_4
  float v140; // xmm6_4
  float v141; // xmm11_4
  float v142; // xmm6_4
  float v143; // xmm7_4
  float v144; // xmm5_4
  float v145; // xmm15_4
  float v146; // xmm11_4
  float v147; // xmm7_4
  float v148; // xmm6_4
  float v149; // xmm13_4
  float v150; // xmm9_4
  float v151; // xmm4_4
  float v152; // xmm12_4
  float v153; // xmm3_4
  float v154; // xmm7_4
  float v155; // xmm6_4
  float v156; // xmm14_4
  float v157; // xmm5_4
  float v158; // xmm2_4
  float v159; // xmm4_4
  float v160; // xmm8_4
  float v161; // xmm1_4
  float v162; // xmm10_4
  float v163; // xmm6_4
  float v164; // xmm14_4
  float v165; // xmm4_4
  float v166; // xmm12_4
  float v167; // xmm0_4
  float v168; // xmm10_4
  float v169; // xmm8_4
  float v170; // xmm14_4
  float v171; // xmm0_4
  float v172; // xmm12_4
  float v173; // xmm13_4
  float v174; // xmm11_4
  float v175; // xmm13_4
  float v176; // xmm15_4
  float v177; // xmm8_4
  float v178; // xmm10_4
  float v179; // xmm9_4
  float v180; // xmm2_4
  float v181; // xmm7_4
  float v182; // xmm0_4
  float v183; // xmm10_4
  float v184; // xmm5_4
  float v185; // xmm10_4
  float v186; // xmm4_4
  float v187; // xmm9_4
  float v188; // xmm2_4
  float v189; // [rsp+0h] [rbp-A8h]
  float v190; // [rsp+0h] [rbp-A8h]
  float v191; // [rsp+0h] [rbp-A8h]
  float v192; // [rsp+8h] [rbp-A0h]
  float v193; // [rsp+8h] [rbp-A0h]
  float v194; // [rsp+8h] [rbp-A0h]
  __int64 v195; // [rsp+10h] [rbp-98h]
  float v196; // [rsp+10h] [rbp-98h]
  float v197; // [rsp+10h] [rbp-98h]
  float v198; // [rsp+10h] [rbp-98h]
  float v199; // [rsp+18h] [rbp-90h]
  float v200; // [rsp+18h] [rbp-90h]
  float v201; // [rsp+1Ch] [rbp-8Ch]
  float v202; // [rsp+20h] [rbp-88h]
  float v203; // [rsp+20h] [rbp-88h]
  float v204; // [rsp+24h] [rbp-84h]
  float v205; // [rsp+24h] [rbp-84h]
  float v206; // [rsp+28h] [rbp-80h]
  float v207; // [rsp+28h] [rbp-80h]
  float v208; // [rsp+2Ch] [rbp-7Ch]
  float v209; // [rsp+2Ch] [rbp-7Ch]
  float v210; // [rsp+30h] [rbp-78h]
  float v211; // [rsp+30h] [rbp-78h]
  float v212; // [rsp+34h] [rbp-74h]
  float v213; // [rsp+34h] [rbp-74h]
  float v214; // [rsp+38h] [rbp-70h]
  float v215; // [rsp+38h] [rbp-70h]
  float v216; // [rsp+3Ch] [rbp-6Ch]
  float v217; // [rsp+3Ch] [rbp-6Ch]
  float v218; // [rsp+40h] [rbp-68h]
  float v219; // [rsp+40h] [rbp-68h]
  float v220; // [rsp+44h] [rbp-64h]
  float v221; // [rsp+44h] [rbp-64h]
  float v222; // [rsp+48h] [rbp-60h]
  float v223; // [rsp+48h] [rbp-60h]
  float v224; // [rsp+4Ch] [rbp-5Ch]
  float v225; // [rsp+50h] [rbp-58h]
  float v226; // [rsp+54h] [rbp-54h]
  float v227; // [rsp+58h] [rbp-50h]
  float v228; // [rsp+58h] [rbp-50h]
  float v229; // [rsp+5Ch] [rbp-4Ch]
  float v230; // [rsp+60h] [rbp-48h]
  float v231; // [rsp+64h] [rbp-44h]
  float v232; // [rsp+68h] [rbp-40h]
  float v233; // [rsp+6Ch] [rbp-3Ch]

  if ( N == 8 )
  {
    v143 = out[2];
    v144 = out[3];
    v145 = *out + v143;
    v146 = *out - v143;
    v147 = out[8];
    v148 = out[10];
    v149 = out[1] + v144;
    v150 = out[1] - v144;
    v151 = out[11];
    v152 = out[15];
    v153 = v147 - v148;
    v154 = v147 + v148;
    v155 = out[12];
    v156 = out[14];
    v157 = out[9] + v151;
    v158 = out[9] - v151;
    v159 = out[13];
    v160 = out[4];
    v161 = v155 - v156;
    v162 = out[5];
    v163 = v155 + v156;
    v164 = out[6] + v160;
    v191 = v159 - v152;
    v165 = v159 + v152;
    v166 = out[7] + v162;
    v167 = v145 - v164;
    v168 = v162 - out[7];
    v169 = v160 - out[6];
    v170 = v164 + v145;
    v198 = v167;
    v171 = v149 - v166;
    v172 = v166 + v149;
    v173 = v146;
    v174 = v146 - v168;
    v175 = v173 + v168;
    v176 = v150 - v169;
    v200 = v171;
    v177 = v169 + v150;
    v178 = v154 + v163;
    v179 = v153 - v158;
    v180 = v158 + v153;
    v181 = v154 - v163;
    v182 = v178;
    v183 = v157 + v165;
    v184 = v157 - v165;
    v194 = v183;
    v185 = (float)((float)(v180 - v161) + v191) * 0.70710677;
    v186 = (float)((float)(v161 + v179) + v191) * 0.70710677;
    v187 = (float)((float)(v179 - v161) - v191) * 0.70710677;
    v188 = (float)((float)(v180 + v161) - v191) * 0.70710677;
    *out = v182 + v170;
    out[1] = v194 + v172;
    out[2] = v174 + v186;
    out[3] = v177 + v185;
    out[4] = v198 - v184;
    out[5] = v200 + v181;
    out[10] = v174 - v186;
    out[11] = v177 - v185;
    out[12] = v184 + v198;
    out[6] = v175 - v188;
    out[8] = v170 - v182;
    out[14] = v188 + v175;
    out[9] = v172 - v194;
    out[15] = v176 - v187;
    out[7] = v176 + v187;
    out[13] = v200 - v181;
  }
  else if ( N == 16 )
  {
    v33 = out[1];
    v34 = out[3];
    v35 = out[8];
    v36 = v33 - v34;
    v37 = v33 + v34;
    v38 = out[11];
    v39 = out[12];
    v40 = out[13];
    v204 = out[10] + v35;
    v41 = out[9];
    v42 = v41 - v38;
    v43 = out[16];
    v44 = v41 + v38;
    v45 = out[17];
    v46 = out[25];
    v192 = v42;
    v208 = out[14] + v39;
    v47 = out[24];
    v216 = v39 - out[14];
    v48 = out[18] + v43;
    v196 = out[15] + v40;
    v49 = out[2] + *out;
    v50 = v43 - out[18];
    v51 = out[4];
    v52 = out[5];
    v53 = v48;
    v54 = out[19] + v45;
    v189 = v40 - out[15];
    v206 = v44;
    v214 = v35 - out[10];
    v55 = out[26] + v47;
    v56 = v47 - out[26];
    v57 = v45 - out[19];
    v58 = out[27] + v46;
    v202 = v46 - out[27];
    v59 = out[6] + v51;
    v60 = v51 - out[6];
    v61 = v59;
    v62 = out[7] + v52;
    v63 = v52 - out[7];
    v64 = v62;
    v65 = v49 - v61;
    v66 = v61 + v49;
    v210 = v65;
    v67 = v37 - v64;
    v68 = v64 + v37;
    v69 = *out - out[2];
    v70 = v69 - v63;
    v71 = v69 + v63;
    v72 = out[21] + out[23];
    v212 = v67;
    v218 = v71;
    v73 = v36;
    v74 = v36 + v60;
    v75 = v73 - v60;
    v76 = out[20] - out[22];
    v77 = v74;
    v220 = v75;
    v78 = v70;
    v79 = out[20] + out[22];
    v80 = out[21] - out[23];
    v81 = v53 - v79;
    v82 = v79 + v53;
    v229 = v81;
    v83 = v54;
    v84 = v54 + v72;
    v85 = v83 - v72;
    v199 = v50 + v80;
    v86 = v50 - v80;
    v222 = v84;
    v87 = v57 - v76;
    v88 = v57 + v76;
    v230 = v85;
    v89 = out[29] + out[31];
    v231 = v87;
    v227 = v88;
    v90 = out[28] + out[30];
    v91 = out[28] - out[30];
    v92 = v202;
    v93 = out[29] - out[31];
    v94 = v55;
    v95 = v55 + v90;
    v96 = v94 - v90;
    v97 = v58;
    v98 = v58 + v89;
    v99 = v97 - v89;
    v201 = v56 + v93;
    v203 = v202 - v91;
    v100 = v92 + v91;
    v232 = v56 - v93;
    v101 = v196 + v206;
    v102 = v204 - v208;
    v103 = v206 - v196;
    v104 = v66;
    v105 = v66 + (float)(v204 + v208);
    v197 = v104 - (float)(v204 + v208);
    v106 = v68;
    v107 = v68 + v101;
    v108 = v210 + v103;
    v205 = v106 - v101;
    v211 = v210 - v103;
    v207 = v108;
    v209 = v212 - v102;
    v213 = v102 + v212;
    v109 = (float)(v189 + (float)(v216 + (float)(v214 - v192))) * 0.70710677;
    v110 = v78;
    v111 = (float)((float)((float)(v214 - v192) - v216) - v189) * 0.70710677;
    v112 = v78 + v109;
    v113 = (float)((float)(v192 + v214) + v216) - v189;
    v114 = (float)((float)(v192 + v214) - v216) + v189;
    v190 = v110 - v109;
    v115 = v113 * 0.70710677;
    v116 = v114 * 0.70710677;
    v117 = v77 - v116;
    v118 = v116 + v77;
    v193 = v117;
    v119 = v218 - v115;
    v120 = v218 + v115;
    v121 = v82;
    v122 = v82 - v95;
    v217 = v119;
    v233 = v120;
    v123 = v111 + v220;
    v124 = v220;
    v221 = v121 + v95;
    v219 = v123;
    v125 = v222 - v98;
    v215 = v124 - v111;
    v223 = v222 + v98;
    v225 = v125;
    v224 = v122;
    v126 = (float)(v86 * 0.9238795) - (float)(v227 * 0.38268346);
    v127 = (float)(-0.38268346 * v232) + (float)(v100 * 0.9238795);
    v128 = (float)(v232 * 0.9238795) - (float)(v100 * -0.38268346);
    v129 = (float)((float)(0.38268346 * v86) + (float)(v227 * 0.9238795)) - v127;
    v130 = v126 + v128;
    v226 = (float)((float)(0.38268346 * v86) + (float)(v227 * 0.9238795)) + v127;
    v228 = v126 - v128;
    v131 = (float)((float)(v96 + (float)(v229 - v230)) + v99) * 0.70710677;
    v132 = (float)((float)((float)(v229 + v230) - v96) + v99) * 0.70710677;
    v133 = (float)((float)((float)(v229 - v230) - v96) - v99) * 0.70710677;
    v134 = (float)((float)(v96 + (float)(v229 + v230)) - v99) * 0.70710677;
    v135 = (float)(v201 * 0.38268343) - (float)(v203 * -0.9238795);
    v136 = (float)(-0.9238795 * v201) + (float)(0.38268343 * v203);
    v137 = (float)(v199 * 0.38268343) - (float)(v231 * 0.9238795);
    v138 = v137 - v135;
    v139 = v137 + v135;
    v140 = (float)(0.9238795 * v199) + (float)(v231 * 0.38268343);
    *out = v221 + v105;
    v141 = v140 - v136;
    v142 = v140 + v136;
    out[1] = v223 + v107;
    out[2] = v112 + v130;
    out[3] = v226 + v118;
    out[4] = v211 + v131;
    out[5] = v213 + v132;
    out[6] = v217 + v139;
    out[7] = v219 + v142;
    out[8] = v197 - v225;
    out[9] = v205 + v224;
    out[10] = v190 - v129;
    out[11] = v193 + v228;
    out[12] = v207 - v134;
    out[18] = v112 - v130;
    out[16] = v105 - v221;
    out[13] = v209 + v133;
    out[17] = v107 - v223;
    out[19] = v118 - v226;
    out[14] = v233 - v141;
    out[15] = v215 + v138;
    out[20] = v211 - v131;
    out[21] = v213 - v132;
    out[22] = v217 - v139;
    out[23] = v219 - v142;
    out[24] = v197 + v225;
    out[25] = v205 - v224;
    out[26] = v129 + v190;
    out[27] = v193 - v228;
    out[29] = v209 - v133;
    out[28] = v134 + v207;
    out[30] = v141 + v233;
    out[31] = v215 - v138;
  }
  else
  {
    v4 = N + 3;
    v5 = N / 2;
    if ( N >= 0 )
      v4 = N;
    v6 = v4 >> 2;
    v7 = &out[2 * v5];
    v195 = 2 * v5;
    v8 = &out[6 * v6];
    FMOD_FFT_DFT_conjugate_pair_dit_NoOpt(out, &root_table[2 * v6], v5);
    v9 = &root_table[2 * v6 + 2 * (N / 8)];
    FMOD_FFT_DFT_conjugate_pair_dit_NoOpt(v7, v9, v6);
    FMOD_FFT_DFT_conjugate_pair_dit_NoOpt(v8, v9, v6);
    if ( v6 > 0 )
    {
      v10 = &out[2 * v6 + 1];
      v11 = &out[v195 + 1];
      v12 = &out[6 * v6 + 1];
      v13 = 0;
      do
      {
        v10 += 2;
        v11 += 2;
        v14 = v7[2 * v13 + 1];
        v12 += 2;
        v15 = root_table[2 * v13];
        v16 = root_table[2 * v13 + 1];
        v17 = v14 * v15;
        v18 = v14 * v16;
        v19 = -v16;
        v20 = (float)(v16 * v7[2 * v13]) + v17;
        v21 = v8[2 * v13];
        v22 = (float)(v7[2 * v13] * v15) - v18;
        v23 = out[2 * v13 + 1];
        v24 = (float)(v15 * v21) - (float)(v8[2 * v13 + 1] * v19);
        v25 = (float)(v19 * v21) + (float)(v15 * v8[2 * v13 + 1]);
        v26 = v22 + v24;
        v27 = v22 - v24;
        v28 = *(v10 - 3);
        v29 = v20 + v25;
        v30 = v20 - v25;
        v31 = *(v10 - 2);
        v32 = out[2 * v13] - v26;
        out[2 * v13] = out[2 * v13] + v26;
        out[2 * v13++ + 1] = v23 + v29;
        *(v10 - 3) = v28 - v30;
        *(v10 - 2) = v31 + v27;
        *(v11 - 3) = v32;
        *(v11 - 2) = v23 - v29;
        *(v12 - 3) = v30 + v28;
        *(v12 - 2) = v31 - v27;
      }
      while ( v6 > (int)v13 );
    }
  }
}


// Address: 0x2261050 | Name: FMOD_FFT_Real_IDFT_Preprocess_NoOpt
void __fastcall FMOD_FFT_Real_IDFT_Preprocess_NoOpt(float *in, float *out, float *table, int N)
{
  int v4; // ecx
  float *v5; // r8
  __int64 v6; // rax
  float v7; // xmm3_4
  float v8; // xmm0_4
  float v9; // xmm8_4
  float v10; // xmm3_4
  float v11; // xmm5_4
  float v12; // xmm2_4
  float v13; // xmm5_4
  float v14; // xmm11_4
  float v15; // xmm3_4
  float v16; // xmm1_4
  float v17; // xmm11_4
  float v18; // xmm5_4

  v4 = N / 2;
  if ( v4 > 0 )
  {
    v5 = &in[2 * v4 + 1];
    v6 = 0;
    do
    {
      v7 = table[2 * v6];
      v5 -= 2;
      v8 = 1.0 - v7;
      v9 = in[2 * v6 + 1];
      v10 = v7 + 1.0;
      v11 = table[2 * v6 + 1];
      v12 = v11 * in[2 * v6];
      v13 = -v11;
      v14 = v5[1] * v10;
      v15 = v10 * v5[2];
      v16 = (float)((float)(in[2 * v6] * v8) - (float)(table[2 * v6 + 1] * v9)) + v14;
      v17 = v5[2] * v13;
      v18 = v13 * v5[1];
      out[2 * v6] = v16 + v17;
      out[2 * v6++ + 1] = (float)((float)((float)(v8 * v9) + v12) + v18) - v15;
    }
    while ( v4 > (int)v6 );
  }
}


