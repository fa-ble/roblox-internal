// Address: 0x21ee730 | Name: _ZN4FMOD7SystemI24getSoundTypeFromFilenameEPKcP15FMOD_SOUND_TYPE
FMOD_RESULT_0 __fastcall FMOD::SystemI::getSoundTypeFromFilename(
        FMOD::SystemI *const this,
        const char *filename,
        FMOD_SOUND_TYPE_0 *soundtype)
{
  char *v4; // rax
  FMOD_RESULT_0 v5; // edx
  const char *v6; // r12
  const FMOD::SystemI::getSoundTypeFromFilename::soundpair_t *v7; // rbp
  int v8; // ebx

  v4 = FMOD_strrchr(filename, 46);
  v5 = FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0;
  if ( v4 )
  {
    v6 = v4 + 1;
    v7 = stru_29B1480;
    while ( 1 )
    {
      v8 = 0;
      if ( v7->numextensions > 0 )
        break;
LABEL_10:
      if ( ++v7 == (const FMOD::SystemI::getSoundTypeFromFilename::soundpair_t *)&unk_29B17B0 )
        return FMOD_RESULT::FMOD_OK_0;
    }
    while ( FMOD_stricmp(v6, v7->extension[v8]) )
    {
      if ( v7->numextensions <= ++v8 )
        goto LABEL_10;
    }
    *soundtype = v7->type;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return v5;
}


// Address: 0x21ee7b0 | Name: _ZN4FMOD7SystemI11createCodecEijjPNS_4FileEP22FMOD_CREATESOUNDEXINFOPPNS_5CodecEPiS8_
FMOD_RESULT_0 __fastcall FMOD::SystemI::createCodec(
        FMOD::SystemI *const this,
        int index,
        FMOD_MODE mode_in,
        FMOD_MODE originalmode,
        FMOD::File *file,
        FMOD_CREATESOUNDEXINFO *exinfo,
        FMOD::Codec_0 **codec_out,
        int *maxchannels_out,
        int *maxfrequency_out)
{
  FMOD::PluginFactory *mPluginFactory; // rdi
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 v16; // edx
  FMOD::Codec *v17; // rax
  unsigned int mLength; // edx
  FMOD::Codec *v19; // rax
  FMOD_RESULT_0 v20; // eax
  FMOD::Codec *v21; // r8
  FMOD_RESULT_0 v22; // r14d
  __int64 v23; // rcx
  FMOD_MODE mMode; // r13d
  FMOD_CODEC_WAVEFORMAT *p_waveformat; // rdi
  FMOD::Codec *v26; // r8
  int channels; // ebx
  int frequency; // ebp
  FMOD::Codec *mDecoder; // r13
  FMOD_CODEC_WAVEFORMAT *v30; // rax
  FMOD::Codec *v31; // rax
  FMOD_CODEC_WAVEFORMAT *mWaveFormatMemory; // rdx
  int i; // r13d
  __int64 v34; // rcx
  void **p_memtype; // rdi
  void (__fastcall *v36)(FMOD::SystemI *const, __int64, void *, _QWORD, _QWORD); // rax
  int v37; // edx
  int v38; // esi
  FMOD_SOUND_FORMAT_0 v39; // ecx
  FMOD_CODEC_WAVEFORMAT *v40; // rax
  unsigned int v41; // edi
  FMOD_SOUND_FORMAT_0 format; // ecx
  int numchannels; // edx
  int defaultfrequency; // eax
  unsigned int length; // edi
  FMOD::FMOD_DSP_CODECPOOL_TYPE mPoolType; // esi
  FMOD::Codec *v47; // r13
  FMOD_CODEC_WAVEFORMAT *v48; // rdi
  FMOD_CODEC_WAVEFORMAT *v49; // rsi
  unsigned int v50; // eax
  __int64 v51; // rdx
  __int64 j; // rcx
  unsigned int (__fastcall *getcontextinfo)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  __int64 pcmblocksize; // r12
  FMOD_CODEC_WAVEFORMAT *v55; // rax
  FMOD_SOUND_FORMAT_0 v56; // edi
  int v57; // eax
  unsigned __int8 *v58; // rax
  void *v59; // rax
  unsigned int handle; // [rsp+8h] [rbp-D0h] BYREF
  unsigned int contextsize; // [rsp+Ch] [rbp-CCh] BYREF
  FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *codecdesc; // [rsp+10h] [rbp-C8h] BYREF
  FMOD::Codec *codec; // [rsp+18h] [rbp-C0h] BYREF
  FMOD_CODEC_WAVEFORMAT waveformat; // [rsp+20h] [rbp-B8h] BYREF
  void *memtype; // [rsp+60h] [rbp-78h] BYREF
  int v66; // [rsp+6Ch] [rbp-6Ch]
  int v67; // [rsp+70h] [rbp-68h]

  codec = 0;
  *codec_out = 0;
  mPluginFactory = this->mPluginFactory;
  *maxchannels_out = 0;
  *maxfrequency_out = 0;
  if ( FMOD::PluginFactory::getCodecHandle(mPluginFactory, index, &handle)
    || FMOD::PluginFactory::getCodec(this->mPluginFactory, handle, &codecdesc) )
  {
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
  if ( (mode_in & 0x1000) != 0 )
  {
    if ( codecdesc->mDescription.mType != FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_RAW_0 )
      return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
  else if ( (mode_in & 0x400) != 0 )
  {
    if ( codecdesc->mDescription.mType != FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_USER_0 )
      return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
  else if ( (codecdesc->mDescription.mType & 0xFFFFFFFD) == 0xC )
  {
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
  v16 = FMOD::PluginFactory::createCodec(this->mPluginFactory, &codecdesc->mDescription, &codec);
  if ( v16 )
  {
    result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    if ( v16 != FMOD_RESULT::FMOD_ERR_MEMORY_0 )
      return FMOD_RESULT::FMOD_ERR_FORMAT_0;
    return result;
  }
  v17 = codec;
  mLength = file->mLength;
  codec->mFlags |= 1u;
  v17->filesize = mLength;
  v17->mFile = file;
  v17->mMode = mode_in;
  v17->mOriginalMode = originalmode;
  v17->filehandle = file;
  v17->mSystem = this;
  result = FMOD::File::seek(file, 0, 0);
  if ( result )
    return result;
  v19 = codec;
  codec->mRoblox_ParsingAnomaly = 0;
  v20 = v19->mDescription.open(v19, mode_in, exinfo);
  v21 = codec;
  v22 = v20;
  if ( codec->mRoblox_ParsingAnomaly )
  {
    codec->mRoblox_ParsingAnomaly = 0;
    memtype = 0;
    FMOD::SystemI::getUserData(this, &memtype);
    v36 = *(void (__fastcall **)(FMOD::SystemI *const, __int64, void *, _QWORD, _QWORD))((char *)&stru_11748.r_offset
                                                                                       + (_QWORD)this);
    if ( v36 && (this->mCallbackMask & 0x10000000) != 0 )
      v36(this, 0x10000000, memtype, 0, *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)this));
    v21 = codec;
  }
  if ( v22 )
  {
    v21->mFile = 0;
    v21->mMetadata = 0;
    FMOD::Codec::release(v21, 1);
    result = v22;
    if ( v22 != FMOD_RESULT::FMOD_ERR_FILE_EOF_0 )
      return result;
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
  result = FMOD_RESULT::FMOD_ERR_PLUGIN_VERSION_0;
  if ( v21->waveformatversion == 3 )
  {
    v23 = 14;
    mMode = v21->mMode;
    p_waveformat = &waveformat;
    while ( v23 )
    {
      LODWORD(p_waveformat->name) = 0;
      p_waveformat = (FMOD_CODEC_WAVEFORMAT *)((char *)p_waveformat + 4);
      --v23;
    }
    result = v21->mDescription.getwaveformat(v21, 0, &waveformat);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v26 = codec;
      if ( codec->mType == FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_PLAYLIST_0
        || (LOBYTE(result) = 53, waveformat.format)
        && waveformat.channels
        && (waveformat.lengthpcm || (mMode & 0x400) != 0)
        && (result = FMOD_RESULT::FMOD_ERR_PLUGIN_0, waveformat.frequency) )
      {
        if ( (mMode & 0x400) != 0 )
        {
          format = exinfo->format;
          numchannels = exinfo->numchannels;
          defaultfrequency = exinfo->defaultfrequency;
          length = exinfo->length;
          waveformat.pcmblocksize = 0;
          waveformat.format = format;
          waveformat.channels = numchannels;
          waveformat.frequency = defaultfrequency;
          result = FMOD::SoundI::getSamplesFromBytes(length, &waveformat.lengthpcm, numchannels, format);
          if ( result )
            return result;
        }
        else
        {
          if ( (mMode & 0x1000) == 0 )
            goto LABEL_32;
          (*((void (__fastcall **)(FMOD::File *, void **))file->_vptr_File + 3))(file, &memtype);
          v37 = exinfo->numchannels;
          v38 = exinfo->defaultfrequency;
          v39 = exinfo->format;
          v40 = codec->waveformat;
          v40->channels = v37;
          v40->frequency = v38;
          v41 = (unsigned int)memtype;
          v40->format = v39;
          waveformat.frequency = v38;
          waveformat.format = v39;
          waveformat.channels = v37;
          result = FMOD::SoundI::getSamplesFromBytes(v41, &waveformat.lengthpcm, v37, v39);
          if ( result )
            return result;
        }
        v26 = codec;
LABEL_32:
        channels = waveformat.channels;
        frequency = waveformat.frequency;
        if ( (mMode & 0x200) != 0 )
        {
          mPoolType = v26->mDescription.mPoolType;
          if ( mPoolType == FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_MPEG )
          {
            FMOD::CodecMPEG::getDescriptionEx();
          }
          else
          {
            result = FMOD::SystemI::DSPCodecPoolRegister(this, mPoolType, 0, 0, 2);
            if ( result )
              return result;
          }
LABEL_62:
          *codec_out = codec;
          *maxchannels_out = channels;
          *maxfrequency_out = frequency;
          return FMOD_RESULT::FMOD_OK_0;
        }
        if ( v26->numsubsounds )
        {
          if ( v26->mDescription.mPoolType == FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_MPEG )
          {
            FMOD::CodecMPEG::getDescriptionEx();
            v26 = codec;
          }
          else
          {
            result = FMOD::PluginFactory::createCodec(this->mPluginFactory, 0, &v26->mDecoder);
            if ( result )
              return result;
            mDecoder = codec->mDecoder;
            v30 = (FMOD_CODEC_WAVEFORMAT *)FMOD::MemPool::calloc(
                                             off_286F358->gSystemMemPool,
                                             56,
                                             "../../../core_api/src/fmod_systemi_sound.cpp",
                                             394,
                                             0);
            v26 = codec;
            mDecoder->mWaveFormatMemory = v30;
            v31 = v26->mDecoder;
            mWaveFormatMemory = v31->mWaveFormatMemory;
            if ( !mWaveFormatMemory )
              return FMOD_RESULT::FMOD_ERR_MEMORY_0;
            v31->waveformat = mWaveFormatMemory;
            v31->mSystem = this;
          }
        }
        if ( v26->numsubsounds )
        {
          for ( i = 0; i < v26->numsubsounds; ++i )
          {
            v34 = 14;
            p_memtype = &memtype;
            while ( v34 )
            {
              *(_DWORD *)p_memtype = 0;
              p_memtype = (void **)((char *)p_memtype + 4);
              --v34;
            }
            result = v26->mDescription.getwaveformat(v26, i, (FMOD_CODEC_WAVEFORMAT *)&memtype);
            if ( result )
              return result;
            v26 = codec;
            if ( channels < v66 )
              channels = v66;
            if ( frequency < v67 )
              frequency = v67;
          }
        }
        v47 = v26->mDecoder;
        if ( !v47 )
          v47 = v26;
        v47->mFile = v26->mFile;
        v48 = v47->waveformat;
        v47->filehandle = v26->mFile;
        v47->mType = v26->mType;
        v47->mFlags = v26->mFlags;
        v47->mSrcDataOffset = v26->mSrcDataOffset;
        if ( v48 )
        {
          v49 = &waveformat;
          v50 = 56;
          if ( ((unsigned __int8)v48 & 1) != 0 )
          {
            LOBYTE(v48->name) = waveformat.name;
            v49 = (FMOD_CODEC_WAVEFORMAT *)((char *)&waveformat.name + 1);
            v48 = (FMOD_CODEC_WAVEFORMAT *)((char *)v48 + 1);
            LOBYTE(v50) = 55;
          }
          if ( ((unsigned __int8)v48 & 2) != 0 )
          {
            v50 -= 2;
            LOWORD(v48->name) = v49->name;
            v49 = (FMOD_CODEC_WAVEFORMAT *)((char *)v49 + 2);
            v48 = (FMOD_CODEC_WAVEFORMAT *)((char *)v48 + 2);
          }
          v51 = 0;
          for ( j = v50 >> 2; j; --j )
          {
            LODWORD(v48->name) = v49->name;
            v49 = (FMOD_CODEC_WAVEFORMAT *)((char *)v49 + 4);
            v48 = (FMOD_CODEC_WAVEFORMAT *)((char *)v48 + 4);
          }
          if ( (v50 & 2) != 0 )
          {
            LOWORD(v48->name) = v49->name;
            v51 = 2;
          }
          if ( (v50 & 1) != 0 )
            *((_BYTE *)&v48->name + v51) = *((_BYTE *)&v49->name + v51);
        }
        getcontextinfo = (unsigned int (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v47->mDescription.getcontextinfo;
        if ( getcontextinfo && v47->mDescription.setupcontext )
        {
          contextsize = 0;
          LODWORD(memtype) = 0;
          result = getcontextinfo(v47, (unsigned int)channels, &contextsize, 0, &memtype, 0);
          if ( result )
            return result;
          if ( contextsize )
          {
            v59 = FMOD::MemPool::calloc(
                    off_286F358->gSystemMemPool,
                    contextsize + 16,
                    "../../../core_api/src/fmod_systemi_sound.cpp",
                    458,
                    (FMOD_MEMORY_TYPE)memtype);
            v47->mDecoderContextMemory = v59;
            if ( !v59 )
              return FMOD_RESULT::FMOD_ERR_MEMORY_0;
            v47->mDecoderContext = (void *)(((unsigned __int64)v59 + 15) & 0xFFFFFFFFFFFFFFF0LL);
          }
        }
        pcmblocksize = waveformat.pcmblocksize;
        if ( waveformat.pcmblocksize <= 1 || v47->mPCMBufferMemory )
          goto LABEL_62;
        v55 = v47->waveformat;
        v47->mPCMBufferLength = waveformat.pcmblocksize;
        v56 = v55->format;
        LODWORD(memtype) = 0;
        FMOD::SoundI::getBitsFromFormat(v56, (int *)&memtype);
        if ( (_DWORD)memtype )
          v47->mPCMBufferLengthBytes = (unsigned __int64)(pcmblocksize * (int)memtype) >> 3;
        else
          v47->mPCMBufferLengthBytes = pcmblocksize;
        v57 = channels * v47->mPCMBufferLengthBytes;
        v47->mPCMBufferLengthBytes = v57;
        v58 = (unsigned __int8 *)FMOD::MemPool::calloc(
                                   off_286F358->gSystemMemPool,
                                   v57 + 16,
                                   "../../../core_api/src/fmod_systemi_sound.cpp",
                                   474,
                                   0);
        v47->mPCMBufferMemory = v58;
        if ( v58 )
        {
          v47->mPCMBuffer = (unsigned __int8 *)((unsigned __int64)(v58 + 15) & 0xFFFFFFFFFFFFFFF0LL);
          goto LABEL_62;
        }
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
    }
  }
  return result;
}


// Address: 0x21eee50 | Name: _ZN4FMOD7SystemI16createMemoryFileEPPNS_4FileE
FMOD_RESULT_0 __fastcall FMOD::SystemI::createMemoryFile(FMOD::SystemI *const this, FMOD::File **newfile)
{
  FMOD::MemoryFile *v2; // rbx
  FMOD_RESULT_0 result; // eax

  v2 = (FMOD::MemoryFile *)FMOD::MemPool::alloc(
                             off_286F358->gSystemMemPool,
                             512,
                             "../../../core_api/src/fmod_systemi_sound.cpp",
                             501,
                             0,
                             0);
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v2 )
  {
    FMOD::File::File(v2);
    v2->mDeviceType = 1;
    v2->_vptr_File = (int (**)(...))off_29B1850;
    FMOD::MemoryFile::init(v2, this, 0, 0, 0);
    *newfile = v2;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21eeed0 | Name: _ZN4FMOD7SystemI14createDiskFileEPKcP22FMOD_CREATESOUNDEXINFOPPNS_4FileEPb
FMOD_RESULT_0 __fastcall FMOD::SystemI::createDiskFile(
        FMOD::SystemI *const this,
        const char *name_or_data,
        FMOD_CREATESOUNDEXINFO *exinfo,
        FMOD::File **newfile,
        bool *wasnetfile)
{
  int mBufferSize; // r12d
  FMOD::NetFile *v10; // rax
  FMOD::NetFile *v11; // rbp
  FMOD::File *v13; // rax
  FMOD::File *v14; // rax
  unsigned int v15; // ecx
  FMOD::File *v16; // rax
  FMOD_FILE_CLOSE_CALLBACK fileuserclose; // rax
  FMOD_FILE_ASYNCCANCEL_CALLBACK fileuserasynccancel; // rsi
  FMOD_FILE_ASYNCREAD_CALLBACK fileuserasyncread; // r8
  FMOD_FILE_SEEK_CALLBACK fileuserseek; // rdx
  FMOD_FILE_READ_CALLBACK fileuserread; // rdi
  FMOD_FILE_OPEN_CALLBACK fileuseropen; // rcx
  char *fileuserdata; // rax
  FMOD::File *v24; // rax

  if ( !exinfo )
  {
    mBufferSize = this->mBufferSize;
    if ( FMOD_strnicmp("fmod:///remote/", name_or_data, 15) )
    {
      if ( !this->mUsesUserCallbacks )
        goto LABEL_13;
LABEL_20:
      v13 = (FMOD::File *)FMOD::MemPool::alloc(
                            off_286F358->gSystemMemPool,
                            568,
                            "../../../core_api/src/fmod_systemi_sound.cpp",
                            554,
                            0,
                            0);
      v11 = (FMOD::NetFile *)v13;
      if ( v13 )
      {
        FMOD::File::File(v13);
        *(_QWORD *)&v11->mMetadata.mList.mType = 0;
        v11->mMetadata.mList.mName = 0;
        *(_QWORD *)&v11->mAbsolutePos = 0;
        *(_QWORD *)&v11->mMetaint = 0;
        v11->mMetabuf = 0;
        v11->mMetadata.mList.mNodeNext = 0;
        v11->_vptr_File = (int (**)(...))off_29B18D0;
        v11->mMetadata.mList.mNodePrev = 0;
        v11->mMetadata.mList.mNodeData = 0;
        v11->mDeviceType = 0;
        if ( exinfo )
          v11->mMetadata.mList.mName = (char *)exinfo->fileuserdata;
        goto LABEL_23;
      }
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
    goto LABEL_25;
  }
  mBufferSize = exinfo->filebuffersize;
  if ( mBufferSize )
  {
    if ( mBufferSize == -1 )
      mBufferSize = 0;
  }
  else
  {
    mBufferSize = this->mBufferSize;
  }
  if ( !FMOD_strnicmp("fmod:///remote/", name_or_data, 15) )
  {
LABEL_25:
    v14 = (FMOD::File *)FMOD::MemPool::alloc(
                          off_286F358->gSystemMemPool,
                          512,
                          "../../../core_api/src/fmod_systemi_sound.cpp",
                          528,
                          0,
                          0);
    v11 = (FMOD::NetFile *)v14;
    if ( v14 )
    {
      FMOD::File::File(v14);
      v15 = this->mBufferSize;
      v11->_vptr_File = (int (**)(...))off_29B1C70;
      FMOD::File::init(v11, this, 0, v15);
      goto LABEL_17;
    }
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
  if ( !exinfo->fileuseropen
    || !exinfo->fileuserclose
    || (!exinfo->fileuserread || !exinfo->fileuserseek) && (!exinfo->fileuserasyncread || !exinfo->fileuserasynccancel)
    || exinfo->ignoresetfilesystem )
  {
    if ( !this->mUsesUserCallbacks || exinfo->ignoresetfilesystem )
    {
LABEL_13:
      if ( FMOD_strnicmp("http://", name_or_data, 7)
        && FMOD_strnicmp("http:\\\\", name_or_data, 7)
        && FMOD_strnicmp("https://", name_or_data, 8)
        && FMOD_strnicmp("https:\\\\", name_or_data, 8)
        && FMOD_strnicmp("mms://", name_or_data, 6)
        && FMOD_strnicmp("mms:\\\\", name_or_data, 6) )
      {
        v24 = (FMOD::File *)FMOD::MemPool::alloc(
                              off_286F358->gSystemMemPool,
                              504,
                              "../../../core_api/src/fmod_systemi_sound.cpp",
                              597,
                              0,
                              0);
        v11 = (FMOD::NetFile *)v24;
        if ( v24 )
        {
          FMOD::File::File(v24);
          v11->mDeviceType = 4;
          v11->mHandle = 0;
          v11->_vptr_File = (int (**)(...))off_29B1950;
          goto LABEL_23;
        }
      }
      else
      {
        v10 = (FMOD::NetFile *)FMOD::MemPool::alloc(
                                 off_286F358->gSystemMemPool,
                                 5768,
                                 "../../../core_api/src/fmod_systemi_sound.cpp",
                                 574,
                                 0,
                                 0);
        v11 = v10;
        if ( v10 )
        {
          FMOD::NetFile::NetFile(v10);
          FMOD::File::init(v11, this, 0, mBufferSize);
          if ( wasnetfile )
            *wasnetfile = 1;
          goto LABEL_17;
        }
      }
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
    goto LABEL_20;
  }
  v16 = (FMOD::File *)FMOD::MemPool::alloc(
                        off_286F358->gSystemMemPool,
                        568,
                        "../../../core_api/src/fmod_systemi_sound.cpp",
                        539,
                        0,
                        0);
  v11 = (FMOD::NetFile *)v16;
  if ( !v16 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  FMOD::File::File(v16);
  *(_QWORD *)&v11->mMetadata.mList.mType = 0;
  v11->mMetadata.mList.mName = 0;
  *(_QWORD *)&v11->mAbsolutePos = 0;
  *(_QWORD *)&v11->mMetaint = 0;
  v11->mMetabuf = 0;
  v11->mMetadata.mList.mNodeNext = 0;
  v11->mMetadata.mList.mNodePrev = 0;
  v11->_vptr_File = (int (**)(...))off_29B18D0;
  fileuserclose = exinfo->fileuserclose;
  v11->mMetadata.mList.mNodeData = 0;
  v11->mDeviceType = 0;
  fileuserasynccancel = exinfo->fileuserasynccancel;
  fileuserasyncread = exinfo->fileuserasyncread;
  fileuserseek = exinfo->fileuserseek;
  fileuserread = exinfo->fileuserread;
  fileuseropen = exinfo->fileuseropen;
  if ( fileuserclose && fileuseropen && (fileuserseek && fileuserread || fileuserasynccancel && fileuserasyncread) )
  {
    *(_QWORD *)&v11->mMetaint = fileuserclose;
    fileuserdata = (char *)exinfo->fileuserdata;
    *(_QWORD *)&v11->mAbsolutePos = fileuseropen;
    v11->mMetabuf = (char *)fileuserread;
    v11->mMetadata.mList.mNodeNext = (FMOD::LinkedListNode *)fileuserseek;
    v11->mMetadata.mList.mNodePrev = (FMOD::LinkedListNode *)fileuserasyncread;
    v11->mMetadata.mList.mNodeData = fileuserasynccancel;
    v11->mMetadata.mList.mName = fileuserdata;
LABEL_23:
    FMOD::File::init(v11, this, 0, mBufferSize);
LABEL_17:
    *newfile = v11;
    return FMOD_RESULT::FMOD_OK_0;
  }
  FMOD::MemPool::free(off_286F358->gSystemMemPool, v11, "../../../core_api/src/fmod_autocleanup.h", 190);
  return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
}


// Address: 0x21ef430 | Name: _ZN4FMOD7SystemI12createSampleEjP21FMOD_CODEC_WAVEFORMATPPNS_6SampleE
FMOD_RESULT_0 __fastcall FMOD::SystemI::createSample(
        FMOD::SystemI *const this,
        FMOD_MODE mode,
        FMOD_CODEC_WAVEFORMAT *waveformat,
        FMOD::Sample **sample_out)
{
  FMOD_RESULT_0 result; // eax
  FMOD_MODE v7; // edx
  int v9; // eax
  FMOD_MODE v10; // esi
  int v11; // eax
  unsigned int v12; // eax
  FMOD_MODE v13; // r13d
  int channels; // r15d
  FMOD::OutputSoftware *mSoftware; // rdi
  __int64 v16; // rax
  FMOD_RESULT_0 v17; // ebp
  FMOD::Sample *v18; // rbp
  float frequency; // xmm0_4
  __int64 loopend; // rcx
  FMOD_SOUND_FORMAT_0 format; // edx
  __int64 loopstart; // rsi
  FMOD_CHANNELORDER_0 channelorder; // eax
  float mDistanceScale; // xmm0_4
  unsigned int mLength; // eax
  float v26; // xmm0_4
  unsigned int v27; // eax
  int (**vptr_SoundI)(...); // rax
  FMOD::Sample *subsample; // [rsp+8h] [rbp-80h] BYREF
  FMOD_CODEC_WAVEFORMAT subsamplewaveformat; // [rsp+10h] [rbp-78h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( sample_out )
  {
    LOBYTE(result) = 38;
    if ( waveformat->lengthpcm != -1 )
    {
      v7 = waveformat->mode;
      v9 = v7 & 0x18;
      v10 = v9 | mode;
      v11 = v10 | v9;
      if ( (v10 & 0x18) == 0 )
        v10 = v11;
      v12 = v10 & 0xFFFFFFF7;
      if ( (v10 & 0x10) == 0 )
        v12 = v10 | 8;
      if ( (v12 & 7) == 0 )
        v12 |= v7 & 7;
      if ( (v12 & 2) != 0 )
      {
        v13 = v12 & 0xFFFFFFF8 | 2;
      }
      else
      {
        v13 = v12 | 1;
        if ( (v12 & 4) != 0 )
          v13 = v12 & 0xFFFFFFFA | 4;
      }
      if ( (v7 & 0x200) != 0 )
        v13 = v13 & 0xFFFFFCFF | 0x200;
      channels = waveformat->channels;
      mSoftware = this->mSoftware;
      subsample = *sample_out;
      subsamplewaveformat.name = waveformat->name;
      *(_QWORD *)&subsamplewaveformat.format = *(_QWORD *)&waveformat->format;
      v16 = *(_QWORD *)&waveformat->frequency;
      subsamplewaveformat.channels = channels;
      *(_QWORD *)&subsamplewaveformat.frequency = v16;
      *(_QWORD *)&subsamplewaveformat.lengthpcm = *(_QWORD *)&waveformat->lengthpcm;
      *(_QWORD *)&subsamplewaveformat.loopstart = *(_QWORD *)&waveformat->loopstart;
      *(_QWORD *)&subsamplewaveformat.mode = *(_QWORD *)&waveformat->mode;
      *(_QWORD *)&subsamplewaveformat.channelorder = *(_QWORD *)&waveformat->channelorder;
      v17 = FMOD::OutputSoftware::createSample(mSoftware, v13, &subsamplewaveformat, &subsample);
      if ( v17 )
      {
        if ( subsample )
        {
          if ( subsample != *sample_out )
            (*((void (__fastcall **)(FMOD::Sample *, __int64))subsample->_vptr_SoundI + 3))(subsample, 1);
        }
        return v17;
      }
      else
      {
        v18 = subsample;
        frequency = (float)waveformat->frequency;
        loopend = (unsigned int)waveformat->loopend;
        format = waveformat->format;
        loopstart = (unsigned int)waveformat->loopstart;
        subsample->mName = waveformat->name;
        channelorder = waveformat->channelorder;
        v18->mDefaultFrequency = frequency;
        v18->mPeakVolume = waveformat->peakvolume;
        v18->mMode = v13;
        mDistanceScale = this->mDistanceScale;
        v18->mDefaultChannelOrder = channelorder;
        mLength = v18->mLength;
        v18->mMinDistance = mDistanceScale;
        v26 = mDistanceScale * 10000.0;
        v18->mFormat = format;
        v18->mChannels = channels;
        v18->mLoopLength = mLength;
        v27 = mLength - 1;
        if ( !(_DWORD)loopend )
          loopend = v27;
        vptr_SoundI = v18->_vptr_SoundI;
        v18->mSystem = this;
        v18->mLoopStart = 0;
        v18->mCodec = 0;
        v18->mType = FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_USER_0;
        v18->mMaxDistance = v26;
        vptr_SoundI[39](v18, loopstart, 2, loopend, 2);
        *sample_out = v18;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21ef620 | Name: _ZN4FMOD7SystemI19createSoundInternalEPKcjjjP22FMOD_CREATESOUNDEXINFObPPNS_6SoundIE
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::SystemI::createSoundInternal(
        FMOD::SystemI *const this,
        const char *name_or_data,
        FMOD_MODE mode_in,
        unsigned int buffersize,
        FMOD_TIMEUNIT buffersizetype,
        FMOD_CREATESOUNDEXINFO *exinfo,
        bool addtosoundlist,
        FMOD::SoundI **sound)
{
  FMOD::SystemI *v8; // r12
  FMOD_CREATESOUNDEXINFO *v10; // r13
  FMOD_MODE v11; // ebx
  FMOD_RESULT_0 v12; // eax
  FMOD_RESULT_0 Buffer; // ebp
  FMOD::File *m_val; // r14
  FMOD::SoundI **v15; // r15
  FMOD::File *v17; // rax
  unsigned int mBufferSize; // ecx
  FMOD::File *v19; // rdi
  FMOD_RESULT_0 v20; // eax
  FMOD::File *v21; // rdi
  const char *encryptionkey; // r8
  unsigned int fileoffset; // ecx
  unsigned int length; // edx
  FMOD::File *v25; // r10
  FMOD_RESULT_0 v26; // eax
  FMOD::File *v27; // r10
  char v28; // cl
  FMOD::SystemI *v29; // r14
  int v30; // r13d
  char v31; // r12
  int v32; // eax
  int v33; // ebp
  FMOD_RESULT_0 v34; // eax
  FMOD::Codec *v35; // rcx
  FMOD::Metadata *mMetadata; // rdi
  FMOD::Codec *v37; // r14
  FMOD::Codec_0 *v38; // rcx
  FMOD::File *mFile; // rdi
  FMOD::SoundI *v40; // r14
  unsigned int v41; // ecx
  unsigned int pcmblocksize; // r9d
  unsigned int lengthpcm; // eax
  FMOD::Sample **p_sample_0; // rdi
  __int64 v45; // rcx
  FMOD_CODEC_WAVEFORMAT *p_waveformat; // rsi
  FMOD::Sample *v47; // rax
  FMOD_RESULT (*pcmreadcallback)(FMOD_SOUND *, void *, unsigned int); // r8
  FMOD_RESULT (*v49)(FMOD_SOUND *, int, unsigned int, FMOD_TIMEUNIT); // rdi
  float frequency; // xmm0_4
  void *v51; // rcx
  FMOD::Codec_0 *v52; // rsi
  unsigned int lengthbytes; // r11d
  FMOD_CHANNELORDER_0 v54; // r11d
  unsigned int v55; // edx
  FMOD_SOUND_FORMAT_0 format; // r11d
  float v57; // xmm0_4
  int v58; // r11d
  float v59; // xmm0_4
  FMOD_MODE mMode; // eax
  const char *name; // rdx
  unsigned int v62; // eax
  char v63; // dl
  FMOD_MODE v64; // r9d
  FMOD::ChannelStream *v65; // rax
  __int64 v66; // rcx
  __int64 v67; // r8
  __int64 v68; // r9
  FMOD_CODEC_SOUNDCREATE_CALLBACK_0 soundcreate; // rax
  FMOD_RESULT_0 updated; // eax
  FMOD::Codec *mDecoder; // r15
  __int64 (__fastcall *setupcontext)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  __int64 initialsubsound; // rcx
  FMOD_TIMEUNIT initialseekpostype; // eax
  unsigned int initialseekposition; // eax
  unsigned int mLength; // ecx
  int v77; // esi
  FMOD::SoundI **mSubSound; // rax
  FMOD::Stream *v79; // r15
  bool v80; // zf
  __int64 (*canpoint)(void); // rax
  FMOD_RESULT_0 v82; // eax
  FMOD::Metadata *v83; // rax
  int v84; // ebp
  FMOD::SoundI *v85; // r10
  float v86; // xmm0_4
  FMOD_RESULT (*v87)(FMOD_SOUND *, int, unsigned int, FMOD_TIMEUNIT); // rax
  void *v88; // rax
  FMOD::Sample *v89; // r10
  FMOD::SystemI *v90; // rbp
  FMOD_TIMEUNIT v91; // r12d
  FMOD::Sample *v92; // rbx
  FMOD_RESULT_1 v93; // eax
  bool v94; // al
  bool v95; // r15
  int *inclusionlist; // rax
  int inclusionlistnum; // edx
  _DWORD *v98; // rax
  _DWORD *v99; // rdx
  FMOD::Sample *v100; // rdi
  FMOD::Codec_0 *v101; // rax
  float v102; // xmm0_4
  FMOD_SOUND_TYPE_0 v103; // edx
  void *v104; // rax
  FMOD::Codec_0 *v105; // r15
  FMOD_CODEC_SOUNDCREATE_CALLBACK_0 v106; // rax
  FMOD_RESULT_0 v107; // eax
  FMOD::Codec *v108; // r10
  __int64 (__fastcall *v109)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  unsigned __int8 *mPCMBuffer; // rdi
  __int64 (__fastcall *reset)(FMOD::Codec_0 *); // rax
  int v112; // r15d
  FMOD_TIMEUNIT v113; // ecx
  FMOD_SOUND_PCMSETPOS_CALLBACK mPostSetPositionCallback; // rax
  bool v115; // r15
  unsigned int v116; // r14d
  FMOD_SOUND_TYPE_0 v117; // eax
  FMOD_RESULT_0 v118; // eax
  FMOD::Sample *v119; // rdi
  unsigned int v120; // edx
  FMOD::Sample *v121; // rax
  FMOD_RESULT (*v122)(FMOD_SOUND *, int, unsigned int, FMOD_TIMEUNIT); // rdx
  FMOD_RESULT_0 v123; // eax
  FMOD::SoundI *v124; // rbp
  float mDistanceScale; // xmm0_4
  FMOD_RESULT (*pcmsetposcallback)(FMOD_SOUND *, int, unsigned int, FMOD_TIMEUNIT); // rax
  float v127; // xmm0_4
  void *userdata; // rax
  FMOD::SoundI *v129; // r13
  const char *mName; // rax
  FMOD::Metadata *v131; // rdi
  int v132; // eax
  __int64 v133; // rdx
  __int64 v134; // rsi
  char v135; // cl
  int v136; // eax
  const char *v137; // rbx
  FMOD::File *v138; // rdi
  FMOD_TIMEUNIT v139; // eax
  FMOD::Stream *v140; // rax
  unsigned int v141; // esi
  FMOD::Codec_0 *v142; // rcx
  int v143; // eax
  signed int v144; // edx
  int mLengthBytes; // esi
  float v146; // xmm0_4
  unsigned int v147; // esi
  FMOD_SOUND_FORMAT_0 mFormat; // edi
  int mChannels; // ebp
  unsigned int v150; // r13d
  FMOD::SoundI *v151; // r10
  FMOD::Codec_0 *v152; // rcx
  FMOD::File *v153; // rdi
  FMOD::Codec *v154; // rax
  FMOD_SOUND_TYPE_0 v155; // eax
  FMOD::Sample *v156; // rax
  FMOD::Sample *v157; // r14
  FMOD::Stream *v158; // rax
  FMOD::SoundI *v159; // rbp
  FMOD::Sample *v160; // rax
  float v161; // xmm0_4
  FMOD::AsyncData *mAsyncData; // rax
  __int64 v163; // rbx
  FMOD::Codec_0 *v164; // r8
  FMOD_CODEC_WAVEFORMAT *p_tag; // rdi
  __int64 i; // rcx
  FMOD_RESULT_1 v167; // eax
  const char *v168; // rax
  __int64 loopstart; // rsi
  float peakvolume; // xmm0_4
  __int64 loopend; // rcx
  FMOD_CODEC_SOUNDCREATE_CALLBACK_0 v172; // rax
  FMOD_RESULT_1 v173; // edx
  float v174; // xmm0_4
  FMOD::Codec_0 *v175; // rcx
  unsigned int v176; // esi
  float v177; // xmm0_4
  FMOD_CHANNELORDER_0 v178; // esi
  FMOD_SOUND_FORMAT_0 v179; // esi
  float v180; // xmm0_4
  int v181; // esi
  FMOD::LinkedListNode *mNodeNext; // rdx
  FMOD_SOUND_TYPE_0 mType; // eax
  FMOD::Sample *v184; // rax
  FMOD::Sample *samplecontainerc; // [rsp+20h] [rbp-4318h]
  FMOD::Sample *samplecontainera; // [rsp+20h] [rbp-4318h]
  FMOD::Sample *samplecontainerb; // [rsp+20h] [rbp-4318h]
  FMOD::Sample *samplecontainerd; // [rsp+20h] [rbp-4318h]
  const char *name_or_datab; // [rsp+30h] [rbp-4308h]
  FMOD_RESULT_0 name_or_datac; // [rsp+30h] [rbp-4308h]
  FMOD_TIMEUNIT buffersizetypeb; // [rsp+3Ch] [rbp-42FCh]
  FMOD::File *startingcodec; // [rsp+40h] [rbp-42F8h]
  int startingcodeca; // [rsp+40h] [rbp-42F8h]
  int startingcodecb; // [rsp+40h] [rbp-42F8h]
  char *filebufferstack; // [rsp+48h] [rbp-42F0h]
  FMOD::File *result; // [rsp+50h] [rbp-42E8h]
  FMOD::File *resulta; // [rsp+50h] [rbp-42E8h]
  FMOD_RESULT_0 resultb; // [rsp+50h] [rbp-42E8h]
  FMOD::AutoRelease<FMOD::Sample> samplecontainer_cleanup; // [rsp+58h] [rbp-42E0h]
  int samplecontainer_cleanupa; // [rsp+58h] [rbp-42E0h]
  FMOD::AutoRelease<FMOD::Sample> samplecontainer_cleanupb; // [rsp+58h] [rbp-42E0h]
  FMOD_CREATESOUNDEXINFO *blocksize; // [rsp+60h] [rbp-42D8h]
  FMOD_MODE blocksizea; // [rsp+60h] [rbp-42D8h]
  __int64 blocksizeb; // [rsp+60h] [rbp-42D8h]
  FMOD::Metadata *stream_cleanup; // [rsp+68h] [rbp-42D0h]
  FMOD::AutoRelease<FMOD::Stream> stream_cleanupa; // [rsp+68h] [rbp-42D0h]
  bool stream_cleanupb; // [rsp+68h] [rbp-42D0h]
  FMOD::AutoFree subsound_cleanup; // [rsp+70h] [rbp-42C8h]
  FMOD_MODE subsound_cleanupa; // [rsp+70h] [rbp-42C8h]
  FMOD::AutoFree subsound_cleanupd; // [rsp+70h] [rbp-42C8h]
  FMOD::AutoFree subsound_cleanupb; // [rsp+70h] [rbp-42C8h]
  FMOD_MODE subsound_cleanupc; // [rsp+70h] [rbp-42C8h]
  FMOD_MODE v216; // [rsp+78h] [rbp-42C0h]
  bool realtimesample; // [rsp+87h] [rbp-42B1h]
  FMOD::SoundI **subsound; // [rsp+98h] [rbp-42A0h]
  bool netfile; // [rsp+A3h] [rbp-4295h] BYREF
  int numcodecs; // [rsp+A4h] [rbp-4294h] BYREF
  int maxchannels; // [rsp+A8h] [rbp-4290h] BYREF
  int maxfrequency; // [rsp+ACh] [rbp-428Ch] BYREF
  FMOD_SOUND_TYPE_0 suggestedsoundtype; // [rsp+B0h] [rbp-4288h] BYREF
  unsigned int pcm; // [rsp+B4h] [rbp-4284h] BYREF
  FMOD::Codec_0 *codec; // [rsp+B8h] [rbp-4280h] BYREF
  FMOD::File *file; // [rsp+C0h] [rbp-4278h] BYREF
  FMOD::Sample *read; // [rsp+C8h] [rbp-4270h] BYREF
  FMOD_CODEC_WAVEFORMAT waveformat; // [rsp+D0h] [rbp-4268h] BYREF
  FMOD::Sample *sample_0; // [rsp+110h] [rbp-4228h] BYREF
  int v230; // [rsp+11Ch] [rbp-421Ch]
  unsigned int decodebuffersize; // [rsp+128h] [rbp-4210h]
  int v232; // [rsp+130h] [rbp-4208h]
  unsigned int v233; // [rsp+134h] [rbp-4204h]
  FMOD_CHANNELORDER channelorder; // [rsp+140h] [rbp-41F8h]
  FMOD_CODEC_WAVEFORMAT tag; // [rsp+150h] [rbp-41E8h] OVERLAPPED BYREF
  FMOD_RESULT_0 (__fastcall *v236)(FMOD_CODEC_STATE *, FMOD_TAGTYPE, char *, void *, unsigned int, FMOD_TAGDATATYPE, int); // [rsp+188h] [rbp-41B0h]
  int v237; // [rsp+1A0h] [rbp-4198h]
  _QWORD v238[33]; // [rsp+1A8h] [rbp-4190h] BYREF
  int v239; // [rsp+2B0h] [rbp-4088h]
  int v240; // [rsp+2B4h] [rbp-4084h]
  __int64 v241; // [rsp+2C0h] [rbp-4078h]
  FMOD::Metadata *v242; // [rsp+2E0h] [rbp-4058h]
  FMOD::File *v243; // [rsp+2E8h] [rbp-4050h]
  char filebufferstackmem[16385]; // [rsp+2F0h] [rbp-4048h] BYREF

  codec = 0;
  file = 0;
  netfile = 0;
  maxchannels = 0;
  maxfrequency = 0;
  suggestedsoundtype = FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_UNKNOWN_0;
  if ( !sound )
    goto LABEL_22;
  v8 = this;
  v10 = exinfo;
  if ( (mode_in & 0x10000000) != 0 )
  {
    if ( exinfo )
    {
      m_val = 0;
      Buffer = FMOD_RESULT::FMOD_ERR_MEMORY_CANTPOINT_0;
      if ( exinfo->encryptionkey )
        goto LABEL_23;
    }
  }
  if ( (mode_in & 0x10000) == 0 )
    *sound = 0;
  v11 = mode_in;
  if ( (mode_in & 0x80u) == 0 )
  {
    BYTE1(v11) = BYTE1(mode_in) & 0xFE;
    if ( (mode_in & 0x200) == 0 )
      v11 = mode_in;
  }
  else
  {
    BYTE1(v11) = BYTE1(mode_in) & 0xFC;
  }
  if ( (v11 & 8) != 0 )
    v11 &= 0xFB03FFFF;
  if ( (v11 & 0x4FC0000) != 0 )
    v11 |= 0x10u;
  if ( (v11 & 0x1400) == 0 )
  {
    if ( (v11 & 0x10000800) == 0 )
      goto LABEL_35;
    if ( exinfo && exinfo->length )
    {
LABEL_17:
      v12 = FMOD::SystemI::createMemoryFile(this, &file);
      if ( v12 )
      {
LABEL_18:
        Buffer = v12;
        m_val = 0;
LABEL_23:
        v15 = 0;
        goto LABEL_24;
      }
      goto LABEL_75;
    }
LABEL_22:
    m_val = 0;
    Buffer = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    goto LABEL_23;
  }
  if ( !exinfo
    || exinfo->format == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_NONE
    || exinfo->numchannels <= 0
    || !exinfo->defaultfrequency )
  {
    goto LABEL_22;
  }
  if ( (v11 & 0x10000800) != 0 )
    goto LABEL_17;
LABEL_35:
  if ( (v11 & 0x400) == 0 )
  {
    v12 = FMOD::SystemI::createDiskFile(this, name_or_data, exinfo, &file, &netfile);
    if ( v12 )
      goto LABEL_18;
LABEL_75:
    m_val = file;
    v19 = file;
    goto LABEL_42;
  }
  v17 = (FMOD::File *)FMOD::MemPool::alloc(
                        off_286F358->gSystemMemPool,
                        504,
                        "../../../core_api/src/fmod_systemi_sound.cpp",
                        882,
                        0,
                        0);
  m_val = v17;
  if ( !v17 )
  {
    file = 0;
    Buffer = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    goto LABEL_23;
  }
  FMOD::File::File(v17);
  m_val->_vptr_File = (int (**)(...))off_29B19D0;
  file = m_val;
  if ( v10 && (mBufferSize = v10->filebuffersize) != 0 )
  {
    if ( mBufferSize == -1 )
      mBufferSize = 0;
  }
  else
  {
    mBufferSize = this->mBufferSize;
  }
  FMOD::File::init(m_val, this, 0, mBufferSize);
  v19 = file;
  BYTE1(v11) &= ~0x10u;
LABEL_42:
  v20 = FMOD::File::setFileCategory(v19, (FMOD::FMOD_FILE_CATEGORY)((v11 & 0x80) != 0));
  if ( v20 )
    goto LABEL_77;
  if ( *sound && netfile )
  {
    (*sound)->mOpenState.m_value = FMOD_OPENSTATE::FMOD_OPENSTATE_CONNECTING_0;
    _mm_mfence();
  }
  v21 = file;
  if ( (v11 & 0x80) == 0 || file->mBlockSize - 1 > 0x3FFF || (v8->mFlags & 1) != 0 )
  {
    filebufferstack = 0;
  }
  else
  {
    file->mBuffer = filebufferstackmem;
    filebufferstack = filebufferstackmem;
  }
  if ( v10 )
  {
    encryptionkey = v10->encryptionkey;
    fileoffset = v10->fileoffset;
    length = v10->length;
  }
  else
  {
    fileoffset = 0;
    encryptionkey = 0;
    length = 0;
  }
  v20 = FMOD::File::open(v21, name_or_data, length, fileoffset, encryptionkey);
  if ( v20 )
  {
LABEL_77:
    Buffer = v20;
    goto LABEL_23;
  }
  v25 = file;
  if ( *sound && netfile )
  {
    (*sound)->mOpenState.m_value = FMOD_OPENSTATE::FMOD_OPENSTATE_BUFFERING_0;
    _mm_mfence();
  }
  startingcodec = v25;
  v26 = FMOD::PluginFactory::getNumCodecs(v8->mPluginFactory, &numcodecs);
  v27 = startingcodec;
  if ( v26 )
  {
    Buffer = v26;
    v15 = 0;
    goto LABEL_72;
  }
  if ( v10 && v10->suggestedsoundtype )
  {
    suggestedsoundtype = v10->suggestedsoundtype;
    v28 = 0;
    goto LABEL_60;
  }
  v28 = 0;
  if ( (v11 & 0x10000C00) == 0 )
  {
    FMOD::SystemI::getSoundTypeFromFilename(v8, name_or_data, &suggestedsoundtype);
    v28 = 1;
    v27 = startingcodec;
  }
  if ( suggestedsoundtype )
  {
LABEL_60:
    if ( numcodecs > 0 )
    {
      samplecontainer_cleanup.m_val = (FMOD::Sample *)m_val;
      v29 = v8;
      blocksize = v10;
      result = v27;
      v30 = 0;
      v31 = v28;
      do
      {
        if ( FMOD::PluginFactory::getCodecHandle(v29->mPluginFactory, v30, (unsigned int *)&sample_0) == FMOD_RESULT::FMOD_OK_0
          && FMOD::PluginFactory::getCodec(
               v29->mPluginFactory,
               (unsigned int)sample_0,
               (FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN **)&tag) == FMOD_RESULT::FMOD_OK_0 )
        {
          v32 = *((_DWORD *)tag.name + 30);
          if ( v32 == suggestedsoundtype || v31 && !v32 )
          {
            v33 = v30;
            v8 = v29;
            v27 = result;
            m_val = (FMOD::File *)samplecontainer_cleanup.m_val;
            v10 = blocksize;
            startingcodeca = v33;
            goto LABEL_69;
          }
        }
        ++v30;
      }
      while ( numcodecs > v30 );
      v8 = v29;
      v27 = result;
      m_val = (FMOD::File *)samplecontainer_cleanup.m_val;
      v10 = blocksize;
    }
  }
  startingcodeca = 0;
LABEL_69:
  if ( (v11 & 0x2000000) != 0 )
  {
    stream_cleanup = 0;
  }
  else
  {
    resulta = v27;
    v237 = 0;
    memset(&v238[29], 0, 32);
    *(_QWORD *)&tag.mode = FMOD::Codec::defaultFileRead;
    v241 = 0;
    v239 = 0;
    v240 = 0;
    *(_QWORD *)&tag.channelorder = FMOD::Codec::defaultFileSeek;
    v242 = 0;
    v236 = FMOD::Codec::defaultMetaData;
    v243 = file;
    qmemcpy(v238, FMOD::CodecTag::getDescriptionEx(), 0xD8u);
    Buffer = FMOD::File::seek(file, 0, 0);
    v27 = resulta;
    if ( Buffer )
      goto LABEL_71;
    Buffer = ((unsigned int (__fastcall *)(FMOD_CODEC_WAVEFORMAT *, _QWORD, FMOD_CREATESOUNDEXINFO *))v238[3])(
               &tag,
               v11,
               v10);
    v27 = resulta;
    if ( Buffer )
      goto LABEL_71;
    v83 = v242;
    v243 = 0;
    v242 = 0;
    stream_cleanup = v83;
    FMOD::Codec::release((FMOD::Codec *const)&tag, 0);
    v27 = resulta;
  }
  subsound_cleanup.m_val = v27;
  v34 = FMOD::SystemI::createCodec(v8, startingcodeca, v11, mode_in, file, v10, &codec, &maxchannels, &maxfrequency);
  v27 = (FMOD::File *)subsound_cleanup.m_val;
  if ( v34 == FMOD_RESULT::FMOD_ERR_FORMAT_0 )
  {
    if ( numcodecs <= 0 )
      goto LABEL_190;
    v84 = 0;
    while ( 1 )
    {
      if ( v84 != startingcodeca )
      {
        v34 = FMOD::SystemI::createCodec(v8, v84, v11, mode_in, file, v10, &codec, &maxchannels, &maxfrequency);
        if ( v34 != FMOD_RESULT::FMOD_ERR_FORMAT_0 )
          break;
      }
      if ( numcodecs <= ++v84 )
      {
        v27 = (FMOD::File *)subsound_cleanup.m_val;
LABEL_190:
        Buffer = FMOD_RESULT::FMOD_ERR_FORMAT_0;
LABEL_180:
        if ( stream_cleanup )
        {
          name_or_datab = (const char *)v27;
          v15 = 0;
          FMOD::Metadata::release(stream_cleanup);
          v27 = (FMOD::File *)name_or_datab;
          goto LABEL_72;
        }
LABEL_71:
        v15 = 0;
LABEL_72:
        if ( v27 )
          FMOD::File::close(v27);
LABEL_24:
        if ( m_val )
          FMOD::MemPool::free(off_286F358->gSystemMemPool, m_val, "../../../core_api/src/fmod_autocleanup.h", 190);
        goto LABEL_26;
      }
    }
    v27 = (FMOD::File *)subsound_cleanup.m_val;
  }
  if ( v34 )
  {
    Buffer = v34;
    goto LABEL_180;
  }
  v35 = codec;
  if ( !codec )
    goto LABEL_190;
  if ( !v10 || (startingcodecb = v10->numsubsounds) == 0 )
    startingcodecb = codec->numsubsounds;
  if ( stream_cleanup )
  {
    mMetadata = codec->mMetadata;
    if ( mMetadata )
    {
      FMOD::Metadata::add(mMetadata, stream_cleanup);
      FMOD::Metadata::release(stream_cleanup);
      v35 = codec;
    }
    else
    {
      codec->mMetadata = stream_cleanup;
    }
  }
  FMOD::Codec::getMetadataFromFile(v35);
  file = 0;
  v37 = codec;
  if ( startingcodecb <= 0 )
  {
    v15 = 0;
  }
  else
  {
    v15 = (FMOD::SoundI **)FMOD::MemPool::calloc(
                             off_286F358->gSystemMemPool,
                             8 * startingcodecb,
                             "../../../core_api/src/fmod_systemi_sound.cpp",
                             1073,
                             0);
    if ( !v15 )
      goto LABEL_194;
  }
  memset(&waveformat, 0, sizeof(waveformat));
  resultb = codec->mDescription.getwaveformat(codec, 0, &waveformat);
  Buffer = resultb;
  if ( resultb )
    goto LABEL_177;
  Buffer = FMOD_RESULT::FMOD_ERR_TOOMANYCHANNELS_0;
  if ( waveformat.channels > 32 )
    goto LABEL_177;
  v38 = codec;
  if ( codec->mDescription.defaultasstream && (v11 & 0x10300) == 0 )
  {
    mFile = codec->mFile;
    if ( mFile )
    {
      Buffer = FMOD::File::setFileCategory(mFile, FMOD::FMOD_FILE_CATEGORY::FMOD_FILE_CATEGORY_STREAM);
      if ( Buffer )
        goto LABEL_177;
      v38 = codec;
    }
    LOBYTE(v11) = v11 | 0x80;
  }
  if ( v38->mType == FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_PLAYLIST_0 )
  {
    if ( (v11 & 0x10000) != 0 )
    {
      v124 = *sound;
    }
    else
    {
      v184 = (FMOD::Sample *)FMOD::MemPool::calloc(
                               off_286F358->gSystemMemPool,
                               352,
                               "../../../core_api/src/fmod_systemi_sound.cpp",
                               1122,
                               0);
      v124 = v184;
      if ( !v184 )
        goto LABEL_194;
      FMOD::Sample::Sample(v184);
      v38 = codec;
    }
    v124->mSystem = v8;
    mDistanceScale = v8->mDistanceScale;
    if ( v10 )
    {
      v124->mPostReadCallback = v10->pcmreadcallback;
      pcmsetposcallback = v10->pcmsetposcallback;
      v124->mPostCallbackSound = (FMOD_SOUND *)v124;
      v124->mPostSetPositionCallback = pcmsetposcallback;
      LODWORD(pcmsetposcallback) = v38->mType;
      v124->mMinDistance = mDistanceScale;
      v127 = mDistanceScale * 10000.0;
      v124->mCodec = v38;
      v124->mSubSound = 0;
      v124->mType = (int)pcmsetposcallback;
      userdata = v10->userdata;
    }
    else
    {
      mType = v38->mType;
      v124->mMinDistance = mDistanceScale;
      v127 = mDistanceScale * 10000.0;
      v124->mPostReadCallback = 0;
      v124->mPostSetPositionCallback = 0;
      v124->mPostCallbackSound = (FMOD_SOUND *)v124;
      v124->mType = mType;
      userdata = 0;
      v124->mCodec = v38;
      v124->mSubSound = 0;
    }
    v124->mNumSubSounds = 0;
    v124->mSubSoundIndex = -1;
    v124->mMaxDistance = v127;
    v124->mUserData = userdata;
    v37 = 0;
    FMOD::SystemI::callInternalCallback(v8, (FMOD_SYSTEM_CALLBACK_TYPE)&stru_100008, v124, 0);
    *sound = v124;
    goto LABEL_283;
  }
  if ( (v11 & 0x80u) != 0 )
  {
    read = 0;
    if ( (v11 & 0x10000) != 0 )
    {
      stream_cleanupa.m_val = 0;
      v40 = *sound;
LABEL_112:
      v40->mSubSound = v15;
      v40->mCodec = v38;
      v40->mSystem = v8;
      v40->mNumSubSounds = startingcodecb;
      if ( !v10 || (v41 = v10->decodebuffersize) == 0 )
        v41 = maxfrequency * v8->mAdvancedSettings.defaultDecodeBufferSize / 0x3E8;
      pcmblocksize = v41;
      samplecontainer_cleanupa = v11 & 0x400;
      if ( (v11 & 0x400) == 0 )
      {
        pcmblocksize = waveformat.pcmblocksize;
        if ( waveformat.pcmblocksize )
        {
          if ( waveformat.pcmblocksize > 0xFF )
            goto LABEL_118;
        }
        else
        {
          pcmblocksize = 1;
        }
        pcmblocksize *= (pcmblocksize + 255) / pcmblocksize;
      }
LABEL_118:
      lengthpcm = pcmblocksize * (v41 / pcmblocksize);
      if ( pcmblocksize >= lengthpcm )
        lengthpcm = 2 * pcmblocksize;
      if ( (v11 & 0x400) == 0 && !startingcodecb && lengthpcm > waveformat.lengthpcm )
        lengthpcm = waveformat.lengthpcm;
      p_sample_0 = &sample_0;
      v45 = 14;
      p_waveformat = &waveformat;
      while ( v45 )
      {
        *(_DWORD *)p_sample_0 = p_waveformat->name;
        p_waveformat = (FMOD_CODEC_WAVEFORMAT *)((char *)p_waveformat + 4);
        p_sample_0 = (FMOD::Sample **)((char *)p_sample_0 + 4);
        --v45;
      }
      if ( v10 && v10->channelorder )
        channelorder = v10->channelorder;
      decodebuffersize = lengthpcm;
      blocksizea = pcmblocksize;
      v232 = 0;
      v230 = maxchannels;
      v233 = lengthpcm - 1;
      resultb = FMOD::SystemI::createSample(v8, v11 & 0xEFFFFDF8 | 2, (FMOD_CODEC_WAVEFORMAT *)&sample_0, &read);
      if ( resultb )
      {
        Buffer = resultb;
        goto LABEL_166;
      }
      v47 = read;
      if ( v10 )
      {
        pcmreadcallback = v10->pcmreadcallback;
        v49 = v10->pcmsetposcallback;
        frequency = (float)waveformat.frequency;
        v51 = v10->userdata;
        v52 = codec;
        lengthbytes = waveformat.lengthbytes;
        read->mPostCallbackSound = (FMOD_SOUND *)v40;
        v47->mPostReadCallback = pcmreadcallback;
        v47->mPostSetPositionCallback = v49;
        v47->mCodec = v52;
        v47->mUserData = v51;
        v40->mDefaultFrequency = frequency;
        v40->mLengthBytes = lengthbytes;
        v54 = v10->channelorder;
        v55 = waveformat.lengthpcm;
        LODWORD(v52) = v52->mType;
        v40->mPeakVolume = waveformat.peakvolume;
        v40->mDefaultChannelOrder = v54;
        format = waveformat.format;
        v57 = v8->mDistanceScale;
        *(_QWORD *)&v40[1].mMagic = v47;
        v40->mSubSoundIndex = 0;
        v40->mFormat = format;
        v58 = maxchannels;
        v40->mLength = v55;
        v40->mSystem = v8;
        v40->mPostReadCallback = pcmreadcallback;
        v40->mPostSetPositionCallback = v49;
        v40->mChannels = v58;
        v40->mPostCallbackSound = (FMOD_SOUND *)v40;
        v40[1].mMode = blocksizea;
        v40->mType = (int)v52;
        v40->mMinDistance = v57;
        v59 = v57 * 10000.0;
      }
      else
      {
        v175 = codec;
        v176 = waveformat.lengthbytes;
        v177 = (float)waveformat.frequency;
        read->mPostReadCallback = 0;
        v47->mPostSetPositionCallback = 0;
        v47->mUserData = 0;
        v47->mPostCallbackSound = (FMOD_SOUND *)v40;
        v47->mCodec = v175;
        v40->mLengthBytes = v176;
        v40->mDefaultFrequency = v177;
        v178 = waveformat.channelorder;
        v40->mPeakVolume = waveformat.peakvolume;
        LODWORD(v175) = v175->mType;
        v55 = waveformat.lengthpcm;
        v40->mDefaultChannelOrder = v178;
        v179 = waveformat.format;
        v180 = v8->mDistanceScale;
        v40->mMinDistance = v180;
        v59 = v180 * 10000.0;
        v40->mType = (int)v175;
        v40->mFormat = v179;
        v181 = maxchannels;
        v51 = 0;
        *(_QWORD *)&v40[1].mMagic = v47;
        v40->mSubSoundIndex = 0;
        v40->mLength = v55;
        v40->mChannels = v181;
        v40->mSystem = v8;
        v40->mPostReadCallback = 0;
        v40->mPostSetPositionCallback = 0;
        v40->mPostCallbackSound = (FMOD_SOUND *)v40;
        v40[1].mMode = blocksizea;
      }
      v40->mMaxDistance = v59;
      mMode = v47->mMode;
      v40->mLoopLength = v55;
      name = waveformat.name;
      v40->mUserData = v51;
      v40->mLoopStart = 0;
      v40->mName = name;
      v62 = v11 & 0xEFFFFDE0 | mMode & 0x18 | 0x20080;
      LOBYTE(name) = waveformat.mode;
      v40->mMode = v62;
      v63 = v11 | (unsigned __int8)name;
      if ( (v63 & 1) != 0 || (v63 & 2) == 0 )
        v40->mMode = v62 | 1;
      else
        v40->mMode = v62 | 2;
      (*((void (__fastcall **)(FMOD::SoundI *, _QWORD, __int64, _QWORD, __int64))v40->_vptr_SoundI + 39))(
        v40,
        (unsigned int)waveformat.loopstart,
        2,
        (unsigned int)waveformat.loopend,
        2);
      v64 = blocksizea;
      if ( !v40->mSoundGroupNode.mNodeData )
      {
        updated = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD::SoundGroupI *))v40->_vptr_SoundI + 27))(
                    v40,
                    v8->mMasterSoundGroup);
        v64 = blocksizea;
        if ( updated )
          goto LABEL_165;
      }
      subsound_cleanupa = v64;
      v65 = (FMOD::ChannelStream *)FMOD::MemPool::calloc(
                                     off_286F358->gSystemMemPool,
                                     200,
                                     "../../../core_api/src/fmod_systemi_sound.cpp",
                                     1331,
                                     0);
      if ( v65 )
      {
        v216 = subsound_cleanupa;
        subsound_cleanupd.m_val = v65;
        FMOD::ChannelStream::ChannelStream(v65);
        v40[1].mNodeData = subsound_cleanupd.m_val;
        *((_QWORD *)subsound_cleanupd.m_val + 1) = v8;
        FMOD::SystemI::enterCrit(v8, FMOD_SYSTEM_CRIT_STREAMLIST);
        v40[1].mNodePrev = (FMOD::LinkedListNode *)v40;
        v40[1].mNodeNext = *(FMOD::LinkedListNode **)((char *)&stru_120F0.r_offset + (_QWORD)v8);
        v40[1]._vptr_SoundI = (int (**)(...))&v8->mStreamListSoundHead;
        *(unsigned __int64 *)((char *)&stru_120F0.r_offset + (_QWORD)v8) = (unsigned __int64)&v40[1];
        v40[1].mNodeNext->mNodeNext = (FMOD::LinkedListNode *)&v40[1];
        FMOD::SystemI::leaveCrit(v8, FMOD_SYSTEM_CRIT_STREAMLIST);
        if ( startingcodecb <= 0 || (v68 = v216, (v11 & 0x400) != 0) )
        {
          soundcreate = codec->mDescription.soundcreate;
          if ( soundcreate )
          {
            updated = ((unsigned int (__fastcall *)(FMOD::Codec_0 *, _QWORD, FMOD::SoundI *, __int64, __int64, __int64))soundcreate)(
                        codec,
                        0,
                        v40,
                        v66,
                        v67,
                        v68);
            if ( updated )
              goto LABEL_165;
          }
          goto LABEL_142;
        }
        v158 = (FMOD::Stream *)FMOD::MemPool::calloc(
                                 off_286F358->gSystemMemPool,
                                 408,
                                 "../../../core_api/src/fmod_systemi_sound.cpp",
                                 1355,
                                 0);
        v159 = v158;
        if ( v158 )
        {
          FMOD::Stream::Stream(v158);
          if ( startingcodecb != 1 )
            v40->mSubSoundShared = v159;
          v159->mSystem = v8;
          v160 = read;
          v161 = v8->mDistanceScale;
          v159->mSubSoundIndex = 0;
          *(_QWORD *)&v159[1].mMagic = v160;
          v159->mCodec = codec;
          v159[1].mNodeData = v40[1].mNodeData;
          v159->mMode = v40->mMode;
          v159->mType = v40->mType;
          mAsyncData = v40->mAsyncData;
          v159->mMinDistance = v161;
          v159[1].mMode = v216;
          v159->mSubSoundParent = v40;
          v159->mAsyncData = mAsyncData;
          v159->mMaxDistance = v161 * 10000.0;
          if ( startingcodecb != 1 )
            v159->mSubSoundShared = v159;
          if ( !v159->mSoundGroupNode.mNodeData )
          {
            v173 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD::SoundGroupI *))v159->_vptr_SoundI + 27))(
                     v159,
                     v8->mMasterSoundGroup);
            if ( v173 )
            {
LABEL_390:
              name_or_datac = v173;
              (*((void (__fastcall **)(FMOD::SoundI *, __int64))v159->_vptr_SoundI + 3))(v159, 1);
              Buffer = name_or_datac;
              goto LABEL_166;
            }
          }
          subsound_cleanupc = v11;
          v163 = 0;
          do
          {
            v15[v163] = v159;
            v164 = codec;
            if ( (int)v163 < codec->numsubsounds )
            {
              p_tag = &tag;
              for ( i = 14; i; --i )
              {
                LODWORD(p_tag->name) = 0;
                p_tag = (FMOD_CODEC_WAVEFORMAT *)((char *)p_tag + 4);
              }
              v167 = v164->mDescription.getwaveformat(v164, v163, &tag);
              if ( v167 )
                goto LABEL_389;
              v168 = tag.name;
              v159->mSubSoundIndex = v163;
              v159->mName = v168;
              v159->mFormat = tag.format;
              v159->mChannels = tag.channels;
              loopstart = (unsigned int)tag.loopstart;
              v159->mDefaultFrequency = (float)tag.frequency;
              LODWORD(v168) = tag.channelorder;
              peakvolume = tag.peakvolume;
              v159->mLoopStart = loopstart;
              loopend = (unsigned int)tag.loopend;
              v159->mPeakVolume = peakvolume;
              v159->mDefaultChannelOrder = (int)v168;
              v159->mLoopLength = loopend - loopstart + 1;
              v159->mLength = tag.lengthpcm;
              v159->mLengthBytes = tag.lengthbytes;
              (*((void (__fastcall **)(FMOD::SoundI *, __int64, __int64, __int64, __int64))v159->_vptr_SoundI + 39))(
                v159,
                loopstart,
                2,
                loopend,
                2);
              v172 = codec->mDescription.soundcreate;
              if ( v172 )
              {
                v167 = v172(codec, v163, (FMOD_SOUND *)v159);
                if ( v167 )
                {
LABEL_389:
                  v173 = v167;
                  goto LABEL_390;
                }
              }
            }
            ++v40->mNumActiveSubSounds;
            ++v163;
          }
          while ( startingcodecb > (int)v163 );
          v11 = subsound_cleanupc;
          if ( codec->numsubsounds && v159->mSubSoundShared )
            FMOD::SoundI::updateSubSound(v159, 0, 0);
LABEL_142:
          FMOD::SystemI::callInternalCallback(v8, (FMOD_SYSTEM_CALLBACK_TYPE)&stru_100008, v40, 0);
          mDecoder = codec->mDecoder;
          if ( !mDecoder )
            mDecoder = codec;
          setupcontext = (__int64 (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD))mDecoder->mDescription.setupcontext;
          if ( setupcontext )
          {
            if ( v10 )
              initialsubsound = (unsigned int)v10->initialsubsound;
            else
              initialsubsound = 0;
            updated = (unsigned int)setupcontext(
                                      mDecoder,
                                      (unsigned int)read->mChannels,
                                      (unsigned int)(int)read->mDefaultFrequency,
                                      initialsubsound,
                                      mDecoder->mDecoderContext);
            if ( updated )
              goto LABEL_165;
            mDecoder->mFlags |= 0x200u;
          }
          if ( v10 )
          {
            initialseekpostype = v10->initialseekpostype;
            if ( initialseekpostype == 1 )
            {
              v174 = (float)((float)(int)v10->initialseekposition / 1000.0) * v40->mDefaultFrequency;
              v10->initialseekpostype = 2;
              v10->initialseekposition = (int)v174;
            }
            else if ( initialseekpostype && initialseekpostype != 2 )
            {
              if ( initialseekpostype != 4 )
              {
LABEL_407:
                Buffer = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
LABEL_166:
                v15 = 0;
                if ( stream_cleanupa.m_val )
                  (*((void (__fastcall **)(FMOD::AutoRelease<FMOD::Stream>, __int64))stream_cleanupa.m_val->_vptr_SoundI
                   + 3))(
                    stream_cleanupa,
                    1);
                goto LABEL_26;
              }
              FMOD::SoundI::getSamplesFromBytes(
                v10->initialseekposition,
                &v10->initialseekposition,
                v40->mChannels,
                v40->mFormat);
              v10->initialseekpostype = 2;
            }
            initialseekposition = v10->initialseekposition;
            if ( initialseekposition )
            {
              mLength = v40->mLength;
              if ( mLength )
                v10->initialseekposition = initialseekposition % mLength;
            }
            v77 = v10->initialsubsound;
            if ( v77 )
            {
              mSubSound = v40->mSubSound;
              if ( mSubSound )
              {
                if ( v77 >= 0 && v77 < v40->mNumSubSounds )
                {
                  v40->mSubSoundIndex = v77;
                  v79 = (FMOD::Stream *)mSubSound[v77];
                  if ( v79 )
                  {
                    v80 = v79->mSubSoundShared == 0;
                    v79->mSubSoundIndex = v77;
                    if ( !v80 )
                    {
                      updated = FMOD::SoundI::updateSubSound(v79, v77, 0);
                      if ( updated )
                        goto LABEL_165;
                    }
                    v141 = v10->initialseekposition;
                    HIDWORD(v40[1].mName) = v141;
                    updated = FMOD::Stream::setPosition(v79, v141, 2u);
                    if ( updated )
                      goto LABEL_165;
                  }
LABEL_334:
                  if ( (v11 & 0x2000) != 0
                    || (updated = FMOD::Stream::flush((FMOD::Stream *const)v40)) == FMOD_RESULT::FMOD_OK_0 )
                  {
                    v142 = codec;
                    if ( !codec->mFile || samplecontainer_cleanupa || (v8->mFlags & 1) != 0 )
                      goto LABEL_349;
                    if ( buffersizetype != 8 )
                    {
                      pcm = buffersize;
                      if ( buffersizetype == 1 )
                      {
                        pcm = buffersize * (int)v40->mDefaultFrequency / 0x3E8;
                      }
                      else if ( buffersizetype == 4 )
                      {
                        FMOD::SoundI::getSamplesFromBytes(buffersize, &pcm, v40->mChannels, v40->mFormat);
                      }
                      v143 = v40->mLength;
                      if ( v143 == -1 || (v142 = codec, v144 = codec->mFile->mLength, v144 == -1) )
                      {
                        mFormat = v40->mFormat;
                        mChannels = v40->mChannels;
                        v150 = pcm;
                        LODWORD(tag.name) = 0;
                        FMOD::SoundI::getBitsFromFormat(mFormat, (int *)&tag);
                        if ( LODWORD(tag.name) )
                          v150 = ((unsigned __int64)v150 * SLODWORD(tag.name)) >> 3;
                        updated = FMOD::File::enableDoubleBuffer(codec->mFile, mChannels * v150, filebufferstack);
LABEL_348:
                        if ( updated == FMOD_RESULT::FMOD_OK_0 )
                        {
LABEL_349:
                          v15 = 0;
                          *sound = v40;
                          v37 = 0;
                          goto LABEL_283;
                        }
                        goto LABEL_165;
                      }
                      mLengthBytes = v40->mLengthBytes;
                      if ( mLengthBytes )
                        v146 = (float)mLengthBytes / (float)v143;
                      else
                        v146 = (float)v144 / (float)v143;
                      buffersize = (int)(float)((float)(int)pcm * v146);
                    }
                    updated = FMOD::File::enableDoubleBuffer(v142->mFile, buffersize, filebufferstack);
                    goto LABEL_348;
                  }
LABEL_165:
                  Buffer = updated;
                  goto LABEL_166;
                }
                goto LABEL_407;
              }
            }
            v147 = v10->initialseekposition;
            HIDWORD(v40[1].mName) = v147;
          }
          else
          {
            HIDWORD(v40[1].mName) = 0;
            v147 = 0;
          }
          updated = FMOD::Stream::setPosition((FMOD::Stream *const)v40, v147, 2u);
          if ( updated )
            goto LABEL_165;
          goto LABEL_334;
        }
      }
      else
      {
        v40[1].mNodeData = 0;
      }
      Buffer = FMOD_RESULT::FMOD_ERR_MEMORY_0;
      goto LABEL_166;
    }
    v140 = (FMOD::Stream *)FMOD::MemPool::calloc(
                             off_286F358->gSystemMemPool,
                             408,
                             "../../../core_api/src/fmod_systemi_sound.cpp",
                             1175,
                             0);
    stream_cleanupa.m_val = v140;
    if ( v140 )
    {
      v40 = v140;
      FMOD::Stream::Stream(v140);
      v38 = codec;
      goto LABEL_112;
    }
LABEL_194:
    Buffer = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    goto LABEL_177;
  }
  sample_0 = 0;
  if ( startingcodecb <= 0 )
  {
    subsound_cleanupb.m_val = v15;
    samplecontainer_cleanupb.m_val = 0;
    v89 = 0;
  }
  else
  {
    if ( (v11 & 0x10000) != 0 )
    {
      samplecontainer_cleanupb.m_val = 0;
      v85 = *sound;
    }
    else
    {
      v156 = (FMOD::Sample *)FMOD::MemPool::calloc(
                               off_286F358->gSystemMemPool,
                               352,
                               "../../../core_api/src/fmod_systemi_sound.cpp",
                               1624,
                               0);
      samplecontainer_cleanupb.m_val = v156;
      if ( !v156 )
      {
        subsound_cleanupb.m_val = v15;
        Buffer = FMOD_RESULT::FMOD_ERR_MEMORY_0;
LABEL_176:
        v15 = (FMOD::SoundI **)subsound_cleanupb.m_val;
        goto LABEL_177;
      }
      v157 = v156;
      FMOD::Sample::Sample(v156);
      v85 = v157;
      v38 = codec;
    }
    v85->mSystem = v8;
    v86 = v8->mDistanceScale;
    if ( v10 )
    {
      v85->mPostReadCallback = v10->pcmreadcallback;
      v87 = v10->pcmsetposcallback;
      v85->mPostCallbackSound = (FMOD_SOUND *)v85;
      v85->mPostSetPositionCallback = v87;
      LODWORD(v87) = v38->mType;
      v85->mMinDistance = v86;
      v85->mCodec = v38;
      v85->mSubSound = v15;
      v85->mType = (int)v87;
      v85->mSubSoundIndex = -1;
      v85->mNumSubSounds = startingcodecb;
      v88 = v10->userdata;
      v85->mMaxDistance = v86 * 10000.0;
    }
    else
    {
      v155 = v38->mType;
      v85->mMinDistance = v86;
      v85->mPostReadCallback = 0;
      v85->mPostSetPositionCallback = 0;
      v85->mPostCallbackSound = (FMOD_SOUND *)v85;
      v85->mType = v155;
      v85->mCodec = v38;
      v85->mSubSound = v15;
      v85->mSubSoundIndex = -1;
      v85->mNumSubSounds = startingcodecb;
      v85->mMaxDistance = v86 * 10000.0;
      v88 = 0;
    }
    v85->mDefaultFrequency = (float)waveformat.frequency;
    v85->mUserData = v88;
    v85->mMode = v11;
    samplecontainerc = (FMOD::Sample *)v85;
    FMOD::SystemI::callInternalCallback(v8, (FMOD_SYSTEM_CALLBACK_TYPE)&stru_100008, v85, 0);
    v89 = samplecontainerc;
    subsound_cleanupb.m_val = 0;
    v37 = 0;
  }
  v90 = v8;
  blocksizeb = 0;
  v91 = v11;
  realtimesample = 0;
  subsound = v15;
  samplecontainera = (FMOD::Sample *)v37;
  v92 = v89;
  while ( !startingcodecb )
  {
    if ( (_DWORD)blocksizeb )
      goto LABEL_361;
LABEL_205:
    memset(&tag, 0, sizeof(tag));
    v93 = codec->mDescription.getwaveformat(codec, blocksizeb, &tag);
    resultb = v93;
    if ( v93 )
    {
      v37 = (FMOD::Codec *)samplecontainera;
      Buffer = v93;
      goto LABEL_174;
    }
    if ( !startingcodecb )
    {
      if ( (v91 & 0x10000) != 0 )
      {
        v95 = v10 != 0;
        sample_0 = (FMOD::Sample *)*sound;
        v94 = 0;
      }
      else
      {
        v94 = 0;
        sample_0 = 0;
        v95 = v10 != 0;
      }
LABEL_217:
      stream_cleanupb = v94;
      if ( v95 )
      {
LABEL_218:
        v95 = 1;
        if ( v10->channelorder )
          tag.channelorder = v10->channelorder;
      }
      if ( (v91 & 0x200) != 0 )
      {
        if ( codec->mDescription.mPoolType > (unsigned int)FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_NONE )
        {
          buffersizetypeb = v91;
          realtimesample = 1;
LABEL_223:
          v82 = FMOD::SystemI::createSample(v90, buffersizetypeb, &tag, &sample_0);
          if ( v82 )
          {
LABEL_173:
            v37 = (FMOD::Codec *)samplecontainera;
            Buffer = v82;
            goto LABEL_174;
          }
          v100 = sample_0;
          v101 = codec;
          v102 = v90->mDistanceScale;
          v103 = codec->mType;
          sample_0->mMinDistance = v102;
          v100->mSubSoundIndex = blocksizeb;
          v100->mSubSoundParent = v92;
          v100->mCodec = v101;
          v100->mType = v103;
          v100->mMaxDistance = v102 * 10000.0;
          if ( v95 )
            v104 = v10->userdata;
          else
            v104 = 0;
          v80 = v100->mSoundGroupNode.mNodeData == 0;
          v100->mUserData = v104;
          if ( v80 )
          {
            v107 = (*((unsigned int (__fastcall **)(FMOD::Sample *, FMOD::SoundGroupI *))v100->_vptr_SoundI + 27))(
                     v100,
                     v90->mMasterSoundGroup);
            if ( v107 )
              goto LABEL_292;
          }
          if ( !((unsigned int)blocksizeb | startingcodecb) )
          {
            FMOD::SystemI::callInternalCallback(v90, (FMOD_SYSTEM_CALLBACK_TYPE)&stru_100008, sample_0, 0);
            v121 = sample_0;
            if ( v95 )
            {
              sample_0->mPostReadCallback = v10->pcmreadcallback;
              v122 = v10->pcmsetposcallback;
            }
            else
            {
              sample_0->mPostReadCallback = 0;
              v122 = 0;
            }
            v121->mPostSetPositionCallback = v122;
            v121->mPostCallbackSound = (FMOD_SOUND *)v121;
          }
          v105 = codec;
          v106 = codec->mDescription.soundcreate;
          if ( v106 )
          {
            v107 = v106(codec, blocksizeb, (FMOD_SOUND *)sample_0);
            if ( v107 )
              goto LABEL_292;
            v105 = codec;
          }
          if ( !(_DWORD)blocksizeb && (buffersizetypeb & 0x200) == 0 )
          {
            v108 = v105->mDecoder;
            if ( !v108 )
              v108 = v105;
            v109 = (__int64 (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v108->mDescription.setupcontext;
            v108->mMode &= ~0x200u;
            if ( v109 )
            {
              samplecontainerb = (FMOD::Sample *)v108;
              v107 = (unsigned int)v109(
                                     v108,
                                     (unsigned int)sample_0->mChannels,
                                     (unsigned int)(int)sample_0->mDefaultFrequency,
                                     0,
                                     v108->mDecoderContext,
                                     v105,
                                     0);
              if ( v107 )
                goto LABEL_292;
              v105 = codec;
              samplecontainerb->mLoopCount |= 0x200u;
            }
          }
          mPCMBuffer = v105->mPCMBuffer;
          v105->mPCMBufferOffset = 0;
          if ( mPCMBuffer )
            memset(mPCMBuffer, 0, v105->mPCMBufferLengthBytes);
          if ( (reset = (__int64 (__fastcall *)(FMOD::Codec_0 *))v105->mDescription.reset) != 0
            && (v107 = (unsigned int)reset(v105)) != FMOD_RESULT::FMOD_OK_0
            || ((v112 = buffersizetypeb & 0x200, (buffersizetypeb & 0x200) == 0) ? (v113 = 2) : (v113 = 8),
                (v107 = FMOD::Codec::setPosition(codec, blocksizeb, 0, v113)) != FMOD_RESULT::FMOD_OK_0) )
          {
LABEL_292:
            Buffer = v107;
            v37 = 0;
            goto LABEL_174;
          }
          mPostSetPositionCallback = sample_0->mPostSetPositionCallback;
          if ( mPostSetPositionCallback )
          {
            if ( stream_cleanupb )
              v92->mPostSetPositionCallback((FMOD_SOUND *)v92, blocksizeb, 0, 2);
            else
              mPostSetPositionCallback((FMOD_SOUND *)sample_0, 0, 0, 2);
          }
          if ( (buffersizetypeb & 0x10000000) == 0 )
          {
            if ( (buffersizetypeb & 0x2000) == 0 )
            {
              v80 = v112 == 0;
              v115 = v112 != 0;
              if ( v80 )
              {
                v116 = tag.lengthpcm;
              }
              else
              {
                v116 = tag.lengthbytes;
                v117 = codec->mType;
                if ( v117 != FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_FSB_0
                  && v117 != FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_XMA_0
                  && v117 != FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_MPEG_0 )
                {
                  v116 = tag.lengthbytes - codec->mSrcDataOffset;
                }
              }
              v118 = FMOD::SoundI::read(sample_0, 0, v116, (unsigned int *)&read);
              if ( (v118 & 0xFFFFFFEF) != 0 )
              {
                Buffer = v118;
                if ( (sample_0->mMode & 0x10000) == 0 && (v92 || codec) )
                {
                  Buffer = v118;
                  (*((void (__fastcall **)(FMOD::Sample *, __int64))sample_0->_vptr_SoundI + 3))(sample_0, 1);
                }
                goto LABEL_322;
              }
              if ( v116 == (_DWORD)read )
              {
                v119 = sample_0;
              }
              else
              {
                if ( !(_DWORD)read || v115 || (v119 = sample_0, v120 = sample_0->mLength, (unsigned int)read > v120) )
                {
                  Buffer = FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
                  goto LABEL_322;
                }
                if ( v120 == sample_0->mLoopLength )
                  sample_0->mLoopLength = (unsigned int)read;
              }
              resultb = FMOD::SoundI::setPositionInternal(v119, 0);
              if ( (resultb & 0xFFFFFFEF) != 0 )
              {
                Buffer = resultb;
                goto LABEL_322;
              }
            }
            goto LABEL_263;
          }
          v123 = (*((unsigned int (__fastcall **)(FMOD::Sample *, const char *))sample_0->_vptr_SoundI + 50))(
                   sample_0,
                   &name_or_data[codec->mFile->mCurrentPosition]);
          if ( v123 == FMOD_RESULT::FMOD_OK_0 )
          {
LABEL_263:
            if ( stream_cleanupb )
            {
              subsound[blocksizeb] = sample_0;
              ++v92->mNumActiveSubSounds;
            }
            samplecontainera = 0;
            goto LABEL_214;
          }
          Buffer = v123;
          if ( v92 || codec )
          {
            v37 = 0;
            (*((void (__fastcall **)(FMOD::Sample *, __int64))sample_0->_vptr_SoundI + 3))(sample_0, 1);
            goto LABEL_174;
          }
LABEL_322:
          v37 = 0;
LABEL_174:
          if ( samplecontainer_cleanupb.m_val )
            (*((void (__fastcall **)(FMOD::AutoRelease<FMOD::Sample>, __int64))samplecontainer_cleanupb.m_val->_vptr_SoundI
             + 3))(
              samplecontainer_cleanupb,
              1);
          goto LABEL_176;
        }
        v139 = v91;
        BYTE1(v139) = BYTE1(v91) & 0xFD;
        buffersizetypeb = v139;
        if ( v92 )
          v92->mMode &= ~0x200u;
      }
      else
      {
        buffersizetypeb = v91;
      }
      if ( !realtimesample && (v91 & 0x10000000) != 0 )
      {
        canpoint = (__int64 (*)(void))codec->mDescription.canpoint;
        if ( !canpoint )
        {
          v37 = (FMOD::Codec *)samplecontainera;
          Buffer = FMOD_RESULT::FMOD_ERR_MEMORY_CANTPOINT_0;
          goto LABEL_174;
        }
        v82 = (unsigned int)canpoint();
        if ( v82 )
          goto LABEL_173;
      }
      goto LABEL_223;
    }
    v94 = startingcodecb > 0;
    sample_0 = 0;
    v95 = v10 != 0;
    stream_cleanupb = v10 != 0 && startingcodecb > 0;
    if ( !stream_cleanupb )
      goto LABEL_217;
    inclusionlist = v10->inclusionlist;
    if ( !inclusionlist )
      goto LABEL_218;
    inclusionlistnum = v10->inclusionlistnum;
    if ( inclusionlistnum <= 0 )
      goto LABEL_214;
    if ( *inclusionlist == (_DWORD)blocksizeb )
      goto LABEL_218;
    v98 = inclusionlist + 1;
    v99 = &v98[inclusionlistnum - 1];
    while ( v98 != v99 )
    {
      if ( *v98++ == (_DWORD)blocksizeb )
        goto LABEL_218;
    }
LABEL_214:
    ++blocksizeb;
  }
  if ( (int)blocksizeb < startingcodecb && (int)blocksizeb < codec->numsubsounds )
    goto LABEL_205;
LABEL_361:
  v151 = v92;
  v11 = v91;
  v37 = (FMOD::Codec *)samplecontainera;
  v80 = (v91 & 0x2000) == 0;
  v8 = v90;
  if ( v80 )
  {
    v152 = codec;
    v153 = codec->mFile;
    if ( v153 )
    {
      samplecontainerd = (FMOD::Sample *)v151;
      FMOD::File::close(v153);
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        codec->mFile,
        "../../../core_api/src/fmod_systemi_sound.cpp",
        1900);
      v152 = codec;
      v151 = samplecontainerd;
      codec->mFile = 0;
    }
    v154 = v152->mDecoder;
    if ( v154 )
      v154->mFile = 0;
  }
  if ( startingcodecb <= 0 )
  {
    *sound = sample_0;
    if ( samplecontainer_cleanupb.m_val )
      (*((void (__fastcall **)(FMOD::AutoRelease<FMOD::Sample>, __int64))samplecontainer_cleanupb.m_val->_vptr_SoundI + 3))(
        samplecontainer_cleanupb,
        1);
  }
  else
  {
    *sound = v151;
  }
  v15 = (FMOD::SoundI **)subsound_cleanupb.m_val;
LABEL_283:
  v129 = *sound;
  if ( addtosoundlist )
  {
    FMOD_OS_CriticalSection_Enter(off_286F358->gSoundListCrit);
    mNodeNext = v8->mSoundListHead.mNodeNext;
    v129->mNodePrev = &v8->mSoundListHead.FMOD::LinkedListNode;
    v129->mNodeNext = mNodeNext;
    mNodeNext->mNodePrev = &v129->FMOD::LinkedListNode;
    v129->mNodePrev->FMOD::LinkedListNode::mNodeNext = &v129->FMOD::LinkedListNode;
    FMOD_OS_CriticalSection_Leave(off_286F358->gSoundListCrit);
  }
  if ( (resultb & 0xFFFFFFEF) != 0 )
  {
    Buffer = resultb;
    if ( (v11 & 0x10000) == 0 )
      *sound = 0;
    goto LABEL_177;
  }
  if ( (v129->mMode & 0x8000000) != 0 )
    goto LABEL_312;
  mName = v129->mName;
  if ( mName )
  {
    if ( *mName )
      goto LABEL_312;
  }
  v131 = codec->mMetadata;
  if ( !v131
    || FMOD::Metadata::getTag(v131, "TIT2", 0, (FMOD_TAG *)&tag)
    && FMOD::Metadata::getTag(codec->mMetadata, "TT2", 0, (FMOD_TAG *)&tag)
    && FMOD::Metadata::getTag(codec->mMetadata, "TITLE", 0, (FMOD_TAG *)&tag) )
  {
    goto LABEL_303;
  }
  switch ( HIDWORD(tag.name) )
  {
    case 4:
      Buffer = (*((unsigned int (__fastcall **)(FMOD::SoundI *))v129->_vptr_SoundI + 17))(v129);
      if ( Buffer )
        goto LABEL_177;
      FMOD_strncpyW((__int16 *)v129->mNameMemory, (const __int16 *)(*(_QWORD *)&tag.frequency + 2LL), 128);
      FMOD_wtoa((__int16 *)v129->mNameMemory);
LABEL_410:
      FMOD::Metadata::addTag(
        codec->mMetadata,
        (FMOD_TAGTYPE)tag.name,
        *(const char **)&tag.format,
        *(void **)&tag.frequency,
        tag.lengthpcm,
        SHIDWORD(tag.name),
        1);
      goto LABEL_312;
    case 6:
      Buffer = (*((unsigned int (__fastcall **)(FMOD::SoundI *))v129->_vptr_SoundI + 17))(v129);
      if ( Buffer )
        goto LABEL_177;
      FMOD_strcpy_safe(v129->mNameMemory, *(const char **)&tag.frequency, 256);
      goto LABEL_410;
    case 3:
      Buffer = (*((unsigned int (__fastcall **)(FMOD::SoundI *))v129->_vptr_SoundI + 17))(v129);
      if ( Buffer )
        goto LABEL_177;
      FMOD_strfromlatin1(v129->mNameMemory, 256, *(const char **)&tag.frequency);
      goto LABEL_410;
  }
  FMOD::Metadata::addTag(
    codec->mMetadata,
    (FMOD_TAGTYPE)tag.name,
    *(const char **)&tag.format,
    *(void **)&tag.frequency,
    tag.lengthpcm,
    SHIDWORD(tag.name),
    1);
LABEL_303:
  if ( (v11 & 0x10000800) == 0 && name_or_data )
  {
    v132 = FMOD_strlen(name_or_data);
    v133 = 0;
    while ( 1 )
    {
      v134 = (unsigned int)(v133 + v132);
      if ( (int)v133 + v132 < 0 )
        break;
      v135 = name_or_data[v132 + v133--];
      if ( v135 == 47 || v135 == 92 )
      {
        v136 = v134 + 1;
        goto LABEL_310;
      }
    }
    v136 = 0;
LABEL_310:
    v137 = &name_or_data[v136];
    if ( *v137 )
    {
      Buffer = (*((unsigned int (__fastcall **)(FMOD::SoundI *, __int64, __int64))v129->_vptr_SoundI + 17))(
                 v129,
                 v134,
                 v133);
      if ( Buffer )
        goto LABEL_177;
      FMOD_strcpy_safe(v129->mNameMemory, v137, 256);
    }
    else
    {
      v129->mName = (const char *)&uri_string;
    }
  }
LABEL_312:
  v138 = codec->mFile;
  if ( v138 )
  {
    Buffer = FMOD_RESULT::FMOD_OK_0;
    if ( filebufferstack && filebufferstack == v138->mBuffer )
      Buffer = FMOD::File::allocateBuffer(v138);
  }
  else
  {
    Buffer = FMOD_RESULT::FMOD_OK_0;
  }
LABEL_177:
  if ( v37 )
    FMOD::Codec::release(v37, 1);
LABEL_26:
  if ( v15 )
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v15, "../../../core_api/src/fmod_autocleanup.h", 190);
  return Buffer;
}


// Address: 0x21f1a20 | Name: _ZN4FMOD7SystemI9stopSoundEPNS_6SoundIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::stopSound(FMOD::SystemI *const this, FMOD::SoundI *sound)
{
  __int64 v2; // rbp
  int i; // ebx
  FMOD::FMOD_RECORDING_INFO *info; // rax
  FMOD_RESULT_0 result; // eax
  char v6; // r14
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::ChannelI *p_mNodePrev; // r15
  FMOD::LinkedListNode *v9; // rax
  FMOD::ChannelI *v10; // r14
  Elf64_Rela *v11; // rbx
  __int64 r_addend; // rbp
  __int64 v13; // rdx
  FMOD::SoundI **v14; // rax
  int v15; // edx
  FMOD::SoundI **v16; // rax
  FMOD::SoundI **v17; // rdx
  FMOD::SoundI *channelsound[8]; // [rsp+18h] [rbp-40h] BYREF

  v2 = 0;
  for ( i = 0; this->mNumRecordDrivers > i; ++v2 )
  {
    info = this->mRecordCache[v2].info;
    if ( info )
    {
      if ( info->mRecordSound == sound )
      {
        result = FMOD::SystemI::recordStop(this, i);
        if ( result )
          return result;
      }
    }
    ++i;
  }
  v6 = 0;
  if ( (*sound->_vptr_SoundI)(sound) )
  {
    FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_STREAMLIST);
    v11 = *(Elf64_Rela **)((char *)&stru_120C0.r_offset + (_QWORD)this);
    if ( (Elf64_Rela *)((char *)&stru_120C0 + (_QWORD)this) == v11 )
    {
      v6 = 0;
LABEL_36:
      FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_STREAMLIST);
      goto LABEL_9;
    }
    while ( 1 )
    {
      r_addend = v11->r_addend;
      v11 = (Elf64_Rela *)v11->r_offset;
      v13 = *(_QWORD *)(r_addend + 40);
      if ( !v13 )
        goto LABEL_34;
      if ( sound == (FMOD::SoundI *)v13 )
        goto LABEL_38;
      v14 = *(FMOD::SoundI ***)(v13 + 160);
      if ( v14 )
        break;
      v6 = 0;
      if ( *(_QWORD *)(v13 + 384) == *(_QWORD *)&sound[1].mMagic )
      {
LABEL_38:
        v6 = 1;
        FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_STREAMLIST);
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(r_addend + 24) + 8LL))(*(_QWORD *)(r_addend + 24));
        FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_STREAMLIST);
      }
LABEL_35:
      if ( (Elf64_Rela *)((char *)&stru_120C0 + (_QWORD)this) == v11 )
        goto LABEL_36;
    }
    v15 = *(_DWORD *)(v13 + 176);
    if ( v15 > 0 )
    {
      if ( *v14 == sound )
        goto LABEL_38;
      v16 = v14 + 1;
      v17 = &v16[v15 - 1];
      while ( v16 != v17 )
      {
        if ( *v16++ == sound )
          goto LABEL_38;
      }
    }
LABEL_34:
    v6 = 0;
    goto LABEL_35;
  }
LABEL_9:
  result = FMOD_RESULT::FMOD_OK_0;
  if ( (sound->mFlags.m_value & 4) != 0 )
  {
    if ( sound->mNumAudible && !v6 )
    {
      mNodeNext = this->mChannelUsedListHead.mNodeNext;
      p_mNodePrev = 0;
      if ( mNodeNext )
        p_mNodePrev = (FMOD::ChannelI *)&mNodeNext[-16].mNodePrev;
      while ( p_mNodePrev != &this->mChannelUsedListHead )
      {
        v9 = p_mNodePrev->mNodeNext;
        v10 = 0;
        if ( v9 )
          v10 = (FMOD::ChannelI *)&v9[-16].mNodePrev;
        if ( p_mNodePrev->mRealChannel )
        {
          channelsound[0] = 0;
          FMOD::ChannelI::getCurrentSound(p_mNodePrev, channelsound);
          if ( channelsound[0] == sound )
            FMOD::ChannelI::stopEx(p_mNodePrev, 0x53u);
        }
        p_mNodePrev = v10;
      }
    }
    (*((void (__fastcall **)(FMOD::SoundI *, FMOD::SoundI **, _QWORD, _QWORD, _QWORD))sound->_vptr_SoundI + 24))(
      sound,
      channelsound,
      0,
      0,
      0);
    if ( LODWORD(channelsound[0]) != 6 )
    {
      if ( (*sound->_vptr_SoundI)(sound) )
        return FMOD_RESULT::FMOD_OK_0;
      goto LABEL_41;
    }
    result = FMOD::SystemI::flushDSPQueue(this, 1);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( (*sound->_vptr_SoundI)(sound) )
        return FMOD_RESULT::FMOD_OK_0;
LABEL_41:
      _InterlockedAnd((volatile signed __int32 *)&sound->mFlags, 0xFFFFFFFB);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


