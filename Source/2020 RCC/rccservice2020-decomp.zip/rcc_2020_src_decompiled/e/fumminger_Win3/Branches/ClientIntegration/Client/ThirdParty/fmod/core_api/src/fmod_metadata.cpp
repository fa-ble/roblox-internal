// Address: 0x21e7830 | Name: _ZN4FMOD7TagNode4initE12FMOD_TAGTYPEPKcPvj16FMOD_TAGDATATYPE
FMOD_RESULT_0 __fastcall FMOD::TagNode::init(
        FMOD::TagNode *const this,
        FMOD_TAGTYPE type,
        const char *name,
        void *data,
        unsigned int datalen,
        FMOD_TAGDATATYPE datatype)
{
  char *v9; // rax
  unsigned int v10; // r15d
  void *v11; // rax

  v9 = FMOD_strdup(name);
  this->mName = v9;
  if ( !v9 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( datatype == FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING_UTF8
    || datatype == FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_STRING )
  {
    v10 = datalen + 1;
  }
  else
  {
    v10 = datalen + 2;
    if ( (unsigned int)(datatype - 4) > 1 )
      v10 = datalen;
  }
  v11 = FMOD::MemPool::calloc(off_286F358->gSystemMemPool, v10, "../../../core_api/src/fmod_metadata.cpp", 47, 0);
  this->mData[0] = v11;
  if ( !v11 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  memcpy_0(v11, data, datalen);
  this->mDataLen = v10;
  this->mType = type;
  this->mDataType = datatype;
  this->mUpdated = 1;
  this->mUnique = 0;
  this->mCurrentBuffer = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e7920 | Name: _ZN4FMOD7TagNode7releaseEv
FMOD_RESULT_0 __fastcall FMOD::TagNode::release(FMOD::TagNode *const this)
{
  char *mName; // rsi
  void *v2; // rsi

  mName = this->mName;
  if ( mName )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mName, "../../../core_api/src/fmod_metadata.cpp", 80);
    this->mName = 0;
  }
  v2 = this->mData[0];
  if ( v2 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v2, "../../../core_api/src/fmod_metadata.cpp", 88);
    this->mData[0] = 0;
  }
  FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_metadata.cpp", 92);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e79c0 | Name: _ZN4FMOD7TagNode6updateEPvj
FMOD_RESULT_0 __fastcall FMOD::TagNode::update(FMOD::TagNode *const this, void *data, unsigned int datalen)
{
  size_t mDataLen; // rdx
  void *v6; // r12
  void *v7; // rdi
  FMOD_RESULT_0 result; // eax

  mDataLen = this->mDataLen;
  v6 = this->mData[0];
  if ( (_DWORD)mDataLen != datalen || (result = memcmp(this->mData[0], data, mDataLen)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( v6 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v6, "../../../core_api/src/fmod_metadata.cpp", 125);
      this->mData[0] = 0;
    }
    v7 = FMOD::MemPool::alloc(
           off_286F358->gSystemMemPool,
           datalen,
           "../../../core_api/src/fmod_metadata.cpp",
           129,
           0,
           0);
    this->mData[0] = v7;
    result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    if ( v7 )
    {
      memcpy_0(v7, data, datalen);
      this->mDataLen = datalen;
      this->mUpdated = 1;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  else
  {
    this->mUpdated = 1;
  }
  return result;
}


// Address: 0x21e7a90 | Name: _ZN4FMOD8Metadata7releaseEv
FMOD_RESULT_0 __fastcall FMOD::Metadata::release(FMOD::Metadata *const this)
{
  FMOD::Metadata *mNodeNext; // rdi
  FMOD::Metadata *v3; // rbx
  FMOD::LinkedListNode *mNodePrev; // rax

  mNodeNext = (FMOD::Metadata *)this->mList.mNodeNext;
  if ( mNodeNext != this )
  {
    while ( 1 )
    {
      v3 = (FMOD::Metadata *)mNodeNext->mList.mNodeNext;
      mNodePrev = mNodeNext->mList.mNodePrev;
      mNodePrev->mNodeNext = mNodeNext->mList.mNodeNext;
      mNodeNext->mList.mNodeNext->mNodePrev = mNodePrev;
      mNodeNext->mList.mNodePrev = &mNodeNext->mList;
      mNodeNext->mList.mNodeNext = &mNodeNext->mList;
      FMOD::TagNode::release(&mNodeNext->mList);
      if ( v3 == this )
        break;
      mNodeNext = v3;
    }
  }
  FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_metadata.cpp", 166);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e7b00 | Name: _ZN4FMOD8Metadata10getNumTagsEPiS1_
FMOD_RESULT_0 __fastcall FMOD::Metadata::getNumTags(FMOD::Metadata *const this, int *numtags, int *numtagsupdated)
{
  FMOD::Metadata *mNodeNext; // rax
  int v4; // ecx
  int i; // r8d
  bool v6; // cf

  mNodeNext = (FMOD::Metadata *)this->mList.mNodeNext;
  v4 = 0;
  for ( i = 0; mNodeNext != this; v4 -= v6 - 1 )
  {
    ++i;
    v6 = !mNodeNext->mList.mUpdated;
    mNodeNext = (FMOD::Metadata *)mNodeNext->mList.mNodeNext;
  }
  if ( numtags )
    *numtags = i;
  if ( numtagsupdated )
    *numtagsupdated = v4;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e7b40 | Name: _ZN4FMOD8Metadata6getTagEPKciP8FMOD_TAG
FMOD_RESULT_0 __fastcall FMOD::Metadata::getTag(FMOD::Metadata *const this, const char *name, int index, FMOD_TAG *tag)
{
  int v5; // r14d
  FMOD::Metadata *mNodeNext; // rbx
  int v7; // r12d
  FMOD_RESULT_0 result; // eax
  bool mUpdated; // dl
  unsigned int mDataLen; // eax

  v5 = index;
  mNodeNext = (FMOD::Metadata *)this->mList.mNodeNext;
  if ( index < 0 )
  {
    if ( name )
    {
      while ( mNodeNext != this )
      {
        if ( mNodeNext->mList.mUpdated && !FMOD_strcmp(mNodeNext->mList.mName, name) )
          goto LABEL_12;
        mNodeNext = (FMOD::Metadata *)mNodeNext->mList.mNodeNext;
      }
    }
    else
    {
      while ( mNodeNext != this )
      {
        if ( mNodeNext->mList.mUpdated )
        {
          tag->type = mNodeNext->mList.mType;
          tag->datatype = mNodeNext->mList.mDataType;
          tag->name = mNodeNext->mList.mName;
          tag->data = mNodeNext->mList.mData[0];
          mDataLen = mNodeNext->mList.mDataLen;
          tag->updated = 1;
          tag->datalen = mDataLen;
          goto LABEL_13;
        }
        mNodeNext = (FMOD::Metadata *)mNodeNext->mList.mNodeNext;
      }
    }
    return FMOD_RESULT::FMOD_ERR_TAGNOTFOUND_0;
  }
  if ( name )
  {
    if ( mNodeNext != this )
    {
      v7 = 0;
      do
      {
        if ( !FMOD_strcmp(mNodeNext->mList.mName, name) )
        {
          if ( v7 == v5 )
            goto LABEL_12;
          ++v7;
        }
        mNodeNext = (FMOD::Metadata *)mNodeNext->mList.mNodeNext;
      }
      while ( mNodeNext != this );
    }
    return FMOD_RESULT::FMOD_ERR_TAGNOTFOUND_0;
  }
  if ( this == mNodeNext )
    return FMOD_RESULT::FMOD_ERR_TAGNOTFOUND_0;
  if ( index )
  {
    do
    {
      mNodeNext = (FMOD::Metadata *)mNodeNext->mList.mNodeNext;
      if ( this == mNodeNext )
        return FMOD_RESULT::FMOD_ERR_TAGNOTFOUND_0;
    }
    while ( --v5 );
  }
  if ( !mNodeNext )
    return FMOD_RESULT::FMOD_ERR_TAGNOTFOUND_0;
LABEL_12:
  mUpdated = mNodeNext->mList.mUpdated;
  tag->type = mNodeNext->mList.mType;
  tag->datatype = mNodeNext->mList.mDataType;
  tag->name = mNodeNext->mList.mName;
  tag->data = mNodeNext->mList.mData[0];
  tag->datalen = mNodeNext->mList.mDataLen;
  tag->updated = mUpdated;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( mUpdated )
  {
LABEL_13:
    mNodeNext->mList.mUpdated = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e7cf0 | Name: _ZN4FMOD8Metadata3addEPS0_
FMOD_RESULT_0 __fastcall FMOD::Metadata::add(FMOD::Metadata *const this, FMOD::Metadata *metadata)
{
  FMOD::TagNode *mNodeNext; // rbp
  FMOD::Metadata *v3; // r13
  FMOD::LinkedListNode *mNodePrev; // rax
  bool v5; // zf
  FMOD::Metadata *v6; // rbx

  mNodeNext = (FMOD::TagNode *)metadata->mList.mNodeNext;
  if ( (FMOD::Metadata *)metadata->mList.mNodeNext != metadata )
  {
    do
    {
      v3 = (FMOD::Metadata *)mNodeNext->mNodeNext;
      mNodePrev = mNodeNext->mNodePrev;
      v5 = !mNodeNext->mUnique;
      mNodePrev->mNodeNext = mNodeNext->mNodeNext;
      mNodeNext->mNodeNext->mNodePrev = mNodePrev;
      mNodeNext->mNodePrev = mNodeNext;
      mNodeNext->mNodeNext = mNodeNext;
      if ( v5 || (v6 = (FMOD::Metadata *)this->mList.mNodeNext, (FMOD::Metadata *const)this->mList.mNodeNext == this) )
      {
LABEL_10:
        FMOD::Metadata::addTag(this, mNodeNext);
      }
      else
      {
        while ( FMOD_strcmp(v6->mList.mName, mNodeNext->mName) )
        {
          v6 = (FMOD::Metadata *)v6->mList.mNodeNext;
          if ( v6 == this )
            goto LABEL_10;
        }
        FMOD::TagNode::update(&v6->mList, mNodeNext->mData[0], mNodeNext->mDataLen);
        FMOD::TagNode::release(mNodeNext);
      }
      mNodeNext = &v3->mList;
    }
    while ( v3 != metadata );
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e7da0 | Name: _ZN4FMOD8Metadata6addTagE12FMOD_TAGTYPEPKcPvj16FMOD_TAGDATATYPEb
FMOD_RESULT_0 __fastcall FMOD::Metadata::addTag(
        FMOD::Metadata *const this,
        FMOD_TAGTYPE type,
        const char *name,
        void *data,
        unsigned int datalen,
        FMOD_TAGDATATYPE datatype,
        bool unique)
{
  FMOD::Metadata *mNodeNext; // r14
  FMOD_RESULT_0 result; // eax

  if ( unique )
  {
    mNodeNext = (FMOD::Metadata *)this->mList.mNodeNext;
    if ( (FMOD::Metadata *const)this->mList.mNodeNext != this )
    {
      while ( FMOD_strcmp(mNodeNext->mList.mName, name) || mNodeNext->mList.mType != type )
      {
        mNodeNext = (FMOD::Metadata *)mNodeNext->mList.mNodeNext;
        if ( mNodeNext == this )
          goto LABEL_3;
      }
      result = FMOD::TagNode::update(&mNodeNext->mList, data, datalen);
      goto LABEL_10;
    }
  }
LABEL_3:
  mNodeNext = (FMOD::Metadata *)FMOD::MemPool::alloc(
                                  off_286F358->gSystemMemPool,
                                  72,
                                  "../../../core_api/src/fmod_metadata.cpp",
                                  450,
                                  0,
                                  0);
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( mNodeNext )
  {
    mNodeNext->mList.mNodePrev = &mNodeNext->mList;
    mNodeNext->mList.mNodeNext = &mNodeNext->mList;
    mNodeNext->mList.mNodeData = 0;
    mNodeNext->mList.mType = FMOD_TAGTYPE::FMOD_TAGTYPE_UNKNOWN;
    mNodeNext->mList.mDataType = FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_BINARY;
    mNodeNext->mList.mName = 0;
    mNodeNext->mList.mData[1] = 0;
    mNodeNext->mList.mData[0] = 0;
    mNodeNext->mList.mDataLen = 0;
    mNodeNext->mList.mUpdated = 1;
    mNodeNext->mList.mUnique = 0;
    mNodeNext->mList.mCurrentBuffer = 0;
    FMOD::TagNode::init(&mNodeNext->mList, type, name, data, datalen, datatype);
    result = FMOD::Metadata::addTag(this, &mNodeNext->mList);
    if ( unique )
LABEL_10:
      mNodeNext->mList.mUnique = 1;
  }
  return result;
}


