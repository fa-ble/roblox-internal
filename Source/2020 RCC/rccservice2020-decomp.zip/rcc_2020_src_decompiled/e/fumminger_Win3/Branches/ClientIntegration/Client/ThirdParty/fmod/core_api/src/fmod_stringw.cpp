// Address: 0x224e310 | Name: FMOD_strlenW
int __fastcall FMOD_strlenW(const __int16 *s)
{
  const __int16 *v1; // rax
  __int64 v2; // rax

  if ( *s )
  {
    v1 = s;
    do
      ++v1;
    while ( *v1 );
    return (unsigned __int64)((char *)v1 - (char *)s) >> 1;
  }
  else
  {
    LODWORD(v2) = 0;
  }
  return v2;
}


// Address: 0x224e340 | Name: FMOD_strcpyW
__int16 *__fastcall FMOD_strcpyW(__int16 *dest, const __int16 *src)
{
  __int16 *result; // rax
  __int16 *v3; // rdx
  __int16 v4; // cx

  result = dest;
  v3 = dest;
  do
  {
    v4 = *src++;
    *v3++ = v4;
  }
  while ( v4 );
  return result;
}


// Address: 0x224e370 | Name: FMOD_strncpyW
__int16 *__fastcall FMOD_strncpyW(__int16 *dest, const __int16 *src, int count)
{
  __int16 *result; // rax
  unsigned __int64 v4; // rcx
  __int64 v5; // rdx
  __int16 v6; // r8

  result = dest;
  v4 = 0;
  v5 = 2LL * (unsigned int)count;
  do
  {
    if ( v4 == v5 )
      break;
    v6 = src[v4 / 2];
    dest[v4 / 2] = v6;
    v4 += 2LL;
  }
  while ( v6 );
  return result;
}


// Address: 0x224e3a0 | Name: FMOD_strcatW
__int16 *__fastcall FMOD_strcatW(__int16 *dest, const __int16 *src)
{
  __int16 *result; // rax
  __int16 *i; // rdx
  __int16 v4; // cx

  result = dest;
  for ( i = dest; *i; ++i )
    ;
  do
  {
    v4 = *src++;
    *i++ = v4;
  }
  while ( v4 );
  return result;
}


// Address: 0x224e3e0 | Name: FMOD_strncatW
__int16 *__fastcall FMOD_strncatW(__int16 *dest, const __int16 *src, int count)
{
  __int16 *result; // rax
  __int16 *i; // rcx
  __int64 v5; // r8
  __int16 v6; // dx
  __int16 *v7; // r9

  result = dest;
  if ( count )
  {
    for ( i = dest; *i; ++i )
      ;
    v5 = (__int64)&i[count - 1 + 1];
    while ( 1 )
    {
      v6 = *src++;
      v7 = i;
      *i = v6;
      if ( !v6 )
        break;
      if ( ++i == (__int16 *)v5 )
      {
        v7[1] = 0;
        return result;
      }
    }
  }
  return result;
}


// Address: 0x224e440 | Name: FMOD_tolowerW
__int16 __fastcall FMOD_tolowerW(__int16 in)
{
  __int16 result; // ax

  result = in + 32;
  if ( (unsigned __int16)(in - 65) > 0x19u )
    return in;
  return result;
}


// Address: 0x224e450 | Name: FMOD_struprW
__int16 *__fastcall FMOD_struprW(__int16 *string)
{
  __int16 v1; // dx
  __int16 *result; // rax
  __int16 *i; // rcx

  v1 = *string;
  result = string;
  for ( i = string; *i; v1 = *i )
  {
    if ( (unsigned __int16)(v1 - 97) <= 0x19u )
      *i = v1 - 32;
    ++i;
  }
  return result;
}


// Address: 0x224e480 | Name: FMOD_strlwrW
__int16 *__fastcall FMOD_strlwrW(__int16 *string)
{
  __int16 v1; // dx
  __int16 *result; // rax
  __int16 *i; // rcx

  v1 = *string;
  result = string;
  for ( i = string; *i; v1 = *i )
  {
    if ( (unsigned __int16)(v1 - 65) <= 0x19u )
      *i = v1 + 32;
    ++i;
  }
  return result;
}


// Address: 0x224e4b0 | Name: FMOD_strcmpW
int __fastcall FMOD_strcmpW(const __int16 *string1, const __int16 *string2)
{
  int v2; // eax

  do
  {
    ++string1;
    ++string2;
    v2 = *(string1 - 1);
  }
  while ( *(string1 - 1) == *(string2 - 1) && (_WORD)v2 );
  return v2 - *(string2 - 1);
}


// Address: 0x224e4d0 | Name: FMOD_strncmpW
int __fastcall FMOD_strncmpW(const __int16 *string1, const __int16 *string2, int len)
{
  __int64 v3; // rcx
  int v4; // eax
  int v5; // r8d

  v3 = 0;
  do
  {
    v4 = string1[v3];
    v5 = string2[v3];
    if ( string1[v3] != string2[v3] )
      break;
    if ( !(_WORD)v4 )
      break;
    ++v3;
  }
  while ( len > (int)v3 );
  return v4 - v5;
}


// Address: 0x224e500 | Name: FMOD_stricmpW
int __fastcall FMOD_stricmpW(const __int16 *string1, const __int16 *string2)
{
  int v4; // r12d
  __int16 v5; // ax

  do
  {
    ++string1;
    ++string2;
    v4 = FMOD_tolowerW(*(string1 - 1));
    v5 = FMOD_tolowerW(*(string2 - 1));
  }
  while ( (_WORD)v4 == v5 && (_WORD)v4 );
  return v4 - v5;
}


// Address: 0x224e550 | Name: FMOD_strnicmpW
int __fastcall FMOD_strnicmpW(const __int16 *string1, const __int16 *string2, int len)
{
  __int64 v4; // rbx
  int v5; // ebp
  __int16 v6; // ax

  v4 = 0;
  do
  {
    v5 = FMOD_tolowerW(string1[v4]);
    v6 = FMOD_tolowerW(string2[v4]);
    if ( (_WORD)v5 != v6 )
      break;
    if ( !(_WORD)v5 )
      break;
    ++v4;
  }
  while ( len > (int)v4 );
  return v5 - v6;
}


// Address: 0x224e5b0 | Name: FMOD_strchrW
__int16 *__fastcall FMOD_strchrW(const __int16 *string, int c)
{
  __int16 *v2; // rbx
  int v3; // eax

  v2 = (__int16 *)string;
  v3 = FMOD_strlenW(string);
  if ( !v3 )
    return 0;
  while ( 1 )
  {
    --v3;
    if ( *v2 == c )
      break;
    ++v2;
    if ( !v3 )
      return 0;
  }
  return v2;
}


// Address: 0x224e600 | Name: FMOD_strstrW
__int16 *__fastcall FMOD_strstrW(const __int16 *s1, const __int16 *s2)
{
  const __int16 *v2; // rbx
  int v3; // r12d
  __int16 *result; // rax
  int v5; // ebp

  v2 = s1;
  v3 = FMOD_strlenW(s2);
  result = (__int16 *)s1;
  if ( v3 )
  {
    v5 = FMOD_strlenW(s1);
    if ( v3 > v5 )
    {
      return 0;
    }
    else
    {
      while ( 1 )
      {
        --v5;
        if ( !memcmp(v2, s2, v3) )
          break;
        ++v2;
        if ( v3 > v5 )
          return 0;
      }
      return (__int16 *)v2;
    }
  }
  return result;
}


// Address: 0x224e690 | Name: FMOD_strdupW
__int16 *__fastcall FMOD_strdupW(const __int16 *src)
{
  int v1; // eax
  __int16 *v2; // rax
  __int16 *v3; // rbx

  v1 = FMOD_strlenW(src);
  v2 = (__int16 *)FMOD::MemPool::alloc(
                    off_286F358->gSystemMemPool,
                    2 * v1 + 2,
                    "../../../core_api/src/fmod_stringw.cpp",
                    202,
                    0,
                    0);
  v3 = v2;
  if ( v2 )
    FMOD_strcpyW(v2, src);
  return v3;
}


// Address: 0x224e6f0 | Name: FMOD_eatwhiteW
__int16 *__fastcall FMOD_eatwhiteW(const __int16 *string)
{
  __int16 v1; // dx
  __int16 *result; // rax

  v1 = *string;
  for ( result = (__int16 *)string; *result; v1 = *result )
  {
    if ( (unsigned __int16)(v1 - 9) > 1u && v1 != 32 )
      break;
    ++result;
  }
  return result;
}


// Address: 0x224e730 | Name: FMOD_atoiW
int __fastcall FMOD_atoiW(const __int16 *s)
{
  const __int16 *i; // rdx
  const __int16 *v2; // rdx
  int v3; // ecx
  int result; // eax
  int v5; // esi
  int v6; // esi

  if ( !s )
    return 0;
  for ( i = s; *i; ++i )
    ;
  v2 = i - 1;
  if ( s > v2 )
    return 0;
  v3 = 1;
  result = 0;
  do
  {
    v5 = *v2--;
    v6 = v3 * (v5 - 48);
    v3 *= 10;
    result += v6;
  }
  while ( s <= v2 );
  return result;
}


// Address: 0x224e790 | Name: FMOD_wtoa
char *__fastcall FMOD_wtoa(__int16 *s)
{
  char v1; // dl
  __int16 *v2; // rcx
  __int16 *v3; // rsi

  if ( !s )
    return 0;
  v1 = *(_BYTE *)s;
  v2 = s;
  if ( *(_BYTE *)s )
  {
    v3 = s;
    do
    {
      ++v3;
      *(_BYTE *)v2 = v1;
      v2 = (__int16 *)((char *)v2 + 1);
      v1 = *(_BYTE *)v3;
    }
    while ( *(_BYTE *)v3 );
  }
  *(_BYTE *)v2 = 0;
  return (char *)s;
}


// Address: 0x224e7d0 | Name: FMOD_atow
__int16 *__fastcall FMOD_atow(char *s, int len)
{
  int v2; // eax
  char *v3; // rcx
  char *v4; // rdx
  char v5; // si

  if ( !s )
    return 0;
  v2 = FMOD_strlen(s);
  if ( 2 * v2 + 2 > len )
    return 0;
  if ( v2 >= 0 )
  {
    v3 = &s[v2];
    v4 = &s[2 * v2 + 1];
    do
    {
      v5 = *v3--;
      *v4 = 0;
      v4 -= 2;
      v4[1] = v5;
    }
    while ( v3 != s - 1 );
  }
  return (__int16 *)s;
}


