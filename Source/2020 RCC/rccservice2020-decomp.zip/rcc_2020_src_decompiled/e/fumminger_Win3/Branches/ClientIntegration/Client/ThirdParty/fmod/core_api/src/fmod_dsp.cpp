// Address: 0x2230020 | Name: _ZN4FMOD3DSP7releaseEv
FMOD_RESULT_0 __fastcall FMOD::DSP::release(FMOD::DSP *const this)
{
  FMOD_RESULT_0 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v1
     || (v1 = (*((unsigned int (__fastcall **)(FMOD::DSPI *))dspi->_vptr_DSPI + 2))(dspi)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      v1,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::release",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x22300c0 | Name: _ZN4FMOD3DSP15getSystemObjectEPPNS_6SystemE
FMOD_RESULT_0 __fastcall FMOD::DSP::getSystemObject(FMOD::DSP *const this, FMOD::System **system)
{
  FMOD_RESULT_0 SystemObject; // ebx
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  SystemObject = FMOD::DSPI::validate(this, &dspi, 0);
  if ( SystemObject == FMOD_RESULT::FMOD_OK_0 )
  {
    SystemObject = FMOD::DSPI::getSystemObject(dspi, system);
    if ( SystemObject == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, system);
    FMOD_ReportError(
      SystemObject,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getSystemObject",
      _buffer);
  }
  return SystemObject;
}


// Address: 0x2230180 | Name: _ZN4FMOD3DSP8addInputEPS0_PPNS_13DSPConnectionE23FMOD_DSPCONNECTION_TYPE
FMOD_RESULT_0 __fastcall FMOD::DSP::addInput(
        FMOD::DSP *const this,
        FMOD::DSP *input,
        FMOD::DSPConnection **connection,
        FMOD_DSPCONNECTION_TYPE_1 type)
{
  FMOD_RESULT_0 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v6
     || (v6 = FMOD::DSPI::addInput(dspi, (FMOD::DSPI *)input, (FMOD::DSPConnectionI **)connection, type, 1, 0)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, input);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), connection);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), type);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::addInput",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x22302e0 | Name: _ZN4FMOD3DSP14disconnectFromEPS0_PNS_13DSPConnectionE
FMOD_RESULT_0 __fastcall FMOD::DSP::disconnectFrom(
        FMOD::DSP *const this,
        FMOD::DSP *target,
        FMOD::DSPConnection *connection)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v4
     || (v4 = FMOD::DSPI::disconnectFrom(
                dspi,
                (FMOD::DSPI *)target,
                (FMOD::DSPConnectionI *)connection,
                FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, target);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), connection);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::disconnectFrom",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x22303f0 | Name: _ZN4FMOD3DSP13disconnectAllEbb
FMOD_RESULT_0 __fastcall FMOD::DSP::disconnectAll(FMOD::DSP *const this, bool inputs, bool outputs)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v4 || (v4 = FMOD::DSPI::disconnectAll(dspi, inputs, outputs)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, inputs);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), outputs);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::disconnectAll",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x2230500 | Name: _ZN4FMOD3DSP12getNumInputsEPi
FMOD_RESULT_0 __fastcall FMOD::DSP::getNumInputs(FMOD::DSP *const this, int *numinputs)
{
  FMOD_RESULT_0 NumInputsInternal; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  NumInputsInternal = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (NumInputsInternal
     || (NumInputsInternal = FMOD::DSPI::getNumInputsInternal(dspi, numinputs, 0, 1)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numinputs);
    FMOD_ReportError(
      NumInputsInternal,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getNumInputs",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return NumInputsInternal;
}


// Address: 0x22305b0 | Name: _ZN4FMOD3DSP13getNumOutputsEPi
FMOD_RESULT_0 __fastcall FMOD::DSP::getNumOutputs(FMOD::DSP *const this, int *numoutputs)
{
  FMOD_RESULT_0 NumOutputsInternal; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  NumOutputsInternal = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (NumOutputsInternal
     || (NumOutputsInternal = FMOD::DSPI::getNumOutputsInternal(dspi, numoutputs, 0, 1)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numoutputs);
    FMOD_ReportError(
      NumOutputsInternal,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getNumOutputs",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return NumOutputsInternal;
}


// Address: 0x2230660 | Name: _ZN4FMOD3DSP8getInputEiPPS0_PPNS_13DSPConnectionE
FMOD_RESULT_0 __fastcall FMOD::DSP::getInput(
        FMOD::DSP *const this,
        int index,
        FMOD::DSP **input,
        FMOD::DSPConnection **inputconnection)
{
  FMOD_RESULT_0 InputInternal; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  InputInternal = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (InputInternal
     || (InputInternal = FMOD::DSPI::getInputInternal(
                           dspi,
                           index,
                           (FMOD::DSPI **)input,
                           (FMOD::DSPConnectionI **)inputconnection,
                           0,
                           1)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), input);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), inputconnection);
    FMOD_ReportError(
      InputInternal,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getInput",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return InputInternal;
}


// Address: 0x22307c0 | Name: _ZN4FMOD3DSP9getOutputEiPPS0_PPNS_13DSPConnectionE
FMOD_RESULT_0 __fastcall FMOD::DSP::getOutput(
        FMOD::DSP *const this,
        int index,
        FMOD::DSP **output,
        FMOD::DSPConnection **outputconnection)
{
  FMOD_RESULT_0 OutputInternal; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  OutputInternal = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (OutputInternal
     || (OutputInternal = FMOD::DSPI::getOutputInternal(
                            dspi,
                            index,
                            (FMOD::DSPI **)output,
                            (FMOD::DSPConnectionI **)outputconnection,
                            0,
                            1)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), output);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), outputconnection);
    FMOD_ReportError(
      OutputInternal,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getOutput",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return OutputInternal;
}


// Address: 0x2230920 | Name: _ZN4FMOD3DSP9setActiveEb
FMOD_RESULT_0 __fastcall FMOD::DSP::setActive(FMOD::DSP *const this, bool active)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v2 || (v2 = FMOD::DSPI::setActive(dspi, active, 1)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, active);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::setActive",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x22309e0 | Name: _ZN4FMOD3DSP9getActiveEPb
FMOD_RESULT_0 __fastcall FMOD::DSP::getActive(FMOD::DSP *const this, bool *active)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( active )
    {
      *active = (dspi->mJob.mFlags & 0x200) != 0;
      goto LABEL_4;
    }
    v2 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, active);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getActive",
      _buffer);
  }
LABEL_4:
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x2230a90 | Name: _ZN4FMOD3DSP9setBypassEb
FMOD_RESULT_0 __fastcall FMOD::DSP::setBypass(FMOD::DSP *const this, bool bypass)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v2 || (v2 = FMOD::DSPI::setBypass(dspi, bypass)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, bypass);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::setBypass",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x2230b40 | Name: _ZN4FMOD3DSP9getBypassEPb
FMOD_RESULT_0 __fastcall FMOD::DSP::getBypass(FMOD::DSP *const this, bool *bypass)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( bypass )
    {
      *bypass = dspi->mJob.mFlags & 1;
      *bypass = *bypass;
      goto LABEL_4;
    }
    v2 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, bypass);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getBypass",
      _buffer);
  }
LABEL_4:
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x2230bf0 | Name: _ZN4FMOD3DSP12setWetDryMixEfff
__int64 __fastcall FMOD::DSP::setWetDryMix(FMOD::DSP *const this, float a2, float prewet, float postwet, float dry)
{
  FMOD_RESULT_0 v5; // ebx
  int v7; // r14d
  int v8; // r14d
  int v9; // r14d
  int v10; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v5 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v5
     || (v5 = (unsigned int)FMOD::DSPI::setWetDryMix(dspi, a2, (__m128i)LODWORD(prewet), (__m128i)LODWORD(postwet), dry)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v7 = FMOD::FMOD_FormatArg(_buffer, 256, prewet);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v7], 256 - v7, ", ") + v7;
    v9 = FMOD::FMOD_FormatArg(&_buffer[v8], 256 - v8, prewet) + v8;
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), prewet);
    FMOD_ReportError(
      v5,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::setWetDryMix",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v5;
}


// Address: 0x2230d50 | Name: _ZN4FMOD3DSP12getWetDryMixEPfS1_S1_
FMOD_RESULT_0 __fastcall FMOD::DSP::getWetDryMix(FMOD::DSP *const this, float *prewet, float *postwet, float *dry)
{
  FMOD_RESULT_0 WetDryMix; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  WetDryMix = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (WetDryMix || (WetDryMix = FMOD::DSPI::getWetDryMix(dspi, prewet, postwet, dry)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, prewet);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), postwet);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), dry);
    FMOD_ReportError(
      WetDryMix,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getWetDryMix",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return WetDryMix;
}


// Address: 0x2230ea0 | Name: _ZN4FMOD3DSP16setChannelFormatEji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSP::setChannelFormat(
        FMOD::DSP *const this,
        FMOD_CHANNELMASK channelmask,
        int numchannels,
        FMOD_SPEAKERMODE_1 source_speakermode)
{
  FMOD_RESULT_0 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v6
     || (v6 = FMOD::DSPI::setChannelFormat(dspi, channelmask, numchannels, source_speakermode)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, channelmask);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), numchannels);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), source_speakermode);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::setChannelFormat",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x2230ff0 | Name: _ZN4FMOD3DSP16getChannelFormatEPjPiP16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSP::getChannelFormat(
        FMOD::DSP *const this,
        FMOD_CHANNELMASK *channelmask,
        int *numchannels,
        FMOD_SPEAKERMODE_1 *source_speakermode)
{
  FMOD_RESULT_0 ChannelFormat; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  ChannelFormat = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (ChannelFormat
     || (ChannelFormat = FMOD::DSPI::getChannelFormat(dspi, channelmask, numchannels, source_speakermode)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, channelmask);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), numchannels);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), source_speakermode);
    FMOD_ReportError(
      ChannelFormat,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getChannelFormat",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return ChannelFormat;
}


// Address: 0x2231140 | Name: _ZN4FMOD3DSP22getOutputChannelFormatEji16FMOD_SPEAKERMODEPjPiPS1_
FMOD_RESULT_0 __fastcall FMOD::DSP::getOutputChannelFormat(
        FMOD::DSP *const this,
        FMOD_CHANNELMASK inmask,
        int inchannels,
        FMOD_SPEAKERMODE_1 inspeakermode,
        FMOD_CHANNELMASK *outmask,
        int *outchannels,
        FMOD_SPEAKERMODE_1 *outspeakermode)
{
  FMOD_RESULT_0 OutputChannelFormat; // r12d
  int v12; // eax
  int v13; // r15d
  int v14; // r15d
  int v15; // r15d
  int v16; // r15d
  int v17; // r14d
  int v18; // r14d
  int v19; // r13d
  int v20; // eax
  int v22; // [rsp+1Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+20h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+28h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+30h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  OutputChannelFormat = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (OutputChannelFormat
     || (OutputChannelFormat = FMOD::DSPI::getOutputChannelFormat(
                                 dspi,
                                 inmask,
                                 inchannels,
                                 inspeakermode,
                                 outmask,
                                 outchannels,
                                 outspeakermode)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v22 = FMOD::FMOD_FormatArg(_buffer, 256, inmask);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v22], 256 - v22, ", ");
    v13 = v12 + v22 + FMOD::FMOD_FormatArg(&_buffer[v12 + v22], 256 - (v12 + v22), inchannels);
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ") + v13;
    v15 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, inspeakermode) + v14;
    v16 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ") + v15;
    v17 = v16 + FMOD::FMOD_FormatArg(&_buffer[v16], 256 - v16, outmask);
    v18 = FMOD::FMOD_FormatArg(&_buffer[v17], 256 - v17, ", ") + v17;
    v19 = v18 + FMOD::FMOD_FormatArg(&_buffer[v18], 256 - v18, outchannels);
    v20 = FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v20 + v19], 256 - (v20 + v19), outspeakermode);
    FMOD_ReportError(
      OutputChannelFormat,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getOutputChannelFormat",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return OutputChannelFormat;
}


// Address: 0x2231340 | Name: _ZN4FMOD3DSP5resetEv
FMOD_RESULT_0 __fastcall FMOD::DSP::reset(FMOD::DSP *const this)
{
  FMOD_RESULT_0 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v1 || (v1 = FMOD::DSPI::reset(dspi)) != FMOD_RESULT::FMOD_OK_0) && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      v1,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::reset",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x22313e0 | Name: _ZN4FMOD3DSP17setParameterFloatEif
__int64 __fastcall FMOD::DSP::setParameterFloat(FMOD::DSP *const this, int index, float a3, double value)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  v4 = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (v4 || (v4 = FMOD::DSPI::setParameterFloat(dspi, index, (__m128i)LODWORD(a3), value)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), *(float *)&value);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::setParameterFloat",
      _buffer);
  }
  return (unsigned int)v4;
}


// Address: 0x22314e0 | Name: _ZN4FMOD3DSP15setParameterIntEii
FMOD_RESULT_0 __fastcall FMOD::DSP::setParameterInt(FMOD::DSP *const this, int index, int value)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  v4 = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (v4 || (v4 = FMOD::DSPI::setParameterInt(dspi, index, value)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), value);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::setParameterInt",
      _buffer);
  }
  return v4;
}


// Address: 0x22315c0 | Name: _ZN4FMOD3DSP16setParameterBoolEib
FMOD_RESULT_0 __fastcall FMOD::DSP::setParameterBool(FMOD::DSP *const this, int index, bool value)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  v4 = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (v4 || (v4 = FMOD::DSPI::setParameterBool(dspi, index, value)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), value);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::setParameterBool",
      _buffer);
  }
  return v4;
}


// Address: 0x22316b0 | Name: _ZN4FMOD3DSP16setParameterDataEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSP::setParameterData(FMOD::DSP *const this, int index, void *data, unsigned int length)
{
  FMOD_RESULT_0 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  v6 = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (v6 || (v6 = FMOD::DSPI::setParameterData(dspi, index, data, length)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), data);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), length);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::setParameterData",
      _buffer);
  }
  return v6;
}


// Address: 0x22317f0 | Name: _ZN4FMOD3DSP17getParameterFloatEiPfPci
FMOD_RESULT_0 __fastcall FMOD::DSP::getParameterFloat(
        FMOD::DSP *const this,
        int index,
        float *value,
        char *valuestr,
        int valuestrlen)
{
  FMOD_RESULT_0 ParameterFloat; // r9d
  int v10; // eax
  int v11; // r15d
  int v12; // r15d
  int v13; // r14d
  int v14; // eax
  int v15; // [rsp+8h] [rbp-150h]
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-14Ch]
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  ParameterFloat = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (ParameterFloat
     || (ParameterFloat = FMOD::DSPI::getParameterFloat(dspi, index, value, valuestr, valuestrlen)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = ParameterFloat;
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v11 = v10 + v15 + FMOD::FMOD_FormatArg(&_buffer[v10 + v15], 256 - (v10 + v15), value);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ") + v11;
    v13 = v12 + FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, valuestr);
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v14 + v13], 256 - (v14 + v13), valuestrlen);
    FMOD_ReportError(
      __result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getParameterFloat",
      _buffer);
    return __result;
  }
  return ParameterFloat;
}


// Address: 0x2231970 | Name: _ZN4FMOD3DSP15getParameterIntEiPiPci
FMOD_RESULT_0 __fastcall FMOD::DSP::getParameterInt(
        FMOD::DSP *const this,
        int index,
        int *value,
        char *valuestr,
        int valuestrlen)
{
  FMOD_RESULT_0 ParameterInt; // r9d
  int v10; // eax
  int v11; // r15d
  int v12; // r15d
  int v13; // r14d
  int v14; // eax
  int v15; // [rsp+8h] [rbp-150h]
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-14Ch]
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  ParameterInt = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (ParameterInt
     || (ParameterInt = FMOD::DSPI::getParameterInt(dspi, index, value, valuestr, valuestrlen)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = ParameterInt;
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v11 = v10 + v15 + FMOD::FMOD_FormatArg(&_buffer[v10 + v15], 256 - (v10 + v15), value);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ") + v11;
    v13 = v12 + FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, valuestr);
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v14 + v13], 256 - (v14 + v13), valuestrlen);
    FMOD_ReportError(
      __result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getParameterInt",
      _buffer);
    return __result;
  }
  return ParameterInt;
}


// Address: 0x2231af0 | Name: _ZN4FMOD3DSP16getParameterBoolEiPbPci
FMOD_RESULT_0 __fastcall FMOD::DSP::getParameterBool(
        FMOD::DSP *const this,
        int index,
        bool *value,
        char *valuestr,
        int valuestrlen)
{
  FMOD_RESULT_0 ParameterBool; // r9d
  int v10; // eax
  int v11; // r15d
  int v12; // r15d
  int v13; // r14d
  int v14; // eax
  int v15; // [rsp+8h] [rbp-150h]
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-14Ch]
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  ParameterBool = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (ParameterBool
     || (ParameterBool = FMOD::DSPI::getParameterBool(dspi, index, value, valuestr, valuestrlen)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = ParameterBool;
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v11 = v10 + v15 + FMOD::FMOD_FormatArg(&_buffer[v10 + v15], 256 - (v10 + v15), value);
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ") + v11;
    v13 = v12 + FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, valuestr);
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v14 + v13], 256 - (v14 + v13), valuestrlen);
    FMOD_ReportError(
      __result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getParameterBool",
      _buffer);
    return __result;
  }
  return ParameterBool;
}


// Address: 0x2231c70 | Name: _ZN4FMOD3DSP16getParameterDataEiPPvPjPci
FMOD_RESULT_0 __fastcall FMOD::DSP::getParameterData(
        FMOD::DSP *const this,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr,
        int valuestrlen)
{
  FMOD_RESULT_0 ParameterData; // r9d
  int v11; // eax
  int v12; // r15d
  int v13; // r15d
  int v14; // r15d
  int v15; // r15d
  int v16; // r14d
  int v17; // eax
  int v19; // [rsp+8h] [rbp-150h]
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-14Ch]
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  ParameterData = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (ParameterData
     || (ParameterData = FMOD::DSPI::getParameterData(dspi, index, data, length, valuestr, valuestrlen)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = ParameterData;
    v19 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, ", ");
    v12 = v11 + v19 + FMOD::FMOD_FormatArg(&_buffer[v11 + v19], 256 - (v11 + v19), data);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ") + v12;
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, length) + v13;
    v15 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, ", ") + v14;
    v16 = v15 + FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, valuestr);
    v17 = FMOD::FMOD_FormatArg(&_buffer[v16], 256 - v16, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v17 + v16], 256 - (v17 + v16), valuestrlen);
    FMOD_ReportError(
      __result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getParameterData",
      _buffer);
    return __result;
  }
  return ParameterData;
}


// Address: 0x2231e30 | Name: _ZN4FMOD3DSP16getNumParametersEPi
FMOD_RESULT_0 __fastcall FMOD::DSP::getNumParameters(FMOD::DSP *const this, int *numparams)
{
  FMOD_RESULT_0 NumParameters; // ebx
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  NumParameters = FMOD::DSPI::validate(this, &dspi, 0);
  if ( NumParameters == FMOD_RESULT::FMOD_OK_0 )
  {
    NumParameters = FMOD::DSPI::getNumParameters(dspi, numparams);
    if ( NumParameters == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numparams);
    FMOD_ReportError(
      NumParameters,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getNumParameters",
      _buffer);
  }
  return NumParameters;
}


// Address: 0x2231ef0 | Name: _ZN4FMOD3DSP16getParameterInfoEiPP23FMOD_DSP_PARAMETER_DESC
FMOD_RESULT_0 __fastcall FMOD::DSP::getParameterInfo(FMOD::DSP *const this, int index, FMOD_DSP_PARAMETER_DESC **desc)
{
  FMOD_RESULT_0 ParameterInfo; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  ParameterInfo = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (ParameterInfo || (ParameterInfo = FMOD::DSPI::getParameterInfo(dspi, index, desc)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), desc);
    FMOD_ReportError(
      ParameterInfo,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getParameterInfo",
      _buffer);
  }
  return ParameterInfo;
}


// Address: 0x2231fd0 | Name: _ZN4FMOD3DSP21getDataParameterIndexEiPi
FMOD_RESULT_0 __fastcall FMOD::DSP::getDataParameterIndex(FMOD::DSP *const this, int datatype, int *index)
{
  FMOD_RESULT_0 DataParameterIndex; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  DataParameterIndex = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (DataParameterIndex
     || (DataParameterIndex = FMOD::DSPI::getDataParameterIndex(dspi, datatype, index)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, datatype);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), index);
    FMOD_ReportError(
      DataParameterIndex,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getDataParameterIndex",
      _buffer);
  }
  return DataParameterIndex;
}


// Address: 0x22320b0 | Name: _ZN4FMOD3DSP16showConfigDialogEPvb
FMOD_RESULT_0 __fastcall FMOD::DSP::showConfigDialog(FMOD::DSP *const this, void *hwnd, bool show)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v4 || (v4 = FMOD::DSPI::showConfigDialog(dspi, hwnd, show)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, hwnd);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), show);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::showConfigDialog",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x22321b0 | Name: _ZN4FMOD3DSP7getInfoEPcPjPiS3_S3_
FMOD_RESULT_0 __fastcall FMOD::DSP::getInfo(
        FMOD::DSP *const this,
        char *name,
        unsigned int *version,
        int *channels,
        int *configwidth,
        int *configheight)
{
  FMOD_RESULT_0 Info; // r9d
  int v11; // eax
  int v12; // r15d
  int v13; // r15d
  int v14; // r15d
  int v15; // r15d
  int v16; // r14d
  int v17; // eax
  int v19; // [rsp+8h] [rbp-150h]
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-14Ch]
  FMOD::DSPI *dspi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  Info = FMOD::DSPI::validate(this, &dspi, 0);
  if ( (Info
     || (Info = FMOD::DSPI::getInfo(dspi, name, version, channels, configwidth, configheight)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = Info;
    v19 = FMOD::FMOD_FormatArg(_buffer, 256, name);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, ", ");
    v12 = v11 + v19 + FMOD::FMOD_FormatArg(&_buffer[v11 + v19], 256 - (v11 + v19), version);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ") + v12;
    v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, channels) + v13;
    v15 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, ", ") + v14;
    v16 = v15 + FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, configwidth);
    v17 = FMOD::FMOD_FormatArg(&_buffer[v16], 256 - v16, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v17 + v16], 256 - (v17 + v16), configheight);
    FMOD_ReportError(
      __result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getInfo",
      _buffer);
    return __result;
  }
  return Info;
}


// Address: 0x2232370 | Name: _ZN4FMOD3DSP7getTypeEP13FMOD_DSP_TYPE
__int64 __fastcall FMOD::DSP::getType(FMOD::DSP *this, FMOD_DSP_TYPE *a2)
{
  FMOD_RESULT_0 Type; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  Type = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (Type || (Type = (unsigned int)FMOD::DSPI::getType(dspi, a2)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, a2);
    FMOD_ReportError(
      Type,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getType",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)Type;
}


// Address: 0x2232420 | Name: _ZN4FMOD3DSP7getIdleEPb
FMOD_RESULT_0 __fastcall FMOD::DSP::getIdle(FMOD::DSP *const this, bool *idle)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v2 || (v2 = FMOD::DSPI::getIdle(dspi, idle)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, idle);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getIdle",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x22324d0 | Name: _ZN4FMOD3DSP11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::DSP::setUserData(FMOD::DSP *const this, void *_userdata)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::DSPI::validate(this, &dspi, 0);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = FMOD::DSPI::setUserData(dspi, _userdata);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::setUserData",
      _buffer);
  }
  return v2;
}


// Address: 0x2232590 | Name: _ZN4FMOD3DSP11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::DSP::getUserData(FMOD::DSP *const this, void **_userdata)
{
  FMOD_RESULT_0 UserData; // ebx
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  UserData = FMOD::DSPI::validate(this, &dspi, 0);
  if ( UserData == FMOD_RESULT::FMOD_OK_0 )
  {
    UserData = FMOD::DSPI::getUserData(dspi, _userdata);
    if ( UserData == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      UserData,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getUserData",
      _buffer);
  }
  return UserData;
}


// Address: 0x2232650 | Name: _ZN4FMOD3DSP18setMeteringEnabledEbb
FMOD_RESULT_0 __fastcall FMOD::DSP::setMeteringEnabled(FMOD::DSP *const this, bool inputEnabled, bool outputEnabled)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (v4 || (v4 = FMOD::DSPI::setMeteringEnabled(dspi, inputEnabled, outputEnabled)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, inputEnabled);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), outputEnabled);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::setMeteringEnabled",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x2232760 | Name: _ZN4FMOD3DSP18getMeteringEnabledEPbS1_
FMOD_RESULT_0 __fastcall FMOD::DSP::getMeteringEnabled(FMOD::DSP *const this, bool *inputEnabled, bool *outputEnabled)
{
  FMOD_RESULT_0 MeteringEnabled; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  MeteringEnabled = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (MeteringEnabled
     || (MeteringEnabled = FMOD::DSPI::getMeteringEnabled(dspi, inputEnabled, outputEnabled)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, inputEnabled);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), outputEnabled);
    FMOD_ReportError(
      MeteringEnabled,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getMeteringEnabled",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return MeteringEnabled;
}


// Address: 0x2232860 | Name: _ZN4FMOD3DSP15getMeteringInfoEP22FMOD_DSP_METERING_INFOS2_
FMOD_RESULT_0 __fastcall FMOD::DSP::getMeteringInfo(
        FMOD::DSP *const this,
        FMOD_DSP_METERING_INFO_1 *inputInfo,
        FMOD_DSP_METERING_INFO_1 *outputInfo)
{
  FMOD_RESULT_0 MeteringInfo; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  MeteringInfo = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (MeteringInfo
     || (MeteringInfo = FMOD::DSPI::getMeteringInfo(dspi, inputInfo, outputInfo)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, inputInfo);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), outputInfo);
    FMOD_ReportError(
      MeteringInfo,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getMeteringInfo",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return MeteringInfo;
}


// Address: 0x2232960 | Name: _ZN4FMOD3DSP11getCPUUsageEPjS1_
FMOD_RESULT_0 __fastcall FMOD::DSP::getCPUUsage(
        FMOD::DSP *const this,
        unsigned int *exclusive,
        unsigned int *inclusive)
{
  FMOD_RESULT_0 CPUUsage; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  CPUUsage = FMOD::DSPI::validate(this, &dspi, &lockScope);
  if ( (CPUUsage || (CPUUsage = FMOD::DSPI::getCPUUsage(dspi, exclusive, inclusive)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, exclusive);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), inclusive);
    FMOD_ReportError(
      CPUUsage,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
      this,
      "DSP::getCPUUsage",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return CPUUsage;
}


