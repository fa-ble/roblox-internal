// Address: 0x223cc40 | Name: _ZN4FMOD10DSPThreeEQ14processAndRampEPfS1_ji
FMOD_RESULT_0 __fastcall FMOD::DSPThreeEQ::processAndRamp(
        FMOD::DSPThreeEQ *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int channels)
{
  float v5; // xmm0_4
  float v6; // xmm0_4
  float v7; // xmm0_4
  float v8; // xmm0_4
  float v9; // xmm0_4
  float v10; // xmm0_4
  float v11; // xmm0_4
  float v12; // xmm0_4
  float v13; // xmm0_4
  int v14; // eax
  int v15; // eax
  float v16; // xmm1_4
  float v17; // xmm0_4
  float v18; // xmm3_4
  float v19; // xmm2_4
  int v20; // eax
  int v21; // eax
  float v22; // xmm1_4
  float v23; // xmm0_4
  float v24; // xmm3_4
  float v25; // xmm2_4
  int v26; // eax
  int v27; // eax
  float v28; // xmm1_4
  float v29; // xmm0_4
  float v30; // xmm3_4
  float v31; // xmm2_4
  int v32; // eax
  int v33; // eax
  float v34; // xmm1_4
  float v35; // xmm0_4
  float v36; // xmm3_4
  float v37; // xmm2_4
  int v38; // eax
  int v39; // eax
  float v40; // xmm1_4
  float v41; // xmm0_4
  float v42; // xmm3_4
  float v43; // xmm2_4
  int v44; // eax
  int v45; // eax
  float v46; // xmm1_4
  float v47; // xmm0_4
  float v48; // xmm3_4
  float v49; // xmm2_4
  int v50; // eax
  int v51; // eax
  float v52; // xmm1_4
  float v53; // xmm0_4
  float v54; // xmm3_4
  float v55; // xmm2_4
  int v56; // eax
  int v57; // eax
  float v58; // xmm1_4
  float v59; // xmm0_4
  float v60; // xmm3_4
  float v61; // xmm2_4
  int v62; // r10d
  int v63; // r9d
  float v64; // xmm4_4
  float v65; // xmm3_4
  float v66; // xmm1_4
  char *v67; // r11
  float *v68; // rbx
  float v69; // xmm11_4
  float v70; // xmm12_4
  float v71; // xmm0_4
  float v72; // xmm3_4
  float v73; // xmm11_4
  float v74; // xmm0_4
  float v75; // xmm3_4
  char *v76; // r11
  float v77; // xmm3_4
  float *v78; // rbx
  float v79; // xmm13_4
  float v80; // xmm12_4
  float v81; // xmm3_4
  float v82; // xmm14_4
  float v83; // xmm0_4
  float v84; // xmm13_4
  float v85; // xmm2_4
  float v86; // xmm0_4
  char *v87; // r11
  char *v88; // rax
  float *v89; // rbx
  float v90; // xmm0_4
  float v91; // xmm13_4
  float v92; // xmm14_4
  float v93; // xmm2_4
  float v94; // xmm13_4
  float v95; // xmm0_4
  float v96; // xmm2_4
  float v97; // xmm11_4
  float *v98; // r11
  float v99; // xmm2_4
  float v100; // xmm14_4
  float v101; // xmm15_4
  float v102; // xmm0_4
  float v103; // xmm14_4
  float v104; // xmm4_4
  float v105; // xmm0_4
  float v106; // xmm12_4
  float v107; // xmm2_4
  char *v108; // r11
  float *v109; // rbx
  float v110; // xmm4_4
  float v111; // xmm11_4
  float v112; // xmm0_4
  float v113; // xmm4_4
  float v114; // xmm1_4
  float v115; // xmm0_4
  char *v116; // r11
  float v117; // xmm0_4
  float *v118; // rbx
  float v119; // xmm3_4
  float v120; // xmm11_4
  float v121; // xmm0_4
  float v122; // xmm4_4
  float v123; // xmm3_4
  float v124; // xmm0_4
  float v125; // xmm4_4
  char *v126; // r11
  float *v127; // rbx
  float v128; // xmm13_4
  float v129; // xmm4_4
  float v130; // xmm11_4
  float v131; // xmm14_4
  float v132; // xmm0_4
  float v133; // xmm13_4
  float v134; // xmm3_4
  float v135; // xmm0_4
  char *v136; // r11
  float *v137; // rbx
  float v138; // xmm0_4
  float v139; // xmm13_4
  float v140; // xmm14_4
  float v141; // xmm1_4
  float v142; // xmm13_4
  float v143; // xmm0_4
  float v144; // xmm1_4
  char *v145; // r11
  float *v146; // rbx
  float v147; // xmm1_4
  float v148; // xmm13_4
  float v149; // xmm14_4
  float v150; // xmm0_4
  float v151; // xmm13_4
  float v152; // xmm1_4
  float v153; // xmm0_4
  char *v154; // r11
  float *v155; // rbx
  float v156; // xmm0_4
  float v157; // xmm13_4
  float v158; // xmm14_4
  float v159; // xmm3_4
  float v160; // xmm13_4
  float v161; // xmm0_4
  float v162; // xmm3_4
  float v163; // xmm1_4
  char *v164; // r11
  char *v165; // rax
  float *v166; // rbx
  float v167; // xmm15_4
  float v168; // xmm12_4
  float v169; // xmm3_4
  float v170; // xmm13_4
  float v171; // xmm0_4
  float v172; // xmm15_4
  float v173; // xmm1_4
  float v174; // xmm0_4
  float v175; // xmm2_4
  float v176; // xmm14_4
  float *v177; // r11
  float v178; // xmm0_4
  float v179; // xmm15_4
  float v180; // xmm1_4
  float v181; // xmm14_4
  float v182; // xmm0_4
  float v183; // xmm1_4
  float v184; // xmm1_4
  float v185; // xmm11_4
  float v186; // xmm2_4
  char *v187; // r11
  float *v188; // rbx
  float v189; // xmm4_4
  float v190; // xmm12_4
  float v191; // xmm0_4
  float v192; // xmm4_4
  float v193; // xmm1_4
  float v194; // xmm0_4
  char *v195; // r11
  float *v196; // rbx
  float v197; // xmm0_4
  float v198; // xmm4_4
  float v199; // xmm12_4
  float v200; // xmm1_4
  float v201; // xmm4_4
  float v202; // xmm0_4
  float v203; // xmm1_4
  char *v204; // r11
  float *v205; // rbx
  float v206; // xmm1_4
  float v207; // xmm4_4
  float v208; // xmm12_4
  float v209; // xmm0_4
  float v210; // xmm4_4
  float v211; // xmm1_4
  float v212; // xmm0_4
  char *v213; // r11
  float *v214; // rbx
  float v215; // xmm0_4
  float v216; // xmm4_4
  float v217; // xmm12_4
  float v218; // xmm3_4
  float v219; // xmm4_4
  float v220; // xmm0_4
  float v221; // xmm3_4
  char *v222; // r11
  float *v223; // rbx
  float v224; // xmm13_4
  float v225; // xmm14_4
  float v226; // xmm3_4
  float v227; // xmm4_4
  float v228; // xmm0_4
  float v229; // xmm13_4
  float v230; // xmm1_4
  float v231; // xmm0_4
  char *v232; // r11
  float *v233; // rbx
  float v234; // xmm0_4
  float v235; // xmm13_4
  float v236; // xmm14_4
  float v237; // xmm1_4
  float v238; // xmm13_4
  float v239; // xmm0_4
  float v240; // xmm1_4
  char *v241; // r11
  float *v242; // rbx
  float v243; // xmm1_4
  float v244; // xmm13_4
  float v245; // xmm14_4
  float v246; // xmm0_4
  float v247; // xmm13_4
  float v248; // xmm1_4
  float v249; // xmm0_4
  char *v250; // r11
  float *v251; // rbx
  float v252; // xmm0_4
  float v253; // xmm13_4
  float v254; // xmm14_4
  float v255; // xmm1_4
  float v256; // xmm13_4
  float v257; // xmm0_4
  float v258; // xmm1_4
  char *v259; // r11
  float *v260; // rbx
  float v261; // xmm1_4
  float v262; // xmm13_4
  float v263; // xmm14_4
  float v264; // xmm0_4
  float v265; // xmm13_4
  float v266; // xmm1_4
  float v267; // xmm0_4
  char *v268; // r11
  float *v269; // rbx
  float v270; // xmm0_4
  float v271; // xmm13_4
  float v272; // xmm14_4
  float v273; // xmm1_4
  float v274; // xmm13_4
  float v275; // xmm0_4
  float v276; // xmm1_4
  char *v277; // r11
  float *v278; // rbx
  float v279; // xmm1_4
  float v280; // xmm13_4
  float v281; // xmm14_4
  float v282; // xmm0_4
  float v283; // xmm13_4
  float v284; // xmm1_4
  float v285; // xmm0_4
  char *v286; // r11
  float *v287; // rbx
  float v288; // xmm0_4
  float v289; // xmm13_4
  float v290; // xmm14_4
  float v291; // xmm12_4
  float v292; // xmm13_4
  float v293; // xmm0_4
  float v294; // xmm12_4
  char *v295; // r11
  float *v296; // rbx
  float v297; // xmm12_4
  float v298; // xmm14_4
  float v299; // xmm15_4
  float v300; // xmm12_4
  float v301; // xmm0_4
  float v302; // xmm14_4
  float v303; // xmm11_4
  float v304; // xmm0_4
  char *v305; // r11
  float *v306; // rbx
  float v307; // xmm0_4
  float v308; // xmm14_4
  float v309; // xmm15_4
  float v310; // xmm1_4
  float v311; // xmm14_4
  float v312; // xmm0_4
  float v313; // xmm1_4
  char *v314; // r11
  char *v315; // rax
  float *v316; // rbx
  float v317; // xmm1_4
  float v318; // xmm14_4
  float v319; // xmm15_4
  float v320; // xmm0_4
  float v321; // xmm14_4
  float v322; // xmm1_4
  float v323; // xmm0_4
  float *v324; // r11
  float v325; // xmm0_4
  float v326; // xmm15_4
  float v327; // xmm0_4
  float v328; // xmm14_4
  float v329; // xmm1_4
  float v330; // xmm14_4
  float v331; // xmm0_4
  float v332; // xmm1_4
  float v333; // xmm4_4
  float v334; // xmm1_4
  float v335; // xmm0_4
  float v336; // xmm3_4
  float v337; // xmm2_4
  float v338; // xmm4_4
  float v339; // xmm4_4
  float v340; // xmm1_4
  float v341; // xmm0_4
  float v342; // xmm3_4
  float v343; // xmm2_4
  float v344; // xmm4_4
  float v345; // xmm4_4
  float v346; // xmm1_4
  float v347; // xmm0_4
  float v348; // xmm3_4
  float v349; // xmm2_4
  float v350; // xmm4_4
  float v351; // xmm4_4
  float v352; // xmm1_4
  float v353; // xmm0_4
  float v354; // xmm3_4
  float v355; // xmm2_4
  float v356; // xmm4_4
  float v357; // xmm4_4
  float v358; // xmm1_4
  float v359; // xmm0_4
  float v360; // xmm3_4
  float v361; // xmm2_4
  float v362; // xmm4_4
  float v363; // xmm4_4
  float v364; // xmm1_4
  float v365; // xmm0_4
  float v366; // xmm3_4
  float v367; // xmm2_4
  float v368; // xmm4_4
  float v369; // xmm4_4
  float v370; // xmm1_4
  float v371; // xmm0_4
  float v372; // xmm3_4
  float v373; // xmm2_4
  float v374; // xmm4_4
  float v375; // xmm4_4
  float v376; // xmm1_4
  float v377; // xmm0_4
  float v378; // xmm3_4
  float v379; // xmm2_4
  float v380; // xmm4_4

LABEL_1:
  while ( --length != -1 )
  {
    v5 = *((float *)this + 2408);
    if ( v5 != 0.0 )
    {
      v6 = v5 - 1.0;
      *((float *)this + 2408) = v6;
      if ( v6 == 0.0 )
        v7 = *((float *)this + 2406);
      else
        v7 = *((float *)this + 2405) + *((float *)this + 2407);
      *((float *)this + 2405) = v7;
    }
    v8 = *((float *)this + 2413);
    if ( v8 != 0.0 )
    {
      v9 = v8 - 1.0;
      *((float *)this + 2413) = v9;
      if ( v9 == 0.0 )
        v10 = *((float *)this + 2411);
      else
        v10 = *((float *)this + 2410) + *((float *)this + 2412);
      *((float *)this + 2410) = v10;
    }
    v11 = *((float *)this + 2418);
    if ( v11 != 0.0 )
    {
      v12 = v11 - 1.0;
      *((float *)this + 2418) = v12;
      if ( v12 == 0.0 )
        v13 = *((float *)this + 2416);
      else
        v13 = *((float *)this + 2415) + *((float *)this + 2417);
      *((float *)this + 2415) = v13;
    }
    v14 = *((_DWORD *)this + 141);
    if ( v14 )
    {
      v15 = v14 - 1;
      *((_DWORD *)this + 141) = v15;
      if ( v15 )
      {
        v375 = *((float *)this + 152) + *((float *)this + 147);
        v376 = *((float *)this + 153) + *((float *)this + 148);
        v377 = *((float *)this + 154) + *((float *)this + 149);
        v378 = *((float *)this + 155) + *((float *)this + 150);
        v379 = *((float *)this + 156) + *((float *)this + 151);
        *((float *)this + 152) = v375;
        v380 = v375 + *((float *)this + 142);
        *((float *)this + 153) = v376;
        v16 = v376 + *((float *)this + 143);
        *((float *)this + 154) = v377;
        v17 = v377 + *((float *)this + 144);
        *((float *)this + 155) = v378;
        v18 = v378 + *((float *)this + 145);
        *((float *)this + 156) = v379;
        v19 = v379 + *((float *)this + 146);
        *((float *)this + 136) = v380;
      }
      else
      {
        *((_DWORD *)this + 136) = *((_DWORD *)this + 142);
        v16 = *((float *)this + 143);
        v17 = *((float *)this + 144);
        v18 = *((float *)this + 145);
        v19 = *((float *)this + 146);
      }
      *((float *)this + 137) = v16;
      *((float *)this + 138) = v17;
      *((float *)this + 139) = v18;
      *((float *)this + 140) = v19;
      *((float *)this + 134) = v16;
      *((float *)this + 135) = v17;
      *((float *)this + 132) = -v18;
      *((float *)this + 133) = -v19;
    }
    v20 = *((_DWORD *)this + 197);
    if ( v20 )
    {
      v21 = v20 - 1;
      *((_DWORD *)this + 197) = v21;
      if ( v21 )
      {
        v363 = *((float *)this + 208) + *((float *)this + 203);
        v364 = *((float *)this + 209) + *((float *)this + 204);
        v365 = *((float *)this + 210) + *((float *)this + 205);
        v366 = *((float *)this + 211) + *((float *)this + 206);
        v367 = *((float *)this + 212) + *((float *)this + 207);
        *((float *)this + 208) = v363;
        v368 = v363 + *((float *)this + 198);
        *((float *)this + 209) = v364;
        v22 = v364 + *((float *)this + 199);
        *((float *)this + 210) = v365;
        v23 = v365 + *((float *)this + 200);
        *((float *)this + 211) = v366;
        v24 = v366 + *((float *)this + 201);
        *((float *)this + 212) = v367;
        v25 = v367 + *((float *)this + 202);
        *((float *)this + 192) = v368;
      }
      else
      {
        *((_DWORD *)this + 192) = *((_DWORD *)this + 198);
        v22 = *((float *)this + 199);
        v23 = *((float *)this + 200);
        v24 = *((float *)this + 201);
        v25 = *((float *)this + 202);
      }
      *((float *)this + 193) = v22;
      *((float *)this + 194) = v23;
      *((float *)this + 195) = v24;
      *((float *)this + 196) = v25;
      *((float *)this + 190) = v22;
      *((float *)this + 191) = v23;
      *((float *)this + 188) = -v24;
      *((float *)this + 189) = -v25;
    }
    v26 = *((_DWORD *)this + 253);
    if ( v26 )
    {
      v27 = v26 - 1;
      *((_DWORD *)this + 253) = v27;
      if ( v27 )
      {
        v369 = *((float *)this + 264) + *((float *)this + 259);
        v370 = *((float *)this + 265) + *((float *)this + 260);
        v371 = *((float *)this + 266) + *((float *)this + 261);
        v372 = *((float *)this + 267) + *((float *)this + 262);
        v373 = *((float *)this + 268) + *((float *)this + 263);
        *((float *)this + 264) = v369;
        v374 = v369 + *((float *)this + 254);
        *((float *)this + 265) = v370;
        v28 = v370 + *((float *)this + 255);
        *((float *)this + 266) = v371;
        v29 = v371 + *((float *)this + 256);
        *((float *)this + 267) = v372;
        v30 = v372 + *((float *)this + 257);
        *((float *)this + 268) = v373;
        v31 = v373 + *((float *)this + 258);
        *((float *)this + 248) = v374;
      }
      else
      {
        *((_DWORD *)this + 248) = *((_DWORD *)this + 254);
        v28 = *((float *)this + 255);
        v29 = *((float *)this + 256);
        v30 = *((float *)this + 257);
        v31 = *((float *)this + 258);
      }
      *((float *)this + 249) = v28;
      *((float *)this + 250) = v29;
      *((float *)this + 251) = v30;
      *((float *)this + 252) = v31;
      *((float *)this + 246) = v28;
      *((float *)this + 247) = v29;
      *((float *)this + 244) = -v30;
      *((float *)this + 245) = -v31;
    }
    v32 = *((_DWORD *)this + 309);
    if ( v32 )
    {
      v33 = v32 - 1;
      *((_DWORD *)this + 309) = v33;
      if ( v33 )
      {
        v333 = *((float *)this + 320) + *((float *)this + 315);
        v334 = *((float *)this + 321) + *((float *)this + 316);
        v335 = *((float *)this + 322) + *((float *)this + 317);
        v336 = *((float *)this + 323) + *((float *)this + 318);
        v337 = *((float *)this + 324) + *((float *)this + 319);
        *((float *)this + 320) = v333;
        v338 = v333 + *((float *)this + 310);
        *((float *)this + 321) = v334;
        v34 = v334 + *((float *)this + 311);
        *((float *)this + 322) = v335;
        v35 = v335 + *((float *)this + 312);
        *((float *)this + 323) = v336;
        v36 = v336 + *((float *)this + 313);
        *((float *)this + 324) = v337;
        v37 = v337 + *((float *)this + 314);
        *((float *)this + 304) = v338;
      }
      else
      {
        *((_DWORD *)this + 304) = *((_DWORD *)this + 310);
        v34 = *((float *)this + 311);
        v35 = *((float *)this + 312);
        v36 = *((float *)this + 313);
        v37 = *((float *)this + 314);
      }
      *((float *)this + 305) = v34;
      *((float *)this + 306) = v35;
      *((float *)this + 307) = v36;
      *((float *)this + 308) = v37;
      *((float *)this + 302) = v34;
      *((float *)this + 303) = v35;
      *((float *)this + 300) = -v36;
      *((float *)this + 301) = -v37;
    }
    v38 = *((_DWORD *)this + 169);
    if ( v38 )
    {
      v39 = v38 - 1;
      *((_DWORD *)this + 169) = v39;
      if ( v39 )
      {
        v339 = *((float *)this + 180) + *((float *)this + 175);
        v340 = *((float *)this + 181) + *((float *)this + 176);
        v341 = *((float *)this + 182) + *((float *)this + 177);
        v342 = *((float *)this + 183) + *((float *)this + 178);
        v343 = *((float *)this + 184) + *((float *)this + 179);
        *((float *)this + 180) = v339;
        v344 = v339 + *((float *)this + 170);
        *((float *)this + 181) = v340;
        v40 = v340 + *((float *)this + 171);
        *((float *)this + 182) = v341;
        v41 = v341 + *((float *)this + 172);
        *((float *)this + 183) = v342;
        v42 = v342 + *((float *)this + 173);
        *((float *)this + 184) = v343;
        v43 = v343 + *((float *)this + 174);
        *((float *)this + 164) = v344;
      }
      else
      {
        *((_DWORD *)this + 164) = *((_DWORD *)this + 170);
        v40 = *((float *)this + 171);
        v41 = *((float *)this + 172);
        v42 = *((float *)this + 173);
        v43 = *((float *)this + 174);
      }
      *((float *)this + 165) = v40;
      *((float *)this + 166) = v41;
      *((float *)this + 167) = v42;
      *((float *)this + 168) = v43;
      *((float *)this + 162) = v40;
      *((float *)this + 163) = v41;
      *((float *)this + 160) = -v42;
      *((float *)this + 161) = -v43;
    }
    v44 = *((_DWORD *)this + 225);
    if ( v44 )
    {
      v45 = v44 - 1;
      *((_DWORD *)this + 225) = v45;
      if ( v45 )
      {
        v345 = *((float *)this + 236) + *((float *)this + 231);
        v346 = *((float *)this + 237) + *((float *)this + 232);
        v347 = *((float *)this + 238) + *((float *)this + 233);
        v348 = *((float *)this + 239) + *((float *)this + 234);
        v349 = *((float *)this + 240) + *((float *)this + 235);
        *((float *)this + 236) = v345;
        v350 = v345 + *((float *)this + 226);
        *((float *)this + 237) = v346;
        v46 = v346 + *((float *)this + 227);
        *((float *)this + 238) = v347;
        v47 = v347 + *((float *)this + 228);
        *((float *)this + 239) = v348;
        v48 = v348 + *((float *)this + 229);
        *((float *)this + 240) = v349;
        v49 = v349 + *((float *)this + 230);
        *((float *)this + 220) = v350;
      }
      else
      {
        *((_DWORD *)this + 220) = *((_DWORD *)this + 226);
        v46 = *((float *)this + 227);
        v47 = *((float *)this + 228);
        v48 = *((float *)this + 229);
        v49 = *((float *)this + 230);
      }
      *((float *)this + 221) = v46;
      *((float *)this + 222) = v47;
      *((float *)this + 223) = v48;
      *((float *)this + 224) = v49;
      *((float *)this + 218) = v46;
      *((float *)this + 219) = v47;
      *((float *)this + 216) = -v48;
      *((float *)this + 217) = -v49;
    }
    v50 = *((_DWORD *)this + 281);
    if ( v50 )
    {
      v51 = v50 - 1;
      *((_DWORD *)this + 281) = v51;
      if ( v51 )
      {
        v351 = *((float *)this + 292) + *((float *)this + 287);
        v352 = *((float *)this + 293) + *((float *)this + 288);
        v353 = *((float *)this + 294) + *((float *)this + 289);
        v354 = *((float *)this + 295) + *((float *)this + 290);
        v355 = *((float *)this + 296) + *((float *)this + 291);
        *((float *)this + 292) = v351;
        v356 = v351 + *((float *)this + 282);
        *((float *)this + 293) = v352;
        v52 = v352 + *((float *)this + 283);
        *((float *)this + 294) = v353;
        v53 = v353 + *((float *)this + 284);
        *((float *)this + 295) = v354;
        v54 = v354 + *((float *)this + 285);
        *((float *)this + 296) = v355;
        v55 = v355 + *((float *)this + 286);
        *((float *)this + 276) = v356;
      }
      else
      {
        *((_DWORD *)this + 276) = *((_DWORD *)this + 282);
        v52 = *((float *)this + 283);
        v53 = *((float *)this + 284);
        v54 = *((float *)this + 285);
        v55 = *((float *)this + 286);
      }
      *((float *)this + 277) = v52;
      *((float *)this + 278) = v53;
      *((float *)this + 279) = v54;
      *((float *)this + 280) = v55;
      *((float *)this + 274) = v52;
      *((float *)this + 275) = v53;
      *((float *)this + 272) = -v54;
      *((float *)this + 273) = -v55;
    }
    v56 = *((_DWORD *)this + 337);
    if ( v56 )
    {
      v57 = v56 - 1;
      *((_DWORD *)this + 337) = v57;
      if ( v57 )
      {
        v357 = *((float *)this + 348) + *((float *)this + 343);
        v358 = *((float *)this + 349) + *((float *)this + 344);
        v359 = *((float *)this + 350) + *((float *)this + 345);
        v360 = *((float *)this + 351) + *((float *)this + 346);
        v361 = *((float *)this + 352) + *((float *)this + 347);
        *((float *)this + 348) = v357;
        v362 = v357 + *((float *)this + 338);
        *((float *)this + 349) = v358;
        v58 = v358 + *((float *)this + 339);
        *((float *)this + 350) = v359;
        v59 = v359 + *((float *)this + 340);
        *((float *)this + 351) = v360;
        v60 = v360 + *((float *)this + 341);
        *((float *)this + 352) = v361;
        v61 = v361 + *((float *)this + 342);
        *((float *)this + 332) = v362;
      }
      else
      {
        *((_DWORD *)this + 332) = *((_DWORD *)this + 338);
        v58 = *((float *)this + 339);
        v59 = *((float *)this + 340);
        v60 = *((float *)this + 341);
        v61 = *((float *)this + 342);
      }
      *((float *)this + 333) = v58;
      *((float *)this + 334) = v59;
      *((float *)this + 335) = v60;
      *((float *)this + 336) = v61;
      *((float *)this + 330) = v58;
      *((float *)this + 331) = v59;
      *((float *)this + 328) = -v60;
      *((float *)this + 329) = -v61;
    }
    if ( channels )
    {
      v62 = *((_DWORD *)this + 2423);
      v63 = 0;
      while ( 1 )
      {
        if ( v62 == 1 )
        {
          v106 = *inbuffer;
          v107 = *((float *)this + 2405);
          v108 = (char *)this + 16 * v63 + 1424;
          v109 = (float *)*((_QWORD *)v108 + 1);
          v110 = *((float *)v108 + 1);
          v111 = v109[5] * *(float *)v108;
          v112 = v109[8] * v110;
          v113 = v110 * v109[6];
          v114 = (float)(*inbuffer - (float)(v109[7] * *(float *)v108)) - v112;
          v115 = v109[4];
          *((_DWORD *)v108 + 1) = *(_DWORD *)v108;
          *(float *)v108 = v114;
          v116 = (char *)this + 16 * v63 + 1936;
          v117 = (float)(v115 * v114) + v111;
          v118 = (float *)*((_QWORD *)v116 + 1);
          v119 = *((float *)v116 + 1);
          v120 = v118[5] * *(float *)v116;
          v121 = (float)(v117 + v113) - (float)(v118[7] * *(float *)v116);
          v122 = v118[8] * v119;
          v123 = v119 * v118[6];
          v124 = v121 - v122;
          v125 = v118[4];
          *((_DWORD *)v116 + 1) = *(_DWORD *)v116;
          *(float *)v116 = v124;
          v126 = (char *)this + 16 * v63 + 3472;
          v127 = (float *)*((_QWORD *)v126 + 1);
          v128 = *((float *)v126 + 1);
          v129 = (float)((float)(v125 * v124) + v120) + v123;
          v130 = *((float *)this + 2410);
          v131 = v127[5] * *(float *)v126;
          v132 = v127[8] * v128;
          v133 = v128 * v127[6];
          v134 = (float)(v106 - (float)(v127[7] * *(float *)v126)) - v132;
          v135 = v127[4];
          *((_DWORD *)v126 + 1) = *(_DWORD *)v126;
          *(float *)v126 = v134;
          v136 = (char *)this + 16 * v63 + 3984;
          v137 = (float *)*((_QWORD *)v136 + 1);
          v138 = (float)((float)(v135 * v134) + v131) + v133;
          v139 = *((float *)v136 + 1);
          v140 = v137[5] * *(float *)v136;
          v141 = v137[8] * v139;
          v142 = v139 * v137[6];
          v143 = (float)(v138 - (float)(v137[7] * *(float *)v136)) - v141;
          v144 = v137[4];
          *((_DWORD *)v136 + 1) = *(_DWORD *)v136;
          *(float *)v136 = v143;
          v145 = (char *)this + 16 * v63 + 5520;
          v146 = (float *)*((_QWORD *)v145 + 1);
          v147 = (float)((float)(v144 * v143) + v140) + v142;
          v148 = *((float *)v145 + 1);
          v149 = v146[5] * *(float *)v145;
          v150 = v146[8] * v148;
          v151 = v148 * v146[6];
          v152 = (float)(v147 - (float)(v146[7] * *(float *)v145)) - v150;
          v153 = v146[4];
          *((_DWORD *)v145 + 1) = *(_DWORD *)v145;
          *(float *)v145 = v152;
          v154 = (char *)this + 16 * v63 + 6032;
          v155 = (float *)*((_QWORD *)v154 + 1);
          v156 = (float)((float)(v153 * v152) + v149) + v151;
          v157 = *((float *)v154 + 1);
          v158 = v155[5] * *(float *)v154;
          v159 = v155[8] * v157;
          v160 = v157 * v155[6];
          v161 = (float)(v156 - (float)(v155[7] * *(float *)v154)) - v159;
          v162 = v155[4];
          *((_DWORD *)v154 + 1) = *(_DWORD *)v154;
          v163 = v106;
          *(float *)v154 = v161;
          v164 = (char *)this + 16 * v63 + 7568;
          v165 = (char *)this + 16 * v63 + 8080;
          v166 = (float *)*((_QWORD *)v164 + 1);
          v167 = *((float *)v164 + 1);
          v168 = v166[5] * *(float *)v164;
          v169 = (float)((float)(v162 * v161) + v158) + v160;
          v170 = *((float *)this + 2415);
          v171 = v166[8] * v167;
          v172 = v167 * v166[6];
          v173 = (float)(v163 - (float)(v166[7] * *(float *)v164)) - v171;
          v174 = v166[4];
          *((_DWORD *)v164 + 1) = *(_DWORD *)v164;
          v175 = (float)(v107 * v129) + (float)(v130 * v169);
          v176 = *((float *)v165 + 1);
          *(float *)v164 = v173;
          v177 = (float *)*((_QWORD *)v165 + 1);
          v178 = (float)((float)(v174 * v173) + v168) + v172;
          v179 = v177[5] * *(float *)v165;
          v180 = v177[8] * v176;
          v181 = v176 * v177[6];
          v182 = (float)(v178 - (float)(v177[7] * *(float *)v165)) - v180;
          v183 = v177[4];
          *((_DWORD *)v165 + 1) = *(_DWORD *)v165;
          *(float *)v165 = v182;
          v184 = (float)((float)(v183 * v182) + v179) + v181;
        }
        else
        {
          if ( v62 != 2 )
          {
            if ( !v62 )
            {
              v64 = *inbuffer;
              v65 = *inbuffer;
              v66 = *((float *)this + 2405);
              ++outbuffer;
              ++inbuffer;
              v67 = (char *)this + 16 * v63 + 1424;
              v68 = (float *)*((_QWORD *)v67 + 1);
              v69 = *((float *)v67 + 1);
              v70 = v68[5] * *(float *)v67;
              v71 = v65 - (float)(v68[7] * *(float *)v67);
              v72 = v68[8] * v69;
              v73 = v69 * v68[6];
              v74 = v71 - v72;
              v75 = v68[4];
              *((_DWORD *)v67 + 1) = *(_DWORD *)v67;
              *(float *)v67 = v74;
              v76 = (char *)this + 16 * v63 + 3472;
              v77 = (float)(v75 * v74) + v70;
              v78 = (float *)*((_QWORD *)v76 + 1);
              v79 = *((float *)v76 + 1);
              v80 = *((float *)this + 2410);
              v81 = v77 + v73;
              v82 = v78[5] * *(float *)v76;
              v83 = v78[8] * v79;
              v84 = v79 * v78[6];
              v85 = (float)(v64 - (float)(v78[7] * *(float *)v76)) - v83;
              v86 = v78[4];
              *((_DWORD *)v76 + 1) = *(_DWORD *)v76;
              *(float *)v76 = v85;
              v87 = (char *)this + 16 * v63 + 5520;
              v88 = (char *)this + 16 * v63 + 7568;
              v89 = (float *)*((_QWORD *)v87 + 1);
              v90 = (float)((float)(v86 * v85) + v82) + v84;
              v91 = *((float *)v87 + 1);
              v92 = v89[5] * *(float *)v87;
              v93 = v89[8] * v91;
              v94 = v91 * v89[6];
              v95 = (float)(v90 - (float)(v89[7] * *(float *)v87)) - v93;
              v96 = v89[4];
              *((_DWORD *)v87 + 1) = *(_DWORD *)v87;
              v97 = *((float *)this + 2415);
              *(float *)v87 = v95;
              v98 = (float *)*((_QWORD *)v88 + 1);
              v99 = (float)(v96 * v95) + v92;
              v100 = *((float *)v88 + 1);
              v101 = v98[5] * *(float *)v88;
              v102 = v98[8] * v100;
              v103 = v100 * v98[6];
              v104 = (float)(v64 - (float)(v98[7] * *(float *)v88)) - v102;
              v105 = v98[4];
              *((_DWORD *)v88 + 1) = *(_DWORD *)v88;
              *(float *)v88 = v104;
              *(outbuffer - 1) = (float)((float)(v66 * v81) - (float)(v80 * (float)(v99 + v94)))
                               + (float)(v97 * (float)((float)((float)(v105 * v104) + v101) + v103));
            }
            goto LABEL_51;
          }
          v185 = *inbuffer;
          v186 = *((float *)this + 2405);
          v187 = (char *)this + 16 * v63 + 1424;
          v188 = (float *)*((_QWORD *)v187 + 1);
          v189 = *((float *)v187 + 1);
          v190 = v188[5] * *(float *)v187;
          v191 = v188[8] * v189;
          v192 = v189 * v188[6];
          v193 = (float)(*inbuffer - (float)(v188[7] * *(float *)v187)) - v191;
          v194 = v188[4];
          *((_DWORD *)v187 + 1) = *(_DWORD *)v187;
          *(float *)v187 = v193;
          v195 = (char *)this + 16 * v63 + 1936;
          v196 = (float *)*((_QWORD *)v195 + 1);
          v197 = (float)((float)(v194 * v193) + v190) + v192;
          v198 = *((float *)v195 + 1);
          v199 = v196[5] * *(float *)v195;
          v200 = v196[8] * v198;
          v201 = v198 * v196[6];
          v202 = (float)(v197 - (float)(v196[7] * *(float *)v195)) - v200;
          v203 = v196[4];
          *((_DWORD *)v195 + 1) = *(_DWORD *)v195;
          *(float *)v195 = v202;
          v204 = (char *)this + 16 * v63 + 2448;
          v205 = (float *)*((_QWORD *)v204 + 1);
          v206 = (float)((float)(v203 * v202) + v199) + v201;
          v207 = *((float *)v204 + 1);
          v208 = v205[5] * *(float *)v204;
          v209 = v205[8] * v207;
          v210 = v207 * v205[6];
          v211 = (float)(v206 - (float)(v205[7] * *(float *)v204)) - v209;
          v212 = v205[4];
          *((_DWORD *)v204 + 1) = *(_DWORD *)v204;
          *(float *)v204 = v211;
          v213 = (char *)this + 16 * v63 + 2960;
          v214 = (float *)*((_QWORD *)v213 + 1);
          v215 = (float)((float)(v212 * v211) + v208) + v210;
          v216 = *((float *)v213 + 1);
          v217 = v214[5] * *(float *)v213;
          v218 = v214[8] * v216;
          v219 = v216 * v214[6];
          v220 = (float)(v215 - (float)(v214[7] * *(float *)v213)) - v218;
          v221 = v214[4];
          *((_DWORD *)v213 + 1) = *(_DWORD *)v213;
          *(float *)v213 = v220;
          v222 = (char *)this + 16 * v63 + 3472;
          v223 = (float *)*((_QWORD *)v222 + 1);
          v224 = *((float *)v222 + 1);
          v225 = v223[5] * *(float *)v222;
          v226 = (float)((float)(v221 * v220) + v217) + v219;
          v227 = *((float *)this + 2410);
          v228 = v223[8] * v224;
          v229 = v224 * v223[6];
          v230 = (float)(v185 - (float)(v223[7] * *(float *)v222)) - v228;
          v231 = v223[4];
          *((_DWORD *)v222 + 1) = *(_DWORD *)v222;
          *(float *)v222 = v230;
          v232 = (char *)this + 16 * v63 + 3984;
          v233 = (float *)*((_QWORD *)v232 + 1);
          v234 = (float)((float)(v231 * v230) + v225) + v229;
          v235 = *((float *)v232 + 1);
          v236 = v233[5] * *(float *)v232;
          v237 = v233[8] * v235;
          v238 = v235 * v233[6];
          v239 = (float)(v234 - (float)(v233[7] * *(float *)v232)) - v237;
          v240 = v233[4];
          *((_DWORD *)v232 + 1) = *(_DWORD *)v232;
          *(float *)v232 = v239;
          v241 = (char *)this + 16 * v63 + 4496;
          v242 = (float *)*((_QWORD *)v241 + 1);
          v243 = (float)((float)(v240 * v239) + v236) + v238;
          v244 = *((float *)v241 + 1);
          v245 = v242[5] * *(float *)v241;
          v246 = v242[8] * v244;
          v247 = v244 * v242[6];
          v248 = (float)(v243 - (float)(v242[7] * *(float *)v241)) - v246;
          v249 = v242[4];
          *((_DWORD *)v241 + 1) = *(_DWORD *)v241;
          *(float *)v241 = v248;
          v250 = (char *)this + 16 * v63 + 5008;
          v251 = (float *)*((_QWORD *)v250 + 1);
          v252 = (float)((float)(v249 * v248) + v245) + v247;
          v253 = *((float *)v250 + 1);
          v254 = v251[5] * *(float *)v250;
          v255 = v251[8] * v253;
          v256 = v253 * v251[6];
          v257 = (float)(v252 - (float)(v251[7] * *(float *)v250)) - v255;
          v258 = v251[4];
          *((_DWORD *)v250 + 1) = *(_DWORD *)v250;
          *(float *)v250 = v257;
          v259 = (char *)this + 16 * v63 + 5520;
          v260 = (float *)*((_QWORD *)v259 + 1);
          v261 = (float)((float)(v258 * v257) + v254) + v256;
          v262 = *((float *)v259 + 1);
          v263 = v260[5] * *(float *)v259;
          v264 = v260[8] * v262;
          v265 = v262 * v260[6];
          v266 = (float)(v261 - (float)(v260[7] * *(float *)v259)) - v264;
          v267 = v260[4];
          *((_DWORD *)v259 + 1) = *(_DWORD *)v259;
          *(float *)v259 = v266;
          v268 = (char *)this + 16 * v63 + 6032;
          v269 = (float *)*((_QWORD *)v268 + 1);
          v270 = (float)((float)(v267 * v266) + v263) + v265;
          v271 = *((float *)v268 + 1);
          v272 = v269[5] * *(float *)v268;
          v273 = v269[8] * v271;
          v274 = v271 * v269[6];
          v275 = (float)(v270 - (float)(v269[7] * *(float *)v268)) - v273;
          v276 = v269[4];
          *((_DWORD *)v268 + 1) = *(_DWORD *)v268;
          *(float *)v268 = v275;
          v277 = (char *)this + 16 * v63 + 6544;
          v278 = (float *)*((_QWORD *)v277 + 1);
          v279 = (float)((float)(v276 * v275) + v272) + v274;
          v280 = *((float *)v277 + 1);
          v281 = v278[5] * *(float *)v277;
          v282 = v278[8] * v280;
          v283 = v280 * v278[6];
          v284 = (float)(v279 - (float)(v278[7] * *(float *)v277)) - v282;
          v285 = v278[4];
          *((_DWORD *)v277 + 1) = *(_DWORD *)v277;
          *(float *)v277 = v284;
          v286 = (char *)this + 16 * v63 + 7056;
          v287 = (float *)*((_QWORD *)v286 + 1);
          v288 = (float)((float)(v285 * v284) + v281) + v283;
          v289 = *((float *)v286 + 1);
          v290 = v287[5] * *(float *)v286;
          v291 = v287[8] * v289;
          v292 = v289 * v287[6];
          v293 = (float)(v288 - (float)(v287[7] * *(float *)v286)) - v291;
          v294 = v287[4];
          *((_DWORD *)v286 + 1) = *(_DWORD *)v286;
          *(float *)v286 = v293;
          v295 = (char *)this + 16 * v63 + 7568;
          v296 = (float *)*((_QWORD *)v295 + 1);
          v297 = (float)(v294 * v293) + v290;
          v298 = *((float *)v295 + 1);
          v299 = v296[5] * *(float *)v295;
          v300 = v297 + v292;
          v170 = *((float *)this + 2415);
          v301 = v296[8] * v298;
          v302 = v298 * v296[6];
          v303 = (float)(v185 - (float)(v296[7] * *(float *)v295)) - v301;
          v304 = v296[4];
          *((_DWORD *)v295 + 1) = *(_DWORD *)v295;
          v175 = (float)(v186 * v226) + (float)(v227 * v300);
          *(float *)v295 = v303;
          v305 = (char *)this + 16 * v63 + 8080;
          v306 = (float *)*((_QWORD *)v305 + 1);
          v307 = (float)((float)(v304 * v303) + v299) + v302;
          v308 = *((float *)v305 + 1);
          v309 = v306[5] * *(float *)v305;
          v310 = v306[8] * v308;
          v311 = v308 * v306[6];
          v312 = (float)(v307 - (float)(v306[7] * *(float *)v305)) - v310;
          v313 = v306[4];
          *((_DWORD *)v305 + 1) = *(_DWORD *)v305;
          *(float *)v305 = v312;
          v314 = (char *)this + 16 * v63 + 8592;
          v315 = (char *)this + 16 * v63 + 9104;
          v316 = (float *)*((_QWORD *)v314 + 1);
          v317 = (float)((float)(v313 * v312) + v309) + v311;
          v318 = *((float *)v314 + 1);
          v319 = v316[5] * *(float *)v314;
          v320 = v316[8] * v318;
          v321 = v318 * v316[6];
          v322 = (float)(v317 - (float)(v316[7] * *(float *)v314)) - v320;
          v323 = v316[4];
          *((_DWORD *)v314 + 1) = *(_DWORD *)v314;
          *(float *)v314 = v322;
          v324 = (float *)*((_QWORD *)v315 + 1);
          v325 = (float)(v323 * v322) + v319;
          v326 = v324[5] * *(float *)v315;
          v327 = v325 + v321;
          v328 = *((float *)v315 + 1);
          v329 = v324[8] * v328;
          v330 = v328 * v324[6];
          v331 = (float)(v327 - (float)(v324[7] * *(float *)v315)) - v329;
          v332 = v324[4];
          *((_DWORD *)v315 + 1) = *(_DWORD *)v315;
          *(float *)v315 = v331;
          v184 = (float)((float)(v332 * v331) + v326) + v330;
        }
        ++outbuffer;
        ++inbuffer;
        *(outbuffer - 1) = v175 + (float)(v170 * v184);
LABEL_51:
        if ( ++v63 == channels )
          goto LABEL_1;
      }
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


