// Address: 0x21e32f0 | Name: _ZN4FMOD14OutputSoftware4initEi
FMOD_RESULT_0 __fastcall FMOD::OutputSoftware::init(FMOD::OutputSoftware *const this, int maxchannels)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelPool *v5; // rax
  FMOD::ChannelPool *v6; // r12
  FMOD::SystemI *mSystem; // rsi
  FMOD::ChannelSoftware *mChannel; // rdi
  __int64 v9; // r12
  int v10; // r13d
  FMOD::ChannelSoftware *v11; // rdx
  FMOD::ChannelSoftware *v12; // rdi

  result = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  if ( this->mSystem )
  {
    LOBYTE(result) = 0;
    if ( maxchannels )
    {
      v5 = (FMOD::ChannelPool *)FMOD::MemPool::alloc(
                                  off_286F358->gSystemMemPool,
                                  32,
                                  "../../../core_api/src/fmod_output_software.cpp",
                                  73,
                                  0,
                                  0);
      v6 = v5;
      if ( v5 )
      {
        FMOD::ChannelPool::ChannelPool(v5);
        mSystem = this->mSystem;
        this->mChannelPool = v6;
        result = FMOD::ChannelPool::init(v6, mSystem, this, maxchannels);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          mChannel = (FMOD::ChannelSoftware *)FMOD::MemPool::calloc(
                                                off_286F358->gSystemMemPool,
                                                768 * maxchannels,
                                                "../../../core_api/src/fmod_output_software.cpp",
                                                82,
                                                0);
          this->mChannel = mChannel;
          result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
          if ( mChannel )
          {
            v9 = 0;
            v10 = 0;
            if ( maxchannels > 0 )
            {
              while ( 1 )
              {
                v11 = 0;
                v12 = &mChannel[v9];
                if ( v12 )
                {
                  FMOD::ChannelSoftware::ChannelSoftware(v12);
                  v11 = &this->mChannel[v9];
                }
                result = FMOD::ChannelPool::setChannel(this->mChannelPool, v10, v11);
                if ( result )
                  break;
                ++v10;
                ++v9;
                if ( v10 == maxchannels )
                  return FMOD_RESULT::FMOD_OK_0;
                mChannel = this->mChannel;
              }
            }
            else
            {
              return FMOD_RESULT::FMOD_OK_0;
            }
          }
        }
      }
      else
      {
        this->mChannelPool = 0;
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
    }
  }
  return result;
}


// Address: 0x21e3430 | Name: _ZN4FMOD14OutputSoftwareC2Ev
void __fastcall FMOD::OutputSoftware::OutputSoftware(FMOD::OutputSoftware *const this)
{
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *p_mDescription; // rdi
  unsigned int v3; // edx
  __int64 v4; // rcx
  unsigned int *v5; // rdi

  FMOD::Output::Output(this);
  p_mDescription = &this->mDescription;
  v3 = 264;
  this->_vptr_Output = (int (**)(...))&off_29B11F0;
  if ( (((_BYTE)this + 112) & 1) == 0 )
  {
    if ( ((unsigned __int8)p_mDescription & 2) == 0 )
      goto LABEL_3;
LABEL_12:
    p_mDescription = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)p_mDescription + 2);
    v3 -= 2;
    HIWORD(p_mDescription[-1].record_unlock) = 0;
    if ( ((unsigned __int8)p_mDescription & 4) == 0 )
      goto LABEL_4;
    goto LABEL_13;
  }
  p_mDescription = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)&this->mDescription.apiversion + 1);
  LOBYTE(this->mDescription.apiversion) = 0;
  LOBYTE(v3) = 7;
  if ( (((_BYTE)this + 113) & 2) != 0 )
    goto LABEL_12;
LABEL_3:
  if ( ((unsigned __int8)p_mDescription & 4) == 0 )
    goto LABEL_4;
LABEL_13:
  p_mDescription->apiversion = 0;
  v3 -= 4;
  p_mDescription = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)p_mDescription + 4);
LABEL_4:
  v4 = v3 >> 3;
  memset(p_mDescription, 0, 8 * v4);
  v5 = &p_mDescription->apiversion + 2 * v4;
  if ( (v3 & 4) != 0 )
    *v5++ = 0;
  if ( (v3 & 2) != 0 )
  {
    v5 = (unsigned int *)((char *)v5 + 2);
    *((_WORD *)v5 - 1) = 0;
  }
  if ( (v3 & 1) != 0 )
    *(_BYTE *)v5 = 0;
  this->mDescription.version = 65792;
  this->mDescription.polling = 0;
  this->mDescription.mType = -1;
  this->mDescription.mSize = 1152;
  this->mDescription.name = "FMOD Software Output";
  this->mChannel = 0;
  this->mChannelPool = 0;
}


// Address: 0x21e3550 | Name: _ZN4FMOD14OutputSoftware12createSampleEjP21FMOD_CODEC_WAVEFORMATPPNS_6SampleE
FMOD_RESULT_0 __fastcall FMOD::OutputSoftware::createSample(
        FMOD::OutputSoftware *const this,
        FMOD_MODE mode,
        FMOD_CODEC_WAVEFORMAT *waveformat,
        FMOD::Sample **sample)
{
  FMOD_RESULT_0 result; // eax
  FMOD::Sample *v6; // rbx
  FMOD::SampleSoftware *v7; // r14
  FMOD_SOUND_FORMAT_0 format; // eax
  unsigned int lengthbytes; // edx
  __int64 v11; // r15
  FMOD::LinkedListNode *v12; // rax
  unsigned __int64 lengthpcm; // rdx
  __int64 v14; // rcx
  int v15; // r15d
  FMOD::LinkedListNode *v16; // rax
  FMOD::SampleSoftware *v17; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( sample )
  {
    v6 = *sample;
    v7 = 0;
    if ( !*sample )
    {
      v17 = (FMOD::SampleSoftware *)FMOD::MemPool::calloc(
                                      off_286F358->gSystemMemPool,
                                      392,
                                      "../../../core_api/src/fmod_output_software.cpp",
                                      155,
                                      0);
      v6 = v17;
      if ( !v17 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      v7 = v17;
      FMOD::SampleSoftware::SampleSoftware(v17);
    }
    if ( !waveformat )
    {
LABEL_8:
      *sample = v6;
      return FMOD_RESULT::FMOD_OK_0;
    }
    format = waveformat->format;
    lengthbytes = waveformat->lengthbytes;
    v11 = 0;
    v6[1].mNodePrev = 0;
    v6->mLengthBytes = lengthbytes;
    v6->mFormat = format;
    if ( (mode & 0x200) == 0 )
    {
      lengthpcm = waveformat->lengthpcm;
      switch ( format )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
          v14 = 8;
          goto LABEL_14;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          v14 = 16;
          goto LABEL_14;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          v14 = 24;
          goto LABEL_14;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          v14 = 32;
LABEL_14:
          lengthpcm = (v14 * lengthpcm) >> 3;
          break;
        default:
          break;
      }
      v6->mLengthBytes = waveformat->channels * lengthpcm;
      switch ( format )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          v15 = 16;
          break;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          v15 = 24;
          break;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          v15 = 32;
          break;
        default:
          v15 = 8;
          break;
      }
      v11 = (unsigned int)(waveformat->channels * v15);
      if ( (unsigned int)v11 > 8 )
      {
        v16 = (FMOD::LinkedListNode *)FMOD::MemPool::calloc(
                                        off_286F358->gSystemMemPool,
                                        v11,
                                        "../../../core_api/src/fmod_output_software.cpp",
                                        205,
                                        0);
        v6[1].mNodePrev = v16;
        if ( !v16 )
        {
LABEL_21:
          if ( v7 )
          {
            (*((void (__fastcall **)(FMOD::SampleSoftware *, __int64))v7->_vptr_SoundI + 3))(v7, 1);
            return FMOD_RESULT::FMOD_ERR_MEMORY_0;
          }
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        }
      }
      else
      {
        v6[1].mNodePrev = (FMOD::LinkedListNode *)&v6[1].mNodeData;
      }
    }
    if ( (mode & 0x10000000) != 0 )
    {
      v6[1].mNodeNext = 0;
      v6[1]._vptr_SoundI = 0;
LABEL_7:
      v6->mFormat = waveformat->format;
      v6->mLength = waveformat->lengthpcm;
      goto LABEL_8;
    }
    v12 = (FMOD::LinkedListNode *)FMOD::MemPool::calloc(
                                    off_286F358->gSystemMemPool,
                                    v6->mLengthBytes + 2 * v11 + 16,
                                    "../../../core_api/src/fmod_output_software.cpp",
                                    220,
                                    (mode & 0x80) == 0 ? 4 : 2);
    v6[1].mNodeNext = v12;
    if ( v12 )
    {
      v6[1]._vptr_SoundI = (int (**)(...))(((unsigned __int64)&v12->mNodePrev + v11 + 7) & 0xFFFFFFFFFFFFFFF0LL);
      goto LABEL_7;
    }
    goto LABEL_21;
  }
  return result;
}


// Address: 0x21e37f0 | Name: _ZN4FMOD14OutputSoftware7releaseEv
FMOD_RESULT_0 __fastcall FMOD::OutputSoftware::release(FMOD::OutputSoftware *const this)
{
  FMOD::ChannelPool *mChannelPool; // rdi
  FMOD::ChannelSoftware *mChannel; // rsi

  mChannelPool = this->mChannelPool;
  if ( mChannelPool )
  {
    FMOD::ChannelPool::release(mChannelPool);
    this->mChannelPool = 0;
  }
  mChannel = this->mChannel;
  if ( mChannel )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mChannel, "../../../core_api/src/fmod_output_software.cpp", 121);
    this->mChannel = 0;
  }
  return FMOD::Output::release(this);
}


