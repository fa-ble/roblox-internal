// Address: 0x2228550 | Name: _ZN4FMOD10DSPParamEq16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPParamEq::getDescriptionEx()
{
  memset(&stru_2B04780, 0, sizeof(stru_2B04780));
  FMOD_strcpy_safe(stru_2B04780.name, "Center freq", 16);
  FMOD_strcpy_safe(stru_2B04780.label, "Hz", 16);
  *(_QWORD *)&stru_2B04780.floatdesc.min = 0x46ABE00041A00000LL;
  stru_2B04780.description = "Frequency center.  20.0 to 22000.0.  Default = 8000.0.";
  memset(&stru_2B04720, 0, sizeof(stru_2B04720));
  stru_2B04780.intdesc.defaultval = 1174011904;
  stru_2B04780.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B04720.name, "Octave range", 16);
  FMOD_strcpy_safe(stru_2B04720.label, "Octaves", 16);
  *(_QWORD *)&stru_2B04720.floatdesc.min = 0x40A000003E4CCCCDLL;
  stru_2B04720.description = "Octave range around the center frequency to filter.  0.2 to 5.0.  Default = 1.0.";
  memset(&stru_2B046C0, 0, sizeof(stru_2B046C0));
  stru_2B04720.intdesc.defaultval = 1065353216;
  stru_2B04720.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B046C0.name, "Frequency gain", 16);
  FMOD_strcpy_safe(stru_2B046C0.label, "dB", 16);
  *(_QWORD *)&stru_2B046C0.floatdesc.min = 0x41F00000C1F00000LL;
  stru_2B046C0.intdesc.defaultval = 0;
  stru_2B046C0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B046C0.description = "Frequency Gain.  -30.0 to 30.0.  Default = 1.0.";
  *(&stru_2B04680.mHandle + 1) = 12;
  stru_2B04680.mSize = 1096;
  stru_2B04680.mDescription = &stru_286EE80;
  return &stru_2B04680;
}


// Address: 0x22286f0 | Name: _ZN4FMOD10DSPParamEq13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPParamEq::resetInternal(FMOD::DSPParamEq *const this)
{
  _DWORD *v1; // rdi
  int v2; // eax

  v1 = (_DWORD *)((char *)this + 548);
  v2 = 32;
  do
  {
    *v1 = 0;
    *(v1 - 1) = 0;
    v1 += 2;
    v1[62] = 0;
    v1[61] = 0;
    --v2;
  }
  while ( v2 );
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2228730 | Name: _ZN4FMOD10DSPParamEq13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPParamEq::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPParamEq::resetInternal((FMOD::DSPParamEq *const)dsp_state->instance);
}


// Address: 0x2228740 | Name: _ZN4FMOD10DSPParamEq18updateCoefficientsEfff
__int64 __fastcall FMOD::DSPParamEq::updateCoefficients(
        FMOD::DSPParamEq *const this,
        float a2,
        float center,
        float bandwidth,
        float gain)
{
  float v6; // xmm4_4
  float v7; // xmm3_4
  float v8; // xmm4_4
  float v9; // xmm1_4
  float v10; // xmm4_4
  float cosx; // [rsp+8h] [rbp-10h] BYREF
  float sinx[3]; // [rsp+Ch] [rbp-Ch] BYREF

  sincosf((float)(a2 * 6.2831855) / (float)*(int *)(*((_QWORD *)this + 22) + 1696LL), sinx, &cosx);
  v6 = sinx[0];
  v7 = cosx * -2.0;
  *((float *)this + 268) = cosx * -2.0;
  *((float *)this + 265) = v7;
  v8 = v6 / (float)((float)(1.0 / center) + (float)(1.0 / center));
  v9 = bandwidth * v8;
  v10 = v8 / bandwidth;
  *((float *)this + 269) = 1.0 - v9;
  *((float *)this + 267) = v9 + 1.0;
  *((float *)this + 264) = v10 + 1.0;
  *((float *)this + 266) = 1.0 - v10;
  return 0;
}


// Address: 0x2228820 | Name: _ZN4FMOD10DSPParamEq14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPParamEq::createInternal(FMOD::DSPParamEq *const this)
{
  double v1; // xmm1_8
  float v2; // xmm3_4
  __int64 v3; // rbp
  __int64 v4; // rax
  int v5; // ebx
  FMOD_RESULT_0 result; // eax
  float v7; // xmm1_4
  float v8; // xmm0_4

  v3 = 0;
  v4 = *((_QWORD *)this + 30);
  v5 = 0;
  *((_DWORD *)this + 133) = 1045220557;
  *((_DWORD *)this + 134) = 0;
  *((_DWORD *)this + 135) = 1065353216;
  if ( *(int *)(v4 + 96) > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v5,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v4 + 104) + v3) + 56LL),
                 v1);
      if ( result )
        break;
      v4 = *((_QWORD *)this + 30);
      ++v5;
      v3 += 8;
      if ( *(_DWORD *)(v4 + 96) <= v5 )
        goto LABEL_6;
    }
  }
  else
  {
LABEL_6:
    FMOD::DSPParamEq::resetInternal(this);
    v7 = *((float *)this + 272);
    *((float *)this + 134) = v7;
    *((_DWORD *)this + 132) = *((_DWORD *)this + 270);
    *((_DWORD *)this + 133) = *((_DWORD *)this + 271);
    v8 = powf(10.0, v7 / 20.0);
    *((float *)this + 135) = v8;
    FMOD::DSPParamEq::updateCoefficients(this, *((float *)this + 132), *((float *)this + 133), v8, v2);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2228930 | Name: _ZN4FMOD10DSPParamEq14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPParamEq::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPParamEq::createInternal((FMOD::DSPParamEq *const)dsp_state->instance);
}


// Address: 0x2228940 | Name: _ZN4FMOD10DSPParamEq12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPParamEq::readInternal(
        FMOD::DSPParamEq *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float v6; // xmm3_4
  float *v7; // rbx
  float v8; // xmm0_4
  float v12; // xmm2_4
  float v13; // xmm1_4
  float v14; // xmm0_4
  float v15; // xmm0_4
  float v16; // xmm14_4
  float v17; // xmm15_4
  float v18; // xmm1_4
  float v19; // xmm2_4
  float v20; // xmm3_4
  float *v21; // r10
  __int64 v22; // r9
  __int64 v23; // rdx
  float *v24; // rcx
  float *v25; // rax
  float *v26; // rdi
  float v27; // xmm6_4
  float v28; // xmm8_4
  float v29; // xmm5_4
  float v30; // xmm9_4
  unsigned int v31; // r8d
  float v32; // xmm7_4
  float v33; // xmm4_4
  float v35; // xmm6_4
  float v36; // xmm5_4
  float v37; // xmm10_4
  __int64 v38; // rax
  float v39; // xmm8_4
  float v40; // xmm7_4
  float v41; // xmm4_4
  float v42; // xmm9_4
  float v43; // xmm8_4
  float v44; // xmm12_4
  float v45; // xmm13_4
  float v46; // xmm7_4
  float v47; // xmm6_4
  float v48; // xmm4_4
  float v49; // xmm11_4
  float v50; // xmm10_4
  float v51; // xmm5_4
  float v52; // xmm0_4
  float v53; // xmm4_4
  float v54; // xmm6_4
  float v55; // xmm5_4
  float v56; // xmm11_4
  float v57; // xmm10_4
  float v58; // xmm13_4
  float v59; // xmm7_4
  float v60; // xmm12_4
  float v61; // xmm12_4
  float v62; // xmm9_4
  float v63; // xmm9_4
  float v64; // xmm8_4
  float v65; // xmm7_4
  float v66; // xmm6_4
  float v67; // xmm5_4
  float v68; // xmm4_4
  float v69; // xmm8_4
  float v70; // xmm7_4
  float v71; // xmm5_4
  float v72; // xmm11_4
  float v73; // xmm4_4
  float v74; // xmm9_4
  float v75; // xmm12_4
  float v76; // xmm10_4
  float v77; // xmm9_4
  float v78; // xmm8_4
  float v79; // xmm7_4
  float v80; // xmm6_4
  float v81; // xmm5_4
  float v82; // xmm4_4
  float out2R; // [rsp+4h] [rbp-B4h]
  float out2Ra; // [rsp+4h] [rbp-B4h]
  float out2Rb; // [rsp+4h] [rbp-B4h]
  float in1D; // [rsp+8h] [rbp-B0h]
  float in1Da; // [rsp+8h] [rbp-B0h]
  float in1Db; // [rsp+8h] [rbp-B0h]
  float in2B; // [rsp+Ch] [rbp-ACh]
  __int64 in2Ba; // [rsp+Ch] [rbp-ACh]
  float in2F; // [rsp+10h] [rbp-A8h]
  float out2A; // [rsp+14h] [rbp-A4h]
  __int64 out2Aa; // [rsp+14h] [rbp-A4h]
  float out1C; // [rsp+18h] [rbp-A0h]
  float out2D; // [rsp+1Ch] [rbp-9Ch]
  float out2Da; // [rsp+1Ch] [rbp-9Ch]
  float out2E; // [rsp+20h] [rbp-98h]
  float out2Ea; // [rsp+20h] [rbp-98h]
  float out2F; // [rsp+24h] [rbp-94h]
  float out2Fa; // [rsp+24h] [rbp-94h]
  float out2B; // [rsp+28h] [rbp-90h]
  float out2Ba; // [rsp+28h] [rbp-90h]
  float in0D_0; // [rsp+2Ch] [rbp-8Ch]
  float in0D_0a; // [rsp+2Ch] [rbp-8Ch]
  float in0E; // [rsp+30h] [rbp-88h]
  float in0Ea; // [rsp+30h] [rbp-88h]
  float in0F_0; // [rsp+34h] [rbp-84h]
  float in0F_0a; // [rsp+34h] [rbp-84h]
  float out1B; // [rsp+38h] [rbp-80h]
  float out1Ba; // [rsp+38h] [rbp-80h]
  float out2G; // [rsp+3Ch] [rbp-7Ch]
  float out2Ga; // [rsp+3Ch] [rbp-7Ch]
  float in0D; // [rsp+40h] [rbp-78h]
  __int64 in0Da; // [rsp+40h] [rbp-78h]
  float in2F_0; // [rsp+44h] [rbp-74h]
  float in0F; // [rsp+48h] [rbp-70h]
  float in0Fa; // [rsp+48h] [rbp-70h]
  float in0G; // [rsp+4Ch] [rbp-6Ch]
  float in0Ga; // [rsp+4Ch] [rbp-6Ch]
  float in0H; // [rsp+50h] [rbp-68h]
  float in0Ha; // [rsp+50h] [rbp-68h]
  float out2H; // [rsp+54h] [rbp-64h]
  float out2Ha; // [rsp+54h] [rbp-64h]
  float in1A; // [rsp+58h] [rbp-60h]
  float in1Aa; // [rsp+58h] [rbp-60h]
  float in1B; // [rsp+5Ch] [rbp-5Ch]
  float in1Ba; // [rsp+5Ch] [rbp-5Ch]
  float in2G_0; // [rsp+60h] [rbp-58h]
  float in2H_0; // [rsp+64h] [rbp-54h]
  float v130; // [rsp+68h] [rbp-50h]
  float out2C_0; // [rsp+6Ch] [rbp-4Ch]
  float out2E_0; // [rsp+70h] [rbp-48h]
  float out2F_0; // [rsp+74h] [rbp-44h]
  float out2G_0; // [rsp+78h] [rbp-40h]
  float v135; // [rsp+7Ch] [rbp-3Ch]
  float in0A; // [rsp+80h] [rbp-38h]
  __int64 in0B; // [rsp+84h] [rbp-34h]
  float v138; // [rsp+8Ch] [rbp-2Ch]

  v7 = inbuffer;
  if ( !inbuffer )
    return FMOD_RESULT::FMOD_OK_0;
  v8 = *((float *)this + 270);
  v12 = *((float *)this + 271);
  if ( v8 != *((float *)this + 132) )
  {
    v13 = *((float *)this + 272);
LABEL_4:
    *((float *)this + 134) = v13;
    *((float *)this + 132) = v8;
    *((float *)this + 133) = v12;
    v14 = powf(10.0, v13 / 20.0);
    *((float *)this + 135) = v14;
    FMOD::DSPParamEq::updateCoefficients(this, *((float *)this + 132), *((float *)this + 133), v14, v6);
    goto LABEL_5;
  }
  v13 = *((float *)this + 272);
  if ( v12 != *((float *)this + 133) || v13 != *((float *)this + 134) )
    goto LABEL_4;
LABEL_5:
  v15 = 1.0 / *((float *)this + 264);
  v16 = *((float *)this + 265);
  v17 = *((float *)this + 266);
  v18 = *((float *)this + 267);
  v19 = *((float *)this + 268);
  v20 = *((float *)this + 269);
  switch ( inchannels )
  {
    case 1:
      v35 = *((float *)this + 136);
      v36 = *((float *)this + 200);
      if ( length )
      {
        v37 = *((float *)this + 137);
        v38 = 0;
        v39 = *((float *)this + 201);
        while ( 1 )
        {
          v40 = inbuffer[v38];
          v41 = (float)((float)((float)((float)((float)(v18 * v40) + (float)(v19 * v35)) + (float)(v37 * v20))
                              - (float)(v16 * v36))
                      - (float)(v39 * v17))
              * v15;
          outbuffer[v38++] = v41;
          if ( length <= (unsigned int)v38 )
            break;
          v39 = v36;
          v37 = v35;
          v36 = v41;
          v35 = v40;
        }
      }
      else
      {
        v41 = *((float *)this + 200);
        v40 = *((float *)this + 136);
        v36 = *((float *)this + 201);
        v35 = *((float *)this + 137);
      }
      *((float *)this + 136) = v40;
      *((float *)this + 137) = v35;
      *((float *)this + 200) = v41;
      *((float *)this + 201) = v36;
      break;
    case 2:
      v42 = *((float *)this + 136);
      v43 = *((float *)this + 138);
      v44 = *((float *)this + 137);
      v45 = *((float *)this + 139);
      v46 = *((float *)this + 200);
      v47 = *((float *)this + 202);
      out2R = *((float *)this + 203);
      if ( length )
      {
        in1D = 1.0 / *((float *)this + 264);
        v48 = *((float *)this + 201);
        while ( 1 )
        {
          v49 = *v7;
          v50 = v7[1];
          outbuffer += 2;
          v7 += 2;
          v51 = (float)((float)((float)((float)((float)(v18 * v49) + (float)(v19 * v42)) + (float)(v44 * v20))
                              - (float)(v16 * v46))
                      - (float)(v48 * v17))
              * in1D;
          *(outbuffer - 2) = v51;
          v52 = (float)((float)((float)((float)((float)(v18 * v50) + (float)(v19 * v43)) + (float)(v45 * v20))
                              - (float)(v16 * v47))
                      - (float)(out2R * v17))
              * in1D;
          *(outbuffer - 1) = v52;
          if ( !--length )
            break;
          out2R = v47;
          v48 = v46;
          v45 = v43;
          v44 = v42;
          v47 = v52;
          v46 = v51;
          v43 = v50;
          v42 = v49;
        }
        v53 = (float)((float)((float)((float)((float)(v18 * v50) + (float)(v19 * v43)) + (float)(v45 * v20))
                            - (float)(v16 * v47))
                    - (float)(out2R * v17))
            * in1D;
      }
      else
      {
        v53 = *((float *)this + 202);
        v51 = *((float *)this + 200);
        v50 = *((float *)this + 138);
        v46 = *((float *)this + 201);
        v47 = *((float *)this + 203);
        v49 = *((float *)this + 136);
        v43 = *((float *)this + 139);
        v42 = *((float *)this + 137);
      }
      *((float *)this + 136) = v49;
      *((float *)this + 138) = v50;
      *((float *)this + 137) = v42;
      *((float *)this + 139) = v43;
      *((float *)this + 200) = v51;
      *((float *)this + 202) = v53;
      *((float *)this + 201) = v46;
      *((float *)this + 203) = v47;
      break;
    case 6:
      out2Ra = *((float *)this + 140);
      in1Da = *((float *)this + 142);
      in2B = *((float *)this + 144);
      in2F = *((float *)this + 146);
      v54 = *((float *)this + 139);
      v55 = *((float *)this + 141);
      out2G = *((float *)this + 143);
      in0D = *((float *)this + 145);
      in2F_0 = *((float *)this + 147);
      out2A = *((float *)this + 200);
      out1B = *((float *)this + 202);
      out1C = *((float *)this + 204);
      out2D = *((float *)this + 206);
      out2E = *((float *)this + 208);
      out2F = *((float *)this + 210);
      v56 = *((float *)this + 136);
      v57 = *((float *)this + 138);
      v58 = *((float *)this + 201);
      in0F = *((float *)this + 205);
      in0G = *((float *)this + 207);
      in0H = *((float *)this + 209);
      out2H = *((float *)this + 211);
      if ( length )
      {
        v59 = *((float *)this + 137);
        v60 = *((float *)this + 203);
        while ( 1 )
        {
          v62 = v7[1];
          v7 += 6;
          out2B = *(v7 - 4);
          outbuffer += 6;
          in0D_0 = *(v7 - 3);
          in0E = *(v7 - 2);
          in0F_0 = *(v7 - 1);
          in1A = *(v7 - 6);
          in1B = v62;
          v63 = (float)((float)((float)((float)((float)(in1A * v18) + (float)(v19 * v56)) + (float)(v59 * v20))
                              - (float)(out2A * v16))
                      - (float)(v58 * v17))
              * v15;
          v64 = (float)((float)((float)((float)((float)(in1B * v18) + (float)(v19 * v57)) + (float)(v54 * v20))
                              - (float)(out1B * v16))
                      - (float)(v60 * v17))
              * v15;
          v65 = (float)((float)((float)((float)((float)(out2B * v18) + (float)(out2Ra * v19)) + (float)(v55 * v20))
                              - (float)(out1C * v16))
                      - (float)(in0F * v17))
              * v15;
          v66 = (float)((float)((float)((float)((float)(in0D_0 * v18) + (float)(in1Da * v19)) + (float)(out2G * v20))
                              - (float)(out2D * v16))
                      - (float)(in0G * v17))
              * v15;
          v67 = (float)((float)((float)((float)((float)(in0E * v18) + (float)(in2B * v19)) + (float)(in0D * v20))
                              - (float)(out2E * v16))
                      - (float)(in0H * v17))
              * v15;
          *(outbuffer - 6) = v63;
          *(outbuffer - 5) = v64;
          *(outbuffer - 4) = v65;
          *(outbuffer - 3) = v66;
          *(outbuffer - 2) = v67;
          v68 = (float)((float)((float)((float)((float)(in0F_0 * v18) + (float)(in2F * v19)) + (float)(in2F_0 * v20))
                              - (float)(out2F * v16))
                      - (float)(out2H * v17))
              * v15;
          *(outbuffer - 1) = v68;
          if ( v7 == &inbuffer[6 * length] )
            break;
          out2H = out2F;
          in0H = out2E;
          in0G = out2D;
          v61 = out1C;
          out1C = v65;
          in2F_0 = in2F;
          in0D = in2B;
          out2G = in1Da;
          v59 = v56;
          in2F = in0F_0;
          in2B = in0E;
          in0F = v61;
          v60 = out1B;
          in1Da = in0D_0;
          v58 = out2A;
          out2F = v68;
          out1B = v64;
          out2A = v63;
          out2E = v67;
          out2D = v66;
          v54 = v57;
          v55 = out2Ra;
          v57 = in1B;
          out2Ra = out2B;
          v56 = in1A;
        }
      }
      else
      {
        v68 = *((float *)this + 210);
        out2F = *((float *)this + 211);
        v67 = *((float *)this + 208);
        out2E = *((float *)this + 209);
        v66 = *((float *)this + 206);
        out2D = *((float *)this + 207);
        v65 = *((float *)this + 204);
        out1C = *((float *)this + 205);
        in0F_0 = *((float *)this + 146);
        in2F = *((float *)this + 147);
        in0E = *((float *)this + 144);
        in2B = *((float *)this + 145);
        in0D_0 = *((float *)this + 142);
        in1Da = *((float *)this + 143);
        out2B = *((float *)this + 140);
        v64 = *((float *)this + 202);
        in1B = *((float *)this + 138);
        out1B = *((float *)this + 203);
        out2Ra = *((float *)this + 141);
        v63 = *((float *)this + 200);
        v57 = *((float *)this + 139);
        out2A = *((float *)this + 201);
        in1A = *((float *)this + 136);
        v56 = *((float *)this + 137);
      }
      *((float *)this + 136) = in1A;
      *((float *)this + 138) = in1B;
      *((float *)this + 140) = out2B;
      *((float *)this + 142) = in0D_0;
      *((float *)this + 144) = in0E;
      *((float *)this + 146) = in0F_0;
      *((float *)this + 141) = out2Ra;
      *((float *)this + 143) = in1Da;
      *((float *)this + 145) = in2B;
      *((float *)this + 147) = in2F;
      *((float *)this + 201) = out2A;
      *((float *)this + 203) = out1B;
      *((float *)this + 137) = v56;
      *((float *)this + 139) = v57;
      *((float *)this + 200) = v63;
      *((float *)this + 202) = v64;
      *((float *)this + 204) = v65;
      *((float *)this + 206) = v66;
      *((float *)this + 208) = v67;
      *((float *)this + 210) = v68;
      *((float *)this + 205) = out1C;
      *((float *)this + 207) = out2D;
      *((float *)this + 209) = out2E;
      *((float *)this + 211) = out2F;
      break;
    case 8:
      in1Db = *((float *)this + 136);
      LODWORD(in2Ba) = *((_DWORD *)this + 138);
      HIDWORD(in2Ba) = *((_DWORD *)this + 140);
      LODWORD(out2Aa) = *((_DWORD *)this + 142);
      HIDWORD(out2Aa) = *((_DWORD *)this + 144);
      out2Rb = *((float *)this + 146);
      out2Da = *((float *)this + 148);
      in1Ba = *((float *)this + 147);
      out2Ea = *((float *)this + 150);
      in2G_0 = *((float *)this + 149);
      v69 = *((float *)this + 137);
      in1Aa = *((float *)this + 141);
      v70 = *((float *)this + 139);
      v71 = *((float *)this + 143);
      in2H_0 = *((float *)this + 151);
      out2Fa = *((float *)this + 200);
      out2Ba = *((float *)this + 202);
      in0D_0a = *((float *)this + 204);
      in0Ea = *((float *)this + 206);
      in0F_0a = *((float *)this + 208);
      out1Ba = *((float *)this + 210);
      out2Ga = *((float *)this + 212);
      out2Ha = *((float *)this + 214);
      v130 = *((float *)this + 201);
      out2C_0 = *((float *)this + 205);
      out2E_0 = *((float *)this + 209);
      out2F_0 = *((float *)this + 211);
      out2G_0 = *((float *)this + 213);
      v72 = *((float *)this + 203);
      v135 = *((float *)this + 215);
      if ( length )
      {
        v73 = *((float *)this + 145);
        v138 = *((float *)this + 207);
        while ( 1 )
        {
          outbuffer += 8;
          in0A = *v7;
          v74 = v7[2];
          *(float *)&in0B = v7[1];
          *(float *)&in0Da = v7[3];
          v7 += 8;
          *((float *)&in0Da + 1) = *(v7 - 4);
          in0Fa = *(v7 - 3);
          in0Ga = *(v7 - 2);
          in0Ha = *(v7 - 1);
          *((float *)&in0B + 1) = v74;
          v75 = (float)((float)((float)((float)((float)(in0A * v18) + (float)(in1Db * v19)) + (float)(v69 * v20))
                              - (float)(out2Fa * v16))
                      - (float)(v130 * v17))
              * v15;
          v76 = (float)((float)((float)((float)((float)(*(float *)&in0B * v18) + (float)(*(float *)&in2Ba * v19))
                                      + (float)(v70 * v20))
                              - (float)(out2Ba * v16))
                      - (float)(v72 * v17))
              * v15;
          v77 = (float)((float)((float)((float)((float)(v74 * v18) + (float)(*((float *)&in2Ba + 1) * v19))
                                      + (float)(in1Aa * v20))
                              - (float)(in0D_0a * v16))
                      - (float)(out2C_0 * v17))
              * v15;
          v78 = (float)((float)((float)((float)((float)(*(float *)&in0Da * v18) + (float)(*(float *)&out2Aa * v19))
                                      + (float)(v71 * v20))
                              - (float)(in0Ea * v16))
                      - (float)(v138 * v17))
              * v15;
          v79 = (float)((float)((float)((float)((float)(*((float *)&in0Da + 1) * v18)
                                              + (float)(*((float *)&out2Aa + 1) * v19))
                                      + (float)(v73 * v20))
                              - (float)(in0F_0a * v16))
                      - (float)(out2E_0 * v17))
              * v15;
          v80 = (float)((float)((float)((float)((float)(in0Fa * v18) + (float)(out2Rb * v19)) + (float)(in1Ba * v20))
                              - (float)(out1Ba * v16))
                      - (float)(out2F_0 * v17))
              * v15;
          v81 = (float)((float)((float)((float)((float)(in0Ga * v18) + (float)(out2Da * v19)) + (float)(in2G_0 * v20))
                              - (float)(out2Ga * v16))
                      - (float)(out2G_0 * v17))
              * v15;
          *(outbuffer - 8) = v75;
          *(outbuffer - 7) = v76;
          *(outbuffer - 6) = v77;
          *(outbuffer - 5) = v78;
          *(outbuffer - 4) = v79;
          *(outbuffer - 3) = v80;
          *(outbuffer - 2) = v81;
          v82 = (float)((float)((float)((float)((float)(in0Ha * v18) + (float)(out2Ea * v19)) + (float)(in2H_0 * v20))
                              - (float)(out2Ha * v16))
                      - (float)(v135 * v17))
              * v15;
          *(outbuffer - 1) = v82;
          if ( !--length )
            break;
          v135 = out2Ha;
          out2G_0 = out2Ga;
          out2F_0 = out1Ba;
          out2E_0 = in0F_0a;
          v138 = in0Ea;
          v130 = out2Fa;
          in2H_0 = out2Ea;
          in2G_0 = out2Da;
          out1Ba = v80;
          in1Ba = out2Rb;
          out2C_0 = in0D_0a;
          out2Ha = v82;
          v72 = out2Ba;
          out2Ga = v81;
          in0F_0a = v79;
          in0Ea = v78;
          in0D_0a = v77;
          out2Ba = v76;
          out2Fa = v75;
          v73 = *((float *)&out2Aa + 1);
          v71 = *(float *)&out2Aa;
          in1Aa = *((float *)&in2Ba + 1);
          v70 = *(float *)&in2Ba;
          v69 = in1Db;
          out2Ea = in0Ha;
          out2Da = in0Ga;
          out2Rb = in0Fa;
          out2Aa = in0Da;
          in2Ba = in0B;
          in1Db = in0A;
        }
      }
      else
      {
        v82 = *((float *)this + 214);
        v81 = *((float *)this + 212);
        out2Ha = *((float *)this + 215);
        out2Ga = *((float *)this + 213);
        v80 = *((float *)this + 210);
        v79 = *((float *)this + 208);
        out1Ba = *((float *)this + 211);
        in0F_0a = *((float *)this + 209);
        v77 = *((float *)this + 204);
        v75 = *((float *)this + 200);
        in0D_0a = *((float *)this + 205);
        out2Fa = *((float *)this + 201);
        in0Ha = *((float *)this + 150);
        out2Ea = *((float *)this + 151);
        in0Ga = *((float *)this + 148);
        v78 = *((float *)this + 206);
        v76 = *((float *)this + 202);
        out2Da = *((float *)this + 149);
        in0Fa = *((float *)this + 146);
        in0Ea = *((float *)this + 207);
        out2Ba = *((float *)this + 203);
        out2Rb = *((float *)this + 147);
        HIDWORD(in0Da) = *((_DWORD *)this + 144);
        HIDWORD(out2Aa) = *((_DWORD *)this + 145);
        LODWORD(in0Da) = *((_DWORD *)this + 142);
        LODWORD(out2Aa) = *((_DWORD *)this + 143);
        HIDWORD(in0B) = *((_DWORD *)this + 140);
        HIDWORD(in2Ba) = *((_DWORD *)this + 141);
        LODWORD(in0B) = *((_DWORD *)this + 138);
        LODWORD(in2Ba) = *((_DWORD *)this + 139);
        in0A = *((float *)this + 136);
        in1Db = *((float *)this + 137);
      }
      *((float *)this + 136) = in0A;
      *((_DWORD *)this + 138) = in0B;
      *((_DWORD *)this + 140) = HIDWORD(in0B);
      *((_DWORD *)this + 142) = in0Da;
      *((_DWORD *)this + 144) = HIDWORD(in0Da);
      *((float *)this + 146) = in0Fa;
      *((float *)this + 148) = in0Ga;
      *((float *)this + 150) = in0Ha;
      *((float *)this + 137) = in1Db;
      *((_DWORD *)this + 139) = in2Ba;
      *((_DWORD *)this + 141) = HIDWORD(in2Ba);
      *((_DWORD *)this + 143) = out2Aa;
      *((_DWORD *)this + 145) = HIDWORD(out2Aa);
      *((float *)this + 147) = out2Rb;
      *((float *)this + 149) = out2Da;
      *((float *)this + 151) = out2Ea;
      *((float *)this + 200) = v75;
      *((float *)this + 202) = v76;
      *((float *)this + 201) = out2Fa;
      *((float *)this + 203) = out2Ba;
      *((float *)this + 205) = in0D_0a;
      *((float *)this + 207) = in0Ea;
      *((float *)this + 209) = in0F_0a;
      *((float *)this + 204) = v77;
      *((float *)this + 206) = v78;
      *((float *)this + 208) = v79;
      *((float *)this + 210) = v80;
      *((float *)this + 212) = v81;
      *((float *)this + 214) = v82;
      *((float *)this + 211) = out1Ba;
      *((float *)this + 213) = out2Ga;
      *((float *)this + 215) = out2Ha;
      break;
    default:
      if ( inchannels > 0 )
      {
        v21 = (float *)((char *)this + 544);
        v22 = 4LL * inchannels;
        v23 = 0;
        v24 = (float *)((char *)this + 8 * (unsigned int)(inchannels - 1) + 552);
        do
        {
          v25 = &inbuffer[v23];
          v26 = &outbuffer[v23];
          v27 = *v21;
          v28 = v21[1];
          v29 = v21[64];
          v30 = v21[65];
          if ( length )
          {
            v31 = length;
            while ( 1 )
            {
              v32 = *v25;
              v25 = (float *)((char *)v25 + v22);
              v33 = (float)((float)((float)((float)((float)(v18 * v32) + (float)(v19 * v27)) + (float)(v28 * v20))
                                  - (float)(v16 * v29))
                          - (float)(v30 * v17))
                  * v15;
              *v26 = v33;
              v26 = (float *)((char *)v26 + v22);
              if ( !--v31 )
                break;
              v30 = v29;
              v28 = v27;
              v29 = v33;
              v27 = v32;
            }
          }
          else
          {
            v33 = v21[64];
            v32 = *v21;
            v29 = v21[65];
            v27 = v21[1];
          }
          *v21 = v32;
          v21 += 2;
          ++v23;
          *(v21 - 1) = v27;
          v21[62] = v33;
          v21[63] = v29;
        }
        while ( v21 != v24 );
      }
      break;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2229ec0 | Name: _ZN4FMOD10DSPParamEq12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPParamEq::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPParamEq::readInternal(
           (FMOD::DSPParamEq *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x2229f50 | Name: _ZN4FMOD10DSPParamEq25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPParamEq::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        __m128 a3,
        __m128 value)
{
  return FMOD::DSPParamEq::setParameterFloatInternal((FMOD::DSPParamEq *const)dsp_state->instance, index, a3, value);
}


// Address: 0x2229f60 | Name: _ZN4FMOD10DSPParamEq25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPParamEq::getParameterFloatInternal(
        FMOD::DSPParamEq *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v5; // xmm0_4

  if ( index == 1 )
  {
    *value = *((float *)this + 271);
    if ( valuestr )
    {
      v5 = *((float *)this + 271);
      goto LABEL_9;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( index == 2 )
  {
    *value = *((float *)this + 272);
    if ( valuestr )
    {
      v5 = *((float *)this + 272);
      goto LABEL_9;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( index )
    return FMOD_RESULT::FMOD_OK_0;
  *value = *((float *)this + 270);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  v5 = *((float *)this + 270);
LABEL_9:
  sprintf(valuestr, "%.02f", v5);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222a000 | Name: _ZN4FMOD10DSPParamEq25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPParamEq::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPParamEq::getParameterFloatInternal(
           (FMOD::DSPParamEq *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


