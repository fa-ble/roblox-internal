// Address: 0x223b5f0 | Name: _ZN4FMOD7SystemI11findChannelEiPNS_6SoundIEPPNS_8ChannelIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::findChannel(
        FMOD::SystemI *const this,
        int id,
        FMOD::SoundI *sound,
        FMOD::ChannelI **channel)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::ChannelI *p_mNodePrev; // r13
  FMOD::LinkedListNode *v9; // rdx
  FMOD::ChannelReal *v10; // rax
  FMOD::ChannelReal *mNodeData; // rdx
  FMOD::SystemI *mNodePrev; // rax
  FMOD_MODE mode; // [rsp+Ch] [rbp-3Ch] BYREF
  FMOD::ChannelReal *realchannel; // [rsp+10h] [rbp-38h] BYREF
  FMOD::DSPCodecPool *pool; // [rsp+18h] [rbp-30h] BYREF

  realchannel = 0;
  if ( !channel )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  result = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD_MODE *))sound->_vptr_SoundI + 36))(sound, &mode);
  if ( result == FMOD_RESULT::FMOD_OK_0
    && ((mode & 0x20000) == 0 || (result = FMOD::SystemI::stopSound(this, sound)) == FMOD_RESULT::FMOD_OK_0) )
  {
    *channel = 0;
    if ( id < 0 )
    {
      mNodeNext = this->mChannelFreeListHead.mNodeNext;
      if ( &this->mChannelFreeListHead.FMOD::LinkedListNode == mNodeNext
        && &this->mChannelFreeListHead.FMOD::LinkedListNode == this->mChannelFreeListHead.mNodePrev )
      {
        mNodePrev = (FMOD::SystemI *)this->mChannelSortedListHead.mNodePrev;
        if ( &this->mChannelSortedListHead == this->mChannelSortedListHead.mNodeNext
          && &this->mChannelSortedListHead == (FMOD::SortedLinkedListNode *)mNodePrev )
        {
          return FMOD_RESULT::FMOD_ERR_CHANNEL_ALLOC_0;
        }
        p_mNodePrev = (FMOD::ChannelI *)mNodePrev->mThreadId[0];
        FMOD::ChannelI::stopEx(p_mNodePrev, 0x1Bu);
      }
      else
      {
        p_mNodePrev = 0;
        if ( mNodeNext )
          p_mNodePrev = (FMOD::ChannelI *)&mNodeNext[-16].mNodePrev;
      }
    }
    else
    {
      if ( id >= this->mNumChannels )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      p_mNodePrev = &this->mChannel[id];
      (*((void (__fastcall **)(FMOD::ChannelI *))p_mNodePrev->_vptr_ChannelControlI + 1))(p_mNodePrev);
    }
    v9 = p_mNodePrev->mNodePrev;
    v9->mNodeNext = p_mNodePrev->mNodeNext;
    p_mNodePrev->mNodeNext->mNodePrev = v9;
    p_mNodePrev->mNodePrev = &p_mNodePrev->FMOD::LinkedListNode;
    p_mNodePrev->mNodePrev = this->mChannelUsedListHead.mNodePrev;
    p_mNodePrev->mNodeNext = &this->mChannelUsedListHead.FMOD::LinkedListNode;
    this->mChannelUsedListHead.mNodePrev = &p_mNodePrev->FMOD::LinkedListNode;
    p_mNodePrev->mNodePrev->FMOD::LinkedListNode::mNodeNext = &p_mNodePrev->FMOD::LinkedListNode;
    ++this->mNumChannelsPlaying;
    if ( (mode & 0x200) != 0
      && (FMOD::SystemI::DSPCodecPoolGet(this, sound->mCodec->mDescription.mPoolType, &pool)
       || FMOD::DSPCodecPool::areAnyFree(pool))
      || FMOD::Output::getFreeChannel(this->mSoftware, &realchannel, 0) )
    {
      result = FMOD::Output::getFreeChannel(this->mEmulated, &realchannel, 0);
      if ( result )
        return result;
      p_mNodePrev->mFlags |= 0x10000u;
    }
    if ( (mode & 0x80u) != 0 )
    {
      v10 = realchannel;
      if ( realchannel->mOutput != this->mEmulated )
      {
        mNodeData = (FMOD::ChannelReal *)sound[1].mNodeData;
        p_mNodePrev->mRealChannel = mNodeData;
        *(_QWORD *)&mNodeData[1].mDirection = v10;
        goto LABEL_18;
      }
    }
    else
    {
      v10 = realchannel;
    }
    p_mNodePrev->mRealChannel = v10;
LABEL_18:
    *channel = p_mNodePrev;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x223b850 | Name: _ZN4FMOD7SystemI11findChannelEiPNS_4DSPIEPPNS_8ChannelIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::findChannel(
        FMOD::SystemI *const this,
        int id,
        FMOD::DSPI *a3,
        FMOD::ChannelI **channel)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelI *p_mNodePrev; // rbp
  FMOD::LinkedListNode *v8; // rdx
  FMOD::OutputSoftware *mSoftware; // rdi
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::SystemI *mNodePrev; // rax
  FMOD::ChannelReal *realchannel[6]; // [rsp+8h] [rbp-30h] BYREF

  realchannel[0] = 0;
  if ( !channel )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *channel = 0;
  if ( id < 0 )
  {
    mNodeNext = this->mChannelFreeListHead.mNodeNext;
    if ( &this->mChannelFreeListHead.FMOD::LinkedListNode == mNodeNext
      && &this->mChannelFreeListHead.FMOD::LinkedListNode == this->mChannelFreeListHead.mNodePrev )
    {
      mNodePrev = (FMOD::SystemI *)this->mChannelSortedListHead.mNodePrev;
      if ( &this->mChannelSortedListHead == this->mChannelSortedListHead.mNodeNext
        && &this->mChannelSortedListHead == (FMOD::SortedLinkedListNode *)mNodePrev )
      {
        return FMOD_RESULT::FMOD_ERR_CHANNEL_ALLOC_0;
      }
      p_mNodePrev = (FMOD::ChannelI *)mNodePrev->mThreadId[0];
      FMOD::ChannelI::stopEx(p_mNodePrev, 0x1Bu);
    }
    else
    {
      p_mNodePrev = 0;
      if ( mNodeNext )
        p_mNodePrev = (FMOD::ChannelI *)&mNodeNext[-16].mNodePrev;
    }
  }
  else
  {
    if ( id >= this->mNumChannels )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    p_mNodePrev = &this->mChannel[id];
    (*((void (__fastcall **)(FMOD::ChannelI *, int, FMOD::DSPI *))p_mNodePrev->_vptr_ChannelControlI + 1))(
      p_mNodePrev,
      id,
      a3);
  }
  v8 = p_mNodePrev->mNodePrev;
  mSoftware = this->mSoftware;
  v8->mNodeNext = p_mNodePrev->mNodeNext;
  p_mNodePrev->mNodeNext->mNodePrev = v8;
  p_mNodePrev->mNodePrev = &p_mNodePrev->FMOD::LinkedListNode;
  p_mNodePrev->mNodePrev = this->mChannelUsedListHead.mNodePrev;
  p_mNodePrev->mNodeNext = &this->mChannelUsedListHead.FMOD::LinkedListNode;
  this->mChannelUsedListHead.mNodePrev = &p_mNodePrev->FMOD::LinkedListNode;
  p_mNodePrev->mNodePrev->FMOD::LinkedListNode::mNodeNext = &p_mNodePrev->FMOD::LinkedListNode;
  ++this->mNumChannelsPlaying;
  if ( FMOD::Output::getFreeChannel(mSoftware, realchannel, 0) == FMOD_RESULT::FMOD_OK_0
    || (result = FMOD::Output::getFreeChannel(this->mEmulated, realchannel, 0)) == FMOD_RESULT::FMOD_OK_0 )
  {
    p_mNodePrev->mRealChannel = realchannel[0];
    *channel = p_mNodePrev;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x223b9f0 | Name: _ZN4FMOD7SystemI26createChannelGroupInternalEPKcPPNS_13ChannelGroupIEb
FMOD_RESULT_0 __fastcall FMOD::SystemI::createChannelGroupInternal(
        FMOD::SystemI *const this,
        const char *name,
        FMOD::ChannelGroupI **channelgroup,
        bool storenameinchannelgroup)
{
  FMOD_RESULT_0 v5; // ebp
  FMOD::ChannelGroupI *v9; // rax
  FMOD::ChannelGroupI *v10; // rbx
  FMOD::LinkedListNode *mNodeNext; // rdx
  FMOD::FMOD_DSP_DESCRIPTION_EX *Description; // rax
  const FMOD_DSP_DESCRIPTION *mDescription; // rsi
  FMOD_DSP_DESCRIPTION_0 *p_description_mem; // rdx
  FMOD::DSPI *v16; // rdi
  bool v17; // zf
  const char *v18; // rdi
  __int64 v19; // rcx
  const char *v20; // rsi
  FMOD::ChannelGroupI *mMasterChannelGroup; // rdi
  int (**vptr_ChannelControlI)(...); // rax
  char *v23; // rax
  FMOD::DSPI *dspfader; // [rsp+8h] [rbp-160h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_EX description_ex; // [rsp+10h] [rbp-158h] BYREF
  FMOD_DSP_DESCRIPTION_0 description_mem; // [rsp+50h] [rbp-118h] BYREF

  v5 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !channelgroup )
    return v5;
  v9 = (FMOD::ChannelGroupI *)FMOD::MemPool::calloc(
                                off_286F358->gSystemMemPool,
                                592,
                                "../../../core_api/src/fmod_systemi_channel.cpp",
                                293,
                                0);
  v10 = v9;
  if ( !v9 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  FMOD::ChannelGroupI::ChannelGroupI(v9);
  mNodeNext = this->mChannelGroupListHead.mNodeNext;
  v10->mNode.mNodePrev = &this->mChannelGroupListHead;
  v10->mNode.mNodeNext = mNodeNext;
  mNodeNext->mNodePrev = &v10->mNode;
  v10->mNode.mNodePrev->mNodeNext = &v10->mNode;
  v10->mNode.mNodeData = v10;
  v10->mSystem = this;
  v10->mHandleCurrent = (FMOD_UINT_NATIVE)v10;
  v10->mGeometryTask.state = OCCLUSION_STATE_READY;
  v10->mGeometryTask.mNodePrev = &v10->mGeometryTask;
  v10->mGeometryTask.mNodeNext = &v10->mGeometryTask;
  v10->mGeometryTask.mNodeData = 0;
  Description = FMOD::DSPFader::getDescriptionEx();
  mDescription = Description->mDescription;
  description_ex = *Description;
  p_description_mem = 0;
  if ( channelgroup == &this->mMasterChannelGroup )
  {
    p_description_mem = &description_mem;
    description_ex.mSize = 688;
    qmemcpy(&description_mem, mDescription, sizeof(description_mem));
    description_mem.numoutputbuffers = 0;
  }
  description_ex.mName = "ChanGroup Fader";
  v5 = FMOD::SystemI::createDSP(this, &description_ex, p_description_mem, &dspfader, 1);
  if ( v5 )
    goto LABEL_6;
  v16 = dspfader;
  v10->mNumDSPs = 1;
  v10->mDSP = 0;
  v10->mDSPFader = (FMOD::DSPFader *)v16;
  v10->mDSPHead = v16;
  v10->mDSPTail = v16;
  v16->mJob.mFlags |= 0x180u;
  v16->mChannelOwner = v10;
  FMOD::DSPI::setActive(v16, 1, 1);
  if ( name && storenameinchannelgroup )
  {
    v23 = FMOD_strdup(name);
    v17 = v23 == 0;
    v10->mName = v23;
    if ( !v23 )
    {
      v5 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
LABEL_6:
      FMOD::ChannelGroupI::release(v10);
      return v5;
    }
  }
  else
  {
    v17 = name == 0;
    v10->mName = 0;
    if ( !name )
    {
LABEL_15:
      mMasterChannelGroup = this->mMasterChannelGroup;
      if ( !mMasterChannelGroup
        || v10 == mMasterChannelGroup
        || (v5 = FMOD::ChannelGroupI::addGroup(mMasterChannelGroup, v10, 1, 0)) == FMOD_RESULT::FMOD_OK_0 )
      {
        *channelgroup = v10;
        return FMOD_RESULT::FMOD_OK_0;
      }
      return v5;
    }
  }
  v18 = "ReturnBus";
  v19 = 9;
  v20 = name;
  do
  {
    if ( !v19 )
      break;
    v17 = *v20++ == *v18++;
    --v19;
  }
  while ( v17 );
  if ( !v17 )
    goto LABEL_15;
  vptr_ChannelControlI = v10->_vptr_ChannelControlI;
  v10->mFlags |= 0x40u;
  v5 = vptr_ChannelControlI[65](v10, v20);
  if ( v5 == FMOD_RESULT::FMOD_OK_0 )
    goto LABEL_15;
  return v5;
}


