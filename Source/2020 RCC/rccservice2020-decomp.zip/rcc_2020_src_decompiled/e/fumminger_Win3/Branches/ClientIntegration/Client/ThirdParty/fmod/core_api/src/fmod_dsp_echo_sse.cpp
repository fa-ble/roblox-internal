// Address: 0x221c130 | Name: FMOD_DSP_Echo_Process_SSE
void __fastcall FMOD_DSP_Echo_Process_SSE(
        float *outbuffer,
        float *inbuffer,
        __int16 *delaybuffermem,
        unsigned int delayread_in,
        unsigned int delaywrite_in,
        unsigned int *delayread_out,
        __m128 wetmix,
        __m128 drymix,
        __m128 feedback,
        unsigned int *delaywrite_out,
        unsigned int delaybufferlen,
        int length,
        int channels)
{
  int v13; // ecx
  int v14; // eax
  unsigned int v15; // r10d
  int v16; // r8d
  int v17; // ebp
  float v18; // xmm3_4
  float v19; // xmm4_4
  float v20; // xmm3_4
  int v21; // r13d
  __m128 v22; // xmm12
  float *v23; // rbp
  __m128 v24; // xmm11
  float *v25; // r11
  __m128 v26; // xmm10
  __m128 v27; // xmm13
  __m128i si128; // xmm3
  __m128 v29; // xmm5
  __m128 v30; // xmm4
  __m128 v31; // xmm14
  __m128 v32; // xmm5
  __m128 v33; // xmm4
  __m128 v34; // xmm6
  __m128 v35; // xmm3
  __m128 v36; // xmm5
  unsigned int v37; // eax
  __int64 v38; // r11
  __int64 v39; // r11
  int v40; // ebp
  float v41; // xmm3_4
  float v42; // xmm4_4
  float v43; // xmm3_4

  v13 = channels * delayread_in;
  v14 = channels * length;
  v15 = channels * delaybufferlen;
  v16 = channels * delaywrite_in;
  if ( channels * length )
  {
    if ( (v13 & 7) != 0 )
    {
      while ( 1 )
      {
        LOWORD(v17) = 0x7FFF;
        v18 = (float)delaybuffermem[v13] * 0.000030518509;
        v19 = (float)(drymix.m128_f32[0] * *inbuffer) + (float)(wetmix.m128_f32[0] * v18);
        v20 = (float)(v18 * feedback.m128_f32[0]) + *inbuffer;
        *outbuffer = v19;
        if ( v20 <= 1.0 )
        {
          LOWORD(v17) = 0x8000;
          if ( v20 >= -1.0 )
            v17 = (int)(float)(v20 * 32767.0);
        }
        delaybuffermem[v16] = v17;
        ++inbuffer;
        ++outbuffer;
        v16 = v16 + 1 - (v15 & ((int)(v15 - (v16 + 1) - 1) >> 31));
        v13 = v13 + 1 - (v15 & ((int)(v15 - (v13 + 1) - 1) >> 31));
        if ( !--v14 )
          break;
        if ( (v13 & 7) == 0 )
          goto LABEL_10;
      }
    }
    else
    {
LABEL_10:
      if ( v14 > 7 )
      {
        v21 = v14;
        v22 = _mm_shuffle_ps(wetmix, wetmix, 0);
        v23 = inbuffer;
        v24 = _mm_shuffle_ps(drymix, drymix, 0);
        v25 = outbuffer;
        v26 = _mm_shuffle_ps(feedback, feedback, 0);
        do
        {
          v27 = *(__m128 *)v23;
          v21 -= 8;
          v23 += 8;
          si128 = _mm_load_si128((const __m128i *)&delaybuffermem[v13]);
          v29 = _mm_mul_ps(_mm_cvtepi32_ps(_mm_srai_epi32(si128, 0x10u)), *(__m128 *)scale16data_0);
          v25 += 8;
          v30 = _mm_mul_ps(
                  _mm_cvtepi32_ps(_mm_srai_epi32(_mm_slli_epi32(si128, 0x10u), 0x10u)),
                  *(__m128 *)scale16data_0);
          v31 = _mm_unpackhi_ps(v30, v29);
          v32 = _mm_unpacklo_ps(v30, v29);
          v33 = _mm_mul_ps(v32, v26);
          v34 = _mm_add_ps(_mm_mul_ps(v27, v24), _mm_mul_ps(v32, v22));
          v35 = _mm_mul_ps(_mm_add_ps(_mm_mul_ps(v31, v26), *(__m128 *)(v23 - 4)), *(__m128 *)mul16data);
          v36 = _mm_mul_ps(*(__m128 *)(v23 - 4), v24);
          *((__m128 *)v25 - 2) = v34;
          *((__m128 *)v25 - 1) = _mm_add_ps(v36, _mm_mul_ps(v31, v22));
          *(__m128i *)&delaybuffermem[v16] = _mm_packs_epi32(
                                               _mm_cvtps_epi32(_mm_mul_ps(_mm_add_ps(v33, v27), *(__m128 *)mul16data)),
                                               _mm_cvtps_epi32(v35));
          v16 = v16 + 8 - (v15 & ((int)(v15 - (v16 + 8) - 1) >> 31));
          v13 = v13 + 8 - (v15 & ((int)(v15 - (v13 + 8) - 1) >> 31));
        }
        while ( v21 > 7 );
        v37 = v14 - 8;
        v38 = v37 >> 3;
        v14 = v37 - 8 * v38;
        v39 = 32 * (v38 + 1);
        inbuffer = (float *)((char *)inbuffer + v39);
        outbuffer = (float *)((char *)outbuffer + v39);
      }
      for ( ; v14; --v14 )
      {
        LOWORD(v40) = 0x7FFF;
        v41 = (float)delaybuffermem[v13] * 0.000030518509;
        v42 = (float)(drymix.m128_f32[0] * *inbuffer) + (float)(wetmix.m128_f32[0] * v41);
        v43 = (float)(v41 * feedback.m128_f32[0]) + *inbuffer;
        *outbuffer = v42;
        if ( v43 <= 1.0 )
        {
          LOWORD(v40) = 0x8000;
          if ( v43 >= -1.0 )
            v40 = (int)(float)(v43 * 32767.0);
        }
        delaybuffermem[v16] = v40;
        ++inbuffer;
        ++outbuffer;
        v16 = v16 + 1 - (v15 & ((int)(v15 - (v16 + 1) - 1) >> 31));
        v13 = v13 + 1 - (v15 & ((int)(v15 - (v13 + 1) - 1) >> 31));
      }
    }
  }
  *delayread_out = v13 / channels;
  *delaywrite_out = v16 / channels;
}


