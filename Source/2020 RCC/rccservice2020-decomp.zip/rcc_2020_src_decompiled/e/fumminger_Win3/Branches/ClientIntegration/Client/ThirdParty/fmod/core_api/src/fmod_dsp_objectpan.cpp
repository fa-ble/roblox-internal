// Address: 0x2252cc0 | Name: _ZN4FMOD12DSPObjectPan16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPObjectPan::getDescriptionEx()
{
  memset(&stru_2B05E20, 0, sizeof(stru_2B05E20));
  stru_2B05E20.type = FMOD_DSP_PARAMETER_TYPE_DATA;
  FMOD_strcpy_safe(stru_2B05E20.name, "3D Position", 16);
  FMOD_strcpy_safe(stru_2B05E20.label, "Deg.", 16);
  stru_2B05E20.intdesc.min = -5;
  stru_2B05E20.description = "3D Position";
  memset(&stru_2B05DC0, 0, sizeof(stru_2B05DC0));
  stru_2B05DC0.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2B05DC0.name, "3D Rolloff", 16);
  FMOD_strcpy_safe(stru_2B05DC0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2B05DC0.floatdesc.min = 0x400000000LL;
  stru_2B05DC0.description = "3D Rolloff";
  memset(&stru_2B05D60, 0, sizeof(stru_2B05D60));
  *(_OWORD *)(&stru_2B05DC0.datadesc + 2) = 0u;
  FMOD_strcpy_safe(stru_2B05D60.name, "3D Min Distance", 16);
  FMOD_strcpy_safe(stru_2B05D60.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2B05D60.floatdesc.min = 0x5D5E0B6B00000000LL;
  stru_2B05D60.description = "3D Min Distance";
  memset(&stru_2B05D00, 0, sizeof(stru_2B05D00));
  stru_2B05D60.intdesc.defaultval = 1065353216;
  stru_2B05D60.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B05D00.name, "3D Max Distance", 16);
  FMOD_strcpy_safe(stru_2B05D00.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2B05D00.floatdesc.min = 0x5D5E0B6B00000000LL;
  stru_2B05D00.description = "3D Max Distance";
  memset(&stru_2B05CA0, 0, sizeof(stru_2B05CA0));
  stru_2B05D00.intdesc.defaultval = 1101004800;
  stru_2B05D00.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B05CA0.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2B05CA0.name, "3D Extent Mode", 16);
  FMOD_strcpy_safe(stru_2B05CA0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2B05CA0.floatdesc.min = 0x200000000LL;
  stru_2B05CA0.description = "3D Extent Mode";
  memset(&stru_2B05C40, 0, sizeof(stru_2B05C40));
  *(_OWORD *)(&stru_2B05CA0.datadesc + 2) = 0u;
  FMOD_strcpy_safe(stru_2B05C40.name, "3D Sound Size", 16);
  FMOD_strcpy_safe(stru_2B05C40.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2B05C40.floatdesc.min = 0x5D5E0B6B00000000LL;
  stru_2B05C40.description = "3D Sound Size";
  memset(&stru_2B05BE0, 0, sizeof(stru_2B05BE0));
  stru_2B05C40.intdesc.defaultval = 0;
  stru_2B05C40.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B05BE0.name, "3D Min Extent", 16);
  FMOD_strcpy_safe(stru_2B05BE0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2B05BE0.floatdesc.min = 0x43B4000000000000LL;
  stru_2B05BE0.description = "3D Min Extent";
  memset(&stru_2B05B80, 0, sizeof(stru_2B05B80));
  stru_2B05BE0.intdesc.defaultval = 0;
  stru_2B05BE0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B05B80.type = FMOD_DSP_PARAMETER_TYPE_DATA;
  FMOD_strcpy_safe(stru_2B05B80.name, "Overall Gain", 16);
  FMOD_strcpy_safe(stru_2B05B80.label, (const char *)&uri_string, 16);
  stru_2B05B80.intdesc.min = -1;
  stru_2B05B80.description = "Overall Gain";
  memset(&stru_2B05B20, 0, sizeof(stru_2B05B20));
  FMOD_strcpy_safe(stru_2B05B20.name, "Output Gain", 16);
  FMOD_strcpy_safe(stru_2B05B20.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2B05B20.floatdesc.min = 0x41A0000000000000LL;
  stru_2B05B20.intdesc.defaultval = 1065353216;
  stru_2B05B20.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B05B20.description = "Output Gain";
  *(&stru_2B05AE0.mHandle + 1) = 35;
  stru_2B05AE0.mSize = 688;
  stru_2B05AE0.mDescription = &stru_286F980;
  stru_2B05AE0.mCommand = FMOD::DSPObjectPan::commandCallback;
  stru_2B05AE0.mCommandMask = 129;
  return &stru_2B05AE0;
}


// Address: 0x2253160 | Name: _ZN4FMOD12DSPObjectPan14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::createInternal(FMOD::DSPObjectPan *const this)
{
  double v1; // xmm1_8
  FMOD_RESULT_0 result; // eax
  __int64 v3; // rax
  __int64 v4; // rbp
  int v5; // ebx
  _DWORD *v6; // rdx

  *((_DWORD *)this + 133) = 0;
  *((_DWORD *)this + 134) = 1065353216;
  result = FMOD::SystemI::getChannelLayout(
             *((FMOD::SystemI *const *)this + 22),
             FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0,
             (const FMOD::ChannelLayout **)this + 68);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v3 = *((_QWORD *)this + 30);
    *((_WORD *)this + 46) |= 0x20u;
    v4 = 0;
    v5 = 0;
    if ( *(int *)(v3 + 96) <= 0 )
    {
LABEL_11:
      *((_DWORD *)this + 153) = 0;
      *((_DWORD *)this + 152) = 0;
      return FMOD::SystemI::allocObject3DHandle(*((FMOD::SystemI *const *)this + 22), (void **)this + 77);
    }
    while ( 1 )
    {
      v6 = *(_DWORD **)(*(_QWORD *)(v3 + 104) + v4);
      if ( !*v6 )
        break;
      if ( *v6 == 1 )
      {
        result = FMOD::DSPI::setParameterInt((FMOD::DSPI *const)this, v5, v6[14]);
        if ( result )
          return result;
LABEL_6:
        v3 = *((_QWORD *)this + 30);
      }
      ++v5;
      v4 += 8;
      if ( *(_DWORD *)(v3 + 96) <= v5 )
        goto LABEL_11;
    }
    result = FMOD::DSPI::setParameterFloat((FMOD::DSPI *const)this, v5, (__m128i)(unsigned int)v6[14], v1);
    if ( result )
      return result;
    goto LABEL_6;
  }
  return result;
}


// Address: 0x2253240 | Name: _ZN4FMOD12DSPObjectPan14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPObjectPan::createInternal((FMOD::DSPObjectPan *const)dsp_state->instance);
}


// Address: 0x2253250 | Name: _ZN4FMOD12DSPObjectPan15processInternalEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::processInternal(
        FMOD::DSPObjectPan *const this,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  float v6; // xmm1_4
  void *v10; // rsi
  FMOD::SystemI *v11; // rdi
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v13; // rsi
  float v14; // xmm0_4
  FMOD::Object3DMetaData *v15; // rdx
  FMOD_RESULT_0 v16; // edx
  FMOD::Object3DMetaData *v17; // rax
  unsigned int v18; // edx
  float *mMatrix; // rdi
  __int64 v20; // rcx
  float *v21; // rdi
  FMOD::Object3DMetaData *v22; // rbp
  float v23; // xmm5_4
  float v24; // xmm3_4
  float v25; // xmm4_4
  __m128 v26; // xmm0
  int v27; // xmm6_4
  __m128 v28; // xmm1
  float v29; // xmm0_4
  float v30; // xmm0_4
  FMOD::Object3DMetaData *info; // [rsp+28h] [rbp-E0h] BYREF
  FMOD::DSPConnectionI connection; // [rsp+30h] [rbp-D8h] BYREF

  if ( op == FMOD_DSP_PROCESS_QUERY )
    return inputsidle != 0 ? 0xB : 0;
  v10 = (void *)*((_QWORD *)this + 77);
  v11 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  info = 0;
  result = FMOD::SystemI::prepareObject3DInfo(v11, v10, &info);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    connection.mMixMatrix.mInChannels = 0;
    v13 = (FMOD::SystemI *)*((_QWORD *)this + 22);
    connection.mInputNode.mNodePrev = &connection.mInputNode;
    connection.mInputNode.mNodeNext = &connection.mInputNode;
    connection.mMixMatrix.mOutChannels = 0;
    v14 = *((float *)this + 151);
    connection.mInputNode.mNodeData = 0;
    connection.mOutputNode.mNodePrev = &connection.mOutputNode;
    connection.mOutputNode.mNodeNext = &connection.mOutputNode;
    connection.mOutputNode.mNodeData = 0;
    connection.mMixMatrix.mData = 0;
    memset(&connection.mMixMatrixCurrent.mData, 0, 24);
    connection.mMixMatrixCurrent.mInChannels = 0;
    connection.mMixMatrixCurrent.mOutChannels = 0;
    connection.mUserData.mMixMatrixUser.mData = 0;
    connection.mUserData.mMixMatrixUser.mInChannels = 0;
    connection.mUserData.mMixMatrixUser.mOutChannels = 0;
    connection.mSystem = 0;
    result = (unsigned int)FMOD::DSPConnectionI::init(&connection, v13, v14, v6);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::DSPConnectionI::mix(
                 &connection,
                 info->mBuffer,
                 *inbufferarray->buffers,
                 0,
                 1,
                 *inbufferarray->buffernumchannels,
                 length,
                 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( *((_BYTE *)this + 624) )
        {
          v17 = info;
          v18 = 48;
          mMatrix = info->mMatrix;
          if ( (((_BYTE)info + 16) & 1) != 0 )
          {
            LOBYTE(info->mMatrix[0]) = 0;
            mMatrix = (float *)((char *)v17->mMatrix + 1);
            LOBYTE(v18) = 47;
          }
          if ( ((unsigned __int8)mMatrix & 2) != 0 )
          {
            mMatrix = (float *)((char *)mMatrix + 2);
            v18 -= 2;
            *((_WORD *)mMatrix - 1) = 0;
          }
          if ( ((unsigned __int8)mMatrix & 4) != 0 )
          {
            *mMatrix = 0.0;
            v18 -= 4;
            ++mMatrix;
          }
          v20 = v18 >> 3;
          memset(mMatrix, 0, 8 * v20);
          v21 = &mMatrix[2 * v20];
          if ( (v18 & 4) != 0 )
            *v21++ = 0.0;
          if ( (v18 & 2) != 0 )
          {
            v21 = (float *)((char *)v21 + 2);
            *((_WORD *)v21 - 1) = 0;
          }
          if ( (v18 & 1) != 0 )
            *(_BYTE *)v21 = 0;
          FMOD::ChannelLayout::sumSurroundMatrixMono(
            *((const FMOD::ChannelLayout **)this + 68),
            *((float *)this + 138),
            *((float *)this + 135),
            0.0,
            1.0,
            1,
            info->mMatrix);
          v22 = info;
          v23 = *((float *)this + 148);
          v24 = *((float *)this + 149);
          v25 = *((float *)this + 150);
          info->mSpread = *((float *)this + 135);
          v26 = (__m128)*((unsigned int *)this + 132);
          v27 = *((_DWORD *)this + 132);
          v22->mPosition.x = v23;
          v28 = _mm_cmplt_ss(v26, (__m128)0x3F800000u);
          v22->mPosition.y = v24;
          v22->mPosition.z = v25;
          LODWORD(v22->mGain) = _mm_andnot_ps(v28, (__m128)0x3F800000u).m128_u32[0] | v27 & v28.m128_i32[0];
          if ( v24 <= 0.0 )
          {
            v15 = v22;
            v30 = (float)(1.0 - v26.m128_f32[0]) + 1.0;
            v22->mPriority = v30;
          }
          else
          {
            v29 = atan2f(v24, fsqrt((float)(v23 * v23) + (float)(v25 * v25)));
            v15 = info;
            v22->mPriority = v29 / 1.5707964;
            v30 = 1.0 - (float)(v15->mPriority * *((float *)this + 132));
            v15->mPriority = v30;
          }
          v15->mPriority = v30 * 0.5;
          *((_BYTE *)this + 624) = 0;
        }
        else
        {
          v15 = info;
        }
        v16 = FMOD::SystemI::commitObject3DInfo(*((FMOD::SystemI *const *)this + 22), *((void **)this + 77), v15);
        result = FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
        if ( v16 )
          return v16;
      }
    }
  }
  return result;
}


// Address: 0x22535d0 | Name: _ZN4FMOD12DSPObjectPan15processCallbackEP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS3_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::processCallback(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  return FMOD::DSPObjectPan::processInternal(
           (FMOD::DSPObjectPan *const)dsp_state->instance,
           length,
           inbufferarray,
           outbufferarray,
           inputsidle,
           op);
}


// Address: 0x22535e0 | Name: _ZN4FMOD12DSPObjectPan16updateParametersEv
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::updateParameters(FMOD::DSPObjectPan *const this)
{
  float v1; // xmm4_4
  __int64 v2; // rsi
  __int64 v3; // rdx
  float v4; // xmm0_4
  __int64 v5; // rcx
  __int64 v6; // rsi
  __int64 v7; // rcx
  unsigned __int64 v8; // rcx
  unsigned __int64 v9; // rcx
  float v10; // xmm1_4
  float v11; // xmm3_4
  float v12; // xmm2_4
  __int64 v13; // rdx
  __int64 v14; // rcx
  float v16; // xmm1_4
  float v17; // xmm2_4
  float v18; // xmm6_4
  float v19; // xmm3_4
  __int64 v20; // rdx
  __int64 v21; // rcx

  if ( *((float *)this + 139) == *((float *)this + 158)
    && *((float *)this + 140) == *((float *)this + 159)
    && *((float *)this + 143) == *((float *)this + 162)
    && *((_DWORD *)this + 145) == *((_DWORD *)this + 164)
    && *((float *)this + 146) == *((float *)this + 165)
    && *((float *)this + 147) == *((float *)this + 166) )
  {
    if ( *((_DWORD *)this + 142) == *((_DWORD *)this + 161) && *((float *)this + 144) == *((float *)this + 163) )
    {
      v20 = *(_QWORD *)((char *)this + 676);
      *((_QWORD *)this + 69) = *(_QWORD *)((char *)this + 628);
      v21 = *(_QWORD *)((char *)this + 636);
      *((_QWORD *)this + 75) = v20;
      *((_QWORD *)this + 70) = v21;
      *((_QWORD *)this + 71) = *(_QWORD *)((char *)this + 644);
      *((_QWORD *)this + 72) = *(_QWORD *)((char *)this + 652);
      *((_QWORD *)this + 73) = *(_QWORD *)((char *)this + 660);
      *((_QWORD *)this + 74) = *(_QWORD *)((char *)this + 668);
      return FMOD_RESULT::FMOD_OK_0;
    }
    v13 = *(_QWORD *)((char *)this + 676);
    *((_QWORD *)this + 69) = *(_QWORD *)((char *)this + 628);
    v14 = *(_QWORD *)((char *)this + 636);
    *((_QWORD *)this + 75) = v13;
    *((_QWORD *)this + 70) = v14;
    *((_QWORD *)this + 71) = *(_QWORD *)((char *)this + 644);
    v10 = *((float *)this + 143);
    *((_QWORD *)this + 72) = *(_QWORD *)((char *)this + 652);
    *((_QWORD *)this + 73) = *(_QWORD *)((char *)this + 660);
    *((_QWORD *)this + 74) = *(_QWORD *)((char *)this + 668);
  }
  else
  {
    v2 = *(_QWORD *)((char *)this + 660);
    v3 = *(_QWORD *)((char *)this + 676);
    v4 = 0.0;
    *((_QWORD *)this + 69) = *(_QWORD *)((char *)this + 628);
    v5 = *(_QWORD *)((char *)this + 636);
    *((_QWORD *)this + 73) = v2;
    v6 = *(_QWORD *)((char *)this + 668);
    *((_DWORD *)this + 135) = 0;
    *((_QWORD *)this + 75) = v3;
    *((_QWORD *)this + 70) = v5;
    v7 = *(_QWORD *)((char *)this + 644);
    *((_QWORD *)this + 74) = v6;
    *((_QWORD *)this + 71) = v7;
    v8 = *(_QWORD *)((char *)this + 652);
    *((_QWORD *)this + 72) = v8;
    v9 = HIDWORD(v8);
    if ( (_DWORD)v9 )
    {
      if ( (_DWORD)v9 == 1 )
      {
        v16 = *((float *)this + 146);
        v1 = *((float *)this + 147);
        v17 = *((float *)this + 140);
        if ( v16 <= 0.0 )
        {
          v1 = fmaxf(v1, 0.0);
          v19 = v1;
        }
        else
        {
          v18 = 0.0;
          if ( (float)(v16 * 5.0) > v17 )
            v18 = 360.0 / (float)((float)((float)((float)(v17 * v17) / (float)(v16 * v16)) * 4.0) + 1.0);
          v19 = *((float *)this + 147);
          if ( v1 <= v18 )
          {
            v19 = 0.0;
            if ( (float)(5.0 * v16) > v17 )
              v19 = 360.0 / (float)((float)((float)((float)(v17 * v17) / (float)(v16 * v16)) * 4.0) + 1.0);
          }
        }
        *((float *)this + 135) = v19;
      }
      v10 = *((float *)this + 143);
    }
    else
    {
      v10 = *((float *)this + 143);
      v11 = *((float *)this + 140);
      v12 = v10 + v10;
      if ( (float)(v10 + v10) > 0.0 )
      {
        v1 = 5.0 * v12;
        if ( (float)(5.0 * v12) > v11 )
          v4 = 360.0 / (float)((float)((float)((float)(v11 * v11) / (float)(v12 * v12)) * 4.0) + 1.0);
      }
      *((float *)this + 135) = v4;
    }
  }
  FMOD::getRolloffGain(
    *((FMOD_DSP_PAN_3D_ROLLOFF_TYPE *)this + 142),
    *((float *)this + 139),
    v10,
    *((float *)this + 144),
    *(float *)((char *)&stru_11358.r_offset + *((_QWORD *)this + 22)),
    (float *)this + 132,
    v1);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2253970 | Name: _ZN4FMOD12DSPObjectPan25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPObjectPan::setParameterFloatInternal(
        FMOD::DSPObjectPan *const this,
        int index,
        __m128 a3,
        float value)
{
  __int64 result; // rax
  int v5; // eax
  unsigned __int32 v6; // xmm0_4
  __m128 v7; // xmm1
  unsigned __int32 v8; // xmm0_4
  __m128 v9; // xmm1
  unsigned __int32 v10; // xmm0_4
  int v11; // eax
  unsigned __int32 v12; // xmm0_4
  __m128 v13; // xmm1
  __m128 v14; // xmm1

  switch ( index )
  {
    case 1:
      v5 = 0;
      if ( a3.m128_f32[0] >= 0.0 )
      {
        v5 = (int)a3.m128_f32[0];
        if ( a3.m128_f32[0] > 4.0 )
          v5 = 4;
      }
      *((_DWORD *)this + 161) = v5;
      goto LABEL_11;
    case 2:
      if ( a3.m128_f32[0] >= 0.0 )
      {
        v9 = _mm_cmplt_ss((__m128)0x5D5E0B6Bu, a3);
        v6 = _mm_andnot_ps(v9, a3).m128_u32[0] | v9.m128_i32[0] & 0x5D5E0B6B;
      }
      else
      {
        v6 = 0;
      }
      *((_DWORD *)this + 162) = v6;
      goto LABEL_11;
    case 3:
      if ( a3.m128_f32[0] < 0.0 )
      {
        v8 = 0;
      }
      else
      {
        v7 = _mm_cmplt_ss((__m128)0x5D5E0B6Bu, a3);
        v8 = _mm_andnot_ps(v7, a3).m128_u32[0] | v7.m128_i32[0] & 0x5D5E0B6B;
      }
      *((_DWORD *)this + 163) = v8;
      goto LABEL_11;
    case 4:
      v11 = 0;
      if ( a3.m128_f32[0] >= 0.0 )
      {
        v11 = (int)a3.m128_f32[0];
        if ( a3.m128_f32[0] > 2.0 )
          v11 = 2;
      }
      *((_DWORD *)this + 164) = v11;
      goto LABEL_11;
    case 5:
      if ( a3.m128_f32[0] >= 0.0 )
      {
        v13 = _mm_cmplt_ss((__m128)0x5D5E0B6Bu, a3);
        v10 = _mm_andnot_ps(v13, a3).m128_u32[0] | v13.m128_i32[0] & 0x5D5E0B6B;
      }
      else
      {
        v10 = 0;
      }
      *((_DWORD *)this + 165) = v10;
      goto LABEL_11;
    case 6:
      if ( a3.m128_f32[0] >= 0.0 )
      {
        v14 = _mm_cmplt_ss((__m128)0x43B40000u, a3);
        v12 = _mm_andnot_ps(v14, a3).m128_u32[0] | v14.m128_i32[0] & 0x43B40000;
      }
      else
      {
        v12 = 0;
      }
      *((_DWORD *)this + 166) = v12;
      goto LABEL_11;
  }
  result = 31;
  if ( index == 8 )
  {
    *((_DWORD *)this + 170) = a3.m128_i32[0];
LABEL_11:
    ++*((_DWORD *)this + 153);
    return 0;
  }
  return result;
}


// Address: 0x2253b40 | Name: _ZN4FMOD12DSPObjectPan25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPObjectPan::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        __m128 a3,
        float value)
{
  return FMOD::DSPObjectPan::setParameterFloatInternal((FMOD::DSPObjectPan *const)dsp_state->instance, index, a3, value);
}


// Address: 0x2253b50 | Name: _ZN4FMOD12DSPObjectPan25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::getParameterFloatInternal(
        FMOD::DSPObjectPan *const this,
        int index,
        float *value,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( value )
  {
    switch ( index )
    {
      case 1:
        *value = (float)*((int *)this + 161);
        break;
      case 2:
        *value = *((float *)this + 162);
        break;
      case 3:
        *value = *((float *)this + 163);
        break;
      case 4:
        *value = (float)*((int *)this + 164);
        break;
      case 5:
        *value = *((float *)this + 165);
        break;
      case 6:
        *value = *((float *)this + 166);
        break;
      case 8:
        *value = *((float *)this + 170);
        break;
      default:
        return result;
    }
    if ( valuestr )
      *valuestr = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2253c40 | Name: _ZN4FMOD12DSPObjectPan25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPObjectPan::getParameterFloatInternal(
           (FMOD::DSPObjectPan *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x2253c50 | Name: _ZN4FMOD12DSPObjectPan23setParameterIntInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::setParameterIntInternal(
        FMOD::DSPObjectPan *const this,
        int index,
        int value)
{
  FMOD_RESULT_0 result; // eax
  int v4; // eax
  int v5; // edx
  FMOD_RESULT_0 v6; // edx

  if ( index == 1 )
  {
    v4 = 4;
    if ( value <= 4 )
      v4 = value;
    v5 = 0;
    if ( v4 >= 0 )
      v5 = v4;
    *((_DWORD *)this + 161) = v5;
    goto LABEL_9;
  }
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index == 4 )
  {
    LOBYTE(result) = 2;
    if ( value <= 2 )
      result = value;
    v6 = FMOD_RESULT::FMOD_OK_0;
    if ( result >= FMOD_RESULT::FMOD_OK_0 )
      v6 = result;
    *((_DWORD *)this + 164) = v6;
LABEL_9:
    ++*((_DWORD *)this + 153);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2253cb0 | Name: _ZN4FMOD12DSPObjectPan23setParameterIntCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::setParameterIntCallback(FMOD_DSP_STATE *dsp_state, int index, int value)
{
  return FMOD::DSPObjectPan::setParameterIntInternal((FMOD::DSPObjectPan *const)dsp_state->instance, index, value);
}


// Address: 0x2253cc0 | Name: _ZN4FMOD12DSPObjectPan23getParameterIntInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::getParameterIntInternal(
        FMOD::DSPObjectPan *const this,
        int index,
        int *value,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( value )
  {
    if ( index == 1 )
    {
      *value = *((_DWORD *)this + 161);
    }
    else
    {
      if ( index != 4 )
        return result;
      *value = *((_DWORD *)this + 164);
    }
    if ( valuestr )
      *valuestr = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2253d10 | Name: _ZN4FMOD12DSPObjectPan23getParameterIntCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::getParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int *value,
        char *valuestr)
{
  return FMOD::DSPObjectPan::getParameterIntInternal(
           (FMOD::DSPObjectPan *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x2253d20 | Name: _ZN4FMOD12DSPObjectPan21calculateListenerInfoEPK37FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTIP11FMOD_VECTORS5_PfS6_
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::calculateListenerInfo(
        FMOD::DSPObjectPan *const this,
        const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *param,
        FMOD_VECTOR *position,
        FMOD_VECTOR *direction,
        float *distanceForGain,
        float *distanceForExtent)
{
  int numlisteners; // r12d
  float v7; // xmm3_4
  const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *v8; // rbx
  __int64 v9; // rbp
  float v10; // xmm0_4
  float v11; // xmm0_4
  float v12; // xmm1_4
  __int64 v13; // rax
  float v14; // xmm2_4
  float v15; // xmm6_4
  float v16; // xmm8_4
  float v17; // xmm0_4
  float *v18; // rax
  float *p_z; // rdi
  float v20; // xmm1_4
  float v21; // xmm0_4
  float v22; // xmm5_4
  float v23; // xmm0_4
  float v24; // xmm1_4
  float v25; // xmm5_4
  float v26; // xmm2_4
  float v27; // xmm0_4
  float x; // xmm1_4
  float v30; // xmm2_4
  float v31; // xmm0_4
  float listenerDist[8]; // [rsp+40h] [rbp-68h]
  float listenerWeight[18]; // [rsp+60h] [rbp-48h] BYREF

  numlisteners = param->numlisteners;
  if ( param->numlisteners == 1 )
  {
    *position = param->relative[0].position;
    direction->x = param->relative[0].forward.x;
    direction->y = param->relative[0].forward.y;
    x = param->relative[0].position.x;
    v30 = param->relative[0].position.y * param->relative[0].position.y;
    direction->z = param->relative[0].forward.z;
    v31 = fsqrt((float)((float)(x * x) + v30) + (float)(param->relative[0].position.z * param->relative[0].position.z));
    *distanceForGain = v31;
    *distanceForExtent = v31;
  }
  else
  {
    v7 = 3.4028235e38;
    if ( numlisteners > 0 )
    {
      v8 = param;
      v9 = 0;
      v7 = 3.4028235e38;
      do
      {
        v10 = fsqrt(
                (float)((float)(v8->relative[0].position.x * v8->relative[0].position.x)
                      + (float)(v8->relative[0].position.y * v8->relative[0].position.y))
              + (float)(v8->relative[0].position.z * v8->relative[0].position.z));
        listenerDist[v9++] = v10;
        v8 = (const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *)((char *)v8 + 48);
        v7 = fminf(v7, v10);
      }
      while ( numlisteners > (int)v9 );
    }
    v11 = fmaxf((float)(0.5 * *((float *)this + 163)) + v7, *((float *)this + 163));
    v12 = v11;
    if ( numlisteners <= 0 )
    {
      position->x = 0.0;
      position->y = 0.0;
      position->z = 0.0;
      v22 = INFINITY;
      direction->x = 0.0;
      direction->y = 0.0;
      direction->z = 0.0;
    }
    else
    {
      v13 = 0;
      v14 = 0.0;
      v15 = v11 - v7;
      do
      {
        while ( 1 )
        {
          v17 = listenerDist[v13];
          if ( v12 <= v17 )
            break;
          v16 = 1.0 - (float)((float)(v17 - v7) / v15);
          listenerWeight[v13++] = v16 * v16;
          v14 = v14 + (float)(v16 * v16);
          if ( numlisteners <= (int)v13 )
            goto LABEL_10;
        }
        listenerWeight[v13++] = 0.0;
        v14 = v14 + 0.0;
      }
      while ( numlisteners > (int)v13 );
LABEL_10:
      v18 = listenerWeight;
      position->x = 0.0;
      position->y = 0.0;
      position->z = 0.0;
      direction->x = 0.0;
      direction->y = 0.0;
      direction->z = 0.0;
      p_z = &param->relative[numlisteners - 1].up.z;
      do
      {
        v20 = param->relative[0].position.x;
        param = (const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *)((char *)param + 48);
        v21 = *v18++;
        position->x = (float)(v20 * v21) + position->x;
        position->y = (float)(param[-1].absolute.position.z * v21) + position->y;
        position->z = (float)(param[-1].absolute.velocity.x * v21) + position->z;
        direction->x = (float)(param[-1].absolute.forward.y * v21) + direction->x;
        direction->y = (float)(param[-1].absolute.forward.z * v21) + direction->y;
        direction->z = (float)(v21 * param[-1].absolute.up.x) + direction->z;
      }
      while ( param != (const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *)p_z );
      v22 = 1.0 / v14;
    }
    position->x = position->x * v22;
    v23 = position->y * v22;
    v24 = direction->x;
    v25 = v22 * position->z;
    position->y = v23;
    v26 = direction->y * direction->y;
    position->z = v25;
    v27 = fsqrt((float)((float)(v24 * v24) + v26) + (float)(direction->z * direction->z));
    if ( v27 <= 0.0 )
    {
      direction->x = 0.0;
      direction->y = 0.0;
      direction->z = 0.0;
    }
    else
    {
      direction->x = direction->x / v27;
      direction->y = direction->y / v27;
      direction->z = direction->z / v27;
    }
    *distanceForGain = v7;
    *distanceForExtent = fsqrt(
                           (float)((float)(position->x * position->x) + (float)(position->y * position->y))
                         + (float)(position->z * position->z));
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2254190 | Name: _ZN4FMOD12DSPObjectPan24setParameterDataInternalEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::setParameterDataInternal(
        FMOD::DSPObjectPan *const this,
        int index,
        void *data,
        unsigned int length)
{
  FMOD_RESULT_0 result; // eax
  float x; // xmm0_4
  float distanceForGain; // [rsp+Ch] [rbp-30h] BYREF
  float distanceForExtent; // [rsp+10h] [rbp-2Ch] BYREF
  FMOD_VECTOR position; // [rsp+14h] [rbp-28h] BYREF
  FMOD_VECTOR direction; // [rsp+24h] [rbp-18h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index )
  {
    if ( index == 7 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  else if ( length == 468 )
  {
    result = FMOD::DSPObjectPan::calculateListenerInfo(
               this,
               (const FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *)data,
               &position,
               &direction,
               &distanceForGain,
               &distanceForExtent);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      *((float *)this + 158) = distanceForGain;
      *((float *)this + 159) = distanceForExtent;
      if ( position.x != 0.0 || position.z != 0.0 )
        *((float *)this + 157) = (float)(atan2f(position.x, position.z) * 180.0) / 3.1415927;
      if ( direction.x != 0.0 || direction.z != 0.0 )
        *((float *)this + 160) = (float)(atan2f(direction.x, direction.z) * 180.0) / 3.1415927;
      x = position.x;
      ++*((_DWORD *)this + 153);
      result = FMOD_RESULT::FMOD_OK_0;
      *((float *)this + 167) = x;
      *((_DWORD *)this + 168) = LODWORD(position.y);
      *((_DWORD *)this + 169) = LODWORD(position.z);
    }
  }
  return result;
}


// Address: 0x22542e0 | Name: _ZN4FMOD12DSPObjectPan24setParameterDataCallbackEP14FMOD_DSP_STATEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::setParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void *data,
        unsigned int length)
{
  return FMOD::DSPObjectPan::setParameterDataInternal(
           (FMOD::DSPObjectPan *const)dsp_state->instance,
           index,
           data,
           length);
}


// Address: 0x22542f0 | Name: _ZN4FMOD12DSPObjectPan24getParameterDataInternalEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::getParameterDataInternal(
        FMOD::DSPObjectPan *const this,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  float v6; // xmm0_4
  float *v7; // rdi

  if ( index != 7 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v6 = *((float *)this + 132);
  v7 = (float *)((char *)this + 532);
  v7[1] = v6 * v7[18];
  *data = v7;
  *length = 8;
  if ( valuestr )
    *valuestr = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2254340 | Name: _ZN4FMOD12DSPObjectPan24getParameterDataCallbackEP14FMOD_DSP_STATEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::getParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  return FMOD::DSPObjectPan::getParameterDataInternal(
           (FMOD::DSPObjectPan *const)dsp_state->instance,
           index,
           data,
           length,
           valuestr);
}


// Address: 0x2254350 | Name: _ZN4FMOD12DSPObjectPan15commandInternalEj
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::commandInternal(
        FMOD::DSPObjectPan *const this,
        FMOD::FMOD_DSP_COMMAND_TYPE type)
{
  FMOD_RESULT_0 result; // eax
  void *v3; // rsi
  int v4; // eax
  float v5; // xmm0_4

  if ( type != 1 )
  {
    if ( type == 128 )
    {
      v3 = (void *)*((_QWORD *)this + 77);
      if ( v3 )
      {
        result = FMOD::SystemI::freeObject3DHandle(*((FMOD::SystemI *const *)this + 22), v3);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
          *((_QWORD *)this + 77) = 0;
        return result;
      }
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  v4 = *((_DWORD *)this + 153);
  if ( v4 <= *((_DWORD *)this + 152) )
    return FMOD_RESULT::FMOD_OK_0;
  v5 = *((float *)this + 138);
  *((_DWORD *)this + 152) = v4;
  if ( v5 == *((float *)this + 157)
    && *((float *)this + 139) == *((float *)this + 158)
    && *((float *)this + 140) == *((float *)this + 159)
    && *((float *)this + 141) == *((float *)this + 160)
    && *((_DWORD *)this + 142) == *((_DWORD *)this + 161)
    && *((float *)this + 143) == *((float *)this + 162)
    && *((float *)this + 144) == *((float *)this + 163)
    && *((_DWORD *)this + 145) == *((_DWORD *)this + 164)
    && *((float *)this + 146) == *((float *)this + 165)
    && *((float *)this + 147) == *((float *)this + 166)
    && *((float *)this + 151) == *((float *)this + 170) )
  {
    return FMOD_RESULT::FMOD_OK_0;
  }
  result = FMOD::DSPObjectPan::updateParameters(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    *((_BYTE *)this + 624) = 1;
  return result;
}


// Address: 0x22544c0 | Name: _ZN4FMOD12DSPObjectPan15commandCallbackEP14FMOD_DSP_STATEjPvS3_
FMOD_RESULT_0 __fastcall FMOD::DSPObjectPan::commandCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *a3,
        void *a4)
{
  return FMOD::DSPObjectPan::commandInternal((FMOD::DSPObjectPan *const)dsp_state->instance, type);
}


