// Address: 0x21d34d0 | Name: _ZN4FMOD8DSPDelay22shouldIProcessCallbackEP14FMOD_DSP_STATEijji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::shouldIProcessCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD_BOOL inputsidle,
        unsigned int length,
        FMOD_CHANNELMASK a4,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d34e0 | Name: _ZN4FMOD8DSPDelay16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPDelay::getDescriptionEx()
{
  memset(&stru_2AD8D00, 0, sizeof(stru_2AD8D00));
  FMOD_strcpy_safe(stru_2AD8D00.name, "Delay ch0", 16);
  FMOD_strcpy_safe(stru_2AD8D00.label, "ms", 16);
  stru_2AD8D00.description = "Channel #0 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8CA0, 0, sizeof(stru_2AD8CA0));
  *(_QWORD *)&stru_2AD8D00.floatdesc.min = 0x461C400000000000LL;
  stru_2AD8D00.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AD8D00.intdesc.defaultval = 0;
  FMOD_strcpy_safe(stru_2AD8CA0.name, "Delay ch1", 16);
  FMOD_strcpy_safe(stru_2AD8CA0.label, "ms", 16);
  stru_2AD8CA0.description = "Channel #1 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8C40, 0, sizeof(stru_2AD8C40));
  stru_2AD8CA0.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8CA0.datadesc + 1) = 1176256512;
  stru_2AD8CA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8C40.name, "Delay ch2", 16);
  FMOD_strcpy_safe(stru_2AD8C40.label, "ms", 16);
  stru_2AD8C40.description = "Channel #2 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8BE0, 0, sizeof(stru_2AD8BE0));
  stru_2AD8C40.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8C40.datadesc + 1) = 1176256512;
  stru_2AD8C40.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8BE0.name, "Delay ch3", 16);
  FMOD_strcpy_safe(stru_2AD8BE0.label, "ms", 16);
  stru_2AD8BE0.description = "Channel #3 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8B80, 0, sizeof(stru_2AD8B80));
  stru_2AD8BE0.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8BE0.datadesc + 1) = 1176256512;
  stru_2AD8BE0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8B80.name, "Delay ch4", 16);
  FMOD_strcpy_safe(stru_2AD8B80.label, "ms", 16);
  stru_2AD8B80.description = "Channel #4 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8B20, 0, sizeof(stru_2AD8B20));
  stru_2AD8B80.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8B80.datadesc + 1) = 1176256512;
  stru_2AD8B80.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8B20.name, "Delay ch5", 16);
  FMOD_strcpy_safe(stru_2AD8B20.label, "ms", 16);
  stru_2AD8B20.description = "Channel #5 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8AC0, 0, sizeof(stru_2AD8AC0));
  stru_2AD8B20.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8B20.datadesc + 1) = 1176256512;
  stru_2AD8B20.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8AC0.name, "Delay ch6", 16);
  FMOD_strcpy_safe(stru_2AD8AC0.label, "ms", 16);
  stru_2AD8AC0.description = "Channel #6 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8A60, 0, sizeof(stru_2AD8A60));
  stru_2AD8AC0.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8AC0.datadesc + 1) = 1176256512;
  stru_2AD8AC0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8A60.name, "Delay ch7", 16);
  FMOD_strcpy_safe(stru_2AD8A60.label, "ms", 16);
  stru_2AD8A60.description = "Channel #7 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8A00, 0, sizeof(stru_2AD8A00));
  stru_2AD8A60.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8A60.datadesc + 1) = 1176256512;
  stru_2AD8A60.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8A00.name, "Delay ch8", 16);
  FMOD_strcpy_safe(stru_2AD8A00.label, "ms", 16);
  stru_2AD8A00.description = "Channel #8 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD89A0, 0, sizeof(stru_2AD89A0));
  stru_2AD8A00.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8A00.datadesc + 1) = 1176256512;
  stru_2AD8A00.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD89A0.name, "Delay ch9", 16);
  FMOD_strcpy_safe(stru_2AD89A0.label, "ms", 16);
  stru_2AD89A0.description = "Channel #9 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8940, 0, sizeof(stru_2AD8940));
  stru_2AD89A0.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD89A0.datadesc + 1) = 1176256512;
  stru_2AD89A0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8940.name, "Delay ch10", 16);
  FMOD_strcpy_safe(stru_2AD8940.label, "ms", 16);
  stru_2AD8940.description = "Channel #10 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD88E0, 0, sizeof(stru_2AD88E0));
  stru_2AD8940.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8940.datadesc + 1) = 1176256512;
  stru_2AD8940.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD88E0.name, "Delay ch11", 16);
  FMOD_strcpy_safe(stru_2AD88E0.label, "ms", 16);
  stru_2AD88E0.description = "Channel #11 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8880, 0, sizeof(stru_2AD8880));
  stru_2AD88E0.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD88E0.datadesc + 1) = 1176256512;
  stru_2AD88E0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8880.name, "Delay ch12", 16);
  FMOD_strcpy_safe(stru_2AD8880.label, "ms", 16);
  stru_2AD8880.description = "Channel #12 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8820, 0, sizeof(stru_2AD8820));
  stru_2AD8880.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8880.datadesc + 1) = 1176256512;
  stru_2AD8880.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8820.name, "Delay ch13", 16);
  FMOD_strcpy_safe(stru_2AD8820.label, "ms", 16);
  stru_2AD8820.description = "Channel #13 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD87C0, 0, sizeof(stru_2AD87C0));
  stru_2AD8820.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8820.datadesc + 1) = 1176256512;
  stru_2AD8820.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD87C0.name, "Delay ch14", 16);
  FMOD_strcpy_safe(stru_2AD87C0.label, "ms", 16);
  stru_2AD87C0.description = "Channel #14 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8760, 0, sizeof(stru_2AD8760));
  stru_2AD87C0.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD87C0.datadesc + 1) = 1176256512;
  stru_2AD87C0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8760.name, "Delay ch15", 16);
  FMOD_strcpy_safe(stru_2AD8760.label, "ms", 16);
  stru_2AD8760.description = "Channel #15 delay in ms.  0  to 10000.  Default = 0.";
  memset(&stru_2AD8700, 0, sizeof(stru_2AD8700));
  stru_2AD8760.intdesc.min = 0;
  *(_QWORD *)(&stru_2AD8760.datadesc + 1) = 1176256512;
  stru_2AD8760.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8700.name, "Max delay", 16);
  FMOD_strcpy_safe(stru_2AD8700.label, "ms", 16);
  *(_QWORD *)&stru_2AD8700.floatdesc.min = 0x461C40003F800000LL;
  stru_2AD8700.intdesc.defaultval = 1092616192;
  stru_2AD8700.description = "Maximum delay in ms.  1  to 10000.  Default = 10.";
  stru_2AD8700.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AD86C0.mDescription = &stru_286A700;
  *(&stru_2AD86C0.mHandle + 1) = 21;
  stru_2AD86C0.mSize = 824;
  return &stru_2AD86C0;
}


// Address: 0x21d3d60 | Name: _ZN4FMOD8DSPDelay15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::releaseInternal(FMOD::DSPDelay *const this)
{
  void *v1; // rsi

  v1 = (void *)*((_QWORD *)this + 92);
  if ( v1 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_dsp_delay.cpp", 222);
    *((_QWORD *)this + 91) = 0;
    *((_QWORD *)this + 92) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d3db0 | Name: _ZN4FMOD8DSPDelay15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPDelay::releaseInternal((FMOD::DSPDelay *const)dsp_state->instance);
}


// Address: 0x21d3dc0 | Name: _ZN4FMOD8DSPDelay13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::resetInternal(FMOD::DSPDelay *const this)
{
  FMOD::DSPDelay *v2; // rax
  int v3; // ecx
  int v4; // edx
  void *v5; // rdi

  *((_DWORD *)this + 188) = 0;
  v2 = this;
  do
  {
    v3 = *((_DWORD *)v2 + 166);
    v4 = 0;
    if ( v3 )
      v4 = *((_DWORD *)this + 187) - v3;
    *((_DWORD *)v2 + 189) = v4;
    v2 = (FMOD::DSPDelay *)((char *)v2 + 4);
  }
  while ( v2 != (FMOD::DSPDelay *const)((char *)this + 64) );
  v5 = (void *)*((_QWORD *)this + 91);
  if ( v5 )
    memset(v5, 0, *((unsigned int *)this + 186));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d3e30 | Name: _ZN4FMOD8DSPDelay14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::createInternal(FMOD::DSPDelay *const this)
{
  double v1; // xmm1_8
  __int64 v3; // rbp
  __int64 v4; // rax
  int v5; // ebx
  FMOD_RESULT_0 result; // eax
  __int64 v7; // rax
  float v8; // xmm1_4
  int v9; // edx
  int v10; // edi
  FMOD::DSPDelay *v11; // rax
  float v12; // xmm4_4
  int v13; // edx
  float v14; // xmm0_4
  float v15; // xmm0_4
  void *v16; // rsi
  int v17; // eax
  int v18; // esi
  FMOD::Global *v19; // rax
  void *v20; // rax

  v3 = 0;
  v4 = *((_QWORD *)this + 30);
  v5 = 0;
  *((_DWORD *)this + 205) = 0;
  if ( *(int *)(v4 + 96) > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v5,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v4 + 104) + v3) + 56LL),
                 v1);
      if ( result )
        break;
      v4 = *((_QWORD *)this + 30);
      ++v5;
      v3 += 8;
      if ( *(_DWORD *)(v4 + 96) <= v5 )
        goto LABEL_6;
    }
  }
  else
  {
LABEL_6:
    v7 = *((_QWORD *)this + 22);
    v8 = *((float *)this + 133);
    *((float *)this + 132) = v8;
    v9 = *(_DWORD *)(v7 + 1696);
    v10 = *(_DWORD *)(v7 + 1700);
    v11 = this;
    v12 = (float)v9;
    v13 = 16;
    *((_DWORD *)this + 205) = v10;
    do
    {
      v14 = *((float *)v11 + 150);
      v11 = (FMOD::DSPDelay *)((char *)v11 + 4);
      v15 = fminf(v14, v8);
      *((float *)v11 + 133) = v15;
      *((_DWORD *)v11 + 165) = (int)(float)((float)((float)(v15 * v12) / 1000.0) + 0.5);
      --v13;
    }
    while ( v13 );
    v16 = (void *)*((_QWORD *)this + 92);
    v17 = (int)(float)((float)((float)(v8 * v12) / 1000.0) + 0.5) + 1;
    *((_DWORD *)this + 187) = v17;
    if ( v16 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v16, "../../../core_api/src/fmod_dsp_delay.cpp", 174);
      v17 = *((_DWORD *)this + 187);
      v10 = *((_DWORD *)this + 205);
      *((_QWORD *)this + 91) = 0;
      *((_QWORD *)this + 92) = 0;
    }
    v18 = 4 * v10 * v17;
    v19 = off_286F358;
    *((_DWORD *)this + 186) = v18;
    v20 = FMOD::MemPool::calloc(v19->gSystemMemPool, v18 + 16, "../../../core_api/src/fmod_dsp_delay.cpp", 186, 0);
    *((_QWORD *)this + 92) = v20;
    *((_QWORD *)this + 91) = ((unsigned __int64)v20 + 15) & 0xFFFFFFFFFFFFFFF0LL;
    if ( v20 )
    {
      FMOD::DSPDelay::resetInternal(this);
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
  }
  return result;
}


// Address: 0x21d3ff0 | Name: _ZN4FMOD8DSPDelay14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPDelay::createInternal((FMOD::DSPDelay *const)dsp_state->instance);
}


// Address: 0x21d4000 | Name: _ZN4FMOD8DSPDelay13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPDelay::resetInternal((FMOD::DSPDelay *const)dsp_state->instance);
}


// Address: 0x21d4010 | Name: _ZN4FMOD8DSPDelay12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::readInternal(
        FMOD::DSPDelay *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float *v6; // r12
  int v11; // r15d
  float v12; // xmm1_4
  float v13; // xmm0_4
  char v14; // r9
  void *v15; // rsi
  int v16; // edx
  FMOD::MemPool *gSystemMemPool; // rdi
  int v18; // edx
  void *v19; // rax
  FMOD::DSPDelay *v21; // rax
  FMOD::DSPDelay *v22; // rsi
  float v23; // xmm0_4
  float v24; // xmm1_4
  int v25; // ecx
  int v26; // edx
  float *v27; // rsi
  int v28; // edx
  float *v29; // rcx
  __int64 i; // rax
  signed int v31; // esi
  __int64 v32; // r8
  __int64 v33; // rdi
  unsigned int v34; // r11d
  int v35; // r10d
  __int64 v36; // rax
  float *v37; // rdx
  unsigned __int64 v38; // rax
  int v39; // edx
  signed int v40; // edx
  int v41; // eax
  float *v42; // r8
  float *v43; // rdx
  signed int v44; // edi
  signed int v45; // r9d
  unsigned int v46; // r10d
  __int64 v47; // rax
  int v48; // ecx
  signed int v49; // ecx
  __int64 v50; // rax
  int v51; // eax
  float *v52; // r13
  float *v53; // rdi
  float *v54; // rcx
  signed int v55; // r9d
  signed int v56; // r11d
  unsigned int v57; // r15d
  float *v58; // rdx
  __int64 v59; // r14
  float *v60; // rax
  float *v61; // r10
  int v62; // r8d
  int v63; // r8d
  int v64; // xmm0_4
  int v65; // r8d
  signed int v66; // r8d
  int v67; // eax
  float *v68; // r11
  signed int v69; // edi
  unsigned int v70; // r10d
  float *v71; // rsi
  float *v72; // rcx
  unsigned __int64 v73; // r13
  float *v74; // r8
  int v75; // xmm0_4
  float *v76; // rax
  int v77; // xmm5_4
  int v78; // xmm4_4
  int v79; // xmm3_4
  int v80; // xmm2_4
  int v81; // xmm0_4
  float *v82; // rax
  int v83; // xmm0_4
  float *v84; // rax
  int v85; // xmm0_4
  float *v86; // rax
  int v87; // xmm0_4
  float *v88; // rax
  int v89; // xmm0_4
  float *v90; // rax
  int v91; // xmm0_4
  __int64 v92; // rax
  int v93; // edx
  signed int v94; // eax
  int v95; // eax
  float *v96; // r11
  int v97; // edi
  int v98; // edx
  int v99; // edi
  int v100; // edx
  int v101; // edi
  int v102; // edx
  int v103; // edi
  int v104; // edx
  int v105; // edi
  int v106; // edx
  int v107; // edi
  int v108; // edx
  int v109; // edi
  signed int v110; // r8d
  unsigned int v111; // r13d
  float *v112; // rdi
  float *v113; // rsi
  float *v114; // rcx
  int v115; // r10d
  int v116; // xmm0_4
  float *v117; // rax
  int v118; // xmm7_4
  int v119; // xmm6_4
  int v120; // xmm5_4
  int v121; // xmm4_4
  int v122; // xmm3_4
  int v123; // xmm2_4
  int v124; // xmm0_4
  float *v125; // rax
  int v126; // xmm0_4
  float *v127; // rax
  int v128; // xmm0_4
  float *v129; // rax
  int v130; // xmm0_4
  float *v131; // rax
  int v132; // xmm0_4
  float *v133; // rax
  float *v134; // rax
  int v135; // xmm0_4
  __int64 v136; // rax
  int v137; // edx
  __int64 v138; // rax
  signed int v139; // eax
  char v141; // [rsp+10h] [rbp-C8h]
  char v142; // [rsp+1Ch] [rbp-BCh]
  float *delaybuffread[16]; // [rsp+20h] [rbp-B8h]

  v6 = inbuffer;
  if ( !inbuffer )
    return FMOD_RESULT::FMOD_OK_0;
  v11 = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  if ( *((_DWORD *)this + 205) == inchannels )
  {
    v12 = *((float *)this + 132);
    v13 = *((float *)this + 133);
    if ( v12 == v13 )
    {
      v14 = 0;
      if ( *((_QWORD *)this + 91) )
        goto LABEL_14;
      goto LABEL_5;
    }
    goto LABEL_4;
  }
  v12 = *((float *)this + 132);
  *((_DWORD *)this + 205) = inchannels;
  v13 = *((float *)this + 133);
  if ( v12 != v13 )
  {
LABEL_4:
    *((float *)this + 132) = v13;
    v12 = v13;
    v14 = 1;
    goto LABEL_5;
  }
  v14 = 1;
LABEL_5:
  v15 = (void *)*((_QWORD *)this + 92);
  v16 = (int)(float)((float)((float)((float)v11 * v12) / 1000.0) + 0.5) + 1;
  *((_DWORD *)this + 187) = v16;
  if ( v15 )
  {
    v142 = v14;
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v15, "../../../core_api/src/fmod_dsp_delay.cpp", 321);
    v16 = *((_DWORD *)this + 187);
    v14 = v142;
    *((_QWORD *)this + 91) = 0;
    *((_QWORD *)this + 92) = 0;
  }
  v141 = v14;
  gSystemMemPool = off_286F358->gSystemMemPool;
  v18 = 4 * *((_DWORD *)this + 205) * v16;
  *((_DWORD *)this + 186) = v18;
  v19 = FMOD::MemPool::calloc(gSystemMemPool, v18 + 16, "../../../core_api/src/fmod_dsp_delay.cpp", 333, 0);
  *((_QWORD *)this + 92) = v19;
  v14 = v141;
  *((_QWORD *)this + 91) = ((unsigned __int64)v19 + 15) & 0xFFFFFFFFFFFFFFF0LL;
  if ( !v19 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
LABEL_14:
  if ( inchannels )
  {
    v21 = this;
    v22 = (FMOD::DSPDelay *const)((char *)this + 4 * (unsigned int)(inchannels - 1) + 4);
    do
    {
      while ( 1 )
      {
        v23 = *((float *)v21 + 150);
        if ( v23 != *((float *)v21 + 134) || v14 )
        {
          v24 = *((float *)this + 132);
          if ( v23 > v24 )
          {
            *((float *)v21 + 150) = v24;
            v23 = v24;
          }
          *((float *)v21 + 134) = v23;
          v25 = (int)(float)((float)((float)(v23 * (float)v11) / 1000.0) + 0.5);
          *((_DWORD *)v21 + 166) = v25;
          v26 = *((_DWORD *)this + 188) - v25;
          *((_DWORD *)v21 + 189) = v26;
          if ( v26 < 0 )
            break;
        }
        v21 = (FMOD::DSPDelay *)((char *)v21 + 4);
        if ( v21 == v22 )
          goto LABEL_23;
      }
      v21 = (FMOD::DSPDelay *)((char *)v21 + 4);
      *((_DWORD *)v21 + 188) = *((_DWORD *)this + 187) + v26;
    }
    while ( v21 != v22 );
  }
LABEL_23:
  if ( !v14 && (v27 = (float *)*((_QWORD *)this + 91)) != 0
    || (FMOD::DSPDelay::resetInternal(this), (v27 = (float *)*((_QWORD *)this + 91)) != 0) )
  {
    if ( inchannels == 1 )
    {
      v41 = *((_DWORD *)this + 188);
      v42 = &v27[v41];
      v43 = &v27[*((int *)this + 189)];
      if ( length )
      {
        v44 = *((_DWORD *)this + 187);
        while ( 1 )
        {
          v45 = length + v41;
          v46 = 0;
          if ( (int)(length + v41) > v44 )
          {
            v45 = v44;
            v46 = length - (v44 - v41);
            length = v44 - v41;
          }
          if ( length )
          {
            v47 = 0;
            do
            {
              while ( 1 )
              {
                v48 = *((_DWORD *)this + 189);
                v42[v47] = v6[v47];
                v49 = v48 + 1;
                outbuffer[v47] = *v43;
                if ( v49 < v44 )
                  break;
                ++v47;
                *((_DWORD *)this + 189) = 0;
                v43 = v27;
                if ( length <= (unsigned int)v47 )
                  goto LABEL_64;
              }
              ++v47;
              ++v43;
              *((_DWORD *)this + 189) = v49;
            }
            while ( length > (unsigned int)v47 );
LABEL_64:
            v50 = 4LL * (length - 1) + 4;
            v6 = (float *)((char *)v6 + v50);
            outbuffer = (float *)((char *)outbuffer + v50);
            v42 = (float *)((char *)v42 + v50);
          }
          if ( v45 >= v44 )
          {
            *((_DWORD *)this + 188) = 0;
            v42 = v27;
          }
          else
          {
            *((_DWORD *)this + 188) = v45;
          }
          if ( !v46 )
            break;
          v41 = *((_DWORD *)this + 188);
          length = v46;
        }
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( inchannels != 2 )
    {
      if ( inchannels == 6 )
      {
        v67 = *((_DWORD *)this + 188);
        v68 = &v27[6 * v67];
        delaybuffread[0] = &v27[6 * *((_DWORD *)this + 189)];
        delaybuffread[1] = &v27[6 * *((_DWORD *)this + 190) + 1];
        delaybuffread[2] = &v27[6 * *((_DWORD *)this + 191) + 2];
        delaybuffread[3] = &v27[6 * *((_DWORD *)this + 192) + 3];
        delaybuffread[4] = &v27[6 * *((_DWORD *)this + 193) + 4];
        delaybuffread[5] = &v27[6 * *((_DWORD *)this + 194) + 5];
        if ( length )
        {
          v69 = *((_DWORD *)this + 187);
          while ( 1 )
          {
            v70 = 0;
            if ( (int)(length + v67) > v69 )
            {
              v70 = length - (v69 - v67);
              length = v69 - v67;
            }
            if ( length )
            {
              v71 = v68;
              v72 = v6;
              v73 = 8 * (3LL * (length - 1) + 3);
              v74 = &outbuffer[v73 / 4];
              do
              {
                v75 = *((_DWORD *)v72 + 5);
                v76 = delaybuffread[0];
                v72 += 6;
                v77 = *((_DWORD *)v72 - 6);
                outbuffer += 6;
                v78 = *((_DWORD *)v72 - 5);
                v71 += 6;
                v79 = *((_DWORD *)v72 - 4);
                v80 = *((_DWORD *)v72 - 3);
                *(v71 - 2) = *(v72 - 2);
                *((_DWORD *)v71 - 6) = v77;
                *((_DWORD *)v71 - 5) = v78;
                *((_DWORD *)v71 - 4) = v79;
                *((_DWORD *)v71 - 3) = v80;
                *((_DWORD *)v71 - 1) = v75;
                v81 = *(_DWORD *)v76;
                v82 = delaybuffread[1];
                *((_DWORD *)outbuffer - 6) = v81;
                v83 = *(_DWORD *)v82;
                v84 = delaybuffread[2];
                *((_DWORD *)outbuffer - 5) = v83;
                v85 = *(_DWORD *)v84;
                v86 = delaybuffread[3];
                *((_DWORD *)outbuffer - 4) = v85;
                v87 = *(_DWORD *)v86;
                v88 = delaybuffread[4];
                *((_DWORD *)outbuffer - 3) = v87;
                v89 = *(_DWORD *)v88;
                v90 = delaybuffread[5];
                *((_DWORD *)outbuffer - 2) = v89;
                v91 = *(_DWORD *)v90;
                v92 = 0;
                *((_DWORD *)outbuffer - 1) = v91;
                do
                {
                  while ( 1 )
                  {
                    v93 = *(_DWORD *)((char *)this + v92 * 4 + 756) + 1;
                    *(_DWORD *)((char *)this + v92 * 4 + 756) = v93;
                    if ( v93 < v69 )
                      break;
                    *(_DWORD *)((char *)this + v92 * 4 + 756) = 0;
                    delaybuffread[v92] = (float *)(*((_QWORD *)this + 91) + v92 * 4);
                    if ( ++v92 == 6 )
                      goto LABEL_98;
                  }
                  delaybuffread[v92++] += 6;
                }
                while ( v92 != 6 );
LABEL_98:
                ;
              }
              while ( outbuffer != v74 );
              v67 = *((_DWORD *)this + 188);
              v6 = (float *)((char *)v6 + v73);
              v68 = (float *)((char *)v68 + v73);
            }
            v94 = length + v67;
            if ( v94 >= v69 )
            {
              *((_DWORD *)this + 188) = 0;
              v68 = (float *)*((_QWORD *)this + 91);
            }
            else
            {
              *((_DWORD *)this + 188) = v94;
            }
            if ( !v70 )
              break;
            v67 = *((_DWORD *)this + 188);
            length = v70;
          }
        }
      }
      else if ( inchannels == 8 )
      {
        v95 = *((_DWORD *)this + 188);
        v96 = &v27[8 * v95];
        v97 = *((_DWORD *)this + 190);
        delaybuffread[0] = &v27[8 * *((_DWORD *)this + 189)];
        v98 = 8 * v97;
        v99 = *((_DWORD *)this + 191);
        delaybuffread[1] = &v27[v98 + 1];
        v100 = 8 * v99;
        v101 = *((_DWORD *)this + 192);
        delaybuffread[2] = &v27[v100 + 2];
        v102 = 8 * v101;
        v103 = *((_DWORD *)this + 193);
        delaybuffread[3] = &v27[v102 + 3];
        v104 = 8 * v103;
        v105 = *((_DWORD *)this + 194);
        delaybuffread[4] = &v27[v104 + 4];
        v106 = 8 * v105;
        v107 = *((_DWORD *)this + 195);
        delaybuffread[5] = &v27[v106 + 5];
        v108 = 8 * v107;
        v109 = *((_DWORD *)this + 196);
        delaybuffread[6] = &v27[v108 + 6];
        delaybuffread[7] = &v27[8 * v109 + 7];
        if ( length )
        {
          v110 = *((_DWORD *)this + 187);
          while ( 1 )
          {
            v111 = 0;
            if ( (int)(length + v95) > v110 )
            {
              v111 = length - (v110 - v95);
              length = v110 - v95;
            }
            if ( length )
            {
              v112 = v96;
              v113 = v6;
              v114 = outbuffer;
              v115 = 0;
              do
              {
                v116 = *((_DWORD *)v113 + 7);
                v117 = delaybuffread[0];
                v113 += 8;
                v118 = *((_DWORD *)v113 - 8);
                v114 += 8;
                v119 = *((_DWORD *)v113 - 7);
                v112 += 8;
                v120 = *((_DWORD *)v113 - 6);
                v121 = *((_DWORD *)v113 - 5);
                v122 = *((_DWORD *)v113 - 4);
                v123 = *((_DWORD *)v113 - 3);
                *(v112 - 2) = *(v113 - 2);
                *((_DWORD *)v112 - 8) = v118;
                *((_DWORD *)v112 - 7) = v119;
                *((_DWORD *)v112 - 6) = v120;
                *((_DWORD *)v112 - 5) = v121;
                *((_DWORD *)v112 - 4) = v122;
                *((_DWORD *)v112 - 3) = v123;
                *((_DWORD *)v112 - 1) = v116;
                v124 = *(_DWORD *)v117;
                v125 = delaybuffread[1];
                *((_DWORD *)v114 - 8) = v124;
                v126 = *(_DWORD *)v125;
                v127 = delaybuffread[2];
                *((_DWORD *)v114 - 7) = v126;
                v128 = *(_DWORD *)v127;
                v129 = delaybuffread[3];
                *((_DWORD *)v114 - 6) = v128;
                v130 = *(_DWORD *)v129;
                v131 = delaybuffread[4];
                *((_DWORD *)v114 - 5) = v130;
                v132 = *(_DWORD *)v131;
                v133 = delaybuffread[5];
                *((_DWORD *)v114 - 4) = v132;
                *(v114 - 3) = *v133;
                v134 = delaybuffread[7];
                *(v114 - 2) = *delaybuffread[6];
                v135 = *(_DWORD *)v134;
                v136 = 0;
                *((_DWORD *)v114 - 1) = v135;
                do
                {
                  while ( 1 )
                  {
                    v137 = *(_DWORD *)((char *)this + v136 * 4 + 756) + 1;
                    *(_DWORD *)((char *)this + v136 * 4 + 756) = v137;
                    if ( v137 < v110 )
                      break;
                    *(_DWORD *)((char *)this + v136 * 4 + 756) = 0;
                    delaybuffread[v136] = (float *)(*((_QWORD *)this + 91) + v136 * 4);
                    if ( ++v136 == 8 )
                      goto LABEL_115;
                  }
                  delaybuffread[v136++] += 8;
                }
                while ( v136 != 8 );
LABEL_115:
                ++v115;
              }
              while ( v115 != length );
              v138 = 32 * (length - 1 + 1LL);
              v6 = (float *)((char *)v6 + v138);
              outbuffer = (float *)((char *)outbuffer + v138);
              v96 = (float *)((char *)v96 + v138);
              v95 = *((_DWORD *)this + 188);
            }
            v139 = length + v95;
            if ( v139 >= v110 )
            {
              *((_DWORD *)this + 188) = 0;
              v96 = (float *)*((_QWORD *)this + 91);
            }
            else
            {
              *((_DWORD *)this + 188) = v139;
            }
            if ( !v111 )
              break;
            v95 = *((_DWORD *)this + 188);
            length = v111;
          }
        }
      }
      else
      {
        v28 = *((_DWORD *)this + 188);
        v29 = &v27[inchannels * v28];
        for ( i = 0; inchannels > (int)i; ++i )
          delaybuffread[i] = &v27[i + inchannels * *((_DWORD *)this + i + 189)];
        if ( length )
        {
          v31 = *((_DWORD *)this + 187);
          v32 = 4LL * inchannels;
          v33 = 4LL * (unsigned int)(inchannels - 1) + 4;
          while ( 1 )
          {
            v34 = 0;
            if ( v31 < (int)(length + v28) )
            {
              v34 = length - (v31 - v28);
              length = v31 - v28;
            }
            if ( length )
            {
              v35 = 0;
              do
              {
                while ( inchannels <= 0 )
                {
                  ++v35;
                  v6 = (float *)((char *)v6 + v32);
                  outbuffer = (float *)((char *)outbuffer + v32);
                  v29 = (float *)((char *)v29 + v32);
                  if ( v35 == length )
                    goto LABEL_45;
                }
                v36 = 0;
                do
                {
                  v37 = delaybuffread[v36];
                  v29[v36] = v6[v36];
                  outbuffer[v36++] = *v37;
                }
                while ( inchannels > (int)v36 );
                v6 = (float *)((char *)v6 + v32);
                outbuffer = (float *)((char *)outbuffer + v32);
                v29 = (float *)((char *)v29 + v32);
                v38 = 0;
                do
                {
                  while ( 1 )
                  {
                    v39 = *(_DWORD *)((char *)this + v38 + 756) + 1;
                    *(_DWORD *)((char *)this + v38 + 756) = v39;
                    if ( v31 > v39 )
                      break;
                    *(_DWORD *)((char *)this + v38 + 756) = 0;
                    delaybuffread[v38 / 4] = (float *)(*((_QWORD *)this + 91) + v38);
                    v38 += 4LL;
                    if ( v38 == v33 )
                      goto LABEL_44;
                  }
                  delaybuffread[v38 / 4] = (float *)((char *)delaybuffread[v38 / 4] + v32);
                  v38 += 4LL;
                }
                while ( v38 != v33 );
LABEL_44:
                ++v35;
              }
              while ( v35 != length );
LABEL_45:
              v28 = *((_DWORD *)this + 188);
            }
            v40 = length + v28;
            if ( v31 <= v40 )
            {
              *((_DWORD *)this + 188) = 0;
              v29 = (float *)*((_QWORD *)this + 91);
            }
            else
            {
              *((_DWORD *)this + 188) = v40;
            }
            if ( !v34 )
              break;
            v28 = *((_DWORD *)this + 188);
            length = v34;
          }
        }
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    v51 = *((_DWORD *)this + 188);
    v52 = &v27[2 * v51];
    v53 = &v27[2 * *((_DWORD *)this + 189)];
    v54 = &v27[2 * *((_DWORD *)this + 190) + 1];
    if ( length )
    {
      v55 = *((_DWORD *)this + 187);
      while ( 1 )
      {
        v56 = length + v51;
        v57 = 0;
        if ( (int)(length + v51) > v55 )
        {
          v56 = v55;
          v57 = length - (v55 - v51);
          length = v55 - v51;
        }
        if ( length )
          break;
LABEL_83:
        if ( v56 >= v55 )
        {
          *((_DWORD *)this + 188) = 0;
          v52 = v27;
        }
        else
        {
          *((_DWORD *)this + 188) = v56;
        }
        if ( !v57 )
          return FMOD_RESULT::FMOD_OK_0;
        v51 = *((_DWORD *)this + 188);
        length = v57;
      }
      v58 = v52;
      v59 = 8LL * (length - 1) + 8;
      v60 = v6;
      v61 = (float *)((char *)outbuffer + v59);
      while ( 1 )
      {
        v64 = *((_DWORD *)v60 + 1);
        v65 = *((_DWORD *)this + 189);
        v60 += 2;
        outbuffer += 2;
        *v58 = *(v60 - 2);
        v58 += 2;
        *((_DWORD *)v58 - 1) = v64;
        v66 = v65 + 1;
        *(outbuffer - 2) = *v53;
        *(outbuffer - 1) = *v54;
        if ( v66 >= v55 )
        {
          v62 = *((_DWORD *)this + 190);
          *((_DWORD *)this + 189) = 0;
          v53 = v27;
          v63 = v62 + 1;
          if ( v63 >= v55 )
            goto LABEL_78;
LABEL_81:
          v54 += 2;
          *((_DWORD *)this + 190) = v63;
          if ( outbuffer == v61 )
          {
LABEL_82:
            v6 = (float *)((char *)v6 + v59);
            v52 = (float *)((char *)v52 + v59);
            goto LABEL_83;
          }
        }
        else
        {
          *((_DWORD *)this + 189) = v66;
          v53 += 2;
          v63 = *((_DWORD *)this + 190) + 1;
          if ( v63 < v55 )
            goto LABEL_81;
LABEL_78:
          *((_DWORD *)this + 190) = 0;
          v54 = v27 + 1;
          if ( outbuffer == v61 )
            goto LABEL_82;
        }
      }
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  memcpy_0(outbuffer, v6, 4LL * *outchannels * length);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d4b80 | Name: _ZN4FMOD8DSPDelay12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPDelay::readInternal(
           (FMOD::DSPDelay *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x21d4b90 | Name: _ZN4FMOD8DSPDelay25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPDelay::setParameterFloatInternal(
        FMOD::DSPDelay *const this,
        unsigned int index,
        float a3,
        float value)
{
  if ( index == 16 )
  {
    *((float *)this + 133) = a3;
    return 0;
  }
  else
  {
    if ( index <= 0xF )
      *((float *)this + (int)index + 150) = a3;
    return 0;
  }
}


// Address: 0x21d4bc0 | Name: _ZN4FMOD8DSPDelay25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPDelay::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        unsigned int index,
        float a3,
        float value)
{
  return FMOD::DSPDelay::setParameterFloatInternal((FMOD::DSPDelay *const)dsp_state->instance, index, a3, value);
}


// Address: 0x21d4bd0 | Name: _ZN4FMOD8DSPDelay25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::getParameterFloatInternal(
        FMOD::DSPDelay *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v4; // xmm0_4
  float *v6; // rax

  if ( index == 16 )
  {
    *value = *((float *)this + 133);
    if ( valuestr )
    {
      v4 = *((float *)this + 133);
LABEL_4:
      sprintf(valuestr, "%.02f", v4);
    }
  }
  else if ( (unsigned int)index <= 0xF )
  {
    v6 = (float *)((char *)this + 4 * index);
    *value = v6[150];
    if ( valuestr )
    {
      v4 = v6[150];
      goto LABEL_4;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d4c40 | Name: _ZN4FMOD8DSPDelay25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPDelay::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPDelay::getParameterFloatInternal((FMOD::DSPDelay *const)dsp_state->instance, index, value, valuestr);
}


