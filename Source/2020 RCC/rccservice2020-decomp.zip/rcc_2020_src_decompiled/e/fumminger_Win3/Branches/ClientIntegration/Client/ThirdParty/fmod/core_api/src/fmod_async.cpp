// Address: 0x224d910 | Name: _ZN4FMOD11AsyncThreadC2Ev
void __fastcall FMOD::AsyncThread::AsyncThread(FMOD::AsyncThread *const this)
{
  FMOD::Thread::Thread(&this->mThread);
  this->mHead.mNodeData = 0;
  this->mCallbackHead.mNodeData = 0;
  this->mIndex = 0;
  this->mCrit = 0;
  this->mHead.mNodePrev = &this->mHead;
  this->mHead.mNodeNext = &this->mHead;
  this->mCallbackHead.mNodePrev = &this->mCallbackHead;
  this->mCallbackHead.mNodeNext = &this->mCallbackHead;
}


// Address: 0x224d970 | Name: _ZN4FMOD11AsyncThread11addCallbackEPF11FMOD_RESULTiE
FMOD_RESULT_0 __fastcall FMOD::AsyncThread::addCallback(FMOD::AsyncThread *const this, FMOD_ASYNC_CALLBACK callback)
{
  FMOD::LinkedListNode *v2; // rax
  FMOD::LinkedListNode *v3; // rbx
  FMOD::Global *v4; // rax

  v2 = (FMOD::LinkedListNode *)FMOD::MemPool::calloc(
                                 off_286F358->gSystemMemPool,
                                 24,
                                 "../../../core_api/src/fmod_async.cpp",
                                 112,
                                 0x200000u);
  v3 = v2;
  if ( !v2 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v2->mNodePrev = v2;
  v2->mNodeNext = v2;
  v2->mNodeData = 0;
  FMOD_OS_CriticalSection_Enter(off_286F358->gAsyncCrit);
  v3->mNodePrev = this->mCallbackHead.mNodePrev;
  v3->mNodeNext = &this->mCallbackHead;
  this->mCallbackHead.mNodePrev = v3;
  v3->mNodePrev->mNodeNext = v3;
  v4 = off_286F358;
  v3->mNodeData = callback;
  FMOD_OS_CriticalSection_Leave(v4->gAsyncCrit);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224da30 | Name: _ZN4FMOD11AsyncThread14removeCallbackEPF11FMOD_RESULTiE
FMOD_RESULT_0 __fastcall FMOD::AsyncThread::removeCallback(FMOD::AsyncThread *const this, FMOD_ASYNC_CALLBACK callback)
{
  FMOD::LinkedListNode *mNodeNext; // rsi
  FMOD::LinkedListNode *p_mCallbackHead; // rdi
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::Global *v6; // rdx

  FMOD_OS_CriticalSection_Enter(off_286F358->gAsyncCrit);
  mNodeNext = this->mCallbackHead.mNodeNext;
  p_mCallbackHead = &this->mCallbackHead;
  if ( mNodeNext != p_mCallbackHead )
  {
    while ( mNodeNext->mNodeData != callback )
    {
      mNodeNext = mNodeNext->mNodeNext;
      if ( mNodeNext == p_mCallbackHead )
        goto LABEL_6;
    }
    mNodePrev = mNodeNext->mNodePrev;
    mNodePrev->mNodeNext = mNodeNext->mNodeNext;
    mNodeNext->mNodeNext->mNodePrev = mNodePrev;
    v6 = off_286F358;
    mNodeNext->mNodePrev = mNodeNext;
    mNodeNext->mNodeNext = mNodeNext;
    FMOD::MemPool::free(v6->gSystemMemPool, mNodeNext, "../../../core_api/src/fmod_async.cpp", 153);
  }
LABEL_6:
  FMOD_OS_CriticalSection_Leave(off_286F358->gAsyncCrit);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224dac0 | Name: _ZN4FMOD11AsyncThread4initEiPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::AsyncThread::init(FMOD::AsyncThread *const this, int index, FMOD::SystemI *system)
{
  FMOD_OS_CRITICALSECTION **p_mCrit; // rdi
  FMOD_RESULT_0 result; // eax
  char s[280]; // [rsp+30h] [rbp-118h] BYREF

  p_mCrit = &this->mCrit;
  *((_DWORD *)p_mCrit + 2) = index;
  result = FMOD_OS_CriticalSection_Create(p_mCrit, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    FMOD_snprintf(s, 256, "FMOD nonblocking thread (%d)", this->mIndex);
    result = FMOD::Thread::initThread(
               &this->mThread,
               s,
               FMOD::AsyncThread::threadFunc,
               this,
               FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_ASYNC,
               FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_HIGH,
               *(_DWORD *)((char *)&stru_11580.r_offset + (_QWORD)system),
               1,
               0,
               0,
               1);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      off_286F358->gAsyncThreadId[this->mIndex] = this->mThread.mThreadID;
  }
  return result;
}


// Address: 0x224db90 | Name: _ZN4FMOD11AsyncThread7releaseEv
FMOD_RESULT_0 __fastcall FMOD::AsyncThread::release(FMOD::AsyncThread *const this)
{
  FMOD::AsyncThread *mNodeNext; // rsi
  FMOD::AsyncThread *vptr_Thread; // rbx
  int (***v4)(...); // rdx
  FMOD::Global *v5; // rdx
  FMOD_OS_CRITICALSECTION *mCrit; // rdi
  FMOD::Global *v7; // rax

  FMOD_OS_CriticalSection_Enter(this->mCrit);
  mNodeNext = (FMOD::AsyncThread *)this->mCallbackHead.mNodeNext;
  if ( mNodeNext != (FMOD::AsyncThread *)&this->mCallbackHead )
  {
    while ( 1 )
    {
      vptr_Thread = (FMOD::AsyncThread *)mNodeNext->mThread._vptr_Thread;
      v4 = *(int (****)(...))mNodeNext->mThread.mName;
      *v4 = mNodeNext->mThread._vptr_Thread;
      *((_QWORD *)mNodeNext->mThread._vptr_Thread + 1) = v4;
      v5 = off_286F358;
      *(_QWORD *)mNodeNext->mThread.mName = mNodeNext;
      mNodeNext->mThread._vptr_Thread = (int (**)(...))mNodeNext;
      FMOD::MemPool::free(v5->gSystemMemPool, mNodeNext, "../../../core_api/src/fmod_async.cpp", 226);
      if ( vptr_Thread == (FMOD::AsyncThread *)&this->mCallbackHead )
        break;
      mNodeNext = vptr_Thread;
    }
  }
  FMOD_OS_CriticalSection_Leave(this->mCrit);
  FMOD::Thread::closeThread(&this->mThread);
  mCrit = this->mCrit;
  v7 = off_286F358;
  off_286F358->gAsyncThreadId[this->mIndex] = 0;
  if ( mCrit )
  {
    FMOD_OS_CriticalSection_Free(mCrit, 0);
    v7 = off_286F358;
  }
  FMOD::MemPool::free(v7->gSystemMemPool, this, "../../../core_api/src/fmod_async.cpp", 241);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224dc70 | Name: _ZN4FMOD11AsyncThread8shutDownEv
FMOD_RESULT_0 __cdecl FMOD::AsyncThread::shutDown()
{
  FMOD_OS_CRITICALSECTION *gAsyncCrit; // rdi
  FMOD::Atomic<FMOD::AsyncThread*> *v1; // rbx

  gAsyncCrit = off_286F358->gAsyncCrit;
  if ( gAsyncCrit )
  {
    FMOD_OS_CriticalSection_Enter(gAsyncCrit);
    v1 = FMOD::AsyncThread::gAsyncThread;
    do
    {
      if ( v1->m_value )
      {
        FMOD::AsyncThread::release(v1->m_value);
        v1->m_value = 0;
      }
      ++v1;
    }
    while ( v1 != (FMOD::Atomic<FMOD::AsyncThread*> *)algn_2B05888 );
    FMOD_OS_CriticalSection_Leave(off_286F358->gAsyncCrit);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224dcf0 | Name: _ZN4FMOD11AsyncThread10threadFuncEv
FMOD_RESULT_0 __fastcall FMOD::AsyncThread::threadFunc(FMOD::AsyncThread *const this)
{
  FMOD_OS_CRITICALSECTION *mCrit; // rdi
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *v4; // rcx
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::SoundI *v6; // rbx
  FMOD::SystemI *mSystem; // r12
  FMOD::AsyncData *v8; // rax
  FMOD_RESULT_0 updated; // r13d
  FMOD::SoundI *mSubSoundParent; // rax
  FMOD::SoundI *v11; // rdi
  FMOD::SoundI *v12; // rax
  FMOD::AsyncData *v13; // rdx
  FMOD_RESULT_0 result; // eax
  FMOD::SoundI *v15; // rax
  FMOD::LinkedListNode *v16; // rbx
  FMOD::SystemI *v17; // r14
  char v18; // r15
  _DWORD *mNodeData; // rdi
  unsigned int v20; // esi
  unsigned int v21; // edx
  FMOD::AsyncData *mAsyncData; // rax
  FMOD_CREATESOUNDEXINFO *p_mExInfo; // r9
  FMOD_MODE mMode; // edx
  FMOD_TIMEUNIT mBufferSizeType; // r8d
  unsigned int mBufferSize; // ecx
  FMOD_RESULT_0 SoundInternal; // eax
  FMOD_RESULT_0 v28; // eax
  FMOD::SystemI *v29; // r13
  bool v30; // zf
  FMOD::SoundI **mSubSound; // rdx
  FMOD::SoundI *sound[8]; // [rsp+18h] [rbp-40h] BYREF

  mCrit = this->mCrit;
  sound[0] = 0;
  FMOD_OS_CriticalSection_Enter(mCrit);
  mNodeNext = this->mHead.mNodeNext;
  if ( mNodeNext != &this->mHead )
  {
    v4 = mNodeNext->mNodeNext;
    sound[0] = (FMOD::SoundI *)mNodeNext->mNodeData;
    mNodePrev = mNodeNext->mNodePrev;
    mNodePrev->mNodeNext = v4;
    mNodeNext->mNodeNext->mNodePrev = mNodePrev;
    mNodeNext->mNodePrev = mNodeNext;
    mNodeNext->mNodeNext = mNodeNext;
  }
  FMOD_OS_CriticalSection_Leave(this->mCrit);
  v6 = sound[0];
  if ( !sound[0] )
    goto LABEL_22;
  mSystem = sound[0]->mSystem;
  switch ( sound[0]->mOpenState.m_value )
  {
    case FMOD_OPENSTATE::FMOD_OPENSTATE_LOADING_0:
      mAsyncData = sound[0]->mAsyncData;
      p_mExInfo = 0;
      mMode = sound[0]->mMode;
      mBufferSizeType = mAsyncData->mBufferSizeType;
      if ( mAsyncData->mExInfoExists )
        p_mExInfo = &mAsyncData->mExInfo;
      mBufferSize = mAsyncData->mBufferSize;
      if ( (mMode & 0x10000800) != 0 )
      {
        SoundInternal = FMOD::SystemI::createSoundInternal(
                          mSystem,
                          (const char *)mAsyncData->mNameData,
                          mMode,
                          mBufferSize,
                          mBufferSizeType,
                          p_mExInfo,
                          1,
                          sound);
        v6 = sound[0];
        updated = SoundInternal;
        v8 = sound[0]->mAsyncData;
      }
      else
      {
        v28 = FMOD::SystemI::createSoundInternal(
                mSystem,
                mAsyncData->mName,
                mMode,
                mBufferSize,
                mBufferSizeType,
                p_mExInfo,
                1,
                sound);
        v6 = sound[0];
        updated = v28;
        v8 = sound[0]->mAsyncData;
        if ( v8->mName )
        {
          FMOD::MemPool::free(off_286F358->gSystemMemPool, v8->mName, "../../../core_api/src/fmod_async.cpp", 321);
          v6 = sound[0];
          v8 = sound[0]->mAsyncData;
          v8->mName = 0;
        }
      }
      if ( updated == FMOD_RESULT::FMOD_OK_0 && v8->mExInfoExists )
        v6->mUserData = v8->mExInfo.userdata;
      goto LABEL_8;
    case FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0:
      while ( (sound[0]->mFlags.m_value & 0x440) == 0 )
        FMOD_OS_Time_Sleep(0xAu);
      if ( (sound[0]->mFlags.m_value & 0x40) != 0 )
      {
        v29 = sound[0]->mSystem;
        if ( v29 )
        {
          FMOD::SystemI::enterCrit(sound[0]->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
          *((_DWORD *)sound[0][1].mNodeData + 15) &= ~0x4000u;
          FMOD::SystemI::leaveCrit(v29, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
          v6 = sound[0];
        }
        else
        {
          v6 = sound[0];
          *((_DWORD *)sound[0][1].mNodeData + 15) &= ~0x4000u;
        }
        break;
      }
      updated = (*(unsigned int (__fastcall **)(void *, _QWORD, _QWORD, __int64))(*(_QWORD *)sound[0][1].mNodeData
                                                                                + 216LL))(
                  sound[0][1].mNodeData,
                  sound[0]->mAsyncData->mPosition,
                  sound[0]->mAsyncData->mPositionType,
                  1);
      v17 = sound[0]->mSystem;
      if ( v17 )
      {
        v18 = 1;
        FMOD::SystemI::enterCrit(sound[0]->mSystem, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
      }
      else
      {
        v18 = 0;
      }
      mNodeData = sound[0][1].mNodeData;
      v20 = mNodeData[15];
      v21 = v20;
      BYTE1(v21) = BYTE1(v20) & 0xBF;
      mNodeData[15] = v21;
      if ( updated )
      {
        if ( updated == FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0 )
          updated = FMOD_RESULT::FMOD_OK_0;
      }
      else if ( *((_QWORD *)mNodeData + 24) )
      {
        (*(void (__fastcall **)(_DWORD *, _QWORD))(*(_QWORD *)mNodeData + 88LL))(mNodeData, (v20 >> 5) & 1);
      }
      if ( v18 && v17 )
        FMOD::SystemI::leaveCrit(v17, FMOD_SYSTEM_CRIT_STREAMREALCHAN);
LABEL_36:
      v6 = sound[0];
      v8 = sound[0]->mAsyncData;
      goto LABEL_8;
    case FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0:
      updated = FMOD::SoundI::updateSubSound(sound[0], sound[0]->mSubSoundIndex, 0);
      if ( updated == FMOD_RESULT::FMOD_OK_0 )
      {
        updated = FMOD::Stream::setPosition((FMOD::Stream *const)sound[0], 0, 2u);
        if ( updated == FMOD_RESULT::FMOD_OK_0 )
          updated = FMOD::Stream::flush((FMOD::Stream *const)sound[0]);
      }
      goto LABEL_36;
  }
  v8 = v6->mAsyncData;
  updated = FMOD_RESULT::FMOD_OK_0;
LABEL_8:
  v8->mResult = updated;
  mSubSoundParent = v6->mSubSoundParent;
  if ( mSubSoundParent )
    mSubSoundParent->mDontRelease = 1;
  v6->mDontRelease = 1;
  v6->mOpenState.m_value = updated != FMOD_RESULT::FMOD_OK_0
                         ? FMOD_OPENSTATE::FMOD_OPENSTATE_ERROR_0
                         : FMOD_OPENSTATE::FMOD_OPENSTATE_READY_0;
  v11 = sound[0];
  if ( sound[0]->mSubSoundParent )
  {
    sound[0]->mSubSoundParent->mOpenState.m_value = sound[0]->mOpenState.m_value;
    v11 = sound[0];
  }
  if ( v11->mSubSoundShared )
  {
    v11->mSubSoundShared->mOpenState.m_value = v11->mOpenState.m_value;
    v12 = sound[0];
  }
  else
  {
    v30 = (unsigned __int8)(*v11->_vptr_SoundI)(v11) == 0;
    v12 = sound[0];
    if ( !v30 && sound[0]->mNumSubSounds == 1 )
    {
      mSubSound = sound[0]->mSubSound;
      if ( *mSubSound )
      {
        (*mSubSound)->mOpenState.m_value = sound[0]->mOpenState.m_value;
        v12 = sound[0];
      }
    }
  }
  v13 = v12->mAsyncData;
  if ( v13->mExInfoExists && v13->mExInfo.nonblockcallback )
  {
    result = FMOD::SystemI::enterUserCallback(mSystem, 1);
    if ( result )
      return result;
    sound[0]->mAsyncData->mExInfo.nonblockcallback((FMOD_SOUND *)sound[0], (FMOD_RESULT)updated);
    result = FMOD::SystemI::leaveUserCallback(mSystem);
    if ( result )
      return result;
    v12 = sound[0];
  }
  v12->mDontRelease = 0;
  v15 = v12->mSubSoundParent;
  if ( v15 )
    v15->mDontRelease = 0;
LABEL_22:
  FMOD_OS_CriticalSection_Enter(this->mCrit);
  v16 = this->mCallbackHead.mNodeNext;
  FMOD_OS_CriticalSection_Leave(this->mCrit);
  if ( v16 == &this->mCallbackHead )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    result = ((unsigned int (__fastcall *)(_QWORD))v16->mNodeData)((unsigned int)this->mIndex);
    if ( result )
      break;
    FMOD_OS_CriticalSection_Enter(this->mCrit);
    v16 = v16->mNodeNext;
    FMOD_OS_CriticalSection_Leave(this->mCrit);
    if ( v16 == &this->mCallbackHead )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224e210 | Name: j__ZN4FMOD11AsyncThread10threadFuncEv
// attributes: thunk
void __fastcall FMOD::AsyncThread::threadFunc(void *data)
{
  _ZN4FMOD11AsyncThread10threadFuncEv((FMOD::AsyncThread *const)data);
}


// Address: 0x224e220 | Name: _ZN4FMOD11AsyncThread14getAsyncThreadEPNS_7SystemIEiPPS0_
FMOD_RESULT_0 __fastcall FMOD::AsyncThread::getAsyncThread(
        FMOD::SystemI *system,
        int threadindex,
        FMOD::AsyncThread **asyncthread_out)
{
  FMOD::Atomic<FMOD::AsyncThread*> *v4; // rbp
  FMOD::AsyncThread *m_value; // rbx
  FMOD_RESULT_0 v6; // r12d
  FMOD_OS_CRITICALSECTION *gAsyncCrit; // r15
  FMOD::AsyncThread *v9; // rax

  v4 = &FMOD::AsyncThread::gAsyncThread[threadindex];
  m_value = v4->m_value;
  if ( v4->m_value )
    goto LABEL_2;
  gAsyncCrit = off_286F358->gAsyncCrit;
  FMOD_OS_CriticalSection_Enter(gAsyncCrit);
  m_value = v4->m_value;
  if ( !v4->m_value )
  {
    v9 = (FMOD::AsyncThread *)FMOD::MemPool::calloc(
                                off_286F358->gSystemMemPool,
                                400,
                                "../../../core_api/src/fmod_async.cpp",
                                511,
                                0x200000u);
    m_value = v9;
    if ( v9 )
    {
      FMOD::AsyncThread::AsyncThread(v9);
      v6 = FMOD::AsyncThread::init(m_value, threadindex, system);
      if ( v6 == FMOD_RESULT::FMOD_OK_0 )
      {
        v4->m_value = m_value;
        goto LABEL_5;
      }
    }
    else
    {
      v6 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
    FMOD_OS_CriticalSection_Leave(gAsyncCrit);
    return v6;
  }
LABEL_5:
  FMOD_OS_CriticalSection_Leave(gAsyncCrit);
LABEL_2:
  *asyncthread_out = m_value;
  return FMOD_RESULT::FMOD_OK_0;
}


