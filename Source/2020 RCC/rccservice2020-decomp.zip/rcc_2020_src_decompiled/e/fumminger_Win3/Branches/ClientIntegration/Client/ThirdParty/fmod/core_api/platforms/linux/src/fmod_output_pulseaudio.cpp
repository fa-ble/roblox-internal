// Address: 0x2263910 | Name: _ZN4FMOD16OutputPulseAudio16getDescriptionExEv
FMOD::FMOD_OUTPUT_DESCRIPTION_EX *__cdecl FMOD::OutputPulseAudio::getDescriptionEx()
{
  memset(&stru_2B06340, 0, sizeof(stru_2B06340));
  stru_2B06340.apiversion = 4;
  stru_2B06340.version = 0x20000;
  stru_2B06340.mType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_PULSEAUDIO_0;
  stru_2B06340.mSize = 3376;
  stru_2B06340.name = "FMOD PulseAudio Output";
  stru_2B06340.getnumdrivers = FMOD::OutputPulseAudio::getNumDriversCallback;
  stru_2B06340.getdriverinfo = FMOD::OutputPulseAudio::getDriverInfoCallback;
  stru_2B06340.init = FMOD::OutputPulseAudio::initCallback;
  stru_2B06340.close = FMOD::OutputPulseAudio::closeCallback;
  stru_2B06340.start = FMOD::OutputPulseAudio::startCallback;
  stru_2B06340.stop = FMOD::OutputPulseAudio::stopCallback;
  stru_2B06340.record_getnumdrivers = FMOD::OutputPulseAudio::recordGetNumDriversCallback;
  stru_2B06340.record_getdriverinfo = FMOD::OutputPulseAudio::recordGetDriverInfoCallback;
  stru_2B06340.record_start = FMOD::OutputPulseAudio::recordStartCallback;
  stru_2B06340.record_stop = FMOD::OutputPulseAudio::recordStopCallback;
  stru_2B06340.record_getposition = FMOD::OutputPulseAudio::recordGetPositionCallback;
  stru_2B06340.record_lock = FMOD::OutputPulseAudio::recordLockCallback;
  return &stru_2B06340;
}


// Address: 0x2263a10 | Name: _ZN4FMOD16OutputPulseAudio11registerLibEv
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::registerLib(FMOD::OutputPulseAudio *const this)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_OK_0;
  if ( !*((_QWORD *)this + 367) )
  {
    result = FMOD_OS_Library_Load("libpulse.so.0", (FMOD_OS_LIBRARY **)this + 367);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD_OS_Library_GetProcAddress(
                 *((FMOD_OS_LIBRARY **)this + 367),
                 "pa_get_library_version",
                 (void **)this + 336);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD_OS_Library_GetProcAddress(*((FMOD_OS_LIBRARY **)this + 367), "pa_strerror", (void **)this + 337);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = FMOD_OS_Library_GetProcAddress(
                     *((FMOD_OS_LIBRARY **)this + 367),
                     "pa_mainloop_new",
                     (void **)this + 338);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = FMOD_OS_Library_GetProcAddress(
                       *((FMOD_OS_LIBRARY **)this + 367),
                       "pa_mainloop_get_api",
                       (void **)this + 339);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              result = FMOD_OS_Library_GetProcAddress(
                         *((FMOD_OS_LIBRARY **)this + 367),
                         "pa_context_new",
                         (void **)this + 340);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                result = FMOD_OS_Library_GetProcAddress(
                           *((FMOD_OS_LIBRARY **)this + 367),
                           "pa_stream_new",
                           (void **)this + 341);
                if ( result == FMOD_RESULT::FMOD_OK_0 )
                {
                  result = FMOD_OS_Library_GetProcAddress(
                             *((FMOD_OS_LIBRARY **)this + 367),
                             "pa_context_get_server_info",
                             (void **)this + 342);
                  if ( result == FMOD_RESULT::FMOD_OK_0 )
                  {
                    result = FMOD_OS_Library_GetProcAddress(
                               *((FMOD_OS_LIBRARY **)this + 367),
                               "pa_context_get_sink_info_list",
                               (void **)this + 343);
                    if ( result == FMOD_RESULT::FMOD_OK_0 )
                    {
                      result = FMOD_OS_Library_GetProcAddress(
                                 *((FMOD_OS_LIBRARY **)this + 367),
                                 "pa_context_get_source_info_list",
                                 (void **)this + 344);
                      if ( result == FMOD_RESULT::FMOD_OK_0 )
                      {
                        result = FMOD_OS_Library_GetProcAddress(
                                   *((FMOD_OS_LIBRARY **)this + 367),
                                   "pa_context_get_state",
                                   (void **)this + 345);
                        if ( result == FMOD_RESULT::FMOD_OK_0 )
                        {
                          result = FMOD_OS_Library_GetProcAddress(
                                     *((FMOD_OS_LIBRARY **)this + 367),
                                     "pa_operation_get_state",
                                     (void **)this + 346);
                          if ( result == FMOD_RESULT::FMOD_OK_0 )
                          {
                            result = FMOD_OS_Library_GetProcAddress(
                                       *((FMOD_OS_LIBRARY **)this + 367),
                                       "pa_stream_get_state",
                                       (void **)this + 347);
                            if ( result == FMOD_RESULT::FMOD_OK_0 )
                            {
                              result = FMOD_OS_Library_GetProcAddress(
                                         *((FMOD_OS_LIBRARY **)this + 367),
                                         "pa_context_errno",
                                         (void **)this + 348);
                              if ( result == FMOD_RESULT::FMOD_OK_0 )
                              {
                                result = FMOD_OS_Library_GetProcAddress(
                                           *((FMOD_OS_LIBRARY **)this + 367),
                                           "pa_context_connect",
                                           (void **)this + 349);
                                if ( result == FMOD_RESULT::FMOD_OK_0 )
                                {
                                  result = FMOD_OS_Library_GetProcAddress(
                                             *((FMOD_OS_LIBRARY **)this + 367),
                                             "pa_mainloop_iterate",
                                             (void **)this + 350);
                                  if ( result == FMOD_RESULT::FMOD_OK_0 )
                                  {
                                    result = FMOD_OS_Library_GetProcAddress(
                                               *((FMOD_OS_LIBRARY **)this + 367),
                                               "pa_stream_connect_playback",
                                               (void **)this + 351);
                                    if ( result == FMOD_RESULT::FMOD_OK_0 )
                                    {
                                      result = FMOD_OS_Library_GetProcAddress(
                                                 *((FMOD_OS_LIBRARY **)this + 367),
                                                 "pa_stream_connect_record",
                                                 (void **)this + 352);
                                      if ( result == FMOD_RESULT::FMOD_OK_0 )
                                      {
                                        result = FMOD_OS_Library_GetProcAddress(
                                                   *((FMOD_OS_LIBRARY **)this + 367),
                                                   "pa_stream_disconnect",
                                                   (void **)this + 353);
                                        if ( result == FMOD_RESULT::FMOD_OK_0 )
                                        {
                                          result = FMOD_OS_Library_GetProcAddress(
                                                     *((FMOD_OS_LIBRARY **)this + 367),
                                                     "pa_stream_write",
                                                     (void **)this + 354);
                                          if ( result == FMOD_RESULT::FMOD_OK_0 )
                                          {
                                            result = FMOD_OS_Library_GetProcAddress(
                                                       *((FMOD_OS_LIBRARY **)this + 367),
                                                       "pa_stream_peek",
                                                       (void **)this + 355);
                                            if ( result == FMOD_RESULT::FMOD_OK_0 )
                                            {
                                              result = FMOD_OS_Library_GetProcAddress(
                                                         *((FMOD_OS_LIBRARY **)this + 367),
                                                         "pa_stream_drop",
                                                         (void **)this + 356);
                                              if ( result == FMOD_RESULT::FMOD_OK_0 )
                                              {
                                                result = FMOD_OS_Library_GetProcAddress(
                                                           *((FMOD_OS_LIBRARY **)this + 367),
                                                           "pa_stream_writable_size",
                                                           (void **)this + 357);
                                                if ( result == FMOD_RESULT::FMOD_OK_0 )
                                                {
                                                  result = FMOD_OS_Library_GetProcAddress(
                                                             *((FMOD_OS_LIBRARY **)this + 367),
                                                             "pa_stream_readable_size",
                                                             (void **)this + 358);
                                                  if ( result == FMOD_RESULT::FMOD_OK_0 )
                                                  {
                                                    result = FMOD_OS_Library_GetProcAddress(
                                                               *((FMOD_OS_LIBRARY **)this + 367),
                                                               "pa_stream_set_underflow_callback",
                                                               (void **)this + 359);
                                                    if ( result == FMOD_RESULT::FMOD_OK_0 )
                                                    {
                                                      result = FMOD_OS_Library_GetProcAddress(
                                                                 *((FMOD_OS_LIBRARY **)this + 367),
                                                                 "pa_mainloop_wakeup",
                                                                 (void **)this + 360);
                                                      if ( result == FMOD_RESULT::FMOD_OK_0 )
                                                      {
                                                        result = FMOD_OS_Library_GetProcAddress(
                                                                   *((FMOD_OS_LIBRARY **)this + 367),
                                                                   "pa_mainloop_free",
                                                                   (void **)this + 361);
                                                        if ( result == FMOD_RESULT::FMOD_OK_0 )
                                                        {
                                                          result = FMOD_OS_Library_GetProcAddress(
                                                                     *((FMOD_OS_LIBRARY **)this + 367),
                                                                     "pa_context_disconnect",
                                                                     (void **)this + 362);
                                                          if ( result == FMOD_RESULT::FMOD_OK_0 )
                                                          {
                                                            result = FMOD_OS_Library_GetProcAddress(
                                                                       *((FMOD_OS_LIBRARY **)this + 367),
                                                                       "pa_context_unref",
                                                                       (void **)this + 363);
                                                            if ( result == FMOD_RESULT::FMOD_OK_0 )
                                                            {
                                                              result = FMOD_OS_Library_GetProcAddress(
                                                                         *((FMOD_OS_LIBRARY **)this + 367),
                                                                         "pa_operation_unref",
                                                                         (void **)this + 364);
                                                              if ( result == FMOD_RESULT::FMOD_OK_0 )
                                                              {
                                                                result = FMOD_OS_Library_GetProcAddress(
                                                                           *((FMOD_OS_LIBRARY **)this + 367),
                                                                           "pa_stream_unref",
                                                                           (void **)this + 365);
                                                                if ( result == FMOD_RESULT::FMOD_OK_0 )
                                                                  return FMOD_OS_Library_GetProcAddress(
                                                                           *((FMOD_OS_LIBRARY **)this + 367),
                                                                           "pa_stream_set_buffer_attr",
                                                                           (void **)this + 366);
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x2263e50 | Name: _ZN4FMOD16OutputPulseAudio10serverInfoEP10pa_contextPK14pa_server_info
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::serverInfo(
        FMOD::OutputPulseAudio *const this,
        pa_context *context,
        const pa_server_info *serverInfo)
{
  const char *default_sink_name; // rdi
  const char *default_source_name; // rdi
  char *v7; // rax
  char *v9; // rax

  default_sink_name = serverInfo->default_sink_name;
  if ( default_sink_name && FMOD_strlen(default_sink_name) )
  {
    v9 = FMOD_strdup(serverInfo->default_sink_name);
    ++*((_DWORD *)this + 670);
    *((_QWORD *)this + 143) = v9;
  }
  default_source_name = serverInfo->default_source_name;
  if ( default_source_name && FMOD_strlen(default_source_name) )
  {
    v7 = FMOD_strdup(serverInfo->default_source_name);
    ++*((_DWORD *)this + 671);
    *((_QWORD *)this + 239) = v7;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2263ec0 | Name: _ZN4FMOD16OutputPulseAudio18serverInfoCallbackEP10pa_contextPK14pa_server_infoPv
void __fastcall FMOD::OutputPulseAudio::serverInfoCallback(
        pa_context *context,
        const pa_server_info *serverInfo,
        void *userData)
{
  FMOD::OutputPulseAudio::serverInfo((FMOD::OutputPulseAudio *const)userData, context, serverInfo);
}


// Address: 0x2263ee0 | Name: _ZN4FMOD16OutputPulseAudio10enumOutputEP10pa_contextPK12pa_sink_info
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::enumOutput(
        FMOD::OutputPulseAudio *const this,
        pa_context *context,
        const pa_sink_info *sinkInfo)
{
  const char *v5; // rdi
  __int64 v7; // r12
  char *v8; // rax
  __int64 v9; // rdx
  __int64 v10; // r12
  const char *description; // rdi
  int v12; // eax
  char *v13; // rdx

  v5 = (const char *)*((_QWORD *)this + 143);
  if ( v5 && !FMOD_strcmp(v5, sinkInfo->name) )
  {
    *((_QWORD *)this + 144) = FMOD_strdup(sinkInfo->description);
    *((_DWORD *)this + 290) = sinkInfo->sample_spec.channels;
    *((_DWORD *)this + 291) = sinkInfo->sample_spec.rate;
    return FMOD_RESULT::FMOD_OK_0;
  }
  v7 = *((int *)this + 670);
  if ( (int)v7 > 31 )
    return FMOD_RESULT::FMOD_OK_0;
  v8 = FMOD_strdup(sinkInfo->name);
  v9 = 3 * v7;
  v10 = *((int *)this + 670);
  description = sinkInfo->description;
  *((_QWORD *)this + v9 + 143) = v8;
  *((_QWORD *)this + 3 * v10 + 144) = FMOD_strdup(description);
  v12 = *((_DWORD *)this + 670);
  v13 = (char *)this + 24 * v12 + 1152;
  *((_DWORD *)v13 + 2) = sinkInfo->sample_spec.channels;
  *((_DWORD *)v13 + 3) = sinkInfo->sample_spec.rate;
  *((_DWORD *)this + 670) = v12 + 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2263fa0 | Name: _ZN4FMOD16OutputPulseAudio18enumOutputCallbackEP10pa_contextPK12pa_sink_infoiPv
void __fastcall FMOD::OutputPulseAudio::enumOutputCallback(
        pa_context *context,
        const pa_sink_info *sinkInfo,
        int eol,
        void *userData)
{
  if ( !eol )
    FMOD::OutputPulseAudio::enumOutput((FMOD::OutputPulseAudio *const)userData, context, sinkInfo);
}


// Address: 0x2263fc0 | Name: _ZN4FMOD16OutputPulseAudio9enumInputEP10pa_contextPK14pa_source_info
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::enumInput(
        FMOD::OutputPulseAudio *const this,
        pa_context *context,
        const pa_source_info *sourceInfo)
{
  const char *v5; // rdi
  __int64 v7; // r12
  char *v8; // rax
  __int64 v9; // rdx
  __int64 v10; // r12
  const char *description; // rdi
  int v12; // eax
  char *v13; // rdx

  v5 = (const char *)*((_QWORD *)this + 239);
  if ( v5 && !FMOD_strcmp(v5, sourceInfo->name) )
  {
    *((_QWORD *)this + 240) = FMOD_strdup(sourceInfo->description);
    *((_DWORD *)this + 482) = sourceInfo->sample_spec.channels;
    *((_DWORD *)this + 483) = sourceInfo->sample_spec.rate;
    return FMOD_RESULT::FMOD_OK_0;
  }
  v7 = *((int *)this + 671);
  if ( (int)v7 > 31 )
    return FMOD_RESULT::FMOD_OK_0;
  v8 = FMOD_strdup(sourceInfo->name);
  v9 = 3 * v7;
  v10 = *((int *)this + 671);
  description = sourceInfo->description;
  *((_QWORD *)this + v9 + 239) = v8;
  *((_QWORD *)this + 3 * v10 + 240) = FMOD_strdup(description);
  v12 = *((_DWORD *)this + 671);
  v13 = (char *)this + 24 * v12 + 1920;
  *((_DWORD *)v13 + 2) = sourceInfo->sample_spec.channels;
  *((_DWORD *)v13 + 3) = sourceInfo->sample_spec.rate;
  *((_DWORD *)this + 671) = v12 + 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2264080 | Name: _ZN4FMOD16OutputPulseAudio17enumInputCallbackEP10pa_contextPK14pa_source_infoiPv
void __fastcall FMOD::OutputPulseAudio::enumInputCallback(
        pa_context *context,
        const pa_source_info *sourceInfo,
        int eol,
        void *userData)
{
  if ( !eol )
    FMOD::OutputPulseAudio::enumInput((FMOD::OutputPulseAudio *const)userData, context, sourceInfo);
}


// Address: 0x22640a0 | Name: _ZN4FMOD16OutputPulseAudio9enumerateEv
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::enumerate(FMOD::OutputPulseAudio *const this)
{
  FMOD_RESULT_0 result; // eax
  __int64 v2; // rax
  __int64 v3; // rbp
  __int64 v4; // rax
  __int64 v5; // rax
  __int64 v6; // r12
  int v7; // eax
  __int64 v8; // r13
  int v9; // eax
  __int64 v10; // r13
  int v11; // eax
  __int64 v12; // r13
  int v13; // eax

  result = FMOD_RESULT::FMOD_OK_0;
  if ( !*((_BYTE *)this + 784) )
  {
    result = FMOD::OutputPulseAudio::registerLib(this);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v2 = (*((__int64 (**)(void))this + 338))();
      v3 = v2;
      if ( v2 )
      {
        v4 = (*((__int64 (__fastcall **)(__int64))this + 339))(v2);
        if ( v4 )
        {
          v5 = (*((__int64 (__fastcall **)(__int64, const char *))this + 340))(v4, "FMOD Device Enumerator");
          v6 = v5;
          if ( v5 )
          {
            if ( (*((int (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD))this + 349))(v5, 0, 0, 0) >= 0 )
            {
              while ( (*((int (__fastcall **)(__int64, __int64, _QWORD))this + 350))(v3, 1, 0) >= 0 )
              {
                v7 = (*((__int64 (__fastcall **)(__int64))this + 345))(v6);
                if ( (unsigned int)(v7 - 1) > 3 )
                  break;
                if ( v7 == 4 )
                {
                  v8 = (*((__int64 (__fastcall **)(__int64, _QWORD, FMOD::OutputPulseAudio *const))this + 342))(
                         v6,
                         FMOD::OutputPulseAudio::serverInfoCallback,
                         this);
                  if ( v8 )
                  {
                    while ( (*((int (__fastcall **)(__int64, __int64, _QWORD))this + 350))(v3, 1, 0) >= 0 )
                    {
                      v9 = (*((__int64 (__fastcall **)(__int64))this + 346))(v8);
                      if ( v9 == 2 )
                        break;
                      if ( v9 == 1 )
                      {
                        (*((void (__fastcall **)(__int64))this + 364))(v8);
                        v10 = (*((__int64 (__fastcall **)(__int64, void (__fastcall *)(pa_context *, const pa_sink_info *, int, void *), FMOD::OutputPulseAudio *const))this
                               + 343))(
                                v6,
                                FMOD::OutputPulseAudio::enumOutputCallback,
                                this);
                        if ( v10 )
                        {
                          while ( (*((int (__fastcall **)(__int64, __int64, _QWORD))this + 350))(v3, 1, 0) >= 0 )
                          {
                            v11 = (*((__int64 (__fastcall **)(__int64))this + 346))(v10);
                            if ( v11 == 2 )
                              break;
                            if ( v11 == 1 )
                            {
                              (*((void (__fastcall **)(__int64))this + 364))(v10);
                              v12 = (*((__int64 (__fastcall **)(__int64, void (__fastcall *)(pa_context *, const pa_source_info *, int, void *), FMOD::OutputPulseAudio *const))this
                                     + 344))(
                                      v6,
                                      FMOD::OutputPulseAudio::enumInputCallback,
                                      this);
                              if ( v12 )
                              {
                                while ( (*((int (__fastcall **)(__int64, __int64, _QWORD))this + 350))(v3, 1, 0) >= 0 )
                                {
                                  v13 = (*((__int64 (__fastcall **)(__int64))this + 346))(v12);
                                  if ( v13 == 2 )
                                    break;
                                  if ( v13 == 1 )
                                  {
                                    (*((void (__fastcall **)(__int64))this + 364))(v12);
                                    (*((void (__fastcall **)(__int64))this + 362))(v6);
                                    (*((void (__fastcall **)(__int64))this + 363))(v6);
                                    (*((void (__fastcall **)(__int64))this + 361))(v3);
                                    *((_BYTE *)this + 784) = 1;
                                    return FMOD_RESULT::FMOD_OK_0;
                                  }
                                }
                              }
                              return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
                            }
                          }
                        }
                        return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
                      }
                    }
                  }
                  return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
                }
              }
            }
          }
        }
      }
      return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
    }
  }
  return result;
}


// Address: 0x22642b0 | Name: _ZN4FMOD16OutputPulseAudio13getNumDriversEPi
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::getNumDrivers(FMOD::OutputPulseAudio *const this, int *numDrivers)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::OutputPulseAudio::enumerate(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( numDrivers )
      *numDrivers = *((_DWORD *)this + 670);
  }
  return result;
}


// Address: 0x22642e0 | Name: _ZN4FMOD16OutputPulseAudio21getNumDriversCallbackEP17FMOD_OUTPUT_STATEPi
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::getNumDriversCallback(FMOD_OUTPUT_STATE *output, int *numDrivers)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::getNumDrivers(p_requestreset, numDrivers);
}


// Address: 0x2264300 | Name: _ZN4FMOD16OutputPulseAudio13getDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::getDriverInfo(
        FMOD::OutputPulseAudio *const this,
        int id,
        char *name,
        int nameLen,
        FMOD_GUID *a5,
        int *systemRate,
        FMOD_SPEAKERMODE_0 *a7,
        int *speakerModeChannels)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::OutputPulseAudio::enumerate(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( id >= 0 && id < *((_DWORD *)this + 670) )
    {
      if ( name && nameLen > 0 )
        FMOD_strcpy_safe(name, *((const char **)this + 3 * id + 144), nameLen);
      if ( systemRate )
        *systemRate = *((_DWORD *)this + 6 * id + 291);
      if ( speakerModeChannels )
        *speakerModeChannels = *((_DWORD *)this + 6 * id + 290);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x22643c0 | Name: _ZN4FMOD16OutputPulseAudio21getDriverInfoCallbackEP17FMOD_OUTPUT_STATEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES6_
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::getDriverInfoCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        char *name,
        int nameLen,
        FMOD_GUID *guid,
        int *systemRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::getDriverInfo(
           p_requestreset,
           id,
           name,
           nameLen,
           guid,
           systemRate,
           speakerMode,
           speakerModeChannels);
}


// Address: 0x22643e0 | Name: _ZN4FMOD16OutputPulseAudio16createChannelMapEP14pa_channel_map16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::createChannelMap(
        FMOD::OutputPulseAudio *const this,
        pa_channel_map *map,
        FMOD_SPEAKERMODE_0 mode)
{
  if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0 )
  {
    map->channels = 1;
    map->map[0] = pa_channel_position::PA_CHANNEL_POSITION_MONO;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
  {
    map->channels = 2;
    map->map[0] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_LEFT;
    map->map[1] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_RIGHT;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_QUAD_0 )
  {
    map->channels = 4;
    map->map[0] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_LEFT;
    map->map[1] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_RIGHT;
    map->map[2] = pa_channel_position::PA_CHANNEL_POSITION_SIDE_LEFT;
    map->map[3] = pa_channel_position::PA_CHANNEL_POSITION_SIDE_RIGHT;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
  {
    map->channels = 5;
    map->map[0] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_LEFT;
    map->map[1] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_RIGHT;
    map->map[2] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_CENTER;
    map->map[3] = pa_channel_position::PA_CHANNEL_POSITION_SIDE_LEFT;
    map->map[4] = pa_channel_position::PA_CHANNEL_POSITION_SIDE_RIGHT;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_5POINT1_0 )
    {
      map->channels = 6;
      map->map[0] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_LEFT;
      map->map[1] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_RIGHT;
      map->map[2] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_CENTER;
      map->map[3] = pa_channel_position::PA_CHANNEL_POSITION_LFE;
      map->map[4] = pa_channel_position::PA_CHANNEL_POSITION_SIDE_LEFT;
      map->map[5] = pa_channel_position::PA_CHANNEL_POSITION_SIDE_RIGHT;
    }
    else if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
    {
      map->channels = 8;
      map->map[0] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_LEFT;
      map->map[1] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_RIGHT;
      map->map[2] = pa_channel_position::PA_CHANNEL_POSITION_FRONT_CENTER;
      map->map[3] = pa_channel_position::PA_CHANNEL_POSITION_LFE;
      map->map[4] = pa_channel_position::PA_CHANNEL_POSITION_SIDE_LEFT;
      map->map[5] = pa_channel_position::PA_CHANNEL_POSITION_SIDE_RIGHT;
      map->map[6] = pa_channel_position::PA_CHANNEL_POSITION_REAR_LEFT;
      map->map[7] = pa_channel_position::PA_CHANNEL_POSITION_REAR_RIGHT;
    }
    else
    {
      map->channels = 0;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x2264510 | Name: _ZN4FMOD16OutputPulseAudio25getOutputBufferAttributesEP14pa_buffer_attr
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::getOutputBufferAttributes(
        FMOD::OutputPulseAudio *const this,
        pa_buffer_attr *bufferAttr)
{
  uint32_t_0 v2; // edx
  int v3; // eax
  uint32_t_0 v4; // eax

  v2 = *((_DWORD *)this + 739);
  v3 = *((_DWORD *)this + 740);
  bufferAttr->fragsize = -1;
  v4 = v2 * v3;
  bufferAttr->minreq = v2;
  bufferAttr->tlength = v4;
  bufferAttr->prebuf = v4;
  bufferAttr->maxlength = v4 + v2;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2264540 | Name: _ZN4FMOD16OutputPulseAudio21handleStreamUnderflowEv
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::handleStreamUnderflow(FMOD::OutputPulseAudio *const this)
{
  FMOD_RESULT_0 v1; // ebp
  int v3; // eax
  pa_buffer_attr bufferAttr; // [rsp+0h] [rbp-38h] BYREF

  v1 = FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  if ( *((_QWORD *)this + 366) )
  {
    LOBYTE(v1) = 0;
    if ( !*((_QWORD *)this + 417) )
    {
      v3 = *((_DWORD *)this + 740);
      if ( v3 < *((_DWORD *)this + 741) )
      {
        *((_DWORD *)this + 740) = v3 + 1;
        FMOD::OutputPulseAudio::getOutputBufferAttributes(this, &bufferAttr);
        *((_QWORD *)this + 417) = (*((__int64 (__fastcall **)(_QWORD, pa_buffer_attr *, _QWORD, _QWORD))this + 366))(
                                    *((_QWORD *)this + 416),
                                    &bufferAttr,
                                    0,
                                    0);
      }
    }
  }
  return v1;
}


// Address: 0x22645c0 | Name: _ZN4FMOD16OutputPulseAudio23streamUnderflowCallbackEP9pa_streamPv
void __fastcall FMOD::OutputPulseAudio::streamUnderflowCallback(pa_stream *stream, void *userdata)
{
  FMOD::OutputPulseAudio::handleStreamUnderflow((FMOD::OutputPulseAudio *const)userdata);
}


// Address: 0x22645d0 | Name: _ZN4FMOD16OutputPulseAudio4initEijPiP16FMOD_SPEAKERMODES1_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::init(
        FMOD::OutputPulseAudio *const this,
        int id,
        FMOD_INITFLAGS a3,
        int *outputRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels,
        FMOD_SOUND_FORMAT_0 *outputFormat,
        int dspBufferLength,
        int dspNumBuffers,
        void *extraDriverData)
{
  FMOD_RESULT_0 result; // eax
  int v14; // edx
  __int64 v15; // rax
  __int64 v16; // rax
  const char *v17; // rdx
  __int64 v18; // rax
  int v19; // eax
  uint32_t_0 v20; // eax
  FMOD_SPEAKERMODE_0 v21; // edx
  __int64 v22; // rax
  int v23; // eax
  void *v24; // rax
  pa_sample_spec sampleSpec; // [rsp+0h] [rbp-E8h] BYREF
  pa_buffer_attr bufferAttr; // [rsp+10h] [rbp-D8h] BYREF
  pa_channel_map channelMap; // [rsp+30h] [rbp-B8h] BYREF

  result = FMOD::OutputPulseAudio::enumerate(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v14 = *((_DWORD *)this + 670);
    result = FMOD_RESULT::FMOD_ERR_OUTPUT_NODRIVERS_0;
    if ( v14 )
    {
      LOBYTE(result) = 31;
      if ( id >= 0 && v14 > id )
      {
        if ( *speakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
        {
          *speakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0;
          *speakerModeChannels = 2;
        }
        *outputFormat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
        v15 = (*((__int64 (**)(void))this + 338))();
        *((_QWORD *)this + 413) = v15;
        if ( v15 )
        {
          v16 = (*((__int64 (__fastcall **)(__int64))this + 339))(v15);
          *((_QWORD *)this + 414) = v16;
          if ( v16 )
          {
            v17 = "FMOD Audio";
            if ( extraDriverData )
              v17 = (const char *)extraDriverData;
            v18 = (*((__int64 (__fastcall **)(__int64, const char *))this + 340))(v16, v17);
            *((_QWORD *)this + 415) = v18;
            if ( v18 )
            {
              if ( (*((int (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD))this + 349))(v18, 0, 0, 0) >= 0 )
              {
                while ( (*((int (__fastcall **)(_QWORD, __int64, _QWORD))this + 350))(*((_QWORD *)this + 413), 1, 0) >= 0 )
                {
                  v19 = (*((__int64 (__fastcall **)(_QWORD))this + 345))(*((_QWORD *)this + 415));
                  if ( (unsigned int)(v19 - 1) > 3 )
                    break;
                  if ( v19 == 4 )
                  {
                    v20 = *outputRate;
                    v21 = *speakerMode;
                    sampleSpec.format = pa_sample_format::PA_SAMPLE_S16LE;
                    sampleSpec.rate = v20;
                    sampleSpec.channels = *speakerModeChannels;
                    result = FMOD::OutputPulseAudio::createChannelMap(this, &channelMap, v21);
                    if ( result )
                      return result;
                    v22 = (*((__int64 (__fastcall **)(_QWORD, const char *, pa_sample_spec *, pa_channel_map *))this
                           + 341))(
                            *((_QWORD *)this + 415),
                            "Mixer Stream",
                            &sampleSpec,
                            &channelMap);
                    *((_QWORD *)this + 416) = v22;
                    if ( v22 )
                    {
                      *((_QWORD *)this + 417) = 0;
                      (*((void (__fastcall **)(__int64, void (__fastcall *)(pa_stream *, void *), FMOD::OutputPulseAudio *const))this
                       + 359))(
                        v22,
                        FMOD::OutputPulseAudio::streamUnderflowCallback,
                        this);
                      *((_DWORD *)this + 738) = dspBufferLength;
                      *((_DWORD *)this + 739) = 2 * *speakerModeChannels * dspBufferLength;
                      *((_DWORD *)this + 740) = dspNumBuffers;
                      *((_DWORD *)this + 741) = 2 * dspNumBuffers;
                      FMOD::OutputPulseAudio::getOutputBufferAttributes(this, &bufferAttr);
                      if ( (*((int (__fastcall **)(_QWORD, _QWORD, pa_buffer_attr *, __int64, _QWORD, _QWORD, _QWORD, _DWORD))this
                            + 351))(
                             *((_QWORD *)this + 416),
                             *((_QWORD *)this + 3 * id + 143),
                             &bufferAttr,
                             0x2000,
                             0,
                             0,
                             *(_QWORD *)&sampleSpec.format,
                             *(_DWORD *)&sampleSpec.channels) >= 0 )
                      {
                        while ( (*((int (__fastcall **)(_QWORD, __int64, _QWORD))this + 350))(
                                  *((_QWORD *)this + 413),
                                  1,
                                  0) >= 0 )
                        {
                          v23 = (*((__int64 (__fastcall **)(_QWORD))this + 347))(*((_QWORD *)this + 416));
                          if ( (unsigned int)(v23 - 1) > 1 )
                            break;
                          if ( v23 == 2 )
                          {
                            v24 = FMOD::MemPool::calloc(
                                    off_286F358->gSystemMemPool,
                                    *((_DWORD *)this + 739),
                                    "../../../core_api/platforms/linux/src/fmod_output_pulseaudio.cpp",
                                    614,
                                    0);
                            *((_QWORD *)this + 368) = v24;
                            return v24 == 0 ? 0x26 : 0;
                          }
                        }
                      }
                    }
                    return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
                  }
                }
              }
            }
          }
        }
        return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
      }
    }
  }
  return result;
}


// Address: 0x2264880 | Name: _ZN4FMOD16OutputPulseAudio12initCallbackEP17FMOD_OUTPUT_STATEijPiP16FMOD_SPEAKERMODES3_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::initCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        FMOD_INITFLAGS flags,
        int *outputRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels,
        FMOD_SOUND_FORMAT_0 *outputFormat,
        int dspBufferLength,
        int dspNumBuffers,
        void *extraDriverData)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::init(
           p_requestreset,
           id,
           flags,
           outputRate,
           speakerMode,
           speakerModeChannels,
           outputFormat,
           dspBufferLength,
           dspNumBuffers,
           extraDriverData);
}


// Address: 0x22648a0 | Name: _ZN4FMOD16OutputPulseAudio5closeEv
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::close(FMOD::OutputPulseAudio *const this)
{
  void *v2; // rsi
  int v3; // edx
  FMOD_RESULT_0 result; // eax
  int v5; // ebp
  char *i; // rbx
  void *v7; // rsi
  int v8; // ebp
  char *j; // rbx
  void *v10; // rsi
  FMOD_OS_LIBRARY *v11; // rdi

  v2 = (void *)*((_QWORD *)this + 368);
  if ( v2 )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      v2,
      "../../../core_api/platforms/linux/src/fmod_output_pulseaudio.cpp",
      634);
    *((_QWORD *)this + 368) = 0;
  }
  if ( *((_QWORD *)this + 417) )
  {
    (*((void (**)(void))this + 364))();
    *((_QWORD *)this + 417) = 0;
  }
  if ( *((_QWORD *)this + 416) )
  {
    v3 = (*((__int64 (**)(void))this + 353))();
    result = FMOD_RESULT::FMOD_ERR_OUTPUT_DRIVERCALL_0;
    if ( v3 < 0 )
      return result;
    (*((void (__fastcall **)(_QWORD))this + 365))(*((_QWORD *)this + 416));
    *((_QWORD *)this + 416) = 0;
  }
  if ( *((_QWORD *)this + 415) )
  {
    (*((void (**)(void))this + 362))();
    (*((void (__fastcall **)(_QWORD))this + 363))(*((_QWORD *)this + 415));
    *((_QWORD *)this + 415) = 0;
  }
  if ( *((_QWORD *)this + 413) )
  {
    (*((void (**)(void))this + 361))();
    *((_QWORD *)this + 413) = 0;
    *((_QWORD *)this + 414) = 0;
  }
  v5 = 0;
  for ( i = (char *)this + 1144; *((_DWORD *)this + 670) > v5; i += 24 )
  {
    if ( *(_QWORD *)i )
    {
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        *(void **)i,
        "../../../core_api/platforms/linux/src/fmod_output_pulseaudio.cpp",
        668);
      *(_QWORD *)i = 0;
    }
    v7 = (void *)*((_QWORD *)i + 1);
    if ( v7 )
    {
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        v7,
        "../../../core_api/platforms/linux/src/fmod_output_pulseaudio.cpp",
        669);
      *((_QWORD *)i + 1) = 0;
    }
    ++v5;
  }
  v8 = 0;
  for ( j = (char *)this + 1912; *((_DWORD *)this + 671) > v8; j += 24 )
  {
    if ( *(_QWORD *)j )
    {
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        *(void **)j,
        "../../../core_api/platforms/linux/src/fmod_output_pulseaudio.cpp",
        674);
      *(_QWORD *)j = 0;
    }
    v10 = (void *)*((_QWORD *)j + 1);
    if ( v10 )
    {
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        v10,
        "../../../core_api/platforms/linux/src/fmod_output_pulseaudio.cpp",
        675);
      *((_QWORD *)j + 1) = 0;
    }
    ++v8;
  }
  v11 = (FMOD_OS_LIBRARY *)*((_QWORD *)this + 367);
  result = FMOD_RESULT::FMOD_OK_0;
  *((_DWORD *)this + 670) = 0;
  *((_DWORD *)this + 671) = 0;
  *((_BYTE *)this + 784) = 0;
  if ( v11 )
  {
    result = FMOD_OS_Library_Free(v11);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      *((_QWORD *)this + 367) = 0;
  }
  return result;
}


// Address: 0x2264b20 | Name: _ZN4FMOD16OutputPulseAudio13closeCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::closeCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::close(p_requestreset);
}


// Address: 0x2264b40 | Name: _ZN4FMOD16OutputPulseAudio5startEv
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::start(FMOD::OutputPulseAudio *const this)
{
  FMOD::Thread *v2; // rdi
  FMOD::SystemI *system; // rax
  FMOD_RESULT_0 result; // eax
  FMOD_OS_SEMAPHORE *v5; // rdi

  v2 = (FMOD::Thread *)((char *)this + 2968);
  system = *(FMOD::SystemI **)&v2[-9].mName[120];
  v2[1].mName[32] = 1;
  result = FMOD::Thread::initThread(
             v2,
             "FMOD mixer thread",
             FMOD::OutputPulseAudio::updateMixer,
             this,
             FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_MIXER,
             FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_CRITICAL,
             system->mAdvancedSettings.stackSizeMixer,
             1,
             0,
             system,
             1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v5 = (FMOD_OS_SEMAPHORE *)*((_QWORD *)this + 408);
    if ( !v5 )
      return FMOD_RESULT::FMOD_OK_0;
    result = FMOD_OS_Semaphore_Signal(v5);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2264bd0 | Name: _ZN4FMOD16OutputPulseAudio13startCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::startCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::start(p_requestreset);
}


// Address: 0x2264bf0 | Name: _ZN4FMOD16OutputPulseAudio4stopEv
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::stop(FMOD::OutputPulseAudio *const this)
{
  if ( !*((_BYTE *)this + 3344) )
    return FMOD_RESULT::FMOD_OK_0;
  *((_BYTE *)this + 3344) = 0;
  (*((void (__fastcall **)(_QWORD))this + 360))(*((_QWORD *)this + 413));
  return FMOD::Thread::closeThread((FMOD::Thread *const)((char *)this + 2968));
}


// Address: 0x2264c30 | Name: _ZN4FMOD16OutputPulseAudio12stopCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::stopCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::stop(p_requestreset);
}


// Address: 0x2264c50 | Name: _ZN4FMOD16OutputPulseAudio11updateMixerEv
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::updateMixer(FMOD::OutputPulseAudio *const this)
{
  int v1; // eax
  int v2; // ebp
  int v3; // eax
  FMOD_RESULT_0 result; // eax

  while ( 1 )
  {
    if ( !*((_BYTE *)this + 3344) )
      return FMOD_RESULT::FMOD_OK_0;
    v1 = (*((__int64 (__fastcall **)(_QWORD))this + 357))(*((_QWORD *)this + 416));
    v2 = v1;
    if ( v1 < 0 )
      return FMOD_RESULT::FMOD_ERR_OUTPUT_DRIVERCALL_0;
    if ( v1 >= *((_DWORD *)this + 739) )
      break;
LABEL_10:
    if ( (*((int (__fastcall **)(_QWORD, __int64, _QWORD))this + 350))(*((_QWORD *)this + 413), 1, 0) < 0 )
      return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
    if ( *((_QWORD *)this + 417) )
    {
      if ( (*((unsigned int (**)(void))this + 346))() )
      {
        (*((void (__fastcall **)(_QWORD))this + 364))(*((_QWORD *)this + 417));
        *((_QWORD *)this + 417) = 0;
      }
    }
  }
  while ( 1 )
  {
    result = (*((unsigned int (__fastcall **)(char *, _QWORD, _QWORD))this + 2))(
               (char *)this + 8,
               *((_QWORD *)this + 368),
               *((unsigned int *)this + 738));
    if ( result )
      return result;
    if ( (*((int (__fastcall **)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))this + 354))(
           *((_QWORD *)this + 416),
           *((_QWORD *)this + 368),
           *((int *)this + 739),
           0,
           0,
           0) < 0 )
      return FMOD_RESULT::FMOD_ERR_OUTPUT_DRIVERCALL_0;
    v3 = *((_DWORD *)this + 739);
    v2 -= v3;
    if ( v3 > v2 )
      goto LABEL_10;
  }
}


// Address: 0x2264d60 | Name: j__ZN4FMOD16OutputPulseAudio11updateMixerEv
// attributes: thunk
void __fastcall FMOD::OutputPulseAudio::updateMixer(void *userData)
{
  _ZN4FMOD16OutputPulseAudio11updateMixerEv((FMOD::OutputPulseAudio *const)userData);
}


// Address: 0x2264d70 | Name: _ZN4FMOD16OutputPulseAudio19recordGetNumDriversEPiS1_
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordGetNumDrivers(
        FMOD::OutputPulseAudio *const this,
        int *numDrivers,
        FMOD_BOOL *enumerationChanged)
{
  *numDrivers = *((_DWORD *)this + 671);
  *enumerationChanged = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2264d90 | Name: _ZN4FMOD16OutputPulseAudio27recordGetNumDriversCallbackEP17FMOD_OUTPUT_STATEPiS3_
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordGetNumDriversCallback(
        FMOD_OUTPUT_STATE *output,
        int *numDrivers,
        FMOD_BOOL *enumerationChanged)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::recordGetNumDrivers(p_requestreset, numDrivers, enumerationChanged);
}


// Address: 0x2264db0 | Name: _ZN4FMOD16OutputPulseAudio19recordGetDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordGetDriverInfo(
        FMOD::OutputPulseAudio *const this,
        int id,
        char *name,
        int nameLen,
        FMOD_GUID *guid,
        int *systemRate,
        FMOD_SPEAKERMODE_0 *a7,
        int *speakerModeChannels)
{
  char *v9; // r12
  int v11; // eax

  v9 = (char *)this + 24 * id;
  FMOD_strcpy_safe(name, *((const char **)v9 + 240), nameLen);
  *(_QWORD *)guid->Data4 = 0;
  *(_QWORD *)&guid->Data1 = 0;
  v11 = *((_DWORD *)v9 + 483);
  guid->Data1 = id + 1;
  *systemRate = v11;
  *speakerModeChannels = *((_DWORD *)v9 + 482);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2264e20 | Name: _ZN4FMOD16OutputPulseAudio27recordGetDriverInfoCallbackEP17FMOD_OUTPUT_STATEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES6_
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordGetDriverInfoCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        char *name,
        int nameLen,
        FMOD_GUID *guid,
        int *systemRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::recordGetDriverInfo(
           p_requestreset,
           id,
           name,
           nameLen,
           guid,
           systemRate,
           speakerMode,
           speakerModeChannels);
}


// Address: 0x2264e40 | Name: _ZN4FMOD16OutputPulseAudio11recordStartEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordStart(
        FMOD::OutputPulseAudio *const this,
        FMOD::FMOD_RECORDING_INFO *recordInfo)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v4; // rdi
  int v6; // eax
  FMOD_SPEAKERMODE_0 v7; // edx
  int mRecordChannels; // eax
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rsi
  int v12; // r12d
  int v13; // eax
  void *v14; // rax
  int dspNumBuffers; // [rsp+8h] [rbp-E0h] BYREF
  unsigned int dspBufferLength; // [rsp+Ch] [rbp-DCh] BYREF
  pa_sample_spec sampleSpec; // [rsp+10h] [rbp-D8h] BYREF
  _DWORD v18[4]; // [rsp+20h] [rbp-C8h] BYREF
  int blockLengthBytes; // [rsp+30h] [rbp-B8h]
  pa_channel_map channelMap; // [rsp+40h] [rbp-A8h] BYREF

  result = FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  if ( !*((_QWORD *)this + 419) )
  {
    v4 = (FMOD::SystemI *)*((_QWORD *)this + 9);
    dspNumBuffers = 0;
    dspBufferLength = 0;
    result = FMOD::SystemI::getDSPBufferSize(v4, &dspBufferLength, &dspNumBuffers);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v6 = dspNumBuffers;
      recordInfo->mRecordFormat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
      v7 = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
      sampleSpec.format = pa_sample_format::PA_SAMPLE_S16LE;
      recordInfo->mRecordBufferLength = dspBufferLength * v6;
      sampleSpec.rate = recordInfo->mRecordRate;
      mRecordChannels = recordInfo->mRecordChannels;
      sampleSpec.channels = mRecordChannels;
      v9 = (unsigned int)(mRecordChannels - 1);
      if ( (unsigned int)v9 <= 0xB )
        v7 = dword_597140[v9];
      result = FMOD::OutputPulseAudio::createChannelMap(this, &channelMap, v7);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v10 = (*((__int64 (__fastcall **)(_QWORD, const char *, pa_sample_spec *, pa_channel_map *))this + 341))(
                *((_QWORD *)this + 415),
                "Record Stream",
                &sampleSpec,
                &channelMap);
        *((_QWORD *)this + 421) = v10;
        if ( v10 )
        {
          v18[3] = -1;
          v18[1] = -1;
          v18[2] = -1;
          v11 = *((_QWORD *)this + 3 * recordInfo->mRecordId + 239);
          v12 = recordInfo->mRecordChannels * 2 * dspBufferLength * dspNumBuffers;
          blockLengthBytes = recordInfo->mRecordChannels * 2 * dspBufferLength;
          v18[0] = v12;
          if ( (*((int (__fastcall **)(__int64, __int64, _DWORD *, __int64))this + 352))(v10, v11, v18, 0x2000) >= 0 )
          {
            while ( 1 )
            {
              v13 = (*((__int64 (__fastcall **)(_QWORD))this + 347))(*((_QWORD *)this + 421));
              if ( (unsigned int)(v13 - 1) > 1 )
                break;
              if ( v13 == 2 )
              {
                *((_DWORD *)this + 840) = 0;
                v14 = FMOD::MemPool::calloc(
                        off_286F358->gSystemMemPool,
                        v12,
                        "../../../core_api/platforms/linux/src/fmod_output_pulseaudio.cpp",
                        891,
                        0);
                *((_QWORD *)this + 419) = v14;
                return v14 == 0 ? 0x26 : 0;
              }
            }
          }
        }
        return FMOD_RESULT::FMOD_ERR_RECORD_0;
      }
    }
  }
  return result;
}


// Address: 0x2264ff0 | Name: _ZN4FMOD16OutputPulseAudio19recordStartCallbackEP17FMOD_OUTPUT_STATEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordStartCallback(
        FMOD_OUTPUT_STATE *output,
        FMOD::FMOD_RECORDING_INFO *recordInfo)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::recordStart(p_requestreset, recordInfo);
}


// Address: 0x2265010 | Name: _ZN4FMOD16OutputPulseAudio10recordStopEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordStop(
        FMOD::OutputPulseAudio *const this,
        FMOD::FMOD_RECORDING_INFO *recordInfo)
{
  void *v2; // rsi
  __int64 v4; // rdi
  FMOD_RESULT_0 v5; // edx
  int v6; // eax

  v2 = (void *)*((_QWORD *)this + 419);
  if ( v2 )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      v2,
      "../../../core_api/platforms/linux/src/fmod_output_pulseaudio.cpp",
      911);
    *((_QWORD *)this + 419) = 0;
  }
  v4 = *((_QWORD *)this + 421);
  v5 = FMOD_RESULT::FMOD_OK_0;
  if ( v4 )
  {
    v6 = (*((__int64 (__fastcall **)(__int64, void *, _QWORD))this + 353))(v4, v2, 0);
    v5 = FMOD_RESULT::FMOD_ERR_RECORD_0;
    if ( v6 >= 0 )
    {
      (*((void (__fastcall **)(_QWORD, void *, __int64))this + 365))(*((_QWORD *)this + 421), v2, 57);
      *((_QWORD *)this + 421) = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return v5;
}


// Address: 0x2265090 | Name: _ZN4FMOD16OutputPulseAudio18recordStopCallbackEP17FMOD_OUTPUT_STATEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordStopCallback(
        FMOD_OUTPUT_STATE *output,
        FMOD::FMOD_RECORDING_INFO *recordInfo)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::recordStop(p_requestreset, recordInfo);
}


// Address: 0x22650b0 | Name: _ZN4FMOD16OutputPulseAudio17recordGetPositionEPNS_19FMOD_RECORDING_INFOEPj
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordGetPosition(
        FMOD::OutputPulseAudio *const this,
        FMOD::FMOD_RECORDING_INFO *recordInfo,
        unsigned int *pcm)
{
  unsigned int mRecordBufferLength; // r12d
  int mRecordChannels; // ebp
  int v6; // edx
  FMOD_RESULT_0 result; // eax
  int v8; // ebx
  int v9; // r12d
  __int64 v10; // rdi
  size_t bytes; // [rsp+20h] [rbp-48h] BYREF
  const void *data; // [rsp+28h] [rbp-40h] BYREF

  mRecordBufferLength = recordInfo->mRecordBufferLength;
  mRecordChannels = recordInfo->mRecordChannels;
  v6 = (*((__int64 (__fastcall **)(_QWORD))this + 358))(*((_QWORD *)this + 421));
  result = FMOD_RESULT::FMOD_ERR_OUTPUT_DRIVERCALL_0;
  if ( v6 >= 0 )
  {
    if ( v6 )
    {
      v8 = v6;
      v9 = mRecordChannels * 2 * mRecordBufferLength;
      while ( 1 )
      {
        bytes = 0;
        data = 0;
        if ( (*((int (__fastcall **)(_QWORD, const void **, size_t *))this + 355))(
               *((_QWORD *)this + 421),
               &data,
               &bytes) < 0 )
          return FMOD_RESULT::FMOD_ERR_OUTPUT_DRIVERCALL_0;
        if ( data )
        {
          v10 = *((int *)this + 840);
          if ( v9 < (int)v10 + (int)bytes )
          {
            memcpy_0((void *)(*((_QWORD *)this + 419) + v10), data, v9 - (int)v10);
            memcpy_0(*((void **)this + 419), (char *)data + v9 - (int)v10, bytes - (v9 - (int)v10));
          }
          else
          {
            memcpy_0((void *)(*((_QWORD *)this + 419) + v10), data, bytes);
          }
          *((_DWORD *)this + 840) = (bytes + *((int *)this + 840)) % v9;
        }
        if ( (*((int (__fastcall **)(_QWORD))this + 356))(*((_QWORD *)this + 421)) < 0 )
          return FMOD_RESULT::FMOD_ERR_OUTPUT_DRIVERCALL_0;
        v8 -= bytes;
        if ( !v8 )
          goto LABEL_12;
      }
    }
    else
    {
LABEL_12:
      *pcm = *((int *)this + 840) / (unsigned __int64)(2LL * recordInfo->mRecordChannels);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2265230 | Name: _ZN4FMOD16OutputPulseAudio25recordGetPositionCallbackEP17FMOD_OUTPUT_STATEPNS_19FMOD_RECORDING_INFOEPj
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordGetPositionCallback(
        FMOD_OUTPUT_STATE *output,
        FMOD::FMOD_RECORDING_INFO *recordInfo,
        unsigned int *pcm)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::recordGetPosition(p_requestreset, recordInfo, pcm);
}


// Address: 0x2265250 | Name: _ZN4FMOD16OutputPulseAudio10recordLockEPNS_19FMOD_RECORDING_INFOEjjPPvS4_PjS5_
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordLock(
        FMOD::OutputPulseAudio *const this,
        FMOD::FMOD_RECORDING_INFO *recordInfo,
        unsigned int offsetBytes,
        unsigned int lengthBytes,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  unsigned int v8; // eax

  v8 = recordInfo->mRecordChannels * 2 * recordInfo->mRecordBufferLength;
  if ( v8 > offsetBytes )
  {
    if ( lengthBytes > v8 )
      lengthBytes = recordInfo->mRecordChannels * 2 * recordInfo->mRecordBufferLength;
    *ptr1 = (void *)(*((_QWORD *)this + 419) + offsetBytes);
    if ( v8 >= lengthBytes + offsetBytes )
    {
      *len1 = lengthBytes;
      *ptr2 = 0;
      *len2 = 0;
    }
    else
    {
      *len1 = v8 - offsetBytes;
      *ptr2 = (void *)*((_QWORD *)this + 419);
      *len2 = offsetBytes - v8 + lengthBytes;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    *ptr2 = 0;
    *ptr1 = 0;
    *len2 = 0;
    *len1 = 0;
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
}


// Address: 0x2265300 | Name: _ZN4FMOD16OutputPulseAudio18recordLockCallbackEP17FMOD_OUTPUT_STATEPNS_19FMOD_RECORDING_INFOEjjPPvS6_PjS7_
FMOD_RESULT_0 __fastcall FMOD::OutputPulseAudio::recordLockCallback(
        FMOD_OUTPUT_STATE *output,
        FMOD::FMOD_RECORDING_INFO *recordInfo,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  FMOD::OutputPulseAudio *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputPulseAudio *)&output[-1].requestreset;
  return FMOD::OutputPulseAudio::recordLock(p_requestreset, recordInfo, offset, length, ptr1, ptr2, len1, len2);
}


