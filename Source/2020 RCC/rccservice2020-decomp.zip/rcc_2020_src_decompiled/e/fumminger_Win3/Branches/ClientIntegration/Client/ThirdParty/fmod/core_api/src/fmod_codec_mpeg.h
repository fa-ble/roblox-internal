// Address: 0x21d0d60 | Name: _ZN4FMOD9CodecMPEG13resetCallbackEP16FMOD_CODEC_STATE
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::resetCallback(FMOD_CODEC_STATE *codec)
{
  return FMOD::CodecMPEG::resetFrame((FMOD::CodecMPEG *const)codec);
}


