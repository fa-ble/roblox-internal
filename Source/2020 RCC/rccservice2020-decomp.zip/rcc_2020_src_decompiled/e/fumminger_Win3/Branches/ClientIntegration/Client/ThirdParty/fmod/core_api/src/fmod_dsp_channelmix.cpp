// Address: 0x21ddf20 | Name: _ZN4FMOD13DSPChannelMix16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPChannelMix::getDescriptionEx()
{
  FMOD_DSP_PARAMETER_DESC *v0; // rbx
  __int64 v1; // rcx
  _DWORD *v2; // rdi
  char *label; // rdi
  _DWORD *v4; // rdi
  unsigned int v5; // edx
  FMOD_DSP_PARAMETER_DESC *v6; // rbx
  int v7; // ebp
  __int64 v8; // rcx
  _DWORD *v9; // rdi
  char *v10; // rdi
  _DWORD *v11; // rdi
  unsigned int v12; // edx

  v0 = stru_2ADAA80;
  memset(&stru_2ADAA20, 0, sizeof(stru_2ADAA20));
  stru_2ADAA20.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2ADAA20.name, "Output Format", 16);
  FMOD_strcpy_safe(stru_2ADAA20.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2ADAA20.floatdesc.min = 0x700000000LL;
  stru_2ADAA20.description = "Output Format.";
  *(_OWORD *)(&stru_2ADAA20.datadesc + 2) = 0u;
  do
  {
    v4 = v0;
    v5 = 96;
    if ( ((unsigned __int8)v0 & 1) != 0 )
    {
      v4 = (_DWORD *)((char *)&v0->type + 1);
      LOBYTE(v0->type) = 0;
      LOBYTE(v5) = 95;
      if ( (((_BYTE)v0 + 1) & 2) != 0 )
      {
LABEL_13:
        v4 = (_DWORD *)((char *)v4 + 2);
        v5 -= 2;
        *((_WORD *)v4 - 1) = 0;
        if ( ((unsigned __int8)v4 & 4) == 0 )
          goto LABEL_4;
        goto LABEL_14;
      }
    }
    else if ( ((unsigned __int8)v0 & 2) != 0 )
    {
      goto LABEL_13;
    }
    if ( ((unsigned __int8)v4 & 4) == 0 )
      goto LABEL_4;
LABEL_14:
    *v4 = 0;
    v5 -= 4;
    ++v4;
LABEL_4:
    v1 = v5 >> 3;
    memset(v4, 0, 8 * v1);
    v2 = &v4[2 * v1];
    if ( (v5 & 4) != 0 )
      *v2++ = 0;
    if ( (v5 & 2) != 0 )
    {
      v2 = (_DWORD *)((char *)v2 + 2);
      *((_WORD *)v2 - 1) = 0;
    }
    if ( (v5 & 1) != 0 )
      *(_BYTE *)v2 = 0;
    v0->type = FMOD_DSP_PARAMETER_TYPE_FLOAT;
    FMOD_strcpy_safe(v0->name, "Channel Gain", 16);
    label = v0->label;
    ++v0;
    FMOD_strcpy_safe(label, "dB", 16);
    v0[-1].intdesc.min = -1029701632;
    v0[-1].intdesc.max = 1092616192;
    v0[-1].intdesc.defaultval = 0;
    v0[-1].floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
    v0[-1].description = "Channel Gain.";
  }
  while ( v0 != (FMOD_DSP_PARAMETER_DESC *)&stru_2ADB680 );
  v6 = stru_2AD9E20;
  v7 = 0;
  do
  {
    v11 = v6;
    v12 = 96;
    if ( ((unsigned __int8)v6 & 1) != 0 )
    {
      v11 = (_DWORD *)((char *)&v6->type + 1);
      LOBYTE(v6->type) = 0;
      LOBYTE(v12) = 95;
      if ( (((_BYTE)v6 + 1) & 2) != 0 )
      {
LABEL_27:
        v11 = (_DWORD *)((char *)v11 + 2);
        v12 -= 2;
        *((_WORD *)v11 - 1) = 0;
        if ( ((unsigned __int8)v11 & 4) == 0 )
          goto LABEL_18;
        goto LABEL_28;
      }
    }
    else if ( ((unsigned __int8)v6 & 2) != 0 )
    {
      goto LABEL_27;
    }
    if ( ((unsigned __int8)v11 & 4) == 0 )
      goto LABEL_18;
LABEL_28:
    *v11 = 0;
    v12 -= 4;
    ++v11;
LABEL_18:
    v8 = v12 >> 3;
    memset(v11, 0, 8 * v8);
    v9 = &v11[2 * v8];
    if ( (v12 & 4) != 0 )
      *v9++ = 0;
    if ( (v12 & 2) != 0 )
    {
      v9 = (_DWORD *)((char *)v9 + 2);
      *((_WORD *)v9 - 1) = 0;
    }
    if ( (v12 & 1) != 0 )
      *(_BYTE *)v9 = 0;
    v6->type = FMOD_DSP_PARAMETER_TYPE_INT;
    FMOD_strcpy_safe(v6->name, "Channel Mapping", 16);
    v10 = v6->label;
    ++v6;
    FMOD_strcpy_safe(v10, (const char *)&uri_string, 16);
    v6[-1].intdesc.defaultval = v7++;
    v6[-1].intdesc.min = 0;
    v6[-1].intdesc.max = 31;
    v6[-1].description = "Channel Mapping.";
    v6[-1].intdesc.goestoinf = 0;
    v6[-1].intdesc.valuenames = 0;
  }
  while ( v7 != 32 );
  *(&stru_2AD9DE0.mHandle + 1) = 33;
  stru_2AD9DE0.mSize = 9424;
  stru_2AD9DE0.mDescription = &stru_286AD80;
  stru_2AD9DE0.mCommand = FMOD::DSPChannelMix::commandCallback;
  stru_2AD9DE0.mCommandMask = 1;
  return &stru_2AD9DE0;
}


// Address: 0x21de240 | Name: _ZN4FMOD13DSPChannelMix14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::createInternal(FMOD::DSPChannelMix *const this)
{
  double v1; // xmm1_8
  __int64 v2; // rax
  __int64 v3; // rax
  __int64 v4; // rbp
  int i; // r12d
  _DWORD *v6; // rdx
  _DWORD *v7; // rdx
  FMOD_RESULT_0 result; // eax

  v2 = 0;
  *((_WORD *)this + 46) |= 0x20u;
  *((_BYTE *)this + 9152) = 0;
  *((_DWORD *)this + 2289) = 0;
  do
  {
    *(_DWORD *)((char *)this + v2 + 9160) = 1065353216;
    *(_DWORD *)((char *)this + v2 + 832) = 1065353216;
    v2 += 4;
  }
  while ( v2 != 128 );
  v3 = *((_QWORD *)this + 30);
  v4 = 0;
  for ( i = 0; *(_DWORD *)(v3 + 96) > i; v4 += 8 )
  {
    while ( 1 )
    {
      v6 = *(_DWORD **)(*(_QWORD *)(v3 + 104) + v4);
      if ( *v6 == 1 )
      {
        result = FMOD::DSPI::setParameterInt((FMOD::DSPI *const)this, i, v6[14]);
        if ( result )
          return result;
        v3 = *((_QWORD *)this + 30);
      }
      v7 = *(_DWORD **)(*(_QWORD *)(v3 + 104) + v4);
      if ( !*v7 )
        break;
      ++i;
      v4 += 8;
      if ( *(_DWORD *)(v3 + 96) <= i )
        goto LABEL_10;
    }
    result = FMOD::DSPI::setParameterFloat((FMOD::DSPI *const)this, i, (__m128i)(unsigned int)v7[14], v1);
    if ( result )
      return result;
    v3 = *((_QWORD *)this + 30);
    ++i;
  }
LABEL_10:
  FMOD::DSPConnectionI::init(
    (FMOD::DSPConnectionI *const)((char *)this + 536),
    *((FMOD::SystemI **)this + 22),
    1.0,
    *(float *)&v1);
  *((_DWORD *)this + 165) |= 0x10u;
  *((_QWORD *)this + 24) = FMOD::FMOD_DSPConnectionI_Mix;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21de350 | Name: _ZN4FMOD13DSPChannelMix14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPChannelMix::createInternal((FMOD::DSPChannelMix *const)dsp_state->instance);
}


// Address: 0x21de360 | Name: _ZN4FMOD13DSPChannelMix13resetInternalEb
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::resetInternal(FMOD::DSPChannelMix *const this, bool hardreset)
{
  FMOD::DSPConnectionI::reset((FMOD::DSPConnectionI *const)((char *)this + 536), hardreset, 1);
  *((_DWORD *)this + 165) |= 0x10u;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21de390 | Name: _ZN4FMOD13DSPChannelMix13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPChannelMix::resetInternal((FMOD::DSPChannelMix *const)dsp_state->instance, 0);
}


// Address: 0x21de3a0 | Name: _ZN4FMOD13DSPChannelMix15processInternalEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::processInternal(
        FMOD::DSPChannelMix *const this,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  int *buffernumchannels; // rsi
  FMOD_SPEAKERMODE_0 speakermode; // edi
  FMOD_SPEAKERMODE_0 v10; // r10d
  int v11; // r12d
  float **buffers; // rax
  int v13; // ebp
  float *v14; // r15
  float **v15; // rax
  float *v16; // r11
  FMOD_RESULT_0 (__fastcall *v17)(char *, float *, float *, _QWORD, _QWORD, _QWORD, int); // r13
  bool v18; // zf
  __int64 v19; // r10
  int v20; // eax
  __int64 v21; // rcx
  float v22; // xmm0_4
  char *v23; // r10
  unsigned int v25; // eax
  unsigned __int64 v26; // rax
  float *outbuffer; // [rsp+18h] [rbp-1040h]
  float matrix[1038]; // [rsp+20h] [rbp-1038h] BYREF

  buffernumchannels = outbufferarray->buffernumchannels;
  speakermode = inbufferarray->speakermode;
  v10 = outbufferarray->speakermode;
  v11 = *inbufferarray->buffernumchannels;
  buffers = inbufferarray->buffers;
  v13 = *buffernumchannels;
  if ( buffers )
  {
    v14 = *buffers;
    v15 = outbufferarray->buffers;
    if ( v15 )
    {
LABEL_3:
      v16 = *v15;
      goto LABEL_4;
    }
  }
  else
  {
    v15 = outbufferarray->buffers;
    v14 = 0;
    if ( v15 )
      goto LABEL_3;
  }
  v16 = 0;
LABEL_4:
  v17 = (FMOD_RESULT_0 (__fastcall *)(char *, float *, float *, _QWORD, _QWORD, _QWORD, int))*((_QWORD *)this + 24);
  if ( op == FMOD_DSP_PROCESS_QUERY )
  {
    v25 = *((_DWORD *)this + 114) & 0xFFFFFFEF;
    *((_DWORD *)this + 114) = v25;
    if ( inputsidle )
    {
      if ( *((float *)this + 160) != *((float *)this + 166) )
        *((_DWORD *)this + 114) = v25 | 0x10;
      return FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
    }
    else
    {
      switch ( *((_DWORD *)this + 132) )
      {
        case 0:
          break;
        case 1:
          v11 = 1;
          speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0;
          break;
        case 2:
          v11 = 2;
          speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0;
          break;
        case 3:
          v11 = 4;
          speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_QUAD_0;
          break;
        case 4:
        case 6:
          v11 = 6;
          speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_5POINT1_0;
          break;
        case 5:
          v11 = 8;
          speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0;
          break;
        case 7:
          v11 = 12;
          speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0;
          break;
        default:
          v11 = v13;
          speakermode = v10;
          break;
      }
      *buffernumchannels = v11;
      outbufferarray->speakermode = speakermode;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  else
  {
    if ( *((_QWORD *)this + 75) && *((_DWORD *)this + 2289) != v11
      || (v23 = (char *)this + 536, *((_BYTE *)this + 9152)) )
    {
      *((_WORD *)this + 296) = v11;
      *((_WORD *)this + 297) = v13;
      *((_QWORD *)this + 75) = (char *)this + 960;
      *((_WORD *)this + 304) = v11;
      *((_WORD *)this + 305) = v13;
      *((_QWORD *)this + 77) = (char *)this + 5056;
      v18 = *((_DWORD *)this + 132) == 6;
      memset(matrix, 0, 0x1000u);
      if ( v18 )
      {
        if ( v11 > 0 )
        {
          v26 = 0;
          do
          {
            matrix[v26 / 4 + 96] = *(float *)((char *)this + v26 + 832);
            v26 += 4LL;
          }
          while ( v26 != 4LL * (unsigned int)(v11 - 1) + 4 );
        }
      }
      else if ( v11 > 0 )
      {
        v19 = 0;
        do
        {
          v20 = *((_DWORD *)this + v19 + 176);
          v21 = (int)v19;
          v22 = *((float *)this + v19++ + 208);
          matrix[32 * (v20 % v13) + v21] = v22;
        }
        while ( v19 != (unsigned int)(v11 - 1) + 1LL );
      }
      outbuffer = v16;
      FMOD::DSPMatrix::set((FMOD::DSPMatrix *const)this + 37, matrix, v13, v11, 32);
      FMOD::DSPConnectionI::rampTo((FMOD::DSPConnectionI *const)((char *)this + 536), 0x40u);
      v23 = (char *)this + 536;
      v16 = outbuffer;
      *((_BYTE *)this + 9152) = 0;
    }
    *((_DWORD *)this + 2289) = v11;
    return v17(v23, v16, v14, (unsigned int)v13, (unsigned int)v11, length, 1);
  }
}


// Address: 0x21de690 | Name: _ZN4FMOD13DSPChannelMix15processCallbackEP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS3_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::processCallback(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  return FMOD::DSPChannelMix::processInternal(
           (FMOD::DSPChannelMix *const)dsp_state->instance,
           length,
           inbufferarray,
           outbufferarray,
           inputsidle,
           op);
}


// Address: 0x21de6a0 | Name: _ZN4FMOD13DSPChannelMix15commandInternalEj
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::commandInternal(
        FMOD::DSPChannelMix *const this,
        FMOD::FMOD_DSP_COMMAND_TYPE type)
{
  int v3; // eax
  float *v4; // rbx
  int v5; // eax
  float v6; // xmm1_4
  float v7; // xmm0_4

  if ( type != 1 )
    return FMOD_RESULT::FMOD_OK_0;
  v3 = *((_DWORD *)this + 2322);
  if ( *((_DWORD *)this + 132) != v3 )
  {
    *((_DWORD *)this + 132) = v3;
    *((_BYTE *)this + 9152) = 1;
  }
  v4 = (float *)((char *)this + 704);
  do
  {
    v6 = v4[2114];
    v7 = 0.0;
    if ( v6 > -80.0 )
      v7 = powf(10.0, v6 / 20.0);
    if ( v7 != v4[32] )
    {
      v4[32] = v7;
      *((_BYTE *)this + 9152) = 1;
    }
    v5 = *((_DWORD *)v4 + 2147);
    if ( *(_DWORD *)v4 != v5 )
    {
      *(_DWORD *)v4 = v5;
      *((_BYTE *)this + 9152) = 1;
    }
    ++v4;
  }
  while ( v4 != (float *)((char *)this + 832) );
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21de780 | Name: _ZN4FMOD13DSPChannelMix15commandCallbackEP14FMOD_DSP_STATEjPvS3_
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::commandCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *commanddata1,
        void *commanddata2)
{
  return FMOD::DSPChannelMix::commandInternal((FMOD::DSPChannelMix *const)dsp_state->instance, type);
}


// Address: 0x21de790 | Name: _ZN4FMOD13DSPChannelMix25setParameterFloatInternalEif
char __fastcall FMOD::DSPChannelMix::setParameterFloatInternal(
        FMOD::DSPChannelMix *const this,
        int index,
        float a3,
        float value)
{
  unsigned int v4; // esi
  char result; // al

  v4 = index - 1;
  result = 31;
  if ( v4 <= 0x1F )
  {
    *((float *)this + (int)v4 + 2290) = a3;
    return 0;
  }
  return result;
}


// Address: 0x21de7b0 | Name: _ZN4FMOD13DSPChannelMix25setParameterFloatCallbackEP14FMOD_DSP_STATEif
char __fastcall FMOD::DSPChannelMix::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPChannelMix::setParameterFloatInternal(
           (FMOD::DSPChannelMix *const)dsp_state->instance,
           index,
           a3,
           value);
}


// Address: 0x21de7c0 | Name: _ZN4FMOD13DSPChannelMix25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::getParameterFloatInternal(
        FMOD::DSPChannelMix *const this,
        int index,
        float *value,
        char *valuestr)
{
  unsigned int v4; // esi
  FMOD_RESULT_0 v5; // ebx
  float *v7; // rax

  v4 = index - 1;
  v5 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( v4 > 0x1F )
    return v5;
  LOBYTE(v5) = 0;
  v7 = (float *)((char *)this + 4 * (int)v4);
  *value = v7[2290];
  if ( !valuestr )
    return v5;
  sprintf(valuestr, "%.02f", v7[2290]);
  return v5;
}


// Address: 0x21de820 | Name: _ZN4FMOD13DSPChannelMix25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPChannelMix::getParameterFloatInternal(
           (FMOD::DSPChannelMix *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x21de830 | Name: _ZN4FMOD13DSPChannelMix23setParameterIntInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::setParameterIntInternal(
        FMOD::DSPChannelMix *const this,
        int index,
        int value)
{
  if ( (unsigned int)(index - 33) <= 0x1F )
  {
    *((_DWORD *)this + index + 2290) = value;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else if ( index )
  {
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  else
  {
    *((_DWORD *)this + 2322) = value;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21de870 | Name: _ZN4FMOD13DSPChannelMix23setParameterIntCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::setParameterIntCallback(FMOD_DSP_STATE *dsp_state, int index, int value)
{
  return FMOD::DSPChannelMix::setParameterIntInternal((FMOD::DSPChannelMix *const)dsp_state->instance, index, value);
}


// Address: 0x21de880 | Name: _ZN4FMOD13DSPChannelMix23getParameterIntInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::getParameterIntInternal(
        FMOD::DSPChannelMix *const this,
        int index,
        int *value,
        char *valuestr)
{
  char *v4; // rax
  FMOD_RESULT_0 result; // eax

  if ( (unsigned int)(index - 33) <= 0x1F )
  {
    v4 = (char *)this + 4 * index - 132;
    *value = *((_DWORD *)v4 + 2323);
    if ( valuestr )
    {
      sprintf(valuestr, "%d", *((_DWORD *)v4 + 2323));
      return FMOD_RESULT::FMOD_OK_0;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !index )
  {
    *value = *((_DWORD *)this + 2322);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21dea00 | Name: _ZN4FMOD13DSPChannelMix23getParameterIntCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPChannelMix::getParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int *value,
        char *valuestr)
{
  return FMOD::DSPChannelMix::getParameterIntInternal(
           (FMOD::DSPChannelMix *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


