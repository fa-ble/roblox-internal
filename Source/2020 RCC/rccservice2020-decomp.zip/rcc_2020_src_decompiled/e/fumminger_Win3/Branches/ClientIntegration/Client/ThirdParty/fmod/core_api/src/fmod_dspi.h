// Address: 0x21b60a0 | Name: _ZN4FMOD4DSPI19getPositionInternalEP14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::DSPI::getPositionInternal(FMOD::DSPI *const this, FMOD_UINT32_32 *pcm)
{
  return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
}


// Address: 0x21b68e0 | Name: _ZN4FMOD4DSPI9setBypassEb
FMOD_RESULT_0 __fastcall FMOD::DSPI::setBypass(FMOD::DSPI *const this, bool bypass)
{
  unsigned __int16 mFlags; // ax

  mFlags = this->mJob.mFlags;
  if ( bypass != (mFlags & 1) )
    *(_DWORD *)(*(unsigned __int64 *)((char *)&stru_10788.r_offset + (unsigned __int64)this->mSystem) + 48) = 1;
  if ( bypass )
    this->mJob.mFlags = mFlags | 1;
  else
    this->mJob.mFlags = mFlags & 0xFFFE;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c6ac0 | Name: _ZN4FMOD4DSPI11memoryAllocEjjPKc
void *__fastcall FMOD::DSPI::memoryAlloc(unsigned int size, FMOD_MEMORY_TYPE type, const char *sourcestr)
{
  return FMOD::MemPool::alloc(off_286F358->gSystemMemPool, size, sourcestr, 0, type | 0x10, 1);
}


// Address: 0x21c6af0 | Name: _ZN4FMOD4DSPI10memoryFreeEPvjPKc
void __fastcall FMOD::DSPI::memoryFree(void *ptr, FMOD_MEMORY_TYPE a2, const char *sourcestr)
{
  FMOD::MemPool::free(off_286F358->gSystemMemPool, ptr, sourcestr, 0);
}


// Address: 0x21c6b10 | Name: _ZN4FMOD4DSPI13memoryReallocEPvjjPKc
void *__fastcall FMOD::DSPI::memoryRealloc(void *ptr, unsigned int size, FMOD_MEMORY_TYPE type, const char *sourcestr)
{
  return FMOD::MemPool::realloc(off_286F358->gSystemMemPool, ptr, size, sourcestr, 0, type | 0x10);
}


// Address: 0x22200f0 | Name: _ZN4FMOD13PluginFactoryC2Ev
void __fastcall FMOD::PluginFactory::PluginFactory(FMOD::PluginFactory *const this)
{
  FMOD::LinkedListNode *p_mPluginFactoryNode; // r11
  FMOD::LinkedListNode *p_mMixCallbackNode; // r10
  FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *p_mCodecHead; // r9
  FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN *p_mOutputHead; // r8
  FMOD::PluginFactory *v5; // rdx
  unsigned int v6; // esi
  __int64 v7; // rcx
  char *v8; // rdi
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **mBuiltInDSPs; // rdi
  unsigned int v10; // esi
  __int64 v11; // rcx
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **v12; // rdi

  p_mPluginFactoryNode = &this->mDSPHead.mPluginFactoryNode;
  p_mMixCallbackNode = &this->mDSPHead.mMixCallbackNode;
  p_mCodecHead = &this->mCodecHead;
  p_mOutputHead = &this->mOutputHead;
  v5 = this;
  this->mDSPHead.mPluginFactoryNode.mNodeData = 0;
  this->mDSPHead.mPluginFactoryNode.mNodePrev = &this->mDSPHead.mPluginFactoryNode;
  this->mDSPHead.mPluginFactoryNode.mNodeNext = &this->mDSPHead.mPluginFactoryNode;
  this->mDSPHead.mMixCallbackNode.mNodePrev = &this->mDSPHead.mMixCallbackNode;
  this->mDSPHead.mMixCallbackNode.mNodeNext = &this->mDSPHead.mMixCallbackNode;
  v6 = 256;
  this->mDSPHead.mMixCallbackNode.mNodeData = 0;
  this->mCodecHead.mNodePrev = &this->mCodecHead;
  this->mCodecHead.mNodeNext = &this->mCodecHead;
  this->mCodecHead.mNodeData = 0;
  this->mCodecHead.mNodePriority = -1;
  this->mOutputHead.mNodePrev = &this->mOutputHead;
  this->mOutputHead.mNodeNext = &this->mOutputHead;
  this->mOutputHead.mNodeData = 0;
  this->mSystem = 0;
  this->mCurrentPluginHandle = 1;
  if ( ((unsigned __int8)this & 1) == 0 )
  {
    if ( ((unsigned __int8)this & 2) == 0 )
      goto LABEL_3;
LABEL_21:
    this = (FMOD::PluginFactory *const)((char *)this + 2);
    v6 -= 2;
    *((_WORD *)this - 1) = 0;
    if ( ((unsigned __int8)this & 4) == 0 )
      goto LABEL_4;
    goto LABEL_22;
  }
  this = (FMOD::PluginFactory *const)((char *)this + 1);
  v5->mPluginPath[0] = 0;
  LOWORD(v6) = 255;
  if ( (((_BYTE)v5 + 1) & 2) != 0 )
    goto LABEL_21;
LABEL_3:
  if ( ((unsigned __int8)this & 4) == 0 )
    goto LABEL_4;
LABEL_22:
  *(_DWORD *)this->mPluginPath = 0;
  v6 -= 4;
  this = (FMOD::PluginFactory *const)((char *)this + 4);
LABEL_4:
  v7 = v6 >> 3;
  memset(this, 0, 8 * v7);
  v8 = &this->mPluginPath[8 * v7];
  if ( (v6 & 4) != 0 )
  {
    *(_DWORD *)v8 = 0;
    v8 += 4;
  }
  if ( (v6 & 2) != 0 )
  {
    v8 += 2;
    *((_WORD *)v8 - 1) = 0;
  }
  if ( (v6 & 1) != 0 )
    *v8 = 0;
  mBuiltInDSPs = v5->mBuiltInDSPs;
  v10 = 296;
  if ( (((_BYTE)v5 - 72) & 1) == 0 )
  {
    if ( (((_BYTE)v5 - 72) & 2) == 0 )
      goto LABEL_12;
LABEL_24:
    mBuiltInDSPs = (FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **)((char *)mBuiltInDSPs + 2);
    v10 -= 2;
    *((_WORD *)mBuiltInDSPs - 1) = 0;
    if ( ((unsigned __int8)mBuiltInDSPs & 4) == 0 )
      goto LABEL_13;
    goto LABEL_25;
  }
  mBuiltInDSPs = (FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **)((char *)v5->mBuiltInDSPs + 1);
  LOBYTE(v5->mBuiltInDSPs[0]) = 0;
  LOBYTE(v10) = 39;
  if ( (((_BYTE)v5 - 71) & 2) != 0 )
    goto LABEL_24;
LABEL_12:
  if ( ((unsigned __int8)mBuiltInDSPs & 4) == 0 )
    goto LABEL_13;
LABEL_25:
  *(_DWORD *)mBuiltInDSPs = 0;
  v10 -= 4;
  mBuiltInDSPs = (FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **)((char *)mBuiltInDSPs + 4);
LABEL_13:
  v11 = v10 >> 3;
  memset(mBuiltInDSPs, 0, 8 * v11);
  v12 = &mBuiltInDSPs[v11];
  if ( (v10 & 4) != 0 )
  {
    *(_DWORD *)v12 = 0;
    v12 = (FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **)((char *)v12 + 4);
  }
  if ( (v10 & 2) != 0 )
  {
    v12 = (FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **)((char *)v12 + 2);
    *((_WORD *)v12 - 1) = 0;
  }
  if ( (v10 & 1) != 0 )
    *(_BYTE *)v12 = 0;
  v5->mDSPHead.mPluginFactoryNode.mNodePrev = p_mPluginFactoryNode;
  v5->mDSPHead.mPluginFactoryNode.mNodeNext = p_mPluginFactoryNode;
  v5->mDSPHead.mPluginFactoryNode.mNodeData = 0;
  v5->mDSPHead.mMixCallbackNode.mNodePrev = p_mMixCallbackNode;
  v5->mDSPHead.mMixCallbackNode.mNodeNext = p_mMixCallbackNode;
  v5->mDSPHead.mMixCallbackNode.mNodeData = 0;
  v5->mCodecHead.mNodePriority = -1;
  v5->mCodecHead.mNodeNext = p_mCodecHead;
  v5->mCodecHead.mNodePrev = p_mCodecHead;
  v5->mCodecHead.mNodeData = 0;
  v5->mOutputHead.mNodePrev = p_mOutputHead;
  v5->mOutputHead.mNodeNext = p_mOutputHead;
  v5->mOutputHead.mNodeData = 0;
}


