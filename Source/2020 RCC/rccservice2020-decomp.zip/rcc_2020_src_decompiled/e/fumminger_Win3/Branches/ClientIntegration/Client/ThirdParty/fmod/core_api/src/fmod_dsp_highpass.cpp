// Address: 0x2209c50 | Name: _ZN4FMOD11DSPHighPass16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPHighPass::getDescriptionEx()
{
  memset(&stru_2AF6C00, 0, sizeof(stru_2AF6C00));
  FMOD_strcpy_safe(stru_2AF6C00.name, "Cutoff freq", 16);
  FMOD_strcpy_safe(stru_2AF6C00.label, "hz", 16);
  *(_QWORD *)&stru_2AF6C00.floatdesc.min = 0x46ABE00041200000LL;
  stru_2AF6C00.description = "Highpass cutoff frequency in hz.   10.0 to 22000.0.  Default = 5000.0.";
  memset(&stru_2AF6BA0, 0, sizeof(stru_2AF6BA0));
  stru_2AF6C00.intdesc.defaultval = 1167867904;
  stru_2AF6C00.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF6BA0.name, "Resonance", 16);
  FMOD_strcpy_safe(stru_2AF6BA0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF6BA0.floatdesc.min = 0x412000003F800000LL;
  stru_2AF6BA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AF6BA0.description = "Highpass resonance Q value. 1.0 to 10.0.  Default = 1.0.";
  stru_2AF6BA0.intdesc.defaultval = 1065353216;
  *(&stru_2AF6B60.mHandle + 1) = 5;
  stru_2AF6B60.mDescription = &stru_286C4E0;
  stru_2AF6B60.mSize = 1088;
  return &stru_2AF6B60;
}


// Address: 0x2209d80 | Name: _ZN4FMOD11DSPHighPass13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPHighPass::resetInternal(FMOD::DSPHighPass *const this)
{
  _DWORD *v1; // rdi
  int v2; // eax

  v1 = (_DWORD *)((char *)this + 668);
  v2 = 32;
  do
  {
    *v1 = 0;
    *(v1 - 32) = 0;
    ++v1;
    v1[63] = 0;
    v1[31] = 0;
    --v2;
  }
  while ( v2 );
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2209dc0 | Name: _ZN4FMOD11DSPHighPass13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPHighPass::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPHighPass::resetInternal((FMOD::DSPHighPass *const)dsp_state->instance);
}


// Address: 0x2209dd0 | Name: _ZN4FMOD11DSPHighPass18updateCoefficientsEff
__int64 __fastcall FMOD::DSPHighPass::updateCoefficients(
        FMOD::DSPHighPass *const this,
        float a2,
        float resonance,
        float cutoff)
{
  float v5; // xmm1_4
  float v6; // xmm5_4
  float cosx; // [rsp+8h] [rbp-10h] BYREF
  float sinx[3]; // [rsp+Ch] [rbp-Ch] BYREF

  sincosf((float)(resonance * 6.2831855) / (float)*(int *)(*((_QWORD *)this + 22) + 1696LL), sinx, &cosx);
  v5 = sinx[0] / (float)(a2 + a2);
  v6 = cosx + 1.0;
  *((float *)this + 264) = cosx * -2.0;
  *((float *)this + 266) = 0.5 * v6;
  *((float *)this + 267) = -v6;
  *((float *)this + 268) = 0.5 * v6;
  *((float *)this + 263) = v5 + 1.0;
  *((float *)this + 265) = 1.0 - v5;
  return 0;
}


// Address: 0x2209ea0 | Name: _ZN4FMOD11DSPHighPass14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPHighPass::createInternal(FMOD::DSPHighPass *const this)
{
  double v1; // xmm1_8
  float v2; // xmm2_4
  __int64 v3; // rbp
  int v4; // ebx
  __int64 v5; // rax
  int v6; // edx
  FMOD_RESULT_0 result; // eax
  float v8; // xmm0_4
  float v9; // xmm1_4

  v3 = 0;
  v4 = 0;
  v5 = *((_QWORD *)this + 30);
  v6 = *(_DWORD *)(v5 + 96);
  *((float *)this + 133) = (float)((float)*(int *)(*((_QWORD *)this + 22) + 1696LL) * 0.5) - 10.0;
  if ( v6 > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v4,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v5 + 104) + v3) + 56LL),
                 v1);
      if ( result )
        break;
      v5 = *((_QWORD *)this + 30);
      ++v4;
      v3 += 8;
      if ( *(_DWORD *)(v5 + 96) <= v4 )
        goto LABEL_6;
    }
  }
  else
  {
LABEL_6:
    FMOD::DSPHighPass::resetInternal(this);
    v8 = *((float *)this + 270);
    v9 = *((float *)this + 269);
    *((float *)this + 134) = v8;
    *((float *)this + 132) = v9;
    FMOD::DSPHighPass::updateCoefficients(this, v8, v9, v2);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2209f60 | Name: _ZN4FMOD11DSPHighPass14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPHighPass::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPHighPass::createInternal((FMOD::DSPHighPass *const)dsp_state->instance);
}


// Address: 0x2209f70 | Name: _ZN4FMOD11DSPHighPass7processEPfS1_ji
FMOD_RESULT_0 __fastcall FMOD::DSPHighPass::process(
        FMOD::DSPHighPass *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int channels)
{
  __m128 v5; // xmm5
  float *v6; // rax
  unsigned int i; // ebx
  unsigned int v8; // r10d
  int v9; // r9d
  __int64 v10; // r11
  float v11; // xmm3_4
  float v12; // xmm4_4
  float v13; // xmm2_4
  float v14; // xmm0_4
  __m128 v16; // xmm2
  __int64 v17; // rax
  float v18; // xmm4_4
  float v19; // xmm5_4
  float v20; // xmm0_4
  float v21; // xmm1_4
  float v22; // xmm3_4
  float v23; // xmm0_4
  float v24; // xmm1_4
  float v25; // xmm0_4
  float v26; // xmm1_4
  float v27; // xmm0_4
  __m128 v28; // xmm2
  int v29; // eax
  __int64 v30; // r10
  float v31; // xmm0_4
  __int64 v32; // r9
  float v33; // xmm7_4
  float v34; // xmm8_4
  float v35; // xmm12_4
  float v36; // xmm11_4
  float v37; // xmm5_4
  float v38; // xmm4_4
  float v39; // xmm6_4
  float v40; // xmm1_4
  float v41; // xmm3_4
  float v42; // xmm10_4
  float v43; // xmm9_4
  float v44; // xmm13_4
  float v45; // xmm12_4
  float v46; // xmm1_4
  float v47; // xmm3_4
  float v48; // xmm10_4
  float v49; // xmm1_4
  float v50; // xmm3_4
  float v51; // xmm1_4
  float v52; // xmm0_4
  __m128 v53; // xmm11
  unsigned int v54; // eax
  __int64 v55; // rbp
  __int64 v56; // r12
  __int64 v57; // rbx
  __int64 v58; // r11
  __int64 v59; // r10
  __int64 v60; // r9
  float v61; // xmm15_4
  float v62; // xmm1_4
  float v63; // xmm9_4
  float v64; // xmm8_4
  float v65; // xmm6_4
  float v66; // xmm14_4
  float v67; // xmm7_4
  float v68; // xmm13_4
  float v69; // xmm0_4
  float v70; // xmm5_4
  float v71; // xmm12_4
  float v72; // xmm4_4
  float v73; // xmm3_4
  float v74; // xmm10_4
  float v75; // xmm2_4
  float v76; // xmm1_4
  int v77; // xmm6_4
  int v78; // xmm6_4
  int v79; // xmm6_4
  float v80; // xmm1_4
  int v81; // xmm7_4
  int v82; // xmm6_4
  int v83; // xmm7_4
  int v84; // xmm6_4
  __m128 v85; // xmm13
  unsigned int v86; // eax
  int v87; // r8d
  __int64 v88; // r13
  __int64 v89; // rbp
  __int64 v90; // r14
  __int64 v91; // r12
  __int64 v92; // r11
  __int64 v93; // rbx
  __int64 v94; // r9
  __int64 v95; // r10
  float v96; // xmm7_4
  float v97; // xmm15_4
  float v98; // xmm0_4
  float v99; // xmm9_4
  float v100; // xmm8_4
  float v101; // xmm7_4
  float v102; // xmm5_4
  float v103; // xmm6_4
  float v104; // xmm14_4
  float v105; // xmm12_4
  float v106; // xmm11_4
  float v107; // xmm4_4
  float v108; // xmm3_4
  float v109; // xmm2_4
  float v110; // xmm10_4
  float v111; // xmm1_4
  float v112; // xmm0_4
  int v113; // xmm5_4
  int v114; // xmm5_4
  int v115; // xmm5_4
  int v116; // xmm5_4
  int v117; // xmm6_4
  int v118; // xmm7_4
  int v119; // xmm7_4
  int v120; // xmm7_4
  float v121; // [rsp+0h] [rbp-54h]
  float v122; // [rsp+0h] [rbp-54h]
  float v123; // [rsp+4h] [rbp-50h]
  float v124; // [rsp+4h] [rbp-50h]
  float v125; // [rsp+8h] [rbp-4Ch]
  float v126; // [rsp+8h] [rbp-4Ch]
  float v127; // [rsp+1Ch] [rbp-38h]
  float v128; // [rsp+20h] [rbp-34h]
  float v129; // [rsp+24h] [rbp-30h]
  float v130; // [rsp+28h] [rbp-2Ch]

  if ( channels == 1 )
  {
    if ( !length )
      return FMOD_RESULT::FMOD_OK_0;
    v16 = (__m128)LODWORD(flt_286C4C0);
    v17 = 0;
    do
    {
      v18 = inbuffer[v17] + v16.m128_f32[0];
      v19 = *((float *)this + 135);
      v20 = *((float *)this + 266);
      v16 = _mm_xor_ps(v16, (__m128)0x80000000);
      v21 = *((float *)this + 267) * v19;
      v22 = *((float *)this + 199);
      *((float *)this + 135) = v18;
      v23 = (float)(v20 * v18) + v21;
      v24 = *((float *)this + 268) * *((float *)this + 167);
      *((float *)this + 167) = v19;
      v25 = (float)(v23 + v24) - (float)(*((float *)this + 264) * v22);
      v26 = *((float *)this + 265) * *((float *)this + 231);
      *((float *)this + 231) = v22;
      v27 = (float)(v25 - v26) / *((float *)this + 263);
      *((float *)this + 199) = v27;
      outbuffer[v17++] = v27;
    }
    while ( length > (unsigned int)v17 );
    flt_286C4C0 = v16.m128_f32[0];
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( channels == 2 )
  {
    if ( !length )
      return FMOD_RESULT::FMOD_OK_0;
    v28 = (__m128)LODWORD(flt_286C4C0);
    LOBYTE(channels) = 1;
    v29 = 0;
    do
    {
      v30 = (unsigned int)(2 * v29);
      v31 = *((float *)this + 266);
      v32 = (unsigned int)channels;
      ++v29;
      v33 = inbuffer[v30] + v28.m128_f32[0];
      channels += 2;
      v34 = *((float *)this + 135);
      v35 = *((float *)this + 268);
      v36 = *((float *)this + 264);
      v37 = inbuffer[v32] + v28.m128_f32[0];
      v38 = *((float *)this + 199);
      v39 = *((float *)this + 136);
      v28 = _mm_xor_ps(v28, (__m128)0x80000000);
      v40 = (float)(v31 * v33) + (float)(*((float *)this + 267) * v34);
      v41 = *((float *)this + 167) * v35;
      v42 = *((float *)this + 265);
      v43 = *((float *)this + 263);
      v44 = *((float *)this + 267) * v39;
      *((float *)this + 167) = v34;
      v45 = v35 * *((float *)this + 168);
      *((float *)this + 135) = v33;
      *((float *)this + 168) = v39;
      *((float *)this + 136) = v37;
      v46 = (float)(v40 + v41) - (float)(v36 * v38);
      v47 = *((float *)this + 231) * v42;
      *((float *)this + 231) = v38;
      v48 = v42 * *((float *)this + 232);
      v49 = v46 - v47;
      v50 = *((float *)this + 200);
      *((float *)this + 232) = v50;
      v51 = v49 / v43;
      v52 = (float)((float)((float)((float)((float)(v31 * v37) + v44) + v45) - (float)(v36 * v50)) - v48) / v43;
      *((float *)this + 199) = v51;
      *((float *)this + 200) = v52;
      outbuffer[v30] = v51;
      outbuffer[v32] = v52;
    }
    while ( v29 != length );
    flt_286C4C0 = v28.m128_f32[0];
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( channels != 6 )
  {
    if ( channels == 8 )
    {
      if ( length )
      {
        v85 = (__m128)LODWORD(flt_286C4C0);
        v86 = 1;
        v87 = 0;
        do
        {
          v88 = v86;
          v89 = v86 + 2;
          v90 = (unsigned int)(8 * v87);
          v91 = v86 + 1;
          v92 = v86 + 4;
          v93 = v86 + 3;
          v94 = v86 + 6;
          v95 = v86 + 5;
          ++v87;
          v96 = inbuffer[v86];
          v86 += 8;
          v97 = inbuffer[v90] + v85.m128_f32[0];
          v98 = *((float *)this + 266);
          v99 = *((float *)this + 267);
          v100 = *((float *)this + 268);
          v124 = v96 + v85.m128_f32[0];
          v126 = inbuffer[v91] + v85.m128_f32[0];
          v127 = inbuffer[v89] + v85.m128_f32[0];
          v122 = inbuffer[v94] + v85.m128_f32[0];
          v101 = *((float *)this + 264);
          v102 = *((float *)this + 263);
          v103 = *((float *)this + 265);
          v104 = (float)((float)((float)((float)((float)(v98 * v97) + (float)(*((float *)this + 135) * v99))
                                       + (float)(*((float *)this + 167) * v100))
                               - (float)(*((float *)this + 199) * v101))
                       - (float)(*((float *)this + 231) * v103))
               / v102;
          v105 = (float)((float)((float)((float)((float)(v124 * v98) + (float)(*((float *)this + 136) * v99))
                                       + (float)(*((float *)this + 168) * v100))
                               - (float)(*((float *)this + 200) * v101))
                       - (float)(*((float *)this + 232) * v103))
               / v102;
          v106 = (float)((float)((float)((float)((float)(v126 * v98) + (float)(*((float *)this + 137) * v99))
                                       + (float)(*((float *)this + 169) * v100))
                               - (float)(*((float *)this + 201) * v101))
                       - (float)(*((float *)this + 233) * v103))
               / v102;
          v128 = inbuffer[v93] + v85.m128_f32[0];
          v129 = inbuffer[v92] + v85.m128_f32[0];
          v130 = inbuffer[v95] + v85.m128_f32[0];
          v107 = (float)((float)((float)((float)((float)(v127 * v98) + (float)(*((float *)this + 138) * v99))
                                       + (float)(*((float *)this + 170) * v100))
                               - (float)(*((float *)this + 202) * v101))
                       - (float)(*((float *)this + 234) * v103))
               / v102;
          v108 = (float)((float)((float)((float)((float)(v128 * v98) + (float)(*((float *)this + 139) * v99))
                                       + (float)(*((float *)this + 171) * v100))
                               - (float)(*((float *)this + 203) * v101))
                       - (float)(*((float *)this + 235) * v103))
               / v102;
          v109 = (float)((float)((float)((float)((float)(v129 * v98) + (float)(*((float *)this + 140) * v99))
                                       + (float)(*((float *)this + 172) * v100))
                               - (float)(*((float *)this + 204) * v101))
                       - (float)(*((float *)this + 236) * v103))
               / v102;
          v110 = *((float *)this + 206);
          v111 = (float)((float)((float)((float)((float)(v130 * v98) + (float)(*((float *)this + 141) * v99))
                                       + (float)(*((float *)this + 173) * v100))
                               - (float)(*((float *)this + 205) * v101))
                       - (float)(*((float *)this + 237) * v103))
               / v102;
          v112 = (float)((float)((float)((float)((float)(v98 * v122) + (float)(v99 * *((float *)this + 142)))
                                       + (float)(v100 * *((float *)this + 174)))
                               - (float)(v101 * v110))
                       - (float)(v103 * *((float *)this + 238)))
               / v102;
          *((_DWORD *)this + 167) = *((_DWORD *)this + 135);
          *((_DWORD *)this + 168) = *((_DWORD *)this + 136);
          v113 = *((_DWORD *)this + 137);
          *((float *)this + 136) = v124;
          *((_DWORD *)this + 169) = v113;
          v114 = *((_DWORD *)this + 138);
          *((float *)this + 137) = v126;
          *((_DWORD *)this + 170) = v114;
          *((float *)this + 135) = v97;
          *((float *)this + 138) = v127;
          *((_DWORD *)this + 171) = *((_DWORD *)this + 139);
          *((float *)this + 139) = v128;
          v115 = *((_DWORD *)this + 140);
          *((float *)this + 140) = v129;
          *((_DWORD *)this + 172) = v115;
          v116 = *((_DWORD *)this + 141);
          *((float *)this + 141) = v130;
          v117 = *((_DWORD *)this + 142);
          *((float *)this + 142) = v122;
          *((_DWORD *)this + 231) = *((_DWORD *)this + 199);
          v118 = *((_DWORD *)this + 200);
          *((_DWORD *)this + 174) = v117;
          *((_DWORD *)this + 232) = v118;
          v119 = *((_DWORD *)this + 202);
          *((_DWORD *)this + 233) = *((_DWORD *)this + 201);
          *((_DWORD *)this + 234) = v119;
          v120 = *((_DWORD *)this + 204);
          *((_DWORD *)this + 235) = *((_DWORD *)this + 203);
          *((_DWORD *)this + 173) = v116;
          *((float *)this + 199) = v104;
          *((float *)this + 200) = v105;
          *((float *)this + 201) = v106;
          *((float *)this + 202) = v107;
          *((float *)this + 203) = v108;
          *((_DWORD *)this + 236) = v120;
          *((float *)this + 204) = v109;
          *((_DWORD *)this + 237) = *((_DWORD *)this + 205);
          *((float *)this + 205) = v111;
          v85 = _mm_xor_ps(v85, (__m128)0x80000000);
          *((float *)this + 238) = v110;
          *((float *)this + 206) = v112;
          outbuffer[v90] = v104;
          outbuffer[v88] = v105;
          outbuffer[v91] = v106;
          outbuffer[v89] = v107;
          outbuffer[v93] = v108;
          outbuffer[v92] = v109;
          outbuffer[v95] = v111;
          outbuffer[v94] = v112;
        }
        while ( v87 != length );
        flt_286C4C0 = v85.m128_f32[0];
      }
    }
    else if ( channels > 0 )
    {
      v5 = (__m128)LODWORD(flt_286C4C0);
      v6 = (float *)this;
      for ( i = 0; i != channels; ++i )
      {
        if ( length )
        {
          v8 = i;
          v9 = 0;
          do
          {
            v10 = v8;
            ++v9;
            v11 = inbuffer[v8] + v5.m128_f32[0];
            v12 = v6[135];
            v8 += channels;
            v13 = v6[199];
            v5 = _mm_xor_ps(v5, (__m128)0x80000000);
            v14 = (float)((float)((float)((float)((float)(*((float *)this + 266) * v11)
                                                + (float)(*((float *)this + 267) * v12))
                                        + (float)(*((float *)this + 268) * v6[167]))
                                - (float)(*((float *)this + 264) * v13))
                        - (float)(*((float *)this + 265) * v6[231]))
                / *((float *)this + 263);
            v6[167] = v12;
            v6[135] = v11;
            v6[231] = v13;
            v6[199] = v14;
            outbuffer[v10] = v14;
          }
          while ( v9 != length );
        }
        ++v6;
      }
      flt_286C4C0 = v5.m128_f32[0];
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( !length )
    return FMOD_RESULT::FMOD_OK_0;
  v53 = (__m128)LODWORD(flt_286C4C0);
  v54 = 0;
  LOBYTE(channels) = 0;
  do
  {
    v55 = v54 + 1;
    v56 = v54;
    v57 = v54 + 2;
    v58 = v54 + 3;
    v59 = v54 + 4;
    v60 = v54 + 5;
    ++channels;
    v54 += 6;
    v61 = inbuffer[v56] + v53.m128_f32[0];
    v62 = *((float *)this + 266);
    v63 = *((float *)this + 267);
    v121 = inbuffer[v55] + v53.m128_f32[0];
    v64 = *((float *)this + 268);
    v65 = *((float *)this + 265);
    v123 = inbuffer[v57] + v53.m128_f32[0];
    v66 = inbuffer[v59] + v53.m128_f32[0];
    v67 = *((float *)this + 264);
    v68 = inbuffer[v60] + v53.m128_f32[0];
    v125 = inbuffer[v58] + v53.m128_f32[0];
    v69 = *((float *)this + 263);
    v70 = (float)((float)((float)((float)((float)(v62 * v61) + (float)(*((float *)this + 135) * v63))
                                + (float)(*((float *)this + 167) * v64))
                        - (float)(*((float *)this + 199) * v67))
                - (float)(*((float *)this + 231) * v65))
        / v69;
    v71 = (float)((float)((float)((float)((float)(v121 * v62) + (float)(*((float *)this + 136) * v63))
                                + (float)(*((float *)this + 168) * v64))
                        - (float)(*((float *)this + 200) * v67))
                - (float)(*((float *)this + 232) * v65))
        / v69;
    v72 = (float)((float)((float)((float)((float)(v123 * v62) + (float)(*((float *)this + 137) * v63))
                                + (float)(*((float *)this + 169) * v64))
                        - (float)(*((float *)this + 201) * v67))
                - (float)(*((float *)this + 233) * v65))
        / v69;
    v73 = (float)((float)((float)((float)((float)(v125 * v62) + (float)(*((float *)this + 138) * v63))
                                + (float)(*((float *)this + 170) * v64))
                        - (float)(*((float *)this + 202) * v67))
                - (float)(*((float *)this + 234) * v65))
        / v69;
    v74 = *((float *)this + 204);
    v75 = (float)((float)((float)((float)((float)(v66 * v62) + (float)(*((float *)this + 139) * v63))
                                + (float)(*((float *)this + 171) * v64))
                        - (float)(*((float *)this + 203) * v67))
                - (float)(*((float *)this + 235) * v65))
        / v69;
    v76 = (float)((float)((float)((float)(v62 * v68) + (float)(v63 * *((float *)this + 140)))
                        + (float)(v64 * *((float *)this + 172)))
                - (float)(v67 * v74))
        - (float)(v65 * *((float *)this + 236));
    *((_DWORD *)this + 167) = *((_DWORD *)this + 135);
    v77 = *((_DWORD *)this + 136);
    *((float *)this + 136) = v121;
    *((_DWORD *)this + 168) = v77;
    v78 = *((_DWORD *)this + 137);
    *((float *)this + 137) = v123;
    *((_DWORD *)this + 169) = v78;
    v79 = *((_DWORD *)this + 138);
    v80 = v76 / v69;
    *((float *)this + 138) = v125;
    *((_DWORD *)this + 171) = *((_DWORD *)this + 139);
    *((_DWORD *)this + 172) = *((_DWORD *)this + 140);
    v81 = *((_DWORD *)this + 199);
    *((_DWORD *)this + 170) = v79;
    *((_DWORD *)this + 231) = v81;
    v82 = *((_DWORD *)this + 201);
    *((_DWORD *)this + 232) = *((_DWORD *)this + 200);
    *((_DWORD *)this + 233) = v82;
    v83 = *((_DWORD *)this + 202);
    v84 = *((_DWORD *)this + 203);
    *((float *)this + 135) = v61;
    *((float *)this + 139) = v66;
    *((float *)this + 140) = v68;
    *((float *)this + 199) = v70;
    *((float *)this + 200) = v71;
    *((float *)this + 201) = v72;
    *((_DWORD *)this + 234) = v83;
    *((float *)this + 202) = v73;
    *((_DWORD *)this + 235) = v84;
    *((float *)this + 203) = v75;
    *((float *)this + 236) = v74;
    *((float *)this + 204) = v80;
    outbuffer[v56] = v70;
    outbuffer[v55] = v71;
    outbuffer[v57] = v72;
    outbuffer[v58] = v73;
    outbuffer[v59] = v75;
    outbuffer[v60] = v80;
    v53 = _mm_xor_ps(v53, (__m128)0x80000000);
  }
  while ( channels != length );
  flt_286C4C0 = v53.m128_f32[0];
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220acb0 | Name: _ZN4FMOD11DSPHighPass12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPHighPass::readInternal(
        FMOD::DSPHighPass *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float *v6; // r12
  __int64 v10; // r15
  float v11; // xmm0_4
  float v12; // xmm2_4
  float v13; // xmm1_4
  float *v14; // rsi
  float v15; // xmm2_4
  float v16; // xmm3_4
  _DWORD *v18; // rax

  v6 = inbuffer;
  if ( !inbuffer )
    return FMOD_RESULT::FMOD_OK_0;
  v10 = 4LL * inchannels;
  while ( 1 )
  {
    v11 = *((float *)this + 134);
    v15 = *((float *)this + 270);
    v13 = *((float *)this + 132);
    if ( v11 == v15 && v13 == *((float *)this + 269) )
      break;
    if ( !length )
      break;
    v16 = (float)(v13 / 100.0) + 10.0;
    if ( v15 > v11 )
    {
      v11 = v11 + 1.0;
      if ( v11 >= v15 )
        goto LABEL_4;
    }
    else
    {
      if ( v11 <= v15 )
        goto LABEL_5;
      v11 = v11 - 1.0;
      if ( v15 >= v11 )
      {
LABEL_4:
        *((float *)this + 134) = v15;
        v11 = v15;
LABEL_5:
        v12 = *((float *)this + 269);
        if ( v12 > v13 )
          goto LABEL_6;
        goto LABEL_15;
      }
    }
    v12 = *((float *)this + 269);
    *((float *)this + 134) = v11;
    if ( v12 > v13 )
    {
LABEL_6:
      v13 = v13 + v16;
      if ( v13 < v12 )
        goto LABEL_17;
      goto LABEL_7;
    }
LABEL_15:
    if ( v13 <= v12 )
      goto LABEL_8;
    v13 = v13 - v16;
    if ( v12 < v13 )
    {
LABEL_17:
      *((float *)this + 132) = v13;
      goto LABEL_8;
    }
LABEL_7:
    *((float *)this + 132) = v12;
    v13 = v12;
LABEL_8:
    FMOD::DSPHighPass::updateCoefficients(this, v11, v13, v12);
    v14 = v6;
    v6 = (float *)((char *)v6 + v10);
    FMOD::DSPHighPass::process(this, v14, outbuffer, 1u, inchannels);
    outbuffer = (float *)((char *)outbuffer + v10);
    if ( !--length )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( v13 < 2.0 )
  {
    memcpy_0(outbuffer, v6, v10 * length);
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( v13 < *((float *)this + 133) )
    return FMOD::DSPHighPass::process(this, v6, outbuffer, length, inchannels);
  memset(outbuffer, 0, v10 * length);
  if ( inchannels > 0 )
  {
    v18 = (_DWORD *)((char *)this + 668);
    do
    {
      *v18 = 0;
      *(v18 - 32) = 0;
      ++v18;
      v18[63] = 0;
      v18[31] = 0;
    }
    while ( v18 != (_DWORD *)((char *)this + 4 * (unsigned int)(inchannels - 1) + 672) );
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220aed0 | Name: _ZN4FMOD11DSPHighPass12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPHighPass::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPHighPass::readInternal(
           (FMOD::DSPHighPass *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x220aee0 | Name: _ZN4FMOD11DSPHighPass25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPHighPass::setParameterFloatInternal(
        FMOD::DSPHighPass *const this,
        int index,
        float a3,
        float value)
{
  float v5; // xmm1_4

  if ( index )
  {
    if ( index == 1 )
      *((float *)this + 270) = a3;
    return 0;
  }
  v5 = *((float *)this + 133);
  *((float *)this + 269) = a3;
  if ( a3 < v5 )
    return 0;
  *((float *)this + 269) = v5;
  return 0;
}


// Address: 0x220af20 | Name: _ZN4FMOD11DSPHighPass25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPHighPass::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPHighPass::setParameterFloatInternal((FMOD::DSPHighPass *const)dsp_state->instance, index, a3, value);
}


// Address: 0x220af30 | Name: _ZN4FMOD11DSPHighPass25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPHighPass::getParameterFloatInternal(
        FMOD::DSPHighPass *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v4; // xmm0_4

  if ( !index )
  {
    *value = *((float *)this + 269);
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    v4 = *((float *)this + 269);
    goto LABEL_5;
  }
  if ( index == 1 )
  {
    *value = *((float *)this + 270);
    if ( valuestr )
    {
      v4 = *((float *)this + 270);
LABEL_5:
      sprintf(valuestr, "%.02f", v4);
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220afa0 | Name: _ZN4FMOD11DSPHighPass25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPHighPass::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPHighPass::getParameterFloatInternal(
           (FMOD::DSPHighPass *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


