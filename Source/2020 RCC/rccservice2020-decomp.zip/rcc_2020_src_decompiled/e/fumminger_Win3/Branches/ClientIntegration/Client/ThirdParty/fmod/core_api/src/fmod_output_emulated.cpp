// Address: 0x221f2a0 | Name: _ZN4FMOD14OutputEmulatedC2Ev
void __fastcall FMOD::OutputEmulated::OutputEmulated(FMOD::OutputEmulated *const this)
{
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *p_mDescription; // rdi
  unsigned int v3; // esi
  __int64 v4; // rcx
  unsigned int *v5; // rdi

  FMOD::Output::Output(this);
  p_mDescription = &this->mDescription;
  v3 = 264;
  this->_vptr_Output = (int (**)(...))&off_29B2250;
  if ( (((_BYTE)this + 112) & 1) == 0 )
  {
    if ( ((unsigned __int8)p_mDescription & 2) == 0 )
      goto LABEL_3;
LABEL_12:
    p_mDescription = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)p_mDescription + 2);
    v3 -= 2;
    HIWORD(p_mDescription[-1].record_unlock) = 0;
    if ( ((unsigned __int8)p_mDescription & 4) == 0 )
      goto LABEL_4;
    goto LABEL_13;
  }
  p_mDescription = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)&this->mDescription.apiversion + 1);
  LOBYTE(this->mDescription.apiversion) = 0;
  LOBYTE(v3) = 7;
  if ( (((_BYTE)this + 113) & 2) != 0 )
    goto LABEL_12;
LABEL_3:
  if ( ((unsigned __int8)p_mDescription & 4) == 0 )
    goto LABEL_4;
LABEL_13:
  p_mDescription->apiversion = 0;
  v3 -= 4;
  p_mDescription = (FMOD::FMOD_OUTPUT_DESCRIPTION_EX *)((char *)p_mDescription + 4);
LABEL_4:
  v4 = v3 >> 3;
  memset(p_mDescription, 0, 8 * v4);
  v5 = &p_mDescription->apiversion + 2 * v4;
  if ( (v3 & 4) != 0 )
    *v5++ = 0;
  if ( (v3 & 2) != 0 )
  {
    v5 = (unsigned int *)((char *)v5 + 2);
    *((_WORD *)v5 - 1) = 0;
  }
  if ( (v3 & 1) != 0 )
    *(_BYTE *)v5 = 0;
  this->mChannel = 0;
}


// Address: 0x221f360 | Name: _ZN4FMOD14OutputEmulated4initEi
FMOD_RESULT_0 __fastcall FMOD::OutputEmulated::init(FMOD::OutputEmulated *const this, int maxchannels)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelPool *v4; // rax
  FMOD::ChannelPool *v5; // r12
  FMOD::SystemI *mSystem; // rsi
  FMOD::ChannelEmulated *v7; // rdx
  FMOD::ChannelEmulated *mChannel; // rax
  __int64 v9; // r12
  int v10; // r13d
  FMOD::ChannelEmulated *v11; // rdx
  bool v12; // zf
  FMOD::ChannelReal *v13; // rax
  FMOD::ChannelReal *v14; // r14

  result = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  if ( this->mSystem )
  {
    if ( !maxchannels )
      return FMOD_RESULT::FMOD_OK_0;
    v4 = (FMOD::ChannelPool *)FMOD::MemPool::alloc(
                                off_286F358->gSystemMemPool,
                                32,
                                "../../../core_api/src/fmod_output_emulated.cpp",
                                65,
                                0,
                                0);
    v5 = v4;
    if ( !v4 )
    {
      this->mChannelPool = 0;
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
    FMOD::ChannelPool::ChannelPool(v4);
    mSystem = this->mSystem;
    this->mChannelPool = v5;
    result = FMOD::ChannelPool::init(v5, mSystem, this, maxchannels);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v7 = (FMOD::ChannelEmulated *)FMOD::MemPool::calloc(
                                      off_286F358->gSystemMemPool,
                                      112 * maxchannels,
                                      "../../../core_api/src/fmod_output_emulated.cpp",
                                      77,
                                      0);
      this->mChannel = v7;
      result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
      if ( v7 )
      {
        if ( maxchannels <= 0 )
          return FMOD_RESULT::FMOD_OK_0;
        mChannel = v7;
        v9 = 0;
        v10 = 0;
        while ( 1 )
        {
          v11 = 0;
          v12 = &mChannel[v9] == 0;
          v13 = &mChannel[v9];
          v14 = v13;
          if ( !v12 )
          {
            FMOD::ChannelReal::ChannelReal(v13);
            v11 = &this->mChannel[v9];
            v14->_vptr_ChannelReal = (int (**)(...))&off_29B2370;
          }
          result = FMOD::ChannelPool::setChannel(this->mChannelPool, v10, v11);
          if ( result )
            break;
          ++v10;
          ++v9;
          if ( v10 == maxchannels )
            return FMOD_RESULT::FMOD_OK_0;
          mChannel = this->mChannel;
        }
      }
    }
  }
  return result;
}


// Address: 0x221f4c0 | Name: _ZN4FMOD14OutputEmulated6updateEv
FMOD_RESULT_0 __fastcall FMOD::OutputEmulated::update(FMOD::OutputEmulated *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x221f4d0 | Name: _ZN4FMOD14OutputEmulated7releaseEv
FMOD_RESULT_0 __fastcall FMOD::OutputEmulated::release(FMOD::OutputEmulated *const this)
{
  FMOD::ChannelPool *mChannelPool; // rdi
  FMOD::ChannelEmulated *mChannel; // rsi

  mChannelPool = this->mChannelPool;
  if ( mChannelPool )
  {
    FMOD::ChannelPool::release(mChannelPool);
    this->mChannelPool = 0;
  }
  mChannel = this->mChannel;
  if ( mChannel )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mChannel, "../../../core_api/src/fmod_output_emulated.cpp", 117);
    this->mChannel = 0;
  }
  return FMOD::Output::release(this);
}


