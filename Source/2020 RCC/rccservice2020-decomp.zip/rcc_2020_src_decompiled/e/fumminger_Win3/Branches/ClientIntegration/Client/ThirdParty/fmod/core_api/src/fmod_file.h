// Address: 0x21f1cb0 | Name: _ZN4FMOD4FileD2Ev
void __fastcall FMOD::File::~File(FMOD::File *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
}


// Address: 0x21f1cc0 | Name: _ZN4FMOD4File11getMetadataEPPNS_8MetadataE
FMOD_RESULT_0 __fastcall FMOD::File::getMetadata(FMOD::File *const this, FMOD::Metadata **a2)
{
  return FMOD_RESULT::FMOD_ERR_TAGNOTFOUND_0;
}


// Address: 0x21f1cd0 | Name: _ZN4FMOD4File7getSizeEPj
FMOD_RESULT_0 __fastcall FMOD::File::getSize(FMOD::File *const this, unsigned int *size)
{
  *size = this->mLength;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f1ce0 | Name: _ZN4FMOD4File14readPtrAdvanceEPPvj
FMOD_RESULT_0 __fastcall FMOD::File::readPtrAdvance(FMOD::File *const this, void **pointer, unsigned int size)
{
  *pointer = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f1cf0 | Name: _ZN4FMOD4File12reallyCancelEP18FMOD_ASYNCREADINFO
FMOD_RESULT_0 __fastcall FMOD::File::reallyCancel(FMOD::File *const this, FMOD_ASYNCREADINFO *info)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f1d00 | Name: _ZN4FMOD4File15reallyAsyncReadEP18FMOD_ASYNCREADINFOPjb
FMOD_RESULT_0 __fastcall FMOD::File::reallyAsyncRead(
        FMOD::File *const this,
        FMOD_ASYNCREADINFO *info,
        unsigned int *bytesread,
        bool a4)
{
  FMOD_RESULT_0 result; // eax

  result = (*((unsigned int (__fastcall **)(FMOD::File *const, void *, _QWORD, unsigned int *))this->_vptr_File + 7))(
             this,
             info->buffer,
             info->sizebytes,
             &info->bytesread);
  *bytesread = info->bytesread;
  return result;
}


// Address: 0x21f1dc0 | Name: _ZN4FMOD10MemoryFileD2Ev
void __fastcall FMOD::MemoryFile::~MemoryFile(FMOD::MemoryFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
}


// Address: 0x21f1dd0 | Name: _ZN4FMOD4FileD0Ev
void __fastcall FMOD::File::~File(FMOD::File *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
  operator delete(this);
}


// Address: 0x21f1df0 | Name: _ZN4FMOD10MemoryFileD0Ev
void __fastcall FMOD::MemoryFile::~MemoryFile(FMOD::MemoryFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
  operator delete(this);
}


// Address: 0x21f1f10 | Name: _ZN4FMOD8UserFileD2Ev
void __fastcall FMOD::UserFile::~UserFile(FMOD::UserFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
}


// Address: 0x21f1f20 | Name: _ZN4FMOD8UserFileD0Ev
void __fastcall FMOD::UserFile::~UserFile(FMOD::UserFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
  operator delete(this);
}


// Address: 0x21f22d0 | Name: _ZN4FMOD8DiskFileD2Ev
void __fastcall FMOD::DiskFile::~DiskFile(FMOD::DiskFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
}


// Address: 0x21f22e0 | Name: _ZN4FMOD8DiskFileD0Ev
void __fastcall FMOD::DiskFile::~DiskFile(FMOD::DiskFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
  operator delete(this);
}


// Address: 0x21f2450 | Name: _ZN4FMOD8NullFileD2Ev
void __fastcall FMOD::NullFile::~NullFile(FMOD::NullFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
}


// Address: 0x21f2460 | Name: _ZN4FMOD8NullFileD0Ev
void __fastcall FMOD::NullFile::~NullFile(FMOD::NullFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
  operator delete(this);
}


// Address: 0x2205720 | Name: _ZN4FMOD10RemoteFileD2Ev
void __fastcall FMOD::RemoteFile::~RemoteFile(FMOD::RemoteFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
}


// Address: 0x2205730 | Name: _ZN4FMOD10RemoteFileD0Ev
void __fastcall FMOD::RemoteFile::~RemoteFile(FMOD::RemoteFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
  operator delete(this);
}


// Address: 0x2242960 | Name: _ZN4FMOD7NetFileD2Ev
void __fastcall FMOD::NetFile::~NetFile(FMOD::NetFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
}


// Address: 0x2242970 | Name: _ZN4FMOD7NetFileD0Ev
void __fastcall FMOD::NetFile::~NetFile(FMOD::NetFile *const this)
{
  this->_vptr_File = (int (**)(...))off_29B17D0;
  operator delete(this);
}


