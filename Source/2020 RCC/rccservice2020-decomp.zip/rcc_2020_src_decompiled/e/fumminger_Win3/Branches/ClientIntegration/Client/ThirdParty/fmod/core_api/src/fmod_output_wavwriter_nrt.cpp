// Address: 0x21d0710 | Name: _ZN4FMOD19OutputWavWriter_NRT16getDescriptionExEv
FMOD::FMOD_OUTPUT_DESCRIPTION_EX *__cdecl FMOD::OutputWavWriter_NRT::getDescriptionEx()
{
  stru_2AD6060.mType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_WAVWRITER_NRT_0;
  stru_2AD6060.mSize = 1432;
  memset(&stru_2AD6060, 0, 0xB0u);
  stru_2AD6060.apiversion = 4;
  stru_2AD6060.version = 65792;
  stru_2AD6060.name = "FMOD WavWriter Output - Non real-time";
  stru_2AD6060.getnumdrivers = FMOD::OutputWavWriter_NRT::getNumDriversCallback;
  stru_2AD6060.getdriverinfo = FMOD::OutputWavWriter_NRT::getDriverInfoCallback;
  stru_2AD6060.init = FMOD::OutputWavWriter_NRT::initCallback;
  stru_2AD6060.close = FMOD::OutputWavWriter_NRT::closeCallback;
  stru_2AD6060.start = FMOD::OutputWavWriter_NRT::startCallback;
  stru_2AD6060.stop = FMOD::OutputWavWriter_NRT::stopCallback;
  stru_2AD6060.update = FMOD::OutputWavWriter_NRT::updateCallback;
  stru_2AD6060.gethandle = FMOD::OutputWavWriter_NRT::getHandleCallback;
  return &stru_2AD6060;
}


// Address: 0x21d07b0 | Name: _ZN4FMOD19OutputWavWriter_NRT13getNumDriversEPi
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::getNumDrivers(
        FMOD::OutputWavWriter_NRT *const this,
        int *numdrivers)
{
  *numdrivers = 5;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d07c0 | Name: _ZN4FMOD19OutputWavWriter_NRT21getNumDriversCallbackEP17FMOD_OUTPUT_STATEPi
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::getNumDriversCallback(FMOD_OUTPUT_STATE *output, int *numdrivers)
{
  FMOD::OutputWavWriter_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter_NRT *)&output[-1].requestreset;
  return FMOD::OutputWavWriter_NRT::getNumDrivers(p_requestreset, numdrivers);
}


// Address: 0x21d07e0 | Name: _ZN4FMOD19OutputWavWriter_NRT13getDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::getDriverInfo(
        FMOD::OutputWavWriter_NRT *const this,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels)
{
  FMOD_RESULT_0 result; // eax

  if ( !name )
    return FMOD_RESULT::FMOD_OK_0;
  switch ( id )
  {
    case 0:
      FMOD_strcpy_safe(name, "16 bit Integer PCM wave writer (default filename = fmodoutput.wav)", namelen);
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case 1:
      FMOD_strcpy_safe(name, "8  bit Integer PCM wave writer (default filename = fmodoutput.wav)", namelen);
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case 2:
      FMOD_strcpy_safe(name, "24 bit Integer PCM wave writer (default filename = fmodoutput.wav)", namelen);
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case 3:
      FMOD_strcpy_safe(name, "32 bit Integer PCM wave writer (default filename = fmodoutput.wav)", namelen);
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case 4:
      FMOD_strcpy_safe(name, "32 bit float   PCM wave writer (default filename = fmodoutput.wav)", namelen);
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    default:
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21d0890 | Name: _ZN4FMOD19OutputWavWriter_NRT21getDriverInfoCallbackEP17FMOD_OUTPUT_STATEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES6_
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::getDriverInfoCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels)
{
  FMOD::OutputWavWriter_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter_NRT *)&output[-1].requestreset;
  return FMOD::OutputWavWriter_NRT::getDriverInfo(
           p_requestreset,
           id,
           name,
           namelen,
           guid,
           systemrate,
           speakermode,
           speakermodechannels);
}


// Address: 0x21d08b0 | Name: _ZN4FMOD19OutputWavWriter_NRT4initEijPiP16FMOD_SPEAKERMODES1_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::init(
        FMOD::OutputWavWriter_NRT *const this,
        int selecteddriver,
        FMOD_INITFLAGS flags,
        int *outputrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels,
        FMOD_SOUND_FORMAT_0 *outputformat,
        int dspbufferlength,
        int dspnumbuffers,
        void *extradriverdata)
{
  FMOD_SOUND_FORMAT_0 v10; // edx
  int v11; // esi
  __int64 v12; // rdx
  unsigned __int64 v13; // rax
  int v14; // esi
  FMOD::Global *v15; // rax
  void *v16; // rdx
  FMOD_RESULT_0 result; // eax
  char *v18; // rdi

  *((_DWORD *)this + 23) = 1;
  switch ( selecteddriver )
  {
    case 0:
      v10 = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
      *outputformat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
      break;
    case 1:
      v10 = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0;
      *outputformat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0;
      break;
    case 2:
      v10 = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0;
      *outputformat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0;
      break;
    case 3:
      v10 = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0;
      *outputformat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0;
      break;
    case 4:
      v10 = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
      *outputformat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
      break;
    default:
      v10 = *outputformat;
      break;
  }
  if ( *speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
  {
    *speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0;
    *speakermodechannels = 2;
  }
  *((_DWORD *)this + 353) = 0;
  switch ( v10 )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      *((_DWORD *)this + 353) = 8;
      v12 = 8;
      v11 = *speakermodechannels;
      goto LABEL_8;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      *((_DWORD *)this + 353) = 16;
      v11 = *speakermodechannels;
LABEL_16:
      v12 = 16;
      goto LABEL_8;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      *((_DWORD *)this + 353) = 24;
      v11 = *speakermodechannels;
LABEL_14:
      v12 = 24;
      goto LABEL_8;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      *((_DWORD *)this + 353) = 32;
      v11 = *speakermodechannels;
LABEL_7:
      v12 = 32;
LABEL_8:
      v13 = (v12 * (unsigned __int64)(unsigned int)dspbufferlength) >> 3;
      break;
    default:
      v11 = *speakermodechannels;
      switch ( v10 )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
          v12 = 8;
          goto LABEL_8;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          goto LABEL_16;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          goto LABEL_14;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          goto LABEL_7;
        default:
          LODWORD(v13) = dspbufferlength;
          break;
      }
      break;
  }
  v14 = v13 * v11;
  v15 = off_286F358;
  *((_DWORD *)this + 352) = v14;
  v16 = FMOD::MemPool::calloc(v15->gSystemMemPool, v14, "../../../core_api/src/fmod_output_wavwriter_nrt.cpp", 144, 0);
  *((_QWORD *)this + 175) = v16;
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v16 )
  {
    v18 = (char *)this + 1144;
    if ( extradriverdata )
    {
      FMOD_strcpy_safe(v18, (const char *)extradriverdata, 256);
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      FMOD_strcpy_safe(v18, "fmodoutput.wav", 256);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21d0ae0 | Name: _ZN4FMOD19OutputWavWriter_NRT12initCallbackEP17FMOD_OUTPUT_STATEijPiP16FMOD_SPEAKERMODES3_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::initCallback(
        FMOD_OUTPUT_STATE *output,
        int selecteddriver,
        FMOD_INITFLAGS flags,
        int *outputrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels,
        FMOD_SOUND_FORMAT_0 *outputformat,
        int dspbufferlength,
        int dspnumbuffers,
        void *extradriverdata)
{
  FMOD::OutputWavWriter_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter_NRT *)&output[-1].requestreset;
  return FMOD::OutputWavWriter_NRT::init(
           p_requestreset,
           selecteddriver,
           flags,
           outputrate,
           speakermode,
           speakermodechannels,
           outputformat,
           dspbufferlength,
           dspnumbuffers,
           extradriverdata);
}


// Address: 0x21d0b00 | Name: _ZN4FMOD19OutputWavWriter_NRT5closeEv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::close(FMOD::OutputWavWriter_NRT *const this)
{
  void *v1; // rsi

  v1 = (void *)*((_QWORD *)this + 175);
  if ( v1 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_output_wavwriter_nrt.cpp", 178);
    *((_QWORD *)this + 175) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d0b50 | Name: _ZN4FMOD19OutputWavWriter_NRT13closeCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::closeCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputWavWriter_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter_NRT *)&output[-1].requestreset;
  return FMOD::OutputWavWriter_NRT::close(p_requestreset);
}


// Address: 0x21d0b70 | Name: _ZN4FMOD19OutputWavWriter_NRT9getHandleEPPv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::getHandle(FMOD::OutputWavWriter_NRT *const this, void **handle)
{
  *handle = (void *)*((_QWORD *)this + 178);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d0b80 | Name: _ZN4FMOD19OutputWavWriter_NRT17getHandleCallbackEP17FMOD_OUTPUT_STATEPPv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::getHandleCallback(FMOD_OUTPUT_STATE *output, void **handle)
{
  FMOD::OutputWavWriter_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter_NRT *)&output[-1].requestreset;
  return FMOD::OutputWavWriter_NRT::getHandle(p_requestreset, handle);
}


// Address: 0x21d0ba0 | Name: _ZN4FMOD19OutputWavWriter_NRT6updateEv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::update(FMOD::OutputWavWriter_NRT *const this)
{
  FMOD_RESULT_0 result; // eax
  size_t v3; // rdx
  _BYTE *v4; // rdi
  __int64 v5; // rax

  result = (*((unsigned int (__fastcall **)(char *, _QWORD, _QWORD))this + 2))(
             (char *)this + 8,
             *((_QWORD *)this + 175),
             (unsigned int)(8 * *((_DWORD *)this + 352)) / *((_DWORD *)this + 353) / *((_DWORD *)this + 22));
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( *((_DWORD *)this + 20) == 1 )
    {
      v3 = *((unsigned int *)this + 352);
      v4 = (_BYTE *)*((_QWORD *)this + 175);
      if ( (int)v3 > 0 )
      {
        v5 = 0;
        do
        {
          v4[v5++] += 0x80;
          v3 = *((unsigned int *)this + 352);
        }
        while ( (int)v5 < (int)v3 );
        v4 = (_BYTE *)*((_QWORD *)this + 175);
      }
    }
    else
    {
      v3 = *((unsigned int *)this + 352);
      v4 = (_BYTE *)*((_QWORD *)this + 175);
    }
    *((_DWORD *)this + 354) += fwrite(v4, 1u, v3, *((FILE **)this + 178));
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21d0c40 | Name: _ZN4FMOD19OutputWavWriter_NRT14updateCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::updateCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputWavWriter_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter_NRT *)&output[-1].requestreset;
  return FMOD::OutputWavWriter_NRT::update(p_requestreset);
}


// Address: 0x21d0c60 | Name: _ZN4FMOD19OutputWavWriter_NRT14writeWavHeaderEv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::writeWavHeader(FMOD::OutputWavWriter_NRT *const this)
{
  return FMOD::FMOD_WriteWavHeader(
           *((FILE **)this + 178),
           *((FMOD_SOUND_FORMAT_0 *)this + 20),
           *((_DWORD *)this + 22),
           *(_DWORD *)(*((_QWORD *)this + 9) + 1696LL),
           *((_DWORD *)this + 354));
}


// Address: 0x21d0c90 | Name: _ZN4FMOD19OutputWavWriter_NRT5startEv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::start(FMOD::OutputWavWriter_NRT *const this)
{
  FILE *v1; // rax

  v1 = fopen((const char *)this + 1144, "wb");
  *((_QWORD *)this + 178) = v1;
  if ( v1 )
    return FMOD::OutputWavWriter_NRT::writeWavHeader(this);
  else
    return FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0;
}


// Address: 0x21d0cd0 | Name: _ZN4FMOD19OutputWavWriter_NRT13startCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::startCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputWavWriter_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter_NRT *)&output[-1].requestreset;
  return FMOD::OutputWavWriter_NRT::start(p_requestreset);
}


// Address: 0x21d0cf0 | Name: _ZN4FMOD19OutputWavWriter_NRT4stopEv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::stop(FMOD::OutputWavWriter_NRT *const this)
{
  FILE *v2; // rdi

  FMOD::OutputWavWriter_NRT::writeWavHeader(this);
  v2 = (FILE *)*((_QWORD *)this + 178);
  if ( v2 )
  {
    fclose(v2);
    *((_QWORD *)this + 178) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d0d20 | Name: _ZN4FMOD19OutputWavWriter_NRT12stopCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter_NRT::stopCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputWavWriter_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter_NRT *)&output[-1].requestreset;
  return FMOD::OutputWavWriter_NRT::stop(p_requestreset);
}


