// Address: 0x2236150 | Name: _ZN4FMOD14FMOD_FormatArgEPcic
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, char arg)
{
  int result; // eax

  if ( length <= 1 )
  {
    result = length;
    if ( length == 1 )
      *buffer = 0;
  }
  else
  {
    *buffer = arg;
    buffer[1] = 0;
    return 1;
  }
  return result;
}


// Address: 0x2236180 | Name: _ZN4FMOD14FMOD_FormatArgEPcii
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, int arg)
{
  if ( (unsigned int)arg > 9 || length <= 1 )
    return FMOD_snprintf(buffer, length, "%d", arg);
  buffer[1] = 0;
  *buffer = arg + 48;
  return 1;
}


// Address: 0x22361b0 | Name: _ZN4FMOD14FMOD_FormatArgEPcij
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, unsigned int arg)
{
  if ( arg > 9 || length <= 1 )
    return FMOD_snprintf(buffer, length, "%u", arg);
  buffer[1] = 0;
  *buffer = arg + 48;
  return 1;
}


// Address: 0x22361e0 | Name: _ZN4FMOD14FMOD_FormatArgEPcix
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, __int64 arg)
{
  return FMOD_snprintf(buffer, length, "%lld", arg);
}


// Address: 0x2236200 | Name: _ZN4FMOD14FMOD_FormatArgEPciy
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, unsigned __int64 arg)
{
  return FMOD_snprintf(buffer, length, "%llu", arg);
}


// Address: 0x2236220 | Name: _ZN4FMOD14FMOD_FormatArgEPcif
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, __m128i a3, float arg)
{
  int v4; // eax

  v4 = _mm_cvtsi128_si32(a3);
  if ( length <= 1 )
    return FMOD_snprintf(buffer, length, "%g", *(float *)a3.m128i_i32);
  if ( v4 )
  {
    if ( v4 != 1065353216 )
      return FMOD_snprintf(buffer, length, "%g", *(float *)a3.m128i_i32);
    *buffer = 49;
    buffer[1] = 0;
    return 1;
  }
  else
  {
    *buffer = 48;
    buffer[1] = 0;
    return 1;
  }
}


// Address: 0x2236280 | Name: _ZN4FMOD14FMOD_FormatArgEPciRK11FMOD_VECTOR
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const FMOD_VECTOR *const arg)
{
  float x; // xmm0_4
  float y; // xmm1_4
  bool v5; // zf
  float z; // xmm2_4
  char v8; // al
  char v9; // al
  char v10; // al

  x = arg->x;
  if ( arg->x == 0.0 )
  {
    y = arg->y;
    v5 = y == 0.0;
  }
  else
  {
    if ( x != 1.0 )
    {
      z = arg->z;
      y = arg->y;
      return FMOD_snprintf(buffer, length, "{%g,%g,%g}", x, y, z);
    }
    y = arg->y;
    v5 = y == 0.0;
  }
  if ( !v5 && y != 1.0 )
  {
    z = arg->z;
    return FMOD_snprintf(buffer, length, "{%g,%g,%g}", x, y, z);
  }
  z = arg->z;
  if ( z != 0.0 && z != 1.0 || length <= 7 )
    return FMOD_snprintf(buffer, length, "{%g,%g,%g}", x, y, z);
  *buffer = 123;
  v8 = 48;
  if ( arg->x != 0.0 )
    v8 = 49;
  buffer[1] = v8;
  buffer[2] = 44;
  v9 = 48;
  if ( arg->y != 0.0 )
    v9 = 49;
  buffer[3] = v9;
  buffer[4] = 44;
  v10 = 48;
  if ( arg->z != 0.0 )
    v10 = 49;
  buffer[5] = v10;
  buffer[6] = 125;
  buffer[7] = 0;
  return 7;
}


// Address: 0x22363a0 | Name: _ZN4FMOD14FMOD_FormatArgEPciRK9FMOD_GUID
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const FMOD_GUID *const arg)
{
  return FMOD_snprintf(
           buffer,
           length,
           "{%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x}",
           arg->Data1,
           arg->Data2,
           arg->Data3,
           arg->Data4[0],
           arg->Data4[1],
           arg->Data4[2],
           arg->Data4[3],
           arg->Data4[4],
           arg->Data4[5],
           arg->Data4[6],
           arg->Data4[7]);
}


// Address: 0x2236410 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKi
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const int *arg)
{
  if ( arg )
    return FMOD_snprintf(buffer, length, "%p:%d", arg, *arg);
  else
    return FMOD_snprintf(buffer, length, "%p", 0);
}


// Address: 0x2236440 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKj
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const unsigned int *arg)
{
  if ( arg )
    return FMOD_snprintf(buffer, length, "%p:%u", arg, *arg);
  else
    return FMOD_snprintf(buffer, length, "%p", 0);
}


// Address: 0x2236470 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKx
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const __int64 *arg)
{
  if ( arg )
    return FMOD_snprintf(buffer, length, "%p:%lld", arg, *arg);
  else
    return FMOD_snprintf(buffer, length, "%p", 0);
}


// Address: 0x22364a0 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKy
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const unsigned __int64 *arg)
{
  if ( arg )
    return FMOD_snprintf(buffer, length, "%p:%llu", arg, *arg);
  else
    return FMOD_snprintf(buffer, length, "%p", 0);
}


// Address: 0x22364d0 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKf
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const float *arg)
{
  if ( arg )
    return FMOD_snprintf(buffer, length, "%p:%g", arg, *arg);
  else
    return FMOD_snprintf(buffer, length, "%p", 0);
}


// Address: 0x2236500 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKb
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const bool *arg)
{
  const char *v3; // r8

  if ( !arg )
    return FMOD_snprintf(buffer, length, "%p", 0);
  v3 = "false";
  if ( *arg )
    v3 = "true";
  return FMOD_snprintf(buffer, length, "%p:%s", arg, v3);
}


// Address: 0x2236540 | Name: _ZN4FMOD14FMOD_FormatArgEPciPK11FMOD_VECTOR
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const FMOD_VECTOR *arg)
{
  if ( arg )
    return FMOD_snprintf(buffer, length, "%p:{%g,%g,%g}", arg, arg->x, arg->y, arg->z);
  else
    return FMOD_snprintf(buffer, length, "%p", 0);
}


// Address: 0x2236580 | Name: _ZN4FMOD14FMOD_FormatArgEPciPK9FMOD_GUID
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const FMOD_GUID *arg)
{
  if ( arg )
    return FMOD_snprintf(
             buffer,
             length,
             "%p:{%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x}",
             arg,
             arg->Data1,
             arg->Data2,
             arg->Data3,
             arg->Data4[0],
             arg->Data4[1],
             arg->Data4[2],
             arg->Data4[3],
             arg->Data4[4],
             arg->Data4[5],
             arg->Data4[6],
             arg->Data4[7]);
  else
    return FMOD_snprintf(buffer, length, "%p", 0);
}


// Address: 0x2236600 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKv
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const void *arg)
{
  return FMOD_snprintf(buffer, length, "%p", arg);
}


// Address: 0x2236620 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKc
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const char *arg)
{
  int v4; // eax
  int v5; // ebp

  if ( !arg )
    return FMOD::FMOD_FormatArg(buffer, length, 0);
  v4 = FMOD_strlen(arg);
  v5 = v4;
  if ( v4 >= length )
    return FMOD_snprintf(buffer, length, "%s", arg);
  memcpy_0(buffer, arg, v4 + 1);
  return v5;
}


// Address: 0x22366b0 | Name: _ZN4FMOD14FMOD_FormatArgEPcib
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, bool arg)
{
  const char *v3; // rax

  v3 = "true";
  if ( !arg )
    v3 = "false";
  return FMOD::FMOD_FormatArg(buffer, length, v3);
}


// Address: 0x22366d0 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKii
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const int *arg, int count)
{
  int result; // eax
  int v5; // r8d
  int *v8; // r12
  int v9; // r13d
  int v10; // edx

  result = 0;
  if ( length > 0 )
  {
    *buffer = 123;
    if ( length > 1 && count )
    {
      v5 = FMOD::FMOD_FormatArg(buffer + 1, length - 1, *arg) + 1;
      if ( length > v5 && count > 1 )
      {
        v8 = (int *)(arg + 1);
        v9 = 1;
        do
        {
          buffer[v5] = 44;
          v10 = *v8;
          ++v9;
          ++v8;
          v5 += 1 + FMOD::FMOD_FormatArg(&buffer[v5 + 1], length - (v5 + 1), v10);
          if ( length <= v5 )
            return v5;
        }
        while ( count > v9 );
      }
    }
    else
    {
      v5 = 1;
    }
    if ( length <= v5 )
      return v5;
    result = v5 + 1;
    buffer[v5] = 125;
  }
  return result;
}


// Address: 0x22367b0 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKji
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const unsigned int *arg, int count)
{
  int result; // eax
  int v5; // r8d
  unsigned int *v8; // r12
  int v9; // r13d
  unsigned int v10; // edx

  result = 0;
  if ( length > 0 )
  {
    *buffer = 123;
    if ( length > 1 && count )
    {
      v5 = FMOD::FMOD_FormatArg(buffer + 1, length - 1, *arg) + 1;
      if ( length > v5 && count > 1 )
      {
        v8 = (unsigned int *)(arg + 1);
        v9 = 1;
        do
        {
          buffer[v5] = 44;
          v10 = *v8;
          ++v9;
          ++v8;
          v5 += 1 + FMOD::FMOD_FormatArg(&buffer[v5 + 1], length - (v5 + 1), v10);
          if ( length <= v5 )
            return v5;
        }
        while ( count > v9 );
      }
    }
    else
    {
      v5 = 1;
    }
    if ( length <= v5 )
      return v5;
    result = v5 + 1;
    buffer[v5] = 125;
  }
  return result;
}


// Address: 0x2236890 | Name: _ZN4FMOD14FMOD_FormatArgEPciPKfi
int __fastcall FMOD::FMOD_FormatArg(char *buffer, int length, const float *arg, int count)
{
  float v4; // xmm1_4
  int result; // eax
  int v6; // r8d
  int v8; // r13d
  const float *v9; // r12

  result = 0;
  if ( length > 0 )
  {
    *buffer = 123;
    if ( length > 1 && count )
    {
      v6 = FMOD::FMOD_FormatArg(buffer + 1, length - 1, (__m128i)*(unsigned int *)arg, v4) + 1;
      if ( length > v6 && count > 1 )
      {
        v8 = 1;
        v9 = arg + 1;
        do
        {
          buffer[v6] = 44;
          ++v8;
          v6 += 1 + FMOD::FMOD_FormatArg(&buffer[v6 + 1], length - (v6 + 1), (__m128i)*((unsigned int *)++v9 - 1), v4);
          if ( length <= v6 )
            return v6;
        }
        while ( count > v8 );
      }
    }
    else
    {
      v6 = 1;
    }
    if ( length <= v6 )
      return v6;
    result = v6 + 1;
    buffer[v6] = 125;
  }
  return result;
}


