// Address: 0x22544d0 | Name: _Z13FMOD_Net_Initv
FMOD_RESULT_0 __cdecl FMOD_Net_Init()
{
  FMOD_RESULT_0 result; // eax

  if ( FMOD_Net_RefCount )
  {
    ++FMOD_Net_RefCount;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    result = FMOD_OS_Net_Init();
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      ++FMOD_Net_RefCount;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2254520 | Name: _Z17FMOD_Net_Shutdownv
FMOD_RESULT_0 __cdecl FMOD_Net_Shutdown()
{
  if ( --FMOD_Net_RefCount )
    return FMOD_RESULT::FMOD_OK_0;
  else
    return FMOD_OS_Net_Shutdown();
}


// Address: 0x2254540 | Name: _Z24FMOD_Net_ParseHTTPStatusPciPiS0_
FMOD_RESULT_0 __fastcall FMOD_Net_ParseHTTPStatus(char *buf, int buflen, int *version, int *statuscode)
{
  char *v6; // rax
  int v7; // ebx
  char *v8; // r8
  __int64 v10; // r13
  int v11; // eax
  int v12; // edx
  char *v13; // rdi
  char *v14; // rax
  char *v15; // rcx
  char *v16; // rdx
  int *v17; // [rsp+8h] [rbp-40h]

  if ( buflen <= 0 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (*buf & 0xDF) != 0 )
  {
    v6 = buf + 1;
    v7 = 0;
    while ( ++v7 != buflen )
    {
      v8 = v6++;
      if ( (*v8 & 0xDF) == 0 )
        goto LABEL_8;
    }
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  v8 = buf;
  v7 = 0;
LABEL_8:
  *v8 = 0;
  v10 = 0;
  while ( 1 )
  {
    v17 = version;
    v11 = FMOD_strcmp(buf, FMOD_Net_VersionString[v10]);
    version = v17;
    if ( !v11 )
      break;
    if ( ++v10 == 3 )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  *v17 = v10;
  v12 = v7 + 1;
  if ( buflen <= v7 + 1 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v13 = &buf[v12];
  if ( (*v13 & 0xDF) != 0 )
  {
    v14 = &buf[v12 + 1];
    v15 = &v14[buflen - 2 - v7];
    while ( v14 != v15 )
    {
      v16 = v14++;
      if ( (*v16 & 0xDF) == 0 )
        goto LABEL_17;
    }
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  v16 = &buf[v12];
LABEL_17:
  *v16 = 0;
  *statuscode = strtol(v13, 0, 10);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2254640 | Name: _Z21FMOD_Net_EncodeBase64PcS_i
FMOD_RESULT_0 __fastcall FMOD_Net_EncodeBase64(char *inbuf, char *outbuf, int outbuflen)
{
  int v4; // r9d
  int v5; // eax
  int v6; // r8d
  int v7; // ecx
  int v8; // ecx
  int v9; // r8d
  int v10; // r8d
  int v11; // r10d
  int v12; // eax

  if ( !inbuf || !outbuf )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v4 = 0;
  v5 = 0;
  v6 = 0;
  while ( 1 )
  {
    v7 = (unsigned __int8)*inbuf++;
    if ( !*(inbuf - 1) )
      break;
    while ( 1 )
    {
      v8 = v6 + v7;
      ++v5;
      v6 = v8 << 8;
      if ( v5 != 3 )
        break;
      if ( v4 == outbuflen )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      outbuf[v4] = base64_code[v8 >> 18];
      if ( v4 + 1 == outbuflen )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      outbuf[v4 + 1] = base64_code[(v8 >> 12) & 0x3F];
      if ( v4 + 2 == outbuflen )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      v9 = v4 + 3;
      outbuf[v4 + 2] = base64_code[(v8 >> 6) & 0x3F];
      if ( v4 + 3 == outbuflen )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      ++inbuf;
      v4 += 4;
      outbuf[v9] = base64_code[v8 & 0x3F];
      v7 = (unsigned __int8)*(inbuf - 1);
      v5 = 0;
      v6 = 0;
      if ( !*(inbuf - 1) )
        goto LABEL_12;
    }
  }
LABEL_12:
  if ( v5 )
  {
    if ( v4 == outbuflen )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    v10 = v6 << (8 * (2 - v5));
    outbuf[v4] = base64_code[v10 >> 18];
    if ( v4 + 1 == outbuflen )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    v11 = v4 + 2;
    outbuf[v4 + 1] = base64_code[(v10 >> 12) & 0x3F];
    if ( v5 == 1 )
    {
      if ( v11 == outbuflen )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      v12 = v4 + 3;
      outbuf[v11] = 61;
      if ( v4 + 3 == outbuflen )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
    else
    {
      if ( v11 == outbuflen )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      v12 = v4 + 3;
      outbuf[v11] = base64_code[(v10 >> 6) & 0x3F];
      if ( v4 + 3 == outbuflen )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
    v4 += 4;
    outbuf[v12] = 61;
  }
  if ( v4 == outbuflen )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  outbuf[v4] = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22547f0 | Name: _Z17FMOD_Net_SetProxyPKc
FMOD_RESULT_0 __fastcall FMOD_Net_SetProxy(const char *proxy)
{
  int v1; // eax
  FMOD_RESULT_0 v2; // edx
  char *v4; // r15
  char *v5; // rax
  char *v6; // rbx
  FMOD_RESULT_0 v7; // eax
  const char *v8; // rbx
  int v9; // r12d
  char *v10; // rax
  FMOD_RESULT_0 result; // [rsp+Ch] [rbp-103Ch]
  char buf[4152]; // [rsp+10h] [rbp-1038h] BYREF

  if ( FMOD_Net_ProxyString )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, FMOD_Net_ProxyString, "../../../core_api/src/fmod_net.cpp", 214);
    FMOD_Net_ProxyString = 0;
  }
  if ( FMOD_Net_ProxyHostname )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, FMOD_Net_ProxyHostname, "../../../core_api/src/fmod_net.cpp", 220);
    FMOD_Net_ProxyHostname = 0;
  }
  if ( FMOD_Net_ProxyAuth )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, FMOD_Net_ProxyAuth, "../../../core_api/src/fmod_net.cpp", 226);
    FMOD_Net_ProxyAuth = 0;
  }
  FMOD_Net_ProxyPort = 0;
  v1 = FMOD_strlen(proxy);
  v2 = FMOD_RESULT::FMOD_OK_0;
  if ( v1 )
  {
    v4 = FMOD_strdup(proxy);
    if ( v4 )
    {
      FMOD_Net_ProxyString = FMOD_strdup(proxy);
      if ( FMOD_Net_ProxyString )
      {
        v5 = FMOD_strstr(v4, "@");
        v6 = v5;
        if ( v5 )
        {
          *v5 = 0;
          v7 = FMOD_Net_EncodeBase64(v4, buf, 4095);
          if ( v7 )
          {
            result = v7;
            FMOD::MemPool::free(off_286F358->gSystemMemPool, v4, "../../../core_api/src/fmod_net.cpp", 274);
            return result;
          }
          FMOD_Net_ProxyAuth = FMOD_strdup(buf);
          if ( !FMOD_Net_ProxyAuth )
            return FMOD_RESULT::FMOD_ERR_MEMORY_0;
          v8 = v6 + 1;
        }
        else
        {
          v8 = v4;
        }
        v9 = 80;
        v10 = FMOD_strstr(v8, ":");
        if ( v10 )
        {
          *v10 = 0;
          v9 = strtol(v10 + 1, 0, 10);
        }
        FMOD_Net_ProxyHostname = FMOD_strdup(v8);
        if ( FMOD_Net_ProxyHostname )
        {
          FMOD_Net_ProxyPort = v9;
          FMOD::MemPool::free(off_286F358->gSystemMemPool, v4, "../../../core_api/src/fmod_net.cpp", 305);
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
  return v2;
}


// Address: 0x2254a20 | Name: _Z17FMOD_Net_GetProxyPci
FMOD_RESULT_0 __fastcall FMOD_Net_GetProxy(char *proxy, int proxylen)
{
  if ( proxy && proxylen )
  {
    if ( FMOD_Net_ProxyString )
    {
      FMOD_strcpy_safe(proxy, FMOD_Net_ProxyString, proxylen);
      return FMOD_RESULT::FMOD_OK_0;
    }
    *proxy = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2254a60 | Name: _Z19FMOD_Net_SetTimeouti
FMOD_RESULT_0 __fastcall FMOD_Net_SetTimeout(int timeout)
{
  FMOD_Net_Timeout = timeout;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2254a70 | Name: _Z19FMOD_Net_GetTimeoutPi
FMOD_RESULT_0 __fastcall FMOD_Net_GetTimeout(int *timeout)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( timeout )
  {
    *timeout = FMOD_Net_Timeout;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2254a90 | Name: _Z13FMOD_Net_ReadPKvPcj
FMOD_RESULT_0 __fastcall FMOD_Net_Read(const void *handle, char *buf, unsigned int len)
{
  FMOD_RESULT_0 result; // eax
  unsigned int bytesread[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  while ( 1 )
  {
    bytesread[0] = 0;
    result = FMOD_OS_Net_Read(handle, buf, len, bytesread);
    if ( result != FMOD_RESULT::FMOD_ERR_NET_WOULD_BLOCK_0 )
      break;
    len -= bytesread[0];
    buf += bytesread[0];
    FMOD_OS_Time_Sleep(1u);
  }
  return result;
}


// Address: 0x2254af0 | Name: _Z17FMOD_Net_ReadLinePKvPcj
FMOD_RESULT_0 __fastcall FMOD_Net_ReadLine(const void *handle, char *buf, unsigned int len)
{
  FMOD_RESULT_0 result; // eax
  unsigned int v4; // r14d
  __int64 v5; // rbx
  __int64 v6; // rdx
  char ch_0[41]; // [rsp+Fh] [rbp-29h] BYREF

  if ( !buf || !len )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *buf = 0;
  v4 = len - 1;
  if ( len == 1 )
  {
    v5 = 0;
LABEL_12:
    buf[v5] = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    v5 = 0;
    while ( 1 )
    {
      ch_0[0] = 0;
      result = FMOD_Net_Read(handle, ch_0, 1u);
      if ( result )
        break;
      if ( ch_0[0] != 10 )
      {
        if ( ch_0[0] != 13 )
        {
          v6 = (unsigned int)v5;
          v5 = (unsigned int)(v5 + 1);
          buf[v6] = ch_0[0];
        }
        if ( (unsigned int)v5 < v4 )
          continue;
      }
      goto LABEL_12;
    }
  }
  return result;
}


