// Address: 0x21ecd80 | Name: _ZN4FMOD7SystemI14getOrCreateFFTEiPPNS_3FFTE
FMOD_RESULT_0 __fastcall FMOD::SystemI::getOrCreateFFT(FMOD::SystemI *const this, int size, FMOD::FFT **fft)
{
  FMOD_RESULT_0 v3; // r13d
  char v5; // r14
  FMOD::FFT *mNodeNext; // rax
  FMOD::FFT *i; // r12
  FMOD::FFT *v9; // rax
  FMOD::FFT *v10; // rax
  FMOD::LinkedListNode *v11; // rdx

  v3 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !fft )
    return v3;
  if ( this )
  {
    v5 = 1;
    FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_FFTLIST);
  }
  else
  {
    v5 = 0;
  }
  mNodeNext = (FMOD::FFT *)this->mFFTHead.mNodeNext;
  for ( i = &this->mFFTHead; mNodeNext != i; mNodeNext = (FMOD::FFT *)mNodeNext->mNodeNext )
  {
    *fft = mNodeNext;
    if ( size == mNodeNext->mSize )
      goto LABEL_8;
  }
  v3 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v9 = (FMOD::FFT *)FMOD::MemPool::calloc(
                      off_286F358->gSystemMemPool,
                      88,
                      "../../../core_api/src/fmod_systemi_fft.cpp",
                      92,
                      0);
  *fft = v9;
  if ( v9 )
  {
    v3 = FMOD::FFT::init(v9, size);
    if ( v3 == FMOD_RESULT::FMOD_OK_0 )
    {
      v10 = *fft;
      v11 = this->mFFTHead.mNodeNext;
      v10->mNodePrev = i;
      v10->mNodeNext = v11;
      v11->mNodePrev = v10;
      v10->mNodePrev->FMOD::LinkedListNode::mNodeNext = v10;
LABEL_8:
      v3 = FMOD_RESULT::FMOD_OK_0;
      goto LABEL_9;
    }
    FMOD::FFT::release(*fft);
    *fft = 0;
  }
LABEL_9:
  if ( v5 )
    FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_FFTLIST);
  return v3;
}


// Address: 0x21ecea0 | Name: _ZN4FMOD7SystemI14performRealFFTEiPKfP12FMOD_COMPLEXS2_i
FMOD_RESULT_0 __fastcall FMOD::SystemI::performRealFFT(
        FMOD::SystemI *const this,
        int size,
        const float *signal,
        FMOD_COMPLEX *dft,
        const float *window,
        int signalhop)
{
  FMOD_RESULT_0 result; // eax
  FMOD::FFT *fft; // [rsp+18h] [rbp-20h] BYREF

  if ( !signal || !dft )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  result = FMOD::SystemI::getOrCreateFFT(this, size, &fft);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::FFT::realDFT(fft, signal, dft, window, signalhop);
  return result;
}


// Address: 0x21ecf00 | Name: _ZN4FMOD7SystemI7realFFTEP14FMOD_DSP_STATEiPKfP12FMOD_COMPLEXS4_i
FMOD_RESULT_0 __fastcall FMOD::SystemI::realFFT(
        FMOD_DSP_STATE *dsp_state,
        int size,
        const float *signal,
        FMOD_COMPLEX *dft,
        const float *window,
        int signalhop)
{
  if ( dsp_state )
    return FMOD::SystemI::performRealFFT(
             *((FMOD::SystemI *const *)dsp_state->instance + 22),
             size,
             signal,
             dft,
             window,
             signalhop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21ecf20 | Name: _ZN4FMOD7SystemI21performRealInverseFFTEiPK12FMOD_COMPLEXPfPKfi
FMOD_RESULT_0 __fastcall FMOD::SystemI::performRealInverseFFT(
        FMOD::SystemI *const this,
        int size,
        const FMOD_COMPLEX *dft,
        float *signal,
        const float *window,
        int signalhop)
{
  FMOD_RESULT_0 result; // eax
  FMOD::FFT *fft; // [rsp+18h] [rbp-20h] BYREF

  if ( !signal || !dft )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  result = FMOD::SystemI::getOrCreateFFT(this, size, &fft);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::FFT::realInverseDFT(fft, dft, signal, window, signalhop);
  return result;
}


// Address: 0x21ecf80 | Name: _ZN4FMOD7SystemI14realInverseFFTEP14FMOD_DSP_STATEiPK12FMOD_COMPLEXPfPKfi
FMOD_RESULT_0 __fastcall FMOD::SystemI::realInverseFFT(
        FMOD_DSP_STATE *dsp_state,
        int size,
        const FMOD_COMPLEX *dft,
        float *signal,
        const float *window,
        int signalhop)
{
  if ( dsp_state )
    return FMOD::SystemI::performRealInverseFFT(
             *((FMOD::SystemI *const *)dsp_state->instance + 22),
             size,
             dft,
             signal,
             window,
             signalhop);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


