// Address: 0x24d15b0 | Name: vorbis_lpc_from_data
float __fastcall vorbis_lpc_from_data(float *data, float *lpci, int n, int m)
{
  __int64 v5; // r8
  __int64 v7; // rax
  void *v8; // rsp
  void *v9; // rsp
  int v10; // esi
  int v11; // r10d
  float v12; // xmm1_4
  float *v13; // rax
  float v14; // xmm0_4
  float result; // xmm0_4
  float v16; // xmm4_4
  float v17; // xmm3_4
  float *v18; // r10
  float *v19; // r9
  __int64 v20; // r8
  __int64 v21; // rax
  int v22; // esi
  float v23; // xmm3_4
  int v24; // ecx
  float *v25; // rdx
  float *v26; // rax
  float v27; // xmm2_4
  float v28; // xmm1_4
  float *v29; // rdx
  __int64 v30; // rax
  float v31; // xmm1_4
  float v32; // xmm1_4
  __int64 v33; // rdi
  float v34; // xmm1_4
  float *v35; // rax
  float v36; // xmm2_4
  float v37; // xmm2_4
  __int64 v38; // rax
  float v39; // [rsp+0h] [rbp-30h] BYREF
  float v40[2]; // [rsp+4h] [rbp-2Ch] BYREF
  float error; // [rsp+Ch] [rbp-24h]

  v5 = m;
  v7 = 4LL * (m + 1);
  v8 = alloca(v7 + 15);
  v9 = alloca(v7 + 11);
  if ( m != -1 )
  {
    v10 = m;
    v11 = n - 1 - m;
    do
    {
      if ( n <= v10 )
      {
        v12 = 0.0;
      }
      else
      {
        v12 = 0.0;
        v13 = data;
        do
        {
          v14 = v13[v5];
          v12 = v12 + (float)(v14 * *v13++);
        }
        while ( v13 != &data[v11 + 1] );
      }
      --v10;
      v40[v5 - 1] = v12;
      ++v11;
      --v5;
    }
    while ( v10 != -1 );
  }
  result = v39;
  v16 = (float)(9.9999997e-10 * v39) + 1.0e-10;
  if ( m > 0 )
  {
    v17 = -v40[0];
    if ( v16 > v39 )
    {
      v33 = 0;
      v22 = 0;
LABEL_22:
      error = result;
      memset(&v40[v33 - 1], 0, 4LL * (m - v22));
      result = error;
    }
    else
    {
      v18 = &v39 - 1;
      v19 = v40;
      v20 = 1;
      v21 = 0;
      v22 = 0;
      while ( 1 )
      {
        v23 = v17 / result;
        v24 = v22 / 2;
        v40[v21 - 1] = v23;
        if ( v22 / 2 <= 0 )
        {
          v24 = 0;
        }
        else
        {
          v25 = &v39;
          v26 = v18;
          do
          {
            v27 = *v26;
            ++v25;
            --v26;
            v28 = *(v25 - 1);
            *(v25 - 1) = (float)(v27 * v23) + v28;
            v26[1] = (float)(v28 * v23) + v26[1];
          }
          while ( v25 != &v40[v24 - 1] );
        }
        if ( (v22 & 1) != 0 )
          v40[v24 - 1] = (float)(v40[v24 - 1] * v23) + v40[v24 - 1];
        ++v22;
        result = result * (float)(1.0 - (float)(v23 * v23));
        if ( v22 == m )
          break;
        v17 = -v19[1];
        if ( v16 > result )
        {
          v33 = v20;
          goto LABEL_22;
        }
        if ( v22 > 0 )
        {
          v29 = v19;
          v30 = 0;
          do
          {
            v31 = v40[v30++ - 1];
            v32 = v31 * *v29--;
            v17 = v17 - v32;
          }
          while ( v30 != v20 );
        }
        v21 = v20;
        ++v18;
        ++v19;
        ++v20;
      }
    }
    v34 = 0.99000001;
    v35 = &v39;
    do
    {
      v36 = *v35++;
      v37 = v36 * v34;
      v34 = v34 * 0.99000001;
      *(v35 - 1) = v37;
    }
    while ( v35 != &v40[m - 1] );
    v38 = 0;
    do
    {
      lpci[v38] = v40[v38 - 1];
      ++v38;
    }
    while ( m > (int)v38 );
  }
  return result;
}


// Address: 0x24d1840 | Name: vorbis_lpc_predict
void __fastcall vorbis_lpc_predict(float *coeff, float *prime, int m, float *data, ogg_int32_t n)
{
  void *v5; // rsp
  __int64 i; // rax
  _DWORD *v7; // r9
  float *v8; // r11
  __int64 v9; // rdi
  int v10; // eax
  float v11; // xmm1_4
  float *v12; // rsi
  __int64 v13; // rax
  float v14; // xmm0_4
  float v15; // xmm0_4
  __int64 v16; // rax
  _DWORD v17[2]; // [rsp+0h] [rbp-8h] BYREF

  v5 = alloca(4LL * (m + n) + 15);
  if ( prime )
  {
    for ( i = 0; m > (int)i; ++i )
      v17[i] = LODWORD(prime[i]);
  }
  else if ( m > 0 )
  {
    v16 = 0;
    do
      v17[v16++] = 0;
    while ( m > (int)v16 );
  }
  if ( n > 0 )
  {
    v7 = v17;
    v8 = &coeff[m - 1];
    v9 = 0;
    do
    {
      v10 = v9;
      if ( m <= 0 )
      {
        v11 = 0.0;
      }
      else
      {
        v11 = 0.0;
        v12 = v8;
        v13 = 0;
        do
        {
          v14 = *(float *)&v7[v13++];
          v15 = v14 * *v12--;
          v11 = v11 - v15;
        }
        while ( m > (int)v13 );
        v10 = m + v9;
      }
      data[v9++] = v11;
      ++v7;
      *(float *)&v17[v10] = v11;
    }
    while ( n > (int)v9 );
  }
}


