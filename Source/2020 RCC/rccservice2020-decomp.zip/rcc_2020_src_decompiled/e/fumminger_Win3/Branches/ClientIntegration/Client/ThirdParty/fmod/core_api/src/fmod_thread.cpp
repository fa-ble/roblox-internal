// Address: 0x21dea10 | Name: _ZN4FMOD6Thread8callbackEPv
void __fastcall FMOD::Thread::callback(void *data)
{
  __int64 v2; // rax
  __int64 v3; // rdx
  FMOD_OS_SEMAPHORE *v4; // rdi
  FMOD_OS_SEMAPHORE *v5; // rdi
  void (__fastcall *v6)(_QWORD); // rax
  unsigned int v7; // edi
  __int64 v8; // rax
  __int64 v9; // rdx

  FMOD_OS_Thread_GetCurrentID((FMOD_UINT_NATIVE *)data + 34);
  v2 = *((_QWORD *)data + 39);
  if ( v2 )
  {
    v3 = *((int *)data + 80);
    if ( (_DWORD)v3 )
      *(_QWORD *)(v2 + 8 * v3 + 16) = *((_QWORD *)data + 34);
  }
  v4 = (FMOD_OS_SEMAPHORE *)*((_QWORD *)data + 38);
  *((_BYTE *)data + 280) = 1;
  FMOD_OS_Semaphore_Signal(v4);
  while ( *((_BYTE *)data + 280) )
  {
    v5 = (FMOD_OS_SEMAPHORE *)*((_QWORD *)data + 37);
    if ( v5 )
      FMOD_OS_Semaphore_Wait(v5);
    if ( !*((_BYTE *)data + 280) )
      goto LABEL_5;
    v6 = (void (__fastcall *)(_QWORD))*((_QWORD *)data + 41);
    if ( v6 )
      v6(*((_QWORD *)data + 36));
    else
      (**(void (__fastcall ***)(void *))data)(data);
    v7 = *((_DWORD *)data + 71);
    if ( v7 )
    {
      FMOD_OS_Time_Sleep(v7);
      if ( !*((_BYTE *)data + 281) )
        break;
    }
    else
    {
LABEL_5:
      if ( !*((_BYTE *)data + 281) )
        break;
    }
  }
  v8 = *((_QWORD *)data + 39);
  if ( v8 )
  {
    v9 = *((int *)data + 80);
    if ( (_DWORD)v9 )
      *(_QWORD *)(v8 + 8 * v9 + 16) = 0;
  }
  FMOD_OS_Semaphore_Signal(*((FMOD_OS_SEMAPHORE **)data + 38));
}


// Address: 0x21deb10 | Name: _ZN4FMOD6ThreadC2Ev
void __fastcall FMOD::Thread::Thread(FMOD::Thread *const this)
{
  this->mHandle = 0;
  this->mThreadID = 0;
  this->mRunning = 0;
  this->mUserData = 0;
  this->mSema = 0;
  this->mControlSema = 0;
  this->mPeriod = 0;
  this->_vptr_Thread = (int (**)(...))&off_29B0E30;
  this->mUserCallback = 0;
  this->mType = FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_GENERIC;
  this->mThreadSystem = 0;
  this->mLooping = 0;
}


// Address: 0x21deb90 | Name: _ZN4FMOD6Thread10initThreadEPKcPFvPvES3_NS_16FMOD_THREAD_TYPEE20FMOD_THREAD_PRIORITYibiPNS_7SystemIEb
FMOD_RESULT_0 __fastcall FMOD::Thread::initThread(
        FMOD::Thread *const this,
        const char *name,
        void (*func)(void *),
        void *userdata,
        FMOD::FMOD_THREAD_TYPE type,
        FMOD_THREAD_PRIORITY priority,
        int stacksize,
        bool usesemaphore,
        int sleepperiod,
        FMOD::SystemI *system,
        bool looping)
{
  FMOD_OS_SEMAPHORE **p_mControlSema; // rdi
  FMOD_RESULT_0 v14; // ebp
  FMOD::SystemI *mThreadSystem; // rdi
  void (__fastcall *v17)(FMOD::SystemI *, __int64, void *, char *, _QWORD); // rax
  FMOD_SYSTEM_CALLBACK gSystemCallback; // r9

  this->mUserCallback = func;
  p_mControlSema = &this->mControlSema;
  *(p_mControlSema - 2) = (FMOD_OS_SEMAPHORE *)userdata;
  *((_BYTE *)p_mControlSema - 23) = looping;
  *((_BYTE *)p_mControlSema - 24) = 0;
  *((_DWORD *)p_mControlSema + 4) = type;
  *((_DWORD *)p_mControlSema - 5) = sleepperiod;
  p_mControlSema[1] = (FMOD_OS_SEMAPHORE *)system;
  v14 = FMOD_OS_Semaphore_Create(p_mControlSema);
  if ( v14 == FMOD_RESULT::FMOD_OK_0
    && (!usesemaphore || (v14 = FMOD_OS_Semaphore_Create(&this->mSema)) == FMOD_RESULT::FMOD_OK_0) )
  {
    FMOD_strcpy_safe(this->mName, name, 256);
    v14 = FMOD_OS_Thread_Create(this->mName, FMOD::Thread::callback, this, priority, stacksize, &this->mHandle);
    if ( v14 == FMOD_RESULT::FMOD_OK_0 )
    {
      v14 = FMOD_OS_Semaphore_Wait(this->mControlSema);
      if ( v14 == FMOD_RESULT::FMOD_OK_0 )
      {
        mThreadSystem = this->mThreadSystem;
        if ( mThreadSystem )
        {
          v17 = *(void (__fastcall **)(FMOD::SystemI *, __int64, void *, char *, _QWORD))((char *)&stru_11748.r_offset
                                                                                        + (_QWORD)mThreadSystem);
          if ( v17 && (mThreadSystem->mCallbackMask & 8) != 0 )
            v17(
              mThreadSystem,
              8,
              this->mHandle,
              this->mName,
              *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)mThreadSystem));
        }
        else
        {
          gSystemCallback = off_286F358->gSystemCallback;
          if ( gSystemCallback && (off_286F358->gSystemCallbackMask & 8) != 0 )
            gSystemCallback(0, 8, this->mHandle, this->mName, off_286F358->gSystemUserData);
        }
      }
    }
  }
  return v14;
}


// Address: 0x21decd0 | Name: _ZN4FMOD6Thread11closeThreadEv
FMOD_RESULT_0 __fastcall FMOD::Thread::closeThread(FMOD::Thread *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD_OS_SEMAPHORE *mSema; // rdi
  FMOD_OS_SEMAPHORE *v4; // rdi
  void *mHandle; // rdi
  FMOD::SystemI *mThreadSystem; // rdi
  void (__fastcall *v7)(FMOD::SystemI *, __int64, void *, char *, _QWORD); // rax
  FMOD_SYSTEM_CALLBACK gSystemCallback; // r9

  result = FMOD_RESULT::FMOD_OK_0;
  if ( this->mRunning )
  {
    if ( this->mLooping )
      this->mRunning = 0;
    mSema = this->mSema;
    if ( !mSema || (result = FMOD_OS_Semaphore_Signal(mSema)) == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD_OS_Semaphore_Wait(this->mControlSema);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v4 = this->mSema;
        if ( v4 )
        {
          result = FMOD_OS_Semaphore_Free(v4);
          if ( result )
            return result;
          this->mSema = 0;
        }
        result = FMOD_OS_Semaphore_Free(this->mControlSema);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          mHandle = this->mHandle;
          this->mControlSema = 0;
          result = FMOD_OS_Thread_Destroy(mHandle);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            mThreadSystem = this->mThreadSystem;
            if ( mThreadSystem )
            {
              v7 = *(void (__fastcall **)(FMOD::SystemI *, __int64, void *, char *, _QWORD))((char *)&stru_11748.r_offset
                                                                                           + (_QWORD)mThreadSystem);
              if ( v7 )
              {
                if ( (mThreadSystem->mCallbackMask & 0x200) != 0 )
                  v7(
                    mThreadSystem,
                    512,
                    this->mHandle,
                    this->mName,
                    *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)mThreadSystem));
              }
            }
            else
            {
              gSystemCallback = off_286F358->gSystemCallback;
              if ( gSystemCallback && (off_286F358->gSystemCallbackMask & 0x200) != 0 )
                gSystemCallback(0, 512, this->mHandle, this->mName, off_286F358->gSystemUserData);
            }
            this->mHandle = 0;
            this->mThreadID = 0;
            return FMOD_RESULT::FMOD_OK_0;
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21dee10 | Name: _ZN4FMOD6Thread22isCurrentThreadInTableEPKy
bool __fastcall FMOD::Thread::isCurrentThreadInTable(const FMOD_UINT_NATIVE *threadTable)
{
  __int64 v1; // rax
  __int64 v2; // rax
  FMOD_UINT_NATIVE id[2]; // [rsp+8h] [rbp-10h] BYREF

  FMOD_OS_Thread_GetCurrentID(id);
  v1 = 0;
  while ( threadTable[v1 + 1] != id[0] )
  {
    if ( ++v1 == 6 )
    {
      if ( off_286F358->gFileThreadId != id[0] )
      {
        v2 = 0;
        while ( off_286F358->gAsyncThreadId[v2] != id[0] )
        {
          if ( ++v2 == 5 )
            return 0;
        }
      }
      return 1;
    }
  }
  return 1;
}


