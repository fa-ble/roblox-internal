// Address: 0x225d000 | Name: FMOD::matrixMult
void __fastcall FMOD::matrixMult(float (*matrix)[4], const FMOD_VECTOR *src, FMOD_VECTOR *dst)
{
  float y; // xmm3_4
  float z; // xmm2_4
  float x; // xmm0_4

  y = src->y;
  z = src->z;
  dst->x = (float)((float)((*matrix)[0] * src->x) + (float)((*matrix)[1] * y)) + (float)((*matrix)[2] * z);
  x = src->x;
  dst->y = (float)((float)((*matrix)[4] * src->x) + (float)(y * (*matrix)[5])) + (float)((*matrix)[6] * z);
  dst->z = (float)((float)(x * (*matrix)[8]) + (float)((*matrix)[9] * src->y)) + (float)(z * (*matrix)[10]);
}


// Address: 0x225d080 | Name: _ZN4FMOD9GeometryI22octreeLineTestCallbackEPNS_10OctreeNodeEPv
bool __fastcall FMOD::GeometryI::octreeLineTestCallback(FMOD::OctreeNode *item, void *data)
{
  float v2; // xmm4_4
  float v3; // xmm3_4
  float v4; // xmm11_4
  float v5; // xmm10_4
  float v6; // xmm9_4
  float xMin; // xmm2_4
  float v8; // xmm1_4
  float v9; // xmm0_4
  int flags; // r8d
  int v11; // r9d
  float *p_splitLevel; // rax
  float v13; // xmm1_4
  float v14; // xmm11_4
  float v15; // xmm10_4
  float v16; // xmm9_4
  char *v17; // rdx
  float v18; // xmm0_4
  float *v19; // rdx
  float v20; // xmm13_4
  float v22; // xmm0_4
  float v23; // xmm1_4
  float v24; // xmm2_4

  v2 = *((float *)data + 1);
  v3 = *((float *)data + 2);
  v4 = *((float *)data + 3);
  v5 = *((float *)data + 4);
  v6 = *((float *)data + 5);
  xMin = item[2].aabb.xMin;
  v8 = (float)((float)((float)(item[2].aabb.xMax * *(float *)data) + (float)(item[2].aabb.yMin * v2))
             + (float)(item[2].aabb.yMax * v3))
     - xMin;
  v9 = (float)((float)((float)(item[2].aabb.xMax * v4) + (float)(item[2].aabb.yMin * v5))
             + (float)(item[2].aabb.yMax * v6))
     - xMin;
  if ( v9 >= 0.0 && v8 >= 0.0 )
    return 1;
  if ( v9 > 0.0 || v8 > 0.0 )
  {
    flags = item[2].flags;
    if ( v8 <= 0.0 || (flags & 0x10000) != 0 )
    {
      v11 = 0;
      p_splitLevel = (float *)&item[2].splitLevel;
      v13 = v8 / (float)(v8 - v9);
      v14 = (float)((float)(v4 - *(float *)data) * v13) + *(float *)data;
      v15 = (float)((float)(v5 - v2) * v13) + v2;
      v16 = (float)((float)(v6 - v3) * v13) + v3;
      while ( v11 < (unsigned __int16)flags )
      {
        v17 = 0;
        v18 = *p_splitLevel;
        if ( v11 + 1 < (unsigned __int16)flags )
          v17 = (char *)p_splitLevel + 12LL - ((_QWORD)item + 188);
        p_splitLevel += 3;
        v19 = (float *)&v17[(_QWORD)item + 188];
        v20 = *(p_splitLevel - 2);
        if ( (float)((float)((float)((float)(v14 - v18)
                                   * (float)((float)(item[2].aabb.yMax * (float)(v19[1] - v20))
                                           - (float)(item[2].aabb.yMin * (float)(v19[2] - *(p_splitLevel - 1)))))
                           + (float)((float)(v15 - v20)
                                   * (float)((float)((float)(v19[2] - *(p_splitLevel - 1)) * item[2].aabb.xMax)
                                           - (float)(item[2].aabb.yMax * (float)(*v19 - v18)))))
                   + (float)((float)(v16 - *(p_splitLevel - 1))
                           * (float)((float)((float)(*v19 - v18) * item[2].aabb.yMin)
                                   - (float)((float)(v19[1] - v20) * item[2].aabb.xMax)))) > 0.0 )
          break;
        ++v11;
      }
      if ( v11 == (unsigned __int16)flags )
      {
        if ( (*(_BYTE *)(**(_QWORD **)(*((_QWORD *)data + 4) + 24LL) + 74LL) & 4) != 0 )
        {
          v22 = *((float *)data + 6);
          v23 = 1.0 - item[2].aabb.zMin;
          v24 = 1.0 - item[2].aabb.zMax;
          if ( v22 > v23 || v23 == v22 && *((float *)data + 7) > v24 )
          {
            *((float *)data + 6) = v23;
            v22 = v23;
            *((float *)data + 7) = v24;
          }
        }
        else
        {
          v22 = (float)(1.0 - item[2].aabb.zMin) * *((float *)data + 6);
          *((float *)data + 7) = (float)(1.0 - item[2].aabb.zMax) * *((float *)data + 7);
          *((float *)data + 6) = v22;
        }
        if ( v22 < 0.050000001 )
          return *((float *)data + 7) >= 0.050000001;
      }
    }
  }
  return 1;
}


// Address: 0x225d340 | Name: _ZN4FMOD9GeometryI9countDataEPviPiS1_i
FMOD_RESULT_0 __fastcall FMOD::GeometryI::countData(
        void *fileData,
        int dataSize,
        int *fileDataIndex,
        void *liveData,
        int liveDataSize)
{
  *fileDataIndex += liveDataSize;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225d350 | Name: _ZN4FMOD9GeometryI8saveDataEPviPiS1_i
FMOD_RESULT_0 __fastcall FMOD::GeometryI::saveData(
        void *fileData,
        int dataSize,
        int *fileDataIndex,
        void *liveData,
        int liveDataSize)
{
  FMOD_RESULT_0 result; // eax
  __int64 v7; // rdx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v7 = *fileDataIndex;
  if ( (int)v7 + liveDataSize <= dataSize )
  {
    memcpy_0((char *)fileData + v7, liveData, liveDataSize);
    *fileDataIndex += liveDataSize;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225d3a0 | Name: _ZN4FMOD9GeometryI8loadDataEPviPiS1_i
FMOD_RESULT_0 __fastcall FMOD::GeometryI::loadData(
        void *fileData,
        int dataSize,
        int *fileDataIndex,
        void *liveData,
        int liveDataSize)
{
  FMOD_RESULT_0 result; // eax
  __int64 v7; // r9

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v7 = *fileDataIndex;
  if ( (int)v7 + liveDataSize <= dataSize )
  {
    memcpy_0(liveData, (char *)fileData + v7, liveDataSize);
    *fileDataIndex += liveDataSize;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225d3f0 | Name: _ZN4FMOD9GeometryI15calculateMatrixEv
void __fastcall FMOD::GeometryI::calculateMatrix(FMOD::GeometryI *const this)
{
  float x; // xmm11_4
  float y; // xmm2_4
  float z; // xmm9_4
  float v4; // xmm8_4
  float v5; // xmm1_4
  float v6; // xmm5_4
  float v7; // xmm7_4
  float v8; // xmm6_4
  float v9; // xmm0_4
  float v10; // xmm3_4
  float v11; // xmm4_4
  float v12; // xmm3_4

  x = this->mUp.x;
  y = this->mScale.y;
  z = this->mUp.z;
  v4 = this->mForward.x;
  v5 = this->mScale.z;
  v6 = this->mUp.y;
  v7 = this->mForward.y;
  this->mMatrix[1][0] = x * y;
  v8 = this->mForward.z;
  this->mMatrix[1][1] = y * v6;
  this->mInvMatrix[1][1] = v6 / y;
  this->mMatrix[1][2] = y * z;
  this->mInvMatrix[0][2] = v4 / v5;
  this->mMatrix[2][0] = v4 * v5;
  this->mMatrix[2][1] = v5 * v7;
  this->mMatrix[2][2] = v5 * v8;
  this->mInvMatrix[2][1] = z / y;
  v9 = this->mScale.x;
  v10 = (float)(v6 * v8) - (float)(z * v7);
  this->mInvMatrix[0][0] = v10 / v9;
  this->mMatrix[0][0] = v10 * v9;
  v11 = (float)(z * v4) - (float)(x * v8);
  this->mInvMatrix[2][2] = v8 / v5;
  this->mMatrix[0][1] = v9 * v11;
  this->mInvMatrix[1][0] = v11 / v9;
  v12 = (float)(x * v7) - (float)(v6 * v4);
  this->mInvMatrix[0][1] = x / y;
  this->mInvMatrix[1][2] = v7 / v5;
  this->mMatrix[0][2] = v9 * v12;
  this->mInvMatrix[2][0] = v12 / v9;
}


// Address: 0x225d580 | Name: _ZN4FMOD9GeometryI17updateSpatialDataEv
void __fastcall FMOD::GeometryI::updateSpatialData(FMOD::GeometryI *const this)
{
  float *v2; // rdi
  bool v3; // zf
  float v4; // xmm2_4
  FMOD::GeometryI::SpatialData *mSpatialData; // rsi
  float v6; // xmm6_4
  float v7; // xmm5_4
  float v8; // xmm4_4
  float v9; // xmm0_4
  FMOD::Octree *mMainOctree; // rdi
  float v11; // xmm1_4
  float v12; // xmm8_4
  float v13; // xmm7_4
  float v14; // xmm2_4
  float v15; // xmm0_4
  float v16; // xmm2_4
  float v17; // xmm1_4
  float v18; // xmm3_4
  float v19; // xmm0_4
  FMOD_VECTOR center; // [rsp+10h] [rbp-28h] BYREF
  FMOD_VECTOR newCenter; // [rsp+20h] [rbp-18h] BYREF

  v2 = this->mMatrix[0];
  center.x = (float)(*(v2 - 18) + *(v2 - 19)) * 0.5;
  center.y = (float)(*(v2 - 16) + *(v2 - 17)) * 0.5;
  center.z = (float)(*(v2 - 14) + *(v2 - 15)) * 0.5;
  FMOD::matrixMult((float (*)[4])v2, &center, &newCenter);
  v3 = !this->mActive;
  v4 = fabs(this->mMatrix[0][0]);
  mSpatialData = this->mSpatialData;
  v6 = (float)(this->mAABB.xMax - this->mAABB.xMin) * 0.5;
  v7 = (float)(this->mAABB.yMax - this->mAABB.yMin) * 0.5;
  v8 = (float)(this->mAABB.zMax - this->mAABB.zMin) * 0.5;
  v9 = fabs(this->mMatrix[1][0]);
  mMainOctree = this->mGeometryMgr->mMainOctree;
  v11 = fabs(this->mMatrix[0][1]);
  v12 = newCenter.y + this->mPosition.y;
  v13 = newCenter.z + this->mPosition.z;
  newCenter.x = newCenter.x + this->mPosition.x;
  v14 = (float)(v4 * v6) + (float)(v9 * v7);
  v15 = fabs(this->mMatrix[2][0]);
  newCenter.y = v12;
  newCenter.z = v13;
  v16 = v14 + (float)(v15 * v8);
  v17 = (float)((float)(v11 * v6) + (float)(fabs(this->mMatrix[1][1]) * v7)) + (float)(fabs(this->mMatrix[2][1]) * v8);
  v18 = newCenter.x + v16;
  v19 = (float)((float)(fabs(this->mMatrix[0][2]) * v6) + (float)(fabs(this->mMatrix[1][2]) * v7))
      + (float)(fabs(this->mMatrix[2][2]) * v8);
  mSpatialData->octreeNode.aabb.xMin = newCenter.x - v16;
  mSpatialData->octreeNode.aabb.xMax = v18;
  mSpatialData->octreeNode.aabb.yMin = v12 - v17;
  mSpatialData->octreeNode.aabb.yMax = v12 + v17;
  mSpatialData->octreeNode.aabb.zMax = v13 + v19;
  mSpatialData->octreeNode.aabb.zMin = v13 - v19;
  if ( v3 )
    FMOD::Octree::deleteItem(mMainOctree, &mSpatialData->octreeNode);
  else
    FMOD::Octree::updateItem(mMainOctree, &mSpatialData->octreeNode);
}


// Address: 0x225d780 | Name: _ZN4FMOD9GeometryI14setToBeUpdatedEv
void __fastcall FMOD::GeometryI::setToBeUpdated(FMOD::GeometryI *const this)
{
  bool v1; // zf
  FMOD::GeometryMgr *mGeometryMgr; // rax
  FMOD::GeometryI *mFirstUpdateItem; // rdx

  v1 = !this->mToBeUpdated;
  mGeometryMgr = this->mGeometryMgr;
  mGeometryMgr->mMoved = 1;
  if ( v1 )
  {
    mFirstUpdateItem = mGeometryMgr->mFirstUpdateItem;
    this->mToBeUpdated = 1;
    this->mNextUpdateItem = mFirstUpdateItem;
    mGeometryMgr->mFirstUpdateItem = this;
  }
}


// Address: 0x225d7b0 | Name: _ZN4FMOD9GeometryIC2EPNS_11GeometryMgrE
void __fastcall FMOD::GeometryI::GeometryI(FMOD::GeometryI *const this, FMOD::GeometryMgr *geometryMgr)
{
  float v2; // xmm1_4

  this->mNodePrev = this;
  this->mNodeNext = this;
  this->mNodeData = 0;
  FMOD::Octree::Octree(&this->mOctree, geometryMgr->mWorldSize, v2);
  this->mGeometryMgr = geometryMgr;
  this->mMaxNumVertices = 0;
  this->mForward.z = 1.0;
  this->mNumVertices = 0;
  this->mMaxNumPolygons = 0;
  this->mForward.x = 0.0;
  this->mNumPolygons = 0;
  this->mPolygonOffsets = 0;
  this->mForward.y = 0.0;
  this->mPolygonDataPos = 0;
  this->mUp.x = 0.0;
  this->mPolygonData = 0;
  this->mUp.y = 1.0;
  this->mUp.z = 0.0;
  this->mPosition.x = 0.0;
  this->mPosition.y = 0.0;
  this->mPosition.z = 0.0;
  this->mScale.x = 1.0;
  this->mScale.y = 1.0;
  this->mScale.z = 1.0;
  FMOD::GeometryI::calculateMatrix(this);
  this->mPolygonUpdateList = 0;
  this->mNextUpdateItem = 0;
  this->mToBeUpdated = 0;
  this->mActive = 1;
}


// Address: 0x225d8b0 | Name: _ZN4FMOD9GeometryI7releaseEv
FMOD_RESULT_0 __fastcall FMOD::GeometryI::release(FMOD::GeometryI *const this)
{
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // r12
  FMOD::GeometryMgr *mGeometryMgr; // rdi
  FMOD::GeometryI *mFirstUpdateItem; // rdx
  FMOD::GeometryI *mNextUpdateItem; // rax
  FMOD::GeometryI::SpatialData *mSpatialData; // rsi
  unsigned __int8 *mPolygonData; // rsi
  int *mPolygonOffsets; // rsi
  FMOD::GeometryMgr *v9; // rax
  FMOD::SystemI *mSystem; // r13
  FMOD_RESULT_0 updated; // eax
  FMOD::SystemI *v12; // rdi
  FMOD::SystemI *v13; // rax
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::Global *v15; // rax
  FMOD::LinkedListNode *mNodeNext; // rdx

  mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  mGeometryMgr = this->mGeometryMgr;
  mFirstUpdateItem = mGeometryMgr->mFirstUpdateItem;
  if ( mFirstUpdateItem )
  {
    if ( this == mFirstUpdateItem )
    {
      mGeometryMgr->mFirstUpdateItem = this->mNextUpdateItem;
    }
    else
    {
      while ( 1 )
      {
        mNextUpdateItem = mFirstUpdateItem->mNextUpdateItem;
        if ( !mNextUpdateItem )
          break;
        if ( this == mNextUpdateItem )
        {
          mSpatialData = this->mSpatialData;
          mFirstUpdateItem->mNextUpdateItem = this->mNextUpdateItem;
          if ( mSpatialData )
            goto LABEL_8;
          goto LABEL_9;
        }
        mFirstUpdateItem = mFirstUpdateItem->mNextUpdateItem;
      }
    }
  }
  mSpatialData = this->mSpatialData;
  if ( mSpatialData )
  {
LABEL_8:
    FMOD::Octree::deleteItem(mGeometryMgr->mMainOctree, &mSpatialData->octreeNode);
    FMOD::Octree::removeInternalNode(this->mGeometryMgr->mMainOctree, &this->mSpatialData->octreeInternalNode);
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      this->mSpatialData,
      "../../../core_api/src/fmod_geometryi.cpp",
      381);
    mGeometryMgr = this->mGeometryMgr;
    this->mSpatialData = 0;
  }
LABEL_9:
  if ( mGeometryMgr->mMainOctree )
    FMOD::GeometryMgr::releaseMainOctree(mGeometryMgr);
  mPolygonData = this->mPolygonData;
  if ( mPolygonData )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mPolygonData, "../../../core_api/src/fmod_geometryi.cpp", 391);
    this->mPolygonData = 0;
  }
  mPolygonOffsets = this->mPolygonOffsets;
  if ( mPolygonOffsets )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mPolygonOffsets, "../../../core_api/src/fmod_geometryi.cpp", 396);
    this->mPolygonOffsets = 0;
  }
  v9 = this->mGeometryMgr;
  mSystem = v9->mSystem;
  v9->mMoved = 1;
  if ( mSystem )
  {
    updated = FMOD::SystemI::enterMainUpdateLock(mSystem);
    v12 = this->mGeometryMgr->mSystem;
    if ( updated == FMOD_RESULT::FMOD_OK_0 )
    {
      FMOD::SystemI::update(v12);
      FMOD::SystemI::leaveMainUpdateLock(mSystem);
      goto LABEL_20;
    }
  }
  else
  {
    v12 = 0;
  }
  FMOD::SystemI::update(v12);
LABEL_20:
  v13 = this->mGeometryMgr->mSystem;
  if ( v13->mGeometryList == this )
  {
    mNodeNext = 0;
    if ( this != this->mNodeNext )
      mNodeNext = this->mNodeNext;
    v13->mGeometryList = (FMOD::GeometryI *)mNodeNext;
  }
  mNodePrev = this->mNodePrev;
  mNodePrev->mNodeNext = this->mNodeNext;
  this->mNodeNext->mNodePrev = mNodePrev;
  v15 = off_286F358;
  this->mNodePrev = this;
  this->mNodeNext = this;
  FMOD::MemPool::free(v15->gSystemMemPool, this, "../../../core_api/src/fmod_geometryi.cpp", 419);
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225dae0 | Name: _ZN4FMOD9GeometryI5allocEii
FMOD_RESULT_0 __fastcall FMOD::GeometryI::alloc(FMOD::GeometryI *const this, int maxNumPolygons, int maxNumVertices)
{
  FMOD_RESULT_0 v4; // r12d
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // rbp
  FMOD::Global *v8; // rax
  int *v9; // rax
  unsigned __int8 *v10; // rax
  FMOD::GeometryI::SpatialData *v11; // rax
  _WORD *v12; // rdi
  unsigned int v13; // edx
  __int64 i; // rcx
  FMOD::GeometryI::SpatialData *mSpatialData; // rax

  v4 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  if ( !this->mPolygonData && !this->mPolygonOffsets )
  {
    this->mMaxNumVertices = maxNumVertices;
    this->mNumVertices = 0;
    this->mMaxNumPolygons = maxNumPolygons;
    v8 = off_286F358;
    this->mNumPolygons = 0;
    v9 = (int *)FMOD::MemPool::alloc(
                  v8->gSystemMemPool,
                  4 * maxNumVertices,
                  "../../../core_api/src/fmod_geometryi.cpp",
                  452,
                  0,
                  0);
    this->mPolygonOffsets = v9;
    if ( !v9 )
      goto LABEL_20;
    this->mPolygonDataPos = 0;
    v10 = (unsigned __int8 *)FMOD::MemPool::alloc(
                               off_286F358->gSystemMemPool,
                               188 * maxNumPolygons + 12 * maxNumVertices,
                               "../../../core_api/src/fmod_geometryi.cpp",
                               461,
                               0,
                               0);
    this->mPolygonData = v10;
    if ( !v10 )
      goto LABEL_20;
    v4 = FMOD::GeometryMgr::acquireMainOctree(this->mGeometryMgr);
    if ( v4 )
      goto LABEL_2;
    v11 = (FMOD::GeometryI::SpatialData *)FMOD::MemPool::alloc(
                                            off_286F358->gSystemMemPool,
                                            168,
                                            "../../../core_api/src/fmod_geometryi.cpp",
                                            473,
                                            0,
                                            0);
    this->mSpatialData = v11;
    if ( !v11 )
    {
LABEL_20:
      v4 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
      goto LABEL_2;
    }
    v12 = v11;
    v13 = 168;
    if ( ((unsigned __int8)v11 & 1) != 0 )
    {
      LOBYTE(v11->octreeNode.aabb.xMin) = 0;
      v12 = (_WORD *)((char *)&v11->octreeNode.aabb.xMin + 1);
      LOBYTE(v13) = -89;
    }
    if ( ((unsigned __int8)v12 & 2) != 0 )
    {
      *v12++ = 0;
      v13 -= 2;
    }
    for ( i = v13 >> 2; i; --i )
    {
      *(_DWORD *)v12 = 0;
      v12 += 2;
    }
    if ( (v13 & 2) != 0 )
      *v12++ = 0;
    if ( (v13 & 1) != 0 )
      *(_BYTE *)v12 = 0;
    mSpatialData = this->mSpatialData;
    v4 = FMOD_RESULT::FMOD_OK_0;
    mSpatialData->geometry = this;
    FMOD::Octree::addInternalNode(this->mGeometryMgr->mMainOctree, &mSpatialData->octreeInternalNode);
  }
LABEL_2:
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  return v4;
}


// Address: 0x225dc90 | Name: _ZN4FMOD9GeometryI10addPolygonEffbiPK11FMOD_VECTORPi
__int64 __fastcall FMOD::GeometryI::addPolygon(
        FMOD::GeometryI *const this,
        float directOcclusion,
        float reverbOcclusion,
        bool doubleSided,
        int numVertices,
        const FMOD_VECTOR *vertices,
        int *polygonIndex)
{
  unsigned int v9; // r13d
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // rbx
  __int64 mNumPolygons; // rax
  int v15; // edx
  int mPolygonDataPos; // eax
  unsigned __int8 *v17; // rsi
  unsigned int v18; // edx
  _DWORD *v19; // rdi
  __int64 v20; // rcx
  _DWORD *v21; // rdi
  _DWORD *v22; // rdi
  unsigned int v23; // edx
  __int64 v24; // rcx
  _DWORD *v25; // rdi
  unsigned __int8 *v26; // rdx
  unsigned __int64 v27; // rax

  v9 = 31;
  mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  if ( vertices )
  {
    if ( numVertices > 2 )
    {
      mNumPolygons = this->mNumPolygons;
      if ( (int)mNumPolygons < this->mMaxNumPolygons )
      {
        v15 = numVertices + this->mNumVertices;
        if ( v15 <= this->mMaxNumVertices )
        {
          if ( polygonIndex )
          {
            *polygonIndex = mNumPolygons;
            mNumPolygons = this->mNumPolygons;
            v15 = numVertices + this->mNumVertices;
          }
          this->mNumVertices = v15;
          this->mPolygonOffsets[mNumPolygons] = this->mPolygonDataPos;
          mPolygonDataPos = this->mPolygonDataPos;
          ++this->mNumPolygons;
          v17 = &this->mPolygonData[mPolygonDataPos];
          v18 = 80;
          this->mPolygonDataPos = mPolygonDataPos + 4 * (3 * numVertices - 3) + 200;
          v19 = v17;
          if ( ((unsigned __int8)v17 & 1) != 0 )
          {
            *v17 = 0;
            v19 = v17 + 1;
            LOBYTE(v18) = 79;
          }
          if ( ((unsigned __int8)v19 & 2) != 0 )
          {
            v19 = (_DWORD *)((char *)v19 + 2);
            v18 -= 2;
            *((_WORD *)v19 - 1) = 0;
          }
          if ( ((unsigned __int8)v19 & 4) != 0 )
          {
            *v19 = 0;
            v18 -= 4;
            ++v19;
          }
          v20 = v18 >> 3;
          memset(v19, 0, 8 * v20);
          v21 = &v19[2 * v20];
          if ( (v18 & 4) != 0 )
            *v21++ = 0;
          if ( (v18 & 2) != 0 )
          {
            v21 = (_DWORD *)((char *)v21 + 2);
            *((_WORD *)v21 - 1) = 0;
          }
          if ( (v18 & 1) != 0 )
            *(_BYTE *)v21 = 0;
          v22 = v17 + 80;
          v23 = 80;
          if ( (((_BYTE)v17 + 80) & 1) != 0 )
          {
            v17[80] = 0;
            v22 = v17 + 81;
            LOBYTE(v23) = 79;
          }
          if ( ((unsigned __int8)v22 & 2) != 0 )
          {
            v22 = (_DWORD *)((char *)v22 + 2);
            v23 -= 2;
            *((_WORD *)v22 - 1) = 0;
          }
          if ( ((unsigned __int8)v22 & 4) != 0 )
          {
            *v22 = 0;
            v23 -= 4;
            ++v22;
          }
          v24 = v23 >> 3;
          memset(v22, 0, 8 * v24);
          v25 = &v22[2 * v24];
          if ( (v23 & 4) != 0 )
            *v25++ = 0;
          if ( (v23 & 2) != 0 )
          {
            v25 = (_DWORD *)((char *)v25 + 2);
            *((_WORD *)v25 - 1) = 0;
          }
          if ( (v23 & 1) != 0 )
            *(_BYTE *)v25 = 0;
          *((float *)v17 + 44) = directOcclusion;
          *((float *)v17 + 45) = reverbOcclusion;
          if ( doubleSided )
            numVertices |= 0x10000u;
          *((_DWORD *)v17 + 46) = numVertices;
          if ( (_WORD)numVertices )
          {
            v26 = v17 + 188;
            v27 = 0;
            do
            {
              *(_QWORD *)&v26[v27] = *(_QWORD *)&vertices[v27 / 0xC].x;
              *(float *)&v26[v27 + 8] = vertices[v27 / 0xC].z;
              v27 += 12LL;
            }
            while ( v27 != 4 * (3LL * ((unsigned int)(unsigned __int16)numVertices - 1) + 3) );
          }
          v9 = 0;
          *((_QWORD *)v17 + 9) = this->mPolygonUpdateList;
          this->mPolygonUpdateList = (FMOD::OctreeNode *)v17;
          FMOD::GeometryI::setToBeUpdated(this);
        }
      }
    }
  }
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  return v9;
}


// Address: 0x225def0 | Name: _ZN4FMOD9GeometryI14getNumPolygonsEPi
FMOD_RESULT_0 __fastcall FMOD::GeometryI::getNumPolygons(FMOD::GeometryI *const this, int *numPolygons)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numPolygons )
  {
    *numPolygons = this->mNumPolygons;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225df10 | Name: _ZN4FMOD9GeometryI14getMaxPolygonsEPiS1_
FMOD_RESULT_0 __fastcall FMOD::GeometryI::getMaxPolygons(
        FMOD::GeometryI *const this,
        int *maxNumPolygons,
        int *maxVertices)
{
  if ( maxNumPolygons )
    *maxNumPolygons = this->mMaxNumPolygons;
  if ( maxVertices )
    *maxVertices = this->mMaxNumVertices;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225df30 | Name: _ZN4FMOD9GeometryI21getPolygonNumVerticesEiPi
FMOD_RESULT_0 __fastcall FMOD::GeometryI::getPolygonNumVertices(
        FMOD::GeometryI *const this,
        int polygonIndex,
        int *numVertices)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( polygonIndex >= 0 && polygonIndex < this->mNumPolygons )
  {
    if ( numVertices )
      *numVertices = *(unsigned __int16 *)&this->mPolygonData[this->mPolygonOffsets[polygonIndex] + 184];
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225df70 | Name: _ZN4FMOD9GeometryI16setPolygonVertexEiiPK11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::GeometryI::setPolygonVertex(
        FMOD::GeometryI *const this,
        int polygonIndex,
        int vertexIndex,
        const FMOD_VECTOR *vertex)
{
  __int64 v4; // r15
  FMOD_RESULT_0 v6; // r13d
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // rbx
  unsigned __int8 *mPolygonData; // rdx
  __int64 v10; // rax
  unsigned __int8 *v11; // r12
  float *v12; // rax
  bool v13; // zf

  v4 = vertexIndex;
  v6 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  if ( polygonIndex >= 0 && polygonIndex < this->mNumPolygons )
  {
    mPolygonData = this->mPolygonData;
    v10 = this->mPolygonOffsets[polygonIndex];
    if ( (int)v4 >= 0 )
    {
      v11 = &mPolygonData[v10];
      if ( (int)v4 < *(unsigned __int16 *)&mPolygonData[v10 + 184] )
      {
        if ( vertex )
        {
          v12 = (float *)&v11[12 * v4 + 188];
          if ( *v12 != vertex->x
            || *(float *)&v11[12 * v4 + 192] != vertex->y
            || (LOBYTE(v6) = 0, *(float *)&v11[12 * v4 + 196] != vertex->z) )
          {
            v13 = (v11[24] & 0x40) == 0;
            *(_QWORD *)v12 = *(_QWORD *)&vertex->x;
            *(float *)&v11[12 * v4 + 196] = vertex->z;
            if ( !v13 )
            {
              FMOD::Octree::deleteItem(&this->mOctree, (FMOD::OctreeNode *)v11);
              *((_QWORD *)v11 + 9) = this->mPolygonUpdateList;
              this->mPolygonUpdateList = (FMOD::OctreeNode *)v11;
            }
            v6 = FMOD_RESULT::FMOD_OK_0;
            FMOD::GeometryI::setToBeUpdated(this);
          }
        }
      }
    }
  }
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  return v6;
}


// Address: 0x225e080 | Name: _ZN4FMOD9GeometryI16getPolygonVertexEiiP11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::GeometryI::getPolygonVertex(
        FMOD::GeometryI *const this,
        int polygonIndex,
        int vertexIndex,
        FMOD_VECTOR *vertex)
{
  FMOD_RESULT_0 result; // eax
  __int64 v5; // rsi
  unsigned __int8 *v6; // r8

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( polygonIndex >= 0 && polygonIndex < this->mNumPolygons )
  {
    if ( vertex )
    {
      v5 = this->mPolygonOffsets[polygonIndex];
      if ( vertexIndex >= 0 )
      {
        v6 = &this->mPolygonData[v5];
        if ( vertexIndex < *((unsigned __int16 *)v6 + 92) )
        {
          *vertex = *(FMOD_VECTOR *)&v6[12 * vertexIndex + 188];
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x225e0e0 | Name: _ZN4FMOD9GeometryI20setPolygonAttributesEiffb
__int64 __fastcall FMOD::GeometryI::setPolygonAttributes(
        FMOD::GeometryI *const this,
        int polygonIndex,
        float directOcclusion,
        float reverbOcclusion,
        bool doubleSided)
{
  unsigned int v6; // r13d
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // rbp
  unsigned __int8 *v9; // rax

  v6 = 31;
  mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  if ( polygonIndex >= 0 && polygonIndex < this->mNumPolygons )
  {
    v9 = &this->mPolygonData[this->mPolygonOffsets[polygonIndex]];
    *((float *)v9 + 44) = directOcclusion;
    *((float *)v9 + 45) = reverbOcclusion;
    if ( doubleSided )
      *((_DWORD *)v9 + 46) |= 0x10000u;
    else
      *((_DWORD *)v9 + 46) &= ~0x10000u;
    v6 = 0;
    FMOD::GeometryI::setToBeUpdated(this);
  }
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  return v6;
}


// Address: 0x225e1a0 | Name: _ZN4FMOD9GeometryI20getPolygonAttributesEiPfS1_Pb
FMOD_RESULT_0 __fastcall FMOD::GeometryI::getPolygonAttributes(
        FMOD::GeometryI *const this,
        int polygonIndex,
        float *directOcclusion,
        float *reverbOcclusion,
        bool *doubleSided)
{
  FMOD_RESULT_0 result; // eax
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // rbp
  unsigned __int8 *v7; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( polygonIndex >= 0 && polygonIndex < this->mNumPolygons )
  {
    mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
    FMOD_OS_CriticalSection_Enter(mGeometryCrit);
    v7 = &this->mPolygonData[this->mPolygonOffsets[polygonIndex]];
    if ( directOcclusion )
      *directOcclusion = *((float *)v7 + 44);
    if ( reverbOcclusion )
      *reverbOcclusion = *((float *)v7 + 45);
    if ( doubleSided )
      *doubleSided = v7[186] & 1;
    FMOD_OS_CriticalSection_Leave(mGeometryCrit);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225e250 | Name: _ZN4FMOD9GeometryI5flushEv
FMOD_RESULT_0 __fastcall FMOD::GeometryI::flush(FMOD::GeometryI *const this)
{
  FMOD::Octree *p_mOctree; // rbp
  FMOD::OctreeNode *mPolygonUpdateList; // rbx
  int flags_low; // ecx
  FMOD::OctreeNode *nextItem; // r13
  float v5; // xmm10_4
  float v6; // xmm8_4
  float v7; // xmm7_4
  float *p_splitLevel; // rax
  float v9; // xmm13_4
  int v10; // ecx
  float v11; // xmm12_4
  int v12; // edx
  float v13; // xmm11_4
  float v14; // xmm1_4
  float v15; // xmm1_4
  float v16; // xmm5_4
  float v17; // xmm3_4
  float v18; // xmm0_4
  float v19; // xmm2_4
  float v20; // xmm4_4
  float v21; // xmm1_4
  int flags; // ecx
  float v23; // xmm3_4
  float v24; // xmm2_4
  float v25; // xmm1_4
  float v26; // xmm6_4
  float v27; // xmm5_4
  float v28; // xmm4_4
  float *v29; // rax
  float v30; // xmm7_4
  float v31; // xmm7_4
  float v32; // xmm7_4
  float v33; // xmm0_4
  float v34; // xmm6_4

  p_mOctree = &this->mOctree;
  mPolygonUpdateList = this->mPolygonUpdateList;
  this->mPolygonUpdateList = 0;
  if ( mPolygonUpdateList )
  {
    while ( 1 )
    {
      flags_low = LOWORD(mPolygonUpdateList[2].flags);
      nextItem = mPolygonUpdateList->nextItem;
      mPolygonUpdateList->nextItem = 0;
      if ( flags_low <= 2 )
      {
        v5 = 0.0;
        v6 = 0.0;
        v7 = 0.0;
      }
      else
      {
        v5 = 0.0;
        v6 = 0.0;
        v7 = 0.0;
        p_splitLevel = (float *)&mPolygonUpdateList[2].splitLevel;
        v9 = *(float *)&mPolygonUpdateList[2].splitLevel;
        v10 = flags_low - 2;
        v11 = *(float *)mPolygonUpdateList[2].pos;
        v12 = 0;
        v13 = *(float *)&mPolygonUpdateList[2].pos[1];
        do
        {
          v14 = p_splitLevel[4];
          ++v12;
          p_splitLevel += 3;
          v15 = v14 - v11;
          v16 = p_splitLevel[2] - v13;
          v17 = *p_splitLevel - v9;
          v18 = p_splitLevel[3] - v9;
          v19 = p_splitLevel[4] - v11;
          v20 = p_splitLevel[5] - v13;
          v7 = v7 + (float)((float)(v15 * v20) - (float)(v16 * v19));
          v6 = v6 + (float)((float)(v16 * v18) - (float)(v20 * v17));
          v5 = v5 + (float)((float)(v19 * v17) - (float)(v18 * v15));
        }
        while ( v12 != v10 );
        v21 = fsqrt((float)((float)(v7 * v7) + (float)(v6 * v6)) + (float)(v5 * v5));
        if ( v21 > 0.0 )
        {
          v7 = v7 / v21;
          mPolygonUpdateList[2].flags &= ~0x20000u;
          v6 = v6 / v21;
          v5 = v5 / v21;
          goto LABEL_7;
        }
      }
      mPolygonUpdateList[2].flags |= 0x20000u;
LABEL_7:
      mPolygonUpdateList[2].aabb.xMax = v7;
      mPolygonUpdateList[2].aabb.yMin = v6;
      mPolygonUpdateList[2].aabb.yMax = v5;
      mPolygonUpdateList[2].aabb.xMin = (float)((float)(v7 * *(float *)&mPolygonUpdateList[2].splitLevel)
                                              + (float)(v6 * *(float *)mPolygonUpdateList[2].pos))
                                      + (float)(v5 * *(float *)&mPolygonUpdateList[2].pos[1]);
      FMOD::Octree::addInternalNode(p_mOctree, mPolygonUpdateList + 1);
      flags = mPolygonUpdateList[2].flags;
      v23 = *(float *)&mPolygonUpdateList[2].splitLevel;
      v24 = *(float *)mPolygonUpdateList[2].pos;
      v25 = *(float *)&mPolygonUpdateList[2].pos[1];
      mPolygonUpdateList->aabb.xMin = v23;
      mPolygonUpdateList->aabb.xMax = v23;
      mPolygonUpdateList->aabb.yMin = v24;
      mPolygonUpdateList->aabb.yMax = v24;
      mPolygonUpdateList->aabb.zMin = v25;
      mPolygonUpdateList->aabb.zMax = v25;
      if ( (unsigned __int16)flags <= 1u )
      {
        v33 = v25;
        v27 = v24;
        v28 = v23;
      }
      else
      {
        v26 = v25;
        v27 = v24;
        v28 = v23;
        v29 = (float *)&mPolygonUpdateList[2].splitLevel;
        do
        {
          v30 = v29[3];
          v29 += 3;
          v23 = fmaxf(v23, v30);
          v28 = fminf(v28, v30);
          v31 = v29[1];
          v24 = fmaxf(v24, v31);
          v27 = fminf(v27, v31);
          v32 = v29[2];
          v25 = fmaxf(v25, v32);
          v26 = fminf(v26, v32);
        }
        while ( v29 != &mPolygonUpdateList[2].aabb.zMin + 3 * (unsigned int)(unsigned __int16)flags );
        v33 = v26;
      }
      v34 = fmaxf(fmaxf(v23 - v28, v24 - v27), v25 - v33) * 0.0099999998;
      mPolygonUpdateList->aabb.xMin = v28 - v34;
      mPolygonUpdateList->aabb.xMax = v23 + v34;
      mPolygonUpdateList->aabb.yMin = v27 - v34;
      mPolygonUpdateList->aabb.yMax = v24 + v34;
      mPolygonUpdateList->aabb.zMin = v33 - v34;
      mPolygonUpdateList->aabb.zMax = v25 + v34;
      if ( (flags & 0x20000) != 0 )
      {
        if ( !nextItem )
          break;
      }
      else
      {
        FMOD::Octree::insertItem(p_mOctree, mPolygonUpdateList);
        if ( !nextItem )
          break;
      }
      mPolygonUpdateList = nextItem;
    }
  }
  FMOD::Octree::getAABB(p_mOctree, &this->mAABB);
  FMOD::GeometryI::updateSpatialData(this);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225e5d0 | Name: _ZN4FMOD9GeometryI9setActiveEb
FMOD_RESULT_0 __fastcall FMOD::GeometryI::setActive(FMOD::GeometryI *const this, bool active)
{
  FMOD::GeometryI::setToBeUpdated(this);
  this->mActive = active;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225e5f0 | Name: _ZN4FMOD9GeometryI9getActiveEPb
FMOD_RESULT_0 __fastcall FMOD::GeometryI::getActive(FMOD::GeometryI *const this, bool *active)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( active )
  {
    *active = this->mActive;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225e610 | Name: _ZN4FMOD9GeometryI11setRotationEPK11FMOD_VECTORS3_
FMOD_RESULT_0 __fastcall FMOD::GeometryI::setRotation(
        FMOD::GeometryI *const this,
        const FMOD_VECTOR *forward,
        const FMOD_VECTOR *up)
{
  FMOD_RESULT_0 v3; // r14d
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // r12

  v3 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  if ( forward )
  {
    if ( up )
    {
      if ( this->mForward.x != forward->x
        || this->mForward.y != forward->y
        || this->mForward.z != forward->z
        || this->mUp.x != up->x
        || this->mUp.y != up->y
        || (LOBYTE(v3) = 0, this->mUp.z != up->z) )
      {
        v3 = FMOD_RESULT::FMOD_OK_0;
        this->mForward = *forward;
        this->mUp = *up;
        FMOD::GeometryI::calculateMatrix(this);
        FMOD::GeometryI::setToBeUpdated(this);
      }
    }
  }
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  return v3;
}


// Address: 0x225e700 | Name: _ZN4FMOD9GeometryI11getRotationEP11FMOD_VECTORS2_
FMOD_RESULT_0 __fastcall FMOD::GeometryI::getRotation(
        FMOD::GeometryI *const this,
        FMOD_VECTOR *forward,
        FMOD_VECTOR *up)
{
  if ( forward )
    *forward = this->mForward;
  if ( up )
    *up = this->mUp;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225e730 | Name: _ZN4FMOD9GeometryI11setPositionEPK11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::GeometryI::setPosition(FMOD::GeometryI *const this, const FMOD_VECTOR *position)
{
  FMOD_RESULT_0 v2; // r13d
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // r12

  v2 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  if ( position )
  {
    if ( this->mPosition.x != position->x
      || this->mPosition.y != position->y
      || (LOBYTE(v2) = 0, this->mPosition.z != position->z) )
    {
      v2 = FMOD_RESULT::FMOD_OK_0;
      this->mPosition = *position;
      FMOD::GeometryI::setToBeUpdated(this);
    }
  }
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  return v2;
}


// Address: 0x225e7d0 | Name: _ZN4FMOD9GeometryI11getPositionEP11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::GeometryI::getPosition(FMOD::GeometryI *const this, FMOD_VECTOR *position)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( position )
  {
    *position = this->mPosition;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225e800 | Name: _ZN4FMOD9GeometryI8setScaleEPK11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::GeometryI::setScale(FMOD::GeometryI *const this, const FMOD_VECTOR *scale)
{
  FMOD_RESULT_0 v2; // r12d
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // rbp
  float y; // xmm2_4
  float z; // xmm3_4

  v2 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  if ( scale )
  {
    if ( scale->x != 0.0 )
    {
      y = scale->y;
      v2 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      if ( y != 0.0 )
      {
        z = scale->z;
        v2 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        if ( z != 0.0 )
        {
          if ( scale->x != this->mScale.x || y != this->mScale.y || (v2 = FMOD_RESULT::FMOD_OK_0, z != this->mScale.z) )
          {
            v2 = FMOD_RESULT::FMOD_OK_0;
            this->mScale = *scale;
            FMOD::GeometryI::calculateMatrix(this);
            FMOD::GeometryI::setToBeUpdated(this);
          }
        }
      }
    }
  }
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  return v2;
}


// Address: 0x225e8e0 | Name: _ZN4FMOD9GeometryI8getScaleEP11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::GeometryI::getScale(FMOD::GeometryI *const this, FMOD_VECTOR *scale)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( scale )
  {
    *scale = this->mScale;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225e910 | Name: _ZN4FMOD9GeometryI10serialiserEPvPibbPF11FMOD_RESULTS1_iS2_S1_iE
FMOD_RESULT_0 __fastcall FMOD::GeometryI::serialiser(
        FMOD::GeometryI *const this,
        void *data,
        int *dataSize,
        bool bWrite,
        bool bRead,
        FMOD_RESULT_0 (*serialiseData)(void *, int, int *, void *, int))
{
  __int64 v11; // rsi
  FMOD_RESULT_0 result; // eax
  __int64 v13; // rsi
  FMOD_RESULT_0 PolygonNumVertices; // eax
  FMOD_RESULT_0 v15; // eax
  int v16; // r15d
  FMOD_VECTOR *v17; // r13
  FMOD_RESULT_0 v18; // eax
  FMOD_RESULT_0 v19; // eax
  FMOD_RESULT_0 PolygonVertex; // eax
  FMOD_RESULT_0 v21; // eax
  FMOD_RESULT_0 v22; // eax
  int v23; // ecx
  FMOD::MemPool *gSystemMemPool; // rdi
  __int64 v25; // rsi
  FMOD_RESULT_0 v26; // eax
  FMOD_RESULT_0 v27; // eax
  FMOD_RESULT_0 v28; // eax
  FMOD_RESULT_0 v29; // eax
  FMOD_RESULT_0 PolygonAttributes; // eax
  FMOD_RESULT_0 v31; // [rsp+0h] [rbp-E8h]
  FMOD_RESULT_0 v32; // [rsp+0h] [rbp-E8h]
  FMOD_RESULT_0 v33; // [rsp+0h] [rbp-E8h]
  FMOD_RESULT_0 v34; // [rsp+0h] [rbp-E8h]
  FMOD_RESULT_0 v35; // [rsp+0h] [rbp-E8h]
  FMOD_VECTOR *vertexArray; // [rsp+10h] [rbp-D8h]
  char v39; // [rsp+1Bh] [rbp-CDh]
  int polygonIndex; // [rsp+1Ch] [rbp-CCh]
  bool v41; // [rsp+48h] [rbp-A0h]
  bool v42; // [rsp+4Ch] [rbp-9Ch]
  bool bDoubleSided; // [rsp+57h] [rbp-91h] BYREF
  int index; // [rsp+58h] [rbp-90h] BYREF
  unsigned int header; // [rsp+5Ch] [rbp-8Ch] BYREF
  int dataSizeCheck; // [rsp+60h] [rbp-88h] BYREF
  int numPolygons; // [rsp+64h] [rbp-84h] BYREF
  int maxPolygons; // [rsp+68h] [rbp-80h] BYREF
  int maxVertices; // [rsp+6Ch] [rbp-7Ch] BYREF
  int numVertices; // [rsp+70h] [rbp-78h] BYREF
  int v51; // [rsp+74h] [rbp-74h] BYREF
  __int64 v52; // [rsp+78h] [rbp-70h] BYREF
  float directOcclusion; // [rsp+80h] [rbp-68h] BYREF
  int v54; // [rsp+84h] [rbp-64h] BYREF
  __int64 v55; // [rsp+88h] [rbp-60h] BYREF
  float reverbOcclusion; // [rsp+90h] [rbp-58h] BYREF
  int v57; // [rsp+94h] [rbp-54h] BYREF
  __int64 v58; // [rsp+98h] [rbp-50h] BYREF
  int doubleSided; // [rsp+A0h] [rbp-48h] BYREF
  int v60; // [rsp+A4h] [rbp-44h] BYREF
  __int64 v61; // [rsp+A8h] [rbp-40h] BYREF

  v11 = (unsigned int)*dataSize;
  index = 0;
  header = 1146047814;
  result = serialiseData(data, v11, &index, &header, 4);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( header != 1146047814 )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    dataSizeCheck = *dataSize;
    result = serialiseData(data, dataSizeCheck, &index, &dataSizeCheck, 4);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( bRead )
      {
        v13 = (unsigned int)*dataSize;
        if ( (_DWORD)v13 != dataSizeCheck )
          return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        v39 = bWrite || !bRead;
        if ( !v39 )
        {
          result = serialiseData(data, v13, &index, &numPolygons, 4);
          if ( result )
            return result;
LABEL_10:
          result = serialiseData(data, *dataSize, &index, &maxPolygons, 4);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = serialiseData(data, *dataSize, &index, &maxVertices, 4);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              vertexArray = (FMOD_VECTOR *)FMOD::MemPool::alloc(
                                             off_286F358->gSystemMemPool,
                                             768,
                                             "../../../core_api/src/fmod_geometryi.cpp",
                                             1389,
                                             0,
                                             0);
              if ( vertexArray )
              {
                if ( bRead && (v22 = FMOD::GeometryI::alloc(this, maxPolygons, maxVertices)) != FMOD_RESULT::FMOD_OK_0 )
                {
                  v34 = v22;
                  v23 = 1395;
                  gSystemMemPool = off_286F358->gSystemMemPool;
LABEL_40:
                  FMOD::MemPool::free(gSystemMemPool, vertexArray, "../../../core_api/src/fmod_geometryi.cpp", v23);
                  return v34;
                }
                else
                {
                  polygonIndex = 0;
                  v41 = bWrite;
                  v42 = bRead;
                  while ( polygonIndex < numPolygons )
                  {
                    if ( v39 )
                    {
                      PolygonNumVertices = FMOD::GeometryI::getPolygonNumVertices(this, polygonIndex, &numVertices);
                      if ( PolygonNumVertices )
                      {
                        v34 = PolygonNumVertices;
                        v23 = 1402;
                        gSystemMemPool = off_286F358->gSystemMemPool;
                        goto LABEL_40;
                      }
                    }
                    v15 = serialiseData(data, *dataSize, &index, &numVertices, 4);
                    if ( v15 )
                    {
                      v34 = v15;
                      v23 = 1404;
                      gSystemMemPool = off_286F358->gSystemMemPool;
                      goto LABEL_40;
                    }
                    if ( numVertices > 64 )
                    {
                      FMOD::MemPool::free(
                        off_286F358->gSystemMemPool,
                        vertexArray,
                        "../../../core_api/src/fmod_geometryi.cpp",
                        1410);
                      vertexArray = (FMOD_VECTOR *)FMOD::MemPool::alloc(
                                                     off_286F358->gSystemMemPool,
                                                     768,
                                                     "../../../core_api/src/fmod_geometryi.cpp",
                                                     1411,
                                                     0,
                                                     0);
                      if ( !vertexArray )
                        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
                    }
                    v16 = 0;
                    v17 = vertexArray;
                    if ( numVertices > 0 )
                    {
                      while ( 1 )
                      {
                        if ( bWrite )
                        {
                          PolygonVertex = FMOD::GeometryI::getPolygonVertex(this, polygonIndex, v16, v17);
                          if ( PolygonVertex )
                            break;
                        }
                        v21 = serialiseData(data, *dataSize, &index, v17, 4);
                        if ( v21 )
                        {
                          v31 = v21;
                          FMOD::MemPool::free(
                            off_286F358->gSystemMemPool,
                            vertexArray,
                            "../../../core_api/src/fmod_geometryi.cpp",
                            1423);
                          return v31;
                        }
                        v18 = serialiseData(data, *dataSize, &index, &v17->y, 4);
                        if ( v18 )
                        {
                          v33 = v18;
                          FMOD::MemPool::free(
                            off_286F358->gSystemMemPool,
                            vertexArray,
                            "../../../core_api/src/fmod_geometryi.cpp",
                            1424);
                          return v33;
                        }
                        v19 = serialiseData(data, *dataSize, &index, &v17->z, 4);
                        if ( v19 )
                        {
                          v32 = v19;
                          FMOD::MemPool::free(
                            off_286F358->gSystemMemPool,
                            vertexArray,
                            "../../../core_api/src/fmod_geometryi.cpp",
                            1425);
                          return v32;
                        }
                        ++v16;
                        ++v17;
                        if ( numVertices <= v16 )
                          goto LABEL_41;
                      }
                      v35 = PolygonVertex;
                      FMOD::MemPool::free(
                        off_286F358->gSystemMemPool,
                        vertexArray,
                        "../../../core_api/src/fmod_geometryi.cpp",
                        1421);
                      return v35;
                    }
LABEL_41:
                    bDoubleSided = 0;
                    if ( v39 )
                    {
                      PolygonAttributes = FMOD::GeometryI::getPolygonAttributes(
                                            this,
                                            polygonIndex,
                                            &directOcclusion,
                                            &reverbOcclusion,
                                            &bDoubleSided);
                      if ( PolygonAttributes )
                      {
                        v34 = PolygonAttributes;
                        v23 = 1433;
                        gSystemMemPool = off_286F358->gSystemMemPool;
                        goto LABEL_40;
                      }
                    }
                    v25 = (unsigned int)*dataSize;
                    doubleSided = bDoubleSided;
                    v26 = serialiseData(data, v25, &index, &directOcclusion, 4);
                    if ( v26 )
                    {
                      v34 = v26;
                      v23 = 1436;
                      gSystemMemPool = off_286F358->gSystemMemPool;
                      goto LABEL_40;
                    }
                    v27 = serialiseData(data, *dataSize, &index, &reverbOcclusion, 4);
                    if ( v27 )
                    {
                      v34 = v27;
                      v23 = 1437;
                      gSystemMemPool = off_286F358->gSystemMemPool;
                      goto LABEL_40;
                    }
                    v28 = serialiseData(data, *dataSize, &index, &doubleSided, 4);
                    if ( v28 )
                    {
                      v34 = v28;
                      v23 = 1438;
                      gSystemMemPool = off_286F358->gSystemMemPool;
                      goto LABEL_40;
                    }
                    bDoubleSided = doubleSided != 0;
                    if ( bRead )
                    {
                      v29 = (unsigned int)FMOD::GeometryI::addPolygon(
                                            this,
                                            directOcclusion,
                                            reverbOcclusion,
                                            doubleSided != 0,
                                            numVertices,
                                            vertexArray,
                                            0);
                      if ( v29 )
                      {
                        v34 = v29;
                        v23 = 1443;
                        gSystemMemPool = off_286F358->gSystemMemPool;
                        goto LABEL_40;
                      }
                    }
                    ++polygonIndex;
                  }
                  FMOD::MemPool::free(
                    off_286F358->gSystemMemPool,
                    vertexArray,
                    "../../../core_api/src/fmod_geometryi.cpp",
                    1447);
                  if ( !v39
                    || (result = FMOD::GeometryI::getRotation(
                                   this,
                                   (FMOD_VECTOR *)&numVertices,
                                   (FMOD_VECTOR *)&directOcclusion)) == FMOD_RESULT::FMOD_OK_0 )
                  {
                    result = serialiseData(data, *dataSize, &index, &numVertices, 4);
                    if ( result == FMOD_RESULT::FMOD_OK_0 )
                    {
                      result = serialiseData(data, *dataSize, &index, &v51, 4);
                      if ( result == FMOD_RESULT::FMOD_OK_0 )
                      {
                        result = serialiseData(data, *dataSize, &index, &v52, 4);
                        if ( result == FMOD_RESULT::FMOD_OK_0 )
                        {
                          result = serialiseData(data, *dataSize, &index, &directOcclusion, 4);
                          if ( result == FMOD_RESULT::FMOD_OK_0 )
                          {
                            result = serialiseData(data, *dataSize, &index, &v54, 4);
                            if ( result == FMOD_RESULT::FMOD_OK_0 )
                            {
                              result = serialiseData(data, *dataSize, &index, &v55, 4);
                              if ( result == FMOD_RESULT::FMOD_OK_0
                                && (!v42
                                 || (result = FMOD::GeometryI::setRotation(
                                                this,
                                                (const FMOD_VECTOR *)&numVertices,
                                                (const FMOD_VECTOR *)&directOcclusion)) == FMOD_RESULT::FMOD_OK_0)
                                && (!v39
                                 || (result = FMOD::GeometryI::getPosition(this, (FMOD_VECTOR *)&reverbOcclusion)) == FMOD_RESULT::FMOD_OK_0) )
                              {
                                result = serialiseData(data, *dataSize, &index, &reverbOcclusion, 4);
                                if ( result == FMOD_RESULT::FMOD_OK_0 )
                                {
                                  result = serialiseData(data, *dataSize, &index, &v57, 4);
                                  if ( result == FMOD_RESULT::FMOD_OK_0 )
                                  {
                                    result = serialiseData(data, *dataSize, &index, &v58, 4);
                                    if ( result == FMOD_RESULT::FMOD_OK_0
                                      && (!v42
                                       || (result = FMOD::GeometryI::setPosition(
                                                      this,
                                                      (const FMOD_VECTOR *)&reverbOcclusion)) == FMOD_RESULT::FMOD_OK_0)
                                      && (!v39
                                       || (result = FMOD::GeometryI::getScale(this, (FMOD_VECTOR *)&doubleSided)) == FMOD_RESULT::FMOD_OK_0) )
                                    {
                                      result = serialiseData(data, *dataSize, &index, &doubleSided, 4);
                                      if ( result == FMOD_RESULT::FMOD_OK_0 )
                                      {
                                        result = serialiseData(data, *dataSize, &index, &v60, 4);
                                        if ( result == FMOD_RESULT::FMOD_OK_0 )
                                        {
                                          result = serialiseData(data, *dataSize, &index, &v61, 4);
                                          if ( result == FMOD_RESULT::FMOD_OK_0 )
                                          {
                                            if ( v42 )
                                            {
                                              result = FMOD::GeometryI::setScale(
                                                         this,
                                                         (const FMOD_VECTOR *)&doubleSided);
                                              if ( result )
                                                return result;
                                            }
                                            else if ( !v41 )
                                            {
                                              *dataSize = index;
                                              return result;
                                            }
                                            result = FMOD_RESULT::FMOD_OK_0;
                                            if ( *dataSize != index )
                                              return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              else
              {
                return FMOD_RESULT::FMOD_ERR_MEMORY_0;
              }
            }
          }
          return result;
        }
      }
      else
      {
        v39 = bWrite | 1;
      }
      result = FMOD::GeometryI::getNumPolygons(this, &numPolygons);
      if ( result )
        return result;
      result = serialiseData(data, *dataSize, &index, &numPolygons, 4);
      if ( result )
        return result;
      result = FMOD::GeometryI::getMaxPolygons(this, &maxPolygons, &maxVertices);
      if ( result )
        return result;
      goto LABEL_10;
    }
  }
  return result;
}


// Address: 0x225f230 | Name: _ZN4FMOD9GeometryI4saveEPvPi
FMOD_RESULT_0 __fastcall FMOD::GeometryI::save(FMOD::GeometryI *const this, void *data, int *dataSize)
{
  FMOD_RESULT_0 result; // eax
  int tmpDataSize[3]; // [rsp+0h] [rbp-Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dataSize )
  {
    if ( data )
    {
      tmpDataSize[0] = *dataSize;
      return FMOD::GeometryI::serialiser(this, data, tmpDataSize, 1, 0, FMOD::GeometryI::saveData);
    }
    else
    {
      return FMOD::GeometryI::serialiser(this, 0, dataSize, 0, 0, FMOD::GeometryI::countData);
    }
  }
  return result;
}


// Address: 0x225f290 | Name: _ZN4FMOD9GeometryI4loadEPKvi
FMOD_RESULT_0 __fastcall FMOD::GeometryI::load(FMOD::GeometryI *const this, const void *data, int dataSize)
{
  FMOD_RESULT_0 v3; // r13d
  FMOD::GeometryMgr *mGeometryMgr; // rax
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // rbx
  int dataSizea[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  v3 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mGeometryMgr = this->mGeometryMgr;
  dataSizea[0] = dataSize;
  mGeometryCrit = mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  if ( data )
    v3 = FMOD::GeometryI::serialiser(this, (void *)data, dataSizea, 0, 1, FMOD::GeometryI::loadData);
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  return v3;
}


// Address: 0x225f300 | Name: _ZN4FMOD9GeometryI11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::GeometryI::setUserData(FMOD::GeometryI *const this, void *userdata)
{
  this->mUserData = userdata;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225f310 | Name: _ZN4FMOD9GeometryI11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::GeometryI::getUserData(FMOD::GeometryI *const this, void **userdata)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( userdata )
  {
    *userdata = this->mUserData;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225f330 | Name: _ZN4FMOD9GeometryI8lineTestEPNS0_12LineTestDataE
bool __fastcall FMOD::GeometryI::lineTest(FMOD::GeometryI *const this, FMOD::GeometryI::LineTestData *lineTestData)
{
  float x; // xmm3_4
  float y; // xmm2_4
  float z; // xmm1_4
  __int64 v5; // rax
  float v6; // xmm9_4
  float v7; // xmm8_4
  float v8; // xmm7_4
  float v9; // xmm6_4
  float v10; // xmm5_4
  bool result; // al
  float v12; // [rsp+8h] [rbp-60h]
  float v13; // [rsp+Ch] [rbp-5Ch]
  FMOD_VECTOR startTmp; // [rsp+20h] [rbp-48h] BYREF
  FMOD_VECTOR endTmp; // [rsp+30h] [rbp-38h] BYREF

  x = this->mPosition.x;
  y = this->mPosition.y;
  *(_QWORD *)&startTmp.x = *(_QWORD *)&lineTestData->start.x;
  z = this->mPosition.z;
  startTmp.z = lineTestData->start.z;
  v5 = *(_QWORD *)&lineTestData->end.x;
  v6 = lineTestData->start.x;
  v7 = lineTestData->start.y;
  startTmp.x = startTmp.x - x;
  *(_QWORD *)&endTmp.x = v5;
  *(float *)&v5 = lineTestData->end.z;
  v8 = lineTestData->start.z;
  v9 = lineTestData->end.x;
  v10 = lineTestData->end.y;
  startTmp.y = startTmp.y - y;
  v13 = v10;
  v12 = *(float *)&v5;
  startTmp.z = startTmp.z - z;
  endTmp.x = endTmp.x - x;
  endTmp.y = endTmp.y - y;
  endTmp.z = *(float *)&v5 - z;
  FMOD::matrixMult(this->mInvMatrix, &startTmp, &lineTestData->start);
  FMOD::matrixMult(this->mInvMatrix, &endTmp, &lineTestData->end);
  result = FMOD::Octree::testLine(
             &this->mOctree,
             FMOD::GeometryI::octreeLineTestCallback,
             lineTestData,
             &lineTestData->start,
             &lineTestData->end);
  lineTestData->geometryI = 0;
  lineTestData->start.y = v7;
  lineTestData->start.z = v8;
  lineTestData->end.x = v9;
  lineTestData->end.y = v13;
  lineTestData->end.z = v12;
  lineTestData->start.x = v6;
  return result;
}


// Address: 0x225f4c0 | Name: _ZN4FMOD9GeometryI12setWorldSizeEf
__int64 __fastcall FMOD::GeometryI::setWorldSize(FMOD::GeometryI *const this, float a2, float worldSize)
{
  __int64 v4; // rbx
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // r12
  int mNumPolygons; // edx
  unsigned __int8 *mPolygonData; // r8
  int *mPolygonOffsets; // rdi
  __int64 v9; // rax
  FMOD::OctreeNode *mPolygonUpdateList; // rsi
  __int64 v11; // rcx
  FMOD::OctreeNode *v12; // rcx

  v4 = 0;
  mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  FMOD::Octree::setMaxSize(&this->mOctree, a2, worldSize);
  if ( this->mNumPolygons > 0 )
  {
    do
    {
      FMOD::Octree::deleteItem(&this->mOctree, (FMOD::OctreeNode *)&this->mPolygonData[this->mPolygonOffsets[v4]]);
      mNumPolygons = this->mNumPolygons;
      ++v4;
    }
    while ( mNumPolygons > (int)v4 );
    if ( mNumPolygons > 0 )
    {
      mPolygonData = this->mPolygonData;
      mPolygonOffsets = this->mPolygonOffsets;
      v9 = 0;
      mPolygonUpdateList = this->mPolygonUpdateList;
      do
      {
        v11 = mPolygonOffsets[v9++];
        v12 = (FMOD::OctreeNode *)&mPolygonData[v11];
        v12->nextItem = mPolygonUpdateList;
        mPolygonUpdateList = v12;
      }
      while ( mNumPolygons > (int)v9 );
      this->mPolygonUpdateList = v12;
    }
  }
  FMOD::GeometryI::setToBeUpdated(this);
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
  return 0;
}


// Address: 0x225f580 | Name: _ZN4FMOD9GeometryI14removeFromTreeEv
void __fastcall FMOD::GeometryI::removeFromTree(FMOD::GeometryI *const this)
{
  FMOD_OS_CRITICALSECTION *mGeometryCrit; // rbp

  mGeometryCrit = this->mGeometryMgr->mGeometryCrit;
  FMOD_OS_CriticalSection_Enter(mGeometryCrit);
  FMOD::Octree::deleteItem(this->mGeometryMgr->mMainOctree, &this->mSpatialData->octreeNode);
  FMOD_OS_CriticalSection_Leave(mGeometryCrit);
}


// Address: 0x225f5d0 | Name: _ZN4FMOD9GeometryI8validateEPNS_8GeometryEPPS0_
FMOD_RESULT_0 __fastcall FMOD::GeometryI::validate(FMOD::Geometry *geometry, FMOD::GeometryI **geometryi)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( geometryi )
  {
    LOBYTE(result) = 30;
    if ( geometry )
    {
      *geometryi = (FMOD::GeometryI *)geometry;
      LOBYTE(result) = 0;
    }
  }
  return result;
}


