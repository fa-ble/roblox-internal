// Address: 0x22056e0 | Name: _ZN4FMOD10GpuCompute11IsAvaliableEv
bool __cdecl FMOD::GpuCompute::IsAvaliable()
{
  return FMOD::GpuCompute::Instance != 0;
}


// Address: 0x22056f0 | Name: _ZN4FMOD10GpuCompute3GetEv
FMOD::GpuCompute *__cdecl FMOD::GpuCompute::Get()
{
  return FMOD::GpuCompute::Instance;
}


