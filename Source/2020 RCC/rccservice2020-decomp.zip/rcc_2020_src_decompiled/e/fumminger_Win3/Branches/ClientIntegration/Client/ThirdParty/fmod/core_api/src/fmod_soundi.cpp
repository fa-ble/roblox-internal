// Address: 0x224e840 | Name: _ZN4FMOD6SoundI15getSystemObjectEPPNS_6SystemE
FMOD_RESULT_0 __fastcall FMOD::SoundI::getSystemObject(FMOD::SoundI *const this, FMOD::System **system)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( system )
  {
    *system = (FMOD::System *)this->mSystem;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224e860 | Name: _ZN4FMOD6SoundI4lockEjjPPvS2_PjS3_
FMOD_RESULT_0 __fastcall FMOD::SoundI::lock(
        FMOD::SoundI *const this,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  return FMOD_RESULT::FMOD_ERR_BADCOMMAND_0;
}


// Address: 0x224e870 | Name: _ZN4FMOD6SoundI6unlockEPvS1_jj
FMOD_RESULT_0 __fastcall FMOD::SoundI::unlock(
        FMOD::SoundI *const this,
        void *ptr1,
        void *ptr2,
        unsigned int len1,
        unsigned int len2)
{
  return FMOD_RESULT::FMOD_ERR_BADCOMMAND_0;
}


// Address: 0x224e880 | Name: _ZN4FMOD6SoundI11setDefaultsEfi
__int64 __fastcall FMOD::SoundI::setDefaults(FMOD::SoundI *const this, float a2, float frequency, int priority)
{
  if ( priority < 0 )
  {
    this->mDefaultFrequency = a2;
    this->mDefaultPriority = 0;
    return 0;
  }
  else
  {
    this->mDefaultFrequency = a2;
    if ( priority >= 257 )
      priority = 256;
    this->mDefaultPriority = priority;
    return 0;
  }
}


// Address: 0x224e8b0 | Name: _ZN4FMOD6SoundI11getDefaultsEPfPi
FMOD_RESULT_0 __fastcall FMOD::SoundI::getDefaults(FMOD::SoundI *const this, float *frequency, int *priority)
{
  if ( frequency )
    *frequency = this->mDefaultFrequency;
  if ( priority )
    *priority = this->mDefaultPriority;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224e8d0 | Name: _ZN4FMOD6SoundI19set3DMinMaxDistanceEff
char __fastcall FMOD::SoundI::set3DMinMaxDistance(FMOD::SoundI *const this, float a2, float min, float max)
{
  char result; // al

  result = 31;
  if ( a2 >= 0.0 && min >= 0.0 && a2 <= min )
  {
    this->mMinDistance = a2;
    this->mMaxDistance = min;
    return 0;
  }
  return result;
}


// Address: 0x224e900 | Name: _ZN4FMOD6SoundI19get3DMinMaxDistanceEPfS1_
FMOD_RESULT_0 __fastcall FMOD::SoundI::get3DMinMaxDistance(FMOD::SoundI *const this, float *min, float *max)
{
  if ( min )
    *min = this->mMinDistance;
  if ( max )
    *max = this->mMaxDistance;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224e920 | Name: _ZN4FMOD6SoundI17set3DConeSettingsEfff
__int64 __fastcall FMOD::SoundI::set3DConeSettings(
        FMOD::SoundI *const this,
        __m128 a2,
        __m128 insideconeangle,
        float outsideconeangle,
        float outsidevolume)
{
  __m128 v5; // xmm0
  __m128 v6; // xmm1
  __m128 v7; // xmm5
  __int32 v8; // xmm6_4
  __m128 v9; // xmm5
  __int32 v10; // xmm0_4
  float v11; // xmm1_4
  float v12; // xmm2_4

  v5.m128_i32[0] = a2.m128_i32[0] & _mm_cmpge_ss(a2, (__m128)0LL).m128_u32[0];
  v6.m128_i32[0] = insideconeangle.m128_i32[0] & _mm_cmpge_ss(insideconeangle, (__m128)0LL).m128_u32[0];
  v7 = _mm_cmpge_ss((__m128)0x43B40000u, v5);
  v8 = v5.m128_i32[0] & v7.m128_i32[0];
  v5.m128_f32[0] = _mm_andnot_ps(v7, (__m128)0x43B40000u).m128_f32[0];
  v9 = _mm_cmpge_ss((__m128)0x43B40000u, v6);
  v10 = v5.m128_i32[0] | v8;
  LODWORD(v11) = _mm_andnot_ps(v9, (__m128)0x43B40000u).m128_u32[0] | v6.m128_i32[0] & v9.m128_i32[0];
  if ( outsideconeangle < 0.0 )
    v12 = 0.0;
  else
    v12 = fminf(1.0, outsideconeangle);
  LODWORD(this->mConeInsideAngle) = v10;
  this->mConeOutsideAngle = v11;
  this->mConeOutsideVolume = v12;
  return 0;
}


// Address: 0x224e9b0 | Name: _ZN4FMOD6SoundI17get3DConeSettingsEPfS1_S1_
FMOD_RESULT_0 __fastcall FMOD::SoundI::get3DConeSettings(
        FMOD::SoundI *const this,
        float *insideconeangle,
        float *outsideconeangle,
        float *outsidevolume)
{
  if ( insideconeangle )
    *insideconeangle = this->mConeInsideAngle;
  if ( outsideconeangle )
    *outsideconeangle = this->mConeOutsideAngle;
  if ( outsidevolume )
    *outsidevolume = this->mConeOutsideVolume;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224e9f0 | Name: _ZN4FMOD6SoundI18get3DCustomRolloffEPP11FMOD_VECTORPi
FMOD_RESULT_0 __fastcall FMOD::SoundI::get3DCustomRolloff(
        FMOD::SoundI *const this,
        FMOD_VECTOR **points,
        int *numpoints)
{
  if ( points )
    *points = this->mRolloffPoint;
  if ( numpoints )
    *numpoints = this->mNumRolloffPoints;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224ea10 | Name: _ZN4FMOD6SoundI17getSubSoundParentEPPS0_
FMOD_RESULT_0 __fastcall FMOD::SoundI::getSubSoundParent(FMOD::SoundI *const this, FMOD::SoundI **parentsound)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( parentsound )
  {
    *parentsound = this->mSubSoundParent;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224ea30 | Name: _ZN4FMOD6SoundI15getNumSubSoundsEPi
FMOD_RESULT_0 __fastcall FMOD::SoundI::getNumSubSounds(FMOD::SoundI *const this, int *numsubsounds)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numsubsounds )
  {
    *numsubsounds = this->mNumSubSounds;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224ea50 | Name: _ZN4FMOD6SoundI13getSoundGroupEPPNS_11SoundGroupIE
FMOD_RESULT_0 __fastcall FMOD::SoundI::getSoundGroup(FMOD::SoundI *const this, FMOD::SoundGroupI **soundgroup)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( soundgroup )
  {
    *soundgroup = this->mSoundGroup;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224ea70 | Name: _ZN4FMOD6SoundI12addSyncPointEjjPKcPP14FMOD_SYNCPOINTib
FMOD_RESULT_0 __fastcall FMOD::SoundI::addSyncPoint(
        FMOD::SoundI *const this,
        unsigned int offset,
        FMOD_TIMEUNIT offsettype,
        const char *name,
        FMOD_SYNCPOINT **syncpoint,
        int subsound,
        bool fixupindicies)
{
  if ( syncpoint )
    *syncpoint = 0;
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::SoundI *const, unsigned int, FMOD_TIMEUNIT, const char *, FMOD_SYNCPOINT **, int))this->_vptr_SoundI
          + 33))(
           this,
           offset,
           offsettype,
           name,
           syncpoint,
           subsound);
}


// Address: 0x224eaa0 | Name: _ZN4FMOD6SoundI7getModeEPj
FMOD_RESULT_0 __fastcall FMOD::SoundI::getMode(FMOD::SoundI *const this, FMOD_MODE *mode)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( mode )
  {
    *mode = this->mMode;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224eac0 | Name: _ZN4FMOD6SoundI12setLoopCountEi
FMOD_RESULT_0 __fastcall FMOD::SoundI::setLoopCount(FMOD::SoundI *const this, int loopcount)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( loopcount >= -1 )
  {
    this->mLoopCount = loopcount;
    LOBYTE(result) = 0;
  }
  return result;
}


// Address: 0x224eae0 | Name: _ZN4FMOD6SoundI12getLoopCountEPi
FMOD_RESULT_0 __fastcall FMOD::SoundI::getLoopCount(FMOD::SoundI *const this, int *loopcount)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( loopcount )
  {
    *loopcount = this->mLoopCount;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224eb00 | Name: _ZN4FMOD6SoundI11getPositionEPj
FMOD_RESULT_0 __fastcall FMOD::SoundI::getPosition(FMOD::SoundI *const this, unsigned int *pcm)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( pcm )
  {
    *pcm = this->mPosition;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224eb20 | Name: _ZN4FMOD6SoundI19getMusicNumChannelsEPi
FMOD_RESULT_0 __fastcall FMOD::SoundI::getMusicNumChannels(FMOD::SoundI *const this, int *numchannels)
{
  FMOD::Codec *mCodec; // rdi
  FMOD_RESULT_0 (__fastcall *getmusicnumchannels)(FMOD::Codec *, int *); // rax

  mCodec = this->mCodec;
  if ( mCodec
    && (getmusicnumchannels = (FMOD_RESULT_0 (__fastcall *)(FMOD::Codec *, int *))mCodec->mDescription.getmusicnumchannels) != 0 )
  {
    return getmusicnumchannels(mCodec, numchannels);
  }
  else
  {
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
}


// Address: 0x224eb50 | Name: _ZN4FMOD6SoundI21setMusicChannelVolumeEif
FMOD_RESULT_0 __fastcall FMOD::SoundI::setMusicChannelVolume(
        FMOD::SoundI *const this,
        __int64 channel,
        double a3,
        float volume)
{
  FMOD::Codec *mCodec; // rdi
  FMOD_RESULT_0 (__fastcall *setmusicchannelvolume)(FMOD::Codec *, __int64, double, float); // rax

  mCodec = this->mCodec;
  if ( mCodec
    && (setmusicchannelvolume = (FMOD_RESULT_0 (__fastcall *)(FMOD::Codec *, __int64, double, float))mCodec->mDescription.setmusicchannelvolume) != 0 )
  {
    return setmusicchannelvolume(mCodec, channel, a3, volume);
  }
  else
  {
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
}


// Address: 0x224eb80 | Name: _ZN4FMOD6SoundI21getMusicChannelVolumeEiPf
FMOD_RESULT_0 __fastcall FMOD::SoundI::getMusicChannelVolume(FMOD::SoundI *const this, int channel, float *volume)
{
  FMOD::Codec *mCodec; // rdi
  FMOD_RESULT_0 (__fastcall *getmusicchannelvolume)(FMOD::Codec *, int, float *); // rax

  mCodec = this->mCodec;
  if ( mCodec
    && (getmusicchannelvolume = (FMOD_RESULT_0 (__fastcall *)(FMOD::Codec *, int, float *))mCodec->mDescription.getmusicchannelvolume) != 0 )
  {
    return getmusicchannelvolume(mCodec, channel, volume);
  }
  else
  {
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
}


// Address: 0x224ebb0 | Name: _ZN4FMOD6SoundI13setMusicSpeedEf
FMOD_RESULT_0 __fastcall FMOD::SoundI::setMusicSpeed(FMOD::SoundI *const this, double a2, float speed)
{
  FMOD::Codec *mCodec; // rdi
  FMOD_RESULT_0 (__fastcall *setmusicspeed)(double); // rax

  if ( *(float *)&a2 < 0.0099999998 )
  {
    *(_QWORD *)&a2 = 1008981770;
  }
  else if ( *(float *)&a2 > 100.0 )
  {
    *(_QWORD *)&a2 = 1120403456;
  }
  mCodec = this->mCodec;
  if ( mCodec && (setmusicspeed = (FMOD_RESULT_0 (__fastcall *)(double))mCodec->mDescription.setmusicspeed) != 0 )
    return setmusicspeed(a2);
  else
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
}


// Address: 0x224ec00 | Name: _ZN4FMOD6SoundI13getMusicSpeedEPf
FMOD_RESULT_0 __fastcall FMOD::SoundI::getMusicSpeed(FMOD::SoundI *const this, float *speed)
{
  FMOD::Codec *mCodec; // rdi
  FMOD_RESULT_0 (*getmusicspeed)(void); // rax

  if ( !speed )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mCodec = this->mCodec;
  if ( mCodec )
  {
    getmusicspeed = (FMOD_RESULT_0 (*)(void))mCodec->mDescription.getmusicspeed;
    if ( getmusicspeed )
      return getmusicspeed();
  }
  *speed = 0.0;
  return FMOD_RESULT::FMOD_ERR_FORMAT_0;
}


// Address: 0x224ec40 | Name: _ZN4FMOD6SoundI11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::SoundI::setUserData(FMOD::SoundI *const this, void *userdata)
{
  this->mUserData = userdata;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224ec50 | Name: _ZN4FMOD6SoundI11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::SoundI::getUserData(FMOD::SoundI *const this, void **userdata)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( userdata )
  {
    *userdata = this->mUserData;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224ec70 | Name: _ZN4FMOD6SoundI13setSoundGroupEPNS_11SoundGroupIE
FMOD_RESULT_0 __fastcall FMOD::SoundI::setSoundGroup(FMOD::SoundI *const this, FMOD::SoundGroupI *soundgroup)
{
  FMOD::SoundGroupI *mSoundGroup; // rbp
  __int64 v3; // rax
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::SoundGroupI *v5; // rax
  FMOD::LinkedListNode *v6; // rdx
  FMOD::SystemI *mSystem; // rcx
  FMOD::LinkedListNode *mNodeNext; // rdx
  FMOD::SoundGroupI *mMasterSoundGroup; // rdx

  mSoundGroup = soundgroup;
  if ( !(*this->_vptr_SoundI)(this) )
  {
    v3 = 0;
    this->mSoundGroup = soundgroup;
    if ( soundgroup )
      goto LABEL_5;
    goto LABEL_7;
  }
  v3 = *((_QWORD *)this + 48);
  this->mSoundGroup = soundgroup;
  if ( v3 )
  {
    *(_QWORD *)(v3 + 280) = soundgroup;
    mSoundGroup = this->mSoundGroup;
  }
  if ( !mSoundGroup )
  {
LABEL_7:
    mMasterSoundGroup = this->mSystem->mMasterSoundGroup;
    this->mSoundGroup = mMasterSoundGroup;
    if ( v3 )
      *(_QWORD *)(v3 + 280) = mMasterSoundGroup;
  }
LABEL_5:
  FMOD_OS_CriticalSection_Enter(off_286F358->gSoundListCrit);
  mNodePrev = this->mSoundGroupNode.mNodePrev;
  mNodePrev->mNodeNext = this->mSoundGroupNode.mNodeNext;
  this->mSoundGroupNode.mNodeNext->mNodePrev = mNodePrev;
  v5 = this->mSoundGroup;
  this->mSoundGroupNode.mNodePrev = &this->mSoundGroupNode;
  this->mSoundGroupNode.mNodePrev = v5->mSoundHead.mNodePrev;
  this->mSoundGroupNode.mNodeNext = &v5->mSoundHead;
  v5->mSoundHead.mNodePrev = &this->mSoundGroupNode;
  this->mSoundGroupNode.mNodePrev->mNodeNext = &this->mSoundGroupNode;
  this->mSoundGroupNode.mNodeData = this;
  v6 = v5->mNodePrev;
  v6->mNodeNext = v5->mNodeNext;
  v5->mNodeNext->mNodePrev = v6;
  mSystem = this->mSystem;
  v5->mNodeNext = v5;
  mNodeNext = mSystem->mSoundGroupUsedHead.mNodeNext;
  v5->mNodePrev = &mSystem->mSoundGroupUsedHead;
  v5->mNodeNext = mNodeNext;
  mNodeNext->mNodePrev = v5;
  v5->mNodePrev->FMOD::LinkedListNode::mNodeNext = v5;
  FMOD_OS_CriticalSection_Leave(off_286F358->gSoundListCrit);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224edc0 | Name: _ZN4FMOD6SoundI12getOpenStateEP14FMOD_OPENSTATEPjPbS4_
FMOD_RESULT_0 __fastcall FMOD::SoundI::getOpenState(
        FMOD::SoundI *const this,
        FMOD_OPENSTATE_1 *openstate,
        unsigned int *percentbuffered,
        bool *starving,
        bool *diskbusy)
{
  FMOD::AsyncData *mAsyncData; // rsi
  FMOD_RESULT_0 result; // eax
  FMOD::Codec *v8; // rdi
  FMOD::Codec *v9; // rdx
  FMOD::File *v10; // rdx
  FMOD::Codec *v11; // rdx
  FMOD::File *v12; // rdx
  char v13; // al
  FMOD::Codec *mCodec; // rax
  FMOD::File *mFile; // rax
  volatile unsigned int mFlags; // edi
  FMOD::SoundI *mSubSoundShared; // rax
  unsigned int mLastAudibleDSPTick; // r9d
  int mNumAudible; // eax
  FMOD::SoundI **mSubSound; // rax
  unsigned int *percentbuffereda; // [rsp+8h] [rbp-20h]
  bool *starvinga; // [rsp+10h] [rbp-18h]
  bool *diskbusya; // [rsp+18h] [rbp-10h]

  if ( !openstate )
    goto LABEL_3;
  *openstate = this->mOpenState.m_value;
  if ( (this->mFlags.m_value & 4) == 0 )
    goto LABEL_3;
  diskbusya = diskbusy;
  starvinga = starving;
  percentbuffereda = percentbuffered;
  v13 = (*this->_vptr_SoundI)(this);
  percentbuffered = percentbuffereda;
  starving = starvinga;
  diskbusy = diskbusya;
  if ( !v13 )
  {
    if ( !this->mNumAudible
      && (signed int)(*(_DWORD *)((char *)&stru_11610.r_offset + (unsigned __int64)this->mSystem)
                    - this->mLastAudibleDSPTick) > 1 )
    {
      goto LABEL_3;
    }
    goto LABEL_31;
  }
  if ( *openstate )
    goto LABEL_3;
  mCodec = this->mCodec;
  if ( !mCodec )
    goto LABEL_3;
  mFile = mCodec->mFile;
  if ( !mFile )
  {
    if ( (this->mFlags.m_value & 0x40) != 0 )
      goto LABEL_34;
    goto LABEL_31;
  }
  mFlags = mFile->mFlags;
  result = mFile->mAsyncError;
  if ( (result & 0xFFFFFFEF) == 0 )
  {
    if ( (this->mFlags.m_value & 0x40) != 0 && (mFlags & 0x10) == 0 )
    {
LABEL_34:
      mSubSoundShared = this->mSubSoundShared;
      if ( mSubSoundShared
        || (mSubSound = this->mSubSound) != 0 && (mSubSoundShared = mSubSound[this->mSubSoundIndex]) != 0 )
      {
        mLastAudibleDSPTick = mSubSoundShared->mLastAudibleDSPTick;
        mNumAudible = mSubSoundShared->mNumAudible;
      }
      else
      {
        mLastAudibleDSPTick = this->mLastAudibleDSPTick;
        mNumAudible = this->mNumAudible;
      }
      if ( !mNumAudible
        && (int)(*(_DWORD *)((char *)&stru_11610.r_offset + (unsigned __int64)this->mSystem) - mLastAudibleDSPTick) > 1 )
      {
        goto LABEL_3;
      }
    }
LABEL_31:
    *openstate = FMOD_OPENSTATE::FMOD_OPENSTATE_PLAYING_0;
LABEL_3:
    mAsyncData = this->mAsyncData;
    result = FMOD_RESULT::FMOD_OK_0;
    goto LABEL_4;
  }
  *openstate = FMOD_OPENSTATE::FMOD_OPENSTATE_ERROR_0;
  mAsyncData = this->mAsyncData;
  if ( mAsyncData )
    mAsyncData->mResult = result;
LABEL_4:
  if ( percentbuffered )
  {
    v8 = this->mCodec;
    if ( v8
      && v8->mFile
      && (this->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_BUFFERING_0
       || this->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_READY_0) )
    {
      *percentbuffered = v8->mFile->mPercentBuffered;
    }
    else
    {
      *percentbuffered = 0;
    }
  }
  if ( starving )
  {
    v9 = this->mCodec;
    *starving = 0;
    if ( v9 )
    {
      v10 = v9->mFile;
      if ( v10 )
        *starving = (v10->mFlags & 0x20) != 0;
    }
  }
  if ( diskbusy )
  {
    v11 = this->mCodec;
    if ( v11 )
    {
      v12 = v11->mFile;
      if ( v12 )
        *diskbusy = (v12->mFlags & 0x10) != 0;
    }
  }
  if ( mAsyncData )
    return mAsyncData->mResult;
  return result;
}


// Address: 0x224f000 | Name: _ZN4FMOD6SoundI18allocateNameMemoryEv
FMOD_RESULT_0 __fastcall FMOD::SoundI::allocateNameMemory(FMOD::SoundI *const this)
{
  char *mNameMemory; // rax
  FMOD_RESULT_0 result; // eax
  char *v3; // rdx

  mNameMemory = this->mNameMemory;
  if ( mNameMemory )
    goto LABEL_2;
  v3 = (char *)FMOD::MemPool::calloc(off_286F358->gSystemMemPool, 256, "../../../core_api/src/fmod_soundi.cpp", 1452, 0);
  this->mNameMemory = v3;
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v3 )
  {
    mNameMemory = v3;
LABEL_2:
    this->mName = mNameMemory;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224f060 | Name: _ZN4FMOD6SoundI7getNameEPci
FMOD_RESULT_0 __fastcall FMOD::SoundI::getName(FMOD::SoundI *const this, char *name, int namelen)
{
  FMOD_RESULT_0 result; // eax
  const char *mName; // rsi

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( name )
  {
    mName = this->mName;
    LOWORD(result) = 256;
    if ( namelen <= 256 )
      result = namelen;
    if ( !mName )
      mName = (const char *)&uri_string;
    FMOD_strcpy_safe(name, mName, result);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224f0b0 | Name: _ZN4FMOD6SoundI6getTagEPKciP8FMOD_TAG
FMOD_RESULT_0 __fastcall FMOD::SoundI::getTag(FMOD::SoundI *const this, const char *name, int index, FMOD_TAG *tag)
{
  FMOD::Codec *mCodec; // rax
  FMOD::Metadata *mMetadata; // rdi

  if ( !tag )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mCodec = this->mCodec;
  if ( mCodec && (mMetadata = mCodec->mMetadata) != 0 )
    return FMOD::Metadata::getTag(mMetadata, name, index, tag);
  else
    return FMOD_RESULT::FMOD_ERR_TAGNOTFOUND_0;
}


// Address: 0x224f0f0 | Name: _ZN4FMOD6SoundI7setModeEj
FMOD_RESULT_0 __fastcall FMOD::SoundI::setMode(FMOD::SoundI *const this, FMOD_MODE mode)
{
  FMOD_MODE mMode; // eax
  FMOD_MODE v3; // eax
  FMOD_MODE v4; // eax
  FMOD::SoundI *mSubSoundParent; // rax

  mMode = this->mMode;
  if ( (mode & 7) != 0 )
  {
    v3 = mMode & 0xFFFFFFF8;
    if ( (mode & 1) != 0 )
    {
      this->mMode = v3 | 1;
    }
    else if ( (mode & 2) != 0 )
    {
      this->mMode = v3 | 2;
    }
    else
    {
      if ( (mode & 4) != 0 )
        v3 |= 4u;
      this->mMode = v3;
    }
    if ( (*this->_vptr_SoundI)(this) )
    {
      if ( (mode & 6) != 0 && (this->mFlags.m_value & 0x80u) == 0 )
      {
        _InterlockedAnd((volatile signed __int32 *)&this->mFlags, 0xFFFFFFB7);
        mSubSoundParent = this->mSubSoundParent;
        if ( mSubSoundParent )
          _InterlockedAnd((volatile signed __int32 *)&mSubSoundParent->mFlags, 0xFFFFFFB7);
      }
      mMode = this->mMode;
      *(_DWORD *)(*((_QWORD *)this + 47) + 56LL) = *(_DWORD *)(*((_QWORD *)this + 47) + 56LL) & 0xFFFFFFF8 | mMode & 7;
    }
    else
    {
      mMode = this->mMode;
    }
  }
  if ( (mode & 0x40000) != 0 )
  {
    mMode = mMode & 0xFFF3FFFF | 0x40000;
    this->mMode = mMode;
    if ( (mode & 0x100000) != 0 )
    {
LABEL_11:
      mMode = mMode & 0xFB0FFFFF | 0x100000;
      this->mMode = mMode;
      goto LABEL_12;
    }
  }
  else
  {
    if ( (mode & 0x80000) != 0 )
    {
      mMode = mMode & 0xFFF3FFFF | 0x80000;
      this->mMode = mMode;
    }
    if ( (mode & 0x100000) != 0 )
      goto LABEL_11;
  }
  if ( (mode & 0x200000) == 0 )
  {
    if ( (mode & 0x400000) != 0 )
    {
      mMode = mMode & 0xFB0FFFFF | 0x400000;
      this->mMode = mMode;
    }
    else if ( (mode & 0x800000) != 0 )
    {
      mMode = mMode & 0xFB0FFFFF | 0x800000;
      this->mMode = mMode;
    }
    else if ( (mode & 0x4000000) != 0 )
    {
      mMode = mMode & 0xFB0FFFFF | 0x4000000;
      this->mMode = mMode;
    }
LABEL_12:
    if ( (mode & 0x40000000) != 0 )
      goto LABEL_13;
LABEL_25:
    v4 = mMode & 0xBFFFFFFF;
    this->mMode = v4;
    if ( (mode & 0x80000000) == 0 )
      goto LABEL_14;
    goto LABEL_26;
  }
  mMode = mMode & 0xFB0FFFFF | 0x200000;
  this->mMode = mMode;
  if ( (mode & 0x40000000) == 0 )
    goto LABEL_25;
LABEL_13:
  v4 = mMode | 0x40000000;
  this->mMode = v4;
  if ( (mode & 0x80000000) == 0 )
  {
LABEL_14:
    this->mMode = v4 & 0x7FFFFFFF;
    goto LABEL_15;
  }
LABEL_26:
  this->mMode = v4 | 0x80000000;
LABEL_15:
  if ( !(*this->_vptr_SoundI)(this) )
  {
    if ( (mode & 0x20000) != 0 )
      this->mMode |= 0x20000u;
    else
      this->mMode &= ~0x20000u;
  }
  if ( (mode & 8) != 0 )
  {
    this->mMode = this->mMode & 0xFFFFFFE7 | 8;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( (mode & 0x10) != 0 )
      this->mMode = this->mMode & 0xFFFFFFE7 | 0x10;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x224f350 | Name: _ZN4FMOD6SoundI18set3DCustomRolloffEP11FMOD_VECTORi
FMOD_RESULT_0 __fastcall FMOD::SoundI::set3DCustomRolloff(FMOD::SoundI *const this, FMOD_VECTOR *points, int numpoints)
{
  FMOD_RESULT_0 result; // eax
  float y; // xmm0_4
  FMOD_VECTOR *v5; // rax
  float v6; // xmm0_4

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numpoints >= 0 )
  {
    if ( !points || numpoints <= 1 )
    {
LABEL_12:
      this->mRolloffPoint = points;
      this->mNumRolloffPoints = numpoints;
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( points->x < points[1].x )
    {
      y = points[1].y;
      if ( y >= 0.0 && y <= 1.0 )
      {
        v5 = points;
        while ( v5 != &points[numpoints - 2] )
        {
          if ( v5[1].x < v5[2].x )
          {
            v6 = v5[2].y;
            if ( v6 >= 0.0 )
            {
              ++v5;
              if ( v6 <= 1.0 )
                continue;
            }
          }
          return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        }
        goto LABEL_12;
      }
    }
  }
  return result;
}


// Address: 0x224f3e0 | Name: _ZN4FMOD6SoundI10getNumTagsEPiS1_
FMOD_RESULT_0 __fastcall FMOD::SoundI::getNumTags(FMOD::SoundI *const this, int *numtags, int *numtagsupdated)
{
  FMOD_RESULT_0 result; // eax
  FMOD::Codec *mCodec; // rax
  FMOD::Metadata *mMetadata; // rdi

  if ( numtags || (result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0, numtagsupdated) )
  {
    if ( numtags )
      *numtags = 0;
    if ( numtagsupdated )
      *numtagsupdated = 0;
    mCodec = this->mCodec;
    if ( mCodec && (mMetadata = mCodec->mMetadata) != 0 )
      return FMOD::Metadata::getNumTags(mMetadata, numtags, numtagsupdated);
    else
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224f440 | Name: _ZN4FMOD6SoundI16getNumSyncPointsEPi
FMOD_RESULT_0 __fastcall FMOD::SoundI::getNumSyncPoints(FMOD::SoundI *const this, int *numsyncpoints)
{
  FMOD_RESULT_0 result; // eax
  int *mNumSyncPointsMulti; // rax
  FMOD::SyncPoint *mSyncPointHead; // rax
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::SyncPoint *i; // rcx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numsyncpoints )
  {
    if ( this->mSubSoundShared )
    {
      mNumSyncPointsMulti = this->mNumSyncPointsMulti;
      if ( mNumSyncPointsMulti )
      {
        *numsyncpoints = mNumSyncPointsMulti[this->mSubSoundIndex];
        return FMOD_RESULT::FMOD_OK_0;
      }
      mSyncPointHead = this->mSyncPointHead;
      *numsyncpoints = 0;
      if ( mSyncPointHead )
      {
        mNodeNext = mSyncPointHead->mNodeNext;
        for ( i = this->mSyncPointTail; mNodeNext != i; mNodeNext = mNodeNext->mNodeNext )
        {
          if ( LOWORD(mNodeNext[2].mNodeNext) == this->mSubSoundIndex )
            ++*numsyncpoints;
        }
      }
    }
    else
    {
      *numsyncpoints = this->mNumSyncPoints;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224f4d0 | Name: _ZN4FMOD6SoundI12getSyncPointEiPP14FMOD_SYNCPOINT
FMOD_RESULT_0 __fastcall FMOD::SoundI::getSyncPoint(FMOD::SoundI *const this, int index, FMOD_SYNCPOINT **point)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SyncPoint *mSyncPointTail; // rsi
  unsigned __int16 *mNodeNext; // rax
  FMOD::SoundI *mSubSoundShared; // rdi
  int v10; // edx
  int numsyncpoints[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::SoundI *const, int *))this->_vptr_SoundI + 29))(this, numsyncpoints);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( index >= 0 && index < numsyncpoints[0] && point )
    {
      mSyncPointTail = this->mSyncPointTail;
      mNodeNext = (unsigned __int16 *)this->mSyncPointHead->mNodeNext;
      if ( mNodeNext == (unsigned __int16 *)mSyncPointTail )
        return FMOD_RESULT::FMOD_OK_0;
      mSubSoundShared = this->mSubSoundShared;
      v10 = 0;
      while ( 1 )
      {
        if ( !mSubSoundShared || mNodeNext[24] == this->mSubSoundIndex )
        {
          if ( index <= v10 )
          {
            *point = (FMOD_SYNCPOINT *)mNodeNext;
            return FMOD_RESULT::FMOD_OK_0;
          }
          ++v10;
        }
        mNodeNext = *(unsigned __int16 **)mNodeNext;
        if ( mSyncPointTail == (FMOD::SyncPoint *)mNodeNext )
          return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x224f580 | Name: _ZN4FMOD6SoundI9getFormatEP15FMOD_SOUND_TYPEP17FMOD_SOUND_FORMATPiS5_
FMOD_RESULT_0 __fastcall FMOD::SoundI::getFormat(
        FMOD::SoundI *const this,
        FMOD_SOUND_TYPE_0 *type,
        FMOD_SOUND_FORMAT_0 *format,
        int *channels,
        int *bits)
{
  FMOD_RESULT_0 result; // eax

  if ( type )
    *type = this->mType;
  if ( format )
    *format = this->mFormat;
  if ( channels )
    *channels = this->mChannels;
  if ( !bits )
    return FMOD_RESULT::FMOD_OK_0;
  switch ( this->mFormat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      *bits = 8;
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      *bits = 16;
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      *bits = 24;
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      *bits = 32;
      result = FMOD_RESULT::FMOD_OK_0;
      break;
    default:
      *bits = 0;
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224f610 | Name: _ZN4FMOD6SoundI9getLengthEPjj
FMOD_RESULT_0 __fastcall FMOD::SoundI::getLength(
        FMOD::SoundI *const this,
        unsigned int *length,
        FMOD_TIMEUNIT lengthtype)
{
  FMOD::Codec *mCodec; // rdi
  float mDefaultFrequency; // xmm0_4
  __int64 v6; // rax
  unsigned __int64 v7; // rax
  unsigned __int64 v8; // rcx
  unsigned __int64 mLength; // rax
  __int64 v10; // rdx

  if ( !length )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( lengthtype == 2 )
  {
    *length = this->mLength;
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( lengthtype != 1 )
  {
    if ( lengthtype != 4 )
    {
      mCodec = this->mCodec;
      if ( mCodec )
        return FMOD::Codec::getLength(mCodec, length, lengthtype);
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
    mLength = this->mLength;
    if ( (_DWORD)mLength != -1 )
    {
      switch ( this->mFormat )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
          v10 = 8;
          goto LABEL_19;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          v10 = 16;
          goto LABEL_19;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          v10 = 24;
          goto LABEL_19;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          v10 = 32;
LABEL_19:
          mLength = (v10 * mLength) >> 3;
          break;
        default:
          break;
      }
      *length = this->mChannels * mLength;
      return FMOD_RESULT::FMOD_OK_0;
    }
LABEL_14:
    *length = -1;
    return FMOD_RESULT::FMOD_OK_0;
  }
  mDefaultFrequency = this->mDefaultFrequency;
  if ( mDefaultFrequency == 0.0 )
    goto LABEL_14;
  v6 = this->mLength;
  if ( (_DWORD)v6 == -1 )
    goto LABEL_14;
  v7 = 1000 * v6;
  v8 = (unsigned int)(int)mDefaultFrequency;
  if ( mDefaultFrequency >= 9.223372e18 )
    v8 = (unsigned int)(int)(float)(mDefaultFrequency - 9.223372e18) ^ 0x8000000000000000LL;
  *length = v7 / v8;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224f720 | Name: _ZN4FMOD6SoundI8readDataEPvjPj
FMOD_RESULT_0 __fastcall FMOD::SoundI::readData(
        FMOD::SoundI *const this,
        void *buffer,
        unsigned int bytes_in,
        unsigned int *bytes_out)
{
  FMOD_RESULT_0 v4; // eax
  FMOD::Codec *mCodec; // r8
  FMOD_MODE mMode; // edx
  unsigned int v8; // ebx
  __int64 mSubSoundIndex; // rsi
  FMOD_RESULT_0 v10; // r15d
  FMOD_MODE v11; // eax
  unsigned int v13; // ebp
  unsigned int v14; // r14d
  unsigned int v15; // r13d
  FMOD_RESULT_0 v16; // r11d
  unsigned int v17; // eax
  FMOD_SOUND_PCMREAD_CALLBACK mPostReadCallback; // rcx
  unsigned int v19; // edx
  unsigned int v20; // edx
  unsigned int mLength; // edx
  unsigned int v22; // eax
  FMOD::Codec *v23; // rdi
  FMOD::Codec *v24; // rax
  bool v25; // zf
  unsigned int v26; // ebx
  int (**vptr_SoundI)(...); // rax
  FMOD::SystemI *mSystem; // rdi
  void (__fastcall *v29)(FMOD::SystemI *, __int64, void *, _QWORD, _QWORD); // rax
  int v30; // ebx
  int v31; // ebx
  FMOD_RESULT_0 resulta; // [rsp+1Ch] [rbp-9Ch]
  FMOD_RESULT_0 result; // [rsp+1Ch] [rbp-9Ch]
  unsigned int bytesread; // [rsp+30h] [rbp-88h] BYREF
  unsigned int samplesread; // [rsp+34h] [rbp-84h] BYREF
  void *userData; // [rsp+38h] [rbp-80h] BYREF
  FMOD_CODEC_WAVEFORMAT waveformat; // [rsp+40h] [rbp-78h] BYREF

  v4 = FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
  mCodec = this->mCodec;
  if ( !mCodec )
    return v4;
  LOBYTE(v4) = 31;
  if ( !buffer )
    return v4;
  mMode = this->mMode;
  if ( (mMode & 0x80u) == 0 )
  {
    LOBYTE(v4) = 68;
    if ( !mCodec->mFile )
      return v4;
    v8 = 1;
    if ( (mMode & 0x200) != 0 )
      goto LABEL_5;
  }
  else
  {
    v8 = 1;
    if ( (mMode & 0x200) != 0 )
      goto LABEL_5;
  }
  switch ( this->mFormat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      v30 = 2;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      v30 = 3;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      v30 = 4;
      break;
    default:
      v30 = 1;
      break;
  }
  v8 = this->mChannels * v30;
LABEL_5:
  mSubSoundIndex = (unsigned int)mCodec->mSubSoundIndex;
  memset(&waveformat, 0, sizeof(waveformat));
  v4 = ((unsigned int (__fastcall *)(FMOD::Codec *, __int64))mCodec->mDescription.getwaveformat)(mCodec, mSubSoundIndex);
  v10 = v4;
  if ( v4 == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( (this->mMode & 0x200) == 0 )
    {
      switch ( this->mFormat )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          v31 = 2;
          break;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          v31 = 3;
          break;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          v31 = 4;
          break;
        default:
          v31 = 1;
          break;
      }
      v8 = this->mChannels * v31;
      bytes_in = v8 * (bytes_in / v8);
    }
    if ( bytes_in )
    {
      BYTE1(v11) = BYTE1(this->mMode);
      v13 = 0;
      v14 = bytes_in;
      v15 = 0;
      while ( 1 )
      {
        bytesread = 0;
        if ( (v11 & 0x200) != 0 )
        {
          v16 = FMOD::File::read(this->mCodec->mFile, (char *)buffer + v13, 1u, v14, &bytesread);
          if ( (v16 & 0xFFFFFFEF) != 0 )
            return v16;
          v17 = bytesread;
        }
        else
        {
          v23 = this->mCodec;
          v23->mRoblox_ParsingAnomaly = 0;
          v16 = FMOD::Codec::read(v23, (char *)buffer + v13, v14 / v8, &samplesread);
          v24 = this->mCodec;
          if ( v24->mRoblox_ParsingAnomaly )
          {
            v25 = !this->mRoblox_ParseAnomaly;
            v24->mRoblox_ParsingAnomaly = 0;
            if ( v25 )
            {
              vptr_SoundI = this->_vptr_SoundI;
              result = v16;
              this->mRoblox_ParseAnomaly = 1;
              userData = 0;
              vptr_SoundI[47](this, &userData);
              mSystem = this->mSystem;
              v16 = result;
              v29 = *(void (__fastcall **)(FMOD::SystemI *, __int64, void *, _QWORD, _QWORD))((char *)&stru_11748.r_offset
                                                                                            + (_QWORD)mSystem);
              if ( v29 )
              {
                if ( (mSystem->mCallbackMask & 0x10000000) != 0 )
                {
                  v29(
                    mSystem,
                    0x10000000,
                    userData,
                    0,
                    *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)mSystem));
                  v16 = result;
                }
              }
            }
          }
          if ( (v16 & 0xFFFFFFEF) != 0 )
            return v16;
          v17 = v8 * samplesread;
          bytesread = v8 * samplesread;
        }
        mPostReadCallback = this->mPostReadCallback;
        if ( mPostReadCallback && v17 )
        {
          resulta = v16;
          mPostReadCallback(this->mPostCallbackSound, (char *)buffer + v13, v17);
          v17 = bytesread;
          v16 = resulta;
        }
        v19 = v14;
        v14 = 0;
        v20 = v19 - v17;
        if ( v16 != FMOD_RESULT::FMOD_ERR_FILE_EOF_0 )
          v14 = v20;
        v13 += v17;
        v15 += v17;
        mLength = this->mLength;
        v22 = this->mPosition + v17 / v8;
        this->mPosition = v22;
        if ( v22 > mLength )
          this->mPosition = mLength;
        if ( !v14 )
        {
          v10 = v16;
          v26 = v15;
          goto LABEL_26;
        }
        v11 = this->mMode;
      }
    }
    v26 = 0;
LABEL_26:
    if ( bytes_out )
      *bytes_out = v26;
    return v10;
  }
  return v4;
}


// Address: 0x224fa90 | Name: _ZN4FMOD6SoundI13getLoopPointsEPjjS1_j
FMOD_RESULT_0 __fastcall FMOD::SoundI::getLoopPoints(
        FMOD::SoundI *const this,
        unsigned int *loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int *loopend,
        FMOD_TIMEUNIT loopendtype)
{
  FMOD_RESULT_0 result; // eax
  unsigned __int64 v6; // rdx
  __int64 v7; // rax
  unsigned __int64 mLoopStart; // rax
  __int64 v9; // rdx

  if ( loopstarttype - 1 <= 1 || (result = FMOD_RESULT::FMOD_ERR_FORMAT_0, loopstarttype == 4) )
  {
    if ( loopendtype - 1 <= 1 || (result = FMOD_RESULT::FMOD_ERR_FORMAT_0, loopendtype == 4) )
    {
      if ( loopstart )
      {
        switch ( loopstarttype )
        {
          case 2u:
            *loopstart = this->mLoopStart;
            break;
          case 4u:
            mLoopStart = this->mLoopStart;
            switch ( this->mFormat )
            {
              case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
                v9 = 8;
                goto LABEL_24;
              case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
                v9 = 16;
                goto LABEL_24;
              case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
                v9 = 24;
                goto LABEL_24;
              case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
              case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
                v9 = 32;
LABEL_24:
                mLoopStart = (v9 * mLoopStart) >> 3;
                break;
              default:
                break;
            }
            *loopstart = this->mChannels * mLoopStart;
            break;
          case 1u:
            *loopstart = (int)(float)((float)((float)(int)this->mLoopStart * 1000.0) / this->mDefaultFrequency);
            break;
        }
      }
      if ( loopend )
      {
        v6 = this->mLoopLength + this->mLoopStart - 1;
        if ( loopendtype != 2 )
        {
          if ( loopendtype != 4 )
          {
            result = FMOD_RESULT::FMOD_OK_0;
            if ( loopendtype == 1 )
              *loopend = (int)(float)((float)((float)(int)v6 * 1000.0) / this->mDefaultFrequency);
            return result;
          }
          switch ( this->mFormat )
          {
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
              v7 = 8;
              goto LABEL_17;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
              v7 = 16;
              goto LABEL_17;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
              v7 = 24;
              goto LABEL_17;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
              v7 = 32;
LABEL_17:
              v6 = (v7 * v6) >> 3;
              break;
            default:
              break;
          }
          LODWORD(v6) = this->mChannels * v6;
        }
        *loopend = v6;
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x224fbe0 | Name: _ZN4FMOD6SoundI16getSyncPointInfoEP14FMOD_SYNCPOINTPciPjj
FMOD_RESULT_0 __fastcall FMOD::SoundI::getSyncPointInfo(
        FMOD::SoundI *const this,
        FMOD_SYNCPOINT *point,
        char *name,
        int namelen,
        unsigned int *offset,
        FMOD_TIMEUNIT offsettype)
{
  FMOD_RESULT_0 result; // eax
  const char *v8; // rsi
  unsigned __int64 v9; // rax
  __int64 v10; // rdx
  unsigned int *v11; // [rsp+0h] [rbp-28h]
  FMOD_TIMEUNIT offsettypea; // [rsp+Ch] [rbp-1Ch]

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( point && (name || offset) )
  {
    if ( name )
    {
      v8 = *(const char **)((char *)point + 28);
      offsettypea = offsettype;
      v11 = offset;
      if ( v8 )
      {
        FMOD_strcpy_safe(name, v8, namelen);
        offset = v11;
        offsettype = offsettypea;
      }
      else
      {
        FMOD_strcpy_safe(name, (const char *)&uri_string, namelen);
        offsettype = offsettypea;
        offset = v11;
      }
    }
    if ( offset )
    {
      if ( offsettype == 2 )
      {
        *offset = *((_DWORD *)point + 11);
        return FMOD_RESULT::FMOD_OK_0;
      }
      else if ( offsettype == 4 )
      {
        v9 = *((unsigned int *)point + 11);
        switch ( this->mFormat )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v10 = 8;
            goto LABEL_18;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v10 = 16;
            goto LABEL_18;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v10 = 24;
            goto LABEL_18;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v10 = 32;
LABEL_18:
            v9 = (v10 * v9) >> 3;
            break;
          default:
            break;
        }
        *offset = this->mChannels * v9;
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        result = FMOD_RESULT::FMOD_OK_0;
        if ( offsettype == 1 )
          *offset = (int)(float)((float)((float)*((int *)point + 11) * 1000.0) / this->mDefaultFrequency);
      }
    }
    else
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x224fd00 | Name: _ZN4FMOD6SoundI13setLoopPointsEjjjj
FMOD_RESULT_0 __fastcall FMOD::SoundI::setLoopPoints(
        FMOD::SoundI *const this,
        unsigned int loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int loopend,
        FMOD_TIMEUNIT loopendtype)
{
  FMOD_RESULT_0 result; // eax
  unsigned int mLength; // eax
  unsigned int v8; // edx
  bool v9; // cc
  char v10; // dl
  unsigned int v11; // edi
  unsigned __int64 v12; // r8
  unsigned int mChannels; // edi
  unsigned __int64 v14; // r9

  if ( loopstarttype - 1 > 1 )
  {
    result = FMOD_RESULT::FMOD_ERR_FORMAT_0;
    if ( loopstarttype != 4 )
      return result;
  }
  if ( loopendtype - 1 > 1 )
  {
    result = FMOD_RESULT::FMOD_ERR_FORMAT_0;
    if ( loopendtype != 4 )
      return result;
  }
  if ( loopstarttype != 2 )
  {
    if ( loopstarttype == 4 )
    {
      mChannels = this->mChannels;
      if ( !mChannels )
        goto LABEL_9;
      switch ( this->mFormat )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
          v14 = 8;
          goto LABEL_39;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          v14 = 16;
          goto LABEL_39;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          v14 = 24;
          goto LABEL_39;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          v14 = 32;
LABEL_39:
          loopstart = (unsigned int)(8 * (unsigned __int64)loopstart / v14) / mChannels;
          break;
        default:
          break;
      }
    }
    else
    {
      if ( loopstarttype != 1 )
      {
LABEL_9:
        loopstart = 0;
        goto LABEL_10;
      }
      loopstart = (int)(float)((float)((float)(int)loopstart / 1000.0) * this->mDefaultFrequency);
    }
  }
LABEL_10:
  if ( loopendtype != 2 )
  {
    if ( loopendtype == 4 )
    {
      v11 = this->mChannels;
      if ( v11 )
      {
        switch ( this->mFormat )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v12 = 8;
            goto LABEL_32;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v12 = 16;
            goto LABEL_32;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v12 = 24;
            goto LABEL_32;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v12 = 32;
LABEL_32:
            loopend = (unsigned int)(8 * (unsigned __int64)loopend / v12) / v11;
            break;
          default:
            goto LABEL_14;
        }
        goto LABEL_14;
      }
    }
    else if ( loopendtype == 1 )
    {
      loopend = (int)(float)((float)((float)(int)loopend / 1000.0) * this->mDefaultFrequency);
      goto LABEL_14;
    }
    loopend = 0;
  }
LABEL_14:
  mLength = this->mLength;
  if ( mLength <= loopstart )
    loopstart = 0;
  v8 = mLength - 1;
  v9 = mLength <= loopend;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( v9 )
    loopend = v8;
  if ( !loopend )
    loopend = v8;
  if ( loopstart < loopend )
  {
    this->mLoopStart = loopstart;
    this->mLoopLength = loopend - loopstart + 1;
    v10 = (*this->_vptr_SoundI)(this);
    result = FMOD_RESULT::FMOD_OK_0;
    if ( v10 )
    {
      if ( this->mLoopStart || this->mLoopLength != this->mLength )
      {
        if ( (this->mMode & 6) != 0 )
          _InterlockedOr((volatile signed __int32 *)&this->mFlags, 0x10u);
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x224fec0 | Name: _ZN4FMOD6SoundI8validateEPNS_5SoundEPPS0_PNS_14SoundLockScopeE
FMOD_RESULT_0 __fastcall FMOD::SoundI::validate(
        FMOD::Sound *sound,
        FMOD::SoundI **soundi_out,
        FMOD::SoundLockScope *lockScope)
{
  FMOD_RESULT_0 result; // eax
  __int64 v4; // rbx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( soundi_out )
  {
    *soundi_out = (FMOD::SoundI *)sound;
    LOBYTE(result) = 30;
    if ( sound )
    {
      if ( ((unsigned __int8)sound & 3) == 0 && *(_DWORD *)&sound[32].gap0 == -1396696354 )
      {
        LOBYTE(result) = 0;
        if ( lockScope )
        {
          v4 = *(_QWORD *)&sound[216].gap0;
          if ( !v4 || (*(_BYTE *)(v4 + 74) & 0x10) != 0 )
            return FMOD_RESULT::FMOD_OK_0;
          LOBYTE(result) = 28;
          if ( !lockScope->mSystem )
          {
            result = FMOD::SystemI::enterCrit(*(FMOD::SystemI *const *)&sound[216].gap0, FMOD_SYSTEM_CRIT_SOUND);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              lockScope->mSystem = (FMOD::SystemI *)v4;
              return FMOD_RESULT::FMOD_OK_0;
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x224ff40 | Name: _ZN4FMOD6SoundIC2Ev
void __fastcall FMOD::SoundI::SoundI(FMOD::SoundI *const this)
{
  this->mNodePrev = &this->FMOD::LinkedListNode;
  this->mNodeNext = &this->FMOD::LinkedListNode;
  this->mMinDistance = 1.0;
  this->mNodeData = 0;
  this->mConeInsideAngle = 360.0;
  this->mSoundGroupNode.mNodeData = 0;
  this->mConeOutsideAngle = 360.0;
  this->mMagic = -1396696354;
  this->mConeOutsideVolume = 1.0;
  this->mMode = 0;
  this->_vptr_SoundI = (int (**)(...))&off_29B2A90;
  this->mFormat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_NONE_0;
  this->mName = 0;
  this->mSoundGroupNode.mNodePrev = &this->mSoundGroupNode;
  this->mSoundGroupNode.mNodeNext = &this->mSoundGroupNode;
  this->mChannels = 1;
  this->mMaxDistance = 10000.0;
  this->mDefaultFrequency = 44100.0;
  this->mDefaultPriority = 128;
  this->mLoopStart = 0;
  this->mLoopLength = 0;
  this->mLoopCount = -1;
  this->mUserData = 0;
  this->mMemoryUsed = 0;
  this->mCodec = 0;
  this->mSubSound = 0;
  this->mSubSoundParent = 0;
  this->mNumSubSounds = 0;
  this->mNumActiveSubSounds = 0;
  this->mAsyncData = 0;
  this->mNumSyncPoints = 0;
  this->mOpenState.m_value = FMOD_OPENSTATE::FMOD_OPENSTATE_READY_0;
  _mm_mfence();
  this->mRolloffPoint = 0;
  this->mNumRolloffPoints = 0;
  this->mSyncPointHead = 0;
  this->mSyncPointTail = 0;
  this->mPostReadCallback = 0;
  this->mPostSetPositionCallback = 0;
  this->mPostCallbackSound = 0;
  this->mFlags.m_value = 0;
  _mm_mfence();
  this->mDontRelease = 0;
  this->mRoblox_ParseAnomaly = 0;
  this->mSoundGroupNode.mNodePrev = &this->mSoundGroupNode;
  this->mSoundGroupNode.mNodeNext = &this->mSoundGroupNode;
  this->mSoundGroupNode.mNodeData = 0;
}


// Address: 0x22500e0 | Name: _ZN4FMOD6SoundI4readEjjPj
FMOD_RESULT_0 __fastcall FMOD::SoundI::read(
        FMOD::SoundI *const this,
        unsigned int offset,
        unsigned int samples_in,
        unsigned int *samples_out)
{
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 v7; // r14d
  unsigned int v8; // r12d
  unsigned int v9; // ebp
  unsigned int v10; // ebx
  __int64 v11; // rdx
  unsigned int v12; // edi
  int (**vptr_SoundI)(...); // rax
  unsigned int v14; // r13d
  __int64 v15; // r8
  void *v16; // rsi
  void *v17; // rdx
  int (**v18)(...); // rax
  int v19; // eax
  unsigned int bytesreadtotal; // [rsp+38h] [rbp-A0h]
  unsigned int bytespersample; // [rsp+3Ch] [rbp-9Ch]
  unsigned int len1; // [rsp+44h] [rbp-94h] BYREF
  unsigned int len2; // [rsp+48h] [rbp-90h] BYREF
  unsigned int readbytes; // [rsp+4Ch] [rbp-8Ch] BYREF
  void *ptr1; // [rsp+50h] [rbp-88h] BYREF
  void *ptr2; // [rsp+58h] [rbp-80h] BYREF
  FMOD_CODEC_WAVEFORMAT waveformat; // [rsp+60h] [rbp-78h] BYREF

  bytespersample = 1;
  if ( (this->mMode & 0x200) == 0 )
  {
    switch ( this->mFormat )
    {
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
        v19 = 2;
        break;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
        v19 = 3;
        break;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
        v19 = 4;
        break;
      default:
        v19 = 1;
        break;
    }
    bytespersample = this->mChannels * v19;
  }
  this->mPosition = offset;
  if ( samples_out )
    *samples_out = 0;
  memset(&waveformat, 0, sizeof(waveformat));
  result = this->mCodec->mDescription.getwaveformat(this->mCodec, this->mCodec->mSubSoundIndex, &waveformat);
  v7 = result;
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v8 = bytespersample * samples_in;
    v9 = bytespersample * offset;
    if ( v8 )
    {
      v10 = v8;
      bytesreadtotal = 0;
      while ( 1 )
      {
        v11 = v8;
        if ( v8 >= v10 )
          v11 = v10;
        v7 = (*((unsigned int (__fastcall **)(FMOD::SoundI *const, _QWORD, __int64, void **, void **, unsigned int *, unsigned int *))this->_vptr_SoundI
              + 5))(
               this,
               v9,
               v11,
               &ptr1,
               &ptr2,
               &len1,
               &len2);
        if ( v7 )
          return v7;
        v12 = len1;
        if ( len1 )
        {
          if ( ptr1 )
          {
            vptr_SoundI = this->_vptr_SoundI;
            readbytes = 0;
            v7 = vptr_SoundI[25](this, ptr1, len1, &readbytes);
            if ( (v7 & 0xFFFFFFEF) != 0 )
              goto LABEL_34;
            v14 = readbytes;
            v15 = len2;
          }
          else
          {
            v15 = len2;
            v14 = 0;
          }
          v16 = ptr2;
          if ( !ptr2 )
          {
            v17 = 0;
            v12 = len1;
            goto LABEL_21;
          }
          if ( !(_DWORD)v15 )
          {
            v17 = ptr2;
            v12 = len1;
            goto LABEL_21;
          }
        }
        else
        {
          v15 = len2;
          if ( !len2 )
          {
            (*((void (__fastcall **)(FMOD::SoundI *const, void *, void *, _QWORD))this->_vptr_SoundI + 6))(
              this,
              ptr1,
              ptr2,
              0);
            return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
          }
          v16 = ptr2;
          v14 = 0;
          if ( !ptr2 )
          {
            v17 = 0;
            v14 = 0;
            goto LABEL_21;
          }
        }
        v18 = this->_vptr_SoundI;
        readbytes = 0;
        v7 = v18[25](this, v16, (unsigned int)v15, &readbytes);
        if ( (v7 & 0xFFFFFFEF) != 0 )
        {
LABEL_34:
          (*((void (__fastcall **)(FMOD::SoundI *const, void *, void *, _QWORD, _QWORD))this->_vptr_SoundI + 6))(
            this,
            ptr1,
            ptr2,
            len1,
            len2);
          return v7;
        }
        v14 += readbytes;
        v15 = len2;
        v17 = ptr2;
        v12 = len1;
LABEL_21:
        result = (*((unsigned int (__fastcall **)(FMOD::SoundI *const, void *, void *, _QWORD, __int64))this->_vptr_SoundI
                  + 6))(
                   this,
                   ptr1,
                   v17,
                   v12,
                   v15);
        if ( result )
          return result;
        v9 += v14;
        bytesreadtotal += v14;
        v10 -= v14;
        if ( v7 == FMOD_RESULT::FMOD_ERR_FILE_EOF_0 || !v10 )
          goto LABEL_24;
      }
    }
    bytesreadtotal = 0;
LABEL_24:
    if ( samples_out )
      *samples_out = bytesreadtotal / bytespersample;
    return v7;
  }
  return result;
}


// Address: 0x22503d0 | Name: _ZN4FMOD6SoundI4seekEij
FMOD_RESULT_0 __fastcall FMOD::SoundI::seek(FMOD::SoundI *const this, int subsound, unsigned int position)
{
  FMOD::Codec *mCodec; // rdi
  FMOD_RESULT_0 v5; // eax
  FMOD::Codec *v6; // rdi
  FMOD_RESULT_0 v7; // ebp
  FMOD_SOUND_PCMSETPOS_CALLBACK mPostSetPositionCallback; // rax
  unsigned int newpos[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  mCodec = this->mCodec;
  if ( mCodec->mFile || (mCodec->mFlags & 0x400) != 0 )
  {
    this->mPosition = position;
    mCodec->mRoblox_ParsingAnomaly = 0;
    v5 = FMOD::Codec::setPosition(mCodec, subsound, position, 2u);
    v6 = this->mCodec;
    if ( v6->mRoblox_ParsingAnomaly )
    {
      v6->mRoblox_ParsingAnomaly = 0;
      return FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
    }
    else
    {
      v7 = v5;
      if ( v5 == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( FMOD::Codec::getPosition(v6, newpos, 2u) == FMOD_RESULT::FMOD_OK_0 )
          this->mPosition = newpos[0];
        mPostSetPositionCallback = this->mPostSetPositionCallback;
        v7 = FMOD_RESULT::FMOD_OK_0;
        if ( mPostSetPositionCallback )
        {
          mPostSetPositionCallback(this->mPostCallbackSound, subsound, this->mPosition, 2);
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
    return v7;
  }
  return FMOD_RESULT::FMOD_ERR_FILE_COULDNOTSEEK_0;
}


// Address: 0x22504b0 | Name: _ZN4FMOD6SoundI8seekDataEj
FMOD_RESULT_0 __fastcall FMOD::SoundI::seekData(FMOD::SoundI *const this, unsigned int position)
{
  FMOD::Codec *mCodec; // rbx
  FMOD::File *mFile; // rax
  unsigned __int8 *mPCMBuffer; // rdi
  void (__fastcall *reset)(FMOD::Codec *); // rax

  mCodec = this->mCodec;
  if ( mCodec )
  {
    mFile = mCodec->mFile;
    if ( mFile && (mFile->mFlags & 0x2000) != 0 && position )
      mFile->mFlags |= 1u;
    mPCMBuffer = mCodec->mPCMBuffer;
    mCodec->mPCMBufferOffset = 0;
    if ( mPCMBuffer )
      memset(mPCMBuffer, 0, mCodec->mPCMBufferLengthBytes);
    reset = (void (__fastcall *)(FMOD::Codec *))mCodec->mDescription.reset;
    if ( reset )
      reset(mCodec);
  }
  return FMOD::SoundI::seek(this, this->mSubSoundIndex, position);
}


// Address: 0x2250540 | Name: _ZN4FMOD6SoundI5clearEjj
FMOD_RESULT_0 __fastcall FMOD::SoundI::clear(FMOD::SoundI *const this, unsigned int offset, unsigned int numsamples)
{
  unsigned int v4; // r12d
  unsigned int v5; // ebp
  unsigned int v6; // ebx
  FMOD_RESULT_0 result; // eax
  void *v8; // rdx
  __int64 v9; // r8
  void *v10; // rdi
  unsigned int v11; // r15d
  int v12; // ebp
  unsigned int len1; // [rsp+28h] [rbp-50h] BYREF
  unsigned int len2; // [rsp+2Ch] [rbp-4Ch] BYREF
  void *ptr1; // [rsp+30h] [rbp-48h] BYREF
  void *ptr2[8]; // [rsp+38h] [rbp-40h] BYREF

  v4 = offset;
  v5 = 1;
  v6 = numsamples;
  if ( (this->mMode & 0x200) == 0 )
  {
    switch ( this->mFormat )
    {
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
        v12 = 2;
        break;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
        v12 = 3;
        break;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
        v12 = 4;
        break;
      default:
        v12 = 1;
        break;
    }
    v5 = this->mChannels * v12;
  }
  this->mPosition = offset;
  if ( numsamples )
  {
    for ( result = (*((unsigned int (__fastcall **)(FMOD::SoundI *const, _QWORD, _QWORD, void **, void **, unsigned int *, unsigned int *))this->_vptr_SoundI
                    + 5))(
                     this,
                     v5 * offset,
                     v5 * numsamples,
                     &ptr1,
                     ptr2,
                     &len1,
                     &len2);
          ;
          result = (*((unsigned int (__fastcall **)(FMOD::SoundI *const, _QWORD, _QWORD, void **, void **, unsigned int *, unsigned int *))this->_vptr_SoundI
                    + 5))(
                     this,
                     v5 * v4,
                     v5 * v6,
                     &ptr1,
                     ptr2,
                     &len1,
                     &len2) )
    {
      if ( result )
        return result;
      if ( !ptr1 )
        break;
      v11 = 0;
      if ( !len1 )
        goto LABEL_4;
      memset(ptr1, 0, len1);
      v8 = ptr2[0];
      v11 = len1 / v5;
      if ( !ptr2[0] )
      {
LABEL_14:
        v9 = len2;
        v10 = 0;
        goto LABEL_7;
      }
LABEL_5:
      v9 = 0;
      v10 = v8;
      if ( len2 )
      {
        memset(v8, 0, len2);
        v9 = len2;
        v10 = ptr2[0];
        v11 += len2 / v5;
      }
LABEL_7:
      result = (*((unsigned int (__fastcall **)(FMOD::SoundI *const, void *, void *, _QWORD, __int64))this->_vptr_SoundI
                + 6))(
                 this,
                 ptr1,
                 v10,
                 len1,
                 v9);
      if ( result )
        return result;
      v4 += v11;
      v6 -= v11;
      if ( !v6 )
        return FMOD_RESULT::FMOD_OK_0;
    }
    v11 = 0;
LABEL_4:
    v8 = ptr2[0];
    if ( !ptr2[0] )
      goto LABEL_14;
    goto LABEL_5;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22506f0 | Name: _ZN4FMOD6SoundI19setSubSoundInternalEiPS0_b
FMOD_RESULT_0 __fastcall FMOD::SoundI::setSubSoundInternal(
        FMOD::SoundI *const this,
        int index,
        FMOD::SoundI *subsound,
        bool calledfromrelease)
{
  FMOD_RESULT_0 result; // eax
  char v7; // al
  bool v8; // cl
  FMOD::SoundI *mSubSoundShared; // rax
  char v10; // r14
  FMOD::SoundI **v11; // rax
  FMOD::SoundI *v12; // r13
  __int64 v13; // rcx
  FMOD_CODEC_WAVEFORMAT *p_waveformat; // rdi
  bool v15; // zf
  __int64 v16; // rcx
  FMOD_CODEC_WAVEFORMAT *v17; // rdi
  __int64 v18; // rax
  unsigned int mLength; // eax
  FMOD::SoundI **mSubSound; // rax
  char v22; // [rsp+Ch] [rbp-7Ch]
  FMOD_CODEC_WAVEFORMAT waveformat; // [rsp+10h] [rbp-78h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index < 0 )
    return result;
  if ( index >= this->mNumSubSounds )
    return result;
  if ( subsound )
  {
    LOBYTE(result) = 61;
    if ( subsound->mSubSoundParent )
      return result;
  }
  result = FMOD_RESULT::FMOD_ERR_SUBSOUND_CANTMOVE_0;
  if ( this->mSubSoundShared )
    return result;
  v7 = (*this->_vptr_SoundI)(this);
  v8 = calledfromrelease;
  if ( !v7 )
    goto LABEL_10;
  mSubSoundShared = this->mSubSoundShared;
  if ( !mSubSoundShared )
  {
    mSubSound = this->mSubSound;
    if ( mSubSound )
    {
      mSubSoundShared = mSubSound[this->mSubSoundIndex];
      if ( !mSubSoundShared )
        goto LABEL_10;
    }
    else
    {
      mSubSoundShared = this;
    }
  }
  if ( (mSubSoundShared->mFlags.m_value & 4) != 0 && (mSubSoundShared->mFlags.m_value & 8) == 0 )
  {
    v10 = 1;
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMUPDATE);
    v8 = calledfromrelease;
    goto LABEL_11;
  }
LABEL_10:
  v10 = 0;
LABEL_11:
  v22 = 0;
  if ( !v8 && (unsigned int)(this->mFormat - 1) <= 4 )
  {
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
    v22 = 1;
  }
  v11 = this->mSubSound;
  v12 = v11[index];
  if ( v12 )
  {
    if ( v12->mSubSoundShared )
    {
      v13 = 14;
      p_waveformat = &waveformat;
      while ( v13 )
      {
        LODWORD(p_waveformat->name) = 0;
        p_waveformat = (FMOD_CODEC_WAVEFORMAT *)((char *)p_waveformat + 4);
        --v13;
      }
      ((void (__fastcall *)(FMOD::Codec *, _QWORD))this->mCodec->mDescription.getwaveformat)(
        this->mCodec,
        (unsigned int)index);
    }
    if ( !subsound )
      goto LABEL_27;
  }
  else if ( !subsound )
  {
    goto LABEL_32;
  }
  v15 = subsound->mSubSoundShared == 0;
  subsound->mSubSoundIndex = index;
  subsound->mSubSoundParent = this;
  if ( !v15 )
  {
    v16 = 14;
    v17 = &waveformat;
    while ( v16 )
    {
      LODWORD(v17->name) = 0;
      v17 = (FMOD_CODEC_WAVEFORMAT *)((char *)v17 + 4);
      --v16;
    }
    ((void (__fastcall *)(FMOD::Codec *, _QWORD))subsound->mCodec->mDescription.getwaveformat)(
      this->mCodec,
      (unsigned int)index);
  }
  if ( !v12 )
  {
    ++this->mNumActiveSubSounds;
    goto LABEL_31;
  }
LABEL_27:
  if ( (*this->_vptr_SoundI)(this) )
  {
    v18 = *((_QWORD *)this + 48);
    if ( v18 == *(_QWORD *)&v12[1].mMagic )
      *(_QWORD *)(v18 + 184) = 0;
  }
  else if ( v12->mSubSoundParent->mCodec == v12->mCodec )
  {
    v12->mCodec = 0;
  }
  v12->mSubSoundParent = 0;
  if ( !subsound )
  {
    --this->mNumActiveSubSounds;
    v11 = this->mSubSound;
    goto LABEL_32;
  }
LABEL_31:
  v11 = this->mSubSound;
LABEL_32:
  v11[index] = subsound;
  mLength = this->mLength;
  this->mLoopStart = 0;
  this->mLoopLength = mLength;
  if ( (*this->_vptr_SoundI)(this) )
    (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(**((_QWORD **)this + 47) + 144LL))(
      *((_QWORD *)this + 47),
      0,
      this->mLength - 1);
  if ( v22 )
    FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
  if ( !(*this->_vptr_SoundI)(this) )
    return FMOD_RESULT::FMOD_OK_0;
  if ( subsound )
    _InterlockedOr((volatile signed __int32 *)&this->mFlags, 0x10u);
  if ( !v10 )
    return FMOD_RESULT::FMOD_OK_0;
  FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_STREAMUPDATE);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22509d0 | Name: _ZN4FMOD6SoundI11getMetaDataEPPvPj
FMOD_RESULT_0 __fastcall FMOD::SoundI::getMetaData(
        FMOD::SoundI *const this,
        void **metadata,
        unsigned int *metadataLength)
{
  FMOD::FMOD_CODEC_GETMETADATA getmetadata; // rax

  getmetadata = this->mCodec->mDescription.getmetadata;
  if ( getmetadata )
    return getmetadata(this->mCodec, this->mSubSoundIndex, metadata, metadataLength);
  else
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
}


// Address: 0x2250a00 | Name: _ZN4FMOD6SoundI16getCodecChannelsEPi
FMOD_RESULT_0 __fastcall FMOD::SoundI::getCodecChannels(FMOD::SoundI *const this, int *numChannels)
{
  __int64 mSubSoundIndex; // rsi
  FMOD_RESULT_0 result; // eax
  FMOD_CODEC_WAVEFORMAT waveFormat; // [rsp+0h] [rbp-48h] BYREF

  mSubSoundIndex = (unsigned int)this->mSubSoundIndex;
  memset(&waveFormat, 0, sizeof(waveFormat));
  result = this->mCodec->mDescription.getwaveformat(this->mCodec, mSubSoundIndex, &waveFormat);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    *numChannels = waveFormat.channels;
  return result;
}


// Address: 0x2250a40 | Name: _ZN4FMOD6SoundI19setPositionInternalEj
FMOD_RESULT_0 __fastcall FMOD::SoundI::setPositionInternal(FMOD::SoundI *const this, unsigned int pcm)
{
  this->mPosition = pcm;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2250a50 | Name: j__ZN4FMOD6SoundI19setPositionInternalEj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::SoundI::setPositionInternal(FMOD::SoundI *const this, unsigned int pos)
{
  return _ZN4FMOD6SoundI19setPositionInternalEj(this, pos);
}


// Address: 0x2250a60 | Name: _ZN4FMOD6SoundI12loadSubSoundEij
FMOD_RESULT_0 __fastcall FMOD::SoundI::loadSubSound(FMOD::SoundI *const this, int index, FMOD_MODE mode)
{
  FMOD_RESULT_1 v4; // ebx
  int mNumSubSounds; // eax
  FMOD::Sample *v8; // rdx
  FMOD::Codec *mCodec; // rbx
  __int64 (__fastcall *soundcreate)(_QWORD, _QWORD); // rax
  unsigned __int8 *mPCMBuffer; // rdi
  void (__fastcall *reset)(FMOD::Codec *); // rax
  FMOD_SOUND_PCMSETPOS_CALLBACK mPostSetPositionCallback; // rax
  FMOD_RESULT_0 v14; // eax
  FMOD::Sample *sample; // [rsp+8h] [rbp-70h] BYREF
  FMOD_CODEC_WAVEFORMAT waveformat; // [rsp+10h] [rbp-68h] BYREF

  v4 = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  mNumSubSounds = this->mNumSubSounds;
  sample = 0;
  if ( mNumSubSounds )
  {
    LOBYTE(v4) = 31;
    if ( index >= 0 && mNumSubSounds > index )
    {
      memset(&waveformat, 0, sizeof(waveformat));
      v4 = this->mCodec->mDescription.getwaveformat(this->mCodec, index, &waveformat);
      if ( v4 == FMOD_RESULT::FMOD_OK_0 )
      {
        v4 = FMOD::SystemI::createSample(this->mSystem, mode, &waveformat, &sample);
        if ( v4 == FMOD_RESULT::FMOD_OK_0 )
        {
          v8 = sample;
          sample->mType = this->mType;
          v8->mCodec = this->mCodec;
          mCodec = this->mCodec;
          soundcreate = (__int64 (__fastcall *)(_QWORD, _QWORD))mCodec->mDescription.soundcreate;
          if ( soundcreate )
          {
            v4 = (unsigned int)soundcreate(this->mCodec, (unsigned int)index);
            if ( v4 )
              return v4;
            mCodec = this->mCodec;
          }
          mPCMBuffer = mCodec->mPCMBuffer;
          mCodec->mPCMBufferOffset = 0;
          if ( mPCMBuffer )
            memset(mPCMBuffer, 0, mCodec->mPCMBufferLengthBytes);
          reset = (void (__fastcall *)(FMOD::Codec *))mCodec->mDescription.reset;
          if ( reset )
            reset(mCodec);
          v4 = FMOD::Codec::setPosition(this->mCodec, index, 0, 2u);
          if ( v4 == FMOD_RESULT::FMOD_OK_0 )
          {
            mPostSetPositionCallback = this->mPostSetPositionCallback;
            if ( mPostSetPositionCallback )
              mPostSetPositionCallback(this->mPostCallbackSound, index, 0, 2);
            if ( (mode & 0x2000) != 0
              || (v4 = FMOD::SoundI::read(sample, 0, sample->mLength, 0), (v4 & 0xFFFFFFEF) == 0) )
            {
              v4 = FMOD::SoundI::setSubSoundInternal(this, index, sample, 0);
              if ( v4 == FMOD_RESULT::FMOD_OK_0 )
              {
                v14 = FMOD::SoundI::setPositionInternal(sample, 0);
                if ( (v14 & 0xFFFFFFEF) != 0 )
                  return v14;
              }
            }
          }
        }
      }
    }
  }
  return v4;
}


// Address: 0x2250c00 | Name: _ZN4FMOD6SoundI19setUserDataInternalEPv
FMOD_RESULT_0 __fastcall FMOD::SoundI::setUserDataInternal(FMOD::SoundI *const this, void *userdata)
{
  this->mUserDataInternal = userdata;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2250c10 | Name: _ZN4FMOD6SoundI19getUserDataInternalEPPv
FMOD_RESULT_0 __fastcall FMOD::SoundI::getUserDataInternal(FMOD::SoundI *const this, void **userdata)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( userdata )
  {
    *userdata = this->mUserDataInternal;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2250c30 | Name: _ZN4FMOD6SoundI14updateSubSoundEib
FMOD_RESULT_0 __fastcall FMOD::SoundI::updateSubSound(FMOD::SoundI *const this, int index, bool updateinfoonly)
{
  FMOD::SystemI *mSystem; // r14
  char v7; // r12
  FMOD::SoundI *mSubSoundParent; // rax
  FMOD::SoundI *v9; // rax
  FMOD_MODE v10; // edx
  FMOD::Codec *v11; // rax
  FMOD_RESULT_0 v12; // ebp
  FMOD::SystemI *v14; // rdi
  const char *name; // rax
  __int64 loopend; // rcx
  __int64 loopstart; // rsi
  float peakvolume; // xmm0_4
  __int64 v19; // rax
  int mChannels; // edx
  FMOD::Codec *mCodec; // rax
  FMOD::File *mFile; // rax
  FMOD_CODEC_WAVEFORMAT waveformat; // [rsp+0h] [rbp-68h] BYREF

  mSystem = this->mSystem;
  if ( !FMOD::Thread::isCurrentThreadInTable(mSystem->mThreadId) && !updateinfoonly )
  {
    v14 = this->mSystem;
    this->mSubSoundIndex = index;
    FMOD::SystemI::stopSound(v14, this);
    if ( (this->mMode & 0x10000) != 0 )
    {
      v12 = FMOD_RESULT::FMOD_OK_0;
      if ( (*this->_vptr_SoundI)(this) )
        return v12;
    }
  }
  v7 = (*this->_vptr_SoundI)(this);
  if ( v7 && (this->mFlags.m_value & 4) != 0 )
  {
    if ( (this->mFlags.m_value & 8) != 0 || !mSystem )
      v7 = 0;
    else
      FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMUPDATE);
    mCodec = this->mCodec;
    if ( mCodec )
    {
      mFile = mCodec->mFile;
      if ( mFile )
      {
        if ( (mFile->mFlags & 0x10) != 0 )
        {
          do
            FMOD_OS_Time_Sleep(0xAu);
          while ( (this->mCodec->mFile->mFlags & 0x10) != 0 );
        }
      }
    }
    *(_BYTE *)(*((_QWORD *)this + 47) + 136LL) = 0;
  }
  else
  {
    v7 = 0;
  }
  _InterlockedAnd((volatile signed __int32 *)&this->mFlags, 0xFFFFFFB3);
  mSubSoundParent = this->mSubSoundParent;
  if ( mSubSoundParent )
  {
    _InterlockedAnd((volatile signed __int32 *)&mSubSoundParent->mFlags, 0xFFFFFFB7);
    v9 = this->mSubSoundParent;
    v10 = this->mMode & 0xFFFFFFF8;
    this->mMode = v10;
    this->mMode = v10 | v9->mMode & 7;
  }
  memset(&waveformat, 0, sizeof(waveformat));
  v11 = this->mCodec;
  this->mSubSoundIndex = index;
  v12 = v11->mDescription.getwaveformat(v11, index, &waveformat);
  if ( v12 == FMOD_RESULT::FMOD_OK_0 )
  {
    name = waveformat.name;
    loopend = (unsigned int)waveformat.loopend;
    loopstart = (unsigned int)waveformat.loopstart;
    this->mDefaultFrequency = (float)waveformat.frequency;
    peakvolume = waveformat.peakvolume;
    this->mName = name;
    this->mPeakVolume = peakvolume;
    LODWORD(name) = waveformat.format;
    this->mLoopStart = loopstart;
    this->mFormat = (int)name;
    this->mChannels = waveformat.channels;
    this->mLoopLength = loopend - loopstart + 1;
    this->mLength = waveformat.lengthpcm;
    (*((void (__fastcall **)(FMOD::SoundI *const, __int64, __int64, __int64, __int64))this->_vptr_SoundI + 39))(
      this,
      loopstart,
      2,
      loopend,
      2);
    if ( (*this->_vptr_SoundI)(this) )
    {
      v19 = *((_QWORD *)this + 48);
      mChannels = this->mChannels;
      *(float *)(v19 + 316) = waveformat.peakvolume;
      *(_DWORD *)(v19 + 104) = mChannels;
      *(_DWORD *)(v19 + 192) = index;
    }
  }
  if ( !v7 || !mSystem )
    return v12;
  FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMUPDATE);
  return v12;
}


// Address: 0x2250e80 | Name: _ZN4FMOD6SoundI11getSubSoundEiPPS0_
FMOD_RESULT_0 __fastcall FMOD::SoundI::getSubSound(FMOD::SoundI *const this, int index, FMOD::SoundI **subsound)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SoundI *v6; // rdi
  FMOD::SoundI *v7; // rbx
  FMOD::SoundI *mSubSoundParent; // rax
  FMOD::AsyncData *mAsyncData; // rax
  FMOD::AsyncThread *mThread; // rdx
  FMOD_OS_CRITICALSECTION *mCrit; // rdi
  FMOD_OS_SEMAPHORE *mSema; // rdi
  char v13; // al
  int mName_high; // ecx
  unsigned int mPosition; // edx
  unsigned int v16; // eax
  unsigned int mLength; // esi

  if ( !subsound )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *subsound = 0;
  if ( index < 0 || index >= this->mNumSubSounds )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *subsound = this->mSubSound[index];
  v6 = this->mSubSound[index];
  if ( !v6 )
    return FMOD_RESULT::FMOD_OK_0;
  if ( (this->mMode & 0x10000) == 0
    || (v13 = (*v6->_vptr_SoundI)(v6), v6 = this->mSubSound[index], !v13)
    || (result = FMOD_RESULT::FMOD_ERR_NOTREADY_0, v6->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0) )
  {
    if ( v6 )
    {
      if ( !v6->mSubSoundShared || (FMOD::SoundI::updateSubSound(v6, index, 0), (v6 = this->mSubSound[index]) != 0) )
      {
        if ( (unsigned __int8)(*v6->_vptr_SoundI)(v6) )
        {
          v7 = *subsound;
          result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
          if ( !v7 )
            return result;
          if ( (this->mMode & 0x10000) != 0 )
          {
            mSubSoundParent = v7->mSubSoundParent;
            if ( index == mSubSoundParent->mSubSoundIndex )
            {
              mName_high = HIDWORD(mSubSoundParent[1].mName);
              mPosition = v7->mPosition;
              v16 = *(_DWORD *)(*(_QWORD *)&v7[1].mMagic + 68LL);
              if ( mPosition == mName_high + v16
                || (mLength = v7->mLength, v16 > mLength) && mPosition == mLength + mName_high )
              {
                if ( (v7->mFlags.m_value & 0x10) == 0 )
                  return FMOD_RESULT::FMOD_OK_0;
              }
            }
            v7->mOpenState.m_value = FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0;
            _mm_mfence();
            this->mOpenState.m_value = FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0;
            _mm_mfence();
            FMOD_OS_CriticalSection_Enter(v7->mAsyncData->mThread->mCrit);
            v7->mAsyncData->mNode.mNodeData = v7;
            mAsyncData = v7->mAsyncData;
            mThread = mAsyncData->mThread;
            mCrit = mThread->mCrit;
            mAsyncData->mNode.mNodePrev = mThread->mHead.mNodePrev;
            mAsyncData->mNode.mNodeNext = &mThread->mHead;
            mThread->mHead.mNodePrev = &mAsyncData->mNode;
            mAsyncData->mNode.mNodePrev->mNodeNext = &mAsyncData->mNode;
            FMOD_OS_CriticalSection_Leave(mCrit);
            mSema = v7->mAsyncData->mThread->mThread.mSema;
            if ( mSema )
              FMOD_OS_Semaphore_Signal(mSema);
          }
          else if ( v7->mSubSoundIndex != v7->mCodec->mSubSoundIndex
                 && FMOD::Stream::setPosition((FMOD::Stream *const)v7, 0, 2u) == FMOD_RESULT::FMOD_OK_0 )
          {
            FMOD::Stream::flush((FMOD::Stream *const)v7);
            return FMOD_RESULT::FMOD_OK_0;
          }
        }
      }
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x22510c0 | Name: _ZN4FMOD6SoundI20syncPointFixIndiciesEv
FMOD_RESULT_0 __fastcall FMOD::SoundI::syncPointFixIndicies(FMOD::SoundI *const this)
{
  int (**vptr_SoundI)(...); // rax
  int i; // ebx
  int numsyncpoints; // [rsp+4h] [rbp-24h] BYREF
  FMOD::SyncPoint *point; // [rsp+8h] [rbp-20h] BYREF

  vptr_SoundI = this->_vptr_SoundI;
  numsyncpoints = 0;
  if ( !vptr_SoundI[29](this, &numsyncpoints) && numsyncpoints > 0 )
  {
    for ( i = 0; i < numsyncpoints; ++i )
    {
      if ( !(*((unsigned int (__fastcall **)(FMOD::SoundI *const, _QWORD, FMOD::SyncPoint **))this->_vptr_SoundI + 30))(
              this,
              (unsigned int)i,
              &point) )
        HIWORD(point->mOffset) = i;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2251130 | Name: _ZN4FMOD6SoundI20addSyncPointInternalEjjPKcPP14FMOD_SYNCPOINTib
FMOD_RESULT_0 __fastcall FMOD::SoundI::addSyncPointInternal(
        FMOD::SoundI *const this,
        unsigned int offset,
        FMOD_TIMEUNIT offsettype,
        const char *name,
        FMOD_SYNCPOINT **syncpoint,
        int subsound,
        bool fixupindicies)
{
  FMOD_TIMEUNIT v7; // r10d
  const char *v8; // r11
  unsigned int v12; // ebp
  FMOD_SYNCPOINT *v13; // rbx
  FMOD_RESULT_0 v14; // r13d
  unsigned int mChannels; // ecx
  char *v17; // rdi
  FMOD::SyncPoint *mSyncPointHead; // rdx
  FMOD::SyncPoint *mSyncPointTail; // rax
  FMOD::LinkedListNode *mNodeNext; // rdx
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::MemPool *gSystemMemPool; // rdi
  FMOD_SYNCPOINT *v23; // rax
  _QWORD *v24; // rax
  FMOD::LinkedListNode *v25; // rdx
  char *v26; // rax
  char *v27; // rdx
  char *v28; // rax
  unsigned __int64 v29; // rsi
  FMOD_TIMEUNIT offsettypea; // [rsp+4h] [rbp-44h]
  const char *namea; // [rsp+8h] [rbp-40h]

  v7 = offsettype;
  v8 = name;
  v12 = offset;
  if ( !this->mSyncPointHead )
  {
    v26 = (char *)FMOD::MemPool::calloc(
                    off_286F358->gSystemMemPool,
                    112,
                    "../../../core_api/src/fmod_soundi.cpp",
                    2264,
                    0);
    this->mSyncPointHead = (FMOD::SyncPoint *)v26;
    v7 = offsettype;
    v8 = name;
    if ( !v26 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v27 = v26 + 56;
    this->mSyncPointTail = (FMOD::SyncPoint *)(v26 + 56);
    *((_QWORD *)v26 + 1) = v26;
    *(_QWORD *)v26 = v26;
    *((_QWORD *)v26 + 2) = 0;
    *((_DWORD *)v26 + 6) = -1;
    if ( v26 != (char *)-56LL )
    {
      *((_QWORD *)v26 + 9) = 0;
      *((_DWORD *)v26 + 20) = -1;
    }
    *((_DWORD *)v26 + 11) = 0;
    *(_QWORD *)(v26 + 28) = 0;
    *((_DWORD *)v26 + 25) = -1;
    *(_QWORD *)(v26 + 84) = 0;
    *((_QWORD *)v26 + 7) = v26;
    *((_QWORD *)v26 + 8) = v26;
    *((_QWORD *)v26 + 1) = v27;
    *(_QWORD *)v26 = v27;
  }
  if ( syncpoint )
  {
    v13 = *syncpoint;
    if ( *syncpoint )
    {
      *((_QWORD *)v13 + 1) = v13;
      *(_QWORD *)v13 = v13;
      *((_QWORD *)v13 + 2) = 0;
      *((_DWORD *)v13 + 6) = -1;
      *((_DWORD *)v13 + 13) = 1;
      goto LABEL_5;
    }
  }
  namea = v8;
  offsettypea = v7;
  gSystemMemPool = off_286F358->gSystemMemPool;
  if ( !v8 )
  {
    v28 = (char *)FMOD::MemPool::alloc(gSystemMemPool, 56, "../../../core_api/src/fmod_soundi.cpp", 2310, 0, 0);
    v13 = (FMOD_SYNCPOINT *)v28;
    if ( v28 )
    {
      *((_QWORD *)v28 + 1) = v28;
      *(_QWORD *)v28 = v28;
      v8 = 0;
      *((_QWORD *)v28 + 2) = 0;
      *((_DWORD *)v28 + 6) = -1;
      *(_QWORD *)(v28 + 28) = 0;
      v7 = offsettypea;
      goto LABEL_23;
    }
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
  v23 = (FMOD_SYNCPOINT *)FMOD::MemPool::alloc(gSystemMemPool, 312, "../../../core_api/src/fmod_soundi.cpp", 2301, 0, 0);
  v13 = v23;
  if ( !v23 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  *((_QWORD *)v23 + 1) = v23;
  *(_QWORD *)v23 = v23;
  v24 = (_QWORD *)((char *)v23 + 56);
  *(v24 - 5) = 0;
  *((_DWORD *)v24 - 8) = -1;
  v7 = offsettypea;
  v8 = namea;
  *(_QWORD *)((char *)v13 + 28) = v24;
LABEL_23:
  if ( syncpoint )
    *syncpoint = v13;
  *((_DWORD *)v13 + 13) = 0;
LABEL_5:
  if ( v7 != 2 )
  {
    if ( v7 == 4 )
    {
      mChannels = this->mChannels;
      if ( mChannels )
      {
        switch ( this->mFormat )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v29 = 8;
            goto LABEL_38;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v29 = 16;
            goto LABEL_38;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v29 = 24;
            goto LABEL_38;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v29 = 32;
LABEL_38:
            v12 = (unsigned int)(8 * (unsigned __int64)v12 / v29) / mChannels;
            break;
          default:
            break;
        }
      }
      else
      {
        v12 = 0;
      }
    }
    else
    {
      v14 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      if ( v7 != 1 )
        return v14;
      v12 = (int)(float)((float)((float)(int)offset / 1000.0) * this->mDefaultFrequency);
    }
  }
  v17 = *(char **)((char *)v13 + 28);
  if ( v17 && v8 )
    FMOD_strcpy_safe(v17, v8, 256);
  mSyncPointHead = this->mSyncPointHead;
  *((_DWORD *)v13 + 11) = v12;
  mSyncPointTail = this->mSyncPointTail;
  mNodeNext = mSyncPointHead->mNodeNext;
  do
  {
    if ( v12 < LODWORD(mNodeNext[1].mNodeNext) )
    {
      mNodePrev = mNodeNext->mNodePrev;
      *((_DWORD *)v13 + 6) = v12;
      *(_QWORD *)v13 = mNodeNext;
      *((_QWORD *)v13 + 1) = mNodePrev;
      mNodeNext->mNodePrev = (FMOD::LinkedListNode *)v13;
      **((_QWORD **)v13 + 1) = v13;
      if ( subsound != -1 )
        goto LABEL_18;
      goto LABEL_27;
    }
    mNodeNext = mNodeNext->mNodeNext;
  }
  while ( mSyncPointTail != mNodeNext->mNodePrev );
  v25 = mSyncPointTail->mNodePrev;
  *((_DWORD *)v13 + 6) = v12;
  *(_QWORD *)v13 = mSyncPointTail;
  *((_QWORD *)v13 + 1) = v25;
  mSyncPointTail->mNodePrev = (FMOD::LinkedListNode *)v13;
  **((_QWORD **)v13 + 1) = v13;
  if ( subsound != -1 )
    goto LABEL_18;
LABEL_27:
  subsound = this->mSubSoundIndex;
LABEL_18:
  *((_WORD *)v13 + 24) = subsound;
  *(_QWORD *)((char *)v13 + 36) = this;
  v14 = FMOD_RESULT::FMOD_OK_0;
  ++this->mNumSyncPoints;
  if ( fixupindicies )
    FMOD::SoundI::syncPointFixIndicies(this);
  return v14;
}


// Address: 0x22514c0 | Name: _ZN4FMOD6SoundI23deleteSyncPointInternalEP14FMOD_SYNCPOINTb
FMOD_RESULT_0 __fastcall FMOD::SoundI::deleteSyncPointInternal(
        FMOD::SoundI *const this,
        FMOD_SYNCPOINT *point,
        bool ignoresubsoundindices)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SoundI *v4; // rbp
  _QWORD *v6; // rax

  v3 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( point )
  {
    v4 = *(FMOD::SoundI **)((char *)point + 36);
    LOBYTE(v3) = 34;
    if ( v4 == this )
    {
      v6 = (_QWORD *)*((_QWORD *)point + 1);
      *v6 = *(_QWORD *)point;
      *(_QWORD *)(*(_QWORD *)point + 8LL) = v6;
      LODWORD(v6) = *((_DWORD *)point + 13);
      *((_QWORD *)point + 1) = point;
      *(_QWORD *)point = point;
      *((_DWORD *)point + 6) = -1;
      *((_QWORD *)point + 2) = 0;
      if ( !(_DWORD)v6 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, point, "../../../core_api/src/fmod_soundi.cpp", 2402);
      --v4->mNumSyncPoints;
      v3 = FMOD_RESULT::FMOD_OK_0;
      if ( !ignoresubsoundindices )
        FMOD::SoundI::syncPointFixIndicies(v4);
    }
  }
  return v3;
}


// Address: 0x2251560 | Name: _ZN4FMOD6SoundI15deleteSyncPointEP14FMOD_SYNCPOINT
FMOD_RESULT_0 __fastcall FMOD::SoundI::deleteSyncPoint(FMOD::SoundI *const this, FMOD_SYNCPOINT *point)
{
  return FMOD::SoundI::deleteSyncPointInternal(this, point, 0);
}


// Address: 0x2251570 | Name: _ZN4FMOD6SoundI7releaseEb
FMOD_RESULT_0 __fastcall FMOD::SoundI::release(FMOD::SoundI *const this, bool freethis)
{
  FMOD::SystemI *mSystem; // rbx
  char v4; // bp
  FMOD::Atomic<unsigned int> *p_mFlags; // r12
  FMOD_RESULT_0 v6; // r15d
  FMOD::SoundI *mSubSoundShared; // rax
  FMOD::Codec *mCodec; // rax
  FMOD::File *mFile; // rdi
  FMOD::Atomic<FMOD_OPENSTATE> *p_mOpenState; // r14
  FMOD::SystemI *v12; // rdi
  FMOD::SyncPoint *mSyncPointHead; // rax
  FMOD_SYNCPOINT *i; // rsi
  int *mNumSyncPointsMulti; // rsi
  FMOD::SyncPoint *mSyncPointMemory; // rsi
  FMOD::Codec *v17; // rdx
  FMOD::SoundI *v18; // rax
  __int64 v19; // rax
  FMOD::SystemI *v20; // rdi
  FMOD::SoundI *v21; // r15
  _QWORD *v22; // rax
  FMOD::SystemI *v23; // rdi
  __int64 *v24; // rdi
  __int64 v25; // rax
  int mNumSubSounds; // eax
  FMOD::SoundI **mSubSound; // rsi
  FMOD::AsyncData *v28; // r15
  __int64 v29; // rbp
  unsigned __int64 v30; // r12
  __int64 v31; // r14
  __int64 *v32; // rax
  __int64 v33; // rdi
  char v34; // al
  FMOD::SoundI **v35; // rcx
  FMOD::SoundI *v36; // rdi
  FMOD::SoundI *v37; // rax
  int v38; // eax
  __int64 v39; // rbx
  __int64 v40; // rsi
  __int64 v41; // rax
  __int64 v42; // rsi
  int v43; // r14d
  FMOD::SoundI *v44; // rsi
  FMOD::Codec *v45; // rdi
  FMOD::SoundI *v46; // rax
  char v47; // al
  FMOD::SoundI *v48; // rdi
  void *v49; // rsi
  FMOD::AsyncData *mAsyncData; // rax
  int v51; // edx
  FMOD::SoundI **v52; // rax
  __int64 v53; // rsi
  char *mNameMemory; // rsi
  FMOD::Global *v55; // rax
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::LinkedListNode *mNodeNext; // rcx
  FMOD::LinkedListNode *v58; // rdx
  FMOD::Global *v59; // rax
  FMOD::SoundI *mSubSoundParent; // rax
  FMOD::Codec *oldcodec; // [rsp+8h] [rbp-60h]
  FMOD::ChannelReal *oldstreamchannel; // [rsp+10h] [rbp-58h]
  FMOD::AsyncData *oldasyncdata; // [rsp+18h] [rbp-50h]
  char oldasyncdataa; // [rsp+18h] [rbp-50h]
  FMOD::SystemI *v66; // [rsp+20h] [rbp-48h]

  mSystem = this->mSystem;
  if ( mSystem )
  {
    v4 = 1;
    FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMLIST);
  }
  else
  {
    v4 = 0;
  }
  p_mFlags = &this->mFlags;
  v6 = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( (this->mFlags.m_value & 0x20) != 0 )
    goto LABEL_4;
  mSubSoundShared = this->mSubSoundShared;
  if ( mSubSoundShared )
  {
    if ( this == mSubSoundShared )
    {
      mSubSoundParent = this->mSubSoundParent;
      if ( mSubSoundParent )
      {
        LOBYTE(v6) = 62;
        if ( (mSubSoundParent->mFlags.m_value & 0x20) == 0 )
          goto LABEL_4;
      }
    }
  }
  _InterlockedOr((volatile signed __int32 *)p_mFlags, 0x20u);
  if ( mSystem && v4 )
  {
    v4 = 0;
    FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMLIST);
  }
  mCodec = this->mCodec;
  if ( mCodec )
  {
    mFile = mCodec->mFile;
    if ( mFile )
      FMOD::File::cancel(mFile);
  }
  p_mOpenState = &this->mOpenState;
  while ( p_mOpenState->m_value && p_mOpenState->m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_ERROR_0 || this->mDontRelease )
    FMOD_OS_Time_Sleep(2u);
  v12 = this->mSystem;
  if ( v12 )
  {
    v6 = FMOD::SystemI::stopSound(v12, this);
    if ( v6 )
      goto LABEL_4;
  }
  mSyncPointHead = this->mSyncPointHead;
  if ( mSyncPointHead )
  {
    for ( i = (FMOD_SYNCPOINT *)mSyncPointHead->mNodeNext;
          this->mSyncPointTail != mSyncPointHead->mNodeNext;
          i = (FMOD_SYNCPOINT *)mSyncPointHead->mNodeNext )
    {
      FMOD::SoundI::deleteSyncPointInternal(this, i, 1);
      mSyncPointHead = this->mSyncPointHead;
    }
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mSyncPointHead, "../../../core_api/src/fmod_soundi.cpp", 505);
    this->mSyncPointHead = 0;
    this->mSyncPointTail = 0;
  }
  mNumSyncPointsMulti = this->mNumSyncPointsMulti;
  if ( mNumSyncPointsMulti )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mNumSyncPointsMulti, "../../../core_api/src/fmod_soundi.cpp", 512);
    this->mNumSyncPointsMulti = 0;
  }
  mSyncPointMemory = this->mSyncPointMemory;
  if ( mSyncPointMemory )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mSyncPointMemory, "../../../core_api/src/fmod_soundi.cpp", 518);
    this->mSyncPointMemory = 0;
  }
  oldcodec = this->mCodec;
  oldasyncdata = this->mAsyncData;
  oldstreamchannel = 0;
  if ( (*this->_vptr_SoundI)(this) )
  {
    v17 = this->mCodec;
    if ( v17 )
    {
      v18 = this->mSubSoundParent;
      if ( !v18 || this == v18 || v17 != v18->mCodec )
      {
        v19 = *((_QWORD *)this + 47);
        if ( v19 )
        {
          *(_BYTE *)(v19 + 136) = 1;
          if ( (this->mFlags.m_value & 4) == 0 )
            _InterlockedOr((volatile signed __int32 *)p_mFlags, 0x40u);
        }
        v20 = this->mSystem;
        v21 = this + 1;
        if ( (v20->mFlags & 1) == 0 && (v21 != *((FMOD::SoundI **)this + 44) || v21 != *((FMOD::SoundI **)this + 45)) )
        {
          while ( (p_mFlags->m_value & 0x40) == 0 )
            FMOD_OS_Time_Sleep(2u);
          v20 = this->mSystem;
        }
        FMOD::SystemI::enterCrit(v20, FMOD_SYSTEM_CRIT_STREAMLIST);
        v22 = (_QWORD *)*((_QWORD *)this + 45);
        v23 = this->mSystem;
        *v22 = *((_QWORD *)this + 44);
        *(_QWORD *)(*((_QWORD *)this + 44) + 8LL) = v22;
        *((_QWORD *)this + 45) = v21;
        *((_QWORD *)this + 44) = v21;
        *((_QWORD *)this + 46) = 0;
        FMOD::SystemI::leaveCrit(v23, FMOD_SYSTEM_CRIT_STREAMLIST);
        v24 = (__int64 *)*((_QWORD *)this + 48);
        oldstreamchannel = (FMOD::ChannelReal *)*((_QWORD *)this + 47);
        if ( v24 )
        {
          v25 = *v24;
          v24[12] = 0;
          (*(void (__fastcall **)(__int64 *, __int64))(v25 + 24))(v24, 1);
          *((_QWORD *)this + 48) = 0;
        }
      }
    }
  }
  mNumSubSounds = this->mNumSubSounds;
  if ( mNumSubSounds )
  {
    mSubSound = this->mSubSound;
    if ( mSubSound )
    {
      if ( this->mNumActiveSubSounds && mNumSubSounds > 0 )
      {
        v28 = oldasyncdata;
        v66 = mSystem;
        oldasyncdataa = v4;
        v29 = 1;
        do
        {
          v30 = v29;
          v31 = 8 * v29 - 8;
          v32 = (__int64 *)((char *)mSubSound + v31);
          v33 = *(__int64 *)((char *)mSubSound + v31);
          if ( v33 )
          {
            if ( *(FMOD::Codec **)(v33 + 96) == oldcodec )
            {
              *(_QWORD *)(v33 + 96) = 0;
              v33 = *v32;
            }
            if ( *(FMOD::AsyncData **)(v33 + 264) == v28 )
            {
              *(_QWORD *)(v33 + 264) = 0;
              v33 = *v32;
            }
            v34 = (**(__int64 (__fastcall ***)(__int64))v33)(v33);
            v35 = this->mSubSound;
            if ( v34 )
            {
              v36 = *(FMOD::SoundI **)((char *)v35 + v31);
              v37 = v36;
              if ( v36[1].mNodeData == oldstreamchannel )
              {
                v36[1].mNodeData = 0;
                v37 = *(FMOD::SoundI **)((char *)v35 + v31);
                v36 = v35[v30 - 1];
              }
            }
            else
            {
              v36 = v35[v30 - 1];
              v37 = v36;
            }
            if ( v37->mSubSoundShared && (v38 = this->mNumSubSounds, (int)v29 < v38) )
            {
              v39 = v29 + 1;
              v40 = (unsigned int)(~(_DWORD)v29 + v38);
              v41 = 8 * v29;
              v42 = 8 * (v29 + 1 + v40);
              do
              {
                if ( v35[(unsigned __int64)v41 / 8] == v36 )
                {
                  v35[(unsigned __int64)v41 / 8] = 0;
                  v35 = this->mSubSound;
                  v36 = *(FMOD::SoundI **)((char *)v35 + v31);
                }
                v41 += 8;
              }
              while ( v41 != v42 );
              v43 = v29;
            }
            else
            {
              v43 = v29;
              v39 = v29 + 1;
            }
            (*((void (__fastcall **)(FMOD::SoundI *, __int64))v36->_vptr_SoundI + 3))(v36, 1);
            this->mSubSound[v30 - 1] = 0;
            mSubSound = this->mSubSound;
          }
          else
          {
            v43 = v29;
            v39 = v29 + 1;
          }
          v29 = v39;
        }
        while ( this->mNumSubSounds > v43 );
        v4 = oldasyncdataa;
        mSystem = v66;
      }
      FMOD::MemPool::free(off_286F358->gSystemMemPool, mSubSound, "../../../core_api/src/fmod_soundi.cpp", 643);
      v44 = this->mSubSoundShared;
      this->mSubSound = 0;
      if ( v44 )
      {
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v44, "../../../core_api/src/fmod_soundi.cpp", 648);
        this->mSubSoundShared = 0;
      }
    }
  }
  v45 = this->mCodec;
  if ( v45 )
  {
    v46 = this->mSubSoundParent;
    if ( !v46 || this == v46 || v45 != v46->mCodec )
    {
      FMOD::Codec::release(v45, 1);
      this->mCodec = 0;
    }
  }
  v47 = (*this->_vptr_SoundI)(this);
  v48 = this->mSubSoundParent;
  if ( !v47 )
  {
LABEL_83:
    mAsyncData = this->mAsyncData;
    if ( !mAsyncData )
      goto LABEL_90;
    if ( !v48 )
      goto LABEL_86;
    goto LABEL_85;
  }
  v49 = (void *)*((_QWORD *)this + 47);
  if ( !v48 || v48[1].mNodeData != v49 )
  {
    if ( v49 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v49, "../../../core_api/src/fmod_soundi.cpp", 678);
      v48 = this->mSubSoundParent;
      *((_QWORD *)this + 47) = 0;
    }
    goto LABEL_83;
  }
  mAsyncData = this->mAsyncData;
  *((_QWORD *)this + 47) = 0;
  if ( mAsyncData )
  {
LABEL_85:
    if ( mAsyncData == v48->mAsyncData )
    {
LABEL_89:
      this->mAsyncData = 0;
      goto LABEL_90;
    }
LABEL_86:
    if ( mAsyncData->mName )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, mAsyncData->mName, "../../../core_api/src/fmod_soundi.cpp", 691);
      mAsyncData = this->mAsyncData;
    }
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mAsyncData, "../../../core_api/src/fmod_soundi.cpp", 693);
    v48 = this->mSubSoundParent;
    goto LABEL_89;
  }
LABEL_90:
  if ( v48 )
  {
    v51 = v48->mNumSubSounds;
    if ( v51 > 0 )
    {
      v52 = v48->mSubSound;
      v53 = 0;
      while ( !v52 || v52[v53] != this )
      {
        if ( v51 <= (int)++v53 )
          goto LABEL_96;
      }
      FMOD::SoundI::setSubSoundInternal(v48, v53, 0, 1);
    }
  }
LABEL_96:
  mNameMemory = this->mNameMemory;
  if ( mNameMemory )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mNameMemory, "../../../core_api/src/fmod_soundi.cpp", 718);
    this->mNameMemory = 0;
  }
  v55 = off_286F358;
  this->mName = 0;
  v6 = FMOD_RESULT::FMOD_OK_0;
  FMOD_OS_CriticalSection_Enter(v55->gSoundListCrit);
  mNodePrev = this->mNodePrev;
  mNodePrev->mNodeNext = this->mNodeNext;
  this->mNodeNext->mNodePrev = mNodePrev;
  mNodeNext = this->mSoundGroupNode.mNodeNext;
  v58 = this->mSoundGroupNode.mNodePrev;
  this->mNodePrev = &this->FMOD::LinkedListNode;
  this->mNodeNext = &this->FMOD::LinkedListNode;
  v58->mNodeNext = mNodeNext;
  this->mSoundGroupNode.mNodeNext->mNodePrev = v58;
  this->mSoundGroupNode.mNodePrev = &this->mSoundGroupNode;
  this->mSoundGroupNode.mNodeNext = &this->mSoundGroupNode;
  FMOD_OS_CriticalSection_Leave(off_286F358->gSoundListCrit);
  if ( freethis && !this->mSubSoundShared )
  {
    v59 = off_286F358;
    this->mMagic = -559063315;
    FMOD::MemPool::free(v59->gSystemMemPool, this, "../../../core_api/src/fmod_soundi.cpp", 733);
  }
LABEL_4:
  if ( v4 && mSystem )
    FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_STREAMLIST);
  return v6;
}


