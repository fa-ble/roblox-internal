// Address: 0x22482d0 | Name: _ZN4FMOD19DSPEnvelopeFollower22shouldIProcessCallbackEP14FMOD_DSP_STATEijji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::shouldIProcessCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD_BOOL inputsidle,
        unsigned int a3,
        FMOD_CHANNELMASK a4,
        int a5,
        FMOD_SPEAKERMODE_0 a6)
{
  FMOD_RESULT_0 result; // eax
  float *instance; // rdx
  float v8; // xmm0_4

  result = FMOD_RESULT::FMOD_OK_0;
  instance = (float *)dsp_state->instance;
  if ( inputsidle && !*((_DWORD *)instance + 140) )
  {
    v8 = instance[136];
    if ( v8 < 0.0 )
      LOBYTE(result) = v8 > -0.000099999997;
    else
      LOBYTE(result) = v8 < 0.000099999997;
    return (result << 31 >> 31) & 6;
  }
  return result;
}


// Address: 0x2248320 | Name: _ZN4FMOD19DSPEnvelopeFollower16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPEnvelopeFollower::getDescriptionEx()
{
  memset(&stru_2B05700, 0, sizeof(stru_2B05700));
  FMOD_strcpy_safe(stru_2B05700.name, "Attack", 16);
  FMOD_strcpy_safe(stru_2B05700.label, "ms", 16);
  *(_QWORD *)&stru_2B05700.floatdesc.min = 0x43FA00003DCCCCCDLL;
  stru_2B05700.description = "EnvelopeFollower attack time. [0.1ms,500ms]  Default = 20ms.";
  memset(&stru_2B056A0, 0, sizeof(stru_2B056A0));
  stru_2B05700.intdesc.defaultval = 1101004800;
  stru_2B05700.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B056A0.name, "Release", 16);
  FMOD_strcpy_safe(stru_2B056A0.label, "ms", 16);
  *(_QWORD *)&stru_2B056A0.floatdesc.min = 0x459C400041200000LL;
  stru_2B056A0.description = "EnvelopeFollower release time. [10ms,5000ms]  Default = 200ms.";
  memset(&stru_2B05640, 0, sizeof(stru_2B05640));
  stru_2B056A0.intdesc.defaultval = 1128792064;
  stru_2B056A0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B05640.name, "Envelope", 16);
  FMOD_strcpy_safe(stru_2B05640.label, (const char *)&uri_string, 16);
  stru_2B05640.description = "Envelope level (read-only)";
  memset(&stru_2B055E0, 0, sizeof(stru_2B055E0));
  stru_2B05640.intdesc.min = 0;
  *(_QWORD *)(&stru_2B05640.datadesc + 1) = 1065353216;
  stru_2B05640.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B055E0.type = FMOD_DSP_PARAMETER_TYPE_DATA;
  FMOD_strcpy_safe(stru_2B055E0.name, "Use sidechain", 16);
  FMOD_strcpy_safe(stru_2B055E0.label, (const char *)&uri_string, 16);
  stru_2B055E0.intdesc.min = -3;
  *(&stru_2B055A0.mHandle + 1) = 31;
  stru_2B055A0.mSize = 568;
  stru_2B055E0.description = "Analyse the sidechain signal instead of the input signal.";
  stru_2B055A0.mDescription = &stru_286F660;
  return &stru_2B055A0;
}


// Address: 0x2248530 | Name: _ZN4FMOD19DSPEnvelopeFollower13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::resetInternal(FMOD::DSPEnvelopeFollower *const this)
{
  *((_DWORD *)this + 136) = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2248540 | Name: _ZN4FMOD19DSPEnvelopeFollower14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::createInternal(FMOD::DSPEnvelopeFollower *const this)
{
  double v1; // xmm1_8
  __int64 v2; // rbp
  __int64 v3; // rdx
  int v4; // ebx
  _DWORD *v5; // rcx
  int v6; // esi

  v2 = 0;
  v3 = *((_QWORD *)this + 30);
  v4 = 0;
  for ( *((_DWORD *)this + 140) = 0; *(_DWORD *)(v3 + 96) > v4; v2 += 8 )
  {
    while ( 1 )
    {
      v5 = *(_DWORD **)(*(_QWORD *)(v3 + 104) + v2);
      if ( *v5 )
        break;
      v6 = v4++;
      v2 += 8;
      FMOD::DSPI::setParameterFloat((FMOD::DSPI *const)this, v6, (__m128i)(unsigned int)v5[14], v1);
      v3 = *((_QWORD *)this + 30);
      if ( *(_DWORD *)(v3 + 96) <= v4 )
        goto LABEL_8;
    }
    if ( *v5 == 2 )
    {
      FMOD::DSPI::setParameterBool((FMOD::DSPI *const)this, v4, v5[12] != 0);
      v3 = *((_QWORD *)this + 30);
    }
    ++v4;
  }
LABEL_8:
  FMOD::DSPEnvelopeFollower::resetInternal(this);
  *((_BYTE *)this + 548) = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22485f0 | Name: _ZN4FMOD19DSPEnvelopeFollower14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPEnvelopeFollower::createInternal((FMOD::DSPEnvelopeFollower *const)dsp_state->instance);
}


// Address: 0x2248600 | Name: _ZN4FMOD19DSPEnvelopeFollower13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPEnvelopeFollower::resetInternal((FMOD::DSPEnvelopeFollower *const)dsp_state->instance);
}


// Address: 0x2248610 | Name: _ZN4FMOD19DSPEnvelopeFollower12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::readInternal(
        FMOD::DSPEnvelopeFollower *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *a6)
{
  float *v10; // r15
  float v11; // xmm0_4
  float v12; // xmm0_4
  unsigned int v13; // r11d
  int v14; // edi
  __int64 v15; // r9
  float *v16; // r8
  float *v17; // r10
  float *v18; // r9
  float v19; // xmm1_4
  __int64 v20; // rax
  float v21; // xmm0_4
  float v22; // xmm0_4
  float v23; // xmm3_4
  __int64 v24; // rax

  if ( inbuffer )
  {
    v10 = inbuffer;
    if ( *((_DWORD *)this + 140) )
      v10 = (float *)*((_QWORD *)this + 26);
    v11 = *((float *)this + 138);
    if ( v11 != *((float *)this + 132) || *((_BYTE *)this + 548) )
    {
      *((float *)this + 132) = v11;
      *((float *)this + 133) = 1.0
                             - expf(
                                 -2.2
                               / (float)((float)*(int *)(*((_QWORD *)this + 22) + 1696LL) * (float)(v11 / 1000.0)));
    }
    v12 = *((float *)this + 139);
    if ( v12 != *((float *)this + 134) || *((_BYTE *)this + 548) )
    {
      *((float *)this + 134) = v12;
      *((float *)this + 135) = 1.0
                             - expf(
                                 -2.2
                               / (float)((float)*(int *)(*((_QWORD *)this + 22) + 1696LL) * (float)(v12 / 1000.0)));
    }
    *((_BYTE *)this + 548) = 0;
    if ( length )
    {
      v13 = 0;
      v14 = 0;
      do
      {
        v15 = v13;
        v16 = &inbuffer[v15];
        v17 = &v10[v15];
        v18 = &outbuffer[v15];
        if ( inchannels <= 0 )
        {
          v19 = 0.0;
        }
        else
        {
          v19 = 0.0;
          v20 = 0;
          do
          {
            v21 = v17[v20++];
            v19 = v19 + (float)((float)(v21 / (float)inchannels) * (float)(v21 / (float)inchannels));
          }
          while ( inchannels > (int)v20 );
        }
        v22 = *((float *)this + 136);
        if ( v19 <= v22 )
          v23 = *((float *)this + 135);
        else
          v23 = *((float *)this + 133);
        v24 = 0;
        for ( *((float *)this + 136) = (float)((float)(v19 - v22) * v23) + v22; inchannels > (int)v24; ++v24 )
          v18[v24] = v16[v24];
        ++v14;
        v13 += inchannels;
      }
      while ( v14 != length );
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2248830 | Name: _ZN4FMOD19DSPEnvelopeFollower12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPEnvelopeFollower::readInternal(
           (FMOD::DSPEnvelopeFollower *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x2248840 | Name: _ZN4FMOD19DSPEnvelopeFollower25setParameterFloatInternalEif
char __fastcall FMOD::DSPEnvelopeFollower::setParameterFloatInternal(
        FMOD::DSPEnvelopeFollower *const this,
        int index,
        float a3,
        float value)
{
  char result; // al

  if ( index == 1 )
  {
    *((float *)this + 139) = a3;
    return 0;
  }
  else
  {
    result = 68;
    if ( index != 2 )
    {
      if ( index )
      {
        return 31;
      }
      else
      {
        *((float *)this + 138) = a3;
        return 0;
      }
    }
  }
  return result;
}


// Address: 0x2248880 | Name: _ZN4FMOD19DSPEnvelopeFollower25setParameterFloatCallbackEP14FMOD_DSP_STATEif
char __fastcall FMOD::DSPEnvelopeFollower::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPEnvelopeFollower::setParameterFloatInternal(
           (FMOD::DSPEnvelopeFollower *const)dsp_state->instance,
           index,
           a3,
           value);
}


// Address: 0x2248890 | Name: _ZN4FMOD19DSPEnvelopeFollower25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::getParameterFloatInternal(
        FMOD::DSPEnvelopeFollower *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v5; // xmm0_4

  if ( index == 1 )
  {
    *value = *((float *)this + 139);
    if ( valuestr )
    {
      v5 = *((float *)this + 139);
      goto LABEL_9;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( index == 2 )
  {
    *value = fsqrt(*((float *)this + 136));
    if ( valuestr )
    {
      v5 = *((float *)this + 136);
      goto LABEL_9;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( index )
    return FMOD_RESULT::FMOD_OK_0;
  *value = *((float *)this + 138);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  v5 = *((float *)this + 138);
LABEL_9:
  sprintf(valuestr, "%.02f", v5);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2248960 | Name: _ZN4FMOD19DSPEnvelopeFollower25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPEnvelopeFollower::getParameterFloatInternal(
           (FMOD::DSPEnvelopeFollower *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x2248970 | Name: _ZN4FMOD19DSPEnvelopeFollower24setParameterDataInternalEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::setParameterDataInternal(
        FMOD::DSPEnvelopeFollower *const this,
        int index,
        void *data,
        unsigned int a4)
{
  if ( index != 3 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *((_DWORD *)this + 140) = *(_DWORD *)data == 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22489a0 | Name: _ZN4FMOD19DSPEnvelopeFollower24setParameterDataCallbackEP14FMOD_DSP_STATEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::setParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void *data,
        unsigned int length)
{
  return FMOD::DSPEnvelopeFollower::setParameterDataInternal(
           (FMOD::DSPEnvelopeFollower *const)dsp_state->instance,
           index,
           data,
           length);
}


// Address: 0x22489b0 | Name: _ZN4FMOD19DSPEnvelopeFollower24getParameterDataInternalEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::getParameterDataInternal(
        FMOD::DSPEnvelopeFollower *const this,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  const char *v5; // rsi

  if ( index != 3 )
    return FMOD_RESULT::FMOD_OK_0;
  *data = (char *)this + 560;
  *length = 4;
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  v5 = "true";
  if ( !*((_DWORD *)this + 140) )
    v5 = "false";
  strcpy(valuestr, v5);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2248a10 | Name: _ZN4FMOD19DSPEnvelopeFollower24getParameterDataCallbackEP14FMOD_DSP_STATEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPEnvelopeFollower::getParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  return FMOD::DSPEnvelopeFollower::getParameterDataInternal(
           (FMOD::DSPEnvelopeFollower *const)dsp_state->instance,
           index,
           data,
           length,
           valuestr);
}


