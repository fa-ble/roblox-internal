// Address: 0x21c2220 | Name: FMOD_DSP_Convert_FloatToPCM16_NoOpt
void __fastcall FMOD_DSP_Convert_FloatToPCM16_NoOpt(
        __int16 *outbuffer,
        float *inbuffer,
        unsigned int length,
        int destchannelstep,
        int srcchannelstep,
        float volume)
{
  unsigned int v6; // r10d
  __int64 v7; // r12
  __int64 v8; // r15
  __int64 v9; // r11
  __int64 v10; // rbx
  __int64 v11; // r14
  __int64 v12; // r13
  __int16 *v13; // rdx
  unsigned int v15; // ecx
  float *v16; // rax
  __int16 v17; // r10
  int v18; // r9d
  int v19; // r8d
  int v20; // edi
  int v21; // esi
  __int16 v22; // r9
  __int16 v23; // r8
  __int16 v24; // di
  __int64 v25; // rax
  int v26; // eax
  __int16 v27; // cx
  int v28; // edx
  __int64 v29; // [rsp+0h] [rbp-60h]
  __int64 v30; // [rsp+8h] [rbp-58h]
  char v31; // [rsp+10h] [rbp-50h]
  unsigned int v32; // [rsp+14h] [rbp-4Ch]
  __int16 *v35; // [rsp+20h] [rbp-40h]
  float *v36; // [rsp+28h] [rbp-38h]

  v6 = length >> 2;
  v31 = length;
  v32 = length >> 2;
  if ( length >> 2 )
  {
    v7 = destchannelstep;
    v8 = srcchannelstep;
    v9 = 2LL * destchannelstep;
    v10 = 3LL * destchannelstep;
    v11 = 2LL * srcchannelstep;
    v12 = 3LL * srcchannelstep;
    v13 = outbuffer;
    v35 = outbuffer;
    v36 = inbuffer;
    v29 = 16LL * srcchannelstep;
    v15 = v6;
    v30 = 8LL * destchannelstep;
    v16 = inbuffer;
    do
    {
      v17 = 0x8000;
      v18 = (int)(float)(*v16 * volume);
      v19 = (int)(float)(v16[v8] * volume);
      v20 = (int)(float)(v16[v11] * volume);
      v21 = (int)(float)(v16[v12] * volume);
      if ( v18 >= -32768 )
      {
        v17 = (int)(float)(*v16 * volume);
        if ( v18 > 0x7FFF )
          v17 = 0x7FFF;
      }
      *v13 = v17;
      v22 = 0x8000;
      if ( v19 >= -32768 )
      {
        v22 = v19;
        if ( v19 > 0x7FFF )
          v22 = 0x7FFF;
      }
      v13[v7] = v22;
      v23 = 0x8000;
      if ( v20 >= -32768 )
      {
        v23 = v20;
        if ( v20 > 0x7FFF )
          v23 = 0x7FFF;
      }
      v13[v9] = v23;
      v24 = 0x8000;
      if ( v21 >= -32768 )
      {
        v24 = v21;
        if ( v21 > 0x7FFF )
          v24 = 0x7FFF;
      }
      v13[v10] = v24;
      v16 = (float *)((char *)v16 + v29);
      v13 = (__int16 *)((char *)v13 + v30);
      --v15;
    }
    while ( v15 );
    v25 = v32 - 1 + 1LL;
    inbuffer = (float *)((char *)v36 + v25 * v29);
    outbuffer = (__int16 *)((char *)v35 + v30 * v25);
  }
  v26 = v31 & 3;
  if ( (v31 & 3) != 0 )
  {
    do
    {
      v27 = 0x8000;
      v28 = (int)(float)(*inbuffer * volume);
      if ( v28 >= -32768 )
      {
        v27 = (int)(float)(*inbuffer * volume);
        if ( v28 > 0x7FFF )
          v27 = 0x7FFF;
      }
      *outbuffer = v27;
      inbuffer += srcchannelstep;
      outbuffer += destchannelstep;
      --v26;
    }
    while ( v26 );
  }
}


