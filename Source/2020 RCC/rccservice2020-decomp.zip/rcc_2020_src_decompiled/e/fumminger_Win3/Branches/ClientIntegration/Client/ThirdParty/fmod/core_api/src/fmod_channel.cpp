// Address: 0x21b1290 | Name: _ZN4FMOD7Channel11setPriorityEi
FMOD_RESULT_0 __fastcall FMOD::Channel::setPriority(FMOD::Channel *const this, int priority)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v2 || (v2 = FMOD::ChannelI::setPriority(channeli, priority)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, priority);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::setPriority",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b1340 | Name: _ZN4FMOD7Channel11getPriorityEPi
FMOD_RESULT_0 __fastcall FMOD::Channel::getPriority(FMOD::Channel *const this, int *priority)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  if ( priority )
    *priority = 0;
  lockScope.mSystem = 0;
  v2 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v2 || (v2 = FMOD::ChannelI::getPriority(channeli, priority)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, priority);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::getPriority",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b1400 | Name: _ZN4FMOD7Channel11setPositionEjj
FMOD_RESULT_0 __fastcall FMOD::Channel::setPosition(
        FMOD::Channel *const this,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v4 || (v4 = FMOD::ChannelI::setPosition(channeli, position, postype)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, position);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), postype);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::setPosition",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21b1500 | Name: _ZN4FMOD7Channel11getPositionEPjj
FMOD_RESULT_0 __fastcall FMOD::Channel::getPosition(
        FMOD::Channel *const this,
        unsigned int *position,
        FMOD_TIMEUNIT postype)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // ebp
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  if ( position )
    *position = 0;
  lockScope.mSystem = 0;
  v4 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v4 || (v4 = FMOD::ChannelI::getPosition(channeli, position, postype)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, position);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), postype);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::getPosition",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21b1610 | Name: _ZN4FMOD7Channel15setChannelGroupEPNS_12ChannelGroupE
FMOD_RESULT_0 __fastcall FMOD::Channel::setChannelGroup(FMOD::Channel *const this, FMOD::ChannelGroup *channelgroup)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v2
     || (v2 = FMOD::ChannelI::setChannelGroup(channeli, (FMOD::ChannelGroupI *)channelgroup)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, channelgroup);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::setChannelGroup",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b16c0 | Name: _ZN4FMOD7Channel15getChannelGroupEPPNS_12ChannelGroupE
FMOD_RESULT_0 __fastcall FMOD::Channel::getChannelGroup(FMOD::Channel *const this, FMOD::ChannelGroup **channelgroup)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  if ( channelgroup )
    *channelgroup = 0;
  lockScope.mSystem = 0;
  v2 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v2
     || (v2 = FMOD::ChannelI::getChannelGroup(channeli, (FMOD::ChannelGroupI **)channelgroup)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, channelgroup);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::getChannelGroup",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b1780 | Name: _ZN4FMOD7Channel12setFrequencyEf
__int64 __fastcall FMOD::Channel::setFrequency(FMOD::Channel *const this, double a2, float frequency)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::ChannelI *channeli; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v3 || (v3 = FMOD::ChannelI::setFrequency(channeli, frequency)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, frequency);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::setFrequency",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21b1830 | Name: _ZN4FMOD7Channel12getFrequencyEPf
FMOD_RESULT_0 __fastcall FMOD::Channel::getFrequency(FMOD::Channel *const this, float *frequency)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  if ( frequency )
    *frequency = 0.0;
  lockScope.mSystem = 0;
  v2 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v2 || (v2 = FMOD::ChannelI::getFrequency(channeli, frequency)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, frequency);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::getFrequency",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b18f0 | Name: _ZN4FMOD7Channel9isVirtualEPb
FMOD_RESULT_0 __fastcall FMOD::Channel::isVirtual(FMOD::Channel *const this, bool *isvirtual)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  if ( isvirtual )
    *isvirtual = 0;
  lockScope.mSystem = 0;
  v2 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v2
     || (v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelI *, bool *))channeli->_vptr_ChannelControlI + 62))(
                channeli,
                isvirtual)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, isvirtual);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::isVirtual",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b19b0 | Name: _ZN4FMOD7Channel15getCurrentSoundEPPNS_5SoundE
FMOD_RESULT_0 __fastcall FMOD::Channel::getCurrentSound(FMOD::Channel *const this, FMOD::Sound **sound)
{
  FMOD_RESULT_0 CurrentSound; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  CurrentSound = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( CurrentSound )
  {
    if ( sound )
      *sound = 0;
  }
  else
  {
    CurrentSound = FMOD::ChannelI::getCurrentSound(channeli, (FMOD::SoundI **)sound);
    if ( CurrentSound == FMOD_RESULT::FMOD_OK_0 )
      goto LABEL_6;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, sound);
    FMOD_ReportError(
      CurrentSound,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::getCurrentSound",
      _buffer);
  }
LABEL_6:
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return CurrentSound;
}


// Address: 0x21b1a70 | Name: _ZN4FMOD7Channel8getIndexEPi
FMOD_RESULT_0 __fastcall FMOD::Channel::getIndex(FMOD::Channel *const this, int *index)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( v2 )
  {
    if ( index )
      *index = 0;
  }
  else
  {
    v2 = FMOD::ChannelI::getIndex(channeli, index);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      goto LABEL_6;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, index);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::getIndex",
      _buffer);
  }
LABEL_6:
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b1b30 | Name: _ZN4FMOD7Channel12setLoopCountEi
FMOD_RESULT_0 __fastcall FMOD::Channel::setLoopCount(FMOD::Channel *const this, int loopcount)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v2 || (v2 = FMOD::ChannelI::setLoopCount(channeli, loopcount)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, loopcount);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::setLoopCount",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b1be0 | Name: _ZN4FMOD7Channel12getLoopCountEPi
FMOD_RESULT_0 __fastcall FMOD::Channel::getLoopCount(FMOD::Channel *const this, int *loopcount)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelI *channeli; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  if ( loopcount )
    *loopcount = 0;
  lockScope.mSystem = 0;
  v2 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v2 || (v2 = FMOD::ChannelI::getLoopCount(channeli, loopcount)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, loopcount);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::getLoopCount",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21b1ca0 | Name: _ZN4FMOD7Channel13setLoopPointsEjjjj
FMOD_RESULT_0 __fastcall FMOD::Channel::setLoopPoints(
        FMOD::Channel *const this,
        unsigned int loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int loopend,
        FMOD_TIMEUNIT loopendtype)
{
  FMOD_RESULT_0 v7; // r13d
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r14d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::ChannelI *channeli; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (v7
     || (v7 = FMOD::ChannelI::setLoopPoints(channeli, loopstart, loopstarttype, loopend, loopendtype)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, loopstart);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), loopstarttype);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = v11 + FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, loopend);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), loopendtype);
    FMOD_ReportError(
      v7,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::setLoopPoints",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v7;
}


// Address: 0x21b1e30 | Name: _ZN4FMOD7Channel13getLoopPointsEPjjS1_j
FMOD_RESULT_0 __fastcall FMOD::Channel::getLoopPoints(
        FMOD::Channel *const this,
        unsigned int *loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int *loopend,
        FMOD_TIMEUNIT loopendtype)
{
  FMOD_RESULT_0 LoopPoints; // ebx
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r15d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::ChannelI *channeli; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  if ( loopstart )
    *loopstart = 0;
  if ( loopend )
    *loopend = 0;
  lockScope.mSystem = 0;
  LoopPoints = FMOD::ChannelI::validate(this, &channeli, &lockScope);
  if ( (LoopPoints
     || (LoopPoints = FMOD::ChannelI::getLoopPoints(channeli, loopstart, loopstarttype, loopend, loopendtype)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, loopstart);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), loopstarttype);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, loopend) + v11;
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), loopendtype);
    FMOD_ReportError(
      LoopPoints,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNEL,
      this,
      "Channel::getLoopPoints",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return LoopPoints;
}


