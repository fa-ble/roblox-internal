// Address: 0x223ac40 | Name: _ZN4FMOD10getGlobalsEPPNS_6GlobalE
void __fastcall FMOD::getGlobals(FMOD::Global **global)
{
  *global = off_286F358;
}


// Address: 0x223ac50 | Name: _ZN4FMOD6GlobalC2Ev
void __fastcall FMOD::Global::Global(FMOD::Global *const this)
{
  this->gFileThreadHead.mNodeData = 0;
  this->gFileThreadHead.mNodePrev = &this->gFileThreadHead;
  this->gFileThreadHead.mNodeNext = &this->gFileThreadHead;
  this->gSystemMemPool = &stru_2B04D80;
  stru_2B04D80.mBlockSize = 256;
  this->gMemoryTypeFlags = -1;
}


// Address: 0x223ac90 | Name: _ZN4FMOD6Global6incRefEv
FMOD_RESULT_0 __fastcall FMOD::Global::incRef(FMOD::Global *const this)
{
  int gSystemInitCount; // eax
  FMOD_RESULT_0 result; // eax

  gSystemInitCount = this->gSystemInitCount;
  if ( this->gSystemInitCount )
    goto LABEL_2;
  result = FMOD_OS_CriticalSection_Create(&this->gSoundListCrit, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_OS_CriticalSection_Create(&this->gFileCrit, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD_OS_CriticalSection_Create(&this->gAsyncCrit, 0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD_OS_Init();
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          gSystemInitCount = this->gSystemInitCount;
LABEL_2:
          this->gSystemInitCount = gSystemInitCount + 1;
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x223acf0 | Name: _ZN4FMOD6Global6decRefEv
FMOD_RESULT_0 __fastcall FMOD::Global::decRef(FMOD::Global *const this)
{
  int v2; // edx
  FMOD_RESULT_0 result; // eax
  bool v4; // zf
  FMOD_OS_CRITICALSECTION *gAsyncCrit; // rdi
  FMOD_OS_CRITICALSECTION *gSoundListCrit; // rdi
  FMOD_OS_CRITICALSECTION *gFileCrit; // rdi

  v2 = this->gSystemInitCount - 1;
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  v4 = this->gSystemInitCount == 1;
  this->gSystemInitCount = v2;
  if ( v2 >= 0 )
  {
    if ( !v4 )
      return FMOD_RESULT::FMOD_OK_0;
    result = FMOD::AsyncThread::shutDown();
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::File::shutDown();
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD_OS_Release();
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          gAsyncCrit = this->gAsyncCrit;
          if ( gAsyncCrit )
          {
            FMOD_OS_CriticalSection_Free(gAsyncCrit, 0);
            this->gAsyncCrit = 0;
          }
          gSoundListCrit = this->gSoundListCrit;
          if ( gSoundListCrit )
          {
            FMOD_OS_CriticalSection_Free(gSoundListCrit, 0);
            this->gSoundListCrit = 0;
          }
          gFileCrit = this->gFileCrit;
          if ( gFileCrit )
          {
            FMOD_OS_CriticalSection_Free(gFileCrit, 0);
            this->gFileCrit = 0;
            return FMOD_RESULT::FMOD_OK_0;
          }
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x223ad80 | Name: _GLOBAL__sub_I_fmod_globals.cpp
void __cdecl GLOBAL__sub_I_fmod_globals_cpp()
{
  FMOD::MemPool::MemPool(&stru_2B04D80);
  __cxa_atexit((void (*)(void *))FMOD::MemPool::close, &stru_2B04D80, &dso_handle);
  FMOD::Global::Global(&stru_2B04C80);
}


