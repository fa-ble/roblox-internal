// Address: 0x21b1fd0 | Name: _ZN4FMOD15ChannelControlI17addUpdateListNodeEv
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::addUpdateListNode(FMOD::ChannelControlI *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b1fe0 | Name: _ZN4FMOD15ChannelControlI21refreshUpdateListNodeEv
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::refreshUpdateListNode(FMOD::ChannelControlI *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e3f50 | Name: _ZN4FMOD15ChannelControlI9isVirtualEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::isVirtual(FMOD::ChannelControlI *const this, bool *isvirtual)
{
  *isvirtual = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e6e0 | Name: _ZN4FMOD15ChannelControlI22set3DOcclusionInternalEffb
__int64 __fastcall FMOD::ChannelControlI::set3DOcclusionInternal(
        FMOD::ChannelControlI *const this,
        double a2,
        float a3,
        float a4)
{
  return 28;
}


// Address: 0x220e6f0 | Name: _ZN4FMOD15ChannelControlI17getNumSubChannelsEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getNumSubChannels(FMOD::ChannelControlI *const this, int *numchannels)
{
  *numchannels = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


