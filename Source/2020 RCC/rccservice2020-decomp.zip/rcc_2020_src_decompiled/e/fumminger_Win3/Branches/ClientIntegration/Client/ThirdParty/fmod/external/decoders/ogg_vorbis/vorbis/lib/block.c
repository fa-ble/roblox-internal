// Address: 0x226f090 | Name: FMOD_vorbis_block_init
int __fastcall FMOD_vorbis_block_init(void *context, vorbis_dsp_state_0 *v, vorbis_block_0 *vb)
{
  vorbis_block_0 *v3; // rdi
  unsigned int v4; // r8d
  __int64 v5; // rcx
  float ***v6; // rdi

  v3 = vb;
  v4 = 136;
  if ( ((unsigned __int8)vb & 1) == 0 )
  {
    if ( ((unsigned __int8)vb & 2) == 0 )
      goto LABEL_3;
LABEL_12:
    v3 = (vorbis_block_0 *)((char *)v3 + 2);
    v4 -= 2;
    HIWORD(v3[-1].res_bits) = 0;
    if ( ((unsigned __int8)v3 & 4) == 0 )
      goto LABEL_4;
    goto LABEL_13;
  }
  v3 = (vorbis_block_0 *)((char *)&vb->pcm + 1);
  LOBYTE(vb->pcm) = 0;
  LOBYTE(v4) = -121;
  if ( (((_BYTE)vb + 1) & 2) != 0 )
    goto LABEL_12;
LABEL_3:
  if ( ((unsigned __int8)v3 & 4) == 0 )
    goto LABEL_4;
LABEL_13:
  LODWORD(v3->pcm) = 0;
  v4 -= 4;
  v3 = (vorbis_block_0 *)((char *)v3 + 4);
LABEL_4:
  v5 = v4 >> 3;
  memset(v3, 0, 8 * v5);
  v6 = &v3->pcm + v5;
  if ( (v4 & 4) != 0 )
  {
    *(_DWORD *)v6 = 0;
    v6 = (float ***)((char *)v6 + 4);
  }
  if ( (v4 & 2) != 0 )
  {
    v6 = (float ***)((char *)v6 + 2);
    *((_WORD *)v6 - 1) = 0;
  }
  if ( (v4 & 1) != 0 )
    *(_BYTE *)v6 = 0;
  vb->vd = (vorbis_dsp_state *)v;
  vb->localalloc = 0;
  vb->localstore = 0;
  return 0;
}


// Address: 0x226f140 | Name: _FMOD_vorbis_block_alloc
void *__fastcall FMOD_vorbis_block_alloc(void *context, vorbis_block_0 *vb, ogg_int32_t bytes)
{
  __int64 localtop; // rcx
  ogg_int32_t v4; // ebp
  ogg_int32_t v5; // edx
  char *localstore; // rax
  alloc_chain *v8; // rax

  localtop = vb->localtop;
  v4 = (bytes + 7) & 0xFFFFFFF8;
  v5 = localtop + v4;
  if ( (int)localtop + v4 <= vb->localalloc )
  {
    localstore = (char *)vb->localstore;
LABEL_3:
    vb->localtop = v5;
    return &localstore[localtop];
  }
  if ( vb->localstore )
  {
    v8 = (alloc_chain *)FMOD_OggVorbis_Malloc(context, 16);
    if ( !v8 )
      return 0;
    vb->totaluse += vb->localtop;
    v8->next = vb->reap;
    v8->ptr = vb->localstore;
    vb->reap = v8;
  }
  vb->localalloc = v4;
  localstore = (char *)FMOD_OggVorbis_Malloc(context, v4);
  vb->localstore = localstore;
  if ( localstore )
  {
    v5 = v4;
    localtop = 0;
    goto LABEL_3;
  }
  return 0;
}


// Address: 0x226f1d0 | Name: _FMOD_vorbis_block_ripcord
int __fastcall FMOD_vorbis_block_ripcord(void *context, vorbis_block_0 *vb)
{
  alloc_chain *reap; // rbx
  alloc_chain *next; // rbp
  ogg_int32_t totaluse; // edx
  int result; // eax
  void *v6; // rax
  ogg_int32_t v7; // edx

  reap = vb->reap;
  if ( reap )
  {
    while ( 1 )
    {
      next = reap->next;
      FMOD_OggVorbis_Free(context, reap->ptr);
      reap->ptr = 0;
      reap->next = 0;
      FMOD_OggVorbis_Free(context, reap);
      if ( !next )
        break;
      reap = next;
    }
  }
  totaluse = vb->totaluse;
  result = 0;
  if ( totaluse )
  {
    v6 = FMOD_OggVorbis_ReAlloc(context, vb->localstore, vb->localalloc + totaluse);
    v7 = vb->totaluse;
    vb->localstore = v6;
    result = -(v6 == 0);
    vb->localalloc += v7;
    vb->totaluse = 0;
    LOBYTE(result) = result & 0x75;
  }
  vb->localtop = 0;
  vb->reap = 0;
  return result;
}


// Address: 0x226f280 | Name: FMOD_vorbis_block_clear
int __fastcall FMOD_vorbis_block_clear(void *context, vorbis_block_0 *vb)
{
  int result; // eax
  void *localstore; // rsi
  vorbis_block_0 *v5; // rdi
  unsigned int v6; // edx
  __int64 v7; // rcx
  float ***v8; // rdi

  result = FMOD_vorbis_block_ripcord(context, vb);
  if ( !result )
  {
    localstore = vb->localstore;
    if ( localstore )
      FMOD_OggVorbis_Free(context, localstore);
    v5 = vb;
    v6 = 136;
    if ( ((unsigned __int8)vb & 1) != 0 )
    {
      LOBYTE(vb->pcm) = 0;
      v5 = (vorbis_block_0 *)((char *)&vb->pcm + 1);
      LOBYTE(v6) = -121;
    }
    if ( ((unsigned __int8)v5 & 2) != 0 )
    {
      v5 = (vorbis_block_0 *)((char *)v5 + 2);
      v6 -= 2;
      HIWORD(v5[-1].res_bits) = 0;
    }
    if ( ((unsigned __int8)v5 & 4) != 0 )
    {
      LODWORD(v5->pcm) = 0;
      v6 -= 4;
      v5 = (vorbis_block_0 *)((char *)v5 + 4);
    }
    v7 = v6 >> 3;
    memset(v5, 0, 8 * v7);
    v8 = &v5->pcm + v7;
    if ( (v6 & 4) != 0 )
    {
      *(_DWORD *)v8 = 0;
      v8 = (float ***)((char *)v8 + 4);
      if ( (v6 & 2) == 0 )
      {
LABEL_12:
        if ( (v6 & 1) == 0 )
          return 0;
LABEL_15:
        *(_BYTE *)v8 = 0;
        return 0;
      }
    }
    else if ( (v6 & 2) == 0 )
    {
      goto LABEL_12;
    }
    v8 = (float ***)((char *)v8 + 2);
    *((_WORD *)v8 - 1) = 0;
    if ( (v6 & 1) == 0 )
      return 0;
    goto LABEL_15;
  }
  return result;
}


// Address: 0x226f360 | Name: FMOD_vorbis_dsp_clear
void __fastcall FMOD_vorbis_dsp_clear(void *context, vorbis_dsp_state_0 *v)
{
  __int64 bitrate_lower; // rbx
  void *backend_state; // r12
  mdct_lookup **v5; // rax
  mdct_lookup **v6; // rax
  _QWORD *v7; // rsi
  __int64 v8; // r15
  _QWORD *v9; // rsi
  __int64 v10; // r15
  float **pcm; // rax
  __int64 v12; // rbx
  float *v13; // rsi
  float **pcmret; // rsi
  vorbis_dsp_state_0 *v15; // rdi
  unsigned int v16; // edx
  __int64 v17; // rcx
  vorbis_info **v18; // rdi
  vorbis_info *vi; // [rsp+8h] [rbp-40h]

  if ( v )
  {
    vi = v->vi;
    if ( v->vi )
      bitrate_lower = v->vi->bitrate_lower;
    else
      bitrate_lower = 0;
    backend_state = v->backend_state;
    if ( backend_state )
    {
      v5 = (mdct_lookup **)*((_QWORD *)backend_state + 1);
      if ( v5 )
      {
        FMOD_mdct_clear(context, *v5);
        FMOD_OggVorbis_Free(context, **((void ***)backend_state + 1));
        FMOD_OggVorbis_Free(context, *((void **)backend_state + 1));
      }
      v6 = (mdct_lookup **)*((_QWORD *)backend_state + 2);
      if ( v6 )
      {
        FMOD_mdct_clear(context, *v6);
        FMOD_OggVorbis_Free(context, **((void ***)backend_state + 2));
        FMOD_OggVorbis_Free(context, *((void **)backend_state + 2));
      }
      v7 = (_QWORD *)*((_QWORD *)backend_state + 4);
      if ( v7 )
      {
        if ( bitrate_lower && *(int *)(bitrate_lower + 16) > 0 )
        {
          v8 = 0;
          do
          {
            ((void (__fastcall *)(void *, _QWORD))FMOD_floor_P[*(int *)(bitrate_lower + 4 * v8 + 1312)]->free_look)(
              context,
              v7[v8]);
            ++v8;
            v7 = (_QWORD *)*((_QWORD *)backend_state + 4);
          }
          while ( *(_DWORD *)(bitrate_lower + 16) > (int)v8 );
        }
        FMOD_OggVorbis_Free(context, v7);
      }
      v9 = (_QWORD *)*((_QWORD *)backend_state + 5);
      if ( v9 )
      {
        if ( bitrate_lower && *(int *)(bitrate_lower + 20) > 0 )
        {
          v10 = 0;
          do
          {
            ((void (__fastcall *)(void *, _QWORD))FMOD_residue_P[*(int *)(bitrate_lower + 4 * v10 + 2080)]->free_look)(
              context,
              v9[v10]);
            ++v10;
            v9 = (_QWORD *)*((_QWORD *)backend_state + 5);
          }
          while ( *(_DWORD *)(bitrate_lower + 20) > (int)v10 );
        }
        FMOD_OggVorbis_Free(context, v9);
      }
    }
    pcm = v->pcm;
    if ( pcm )
    {
      if ( vi && vi->channels > 0 )
      {
        v12 = 0;
        do
        {
          v13 = pcm[v12];
          if ( v13 )
          {
            FMOD_OggVorbis_Free(context, v13);
            pcm = v->pcm;
          }
          ++v12;
        }
        while ( vi->channels > (int)v12 );
      }
      FMOD_OggVorbis_Free(context, pcm);
      pcmret = v->pcmret;
      if ( pcmret )
        FMOD_OggVorbis_Free(context, pcmret);
    }
    if ( backend_state )
      FMOD_OggVorbis_Free(context, backend_state);
    v15 = v;
    v16 = 120;
    if ( ((unsigned __int8)v & 1) != 0 )
    {
      LOBYTE(v->vi) = 0;
      v15 = (vorbis_dsp_state_0 *)((char *)&v->vi + 1);
      LOBYTE(v16) = 119;
    }
    if ( ((unsigned __int8)v15 & 2) != 0 )
    {
      v15 = (vorbis_dsp_state_0 *)((char *)v15 + 2);
      v16 -= 2;
      HIWORD(v15[-1].backend_state) = 0;
    }
    if ( ((unsigned __int8)v15 & 4) != 0 )
    {
      LODWORD(v15->vi) = 0;
      v16 -= 4;
      v15 = (vorbis_dsp_state_0 *)((char *)v15 + 4);
    }
    v17 = v16 >> 3;
    memset(v15, 0, 8 * v17);
    v18 = &v15->vi + v17;
    if ( (v16 & 4) != 0 )
    {
      *(_DWORD *)v18 = 0;
      v18 = (vorbis_info **)((char *)v18 + 4);
      if ( (v16 & 2) == 0 )
      {
LABEL_40:
        if ( (v16 & 1) == 0 )
          return;
LABEL_42:
        *(_BYTE *)v18 = 0;
        return;
      }
    }
    else if ( (v16 & 2) == 0 )
    {
      goto LABEL_40;
    }
    v18 = (vorbis_info **)((char *)v18 + 2);
    *((_WORD *)v18 - 1) = 0;
    if ( (v16 & 1) != 0 )
      goto LABEL_42;
  }
}


// Address: 0x226f5f0 | Name: FMOD_vorbis_synthesis_restart
int __fastcall FMOD_vorbis_synthesis_restart(vorbis_dsp_state_0 *v)
{
  _QWORD *backend_state; // rdx
  vorbis_info *vi; // rax
  __int64 bitrate_lower; // rax
  int v4; // esi
  int v5; // eax
  ogg_int32_t v6; // eax

  backend_state = v->backend_state;
  vi = v->vi;
  if ( !backend_state )
    return -1;
  if ( !vi )
    return -1;
  bitrate_lower = vi->bitrate_lower;
  if ( !bitrate_lower )
    return -1;
  v4 = *(_DWORD *)(bitrate_lower + 4904);
  v5 = *(_DWORD *)(bitrate_lower + 4);
  v->pcm_returned = -1;
  v->granulepos = -1;
  v->sequence = -1;
  v->eofflag = 0;
  v6 = v5 >> (v4 + 1);
  v->centerW = v6;
  v->pcm_current = v6 >> v4;
  backend_state[6] = -1;
  return 0;
}


// Address: 0x226f660 | Name: FMOD_vorbis_synthesis_init
int __fastcall FMOD_vorbis_synthesis_init(void *context, vorbis_dsp_state_0 *v, vorbis_info_0 *vi)
{
  int *codec_setup; // rbx
  int v6; // r14d
  vorbis_dsp_state_0 *v7; // rdi
  unsigned int v8; // edx
  __int64 v9; // rcx
  vorbis_info **v10; // rdi
  _DWORD *v11; // r13
  int v12; // edx
  int v13; // eax
  void *v14; // rax
  void *v15; // rax
  void **v16; // r15
  void **v17; // r15
  int v18; // edx
  unsigned int v19; // eax
  int v20; // edx
  int v21; // ecx
  int v22; // edx
  bool v23; // zf
  float **v24; // rax
  float **v25; // rax
  float **pcm; // rax
  __int64 v27; // r15
  unsigned int i; // eax
  unsigned int v30; // eax
  int v31; // edx
  ogg_int32_t v32; // eax
  int v33; // esi
  void *v34; // rax
  void *v35; // rax
  __int64 v36; // r15
  _QWORD *v37; // r14
  __int64 v38; // r15
  _QWORD *v39; // r14
  codebook_0 *v40; // rax
  __int64 v41; // r15
  int v43; // [rsp+8h] [rbp-40h]

  codec_setup = (int *)vi->codec_setup;
  if ( !codec_setup )
  {
    v43 = 1;
    goto LABEL_33;
  }
  v6 = codec_setup[1226];
  v7 = v;
  v8 = 120;
  if ( ((unsigned __int8)v & 1) != 0 )
  {
    LOBYTE(v->vi) = 0;
    v7 = (vorbis_dsp_state_0 *)((char *)&v->vi + 1);
    LOBYTE(v8) = 119;
  }
  if ( ((unsigned __int8)v7 & 2) != 0 )
  {
    v7 = (vorbis_dsp_state_0 *)((char *)v7 + 2);
    v8 -= 2;
    HIWORD(v7[-1].backend_state) = 0;
  }
  if ( ((unsigned __int8)v7 & 4) != 0 )
  {
    LODWORD(v7->vi) = 0;
    v8 -= 4;
    v7 = (vorbis_dsp_state_0 *)((char *)v7 + 4);
  }
  v9 = v8 >> 3;
  memset(v7, 0, 8 * v9);
  v10 = &v7->vi + v9;
  if ( (v8 & 4) == 0 )
  {
    if ( (v8 & 2) == 0 )
      goto LABEL_10;
LABEL_36:
    v10 = (vorbis_info **)((char *)v10 + 2);
    *((_WORD *)v10 - 1) = 0;
    if ( (v8 & 1) == 0 )
      goto LABEL_11;
    goto LABEL_35;
  }
  *(_DWORD *)v10 = 0;
  v10 = (vorbis_info **)((char *)v10 + 4);
  if ( (v8 & 2) != 0 )
    goto LABEL_36;
LABEL_10:
  if ( (v8 & 1) != 0 )
LABEL_35:
    *(_BYTE *)v10 = 0;
LABEL_11:
  v11 = FMOD_OggVorbis_Calloc(context, 1, 56);
  v->backend_state = v11;
  if ( !v11 )
    goto LABEL_32;
  v12 = 0;
  v->vi = (vorbis_info *)vi;
  v13 = codec_setup[2];
  if ( v13 )
  {
    for ( i = v13 - 1; i; i >>= 1 )
      ++v12;
  }
  v11[6] = v12;
  v14 = FMOD_OggVorbis_Calloc(context, 1, 8);
  *((_QWORD *)v11 + 1) = v14;
  if ( !v14 )
    goto LABEL_32;
  v15 = FMOD_OggVorbis_Calloc(context, 1, 8);
  *((_QWORD *)v11 + 2) = v15;
  if ( !v15 )
    goto LABEL_32;
  v16 = (void **)*((_QWORD *)v11 + 1);
  *v16 = FMOD_OggVorbis_Calloc(context, 1, 32);
  if ( !**((_QWORD **)v11 + 1) )
    goto LABEL_32;
  v17 = (void **)*((_QWORD *)v11 + 2);
  *v17 = FMOD_OggVorbis_Calloc(context, 1, 32);
  if ( !**((_QWORD **)v11 + 2) )
    goto LABEL_32;
  if ( FMOD_mdct_init(context, **((mdct_lookup ***)v11 + 1), *codec_setup >> v6) )
    goto LABEL_32;
  v43 = FMOD_mdct_init(context, **((mdct_lookup ***)v11 + 2), codec_setup[1] >> v6);
  if ( v43 )
    goto LABEL_32;
  v18 = -6;
  if ( *codec_setup )
  {
    v19 = *codec_setup - 1;
    if ( *codec_setup != 1 )
    {
      v20 = 0;
      do
      {
        ++v20;
        v19 >>= 1;
      }
      while ( v19 );
      v18 = v20 - 6;
    }
  }
  v21 = codec_setup[1];
  *v11 = v18;
  v22 = -6;
  if ( v21 )
  {
    v30 = v21 - 1;
    if ( v21 != 1 )
    {
      v31 = 0;
      do
      {
        ++v31;
        v30 >>= 1;
      }
      while ( v30 );
      v22 = v31 - 6;
    }
  }
  v23 = *((_QWORD *)codec_setup + 612) == 0;
  v11[1] = v22;
  if ( v23 )
  {
    v40 = (codebook_0 *)FMOD_OggVorbis_Calloc(context, codec_setup[6], 72);
    *((_QWORD *)codec_setup + 612) = v40;
    if ( !v40 )
      goto LABEL_32;
    v41 = 0;
    if ( codec_setup[6] > 0 )
    {
      while ( !FMOD_vorbis_book_init_decode(
                 context,
                 &v40[v41],
                 *(const static_codebook_0 **)&codec_setup[2 * v41 + 712]) )
      {
        FMOD_vorbis_staticbook_destroy(context, *(static_codebook_0 **)&codec_setup[2 * v41 + 712]);
        *(_QWORD *)&codec_setup[2 * v41++ + 712] = 0;
        if ( codec_setup[6] <= (int)v41 )
          goto LABEL_64;
        v40 = (codebook_0 *)*((_QWORD *)codec_setup + 612);
      }
      goto LABEL_32;
    }
LABEL_64:
    v21 = codec_setup[1];
  }
  v->pcm_storage = v21;
  v24 = (float **)FMOD_OggVorbis_Malloc(context, 8 * vi->channels);
  v->pcm = v24;
  if ( !v24 )
    goto LABEL_32;
  v25 = (float **)FMOD_OggVorbis_Malloc(context, 8 * vi->channels);
  v->pcmret = v25;
  if ( !v25 )
    goto LABEL_32;
  if ( vi->channels > 0 )
  {
    pcm = v->pcm;
    v27 = 0;
    do
    {
      pcm[v27] = (float *)FMOD_OggVorbis_Calloc(context, v->pcm_storage, 4);
      pcm = v->pcm;
      if ( !pcm[v27] )
        goto LABEL_32;
    }
    while ( vi->channels > (int)++v27 );
  }
  v32 = codec_setup[1];
  v33 = codec_setup[4];
  v->lW = 0;
  v->W = 0;
  v32 /= 2;
  v->centerW = v32;
  v->pcm_current = v32;
  v34 = FMOD_OggVorbis_Calloc(context, v33, 8);
  *((_QWORD *)v11 + 4) = v34;
  if ( !v34 || (v35 = FMOD_OggVorbis_Calloc(context, codec_setup[5], 8), (*((_QWORD *)v11 + 5) = v35) == 0) )
  {
LABEL_32:
    v43 = -139;
LABEL_33:
    FMOD_vorbis_dsp_clear(context, v);
    return v43;
  }
  if ( codec_setup[4] > 0 )
  {
    v36 = 0;
    do
    {
      v37 = (_QWORD *)(*((_QWORD *)v11 + 4) + 8 * v36);
      *v37 = ((__int64 (__fastcall *)(void *, vorbis_dsp_state_0 *, _QWORD))FMOD_floor_P[codec_setup[v36 + 328]]->look)(
               context,
               v,
               *(_QWORD *)&codec_setup[2 * v36 + 392]);
      ++v36;
    }
    while ( codec_setup[4] > (int)v36 );
  }
  if ( codec_setup[5] > 0 )
  {
    v38 = 0;
    do
    {
      v39 = (_QWORD *)(*((_QWORD *)v11 + 5) + 8 * v38);
      *v39 = ((__int64 (__fastcall *)(void *, vorbis_dsp_state_0 *, _QWORD))FMOD_residue_P[codec_setup[v38 + 520]]->look)(
               context,
               v,
               *(_QWORD *)&codec_setup[2 * v38 + 584]);
      ++v38;
    }
    while ( (int)v38 < codec_setup[5] );
  }
  FMOD_vorbis_synthesis_restart(v);
  return v43;
}


// Address: 0x226fb40 | Name: FMOD_vorbis_synthesis_blockin
int __fastcall FMOD_vorbis_synthesis_blockin(vorbis_dsp_state_0 *v, vorbis_block_0 *vb)
{
  int pcm_returned; // edx
  int result; // eax
  ogg_int64_t_0 sequence; // rax
  ogg_int32_t W; // r10d
  ogg_int32_t v7; // edi
  ogg_int64_t_0 v8; // rax
  bool v9; // zf
  int v10; // ebp
  int v11; // ebx
  int v12; // r14d
  int v13; // r8d
  int channels; // r9d
  int v15; // ebp
  int v16; // ebx
  int v17; // r14d
  int v18; // r15d
  int v19; // ecx
  ogg_int32_t centerW; // eax
  __int64 v21; // r9
  __int64 v22; // rcx
  __int64 v23; // r9
  __int64 v24; // r13
  int v25; // r15d
  __int64 v26; // r9
  float *v27; // rax
  float *v28; // r10
  float *v29; // r11
  __int64 v30; // rdx
  float *v31; // rcx
  float *v32; // r10
  float *v33; // r11
  __int64 j; // rax
  ogg_int32_t v35; // ecx
  ogg_int32_t v36; // eax
  ogg_int64_t_0 granulepos; // rdx
  ogg_int64_t_0 v38; // rcx
  int v39; // edi
  float *v40; // rax
  float *v41; // rdi
  float *v42; // r8
  __int64 v43; // rdx
  float *v44; // rcx
  float *v45; // r8
  float *v46; // rdi
  unsigned __int64 v47; // rax
  float *v48; // rax
  __int64 v49; // rdx
  float *v50; // rcx
  float *v51; // rax
  __int64 v52; // rdx
  float *v53; // rcx
  ogg_int64_t_0 v54; // rdx
  ogg_int64_t_0 sample_count; // rcx
  int v56; // edx
  int pcm_current; // ecx
  private_state_1 *b; // [rsp+0h] [rbp-B8h]
  int hs; // [rsp+Ch] [rbp-ACh]
  vorbis_info *vi; // [rsp+10h] [rbp-A8h]
  __int64 v61; // [rsp+18h] [rbp-A0h]
  __int64 v62; // [rsp+28h] [rbp-90h]
  __int64 v63; // [rsp+30h] [rbp-88h]
  __int64 v64; // [rsp+38h] [rbp-80h]
  codec_setup_info_0 *ci; // [rsp+48h] [rbp-70h]
  __int64 v66; // [rsp+50h] [rbp-68h]
  __int64 v67; // [rsp+58h] [rbp-60h]
  int i; // [rsp+60h] [rbp-58h]
  __int64 v69; // [rsp+68h] [rbp-50h]
  int prevCenter; // [rsp+78h] [rbp-40h]
  int thisCenter; // [rsp+7Ch] [rbp-3Ch]

  vi = v->vi;
  b = (private_state_1 *)v->backend_state;
  ci = (codec_setup_info_0 *)v->vi->bitrate_lower;
  hs = ci->halfrate_flag;
  if ( !vb )
    return -131;
  pcm_returned = v->pcm_returned;
  if ( v->pcm_current > pcm_returned )
  {
    result = -131;
    if ( pcm_returned != -1 )
      return result;
  }
  sequence = v->sequence;
  W = v->W;
  v7 = vb->W;
  v->nW = -1;
  v->lW = W;
  v->W = v7;
  if ( sequence == -1 )
  {
    v8 = vb->sequence;
    goto LABEL_7;
  }
  v8 = sequence + 1;
  if ( v8 != vb->sequence )
  {
    v8 = vb->sequence;
LABEL_7:
    v->granulepos = -1;
    b->sample_count = -1;
  }
  v9 = vb->pcm == 0;
  v->sequence = v8;
  if ( !v9 )
  {
    v10 = ci->blocksizes[0];
    v11 = ci->blocksizes[v7];
    v12 = ci->blocksizes[1];
    v->glue_bits += vb->glue_bits;
    v13 = 0;
    channels = vi->channels;
    v15 = v10 >> (hs + 1);
    v->time_bits += vb->time_bits;
    v16 = v11 >> (hs + 1);
    v->floor_bits += vb->floor_bits;
    v17 = v12 >> (hs + 1);
    v18 = 0;
    v19 = 0;
    v->res_bits += vb->res_bits;
    centerW = v->centerW;
    if ( centerW )
      v18 = v17;
    else
      v19 = v17;
    prevCenter = v19;
    thisCenter = v18;
    if ( channels > 0 )
    {
      v21 = v19;
      v61 = v18;
      v62 = v19;
      v22 = v17 / 2 - (__int64)(v15 / 2);
      v23 = v22 + v21;
      v67 = v22;
      if ( v15 > 0 )
        v13 = v15;
      i = v13;
      v24 = 0;
      v66 = v23;
      v25 = 0;
      v63 = 4LL * v15 - 4;
      v26 = 4LL * (unsigned int)(v17 / 2 + v15 / 2 - v13 - 1) + 4;
      v69 = v13;
      while ( 1 )
      {
        v64 = v26;
        if ( W )
        {
          if ( v7 )
          {
            v27 = FMOD_vorbis_window_get(b->window[1] - hs);
            v26 = v64;
            v28 = v->pcm[v24];
            v29 = vb->pcm[v24];
            if ( v17 > 0 )
            {
              v30 = 0;
              v31 = &v27[v17 - 1];
              do
              {
                --v31;
                v28[v62 + v30] = (float)(v28[v62 + v30] * v31[1]) + (float)(v29[v30] * v27[v30]);
                ++v30;
              }
              while ( v17 > (int)v30 );
            }
          }
          else
          {
            v51 = FMOD_vorbis_window_get(b->window[0] - hs);
            v26 = v64;
            v28 = v->pcm[v24];
            v29 = vb->pcm[v24];
            if ( v15 > 0 )
            {
              v52 = 0;
              v53 = (float *)((char *)v51 + v63);
              do
              {
                --v53;
                v28[v66 + v52] = (float)(v28[v66 + v52] * v53[1]) + (float)(v29[v52] * v51[v52]);
                ++v52;
              }
              while ( v15 > (int)v52 );
            }
          }
        }
        else
        {
          v9 = v7 == 0;
          v39 = b->window[0];
          if ( v9 )
          {
            v48 = FMOD_vorbis_window_get(v39 - hs);
            v26 = v64;
            v28 = v->pcm[v24];
            v29 = vb->pcm[v24];
            if ( v15 > 0 )
            {
              v49 = 0;
              v50 = (float *)((char *)v48 + v63);
              do
              {
                --v50;
                v28[v62 + v49] = (float)(v28[v62 + v49] * v50[1]) + (float)(v29[v49] * v48[v49]);
                ++v49;
              }
              while ( v15 > (int)v49 );
            }
          }
          else
          {
            v40 = FMOD_vorbis_window_get(v39 - hs);
            v26 = v64;
            v28 = v->pcm[v24];
            v41 = &v28[v62];
            v29 = vb->pcm[v24];
            v42 = &v29[v67];
            if ( v15 > 0 )
            {
              v43 = 0;
              v44 = (float *)((char *)v40 + v63);
              do
              {
                --v44;
                v41[v43] = (float)(v41[v43] * v44[1]) + (float)(v42[v43] * v40[v43]);
                ++v43;
              }
              while ( v15 > (int)v43 );
            }
            if ( i < v17 / 2 + v15 / 2 )
            {
              v45 = &v42[v69];
              v46 = &v41[v69];
              v47 = 0;
              do
              {
                v46[v47 / 4] = v45[v47 / 4];
                v47 += 4LL;
              }
              while ( v47 != v64 );
            }
          }
        }
        v32 = &v28[v61];
        v33 = &v29[v16];
        for ( j = 0; v16 > (int)j; ++j )
          v32[j] = v33[j];
        ++v25;
        ++v24;
        if ( vi->channels <= v25 )
          break;
        W = v->lW;
        v7 = v->W;
      }
      centerW = v->centerW;
      pcm_returned = v->pcm_returned;
    }
    v35 = 0;
    if ( !centerW )
      v35 = v17;
    v->centerW = v35;
    if ( pcm_returned == -1 )
    {
      v->pcm_returned = thisCenter;
      v->pcm_current = thisCenter;
    }
    else
    {
      v36 = ci->blocksizes[v->lW];
      v->pcm_returned = prevCenter;
      v->pcm_current = prevCenter + ((v36 / 4 + ci->blocksizes[v->W] / 4) >> hs);
    }
  }
  if ( b->sample_count == -1 )
    b->sample_count = 0;
  else
    b->sample_count += ci->blocksizes[v->lW] / 4 + ci->blocksizes[v->W] / 4;
  if ( v->granulepos != -1 )
  {
    granulepos = vb->granulepos;
    v38 = ci->blocksizes[v->lW] / 4 + ci->blocksizes[v->W] / 4 + v->granulepos;
    v->granulepos = v38;
    if ( granulepos != -1 && v38 != granulepos )
    {
      result = vb->eofflag;
      if ( v38 > granulepos && (_DWORD)v38 != (_DWORD)granulepos )
      {
        if ( result )
          v->pcm_current -= ((int)v38 - (int)granulepos) >> hs;
      }
      v->granulepos = granulepos;
LABEL_35:
      if ( !result )
        return result;
      goto LABEL_36;
    }
LABEL_34:
    result = vb->eofflag;
    goto LABEL_35;
  }
  v54 = vb->granulepos;
  if ( v54 == -1 )
    goto LABEL_34;
  v->granulepos = v54;
  sample_count = b->sample_count;
  if ( v54 >= sample_count )
    goto LABEL_34;
  result = vb->eofflag;
  if ( result )
  {
    v->pcm_current -= (sample_count - v54) >> hs;
LABEL_36:
    v->eofflag = 1;
    return 0;
  }
  v56 = v->pcm_returned + ((sample_count - v54) >> hs);
  pcm_current = v->pcm_current;
  v->pcm_returned = v56;
  if ( v56 > pcm_current )
    v->pcm_returned = pcm_current;
  return result;
}


// Address: 0x22701b0 | Name: FMOD_vorbis_synthesis_pcmout
int __fastcall FMOD_vorbis_synthesis_pcmout(vorbis_dsp_state_0 *v, float ***pcm)
{
  int pcm_returned; // r10d
  int pcm_current; // r11d
  int result; // eax
  int channels; // eax
  __int64 v6; // r8
  unsigned __int64 v7; // rax

  pcm_returned = v->pcm_returned;
  if ( pcm_returned < 0 )
    return 0;
  pcm_current = v->pcm_current;
  result = 0;
  if ( pcm_returned < pcm_current )
  {
    if ( pcm )
    {
      channels = v->vi->channels;
      if ( channels > 0 )
      {
        v6 = 8LL * (unsigned int)(channels - 1) + 8;
        v7 = 0;
        do
        {
          v->pcmret[v7 / 8] = &v->pcm[v7 / 8][pcm_returned];
          v7 += 8LL;
        }
        while ( v7 != v6 );
        *pcm = v->pcmret;
        return pcm_current - pcm_returned;
      }
      *pcm = v->pcmret;
    }
    return pcm_current - pcm_returned;
  }
  return result;
}


// Address: 0x2270240 | Name: FMOD_vorbis_synthesis_read
int __fastcall FMOD_vorbis_synthesis_read(vorbis_dsp_state_0 *v, int n)
{
  int pcm_returned; // esi

  if ( !n )
  {
    pcm_returned = v->pcm_returned;
LABEL_3:
    v->pcm_returned = pcm_returned;
    return 0;
  }
  pcm_returned = v->pcm_returned + n;
  if ( pcm_returned <= v->pcm_current )
    goto LABEL_3;
  return -131;
}


// Address: 0x2270260 | Name: FMOD_vorbis_synthesis_lapout
int __fastcall FMOD_vorbis_synthesis_lapout(vorbis_dsp_state_0 *v, float ***pcm)
{
  vorbis_info *vi; // r10
  int *bitrate_lower; // rax
  ogg_int32_t W; // r12d
  int pcm_returned; // r11d
  int v6; // ecx
  int v7; // ebx
  int v8; // ebp
  int v9; // eax
  ogg_int32_t centerW; // ebx
  ogg_int32_t lW; // edx
  int v12; // r13d
  float **v13; // r15
  __int64 v14; // rbx
  __int64 v15; // r9
  __int64 v16; // r12
  __int64 v17; // r9
  float *v18; // r8
  unsigned __int64 v19; // rdx
  float *v20; // rcx
  float *v21; // r8
  float *v22; // rcx
  int v23; // edx
  __int64 v24; // r9
  unsigned __int64 v25; // rdx
  int v27; // r12d
  float **v28; // r14
  int v29; // r15d
  __int64 v30; // rbx
  __int64 v31; // r9
  __int64 v32; // rbp
  __int64 v33; // r9
  float *v34; // r8
  unsigned __int64 v35; // rdx
  float *v36; // rcx
  float *v37; // r8
  float *v38; // rcx
  int channels; // r13d
  float **v40; // r15
  __int64 v41; // r9
  float *v42; // rdx
  float *v43; // r8
  float v44; // xmm0_4
  int v45; // [rsp+0h] [rbp-38h]
  int v46; // [rsp+4h] [rbp-34h]

  vi = v->vi;
  bitrate_lower = (int *)v->vi->bitrate_lower;
  W = v->W;
  pcm_returned = v->pcm_returned;
  v6 = bitrate_lower[1226] + 1;
  v7 = bitrate_lower[W];
  v8 = *bitrate_lower >> (*((_BYTE *)bitrate_lower + 4904) + 1);
  v9 = bitrate_lower[1] >> (*((_BYTE *)bitrate_lower + 4904) + 1);
  v45 = v7 >> v6;
  if ( pcm_returned < 0 )
    return 0;
  centerW = v->centerW;
  if ( centerW == v9 )
  {
    channels = vi->channels;
    if ( channels > 0 )
    {
      v40 = v->pcm;
      v41 = 0;
      do
      {
        v42 = v40[v41];
        v43 = &v42[centerW - 1 + 1];
        if ( centerW > 0 )
        {
          do
          {
            v44 = *v42;
            *v42 = v42[centerW];
            v42[centerW] = v44;
            ++v42;
          }
          while ( v42 != v43 );
        }
        ++v41;
      }
      while ( channels > (int)v41 );
    }
    pcm_returned -= centerW;
    v->pcm_current -= centerW;
    v->centerW = 0;
    v->pcm_returned = pcm_returned;
  }
  lW = v->lW;
  if ( (lW ^ W) == 1 )
  {
    v27 = vi->channels;
    if ( v27 <= 0 )
    {
      v46 = (v9 - v8) / 2;
    }
    else
    {
      v28 = v->pcm;
      v29 = (v9 + v8) / 2;
      v46 = (v9 - v8) / 2;
      v30 = 0;
      v31 = (unsigned int)(v29 - 1);
      v32 = (int)v31;
      v33 = 4 * ~v31;
      do
      {
        v34 = v28[v30];
        v35 = 0;
        v36 = &v34[v46];
        v37 = &v34[v32];
        v38 = &v36[v32];
        if ( v29 > 0 )
        {
          do
          {
            v38[v35 / 4] = v37[v35 / 4];
            v35 -= 4LL;
          }
          while ( v35 != v33 );
        }
        ++v30;
      }
      while ( v27 > (int)v30 );
    }
    v->pcm_current += v46;
    pcm_returned += v46;
    v->pcm_returned = pcm_returned;
  }
  else if ( !lW )
  {
    v12 = vi->channels;
    if ( v12 > 0 )
    {
      v13 = v->pcm;
      v14 = 0;
      v15 = (unsigned int)(v8 - 1);
      v16 = (int)v15;
      v17 = 4 * ~v15;
      do
      {
        v18 = v13[v14];
        v19 = 0;
        v20 = &v18[v9 - (__int64)v8];
        v21 = &v18[v16];
        v22 = &v20[v16];
        if ( v8 > 0 )
        {
          do
          {
            v22[v19 / 4] = v21[v19 / 4];
            v19 -= 4LL;
          }
          while ( v19 != v17 );
        }
        ++v14;
      }
      while ( v12 > (int)v14 );
    }
    v->pcm_current += v9 - v8;
    pcm_returned += v9 - v8;
    v->pcm_returned = pcm_returned;
  }
  if ( pcm )
  {
    v23 = vi->channels;
    if ( v23 > 0 )
    {
      v24 = 8LL * (unsigned int)(v23 - 1) + 8;
      v25 = 0;
      do
      {
        v->pcmret[v25 / 8] = &v->pcm[v25 / 8][pcm_returned];
        v25 += 8LL;
      }
      while ( v25 != v24 );
    }
    *pcm = v->pcmret;
  }
  return v45 + v9 - pcm_returned;
}


// Address: 0x22704d0 | Name: FMOD_vorbis_window
float *__fastcall FMOD_vorbis_window(vorbis_dsp_state_0 *v, int W)
{
  int v2; // edx
  int v3; // edi

  v2 = *(_DWORD *)(v->vi->bitrate_lower + 4904);
  v3 = *((_DWORD *)v->backend_state + W);
  if ( v3 <= 0 )
    return 0;
  else
    return FMOD_vorbis_window_get(v3 - v2);
}


