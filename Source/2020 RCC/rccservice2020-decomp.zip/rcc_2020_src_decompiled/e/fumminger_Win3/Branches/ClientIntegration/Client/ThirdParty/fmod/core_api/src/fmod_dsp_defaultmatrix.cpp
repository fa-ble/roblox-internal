// Address: 0x21c21c0 | Name: _ZN4FMOD25FMOD_DefaultMatrix_UnpackEPfii
void __fastcall FMOD::FMOD_DefaultMatrix_Unpack(float *mixmatrix, int outchannels, int inchannels)
{
  FMOD::FMOD_DEFAULTMATRIX_ENTRY *v3; // rax
  char val_index; // dl

  v3 = &stru_286A060[byte_286A020[8 * outchannels - 9 + inchannels]];
  do
  {
    val_index = v3->val_index;
    ++v3;
    mixmatrix[v3[-1].offset] = flt_286A140[val_index & 0x7F];
  }
  while ( val_index >= 0 );
}


