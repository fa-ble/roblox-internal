// Address: 0x222e160 | Name: _ZN4FMOD9CodecMPEG7getBitsEi
unsigned int __fastcall FMOD::CodecMPEG::getBits(FMOD::CodecMPEG *const this, int number_of_bits)
{
  unsigned int result; // eax
  FMOD::CodecMPEG_Context *mContext; // rdx
  unsigned __int8 *mWordPointer; // rdi
  int mBitIndex; // ecx

  result = 0;
  if ( number_of_bits )
  {
    mContext = this->mContext;
    mWordPointer = mContext->mBSI.mWordPointer;
    mBitIndex = mContext->mBSI.mBitIndex;
    result = (((mWordPointer[2] | ((mWordPointer[1] | (*mWordPointer << 8)) << 8)) << mBitIndex) & 0xFFFFFFu) >> (24 - number_of_bits);
    mContext->mBSI.mBitIndex = (number_of_bits + mBitIndex) & 7;
    mContext->mBSI.mWordPointer = &mWordPointer[(number_of_bits + mBitIndex) >> 3];
  }
  return result;
}


// Address: 0x222e1d0 | Name: _ZN4FMOD9CodecMPEG11getBitsFastEi
unsigned int __fastcall FMOD::CodecMPEG::getBitsFast(FMOD::CodecMPEG *const this, int number_of_bits)
{
  FMOD::CodecMPEG_Context *mContext; // rdx
  unsigned __int8 *mWordPointer; // rdi
  int mBitIndex; // ecx
  int v5; // eax

  mContext = this->mContext;
  mWordPointer = mContext->mBSI.mWordPointer;
  mBitIndex = mContext->mBSI.mBitIndex;
  v5 = (mWordPointer[1] | (*mWordPointer << 8)) << mBitIndex;
  mContext->mBSI.mBitIndex = (number_of_bits + mBitIndex) & 7;
  mContext->mBSI.mWordPointer = &mWordPointer[(number_of_bits + mBitIndex) >> 3];
  return (unsigned __int16)v5 >> (16 - number_of_bits);
}


// Address: 0x222e220 | Name: _ZN4FMOD9CodecMPEG12decodeHeaderEPvPiS2_S2_
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::decodeHeader(
        FMOD::CodecMPEG *const this,
        void *in,
        int *samplerate,
        int *channels,
        int *framesize)
{
  unsigned int v5; // eax
  FMOD::CodecMPEG_Context *mContext; // rsi
  FMOD_RESULT_0 result; // eax
  int v8; // r9d
  int v9; // r10d
  int mLayer; // r9d
  int v11; // r9d
  int v12; // r9d
  int v13; // r9d
  int v14; // r10d
  int v15; // edx
  int v16; // eax
  FMOD::FMOD_CODEC_FLAG mFlags; // r11d
  FMOD_CODEC_WAVEFORMAT *waveformat; // rdx
  int v19; // edx
  int v20; // eax
  int v21; // edx
  FMOD_CODEC_WAVEFORMAT *v22; // rcx
  int mFrameSizeOld; // eax
  int v24; // r9d

  v5 = *((unsigned __int8 *)in + 3)
     | ((*((unsigned __int8 *)in + 2) | ((*((unsigned __int8 *)in + 1) | (*(unsigned __int8 *)in << 8)) << 8)) << 8);
  mContext = this->mContext;
  mContext->mFrameHeader = v5;
  if ( (v5 & 0xFFE00000) != 0xFFE00000 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  if ( (v5 & 0x100000) != 0 )
  {
    mContext->mFrame.mpeg25 = 0;
    mContext->mFrame.lsf = ((unsigned __int8)(v5 >> 19) ^ 1) & 1;
  }
  else
  {
    if ( (v5 & 0x80000) != 0 )
      return FMOD_RESULT::FMOD_ERR_FORMAT_0;
    mContext->mFrame.lsf = 1;
    mContext->mFrame.mpeg25 = 1;
  }
  v8 = (v5 >> 17) & 3;
  v9 = 4 - v8;
  mContext->mFrame.lay = 4 - v8;
  if ( v8 != 2 && v8 != 1 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  mLayer = mContext->mLayer;
  if ( mLayer )
  {
    if ( v9 == mLayer )
      goto LABEL_8;
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
  mContext->mLayer = v9;
LABEL_8:
  v11 = (v5 >> 10) & 3;
  if ( v11 == 3 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  if ( mContext->mFrame.mpeg25 )
    v12 = v11 + 6;
  else
    v12 = 3 * mContext->mFrame.lsf + v11;
  mContext->mFrame.sampling_frequency = v12;
  if ( samplerate )
    *samplerate = FMOD::CodecMPEG::gFreqs[mContext->mFrame.sampling_frequency];
  mContext->mFrame.copyright = (v5 >> 3) & 1;
  mContext->mFrame.error_protection = (BYTE2(v5) ^ 1) & 1;
  v13 = (unsigned __int16)v5 >> 12;
  v14 = (v5 >> 4) & 3;
  mContext->mFrame.padding = (v5 >> 9) & 1;
  mContext->mFrame.bitrate_index = v13;
  mContext->mFrame.mode_ext = v14;
  mContext->mFrame.original = (v5 >> 2) & 1;
  mContext->mFrame.extension = (v5 >> 8) & 1;
  mContext->mFrame.emphasis = v5 & 3;
  v15 = (unsigned __int8)v5 >> 6;
  mContext->mFrame.mode = v15;
  v16 = (v15 != 3) + 1;
  mContext->mFrame.stereo = v16;
  if ( v13 == 15 || !v13 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  mFlags = this->mFlags;
  if ( mContext->mFrame.lay != 2 )
    goto LABEL_16;
  if ( (mFlags & 2) != 0 )
    goto LABEL_44;
  v24 = FMOD::CodecMPEG::gTabSel123[mContext->mFrame.lsf][1][v13];
  if ( v15 != 3 )
  {
    if ( (v24 & 0xFFFFFFEF) == 0x20 || v24 == 56 || v24 == 80 )
      return FMOD_RESULT::FMOD_ERR_FORMAT_0;
LABEL_44:
    if ( v15 == 1 )
      goto LABEL_16;
    goto LABEL_45;
  }
  if ( v24 > 223 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
LABEL_45:
  if ( v14 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
LABEL_16:
  if ( (mFlags & 2) == 0 )
  {
    waveformat = this->waveformat;
    if ( waveformat )
    {
      v19 = waveformat->channels;
      if ( v19 )
      {
        if ( v16 != v19 )
          return FMOD_RESULT::FMOD_ERR_FORMAT_0;
      }
    }
  }
  if ( channels )
  {
    *channels = v16;
    goto LABEL_29;
  }
  if ( v16 != this->waveformat->channels && !this->mChannels )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
LABEL_29:
  result = FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  if ( mContext->mFrame.lay == 3 )
  {
    v20 = mContext->mFrame.padding
        + 144000
        * FMOD::CodecMPEG::gTabSel123[mContext->mFrame.lsf][2][mContext->mFrame.bitrate_index]
        / (FMOD::CodecMPEG::gFreqs[mContext->mFrame.sampling_frequency] << mContext->mFrame.lsf);
    v21 = v20 - 4;
    mContext->mFrame.framesize = v20 - 4;
    if ( (unsigned int)(v20 - 20) <= 0x6F0 )
    {
      mContext->mFrameSize = v21;
      if ( framesize )
      {
        *framesize = v21;
        if ( (this->mFlags & 2) != 0 )
        {
          v22 = this->waveformat;
          if ( v22 && v22->channels > 2 )
          {
            mFrameSizeOld = mContext->mFrameSizeOld;
            if ( mContext->mFrame.framesize >= mFrameSizeOld )
              mFrameSizeOld = v21;
            *framesize = ((mFrameSizeOld + 19) & 0xFFFFFFF0) - 4;
          }
          else if ( mContext->mFrame.lay == 3 )
          {
            *framesize = ((v20 + 3) & 0xFFFFFFFC) - 4;
            return FMOD_RESULT::FMOD_OK_0;
          }
        }
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
  }
  return result;
}


// Address: 0x222e5d0 | Name: _ZN4FMOD9CodecMPEG16decodeXingHeaderEPhS1_Pj
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::decodeXingHeader(
        FMOD::CodecMPEG *const this,
        unsigned __int8 *in,
        unsigned __int8 *toc,
        unsigned int *numframes)
{
  int v6; // eax
  unsigned __int8 *v7; // r12
  int v8; // eax
  FMOD_RESULT_0 v9; // ecx
  unsigned __int8 *v11; // r8
  unsigned __int8 v12; // dl
  __int64 i; // rax

  v6 = in[3] >> 6;
  if ( (in[1] & 8) == 0 )
  {
    if ( v6 == 3 )
    {
      v7 = in + 13;
      goto LABEL_3;
    }
    goto LABEL_6;
  }
  v7 = in + 36;
  if ( v6 == 3 )
LABEL_6:
    v7 = in + 21;
LABEL_3:
  v8 = FMOD_strncmp((const char *)v7, "Xing", 4);
  v9 = FMOD_RESULT::FMOD_ERR_FORMAT_0;
  if ( v8 )
    return v9;
  v11 = v7 + 8;
  v12 = v7[7];
  if ( (v12 & 1) != 0 )
  {
    v11 = v7 + 12;
    if ( numframes )
    {
      *numframes = v7[11] | ((v7[10] | ((v7[9] | (v7[8] << 8)) << 8)) << 8);
      this->mHasXingNumFrames = 1;
    }
  }
  if ( (v12 & 2) != 0 )
    v11 += 4;
  v9 = FMOD_RESULT::FMOD_OK_0;
  if ( (v12 & 4) == 0 || !toc )
    return v9;
  for ( i = 0; i != 100; ++i )
    toc[i] = v11[i];
  this->mHasXingToc = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222e710 | Name: _ZN4FMOD9CodecMPEG11decodeFrameEPhPvPj
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::decodeFrame(
        FMOD::CodecMPEG *const this,
        unsigned __int8 *in,
        void *out,
        unsigned int *samples_out)
{
  FMOD::CodecMPEG_Context *mContext; // rax
  size_t mFrameSize; // rdx
  FMOD_RESULT_0 result; // eax
  int mBSNum; // r8d
  unsigned __int8 *v11; // rdi
  FMOD::CodecMPEG_Context *v12; // r8
  int v13; // edx

  mContext = this->mContext;
  mFrameSize = mContext->mFrameSize;
  if ( !(_DWORD)mFrameSize )
  {
    result = FMOD::CodecMPEG::decodeHeader(this, in, 0, 0, 0);
    if ( result )
      return result;
    mContext = this->mContext;
    mFrameSize = mContext->mFrameSize;
  }
  mBSNum = mContext->mBSNum;
  mContext->mBSI.mBitIndex = 0;
  mContext->mBSNum = ((_BYTE)mBSNum + 1) & 1;
  v11 = &mContext->mBSSpace[mBSNum][512];
  mContext->mBSI.mWordPointer = v11;
  memcpy_0(v11, in + 4, mFrameSize);
  v12 = this->mContext;
  if ( v12->mFrame.error_protection )
  {
    FMOD::CodecMPEG::getBits(this, 16);
    v12 = this->mContext;
  }
  result = FMOD_RESULT::FMOD_OK_0;
  if ( v12->mFrame.lay == 3 )
  {
    result = FMOD::CodecMPEG::decodeLayer3(this, out, samples_out);
    v12 = this->mContext;
  }
  v13 = v12->mFrameSize;
  v12->mFrameSize = 0;
  v12->mFrameSizeOld = v13;
  return result;
}


// Address: 0x222e820 | Name: _ZN4FMOD9CodecMPEG10resetFrameEv
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::resetFrame(FMOD::CodecMPEG *const this)
{
  FMOD::CodecMPEG_Context *mContext; // rcx
  int v2; // eax
  unsigned __int64 v3; // rbx
  __int64 v4; // r12
  FMOD::CodecMPEG_Context *v5; // rax

  mContext = this->mContext;
  if ( mContext )
  {
    v2 = (this->mChannels + 1) / 2;
    if ( v2 > 0 )
    {
      v3 = 0;
      v4 = 18640 * ((unsigned int)(v2 - 1) + 1LL);
      do
      {
        memset(&mContext[v3 / 0x48D0], 0, sizeof(FMOD::CodecMPEG_Context));
        mContext = this->mContext;
        v5 = &mContext[v3 / 0x48D0];
        v3 += 18640LL;
        v5->mFrameSizeOld = -1;
        v5->mSynthBo = 1;
        v5->mSynthBuffs = (float *)(((unsigned __int64)&v5->mSynthBuffsMem[3] + 3) & 0xFFFFFFFFFFFFFFF0LL);
      }
      while ( v3 != v4 );
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222e8c0 | Name: _ZN4FMOD9CodecMPEG5dct64EPfS1_S1_
void __fastcall FMOD::CodecMPEG::dct64(float *out0, float *out1, float *samples)
{
  float v3; // xmm0_4
  float v4; // xmm4_4
  float v5; // xmm12_4
  float v6; // xmm0_4
  float v7; // xmm10_4
  float v8; // xmm3_4
  float v9; // xmm2_4
  float v10; // xmm0_4
  float v11; // xmm8_4
  float v12; // xmm1_4
  float v13; // xmm6_4
  float v14; // xmm4_4
  float v15; // xmm0_4
  float v16; // xmm2_4
  float v17; // xmm6_4
  float v18; // xmm3_4
  float v19; // xmm1_4
  float v20; // xmm0_4
  float v21; // xmm6_4
  float v22; // xmm5_4
  float v23; // xmm6_4
  float v24; // xmm3_4
  float v25; // xmm9_4
  float v26; // xmm14_4
  float v27; // xmm7_4
  float v28; // xmm9_4
  float v29; // xmm3_4
  float v30; // xmm15_4
  float v31; // xmm14_4
  float v32; // xmm3_4
  float v33; // xmm13_4
  float v34; // xmm11_4
  float v35; // xmm3_4
  float v36; // xmm15_4
  float v37; // xmm6_4
  float v38; // xmm13_4
  float v39; // xmm3_4
  float v40; // xmm3_4
  float v41; // xmm14_4
  float v42; // xmm3_4
  float v43; // xmm5_4
  float v44; // xmm11_4
  float v45; // xmm3_4
  float v46; // xmm9_4
  float v47; // xmm7_4
  float v48; // xmm3_4
  float v49; // xmm6_4
  float v50; // xmm13_4
  float v51; // xmm9_4
  float v52; // xmm13_4
  float v53; // xmm3_4
  float v54; // xmm11_4
  float v55; // xmm7_4
  float v56; // xmm13_4
  float v57; // xmm9_4
  float v58; // xmm14_4
  float v59; // xmm11_4
  float v60; // xmm3_4
  float *v61; // rax
  float v62; // xmm11_4
  float v63; // xmm14_4
  float v64; // xmm12_4
  float v65; // xmm11_4
  float v66; // xmm12_4
  float v67; // xmm13_4
  float v68; // xmm14_4
  float v69; // xmm9_4
  float v70; // xmm8_4
  float v71; // xmm10_4
  float v72; // xmm7_4
  float v73; // xmm7_4
  float v74; // xmm5_4
  float v75; // xmm6_4
  float v76; // xmm5_4
  float v77; // xmm4_4
  float v78; // xmm3_4
  float v79; // xmm6_4
  float *v80; // rax
  float v81; // xmm4_4
  float v82; // xmm2_4
  float v83; // xmm1_4
  float v84; // xmm3_4
  float v85; // xmm2_4
  float v86; // xmm1_4
  float v87; // xmm12_4
  float v88; // xmm11_4
  float v89; // xmm10_4
  float v90; // xmm3_4
  float v91; // xmm15_4
  float v92; // xmm0_4
  float v93; // xmm9_4
  float v94; // xmm6_4
  float v95; // xmm7_4
  float v96; // xmm13_4
  float v97; // xmm14_4
  float v98; // xmm8_4
  float v99; // xmm5_4
  float v100; // xmm8_4
  float v101; // xmm10_4
  float v102; // xmm11_4
  float v103; // xmm10_4
  float *v104; // rax
  float v105; // xmm12_4
  float v106; // xmm2_4
  float v107; // xmm0_4
  float v108; // xmm9_4
  float v109; // xmm13_4
  float v110; // xmm15_4
  float v111; // xmm1_4
  float v112; // xmm14_4
  float v113; // xmm3_4
  float v114; // xmm6_4
  float v115; // xmm7_4
  float v116; // xmm11_4
  float v117; // xmm11_4
  float v118; // xmm5_4
  float v119; // xmm10_4
  float v120; // xmm8_4
  float v121; // xmm12_4
  float v122; // xmm12_4
  float v123; // xmm1_4
  float v124; // xmm2_4
  float v125; // xmm0_4
  float v126; // xmm4_4
  float v127; // xmm9_4
  float v128; // xmm4_4
  float v129; // xmm9_4
  float v130; // xmm13_4
  float v131; // xmm6_4
  float v132; // xmm15_4
  float v133; // xmm7_4
  float v134; // xmm15_4
  float v135; // xmm3_4
  float v136; // xmm11_4
  float v137; // xmm6_4
  float v138; // xmm10_4
  float v139; // xmm3_4
  float v140; // xmm14_4
  float v141; // xmm5_4
  float v142; // xmm15_4
  float v143; // xmm10_4
  float v144; // xmm7_4
  float v145; // xmm4_4
  float v146; // xmm15_4
  float v147; // xmm12_4
  float v148; // xmm15_4
  float v149; // xmm8_4
  float v150; // xmm12_4
  float v151; // xmm0_4
  float v152; // xmm1_4
  float v153; // xmm0_4
  float v154; // xmm8_4
  float v155; // xmm2_4
  float v156; // xmm1_4
  float v157; // xmm12_4
  float v158; // xmm0_4
  float v159; // xmm7_4
  float v160; // xmm8_4
  float v161; // xmm15_4
  float b1_7_0; // [rsp+0h] [rbp-6Ch]
  float b1_7_0a; // [rsp+0h] [rbp-6Ch]
  float b1_7_0b; // [rsp+0h] [rbp-6Ch]
  float b1_7_0c; // [rsp+0h] [rbp-6Ch]
  float v166; // [rsp+4h] [rbp-68h]
  float v167; // [rsp+4h] [rbp-68h]
  float v168; // [rsp+4h] [rbp-68h]
  float v169; // [rsp+4h] [rbp-68h]
  float v170; // [rsp+4h] [rbp-68h]
  float v171; // [rsp+8h] [rbp-64h]
  float v172; // [rsp+8h] [rbp-64h]
  float v173; // [rsp+8h] [rbp-64h]
  float v174; // [rsp+Ch] [rbp-60h]
  float v175; // [rsp+Ch] [rbp-60h]
  float b2_1; // [rsp+10h] [rbp-5Ch]
  float b2_1a; // [rsp+10h] [rbp-5Ch]
  float b2_1b; // [rsp+10h] [rbp-5Ch]
  float v179; // [rsp+14h] [rbp-58h]
  float v180; // [rsp+14h] [rbp-58h]
  float v181; // [rsp+14h] [rbp-58h]
  float v182; // [rsp+18h] [rbp-54h]
  float v183; // [rsp+18h] [rbp-54h]
  float v184; // [rsp+18h] [rbp-54h]
  float v185; // [rsp+1Ch] [rbp-50h]
  float v186; // [rsp+1Ch] [rbp-50h]
  float v187; // [rsp+1Ch] [rbp-50h]
  float v188; // [rsp+1Ch] [rbp-50h]
  float v189; // [rsp+1Ch] [rbp-50h]
  float b2_4; // [rsp+20h] [rbp-4Ch]
  float b2_4a; // [rsp+20h] [rbp-4Ch]
  float b2_4b; // [rsp+20h] [rbp-4Ch]
  float b2_4c; // [rsp+20h] [rbp-4Ch]
  float b2_5; // [rsp+24h] [rbp-48h]
  float b2_5a; // [rsp+24h] [rbp-48h]
  float b2_5b; // [rsp+24h] [rbp-48h]
  float b2_5c; // [rsp+24h] [rbp-48h]
  float b1_5; // [rsp+28h] [rbp-44h]
  float b1_5a; // [rsp+28h] [rbp-44h]
  float b1_5b; // [rsp+28h] [rbp-44h]
  float b1_6; // [rsp+2Ch] [rbp-40h]
  float b1_6a; // [rsp+2Ch] [rbp-40h]
  float b1_6b; // [rsp+2Ch] [rbp-40h]
  float b1_6c; // [rsp+2Ch] [rbp-40h]
  float v205; // [rsp+30h] [rbp-3Ch]
  float v206; // [rsp+30h] [rbp-3Ch]
  float v207; // [rsp+30h] [rbp-3Ch]
  float v208; // [rsp+34h] [rbp-38h]
  float v209; // [rsp+34h] [rbp-38h]
  float v210; // [rsp+34h] [rbp-38h]
  float v211; // [rsp+38h] [rbp-34h]
  float v212; // [rsp+38h] [rbp-34h]
  float v213; // [rsp+38h] [rbp-34h]
  float b1_7; // [rsp+3Ch] [rbp-30h]
  float b1_7a; // [rsp+3Ch] [rbp-30h]
  float b1_7b; // [rsp+3Ch] [rbp-30h]
  float b1_7c; // [rsp+3Ch] [rbp-30h]
  float v218; // [rsp+40h] [rbp-2Ch]
  float v219; // [rsp+40h] [rbp-2Ch]
  float v220; // [rsp+40h] [rbp-2Ch]
  float v221; // [rsp+44h] [rbp-28h]
  float v222; // [rsp+44h] [rbp-28h]
  float v223; // [rsp+44h] [rbp-28h]
  float b2_6; // [rsp+48h] [rbp-24h]
  float b2_6a; // [rsp+48h] [rbp-24h]
  float b2_6b; // [rsp+48h] [rbp-24h]
  float b2_6c; // [rsp+48h] [rbp-24h]
  float v228; // [rsp+4Ch] [rbp-20h]
  float v229; // [rsp+4Ch] [rbp-20h]
  float v230; // [rsp+4Ch] [rbp-20h]
  float v231; // [rsp+50h] [rbp-1Ch]
  float v232; // [rsp+50h] [rbp-1Ch]
  float v233; // [rsp+50h] [rbp-1Ch]
  float v234; // [rsp+50h] [rbp-1Ch]
  float v235; // [rsp+54h] [rbp-18h]
  float v236; // [rsp+54h] [rbp-18h]
  float v237; // [rsp+54h] [rbp-18h]
  float v238; // [rsp+54h] [rbp-18h]
  float v239; // [rsp+58h] [rbp-14h]
  float v240; // [rsp+58h] [rbp-14h]
  float v241; // [rsp+58h] [rbp-14h]
  float v242; // [rsp+58h] [rbp-14h]
  float v243; // [rsp+5Ch] [rbp-10h]
  float v244; // [rsp+5Ch] [rbp-10h]
  float v245; // [rsp+5Ch] [rbp-10h]
  float v246; // [rsp+5Ch] [rbp-10h]
  float v247; // [rsp+60h] [rbp-Ch]
  float v248; // [rsp+60h] [rbp-Ch]
  float v249; // [rsp+60h] [rbp-Ch]
  float v250; // [rsp+60h] [rbp-Ch]
  float v251; // [rsp+64h] [rbp-8h]
  float v252; // [rsp+64h] [rbp-8h]
  float v253; // [rsp+64h] [rbp-8h]
  float v254; // [rsp+68h] [rbp-4h]

  v3 = samples[31];
  v4 = *samples - v3;
  v5 = *samples + v3;
  v6 = samples[30];
  v7 = samples[1] + v6;
  v8 = samples[28];
  v9 = samples[1] - v6;
  v10 = samples[29];
  v11 = samples[2] + v10;
  v12 = samples[2] - v10;
  v13 = samples[3];
  v14 = v4 * *FMOD::CodecMPEG::gPnts[0];
  v15 = v13 - v8;
  v16 = v9 * FMOD::CodecMPEG::gPnts[0][1];
  v17 = v13 + v8;
  v18 = samples[27];
  v19 = v12 * FMOD::CodecMPEG::gPnts[0][2];
  v20 = v15 * FMOD::CodecMPEG::gPnts[0][3];
  b2_4 = v17;
  v21 = samples[4];
  v22 = v21 - v18;
  v23 = v21 + v18;
  v24 = samples[26];
  b2_5 = v23;
  v205 = v22 * FMOD::CodecMPEG::gPnts[0][4];
  v25 = samples[5];
  v26 = samples[6];
  v27 = v25 + v24;
  v28 = v25 - v24;
  v29 = samples[25];
  v30 = v26 - v29;
  v31 = v26 + v29;
  v32 = samples[24];
  v33 = samples[7] - v32;
  v34 = samples[7] + v32;
  b1_5 = v27;
  v35 = samples[23];
  b1_6 = v31;
  b1_7 = v34;
  v208 = v28 * FMOD::CodecMPEG::gPnts[0][5];
  v211 = v30 * FMOD::CodecMPEG::gPnts[0][6];
  v36 = FMOD::CodecMPEG::gPnts[0][7] * v33;
  b1_7_0 = samples[8] + v35;
  v37 = samples[11];
  v38 = samples[8] - v35;
  v39 = samples[22];
  v166 = samples[9] + v39;
  v218 = v38 * FMOD::CodecMPEG::gPnts[0][8];
  v221 = FMOD::CodecMPEG::gPnts[0][9] * (float)(samples[9] - v39);
  v40 = samples[21];
  b2_6 = samples[10] + v40;
  v41 = samples[10] - v40;
  v42 = samples[20];
  v43 = v37 + v42;
  v44 = v37 - v42;
  v45 = samples[19];
  v46 = samples[12] + v45;
  v47 = samples[12] - v45;
  v48 = samples[18];
  v49 = v46;
  v50 = samples[13];
  v51 = v50 - v48;
  v52 = v50 + v48;
  v53 = samples[17];
  v228 = v41 * FMOD::CodecMPEG::gPnts[0][10];
  v231 = v44 * FMOD::CodecMPEG::gPnts[0][11];
  v54 = samples[14];
  v235 = v47 * FMOD::CodecMPEG::gPnts[0][12];
  v55 = v52;
  v56 = samples[16];
  v239 = v51 * FMOD::CodecMPEG::gPnts[0][13];
  v57 = v54 + v53;
  v58 = samples[15];
  v59 = (float)(v54 - v53) * FMOD::CodecMPEG::gPnts[0][14];
  v60 = (float)(v58 - v56) * FMOD::CodecMPEG::gPnts[0][15];
  v61 = FMOD::CodecMPEG::gPnts[1];
  v243 = v59;
  v62 = v58 + v56;
  v63 = v5;
  v64 = (float)(v5 - v62) * *v61;
  v247 = v63 + v62;
  v65 = v61[4];
  v174 = v64;
  b2_1 = v7 + v57;
  v179 = v61[1];
  v66 = v61[3];
  v67 = v11 + v55;
  v68 = (float)(v11 - v55) * v61[2];
  v185 = v61[2];
  v182 = (float)(v7 - v57) * v179;
  v69 = b2_4 + v49;
  v70 = (float)(b2_4 - v49) * v66;
  b2_4a = b2_5 + v43;
  v71 = v61[5];
  v251 = (float)(b2_5 - v43) * v65;
  b2_5a = b1_5 + b2_6;
  b1_5a = (float)(b1_5 - b2_6) * v71;
  b2_6a = v166 + b1_6;
  v72 = b1_6 - v166;
  v167 = v61[6];
  v73 = v72 * v167;
  v74 = b1_7;
  b1_7a = b1_7_0 + b1_7;
  b1_6a = v61[7];
  v75 = v74;
  v76 = v14 + v60;
  v77 = *v61 * (float)(v14 - v60);
  v78 = v243;
  v79 = (float)(v75 - b1_7_0) * b1_6a;
  v254 = v77;
  v244 = v243 + v16;
  v80 = FMOD::CodecMPEG::gPnts[2];
  v81 = v179 * (float)(v16 - v78);
  v82 = v239 + v19;
  v83 = v19 - v239;
  v84 = v235;
  v240 = v82;
  v85 = v185 * v83;
  v236 = v235 + v20;
  v86 = (float)(v20 - v84) * v66;
  v87 = v205 + v231;
  v206 = v65 * (float)(v205 - v231);
  v88 = v208 + v228;
  v209 = v71 * (float)(v208 - v228);
  v89 = v211 + v221;
  v212 = v167 * (float)(v211 - v221);
  v186 = v218 + v36;
  b1_6b = b1_6a * (float)(v36 - v218);
  v180 = v247 + b1_7a;
  b1_7_0a = *v80;
  v90 = (float)(v247 - b1_7a) * *v80;
  b1_7b = b2_1 + b2_6a;
  v168 = v80[1];
  v91 = (float)(b2_1 - b2_6a) * v168;
  b2_1a = b2_5a + v67;
  v92 = v80[2];
  v219 = (float)(v67 - b2_5a) * v92;
  v222 = b2_4a + v69;
  v171 = v80[3];
  v93 = (float)(v69 - b2_4a) * v171;
  b2_6b = v174 + v79;
  v94 = *v80 * (float)(v174 - v79);
  v229 = v182 + v73;
  v95 = v168 * (float)(v182 - v73);
  v183 = b1_5a + v68;
  v232 = (float)(v68 - b1_5a) * v92;
  v96 = v244;
  v248 = v251 + v70;
  v97 = v171 * (float)(v70 - v251);
  v98 = v76;
  v99 = (float)(v76 - v186) * *v80;
  v252 = v98 + v186;
  v245 = v244 + v89;
  v100 = (float)(v96 - v89) * v168;
  v187 = v240 + v88;
  v101 = v240 - v88;
  v102 = v236 + v87;
  v103 = v101 * v92;
  b2_4b = v171 * (float)(v236 - v87);
  v104 = FMOD::CodecMPEG::gPnts[3];
  v105 = v254 + b1_6b;
  b1_7_0b = b1_7_0a * (float)(v254 - b1_6b);
  v237 = v212 + v81;
  v169 = v168 * (float)(v81 - v212);
  b2_5b = v209 + v85;
  v106 = (float)(v85 - v209) * v92;
  v241 = v86 + v206;
  v107 = v104[1];
  v172 = (float)(v86 - v206) * v171;
  v175 = v180 + v222;
  v181 = (float)(v180 - v222) * *v104;
  b1_5b = b2_1a + b1_7b;
  b2_1b = (float)(b1_7b - b2_1a) * v107;
  b1_6c = v90 + v93;
  v108 = (float)(v90 - v93) * *v104;
  v207 = v91 + v219;
  v109 = (float)(v91 - v219) * v107;
  v110 = (float)(b2_6b - v248) * *v104;
  v210 = b2_6b + v248;
  v213 = v183 + v229;
  v249 = v94 + v97;
  v111 = v232;
  v112 = (float)(v94 - v97) * *v104;
  v113 = (float)(v229 - v183) * v107;
  v233 = v232 + v95;
  v114 = (float)(v95 - v111) * v107;
  v184 = v252 + v102;
  v115 = (float)(v252 - v102) * *v104;
  b1_7c = v187 + v245;
  v116 = v245 - v187;
  v246 = b2_4b + v99;
  v117 = v116 * v107;
  v118 = (float)(v99 - b2_4b) * *v104;
  v188 = v100 + v103;
  v119 = (float)(v100 - v103) * v107;
  b2_4c = v241 + v105;
  v120 = (float)(v105 - v241) * *v104;
  v220 = b2_5b + v237;
  v121 = v237 - b2_5b;
  b2_5c = b1_7_0b + v172;
  v122 = v121 * v107;
  v123 = (float)(b1_7_0b - v172) * *v104;
  v173 = v169 + v106;
  v124 = (float)(v169 - v106) * v107;
  v125 = *FMOD::CodecMPEG::gPnts[4];
  v238 = (float)(v175 - b1_5b) * v125;
  v170 = (float)(v181 - b2_1b) * v125;
  v223 = (float)(b1_6c - v207) * v125;
  v126 = (float)(v108 - v109) * v125;
  v127 = (float)(v108 + v109) + v126;
  b1_7_0c = v126;
  v128 = v233;
  b2_6c = v127;
  v242 = (float)(v210 - v213) * v125;
  v129 = (float)(v110 - v113) * v125;
  v130 = (float)(v112 - v114) * v125;
  v131 = (float)(v114 + v112) + v130;
  v230 = (float)(v110 + v113) + v129;
  v132 = v115;
  v133 = v115 + v117;
  v134 = v132 - v117;
  v234 = (float)(v249 + v233) + v131;
  v135 = (float)(v249 - v128) * v125;
  v136 = (float)(v118 - v119) * v125;
  v137 = v131 + v135;
  v138 = (float)(v119 + v118) + v136;
  v139 = v135 + v130;
  v250 = (float)(v184 - b1_7c) * v125;
  v140 = v134 * v125;
  v141 = (float)(v188 + v246) + v138;
  v253 = v133 + (float)(v134 * v125);
  v142 = (float)(v246 - v188) * v125;
  v143 = v138 + v142;
  v144 = (float)(b2_4c - v220) * v125;
  v189 = v142 + v136;
  v145 = (float)(v123 - v124) * v125;
  v146 = v120 - v122;
  v147 = v122 + v120;
  v148 = v146 * v125;
  v149 = (float)(b2_5c - v173) * v125;
  v150 = v147 + v148;
  v151 = (float)(v123 + v124) + v145;
  out0[256] = v175 + b1_5b;
  v152 = (float)(b2_5c + v173) + v151;
  v153 = v151 + v149;
  v154 = v149 + v145;
  out0[192] = (float)(b1_6c + v207) + b2_6c;
  out0[128] = (float)(v181 + b2_1b) + v170;
  out0[64] = b2_6c + v223;
  *out0 = v238;
  *out1 = v238;
  out1[64] = v223 + b1_7_0c;
  out1[128] = v170;
  out1[192] = b1_7_0c;
  out0[224] = (float)(v210 + v213) + v234;
  out0[160] = v234 + v230;
  out0[96] = v230 + v137;
  out0[32] = v137 + v242;
  out1[32] = v242 + v139;
  out1[96] = v139 + v129;
  out1[224] = v130;
  out1[160] = v129 + v130;
  v155 = (float)(b2_4c + v220) + v152;
  v156 = v152 + v150;
  v157 = v150 + v153;
  v158 = v153 + v144;
  v159 = v144 + v154;
  out0[240] = (float)(v184 + b1_7c) + v155;
  v160 = v154 + v148;
  v161 = v148 + v145;
  out0[176] = v141 + v156;
  out0[208] = v155 + v141;
  out0[144] = v156 + v253;
  out0[112] = v253 + v157;
  out0[80] = v157 + v143;
  out0[48] = v143 + v158;
  out0[16] = v158 + v250;
  out1[240] = v145;
  out1[16] = v250 + v159;
  out1[48] = v159 + v189;
  out1[80] = v189 + v160;
  out1[112] = v160 + v140;
  out1[144] = v140 + v161;
  out1[176] = v161 + v136;
  out1[208] = v136 + v145;
}


// Address: 0x222f6e0 | Name: _ZN4FMOD9CodecMPEG6synthCEPfiiPs
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::synthC(
        FMOD::CodecMPEG *const this,
        float *b0,
        int bo1,
        int channelskip,
        __int16 *samples)
{
  __int16 *v5; // r9
  __int64 v6; // rcx
  float *v7; // r11
  float *v8; // rdi
  float *v9; // r10
  float *v10; // rax
  float v11; // xmm15_4
  float v12; // xmm2_4
  float v13; // xmm3_4
  float v14; // xmm4_4
  float v15; // xmm8_4
  float v16; // xmm9_4
  float v17; // xmm12_4
  float v18; // xmm13_4
  float v19; // xmm5_4
  float v20; // xmm6_4
  float v21; // xmm7_4
  float v22; // xmm10_4
  float v23; // xmm11_4
  float v24; // xmm14_4
  float v25; // xmm0_4
  float *v26; // rdi
  __int16 *v27; // r8
  float v28; // xmm1_4
  float v29; // xmm15_4
  __int16 *v30; // r8
  __int64 v31; // rax
  float v32; // xmm0_4
  float v34; // [rsp+0h] [rbp-14h]
  float v35; // [rsp+4h] [rbp-10h]
  float v36; // [rsp+8h] [rbp-Ch]

  v5 = samples;
  v6 = 2LL * channelskip;
  v7 = &qword_2AD84C8[-bo1 + 16];
  v8 = b0;
  v9 = &qword_2AD84C8[-bo1 + 528];
  v10 = v7;
  do
  {
    while ( 1 )
    {
      v11 = *v8;
      v12 = v8[1];
      v13 = v8[2];
      v14 = v8[3];
      v34 = v8[5];
      v36 = v8[4];
      v15 = v8[9];
      v16 = v8[10];
      v17 = v8[13];
      v18 = v8[14];
      v19 = v8[6];
      v20 = v8[7];
      v21 = v8[8];
      v22 = v8[11];
      v23 = v8[12];
      v24 = v8[15];
      v25 = (float)((float)((float)(v10[14] * v18)
                          + (float)((float)((float)(v10[12] * v23)
                                          + (float)((float)((float)(v10[10] * v16)
                                                          + (float)((float)((float)(v10[8] * v21)
                                                                          + (float)((float)((float)(v10[6] * v19)
                                                                                          + (float)((float)((float)(v10[4] * v36) + (float)((float)((float)(v10[2] * v13) + (float)((float)(*v10 * *v8) - (float)(v10[1] * v12))) - (float)(v10[3] * v14)))
                                                                                                  - (float)(v10[5] * v34)))
                                                                                  - (float)(v10[7] * v20)))
                                                                  - (float)(v10[9] * v15)))
                                                  - (float)(v10[11] * v22)))
                                  - (float)(v10[13] * v17)))
                  - (float)(v10[15] * v24))
          * 32767.0;
      if ( v25 <= 32767.0 )
        break;
      *v5 = 0x7FFF;
LABEL_3:
      v10 += 32;
      v8 += 16;
      v5 = (__int16 *)((char *)v5 + v6);
      if ( v10 == v9 )
        goto LABEL_7;
    }
    if ( v25 >= -32768.0 )
    {
      *v5 = (int)v25;
      goto LABEL_3;
    }
    v10 += 32;
    v8 += 16;
    *v5 = 0x8000;
    v5 = (__int16 *)((char *)v5 + v6);
  }
  while ( v10 != v9 );
LABEL_7:
  v35 = v11;
  v26 = b0 + 240;
  v27 = &samples[8 * v6];
  v28 = v36;
  v29 = (float)((float)(v7[526] * b0[270])
              + (float)((float)(v7[524] * b0[268])
                      + (float)((float)(v7[522] * b0[266])
                              + (float)((float)(v7[520] * b0[264])
                                      + (float)((float)(v7[518] * b0[262])
                                              + (float)((float)(v7[516] * b0[260])
                                                      + (float)((float)(v7[514] * b0[258]) + (float)(v7[512] * b0[256]))))))))
      * 32767.0;
  if ( v29 <= 32767.0 )
  {
    if ( v29 >= -32768.0 )
      *v27 = (int)v29;
    else
      *v27 = 0x8000;
  }
  else
  {
    *v27 = 0x7FFF;
  }
  v30 = &v27[(unsigned __int64)v6 / 2];
  v31 = (__int64)&v7[2 * bo1 + 480];
  while ( 2 )
  {
    v32 = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)-*(float *)(v31 - 4) * v35) - (float)(v12 * *(float *)(v31 - 8))) - (float)(v13 * *(float *)(v31 - 12))) - (float)(v14 * *(float *)(v31 - 16))) - (float)(v28 * *(float *)(v31 - 20)))
                                                                                                - (float)(v34 * *(float *)(v31 - 24)))
                                                                                        - (float)(v19
                                                                                                * *(float *)(v31 - 28)))
                                                                                - (float)(v20 * *(float *)(v31 - 32)))
                                                                        - (float)(v21 * *(float *)(v31 - 36)))
                                                                - (float)(v15 * *(float *)(v31 - 40)))
                                                        - (float)(v16 * *(float *)(v31 - 44)))
                                                - (float)(v22 * *(float *)(v31 - 48)))
                                        - (float)(v23 * *(float *)(v31 - 52)))
                                - (float)(v17 * *(float *)(v31 - 56)))
                        - (float)(v18 * *(float *)(v31 - 60)))
                - (float)(v24 * *(float *)(v31 - 64)))
        * 32767.0;
    if ( v32 > 32767.0 )
    {
      *v30 = 0x7FFF;
      goto LABEL_11;
    }
    if ( v32 >= -32768.0 )
    {
      *v30 = (int)v32;
LABEL_11:
      v26 -= 16;
      v31 -= 128;
      v30 = (__int16 *)((char *)v30 + v6);
      if ( v26 == b0 )
        return FMOD_RESULT::FMOD_OK_0;
      goto LABEL_12;
    }
    v26 -= 16;
    v31 -= 128;
    *v30 = 0x8000;
    v30 = (__int16 *)((char *)v30 + v6);
    if ( v26 != b0 )
    {
LABEL_12:
      v35 = *v26;
      v34 = v26[5];
      v12 = v26[1];
      v13 = v26[2];
      v14 = v26[3];
      v28 = v26[4];
      v19 = v26[6];
      v20 = v26[7];
      v21 = v26[8];
      v15 = v26[9];
      v16 = v26[10];
      v22 = v26[11];
      v23 = v26[12];
      v17 = v26[13];
      v18 = v26[14];
      v24 = v26[15];
      continue;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x222fb80 | Name: _ZN4FMOD9CodecMPEG5synthEPvPfii
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::synth(
        FMOD::CodecMPEG *const this,
        void *samples,
        float *bandPtr,
        int channels,
        int channelskip)
{
  FMOD::CodecMPEG_Context *mContext; // rax
  int v8; // r14d
  int v9; // esi
  _BOOL4 v10; // edx
  int v11; // edi
  unsigned __int64 v12; // r14
  __int64 v13; // r15
  __int64 v14; // r13
  __int64 v15; // r12
  int lay; // edx
  float *v17; // rcx
  float *v18; // r11
  int bo1; // [rsp+Ch] [rbp-6Ch]
  char bob1; // [rsp+14h] [rbp-64h]
  __int64 v24; // [rsp+20h] [rbp-58h]
  __int64 v25; // [rsp+28h] [rbp-50h]
  float *buf; // [rsp+30h] [rbp-48h]
  float *bufa; // [rsp+30h] [rbp-48h]
  float *b0; // [rsp+38h] [rbp-40h]

  mContext = this->mContext;
  v8 = ((unsigned __int8)mContext->mSynthBo - 1) & 0xF;
  v9 = ((unsigned __int8)mContext->mSynthBo - 1) & 1;
  bob1 = (mContext->mSynthBo - 1) & 1;
  v10 = !bob1;
  mContext->mSynthBo = v8;
  v11 = v8 + v10;
  bo1 = v8 + v10;
  if ( channels > 0 )
  {
    v12 = 0;
    v13 = 0;
    v14 = 288LL * v10;
    v24 = v11;
    v25 = (unsigned int)(288 * v9);
    v15 = (9LL * (unsigned int)(channels - 1) + 9) << 8;
    while ( 1 )
    {
      lay = mContext->mFrame.lay;
      v17 = &mContext->mSynthBuffs[v12 / 4];
      v18 = &v17[v14];
      if ( lay == 2 )
      {
        b0 = &v17[v14];
        buf = &mContext->mSynthBuffs[v12 / 4];
        FMOD::CodecMPEG::dct64(&v17[v25 + ((LOBYTE(mContext->mSynthBo) + bob1) & 0xF)], &v18[v24], &bandPtr[64 * v13]);
        mContext = this->mContext;
        v18 = b0;
        v17 = buf;
        if ( mContext->mFrame.lay != 3 )
          goto LABEL_4;
      }
      else if ( lay != 3 )
      {
        goto LABEL_4;
      }
      bufa = v18;
      FMOD::CodecMPEG::dct64(&v17[v25 + ((LOBYTE(mContext->mSynthBo) + bob1) & 0xF)], &v18[v24], &bandPtr[v12 / 4]);
      v18 = bufa;
LABEL_4:
      if ( samples )
        FMOD::CodecMPEG::synthC(this, v18, bo1, channelskip, (__int16 *)((char *)samples + v13));
      v12 += 2304LL;
      v13 += 2;
      if ( v12 == v15 )
        return FMOD_RESULT::FMOD_OK_0;
      mContext = this->mContext;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


