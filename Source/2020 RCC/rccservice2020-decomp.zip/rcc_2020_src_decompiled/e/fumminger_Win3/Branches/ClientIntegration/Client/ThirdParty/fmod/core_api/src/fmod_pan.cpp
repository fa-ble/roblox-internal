// Address: 0x21daac0 | Name: _ZN4FMOD4wrapEfff
float __fastcall FMOD::wrap(float result, float value, float min, float max)
{
  for ( ; value > result; result = result + (float)(min - value) )
    ;
  for ( ; result >= min; result = result - (float)(min - value) )
    ;
  return result;
}


// Address: 0x21dab00 | Name: _ZN4FMOD4wrapEiii
int __fastcall FMOD::wrap(int value, int min, int max)
{
  int result; // eax
  int v4; // esi

  for ( result = value; min > result; result += max - min )
    ;
  if ( max <= result )
  {
    v4 = min - max;
    do
      result += v4;
    while ( max <= result );
  }
  return result;
}


// Address: 0x21dab30 | Name: _ZN4FMOD26normaliseSourceGainsAndSumEifiPfiS0_
void __fastcall FMOD::normaliseSourceGainsAndSum(
        int targetChannelCount,
        float gain,
        int inMatrixHop,
        float *inMatrix,
        int outMatrixHop,
        float *outMatrix)
{
  __int64 v6; // rbx
  float *v7; // r9
  int v8; // eax
  float v9; // xmm2_4
  float v10; // xmm1_4
  float v11; // xmm4_4
  int v12; // eax
  __int64 v13; // rcx
  float v14; // xmm1_4

  if ( targetChannelCount > 0 )
  {
    v6 = 4LL * inMatrixHop;
    v7 = inMatrix;
    v8 = 0;
    v9 = 0.0;
    do
    {
      v10 = *v7;
      ++v8;
      v7 = (float *)((char *)v7 + v6);
      v9 = v9 + (float)(v10 * v10);
    }
    while ( v8 != targetChannelCount );
    if ( v9 != 0.0 )
    {
      v11 = gain / fsqrt(v9);
      v12 = 0;
      v13 = 4LL * outMatrixHop;
      do
      {
        v14 = *inMatrix;
        ++v12;
        inMatrix = (float *)((char *)inMatrix + v6);
        *outMatrix = (float)(v14 * v11) + *outMatrix;
        outMatrix = (float *)((char *)outMatrix + v13);
      }
      while ( v12 != targetChannelCount );
    }
  }
}


// Address: 0x21dac00 | Name: _ZN4FMOD19PositionableSpeaker4initEif
void __fastcall FMOD::PositionableSpeaker::init(
        FMOD::PositionableSpeaker *const this,
        int channelIndex,
        float a3,
        float azimuth,
        double a5,
        float a6)
{
  float v6; // xmm0_4
  float v7; // xmm0_4
  float v8; // xmm1_4
  float cosx; // [rsp+8h] [rbp-10h] BYREF
  float sinx[3]; // [rsp+Ch] [rbp-Ch] BYREF

  this->mChannelIndex = channelIndex;
  v6 = FMOD::wrap(a3, -180.0, 180.0, a6);
  this->mAzimuth = v6;
  sincosf(v6 * 0.017453292, sinx, &cosx);
  v7 = cosx;
  v8 = sinx[0];
  this->mNormal.y = 0.0;
  this->mNormal.x = v8;
  this->mNormal.z = v7;
}


// Address: 0x21dac60 | Name: _ZN4FMOD11SpeakerPair8spansArcEfff
bool __fastcall FMOD::SpeakerPair::spansArc(float a1, float angle, float arcStart, float arcEnd)
{
  if ( arcStart > angle )
    return arcStart >= a1 && a1 >= angle;
  if ( a1 >= 0.0 )
  {
    if ( a1 >= angle )
      return (float)(arcStart + 360.0) >= a1;
    return 0;
  }
  if ( a1 < (float)(angle - 360.0) )
    return 0;
  return arcStart >= a1;
}


// Address: 0x21dacc0 | Name: _ZNK4FMOD11SpeakerPair5spansEf
bool __fastcall FMOD::SpeakerPair::spans(
        const FMOD::SpeakerPair *const this,
        float a2,
        float angle,
        double a4,
        float a5)
{
  return FMOD::SpeakerPair::spansArc(a2, this->mSpeakerA->mAzimuth, this->mSpeakerB->mAzimuth, a5);
}


// Address: 0x21dace0 | Name: _ZN4FMOD11SpeakerPair9arcCenterEff
float __fastcall FMOD::SpeakerPair::arcCenter(float a1, float arcStart, float arcEnd)
{
  float v3; // xmm2_4

  v3 = (float)(a1 + arcStart) * 0.5;
  if ( arcStart >= a1 )
    return (float)(a1 + arcStart) * 0.5;
  if ( v3 < 0.0 )
    return v3 + 180.0;
  else
    return v3 - 180.0;
}


// Address: 0x21dad30 | Name: _ZN4FMOD11SpeakerPair9arcExtentEff
float __fastcall FMOD::SpeakerPair::arcExtent(float a1, float arcStart, float arcEnd)
{
  if ( arcStart >= a1 )
    return arcStart - a1;
  else
    return 360.0 - (float)(a1 - arcStart);
}


// Address: 0x21dad60 | Name: _ZN4FMOD11SpeakerPair18absoluteSeparationEff
float __fastcall FMOD::SpeakerPair::absoluteSeparation(float a1, float angle1, float angle2)
{
  float v3; // xmm0_4
  float v4; // xmm1_4

  v3 = FMOD::SpeakerPair::arcExtent(a1, angle1, angle2);
  v4 = v3;
  if ( v3 > 180.0 )
    return 360.0 - v3;
  return v4;
}


// Address: 0x21dad90 | Name: _ZNK4FMOD11SpeakerPair23areSegmentsIntersectingEffffPfS1_S1_S1_
__int64 __fastcall FMOD::SpeakerPair::areSegmentsIntersecting(
        const FMOD::SpeakerPair *const this,
        float segment1Min,
        float segment1Max,
        float segment2Min,
        float segment2Max,
        float *intersectionMin,
        float *intersectionMax,
        float *unionMin,
        float *unionMax)
{
  if ( segment2Min >= segment1Max || segment1Min >= segment2Max )
    return 0;
  if ( intersectionMin )
    *intersectionMin = fmaxf(segment1Min, segment2Min);
  if ( intersectionMax )
    *intersectionMax = fminf(segment1Max, segment2Max);
  if ( unionMin )
    *unionMin = fminf(segment1Min, segment2Min);
  if ( unionMax )
    *unionMax = fmaxf(segment1Max, segment2Max);
  return 1;
}


// Address: 0x21dadf0 | Name: _ZNK4FMOD11SpeakerPair20intersectionsWithArcEffPfS1_
__int64 __fastcall FMOD::SpeakerPair::intersectionsWithArc(
        const FMOD::SpeakerPair *const this,
        float arcStart,
        float arcEnd,
        float *intersectionStart,
        float *intersectionEnd)
{
  float mAzimuth; // xmm0_4
  FMOD::PositionableSpeaker *mSpeakerB; // rax
  float v9; // xmm6_4
  __int64 result; // rax
  int v11; // r13d
  FMOD::PositionableSpeaker *v12; // rdx
  FMOD::PositionableSpeaker *mSpeakerA; // rax
  int v14; // r13d
  float *v15; // rsi
  float v16; // xmm0_4
  float arcStarta; // [rsp+8h] [rbp-30h]
  float arcEnda; // [rsp+Ch] [rbp-2Ch]

  mAzimuth = this->mSpeakerA->mAzimuth;
  mSpeakerB = this->mSpeakerB;
  v9 = mSpeakerB->mAzimuth;
  if ( v9 >= mAzimuth )
  {
    if ( arcEnd > arcStart )
      return (unsigned __int8)FMOD::SpeakerPair::areSegmentsIntersecting(
                                this,
                                mAzimuth,
                                mSpeakerB->mAzimuth,
                                arcStart,
                                arcEnd,
                                intersectionStart,
                                intersectionEnd,
                                0,
                                0);
    v14 = (unsigned __int8)FMOD::SpeakerPair::areSegmentsIntersecting(
                             this,
                             mAzimuth,
                             v9,
                             arcStart,
                             180.0,
                             intersectionStart,
                             intersectionEnd,
                             0,
                             0);
    return v14
         + (unsigned int)(unsigned __int8)FMOD::SpeakerPair::areSegmentsIntersecting(
                                            this,
                                            this->mSpeakerA->mAzimuth,
                                            this->mSpeakerB->mAzimuth,
                                            -180.0,
                                            arcEnd,
                                            &intersectionStart[(unsigned __int8)v14],
                                            &intersectionEnd[(unsigned __int8)v14],
                                            0,
                                            0);
  }
  if ( arcEnd > arcStart )
  {
    arcStarta = arcStart;
    v11 = (unsigned __int8)FMOD::SpeakerPair::areSegmentsIntersecting(
                             this,
                             mAzimuth,
                             180.0,
                             arcStart,
                             arcEnd,
                             intersectionStart,
                             intersectionEnd,
                             0,
                             0);
    return v11
         + (unsigned int)(unsigned __int8)FMOD::SpeakerPair::areSegmentsIntersecting(
                                            this,
                                            -180.0,
                                            this->mSpeakerB->mAzimuth,
                                            arcStarta,
                                            arcEnd,
                                            &intersectionStart[(unsigned __int8)v11],
                                            &intersectionEnd[(unsigned __int8)v11],
                                            0,
                                            0);
  }
  arcEnda = arcStart;
  if ( (unsigned __int8)FMOD::SpeakerPair::areSegmentsIntersecting(
                          this,
                          v9,
                          mAzimuth,
                          arcEnd,
                          arcStart,
                          0,
                          0,
                          intersectionEnd,
                          intersectionStart) )
    return 1;
  v12 = this->mSpeakerB;
  if ( v12->mAzimuth > arcEnda )
  {
    *intersectionStart = arcEnda;
    mSpeakerA = this->mSpeakerA;
    *intersectionEnd = v12->mAzimuth;
    intersectionStart[1] = mSpeakerA->mAzimuth;
    intersectionEnd[1] = arcEnd;
    if ( arcEnd != intersectionStart[1] )
      return 2;
    return 1;
  }
  *intersectionStart = this->mSpeakerA->mAzimuth;
  *intersectionEnd = arcEnd;
  result = arcEnd != *intersectionStart;
  v15 = &intersectionStart[result];
  *v15 = arcEnda;
  v16 = v12->mAzimuth;
  intersectionEnd[result] = v16;
  if ( v16 != *v15 )
    return (unsigned int)(result + 1);
  return result;
}


// Address: 0x21db040 | Name: _ZN4FMOD11SpeakerPair11setSpeakersEPNS_19PositionableSpeakerES2_
FMOD_RESULT_0 __fastcall FMOD::SpeakerPair::setSpeakers(
        FMOD::SpeakerPair *const this,
        FMOD::PositionableSpeaker *spkA,
        FMOD::PositionableSpeaker *spkB)
{
  float v3; // xmm2_4
  float v5; // xmm0_4
  FMOD::PositionableSpeaker *mSpeakerB; // rax
  FMOD::PositionableSpeaker *mSpeakerA; // rdx
  float v8; // xmm0_4

  if ( !spkA || !spkB )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  this->mSpeakerA = spkA;
  this->mSpeakerB = spkB;
  v5 = FMOD::SpeakerPair::arcCenter(spkA->mAzimuth, spkB->mAzimuth, v3);
  mSpeakerB = this->mSpeakerB;
  mSpeakerA = this->mSpeakerA;
  this->mCenter = v5;
  v8 = FMOD::SpeakerPair::arcExtent(mSpeakerA->mAzimuth, mSpeakerB->mAzimuth, v3);
  this->mExtent = v8;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21db0b0 | Name: _ZN4FMOD15VBAPSpeakerPair11setSpeakersEPNS_19PositionableSpeakerES2_
FMOD_RESULT_0 __fastcall FMOD::VBAPSpeakerPair::setSpeakers(
        FMOD::VBAPSpeakerPair *const this,
        FMOD::PositionableSpeaker *spkA,
        FMOD::PositionableSpeaker *spkB)
{
  FMOD_RESULT_0 result; // eax
  float mAzimuth; // xmm0_4
  float v6; // xmm1_4
  float mExtent; // xmm1_4
  __m128 v8; // xmm3
  __m128 v9; // xmm0

  result = FMOD::SpeakerPair::setSpeakers(this, spkA, spkB);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mAzimuth = spkB->mAzimuth;
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    v6 = spkA->mAzimuth;
    if ( (float)(mAzimuth - v6) <= 181.0 && (v6 <= mAzimuth || (float)(v6 - mAzimuth) >= 179.0) )
    {
      mExtent = this->mExtent;
      if ( mExtent > 179.0 || mExtent <= 0.0 )
      {
        this->mDeterminantInverse = 0.0;
        this->mSign = 0.0;
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        v8.m128_f32[0] = 1.0
                       / (float)((float)(spkA->mNormal.x * spkB->mNormal.z) - (float)(spkA->mNormal.z * spkB->mNormal.x));
        v9 = _mm_cmplt_ss((__m128)0LL, v8);
        LODWORD(this->mDeterminantInverse) = v8.m128_i32[0];
        LODWORD(this->mSign) = _mm_andnot_ps(v9, (__m128)0xBF800000).m128_u32[0] | v9.m128_i32[0] & 0x3F800000;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21db1b0 | Name: _ZNK4FMOD15VBAPSpeakerPair17sumLateralPanningEPfS1_ff
__int64 __fastcall FMOD::VBAPSpeakerPair::sumLateralPanning(
        const FMOD::VBAPSpeakerPair *const this,
        float *gainA,
        float *gainB,
        float angle,
        float gain)
{
  float v6; // xmm2_4
  float v7; // xmm0_4
  float z; // [rsp+8h] [rbp-20h] BYREF
  float x[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  sincosf(angle * 0.017453292, x, &z);
  v6 = (float)(x[0] * this->mSpeakerA->mNormal.x) + (float)(z * this->mSpeakerA->mNormal.z);
  v7 = fsqrt(2.0 - (float)(v6 * v6));
  *gainA = (float)((float)((float)(v7 + v6) * gain) * 0.5) + *gainA;
  *gainB = (float)((float)((float)(v7 - v6) * gain) * 0.5) + *gainB;
  return 0;
}


// Address: 0x21db280 | Name: _ZNK4FMOD15VBAPSpeakerPair7sumVBAPEPfS1_ff
__int64 __fastcall FMOD::VBAPSpeakerPair::sumVBAP(
        const FMOD::VBAPSpeakerPair *const this,
        float *gainA,
        float *gainB,
        float angle,
        float gain)
{
  FMOD::PositionableSpeaker *mSpeakerB; // rbp
  float mDeterminantInverse; // xmm2_4
  float v7; // xmm0_4
  float v8; // xmm3_4
  float cosx; // [rsp+18h] [rbp-20h] BYREF
  float sinx[7]; // [rsp+1Ch] [rbp-1Ch] BYREF

  if ( !this->mSpeakerA )
    return 67;
  mSpeakerB = this->mSpeakerB;
  if ( !mSpeakerB )
    return 67;
  mDeterminantInverse = this->mDeterminantInverse;
  if ( mDeterminantInverse == 0.0 )
    return FMOD::VBAPSpeakerPair::sumLateralPanning(this, gainA, gainB, angle, gain);
  sincosf(angle * 0.017453292, sinx, &cosx);
  v7 = cosx;
  v8 = sinx[0];
  *gainA = (float)((float)((float)(mSpeakerB->mNormal.z * sinx[0]) - (float)(mSpeakerB->mNormal.x * cosx))
                 * (float)(gain * mDeterminantInverse))
         + *gainA;
  *gainB = (float)((float)((float)(v7 * this->mSpeakerA->mNormal.x) - (float)(v8 * this->mSpeakerA->mNormal.z))
                 * (float)(gain * mDeterminantInverse))
         + *gainB;
  return 0;
}


// Address: 0x21db380 | Name: _ZNK4FMOD15VBAPSpeakerPair17sumVBAPNormalisedEPfS1_ff
__int64 __fastcall FMOD::VBAPSpeakerPair::sumVBAPNormalised(
        const FMOD::VBAPSpeakerPair *const this,
        float *gainA,
        float *gainB,
        float angle,
        float gain)
{
  FMOD::PositionableSpeaker *mSpeakerA; // rbp
  FMOD::PositionableSpeaker *mSpeakerB; // r12
  float v7; // xmm3_4
  float v8; // xmm2_4
  float v9; // xmm6_4
  float z; // [rsp+28h] [rbp-30h] BYREF
  float x[11]; // [rsp+2Ch] [rbp-2Ch] BYREF

  mSpeakerA = this->mSpeakerA;
  if ( !this->mSpeakerA )
    return 67;
  mSpeakerB = this->mSpeakerB;
  if ( !mSpeakerB )
    return 67;
  if ( this->mDeterminantInverse == 0.0 )
    return FMOD::VBAPSpeakerPair::sumLateralPanning(this, gainA, gainB, angle, gain);
  sincosf(angle * 0.017453292, x, &z);
  v7 = (float)(mSpeakerB->mNormal.z * x[0]) - (float)(mSpeakerB->mNormal.x * z);
  v8 = (float)(z * mSpeakerA->mNormal.x) - (float)(x[0] * mSpeakerA->mNormal.z);
  v9 = this->mSign / fsqrt((float)(v7 * v7) + (float)(v8 * v8));
  *gainA = (float)(v7 * (float)(v9 * gain)) + *gainA;
  *gainB = (float)(v8 * (float)(v9 * gain)) + *gainB;
  return 0;
}


// Address: 0x21db4f0 | Name: _ZNK4FMOD13ChannelLayout20maxSpeakerSeparationEv
float __fastcall FMOD::ChannelLayout::maxSpeakerSeparation(const FMOD::ChannelLayout *const this)
{
  int mSortedPositionableSpeakerCount; // edx
  FMOD::VBAPSpeakerPair *mSpeakerPairs; // rcx
  float result; // xmm0_4
  float *p_mExtent; // rax
  __int64 v5; // rdx
  float v6; // xmm1_4

  mSortedPositionableSpeakerCount = this->mSortedPositionableSpeakerCount;
  if ( mSortedPositionableSpeakerCount <= 1 )
    return 360.0;
  mSpeakerPairs = this->mSpeakerPairs;
  result = 0.0;
  p_mExtent = &mSpeakerPairs->mExtent;
  v5 = (__int64)&mSpeakerPairs[(unsigned int)(mSortedPositionableSpeakerCount - 1) + 1].mExtent;
  do
  {
    v6 = *p_mExtent;
    p_mExtent += 8;
    result = fmaxf(v6, result);
  }
  while ( p_mExtent != (float *)v5 );
  return result;
}


// Address: 0x21db540 | Name: _ZN4FMOD13ChannelLayout14allocateMemoryEiiii
FMOD_RESULT_0 __fastcall FMOD::ChannelLayout::allocateMemory(
        FMOD::ChannelLayout *const this,
        int monoCount,
        int stereoCount,
        int positionedCount,
        int positionedHeightCount)
{
  __int64 v6; // r14
  FMOD_RESULT_0 v9; // ebx
  FMOD::VBAPSpeakerPair *v11; // rax
  FMOD::PositionableSpeaker *v12; // rax
  FMOD::LayoutChannel *v13; // rax
  FMOD::LayoutChannel *v14; // rax
  FMOD::PositionableSpeaker *v15; // rax
  FMOD::LayoutChannel *v16; // rax

  LODWORD(v6) = positionedCount;
  if ( positionedCount <= 1 )
    v6 = stereoCount != 0;
  if ( monoCount )
  {
    v14 = (FMOD::LayoutChannel *)FMOD::MemPool::alloc(
                                   off_286F358->gSystemMemPool,
                                   4 * monoCount,
                                   "../../../core_api/src/fmod_pan.cpp",
                                   494,
                                   0,
                                   0);
    this->mMapAsMonoChannels = v14;
    if ( !v14 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    this->mMapAsMonoChannelCount = monoCount;
  }
  if ( stereoCount )
  {
    v13 = (FMOD::LayoutChannel *)FMOD::MemPool::alloc(
                                   off_286F358->gSystemMemPool,
                                   4 * stereoCount,
                                   "../../../core_api/src/fmod_pan.cpp",
                                   502,
                                   0,
                                   0);
    this->mMapAsStereoLeftChannels = v13;
    if ( !v13 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v16 = (FMOD::LayoutChannel *)FMOD::MemPool::alloc(
                                   off_286F358->gSystemMemPool,
                                   4 * stereoCount,
                                   "../../../core_api/src/fmod_pan.cpp",
                                   505,
                                   0,
                                   0);
    this->mMapAsStereoRightChannels = v16;
    if ( !v16 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    this->mMapAsStereoPairCount = stereoCount;
  }
  if ( positionedCount )
  {
    v15 = (FMOD::PositionableSpeaker *)FMOD::MemPool::alloc(
                                         off_286F358->gSystemMemPool,
                                         20 * positionedCount,
                                         "../../../core_api/src/fmod_pan.cpp",
                                         513,
                                         0,
                                         0);
    this->mSortedPositionableSpeakers = v15;
    if ( !v15 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    this->mSortedPositionableSpeakerCount = positionedCount;
  }
  if ( positionedHeightCount )
  {
    v12 = (FMOD::PositionableSpeaker *)FMOD::MemPool::alloc(
                                         off_286F358->gSystemMemPool,
                                         20 * positionedHeightCount,
                                         "../../../core_api/src/fmod_pan.cpp",
                                         521,
                                         0,
                                         0);
    this->mPositionableHeightSpeakers = v12;
    if ( !v12 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v9 = FMOD_RESULT::FMOD_OK_0;
    this->mPositionableHeightSpeakerCount = positionedHeightCount;
    if ( !(_DWORD)v6 )
      return v9;
LABEL_9:
    v11 = (FMOD::VBAPSpeakerPair *)FMOD::MemPool::alloc(
                                     off_286F358->gSystemMemPool,
                                     32 * (int)v6,
                                     "../../../core_api/src/fmod_pan.cpp",
                                     529,
                                     0,
                                     0);
    this->mSpeakerPairs = v11;
    if ( v11 )
    {
      this->mSpeakerPairCount = v6;
      return v9;
    }
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
  v9 = FMOD_RESULT::FMOD_OK_0;
  if ( (_DWORD)v6 )
    goto LABEL_9;
  return v9;
}


// Address: 0x21db770 | Name: _ZN4FMOD13ChannelLayout11initMembersEv
void __fastcall FMOD::ChannelLayout::initMembers(FMOD::ChannelLayout *const this)
{
  FMOD::SpeakerPair *mReflexPair; // rdi
  unsigned int v3; // edx
  __int64 v4; // rcx
  FMOD::PositionableSpeaker **v5; // rdi

  this->mChannelCount = 0;
  this->mSortedPositionableSpeakerCount = 0;
  this->mSortedPositionableSpeakers = 0;
  this->mPositionableHeightSpeakerCount = 0;
  mReflexPair = this->mReflexPair;
  mReflexPair[-3].mSpeakerB = 0;
  mReflexPair[-3].mCenter = 0.0;
  v3 = 48;
  mReflexPair[-2].mSpeakerA = 0;
  mReflexPair[2].mSpeakerA = 0;
  mReflexPair[2].mSpeakerB = 0;
  mReflexPair[2].mCenter = NAN;
  mReflexPair[2].mExtent = 0.0;
  mReflexPair[3].mSpeakerA = 0;
  LODWORD(mReflexPair[3].mSpeakerB) = 0;
  *(_QWORD *)&mReflexPair[3].mCenter = 0;
  mReflexPair[4].mSpeakerA = 0;
  mReflexPair[-2].mSpeakerB = 0;
  *(_QWORD *)&mReflexPair[-2].mCenter = 0;
  LODWORD(mReflexPair[-1].mSpeakerA) = 0;
  *(FMOD::PositionableSpeaker **)((char *)&mReflexPair[-1].mSpeakerA + 4) = 0;
  *(FMOD::PositionableSpeaker **)((char *)&mReflexPair[-1].mSpeakerB + 4) = 0;
  mReflexPair[-1].mExtent = 0.0;
  if ( ((unsigned __int8)mReflexPair & 1) == 0 )
  {
    if ( ((unsigned __int8)mReflexPair & 2) == 0 )
      goto LABEL_3;
LABEL_12:
    mReflexPair = (FMOD::SpeakerPair *)((char *)mReflexPair + 2);
    v3 -= 2;
    HIWORD(mReflexPair[-1].mExtent) = 0;
    if ( ((unsigned __int8)mReflexPair & 4) == 0 )
      goto LABEL_4;
    goto LABEL_13;
  }
  mReflexPair = (FMOD::SpeakerPair *)((char *)&this->mReflexPair[0].mSpeakerA + 1);
  LOBYTE(this->mReflexPair[0].mSpeakerA) = 0;
  LOBYTE(v3) = 47;
  if ( (((_BYTE)this + 89) & 2) != 0 )
    goto LABEL_12;
LABEL_3:
  if ( ((unsigned __int8)mReflexPair & 4) == 0 )
    goto LABEL_4;
LABEL_13:
  LODWORD(mReflexPair->mSpeakerA) = 0;
  v3 -= 4;
  mReflexPair = (FMOD::SpeakerPair *)((char *)mReflexPair + 4);
LABEL_4:
  v4 = v3 >> 3;
  memset(mReflexPair, 0, 8 * v4);
  v5 = &mReflexPair->mSpeakerA + v4;
  if ( (v3 & 4) != 0 )
  {
    *(_DWORD *)v5 = 0;
    v5 = (FMOD::PositionableSpeaker **)((char *)v5 + 4);
  }
  if ( (v3 & 2) != 0 )
  {
    v5 = (FMOD::PositionableSpeaker **)((char *)v5 + 2);
    *((_WORD *)v5 - 1) = 0;
  }
  if ( (v3 & 1) != 0 )
    *(_BYTE *)v5 = 0;
}


// Address: 0x21db8a0 | Name: _ZN4FMOD13ChannelLayout33sortSpeakersAndCreateSpeakerPairsEPNS_19PositionableSpeakerEi
FMOD_RESULT_0 __fastcall FMOD::ChannelLayout::sortSpeakersAndCreateSpeakerPairs(
        FMOD::ChannelLayout *const this,
        FMOD::PositionableSpeaker *speakers,
        int count)
{
  double v3; // xmm2_8
  float v4; // xmm3_4
  __int64 mAzimuth_low; // xmm1_8
  int v7; // r9d
  int v8; // eax
  char v9; // di
  FMOD::PositionableSpeaker *v10; // rcx
  float mAzimuth; // xmm0_4
  FMOD::PositionableSpeaker *v12; // rdi
  FMOD_RESULT_0 result; // eax
  int mSpeakerPairCount; // eax
  __int64 v15; // r13
  __int64 v16; // r12
  int v17; // ebp
  float v18; // xmm0_4
  FMOD::PositionableSpeaker *mSortedPositionableSpeakers; // r14
  FMOD::PositionableSpeaker *v20; // rbx
  float v21; // xmm0_4
  bool v22; // zf
  FMOD::PositionableSpeaker *mFrontLeftSpeaker; // rax
  float v24; // xmm0_4
  FMOD::PositionableSpeaker *mFrontRightSpeaker; // rax
  FMOD::PositionableSpeaker *spkA; // [rsp+0h] [rbp-48h]
  float axis; // [rsp+8h] [rbp-40h]
  float axisa; // [rsp+8h] [rbp-40h]
  float axisb; // [rsp+8h] [rbp-40h]
  float axisc; // [rsp+8h] [rbp-40h]
  float axisd; // [rsp+8h] [rbp-40h]

  if ( count > 0 )
  {
    mAzimuth_low = 1135869952;
    v7 = 0;
    v8 = 0;
    v4 = 360.0;
    v9 = 0;
    LODWORD(v3) = -1011613696;
    while ( 1 )
    {
      while ( 1 )
      {
        v10 = &speakers[v8];
        mAzimuth = v10->mAzimuth;
        if ( *(float *)&mAzimuth_low <= mAzimuth || mAzimuth <= *(float *)&v3 )
          break;
        ++v8;
        mAzimuth_low = LODWORD(v10->mAzimuth);
        v12 = &this->mSortedPositionableSpeakers[v7];
        *(_QWORD *)&v12->mChannelIndex = *(_QWORD *)&v10->mChannelIndex;
        *(_QWORD *)&v12->mNormal.x = *(_QWORD *)&v10->mNormal.x;
        v12->mNormal.z = v10->mNormal.z;
        v9 = 1;
        if ( count <= v8 )
          goto LABEL_6;
      }
      if ( count <= ++v8 )
      {
        if ( !v9 )
        {
          this->mChannelCount = 0;
          return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        }
LABEL_6:
        ++v7;
        v3 = *(double *)&mAzimuth_low;
        if ( count <= v7 )
          break;
        v8 = 0;
        v9 = 0;
        mAzimuth_low = 1135869952;
      }
    }
  }
  if ( this->mSortedPositionableSpeakerCount > 1 )
  {
    mSpeakerPairCount = this->mSpeakerPairCount;
    if ( mSpeakerPairCount > 0 )
    {
      v15 = 0;
      v16 = 0;
      v17 = 0;
      spkA = &this->mReflexSpeakerA;
      do
      {
        mSortedPositionableSpeakers = this->mSortedPositionableSpeakers;
        v20 = &mSortedPositionableSpeakers[v16];
        if ( v17 != mSpeakerPairCount - 1 )
          mSortedPositionableSpeakers = (FMOD::PositionableSpeaker *)((char *)mSortedPositionableSpeakers + v16 * 20 + 20);
        if ( FMOD::SpeakerPair::arcExtent(v20->mAzimuth, mSortedPositionableSpeakers->mAzimuth, *(float *)&v3) > 180.0 )
        {
          axis = FMOD::SpeakerPair::arcCenter(v20->mAzimuth, mSortedPositionableSpeakers->mAzimuth, *(float *)&v3);
          FMOD::PositionableSpeaker::init(spkA, v20->mChannelIndex, axis - 90.0, axis, v3, v4);
          FMOD::PositionableSpeaker::init(
            &this->mReflexSpeakerB,
            mSortedPositionableSpeakers->mChannelIndex,
            axis + 90.0,
            axis,
            v3,
            v4);
          result = FMOD::VBAPSpeakerPair::setSpeakers(&this->mSpeakerPairs[v15], spkA, &this->mReflexSpeakerB);
          if ( result )
            return result;
          result = FMOD::SpeakerPair::setSpeakers(this->mReflexPair, v20, spkA);
          if ( result )
            return result;
          result = FMOD::SpeakerPair::setSpeakers(
                     &this->mReflexPair[1],
                     &this->mReflexSpeakerB,
                     mSortedPositionableSpeakers);
          if ( result )
            return result;
          v18 = v20->mAzimuth;
          if ( v18 >= 0.0 )
            goto LABEL_18;
        }
        else
        {
          result = FMOD::VBAPSpeakerPair::setSpeakers(&this->mSpeakerPairs[v15], v20, mSortedPositionableSpeakers);
          if ( result )
            return result;
          v18 = v20->mAzimuth;
          if ( v18 >= 0.0 )
            goto LABEL_18;
        }
        if ( v18 >= -90.0 )
        {
          if ( this->mFrontLeftSpeaker )
          {
            axisb = FMOD::SpeakerPair::absoluteSeparation(v18, -45.0, *(float *)&v3);
            if ( FMOD::SpeakerPair::absoluteSeparation(this->mFrontLeftSpeaker->mAzimuth, -45.0, *(float *)&v3) <= axisb )
            {
              axisc = FMOD::SpeakerPair::absoluteSeparation(v20->mAzimuth, -45.0, *(float *)&v3);
              v21 = FMOD::SpeakerPair::absoluteSeparation(this->mFrontLeftSpeaker->mAzimuth, -45.0, *(float *)&v3);
              *(_QWORD *)&v3 = LODWORD(axisc);
              v22 = axisc == v21;
              v18 = v20->mAzimuth;
              if ( v22 )
              {
                mFrontLeftSpeaker = this->mFrontLeftSpeaker;
                if ( v18 > mFrontLeftSpeaker->mAzimuth )
                  mFrontLeftSpeaker = v20;
                this->mFrontLeftSpeaker = mFrontLeftSpeaker;
              }
            }
            else
            {
              this->mFrontLeftSpeaker = v20;
              v18 = v20->mAzimuth;
            }
          }
          else
          {
            this->mFrontLeftSpeaker = v20;
          }
        }
LABEL_18:
        if ( v18 > 0.0 && v18 <= 90.0 )
        {
          if ( this->mFrontRightSpeaker
            && (axisa = FMOD::SpeakerPair::absoluteSeparation(v18, 45.0, *(float *)&v3),
                FMOD::SpeakerPair::absoluteSeparation(this->mFrontRightSpeaker->mAzimuth, 45.0, *(float *)&v3) <= axisa) )
          {
            axisd = FMOD::SpeakerPair::absoluteSeparation(v20->mAzimuth, 45.0, *(float *)&v3);
            v24 = FMOD::SpeakerPair::absoluteSeparation(this->mFrontRightSpeaker->mAzimuth, 45.0, *(float *)&v3);
            *(_QWORD *)&v3 = LODWORD(axisd);
            if ( axisd == v24 )
            {
              mFrontRightSpeaker = this->mFrontRightSpeaker;
              if ( v20->mAzimuth > mFrontRightSpeaker->mAzimuth )
                mFrontRightSpeaker = v20;
              this->mFrontRightSpeaker = mFrontRightSpeaker;
            }
          }
          else
          {
            this->mFrontRightSpeaker = v20;
          }
        }
        mSpeakerPairCount = this->mSpeakerPairCount;
        ++v17;
        ++v16;
        ++v15;
      }
      while ( mSpeakerPairCount > v17 );
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21dbc60 | Name: _ZN4FMOD13ChannelLayout4initEiPKNS_17FMOD_CHANNEL_TYPEEPKf
FMOD_RESULT_0 __fastcall FMOD::ChannelLayout::init(
        FMOD::ChannelLayout *const this,
        int channelCount,
        const FMOD::FMOD_CHANNEL_TYPE *channelTypes,
        const float *speakerDirections)
{
  float v4; // xmm1_4
  double v5; // xmm2_8
  float v6; // xmm3_4
  __int64 v10; // rax
  int v11; // esi
  int v12; // r8d
  int v13; // r13d
  FMOD::FMOD_CHANNEL_TYPE v14; // edx
  FMOD_RESULT_0 result; // eax
  __int64 v16; // r14
  __int64 v17; // rcx
  FMOD::FMOD_CHANNEL_TYPE v18; // edx
  int v19; // ebp
  int stereoLeftCount; // [rsp+8h] [rbp-2D0h]
  int monoIndex; // [rsp+Ch] [rbp-2CCh]
  int positionedHeightIndex; // [rsp+10h] [rbp-2C8h]
  int stereoLeftIndex; // [rsp+14h] [rbp-2C4h]
  int stereoRightIndex; // [rsp+18h] [rbp-2C0h]
  int positionedIndex; // [rsp+1Ch] [rbp-2BCh]
  FMOD::PositionableSpeaker positioned[32]; // [rsp+20h] [rbp-2B8h] BYREF

  FMOD::ChannelLayout::initMembers(this);
  this->mChannelCount = channelCount;
  if ( channelCount > 0 )
  {
    v10 = 0;
    stereoLeftCount = 0;
    v11 = 0;
    v12 = 0;
    v13 = 0;
    while ( 1 )
    {
      v14 = channelTypes[v10];
      if ( v14 == FMOD::FMOD_CHANNEL_TYPE::FMOD_CHANNEL_TYPE_POSITIONED_SPEAKER )
        break;
      switch ( v14 )
      {
        case FMOD::FMOD_CHANNEL_TYPE::FMOD_CHANNEL_TYPE_POSITIONED_HEIGHT_SPEAKER:
          ++v12;
          goto LABEL_4;
        case FMOD::FMOD_CHANNEL_TYPE::FMOD_CHANNEL_TYPE_LOW_FREQUENCY:
LABEL_4:
          if ( channelCount <= (int)++v10 )
            goto LABEL_10;
          break;
        case FMOD::FMOD_CHANNEL_TYPE::FMOD_CHANNEL_TYPE_MAP_AS_MONO:
          ++v11;
          goto LABEL_4;
        default:
          ++v10;
          stereoLeftCount += v14 == FMOD::FMOD_CHANNEL_TYPE::FMOD_CHANNEL_TYPE_MAP_AS_STEREO_LEFT;
          if ( channelCount <= (int)v10 )
          {
LABEL_10:
            result = FMOD::ChannelLayout::allocateMemory(this, v11, stereoLeftCount, v13, v12);
            goto LABEL_11;
          }
          break;
      }
    }
    ++v13;
    goto LABEL_4;
  }
  stereoLeftCount = 0;
  v13 = 0;
  result = FMOD::ChannelLayout::allocateMemory(this, 0, 0, 0, 0);
LABEL_11:
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( this->mChannelCount > 0 )
    {
      v16 = 0;
      positionedHeightIndex = 0;
      v17 = 0;
      stereoRightIndex = 0;
      stereoLeftIndex = 0;
      monoIndex = 0;
      do
      {
        while ( 1 )
        {
          v18 = channelTypes[v16];
          if ( v18 )
            break;
          v19 = v17 + 1;
          FMOD::PositionableSpeaker::init(&positioned[v17], v16, speakerDirections[v16], v4, v5, v6);
          ++v16;
          v17 = v19;
          if ( this->mChannelCount <= (int)v16 )
            goto LABEL_23;
        }
        switch ( v18 )
        {
          case FMOD::FMOD_CHANNEL_TYPE::FMOD_CHANNEL_TYPE_POSITIONED_HEIGHT_SPEAKER:
            positionedIndex = v17;
            FMOD::PositionableSpeaker::init(
              &this->mPositionableHeightSpeakers[positionedHeightIndex++],
              v16,
              speakerDirections[v16],
              v4,
              v5,
              v6);
            v17 = positionedIndex;
            break;
          case FMOD::FMOD_CHANNEL_TYPE::FMOD_CHANNEL_TYPE_LOW_FREQUENCY:
            this->mLowFrequencyChannelIndex = v16;
            break;
          case FMOD::FMOD_CHANNEL_TYPE::FMOD_CHANNEL_TYPE_MAP_AS_MONO:
            this->mMapAsMonoChannels[monoIndex++].mChannelIndex = v16;
            break;
          case FMOD::FMOD_CHANNEL_TYPE::FMOD_CHANNEL_TYPE_MAP_AS_STEREO_LEFT:
            this->mMapAsStereoLeftChannels[stereoLeftIndex++].mChannelIndex = v16;
            break;
          case FMOD::FMOD_CHANNEL_TYPE::FMOD_CHANNEL_TYPE_MAP_AS_STEREO_RIGHT:
            this->mMapAsStereoRightChannels[stereoRightIndex++].mChannelIndex = v16;
            break;
        }
        ++v16;
      }
      while ( this->mChannelCount > (int)v16 );
    }
LABEL_23:
    if ( v13 )
    {
      return FMOD::ChannelLayout::sortSpeakersAndCreateSpeakerPairs(this, positioned, v13);
    }
    else
    {
      result = FMOD_RESULT::FMOD_OK_0;
      if ( stereoLeftCount )
      {
        FMOD::PositionableSpeaker::init(
          &this->mReflexSpeakerA,
          this->mMapAsStereoLeftChannels->mChannelIndex,
          -90.0,
          v4,
          v5,
          v6);
        FMOD::PositionableSpeaker::init(
          &this->mReflexSpeakerB,
          this->mMapAsStereoRightChannels->mChannelIndex,
          90.0,
          v4,
          v5,
          v6);
        return FMOD::VBAPSpeakerPair::setSpeakers(this->mSpeakerPairs, &this->mReflexSpeakerA, &this->mReflexSpeakerB);
      }
    }
  }
  return result;
}


// Address: 0x21dbf30 | Name: _ZN4FMOD13ChannelLayout14initFromLayoutEPKS0_jb
FMOD_RESULT_0 __fastcall FMOD::ChannelLayout::initFromLayout(
        FMOD::ChannelLayout *const this,
        const FMOD::ChannelLayout *layout,
        unsigned int enabledChannels,
        bool heightOnly)
{
  float v4; // xmm1_4
  double v5; // xmm2_8
  float v6; // xmm3_4
  __int64 v10; // r14
  int v11; // r15d
  __int64 v12; // rbp
  FMOD::PositionableSpeaker *v13; // rdx
  unsigned int v14; // eax
  FMOD::PositionableSpeaker *v15; // rdi
  FMOD_RESULT_0 result; // eax
  __int64 v17; // r13
  int i; // r14d
  FMOD::PositionableSpeaker *v19; // rax
  FMOD::PositionableSpeaker *v20; // rdi
  int mMapAsMonoChannelCount; // eax
  FMOD::LayoutChannel *mMapAsMonoChannels; // rsi
  __int64 v23; // rcx
  unsigned __int64 v24; // rax
  int mMapAsStereoPairCount; // r8d
  FMOD::LayoutChannel *mMapAsStereoLeftChannels; // rdi
  FMOD::LayoutChannel *mMapAsStereoRightChannels; // rsi
  unsigned __int64 v28; // rax
  int mLowFrequencyChannelIndex; // eax
  unsigned int v30; // ecx
  __int64 v31; // r15
  int v32; // r14d
  FMOD::PositionableSpeaker *v33; // rcx
  unsigned int v34; // eax
  FMOD::PositionableSpeaker *v35; // rdi
  int positionedHeightCount; // [rsp+10h] [rbp-2C8h]
  FMOD::PositionableSpeaker positioned[32]; // [rsp+20h] [rbp-2B8h] BYREF

  FMOD::ChannelLayout::initMembers(this);
  this->mChannelCount = layout->mChannelCount;
  if ( !heightOnly )
  {
    positionedHeightCount = layout->mPositionableHeightSpeakerCount;
    if ( layout->mSortedPositionableSpeakerCount <= 0 )
    {
      LODWORD(v12) = 0;
    }
    else
    {
      v31 = 0;
      v32 = 0;
      v12 = 0;
      do
      {
        v33 = &layout->mSortedPositionableSpeakers[v31];
        v34 = enabledChannels;
        if ( _bittest((const int *)&v34, v33->mChannelIndex) )
        {
          v35 = &positioned[v12];
          v12 = (int)v12 + 1;
          FMOD::PositionableSpeaker::init(v35, v33->mChannelIndex, v33->mAzimuth, v4, v5, v6);
        }
        ++v32;
        ++v31;
      }
      while ( layout->mSortedPositionableSpeakerCount > v32 );
    }
LABEL_8:
    result = FMOD::ChannelLayout::allocateMemory(
               this,
               layout->mMapAsMonoChannelCount,
               layout->mMapAsStereoPairCount,
               v12,
               positionedHeightCount);
    goto LABEL_9;
  }
  if ( layout->mPositionableHeightSpeakerCount > 0 )
  {
    v10 = 0;
    v11 = 0;
    v12 = 0;
    do
    {
      while ( 1 )
      {
        v13 = &layout->mPositionableHeightSpeakers[v10];
        v14 = enabledChannels;
        if ( _bittest((const int *)&v14, v13->mChannelIndex) )
          break;
        ++v11;
        ++v10;
        if ( layout->mPositionableHeightSpeakerCount <= v11 )
          goto LABEL_7;
      }
      ++v11;
      ++v10;
      v15 = &positioned[v12];
      v12 = (int)v12 + 1;
      FMOD::PositionableSpeaker::init(v15, v13->mChannelIndex, v13->mAzimuth, v4, v5, v6);
    }
    while ( layout->mPositionableHeightSpeakerCount > v11 );
LABEL_7:
    positionedHeightCount = 0;
    goto LABEL_8;
  }
  LODWORD(v12) = 0;
  result = FMOD::ChannelLayout::allocateMemory(
             this,
             layout->mMapAsMonoChannelCount,
             layout->mMapAsStereoPairCount,
             0,
             0);
LABEL_9:
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v17 = 0;
    for ( i = 0; this->mPositionableHeightSpeakerCount > i; ++i )
    {
      v19 = &layout->mPositionableHeightSpeakers[v17];
      v20 = &this->mPositionableHeightSpeakers[v17++];
      FMOD::PositionableSpeaker::init(v20, v19->mChannelIndex, v19->mAzimuth, v4, v5, v6);
    }
    mMapAsMonoChannelCount = this->mMapAsMonoChannelCount;
    if ( mMapAsMonoChannelCount > 0 )
    {
      mMapAsMonoChannels = this->mMapAsMonoChannels;
      v23 = 4LL * (unsigned int)(mMapAsMonoChannelCount - 1) + 4;
      v24 = 0;
      do
      {
        mMapAsMonoChannels[v24 / 4] = layout->mMapAsMonoChannels[v24 / 4];
        v24 += 4LL;
      }
      while ( v24 != v23 );
    }
    mMapAsStereoPairCount = this->mMapAsStereoPairCount;
    if ( mMapAsStereoPairCount > 0 )
    {
      mMapAsStereoLeftChannels = this->mMapAsStereoLeftChannels;
      mMapAsStereoRightChannels = this->mMapAsStereoRightChannels;
      v28 = 0;
      do
      {
        mMapAsStereoLeftChannels[v28 / 4] = layout->mMapAsStereoLeftChannels[v28 / 4];
        mMapAsStereoRightChannels[v28 / 4] = layout->mMapAsStereoRightChannels[v28 / 4];
        v28 += 4LL;
      }
      while ( v28 != 4LL * (unsigned int)(mMapAsStereoPairCount - 1) + 4 );
    }
    mLowFrequencyChannelIndex = layout->mLowFrequencyChannelIndex;
    if ( mLowFrequencyChannelIndex != -1 )
    {
      v30 = enabledChannels;
      if ( _bittest((const int *)&v30, mLowFrequencyChannelIndex) )
        this->mLowFrequencyChannelIndex = mLowFrequencyChannelIndex;
    }
    if ( (_DWORD)v12 )
    {
      return FMOD::ChannelLayout::sortSpeakersAndCreateSpeakerPairs(this, positioned, v12);
    }
    else
    {
      result = FMOD_RESULT::FMOD_OK_0;
      if ( mMapAsStereoPairCount )
      {
        FMOD::PositionableSpeaker::init(
          &this->mReflexSpeakerA,
          this->mMapAsStereoLeftChannels->mChannelIndex,
          -90.0,
          v4,
          v5,
          v6);
        FMOD::PositionableSpeaker::init(
          &this->mReflexSpeakerB,
          this->mMapAsStereoRightChannels->mChannelIndex,
          90.0,
          v4,
          v5,
          v6);
        return FMOD::VBAPSpeakerPair::setSpeakers(this->mSpeakerPairs, &this->mReflexSpeakerA, &this->mReflexSpeakerB);
      }
    }
  }
  return result;
}


// Address: 0x21dc200 | Name: _ZN4FMOD13ChannelLayout5closeEv
FMOD_RESULT_0 __fastcall FMOD::ChannelLayout::close(FMOD::ChannelLayout *const this)
{
  FMOD::VBAPSpeakerPair *mSpeakerPairs; // rsi
  FMOD::PositionableSpeaker *mSortedPositionableSpeakers; // rsi
  FMOD::PositionableSpeaker *mPositionableHeightSpeakers; // rsi
  FMOD::LayoutChannel *mMapAsMonoChannels; // rsi
  FMOD::LayoutChannel *mMapAsStereoLeftChannels; // rsi
  FMOD::LayoutChannel *mMapAsStereoRightChannels; // rsi

  mSpeakerPairs = this->mSpeakerPairs;
  if ( mSpeakerPairs )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mSpeakerPairs, "../../../core_api/src/fmod_pan.cpp", 870);
    this->mSpeakerPairs = 0;
  }
  mSortedPositionableSpeakers = this->mSortedPositionableSpeakers;
  if ( mSortedPositionableSpeakers )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      mSortedPositionableSpeakers,
      "../../../core_api/src/fmod_pan.cpp",
      871);
    this->mSortedPositionableSpeakers = 0;
  }
  mPositionableHeightSpeakers = this->mPositionableHeightSpeakers;
  if ( mPositionableHeightSpeakers )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      mPositionableHeightSpeakers,
      "../../../core_api/src/fmod_pan.cpp",
      872);
    this->mPositionableHeightSpeakers = 0;
  }
  mMapAsMonoChannels = this->mMapAsMonoChannels;
  if ( mMapAsMonoChannels )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mMapAsMonoChannels, "../../../core_api/src/fmod_pan.cpp", 873);
    this->mMapAsMonoChannels = 0;
  }
  mMapAsStereoLeftChannels = this->mMapAsStereoLeftChannels;
  if ( mMapAsStereoLeftChannels )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      mMapAsStereoLeftChannels,
      "../../../core_api/src/fmod_pan.cpp",
      874);
    this->mMapAsStereoLeftChannels = 0;
  }
  mMapAsStereoRightChannels = this->mMapAsStereoRightChannels;
  if ( mMapAsStereoRightChannels )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      mMapAsStereoRightChannels,
      "../../../core_api/src/fmod_pan.cpp",
      875);
    this->mMapAsStereoRightChannels = 0;
  }
  FMOD::ChannelLayout::initMembers(this);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21dc360 | Name: _ZN4FMOD13ChannelLayout11clearMatrixEiiiPf
FMOD_RESULT_0 __fastcall FMOD::ChannelLayout::clearMatrix(
        int sourceChannels,
        int targetChannels,
        int hopsize,
        float *matrix)
{
  __int64 v4; // r8
  int i; // edx
  __int64 v6; // rax

  if ( targetChannels > 0 )
  {
    v4 = 4LL * hopsize;
    for ( i = 0; i != targetChannels; ++i )
    {
      if ( sourceChannels > 0 )
      {
        v6 = 0;
        do
          matrix[v6++] = 0.0;
        while ( sourceChannels > (int)v6 );
      }
      matrix = (float *)((char *)matrix + v4);
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21dc3a0 | Name: _ZN4FMOD13ChannelLayout13sumMonoMatrixEPKS0_ffPf
__int64 __fastcall FMOD::ChannelLayout::sumMonoMatrix(
        const FMOD::ChannelLayout *sourceLayout,
        float a2,
        float lowFrequencyGain,
        float overallGain,
        float *matrix)
{
  __int64 v5; // rdx
  int i; // eax
  __int64 mChannelIndex; // rcx
  __int64 mLowFrequencyChannelIndex; // rax
  float v10; // xmm2_4
  __int64 v11; // rax
  int v12; // edx
  float *v13; // rcx
  __int64 v14; // rcx
  int mSortedPositionableSpeakerCount; // eax
  float v16; // xmm5_4
  __int64 v17; // rdx
  int v18; // eax
  __int64 v19; // rcx

  if ( sourceLayout->mMapAsMonoChannelCount )
  {
    v5 = 0;
    for ( i = 0; sourceLayout->mMapAsMonoChannelCount > i; matrix[mChannelIndex] = matrix[mChannelIndex]
                                                                                 + lowFrequencyGain )
    {
      ++i;
      mChannelIndex = sourceLayout->mMapAsMonoChannels[v5++].mChannelIndex;
    }
  }
  else if ( sourceLayout->mMapAsStereoPairCount )
  {
    v10 = lowFrequencyGain / 1.4142135;
    if ( sourceLayout->mMapAsStereoPairCount > 0 )
    {
      v11 = 0;
      v12 = 0;
      do
      {
        ++v12;
        v13 = &matrix[sourceLayout->mMapAsStereoLeftChannels[v11].mChannelIndex];
        *v13 = *v13 + v10;
        v14 = sourceLayout->mMapAsStereoRightChannels[v11++].mChannelIndex;
        matrix[v14] = matrix[v14] + v10;
      }
      while ( sourceLayout->mMapAsStereoPairCount > v12 );
    }
  }
  else
  {
    mSortedPositionableSpeakerCount = sourceLayout->mSortedPositionableSpeakerCount;
    if ( mSortedPositionableSpeakerCount )
    {
      v16 = lowFrequencyGain / fsqrt((float)mSortedPositionableSpeakerCount);
      if ( sourceLayout->mSortedPositionableSpeakerCount > 0 )
      {
        v17 = 0;
        v18 = 0;
        do
        {
          ++v18;
          v19 = sourceLayout->mSortedPositionableSpeakers[v17++].mChannelIndex;
          matrix[v19] = matrix[v19] + v16;
        }
        while ( sourceLayout->mSortedPositionableSpeakerCount > v18 );
      }
    }
  }
  mLowFrequencyChannelIndex = sourceLayout->mLowFrequencyChannelIndex;
  if ( (_DWORD)mLowFrequencyChannelIndex != -1 )
    matrix[mLowFrequencyChannelIndex] = (float)(lowFrequencyGain * a2) + matrix[mLowFrequencyChannelIndex];
  return 0;
}


// Address: 0x21dc520 | Name: _ZN4FMOD13ChannelLayout7sumVBAPEPKS0_fffbiPf
void __fastcall FMOD::ChannelLayout::sumVBAP(
        const FMOD::ChannelLayout *targetLayout,
        float direction,
        float extent,
        float gain,
        bool powerNormalize,
        int matrixHop,
        float *matrix,
        float a8)
{
  float *v9; // rbp
  int v10; // ebx
  float v11; // xmm0_4
  int mSortedPositionableSpeakerCount; // eax
  float v13; // xmm2_4
  char v14; // r14
  __int64 v15; // rbp
  __int64 v16; // rbx
  int v17; // r8d
  FMOD::VBAPSpeakerPair *v18; // rax
  __int64 v19; // rdx
  __int64 v20; // rax
  __int64 v21; // rbp
  int v22; // r14d
  float v23; // xmm2_4
  float v24; // xmm1_4
  float v25; // xmm0_4
  float v26; // xmm0_4
  int v27; // eax
  FMOD::PositionableSpeaker *mSortedPositionableSpeakers; // rcx
  __m128 v29; // xmm2
  FMOD::PositionableSpeaker *v30; // rdx
  __int64 v31; // rsi
  float v32; // xmm1_4
  float v33; // xmm2_4
  __int64 v34; // rcx
  int v35; // edx
  __int64 v36; // rsi
  __int64 v37; // rdx
  int v38; // eax
  int v39; // esi
  float *v40; // rax
  float v41; // xmm2_4
  float v42; // xmm0_4
  float v43; // xmm0_4
  float v44; // xmm2_4
  __int64 v45; // rax
  int v46; // edx
  float v47; // xmm1_4
  int v48; // esi
  int v49; // edi
  __int64 v50; // r12
  int v51; // r13d
  FMOD::VBAPSpeakerPair *v52; // rdi
  float *v53; // rsi
  float *v54; // rdx
  __int64 v55; // rdx
  float v56; // xmm5_4
  int i; // eax
  int mChannelIndex; // esi
  FMOD::SpeakerPair *mReflexPair; // r12
  FMOD::SpeakerPair *v60; // r12
  float *v61; // rax
  __int64 v62; // rsi
  float gaina; // [rsp+Ch] [rbp-11Ch]
  float angle; // [rsp+10h] [rbp-118h]
  float anglea; // [rsp+10h] [rbp-118h]
  float extentArcCentroid; // [rsp+18h] [rbp-110h]
  float maxExtent; // [rsp+1Ch] [rbp-10Ch]
  float *gainB; // [rsp+20h] [rbp-108h]
  float *gainA; // [rsp+28h] [rbp-100h]
  __int64 v70; // [rsp+30h] [rbp-F8h]
  int matrixHopa; // [rsp+44h] [rbp-E4h]
  float *matrixa; // [rsp+48h] [rbp-E0h]
  float intersectionStart[4]; // [rsp+50h] [rbp-D8h] BYREF
  float leftGain[4]; // [rsp+60h] [rbp-C8h] BYREF
  float rightGain[46]; // [rsp+70h] [rbp-B8h] BYREF

  v9 = matrix;
  v10 = matrixHop;
  gaina = gain;
  if ( targetLayout->mSortedPositionableSpeakerCount == 1 )
  {
    v40 = &matrix[targetLayout->mSortedPositionableSpeakers->mChannelIndex * matrixHop];
    *v40 = *v40 + gain;
    return;
  }
  v11 = FMOD::wrap(direction, -180.0, 180.0, a8);
  mSortedPositionableSpeakerCount = targetLayout->mSortedPositionableSpeakerCount;
  angle = v11;
  if ( mSortedPositionableSpeakerCount )
  {
    if ( extent >= 360.0 )
    {
      v55 = 0;
      v56 = gain / fsqrt((float)mSortedPositionableSpeakerCount);
      for ( i = 0;
            i < targetLayout->mSortedPositionableSpeakerCount;
            v9[v10 * mChannelIndex] = v9[v10 * mChannelIndex] + v56 )
      {
        ++i;
        mChannelIndex = targetLayout->mSortedPositionableSpeakers[v55++].mChannelIndex;
      }
    }
    else
    {
      if ( extent > 0.0 )
      {
        memset(rightGain, 0, 4LL * targetLayout->mChannelCount);
        extentArcCentroid = FMOD::wrap(v11 - (float)(extent * 0.5), -180.0, 180.0, extent * 0.5);
        v13 = 180.0;
        maxExtent = FMOD::wrap(angle + (float)(extent * 0.5), -180.0, 180.0, extent * 0.5);
        if ( targetLayout->mSortedPositionableSpeakerCount <= 0 )
          goto LABEL_75;
        matrixa = v9;
        v14 = 0;
        matrixHopa = v10;
        v15 = 0;
        do
        {
          v16 = v15;
          v17 = FMOD::SpeakerPair::intersectionsWithArc(
                  &targetLayout->mSpeakerPairs[v15],
                  extentArcCentroid,
                  maxExtent,
                  intersectionStart,
                  leftGain);
          if ( v17 )
          {
            v18 = &targetLayout->mSpeakerPairs[v16];
            v19 = v18->mSpeakerA->mChannelIndex;
            v20 = v18->mSpeakerB->mChannelIndex;
            if ( v17 > 0 )
            {
              v70 = v15;
              v21 = 0;
              v22 = v17;
              gainB = &rightGain[v20];
              gainA = &rightGain[v19];
              do
              {
                v23 = FMOD::SpeakerPair::arcExtent(intersectionStart[v21], leftGain[v21], v13);
                v24 = leftGain[v21];
                v25 = intersectionStart[v21++];
                anglea = v23 / targetLayout->mSpeakerPairs[v16].mExtent;
                v26 = FMOD::SpeakerPair::arcCenter(v25, v24, anglea);
                v13 = anglea;
                FMOD::VBAPSpeakerPair::sumVBAPNormalised(&targetLayout->mSpeakerPairs[v16], gainA, gainB, v26, anglea);
              }
              while ( v22 > (int)v21 );
              v15 = v70;
              v14 = 1;
            }
          }
          v27 = targetLayout->mSortedPositionableSpeakerCount;
          ++v15;
        }
        while ( v27 > (int)v15 );
        v10 = matrixHopa;
        v9 = matrixa;
        if ( !v14 )
        {
LABEL_75:
          if ( targetLayout->mReflexPair[0].mSpeakerA && targetLayout->mReflexPair[0].mSpeakerB )
          {
            mReflexPair = targetLayout->mReflexPair;
            while ( !(unsigned int)FMOD::SpeakerPair::intersectionsWithArc(
                                     mReflexPair,
                                     extentArcCentroid,
                                     maxExtent,
                                     0,
                                     0) )
            {
              if ( targetLayout->mReflexPair[0].mSpeakerA )
              {
                if ( targetLayout->mReflexPair[0].mSpeakerB )
                {
                  if ( ++mReflexPair != (FMOD::SpeakerPair *)&targetLayout->mFrontLeftSpeaker )
                    continue;
                }
              }
              goto LABEL_57;
            }
            rightGain[mReflexPair->mSpeakerA->mChannelIndex] = rightGain[mReflexPair->mSpeakerA->mChannelIndex] + 1.0;
          }
LABEL_57:
          v27 = targetLayout->mSortedPositionableSpeakerCount;
        }
        if ( !powerNormalize )
          goto LABEL_22;
        if ( v27 <= 0 )
        {
          v33 = 0.0;
        }
        else
        {
          mSortedPositionableSpeakers = targetLayout->mSortedPositionableSpeakers;
          v29 = 0;
          v30 = mSortedPositionableSpeakers + 1;
          v31 = (__int64)&mSortedPositionableSpeakers[(unsigned int)(v27 - 1) + 1];
          while ( 1 )
          {
            v32 = rightGain[mSortedPositionableSpeakers->mChannelIndex];
            mSortedPositionableSpeakers = v30;
            v29.m128_f32[0] = v29.m128_f32[0] + (float)(v32 * v32);
            if ( v30 == (FMOD::PositionableSpeaker *)v31 )
              break;
            ++v30;
          }
          v33 = _mm_unpacklo_ps(v29, v29).m128_f32[0];
          if ( v33 >= 0.999999 && v33 <= 1.000001 )
          {
LABEL_22:
            v34 = 0;
            v35 = 0;
            if ( gaina >= 0.999999 && gaina <= 1.000001 )
            {
              if ( v27 > 0 )
              {
                do
                {
                  ++v35;
                  v62 = targetLayout->mSortedPositionableSpeakers[v34++].mChannelIndex;
                  v9[(int)v62 * v10] = v9[(int)v62 * v10] + rightGain[v62];
                }
                while ( v35 < targetLayout->mSortedPositionableSpeakerCount );
              }
            }
            else if ( v27 > 0 )
            {
              do
              {
                ++v35;
                v36 = targetLayout->mSortedPositionableSpeakers[v34++].mChannelIndex;
                v9[(int)v36 * v10] = (float)(gaina * rightGain[v36]) + v9[(int)v36 * v10];
              }
              while ( v35 < targetLayout->mSortedPositionableSpeakerCount );
            }
            return;
          }
        }
        gaina = gaina / fsqrt(v33);
        goto LABEL_22;
      }
      v50 = 0;
      v51 = 0;
      if ( mSortedPositionableSpeakerCount > 0 )
      {
        while ( !FMOD::SpeakerPair::spans(
                   &targetLayout->mSpeakerPairs[v50],
                   v11,
                   -180.0,
                   COERCE_DOUBLE(1127481344),
                   extent) )
        {
          ++v51;
          ++v50;
          if ( v51 >= targetLayout->mSortedPositionableSpeakerCount )
            goto LABEL_58;
        }
        v52 = &targetLayout->mSpeakerPairs[v50];
        v53 = &v9[v10 * v52->mSpeakerA->mChannelIndex];
        v54 = &v9[v52->mSpeakerB->mChannelIndex * v10];
        if ( powerNormalize )
          FMOD::VBAPSpeakerPair::sumVBAPNormalised(v52, v53, v54, v11, gain);
        else
          FMOD::VBAPSpeakerPair::sumVBAP(v52, v53, v54, v11, gain);
      }
      else
      {
LABEL_58:
        if ( targetLayout->mReflexPair[0].mSpeakerA && targetLayout->mReflexPair[0].mSpeakerB )
        {
          v60 = targetLayout->mReflexPair;
          do
          {
            if ( FMOD::SpeakerPair::spans(v60, v11, -180.0, COERCE_DOUBLE(1127481344), extent) )
            {
              v61 = &v9[v10 * v60->mSpeakerA->mChannelIndex];
              *v61 = gain + *v61;
            }
            if ( !targetLayout->mReflexPair[0].mSpeakerA )
              break;
            if ( !targetLayout->mReflexPair[0].mSpeakerB )
              break;
            ++v60;
          }
          while ( v60 != (FMOD::SpeakerPair *)&targetLayout->mFrontLeftSpeaker );
        }
      }
    }
  }
  else if ( targetLayout->mMapAsStereoPairCount )
  {
    leftGain[0] = 0.0;
    rightGain[0] = 0.0;
    if ( extent == 0.0 )
      v41 = 1.0;
    else
      v41 = sinf((float)(extent / 360.0) * 3.1415927) / (float)((float)(extent / 360.0) * 3.1415927);
    v42 = sinf((float)(angle / 180.0) * 3.1415927);
    v43 = asinf(v42 * v41);
    FMOD::VBAPSpeakerPair::sumVBAP(
      targetLayout->mSpeakerPairs,
      leftGain,
      rightGain,
      (float)(v43 / 3.1415927) * 180.0,
      gaina);
    if ( targetLayout->mMapAsStereoPairCount > 0 )
    {
      v44 = leftGain[0];
      v45 = 0;
      v46 = 0;
      v47 = rightGain[0];
      do
      {
        ++v46;
        v48 = v10 * targetLayout->mMapAsStereoLeftChannels[v45].mChannelIndex;
        v9[v48] = v9[v48] + v44;
        v49 = targetLayout->mMapAsStereoRightChannels[v45++].mChannelIndex;
        v9[v10 * v49] = v9[v10 * v49] + v47;
      }
      while ( v46 < targetLayout->mMapAsStereoPairCount );
    }
  }
  else if ( targetLayout->mMapAsMonoChannelCount > 0 )
  {
    v37 = 0;
    v38 = 0;
    do
    {
      ++v38;
      v39 = targetLayout->mMapAsMonoChannels[v37++].mChannelIndex;
      v9[v10 * v39] = gain + v9[v10 * v39];
    }
    while ( v38 < targetLayout->mMapAsMonoChannelCount );
  }
}


// Address: 0x21dcc90 | Name: _ZN4FMOD13ChannelLayout15sumStereoMatrixEPKS0_fffiPf
__int64 __fastcall FMOD::ChannelLayout::sumStereoMatrix(
        const FMOD::ChannelLayout *sourceLayout,
        float pan,
        float lowFrequencyGain,
        float overallGain,
        int matrixHop,
        float *matrix)
{
  float v9; // xmm2_4
  float v10; // xmm0_4
  __int64 mLowFrequencyChannelIndex; // rax
  float v12; // xmm3_4
  __int64 v13; // rax
  int v14; // edx
  float v15; // xmm2_4
  float i; // xmm3_4
  float *v17; // rcx
  int mChannelIndex; // esi
  __int64 v20; // rax
  int v21; // edx
  float *v22; // rcx
  int v23; // edi
  __int64 v24; // rax
  float *v25; // rax
  float *v26; // rax
  float m[74]; // [rsp+10h] [rbp-128h] BYREF

  v9 = overallGain * cosf((float)((float)(pan + 100.0) * 3.1415927) / 400.0);
  v10 = cosf((float)((float)(100.0 - pan) * 3.1415927) / 400.0);
  mLowFrequencyChannelIndex = sourceLayout->mLowFrequencyChannelIndex;
  v12 = overallGain * v10;
  if ( (_DWORD)mLowFrequencyChannelIndex != -1 )
  {
    matrix[mLowFrequencyChannelIndex] = (float)(lowFrequencyGain * v9) + matrix[mLowFrequencyChannelIndex];
    matrix[matrixHop + sourceLayout->mLowFrequencyChannelIndex] = (float)(lowFrequencyGain * v12)
                                                                + matrix[matrixHop
                                                                       + sourceLayout->mLowFrequencyChannelIndex];
  }
  if ( sourceLayout->mMapAsStereoPairCount )
  {
    v13 = 0;
    v14 = 0;
    v15 = v9 * 1.4142135;
    for ( i = v12 * 1.4142135;
          sourceLayout->mMapAsStereoPairCount > v14;
          matrix[matrixHop + mChannelIndex] = matrix[matrixHop + mChannelIndex] + i )
    {
      ++v14;
      v17 = &matrix[sourceLayout->mMapAsStereoLeftChannels[v13].mChannelIndex];
      *v17 = *v17 + v15;
      mChannelIndex = sourceLayout->mMapAsStereoRightChannels[v13++].mChannelIndex;
    }
    return 0;
  }
  if ( sourceLayout->mMapAsMonoChannelCount )
  {
    if ( sourceLayout->mMapAsMonoChannelCount > 0 )
    {
      v20 = 0;
      v21 = 0;
      do
      {
        ++v21;
        v22 = &matrix[sourceLayout->mMapAsMonoChannels[v20].mChannelIndex];
        *v22 = *v22 + v9;
        v23 = sourceLayout->mMapAsMonoChannels[v20++].mChannelIndex;
        matrix[matrixHop + v23] = matrix[matrixHop + v23] + v12;
      }
      while ( sourceLayout->mMapAsMonoChannelCount > v21 );
      return 0;
    }
    return 0;
  }
  if ( sourceLayout->mSortedPositionableSpeakerCount == 1 )
  {
    v25 = &matrix[sourceLayout->mSortedPositionableSpeakers->mChannelIndex];
    *v25 = v9 + *v25;
    v26 = &matrix[sourceLayout->mSortedPositionableSpeakers->mChannelIndex + matrixHop];
    *v26 = v12 + *v26;
    return 0;
  }
  if ( sourceLayout->mSortedPositionableSpeakerCount <= 1 )
    return 0;
  memset(m, 0, 0x100u);
  FMOD::ChannelLayout::sumVBAP(sourceLayout, -90.0, 180.0, v9 * 1.4142135, 1, 2, m, v12);
  FMOD::ChannelLayout::sumVBAP(sourceLayout, 90.0, 180.0, 1.4142135 * v12, 1, 2, &m[1], v12);
  v24 = 0;
  if ( sourceLayout->mChannelCount <= 0 )
    return 0;
  do
  {
    matrix[v24] = matrix[v24] + m[2 * v24];
    matrix[matrixHop + v24] = matrix[matrixHop + v24] + m[2 * v24 + 1];
    ++v24;
  }
  while ( sourceLayout->mChannelCount > (int)v24 );
  return 0;
}


// Address: 0x21dcf70 | Name: _ZN4FMOD13ChannelLayout21sumSurroundMatrixMonoEPKS0_ffffiPf
__int64 __fastcall FMOD::ChannelLayout::sumSurroundMatrixMono(
        const FMOD::ChannelLayout *targetLayout,
        float direction,
        float extent,
        float lowFrequencyGain,
        float overallGain,
        int matrixHop,
        float *matrix)
{
  int mLowFrequencyChannelIndex; // eax

  FMOD::ChannelLayout::sumVBAP(targetLayout, direction, extent, overallGain, 1, matrixHop, matrix, overallGain);
  mLowFrequencyChannelIndex = targetLayout->mLowFrequencyChannelIndex;
  if ( mLowFrequencyChannelIndex != -1 )
    matrix[matrixHop * mLowFrequencyChannelIndex] = (float)(overallGain * lowFrequencyGain)
                                                  + matrix[matrixHop * mLowFrequencyChannelIndex];
  return 0;
}


// Address: 0x21dcfe0 | Name: _ZN4FMOD13ChannelLayout29sumStereoChannelToSurroundPanEPKS0_ffffbfiPf
void __fastcall FMOD::ChannelLayout::sumStereoChannelToSurroundPan(
        const FMOD::ChannelLayout *targetLayout,
        float relativeRotation,
        float relativeExtent,
        float direction,
        float extent,
        bool normalise,
        float overallGain,
        int hopsize,
        float *matrix)
{
  FMOD::ChannelLayout::sumVBAP(
    targetLayout,
    (float)(relativeRotation * (float)(extent / 360.0)) + direction,
    relativeExtent * (float)(extent / 360.0),
    (float)(relativeExtent / 180.0) * overallGain,
    normalise,
    hopsize,
    matrix,
    extent / 360.0);
}


// Address: 0x21dd010 | Name: _ZN4FMOD13ChannelLayout25sumStereoToSurroundMatrixEPKS0_fffffiPf
__int64 __fastcall FMOD::ChannelLayout::sumStereoToSurroundMatrix(
        const FMOD::ChannelLayout *targetLayout,
        float direction,
        float extent,
        float rotation,
        float lowFrequencyGain,
        float overallGain,
        int matrixHop,
        float *matrix)
{
  __int64 v11; // rax
  int v12; // edi
  float v13; // xmm0_4
  int v14; // ecx
  int mChannelIndex; // esi
  float *v16; // r9
  int mLowFrequencyChannelIndex; // eax
  float v18; // xmm0_4
  float *v19; // rax
  float v21; // xmm0_4
  float relativeRotation; // [rsp+14h] [rbp-B4h]
  float relativeRotationa; // [rsp+14h] [rbp-B4h]
  float workingMatrix[42]; // [rsp+20h] [rbp-A8h] BYREF

  if ( targetLayout->mSortedPositionableSpeakerCount || targetLayout->mMapAsStereoPairCount )
  {
    v21 = FMOD::wrap(rotation - direction, -180.0, 180.0, lowFrequencyGain);
    if ( v21 < 0.0 )
    {
      relativeRotationa = v21;
      FMOD::ChannelLayout::clearMatrix(1, targetLayout->mChannelCount, 1, workingMatrix);
      FMOD::ChannelLayout::sumStereoChannelToSurroundPan(
        targetLayout,
        (float)(relativeRotationa - 180.0) * 0.5,
        relativeRotationa + 180.0,
        direction,
        extent,
        0,
        overallGain,
        1,
        workingMatrix);
      FMOD::ChannelLayout::sumStereoChannelToSurroundPan(
        targetLayout,
        (float)(0.5 * relativeRotationa) + 180.0,
        -relativeRotationa,
        direction,
        extent,
        0,
        overallGain,
        1,
        workingMatrix);
      FMOD::normaliseSourceGainsAndSum(targetLayout->mChannelCount, overallGain, 1, workingMatrix, matrixHop, matrix);
    }
    else
    {
      FMOD::ChannelLayout::sumStereoChannelToSurroundPan(
        targetLayout,
        v21 - 90.0,
        180.0,
        direction,
        extent,
        1,
        overallGain,
        matrixHop,
        matrix);
    }
    if ( v21 <= 0.0 )
    {
      FMOD::ChannelLayout::sumStereoChannelToSurroundPan(
        targetLayout,
        v21 + 90.0,
        180.0,
        direction,
        extent,
        1,
        overallGain,
        matrixHop,
        matrix + 1);
    }
    else
    {
      relativeRotation = v21;
      FMOD::ChannelLayout::clearMatrix(1, targetLayout->mChannelCount, 1, workingMatrix);
      FMOD::ChannelLayout::sumStereoChannelToSurroundPan(
        targetLayout,
        (float)(relativeRotation + 180.0) * 0.5,
        180.0 - relativeRotation,
        direction,
        extent,
        0,
        overallGain,
        1,
        workingMatrix);
      FMOD::ChannelLayout::sumStereoChannelToSurroundPan(
        targetLayout,
        (float)(0.5 * relativeRotation) - 180.0,
        relativeRotation,
        direction,
        extent,
        0,
        overallGain,
        1,
        workingMatrix);
      FMOD::normaliseSourceGainsAndSum(
        targetLayout->mChannelCount,
        overallGain,
        1,
        workingMatrix,
        matrixHop,
        matrix + 1);
    }
  }
  else if ( targetLayout->mMapAsMonoChannelCount > 0 )
  {
    v11 = 0;
    v12 = 0;
    v13 = overallGain / 1.4142135;
    do
    {
      ++v12;
      v14 = matrixHop * targetLayout->mMapAsMonoChannels[v11].mChannelIndex;
      matrix[v14] = matrix[v14] + v13;
      mChannelIndex = targetLayout->mMapAsMonoChannels[v11++].mChannelIndex;
      v16 = &matrix[matrixHop * mChannelIndex + 1];
      *v16 = *v16 + v13;
    }
    while ( targetLayout->mMapAsMonoChannelCount > v12 );
  }
  mLowFrequencyChannelIndex = targetLayout->mLowFrequencyChannelIndex;
  if ( mLowFrequencyChannelIndex != -1 )
  {
    v18 = (float)(overallGain * lowFrequencyGain) / 1.4142135;
    matrix[matrixHop * mLowFrequencyChannelIndex] = matrix[matrixHop * mLowFrequencyChannelIndex] + v18;
    v19 = &matrix[targetLayout->mLowFrequencyChannelIndex * matrixHop + 1];
    *v19 = v18 + *v19;
  }
  return 0;
}


// Address: 0x21dd3c0 | Name: _ZN4FMOD13ChannelLayout17sumSurroundMatrixEPKS0_S2_fffffiPf27FMOD_DSP_PAN_SURROUND_FLAGS
__int64 __fastcall FMOD::ChannelLayout::sumSurroundMatrix(
        const FMOD::ChannelLayout *sourceLayout,
        const FMOD::ChannelLayout *targetLayout,
        float direction,
        float extent,
        __m128 rotation,
        float lowFrequencyGain,
        float overallGain,
        int matrixHop,
        float *matrix,
        FMOD_DSP_PAN_SURROUND_FLAGS flags)
{
  int mSortedPositionableSpeakerCount; // eax
  int v14; // edx
  __m128 v15; // xmm0
  __int32 v16; // xmm1_4
  float v17; // xmm0_4
  __int64 v18; // r15
  __int64 v19; // r14
  FMOD::PositionableSpeaker *mSpeakerA; // rax
  float v21; // xmm0_4
  int v22; // eax
  FMOD::PositionableSpeaker *v23; // rcx
  float mExtent; // xmm1_4
  float mAzimuth; // xmm3_4
  __int64 v26; // r15
  int i; // r14d
  int v28; // ecx
  __int64 mLowFrequencyChannelIndex; // rdx
  int v30; // eax
  float *v31; // rax
  __int64 v33; // r14
  int v34; // r15d
  int mChannelIndex; // eax
  int v36; // esi
  int v37; // eax
  int v38; // eax
  int mMapAsStereoPairCount; // eax
  __int64 v40; // r15
  int v41; // r14d
  float v42; // xmm2_4
  float v45; // [rsp+10h] [rbp-E8h]
  float rotationa; // [rsp+14h] [rbp-E4h]
  float inMatrix; // [rsp+18h] [rbp-E0h]
  char flagsa; // [rsp+24h] [rbp-D4h]
  float lowFrequencyGaina; // [rsp+28h] [rbp-D0h]
  float gain; // [rsp+2Ch] [rbp-CCh]
  float g; // [rsp+30h] [rbp-C8h]
  float relativeRotationAngle; // [rsp+34h] [rbp-C4h]
  int sourceIndexAtRotation; // [rsp+38h] [rbp-C0h]
  float sourceRotationFraction; // [rsp+3Ch] [rbp-BCh]
  float workingMatrix[46]; // [rsp+40h] [rbp-B8h] BYREF

  mSortedPositionableSpeakerCount = targetLayout->mSortedPositionableSpeakerCount;
  flagsa = flags;
  rotationa = rotation.m128_f32[0];
  lowFrequencyGaina = lowFrequencyGain;
  if ( mSortedPositionableSpeakerCount || targetLayout->mMapAsStereoPairCount )
  {
    v14 = sourceLayout->mSortedPositionableSpeakerCount;
    if ( !v14 )
    {
      if ( sourceLayout->mMapAsStereoPairCount )
      {
        if ( sourceLayout->mMapAsStereoPairCount > 0 )
        {
          v33 = 0;
          v34 = 0;
          do
          {
            lowFrequencyGain = 0.0;
            mChannelIndex = sourceLayout->mMapAsStereoLeftChannels[v33].mChannelIndex;
            v36 = matrixHop * (sourceLayout->mMapAsStereoRightChannels[v33].mChannelIndex - mChannelIndex);
            if ( sourceLayout->mLowFrequencyChannelIndex == -1 )
            {
              lowFrequencyGain = lowFrequencyGaina;
              if ( targetLayout->mLowFrequencyChannelIndex == -1 )
                lowFrequencyGain = 0.0;
            }
            ++v34;
            ++v33;
            FMOD::ChannelLayout::sumStereoToSurroundMatrix(
              targetLayout,
              direction,
              extent,
              rotation.m128_f32[0],
              lowFrequencyGain,
              overallGain,
              v36,
              &matrix[mChannelIndex]);
          }
          while ( sourceLayout->mMapAsStereoPairCount > v34 );
        }
      }
      else if ( sourceLayout->mMapAsMonoChannelCount > 0 )
      {
        v40 = 0;
        v41 = 0;
        do
        {
          v42 = 0.0;
          if ( sourceLayout->mLowFrequencyChannelIndex == -1 )
          {
            v42 = lowFrequencyGaina;
            if ( targetLayout->mLowFrequencyChannelIndex == -1 )
              v42 = 0.0;
          }
          lowFrequencyGain = overallGain;
          ++v41;
          FMOD::ChannelLayout::sumSurroundMatrixMono(
            targetLayout,
            direction,
            extent,
            v42,
            overallGain,
            matrixHop,
            &matrix[sourceLayout->mMapAsMonoChannels[v40++].mChannelIndex]);
        }
        while ( sourceLayout->mMapAsMonoChannelCount > v41 );
      }
      goto LABEL_38;
    }
    v15 = (__m128)rotation.m128_u32[0];
    lowFrequencyGain = NAN;
    v15.m128_f32[0] = (float)(rotation.m128_f32[0] / 360.0) * (float)v14;
    v16 = v15.m128_i32[0];
    rotation = _mm_and_ps(v15, (__m128)0x7FFFFFFFu);
    if ( rotation.m128_f32[0] < 8388608.0 )
    {
      lowFrequencyGain = _mm_andnot_ps((__m128)0x7FFFFFFFu, v15).m128_f32[0];
      rotation.m128_f32[0] = (float)(int)v15.m128_f32[0];
      rotation.m128_f32[0] = rotation.m128_f32[0] - COERCE_FLOAT(_mm_cmpgt_ss(rotation, v15).m128_u32[0] & 0x3F800000);
      v16 = rotation.m128_i32[0] | LODWORD(lowFrequencyGain);
    }
    sourceIndexAtRotation = (int)*(float *)&v16;
    sourceRotationFraction = v15.m128_f32[0] - (float)(int)*(float *)&v16;
    v17 = 1.0;
    if ( !mSortedPositionableSpeakerCount )
    {
      mMapAsStereoPairCount = targetLayout->mMapAsStereoPairCount;
      if ( mMapAsStereoPairCount )
        v17 = fsqrt((float)mMapAsStereoPairCount);
    }
    if ( v14 > 0 )
    {
      v18 = 0;
      v19 = 0;
      gain = v17 * overallGain;
      v45 = extent / 360.0;
      while ( v14 != 1 )
      {
        if ( (flagsa & 1) != 0 )
        {
          mSpeakerA = sourceLayout->mSpeakerPairs[v19].mSpeakerA;
          goto LABEL_10;
        }
        v22 = FMOD::wrap(sourceIndexAtRotation + v19, 0, v14);
        v23 = &sourceLayout->mSortedPositionableSpeakers[v22];
        mExtent = sourceLayout->mSpeakerPairs[v22].mExtent;
        mAzimuth = v23->mAzimuth;
        if ( mExtent >= 180.0 )
        {
          inMatrix = v23->mAzimuth;
          v37 = FMOD::wrap(v22 + 1, 0, sourceLayout->mSortedPositionableSpeakerCount);
          mAzimuth = inMatrix;
          mExtent = FMOD::wrap(sourceLayout->mSortedPositionableSpeakers[v37].mAzimuth - inMatrix, 0.0, 360.0, inMatrix);
        }
        lowFrequencyGain = FMOD::wrap(
                             (float)(mAzimuth - direction) + (float)(mExtent * sourceRotationFraction),
                             -180.0,
                             180.0,
                             mAzimuth - direction);
        if ( lowFrequencyGain < -150.0 )
        {
LABEL_20:
          g = (float)(lowFrequencyGain + 210.0) / 60.0;
          FMOD::ChannelLayout::clearMatrix(1, targetLayout->mChannelCount, 1, workingMatrix);
          FMOD::ChannelLayout::sumVBAP(
            targetLayout,
            (float)(v45 * lowFrequencyGain) + direction,
            0.0,
            g,
            0,
            1,
            workingMatrix,
            lowFrequencyGain);
          v21 = lowFrequencyGain + 360.0;
          goto LABEL_13;
        }
LABEL_11:
        if ( lowFrequencyGain <= 150.0 )
        {
          lowFrequencyGain = lowFrequencyGain * v45;
          rotation.m128_f32[0] = overallGain;
          FMOD::ChannelLayout::sumVBAP(
            targetLayout,
            direction + lowFrequencyGain,
            0.0,
            overallGain,
            1,
            matrixHop,
            &matrix[sourceLayout->mSortedPositionableSpeakers[v18].mChannelIndex],
            lowFrequencyGain);
          goto LABEL_14;
        }
        relativeRotationAngle = lowFrequencyGain;
        g = (float)(210.0 - lowFrequencyGain) / 60.0;
        FMOD::ChannelLayout::clearMatrix(1, targetLayout->mChannelCount, 1, workingMatrix);
        FMOD::ChannelLayout::sumVBAP(
          targetLayout,
          (float)(v45 * relativeRotationAngle) + direction,
          0.0,
          g,
          0,
          1,
          workingMatrix,
          relativeRotationAngle);
        lowFrequencyGain = lowFrequencyGain - 360.0;
        v21 = relativeRotationAngle - 360.0;
LABEL_13:
        rotation.m128_f32[0] = 1.0 - g;
        FMOD::ChannelLayout::sumVBAP(
          targetLayout,
          (float)(v21 * v45) + direction,
          0.0,
          1.0 - g,
          0,
          1,
          workingMatrix,
          lowFrequencyGain);
        FMOD::normaliseSourceGainsAndSum(
          targetLayout->mChannelCount,
          gain,
          1,
          workingMatrix,
          matrixHop,
          &matrix[sourceLayout->mSortedPositionableSpeakers[v18].mChannelIndex]);
LABEL_14:
        v14 = sourceLayout->mSortedPositionableSpeakerCount;
        ++v18;
        if ( v14 <= (int)++v19 )
          goto LABEL_23;
      }
      mSpeakerA = sourceLayout->mSortedPositionableSpeakers;
LABEL_10:
      lowFrequencyGain = FMOD::wrap(
                           (float)(mSpeakerA->mAzimuth - direction) + rotationa,
                           -180.0,
                           180.0,
                           lowFrequencyGain);
      if ( lowFrequencyGain < -150.0 )
        goto LABEL_20;
      goto LABEL_11;
    }
  }
  else
  {
    v26 = 0;
    for ( i = 0; targetLayout->mMapAsMonoChannelCount > i; ++i )
    {
      v28 = targetLayout->mMapAsMonoChannels[v26++].mChannelIndex;
      FMOD::ChannelLayout::sumMonoMatrix(sourceLayout, 0.0, overallGain, rotation.m128_f32[0], &matrix[matrixHop * v28]);
    }
  }
LABEL_23:
  mLowFrequencyChannelIndex = sourceLayout->mLowFrequencyChannelIndex;
  if ( (_DWORD)mLowFrequencyChannelIndex == -1 )
  {
    v38 = targetLayout->mLowFrequencyChannelIndex;
    if ( v38 == -1 )
      return 0;
    FMOD::ChannelLayout::sumMonoMatrix(
      sourceLayout,
      0.0,
      lowFrequencyGaina * overallGain,
      rotation.m128_f32[0],
      &matrix[matrixHop * v38]);
LABEL_38:
    mLowFrequencyChannelIndex = sourceLayout->mLowFrequencyChannelIndex;
    if ( (_DWORD)mLowFrequencyChannelIndex == -1 )
      return 0;
    v30 = targetLayout->mLowFrequencyChannelIndex;
    if ( v30 != -1 )
      goto LABEL_25;
LABEL_40:
    FMOD::ChannelLayout::sumVBAP(
      targetLayout,
      direction,
      extent,
      lowFrequencyGaina * overallGain,
      1,
      matrixHop,
      &matrix[mLowFrequencyChannelIndex],
      lowFrequencyGain);
    return 0;
  }
  v30 = targetLayout->mLowFrequencyChannelIndex;
  if ( v30 == -1 )
    goto LABEL_40;
LABEL_25:
  v31 = &matrix[v30 * matrixHop + (int)mLowFrequencyChannelIndex];
  *v31 = (float)(lowFrequencyGaina * overallGain) + *v31;
  return 0;
}


// Address: 0x21dda90 | Name: _ZN4FMOD13ChannelLayout16sumDefaultMatrixEPKS0_S2_fiPf
__int64 __fastcall FMOD::ChannelLayout::sumDefaultMatrix(
        const FMOD::ChannelLayout *sourceLayout,
        const FMOD::ChannelLayout *targetLayout,
        float overallGain,
        int matrixHop,
        float *matrix,
        double a6,
        float a7)
{
  float v7; // xmm4_4
  float *v8; // r13
  __int64 v11; // r14
  int v12; // r15d
  __int64 result; // rax
  int mMapAsStereoPairCount; // eax
  FMOD::PositionableSpeaker *mFrontLeftSpeaker; // rsi
  FMOD::PositionableSpeaker *mFrontRightSpeaker; // rdx
  __int64 v17; // rax
  int v18; // ecx
  int mChannelIndex; // edx
  float *v20; // rdx
  FMOD::PositionableSpeaker *v21; // rsi
  int v22; // edx
  int v23; // edx
  float v24; // xmm3_4
  __int64 v25; // r14
  int v26; // r15d
  int v27; // eax
  __int64 v28; // rdx
  float v29; // [rsp+Ch] [rbp-3Ch]
  float v30; // [rsp+Ch] [rbp-3Ch]

  v7 = overallGain;
  v8 = matrix;
  if ( sourceLayout == targetLayout )
  {
    if ( sourceLayout->mChannelCount > 0 )
    {
      v27 = 0;
      v28 = 4LL * (matrixHop + 1);
      do
      {
        ++v27;
        *v8 = *v8 + overallGain;
        v8 = (float *)((char *)v8 + v28);
      }
      while ( sourceLayout->mChannelCount > v27 );
      return 0;
    }
    return 0;
  }
  if ( targetLayout->mSortedPositionableSpeakerCount )
  {
    if ( sourceLayout->mSortedPositionableSpeakerCount
      || (mMapAsStereoPairCount = sourceLayout->mMapAsStereoPairCount) == 0
      || (mFrontLeftSpeaker = targetLayout->mFrontLeftSpeaker) == 0
      || mFrontLeftSpeaker->mChannelIndex < 0
      || (mFrontRightSpeaker = targetLayout->mFrontRightSpeaker) == 0
      || mFrontRightSpeaker->mChannelIndex < 0 )
    {
      if ( sourceLayout->mLowFrequencyChannelIndex == -1 || (v24 = 1.0, targetLayout->mLowFrequencyChannelIndex == -1) )
        v24 = 0.0;
      return FMOD::ChannelLayout::sumSurroundMatrix(
               sourceLayout,
               targetLayout,
               0.0,
               360.0,
               (__m128)0LL,
               v24,
               overallGain,
               matrixHop,
               matrix,
               FMOD_DSP_PAN_SURROUND_FLAGS::FMOD_DSP_PAN_SURROUND_DEFAULT);
    }
    if ( mMapAsStereoPairCount > 0 )
    {
      v17 = 0;
      v18 = 0;
      while ( 1 )
      {
        mChannelIndex = -1;
        if ( mFrontLeftSpeaker )
          mChannelIndex = mFrontLeftSpeaker->mChannelIndex;
        v20 = &v8[sourceLayout->mMapAsStereoLeftChannels[v17].mChannelIndex + matrixHop * mChannelIndex];
        *v20 = *v20 + overallGain;
        v21 = targetLayout->mFrontRightSpeaker;
        v22 = -1;
        if ( v21 )
          v22 = v21->mChannelIndex;
        ++v18;
        v23 = sourceLayout->mMapAsStereoRightChannels[v17++].mChannelIndex + matrixHop * v22;
        v8[v23] = v8[v23] + overallGain;
        if ( sourceLayout->mMapAsStereoPairCount <= v18 )
          break;
        mFrontLeftSpeaker = targetLayout->mFrontLeftSpeaker;
      }
    }
    return 0;
  }
  if ( targetLayout->mMapAsStereoPairCount )
  {
    if ( targetLayout->mMapAsStereoPairCount > 0 )
    {
      v11 = 0;
      v12 = 0;
      while ( 1 )
      {
        v29 = v7;
        result = FMOD::ChannelLayout::sumStereoMatrix(
                   sourceLayout,
                   0.0,
                   1.0,
                   v7,
                   (4LL * matrixHop * targetLayout->mMapAsStereoRightChannels[v11].mChannelIndex
                  - 4LL * matrixHop * targetLayout->mMapAsStereoLeftChannels[v11].mChannelIndex) >> 2,
                   &v8[matrixHop * targetLayout->mMapAsStereoLeftChannels[v11].mChannelIndex]);
        if ( (_DWORD)result )
          break;
        ++v12;
        ++v11;
        v7 = v29;
        if ( targetLayout->mMapAsStereoPairCount <= v12 )
          return 0;
      }
      return result;
    }
    return 0;
  }
  if ( targetLayout->mMapAsMonoChannelCount <= 0 )
    return 0;
  v25 = 0;
  v26 = 0;
  while ( 1 )
  {
    v30 = v7;
    result = FMOD::ChannelLayout::sumMonoMatrix(
               sourceLayout,
               1.0,
               v7,
               a7,
               &v8[matrixHop * targetLayout->mMapAsMonoChannels[v25].mChannelIndex]);
    if ( (_DWORD)result )
      break;
    ++v26;
    ++v25;
    v7 = v30;
    if ( targetLayout->mMapAsMonoChannelCount <= v26 )
      return 0;
  }
  return result;
}


// Address: 0x21ddd70 | Name: _ZN4FMOD14getRolloffGainE28FMOD_DSP_PAN_3D_ROLLOFF_TYPEfffPff
__int64 __fastcall FMOD::getRolloffGain(
        FMOD_DSP_PAN_3D_ROLLOFF_TYPE rolloffType,
        float a2,
        float distance,
        float minDistance,
        float maxDistance,
        float *gain,
        float scale)
{
  __int64 result; // rax
  float v8; // xmm0_4

  result = 31;
  if ( gain )
  {
    if ( distance >= a2 || maxDistance <= 0.0 )
    {
LABEL_9:
      *gain = 1.0;
      return 0;
    }
    else
    {
      if ( maxDistance != 1.0 )
        a2 = (float)((float)(a2 - distance) * maxDistance) + distance;
      switch ( rolloffType )
      {
        case FMOD_DSP_PAN_3D_ROLLOFF_LINEARSQUARED:
        case FMOD_DSP_PAN_3D_ROLLOFF_LINEAR:
          if ( a2 >= minDistance )
            goto LABEL_17;
          v8 = (float)(minDistance - a2) / (float)(minDistance - distance);
          if ( rolloffType == FMOD_DSP_PAN_3D_ROLLOFF_LINEARSQUARED )
            v8 = v8 * v8;
          *gain = v8;
          result = 0;
          break;
        case FMOD_DSP_PAN_3D_ROLLOFF_INVERSE:
          *gain = distance / fminf(a2, minDistance);
          return 0;
        case FMOD_DSP_PAN_3D_ROLLOFF_INVERSETAPERED:
          if ( a2 >= minDistance )
          {
LABEL_17:
            *gain = 0.0;
            result = 0;
          }
          else
          {
            *gain = fminf(
                      distance / a2,
                      (float)((float)(minDistance - a2) / (float)(minDistance - distance))
                    * (float)((float)(minDistance - a2) / (float)(minDistance - distance)));
            result = 0;
          }
          break;
        case FMOD_DSP_PAN_3D_ROLLOFF_CUSTOM:
          goto LABEL_9;
        default:
          result = 0;
          break;
      }
    }
  }
  return result;
}


// Address: 0x21dde60 | Name: _ZN4FMOD13ChannelLayout20speakerConfigurationE16FMOD_SPEAKERMODEPiPPKNS_17FMOD_CHANNEL_TYPEEPPKfPPK12FMOD_SPEAKER
void __fastcall FMOD::ChannelLayout::speakerConfiguration(
        FMOD_SPEAKERMODE_0 mode,
        int *count_in,
        const FMOD::FMOD_CHANNEL_TYPE **types_in,
        const float **directions_in,
        const FMOD_SPEAKER_1 **speakers_in)
{
  if ( count_in )
    *count_in = stru_29B0FC0[mode].count;
  if ( types_in )
    *types_in = stru_29B0FC0[mode].types;
  if ( directions_in )
    *directions_in = stru_29B0FC0[mode].directions;
  if ( speakers_in )
    *speakers_in = stru_29B0FC0[mode].speakers;
}


// Address: 0x21dded0 | Name: _ZN4FMOD13ChannelLayout23speakerMaskToLayoutMaskEj16FMOD_SPEAKERMODE
unsigned int __fastcall FMOD::ChannelLayout::speakerMaskToLayoutMask(
        unsigned int speakerMask,
        FMOD_SPEAKERMODE_0 speakerMode)
{
  unsigned int result; // eax

  result = speakerMask;
  if ( speakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_QUAD_0 )
    return (speakerMask >> 2) & 4 | speakerMask & 3 | (speakerMask >> 2) & 8;
  if ( speakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    return (speakerMask >> 1) & 8 | speakerMask & 7 | (speakerMask >> 1) & 0x10;
  return result;
}


