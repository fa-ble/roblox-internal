// Address: 0x21fa810 | Name: _ZN4FMOD8ListenerC2Ev
void __fastcall FMOD::Listener::Listener(FMOD::Listener *const this)
{
  this->mUp.y = 1.0;
  this->mPosition.x = 0.0;
  this->mPosition.y = 0.0;
  this->mPosition.z = 0.0;
  this->mLastPosition.x = 0.0;
  this->mLastPosition.y = 0.0;
  this->mLastPosition.z = 0.0;
  this->mVelocity.x = 0.0;
  this->mVelocity.y = 0.0;
  this->mVelocity.z = 0.0;
  this->mUp.x = 0.0;
  this->mUp.z = 0.0;
  this->mFront.x = 0.0;
  this->mFront.y = 0.0;
  this->mFront.z = 1.0;
  this->mRight.x = 1.0;
  this->mRight.y = 0.0;
  this->mRight.z = 0.0;
}


