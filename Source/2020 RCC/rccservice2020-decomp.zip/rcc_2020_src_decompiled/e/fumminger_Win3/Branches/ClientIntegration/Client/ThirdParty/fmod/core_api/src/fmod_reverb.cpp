// Address: 0x21fee10 | Name: _ZN4FMOD8Reverb3D7releaseEv
FMOD_RESULT_0 __fastcall FMOD::Reverb3D::release(FMOD::Reverb3D *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-11Ch]
  FMOD::ReverbI *reverbi; // [rsp+18h] [rbp-110h] BYREF
  char _buffer[264]; // [rsp+20h] [rbp-108h] BYREF

  result = FMOD::ReverbI::validate(this, &reverbi);
  if ( (result || (result = FMOD::ReverbI::release(reverbi, 1)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = result;
    _buffer[0] = 0;
    FMOD_ReportError(
      result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_REVERB3D,
      this,
      "Reverb3D::release",
      _buffer);
    return __result;
  }
  return result;
}


// Address: 0x21feea0 | Name: _ZN4FMOD8Reverb3D15set3DAttributesEPK11FMOD_VECTORff
FMOD_RESULT_0 __fastcall FMOD::Reverb3D::set3DAttributes(
        FMOD::Reverb3D *const this,
        const FMOD_VECTOR *position,
        float a3,
        float mindistance,
        float maxdistance)
{
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 __result; // [rsp+8h] [rbp-130h]
  FMOD::ReverbI *reverbi; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  result = FMOD::ReverbI::validate(this, &reverbi);
  if ( (result
     || (result = (unsigned int)FMOD::ReverbI::set3DAttributes(reverbi, position, a3, mindistance, maxdistance)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    __result = result;
    _buffer[0] = 0;
    FMOD_ReportError(
      result,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_REVERB3D,
      this,
      "Reverb3D::set3DAttributes",
      _buffer);
    return __result;
  }
  return result;
}


// Address: 0x21fef50 | Name: _ZN4FMOD8Reverb3D15get3DAttributesEP11FMOD_VECTORPfS3_
FMOD_RESULT_0 __fastcall FMOD::Reverb3D::get3DAttributes(
        FMOD::Reverb3D *const this,
        FMOD_VECTOR *position,
        float *mindistance,
        float *maxdistance)
{
  FMOD_RESULT_0 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::ReverbI *reverbi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  v6 = FMOD::ReverbI::validate(this, &reverbi);
  if ( (v6
     || (v6 = FMOD::ReverbI::get3DAttributes(reverbi, position, mindistance, maxdistance)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v11 = FMOD::FMOD_FormatArg(_buffer, 256, position);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
    v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), mindistance);
    v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), maxdistance);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_REVERB3D,
      this,
      "Reverb3D::get3DAttributes",
      _buffer);
  }
  return v6;
}


// Address: 0x21ff080 | Name: _ZN4FMOD8Reverb3D13setPropertiesEPK22FMOD_REVERB_PROPERTIES
FMOD_RESULT_0 __fastcall FMOD::Reverb3D::setProperties(
        FMOD::Reverb3D *const this,
        const FMOD_REVERB_PROPERTIES *properties)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::ReverbI *reverbi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::ReverbI::validate(this, &reverbi);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = FMOD::ReverbI::setProperties(reverbi, properties);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, properties);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_REVERB3D,
      this,
      "Reverb3D::setProperties",
      _buffer);
  }
  return v2;
}


// Address: 0x21ff140 | Name: _ZN4FMOD8Reverb3D13getPropertiesEP22FMOD_REVERB_PROPERTIES
FMOD_RESULT_0 __fastcall FMOD::Reverb3D::getProperties(FMOD::Reverb3D *const this, FMOD_REVERB_PROPERTIES *properties)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::ReverbI *reverbi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::ReverbI::validate(this, &reverbi);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = FMOD::ReverbI::getProperties(reverbi, properties);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, properties);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_REVERB3D,
      this,
      "Reverb3D::getProperties",
      _buffer);
  }
  return v2;
}


// Address: 0x21ff200 | Name: _ZN4FMOD8Reverb3D9setActiveEb
FMOD_RESULT_0 __fastcall FMOD::Reverb3D::setActive(FMOD::Reverb3D *const this, bool active)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::ReverbI *reverbi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::ReverbI::validate(this, &reverbi);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = FMOD::ReverbI::setActive(reverbi, active);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, active);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_REVERB3D,
      this,
      "Reverb3D::setActive",
      _buffer);
  }
  return v2;
}


// Address: 0x21ff2c0 | Name: _ZN4FMOD8Reverb3D9getActiveEPb
FMOD_RESULT_0 __fastcall FMOD::Reverb3D::getActive(FMOD::Reverb3D *const this, bool *active)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::ReverbI *reverbi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::ReverbI::validate(this, &reverbi);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = FMOD::ReverbI::getActive(reverbi, active);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, active);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_REVERB3D,
      this,
      "Reverb3D::getActive",
      _buffer);
  }
  return v2;
}


// Address: 0x21ff380 | Name: _ZN4FMOD8Reverb3D11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::Reverb3D::setUserData(FMOD::Reverb3D *const this, void *_userdata)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::ReverbI *reverbi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::ReverbI::validate(this, &reverbi);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = FMOD::ReverbI::setUserData(reverbi, _userdata);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_REVERB3D,
      this,
      "Reverb3D::setUserData",
      _buffer);
  }
  return v2;
}


// Address: 0x21ff440 | Name: _ZN4FMOD8Reverb3D11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::Reverb3D::getUserData(FMOD::Reverb3D *const this, void **_userdata)
{
  FMOD_RESULT_0 UserData; // ebx
  FMOD::ReverbI *reverbi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  UserData = FMOD::ReverbI::validate(this, &reverbi);
  if ( UserData == FMOD_RESULT::FMOD_OK_0 )
  {
    UserData = FMOD::ReverbI::getUserData(reverbi, _userdata);
    if ( UserData == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      UserData,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_REVERB3D,
      this,
      "Reverb3D::getUserData",
      _buffer);
  }
  return UserData;
}


