// Address: 0x21cdee0 | Name: _ZNK4FMOD17ProfileRemoteFile7getTypeEv
unsigned __int8 __fastcall FMOD::ProfileRemoteFile::getType(const FMOD::ProfileRemoteFile *const this)
{
  return 10;
}


// Address: 0x21cdef0 | Name: _ZNK4FMOD17ProfileRemoteFile12hasAsyncReadEv
bool __fastcall FMOD::ProfileRemoteFile::hasAsyncRead(const FMOD::ProfileRemoteFile *const this)
{
  return 1;
}


// Address: 0x21cdf00 | Name: _ZNK4FMOD17ProfileRemoteFile17getNextPacketInfoEPNS_10PacketInfoE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::getNextPacketInfo(
        const FMOD::ProfileRemoteFile *const this,
        FMOD::PacketInfo *info)
{
  info->type = -1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cdf10 | Name: _ZN4FMOD17ProfileRemoteFile13getNextPacketEPNS_7Profile17PacketWriteHandleE
FMOD_RESULT_0 __fastcall FMOD::ProfileRemoteFile::getNextPacket(
        FMOD::ProfileRemoteFile *const this,
        FMOD::Profile::PacketWriteHandle *handle)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ce660 | Name: _ZN4FMOD17ProfileRemoteFileD2Ev
void __fastcall FMOD::ProfileRemoteFile::~ProfileRemoteFile(FMOD::ProfileRemoteFile *const this)
{
  bool v2; // zf
  bool v3; // cc
  __int64 mSize; // rdi
  int mCapacity; // eax
  bool v6; // cc
  bool v7; // cc
  __int64 v8; // rdi
  int v9; // eax
  bool v10; // cc
  __int64 v11; // rdi
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v12; // rsi
  int v13; // eax
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v14; // rsi
  unsigned int *v15; // rsi
  unsigned int *mData; // rsi
  unsigned int *v17; // rsi
  unsigned int *v18; // rsi
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v19; // rsi
  __int64 v20; // rdi
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v21; // rsi

  this->mRemoteFiles.mBuckets.mSize = 0;
  v2 = this->mRemoteFiles.mBuckets.mCapacity == 0;
  v3 = this->mRemoteFiles.mBuckets.mCapacity <= 0;
  this->_vptr_ProfileModule = (int (**)(...))off_29B0F30;
  if ( !v2 )
  {
    if ( !v3 )
    {
      mData = this->mRemoteFiles.mBuckets.mData;
      if ( mData )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mData, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mRemoteFiles.mBuckets.mData = 0;
    this->mRemoteFiles.mBuckets.mCapacity = 0;
  }
  mSize = this->mRemoteFiles.mNodes.mSize;
  if ( (int)mSize < 0 )
    memset(&this->mRemoteFiles.mNodes.mData[mSize], 0, 16LL * -this->mRemoteFiles.mNodes.mSize);
  mCapacity = this->mRemoteFiles.mNodes.mCapacity;
  this->mRemoteFiles.mNodes.mSize = 0;
  if ( !mCapacity )
  {
    this->mRemoteFiles.mFreeList = -1;
    this->mRemoteFiles.mNodeCount = 0;
LABEL_6:
    this->mRemoteFiles.mNodes.mSize = 0;
    goto LABEL_7;
  }
  v11 = 0;
  if ( mCapacity > 0 )
  {
    v12 = this->mRemoteFiles.mNodes.mData;
    if ( v12 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v12, "../../../core_api/src/fmod_memory.h", 244);
      v11 = this->mRemoteFiles.mNodes.mSize;
    }
  }
  this->mRemoteFiles.mNodes.mData = 0;
  this->mRemoteFiles.mNodes.mCapacity = 0;
  this->mRemoteFiles.mFreeList = -1;
  this->mRemoteFiles.mNodeCount = 0;
  if ( (int)v11 >= 0 )
    goto LABEL_6;
  memset((void *)(16 * v11), 0, 16LL * -(int)v11);
  v13 = this->mRemoteFiles.mNodes.mCapacity;
  this->mRemoteFiles.mNodes.mSize = 0;
  if ( v13 )
  {
    if ( v13 > 0 )
    {
      v14 = this->mRemoteFiles.mNodes.mData;
      if ( v14 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v14, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mRemoteFiles.mNodes.mData = 0;
    this->mRemoteFiles.mNodes.mCapacity = 0;
  }
LABEL_7:
  v2 = this->mRemoteFiles.mBuckets.mCapacity == 0;
  v6 = this->mRemoteFiles.mBuckets.mCapacity <= 0;
  this->mRemoteFiles.mBuckets.mSize = 0;
  if ( v2 )
  {
    v2 = this->mLocalFiles.mBuckets.mCapacity == 0;
    v7 = this->mLocalFiles.mBuckets.mCapacity <= 0;
    this->mLocalFiles.mBuckets.mSize = 0;
    if ( v2 )
      goto LABEL_9;
  }
  else
  {
    if ( !v6 )
    {
      v17 = this->mRemoteFiles.mBuckets.mData;
      if ( v17 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v17, "../../../core_api/src/fmod_memory.h", 244);
    }
    v2 = this->mLocalFiles.mBuckets.mCapacity == 0;
    v7 = this->mLocalFiles.mBuckets.mCapacity <= 0;
    this->mRemoteFiles.mBuckets.mData = 0;
    this->mRemoteFiles.mBuckets.mCapacity = 0;
    this->mLocalFiles.mBuckets.mSize = 0;
    if ( v2 )
    {
LABEL_9:
      v8 = this->mLocalFiles.mNodes.mSize;
      if ( (int)v8 >= 0 )
        goto LABEL_10;
      goto LABEL_40;
    }
  }
  if ( !v7 )
  {
    v18 = this->mLocalFiles.mBuckets.mData;
    if ( v18 )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v18, "../../../core_api/src/fmod_memory.h", 244);
  }
  v8 = this->mLocalFiles.mNodes.mSize;
  this->mLocalFiles.mBuckets.mData = 0;
  this->mLocalFiles.mBuckets.mCapacity = 0;
  if ( (int)v8 < 0 )
LABEL_40:
    memset(&this->mLocalFiles.mNodes.mData[v8], 0, 16LL * -(int)v8);
LABEL_10:
  v9 = this->mLocalFiles.mNodes.mCapacity;
  this->mLocalFiles.mNodes.mSize = 0;
  if ( v9 )
  {
    v20 = 0;
    if ( v9 > 0 )
    {
      v21 = this->mLocalFiles.mNodes.mData;
      if ( v21 )
      {
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v21, "../../../core_api/src/fmod_memory.h", 244);
        v20 = this->mLocalFiles.mNodes.mSize;
      }
    }
    this->mLocalFiles.mNodes.mData = 0;
    this->mLocalFiles.mNodes.mCapacity = 0;
    this->mLocalFiles.mFreeList = -1;
    this->mLocalFiles.mNodeCount = 0;
    if ( (int)v20 >= 0 )
    {
      v9 = 0;
    }
    else
    {
      memset((void *)(16 * v20), 0, 16LL * -(int)v20);
      v9 = this->mLocalFiles.mNodes.mCapacity;
    }
  }
  else
  {
    this->mLocalFiles.mFreeList = -1;
    this->mLocalFiles.mNodeCount = 0;
  }
  this->mLocalFiles.mNodes.mSize = 0;
  if ( v9 )
  {
    if ( v9 > 0 )
    {
      v19 = this->mLocalFiles.mNodes.mData;
      if ( v19 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v19, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mLocalFiles.mNodes.mData = 0;
    this->mLocalFiles.mNodes.mCapacity = 0;
  }
  v2 = this->mLocalFiles.mBuckets.mCapacity == 0;
  v10 = this->mLocalFiles.mBuckets.mCapacity <= 0;
  this->mLocalFiles.mBuckets.mSize = 0;
  if ( v2 )
  {
    this->_vptr_ProfileModule = (int (**)(...))&off_29B0E90;
  }
  else
  {
    if ( !v10 )
    {
      v15 = this->mLocalFiles.mBuckets.mData;
      if ( v15 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v15, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mLocalFiles.mBuckets.mData = 0;
    this->mLocalFiles.mBuckets.mCapacity = 0;
    this->_vptr_ProfileModule = (int (**)(...))&off_29B0E90;
  }
}


// Address: 0x21ceaa0 | Name: _ZN4FMOD17ProfileRemoteFileD0Ev
void __fastcall FMOD::ProfileRemoteFile::~ProfileRemoteFile(FMOD::ProfileRemoteFile *const this)
{
  bool v2; // zf
  bool v3; // cc
  __int64 mSize; // rdi
  int mCapacity; // eax
  bool v6; // cc
  bool v7; // cc
  __int64 v8; // rdi
  int v9; // eax
  bool v10; // cc
  __int64 v11; // rdi
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v12; // rsi
  int v13; // eax
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v14; // rsi
  unsigned int *v15; // rsi
  unsigned int *mData; // rsi
  unsigned int *v17; // rsi
  unsigned int *v18; // rsi
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v19; // rsi
  __int64 v20; // rdi
  FMOD::HashMap<int,FMOD::ProfileFileEntryLocal*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryLocal*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v21; // rsi

  this->mRemoteFiles.mBuckets.mSize = 0;
  v2 = this->mRemoteFiles.mBuckets.mCapacity == 0;
  v3 = this->mRemoteFiles.mBuckets.mCapacity <= 0;
  this->_vptr_ProfileModule = (int (**)(...))off_29B0F30;
  if ( !v2 )
  {
    if ( !v3 )
    {
      mData = this->mRemoteFiles.mBuckets.mData;
      if ( mData )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mData, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mRemoteFiles.mBuckets.mData = 0;
    this->mRemoteFiles.mBuckets.mCapacity = 0;
  }
  mSize = this->mRemoteFiles.mNodes.mSize;
  if ( (int)mSize < 0 )
    memset(&this->mRemoteFiles.mNodes.mData[mSize], 0, 16LL * -this->mRemoteFiles.mNodes.mSize);
  mCapacity = this->mRemoteFiles.mNodes.mCapacity;
  this->mRemoteFiles.mNodes.mSize = 0;
  if ( !mCapacity )
  {
    this->mRemoteFiles.mFreeList = -1;
    this->mRemoteFiles.mNodeCount = 0;
LABEL_6:
    this->mRemoteFiles.mNodes.mSize = 0;
    goto LABEL_7;
  }
  v11 = 0;
  if ( mCapacity > 0 )
  {
    v12 = this->mRemoteFiles.mNodes.mData;
    if ( v12 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v12, "../../../core_api/src/fmod_memory.h", 244);
      v11 = this->mRemoteFiles.mNodes.mSize;
    }
  }
  this->mRemoteFiles.mNodes.mData = 0;
  this->mRemoteFiles.mNodes.mCapacity = 0;
  this->mRemoteFiles.mFreeList = -1;
  this->mRemoteFiles.mNodeCount = 0;
  if ( (int)v11 >= 0 )
    goto LABEL_6;
  memset((void *)(16 * v11), 0, 16LL * -(int)v11);
  v13 = this->mRemoteFiles.mNodes.mCapacity;
  this->mRemoteFiles.mNodes.mSize = 0;
  if ( v13 )
  {
    if ( v13 > 0 )
    {
      v14 = this->mRemoteFiles.mNodes.mData;
      if ( v14 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v14, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mRemoteFiles.mNodes.mData = 0;
    this->mRemoteFiles.mNodes.mCapacity = 0;
  }
LABEL_7:
  v2 = this->mRemoteFiles.mBuckets.mCapacity == 0;
  v6 = this->mRemoteFiles.mBuckets.mCapacity <= 0;
  this->mRemoteFiles.mBuckets.mSize = 0;
  if ( v2 )
  {
    v2 = this->mLocalFiles.mBuckets.mCapacity == 0;
    v7 = this->mLocalFiles.mBuckets.mCapacity <= 0;
    this->mLocalFiles.mBuckets.mSize = 0;
    if ( v2 )
      goto LABEL_9;
  }
  else
  {
    if ( !v6 )
    {
      v17 = this->mRemoteFiles.mBuckets.mData;
      if ( v17 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v17, "../../../core_api/src/fmod_memory.h", 244);
    }
    v2 = this->mLocalFiles.mBuckets.mCapacity == 0;
    v7 = this->mLocalFiles.mBuckets.mCapacity <= 0;
    this->mRemoteFiles.mBuckets.mData = 0;
    this->mRemoteFiles.mBuckets.mCapacity = 0;
    this->mLocalFiles.mBuckets.mSize = 0;
    if ( v2 )
    {
LABEL_9:
      v8 = this->mLocalFiles.mNodes.mSize;
      if ( (int)v8 >= 0 )
        goto LABEL_10;
      goto LABEL_40;
    }
  }
  if ( !v7 )
  {
    v18 = this->mLocalFiles.mBuckets.mData;
    if ( v18 )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v18, "../../../core_api/src/fmod_memory.h", 244);
  }
  v8 = this->mLocalFiles.mNodes.mSize;
  this->mLocalFiles.mBuckets.mData = 0;
  this->mLocalFiles.mBuckets.mCapacity = 0;
  if ( (int)v8 < 0 )
LABEL_40:
    memset(&this->mLocalFiles.mNodes.mData[v8], 0, 16LL * -(int)v8);
LABEL_10:
  v9 = this->mLocalFiles.mNodes.mCapacity;
  this->mLocalFiles.mNodes.mSize = 0;
  if ( v9 )
  {
    v20 = 0;
    if ( v9 > 0 )
    {
      v21 = this->mLocalFiles.mNodes.mData;
      if ( v21 )
      {
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v21, "../../../core_api/src/fmod_memory.h", 244);
        v20 = this->mLocalFiles.mNodes.mSize;
      }
    }
    this->mLocalFiles.mNodes.mData = 0;
    this->mLocalFiles.mNodes.mCapacity = 0;
    this->mLocalFiles.mFreeList = -1;
    this->mLocalFiles.mNodeCount = 0;
    if ( (int)v20 >= 0 )
    {
      v9 = 0;
    }
    else
    {
      memset((void *)(16 * v20), 0, 16LL * -(int)v20);
      v9 = this->mLocalFiles.mNodes.mCapacity;
    }
  }
  else
  {
    this->mLocalFiles.mFreeList = -1;
    this->mLocalFiles.mNodeCount = 0;
  }
  this->mLocalFiles.mNodes.mSize = 0;
  if ( v9 )
  {
    if ( v9 > 0 )
    {
      v19 = this->mLocalFiles.mNodes.mData;
      if ( v19 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v19, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mLocalFiles.mNodes.mData = 0;
    this->mLocalFiles.mNodes.mCapacity = 0;
  }
  v2 = this->mLocalFiles.mBuckets.mCapacity == 0;
  v10 = this->mLocalFiles.mBuckets.mCapacity <= 0;
  this->mLocalFiles.mBuckets.mSize = 0;
  if ( !v2 )
  {
    if ( !v10 )
    {
      v15 = this->mLocalFiles.mBuckets.mData;
      if ( v15 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v15, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mLocalFiles.mBuckets.mData = 0;
    this->mLocalFiles.mBuckets.mCapacity = 0;
  }
  this->_vptr_ProfileModule = (int (**)(...))&off_29B0E90;
  operator delete(this);
}


