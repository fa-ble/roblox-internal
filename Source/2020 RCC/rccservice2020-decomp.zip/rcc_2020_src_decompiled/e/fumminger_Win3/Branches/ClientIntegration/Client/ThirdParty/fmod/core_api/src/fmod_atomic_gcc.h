// Address: 0x2237fc0 | Name: _ZN4FMOD6Stream12setLoopCountEi
FMOD_RESULT_0 __fastcall FMOD::Stream::setLoopCount(FMOD::Stream *const this, int loopcount)
{
  if ( this->mOpenState.m_value && this->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0 )
    return FMOD_RESULT::FMOD_ERR_NOTREADY_0;
  this->mLoopCountCurrent = loopcount;
  this->mLoopCount = loopcount;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22387f0 | Name: _ZN4FMOD6Stream11getPositionEPjj
FMOD_RESULT_0 __fastcall FMOD::Stream::getPosition(
        FMOD::Stream *const this,
        unsigned int *position,
        FMOD_TIMEUNIT postype)
{
  unsigned __int64 mLastPos; // rax
  FMOD_RESULT_0 result; // eax
  __int64 v5; // rcx

  if ( this->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_READY_0
    || (result = FMOD_RESULT::FMOD_ERR_NOTREADY_0,
        this->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0) )
  {
    if ( position )
    {
      switch ( postype )
      {
        case 4u:
          mLastPos = this->mLastPos;
          switch ( this->mFormat )
          {
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
              v5 = 8;
              goto LABEL_14;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
              v5 = 16;
              goto LABEL_14;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
              v5 = 24;
              goto LABEL_14;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
              v5 = 32;
LABEL_14:
              mLastPos = (v5 * mLastPos) >> 3;
              break;
            default:
              break;
          }
          *position = this->mChannels * mLastPos;
          return FMOD_RESULT::FMOD_OK_0;
        case 2u:
          *position = this->mLastPos;
          return FMOD_RESULT::FMOD_OK_0;
        case 1u:
          *position = (int)(float)((float)((float)(int)this->mLastPos / 1000.0) * this->mDefaultFrequency);
          return FMOD_RESULT::FMOD_OK_0;
        default:
          return FMOD::Codec::getPosition(this->mCodec, position, postype);
      }
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
  }
  return result;
}


