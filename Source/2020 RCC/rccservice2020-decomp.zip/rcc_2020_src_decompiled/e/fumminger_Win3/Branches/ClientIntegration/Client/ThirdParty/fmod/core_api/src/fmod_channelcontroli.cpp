// Address: 0x220e700 | Name: _ZN4FMOD15ChannelControlI4stopEv
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::stop(FMOD::ChannelControlI *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e710 | Name: _ZN4FMOD15ChannelControlI9setPausedEb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setPaused(FMOD::ChannelControlI *const this, bool paused)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e720 | Name: _ZN4FMOD15ChannelControlI9getPausedEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getPaused(FMOD::ChannelControlI *const this, bool *paused)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e730 | Name: _ZN4FMOD15ChannelControlI9setVolumeEfb
__int64 __fastcall FMOD::ChannelControlI::setVolume(
        FMOD::ChannelControlI *const this,
        double a2,
        float volume,
        bool forceupdatepos)
{
  return 0;
}


// Address: 0x220e740 | Name: _ZN4FMOD15ChannelControlI9getVolumeEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getVolume(FMOD::ChannelControlI *const this, float *volume)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e750 | Name: _ZN4FMOD15ChannelControlI13setVolumeRampEb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setVolumeRamp(FMOD::ChannelControlI *const this, bool ramp)
{
  if ( ramp )
    this->mFlags &= ~0x20u;
  else
    this->mFlags |= 0x20u;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e770 | Name: _ZN4FMOD15ChannelControlI13getVolumeRampEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getVolumeRamp(FMOD::ChannelControlI *const this, bool *ramp)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( ramp )
  {
    *ramp = ((this->mFlags >> 5) ^ 1) & 1;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x220e7d0 | Name: _ZN4FMOD15ChannelControlI8getPitchEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getPitch(FMOD::ChannelControlI *const this, float *pitch)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( pitch )
  {
    LOBYTE(result) = 0;
    *pitch = this->mPitch;
  }
  return result;
}


// Address: 0x220e7f0 | Name: _ZN4FMOD15ChannelControlI7setMuteEb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setMute(FMOD::ChannelControlI *const this, bool mute)
{
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // eax

  mFlags = this->mFlags;
  if ( mute == ((mFlags & 2) != 0) )
    return FMOD_RESULT::FMOD_OK_0;
  if ( mute )
    this->mFlags = mFlags | 2;
  else
    this->mFlags = mFlags & 0xFFFFFFFD;
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelControlI *const, __int64, float))this->_vptr_ChannelControlI + 4))(
           this,
           1,
           this->mVolume);
}


// Address: 0x220e840 | Name: _ZN4FMOD15ChannelControlI7getMuteEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getMute(FMOD::ChannelControlI *const this, bool *mute)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( mute )
  {
    *mute = (this->mFlags & 2) != 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x220e860 | Name: _ZN4FMOD15ChannelControlI19setReverbPropertiesEif
__int64 __fastcall FMOD::ChannelControlI::setReverbProperties(
        FMOD::ChannelControlI *const this,
        unsigned int instance,
        float a3,
        float wet)
{
  __int64 result; // rax

  result = 29;
  if ( (LODWORD(a3) & 0x7F800000) != 0x7F800000 )
  {
    result = 59;
    if ( instance <= 3 )
    {
      this->mReverbLevel[instance] = a3;
      return 0;
    }
  }
  return result;
}


// Address: 0x220e8b0 | Name: _ZN4FMOD15ChannelControlI19getReverbPropertiesEiPf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getReverbProperties(
        FMOD::ChannelControlI *const this,
        int instance,
        float *wet)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( wet )
  {
    LOBYTE(result) = 59;
    if ( (unsigned int)instance <= 3 )
    {
      LOBYTE(result) = 0;
      *wet = this->mReverbLevel[instance];
    }
  }
  return result;
}


// Address: 0x220e8e0 | Name: _ZN4FMOD15ChannelControlI22updateReverbConnectionEi
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::updateReverbConnection(FMOD::ChannelControlI *const this, int instance)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e8f0 | Name: _ZN4FMOD15ChannelControlI14setLowPassGainEf
__int64 __fastcall FMOD::ChannelControlI::setLowPassGain(FMOD::ChannelControlI *const this, float a2, float gain)
{
  __int64 result; // rax

  result = 0;
  if ( (LODWORD(a2) & 0x7F800000) == 0x7F800000 )
    return 29;
  return result;
}


// Address: 0x220e920 | Name: _ZN4FMOD15ChannelControlI14getLowPassGainEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getLowPassGain(FMOD::ChannelControlI *const this, float *gain)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e930 | Name: _ZN4FMOD15ChannelControlI7setModeEj
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setMode(FMOD::ChannelControlI *const this, FMOD_MODE mode)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e940 | Name: _ZN4FMOD15ChannelControlI7getModeEPj
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getMode(FMOD::ChannelControlI *const this, FMOD_MODE *mode)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e950 | Name: _ZN4FMOD15ChannelControlI11setCallbackEPF11FMOD_RESULTP19FMOD_CHANNELCONTROL24FMOD_CHANNELCONTROL_TYPE33FMOD_CHANNELCONTROL_CALLBACK_TYPEPvS6_E
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setCallback(
        FMOD::ChannelControlI *const this,
        FMOD_CHANNELCONTROL_CALLBACK callback)
{
  this->mCallback = callback;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e960 | Name: _ZN4FMOD15ChannelControlI9isPlayingEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::isPlaying(FMOD::ChannelControlI *const this, bool *isplaying)
{
  *isplaying = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e970 | Name: _ZN4FMOD15ChannelControlI18setMixLevelsOutputEffffffff
__int64 __fastcall FMOD::ChannelControlI::setMixLevelsOutput(
        FMOD::ChannelControlI *const this,
        double a2,
        float frontleft,
        float frontright,
        float center,
        float lfe,
        float surroundleft,
        float surroundright,
        float backleft)
{
  return 0;
}


// Address: 0x220e980 | Name: _ZN4FMOD15ChannelControlI17setMixLevelsInputEPfi
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setMixLevelsInput(
        FMOD::ChannelControlI *const this,
        float *levels,
        int numlevels)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e990 | Name: _ZN4FMOD15ChannelControlI11getDSPClockEPyS1_
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getDSPClock(
        FMOD::ChannelControlI *const this,
        FMOD_CLOCKTIME *dspclock,
        FMOD_CLOCKTIME *parentclock)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e9a0 | Name: _ZN4FMOD15ChannelControlI8getDelayEPyS1_Pb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getDelay(
        FMOD::ChannelControlI *const this,
        FMOD_CLOCKTIME *dspclock_start,
        FMOD_CLOCKTIME *dspclock_end,
        bool *stopchannels)
{
  if ( dspclock_start )
    *dspclock_start = this->mDelayClockStart;
  if ( dspclock_end )
    *dspclock_end = this->mDelayClockEnd;
  if ( stopchannels )
    *stopchannels = this->mDelayClockStopChannels;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220e9d0 | Name: _ZN4FMOD15ChannelControlI6getDSPEiPPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getDSP(FMOD::ChannelControlI *const this, int index, FMOD::DSPI **dsp)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *mDSPHead; // r13
  FMOD::DSPI *mDSPTail; // r15
  FMOD::DSPI *mDSPFader; // r14
  int numdsps[15]; // [rsp+Ch] [rbp-3Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  numdsps[0] = 0;
  if ( dsp )
  {
    mDSPHead = this->mDSPHead;
    mDSPTail = this->mDSPTail;
    mDSPFader = (FMOD::DSPI *)this->mDSPFader;
    if ( mDSPHead )
    {
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, int *))this->_vptr_ChannelControlI + 37))(
                 this,
                 numdsps);
      if ( result )
        return result;
      if ( (unsigned int)(index + 1) <= 1 )
      {
        *dsp = mDSPHead;
        return result;
      }
      if ( numdsps[0] - 1 == index || index == -3 )
      {
        *dsp = mDSPTail;
        return FMOD_RESULT::FMOD_OK_0;
      }
      if ( index == -2 )
      {
        *dsp = mDSPFader;
        return result;
      }
      if ( index < numdsps[0] )
      {
        *dsp = this->mDSP[index];
        return result;
      }
    }
    return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
  }
  return result;
}


// Address: 0x220eaa0 | Name: _ZN4FMOD15ChannelControlI10getNumDSPsEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getNumDSPs(FMOD::ChannelControlI *const this, int *numdsps)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numdsps )
  {
    *numdsps = this->mNumDSPs;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x220eac0 | Name: _ZN4FMOD15ChannelControlI11getDSPIndexEPNS_4DSPIEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getDSPIndex(
        FMOD::ChannelControlI *const this,
        FMOD::DSPI *dsp,
        int *index)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI **mDSP; // rcx
  int mNumDSPs; // edi
  FMOD::DSPI **v6; // rcx
  int v7; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp )
  {
    if ( index )
      *index = 0;
    mDSP = this->mDSP;
    if ( mDSP )
    {
      mNumDSPs = this->mNumDSPs;
      if ( mNumDSPs <= 0 )
        return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
      if ( *mDSP != dsp )
      {
        v6 = mDSP + 1;
        v7 = 0;
        while ( ++v7 != mNumDSPs )
        {
          if ( *v6++ == dsp )
            goto LABEL_14;
        }
        return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
      }
      v7 = 0;
LABEL_14:
      if ( index )
      {
        *index = v7;
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
    else
    {
      return 9 * (dsp != this->mDSPHead);
    }
  }
  return result;
}


// Address: 0x220eb40 | Name: _ZN4FMOD15ChannelControlI18get3DCustomRolloffEPP11FMOD_VECTORPi
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::get3DCustomRolloff(
        FMOD::ChannelControlI *const this,
        FMOD_VECTOR **points,
        int *numpoints)
{
  if ( points )
    *points = this->mRolloffPoint;
  if ( numpoints )
    *numpoints = this->mNumRolloffPoints;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220eb60 | Name: _ZN4FMOD15ChannelControlI14get3DOcclusionEPfS1_
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::get3DOcclusion(
        FMOD::ChannelControlI *const this,
        float *directocclusion,
        float *reverbocclusion)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220eb70 | Name: _ZN4FMOD15ChannelControlI11get3DSpreadEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::get3DSpread(FMOD::ChannelControlI *const this, float *angle)
{
  FMOD_RESULT_0 result; // eax
  FMOD_MODE mode[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
    if ( (mode[0] & 0x10) != 0 )
    {
      LOBYTE(result) = 31;
      if ( angle )
      {
        LOBYTE(result) = 0;
        *angle = this->mSpread;
      }
    }
  }
  return result;
}


// Address: 0x220ebc0 | Name: _ZN4FMOD15ChannelControlI10get3DLevelEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::get3DLevel(FMOD::ChannelControlI *const this, float *level)
{
  FMOD_RESULT_0 result; // eax
  FMOD_MODE mode[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
    if ( (mode[0] & 0x10) != 0 )
    {
      LOBYTE(result) = 31;
      if ( level )
      {
        LOBYTE(result) = 0;
        *level = this->m3DLevel;
      }
    }
  }
  return result;
}


// Address: 0x220ec10 | Name: _ZN4FMOD15ChannelControlI17get3DDopplerLevelEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::get3DDopplerLevel(FMOD::ChannelControlI *const this, float *level)
{
  FMOD_RESULT_0 result; // eax
  FMOD_MODE mode[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
    if ( (mode[0] & 0x10) != 0 )
    {
      LOBYTE(result) = 31;
      if ( level )
      {
        LOBYTE(result) = 0;
        *level = this->m3DDopplerLevel;
      }
    }
  }
  return result;
}


// Address: 0x220ec60 | Name: _ZN4FMOD15ChannelControlI12getMixMatrixEPfPiS2_i
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getMixMatrix(
        FMOD::ChannelControlI *const this,
        float *matrix,
        int *outchannels,
        int *inchannels,
        int inchannel_hop)
{
  return FMOD::DSPMatrix::get(&this->mMixMatrix, matrix, outchannels, inchannels, inchannel_hop);
}


// Address: 0x220ec70 | Name: _ZN4FMOD15ChannelControlI8setDelayEyyb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setDelay(
        FMOD::ChannelControlI *const this,
        FMOD_CLOCKTIME dspclock_start,
        FMOD_CLOCKTIME dspclock_end,
        bool stopchannels)
{
  int (**vptr_ChannelControlI)(...); // rax
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *dsphead; // [rsp+8h] [rbp-20h] BYREF

  if ( *(_OWORD *)&this->mDelayClockStart == __PAIR128__(dspclock_end, dspclock_start)
    && this->mDelayClockStopChannels == stopchannels )
  {
    return FMOD_RESULT::FMOD_OK_0;
  }
  vptr_ChannelControlI = this->_vptr_ChannelControlI;
  this->mDelayClockStart = dspclock_start;
  this->mDelayClockEnd = dspclock_end;
  this->mDelayClockStopChannels = stopchannels;
  result = vptr_ChannelControlI[36](this, 0, &dsphead);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
    if ( dsphead )
      return FMOD::DSPI::setDelay(dsphead, dspclock_start, dspclock_end, stopchannels);
  }
  return result;
}


// Address: 0x220ed00 | Name: _ZN4FMOD15ChannelControlI13getFadePointsEPjPyPf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getFadePoints(
        FMOD::ChannelControlI *const this,
        unsigned int *numpoints,
        FMOD_CLOCKTIME *point_dspclock,
        float *point_volume)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPFader *dspfader; // [rsp+8h] [rbp-20h] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, __int64, FMOD::DSPFader **))this->_vptr_ChannelControlI
            + 36))(
             this,
             4294967294LL,
             &dspfader);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::DSPFader::getFadePoints(dspfader, numpoints, point_dspclock, point_volume);
  return result;
}


// Address: 0x220ed50 | Name: _ZN4FMOD15ChannelControlI15set3DAttributesEPK11FMOD_VECTORS3_
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::set3DAttributes(
        FMOD::ChannelControlI *const this,
        const FMOD_VECTOR *pos,
        const FMOD_VECTOR *vel)
{
  FMOD_RESULT_0 result; // eax
  float x; // esi
  float y; // edi
  FMOD_RESULT_0 v9; // r8d
  FMOD_RESULT_0 v10; // edx
  int v11; // edx
  float z; // r8d
  float v13; // edi
  int v14; // eax
  int v15; // r8d
  int v16; // edx
  int v17; // edx
  float v18; // r8d
  FMOD_MODE mode[7]; // [rsp+1Ch] [rbp-1Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result )
    return result;
  result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
  if ( (mode[0] & 0x10) == 0 )
    return result;
  if ( !pos )
    goto LABEL_15;
  x = pos->x;
  y = pos->y;
  LOBYTE(result) = 29;
  v9 = result;
  if ( (LODWORD(pos->x) & 0x7F800000) != 0x7F800000 )
    v9 = FMOD_RESULT::FMOD_OK_0;
  v10 = result;
  if ( (LODWORD(y) & 0x7F800000) != 0x7F800000 )
    v10 = FMOD_RESULT::FMOD_OK_0;
  v11 = v9 | v10;
  z = pos->z;
  if ( (LODWORD(z) & 0x7F800000) != 0x7F800000 )
    result = FMOD_RESULT::FMOD_OK_0;
  result |= v11;
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( x != this->mPosition3D.x || y != this->mPosition3D.y || z != this->mPosition3D.z )
      this->mFlags |= 4u;
    *(_QWORD *)&this->mPosition3D.x = *(_QWORD *)&pos->x;
    this->mPosition3D.z = pos->z;
LABEL_15:
    if ( vel )
    {
      v13 = vel->y;
      v14 = 29;
      v15 = 29;
      if ( (LODWORD(vel->x) & 0x7F800000) != 0x7F800000 )
        v15 = 0;
      v16 = 29;
      if ( (LODWORD(v13) & 0x7F800000) != 0x7F800000 )
        v16 = 0;
      v17 = v15 | v16;
      v18 = vel->z;
      if ( (LODWORD(v18) & 0x7F800000) != 0x7F800000 )
        v14 = 0;
      result = v17 | v14;
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( vel->x != this->mVelocity3D.x || v13 != this->mVelocity3D.y || v18 != this->mVelocity3D.z )
          this->mFlags |= 4u;
        *(_QWORD *)&this->mVelocity3D.x = *(_QWORD *)&vel->x;
        this->mVelocity3D.z = vel->z;
      }
    }
    else
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x220ef30 | Name: _ZN4FMOD15ChannelControlI15get3DAttributesEP11FMOD_VECTORS2_
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::get3DAttributes(
        FMOD::ChannelControlI *const this,
        FMOD_VECTOR *pos,
        FMOD_VECTOR *vel)
{
  FMOD_RESULT_0 result; // eax
  FMOD_MODE mode[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
    if ( (mode[0] & 0x10) != 0 )
    {
      if ( pos )
        *pos = this->mPosition3D;
      if ( vel )
        *vel = this->mVelocity3D;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x220efe0 | Name: _ZN4FMOD15ChannelControlI19get3DMinMaxDistanceEPfS1_
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::get3DMinMaxDistance(
        FMOD::ChannelControlI *const this,
        float *mindistance,
        float *maxdistance)
{
  FMOD_RESULT_0 result; // eax
  FMOD_MODE mode[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
    if ( (mode[0] & 0x10) != 0 )
    {
      if ( mindistance )
        *mindistance = this->mMinDistance;
      if ( maxdistance )
        *maxdistance = this->mMaxDistance;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x220f060 | Name: _ZN4FMOD15ChannelControlI17set3DConeSettingsEfff
char __fastcall FMOD::ChannelControlI::set3DConeSettings(
        FMOD::ChannelControlI *const this,
        double a2,
        float insideconeangle,
        float outsideconeangle,
        float outsidevolume)
{
  int v5; // eax
  float v6; // xmm0_4
  float insideconeanglea; // [rsp+0h] [rbp-28h]
  FMOD_MODE mode[3]; // [rsp+1Ch] [rbp-Ch] BYREF

  insideconeanglea = *(float *)&a2;
  v5 = (*((__int64 (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *, double, float, float, float))this->_vptr_ChannelControlI
        + 19))(
         this,
         mode,
         a2,
         insideconeangle,
         outsideconeangle,
         outsidevolume);
  if ( !v5 )
  {
    LOBYTE(v5) = 40;
    if ( (mode[0] & 0x10) != 0 )
    {
      LOBYTE(v5) = 29;
      if ( (LODWORD(a2) & 0x7F800000) != 0x7F800000
        && (_mm_cvtsi128_si32((__m128i)LODWORD(insideconeangle)) & 0x7F800000) != 0x7F800000
        && (LODWORD(outsideconeangle) & 0x7F800000) != 0x7F800000 )
      {
        LOBYTE(v5) = 31;
        if ( *(float *)&a2 <= insideconeangle )
        {
          v6 = 1.0;
          if ( outsideconeangle <= 1.0 )
            v6 = fmaxf(0.0, outsideconeangle);
          this->mFlags |= 4u;
          this->mConeInsideAngle = insideconeanglea;
          this->mConeOutsideAngle = insideconeangle;
          this->mConeOutsideVolume = v6;
          LOBYTE(v5) = 0;
        }
      }
    }
  }
  return v5;
}


// Address: 0x220f150 | Name: _ZN4FMOD15ChannelControlI17get3DConeSettingsEPfS1_S1_
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::get3DConeSettings(
        FMOD::ChannelControlI *const this,
        float *insideconeangle,
        float *outsideconeangle,
        float *outsidevolume)
{
  FMOD_RESULT_0 result; // eax
  FMOD_MODE mode[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
    if ( (mode[0] & 0x10) != 0 )
    {
      if ( insideconeangle )
        *insideconeangle = this->mConeInsideAngle;
      if ( outsideconeangle )
        *outsideconeangle = this->mConeOutsideAngle;
      if ( outsidevolume )
        *outsidevolume = this->mConeOutsideVolume;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x220f1e0 | Name: _ZN4FMOD15ChannelControlI20set3DConeOrientationEP11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::set3DConeOrientation(
        FMOD::ChannelControlI *const this,
        FMOD_VECTOR *orientation)
{
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 v4; // esi
  FMOD_RESULT_0 v5; // ecx
  int v6; // ecx
  float z; // edx
  FMOD_MODE mode[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
    if ( (mode[0] & 0x10) != 0 )
    {
      LOBYTE(result) = 31;
      if ( orientation )
      {
        LOBYTE(result) = 29;
        v4 = result;
        if ( (LODWORD(orientation->x) & 0x7F800000) != 0x7F800000 )
          v4 = FMOD_RESULT::FMOD_OK_0;
        v5 = result;
        if ( (LODWORD(orientation->y) & 0x7F800000) != 0x7F800000 )
          v5 = FMOD_RESULT::FMOD_OK_0;
        v6 = v4 | v5;
        if ( (LODWORD(orientation->z) & 0x7F800000) != 0x7F800000 )
          result = FMOD_RESULT::FMOD_OK_0;
        result |= v6;
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          *(_QWORD *)&this->mConeOrientation.x = *(_QWORD *)&orientation->x;
          z = orientation->z;
          this->mFlags |= 4u;
          this->mConeOrientation.z = z;
        }
      }
    }
  }
  return result;
}


// Address: 0x220f280 | Name: _ZN4FMOD15ChannelControlI20get3DConeOrientationEP11FMOD_VECTOR
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::get3DConeOrientation(
        FMOD::ChannelControlI *const this,
        FMOD_VECTOR *orientation)
{
  FMOD_RESULT_0 result; // eax
  FMOD_MODE mode[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
    if ( (mode[0] & 0x10) != 0 )
    {
      if ( orientation )
        *orientation = this->mConeOrientation;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x220f2e0 | Name: _ZN4FMOD15ChannelControlI18set3DCustomRolloffEP11FMOD_VECTORi
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::set3DCustomRolloff(
        FMOD::ChannelControlI *const this,
        FMOD_VECTOR *points,
        int numpoints)
{
  FMOD_RESULT_0 result; // eax
  FMOD_VECTOR *v4; // rcx
  int v5; // r9d
  __m128i x_low; // xmm1
  int v7; // r8d
  __m128i y_low; // xmm0
  int v9; // eax
  bool v10; // zf
  int v11; // eax
  int v12; // eax
  int v13; // r8d

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numpoints >= 0 )
  {
    if ( points && numpoints )
    {
      v4 = points;
      v5 = 0;
      while ( 1 )
      {
        x_low = (__m128i)LODWORD(v4->x);
        v7 = 29;
        y_low = (__m128i)LODWORD(v4->y);
        v9 = _mm_cvtsi128_si32(y_low);
        if ( (_mm_cvtsi128_si32(x_low) & 0x7F800000) != 0x7F800000 )
          v7 = 0;
        v10 = (v9 & 0x7F800000) == 2139095040;
        v11 = 29;
        if ( !v10 )
          v11 = 0;
        v12 = v7 | v11;
        v13 = 29;
        if ( (LODWORD(v4->z) & 0x7F800000) != 0x7F800000 )
          v13 = 0;
        result = v13 | v12;
        if ( result )
          break;
        if ( v5 && v4[-1].x >= *(float *)x_low.m128i_i32
          || *(float *)y_low.m128i_i32 < 0.0
          || *(float *)y_low.m128i_i32 > 1.0 )
        {
          return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        }
        ++v5;
        ++v4;
        if ( v5 == numpoints )
          goto LABEL_19;
      }
    }
    else
    {
LABEL_19:
      this->mRolloffPoint = points;
      this->mNumRolloffPoints = numpoints;
      this->mFlags |= 4u;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x220f3f0 | Name: _ZN4FMOD15ChannelControlI14set3DOcclusionEff
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::set3DOcclusion(
        FMOD::ChannelControlI *const this,
        float a2,
        float directocclusion,
        float reverbocclusion)
{
  int (**vptr_ChannelControlI)(...); // rax

  if ( (LODWORD(a2) & 0x7F800000) == 0x7F800000 || (LODWORD(directocclusion) & 0x7F800000) == 0x7F800000 )
    return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  this->mDirectOcclusion = a2;
  vptr_ChannelControlI = this->_vptr_ChannelControlI;
  this->mReverbOcclusion = directocclusion;
  return (FMOD_RESULT_0)vptr_ChannelControlI[4](this, 0, this->mVolume, directocclusion, reverbocclusion);
}


// Address: 0x220f450 | Name: _ZN4FMOD15ChannelControlI11set3DSpreadEf
char __fastcall FMOD::ChannelControlI::set3DSpread(FMOD::ChannelControlI *const this, double a2, float angle)
{
  int v3; // eax
  FMOD_MODE mode[3]; // [rsp+1Ch] [rbp-Ch] BYREF

  v3 = (*((__int64 (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *, double, float))this->_vptr_ChannelControlI
        + 19))(
         this,
         mode,
         a2,
         angle);
  if ( !v3 )
  {
    LOBYTE(v3) = 40;
    if ( (mode[0] & 0x10) != 0 )
    {
      LOBYTE(v3) = 29;
      if ( (LODWORD(a2) & 0x7F800000) != 0x7F800000 )
      {
        if ( *(float *)&a2 > 360.0 || *(float *)&a2 < 0.0 )
        {
          LOBYTE(v3) = 31;
        }
        else
        {
          this->mSpread = *(float *)&a2;
          LOBYTE(v3) = 0;
        }
      }
    }
  }
  return v3;
}


// Address: 0x220f4d0 | Name: _ZN4FMOD15ChannelControlI10set3DLevelEf
char __fastcall FMOD::ChannelControlI::set3DLevel(FMOD::ChannelControlI *const this, double a2, float level)
{
  int v3; // eax
  FMOD_MODE mode[3]; // [rsp+1Ch] [rbp-Ch] BYREF

  v3 = (*((__int64 (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *, double, float))this->_vptr_ChannelControlI
        + 19))(
         this,
         mode,
         a2,
         level);
  if ( !v3 )
  {
    LOBYTE(v3) = 40;
    if ( (mode[0] & 0x10) != 0 )
    {
      LOBYTE(v3) = 29;
      if ( (LODWORD(a2) & 0x7F800000) != 0x7F800000 )
      {
        if ( *(float *)&a2 > 1.0 || *(float *)&a2 < 0.0 )
        {
          LOBYTE(v3) = 31;
        }
        else
        {
          this->m3DLevel = *(float *)&a2;
          LOBYTE(v3) = 0;
        }
      }
    }
  }
  return v3;
}


// Address: 0x220f550 | Name: _ZN4FMOD15ChannelControlI17set3DDopplerLevelEf
char __fastcall FMOD::ChannelControlI::set3DDopplerLevel(FMOD::ChannelControlI *const this, double a2, float level)
{
  int v3; // eax
  FMOD_MODE mode[3]; // [rsp+1Ch] [rbp-Ch] BYREF

  v3 = (*((__int64 (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *, double, float))this->_vptr_ChannelControlI
        + 19))(
         this,
         mode,
         a2,
         level);
  if ( !v3 )
  {
    LOBYTE(v3) = 40;
    if ( (mode[0] & 0x10) != 0 )
    {
      LOBYTE(v3) = 29;
      if ( (LODWORD(a2) & 0x7F800000) != 0x7F800000 )
      {
        if ( *(float *)&a2 > 5.0 || *(float *)&a2 < 0.0 )
        {
          LOBYTE(v3) = 31;
        }
        else
        {
          this->m3DDopplerLevel = *(float *)&a2;
          LOBYTE(v3) = 0;
        }
      }
    }
  }
  return v3;
}


// Address: 0x220f5d0 | Name: _ZN4FMOD15ChannelControlI19set3DDistanceFilterEbff
char __fastcall FMOD::ChannelControlI::set3DDistanceFilter(
        FMOD::ChannelControlI *const this,
        bool custom,
        double a3,
        float customLevel,
        float centerFreq)
{
  FMOD::FMOD_CHANNELCONTROL_FLAG v5; // eax
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // eax
  float centerFreqa; // [rsp+Ch] [rbp-2Ch]
  FMOD_MODE mode[7]; // [rsp+1Ch] [rbp-1Ch] BYREF

  centerFreqa = customLevel;
  v5 = (*((__int64 (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *, double, float, float))this->_vptr_ChannelControlI
        + 19))(
         this,
         mode,
         a3,
         customLevel,
         centerFreq);
  if ( v5 )
    return v5;
  LOBYTE(v5) = 40;
  if ( (mode[0] & 0x10) == 0 )
    return v5;
  LOBYTE(v5) = 29;
  if ( (LODWORD(a3) & 0x7F800000) == 0x7F800000 || (LODWORD(customLevel) & 0x7F800000) == 0x7F800000 )
    return v5;
  if ( *(float *)&a3 > 1.0 || *(float *)&a3 < 0.0 )
    goto LABEL_7;
  if ( customLevel < 0.000099999997 )
  {
    centerFreqa = this->mSystem->mAdvancedSettings.distanceFilterCenterFreq;
    goto LABEL_11;
  }
  if ( customLevel > 22050.0 || customLevel < 10.0 )
  {
LABEL_7:
    LOBYTE(v5) = 31;
    return v5;
  }
LABEL_11:
  mFlags = this->mFlags;
  if ( custom )
    v5 = mFlags | 0x100000;
  else
    v5 = mFlags & 0xFFEFFFFF;
  this->mFlags = v5;
  this->mDistanceFilterCustomLevel = *(float *)&a3;
  this->mDistanceFilterCentreFreq = centerFreqa;
  LOBYTE(v5) = 0;
  return v5;
}


// Address: 0x220f6e0 | Name: _ZN4FMOD15ChannelControlI19get3DDistanceFilterEPbPfS2_
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::get3DDistanceFilter(
        FMOD::ChannelControlI *const this,
        bool *custom,
        float *customLevel,
        float *centerFreq)
{
  FMOD_RESULT_0 result; // eax
  FMOD_MODE mode[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *))this->_vptr_ChannelControlI + 19))(
             this,
             mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_NEEDS3D_0;
    if ( (mode[0] & 0x10) != 0 )
    {
      if ( custom )
        *custom = (this->mFlags & 0x100000) != 0;
      if ( customLevel )
        *customLevel = this->mDistanceFilterCustomLevel;
      if ( centerFreq )
        *centerFreq = this->mDistanceFilterCentreFreq;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x220f770 | Name: _ZN4FMOD15ChannelControlI6setPanEf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setPan(FMOD::ChannelControlI *const this, __m128i a2, float pan)
{
  double v3; // xmm1_8
  float v4; // xmm2_4

  if ( (_mm_cvtsi128_si32(a2) & 0x7F800000) == 0x7F800000 )
    return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  HIDWORD(v3) = 0;
  if ( *(float *)a2.m128i_i32 >= -1.0 )
  {
    HIDWORD(v3) = 0;
    if ( *(float *)a2.m128i_i32 > 1.0 )
    {
      v4 = 0.0;
      a2.m128i_i64[0] = 1065353216;
    }
    else
    {
      *(float *)a2.m128i_i32 = (float)(*(float *)a2.m128i_i32 + 1.0) * 0.5;
      v4 = 1.0 - *(float *)a2.m128i_i32;
    }
  }
  else
  {
    a2.m128i_i64[0] = 0;
    v4 = 1.0;
  }
  *(float *)&v3 = fsqrt(*(float *)a2.m128i_i32);
  *(float *)a2.m128i_i32 = fsqrt(v4);
  return (*((FMOD_RESULT_0 (__fastcall **)(double, double, double, double, double, double, double))this->_vptr_ChannelControlI
          + 23))(
           *(double *)a2.m128i_i64,
           v3,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0);
}


// Address: 0x220f880 | Name: _ZN4FMOD15ChannelControlI12addFadePointEyf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::addFadePoint(
        FMOD::ChannelControlI *const this,
        FMOD::LinkedListNode *dspclock,
        double a3,
        float volume)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPFader *dspfader; // [rsp+18h] [rbp-20h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  if ( (LODWORD(a3) & 0x7F800000) != 0x7F800000 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, __int64, FMOD::DSPFader **, double, float))this->_vptr_ChannelControlI
              + 36))(
               this,
               4294967294LL,
               &dspfader,
               a3,
               volume);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = (unsigned int)FMOD::DSPFader::addFadePoint(dspfader, dspclock, *(float *)&a3, volume);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 65))(this);
    }
  }
  return result;
}


// Address: 0x220f900 | Name: _ZN4FMOD15ChannelControlI16setFadePointRampEyf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setFadePointRamp(
        FMOD::ChannelControlI *const this,
        FMOD_CLOCKTIME dspclock,
        double a3,
        float volume)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPFader *dspfader; // [rsp+18h] [rbp-20h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  if ( (LODWORD(a3) & 0x7F800000) != 0x7F800000 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, __int64, FMOD::DSPFader **, double, float))this->_vptr_ChannelControlI
              + 36))(
               this,
               4294967294LL,
               &dspfader,
               a3,
               volume);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = (unsigned int)FMOD::DSPFader::setFadePointRamp(dspfader, dspclock, *(float *)&a3, volume);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 65))(this);
    }
  }
  return result;
}


// Address: 0x220f980 | Name: _ZN4FMOD15ChannelControlI16removeFadePointsEyy
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::removeFadePoints(
        FMOD::ChannelControlI *const this,
        FMOD_CLOCKTIME dspclock_start,
        FMOD_CLOCKTIME dspclock_end)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-20h] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI
            + 36))(
             this,
             4294967294LL,
             &dspi);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( !dspi )
      return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 65))(this);
    result = FMOD::DSPFader::removeFadePoints((FMOD::DSPFader *const)dspi, dspclock_start, dspclock_end, 1);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 65))(this);
  }
  return result;
}


// Address: 0x220f9e0 | Name: _ZN4FMOD15ChannelControlI12setMixMatrixEPfiiib
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setMixMatrix(
        FMOD::ChannelControlI *const this,
        float *matrix,
        int outchannels,
        int inchannels,
        int inchannel_hop,
        bool updatematrix)
{
  __int64 v9; // rax
  float *v12; // rcx
  __int64 v13; // r8
  int i; // edi
  float *j; // rax
  int v16; // r9d
  FMOD_RESULT_0 result; // eax
  float *mData; // rsi
  int v19; // r15d
  float *v20; // rax
  float *v21; // rsi

  if ( !updatematrix )
    return FMOD_RESULT::FMOD_OK_0;
  if ( matrix )
  {
    v9 = inchannel_hop;
    if ( !inchannel_hop )
      v9 = inchannels;
    if ( outchannels > 0 )
    {
      v12 = matrix + 1;
      v13 = 4 * v9;
      for ( i = 0; i != outchannels; ++i )
      {
        if ( inchannels > 0 )
        {
          if ( (*(_DWORD *)(v12 - 1) & 0x7F800000) == 0x7F800000 )
            return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
          for ( j = v12; &v12[inchannels - 1] != j; ++j )
          {
            v16 = *(_DWORD *)j;
            if ( (v16 & 0x7F800000) == 0x7F800000 )
              return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
          }
        }
        v12 = (float *)((char *)v12 + v13);
      }
    }
    mData = this->mMixMatrix.mData;
    if ( mData )
    {
      if ( inchannels <= this->mMixMatrix.mInChannels && outchannels <= this->mMixMatrix.mOutChannels )
        return FMOD::DSPMatrix::set(&this->mMixMatrix, matrix, outchannels, inchannels, inchannel_hop);
      FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, mData, (const char *)&uri_string, 0);
    }
    v19 = outchannels;
    if ( inchannels >= outchannels )
      v19 = inchannels;
    v20 = (float *)FMOD::MemPool::alloc(
                     &this->mSystem->mDSPLevelsPool,
                     4 * v19 * outchannels,
                     (const char *)&uri_string,
                     0,
                     0,
                     0);
    if ( !v20 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    this->mMixMatrix.mInChannels = v19;
    this->mMixMatrix.mOutChannels = outchannels;
    this->mMixMatrix.mData = v20;
    return FMOD::DSPMatrix::set(&this->mMixMatrix, matrix, outchannels, inchannels, inchannel_hop);
  }
  v21 = this->mMixMatrix.mData;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( v21 )
  {
    FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, v21, (const char *)&uri_string, 0);
    this->mMixMatrix.mData = 0;
    this->mMixMatrix.mInChannels = 0;
    this->mMixMatrix.mOutChannels = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x220fba0 | Name: _ZN4FMOD15ChannelControlI11setDSPIndexEPNS_4DSPIEi
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setDSPIndex(
        FMOD::ChannelControlI *const this,
        FMOD::DSPI *dsp,
        int index)
{
  FMOD_RESULT_0 v3; // ebp
  FMOD::DSPI *mDSPHead; // r12
  FMOD::DSPFader *mDSPFader; // r15
  int v6; // eax
  int v8; // edx
  int mNumDSPs; // ecx
  int v10; // eax
  int v11; // ecx
  unsigned __int64 v12; // rax
  FMOD::SystemI *mSystem; // r14
  FMOD_RESULT_0 v14; // eax
  __int64 i; // rax
  char v16; // [rsp+Bh] [rbp-5Dh]
  int indexa[4]; // [rsp+Ch] [rbp-5Ch] BYREF
  int oldindex; // [rsp+1Ch] [rbp-4Ch] BYREF
  FMOD::DSPI *newhead; // [rsp+20h] [rbp-48h] BYREF
  FMOD::DSPI *newtail; // [rsp+28h] [rbp-40h] BYREF

  v3 = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
  mDSPHead = this->mDSPHead;
  mDSPFader = this->mDSPFader;
  indexa[0] = index;
  newhead = 0;
  newtail = 0;
  if ( mDSPHead )
  {
    v6 = index;
    if ( index == -1 )
    {
      indexa[0] = 0;
      v6 = 0;
    }
    else
    {
      if ( index == -3 )
      {
        v6 = this->mNumDSPs - 1;
        indexa[0] = v6;
      }
      else if ( index == -2 )
      {
        v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD::DSPFader *, int *))this->_vptr_ChannelControlI
              + 39))(
               this,
               mDSPFader,
               indexa);
        if ( v3 )
          return v3;
        v6 = indexa[0];
      }
      if ( v6 < 0 )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
    if ( this->mNumDSPs <= v6 )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD::DSPI *, int *))this->_vptr_ChannelControlI
          + 39))(
           this,
           dsp,
           &oldindex);
    if ( v3 )
      return v3;
    v8 = oldindex;
    if ( indexa[0] == oldindex )
      return FMOD_RESULT::FMOD_OK_0;
    if ( oldindex )
    {
      if ( !indexa[0] )
        newhead = dsp;
    }
    else
    {
      v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI
            + 36))(
             this,
             1,
             &newhead);
      if ( v3 )
        return v3;
      v8 = oldindex;
    }
    mNumDSPs = this->mNumDSPs;
    v10 = mNumDSPs - 1;
    if ( mNumDSPs - 1 == v8 )
    {
      v3 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, _QWORD, FMOD::DSPI **))this->_vptr_ChannelControlI
            + 36))(
             this,
             (unsigned int)(mNumDSPs - 2),
             &newtail);
      if ( v3 )
        return v3;
      v8 = oldindex;
      v11 = indexa[0];
    }
    else
    {
      v11 = indexa[0];
      if ( v10 == indexa[0] )
        newtail = dsp;
    }
    if ( v11 > v8 )
    {
      for ( i = v8; ; ++i )
      {
        this->mDSP[i] = this->mDSP[i + 1];
        if ( i * 8 + 8 == 8 * (v8 + (unsigned __int64)(unsigned int)(v11 - 1 - v8) + 1) )
          break;
      }
    }
    else if ( v11 < v8 )
    {
      v12 = 8LL * v8;
      do
      {
        this->mDSP[v12 / 8] = this->mDSP[v12 / 8 - 1];
        v12 -= 8LL;
      }
      while ( v12 != 8 * (v8 - (unsigned __int64)(unsigned int)(v8 - 1 - v11)) - 8 );
    }
    this->mDSP[v11] = dsp;
    mSystem = this->mSystem;
    if ( mSystem )
    {
      FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
      v11 = indexa[0];
      v8 = oldindex;
      v16 = 1;
    }
    else
    {
      v16 = 0;
    }
    v14 = FMOD::DSPI::addInputChainAt(mDSPHead, dsp, v8, v11, 1, 0);
    if ( v14 == FMOD_RESULT::FMOD_OK_0
      && (!newhead
       || (v14 = FMOD::DSPFader::setHeadDSPClock(mDSPFader, &newhead->mJob.mDelayClock, 0)) == FMOD_RESULT::FMOD_OK_0) )
    {
      if ( v16 && mSystem )
        FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
      if ( newhead || newtail )
        return (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD::DSPI *, FMOD::DSPI *))this->_vptr_ChannelControlI
                + 61))(
                 this,
                 newhead,
                 newtail);
      return FMOD_RESULT::FMOD_OK_0;
    }
    v3 = v14;
    if ( v16 && mSystem )
      FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
  }
  return v3;
}


// Address: 0x220fea0 | Name: _ZN4FMOD15ChannelControlI6addDSPEiPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::addDSP(FMOD::ChannelControlI *const this, int index, FMOD::DSPI *dsp)
{
  FMOD::DSPI *v3; // rbp
  FMOD::DSPI *mDSPHead; // r12
  FMOD::DSPI *mDSPTail; // r14
  FMOD_RESULT_0 v7; // eax
  FMOD::DSPFader *mDSPFader; // r13
  int mNumDSPs; // eax
  FMOD_CLOCKTIME mClockNext; // rax
  FMOD::SystemI *mSystem; // rdi
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *p_mGainModifierHead; // r13
  int i; // r8d
  int v15; // esi
  FMOD::LinkedListNode *p_mGainModifierNode; // rdi
  int v17; // ecx
  FMOD::LinkedListNode *v18; // rax
  void *mNodeData; // rdx
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::DSPI **v21; // r13
  int v22; // edi
  int v23; // r8d
  __int64 v24; // rdx
  int v25; // ecx
  FMOD::DSPI **mDSP; // rsi
  FMOD::DSPI *v27; // rax
  FMOD::DSPI **v28; // rsi
  int v29; // eax
  FMOD::DSPI *v30; // rdx
  FMOD::DSPI *v31; // rax
  FMOD_RESULT_0 result; // [rsp+8h] [rbp-40h]
  int indexa; // [rsp+Ch] [rbp-3Ch] BYREF
  FMOD::LocalSystemSection crit_dspqueue; // [rsp+10h] [rbp-38h] BYREF

  v3 = dsp;
  indexa = index;
  if ( !dsp )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD::DSPI *, _QWORD))this->_vptr_ChannelControlI
        + 39))(
         this,
         dsp,
         0)
    || (v7 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD::DSPI *))this->_vptr_ChannelControlI
              + 35))(
               this,
               v3)) == FMOD_RESULT::FMOD_OK_0 )
  {
    mDSPHead = this->mDSPHead;
    mDSPTail = this->mDSPTail;
    v7 = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
    mDSPFader = this->mDSPFader;
    if ( mDSPHead )
    {
      mNumDSPs = indexa;
      if ( indexa == -1 )
      {
        indexa = 0;
        mNumDSPs = 0;
      }
      else
      {
        if ( indexa == -3 )
        {
          mNumDSPs = this->mNumDSPs;
          indexa = mNumDSPs;
        }
        else if ( indexa == -2 )
        {
          v7 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD::DSPFader *, int *))this->_vptr_ChannelControlI
                + 39))(
                 this,
                 this->mDSPFader,
                 &indexa);
          if ( v7 )
            return v7;
          mNumDSPs = indexa;
        }
        if ( mNumDSPs < 0 )
          return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      }
      if ( mNumDSPs > this->mNumDSPs )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      v3->mChannelOwner = this;
      v7 = FMOD::DSPI::reset(v3);
      if ( v7 == FMOD_RESULT::FMOD_OK_0 )
      {
        v3->mJob.mDelayClock.mClock = mDSPTail->mJob.mDelayClock.mClock;
        mClockNext = mDSPTail->mJob.mDelayClock.mClockNext;
        v3->mJob.mFlags |= 0x100u;
        v3->mJob.mDelayClock.mClockNext = mClockNext;
        v7 = FMOD::DSPI::setActive(v3, 1, 1);
        if ( v7 == FMOD_RESULT::FMOD_OK_0 )
        {
          mSystem = this->mSystem;
          crit_dspqueue.mEntered = 0;
          crit_dspqueue.mCritType = FMOD_SYSTEM_CRIT_DSPQUEUE;
          crit_dspqueue.mSystem = mSystem;
          if ( mSystem )
          {
            FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
            crit_dspqueue.mEntered = 1;
          }
          v7 = FMOD::DSPI::addInputChainAt(mDSPHead, v3, -1, indexa, 1, 0);
          if ( v7
            || !indexa
            && (v7 = FMOD::DSPFader::setHeadDSPClock(mDSPFader, &v3->mJob.mDelayClock, 0)) != FMOD_RESULT::FMOD_OK_0 )
          {
            if ( crit_dspqueue.mEntered )
            {
              result = v7;
              FMOD::LocalSystemSection::leave(&crit_dspqueue);
              return result;
            }
            return v7;
          }
          if ( crit_dspqueue.mEntered )
            FMOD::LocalSystemSection::leave(&crit_dspqueue);
          mNodeNext = this->mGainModifierHead.mNodeNext;
          p_mGainModifierHead = &this->mGainModifierHead;
          for ( i = indexa; mNodeNext != p_mGainModifierHead; mNodeNext = mNodeNext->mNodeNext )
          {
            v15 = (int)mNodeNext->mNodeData >> 16;
            if ( v15 >= i )
              mNodeNext->mNodeData = (void *)(((unsigned __int64)(unsigned __int16)(v15 + 1) << 16)
                                            | (unsigned __int64)mNodeNext->mNodeData & 0xFFFFFFFF0000FFFFLL);
          }
          if ( FMOD::DSPI::getDataParameterIndex(v3, -1, (int *)&crit_dspqueue) )
            goto LABEL_44;
          p_mGainModifierNode = &v3->mJob.mGainModifierNode;
          if ( &v3->mJob.mGainModifierNode != v3->mJob.mGainModifierNode.mNodeNext )
            return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          if ( p_mGainModifierNode != v3->mJob.mGainModifierNode.mNodePrev )
            return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          if ( SLODWORD(crit_dspqueue.mSystem) > 32766 )
            return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          v17 = indexa;
          if ( indexa > 32766 )
            return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          v3->mJob.mGainModifierNode.mNodeData = (void *)(LOWORD(crit_dspqueue.mSystem)
                                                        | ((unsigned __int64)(unsigned __int16)indexa << 16));
          v18 = this->mGainModifierHead.mNodeNext;
          mNodeData = v18->mNodeData;
          if ( v18 != p_mGainModifierHead )
          {
            while ( v17 > (int)mNodeData >> 16 )
            {
              v18 = v18->mNodeNext;
              mNodeData = v18->mNodeData;
              if ( v18 == p_mGainModifierHead )
                goto LABEL_43;
            }
            if ( v17 == (int)mNodeData >> 16 )
              return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          }
LABEL_43:
          mNodePrev = v18->mNodePrev;
          v3->mJob.mGainModifierNode.mNodeNext = v18;
          v3->mJob.mGainModifierNode.mNodePrev = mNodePrev;
          v18->mNodePrev = p_mGainModifierNode;
          v3->mJob.mGainModifierNode.mNodePrev->mNodeNext = p_mGainModifierNode;
          v7 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 65))(this);
          if ( v7 == FMOD_RESULT::FMOD_OK_0 )
          {
LABEL_44:
            v21 = (FMOD::DSPI **)FMOD::MemPool::alloc(
                                   (FMOD::MemPool *const)((char *)&stru_10818 + (unsigned __int64)this->mSystem),
                                   8 * this->mNumDSPs + 8,
                                   (const char *)&uri_string,
                                   0,
                                   0,
                                   0);
            if ( !v21 )
              return FMOD_RESULT::FMOD_ERR_MEMORY_0;
            v22 = this->mNumDSPs + 1;
            this->mNumDSPs = v22;
            if ( v22 > 0 )
            {
              v23 = indexa;
              v24 = 0;
              v25 = 0;
              do
              {
                if ( v23 == (_DWORD)v24 )
                {
                  v21[v24] = v3;
                }
                else
                {
                  mDSP = this->mDSP;
                  if ( mDSP )
                    v27 = mDSP[v25];
                  else
                    v27 = mDSPHead;
                  v21[v24] = v27;
                  ++v25;
                }
                ++v24;
              }
              while ( v22 > (int)v24 );
            }
            v28 = this->mDSP;
            if ( v28 )
              FMOD::MemPool::free(
                (FMOD::MemPool *const)((char *)&stru_10818 + (unsigned __int64)this->mSystem),
                v28,
                (const char *)&uri_string,
                0);
            v29 = indexa;
            this->mDSP = v21;
            if ( v29 )
            {
              if ( v29 != this->mNumDSPs - 1 )
                return FMOD_RESULT::FMOD_OK_0;
              v31 = 0;
            }
            else
            {
              v30 = 0;
              v31 = v3;
              if ( this->mNumDSPs != 1 )
                return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelControlI *const, FMOD::DSPI *, FMOD::DSPI *))this->_vptr_ChannelControlI
                        + 61))(
                         this,
                         v3,
                         v30);
            }
            v30 = v3;
            v3 = v31;
            return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelControlI *const, FMOD::DSPI *, FMOD::DSPI *))this->_vptr_ChannelControlI
                    + 61))(
                     this,
                     v3,
                     v30);
          }
        }
      }
    }
  }
  return v7;
}


// Address: 0x2210290 | Name: _ZN4FMOD15ChannelControlI9removeDSPEPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::removeDSP(FMOD::ChannelControlI *const this, FMOD::DSPI *dsp)
{
  FMOD_RESULT_0 v2; // r13d
  FMOD::DSPI *mDSPHead; // rax
  FMOD::SystemI *mDSPFader; // r15
  unsigned int v6; // r12d
  bool v7; // zf
  int v9; // ebp
  int (**vptr_ChannelControlI)(...); // rax
  FMOD_RESULT_0 v11; // eax
  FMOD::SystemI *mSystem; // rdi
  int v13; // ebp
  FMOD_RESULT_0 v14; // eax
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::ChannelControlI *i; // rax
  int v17; // ecx
  int mNumDSPs; // eax
  FMOD::DSPI **v19; // r12
  FMOD::DSPI **mDSP; // rsi
  FMOD::DSPI *v21; // rsi
  int v22; // eax
  int v23; // eax
  __int64 v24; // rcx
  int v25; // edx
  int v26; // edx
  __int64 v27; // rdi
  int numdsps; // [rsp+Ch] [rbp-5Ch] BYREF
  FMOD::DSPI *newhead; // [rsp+10h] [rbp-58h] BYREF
  __int64 numdsps_0; // [rsp+18h] [rbp-50h] BYREF
  FMOD::LocalSystemSection crit_dspqueue; // [rsp+20h] [rbp-48h] BYREF

  v2 = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
  mDSPHead = this->mDSPHead;
  mDSPFader = (FMOD::SystemI *)this->mDSPFader;
  if ( mDSPHead )
  {
    if ( mDSPHead == this->mDSPTail )
      return FMOD_RESULT::FMOD_OK_0;
    v6 = (unsigned int)dsp;
    if ( !dsp )
    {
      v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, __int64 *))this->_vptr_ChannelControlI + 37))(
             this,
             &numdsps_0);
      if ( v2 )
        return v2;
      if ( (int)numdsps_0 <= 0 )
        return (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 65))(this);
      v13 = 0;
      while ( 1 )
      {
        v11 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, _QWORD, FMOD::LocalSystemSection *))this->_vptr_ChannelControlI
               + 36))(
                this,
                v6,
                &crit_dspqueue);
        if ( v11 )
          break;
        if ( crit_dspqueue.mSystem == mDSPFader )
          ++v6;
        else
          (*((void (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 35))(this);
        if ( (int)numdsps_0 <= ++v13 )
          return (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 65))(this);
      }
      return v11;
    }
    v7 = SLOBYTE(dsp->mJob.mFlags) >= 0;
    newhead = 0;
    v2 = FMOD_RESULT::FMOD_ERR_DSP_RESERVED_0;
    numdsps_0 = 0;
    if ( v7 )
    {
      v2 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, int *))this->_vptr_ChannelControlI + 37))(
             this,
             &numdsps);
      if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( numdsps <= 0 )
          return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
        v9 = 0;
        while ( 1 )
        {
          vptr_ChannelControlI = this->_vptr_ChannelControlI;
          crit_dspqueue.mSystem = 0;
          v11 = vptr_ChannelControlI[36](this, (unsigned int)v9, &crit_dspqueue);
          if ( v11 )
            return v11;
          if ( (FMOD::DSPI *)crit_dspqueue.mSystem == dsp )
            break;
          if ( numdsps <= ++v9 )
            return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
        }
        if ( numdsps <= v9 )
          return FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
        if ( v9 )
        {
          if ( numdsps - 1 == v9 )
            (*((void (__fastcall **)(FMOD::ChannelControlI *const, _QWORD, __int64 *))this->_vptr_ChannelControlI + 36))(
              this,
              (unsigned int)(numdsps - 2),
              &numdsps_0);
        }
        else
        {
          (*((void (__fastcall **)(FMOD::ChannelControlI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI + 36))(
            this,
            1,
            &newhead);
        }
        mSystem = this->mSystem;
        crit_dspqueue.mEntered = 0;
        crit_dspqueue.mCritType = FMOD_SYSTEM_CRIT_DSPQUEUE;
        crit_dspqueue.mSystem = mSystem;
        if ( mSystem )
        {
          FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
          crit_dspqueue.mEntered = 1;
        }
        dsp->mJob.mFlags &= ~0x100u;
        dsp->mChannelOwner = 0;
        v2 = FMOD::DSPI::setActive(dsp, 0, 0);
        if ( v2 )
        {
LABEL_21:
          if ( crit_dspqueue.mEntered && crit_dspqueue.mSystem )
          {
            crit_dspqueue.mEntered = 0;
            FMOD::SystemI::leaveCrit(crit_dspqueue.mSystem, crit_dspqueue.mCritType);
          }
          return v2;
        }
        v14 = FMOD::DSPI::removeToInclusive(dsp, dsp, 0);
        if ( v14
          || newhead
          && (v14 = FMOD::DSPFader::setHeadDSPClock((FMOD::DSPFader *const)mDSPFader, &newhead->mJob.mDelayClock, 0)) != FMOD_RESULT::FMOD_OK_0 )
        {
          v2 = v14;
          goto LABEL_21;
        }
        if ( crit_dspqueue.mEntered )
          FMOD::LocalSystemSection::leave(&crit_dspqueue);
        mNodePrev = dsp->mJob.mGainModifierNode.mNodePrev;
        mNodePrev->mNodeNext = dsp->mJob.mGainModifierNode.mNodeNext;
        dsp->mJob.mGainModifierNode.mNodeNext->mNodePrev = mNodePrev;
        dsp->mJob.mGainModifierNode.mNodePrev = &dsp->mJob.mGainModifierNode;
        dsp->mJob.mGainModifierNode.mNodeNext = &dsp->mJob.mGainModifierNode;
        for ( i = (FMOD::ChannelControlI *)this->mGainModifierHead.mNodeNext;
              i != (FMOD::ChannelControlI *)&this->mGainModifierHead;
              i = (FMOD::ChannelControlI *)i->_vptr_ChannelControlI )
        {
          v17 = (int)i->mDSP >> 16;
          if ( v17 > v9 )
            i->mDSP = (FMOD::DSPI **)(((unsigned __int64)(unsigned __int16)(v17 - 1) << 16)
                                    | (unsigned __int64)i->mDSP & 0xFFFFFFFF0000FFFFLL);
        }
        mNumDSPs = this->mNumDSPs;
        v19 = 0;
        if ( mNumDSPs > 2 )
        {
          v19 = (FMOD::DSPI **)FMOD::MemPool::alloc(
                                 (FMOD::MemPool *const)((char *)&stru_10818 + (unsigned __int64)this->mSystem),
                                 8 * mNumDSPs - 8,
                                 (const char *)&uri_string,
                                 0,
                                 0,
                                 0);
          if ( !v19 )
            return FMOD_RESULT::FMOD_ERR_MEMORY_0;
          v22 = this->mNumDSPs;
          if ( v22 > 1 )
          {
            v23 = v22 - 1;
            v24 = 0;
            v25 = 0;
            do
            {
              v26 = (v9 == (_DWORD)v24) + v25;
              v27 = v26;
              v25 = v26 + 1;
              v19[v24++] = this->mDSP[v27];
            }
            while ( v23 > (int)v24 );
          }
        }
        mDSP = this->mDSP;
        if ( mDSP )
          FMOD::MemPool::free(
            (FMOD::MemPool *const)((char *)&stru_10818 + (unsigned __int64)this->mSystem),
            mDSP,
            (const char *)&uri_string,
            0);
        v21 = newhead;
        this->mDSP = v19;
        if ( !v21 && !numdsps_0
          || (v11 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD::DSPI *, __int64))this->_vptr_ChannelControlI
                     + 61))(
                      this,
                      v21,
                      numdsps_0)) == FMOD_RESULT::FMOD_OK_0 )
        {
          --this->mNumDSPs;
          return (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 65))(this);
        }
        return v11;
      }
    }
  }
  return v2;
}


// Address: 0x22106b0 | Name: _ZN4FMOD15ChannelControlI21calculate3DReverbGainEPNS_7ReverbIEP11FMOD_VECTORPf
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::calculate3DReverbGain(
        FMOD::ChannelControlI *const this,
        FMOD::ReverbI *reverb,
        FMOD_VECTOR *channelpos,
        float *gain)
{
  float direct_o; // [rsp+8h] [rbp-40h] BYREF
  float reverb_o; // [rsp+Ch] [rbp-3Ch] BYREF
  FMOD_VECTOR reverbpos; // [rsp+10h] [rbp-38h] BYREF

  if ( !gain )
    return FMOD_RESULT::FMOD_OK_0;
  if ( reverb )
  {
    FMOD::ReverbI::calculateDistanceGain(reverb, channelpos, gain, 0);
    if ( *gain > 0.0 )
    {
      FMOD::ReverbI::get3DAttributes(reverb, &reverbpos, 0, 0);
      FMOD::GeometryMgr::lineTestAll(&this->mSystem->mGeometryMgr, channelpos, &reverbpos, &direct_o, &reverb_o);
      *gain = (float)(1.0 - reverb_o) * *gain;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  *gain = 1.0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2210770 | Name: _ZN4FMOD15ChannelControlI19distanceAttenuationEfj
float __fastcall FMOD::ChannelControlI::distanceAttenuation(
        FMOD::ChannelControlI *const this,
        float a2,
        float distance,
        unsigned int rolloffMode,
        double a5,
        double a6,
        float a7)
{
  FMOD_DSP_PAN_3D_ROLLOFF_TYPE v9; // edi
  float gain[3]; // [rsp+Ch] [rbp-Ch] BYREF

  if ( rolloffMode == 0x400000 )
  {
    v9 = FMOD_DSP_PAN_3D_ROLLOFF_LINEARSQUARED;
    goto LABEL_7;
  }
  if ( rolloffMode <= 0x400000 )
  {
    v9 = FMOD_DSP_PAN_3D_ROLLOFF_LINEAR;
    if ( rolloffMode != 0x200000 )
LABEL_9:
      v9 = FMOD_DSP_PAN_3D_ROLLOFF_INVERSE;
  }
  else
  {
    if ( rolloffMode != (_DWORD)&unk_800000 )
    {
      if ( rolloffMode == 0x4000000 )
        return 1.0;
      goto LABEL_9;
    }
    v9 = FMOD_DSP_PAN_3D_ROLLOFF_INVERSETAPERED;
  }
LABEL_7:
  FMOD::getRolloffGain(
    v9,
    a2,
    this->mMinDistance,
    this->mMaxDistance,
    *(float *)((char *)&stru_11358.r_offset + (unsigned __int64)this->mSystem),
    gain,
    a7);
  return gain[0];
}


// Address: 0x2210810 | Name: _ZN4FMOD15ChannelControlI6updateEibb
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::update(
        FMOD::ChannelControlI *const this,
        int delta_ms,
        bool updategeometrynow,
        bool forceupdatepos)
{
  int (**vptr_ChannelControlI)(...); // rax
  float mDSPDirectVolume; // xmm4_4
  float mDSPSendVolume; // xmm5_4
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *v9; // r13
  FMOD::LinkedListNode *p_mGainModifierHead; // r15
  FMOD::ChannelControlI *mNodeNext; // rax
  char v12; // r12
  int v13; // edx
  float v14; // xmm1_4
  float v15; // xmm0_4
  int (**v16)(...); // rbx
  FMOD::DSPI *p_m3DLevel; // rdi
  FMOD::DSPI **mDSP; // r14
  float v19; // xmm2_4
  float v20; // xmm3_4
  float v21; // xmm1_4
  float v22; // xmm0_4
  float mVolume; // xmm2_4
  float v24; // xmm2_4
  float v25; // xmm3_4
  float v26; // xmm1_4
  float v27; // xmm0_4
  float v28; // xmm2_4
  float v29; // [rsp+Ch] [rbp-6Ch]
  float v30; // [rsp+18h] [rbp-60h]
  int faderindex; // [rsp+2Ch] [rbp-4Ch] BYREF
  FMOD::DSPI *dspi; // [rsp+30h] [rbp-48h] BYREF
  FMOD_DSP_PARAMETER_OVERALLGAIN *gain; // [rsp+38h] [rbp-40h] BYREF

  vptr_ChannelControlI = this->_vptr_ChannelControlI;
  mDSPDirectVolume = this->mDSPDirectVolume;
  mDSPSendVolume = this->mDSPSendVolume;
  faderindex = 0;
  v29 = mDSPDirectVolume;
  v30 = mDSPSendVolume;
  result = vptr_ChannelControlI[36](this, 4294967294LL, &dspi);
  if ( result )
    return result;
  v9 = dspi;
  p_mGainModifierHead = &this->mGainModifierHead;
  (*((void (__fastcall **)(FMOD::ChannelControlI *const, FMOD::DSPI *, int *))this->_vptr_ChannelControlI + 39))(
    this,
    dspi,
    &faderindex);
  mNodeNext = (FMOD::ChannelControlI *)this->mGainModifierHead.mNodeNext;
  if ( &this->mGainModifierHead == (FMOD::LinkedListNode *)mNodeNext )
  {
    v14 = 0.0;
    v15 = 1.0;
    goto LABEL_16;
  }
  v12 = 0;
  v13 = -1;
  v14 = 0.0;
  v15 = 1.0;
  while ( 1 )
  {
    v16 = mNodeNext->_vptr_ChannelControlI;
    p_m3DLevel = (FMOD::DSPI *)&mNodeNext[-1].m3DLevel;
    mDSP = mNodeNext->mDSP;
    if ( faderindex > v13 && faderindex < (int)mDSP >> 16 )
    {
      v19 = *(float *)&v9[1].mJob.mDelayClock.mDelayStart;
      v20 = *(float *)&v9[1].mJob.mGainModifierNode.mNodeNext;
      if ( v19 <= v20 )
      {
        v21 = v14 * v20;
        v19 = *(float *)&v9[1].mJob.mGainModifierNode.mNodeNext;
      }
      else
      {
        v21 = v14 * v19;
      }
      v22 = v15 * v19;
      mVolume = this->mVolume;
      v14 = v21 * mVolume;
      v12 = 1;
      v15 = v22 * mVolume;
    }
    if ( (p_m3DLevel->mJob.mFlags & 1) == 0 )
      break;
    v13 = (int)mDSP >> 16;
    if ( p_mGainModifierHead == (FMOD::LinkedListNode *)v16 )
      goto LABEL_15;
LABEL_6:
    mNodeNext = (FMOD::ChannelControlI *)v16;
  }
  gain = 0;
  result = FMOD::DSPI::getParameterData(p_m3DLevel, (__int16)mDSP, (void **)&gain, 0, 0, 0);
  if ( result )
    return result;
  v13 = (int)mDSP >> 16;
  v15 = v15 * gain->linear_gain;
  v14 = (float)(v14 * gain->linear_gain) + gain->linear_gain_additive;
  if ( p_mGainModifierHead != (FMOD::LinkedListNode *)v16 )
    goto LABEL_6;
LABEL_15:
  if ( !v12 )
  {
LABEL_16:
    if ( v9 )
    {
      v24 = *(float *)&v9[1].mJob.mDelayClock.mDelayStart;
      v25 = *(float *)&v9[1].mJob.mGainModifierNode.mNodeNext;
      if ( v24 <= v25 )
      {
        v26 = v14 * v25;
        v24 = *(float *)&v9[1].mJob.mGainModifierNode.mNodeNext;
      }
      else
      {
        v26 = v14 * v24;
      }
      v27 = v15 * v24;
      v28 = this->mVolume;
      v14 = v26 * v28;
      v15 = v27 * v28;
    }
  }
  this->mDSPDirectVolume = v15;
  this->mDSPSendVolume = v14;
  if ( (float)(v15 + v14) == (float)(v29 + v30) && !forceupdatepos )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 66))(this);
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 64))(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelControlI *const))this->_vptr_ChannelControlI + 66))(this);
  return result;
}


// Address: 0x2210a60 | Name: _ZN4FMOD15ChannelControlI19set3DMinMaxDistanceEff
char __fastcall FMOD::ChannelControlI::set3DMinMaxDistance(
        FMOD::ChannelControlI *const this,
        double a2,
        float mindistance,
        float maxdistance)
{
  FMOD_RESULT_0 v4; // eax
  FMOD_MODE v5; // edx
  FMOD_MODE mode[3]; // [rsp+1Ch] [rbp-Ch] BYREF

  v4 = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, FMOD_MODE *, double, float, float))this->_vptr_ChannelControlI
        + 19))(
         this,
         mode,
         a2,
         mindistance,
         maxdistance);
  if ( v4 == FMOD_RESULT::FMOD_OK_0 )
  {
    v5 = mode[0];
    LOBYTE(v4) = 40;
    if ( (mode[0] & 0x10) != 0 )
    {
      LOBYTE(v4) = 29;
      if ( (LODWORD(a2) & 0x7F800000) != 0x7F800000 && (LODWORD(mindistance) & 0x7F800000) != 0x7F800000 )
      {
        if ( *(float *)&a2 < 0.0 || mindistance < 0.0 )
        {
          LOBYTE(v4) = 31;
        }
        else
        {
          LOBYTE(v4) = 31;
          if ( *(float *)&a2 <= mindistance )
          {
            if ( *(float *)&a2 == this->mMinDistance && mindistance == this->mMaxDistance )
            {
              LOBYTE(v4) = 0;
            }
            else
            {
              this->mMinDistance = *(float *)&a2;
              this->mMaxDistance = mindistance;
              if ( (v5 & 0x4F00000) != 0 || this->mSystem->mRolloffCallback )
              {
                this->mFlags |= 4u;
                v4 = FMOD::ChannelControlI::update(this, 0, 0, 0);
                if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                  LOBYTE(v4) = (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelControlI *const, _QWORD, float))this->_vptr_ChannelControlI
                                + 4))(
                                 this,
                                 0,
                                 this->mVolume);
              }
              else
              {
                this->mFlags |= 4u;
                LOBYTE(v4) = 0;
              }
            }
          }
        }
      }
    }
  }
  return v4;
}


// Address: 0x2210b80 | Name: _ZN4FMOD15ChannelControlI8validateEPNS_14ChannelControlEPPS0_PNS_15SystemLockScopeE
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::validate(
        FMOD::ChannelControl *channelcontrol,
        FMOD::ChannelControlI **channelcontroli,
        FMOD::SystemLockScope *lockScope)
{
  if ( ((unsigned __int8)channelcontrol & 1) != 0 )
    return FMOD::ChannelI::validate((FMOD::Channel *)channelcontrol, (FMOD::ChannelI **)channelcontroli, lockScope);
  else
    return FMOD::ChannelGroupI::validate(
             (FMOD::ChannelGroup *)channelcontrol,
             (FMOD::ChannelGroupI **)channelcontroli,
             lockScope);
}


// Address: 0x2210ba0 | Name: _ZN4FMOD15ChannelControlI11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::setUserData(FMOD::ChannelControlI *const this, void *userdata)
{
  this->mUserData = userdata;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2210bb0 | Name: _ZN4FMOD15ChannelControlI11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::getUserData(FMOD::ChannelControlI *const this, void **userdata)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( userdata )
  {
    *userdata = this->mUserData;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2210bd0 | Name: _ZN4FMOD15ChannelControlI15executeCallbackEP19FMOD_CHANNELCONTROL24FMOD_CHANNELCONTROL_TYPE33FMOD_CHANNELCONTROL_CALLBACK_TYPEPvS5_
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::executeCallback(
        FMOD::ChannelControlI *const this,
        FMOD_CHANNELCONTROL *channel,
        FMOD_CHANNELCONTROL_TYPE_0 controltype,
        FMOD_CHANNELCONTROL_CALLBACK_TYPE_0 callbacktype,
        void *commanddata1,
        void *commanddata2)
{
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 v11; // ebp

  result = FMOD::SystemI::enterUserCallback(this->mSystem, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v11 = this->mCallback(
            channel,
            (FMOD_CHANNELCONTROL_TYPE)controltype,
            (FMOD_CHANNELCONTROL_CALLBACK_TYPE)callbacktype,
            commanddata1,
            commanddata2);
    result = FMOD::SystemI::leaveUserCallback(this->mSystem);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return v11;
  }
  return result;
}


// Address: 0x2210c40 | Name: _ZN4FMOD15ChannelControlI8update3DEib
FMOD_RESULT_0 __fastcall FMOD::ChannelControlI::update3D(
        FMOD::ChannelControlI *const this,
        int delta_ms,
        bool updategeometrynow)
{
  __int128 mReverbOcclusionTarget_low; // xmm1
  __int128 mDirectOcclusionTarget_low; // xmm2
  double v5; // xmm3_8
  __int64 mDirectOcclusionRateOfChange_low; // xmm6_8
  double v7; // xmm7_8
  int (**vptr_ChannelControlI)(...); // rax
  FMOD_RESULT_0 result; // eax
  unsigned __int64 v13; // xmm4_8
  FMOD::SystemI *v14; // rdi
  bool v15; // zf
  double v16; // xmm0_8
  FMOD::SystemI *v17; // rdi
  int v18; // edx
  FMOD::SystemI *v19; // rax
  FMOD::SystemI *v20; // rdx
  double v21; // xmm5_8
  FMOD::SystemI *v22; // rsi
  float *v23; // rdx
  double v24; // xmm4_8
  double v25; // xmm11_8
  float v26; // xmm9_4
  float v27; // xmm8_4
  FMOD_SPEAKERMODE_0 mSpeakerMode; // r8d
  unsigned int v29; // r13d
  int v30; // r14d
  int v31; // r9d
  double v32; // xmm2_8
  float *v33; // r10
  __int64 v34; // r15
  FMOD::SystemI *v35; // rsi
  float *v36; // rcx
  int v37; // eax
  __int64 v38; // rcx
  FMOD::SystemI *mSystem; // rdi
  int mNumListeners; // edx
  FMOD::SystemI *v41; // rax
  FMOD::SystemI *v42; // rdx
  char v43; // r13
  float v44; // xmm5_4
  int geometryMaxFadeTime; // eax
  __m128 v46; // xmm0
  __m128 v47; // xmm0
  float mReverbOcclusionRateOfChange; // xmm5_4
  double v49; // xmm0_8
  int v50; // ebp
  float y; // xmm4_4
  float v52; // xmm1_4
  FMOD::SystemI *v53; // rdi
  float v54; // xmm0_4
  FMOD::SystemI *v55; // rdi
  float mVolume3D; // xmm0_4
  __m128 x_low; // xmm5
  float v58; // xmm0_4
  double v59; // xmm0_8
  float z; // xmm8_4
  __m128 v61; // xmm0
  __m128 v62; // xmm0
  float v63; // xmm6_4
  __m128 v64; // xmm0
  float v65; // eax
  FMOD::SystemI *v66; // rdx
  __int64 v67; // rax
  float *p_x; // r12
  float v69; // xmm9_4
  float v70; // xmm8_4
  float v71; // xmm5_4
  float v72; // xmm4_4
  float v73; // xmm0_4
  float mConeOutsideAngle; // xmm4_4
  float v75; // xmm4_4
  float v76; // xmm0_4
  FMOD_VECTOR *mRolloffPoint; // rax
  int mNumRolloffPoints; // edx
  float *v79; // rcx
  __int64 v80; // rcx
  FMOD_VECTOR *v81; // rdx
  float x; // xmm1_4
  FMOD_CHANNELCONTROL *mHandleCurrent; // rsi
  FMOD::OCCLUSION_TASK *Occlusion; // rax
  float v85; // xmm2_4
  FMOD::SystemI *v86; // r8
  __int64 v87; // rdi
  FMOD_SPEAKERCONFIG *v88; // rax
  FMOD::SystemI *v89; // rsi
  FMOD_SPEAKERCONFIG *v90; // rbp
  int v91; // ecx
  FMOD_SPEAKERCONFIG *v92; // r12
  float mXZAngle; // xmm2_4
  float v94; // xmm6_4
  FMOD::SystemI *v95; // rcx
  float v96; // xmm2_4
  float v97; // xmm5_4
  float v98; // xmm2_4
  float v99; // xmm9_4
  float v100; // xmm10_4
  float v101; // xmm8_4
  float v102; // xmm11_4
  float v103; // xmm1_4
  float v104; // xmm5_4
  float v105; // xmm2_4
  float v106; // xmm8_4
  float *v107; // rax
  float *j; // rdx
  __m128 v109; // xmm4
  unsigned __int32 v110; // xmm5_4
  __m128 v111; // xmm4
  float *v112; // rax
  int v113; // r11d
  float *v114; // rbp
  int v115; // r8d
  float *v116; // r10
  float *v117; // rcx
  int i; // edx
  float *v119; // rsi
  int v120; // edi
  float *v121; // rsi
  float *v122; // rdx
  unsigned __int64 v123; // rax
  float v124; // xmm0_4
  float v125; // xmm1_4
  float v126; // xmm0_4
  int v127; // r12d
  __int64 v128; // rbp
  float v129; // xmm0_4
  float *mData; // r10
  __int16 mOutChannels; // r9
  __int64 v132; // rax
  __int64 v133; // r8
  float *v134; // rcx
  int mInChannels; // esi
  float _2dmix; // [rsp+8h] [rbp-E00h]
  unsigned __int32 _2dmixa; // [rsp+8h] [rbp-E00h]
  float _3dmix; // [rsp+10h] [rbp-DF8h]
  float _3dmixa; // [rsp+10h] [rbp-DF8h]
  unsigned __int32 _3dmixb; // [rsp+10h] [rbp-DF8h]
  float lrpan_base; // [rsp+18h] [rbp-DF0h]
  char distance; // [rsp+28h] [rbp-DE0h]
  unsigned int v143; // [rsp+30h] [rbp-DD8h]
  unsigned int cost; // [rsp+A8h] [rbp-D60h] BYREF
  unsigned int sint[4]; // [rsp+ACh] [rbp-D5Ch] BYREF
  FMOD_MODE mode; // [rsp+BCh] [rbp-D4Ch] BYREF
  unsigned int dopplerscale; // [rsp+C0h] [rbp-D48h] BYREF
  float distancescale; // [rsp+C4h] [rbp-D44h] BYREF
  float rolloffscale; // [rsp+C8h] [rbp-D40h] BYREF
  int numsubchannels; // [rsp+CCh] [rbp-D3Ch] BYREF
  float lrpan[32]; // [rsp+D0h] [rbp-D38h] BYREF
  float fbpan[32]; // [rsp+150h] [rbp-CB8h] BYREF
  float speakerlevel[12][32]; // [rsp+1D0h] [rbp-C38h] BYREF
  float level2d[12][32]; // [rsp+7D0h] [rbp-638h] BYREF

  vptr_ChannelControlI = this->_vptr_ChannelControlI;
  mode = 0;
  result = vptr_ChannelControlI[19](this, &mode);
  if ( result )
    return result;
  if ( (mode & 0x40000010) != 0x10 )
    goto LABEL_3;
  v15 = (this->mFlags & 4) == 0;
  _2dmix = this->mDirectOcclusionTarget;
  mSystem = this->mSystem;
  _3dmix = this->mReverbOcclusionTarget;
  if ( v15 )
  {
    mNumListeners = mSystem->mNumListeners;
    if ( mNumListeners > 0 )
    {
      if ( mSystem->mListener[0].mMoved )
        goto LABEL_48;
      v41 = mSystem;
      v42 = (FMOD::SystemI *)((char *)mSystem + 112 * (unsigned int)(mNumListeners - 1));
      while ( v41 != v42 )
      {
        v41 = (FMOD::SystemI *)((char *)v41 + 112);
        if ( v41->mListener[0].mMoved )
          goto LABEL_48;
      }
    }
    if ( !*((_BYTE *)&stru_122A0.r_offset + (_QWORD)mSystem) && !updategeometrynow )
    {
      v43 = 0;
      goto LABEL_137;
    }
  }
LABEL_48:
  if ( !mSystem->mGeometryList )
  {
LABEL_128:
    v43 = 0;
    goto LABEL_53;
  }
  if ( (mode & 0x40000) != 0 )
  {
    level2d[0][0] = this->mPosition3D.x + mSystem->mListener[0].mPosition.x;
    level2d[0][1] = this->mPosition3D.y + mSystem->mListener[0].mPosition.y;
    level2d[0][2] = this->mPosition3D.z + mSystem->mListener[0].mPosition.z;
  }
  else
  {
    *(_QWORD *)&level2d[0][0] = *(_QWORD *)&this->mPosition3D.x;
    level2d[0][2] = this->mPosition3D.z;
  }
  if ( !updategeometrynow )
  {
    FMOD::OcclusionThread::enqueue(
      &mSystem->mGeometryMgr.mOcclusionThread,
      this->mHandleCurrent,
      (FMOD_VECTOR *)level2d);
    goto LABEL_128;
  }
  FMOD::GeometryMgr::lineTestAll(
    &mSystem->mGeometryMgr,
    &mSystem->mListener[0].mPosition,
    (const FMOD_VECTOR *)level2d,
    &this->mDirectOcclusionTarget,
    &this->mReverbOcclusionTarget);
  v43 = 1;
  FMOD::ChannelControlI::calculate3DReverbGain(this, 0, (FMOD_VECTOR *)level2d, speakerlevel[0]);
LABEL_53:
  if ( updategeometrynow )
  {
LABEL_54:
    if ( !this->mCallback || !v43 )
    {
LABEL_56:
      mDirectOcclusionTarget_low = LODWORD(this->mDirectOcclusionTarget);
      mReverbOcclusionTarget_low = LODWORD(this->mReverbOcclusionTarget);
      goto LABEL_57;
    }
    mHandleCurrent = (FMOD_CHANNELCONTROL *)this->mHandleCurrent;
LABEL_134:
    result = FMOD::ChannelControlI::executeCallback(
               this,
               mHandleCurrent,
               FMOD_CHANNELCONTROL_TYPE::FMOD_CHANNELCONTROL_CHANNEL_0,
               FMOD_CHANNELCONTROL_CALLBACK_TYPE::FMOD_CHANNELCONTROL_CALLBACK_OCCLUSION_0,
               &this->mDirectOcclusionTarget,
               &this->mReverbOcclusionTarget);
    if ( result )
      return result;
    goto LABEL_56;
  }
  mSystem = this->mSystem;
LABEL_137:
  Occlusion = FMOD::OcclusionThread::retrieveOcclusion(&mSystem->mGeometryMgr.mOcclusionThread, this->mHandleCurrent);
  if ( !Occlusion )
    goto LABEL_54;
  mHandleCurrent = (FMOD_CHANNELCONTROL *)Occlusion->currenthandle;
  if ( mHandleCurrent != (FMOD_CHANNELCONTROL *)this->mHandleCurrent )
    goto LABEL_54;
  v15 = this->mCallback == 0;
  mDirectOcclusionTarget_low = LODWORD(Occlusion->directocclusion);
  mReverbOcclusionTarget_low = LODWORD(Occlusion->reverbocclusion);
  LODWORD(this->mDirectOcclusionTarget) = mDirectOcclusionTarget_low;
  LODWORD(this->mReverbOcclusionTarget) = mReverbOcclusionTarget_low;
  if ( !v15 )
    goto LABEL_134;
LABEL_57:
  v14 = this->mSystem;
  v44 = 500.0;
  geometryMaxFadeTime = v14->mAdvancedSettings.geometryMaxFadeTime;
  if ( geometryMaxFadeTime )
    v44 = (float)geometryMaxFadeTime;
  mDirectOcclusionRateOfChange_low = LODWORD(_2dmix);
  *(_QWORD *)&v5 = LODWORD(this->mDirectOcclusion);
  if ( _2dmix != *(float *)&mDirectOcclusionTarget_low )
  {
    v46 = (__m128)mDirectOcclusionTarget_low;
    v46.m128_f32[0] = (float)(*(float *)&mDirectOcclusionTarget_low - *(float *)&v5) / v44;
    LODWORD(this->mDirectOcclusionRateOfChange) = v46.m128_i32[0];
    if ( v46.m128_f32[0] < 0.0 )
    {
      v111 = _mm_cmplt_ss((__m128)0xB8D1B717, v46);
      mDirectOcclusionRateOfChange_low = v111.m128_i32[0] & 0xB8D1B717;
      v13 = _mm_andnot_ps(v111, v46).m128_u64[0];
      LODWORD(this->mDirectOcclusionRateOfChange) = v13 | mDirectOcclusionRateOfChange_low;
    }
    else
    {
      HIDWORD(v13) = 0;
      this->mDirectOcclusionRateOfChange = fmaxf(0.000099999997, v46.m128_f32[0]);
    }
  }
  *(_QWORD *)&v7 = LODWORD(_3dmix);
  if ( _3dmix != *(float *)&mReverbOcclusionTarget_low )
  {
    v47 = (__m128)mReverbOcclusionTarget_low;
    v47.m128_f32[0] = (float)(*(float *)&mReverbOcclusionTarget_low - this->mReverbOcclusion) / v44;
    LODWORD(this->mReverbOcclusionRateOfChange) = v47.m128_i32[0];
    if ( v47.m128_f32[0] < 0.0 )
    {
      v109 = _mm_cmplt_ss((__m128)0xB8D1B717, v47);
      v110 = v109.m128_i32[0] & 0xB8D1B717;
      v13 = _mm_andnot_ps(v109, v47).m128_u64[0];
      LODWORD(this->mReverbOcclusionRateOfChange) = v13 | v110;
    }
    else
    {
      HIDWORD(v13) = 0;
      this->mReverbOcclusionRateOfChange = fmaxf(0.000099999997, v47.m128_f32[0]);
    }
  }
  if ( *(float *)&mDirectOcclusionTarget_low == *(float *)&v5
    && *(float *)&mReverbOcclusionTarget_low == this->mReverbOcclusion )
  {
    goto LABEL_4;
  }
  if ( !delta_ms )
  {
    if ( !updategeometrynow )
      goto LABEL_4;
    goto LABEL_130;
  }
  if ( updategeometrynow )
  {
LABEL_130:
    LODWORD(this->mDirectOcclusion) = mDirectOcclusionTarget_low;
    v49 = *(double *)&mDirectOcclusionTarget_low;
    LODWORD(this->mReverbOcclusion) = mReverbOcclusionTarget_low;
    goto LABEL_131;
  }
  mDirectOcclusionRateOfChange_low = LODWORD(this->mDirectOcclusionRateOfChange);
  HIDWORD(v49) = HIDWORD(mDirectOcclusionRateOfChange_low);
  mReverbOcclusionRateOfChange = this->mReverbOcclusionRateOfChange;
  *(float *)&v49 = (float)(*(float *)&mDirectOcclusionRateOfChange_low * (float)delta_ms) + *(float *)&v5;
  HIDWORD(v5) = HIDWORD(v13);
  this->mDirectOcclusion = *(float *)&v49;
  *(float *)&v5 = (float)((float)delta_ms * mReverbOcclusionRateOfChange) + this->mReverbOcclusion;
  this->mReverbOcclusion = *(float *)&v5;
  if ( *(float *)&mDirectOcclusionRateOfChange_low > 0.0 )
  {
    if ( *(float *)&v49 <= *(float *)&mDirectOcclusionTarget_low )
      goto LABEL_72;
    goto LABEL_71;
  }
  if ( *(float *)&mDirectOcclusionTarget_low > *(float *)&v49 )
  {
LABEL_71:
    LODWORD(this->mDirectOcclusion) = mDirectOcclusionTarget_low;
    v49 = *(double *)&mDirectOcclusionTarget_low;
  }
LABEL_72:
  if ( mReverbOcclusionRateOfChange <= 0.0 )
  {
    if ( *(float *)&mReverbOcclusionTarget_low > *(float *)&v5 )
      goto LABEL_74;
LABEL_201:
    *(double *)&mReverbOcclusionTarget_low = v5;
    goto LABEL_131;
  }
  if ( *(float *)&v5 <= *(float *)&mReverbOcclusionTarget_low )
    goto LABEL_201;
LABEL_74:
  LODWORD(this->mReverbOcclusion) = mReverbOcclusionTarget_low;
LABEL_131:
  (*((void (__fastcall **)(FMOD::ChannelControlI *const, _QWORD, double))this->_vptr_ChannelControlI + 51))(
    this,
    0,
    v49);
LABEL_3:
  v14 = this->mSystem;
LABEL_4:
  result = FMOD::SystemI::get3DSettings(v14, (float *)&dopplerscale, &distancescale, &rolloffscale);
  if ( result )
    return result;
  *(_QWORD *)&v16 = dopplerscale;
  v15 = (this->mFlags & 4) == 0;
  *(float *)&v16 = *(float *)&dopplerscale * this->m3DDopplerLevel;
  v17 = this->mSystem;
  dopplerscale = LODWORD(v16);
  if ( !v15 )
    goto LABEL_75;
  v18 = v17->mNumListeners;
  if ( v18 <= 0 )
    goto LABEL_11;
  if ( v17->mListener[0].mMoved )
  {
LABEL_75:
    result = FMOD::SystemI::get3DNumListeners(v17, (int *)level2d);
    if ( result )
      return result;
    v50 = 0;
    mDirectOcclusionRateOfChange_low = 2139095039;
    if ( SLODWORD(level2d[0][0]) <= 0 )
      goto LABEL_11;
    while ( 1 )
    {
      v66 = this->mSystem;
      x_low = (__m128)LODWORD(this->mPosition3D.x);
      v67 = v50;
      p_x = &v66->mListener[v67].mPosition.x;
      if ( (mode & 0x40000) != 0 )
      {
        y = this->mPosition3D.y;
        *(_QWORD *)&v5 = LODWORD(this->mPosition3D.z);
      }
      else
      {
        x_low.m128_f32[0] = x_low.m128_f32[0] - *p_x;
        *(_QWORD *)&v5 = LODWORD(this->mPosition3D.z);
        y = this->mPosition3D.y - v66->mListener[v67].mPosition.y;
        *(float *)&v5 = *(float *)&v5 - v66->mListener[v67].mPosition.z;
      }
      if ( (v66->mFlags & 4) != 0 )
        *(_QWORD *)&v5 ^= 0x80000000uLL;
      *(float *)&mDirectOcclusionTarget_low = fsqrt(
                                                (float)((float)(x_low.m128_f32[0] * x_low.m128_f32[0]) + (float)(y * y))
                                              + (float)(*(float *)&v5 * *(float *)&v5));
      v52 = 0.0;
      if ( *(float *)&mDirectOcclusionRateOfChange_low <= *(float *)&mDirectOcclusionTarget_low )
        goto LABEL_97;
      v53 = this->mSystem;
      LODWORD(this->mDistance) = mDirectOcclusionTarget_low;
      if ( v53->mRolloffCallback )
        break;
      if ( (mode & 0x4000000) == 0 )
      {
        lrpan_base = y;
        _3dmixb = x_low.m128_i32[0];
        mVolume3D = FMOD::ChannelControlI::distanceAttenuation(
                      this,
                      *(float *)&mDirectOcclusionTarget_low,
                      0.0,
                      mode & 0x4F00000,
                      *(double *)&mDirectOcclusionTarget_low,
                      v5,
                      y);
        *(_QWORD *)&v5 = LODWORD(v5);
        this->mVolume3D = mVolume3D;
        y = lrpan_base;
        x_low = (__m128)_3dmixb;
        *(_QWORD *)&mDirectOcclusionTarget_low = (unsigned int)mDirectOcclusionTarget_low;
LABEL_86:
        v52 = 0.0;
        if ( mVolume3D < 0.0 )
        {
          this->mVolume3D = 0.0;
        }
        else if ( mVolume3D > 1.0 )
        {
          this->mVolume3D = 1.0;
        }
        goto LABEL_89;
      }
      mRolloffPoint = this->mRolloffPoint;
      if ( mRolloffPoint )
      {
        mNumRolloffPoints = this->mNumRolloffPoints;
        if ( mNumRolloffPoints )
        {
          v79 = &mRolloffPoint[mNumRolloffPoints - 1].x;
          if ( *(float *)&mDirectOcclusionTarget_low >= *v79 )
          {
            mVolume3D = v79[1];
            this->mVolume3D = mVolume3D;
          }
          else if ( mNumRolloffPoints <= 1 )
          {
LABEL_122:
            mVolume3D = this->mVolume3D;
          }
          else
          {
            v80 = (__int64)&mRolloffPoint[(unsigned int)(mNumRolloffPoints - 2) + 1];
            while ( 1 )
            {
              v81 = mRolloffPoint + 1;
              if ( *(float *)&mDirectOcclusionTarget_low >= mRolloffPoint->x )
              {
                x = mRolloffPoint[1].x;
                if ( x > *(float *)&mDirectOcclusionTarget_low )
                  break;
              }
              ++mRolloffPoint;
              if ( v81 == (FMOD_VECTOR *)v80 )
                goto LABEL_122;
            }
            mVolume3D = (float)((float)(1.0
                                      - (float)((float)(*(float *)&mDirectOcclusionTarget_low - mRolloffPoint->x)
                                              / (float)(x - mRolloffPoint->x)))
                              * mRolloffPoint->y)
                      + (float)((float)((float)(*(float *)&mDirectOcclusionTarget_low - mRolloffPoint->x)
                                      / (float)(x - mRolloffPoint->x))
                              * mRolloffPoint[1].y);
            this->mVolume3D = mVolume3D;
          }
          goto LABEL_86;
        }
      }
      this->mVolume3D = 1.0;
      v52 = 0.0;
LABEL_89:
      *(_QWORD *)&v7 = 1135869952;
      if ( this->mConeOutsideAngle < 360.0
        || (mDirectOcclusionRateOfChange_low = mDirectOcclusionTarget_low, this->mConeInsideAngle < 360.0) )
      {
        *(_QWORD *)&v7 = LODWORD(this->mDistance);
        v58 = 0.0;
        if ( *(float *)&v7 > 0.0 )
        {
          HIDWORD(v59) = 0;
          *(float *)&v59 = 1.0 / *(float *)&v7;
          z = this->mConeOrientation.z;
          v7 = v59;
          if ( (this->mSystem->mFlags & 4) != 0 )
            z = -z;
          x_low.m128_f32[0] = x_low.m128_f32[0] * *(float *)&v59;
          v61 = x_low;
          v61.m128_f32[0] = (float)((float)(x_low.m128_f32[0] * this->mConeOrientation.x)
                                  + (float)((float)(y * *(float *)&v7) * this->mConeOrientation.y))
                          + (float)((float)(*(float *)&v7 * *(float *)&v5) * z);
          v62 = _mm_xor_ps(v61, (__m128)0x80000000);
          v63 = fminf(1.0, v62.m128_f32[0]);
          v64 = _mm_cmpge_ss(v62, (__m128)0xBF800000);
          v64.m128_f32[0] = acosf(COERCE_FLOAT(_mm_andnot_ps(v64, (__m128)0xBF800000).m128_u32[0] | LODWORD(v63) & v64.m128_i32[0]));
          *(_QWORD *)&mDirectOcclusionTarget_low = (unsigned int)mDirectOcclusionTarget_low;
          v58 = (float)((float)(v64.m128_f32[0] / 3.1415927) * 180.0)
              + (float)((float)(v64.m128_f32[0] / 3.1415927) * 180.0);
        }
        *(_QWORD *)&v5 = LODWORD(this->mConeInsideAngle);
        if ( *(float *)&v5 <= v58 )
        {
          mConeOutsideAngle = this->mConeOutsideAngle;
          if ( mConeOutsideAngle <= v58 )
          {
            this->mConeVolume3D = this->mConeOutsideVolume;
            mDirectOcclusionRateOfChange_low = mDirectOcclusionTarget_low;
          }
          else
          {
            v75 = mConeOutsideAngle - *(float *)&v5;
            mDirectOcclusionRateOfChange_low = mDirectOcclusionTarget_low;
            v76 = v58 - *(float *)&v5;
            *(_QWORD *)&v5 = LODWORD(this->mConeOutsideVolume);
            *(float *)&v5 = (float)(*(float *)&v5 * (float)(v76 / v75)) + (float)(1.0 - (float)(v76 / v75));
            this->mConeVolume3D = *(float *)&v5;
          }
        }
        else
        {
          mDirectOcclusionRateOfChange_low = mDirectOcclusionTarget_low;
          this->mConeVolume3D = 1.0;
        }
      }
LABEL_97:
      v65 = level2d[0][0];
      if ( *(float *)&dopplerscale > 0.0 && LODWORD(level2d[0][0]) == 1 )
      {
        v69 = this->mVelocity3D.x;
        if ( (mode & 0x40000) != 0 )
        {
          v70 = this->mVelocity3D.y;
          *(_QWORD *)&v7 = LODWORD(this->mVelocity3D.z);
          v71 = this->mPosition3D.x;
          v72 = this->mPosition3D.y;
          *(_QWORD *)&v5 = LODWORD(this->mPosition3D.z);
        }
        else
        {
          v69 = v69 - p_x[6];
          *(_QWORD *)&v7 = LODWORD(this->mVelocity3D.z);
          v70 = this->mVelocity3D.y - p_x[7];
          *(float *)&v7 = *(float *)&v7 - p_x[8];
          v71 = this->mPosition3D.x - *p_x;
          *(_QWORD *)&v5 = LODWORD(this->mPosition3D.z);
          v72 = this->mPosition3D.y - p_x[1];
          *(float *)&v5 = *(float *)&v5 - p_x[2];
        }
        v73 = fsqrt((float)((float)(v71 * v71) + (float)(v72 * v72)) + (float)(*(float *)&v5 * *(float *)&v5));
        if ( v73 > 0.0 )
        {
          *(float *)&v5 = *(float *)&v5 * *(float *)&v7;
          v52 = (float)((float)((float)(v71 * v69) + (float)(v72 * v70)) + *(float *)&v5) / v73;
        }
        DWORD1(mDirectOcclusionTarget_low) = 0;
        HIDWORD(v16) = 0;
        *(float *)&v16 = (float)((float)(340.0 * distancescale) - (float)(v52 * *(float *)&dopplerscale))
                       / (float)(340.0 * distancescale);
        this->mPitch3D = *(float *)&v16;
      }
      else
      {
        *(_QWORD *)&v16 = LODWORD(this->mPitch3D);
      }
      *(_QWORD *)&mReverbOcclusionTarget_low = 897988541;
      if ( *(float *)&v16 < 0.000001 )
        this->mPitch3D = 0.000001;
      if ( ++v50 >= SLODWORD(v65) )
        goto LABEL_11;
    }
    _3dmixa = y;
    _2dmixa = x_low.m128_i32[0];
    result = FMOD::SystemI::enterUserCallback(v53, 0);
    if ( result )
      return result;
    v54 = ((float (__fastcall *)(FMOD_UINT_NATIVE, float, double))this->mSystem->mRolloffCallback)(
            this->mHandleCurrent,
            this->mDistance,
            0.0);
    v55 = this->mSystem;
    this->mVolume3D = v54;
    result = FMOD::SystemI::leaveUserCallback(v55);
    if ( result )
      return result;
    mVolume3D = this->mVolume3D;
    x_low = (__m128)_2dmixa;
    y = _3dmixa;
    *(_QWORD *)&v5 = LODWORD(v5);
    *(_QWORD *)&mDirectOcclusionTarget_low = (unsigned int)mDirectOcclusionTarget_low;
    goto LABEL_86;
  }
  v19 = v17;
  v20 = (FMOD::SystemI *)((char *)v17 + 112 * (unsigned int)(v18 - 1));
  while ( v19 != v20 )
  {
    v19 = (FMOD::SystemI *)((char *)v19 + 112);
    if ( v19->mListener[0].mMoved )
      goto LABEL_75;
  }
LABEL_11:
  memset(lrpan, 0, sizeof(lrpan));
  memset(fbpan, 0, sizeof(fbpan));
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelControlI *const, int *))this->_vptr_ChannelControlI + 63))(
             this,
             &numsubchannels);
  if ( result )
    return result;
  v22 = this->mSystem;
  v23 = fbpan;
  if ( v22->mNumListeners != 1 )
  {
    v24 = 0.0;
    distance = 0;
    v25 = 0.0;
    v26 = 0.0;
    v27 = 0.0;
    goto LABEL_14;
  }
  v97 = this->mPosition3D.x;
  *(_QWORD *)&v5 = LODWORD(this->mPosition3D.y);
  v98 = this->mPosition3D.z;
  if ( (mode & 0x40000) != 0 )
  {
    v101 = 1.0;
    mDirectOcclusionRateOfChange_low = 1065353216;
    v7 = 0.0;
    v102 = 0.0;
    v100 = 0.0;
    v99 = 0.0;
  }
  else
  {
    v97 = v97 - v22->mListener[0].mPosition.x;
    *(float *)&v5 = *(float *)&v5 - v22->mListener[0].mPosition.y;
    v99 = *(float *)((char *)&qword_11018 + (_QWORD)v22);
    v98 = v98 - v22->mListener[0].mPosition.z;
    v100 = v22->mListener[0].mFront.y;
    mDirectOcclusionRateOfChange_low = *(unsigned int *)((char *)off_11020 + (_QWORD)v22);
    v101 = v22->mListener[0].mRight.x;
    v102 = v22->mListener[0].mRight.y;
    *(_QWORD *)&v7 = LODWORD(v22->mListener[0].mRight.z);
  }
  if ( (v22->mFlags & 4) != 0 )
  {
    mDirectOcclusionRateOfChange_low ^= 0x80000000uLL;
    v98 = -v98;
  }
  v103 = fsqrt((float)((float)(v97 * v97) + (float)(*(float *)&v5 * *(float *)&v5)) + (float)(v98 * v98));
  if ( v103 <= 0.0 )
  {
    v105 = 0.0;
    v5 = 0.0;
    v104 = 0.0;
  }
  else
  {
    v104 = v97 / v103;
    *(float *)&v5 = *(float *)&v5 / v103;
    v105 = v98 / v103;
  }
  *(float *)&v7 = *(float *)&v7 * v105;
  v106 = (float)((float)(v101 * v104) + (float)(v102 * *(float *)&v5)) + *(float *)&v7;
  if ( v106 < -1.01 )
    return FMOD_RESULT::FMOD_ERR_INVALID_VECTOR_0;
  if ( v106 > 1.01 )
    return FMOD_RESULT::FMOD_ERR_INVALID_VECTOR_0;
  *(float *)&v5 = *(float *)&v5 * v100;
  v26 = (float)((float)(v99 * v104) + *(float *)&v5) + (float)(v105 * *(float *)&mDirectOcclusionRateOfChange_low);
  if ( v26 < -1.01 || v26 > 1.01 )
    return FMOD_RESULT::FMOD_ERR_INVALID_VECTOR_0;
  if ( v106 > 1.0 )
    v27 = 1.0;
  else
    v27 = fmaxf(-1.0, v106);
  if ( v26 > 1.0 )
  {
    v26 = 1.0;
    v124 = 1.0;
    goto LABEL_232;
  }
  if ( v26 < -1.0 )
  {
    v124 = 1.0;
    v26 = -1.0;
LABEL_232:
    v125 = v27;
    if ( v27 < 0.0 )
      v125 = -v27;
    if ( v124 < v125 )
    {
      *(float *)&v25 = 3.0 - (float)(v26 / v125);
      if ( v27 < 0.0 )
        *(float *)&v25 = 10.0 - *(float *)&v25;
    }
    else
    {
      *(float *)&v25 = (float)(v27 / v124) + 1.0;
      if ( v26 < 0.0 )
        *(float *)&v25 = 6.0 - *(float *)&v25;
    }
    goto LABEL_237;
  }
  if ( v27 != 0.0 || (LODWORD(v25) = 0, v26 != 0.0) )
  {
    v124 = v26;
    if ( v26 < 0.0 )
      v124 = -v26;
    goto LABEL_232;
  }
LABEL_237:
  v126 = acosf(v26);
  DWORD1(mReverbOcclusionTarget_low) = 0;
  v127 = numsubchannels;
  v24 = 0.0;
  v23 = fbpan;
  *(_QWORD *)&v25 = LODWORD(v25);
  this->mAngleToListener = v126 * 57.295776;
  *(_QWORD *)&v16 = LODWORD(this->mSpread);
  *(float *)&mReverbOcclusionTarget_low = (float)(3.1415927 * *(float *)&v16) / 180.0;
  if ( *(float *)&v16 != 0.0 && v127 == 1 )
  {
    numsubchannels = 2;
    distance = 1;
    LOBYTE(v127) = 2;
  }
  else
  {
    distance = 0;
    if ( v127 <= 0 )
      goto LABEL_273;
  }
  v128 = 0;
  *(float *)&mDirectOcclusionRateOfChange_low = (float)(v127 - 1);
  while ( 1 )
  {
    if ( *(float *)&v16 != *(float *)&v24 && v127 != 1 )
    {
      if ( v127 == 6 )
      {
        v129 = -0.0;
        if ( (unsigned int)v128 <= 5 )
          v129 = -0.5 * flt_5964C0[v128];
        goto LABEL_248;
      }
      if ( v127 > 6 )
      {
        if ( v127 == 8 || v127 == 12 )
        {
          v129 = -0.0;
          if ( (unsigned int)v128 <= 7 )
            v129 = -0.5 * flt_5964A0[v128];
          goto LABEL_248;
        }
      }
      else if ( v127 == 4 )
      {
        if ( (_DWORD)v128 )
        {
          v129 = -0.5;
          if ( (_DWORD)v128 != 1 )
            v129 = -0.0;
        }
        else
        {
          v129 = 0.5;
        }
        goto LABEL_248;
      }
      v129 = (float)((float)((float)((float)(int)v128 + (float)(int)v128) / (float)(v127 - 1)) - 1.0) * -0.5;
LABEL_248:
      v143 = LODWORD(v24);
      sincosf(v129 * *(float *)&mReverbOcclusionTarget_low, (float *)sint, (float *)&cost);
      *(_QWORD *)&v21 = LODWORD(v26);
      *(_QWORD *)&v16 = cost;
      *(_QWORD *)&v5 = sint[0];
      *(float *)&v21 = v26 * *(float *)sint;
      *(_QWORD *)&v24 = v143;
      *(float *)&v5 = *(float *)sint * v27;
      *(_QWORD *)&v25 = LODWORD(v25);
      *(_QWORD *)&mReverbOcclusionTarget_low = (unsigned int)mReverbOcclusionTarget_low;
      *(float *)&v16 = (float)(*(float *)&cost * v26) + (float)(*(float *)sint * v27);
      lrpan[v128] = (float)(v27 * *(float *)&cost) - (float)(v26 * *(float *)sint);
      fbpan[v128] = *(float *)&v16;
      goto LABEL_249;
    }
    lrpan[v128] = v27;
    fbpan[v128] = v26;
LABEL_249:
    if ( v127 <= (int)++v128 )
      break;
    *(_QWORD *)&v16 = LODWORD(this->mSpread);
  }
  v23 = fbpan;
LABEL_273:
  v22 = this->mSystem;
LABEL_14:
  mSpeakerMode = v22->mSpeakerMode;
  if ( (unsigned int)(mSpeakerMode - 1) <= 1 )
    goto LABEL_39;
  memset(speakerlevel, 0, sizeof(speakerlevel));
  switch ( mSpeakerMode )
  {
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0:
      v29 = 2;
      goto LABEL_21;
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_QUAD_0:
      v29 = 4;
LABEL_21:
      v30 = v29;
      v31 = -1;
      goto LABEL_22;
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0:
      v29 = 5;
      goto LABEL_21;
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_5POINT1_0:
      v29 = 6;
      v30 = 5;
      break;
    case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0:
      v29 = 8;
      v30 = 7;
      break;
    default:
      v29 = 0;
      if ( mSpeakerMode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
        goto LABEL_21;
      v29 = 12;
      v30 = 11;
      break;
  }
  mData = this->mMixMatrix.mData;
  if ( mData )
  {
    v31 = 3;
    if ( v22->mSpeaker[3].mActive && numsubchannels > 0 )
    {
      mOutChannels = this->mMixMatrix.mOutChannels;
      v132 = 0;
      v133 = (unsigned int)(numsubchannels - 1) + 1LL;
      do
      {
        v134 = &DSPMatrixError_0;
        if ( mOutChannels > 3 )
        {
          mInChannels = this->mMixMatrix.mInChannels;
          if ( mInChannels > (int)v132 )
            v134 = &mData[3 * mInChannels + (int)v132];
        }
        *(_QWORD *)&v16 = *(unsigned int *)v134;
        speakerlevel[3][v132++] = *(float *)&v16;
      }
      while ( v132 != v133 );
      goto LABEL_264;
    }
  }
  else
  {
LABEL_264:
    v31 = 3;
  }
LABEL_22:
  *(_QWORD *)&v32 = LODWORD(this->m3DLevel);
  if ( *(float *)&v32 > *(float *)&v24 && numsubchannels > 0 )
  {
    HIDWORD(v7) = 0;
    v33 = speakerlevel[0];
    v34 = 0;
    *(float *)&v7 = 1.4142135 / (float)v30;
    do
    {
      mDirectOcclusionRateOfChange_low = LODWORD(fbpan[v34]);
      *(_QWORD *)&v16 = LODWORD(lrpan[v34]);
      if ( *(float *)&mDirectOcclusionRateOfChange_low == *(float *)&v24 && *(float *)&v16 == *(float *)&v24 )
      {
        if ( v29 )
        {
          v35 = this->mSystem;
          v16 = v24;
          v36 = v33;
          v37 = 0;
          do
          {
            *(double *)&mReverbOcclusionTarget_low = v24;
            if ( v35->mSpeaker[0].mActive && v37 != v31 )
              *(double *)&mReverbOcclusionTarget_low = v7;
            ++v37;
            *(_DWORD *)v36 = mReverbOcclusionTarget_low;
            v35 = (FMOD::SystemI *)((char *)v35 + 48);
            v36 += 32;
          }
          while ( v37 != v29 );
        }
      }
      else
      {
        if ( v27 != *(float *)&v16 || (v5 = v25, v26 != *(float *)&mDirectOcclusionRateOfChange_low) )
        {
          if ( *(float *)&v16 != *(float *)&v24
            || (v5 = v24, *(float *)&mDirectOcclusionRateOfChange_low != *(float *)&v24) )
          {
            v85 = fbpan[v34];
            if ( *(float *)&v24 > *(float *)&mDirectOcclusionRateOfChange_low )
              v85 = -*(float *)&mDirectOcclusionRateOfChange_low;
            *(_QWORD *)&mReverbOcclusionTarget_low = LODWORD(lrpan[v34]);
            if ( *(float *)&v24 > *(float *)&v16 )
              *(_QWORD *)&mReverbOcclusionTarget_low = *(_QWORD *)&v16 ^ 0x80000000LL;
            if ( v85 < *(float *)&mReverbOcclusionTarget_low )
            {
              *(_QWORD *)&v21 = LODWORD(fbpan[v34]);
              *(float *)&v21 = *(float *)&mDirectOcclusionRateOfChange_low / *(float *)&mReverbOcclusionTarget_low;
              HIDWORD(v5) = 0;
              *(float *)&v5 = 3.0
                            - (float)(*(float *)&mDirectOcclusionRateOfChange_low / *(float *)&mReverbOcclusionTarget_low);
              if ( *(float *)&v24 > *(float *)&v16 )
              {
                DWORD1(mReverbOcclusionTarget_low) = 0;
                *(float *)&mReverbOcclusionTarget_low = 10.0 - *(float *)&v5;
                v5 = *(double *)&mReverbOcclusionTarget_low;
              }
            }
            else
            {
              *(_QWORD *)&v5 = LODWORD(lrpan[v34]);
              *(float *)&v5 = (float)(*(float *)&v16 / v85) + 1.0;
              if ( *(float *)&v24 > *(float *)&mDirectOcclusionRateOfChange_low )
              {
                DWORD1(mReverbOcclusionTarget_low) = 0;
                *(float *)&mReverbOcclusionTarget_low = 6.0 - *(float *)&v5;
                v5 = *(double *)&mReverbOcclusionTarget_low;
              }
            }
          }
        }
        v86 = this->mSystem;
        v87 = *(unsigned __int64 *)((char *)&stru_11A60.r_offset + (_QWORD)v86);
        if ( v87 )
        {
          v88 = v86->mSpeakerList[1];
          if ( v88 )
          {
            if ( v30 )
            {
              HIDWORD(v21) = HIDWORD(v5);
              v89 = this->mSystem;
              v90 = *(FMOD_SPEAKERCONFIG **)((char *)&stru_11A60.r_offset + (_QWORD)v86);
              v91 = 1;
              *(float *)&v21 = *(float *)&v5 + 8.0;
              while ( 1 )
              {
                v92 = v88;
                if ( !v88 )
                  v92 = *(FMOD_SPEAKERCONFIG **)((char *)&stru_11A60.r_offset + (_QWORD)v86);
                mXZAngle = v90->mXZAngle;
                *(_QWORD *)&mReverbOcclusionTarget_low = LODWORD(v92->mXZAngle);
                if ( mXZAngle != *(float *)&mReverbOcclusionTarget_low )
                {
                  if ( *(float *)&mReverbOcclusionTarget_low < mXZAngle )
                    *(float *)&mReverbOcclusionTarget_low = *(float *)&mReverbOcclusionTarget_low + 8.0;
                  if ( *(float *)&mReverbOcclusionTarget_low > *(float *)&v5 && *(float *)&v5 >= mXZAngle
                    || *(float *)&v21 >= mXZAngle && *(float *)&mReverbOcclusionTarget_low > *(float *)&v21 )
                  {
                    if ( v90->mPairUseVBAP )
                    {
                      *(_QWORD *)&mReverbOcclusionTarget_low = LODWORD(v92->mXZNormal.z);
                      *(_QWORD *)&v5 = LODWORD(v90->mPairVBAPSign);
                      *(float *)&mReverbOcclusionTarget_low = (float)(*(float *)&mReverbOcclusionTarget_low
                                                                    * *(float *)&v16)
                                                            - (float)(v92->mXZNormal.x
                                                                    * *(float *)&mDirectOcclusionRateOfChange_low);
                      v94 = (float)(*(float *)&mDirectOcclusionRateOfChange_low * v90->mXZNormal.x)
                          - (float)(*(float *)&v16 * v90->mXZNormal.z);
                      HIDWORD(v16) = 0;
                      *(float *)&v16 = (float)(*(float *)&mReverbOcclusionTarget_low
                                             * *(float *)&mReverbOcclusionTarget_low)
                                     + (float)(v94 * v94);
                      *(float *)&v5 = *(float *)&v5 / fsqrt(*(float *)&v16);
                      *(float *)&mReverbOcclusionTarget_low = *(float *)&mReverbOcclusionTarget_low * *(float *)&v5;
                      *(float *)&mDirectOcclusionRateOfChange_low = v94 * *(float *)&v5;
                      LODWORD(speakerlevel[v90->mIndex][(int)v34]) = mReverbOcclusionTarget_low;
                      LODWORD(speakerlevel[v92->mIndex][(int)v34]) = mDirectOcclusionRateOfChange_low;
                    }
                    else
                    {
                      *(float *)&mDirectOcclusionRateOfChange_low = *(float *)&mDirectOcclusionRateOfChange_low
                                                                  * v90->mXZNormal.z;
                      *(_QWORD *)&mReverbOcclusionTarget_low = LODWORD(v90->mXZNormal.x);
                      *(float *)&mReverbOcclusionTarget_low = (float)(*(float *)&mReverbOcclusionTarget_low
                                                                    * *(float *)&v16)
                                                            + *(float *)&mDirectOcclusionRateOfChange_low;
                      v96 = fsqrt(
                              2.0
                            - (float)(*(float *)&mReverbOcclusionTarget_low * *(float *)&mReverbOcclusionTarget_low));
                      HIDWORD(v16) = 0;
                      *(_QWORD *)&v5 = 1056964608;
                      *(float *)&v16 = (float)(v96 + *(float *)&mReverbOcclusionTarget_low) * 0.5;
                      speakerlevel[v90->mIndex][(int)v34] = *(float *)&v16;
                      speakerlevel[v92->mIndex][(int)v34] = (float)(v96 - *(float *)&mReverbOcclusionTarget_low) * 0.5;
                    }
                    goto LABEL_33;
                  }
                }
                if ( v30 < ++v91 )
                  goto LABEL_33;
                v89 = (FMOD::SystemI *)((char *)v89 + 8);
                if ( !v88 )
                  break;
                v90 = v88;
                v88 = v89->mSpeakerList[1];
              }
              v95 = (FMOD::SystemI *)((char *)v86 + 8 * (unsigned int)(v30 - 1));
              do
              {
                speakerlevel[*(int *)(v87 + 4)][(int)v34] = 1.0;
                if ( v86 == v95 )
                  break;
                v86 = (FMOD::SystemI *)((char *)v86 + 8);
                v87 = *(unsigned __int64 *)((char *)&stru_11A60.r_offset + (_QWORD)v86);
              }
              while ( v87 );
            }
          }
          else
          {
            speakerlevel[*(int *)(v87 + 4)][(int)v34] = 1.0;
          }
        }
      }
LABEL_33:
      ++v33;
      ++v34;
    }
    while ( numsubchannels > (int)v34 );
    *(_QWORD *)&v32 = LODWORD(this->m3DLevel);
  }
  if ( *(float *)&v32 < 1.0 )
  {
    v112 = this->mMixMatrix.mData;
    HIDWORD(v5) = 0;
    *(float *)&v5 = 1.0 - *(float *)&v32;
    if ( v112 )
    {
      v113 = numsubchannels;
      if ( numsubchannels <= 0 )
        goto LABEL_36;
      v114 = level2d[0];
      v115 = 0;
      v116 = level2d[0];
      do
      {
        if ( v29 )
        {
          v117 = v116;
          for ( i = 0; i != v29; ++i )
          {
            if ( i == v31 )
            {
              v16 = v24;
            }
            else
            {
              v119 = &DSPMatrixError_0;
              if ( this->mMixMatrix.mOutChannels > i )
              {
                v120 = this->mMixMatrix.mInChannels;
                if ( v120 > v115 )
                  v119 = &v112[v115 + i * v120];
              }
              *(_QWORD *)&v16 = *(unsigned int *)v119;
            }
            *v117 = *(float *)&v16;
            v117 += 32;
          }
        }
        ++v115;
        ++v116;
      }
      while ( v115 != v113 );
    }
    else
    {
      v114 = level2d[0];
      *(_QWORD *)&v16 = 1065353216;
      memset(level2d, 0, sizeof(level2d));
      FMOD::DSPConnectionI::getDefaultMatrix(level2d, 0, v29, numsubchannels, 1.0);
      v115 = numsubchannels;
      *(_QWORD *)&v5 = COERCE_UNSIGNED_INT(1.0 - *(float *)&v32);
      *(_QWORD *)&v32 = LODWORD(v32);
      if ( numsubchannels <= 0 )
        goto LABEL_36;
    }
    v121 = &speakerlevel[0][1];
    v122 = speakerlevel[0];
    while ( 1 )
    {
      if ( v29 )
      {
        v123 = 0;
        do
        {
          *(_QWORD *)&v16 = LODWORD(v122[v123 / 4]);
          *(_QWORD *)&mReverbOcclusionTarget_low = LODWORD(v114[v123 / 4]);
          *(float *)&mReverbOcclusionTarget_low = *(float *)&mReverbOcclusionTarget_low * *(float *)&v5;
          *(float *)&v16 = (float)(*(float *)&v16 * *(float *)&v32) + *(float *)&mReverbOcclusionTarget_low;
          v122[v123 / 4] = *(float *)&v16;
          v123 += 128LL;
        }
        while ( v123 != (v29 - 1 + 1LL) << 7 );
      }
      ++v114;
      v122 = v121;
      if ( v121 == &speakerlevel[0][v115 - 1 + 1] )
        break;
      ++v121;
    }
  }
LABEL_36:
  if ( distance )
  {
    numsubchannels = 1;
    if ( v29 )
    {
      *(_QWORD *)&mReverbOcclusionTarget_low = 1056964608;
      v107 = speakerlevel[0];
      for ( j = speakerlevel[1]; ; j += 32 )
      {
        *(_QWORD *)&v16 = *(unsigned int *)v107;
        *(float *)&v16 = (float)(*(float *)&v16 + v107[1]) * 0.5;
        *v107 = *(float *)&v16;
        v107 = j;
        if ( j == speakerlevel[(unsigned __int64)(v29 - 1) + 1] )
          break;
      }
    }
    v38 = 1;
  }
  else
  {
    v38 = (unsigned int)numsubchannels;
  }
  v22 = (FMOD::SystemI *)speakerlevel;
  (*((void (__fastcall **)(FMOD::ChannelControlI *const, float *, _QWORD, __int64, __int64, _QWORD, double, double, double, double, double, double, double, double))this->_vptr_ChannelControlI
   + 25))(
    this,
    speakerlevel[0],
    v29,
    v38,
    32,
    0,
    v16,
    *(double *)&mReverbOcclusionTarget_low,
    v32,
    v5,
    v24,
    v21,
    *(double *)&mDirectOcclusionRateOfChange_low,
    v7);
LABEL_39:
  (*((void (__fastcall **)(FMOD::ChannelControlI *const, FMOD::SystemI *, float *, float))this->_vptr_ChannelControlI + 9))(
    this,
    v22,
    v23,
    this->mPitch);
  (*((void (__fastcall **)(FMOD::ChannelControlI *const, _QWORD, float))this->_vptr_ChannelControlI + 4))(
    this,
    0,
    this->mVolume);
  return FMOD_RESULT::FMOD_OK_0;
}


