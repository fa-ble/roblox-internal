// Address: 0x21e3f60 | Name: _ZN4FMOD13ChannelGroupI17addUpdateListNodeEv
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::addUpdateListNode(FMOD::ChannelGroupI *const this)
{
  FMOD::LinkedListNode *p_mSystemUpdateListNode; // rax
  FMOD::SystemI *mSystem; // rdx

  p_mSystemUpdateListNode = &this->mSystemUpdateListNode;
  if ( &this->mSystemUpdateListNode == this->mSystemUpdateListNode.mNodeNext
    && p_mSystemUpdateListNode == this->mSystemUpdateListNode.mNodePrev )
  {
    mSystem = this->mSystem;
    this->mSystemUpdateListNode.mNodePrev = mSystem->mChannelGroupUpdateListHead.mNodePrev;
    this->mSystemUpdateListNode.mNodeNext = &mSystem->mChannelGroupUpdateListHead;
    mSystem->mChannelGroupUpdateListHead.mNodePrev = p_mSystemUpdateListNode;
    this->mSystemUpdateListNode.mNodePrev->mNodeNext = p_mSystemUpdateListNode;
    this->mSystemUpdateListNode.mNodeData = this;
  }
  this->mFlags |= 0x80u;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e3fd0 | Name: _ZN4FMOD13ChannelGroupI21refreshUpdateListNodeEv
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::refreshUpdateListNode(FMOD::ChannelGroupI *const this)
{
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // eax
  FMOD_MODE mMode; // ecx
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD_MODE v5; // edx

  mFlags = this->mFlags;
  if ( (mFlags & 0x40) != 0 )
  {
    mMode = this->mMode;
    goto LABEL_3;
  }
  v5 = this->mMode;
  if ( (v5 & 0x10) != 0 )
  {
    mMode = this->mMode;
    goto LABEL_3;
  }
  mMode = this->mMode;
  if ( &this->mGainModifierHead != this->mGainModifierHead.mNodeNext
    || &this->mGainModifierHead != this->mGainModifierHead.mNodePrev )
  {
LABEL_3:
    if ( (mMode & 0x1000000) != 0 )
      goto LABEL_4;
LABEL_14:
    (*((void (__fastcall **)(FMOD::ChannelGroupI *const))this->_vptr_ChannelControlI + 65))(this);
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( (v5 & 0x1000000) == 0 && !*((_DWORD *)this->mDSPFader + 167) )
    goto LABEL_14;
LABEL_4:
  if ( (mFlags & 0x80u) != 0 )
  {
    LOBYTE(mFlags) = mFlags & 0x7F;
    this->mFlags = mFlags;
  }
  else
  {
    mNodePrev = this->mSystemUpdateListNode.mNodePrev;
    mNodePrev->mNodeNext = this->mSystemUpdateListNode.mNodeNext;
    this->mSystemUpdateListNode.mNodeNext->mNodePrev = mNodePrev;
    this->mSystemUpdateListNode.mNodePrev = &this->mSystemUpdateListNode;
    this->mSystemUpdateListNode.mNodeNext = &this->mSystemUpdateListNode;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e40b0 | Name: _ZN4FMOD13ChannelGroupI15getSystemObjectEPPNS_6SystemE
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getSystemObject(FMOD::ChannelGroupI *const this, FMOD::System **system)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( system )
  {
    *system = (FMOD::System *)this->mSystem;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e40d0 | Name: _ZN4FMOD13ChannelGroupI4stopEv
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::stop(FMOD::ChannelGroupI *const this)
{
  FMOD::ChannelGroupI *i; // rbx
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD::LinkedListNode *p_mChannelHead; // rbp
  void *mNodeData; // rdi

  for ( i = (FMOD::ChannelGroupI *)this->mGroupHead.mNodeNext;
        i != (FMOD::ChannelGroupI *)&this->mGroupHead;
        i = (FMOD::ChannelGroupI *)i->_vptr_ChannelControlI )
  {
    ((void (__fastcall *)(FMOD::DSPI **))(*i->mDSP)->mJob.mDelayClock.mClock)(i->mDSP);
  }
  mNodeNext = this->mChannelHead.mNodeNext;
  p_mChannelHead = &this->mChannelHead;
  while ( mNodeNext != p_mChannelHead )
  {
    mNodeData = mNodeNext->mNodeData;
    mNodeNext = mNodeNext->mNodeNext;
    (*(void (__fastcall **)(void *))(*(_QWORD *)mNodeData + 8LL))(mNodeData);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e4140 | Name: _ZN4FMOD13ChannelGroupI9getPausedEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getPaused(FMOD::ChannelGroupI *const this, bool *paused)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( paused )
  {
    *paused = this->mFlags & 1;
    *paused = *paused;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e4160 | Name: _ZN4FMOD13ChannelGroupI9getVolumeEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getVolume(FMOD::ChannelGroupI *const this, float *volume)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( volume )
  {
    LOBYTE(result) = 0;
    *volume = this->mVolume;
  }
  return result;
}


// Address: 0x21e4180 | Name: _ZN4FMOD13ChannelGroupI7getModeEPj
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getMode(FMOD::ChannelGroupI *const this, FMOD_MODE *mode)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( mode )
  {
    *mode = this->mMode & 0xFEFFFFFF;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e41a0 | Name: _ZN4FMOD13ChannelGroupI22set3DOcclusionInternalEffb
__int64 __fastcall FMOD::ChannelGroupI::set3DOcclusionInternal(
        FMOD::ChannelGroupI *const this,
        float a2,
        float direct,
        float reverb,
        bool resettarget)
{
  float v5; // xmm3_4
  float v6; // xmm6_4
  float v7; // xmm4_4
  float v8; // xmm5_4
  FMOD::ChannelGroupI *mChannelGroupParent; // rax
  float mRealReverbOcclusionVolume; // xmm0_4
  FMOD::ChannelGroupI *mNodeNext; // rbx

  v5 = 0.0;
  if ( a2 < 0.0 && a2 <= 1.0 )
  {
    v6 = 1.0;
    v7 = 0.0;
    goto LABEL_4;
  }
  if ( a2 > 1.0 )
  {
    v6 = 0.0;
    v7 = 1.0;
LABEL_4:
    this->mDirectOcclusion = v7;
    if ( direct < 0.0 )
      goto LABEL_5;
    goto LABEL_15;
  }
  v7 = a2;
  v6 = 1.0 - a2;
  this->mDirectOcclusion = a2;
  if ( direct < 0.0 )
  {
LABEL_5:
    v8 = 1.0;
    if ( direct <= 1.0 )
      goto LABEL_6;
  }
LABEL_15:
  if ( direct > 1.0 )
  {
    v8 = 0.0;
    v5 = 1.0;
  }
  else
  {
    v5 = direct;
    v8 = 1.0 - direct;
  }
LABEL_6:
  this->mReverbOcclusion = v5;
  if ( resettarget )
  {
    this->mDirectOcclusionTarget = v7;
    this->mReverbOcclusionTarget = v5;
  }
  mChannelGroupParent = this->mChannelGroupParent;
  if ( mChannelGroupParent )
  {
    mRealReverbOcclusionVolume = mChannelGroupParent->mRealReverbOcclusionVolume;
    this->mRealDirectOcclusionVolume = (float)(v6 * mChannelGroupParent->mRealDirectOcclusionVolume)
                                     * (float)(1.0 - this->mUserDirectOcclusion);
  }
  else
  {
    this->mRealDirectOcclusionVolume = (float)(1.0 - this->mUserDirectOcclusion) * v6;
    mRealReverbOcclusionVolume = 1.0;
  }
  mNodeNext = (FMOD::ChannelGroupI *)this->mGroupHead.mNodeNext;
  for ( this->mRealReverbOcclusionVolume = (float)(mRealReverbOcclusionVolume * v8)
                                         * (float)(1.0 - this->mUserReverbOcclusion);
        &this->mGroupHead != (FMOD::LinkedListNode *)mNodeNext;
        mNodeNext = (FMOD::ChannelGroupI *)mNodeNext->_vptr_ChannelControlI )
  {
    ((void (__fastcall *)(FMOD::DSPI **, _QWORD, float, float))(*mNodeNext->mDSP)->mOutputHead.mNodeNext)(
      mNodeNext->mDSP,
      0,
      *((float *)mNodeNext->mDSP + 48),
      *((float *)mNodeNext->mDSP + 49));
  }
  return 0;
}


// Address: 0x21e4320 | Name: _ZN4FMOD13ChannelGroupI14get3DOcclusionEPfS1_
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::get3DOcclusion(
        FMOD::ChannelGroupI *const this,
        float *directOcclusion,
        float *reverbOcclusion)
{
  if ( directOcclusion )
    *directOcclusion = this->mDirectOcclusion;
  if ( reverbOcclusion )
    *reverbOcclusion = this->mReverbOcclusion;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e4350 | Name: _ZN4FMOD13ChannelGroupI14updateDSPUnitsEPNS_4DSPIES2_
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::updateDSPUnits(
        FMOD::ChannelGroupI *const this,
        FMOD::DSPI *newdsphead,
        FMOD::DSPI *newdsptail)
{
  float v3; // xmm1_4
  FMOD::DSPI *mDSPHead; // rbp
  FMOD::DSPI *mDSPTail; // r13
  FMOD::DSPFader *mDSPFader; // r12
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *v9; // rcx
  FMOD::DSPI *dsphead; // [rsp+8h] [rbp-60h]
  bool delay_stopchannels; // [rsp+1Eh] [rbp-4Ah] BYREF
  bool paused; // [rsp+1Fh] [rbp-49h] BYREF
  FMOD_CLOCKTIME delay_start; // [rsp+20h] [rbp-48h] BYREF
  FMOD_CLOCKTIME delay_end[8]; // [rsp+28h] [rbp-40h] BYREF

  mDSPHead = this->mDSPHead;
  mDSPTail = this->mDSPTail;
  mDSPFader = this->mDSPFader;
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, bool *))this->_vptr_ChannelControlI + 3))(
             this,
             &paused);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v9 = mDSPHead;
    this->mDSPFader = mDSPFader;
    if ( newdsphead )
      v9 = newdsphead;
    if ( !newdsptail )
      newdsptail = mDSPTail;
    dsphead = v9;
    this->mDSPHead = v9;
    this->mDSPTail = newdsptail;
    if ( newdsphead )
    {
      result = FMOD::DSPI::getDelay(mDSPHead, &delay_start, delay_end, &delay_stopchannels);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD::DSPI::setDelay(dsphead, delay_start, delay_end[0], delay_stopchannels);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = (unsigned int)FMOD::DSPI::setPitch(dsphead, this->mPitch, v3, 1);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = FMOD::DSPI::setDelay(mDSPHead, 0, 0, 0);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              result = (unsigned int)FMOD::DSPI::setPitch(mDSPHead, 1.0, v3, 1);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                result = FMOD::DSPI::setActive(dsphead, !paused, 1);
                if ( result == FMOD_RESULT::FMOD_OK_0 )
                  return FMOD::DSPI::setActive(mDSPHead, 1, 1);
              }
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21e4480 | Name: _ZN4FMOD13ChannelGroupI7setModeEj
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setMode(FMOD::ChannelGroupI *const this, FMOD_MODE mode)
{
  FMOD_RESULT_0 result; // eax
  FMOD_MODE mMode; // eax
  FMOD_MODE v4; // eax
  FMOD_MODE v5; // eax
  FMOD_SPEAKERMODE_0 v6; // ecx
  int v7; // edx
  FMOD::DSPI *dspfader; // [rsp+8h] [rbp-20h] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI
            + 36))(
             this,
             4294967294LL,
             &dspfader);
  if ( result )
    return result;
  mMode = this->mMode;
  if ( (mode & 7) != 0 )
  {
    mMode &= 0xFFFFFFF8;
    if ( (mode & 1) != 0 )
    {
      mMode |= 1u;
      this->mMode = mMode;
      if ( (mode & 0x40000) != 0 )
        goto LABEL_7;
      goto LABEL_18;
    }
    if ( (mode & 2) != 0 )
    {
      mMode |= 2u;
      this->mMode = mMode;
    }
    else
    {
      if ( (mode & 4) != 0 )
        mMode |= 4u;
      this->mMode = mMode;
    }
  }
  if ( (mode & 0x40000) != 0 )
  {
LABEL_7:
    mMode = mMode & 0xFFF3FFFF | 0x40000;
    this->mMode = mMode;
    goto LABEL_8;
  }
LABEL_18:
  if ( (mode & 0x80000) != 0 )
  {
    mMode = mMode & 0xFFF3FFFF | 0x80000;
    this->mMode = mMode;
    if ( (mode & 0x100000) != 0 )
      goto LABEL_9;
    goto LABEL_20;
  }
LABEL_8:
  if ( (mode & 0x100000) != 0 )
  {
LABEL_9:
    mMode = mMode & 0xFB0FFFFF | 0x100000;
    this->mMode = mMode;
    goto LABEL_10;
  }
LABEL_20:
  if ( (mode & 0x200000) != 0 )
  {
    mMode = mMode & 0xFB0FFFFF | 0x200000;
    this->mMode = mMode;
  }
  else if ( (mode & 0x400000) != 0 )
  {
    mMode = mMode & 0xFB0FFFFF | 0x400000;
    this->mMode = mMode;
  }
  else if ( (mode & 0x800000) != 0 )
  {
    mMode = mMode & 0xFB0FFFFF | 0x800000;
    this->mMode = mMode;
  }
  else if ( (mode & 0x4000000) != 0 )
  {
    mMode = mMode & 0xFB0FFFFF | 0x4000000;
    this->mMode = mMode;
  }
LABEL_10:
  if ( (mode & 0x40000000) != 0 )
  {
    v4 = mMode | 0x40000000;
    this->mMode = v4;
    if ( (mode & 0x80000000) == 0 )
      goto LABEL_12;
LABEL_24:
    v5 = v4 | 0x80000000;
    this->mMode = v5;
    if ( (mode & 8) == 0 )
      goto LABEL_13;
    goto LABEL_25;
  }
  v4 = mMode & 0xBFFFFFFF;
  this->mMode = v4;
  if ( (mode & 0x80000000) != 0 )
    goto LABEL_24;
LABEL_12:
  v5 = v4 & 0x7FFFFFFF;
  this->mMode = v5;
  if ( (mode & 8) == 0 )
  {
LABEL_13:
    if ( (mode & 0x10) == 0 )
    {
      if ( (mode & 0x1000000) != 0 )
      {
LABEL_15:
        this->mMode = v5 | 0x1000000;
        return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelGroupI *const))this->_vptr_ChannelControlI + 65))(this);
      }
LABEL_28:
      this->mMode = v5 & 0xFEFFFFFF;
      return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelGroupI *const))this->_vptr_ChannelControlI + 65))(this);
    }
    v6 = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0;
    v7 = 1;
    this->mMode = v5 & 0xFFFFFFE7 | 0x10;
    goto LABEL_26;
  }
LABEL_25:
  this->mVolume3D = 1.0;
  this->mDirectOcclusion = 0.0;
  this->mConeVolume3D = 1.0;
  this->mPitch3D = 1.0;
  this->mMode = v5 & 0xFFFFFFE7 | 8;
  v6 = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
  v7 = 0;
LABEL_26:
  result = FMOD::DSPI::setChannelFormat(dspfader, 0, v7, v6);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v5 = this->mMode;
    if ( (mode & 0x1000000) != 0 )
      goto LABEL_15;
    goto LABEL_28;
  }
  return result;
}


// Address: 0x21e4730 | Name: _ZN4FMOD13ChannelGroupI6addDSPEiPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::addDSP(FMOD::ChannelGroupI *const this, int index, FMOD::DSPI *dsp)
{
  FMOD_RESULT_0 result; // eax
  FMOD_DSP_TYPE v5[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  v5[0] = FMOD_DSP_TYPE_UNKNOWN;
  result = FMOD::ChannelControlI::addDSP(this, index, dsp);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (unsigned int)FMOD::DSPI::getType(dsp, v5);
    if ( result == FMOD_RESULT::FMOD_OK_0 && v5[0] == FMOD_DSP_TYPE_RETURN )
      this->mDSPReturn = (FMOD::DSPReturn *)dsp;
  }
  return result;
}


// Address: 0x21e4780 | Name: _ZN4FMOD13ChannelGroupI13getAudibilityEPf
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getAudibility(FMOD::ChannelGroupI *const this, float *audibility)
{
  FMOD_RESULT_0 result; // eax
  float m3DLevel; // xmm0_4

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( audibility )
  {
    if ( (this->mFlags & 0x10) != 0 )
    {
      *audibility = 0.0;
      LOBYTE(result) = 0;
    }
    else if ( (this->mMode & 0x10) != 0 )
    {
      m3DLevel = this->m3DLevel;
      result = FMOD_RESULT::FMOD_OK_0;
      if ( m3DLevel < 1.0 )
        *audibility = (float)((float)((float)((float)((float)(this->mVolume3D * m3DLevel) + (float)(1.0 - m3DLevel))
                                            * (float)((float)(this->mConeVolume3D * m3DLevel) + (float)(1.0 - m3DLevel)))
                                    * (float)((float)((float)(1.0 - this->mDirectOcclusion) * m3DLevel)
                                            + (float)(1.0 - m3DLevel)))
                            * (float)((float)((float)(1.0 - this->mUserDirectOcclusion) * m3DLevel)
                                    + (float)(1.0 - m3DLevel)))
                    * this->mAudibility;
      else
        *audibility = (float)((float)((float)(this->mVolume3D * this->mConeVolume3D)
                                    * (float)(1.0 - this->mDirectOcclusion))
                            * (float)(1.0 - this->mUserDirectOcclusion))
                    * this->mAudibility;
    }
    else
    {
      result = FMOD_RESULT::FMOD_OK_0;
      *audibility = this->mAudibility;
    }
  }
  return result;
}


// Address: 0x21e4930 | Name: _ZN4FMOD13ChannelGroupI17getNumSubChannelsEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getNumSubChannels(FMOD::ChannelGroupI *const this, int *numchannels)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *dspfader; // [rsp+8h] [rbp-10h] BYREF

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI
            + 36))(
             this,
             4294967294LL,
             &dspfader);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD::DSPI::getChannelFormat(dspfader, 0, numchannels, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 && !*numchannels )
      *numchannels = 1;
  }
  return result;
}


// Address: 0x21e4980 | Name: _ZN4FMOD13ChannelGroupI9setVolumeEfb
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setVolume(
        FMOD::ChannelGroupI *const this,
        __m128i a2,
        float volume,
        bool forceupdatepos)
{
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // eax
  float mVolume; // xmm6_4
  float v6; // xmm5_4
  FMOD_RESULT_0 result; // eax

  if ( (_mm_cvtsi128_si32(a2) & 0x7F800000) == 0x7F800000 )
    return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  mFlags = this->mFlags;
  mVolume = this->mVolume;
  v6 = 0.0;
  LODWORD(this->mVolume) = a2.m128i_i32[0];
  if ( (mFlags & 2) == 0 )
    v6 = *(float *)a2.m128i_i32;
  result = FMOD::DSPFader::setMix(
             this->mDSPFader,
             (float)((float)(1.0 - this->mDirectOcclusion) * (float)(1.0 - this->mUserDirectOcclusion))
           * (float)((float)((float)((float)(this->mVolume3D * this->m3DLevel) + (float)(1.0 - this->m3DLevel)) * v6)
                   * (float)((float)(this->m3DLevel * this->mConeVolume3D) + (float)(1.0 - this->m3DLevel))),
             (mFlags & 0x30) == 0 ? FMOD_RESULT::FMOD_ERR_TOOMANYCHANNELS_0 : FMOD_RESULT::FMOD_OK_0,
             1,
             0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( *(float *)a2.m128i_i32 != mVolume )
      return FMOD::ChannelControlI::update(this, 0, 0, forceupdatepos);
    result = FMOD_RESULT::FMOD_OK_0;
    if ( forceupdatepos )
      return FMOD::ChannelControlI::update(this, 0, 0, forceupdatepos);
  }
  return result;
}


// Address: 0x21e4ab0 | Name: _ZN4FMOD13ChannelGroupI18setMixLevelsOutputEffffffff
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setMixLevelsOutput(
        FMOD::ChannelGroupI *const this,
        float a2,
        float frontleft,
        float frontright,
        float center,
        float lfe,
        float surroundleft,
        float surroundright,
        __m128i backleft)
{
  FMOD_RESULT_0 result; // eax
  int numinputlevels; // [rsp+1Ch] [rbp-101Ch] BYREF
  float levels[1030]; // [rsp+20h] [rbp-1018h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  if ( (LODWORD(surroundleft) & 0x7F800000) != 0x7F800000
    && (LODWORD(surroundright) & 0x7F800000) != 0x7F800000
    && (_mm_cvtsi128_si32(backleft) & 0x7F800000) != 0x7F800000 )
  {
    result = (unsigned int)FMOD::DSPI::calculateSpeakerLevels(
                             a2,
                             frontleft,
                             frontright,
                             center,
                             lfe,
                             surroundleft,
                             surroundright,
                             *(float *)backleft.m128i_i32,
                             this->mSystem->mSpeakerMode,
                             this->mSystem->mDSPMaxOutputChannels,
                             FMOD_CHANNELORDER::FMOD_CHANNELORDER_DEFAULT_0,
                             levels,
                             &numinputlevels);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::DSPI::setChannelFormat(
                 (FMOD::DSPI *const)this->mDSPFader,
                 0,
                 numinputlevels,
                 this->mSystem->mSpeakerMode);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelGroupI *const, float *, _QWORD, _QWORD, _QWORD, __int64))this->_vptr_ChannelControlI
                + 25))(
                 this,
                 levels,
                 (unsigned int)this->mSystem->mDSPMaxOutputChannels,
                 (unsigned int)this->mSystem->mDSPMaxOutputChannels,
                 0,
                 1);
    }
  }
  return result;
}


// Address: 0x21e4bb0 | Name: _ZN4FMOD13ChannelGroupI18setMixLevelsOutputEffffffff_0
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setMixLevelsOutput(
        FMOD::ChannelGroupI *const this,
        float a2,
        float frontleft,
        __m128i frontright,
        __m128i center,
        __m128i lfe,
        float surroundleft,
        float surroundright,
        __m128i backleft)
{
  if ( (LODWORD(a2) & 0x7F800000) == 0x7F800000
    || (LODWORD(frontleft) & 0x7F800000) == 0x7F800000
    || (_mm_cvtsi128_si32(frontright) & 0x7F800000) == 0x7F800000
    || (_mm_cvtsi128_si32(center) & 0x7F800000) == 0x7F800000
    || (_mm_cvtsi128_si32(lfe) & 0x7F800000) == 0x7F800000 )
  {
    return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  }
  else
  {
    return FMOD::ChannelGroupI::setMixLevelsOutput(
             this,
             a2,
             frontleft,
             *(float *)frontright.m128i_i32,
             *(float *)center.m128i_i32,
             *(float *)lfe.m128i_i32,
             surroundleft,
             surroundright,
             backleft);
  }
}


// Address: 0x21e4c40 | Name: _ZN4FMOD13ChannelGroupI19setReverbPropertiesEif
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setReverbProperties(
        FMOD::ChannelGroupI *const this,
        unsigned int instance,
        double a3,
        float wet)
{
  FMOD_RESULT_0 result; // eax

  if ( this->mSystem->mMasterChannelGroup == this )
    return FMOD_RESULT::FMOD_ERR_DSP_CONNECTION_0;
  result = FMOD::ChannelControlI::setReverbProperties(this, instance, wet);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelGroupI *const, _QWORD))this->_vptr_ChannelControlI + 15))(
             this,
             instance);
  return result;
}


// Address: 0x21e4ca0 | Name: _ZN4FMOD13ChannelGroupI9removeDSPEPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::removeDSP(FMOD::ChannelGroupI *const this, FMOD::DSPI *dsp)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::ChannelControlI::removeDSP(this, dsp);
  if ( result == FMOD_RESULT::FMOD_OK_0 && (!dsp || dsp == (FMOD::DSPI *)this->mDSPReturn) )
  {
    this->mDSPReturn = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e4cf0 | Name: _ZN4FMOD13ChannelGroupI12setMixMatrixEPfiiib
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setMixMatrix(
        FMOD::ChannelGroupI *const this,
        float *matrix,
        int outchannels,
        int inchannels,
        int inchannel_hop,
        bool updatematrix)
{
  FMOD_RESULT_0 result; // eax

  if ( !matrix && !this->mMixMatrix.mData )
    return FMOD_RESULT::FMOD_OK_0;
  if ( !updatematrix )
    return FMOD::DSPFader::setMixMatrix(this->mDSPFader, matrix, outchannels, inchannels, inchannel_hop, 64, 1);
  result = FMOD::ChannelControlI::setMixMatrix(this, matrix, outchannels, inchannels, inchannel_hop, 1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::DSPFader::setMixMatrix(this->mDSPFader, matrix, outchannels, inchannels, inchannel_hop, 64, 1);
  return result;
}


// Address: 0x21e4d90 | Name: _ZN4FMOD13ChannelGroupI11getDSPClockEPyS1_
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getDSPClock(
        FMOD::ChannelGroupI *const this,
        FMOD_CLOCKTIME *dspclock,
        FMOD_CLOCKTIME *parentclock)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelGroupI *mChannelGroupParent; // rdi
  FMOD::DSPI *dsptail[4]; // [rsp+8h] [rbp-20h] BYREF

  if ( dspclock )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI
              + 36))(
               this,
               4294967293LL,
               dsptail);
    if ( result )
      return result;
    *dspclock = dsptail[0]->mJob.mDelayClock.mClockNext;
  }
  if ( !parentclock )
    return FMOD_RESULT::FMOD_OK_0;
  mChannelGroupParent = this->mChannelGroupParent;
  dsptail[0] = 0;
  if ( mChannelGroupParent )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **))mChannelGroupParent->_vptr_ChannelControlI
              + 36))(
               mChannelGroupParent,
               4294967293LL,
               dsptail);
    if ( result )
      return result;
    goto LABEL_7;
  }
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI
            + 36))(
             this,
             4294967293LL,
             dsptail);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
LABEL_7:
    *parentclock = dsptail[0]->mJob.mDelayClock.mClockNext;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e4e40 | Name: _ZN4FMOD13ChannelGroupI8validateEPNS_12ChannelGroupEPPS0_PNS_15SystemLockScopeE
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::validate(
        FMOD::ChannelGroup *channelgroup,
        FMOD::ChannelGroupI **channelgroupi,
        FMOD::SystemLockScope *lockScope)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v4; // rbx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroupi )
  {
    *channelgroupi = (FMOD::ChannelGroupI *)channelgroup;
    LOBYTE(result) = 30;
    if ( channelgroup )
    {
      if ( ((unsigned __int8)channelgroup & 3) == 0 && *(_DWORD *)&channelgroup[472].gap0 == -899895835 )
      {
        LOBYTE(result) = 0;
        if ( lockScope )
        {
          LOBYTE(result) = 28;
          v4 = *(FMOD::SystemI **)&channelgroup[8].gap0;
          if ( !lockScope->mSystem )
          {
            if ( v4 )
            {
              result = FMOD::SystemI::enterMainUpdateLock(v4);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
                lockScope->mSystem = v4;
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21e50d0 | Name: _ZN4FMOD13ChannelGroupI15updateClockTreeEPNS_8DSPClockE
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::updateClockTree(FMOD::ChannelGroupI *const this, FMOD::DSPClock *clock)
{
  FMOD::DSPI **mDSP; // rsi
  int mNumDSPs; // r8d
  __int64 i; // rax
  FMOD::DSPI *v6; // rdx
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *mDSPHead; // rax

  mDSP = this->mDSP;
  if ( mDSP )
  {
    mNumDSPs = this->mNumDSPs;
    for ( i = 0; mNumDSPs > (int)i; v6->mJob.mDelayClock.mClockNext = clock->mClockNext )
    {
      v6 = mDSP[i++];
      v6->mJob.mDelayClock.mClock = clock->mClock;
    }
  }
  else
  {
    mDSPHead = this->mDSPHead;
    mDSPHead->mJob.mDelayClock.mClock = clock->mClock;
    mDSPHead->mJob.mDelayClock.mClockNext = clock->mClockNext;
  }
  mNodeNext = this->mGroupHead.mNodeNext;
  if ( mNodeNext == &this->mGroupHead )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    result = FMOD::ChannelGroupI::updateClockTree((FMOD::ChannelGroupI *const)mNodeNext->mNodeData, clock);
    if ( result )
      break;
    mNodeNext = mNodeNext->mNodeNext;
    if ( mNodeNext == &this->mGroupHead )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e5170 | Name: _ZN4FMOD13ChannelGroupI18disconnectFromPortEv
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::disconnectFromPort(FMOD::ChannelGroupI *const this)
{
  int (**vptr_ChannelControlI)(...); // rax
  FMOD_RESULT_0 result; // eax
  int i; // ebx
  int numoutputs; // [rsp+4h] [rbp-64h] BYREF
  FMOD::DSPI *head; // [rsp+8h] [rbp-60h] BYREF
  FMOD::DSPI *parent; // [rsp+10h] [rbp-58h] BYREF
  FMOD::DSPConnectionI *connection; // [rsp+18h] [rbp-50h] BYREF
  FMOD::DSPI *output; // [rsp+20h] [rbp-48h] BYREF
  void *userdata; // [rsp+28h] [rbp-40h] BYREF

  vptr_ChannelControlI = this->_vptr_ChannelControlI;
  head = 0;
  result = vptr_ChannelControlI[36](this, 0xFFFFFFFFLL, &head);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **))this->mChannelGroupParent->FMOD::ChannelControlI::_vptr_ChannelControlI
              + 36))(
               this->mChannelGroupParent,
               4294967293LL,
               &parent);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      FMOD::DSPI::getNumOutputsInternal(head, &numoutputs, 0, 1);
      if ( numoutputs > 0 )
      {
        for ( i = 0; i < numoutputs; ++i )
        {
          while ( 1 )
          {
            FMOD::DSPI::getOutputInternal(head, i, &output, &connection, 0, 1);
            FMOD::DSPConnectionI::getUserData(connection, &userdata);
            if ( userdata != (void *)(this->mPortId | 0xFEED0000LL) )
              break;
            FMOD::DSPI::disconnectFrom(head, output, connection, FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
            if ( i >= --numoutputs )
              return FMOD::Output::closeport(this->mSystem->mOutput, this->mPortId);
          }
          if ( output == parent && !this->mPortPassthru )
            FMOD::DSPConnectionI::setMix(connection, 1.0, 0, 1, 0);
        }
      }
      return FMOD::Output::closeport(this->mSystem->mOutput, this->mPortId);
    }
  }
  return result;
}


// Address: 0x21e52f0 | Name: _ZN4FMOD13ChannelGroupI6updateEib
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::update(
        FMOD::ChannelGroupI *const this,
        int delta_ms,
        bool updategeometrynow)
{
  double v3; // xmm1_8
  FMOD_RESULT_0 result; // eax
  int v6; // ebx
  FMOD::ChannelGroupI *mChannelGroupParent; // rax
  __m128i mRealVolume_low; // xmm0
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // ecx
  FMOD::SystemI *mSystem; // rax
  int mNumListeners; // edx
  FMOD::SystemI *v12; // rdx
  int numdsps; // [rsp+4h] [rbp-24h] BYREF
  FMOD::DSPI *dsppanner; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD::ChannelControlI::update(this, delta_ms, updategeometrynow, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0
    && ((this->mMode & 0x10) == 0
     || (result = FMOD::ChannelControlI::update3D(this, delta_ms, updategeometrynow)) == FMOD_RESULT::FMOD_OK_0) )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, int *))this->_vptr_ChannelControlI + 37))(
               this,
               &numdsps);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v6 = 0;
      if ( numdsps <= 0 )
      {
LABEL_13:
        mFlags = this->mFlags;
        if ( (mFlags & 4) == 0 )
        {
          mSystem = this->mSystem;
          mNumListeners = mSystem->mNumListeners;
          if ( mNumListeners <= 0 )
            return FMOD_RESULT::FMOD_OK_0;
          if ( !mSystem->mListener[0].mMoved )
          {
            v12 = (FMOD::SystemI *)((char *)mSystem + 112 * (unsigned int)(mNumListeners - 1));
            while ( mSystem != v12 )
            {
              mSystem = (FMOD::SystemI *)((char *)mSystem + 112);
              if ( mSystem->mListener[0].mMoved )
                goto LABEL_23;
            }
            return FMOD_RESULT::FMOD_OK_0;
          }
        }
LABEL_23:
        this->mFlags = mFlags & 0xFFFFFFFB;
        return FMOD_RESULT::FMOD_OK_0;
      }
      while ( 1 )
      {
        result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, _QWORD, FMOD::DSPI **))this->_vptr_ChannelControlI
                  + 36))(
                   this,
                   (unsigned int)v6,
                   &dsppanner);
        if ( result )
          break;
        if ( dsppanner && *(&dsppanner->mDescription.mHandle + 1) == 35 )
        {
          mChannelGroupParent = this->mChannelGroupParent;
          if ( mChannelGroupParent )
            mRealVolume_low = (__m128i)LODWORD(mChannelGroupParent->mRealVolume);
          else
            mRealVolume_low = (__m128i)0x3F800000u;
          ++v6;
          FMOD::DSPI::setParameterFloat(dsppanner, 8, mRealVolume_low, v3);
          if ( numdsps <= v6 )
            goto LABEL_13;
        }
        else if ( numdsps <= ++v6 )
        {
          goto LABEL_13;
        }
      }
    }
  }
  return result;
}


// Address: 0x21e5450 | Name: _ZN4FMOD13ChannelGroupI17setPausedInternalEb
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setPausedInternal(FMOD::ChannelGroupI *const this, bool realpausedstate)
{
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // eax
  FMOD::LinkedListNode *i; // rbx
  FMOD::ChannelGroupI *j; // rbp
  FMOD::DSPI **mDSP; // rbx
  bool paused[41]; // [rsp+Fh] [rbp-29h] BYREF

  mFlags = this->mFlags;
  if ( (mFlags & 1) != 0 || realpausedstate )
    this->mFlags = mFlags | 0x10;
  else
    this->mFlags = mFlags & 0xFFFFFFEF;
  for ( i = this->mGroupHead.mNodeNext; i != &this->mGroupHead; i = i->mNodeNext )
    FMOD::ChannelGroupI::setPausedInternal((FMOD::ChannelGroupI *const)i->mNodeData, (this->mFlags & 0x10) != 0);
  for ( j = (FMOD::ChannelGroupI *)this->mChannelHead.mNodeNext;
        j != (FMOD::ChannelGroupI *)&this->mChannelHead;
        j = (FMOD::ChannelGroupI *)j->_vptr_ChannelControlI )
  {
    mDSP = j->mDSP;
    ((void (__fastcall *)(FMOD::DSPI **, bool *))(*mDSP)->mJob.mDelayClock.mDelayStart)(mDSP, paused);
    ((void (__fastcall *)(FMOD::DSPI **, bool))(*mDSP)->mJob.mDelayClock.mClockNext)(mDSP, paused[0]);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e5510 | Name: _ZN4FMOD13ChannelGroupI9setPausedEb
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setPaused(FMOD::ChannelGroupI *const this, bool paused)
{
  FMOD::ChannelGroupI *mChannelGroupParent; // rax
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *dsphead; // [rsp+8h] [rbp-20h] BYREF

  if ( paused )
  {
    mChannelGroupParent = this->mChannelGroupParent;
    this->mFlags |= 1u;
    if ( mChannelGroupParent )
      goto LABEL_3;
LABEL_6:
    result = FMOD::ChannelGroupI::setPausedInternal(this, 0);
    if ( result )
      return result;
    goto LABEL_7;
  }
  mChannelGroupParent = this->mChannelGroupParent;
  this->mFlags &= ~1u;
  if ( !mChannelGroupParent )
    goto LABEL_6;
LABEL_3:
  result = FMOD::ChannelGroupI::setPausedInternal(this, (mChannelGroupParent->mFlags & 0x10) != 0);
  if ( result )
    return result;
LABEL_7:
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, _QWORD, FMOD::DSPI **))this->_vptr_ChannelControlI
            + 36))(
             this,
             0,
             &dsphead);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::DSPI::setActive(dsphead, !paused, 1);
  return result;
}


// Address: 0x21e55b0 | Name: _ZN4FMOD13ChannelGroupI16setPitchInternalEv
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setPitchInternal(FMOD::ChannelGroupI *const this)
{
  float v1; // xmm1_4
  FMOD::ChannelGroupI *mChannelGroupParent; // rax
  float mRealPitch; // xmm0_4
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD::ChannelGroupI *i; // rbx
  FMOD::ChannelI *mDSP; // rbp
  float freq[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  mChannelGroupParent = this->mChannelGroupParent;
  if ( mChannelGroupParent )
    mRealPitch = mChannelGroupParent->mRealPitch;
  else
    mRealPitch = 1.0;
  mNodeNext = this->mGroupHead.mNodeNext;
  for ( this->mRealPitch = mRealPitch * this->mPitch; mNodeNext != &this->mGroupHead; mNodeNext = mNodeNext->mNodeNext )
    FMOD::ChannelGroupI::setPitchInternal((FMOD::ChannelGroupI *const)mNodeNext->mNodeData);
  for ( i = (FMOD::ChannelGroupI *)this->mChannelHead.mNodeNext;
        i != (FMOD::ChannelGroupI *)&this->mChannelHead;
        i = (FMOD::ChannelGroupI *)i->_vptr_ChannelControlI )
  {
    mDSP = (FMOD::ChannelI *)i->mDSP;
    FMOD::ChannelI::getFrequency(mDSP, freq);
    FMOD::ChannelI::setFrequency(mDSP, freq[0], v1);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e5680 | Name: _ZN4FMOD13ChannelGroupI8setPitchEf
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setPitch(FMOD::ChannelGroupI *const this, float a2, float pitch)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *dsphead; // [rsp+18h] [rbp-10h] BYREF

  result = FMOD::ChannelControlI::setPitch(this, pitch);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD::ChannelGroupI::setPitchInternal(this);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, _QWORD, FMOD::DSPI **))this->_vptr_ChannelControlI
                + 36))(
                 this,
                 0,
                 &dsphead);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        return (unsigned int)FMOD::DSPI::setPitch(dsphead, a2, pitch, 1);
    }
  }
  return result;
}


// Address: 0x21e56e0 | Name: _ZN4FMOD13ChannelGroupI21updateReverbRecursiveEi
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::updateReverbRecursive(FMOD::ChannelGroupI *const this, int instance)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rbx

  result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const))this->_vptr_ChannelControlI + 15))(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mNodeNext = this->mGroupHead.mNodeNext;
    if ( mNodeNext == &this->mGroupHead )
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      while ( 1 )
      {
        result = FMOD::ChannelGroupI::updateReverbRecursive((FMOD::ChannelGroupI *const)mNodeNext->mNodeData, instance);
        if ( result )
          break;
        mNodeNext = mNodeNext->mNodeNext;
        if ( mNodeNext == &this->mGroupHead )
          return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21e5740 | Name: _ZN4FMOD13ChannelGroupI17updateReverbLevelEi
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::updateReverbLevel(FMOD::ChannelGroupI *const this, int instance)
{
  FMOD::DSPConnectionI *v3; // rdi

  v3 = this->mReverbConnection[instance];
  if ( v3 )
    return FMOD::DSPConnectionI::setMix(
             v3,
             this->mReverbLevel[instance] * this->mChannelGroupParent->mAudibility,
             0x40u,
             1,
             0);
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e5790 | Name: _ZN4FMOD13ChannelGroupI17setVolumeInternalEv
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setVolumeInternal(FMOD::ChannelGroupI *const this)
{
  float v1; // xmm1_4
  float v2; // xmm0_4
  FMOD::ChannelGroupI *mChannelGroupParent; // rax
  float mRealVolume; // xmm1_4
  int v5; // ebx
  FMOD::DSPReturn *mDSPReturn; // rax
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD::ChannelGroupI *vptr_ChannelControlI; // rbx

  v1 = 0.0;
  v2 = 0.0;
  if ( (this->mFlags & 2) == 0 )
  {
    mChannelGroupParent = this->mChannelGroupParent;
    if ( mChannelGroupParent )
    {
      mRealVolume = mChannelGroupParent->mRealVolume;
      v2 = (float)(mChannelGroupParent->mAudibility * this->mDSPDirectVolume) + this->mDSPSendVolume;
    }
    else
    {
      v2 = this->mDSPSendVolume + this->mDSPDirectVolume;
      mRealVolume = 1.0;
    }
    v1 = mRealVolume * this->mVolume;
  }
  if ( v2 != this->mAudibility || (LODWORD(mDSPReturn) = 0, v1 != this->mRealVolume) )
  {
    this->mRealVolume = v1;
    v5 = 0;
    this->mAudibility = v2;
    while ( 1 )
    {
      LODWORD(mDSPReturn) = FMOD::ChannelGroupI::updateReverbLevel(this, v5);
      if ( (_DWORD)mDSPReturn )
        break;
      if ( ++v5 == 4 )
      {
        mNodeNext = this->mGroupHead.mNodeNext;
        if ( &this->mGroupHead == mNodeNext )
        {
LABEL_16:
          vptr_ChannelControlI = (FMOD::ChannelGroupI *)this->mChannelHead.mNodeNext;
          if ( vptr_ChannelControlI == (FMOD::ChannelGroupI *)&this->mChannelHead )
          {
LABEL_22:
            mDSPReturn = this->mDSPReturn;
            if ( mDSPReturn )
            {
              *((_DWORD *)mDSPReturn + 155) = LODWORD(this->mAudibility);
              LODWORD(mDSPReturn) = 0;
            }
          }
          else
          {
            while ( 1 )
            {
              LODWORD(mDSPReturn) = ((__int64 (__fastcall *)(FMOD::DSPI **))(*vptr_ChannelControlI->mDSP)->mProfileContextMemory)(vptr_ChannelControlI->mDSP);
              if ( (_DWORD)mDSPReturn )
                break;
              vptr_ChannelControlI = (FMOD::ChannelGroupI *)vptr_ChannelControlI->_vptr_ChannelControlI;
              if ( vptr_ChannelControlI == (FMOD::ChannelGroupI *)&this->mChannelHead )
                goto LABEL_22;
            }
          }
        }
        else
        {
          while ( 1 )
          {
            LODWORD(mDSPReturn) = FMOD::ChannelGroupI::setVolumeInternal((FMOD::ChannelGroupI *const)mNodeNext->mNodeData);
            if ( (_DWORD)mDSPReturn )
              break;
            mNodeNext = mNodeNext->mNodeNext;
            if ( &this->mGroupHead == mNodeNext )
              goto LABEL_16;
          }
        }
        return (int)mDSPReturn;
      }
    }
  }
  return (int)mDSPReturn;
}


// Address: 0x21e58e0 | Name: j__ZN4FMOD13ChannelGroupI17setVolumeInternalEv
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::setVolumeInternal(FMOD::ChannelGroupI *const this)
{
  return _ZN4FMOD13ChannelGroupI17setVolumeInternalEv(this);
}


// Address: 0x21e58f0 | Name: _ZN4FMOD13ChannelGroupI22updateReverbConnectionEi
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::updateReverbConnection(FMOD::ChannelGroupI *const this, int instance)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPConnectionI **v3; // rbp
  FMOD::DSPI *dspreverb[6]; // [rsp+8h] [rbp-30h] BYREF

  if ( this->mSystem->mReverb[instance].mDSP )
  {
    if ( this->mReverbLevel[instance] == 0.0 )
    {
      v3 = (FMOD::DSPConnectionI **)(&this->_vptr_ChannelControlI + instance);
      result = FMOD_RESULT::FMOD_OK_0;
      if ( v3[42] )
      {
        result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, __int64, FMOD::DSPI **, double))this->_vptr_ChannelControlI
                  + 36))(
                   this,
                   4294967294LL,
                   dspreverb,
                   0.0);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = FMOD::DSPI::disconnectFrom(
                     this->mSystem->mReverb[instance].mDSP,
                     dspreverb[0],
                     v3[42],
                     FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
            v3[42] = 0;
        }
      }
    }
    else
    {
      if ( this->mReverbConnection[instance] )
        return FMOD::ChannelGroupI::updateReverbLevel(this, instance);
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, __int64, FMOD::DSPI **, double))this->_vptr_ChannelControlI
                + 36))(
                 this,
                 4294967294LL,
                 dspreverb,
                 0.0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD::DSPI::addInput(
                   this->mSystem->mReverb[instance].mDSP,
                   dspreverb[0],
                   &this->mReverbConnection[instance],
                   FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SEND_0,
                   0,
                   0);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
          return FMOD::ChannelGroupI::updateReverbLevel(this, instance);
      }
    }
  }
  else
  {
    this->mReverbConnection[instance] = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e5a30 | Name: _ZN4FMOD13ChannelGroupI8addGroupEPS0_bPPNS_14DSPConnectionIE
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::addGroup(
        FMOD::ChannelGroupI *const this,
        FMOD::ChannelGroupI *group,
        bool propagatedspclock,
        FMOD::DSPConnectionI **connection)
{
  FMOD_RESULT_0 updated; // ebp
  FMOD::SystemI *mSystem; // r12
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::LinkedListNode *p_mNode; // r14
  int (**vptr_ChannelControlI)(...); // rax
  FMOD::ChannelGroupI *mChannelGroupParent; // rdi
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // esi
  FMOD_RESULT_0 v15; // eax
  char v17; // [rsp+7h] [rbp-51h]
  FMOD::DSPI *group_dsphead; // [rsp+10h] [rbp-48h] BYREF
  FMOD::DSPI *parentTail[8]; // [rsp+18h] [rbp-40h] BYREF

  updated = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !group )
    return updated;
  if ( group == this )
    return updated;
  LOBYTE(updated) = 0;
  if ( group->mChannelGroupParent == this )
    return updated;
  mSystem = this->mSystem;
  if ( mSystem )
  {
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPCLOCK);
    v17 = 1;
  }
  else
  {
    v17 = 0;
  }
  mNodePrev = group->mNode.mNodePrev;
  p_mNode = &group->mNode;
  mNodePrev->mNodeNext = group->mNode.mNodeNext;
  group->mNode.mNodeNext->mNodePrev = mNodePrev;
  vptr_ChannelControlI = group->_vptr_ChannelControlI;
  group->mNode.mNodePrev = &group->mNode;
  group->mNode.mNodeNext = &group->mNode;
  updated = vptr_ChannelControlI[36](group, 0, &group_dsphead);
  if ( updated == FMOD_RESULT::FMOD_OK_0 )
  {
    mChannelGroupParent = group->mChannelGroupParent;
    if ( !mChannelGroupParent )
      goto LABEL_10;
    parentTail[0] = 0;
    updated = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **))mChannelGroupParent->_vptr_ChannelControlI
               + 36))(
                mChannelGroupParent,
                4294967293LL,
                parentTail);
    if ( updated == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( (parentTail[0]->mJob.mFlags & 0x1000) == 0 )
      {
        v15 = FMOD::DSPI::disconnectFrom(
                parentTail[0],
                group_dsphead,
                0,
                FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0);
        if ( v15 )
        {
          updated = v15;
          goto LABEL_17;
        }
      }
LABEL_10:
      group->mNode.mNodePrev = this->mGroupHead.mNodePrev;
      group->mNode.mNodeNext = &this->mGroupHead;
      this->mGroupHead.mNodePrev = p_mNode;
      group->mNode.mNodePrev->mNodeNext = p_mNode;
      group->mNode.mNodeData = group;
      updated = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, __int64, FMOD::DSPI **))this->_vptr_ChannelControlI
                 + 36))(
                  this,
                  4294967293LL,
                  parentTail);
      if ( updated == FMOD_RESULT::FMOD_OK_0
        && (!group_dsphead
         || (updated = FMOD::DSPI::addInput(
                         parentTail[0],
                         group_dsphead,
                         connection,
                         FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                         0,
                         0)) == FMOD_RESULT::FMOD_OK_0
         && (!propagatedspclock
          || (updated = FMOD::ChannelGroupI::updateClockTree(group, &parentTail[0]->mJob.mDelayClock)) == FMOD_RESULT::FMOD_OK_0)) )
      {
        mFlags = this->mFlags;
        group->mChannelGroupParent = this;
        updated = FMOD::ChannelGroupI::setPausedInternal(group, (mFlags & 0x10) != 0);
        if ( updated == FMOD_RESULT::FMOD_OK_0 )
        {
          updated = FMOD::ChannelGroupI::setVolumeInternal(group);
          if ( updated == FMOD_RESULT::FMOD_OK_0 )
            updated = FMOD::ChannelGroupI::setPitchInternal(group);
        }
      }
    }
  }
LABEL_17:
  if ( v17 && mSystem )
    FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPCLOCK);
  return updated;
}


// Address: 0x21e5c70 | Name: _ZN4FMOD13ChannelGroupI15releaseInternalEb
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::releaseInternal(FMOD::ChannelGroupI *const this, bool releasechildren)
{
  FMOD::LinkedListNode *i; // rax
  FMOD::LinkedListNode *mNodeNext; // rbp
  FMOD_RESULT_0 result; // eax
  unsigned int v6; // ebp
  FMOD::SystemI *mSystem; // rdx
  FMOD::ChannelGroupI *mMasterChannelGroup; // rsi
  FMOD::LinkedListNode *v9; // rax
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::DSPFader *mDSPFader; // rdi
  __int64 v12; // rax
  char *mName; // rsi
  float *mData; // rsi
  FMOD::DSPI **mDSP; // rsi
  FMOD::ChannelGroupI *v16; // rdi
  FMOD::LinkedListNode *v17; // rax
  FMOD::ChannelGroupI *v18; // rbp
  FMOD::LinkedListNode *v19; // rdx
  FMOD::Global *v20; // rax

  if ( releasechildren )
  {
    for ( i = this->mGroupHead.mNodeNext; i != &this->mGroupHead; i = mNodeNext )
    {
      mNodeNext = i->mNodeNext;
      result = FMOD::ChannelGroupI::releaseInternal((FMOD::ChannelGroupI *const)i->mNodeData, 1);
      if ( result )
        return result;
    }
  }
  v6 = 0;
  (*((void (__fastcall **)(FMOD::ChannelGroupI *const, _QWORD, __int64))this->_vptr_ChannelControlI + 32))(
    this,
    0,
    -1048576);
  mSystem = this->mSystem;
  if ( mSystem->mMasterChannelGroup != this )
  {
    do
    {
      if ( mSystem->mReverb[v6].mDSP )
      {
        result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *const, _QWORD, double))this->_vptr_ChannelControlI
                  + 13))(
                   this,
                   v6,
                   0.0);
        if ( result )
          return result;
        mSystem = this->mSystem;
      }
      ++v6;
    }
    while ( v6 != 4 );
    mMasterChannelGroup = mSystem->mMasterChannelGroup;
    if ( mMasterChannelGroup )
    {
      if ( this != mMasterChannelGroup )
      {
        v9 = this->mChannelHead.mNodeNext;
        if ( v9 != &this->mChannelHead )
        {
          while ( 1 )
          {
            FMOD::ChannelI::setChannelGroup((FMOD::ChannelI *const)v9->mNodeData, mMasterChannelGroup);
            v9 = this->mChannelHead.mNodeNext;
            if ( v9 == &this->mChannelHead )
              break;
            mMasterChannelGroup = this->mSystem->mMasterChannelGroup;
          }
        }
      }
    }
  }
  if ( this->mPortId == -1 || (result = FMOD::ChannelGroupI::disconnectFromPort(this)) == FMOD_RESULT::FMOD_OK_0 )
  {
    mNodePrev = this->mSystemUpdateListNode.mNodePrev;
    mDSPFader = this->mDSPFader;
    mNodePrev->mNodeNext = this->mSystemUpdateListNode.mNodeNext;
    this->mSystemUpdateListNode.mNodeNext->mNodePrev = mNodePrev;
    this->mSystemUpdateListNode.mNodePrev = &this->mSystemUpdateListNode;
    this->mSystemUpdateListNode.mNodeNext = &this->mSystemUpdateListNode;
    if ( mDSPFader )
    {
      v12 = *(_QWORD *)mDSPFader;
      *((_WORD *)mDSPFader + 46) &= 0xFE7Fu;
      result = (*(unsigned int (**)(void))(v12 + 16))();
      if ( result )
        return result;
      this->mDSPFader = 0;
    }
    mName = this->mName;
    if ( mName )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, mName, "../../../core_api/src/fmod_channelgroupi.cpp", 450);
    mData = this->mMixMatrix.mData;
    if ( mData )
    {
      FMOD::MemPool::free(&this->mSystem->mDSPLevelsPool, mData, (const char *)&uri_string, 0);
      this->mMixMatrix.mData = 0;
      this->mMixMatrix.mInChannels = 0;
      this->mMixMatrix.mOutChannels = 0;
    }
    mDSP = this->mDSP;
    if ( mDSP )
    {
      FMOD::MemPool::free(
        (FMOD::MemPool *const)((char *)&stru_10818 + (unsigned __int64)this->mSystem),
        mDSP,
        (const char *)&uri_string,
        0);
      this->mDSP = 0;
    }
    v16 = this->mSystem->mMasterChannelGroup;
    if ( v16 )
    {
      if ( this != v16 )
      {
        v17 = this->mGroupHead.mNodeNext;
        if ( &this->mGroupHead != v17 )
        {
          while ( 1 )
          {
            v18 = (FMOD::ChannelGroupI *)v17->mNodeNext;
            FMOD::ChannelGroupI::addGroup(v16, (FMOD::ChannelGroupI *)v17->mNodeData, 1, 0);
            if ( &this->mGroupHead == (FMOD::LinkedListNode *)v18 )
              break;
            v16 = this->mSystem->mMasterChannelGroup;
            v17 = (FMOD::LinkedListNode *)v18;
          }
        }
      }
    }
    v19 = this->mNode.mNodePrev;
    v19->mNodeNext = this->mNode.mNodeNext;
    this->mNode.mNodeNext->mNodePrev = v19;
    this->mNode.mNodePrev = &this->mNode;
    this->mNode.mNodeNext = &this->mNode;
    v20 = off_286F358;
    this->mMagic = -559039983;
    FMOD::MemPool::free(v20->gSystemMemPool, this, "../../../core_api/src/fmod_channelgroupi.cpp", 487);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e5f20 | Name: _ZN4FMOD13ChannelGroupI7releaseEv
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::release(FMOD::ChannelGroupI *const this)
{
  if ( this->mSystem->mMasterChannelGroup == this )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  else
    return FMOD::ChannelGroupI::releaseInternal(this, 0);
}


// Address: 0x21e5f40 | Name: _ZN4FMOD13ChannelGroupI12getNumGroupsEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getNumGroups(FMOD::ChannelGroupI *const this, int *numgroups)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelGroupI *mNodeNext; // rax
  int i; // edx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numgroups )
  {
    mNodeNext = (FMOD::ChannelGroupI *)this->mGroupHead.mNodeNext;
    for ( i = 0; &this->mGroupHead != (FMOD::LinkedListNode *)mNodeNext; ++i )
      mNodeNext = (FMOD::ChannelGroupI *)mNodeNext->_vptr_ChannelControlI;
    *numgroups = i;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e5f80 | Name: _ZN4FMOD13ChannelGroupI8getGroupEiPPS0_
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getGroup(
        FMOD::ChannelGroupI *const this,
        int index,
        FMOD::ChannelGroupI **group)
{
  FMOD::LinkedListNode *p_mGroupHead; // r8
  FMOD::LinkedListNode *mNodeNext; // rdi
  FMOD::LinkedListNode *v5; // rax
  FMOD_RESULT_0 v6; // ecx
  FMOD_RESULT_0 result; // eax

  p_mGroupHead = &this->mGroupHead;
  mNodeNext = this->mGroupHead.mNodeNext;
  if ( p_mGroupHead == mNodeNext )
  {
    v6 = FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    v5 = mNodeNext;
    v6 = FMOD_RESULT::FMOD_OK_0;
    do
    {
      v5 = v5->mNodeNext;
      ++v6;
    }
    while ( p_mGroupHead != v5 );
  }
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index >= 0 && index < v6 && group )
  {
    LOBYTE(result) = 0;
    do
    {
      if ( result == index )
        *group = (FMOD::ChannelGroupI *)mNodeNext->mNodeData;
      ++result;
      mNodeNext = mNodeNext->mNodeNext;
    }
    while ( v6 > result );
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e5ff0 | Name: _ZN4FMOD13ChannelGroupI14getParentGroupEPPS0_
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getParentGroup(
        FMOD::ChannelGroupI *const this,
        FMOD::ChannelGroupI **group)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( group )
  {
    *group = this->mChannelGroupParent;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e6010 | Name: _ZN4FMOD13ChannelGroupI7getNameEPci
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getName(FMOD::ChannelGroupI *const this, char *name, int namelen)
{
  FMOD_RESULT_0 result; // eax
  char *mName; // rsi

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( name )
  {
    mName = this->mName;
    LOWORD(result) = 256;
    if ( namelen <= 256 )
      result = namelen;
    if ( !mName )
      mName = "(null)";
    FMOD_strcpy_safe(name, mName, result);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e6060 | Name: _ZN4FMOD13ChannelGroupI14getNumChannelsEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getNumChannels(FMOD::ChannelGroupI *const this, int *numchannels)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numchannels )
  {
    *numchannels = this->mNumChannels;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e6080 | Name: _ZN4FMOD13ChannelGroupI10getChannelEiPPNS_7ChannelE
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::getChannel(
        FMOD::ChannelGroupI *const this,
        int index,
        FMOD::Channel **channel)
{
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *p_mChannelHead; // rdi
  int v5; // ecx

  if ( !channel )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *channel = 0;
  mNodeNext = this->mChannelHead.mNodeNext;
  p_mChannelHead = &this->mChannelHead;
  if ( mNodeNext == p_mChannelHead )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v5 = 0;
  if ( index )
  {
    do
    {
      mNodeNext = mNodeNext->mNodeNext;
      ++v5;
      if ( mNodeNext == p_mChannelHead )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
    while ( index != v5 );
  }
  *channel = (FMOD::Channel *)*((_QWORD *)mNodeNext->mNodeData + 10);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e60e0 | Name: _ZN4FMOD13ChannelGroupI9isPlayingEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::isPlaying(FMOD::ChannelGroupI *const this, bool *isplaying)
{
  FMOD_RESULT_0 result; // eax
  int v3; // ebx
  int v4; // ebx
  int numchannels; // [rsp+0h] [rbp-38h] BYREF
  int numgroups; // [rsp+4h] [rbp-34h] BYREF
  FMOD::ChannelGroupI *group[6]; // [rsp+8h] [rbp-30h] BYREF

  *isplaying = 0;
  result = FMOD::ChannelGroupI::getNumChannels(this, &numchannels);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( numchannels <= 0 )
    {
LABEL_9:
      result = FMOD::ChannelGroupI::getNumGroups(this, &numgroups);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v4 = 0;
        if ( numgroups > 0 )
        {
          while ( 1 )
          {
            result = FMOD::ChannelGroupI::getGroup(this, v4, group);
            if ( result )
              break;
            result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, bool *))group[0]->_vptr_ChannelControlI + 21))(
                       group[0],
                       isplaying);
            if ( result )
              break;
            if ( ++v4 >= numgroups )
              return FMOD_RESULT::FMOD_OK_0;
          }
        }
        else
        {
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
    else
    {
      v3 = 0;
      while ( 1 )
      {
        result = FMOD::ChannelGroupI::getChannel(this, v3, (FMOD::Channel **)group);
        if ( result )
          break;
        FMOD::ChannelControl::isPlaying((FMOD::ChannelControl *const)group[0], isplaying);
        if ( *isplaying )
          return FMOD_RESULT::FMOD_OK_0;
        if ( numchannels <= ++v3 )
          goto LABEL_9;
      }
    }
  }
  return result;
}


