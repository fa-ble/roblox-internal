// Address: 0x2219b10 | Name: FMOD_DSP_Convert_FloatToPCM16_AVX
void __fastcall FMOD_DSP_Convert_FloatToPCM16_AVX(
        __int16 *outbuffer,
        float *inbuffer,
        int length,
        int destchannelstep,
        int srcchannelstep,
        __m128 volume,
        __m128 _XMM1,
        double a8,
        double a9,
        double a10,
        __m128 _XMM5)
{
  __int64 v19; // r9
  __int64 v20; // r11
  __int64 v21; // r15
  __int64 v22; // r14
  __int64 v23; // r13
  __int64 v24; // r12
  __int64 v25; // rbx
  __int64 v26; // r10
  __int64 v27; // r9
  __int16 *v29; // rax
  int v30; // edi
  int v60; // edi
  __int64 v61; // rax
  int v62; // eax
  float *v102; // [rsp+Ch] [rbp-90h]
  __int16 *v103; // [rsp+14h] [rbp-88h]
  __int64 v104; // [rsp+2Ch] [rbp-70h]
  __int64 v105; // [rsp+34h] [rbp-68h]
  __int64 v106; // [rsp+3Ch] [rbp-60h]
  __int64 v107; // [rsp+44h] [rbp-58h]
  __int64 v108; // [rsp+4Ch] [rbp-50h]
  __int64 v109; // [rsp+54h] [rbp-48h]
  __int64 v110; // [rsp+5Ch] [rbp-40h]
  __int64 v111; // [rsp+64h] [rbp-38h]

  __asm { vshufps xmm0, xmm0, xmm0, 0 }
  __asm { vinsertf128 ymm0, ymm0, xmm0, 1 }
  v103 = outbuffer;
  v102 = inbuffer;
  if ( length <= 7 )
  {
    v60 = 0;
  }
  else
  {
    v111 = 4LL * srcchannelstep;
    __asm { vxorps  xmm5, xmm5, xmm5 }
    v110 = 8LL * srcchannelstep;
    v109 = 12LL * srcchannelstep;
    v106 = 24LL * srcchannelstep;
    v19 = 8 * srcchannelstep;
    v105 = 28LL * srcchannelstep;
    v107 = 20LL * srcchannelstep;
    v108 = 16LL * srcchannelstep;
    v104 = destchannelstep;
    v20 = 2LL * destchannelstep;
    v21 = 3LL * destchannelstep;
    v22 = 4LL * destchannelstep;
    v23 = 5LL * destchannelstep;
    v24 = 6LL * destchannelstep;
    v25 = 7LL * destchannelstep;
    v26 = 16LL * destchannelstep;
    v27 = 4 * v19;
    _RDX = inbuffer;
    v29 = outbuffer;
    v30 = 0;
    do
    {
      _RCX = v111;
      __asm { vbroadcastss ymm1, dword ptr [inbuffer] }
      ++v30;
      _RSI = v106;
      __asm
      {
        vblendps ymm1, ymm5, ymm1, 1
        vbroadcastss ymm9, dword ptr [inbuffer+rcx]
      }
      _RCX = v110;
      __asm
      {
        vbroadcastss ymm3, dword ptr [inbuffer+rsi]
        vblendps ymm1, ymm1, ymm9, 2
        vbroadcastss ymm8, dword ptr [inbuffer+rcx]
      }
      _RCX = v109;
      __asm
      {
        vblendps ymm1, ymm1, ymm8, 4
        vbroadcastss ymm7, dword ptr [inbuffer+rcx]
      }
      _RCX = v108;
      __asm
      {
        vblendps ymm1, ymm1, ymm7, 8
        vbroadcastss ymm6, dword ptr [inbuffer+rcx]
      }
      _RCX = v107;
      __asm
      {
        vblendps ymm1, ymm1, ymm6, 10h
        vbroadcastss ymm4, dword ptr [inbuffer+rcx]
      }
      _RCX = v105;
      __asm
      {
        vblendps ymm1, ymm1, ymm4, 20h ; ' '
        vbroadcastss ymm2, dword ptr [inbuffer+rcx]
      }
      _RDX = (float *)((char *)_RDX + v27);
      __asm
      {
        vblendps ymm1, ymm1, ymm3, 40h ; '@'
        vblendps ymm1, ymm1, ymm2, 80h
        vmulps  ymm1, ymm1, ymm0
        vcvtps2dq ymm1, ymm1
        vmovdqa xmm2, xmm1
        vextractf128 xmm1, ymm1, 1
        vpackssdw xmm2, xmm2, xmm2
        vpackssdw xmm1, xmm1, xmm1
        vpextrq rsi, xmm2, 0
        vpextrq rcx, xmm1, 0
      }
      *v29 = _RSI;
      v29[v104] = WORD1(_RSI);
      v29[v20] = WORD2(_RSI);
      v29[v21] = HIWORD(_RSI);
      v29[v22] = _RCX;
      v29[v23] = WORD1(_RCX);
      v29[v24] = WORD2(_RCX);
      v29[v25] = HIWORD(_RCX);
      v29 = (__int16 *)((char *)v29 + v26);
    }
    while ( v30 != ((unsigned int)(length - 8) >> 3) + 1 );
    v60 = 8 * v30;
    v61 = ((unsigned int)(length - 8) >> 3) + 1LL;
    v103 = (__int16 *)((char *)v103 + v61 * v26);
    v102 = (float *)((char *)v102 + v61 * v27);
  }
  v62 = length - v60;
  if ( length != v60 )
  {
    switch ( v62 )
    {
      case 1:
        __asm { vxorps  xmm1, xmm1, xmm1; jumptable 0000000002219DA8 case 1 }
        goto LABEL_21;
      case 2:
        __asm { vxorps  xmm1, xmm1, xmm1; jumptable 0000000002219DA8 case 2 }
        goto LABEL_20;
      case 3:
        __asm { vxorps  xmm1, xmm1, xmm1; jumptable 0000000002219DA8 case 3 }
        goto LABEL_19;
      case 4:
        __asm { vxorps  xmm1, xmm1, xmm1; jumptable 0000000002219DA8 case 4 }
        goto LABEL_18;
      case 5:
        __asm { vxorps  xmm1, xmm1, xmm1; jumptable 0000000002219DA8 case 5 }
        goto LABEL_17;
      case 6:
        __asm { vxorps  xmm1, xmm1, xmm1; jumptable 0000000002219DA8 case 6 }
        goto LABEL_16;
      case 7:
        __asm { vxorps  xmm1, xmm1, xmm1 }
        _RBX = v102;
        _RDX = 6 * srcchannelstep;
        __asm
        {
          vbroadcastss ymm2, dword ptr [rbx+rdx*4]
          vblendps ymm1, ymm1, ymm2, 40h ; '@'
        }
LABEL_16:
        _RBX = v102;
        _RDX = 5 * srcchannelstep;
        __asm
        {
          vbroadcastss ymm2, dword ptr [rbx+rdx*4]
          vblendps ymm1, ymm1, ymm2, 20h ; ' '
        }
LABEL_17:
        _RDI = v102;
        _RDX = 4 * srcchannelstep;
        __asm
        {
          vbroadcastss ymm2, dword ptr [rdi+rdx*4]
          vblendps ymm1, ymm1, ymm2, 10h
        }
LABEL_18:
        _RBX = v102;
        _RDX = 3 * srcchannelstep;
        __asm
        {
          vbroadcastss ymm2, dword ptr [rbx+rdx*4]
          vblendps ymm1, ymm1, ymm2, 8
        }
LABEL_19:
        _RBX = v102;
        _RDX = 2 * srcchannelstep;
        __asm
        {
          vbroadcastss ymm2, dword ptr [rbx+rdx*4]
          vblendps ymm1, ymm1, ymm2, 4
        }
LABEL_20:
        _RDX = srcchannelstep;
        _RBX = v102;
        __asm
        {
          vbroadcastss ymm2, dword ptr [rbx+rdx*4]
          vblendps ymm1, ymm1, ymm2, 2
        }
LABEL_21:
        _RBX = v102;
        __asm
        {
          vbroadcastss ymm2, dword ptr [rbx]
          vblendps ymm1, ymm1, ymm2, 1
        }
        break;
      default:
        __asm { vxorps  xmm1, xmm1, xmm1; jumptable 0000000002219DA8 default case, case 0 }
        break;
    }
    __asm { vmulps  ymm0, ymm1, ymm0 }
    __asm
    {
      vcvtps2dq ymm0, ymm0
      vmovdqa xmm1, xmm0
      vextractf128 xmm0, ymm0, 1
      vpackssdw xmm1, xmm1, xmm1
      vpackssdw xmm0, xmm0, xmm0
      vpextrq rdx, xmm1, 0
      vpextrq rsi, xmm0, 0
    }
    switch ( v62 )
    {
      case 1:
        goto LABEL_13;
      case 2:
        goto LABEL_12;
      case 3:
        goto LABEL_11;
      case 4:
        goto LABEL_10;
      case 5:
        goto LABEL_9;
      case 6:
        goto LABEL_8;
      case 7:
        v103[6 * destchannelstep] = WORD2(_RSI);
LABEL_8:
        v103[5 * destchannelstep] = WORD1(_RSI);
LABEL_9:
        v103[4 * destchannelstep] = _RSI;
LABEL_10:
        v103[3 * destchannelstep] = HIWORD(_RDX);
LABEL_11:
        v103[2 * destchannelstep] = WORD2(_RDX);
LABEL_12:
        v103[destchannelstep] = WORD1(_RDX);
LABEL_13:
        *v103 = _RDX;
        break;
      default:
        break;
    }
  }
  __asm { vzeroupper; jumptable 0000000002219F29 default case, case 0 }
}


