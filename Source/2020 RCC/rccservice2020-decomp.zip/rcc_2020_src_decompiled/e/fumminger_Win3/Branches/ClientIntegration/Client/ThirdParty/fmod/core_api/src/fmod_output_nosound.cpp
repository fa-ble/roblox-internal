// Address: 0x2252940 | Name: _ZN4FMOD13OutputNoSound16getDescriptionExEv
FMOD::FMOD_OUTPUT_DESCRIPTION_EX *__cdecl FMOD::OutputNoSound::getDescriptionEx()
{
  memset(&stru_2B059C0, 0, sizeof(stru_2B059C0));
  stru_2B059C0.apiversion = 4;
  stru_2B059C0.version = 65792;
  stru_2B059C0.polling = 1;
  stru_2B059C0.mType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_NOSOUND_0;
  stru_2B059C0.name = "FMOD NoSound Output";
  stru_2B059C0.mSize = 1160;
  stru_2B059C0.getnumdrivers = FMOD::OutputNoSound::getNumDriversCallback;
  stru_2B059C0.getdriverinfo = FMOD::OutputNoSound::getDriverInfoCallback;
  stru_2B059C0.init = FMOD::OutputNoSound::initCallback;
  stru_2B059C0.close = FMOD::OutputNoSound::closeCallback;
  stru_2B059C0.getposition = FMOD::OutputNoSound::getPositionCallback;
  stru_2B059C0.lock = FMOD::OutputNoSound::lockCallback;
  return &stru_2B059C0;
}


// Address: 0x22529d0 | Name: _ZN4FMOD13OutputNoSound13getNumDriversEPi
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::getNumDrivers(FMOD::OutputNoSound *const this, int *numdrivers)
{
  *numdrivers = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22529e0 | Name: _ZN4FMOD13OutputNoSound21getNumDriversCallbackEP17FMOD_OUTPUT_STATEPi
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::getNumDriversCallback(FMOD_OUTPUT_STATE *output, int *numdrivers)
{
  FMOD::OutputNoSound *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound *)&output[-1].requestreset;
  return FMOD::OutputNoSound::getNumDrivers(p_requestreset, numdrivers);
}


// Address: 0x2252a00 | Name: _ZN4FMOD13OutputNoSound13getDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::getDriverInfo(
        FMOD::OutputNoSound *const this,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels)
{
  if ( name )
    FMOD_strcpy_safe(name, "NoSound Driver", namelen);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2252a30 | Name: _ZN4FMOD13OutputNoSound21getDriverInfoCallbackEP17FMOD_OUTPUT_STATEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES6_
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::getDriverInfoCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels)
{
  FMOD::OutputNoSound *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound *)&output[-1].requestreset;
  return FMOD::OutputNoSound::getDriverInfo(
           p_requestreset,
           id,
           name,
           namelen,
           guid,
           systemrate,
           speakermode,
           speakermodechannels);
}


// Address: 0x2252a50 | Name: _ZN4FMOD13OutputNoSound4initEijPiP16FMOD_SPEAKERMODES1_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::init(
        FMOD::OutputNoSound *const this,
        int selecteddriver,
        FMOD_INITFLAGS flags,
        int *outputrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels,
        FMOD_SOUND_FORMAT_0 *outputformat,
        int dspbufferlength,
        int dspnumbuffers,
        void *extradriverdata)
{
  int v10; // esi
  unsigned __int64 v11; // rax
  __int64 v12; // rdx
  int v13; // esi
  FMOD::Global *v14; // rax
  void *v15; // rax

  if ( *speakermode )
  {
    v10 = *speakermodechannels;
  }
  else
  {
    *speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0;
    v10 = 2;
    *speakermodechannels = 2;
  }
  v11 = (unsigned int)(dspnumbuffers * dspbufferlength);
  switch ( *outputformat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      v12 = 8;
      goto LABEL_5;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      v12 = 16;
      goto LABEL_5;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      v12 = 24;
      goto LABEL_5;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      v12 = 32;
LABEL_5:
      v11 = (v12 * v11) >> 3;
      break;
    default:
      break;
  }
  v13 = v11 * v10;
  v14 = off_286F358;
  *((_DWORD *)this + 286) = v13;
  v15 = FMOD::MemPool::calloc(v14->gSystemMemPool, v13, "../../../core_api/src/fmod_output_nosound.cpp", 119, 0);
  *((_QWORD *)this + 144) = v15;
  return v15 == 0 ? 0x26 : 0;
}


// Address: 0x2252b20 | Name: _ZN4FMOD13OutputNoSound12initCallbackEP17FMOD_OUTPUT_STATEijPiP16FMOD_SPEAKERMODES3_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::initCallback(
        FMOD_OUTPUT_STATE *output,
        int selecteddriver,
        FMOD_INITFLAGS flags,
        int *outputrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels,
        FMOD_SOUND_FORMAT_0 *outputformat,
        int dspbufferlength,
        int dspnumbuffers,
        void *extradriverdata)
{
  FMOD::OutputNoSound *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound *)&output[-1].requestreset;
  return FMOD::OutputNoSound::init(
           p_requestreset,
           selecteddriver,
           flags,
           outputrate,
           speakermode,
           speakermodechannels,
           outputformat,
           dspbufferlength,
           dspnumbuffers,
           extradriverdata);
}


// Address: 0x2252b40 | Name: _ZN4FMOD13OutputNoSound5closeEv
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::close(FMOD::OutputNoSound *const this)
{
  void *v1; // rsi

  v1 = (void *)*((_QWORD *)this + 144);
  if ( v1 )
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_output_nosound.cpp", 146);
  *((_QWORD *)this + 144) = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2252b90 | Name: _ZN4FMOD13OutputNoSound13closeCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::closeCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputNoSound *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound *)&output[-1].requestreset;
  return FMOD::OutputNoSound::close(p_requestreset);
}


// Address: 0x2252bb0 | Name: _ZN4FMOD13OutputNoSound11getPositionEPj
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::getPosition(FMOD::OutputNoSound *const this, unsigned int *pcm)
{
  __int64 v2; // rax
  int v3; // ebp
  unsigned int ms[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  v2 = *((_QWORD *)this + 9);
  ms[0] = 0;
  v3 = *(_DWORD *)(v2 + 1696);
  FMOD_OS_Time_GetMs(ms);
  *pcm = v3 * ms[0] / 0x3E8;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2252c00 | Name: _ZN4FMOD13OutputNoSound19getPositionCallbackEP17FMOD_OUTPUT_STATEPj
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::getPositionCallback(FMOD_OUTPUT_STATE *output, unsigned int *pcm)
{
  FMOD::OutputNoSound *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound *)&output[-1].requestreset;
  return FMOD::OutputNoSound::getPosition(p_requestreset, pcm);
}


// Address: 0x2252c20 | Name: _ZN4FMOD13OutputNoSound4lockEjjPPvS2_PjS3_
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::lock(
        FMOD::OutputNoSound *const this,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  unsigned int v7; // r10d
  unsigned int v9; // edx

  v7 = *((_DWORD *)this + 286);
  v9 = offset % v7;
  *ptr1 = (void *)(*((_QWORD *)this + 144) + offset % v7);
  if ( v7 < offset % v7 + length )
  {
    *ptr2 = (void *)*((_QWORD *)this + 144);
    *len1 = v7 - v9;
    *len2 = length - *((_DWORD *)this + 286) + v9;
  }
  else
  {
    *ptr2 = 0;
    *len1 = length;
    *len2 = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2252ca0 | Name: _ZN4FMOD13OutputNoSound12lockCallbackEP17FMOD_OUTPUT_STATEjjPPvS4_PjS5_
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound::lockCallback(
        FMOD_OUTPUT_STATE *output,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  FMOD::OutputNoSound *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound *)&output[-1].requestreset;
  return FMOD::OutputNoSound::lock(p_requestreset, offset, length, ptr1, ptr2, len1, len2);
}


