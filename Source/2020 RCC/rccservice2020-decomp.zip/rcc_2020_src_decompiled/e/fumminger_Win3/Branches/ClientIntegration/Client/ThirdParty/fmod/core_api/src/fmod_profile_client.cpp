// Address: 0x225a510 | Name: _ZN4FMOD17ProfileRingBuffer4initEii
FMOD_RESULT_0 __fastcall FMOD::ProfileRingBuffer::init(
        FMOD::ProfileRingBuffer *const this,
        int initialSize,
        int writeAlign)
{
  char *v4; // rax
  FMOD_RESULT_0 v5; // ecx
  FMOD_RESULT_0 v7; // eax

  v4 = (char *)FMOD::MemPool::alloc(
                 off_286F358->gSystemMemPool,
                 initialSize,
                 "../../../core_api/src/fmod_profile_client.cpp",
                 82,
                 0,
                 0);
  this->mPtr = v4;
  v5 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v4 )
  {
    this->mLength = initialSize;
    this->mWriteCount = 0;
    this->mReadCount = 0;
    this->mNewCapacityRequested = 0;
    this->mShuttingDown = 0;
    this->mWriteAlign = writeAlign;
    v5 = FMOD_OS_CriticalSection_Create(&this->mLock, 0);
    if ( v5 == FMOD_RESULT::FMOD_OK_0 )
    {
      v5 = FMOD_OS_Semaphore_Create(&this->mDataAvailable);
      if ( v5 == FMOD_RESULT::FMOD_OK_0 )
      {
        v7 = FMOD_OS_Semaphore_Create(&this->mCapacityAvailable);
        if ( v7 == FMOD_RESULT::FMOD_OK_0 )
        {
          this->mDataWaitCount = 0;
          this->mCapacityWaitCount = 0;
        }
        return v7;
      }
    }
  }
  return v5;
}


// Address: 0x225a5c0 | Name: _ZN4FMOD17ProfileRingBuffer8moreDataEv
FMOD_RESULT_0 __fastcall FMOD::ProfileRingBuffer::moreData(FMOD::ProfileRingBuffer *const this)
{
  FMOD_OS_CRITICALSECTION *mLock; // r12
  int v2; // ebx
  FMOD_RESULT_0 v3; // eax
  FMOD_RESULT_0 v4; // ebx

  mLock = this->mLock;
  v2 = 0;
  FMOD_OS_CriticalSection_Enter(mLock);
  if ( this->mDataWaitCount > 0 )
  {
    while ( 1 )
    {
      v3 = FMOD_OS_Semaphore_Signal(this->mDataAvailable);
      if ( v3 )
        break;
      if ( this->mDataWaitCount <= ++v2 )
        goto LABEL_6;
    }
    v4 = v3;
    FMOD_OS_CriticalSection_Leave(mLock);
    return v4;
  }
  else
  {
LABEL_6:
    this->mDataWaitCount = 0;
    FMOD_OS_CriticalSection_Leave(mLock);
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x225a630 | Name: _ZN4FMOD17ProfileRingBuffer10startWriteEibPNS0_12LockedBufferE
FMOD_RESULT_0 __fastcall FMOD::ProfileRingBuffer::startWrite(
        FMOD::ProfileRingBuffer *const this,
        int size,
        bool contiguous,
        FMOD::ProfileRingBuffer::LockedBuffer *locked)
{
  unsigned int mWriteCount; // esi
  int v8; // ecx
  unsigned int v9; // edx
  char *mPtr; // rsi
  int v11; // eax
  int v12; // edx
  int v13; // ecx
  FMOD_RESULT_0 result; // eax
  int mLength; // eax

  while ( !this->mShuttingDown )
  {
    result = FMOD_OS_CriticalSection_Enter(this->mLock);
    if ( result )
      return result;
    if ( this->mNewCapacityRequested )
      goto LABEL_6;
    mLength = this->mLength;
    if ( mLength < size )
    {
      this->mNewCapacityRequested = size;
      result = FMOD::ProfileRingBuffer::moreData(this);
      if ( result )
        return result;
      goto LABEL_6;
    }
    mWriteCount = this->mWriteCount;
    v8 = mWriteCount & (mLength - 1);
    v9 = mLength - mWriteCount;
    mPtr = this->mPtr;
    v11 = mLength - v8;
    v12 = this->mReadCount + v9;
    locked->mPtr2 = 0;
    locked->mLen1 = size;
    locked->mLen2 = 0;
    locked->mPtr1 = &mPtr[v8];
    v13 = size;
    if ( size <= v11 )
      goto LABEL_5;
    if ( contiguous )
    {
      v13 = size + v11;
      locked->mLen1 = v11;
      locked->mPtr2 = mPtr;
      locked->mLen2 = size;
LABEL_5:
      if ( v13 <= v12 )
        goto LABEL_15;
      goto LABEL_6;
    }
    locked->mPtr2 = mPtr;
    locked->mLen1 = v11;
    locked->mLen2 = size - v11;
    if ( size <= v12 )
    {
LABEL_15:
      locked->mLock = this->mLock;
      return FMOD_RESULT::FMOD_OK_0;
    }
LABEL_6:
    ++this->mCapacityWaitCount;
    result = FMOD_OS_CriticalSection_Leave(this->mLock);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD_OS_Semaphore_Wait(this->mCapacityAvailable);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        continue;
    }
    return result;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225a750 | Name: _ZN4FMOD17ProfileRingBuffer12advanceWriteEi
FMOD_RESULT_0 __fastcall FMOD::ProfileRingBuffer::advanceWrite(FMOD::ProfileRingBuffer *const this, int commitAmount)
{
  FMOD_OS_CRITICALSECTION *mLock; // rbp
  FMOD_RESULT_0 v3; // ebx

  mLock = this->mLock;
  FMOD_OS_CriticalSection_Enter(mLock);
  if ( commitAmount )
    this->mWriteCount += commitAmount;
  v3 = FMOD::ProfileRingBuffer::moreData(this);
  FMOD_OS_CriticalSection_Leave(mLock);
  return v3;
}


// Address: 0x225a790 | Name: _ZN4FMOD17ProfileRingBuffer12moreCapacityEv
FMOD_RESULT_0 __fastcall FMOD::ProfileRingBuffer::moreCapacity(FMOD::ProfileRingBuffer *const this)
{
  FMOD_OS_CRITICALSECTION *mLock; // r12
  FMOD_RESULT_0 v2; // ebx
  FMOD_RESULT_0 v3; // eax

  mLock = this->mLock;
  v2 = FMOD_RESULT::FMOD_OK_0;
  FMOD_OS_CriticalSection_Enter(mLock);
  if ( this->mCapacityWaitCount > 0 )
  {
    do
    {
      v3 = FMOD_OS_Semaphore_Signal(this->mCapacityAvailable);
      if ( v3 )
      {
        v2 = v3;
        goto LABEL_6;
      }
      ++v2;
    }
    while ( this->mCapacityWaitCount > v2 );
    this->mCapacityWaitCount = 0;
    FMOD_OS_CriticalSection_Leave(mLock);
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
LABEL_6:
    FMOD_OS_CriticalSection_Leave(mLock);
    return v2;
  }
}


// Address: 0x225a800 | Name: _ZN4FMOD17ProfileRingBuffer9startReadEbPNS0_12LockedBufferE
FMOD_RESULT_0 __fastcall FMOD::ProfileRingBuffer::startRead(
        FMOD::ProfileRingBuffer *const this,
        bool blockUntilData,
        FMOD::ProfileRingBuffer::LockedBuffer *locked)
{
  FMOD_RESULT_0 result; // eax
  unsigned int mReadCount; // eax
  int mLength; // edx
  int v8; // ecx
  FMOD_RESULT_0 v9; // eax
  FMOD_RESULT_0 v10; // edx
  unsigned int v11; // eax
  int v12; // esi
  FMOD::Global *v13; // rax
  char *v14; // rax
  int v15; // esi
  int v16; // edx
  char *mPtr; // rax
  char *v18; // rsi

  while ( 1 )
  {
    if ( this->mShuttingDown )
      return FMOD_RESULT::FMOD_OK_0;
    result = FMOD_OS_CriticalSection_Enter(this->mLock);
    if ( result )
      return result;
    mReadCount = this->mReadCount;
    mLength = this->mLength;
    v8 = this->mWriteCount - mReadCount;
    if ( v8 )
      break;
    if ( this->mNewCapacityRequested )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, this->mPtr, "../../../core_api/src/fmod_profile_client.cpp", 244);
      v11 = (this->mNewCapacityRequested - 1)
          | ((this->mNewCapacityRequested - 1) >> 1)
          | (((this->mNewCapacityRequested - 1) | ((this->mNewCapacityRequested - 1) >> 1)) >> 2)
          | (((this->mNewCapacityRequested - 1)
            | ((this->mNewCapacityRequested - 1) >> 1)
            | (((this->mNewCapacityRequested - 1) | ((this->mNewCapacityRequested - 1) >> 1)) >> 2)) >> 4)
          | (((this->mNewCapacityRequested - 1)
            | ((this->mNewCapacityRequested - 1) >> 1)
            | (((this->mNewCapacityRequested - 1) | ((this->mNewCapacityRequested - 1) >> 1)) >> 2)
            | (((this->mNewCapacityRequested - 1)
              | ((this->mNewCapacityRequested - 1) >> 1)
              | (((this->mNewCapacityRequested - 1) | ((this->mNewCapacityRequested - 1) >> 1)) >> 2)) >> 4)) >> 8);
      v12 = v11 | HIWORD(v11);
      v13 = off_286F358;
      this->mLength = ++v12;
      v14 = (char *)FMOD::MemPool::alloc(
                      v13->gSystemMemPool,
                      v12,
                      "../../../core_api/src/fmod_profile_client.cpp",
                      248,
                      0,
                      0);
      this->mPtr = v14;
      if ( !v14 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      this->mWriteCount = 0;
      this->mReadCount = 0;
      this->mNewCapacityRequested = 0;
      result = FMOD::ProfileRingBuffer::moreCapacity(this);
      if ( result )
        return result;
    }
    if ( !blockUntilData )
    {
      v9 = FMOD_OS_CriticalSection_Leave(this->mLock);
      v10 = FMOD_RESULT::FMOD_ERR_NET_WOULD_BLOCK_0;
      if ( v9 )
        return v9;
      return v10;
    }
    ++this->mDataWaitCount;
    result = FMOD_OS_CriticalSection_Leave(this->mLock);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD_OS_Semaphore_Wait(this->mDataAvailable);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        continue;
    }
    return result;
  }
  v15 = mReadCount & (mLength - 1);
  v16 = mLength - v15;
  if ( v16 >= v8 )
  {
    v18 = &this->mPtr[v15];
    locked->mPtr2 = 0;
    locked->mLen1 = v8;
    locked->mLen2 = 0;
  }
  else
  {
    mPtr = this->mPtr;
    locked->mLen1 = v16;
    locked->mLen2 = v8 - v16;
    v18 = &mPtr[v15];
    locked->mPtr2 = mPtr;
  }
  locked->mPtr1 = v18;
  locked->mLock = this->mLock;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225a9e0 | Name: _ZN4FMOD17ProfileRingBuffer11advanceReadEi
FMOD_RESULT_0 __fastcall FMOD::ProfileRingBuffer::advanceRead(FMOD::ProfileRingBuffer *const this, int consumed)
{
  FMOD_OS_CRITICALSECTION *mLock; // rbp
  unsigned int v3; // r12d
  bool v4; // zf
  FMOD_RESULT_0 v5; // ebx

  mLock = this->mLock;
  FMOD_OS_CriticalSection_Enter(mLock);
  if ( consumed )
  {
    v3 = this->mReadCount + consumed;
    v4 = v3 == this->mWriteCount;
    this->mReadCount = v3;
    if ( v4 )
    {
      this->mReadCount = 0;
      this->mWriteCount = 0;
    }
  }
  v5 = FMOD::ProfileRingBuffer::moreCapacity(this);
  FMOD_OS_CriticalSection_Leave(mLock);
  return v5;
}


// Address: 0x225aa40 | Name: _ZNK4FMOD17ProfileRingBuffer9getLengthEv
int __fastcall FMOD::ProfileRingBuffer::getLength(const FMOD::ProfileRingBuffer *const this)
{
  return this->mLength;
}


// Address: 0x225aa50 | Name: _ZNK4FMOD17ProfileRingBuffer11getCapacityEv
int __fastcall FMOD::ProfileRingBuffer::getCapacity(const FMOD::ProfileRingBuffer *const this)
{
  FMOD_OS_CRITICALSECTION *mLock; // r12
  int v2; // ebx

  mLock = this->mLock;
  FMOD_OS_CriticalSection_Enter(mLock);
  v2 = this->mLength + this->mReadCount - this->mWriteCount;
  FMOD_OS_CriticalSection_Leave(mLock);
  return v2;
}


// Address: 0x225aa80 | Name: _ZNK4FMOD17ProfileRingBuffer17getWaitingWritersEv
int __fastcall FMOD::ProfileRingBuffer::getWaitingWriters(const FMOD::ProfileRingBuffer *const this)
{
  return this->mCapacityWaitCount;
}


// Address: 0x225aa90 | Name: _ZNK4FMOD17ProfileRingBuffer13getWriteCountEv
int __fastcall FMOD::ProfileRingBuffer::getWriteCount(const FMOD::ProfileRingBuffer *const this)
{
  return this->mWriteCount;
}


// Address: 0x225aaa0 | Name: _ZNK4FMOD17ProfileRingBuffer12getReadCountEv
int __fastcall FMOD::ProfileRingBuffer::getReadCount(const FMOD::ProfileRingBuffer *const this)
{
  return this->mReadCount;
}


// Address: 0x225aab0 | Name: _ZN4FMOD17ProfileRingBuffer15wakeForShutdownEv
FMOD_RESULT_0 __fastcall FMOD::ProfileRingBuffer::wakeForShutdown(FMOD::ProfileRingBuffer *const this)
{
  FMOD_RESULT_0 result; // eax

  this->mShuttingDown = 1;
  result = FMOD_OS_Semaphore_Signal(this->mDataAvailable);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_OS_Semaphore_Signal(this->mCapacityAvailable);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return FMOD::ProfileRingBuffer::moreCapacity(this);
  }
  return result;
}


// Address: 0x225aaf0 | Name: _ZN4FMOD17ProfileRingBuffer7releaseEv
FMOD_RESULT_0 __fastcall FMOD::ProfileRingBuffer::release(FMOD::ProfileRingBuffer *const this)
{
  FMOD_RESULT_0 result; // eax

  FMOD::MemPool::free(off_286F358->gSystemMemPool, this->mPtr, "../../../core_api/src/fmod_profile_client.cpp", 371);
  result = FMOD_OS_CriticalSection_Free(this->mLock, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_OS_Semaphore_Free(this->mDataAvailable);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_OS_Semaphore_Free(this->mCapacityAvailable);
  }
  return result;
}


// Address: 0x225ab50 | Name: _ZN4FMOD13ProfileClientC2Ev
void __fastcall FMOD::ProfileClient::ProfileClient(FMOD::ProfileClient *const this)
{
  FMOD::Thread *p_mRecvThread; // rdi
  FMOD::ProfileDataType *mDataType; // rdi
  unsigned int v4; // edx
  __int64 v5; // rcx
  unsigned __int8 *v6; // rdi
  FMOD::ProfileRingBuffer *p_mSendBuffer; // rdi
  unsigned int v8; // edx
  __int64 v9; // rcx
  char **v10; // rdi
  FMOD::ProfileRingBuffer *p_mRecvBuffer; // rdi
  unsigned int v12; // edx
  __int64 v13; // rcx
  char **v14; // rdi
  __int64 i; // rax

  this->mNodePrev = this;
  this->mNodeNext = this;
  p_mRecvThread = &this->mRecvThread;
  p_mRecvThread[-1].mControlSema = 0;
  FMOD::Thread::Thread(p_mRecvThread);
  FMOD::Thread::Thread(&this->mSendThread);
  mDataType = this->mDataType;
  this->mProfile = 0;
  this->mSocket = (void *)-1LL;
  this->mLock = 0;
  this->mDead = 0;
  v4 = 512;
  this->mSendCount = 0;
  this->mRecvCount = 0;
  if ( (((_BYTE)this - 44) & 1) == 0 )
  {
    if ( (((_BYTE)this - 44) & 2) == 0 )
      goto LABEL_3;
LABEL_32:
    mDataType = (FMOD::ProfileDataType *)((char *)mDataType + 2);
    v4 -= 2;
    HIWORD(mDataType[-1].maxPacketSize) = 0;
    if ( ((unsigned __int8)mDataType & 4) == 0 )
      goto LABEL_4;
    goto LABEL_33;
  }
  mDataType = (FMOD::ProfileDataType *)&this->mDataType[0].subType;
  this->mDataType[0].type = 0;
  LOWORD(v4) = 511;
  if ( (((_BYTE)this - 43) & 2) != 0 )
    goto LABEL_32;
LABEL_3:
  if ( ((unsigned __int8)mDataType & 4) == 0 )
    goto LABEL_4;
LABEL_33:
  *(_DWORD *)&mDataType->type = 0;
  v4 -= 4;
  mDataType = (FMOD::ProfileDataType *)((char *)mDataType + 4);
LABEL_4:
  v5 = v4 >> 3;
  memset(mDataType, 0, 8 * v5);
  v6 = &mDataType->type + 8 * v5;
  if ( (v4 & 4) != 0 )
  {
    *(_DWORD *)v6 = 0;
    v6 += 4;
  }
  if ( (v4 & 2) != 0 )
  {
    v6 += 2;
    *((_WORD *)v6 - 1) = 0;
  }
  if ( (v4 & 1) != 0 )
    *v6 = 0;
  p_mSendBuffer = &this->mSendBuffer;
  v8 = 72;
  if ( (((_BYTE)this - 40) & 1) == 0 )
  {
    if ( (((_BYTE)this - 40) & 2) == 0 )
      goto LABEL_12;
LABEL_35:
    p_mSendBuffer = (FMOD::ProfileRingBuffer *)((char *)p_mSendBuffer + 2);
    v8 -= 2;
    *((_WORD *)&p_mSendBuffer[-1].mWriteAlign + 3) = 0;
    if ( ((unsigned __int8)p_mSendBuffer & 4) == 0 )
      goto LABEL_13;
    goto LABEL_36;
  }
  p_mSendBuffer = (FMOD::ProfileRingBuffer *)((char *)&this->mSendBuffer.mPtr + 1);
  LOBYTE(this->mSendBuffer.mPtr) = 0;
  LOBYTE(v8) = 71;
  if ( (((_BYTE)this - 39) & 2) != 0 )
    goto LABEL_35;
LABEL_12:
  if ( ((unsigned __int8)p_mSendBuffer & 4) == 0 )
    goto LABEL_13;
LABEL_36:
  LODWORD(p_mSendBuffer->mPtr) = 0;
  v8 -= 4;
  p_mSendBuffer = (FMOD::ProfileRingBuffer *)((char *)p_mSendBuffer + 4);
LABEL_13:
  v9 = v8 >> 3;
  memset(p_mSendBuffer, 0, 8 * v9);
  v10 = &p_mSendBuffer->mPtr + v9;
  if ( (v8 & 4) != 0 )
  {
    *(_DWORD *)v10 = 0;
    v10 = (char **)((char *)v10 + 4);
  }
  if ( (v8 & 2) != 0 )
  {
    v10 = (char **)((char *)v10 + 2);
    *((_WORD *)v10 - 1) = 0;
  }
  if ( (v8 & 1) != 0 )
    *(_BYTE *)v10 = 0;
  p_mRecvBuffer = &this->mRecvBuffer;
  v12 = 72;
  if ( (((_BYTE)this + 32) & 1) == 0 )
  {
    if ( ((unsigned __int8)p_mRecvBuffer & 2) == 0 )
      goto LABEL_21;
LABEL_38:
    p_mRecvBuffer = (FMOD::ProfileRingBuffer *)((char *)p_mRecvBuffer + 2);
    v12 -= 2;
    *((_WORD *)&p_mRecvBuffer[-1].mWriteAlign + 3) = 0;
    if ( ((unsigned __int8)p_mRecvBuffer & 4) == 0 )
      goto LABEL_22;
    goto LABEL_39;
  }
  p_mRecvBuffer = (FMOD::ProfileRingBuffer *)((char *)&this->mRecvBuffer.mPtr + 1);
  LOBYTE(this->mRecvBuffer.mPtr) = 0;
  LOBYTE(v12) = 71;
  if ( (((_BYTE)this + 33) & 2) != 0 )
    goto LABEL_38;
LABEL_21:
  if ( ((unsigned __int8)p_mRecvBuffer & 4) == 0 )
    goto LABEL_22;
LABEL_39:
  LODWORD(p_mRecvBuffer->mPtr) = 0;
  v12 -= 4;
  p_mRecvBuffer = (FMOD::ProfileRingBuffer *)((char *)p_mRecvBuffer + 4);
LABEL_22:
  v13 = v12 >> 3;
  memset(p_mRecvBuffer, 0, 8 * v13);
  v14 = &p_mRecvBuffer->mPtr + v13;
  if ( (v12 & 4) != 0 )
  {
    *(_DWORD *)v14 = 0;
    v14 = (char **)((char *)v14 + 4);
  }
  if ( (v12 & 2) != 0 )
  {
    v14 = (char **)((char *)v14 + 2);
    *((_WORD *)v14 - 1) = 0;
  }
  if ( (v12 & 1) != 0 )
    *(_BYTE *)v14 = 0;
  for ( i = 0; i != 32; ++i )
    this->mDataType[i].type = -1;
}


// Address: 0x225adb0 | Name: _ZN4FMOD13ProfileClient6updateEv
FMOD_RESULT_0 __fastcall FMOD::ProfileClient::update(FMOD::ProfileClient *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225adc0 | Name: _ZN4FMOD13ProfileClient13receivePacketEPPNS_19ProfilePacketHeaderEPNS_17ProfileRingBuffer12LockedBufferE
FMOD_RESULT_0 __fastcall FMOD::ProfileClient::receivePacket(
        FMOD::ProfileClient *const this,
        FMOD::ProfilePacketHeader **packet,
        FMOD::ProfileRingBuffer::LockedBuffer *locked)
{
  FMOD_RESULT_0 result; // eax
  char *mPtr1; // rax
  char *v7; // rcx
  int v8; // ebx
  int v9; // edx
  int mLen1; // esi
  int v11; // edx
  char *mPtr2; // rax
  int mLen2; // edx

  result = FMOD::ProfileRingBuffer::startRead(&this->mRecvBuffer, 0, locked);
  if ( result == FMOD_RESULT::FMOD_ERR_NET_WOULD_BLOCK_0 )
    goto LABEL_18;
  if ( result )
    return result;
  if ( this->mDead )
    goto LABEL_18;
  mPtr1 = locked->mPtr1;
  if ( ((unsigned __int8)mPtr1 & 3) != 0 )
  {
    v7 = mPtr1 + 1;
    v8 = 0;
    do
    {
      mPtr1 = v7;
      ++v8;
      ++v7;
    }
    while ( ((unsigned __int8)mPtr1 & 3) != 0 );
    v9 = v8 + 3;
  }
  else
  {
    v9 = 3;
    v8 = 0;
  }
  mLen1 = locked->mLen1;
  if ( v9 < mLen1 )
  {
    do
    {
      if ( *(_DWORD *)mPtr1 != -1 )
        break;
      v8 += 4;
      mPtr1 += 4;
    }
    while ( v8 + 3 < mLen1 );
  }
  result = FMOD::ProfileRingBuffer::advanceRead(&this->mRecvBuffer, v8);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v11 = locked->mLen1;
    if ( v11 <= v8 )
    {
      mPtr2 = locked->mPtr2;
      mLen2 = locked->mLen2;
    }
    else
    {
      mPtr2 = &locked->mPtr1[v8];
      mLen2 = v11 - v8;
    }
    if ( mLen2 > 0 )
    {
      *packet = (FMOD::ProfilePacketHeader *)mPtr2;
      return FMOD_RESULT::FMOD_OK_0;
    }
LABEL_18:
    *packet = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x225aeb0 | Name: _ZN4FMOD13ProfileClient19finishReceivePacketEPNS_19ProfilePacketHeaderEPNS_17ProfileRingBuffer12LockedBufferE
FMOD_RESULT_0 __fastcall FMOD::ProfileClient::finishReceivePacket(
        FMOD::ProfileClient *const this,
        FMOD::ProfilePacketHeader *packet,
        FMOD::ProfileRingBuffer::LockedBuffer *locked)
{
  return FMOD::ProfileRingBuffer::advanceRead(&this->mRecvBuffer, packet->size);
}


// Address: 0x225aec0 | Name: _ZN4FMOD13ProfileClient11writePacketEPNS_19ProfilePacketHeaderE
FMOD_RESULT_0 __fastcall FMOD::ProfileClient::writePacket(
        FMOD::ProfileClient *const this,
        FMOD::ProfilePacketHeader *packet)
{
  FMOD_RESULT_0 v3; // ebx
  signed int size; // ebp
  FMOD_RESULT_0 Ms; // eax
  unsigned int v7; // esi
  unsigned __int8 type; // cl
  FMOD::ProfileDataType *mDataType; // rax
  __int64 v10; // rdx
  char *v11; // r13
  signed int v12; // eax
  unsigned int currentTime; // [rsp+Ch] [rbp-4Ch] BYREF
  FMOD::ProfileRingBuffer::LockedBuffer locked; // [rsp+10h] [rbp-48h] BYREF

  v3 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  size = packet->size;
  if ( packet->size > 0x6400000 )
    return v3;
  memset(&locked, 0, sizeof(locked));
  Ms = FMOD::ProfileRingBuffer::startWrite(&this->mSendBuffer, size, 0, &locked);
  if ( Ms )
    goto LABEL_7;
  LOBYTE(v3) = 0;
  if ( this->mDead )
    goto LABEL_5;
  Ms = FMOD_OS_Time_GetMs(&currentTime);
  if ( Ms )
  {
LABEL_7:
    v3 = Ms;
  }
  else
  {
    v7 = currentTime;
    type = packet->type;
    mDataType = this->mDataType;
    v10 = 0;
    packet->timestamp = currentTime;
    while ( mDataType->type != type || mDataType->subType != packet->subtype )
    {
      v10 = (unsigned int)(v10 + 1);
      ++mDataType;
      if ( (_DWORD)v10 == 32 )
        goto LABEL_16;
    }
    v11 = (char *)this + 16 * v10;
    v12 = *((_DWORD *)v11 + 184);
    *((_DWORD *)v11 + 183) = v7;
    if ( size >= v12 )
      v12 = size;
    *((_DWORD *)v11 + 184) = v12;
LABEL_16:
    memcpy_0(locked.mPtr1, packet, locked.mLen1);
    if ( locked.mLen2 )
      memcpy_0(locked.mPtr2, (char *)packet + locked.mLen1, locked.mLen2);
    v3 = FMOD::ProfileRingBuffer::advanceWrite(&this->mSendBuffer, size);
    if ( v3 == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( locked.mLock )
        FMOD_OS_CriticalSection_Leave(locked.mLock);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
LABEL_5:
  if ( !locked.mLock )
    return v3;
  FMOD_OS_CriticalSection_Leave(locked.mLock);
  return v3;
}


// Address: 0x225b040 | Name: _ZN4FMOD13ProfileClient14sendThreadLoopEv
FMOD_RESULT_0 __fastcall FMOD::ProfileClient::sendThreadLoop(FMOD::ProfileClient *const this)
{
  FMOD::ProfileRingBuffer *p_mSendBuffer; // rbp
  FMOD_RESULT_0 started; // eax
  int mLen1; // r15d
  FMOD_OS_CRITICALSECTION *mLock; // rdi
  unsigned int mLen2; // r9d
  FMOD_RESULT_0 v7; // ebx
  int toSend2; // [rsp+Ch] [rbp-6Ch]
  unsigned int t1; // [rsp+18h] [rbp-60h] BYREF
  unsigned int bytesWritten; // [rsp+1Ch] [rbp-5Ch] BYREF
  FMOD::ProfileRingBuffer::LockedBuffer locked; // [rsp+20h] [rbp-58h] BYREF

  p_mSendBuffer = &this->mSendBuffer;
  while ( 1 )
  {
    memset(&locked, 0, sizeof(locked));
    started = FMOD::ProfileRingBuffer::startRead(p_mSendBuffer, 1, &locked);
    if ( started )
    {
LABEL_18:
      v7 = started;
      goto LABEL_19;
    }
    if ( this->mDead )
      break;
    mLen1 = 0x10000;
    FMOD_OS_Time_GetUs(&t1);
    if ( locked.mLen1 <= 0x10000 )
      mLen1 = locked.mLen1;
    started = FMOD_OS_Net_Write(this->mSocket, locked.mPtr1, mLen1, &bytesWritten);
    if ( started )
      goto LABEL_18;
    if ( mLen1 != bytesWritten )
      goto LABEL_22;
    if ( locked.mLen2 && mLen1 != 0x10000 )
    {
      mLen2 = 0x10000 - mLen1;
      if ( 0x10000 - mLen1 > locked.mLen2 )
        mLen2 = locked.mLen2;
      toSend2 = mLen2;
      started = FMOD_OS_Net_Write(this->mSocket, locked.mPtr2, mLen2, &bytesWritten);
      if ( started )
        goto LABEL_18;
      if ( toSend2 != bytesWritten )
      {
LABEL_22:
        v7 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
        goto LABEL_19;
      }
      mLen1 += toSend2;
      started = FMOD::ProfileRingBuffer::advanceRead(p_mSendBuffer, mLen1);
      if ( started )
        goto LABEL_18;
    }
    else
    {
      started = FMOD::ProfileRingBuffer::advanceRead(p_mSendBuffer, mLen1);
      if ( started )
        goto LABEL_18;
    }
    mLock = locked.mLock;
    this->mSendCount += mLen1;
    if ( mLock )
      FMOD_OS_CriticalSection_Leave(mLock);
  }
  v7 = FMOD_RESULT::FMOD_OK_0;
LABEL_19:
  if ( locked.mLock )
    FMOD_OS_CriticalSection_Leave(locked.mLock);
  return v7;
}


// Address: 0x225b1e0 | Name: _ZN4FMOD13ProfileClient15requestDataTypeEhhj
FMOD_RESULT_0 __fastcall FMOD::ProfileClient::requestDataType(
        FMOD::ProfileClient *const this,
        unsigned __int8 type,
        unsigned __int8 subtype,
        unsigned int updatetime)
{
  FMOD_OS_CRITICALSECTION *mLock; // r14
  __int64 v8; // rax
  FMOD_RESULT_0 v9; // ebx
  FMOD::ProfileDataType *mDataType; // rax
  __int64 v12; // r8
  char *v13; // r8
  FMOD::Profile *mProfile; // rdi

  mLock = this->mLock;
  FMOD_OS_CriticalSection_Enter(mLock);
  v8 = 0;
  if ( !this->mDead )
  {
    while ( this->mDataType[v8].type != type || this->mDataType[v8].subType != subtype )
    {
      if ( ++v8 == 32 )
      {
        mDataType = this->mDataType;
        v12 = 0;
        while ( mDataType->type != 0xFF )
        {
          v12 = (unsigned int)(v12 + 1);
          ++mDataType;
          if ( (_DWORD)v12 == 32 )
          {
            v9 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
            goto LABEL_7;
          }
        }
        v13 = (char *)this + 16 * v12;
        v13[724] = type;
        v13[725] = subtype;
        *((_QWORD *)v13 + 91) = updatetime;
        mProfile = this->mProfile;
        if ( !mProfile )
          break;
        v9 = (*((unsigned int (__fastcall **)(FMOD::Profile *, FMOD::ProfileClient *const, _QWORD, _QWORD))mProfile->_vptr_ProfileInterface
              + 7))(
               mProfile,
               this,
               type,
               subtype);
        goto LABEL_7;
      }
    }
  }
  v9 = FMOD_RESULT::FMOD_OK_0;
LABEL_7:
  FMOD_OS_CriticalSection_Leave(mLock);
  return v9;
}


// Address: 0x225b2e0 | Name: _ZN4FMOD13ProfileClient4initEPvPNS_7ProfileE
FMOD_RESULT_0 __fastcall FMOD::ProfileClient::init(
        FMOD::ProfileClient *const this,
        void *socket,
        FMOD::Profile *profile)
{
  FMOD::ProfileRingBuffer *p_mSendBuffer; // rdi
  FMOD_RESULT_0 v5; // ebp

  p_mSendBuffer = &this->mSendBuffer;
  *(_QWORD *)&p_mSendBuffer[-17].mReadCount = socket;
  *(_QWORD *)&p_mSendBuffer[-17].mLength = profile;
  v5 = FMOD::ProfileRingBuffer::init(p_mSendBuffer, 0x20000, 1);
  if ( v5 == FMOD_RESULT::FMOD_OK_0 )
  {
    v5 = FMOD::ProfileRingBuffer::init(&this->mRecvBuffer, 0x20000, 4);
    if ( v5 == FMOD_RESULT::FMOD_OK_0 )
    {
      v5 = FMOD_OS_CriticalSection_Create(&this->mLock, 0);
      if ( v5 == FMOD_RESULT::FMOD_OK_0 )
      {
        v5 = FMOD::ProfileClient::requestDataType(this, 0, 0, 0xFFFFFFFF);
        if ( v5 == FMOD_RESULT::FMOD_OK_0 )
        {
          FMOD::Thread::initThread(
            &this->mRecvThread,
            "FMOD profiler thread (recv)",
            FMOD::ProfileClient::recvThreadLoopFunction,
            this,
            FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_GENERIC,
            FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_NORMAL,
            0x20000,
            0,
            0,
            0,
            0);
          FMOD::Thread::initThread(
            &this->mSendThread,
            "FMOD profiler thread (send)",
            FMOD::ProfileClient::sendThreadLoopFunction,
            this,
            FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_GENERIC,
            FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_NORMAL,
            0x20000,
            0,
            0,
            0,
            0);
        }
      }
    }
  }
  return v5;
}


// Address: 0x225b400 | Name: _ZN4FMOD13ProfileClient14recvThreadLoopEv
FMOD_RESULT_0 __fastcall FMOD::ProfileClient::recvThreadLoop(FMOD::ProfileClient *const this)
{
  FMOD::ProfileRingBuffer *p_mRecvBuffer; // r14
  void *mSocket; // rdi
  FMOD_RESULT_0 v4; // eax
  unsigned int size; // esi
  FMOD::Profile *mProfile; // rdi
  FMOD::ProfileModule_0 *ModuleForAsyncRead; // rax
  FMOD::ProfileModule_0 *v8; // r15
  FMOD_RESULT_0 v9; // eax
  __int64 v10; // rcx
  __int64 v11; // r8
  char *mPtr1; // rdi
  bool v13; // zf
  __int64 v14; // r9
  FMOD_OS_CRITICALSECTION *mLock; // rdi
  FMOD_RESULT_0 v16; // ebx
  unsigned int v18; // [rsp+4h] [rbp-84h]
  unsigned int bytesRead; // [rsp+14h] [rbp-74h] BYREF
  char *dest; // [rsp+18h] [rbp-70h] BYREF
  FMOD::ProfilePacketHeader header; // [rsp+20h] [rbp-68h] BYREF
  FMOD::ProfileRingBuffer::LockedBuffer locked; // [rsp+30h] [rbp-58h] BYREF

  p_mRecvBuffer = &this->mRecvBuffer;
  while ( 1 )
  {
    mSocket = this->mSocket;
    *(_QWORD *)&header.size = 0;
    *(_DWORD *)&header.type = 0;
    v4 = FMOD_OS_Net_Read(mSocket, (char *)&header, 0xCu, &bytesRead);
    if ( v4 )
      return v4;
    if ( bytesRead != 12 )
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    size = header.size;
    if ( header.size - 12 > 0x63FFFF4 || header.type > 0xAu || header.flags )
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    mProfile = this->mProfile;
    if ( mProfile )
    {
      ModuleForAsyncRead = FMOD::Profile::getModuleForAsyncRead(mProfile, &header);
      v8 = ModuleForAsyncRead;
      memset(&locked, 0, sizeof(locked));
      dest = 0;
      if ( ModuleForAsyncRead )
      {
        v9 = (*((unsigned int (__fastcall **)(FMOD::ProfileModule_0 *, FMOD::ProfilePacketHeader *, char **))ModuleForAsyncRead->_vptr_ProfileModule
              + 6))(
               ModuleForAsyncRead,
               &header,
               &dest);
        if ( v9 )
          goto LABEL_19;
        mPtr1 = dest;
        goto LABEL_11;
      }
      size = header.size;
    }
    else
    {
      memset(&locked, 0, sizeof(locked));
      dest = 0;
    }
    v9 = FMOD::ProfileRingBuffer::startWrite(p_mRecvBuffer, (size + 3) & 0xFFFFFFFC, 1, &locked);
    if ( v9 )
      goto LABEL_19;
    if ( this->mDead )
      break;
    v8 = 0;
    mPtr1 = locked.mPtr1;
    dest = locked.mPtr1;
    if ( locked.mPtr2 )
    {
      v8 = 0;
      memset(locked.mPtr1, 255, locked.mLen1);
      mPtr1 = locked.mPtr2;
      dest = locked.mPtr2;
    }
LABEL_11:
    *(_QWORD *)mPtr1 = *(_QWORD *)&header.size;
    v13 = header.size == 12;
    v14 = header.size - 12;
    *((_DWORD *)mPtr1 + 2) = *(_DWORD *)&header.type;
    if ( !v13 )
    {
      v18 = v14;
      v9 = FMOD_OS_Net_Read(this->mSocket, dest + 12, v14, &bytesRead);
      if ( v9 )
        goto LABEL_19;
      v14 = v18;
      if ( bytesRead != v18 )
      {
        v16 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
        goto LABEL_20;
      }
    }
    if ( dest[8] )
    {
      if ( !v8 )
      {
LABEL_14:
        v9 = FMOD::ProfileRingBuffer::advanceWrite(p_mRecvBuffer, locked.mLen2 + locked.mLen1);
        if ( v9 )
          goto LABEL_19;
        goto LABEL_15;
      }
      v9 = (*((unsigned int (__fastcall **)(FMOD::ProfileModule_0 *, char *, FMOD::ProfileClient *const, __int64, __int64, __int64))v8->_vptr_ProfileModule
            + 7))(
             v8,
             dest,
             this,
             v10,
             v11,
             v14);
      if ( v9 )
        goto LABEL_19;
    }
    else
    {
      if ( dest[9] )
        goto LABEL_14;
      v9 = FMOD::ProfileClient::requestDataType(this, dest[12], dest[13], *(_DWORD *)(dest + 14));
      if ( v9 )
      {
LABEL_19:
        v16 = v9;
        goto LABEL_20;
      }
    }
LABEL_15:
    mLock = locked.mLock;
    this->mRecvCount += header.size;
    if ( mLock )
      FMOD_OS_CriticalSection_Leave(mLock);
  }
  v16 = FMOD_RESULT::FMOD_OK_0;
LABEL_20:
  if ( locked.mLock )
    FMOD_OS_CriticalSection_Leave(locked.mLock);
  return v16;
}


// Address: 0x225b6e0 | Name: _ZN4FMOD13ProfileClient8markDeadEv
FMOD_RESULT_0 __fastcall FMOD::ProfileClient::markDead(FMOD::ProfileClient *const this)
{
  FMOD_OS_CRITICALSECTION *mLock; // r13
  FMOD::ProfileDataType *mDataType; // rbx
  FMOD::ProfileDataType *v4; // r12
  __int64 type; // rdx
  FMOD::Profile *mProfile; // rdi
  FMOD_RESULT_0 v7; // eax
  void *mSocket; // rdi
  FMOD_RESULT_0 v9; // ebx

  mLock = this->mLock;
  FMOD_OS_CriticalSection_Enter(mLock);
  if ( this->mDead )
  {
    v9 = FMOD_RESULT::FMOD_OK_0;
LABEL_11:
    FMOD_OS_CriticalSection_Leave(mLock);
  }
  else
  {
    mDataType = this->mDataType;
    v4 = &this->mDataType[32];
    do
    {
      type = mDataType->type;
      if ( (_BYTE)type != 0xFF )
      {
        mProfile = this->mProfile;
        if ( mProfile )
        {
          v7 = (*((unsigned int (__fastcall **)(FMOD::Profile *, FMOD::ProfileClient *const, __int64, _QWORD))mProfile->_vptr_ProfileInterface
                + 8))(
                 mProfile,
                 this,
                 type,
                 mDataType->subType);
          if ( v7 )
          {
            v9 = v7;
            goto LABEL_11;
          }
        }
      }
      ++mDataType;
    }
    while ( mDataType != v4 );
    mSocket = this->mSocket;
    this->mDead = 1;
    v9 = FMOD_OS_Net_Close(mSocket);
    if ( v9 )
      goto LABEL_11;
    FMOD_OS_CriticalSection_Leave(mLock);
    v9 = FMOD::ProfileRingBuffer::wakeForShutdown(&this->mSendBuffer);
    if ( v9 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD::ProfileRingBuffer::wakeForShutdown(&this->mRecvBuffer);
  }
  return v9;
}


// Address: 0x225b7c0 | Name: _ZN4FMOD13ProfileClient7releaseEv
FMOD_RESULT_0 __fastcall FMOD::ProfileClient::release(FMOD::ProfileClient *const this)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::ProfileClient::markDead(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD::Thread::closeThread(&this->mRecvThread);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::Thread::closeThread(&this->mSendThread);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD_OS_CriticalSection_Free(this->mLock, 0);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = FMOD::ProfileRingBuffer::release(&this->mSendBuffer);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = FMOD::ProfileRingBuffer::release(&this->mRecvBuffer);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              FMOD::MemPool::free(
                off_286F358->gSystemMemPool,
                this,
                "../../../core_api/src/fmod_profile_client.cpp",
                454);
              return FMOD_RESULT::FMOD_OK_0;
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x225b860 | Name: _ZN4FMOD13ProfileClient22recvThreadLoopFunctionEPv
void __fastcall FMOD::ProfileClient::recvThreadLoopFunction(void *userdata)
{
  if ( FMOD::ProfileClient::recvThreadLoop((FMOD::ProfileClient *const)userdata) )
    FMOD::ProfileClient::markDead((FMOD::ProfileClient *const)userdata);
}


// Address: 0x225b880 | Name: _ZN4FMOD13ProfileClient22sendThreadLoopFunctionEPv
void __fastcall FMOD::ProfileClient::sendThreadLoopFunction(void *userdata)
{
  if ( FMOD::ProfileClient::sendThreadLoop((FMOD::ProfileClient *const)userdata) )
    FMOD::ProfileClient::markDead((FMOD::ProfileClient *const)userdata);
}


// Address: 0x225b8a0 | Name: _ZNK4FMOD13ProfileClient15isDataRequestedERKNS_10PacketInfoE
bool __fastcall FMOD::ProfileClient::isDataRequested(
        const FMOD::ProfileClient *const this,
        const FMOD::PacketInfo *const info)
{
  bool result; // al
  __int64 v3; // rdx
  unsigned __int8 subType; // r8

  result = this->mDead;
  if ( result )
    return 0;
  v3 = 0;
  while ( 1 )
  {
    if ( this->mDataType[v3].type == info->type )
    {
      subType = this->mDataType[v3].subType;
      if ( subType == info->subType || subType == 0xFF )
        break;
    }
    if ( ++v3 == 32 )
      return result;
  }
  return 1;
}


// Address: 0x225b900 | Name: _ZNK4FMOD13ProfileClient14isReadyForDataERKNS_10PacketInfoE
bool __fastcall FMOD::ProfileClient::isReadyForData(
        const FMOD::ProfileClient *const this,
        const FMOD::PacketInfo *const info)
{
  FMOD::ProfileDataType *mDataType; // rax
  __int64 v4; // rdx
  unsigned int lastDataTime; // ecx
  int updateTime; // r10d
  bool v7; // r9
  bool v8; // r8
  unsigned __int8 subType; // cl
  int maxPacketSize; // ebx
  unsigned int currentTime[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  if ( this->mDead )
    return 0;
  FMOD_OS_Time_GetMs(currentTime);
  mDataType = this->mDataType;
  v4 = 0;
  while ( 1 )
  {
    v8 = 0;
    if ( mDataType->type == info->type )
    {
      subType = mDataType->subType;
      v8 = 1;
      if ( subType != info->subType )
        v8 = subType == 0xFF;
    }
    lastDataTime = mDataType->lastDataTime;
    updateTime = mDataType->updateTime;
    v7 = 1;
    if ( lastDataTime )
      v7 = (int)(currentTime[0] - lastDataTime) > updateTime;
    if ( v8 && (v7 || updateTime == -1) )
      break;
    v4 = (unsigned int)(v4 + 1);
    ++mDataType;
    if ( (_DWORD)v4 == 32 )
      return 0;
  }
  maxPacketSize = this->mDataType[v4].maxPacketSize;
  return FMOD::ProfileRingBuffer::getCapacity(&this->mSendBuffer) >= maxPacketSize;
}


