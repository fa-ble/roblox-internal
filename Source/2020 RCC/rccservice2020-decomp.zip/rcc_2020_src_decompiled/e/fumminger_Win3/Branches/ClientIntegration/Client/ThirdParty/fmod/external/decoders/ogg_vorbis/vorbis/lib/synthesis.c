// Address: 0x2277970 | Name: FMOD_vorbis_synthesis
int __fastcall FMOD_vorbis_synthesis(void *context, vorbis_block_0 *vb, ogg_packet *op)
{
  vorbis_dsp_state *vd; // rax
  __int64 v5; // r13
  ogg_int64_t time_bits; // r15
  __int64 v7; // r14
  int result; // eax
  ogg_int32_t v9; // eax
  ogg_int32_t v10; // eax
  __int64 W; // rax
  int v12; // eax
  int b_o_s; // edx
  int v14; // eax
  float **pcm; // rax
  __int64 v16; // rbx
  __int64 v17; // rax
  ogg_int32_t v18; // eax
  oggpack_buffer_0 *opb; // [rsp+0h] [rbp-48h]
  __int64 v20; // [rsp+8h] [rbp-40h]

  vd = vb->vd;
  v5 = *(_QWORD *)&vd->analysisp;
  time_bits = vd->time_bits;
  v7 = *(_QWORD *)(*(_QWORD *)&vd->analysisp + 32LL);
  result = FMOD_vorbis_block_ripcord(context, vb);
  if ( !result )
  {
    opb = &vb->opb;
    FMOD_oggpack_readinit((oggpack_buffer *)&vb->opb, op->packet, op->bytes);
    if ( FMOD_oggpack_read((oggpack_buffer *)&vb->opb, 1) )
    {
      return -135;
    }
    else
    {
      v9 = FMOD_oggpack_read((oggpack_buffer *)opb, *(_DWORD *)(time_bits + 24));
      if ( v9 != -1 )
      {
        vb->mode = v9;
        v20 = v7 + 8LL * v9;
        v10 = **(_DWORD **)(v20 + 32);
        vb->W = v10;
        if ( !v10 )
        {
          vb->lW = 0;
          vb->nW = 0;
          W = 0;
          goto LABEL_6;
        }
        vb->lW = FMOD_oggpack_read((oggpack_buffer *)opb, 1);
        v18 = FMOD_oggpack_read((oggpack_buffer *)opb, 1);
        vb->nW = v18;
        if ( v18 != -1 )
        {
          W = vb->W;
LABEL_6:
          v12 = *(_DWORD *)(v7 + 4 * W);
          vb->granulepos = op->e_o_s;
          vb->sequence = op->granulepos;
          b_o_s = op->b_o_s;
          vb->pcmend = v12;
          v14 = *(_DWORD *)(v5 + 4);
          vb->eofflag = b_o_s;
          pcm = (float **)FMOD_vorbis_block_alloc(context, vb, 8 * v14);
          vb->pcm = pcm;
          if ( pcm )
          {
            v16 = 0;
            if ( *(int *)(v5 + 4) <= 0 )
            {
LABEL_12:
              v17 = *(int *)(*(_QWORD *)(v20 + 32) + 12LL);
              return ((int (__fastcall *)(void *, vorbis_block_0 *, _QWORD))FMOD_mapping_P[*(int *)(v7 + 4 * v17 + 544)]->inverse)(
                       context,
                       vb,
                       *(_QWORD *)(v7 + 8 * v17 + 800));
            }
            while ( 1 )
            {
              pcm[v16] = (float *)FMOD_vorbis_block_alloc(context, vb, 4 * vb->pcmend);
              pcm = vb->pcm;
              if ( !vb->pcm[v16] )
                break;
              if ( *(_DWORD *)(v5 + 4) <= (int)++v16 )
                goto LABEL_12;
            }
          }
          return -139;
        }
      }
      return -136;
    }
  }
  return result;
}


// Address: 0x2277b50 | Name: FMOD_vorbis_synthesis_trackonly
int __fastcall FMOD_vorbis_synthesis_trackonly(void *context, vorbis_block_0 *vb, ogg_packet *op)
{
  vorbis_dsp_state *vd; // rax
  ogg_int64_t time_bits; // r13
  __int64 v6; // r14
  int v7; // ebp
  ogg_int32_t v9; // eax
  ogg_int32_t v10; // eax
  int b_o_s; // eax
  ogg_int32_t v12; // eax

  vd = vb->vd;
  time_bits = vd->time_bits;
  v6 = *(_QWORD *)(*(_QWORD *)&vd->analysisp + 32LL);
  v7 = FMOD_vorbis_block_ripcord(context, vb);
  if ( !v7 )
  {
    FMOD_oggpack_readinit((oggpack_buffer *)&vb->opb, op->packet, op->bytes);
    v7 = FMOD_oggpack_read((oggpack_buffer *)&vb->opb, 1);
    if ( v7 )
      return -135;
    v9 = FMOD_oggpack_read((oggpack_buffer *)&vb->opb, *(_DWORD *)(time_bits + 24));
    if ( v9 != -1 )
    {
      vb->mode = v9;
      v10 = **(_DWORD **)(v6 + 8LL * v9 + 32);
      vb->W = v10;
      if ( !v10 )
      {
        vb->lW = 0;
        vb->nW = 0;
LABEL_7:
        vb->granulepos = op->e_o_s;
        vb->sequence = op->granulepos;
        b_o_s = op->b_o_s;
        vb->pcmend = 0;
        vb->pcm = 0;
        vb->eofflag = b_o_s;
        return v7;
      }
      vb->lW = FMOD_oggpack_read((oggpack_buffer *)&vb->opb, 1);
      v12 = FMOD_oggpack_read((oggpack_buffer *)&vb->opb, 1);
      vb->nW = v12;
      if ( v12 != -1 )
        goto LABEL_7;
    }
    return -136;
  }
  return v7;
}


// Address: 0x2277c60 | Name: FMOD_vorbis_packet_blocksize
ogg_int32_t __fastcall FMOD_vorbis_packet_blocksize(vorbis_info_0 *vi, ogg_packet *op)
{
  _DWORD *codec_setup; // rbp
  int v3; // eax
  int i; // esi
  ogg_int32_t v5; // eax
  oggpack_buffer_0 opb; // [rsp+0h] [rbp-38h] BYREF

  codec_setup = vi->codec_setup;
  FMOD_oggpack_readinit((oggpack_buffer *)&opb, op->packet, op->bytes);
  if ( FMOD_oggpack_read((oggpack_buffer *)&opb, 1) )
    return -135;
  v3 = codec_setup[2];
  for ( i = 0; v3 > 1; ++i )
    v3 >>= 1;
  v5 = FMOD_oggpack_read((oggpack_buffer *)&opb, i);
  if ( v5 == -1 )
    return -136;
  else
    return codec_setup[**(int **)&codec_setup[2 * v5 + 8]];
}


// Address: 0x2277ce0 | Name: FMOD_vorbis_synthesis_halfrate
int __fastcall FMOD_vorbis_synthesis_halfrate(vorbis_info_0 *vi, int flag)
{
  int *codec_setup; // rax

  codec_setup = (int *)vi->codec_setup;
  if ( *codec_setup <= 64 && flag )
    return -1;
  codec_setup[1226] = flag != 0;
  return 0;
}


// Address: 0x2277d10 | Name: FMOD_vorbis_synthesis_halfrate_p
int __fastcall FMOD_vorbis_synthesis_halfrate_p(vorbis_info_0 *vi)
{
  return *((_DWORD *)vi->codec_setup + 1226);
}


