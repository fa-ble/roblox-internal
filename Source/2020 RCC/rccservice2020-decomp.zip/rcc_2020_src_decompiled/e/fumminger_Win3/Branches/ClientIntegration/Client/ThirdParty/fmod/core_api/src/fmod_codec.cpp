// Address: 0x21e6ac0 | Name: Roblox_SetCodecParsingAnomaly
void __fastcall Roblox_SetCodecParsingAnomaly(void *context, int value)
{
  if ( context )
    *((_DWORD *)context + 88) = value;
}


// Address: 0x21e6ad0 | Name: Roblox_ParsingChecksDisabled
int __fastcall Roblox_ParsingChecksDisabled(void *context)
{
  if ( context )
    return *((_DWORD *)context + 89);
  else
    return 0;
}


// Address: 0x21e6af0 | Name: Roblox_DisableParsingChecks
void __fastcall Roblox_DisableParsingChecks(void *context)
{
  if ( context )
    ++*((_DWORD *)context + 89);
}


// Address: 0x21e6b00 | Name: Roblox_ReenableParsingChecks
void __fastcall Roblox_ReenableParsingChecks(void *context)
{
  if ( context )
    --*((_DWORD *)context + 89);
}


// Address: 0x21e6b10 | Name: _ZN4FMOD5Codec7releaseEb
FMOD_RESULT_0 __fastcall FMOD::Codec::release(FMOD::Codec *const this, bool freethis)
{
  FMOD::Codec *mDecoder; // rdi
  void (__fastcall *cleanupcontext)(_QWORD, _QWORD); // rax
  FMOD_RESULT_0 result; // eax
  FMOD_CODEC_CLOSE_CALLBACK_0 close; // rax
  FMOD::File *mFile; // rdi
  unsigned __int8 *mPCMBufferMemory; // rsi
  FMOD_CODEC_WAVEFORMAT *mWaveFormatMemory; // rsi
  void *mDecoderContextMemory; // rsi
  FMOD::Metadata *mMetadata; // rdi

  mDecoder = this->mDecoder;
  if ( !mDecoder )
    goto LABEL_9;
  if ( this->mFile == mDecoder->mFile )
    mDecoder->mFile = 0;
  cleanupcontext = (void (__fastcall *)(_QWORD, _QWORD))mDecoder->mDescription.cleanupcontext;
  if ( cleanupcontext && (mDecoder->mFlags & 0x200) != 0 )
  {
    cleanupcontext(mDecoder, 0);
    mDecoder = this->mDecoder;
    mDecoder->mFlags &= ~0x200u;
  }
  result = FMOD::Codec::release(mDecoder, 1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    this->mDecoder = 0;
LABEL_9:
    close = this->mDescription.close;
    if ( close )
      close(this);
    mFile = this->mFile;
    if ( mFile )
    {
      FMOD::File::close(mFile);
      FMOD::MemPool::free(off_286F358->gSystemMemPool, this->mFile, "../../../core_api/src/fmod_codec.cpp", 101);
      this->mFile = 0;
    }
    mPCMBufferMemory = this->mPCMBufferMemory;
    if ( mPCMBufferMemory )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, mPCMBufferMemory, "../../../core_api/src/fmod_codec.cpp", 109);
      this->mPCMBufferMemory = 0;
      this->mPCMBuffer = 0;
    }
    mWaveFormatMemory = this->mWaveFormatMemory;
    this->mPCMBufferLength = 0;
    if ( mWaveFormatMemory )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, mWaveFormatMemory, "../../../core_api/src/fmod_codec.cpp", 116);
      this->mWaveFormatMemory = 0;
    }
    mDecoderContextMemory = this->mDecoderContextMemory;
    if ( mDecoderContextMemory )
    {
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        mDecoderContextMemory,
        "../../../core_api/src/fmod_codec.cpp",
        122);
      this->mDecoderContextMemory = 0;
    }
    mMetadata = this->mMetadata;
    this->mDecoderContext = 0;
    if ( mMetadata )
    {
      FMOD::Metadata::release(mMetadata);
      this->mMetadata = 0;
    }
    result = FMOD_RESULT::FMOD_OK_0;
    if ( freethis )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_codec.cpp", 137);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21e6d20 | Name: _ZN4FMOD5Codec19getMetadataFromFileEv
FMOD_RESULT_0 __fastcall FMOD::Codec::getMetadataFromFile(FMOD::Codec *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD::File *mFile; // rdi
  FMOD::Metadata *mMetadata; // rdi
  FMOD::Metadata *v5; // rax
  FMOD::Metadata *filemetadata; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD_RESULT::FMOD_OK_0;
  mFile = this->mFile;
  if ( mFile )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::File *, FMOD::Metadata **))mFile->_vptr_File + 2))(
               mFile,
               &filemetadata);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mMetadata = this->mMetadata;
      if ( !mMetadata )
      {
        v5 = (FMOD::Metadata *)FMOD::MemPool::alloc(
                                 off_286F358->gSystemMemPool,
                                 72,
                                 "../../../core_api/src/fmod_codec.cpp",
                                 293,
                                 0,
                                 0);
        if ( !v5 )
        {
          this->mMetadata = 0;
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        }
        v5->mList.mNodePrev = &v5->mList;
        v5->mList.mNodeNext = &v5->mList;
        mMetadata = v5;
        v5->mList.mNodeData = 0;
        v5->mList.mType = FMOD_TAGTYPE::FMOD_TAGTYPE_UNKNOWN;
        v5->mList.mDataType = FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_BINARY;
        v5->mList.mName = 0;
        v5->mList.mData[1] = 0;
        v5->mList.mData[0] = 0;
        v5->mList.mDataLen = 0;
        v5->mList.mUpdated = 1;
        v5->mList.mUnique = 0;
        v5->mList.mCurrentBuffer = 0;
        this->mMetadata = v5;
      }
      return FMOD::Metadata::add(mMetadata, filemetadata);
    }
  }
  return result;
}


// Address: 0x21e6e10 | Name: _ZN4FMOD5Codec4readEPvjPj
FMOD_RESULT_0 __fastcall FMOD::Codec::read(
        FMOD::Codec *const this,
        void *buffer,
        unsigned int samples_in,
        unsigned int *samples_out)
{
  __int64 mSubSoundIndex; // rsi
  int v9; // ebp
  int v10; // ebp
  unsigned int v11; // r15d
  char v12; // r13
  unsigned int v13; // eax
  unsigned int v14; // r12d
  unsigned int v15; // r15d
  unsigned int v16; // r9d
  char *v17; // rsi
  FMOD_RESULT_1 v18; // eax
  unsigned int v19; // edx
  unsigned __int8 *mPCMBuffer; // rsi
  unsigned int mPCMBufferLength; // edi
  unsigned int mPCMBufferOffset; // eax
  unsigned int mPCMBufferFilled; // edx
  unsigned int v24; // ecx
  unsigned int v25; // eax
  FMOD_RESULT_0 v26; // [rsp+0h] [rbp-A8h]
  unsigned int toread; // [rsp+4h] [rbp-A4h]
  unsigned int toreada; // [rsp+4h] [rbp-A4h]
  unsigned int *p_mPCMBufferFilled; // [rsp+18h] [rbp-90h]
  unsigned int read; // [rsp+2Ch] [rbp-7Ch] BYREF
  FMOD_CODEC_WAVEFORMAT wf; // [rsp+30h] [rbp-78h] BYREF

  mSubSoundIndex = (unsigned int)this->mSubSoundIndex;
  memset(&wf, 0, sizeof(wf));
  v26 = this->mDescription.getwaveformat(this, mSubSoundIndex, &wf);
  if ( v26 )
    return v26;
  switch ( wf.format )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      v9 = 2;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      v9 = 3;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      v9 = 4;
      break;
    default:
      v9 = 1;
      break;
  }
  v10 = wf.channels * v9;
  v11 = 0;
  if ( !samples_in )
    goto LABEL_40;
  v12 = 0;
  p_mPCMBufferFilled = &this->mPCMBufferFilled;
  v13 = samples_in;
  v14 = 0;
  v15 = v13;
  do
  {
    mPCMBuffer = this->mPCMBuffer;
    read = 0;
    mPCMBufferLength = this->mPCMBufferLength;
    if ( mPCMBuffer && (mPCMBufferLength > v15 || this->mPCMBufferFilled || !buffer) )
    {
      mPCMBufferOffset = this->mPCMBufferOffset;
      if ( mPCMBufferOffset )
      {
        mPCMBufferFilled = this->mPCMBufferFilled;
        if ( mPCMBufferOffset + v15 > mPCMBufferFilled )
        {
LABEL_24:
          v24 = mPCMBufferFilled - mPCMBufferOffset;
          v15 -= mPCMBufferFilled - mPCMBufferOffset;
          goto LABEL_25;
        }
      }
      else
      {
        v18 = this->mDescription.read(this, mPCMBuffer, mPCMBufferLength, p_mPCMBufferFilled);
        if ( v18 )
        {
          v11 = v14 + read;
          goto LABEL_39;
        }
        mPCMBufferOffset = this->mPCMBufferOffset;
        mPCMBufferFilled = this->mPCMBufferFilled;
        v12 = 1;
        if ( mPCMBufferOffset + v15 > mPCMBufferFilled )
          goto LABEL_24;
      }
      v24 = v15;
      v15 = 0;
LABEL_25:
      if ( buffer )
      {
        toreada = v24;
        memcpy_0((char *)buffer + v10 * v14, &this->mPCMBuffer[v10 * mPCMBufferOffset], v10 * v24);
        mPCMBufferOffset = this->mPCMBufferOffset;
        mPCMBufferFilled = this->mPCMBufferFilled;
        v24 = toreada;
      }
      v25 = v24 + mPCMBufferOffset;
      if ( mPCMBufferFilled <= v25 )
      {
        this->mPCMBufferOffset = 0;
        this->mPCMBufferFilled = 0;
      }
      else
      {
        this->mPCMBufferOffset = v25;
      }
      v14 += v24;
      read = v24;
      if ( !v24 )
      {
        v11 = v14;
        v18 = FMOD_RESULT::FMOD_OK_0;
        goto LABEL_39;
      }
      continue;
    }
    v16 = v15;
    if ( mPCMBufferLength )
      v16 = mPCMBufferLength * (v15 / mPCMBufferLength);
    if ( buffer )
      v17 = (char *)buffer + v10 * v14;
    else
      v17 = 0;
    toread = v16;
    v18 = this->mDescription.read(this, v17, v16, &read);
    v19 = read;
    if ( v18 == FMOD_RESULT::FMOD_OK_0 )
      v12 = 1;
    if ( toread < read )
    {
      read = toread;
      v19 = toread;
    }
    v14 += v19;
    v15 -= v19;
    this->mPCMBufferOffset = 0;
    this->mPCMBufferFilled = 0;
    if ( !v19 || v18 )
    {
      v11 = v14;
LABEL_39:
      v26 = v18;
      if ( !v12 )
        goto LABEL_40;
      goto LABEL_45;
    }
  }
  while ( v15 );
  v11 = v14;
  if ( !v12 )
    goto LABEL_40;
LABEL_45:
  FMOD::Codec::getMetadataFromFile(this);
LABEL_40:
  if ( samples_out )
    *samples_out = v11;
  return v26;
}


// Address: 0x21e7130 | Name: _ZN4FMOD5Codec9getLengthEPjj
FMOD_RESULT_0 __fastcall FMOD::Codec::getLength(
        FMOD::Codec *const this,
        unsigned int *length,
        FMOD_TIMEUNIT lengthtype)
{
  __int64 v3; // rcx
  FMOD_CODEC_GETLENGTH_CALLBACK_0 getlength; // rax
  FMOD_RESULT_0 result; // eax
  FMOD_CODEC_WAVEFORMAT wf; // [rsp+0h] [rbp-48h] BYREF

  if ( lengthtype == 8 )
  {
    memset(&wf, 0, sizeof(wf));
    result = this->mDescription.getwaveformat(this, this->mSubSoundIndex, &wf);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      *length = wf.lengthbytes;
  }
  else
  {
    getlength = this->mDescription.getlength;
    if ( getlength )
    {
      return ((FMOD_RESULT_0 (__fastcall *)(FMOD::Codec *const, unsigned int *, FMOD_TIMEUNIT, __int64, FMOD::Codec *const))getlength)(
               this,
               length,
               lengthtype,
               v3,
               this);
    }
    else
    {
      *length = 0;
      return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
    }
  }
  return result;
}


// Address: 0x21e71a0 | Name: _ZN4FMOD5Codec11setPositionEijj
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::Codec::setPosition(
        FMOD::Codec *const this,
        int subsound,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  __int64 v4; // r13
  unsigned int mSubSoundIndex; // ebp
  int numsubsounds; // edx
  FMOD_RESULT_0 result; // eax
  FMOD::Codec *mDecoder; // rdi
  unsigned int v11; // r14d
  FMOD_SOUND_FORMAT_0 v12; // r11d
  int v13; // r15d
  void (__fastcall *cleanupcontext)(_QWORD, _QWORD); // rax
  FMOD_CODEC_WAVEFORMAT *waveformat; // rax
  FMOD::Codec *v16; // rdi
  unsigned int (__fastcall *setupcontext)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  FMOD_TIMEUNIT timeunits; // eax
  __int64 v19; // rax
  unsigned __int64 v20; // rcx
  unsigned int v21; // eax
  unsigned int v22; // r13d
  unsigned __int64 v23; // rcx
  unsigned int v24; // [rsp+8h] [rbp-90h]
  FMOD_SOUND_FORMAT_0 format; // [rsp+Ch] [rbp-8Ch]
  FMOD_SOUND_FORMAT_0 formata; // [rsp+Ch] [rbp-8Ch]
  unsigned int out; // [rsp+1Ch] [rbp-7Ch] BYREF
  _BYTE v28[56]; // [rsp+20h] [rbp-78h] OVERLAPPED BYREF

  v4 = position;
  mSubSoundIndex = subsound;
  numsubsounds = this->numsubsounds;
  if ( this->numsubsounds )
  {
    result = FMOD_RESULT::FMOD_ERR_INVALID_POSITION_0;
    if ( numsubsounds <= subsound )
      return result;
  }
  result = FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  if ( !this->mDescription.setposition )
    return result;
  if ( subsound < 0 )
    mSubSoundIndex = this->mSubSoundIndex;
  if ( !numsubsounds )
    mSubSoundIndex = 0;
  memset(v28, 0, sizeof(v28));
  result = this->mDescription.getwaveformat(this, mSubSoundIndex, (FMOD_CODEC_WAVEFORMAT *)v28);
  if ( result )
    return result;
  mDecoder = this->mDecoder;
  v11 = *(_DWORD *)&v28[12];
  v12 = *(_DWORD *)&v28[8];
  v13 = *(_DWORD *)&v28[16];
  v24 = *(_DWORD *)&v28[28];
  if ( mDecoder && this->mSubSoundIndex != mSubSoundIndex )
  {
    cleanupcontext = (void (__fastcall *)(_QWORD, _QWORD))mDecoder->mDescription.cleanupcontext;
    if ( cleanupcontext && (mDecoder->mFlags & 0x200) != 0 )
    {
      formata = *(_DWORD *)&v28[8];
      cleanupcontext(mDecoder, 0);
      mDecoder = this->mDecoder;
      v12 = formata;
      mDecoder->mFlags &= ~0x200u;
    }
    waveformat = mDecoder->waveformat;
    waveformat->name = *(const char **)v28;
    *(_QWORD *)&waveformat->format = *(_QWORD *)&v28[8];
    *(_QWORD *)&waveformat->frequency = *(_QWORD *)&v28[16];
    *(_QWORD *)&waveformat->lengthpcm = *(_QWORD *)&v28[24];
    *(_QWORD *)&waveformat->loopstart = *(_QWORD *)&v28[32];
    *(_QWORD *)&waveformat->mode = *(_QWORD *)&v28[40];
    *(_QWORD *)&waveformat->channelorder = *(_QWORD *)&v28[48];
    v16 = this->mDecoder;
    setupcontext = (unsigned int (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v16->mDescription.setupcontext;
    if ( setupcontext )
    {
      format = v12;
      result = setupcontext(v16, v11, (unsigned int)v13, mSubSoundIndex, v16->mDecoderContext, this, 0);
      if ( result )
        return result;
      v12 = format;
      this->mDecoder->mFlags |= 0x200u;
    }
  }
  timeunits = this->mDescription.timeunits;
  if ( (timeunits & 2) != 0 )
  {
    if ( (postype & 4) != 0 )
    {
      postype = 2;
      if ( v11 )
      {
        switch ( v12 )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v20 = 8;
            goto LABEL_51;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v20 = 16;
            goto LABEL_51;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v20 = 24;
            goto LABEL_51;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v20 = 32;
LABEL_51:
            postype = 2;
            LODWORD(v4) = (unsigned int)(8 * (unsigned __int64)(unsigned int)v4 / v20) / v11;
            break;
          default:
            postype = 2;
            break;
        }
      }
      goto LABEL_32;
    }
    if ( (postype & 1) != 0 )
    {
      postype = 2;
      LODWORD(v4) = (int)(float)((float)((float)(int)v4 / 1000.0) * (float)v13);
      goto LABEL_32;
    }
  }
  else
  {
    if ( (timeunits & 4) != 0 )
    {
      if ( (postype & 2) != 0 )
      {
        switch ( v12 )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v19 = 8;
            goto LABEL_39;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v19 = 16;
            goto LABEL_39;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v19 = 24;
            goto LABEL_39;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v19 = 32;
LABEL_39:
            v4 = (unsigned __int64)(v19 * v4) >> 3;
            break;
          default:
            break;
        }
      }
      else
      {
        if ( (postype & 1) == 0 )
          goto LABEL_21;
        LODWORD(v19) = (int)(float)((float)((float)(int)v4 / 1000.0) * (float)v13);
        LODWORD(v4) = v19;
        switch ( v12 )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v4 = 8;
            v19 = (unsigned int)v19;
            goto LABEL_39;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v4 = 16;
            v19 = (unsigned int)v19;
            goto LABEL_39;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v4 = 24;
            v19 = (unsigned int)v19;
            goto LABEL_39;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v4 = 32;
            v19 = (unsigned int)v19;
            goto LABEL_39;
          default:
            break;
        }
      }
      LODWORD(v4) = v11 * v4;
      postype = 4;
      goto LABEL_32;
    }
    if ( (timeunits & 1) != 0 )
    {
      if ( (postype & 2) == 0 )
      {
        if ( (postype & 4) == 0 )
          goto LABEL_21;
        if ( v11 )
        {
          switch ( v12 )
          {
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
              v23 = 8;
              goto LABEL_67;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
              v23 = 16;
              goto LABEL_67;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
              v23 = 24;
              goto LABEL_67;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
              v23 = 32;
LABEL_67:
              LODWORD(v4) = (unsigned int)(8 * (unsigned __int64)(unsigned int)v4 / v23) / v11;
              break;
            default:
              break;
          }
        }
      }
      postype = 1;
      LODWORD(v4) = (int)(float)((float)((float)((float)(int)v4 / (float)v13) * 1000.0) + 0.5);
      goto LABEL_32;
    }
  }
LABEL_21:
  if ( (postype & timeunits) == 0 )
    return FMOD_RESULT::FMOD_ERR_FORMAT_0;
LABEL_32:
  if ( (_DWORD)v4 && postype == 2 && v24 && this->mPCMBuffer )
  {
    this->mPCMBufferOffset = 0;
    v21 = v24 * ((unsigned int)v4 / v24);
    v22 = (unsigned int)v4 % v24;
    result = this->mDescription.setposition(this, mSubSoundIndex, v21, 2);
    if ( (result & 0xFFFFFFEF) == 0 )
    {
      if ( !v22 )
        goto LABEL_35;
      while ( 1 )
      {
        out = 0;
        result = FMOD::Codec::read(this, 0, v22, &out);
        if ( (result & 0xFFFFFFEF) != 0 )
          break;
        if ( out )
        {
          v22 -= out;
          if ( v22 )
            continue;
        }
        goto LABEL_35;
      }
    }
  }
  else
  {
    this->mPCMBufferOffset = 0;
    result = this->mDescription.setposition(this, mSubSoundIndex, v4, postype);
    if ( (result & 0xFFFFFFEF) == 0 )
    {
LABEL_35:
      this->mSubSoundIndex = mSubSoundIndex;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21e7660 | Name: _ZN4FMOD5Codec11getPositionEPjj
FMOD_RESULT_0 __fastcall FMOD::Codec::getPosition(
        FMOD::Codec *const this,
        unsigned int *position,
        FMOD_TIMEUNIT postype)
{
  FMOD_CODEC_GETPOSITION_CALLBACK_0 getposition; // rcx
  FMOD_RESULT_0 result; // eax
  FMOD::File *mFile; // rdi

  if ( postype != 8 )
  {
    getposition = this->mDescription.getposition;
    if ( getposition )
      goto LABEL_3;
    return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  }
  mFile = this->mFile;
  if ( !mFile )
    *position = 0;
  result = FMOD::File::tell(mFile, position);
  postype = 8;
  if ( result )
  {
    *position = 0;
    return result;
  }
  getposition = this->mDescription.getposition;
  *position -= this->mSrcDataOffset;
  if ( !getposition )
    return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
LABEL_3:
  result = FMOD_RESULT::FMOD_ERR_FORMAT_0;
  if ( (postype & this->mDescription.timeunits) != 0 )
    return ((FMOD_RESULT_0 (__fastcall *)(FMOD::Codec *const, unsigned int *))getposition)(this, position);
  return result;
}


// Address: 0x21e7710 | Name: _ZN4FMOD5Codec8metaDataE12FMOD_TAGTYPEPKcPvj16FMOD_TAGDATATYPEb
FMOD_RESULT_0 __fastcall FMOD::Codec::metaData(
        FMOD::Codec *const this,
        FMOD_TAGTYPE type,
        const char *name,
        void *data,
        unsigned int datalen,
        FMOD_TAGDATATYPE datatype,
        bool unique)
{
  FMOD::Metadata *mMetadata; // rdi
  bool v13; // r10
  FMOD::Metadata *v15; // rax

  mMetadata = this->mMetadata;
  v13 = unique;
  if ( mMetadata )
    return FMOD::Metadata::addTag(mMetadata, type, name, data, datalen, datatype, v13);
  v15 = (FMOD::Metadata *)FMOD::MemPool::alloc(
                            off_286F358->gSystemMemPool,
                            72,
                            "../../../core_api/src/fmod_codec.cpp",
                            572,
                            0,
                            0);
  if ( v15 )
  {
    v15->mList.mNodePrev = &v15->mList;
    v15->mList.mNodeNext = &v15->mList;
    mMetadata = v15;
    v15->mList.mNodeData = 0;
    v15->mList.mType = FMOD_TAGTYPE::FMOD_TAGTYPE_UNKNOWN;
    v15->mList.mDataType = FMOD_TAGDATATYPE::FMOD_TAGDATATYPE_BINARY;
    v15->mList.mName = 0;
    v15->mList.mData[1] = 0;
    v15->mList.mData[0] = 0;
    v15->mList.mDataLen = 0;
    v15->mList.mUpdated = 1;
    v15->mList.mUnique = 0;
    v15->mList.mCurrentBuffer = 0;
    v13 = unique;
    this->mMetadata = v15;
    return FMOD::Metadata::addTag(mMetadata, type, name, data, datalen, datatype, v13);
  }
  this->mMetadata = 0;
  return FMOD_RESULT::FMOD_ERR_MEMORY_0;
}


