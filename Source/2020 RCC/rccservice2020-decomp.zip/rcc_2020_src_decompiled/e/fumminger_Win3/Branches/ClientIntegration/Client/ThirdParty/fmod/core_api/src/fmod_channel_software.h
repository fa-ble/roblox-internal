// Address: 0x2257950 | Name: _ZN4FMOD15ChannelSoftwareD2Ev
void __fastcall FMOD::ChannelSoftware::~ChannelSoftware(FMOD::ChannelSoftware *const this)
{
  FMOD::DSPBuffer *p_mSideChainBuffer; // rdi

  p_mSideChainBuffer = &this->mDSPWaveTable.mSideChainBuffer;
  *(_QWORD *)&p_mSideChainBuffer[-15].mChannels = &off_29B2CB0;
  p_mSideChainBuffer[-11].mData = (FMOD::DSPMemory *)off_29B0CB0;
  FMOD::DSPBuffer::~DSPBuffer(p_mSideChainBuffer);
  FMOD::DSPBuffer::~DSPBuffer(&this->mDSPWaveTable.mBuffer);
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2270;
}


// Address: 0x22579a0 | Name: _ZN4FMOD15ChannelSoftwareD0Ev
void __fastcall FMOD::ChannelSoftware::~ChannelSoftware(FMOD::ChannelSoftware *const this)
{
  FMOD::DSPBuffer *p_mSideChainBuffer; // rdi

  p_mSideChainBuffer = &this->mDSPWaveTable.mSideChainBuffer;
  *(_QWORD *)&p_mSideChainBuffer[-15].mChannels = &off_29B2CB0;
  p_mSideChainBuffer[-11].mData = (FMOD::DSPMemory *)off_29B0CB0;
  FMOD::DSPBuffer::~DSPBuffer(p_mSideChainBuffer);
  FMOD::DSPBuffer::~DSPBuffer(&this->mDSPWaveTable.mBuffer);
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2270;
  operator delete(this);
}


