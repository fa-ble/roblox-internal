// Address: 0x223adc0 | Name: _ZNK4FMOD12ProfileStats7getTypeEv
unsigned __int8 __fastcall FMOD::ProfileStats::getType(const FMOD::ProfileStats *const this)
{
  return 9;
}


