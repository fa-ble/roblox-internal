// Address: 0x2237fb0 | Name: _ZN4FMOD6Stream8isStreamEv
bool __fastcall FMOD::Stream::isStream(FMOD::Stream *const this)
{
  return 1;
}


