// Address: 0x22768c0 | Name: _packetout
int __fastcall packetout(ogg_stream_state *os, ogg_packet *op, int adv)
{
  int result; // eax
  ogg_int32_t lacing_returned; // r9d
  int *lacing_vals; // rcx
  __int64 v6; // r8
  int v7; // eax
  int v8; // r10d
  int v9; // r11d
  int v10; // ebp
  int *v11; // rax
  int v12; // ecx
  __int64 body_returned; // rax
  unsigned __int8 *v14; // rax
  __int64 v15; // rax

  result = 0;
  lacing_returned = os->lacing_returned;
  if ( lacing_returned < os->lacing_packet )
  {
    lacing_vals = os->lacing_vals;
    v6 = lacing_returned;
    v7 = lacing_vals[v6];
    if ( (v7 & 0x400) != 0 )
    {
      ++os->packetno;
      os->lacing_returned = lacing_returned + 1;
      return -1;
    }
    else
    {
      if ( op || adv )
      {
        v8 = (unsigned __int8)v7;
        v9 = lacing_vals[lacing_returned] & 0x200;
        v10 = lacing_vals[lacing_returned] & 0x100;
        if ( (unsigned __int8)v7 == 255 )
        {
          v11 = &lacing_vals[v6 + 1];
          do
          {
            ++lacing_returned;
            v12 = (unsigned __int8)*v11;
            if ( (*v11 & 0x200) != 0 )
              v9 = 512;
            v8 += v12;
            ++v11;
          }
          while ( v12 == 255 );
        }
        if ( op )
        {
          body_returned = os->body_returned;
          LODWORD(op->b_o_s) = v9;
          v14 = &os->body_data[body_returned];
          HIDWORD(op->bytes) = v10;
          op->packet = v14;
          op->granulepos = os->packetno;
          v15 = os->granule_vals[lacing_returned];
          LODWORD(op->bytes) = v8;
          op->e_o_s = v15;
        }
        if ( adv )
        {
          os->body_returned += v8;
          ++os->packetno;
          os->lacing_returned = lacing_returned + 1;
        }
      }
      return 1;
    }
  }
  return result;
}


// Address: 0x22769d0 | Name: FMOD_ogg_page_version
int __fastcall FMOD_ogg_page_version(const ogg_page *og)
{
  return og->header[4];
}


// Address: 0x22769e0 | Name: FMOD_ogg_page_continued
int __fastcall FMOD_ogg_page_continued(const ogg_page *og)
{
  return og->header[5] & 1;
}


// Address: 0x22769f0 | Name: FMOD_ogg_page_bos
int __fastcall FMOD_ogg_page_bos(const ogg_page *og)
{
  return og->header[5] & 2;
}


// Address: 0x2276a00 | Name: FMOD_ogg_page_eos
int __fastcall FMOD_ogg_page_eos(const ogg_page *og)
{
  return og->header[5] & 4;
}


// Address: 0x2276a10 | Name: FMOD_ogg_page_granulepos
ogg_int64_t_0 __fastcall FMOD_ogg_page_granulepos(const ogg_page *og)
{
  return og->header[6]
       | ((og->header[7]
         | ((og->header[8]
           | ((og->header[9]
             | ((og->header[10]
               | ((og->header[11] | ((unsigned __int64)*((unsigned __int16 *)og->header + 6) << 8)) << 8)) << 8)) << 8)) << 8)) << 8);
}


// Address: 0x2276a70 | Name: FMOD_ogg_page_serialno
int __fastcall FMOD_ogg_page_serialno(const ogg_page *og)
{
  return (og->header[17] << 24) | og->header[14] | (og->header[16] << 16) | (og->header[15] << 8);
}


// Address: 0x2276aa0 | Name: FMOD_ogg_page_pageno
ogg_int32_t __fastcall FMOD_ogg_page_pageno(const ogg_page *og)
{
  return (og->header[21] << 24) | og->header[18] | (og->header[20] << 16) | (og->header[19] << 8);
}


// Address: 0x2276ad0 | Name: FMOD_ogg_page_packets
int __fastcall FMOD_ogg_page_packets(const ogg_page *og)
{
  unsigned __int8 *header; // rsi
  int v2; // edi
  __int64 v3; // rdx
  int result; // eax
  __int64 v5; // rcx

  header = og->header;
  v2 = og->header[26];
  if ( !v2 )
    return 0;
  v3 = 0;
  result = 0;
  do
  {
    v5 = header[v3++ + 27] != 0xFF;
    result += v5;
  }
  while ( v2 > (int)v3 );
  return result;
}


// Address: 0x2276b00 | Name: FMOD_ogg_stream_check
int __fastcall FMOD_ogg_stream_check(ogg_stream_state *os)
{
  if ( os )
    return -(os->body_data == 0);
  else
    return -1;
}


// Address: 0x2276b20 | Name: FMOD_ogg_stream_clear
int __fastcall FMOD_ogg_stream_clear(void *context, ogg_stream_state *os)
{
  unsigned __int8 *body_data; // rsi
  int *lacing_vals; // rsi
  ogg_int64_t_0 *granule_vals; // rsi
  ogg_stream_state *v6; // rdi
  unsigned int v7; // edx
  __int64 v8; // rcx
  unsigned __int8 **v9; // rdi

  if ( !os )
    return 0;
  body_data = os->body_data;
  if ( body_data )
    FMOD_OggVorbis_Free(context, body_data);
  lacing_vals = os->lacing_vals;
  if ( lacing_vals )
    FMOD_OggVorbis_Free(context, lacing_vals);
  granule_vals = os->granule_vals;
  if ( granule_vals )
    FMOD_OggVorbis_Free(context, granule_vals);
  v6 = os;
  v7 = 376;
  if ( ((unsigned __int8)os & 1) != 0 )
  {
    LOBYTE(os->body_data) = 0;
    v6 = (ogg_stream_state *)((char *)&os->body_data + 1);
    LOBYTE(v7) = 119;
  }
  if ( ((unsigned __int8)v6 & 2) != 0 )
  {
    v6 = (ogg_stream_state *)((char *)v6 + 2);
    v7 -= 2;
    HIWORD(v6[-1].granulepos) = 0;
  }
  if ( ((unsigned __int8)v6 & 4) != 0 )
  {
    LODWORD(v6->body_data) = 0;
    v7 -= 4;
    v6 = (ogg_stream_state *)((char *)v6 + 4);
  }
  v8 = v7 >> 3;
  memset(v6, 0, 8 * v8);
  v9 = &v6->body_data + v8;
  if ( (v7 & 4) == 0 )
  {
    if ( (v7 & 2) == 0 )
      goto LABEL_16;
LABEL_19:
    v9 = (unsigned __int8 **)((char *)v9 + 2);
    *((_WORD *)v9 - 1) = 0;
    if ( (v7 & 1) == 0 )
      return 0;
    goto LABEL_18;
  }
  *(_DWORD *)v9 = 0;
  v9 = (unsigned __int8 **)((char *)v9 + 4);
  if ( (v7 & 2) != 0 )
    goto LABEL_19;
LABEL_16:
  if ( (v7 & 1) == 0 )
    return 0;
LABEL_18:
  *(_BYTE *)v9 = 0;
  return 0;
}


// Address: 0x2276c30 | Name: FMOD_ogg_stream_init
int __fastcall FMOD_ogg_stream_init(void *context, ogg_stream_state *os, int serialno)
{
  ogg_stream_state *v5; // rdi
  unsigned int v6; // r8d
  __int64 v7; // rcx
  unsigned __int8 **v8; // rdi
  ogg_int64_t_0 *v9; // rax
  bool v10; // zf

  if ( !os )
    return -1;
  v5 = os;
  v6 = 376;
  if ( ((unsigned __int8)os & 1) != 0 )
  {
    LOBYTE(os->body_data) = 0;
    v5 = (ogg_stream_state *)((char *)&os->body_data + 1);
    LOBYTE(v6) = 119;
  }
  if ( ((unsigned __int8)v5 & 2) != 0 )
  {
    v5 = (ogg_stream_state *)((char *)v5 + 2);
    v6 -= 2;
    HIWORD(v5[-1].granulepos) = 0;
  }
  if ( ((unsigned __int8)v5 & 4) != 0 )
  {
    LODWORD(v5->body_data) = 0;
    v6 -= 4;
    v5 = (ogg_stream_state *)((char *)v5 + 4);
  }
  v7 = v6 >> 3;
  memset(v5, 0, 8 * v7);
  v8 = &v5->body_data + v7;
  if ( (v6 & 4) == 0 )
  {
    if ( (v6 & 2) == 0 )
      goto LABEL_10;
LABEL_16:
    v8 = (unsigned __int8 **)((char *)v8 + 2);
    *((_WORD *)v8 - 1) = 0;
    if ( (v6 & 1) == 0 )
      goto LABEL_11;
    goto LABEL_15;
  }
  *(_DWORD *)v8 = 0;
  v8 = (unsigned __int8 **)((char *)v8 + 4);
  if ( (v6 & 2) != 0 )
    goto LABEL_16;
LABEL_10:
  if ( (v6 & 1) != 0 )
LABEL_15:
    *(_BYTE *)v8 = 0;
LABEL_11:
  os->body_storage = 4608;
  os->lacing_storage = 64;
  os->body_data = (unsigned __int8 *)FMOD_OggVorbis_Malloc(context, 4608);
  os->lacing_vals = (int *)FMOD_OggVorbis_Malloc(context, 4 * os->lacing_storage);
  v9 = (ogg_int64_t_0 *)FMOD_OggVorbis_Malloc(context, 8 * os->lacing_storage);
  v10 = os->body_data == 0;
  os->granule_vals = v9;
  if ( !v10 && os->lacing_vals && v9 )
  {
    os->serialno = serialno;
    return 0;
  }
  else
  {
    FMOD_ogg_stream_clear(context, os);
    return -1;
  }
}


// Address: 0x2276dd0 | Name: FMOD_ogg_stream_destroy
int __fastcall FMOD_ogg_stream_destroy(void *context, ogg_stream_state *os)
{
  if ( os )
  {
    FMOD_ogg_stream_clear(context, os);
    FMOD_OggVorbis_Free(context, os);
  }
  return 0;
}


// Address: 0x2276e00 | Name: FMOD_ogg_page_checksum_set
void __fastcall FMOD_ogg_page_checksum_set(ogg_page *og)
{
  ogg_uint32_t_0 v1; // edx
  ogg_int32_t header_len; // r8d
  ogg_uint32_t_0 v3; // eax
  unsigned __int8 *header; // r9
  __int64 v5; // rdx
  ogg_uint32_t_0 v6; // esi
  unsigned __int8 v7; // al
  ogg_uint32_t_0 v8; // esi
  ogg_int32_t body_len; // r8d
  __int64 v10; // rdx
  ogg_uint32_t_0 v11; // esi
  unsigned __int8 v12; // al
  ogg_uint32_t_0 v13; // esi

  if ( og )
  {
    LOBYTE(v1) = 0;
    og->header[22] = 0;
    og->header[23] = 0;
    og->header[24] = 0;
    og->header[25] = 0;
    header_len = og->header_len;
    v3 = 0;
    header = og->header;
    if ( header_len > 0 )
    {
      v5 = 0;
      v3 = 0;
      do
      {
        v6 = v3;
        v7 = header[v5++] ^ HIBYTE(v3);
        v8 = crc_lookup[v7] ^ (v6 << 8);
        v3 = v8;
      }
      while ( header_len > (int)v5 );
      v1 = HIBYTE(v8);
    }
    body_len = og->body_len;
    if ( body_len > 0 )
    {
      v10 = 0;
      do
      {
        v11 = v3;
        v12 = og->body[v10++] ^ HIBYTE(v3);
        v13 = crc_lookup[v12] ^ (v11 << 8);
        v3 = v13;
      }
      while ( body_len > (int)v10 );
      v1 = HIBYTE(v13);
    }
    header[22] = v3;
    og->header[23] = BYTE1(v3);
    og->header[24] = BYTE2(v3);
    og->header[25] = v1;
  }
}


// Address: 0x2276ed0 | Name: FMOD_ogg_stream_eos
int __fastcall FMOD_ogg_stream_eos(ogg_stream_state *os)
{
  int v1; // eax
  int v2; // edx

  v1 = FMOD_ogg_stream_check(os);
  v2 = 1;
  if ( !v1 )
    return os->e_o_s;
  return v2;
}


// Address: 0x2276ef0 | Name: FMOD_ogg_sync_init
int __fastcall FMOD_ogg_sync_init(ogg_sync_state *oy)
{
  if ( oy )
  {
    oy->data = 0;
    *(_QWORD *)&oy->storage = 0;
    *(_QWORD *)&oy->returned = 0;
    *(_QWORD *)&oy->headerbytes = 0;
  }
  return 0;
}


// Address: 0x2276f20 | Name: FMOD_ogg_sync_clear
int __fastcall FMOD_ogg_sync_clear(void *context, ogg_sync_state *oy)
{
  unsigned __int8 *data; // rsi

  if ( oy )
  {
    data = oy->data;
    if ( data )
      FMOD_OggVorbis_Free(context, data);
    oy->data = 0;
    *(_QWORD *)&oy->storage = 0;
    *(_QWORD *)&oy->returned = 0;
    *(_QWORD *)&oy->headerbytes = 0;
  }
  return 0;
}


// Address: 0x2276f60 | Name: FMOD_ogg_sync_destroy
int __fastcall FMOD_ogg_sync_destroy(void *context, ogg_sync_state *oy)
{
  if ( oy )
  {
    FMOD_ogg_sync_clear(context, oy);
    FMOD_OggVorbis_Free(context, oy);
  }
  return 0;
}


// Address: 0x2276f90 | Name: FMOD_ogg_sync_check
int __fastcall FMOD_ogg_sync_check(ogg_sync_state *oy)
{
  return oy->storage >> 31;
}


// Address: 0x2276fa0 | Name: FMOD_ogg_sync_buffer
char *__fastcall FMOD_ogg_sync_buffer(void *context, ogg_sync_state *oy, ogg_int32_t size)
{
  __int64 returned; // rsi
  int fill; // ecx
  int v7; // ebp
  unsigned __int8 *data; // rax

  if ( FMOD_ogg_sync_check(oy) )
    return 0;
  returned = oy->returned;
  fill = oy->fill;
  if ( (_DWORD)returned )
  {
    fill -= returned;
    oy->fill = fill;
    if ( fill > 0 )
    {
      memmove(oy->data, &oy->data[returned], fill);
      fill = oy->fill;
    }
    oy->returned = 0;
  }
  if ( oy->storage - fill >= size )
  {
    data = oy->data;
    return (char *)&data[fill];
  }
  v7 = fill + size + 4096;
  if ( oy->data )
    data = (unsigned __int8 *)FMOD_OggVorbis_ReAlloc(context, oy->data, v7);
  else
    data = (unsigned __int8 *)FMOD_OggVorbis_Malloc(context, v7);
  oy->data = 0;
  if ( data )
  {
    oy->data = data;
    oy->storage = v7;
    fill = oy->fill;
    return (char *)&data[fill];
  }
  FMOD_ogg_sync_clear(context, oy);
  return 0;
}


// Address: 0x2277060 | Name: FMOD_ogg_sync_wrote
int __fastcall FMOD_ogg_sync_wrote(ogg_sync_state *oy, ogg_int32_t bytes)
{
  int result; // eax
  int v3; // esi

  result = FMOD_ogg_sync_check(oy);
  if ( result )
    return -1;
  v3 = bytes + oy->fill;
  if ( v3 > oy->storage )
    return -1;
  oy->fill = v3;
  return result;
}


// Address: 0x22770a0 | Name: FMOD_ogg_sync_pageseek
ogg_int32_t __fastcall FMOD_ogg_sync_pageseek(ogg_sync_state *oy, ogg_page *og)
{
  unsigned __int8 *data; // rbp
  int returned; // r12d
  int fill; // r14d
  int headerbytes; // ecx
  int v7; // r14d
  unsigned __int8 *v8; // rbp
  int bodybytes; // eax
  ogg_int32_t result; // eax
  int v11; // eax
  int v12; // edi
  bool v13; // zf
  __int64 v14; // rcx
  int v15; // eax
  void *v16; // rax
  unsigned __int8 *v17; // rdx
  int v18; // ecx
  unsigned __int8 *v19; // rdx
  ogg_int32_t v20; // eax
  ogg_int32_t v21; // ebp
  char chksum[4]; // [rsp+0h] [rbp-58h] BYREF
  ogg_page log; // [rsp+10h] [rbp-48h] BYREF

  data = oy->data;
  returned = oy->returned;
  fill = oy->fill;
  if ( FMOD_ogg_sync_check(oy) )
    return 0;
  headerbytes = oy->headerbytes;
  v7 = fill - returned;
  v8 = &data[returned];
  if ( headerbytes )
  {
    bodybytes = oy->bodybytes;
  }
  else
  {
    if ( v7 <= 26 )
      return 0;
    if ( memcmp(v8, "OggS", 4u) )
      goto sync_fail;
    v11 = v8[26];
    v12 = v11 + 27;
    if ( v7 < v11 + 27 )
      return 0;
    v13 = v11 == 0;
    bodybytes = oy->bodybytes;
    if ( !v13 )
    {
      v14 = 0;
      do
      {
        bodybytes += v8[v14++ + 27];
        oy->bodybytes = bodybytes;
      }
      while ( v8[26] > (int)v14 );
    }
    oy->headerbytes = v12;
    headerbytes = v12;
  }
  if ( v7 < headerbytes + bodybytes )
    return 0;
  v15 = *(_DWORD *)(v8 + 22);
  *(_DWORD *)(v8 + 22) = 0;
  log.header = v8;
  *(_DWORD *)chksum = v15;
  log.header_len = oy->headerbytes;
  log.body = &v8[log.header_len];
  log.body_len = oy->bodybytes;
  FMOD_ogg_page_checksum_set(&log);
  if ( memcmp(chksum, v8 + 22, 4u) )
  {
    *(_DWORD *)(v8 + 22) = *(_DWORD *)chksum;
sync_fail:
    oy->headerbytes = 0;
    oy->bodybytes = 0;
    v16 = memchr(v8 + 1, 79, v7 - 1);
    v17 = oy->data;
    if ( !v16 )
      LODWORD(v16) = (_DWORD)v17 + oy->fill;
    oy->returned = (_DWORD)v16 - (_DWORD)v17;
    return (_DWORD)v8 - (_DWORD)v16;
  }
  v18 = oy->returned;
  v19 = &oy->data[v18];
  v20 = oy->headerbytes;
  v21 = oy->bodybytes;
  if ( og )
  {
    og->header = v19;
    og->header_len = v20;
    og->body_len = v21;
    og->body = &v19[v20];
  }
  result = v21 + v20;
  oy->unsynced = 0;
  oy->headerbytes = 0;
  oy->bodybytes = 0;
  oy->returned = result + v18;
  return result;
}


// Address: 0x2277260 | Name: FMOD_ogg_sync_pageout
int __fastcall FMOD_ogg_sync_pageout(ogg_sync_state *oy, ogg_page *og)
{
  ogg_int32_t v2; // eax

  if ( FMOD_ogg_sync_check(oy) )
    return 0;
  do
  {
    v2 = FMOD_ogg_sync_pageseek(oy, og);
    if ( v2 > 0 )
      return 1;
    if ( !v2 )
      return 0;
  }
  while ( oy->unsynced );
  oy->unsynced = 1;
  return -1;
}


// Address: 0x22772d0 | Name: FMOD_ogg_stream_pagein
int __fastcall FMOD_ogg_stream_pagein(void *context, ogg_stream_state *os, ogg_page *og)
{
  ogg_int32_t body_len; // r13d
  int v6; // r15d
  int v7; // r12d
  int v8; // r14d
  ogg_int32_t v9; // ebp
  int v10; // r10d
  __int64 body_returned; // rax
  ogg_int32_t lacing_returned; // r9d
  ogg_int32_t v13; // edx
  bool v14; // zf
  ogg_int32_t lacing_fill; // edx
  ogg_int32_t v16; // eax
  int v17; // r14d
  ogg_int32_t lacing_storage; // eax
  int v19; // r15d
  ogg_int32_t pageno; // edi
  __int64 lacing_packet; // rsi
  ogg_int32_t v22; // r9d
  int *lacing_vals; // r11
  ogg_int32_t body_fill; // edx
  unsigned __int8 *v25; // rax
  unsigned __int64 v26; // r11
  int v27; // ecx
  int *v28; // rax
  int v29; // r15d
  __int64 v30; // rax
  __int64 v31; // rax
  int *v32; // rdi
  ogg_int64_t_0 *v33; // r8
  int v34; // r15d
  __int64 v35; // r11
  unsigned __int8 *v36; // rax
  int v37; // ecx
  int v38; // ecx
  ogg_int32_t v39; // edx
  int v40; // ecx
  __int64 v41; // rax
  int *v43; // rax
  int v44; // r15d
  ogg_int64_t_0 *granule_vals; // rsi
  ogg_int64_t_0 *v46; // rax
  __int64 v47; // rdx
  ogg_int32_t body_storage; // eax
  unsigned __int8 *body_data; // rdi
  __int64 v50; // rdx
  unsigned __int8 *v51; // rsi
  unsigned __int8 *v52; // rax
  __int64 v53; // rcx
  unsigned __int8 *v54; // rax
  unsigned __int8 *header; // [rsp+0h] [rbp-78h]
  unsigned __int8 v56; // [rsp+Ch] [rbp-6Ch]
  int v57; // [rsp+Ch] [rbp-6Ch]
  int v58; // [rsp+Ch] [rbp-6Ch]
  int v59; // [rsp+Ch] [rbp-6Ch]
  int continued; // [rsp+10h] [rbp-68h]
  int eos; // [rsp+14h] [rbp-64h]
  unsigned __int8 *body; // [rsp+18h] [rbp-60h]
  ogg_int64_t_0 granulepos; // [rsp+28h] [rbp-50h]
  __int64 lra; // [rsp+30h] [rbp-48h]
  ogg_int32_t lr; // [rsp+30h] [rbp-48h]
  ogg_int32_t v67; // [rsp+38h] [rbp-40h]
  int v68; // [rsp+3Ch] [rbp-3Ch]

  body_len = og->body_len;
  header = og->header;
  body = og->body;
  v6 = FMOD_ogg_page_version(og);
  continued = FMOD_ogg_page_continued(og);
  v7 = FMOD_ogg_page_bos(og);
  eos = FMOD_ogg_page_eos(og);
  granulepos = FMOD_ogg_page_granulepos(og);
  v8 = FMOD_ogg_page_serialno(og);
  v9 = FMOD_ogg_page_pageno(og);
  v56 = header[26];
  v10 = FMOD_ogg_stream_check(os);
  if ( v10 )
    return -1;
  body_returned = os->body_returned;
  lacing_returned = os->lacing_returned;
  if ( (_DWORD)body_returned )
  {
    v13 = os->body_fill - body_returned;
    v14 = os->body_fill == (_DWORD)body_returned;
    os->body_fill = v13;
    if ( !v14 )
    {
      lr = lacing_returned;
      memmove(os->body_data, &os->body_data[body_returned], v13);
      lacing_returned = lr;
      v10 = 0;
    }
    os->body_returned = 0;
  }
  if ( lacing_returned )
  {
    lacing_fill = os->lacing_fill;
    v16 = lacing_returned;
    if ( lacing_fill != lacing_returned )
    {
      v68 = v10;
      v67 = lacing_returned;
      lra = lacing_returned;
      memmove(os->lacing_vals, &os->lacing_vals[lacing_returned], 4LL * (lacing_fill - lacing_returned));
      memmove(os->granule_vals, &os->granule_vals[lra], 8LL * (os->lacing_fill - v67));
      v16 = os->lacing_fill;
      v10 = v68;
      lacing_returned = v67;
    }
    os->lacing_packet -= lacing_returned;
    os->lacing_returned = 0;
    os->lacing_fill = v16 - lacing_returned;
  }
  if ( os->serialno != v8 || v6 > 0 )
    return -1;
  v17 = v56;
  lacing_storage = os->lacing_storage;
  v19 = v56 + 1;
  if ( lacing_storage > v19 + os->lacing_fill )
  {
    pageno = os->pageno;
    if ( pageno == v9 )
      goto LABEL_19;
    goto LABEL_14;
  }
  v57 = v10;
  v43 = (int *)FMOD_OggVorbis_ReAlloc(context, os->lacing_vals, 4 * (v19 + lacing_storage + 32));
  if ( !v43
    || (v44 = os->lacing_storage + v19,
        granule_vals = os->granule_vals,
        os->lacing_vals = v43,
        (v46 = (ogg_int64_t_0 *)FMOD_OggVorbis_ReAlloc(context, granule_vals, 8 * v44 + 256)) == 0) )
  {
LABEL_42:
    FMOD_ogg_stream_clear(context, os);
    return -1;
  }
  pageno = os->pageno;
  os->granule_vals = v46;
  os->lacing_storage += v17 + 33;
  v10 = v57;
  if ( pageno != v9 )
  {
LABEL_14:
    lacing_packet = os->lacing_packet;
    v22 = os->lacing_fill;
    if ( (int)lacing_packet < v22 )
    {
      lacing_vals = os->lacing_vals;
      body_fill = os->body_fill;
      v25 = (unsigned __int8 *)&lacing_vals[(int)lacing_packet];
      v26 = (unsigned __int64)&lacing_vals[(int)lacing_packet
                                         + 1
                                         + (unsigned __int64)(unsigned int)(v22 - 1 - lacing_packet)];
      do
      {
        v27 = *v25;
        v25 += 4;
        body_fill -= v27;
        os->body_fill = body_fill;
      }
      while ( v25 != (unsigned __int8 *)v26 );
    }
    os->lacing_fill = lacing_packet;
    if ( pageno != -1 )
    {
      v28 = os->lacing_vals;
      os->lacing_fill = lacing_packet + 1;
      v28[lacing_packet] = 1024;
      ++os->lacing_packet;
    }
  }
LABEL_19:
  v29 = 0;
  if ( continued )
  {
    v30 = os->lacing_fill;
    if ( (int)v30 <= 0 || os->lacing_vals[v30 - 1] == 1024 )
    {
      if ( v17 )
      {
        v50 = header[27];
        body += v50;
        body_len -= (unsigned __int8)v50;
        if ( (unsigned __int8)v50 == 255 )
        {
          v29 = 0;
          v51 = body;
          v52 = header + 28;
          do
          {
            if ( v17 <= ++v29 )
            {
              body = v51;
              goto LABEL_53;
            }
            v53 = *v52++;
            v51 += v53;
            body_len -= (unsigned __int8)v53;
          }
          while ( (unsigned __int8)v53 == 255 );
          body = v51;
          ++v29;
        }
        else
        {
          v29 = 1;
        }
LABEL_53:
        v7 = 0;
        if ( !body_len )
          goto LABEL_23;
        goto LABEL_44;
      }
      v7 = 0;
      v29 = 0;
    }
  }
  if ( body_len )
  {
LABEL_44:
    v47 = os->body_fill;
    body_storage = os->body_storage;
    if ( body_storage > body_len + (int)v47 )
    {
      body_data = os->body_data;
LABEL_46:
      v58 = v10;
      memcpy_0(&body_data[v47], body, body_len);
      os->body_fill += body_len;
      v10 = v58;
      goto LABEL_23;
    }
    v59 = v10;
    v54 = (unsigned __int8 *)FMOD_OggVorbis_ReAlloc(context, os->body_data, body_len + body_storage + 1024);
    v10 = v59;
    if ( v54 )
    {
      os->body_data = v54;
      os->body_storage += body_len + 1024;
      body_data = v54;
      v47 = os->body_fill;
      goto LABEL_46;
    }
    goto LABEL_42;
  }
LABEL_23:
  if ( v29 >= v17 )
    goto LABEL_33;
  v31 = v29;
  v32 = os->lacing_vals;
  v33 = os->granule_vals;
  v34 = v29 + 1;
  v35 = -1;
  v36 = &header[v31 + 27];
  while ( 1 )
  {
    v38 = *v36;
    v32[os->lacing_fill] = v38;
    v39 = os->lacing_fill;
    v33[v39] = -1;
    if ( v7 )
    {
      v32[v39] |= 0x100u;
      v39 = os->lacing_fill;
    }
    if ( v38 == 255 )
      break;
    v37 = v34;
    ++v36;
    ++v34;
    v35 = v39;
    os->lacing_fill = v39 + 1;
    os->lacing_packet = v39 + 1;
    if ( v17 <= v37 )
      goto LABEL_31;
LABEL_26:
    v7 = 0;
  }
  v40 = v34;
  ++v36;
  ++v34;
  os->lacing_fill = v39 + 1;
  if ( v17 > v40 )
    goto LABEL_26;
LABEL_31:
  if ( (_DWORD)v35 != -1 )
    v33[v35] = granulepos;
LABEL_33:
  if ( eos )
  {
    v41 = os->lacing_fill;
    os->e_o_s = 1;
    if ( (int)v41 > 0 )
      os->lacing_vals[v41 - 1] |= 0x200u;
  }
  os->pageno = v9 + 1;
  return v10;
}


// Address: 0x22777b0 | Name: FMOD_ogg_sync_reset
int __fastcall FMOD_ogg_sync_reset(ogg_sync_state *oy)
{
  int result; // eax

  result = FMOD_ogg_sync_check(oy);
  if ( result )
    return -1;
  oy->fill = 0;
  oy->returned = 0;
  oy->unsynced = 0;
  oy->headerbytes = 0;
  oy->bodybytes = 0;
  return result;
}


// Address: 0x22777f0 | Name: FMOD_ogg_stream_reset
int __fastcall FMOD_ogg_stream_reset(ogg_stream_state *os)
{
  int result; // eax

  result = FMOD_ogg_stream_check(os);
  if ( result )
    return -1;
  os->body_fill = 0;
  os->body_returned = 0;
  os->lacing_fill = 0;
  os->lacing_packet = 0;
  os->lacing_returned = 0;
  os->header_fill = 0;
  os->e_o_s = 0;
  os->b_o_s = 0;
  os->pageno = -1;
  os->packetno = 0;
  os->granulepos = 0;
  return result;
}


// Address: 0x2277870 | Name: FMOD_ogg_stream_reset_serialno
int __fastcall FMOD_ogg_stream_reset_serialno(ogg_stream_state *os, int serialno)
{
  int v2; // ebp

  v2 = FMOD_ogg_stream_check(os);
  if ( v2 )
    return -1;
  FMOD_ogg_stream_reset(os);
  os->serialno = serialno;
  return v2;
}


// Address: 0x22778b0 | Name: FMOD_ogg_stream_packetout
int __fastcall FMOD_ogg_stream_packetout(ogg_stream_state *os, ogg_packet *op)
{
  if ( FMOD_ogg_stream_check(os) )
    return 0;
  else
    return packetout(os, op, 1);
}


// Address: 0x22778f0 | Name: FMOD_ogg_stream_packetpeek
int __fastcall FMOD_ogg_stream_packetpeek(ogg_stream_state *os, ogg_packet *op)
{
  if ( FMOD_ogg_stream_check(os) )
    return 0;
  else
    return packetout(os, op, 0);
}


// Address: 0x2277930 | Name: FMOD_ogg_packet_clear
void __fastcall FMOD_ogg_packet_clear(void *context, ogg_packet *op)
{
  FMOD_OggVorbis_Free(context, op->packet);
  op->packet = 0;
  op->bytes = 0;
  op->b_o_s = 0;
  op->e_o_s = 0;
  op->granulepos = 0;
}


