// Address: 0x21fdd50 | Name: _ZN4FMOD10SoundGroup7releaseEv
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::release(FMOD::SoundGroup *const this)
{
  FMOD_RESULT_0 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v1 || (v1 = FMOD::SoundGroupI::release(soundgroupi)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      v1,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::release",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x21fddf0 | Name: _ZN4FMOD10SoundGroup15getSystemObjectEPPNS_6SystemE
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::getSystemObject(FMOD::SoundGroup *const this, FMOD::System **system)
{
  FMOD_RESULT_0 SystemObject; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  SystemObject = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (SystemObject
     || (SystemObject = FMOD::SoundGroupI::getSystemObject(soundgroupi, system)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, system);
    FMOD_ReportError(
      SystemObject,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::getSystemObject",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return SystemObject;
}


// Address: 0x21fdea0 | Name: _ZN4FMOD10SoundGroup13setMaxAudibleEi
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::setMaxAudible(FMOD::SoundGroup *const this, int maxaudible)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v2 || (v2 = FMOD::SoundGroupI::setMaxAudible(soundgroupi, maxaudible)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, maxaudible);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::setMaxAudible",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21fdf50 | Name: _ZN4FMOD10SoundGroup13getMaxAudibleEPi
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::getMaxAudible(FMOD::SoundGroup *const this, int *maxaudible)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v2 || (v2 = FMOD::SoundGroupI::getMaxAudible(soundgroupi, maxaudible)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, maxaudible);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::getMaxAudible",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21fe000 | Name: _ZN4FMOD10SoundGroup21setMaxAudibleBehaviorE24FMOD_SOUNDGROUP_BEHAVIOR
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::setMaxAudibleBehavior(
        FMOD::SoundGroup *const this,
        FMOD_SOUNDGROUP_BEHAVIOR behavior)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v2 || (v2 = FMOD::SoundGroupI::setMaxAudibleBehavior(soundgroupi, behavior)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, behavior);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::setMaxAudibleBehavior",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21fe0b0 | Name: _ZN4FMOD10SoundGroup21getMaxAudibleBehaviorEP24FMOD_SOUNDGROUP_BEHAVIOR
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::getMaxAudibleBehavior(
        FMOD::SoundGroup *const this,
        FMOD_SOUNDGROUP_BEHAVIOR *behavior)
{
  FMOD_RESULT_0 MaxAudibleBehavior; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  MaxAudibleBehavior = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (MaxAudibleBehavior
     || (MaxAudibleBehavior = FMOD::SoundGroupI::getMaxAudibleBehavior(soundgroupi, behavior)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, behavior);
    FMOD_ReportError(
      MaxAudibleBehavior,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::getMaxAudibleBehavior",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return MaxAudibleBehavior;
}


// Address: 0x21fe160 | Name: _ZN4FMOD10SoundGroup16setMuteFadeSpeedEf
__int64 __fastcall FMOD::SoundGroup::setMuteFadeSpeed(FMOD::SoundGroup *const this, float a2, float speed)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD_RESULT_0 v5; // eax
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( v3
    || (LOBYTE(v5) = FMOD::SoundGroupI::setMuteFadeSpeed(soundgroupi, a2, speed), (v3 = v5) != FMOD_RESULT::FMOD_OK_0) )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      FMOD::FMOD_FormatArg(_buffer, 256, speed);
      FMOD_ReportError(
        v3,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
        this,
        "SoundGroup::setMuteFadeSpeed",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21fe210 | Name: _ZN4FMOD10SoundGroup16getMuteFadeSpeedEPf
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::getMuteFadeSpeed(FMOD::SoundGroup *const this, float *speed)
{
  FMOD_RESULT_0 MuteFadeSpeed; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  MuteFadeSpeed = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (MuteFadeSpeed
     || (MuteFadeSpeed = FMOD::SoundGroupI::getMuteFadeSpeed(soundgroupi, speed)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, speed);
    FMOD_ReportError(
      MuteFadeSpeed,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::getMuteFadeSpeed",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return MuteFadeSpeed;
}


// Address: 0x21fe2c0 | Name: _ZN4FMOD10SoundGroup9setVolumeEf
__int64 __fastcall FMOD::SoundGroup::setVolume(FMOD::SoundGroup *const this, float a2, float volume)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v3 || (v3 = (unsigned int)FMOD::SoundGroupI::setVolume(soundgroupi, a2, volume)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, volume);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::setVolume",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x21fe370 | Name: _ZN4FMOD10SoundGroup9getVolumeEPf
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::getVolume(FMOD::SoundGroup *const this, float *volume)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v2 || (v2 = FMOD::SoundGroupI::getVolume(soundgroupi, volume)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, volume);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::getVolume",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21fe420 | Name: _ZN4FMOD10SoundGroup4stopEv
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::stop(FMOD::SoundGroup *const this)
{
  FMOD_RESULT_0 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v1 || (v1 = FMOD::SoundGroupI::stop(soundgroupi)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      v1,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::stop",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x21fe4c0 | Name: _ZN4FMOD10SoundGroup7getNameEPci
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::getName(FMOD::SoundGroup *const this, char *name, int namelen)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v4 || (v4 = FMOD::SoundGroupI::getName(soundgroupi, name, namelen)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, name);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), namelen);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::getName",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21fe5c0 | Name: _ZN4FMOD10SoundGroup12getNumSoundsEPi
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::getNumSounds(FMOD::SoundGroup *const this, int *numsounds)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v2 || (v2 = FMOD::SoundGroupI::getNumSounds(soundgroupi, numsounds)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numsounds);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::getNumSounds",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21fe670 | Name: _ZN4FMOD10SoundGroup8getSoundEiPPNS_5SoundE
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::getSound(FMOD::SoundGroup *const this, int index, FMOD::Sound **sound)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v4 || (v4 = FMOD::SoundGroupI::getSound(soundgroupi, index, sound)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), sound);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::getSound",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x21fe770 | Name: _ZN4FMOD10SoundGroup13getNumPlayingEPi
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::getNumPlaying(FMOD::SoundGroup *const this, int *numplaying)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v2 || (v2 = FMOD::SoundGroupI::getNumPlaying(soundgroupi, numplaying)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numplaying);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::getNumPlaying",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21fe820 | Name: _ZN4FMOD10SoundGroup11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::setUserData(FMOD::SoundGroup *const this, void *_userdata)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (v2 || (v2 = FMOD::SoundGroupI::setUserData(soundgroupi, _userdata)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::setUserData",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x21fe8d0 | Name: _ZN4FMOD10SoundGroup11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::SoundGroup::getUserData(FMOD::SoundGroup *const this, void **_userdata)
{
  FMOD_RESULT_0 UserData; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundGroupI *soundgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  UserData = FMOD::SoundGroupI::validate(this, &soundgroupi, &lockScope);
  if ( (UserData || (UserData = FMOD::SoundGroupI::getUserData(soundgroupi, _userdata)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      UserData,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUNDGROUP,
      this,
      "SoundGroup::getUserData",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return UserData;
}


