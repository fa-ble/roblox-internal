// Address: 0x226a5d0 | Name: FMOD_oggpack_reset
void __fastcall FMOD_oggpack_reset(oggpack_buffer *b)
{
  unsigned __int8 *v1; // rax

  if ( b->buffer )
  {
    v1 = *(unsigned __int8 **)&b->endbit;
    b->buffer = v1;
    *v1 = 0;
    b->endbyte = 0;
  }
}


// Address: 0x226a600 | Name: FMOD_oggpackB_reset
// Alternative name is 'j_FMOD_oggpack_reset'
// attributes: thunk
void __fastcall FMOD_oggpackB_reset(oggpack_buffer *b)
{
  FMOD_oggpack_reset(b);
}


// Address: 0x226a610 | Name: FMOD_oggpack_readinit
void __fastcall FMOD_oggpack_readinit(oggpack_buffer *b, unsigned __int8 *buf, int bytes)
{
  b->ptr = 0;
  b->endbyte = 0;
  b->buffer = buf;
  *(_QWORD *)&b->endbit = buf;
  LODWORD(b->ptr) = bytes;
}


// Address: 0x226a630 | Name: FMOD_oggpackB_readinit
// Alternative name is 'j_FMOD_oggpack_readinit'
// attributes: thunk
void __fastcall FMOD_oggpackB_readinit(oggpack_buffer *b, unsigned __int8 *buf, int bytes)
{
  FMOD_oggpack_readinit(b, buf, bytes);
}


// Address: 0x226a640 | Name: FMOD_oggpack_look
ogg_int32_t __fastcall FMOD_oggpack_look(oggpack_buffer *b, int bits)
{
  int endbyte_high; // r8d
  ogg_uint32_t_0 v3; // r9d
  int ptr; // edx
  int v5; // esi
  ogg_int32_t result; // eax
  unsigned __int8 *buffer; // rax
  int v8; // edx

  if ( (unsigned int)bits > 0x20 )
    return -1;
  endbyte_high = HIDWORD(b->endbyte);
  v3 = mask[bits];
  ptr = (int)b->ptr;
  v5 = endbyte_high + bits;
  if ( SLODWORD(b->endbyte) >= ptr - 4 )
  {
    if ( SLODWORD(b->endbyte) <= ptr - ((v5 + 7) >> 3) )
    {
      result = 0;
      if ( !v5 )
        return result;
      goto LABEL_5;
    }
    return -1;
  }
LABEL_5:
  buffer = b->buffer;
  v8 = (int)*buffer >> endbyte_high;
  if ( v5 > 8 )
  {
    v8 |= buffer[1] << (8 - endbyte_high);
    if ( v5 > 16 )
    {
      v8 |= buffer[2] << (16 - endbyte_high);
      if ( v5 > 24 )
      {
        v8 |= buffer[3] << (24 - endbyte_high);
        if ( v5 > 32 )
        {
          if ( endbyte_high )
            v8 |= buffer[4] << (32 - endbyte_high);
        }
      }
    }
  }
  return v8 & v3;
}


// Address: 0x226a700 | Name: FMOD_oggpackB_look
ogg_int32_t __fastcall FMOD_oggpackB_look(oggpack_buffer *b, int bits)
{
  int ptr; // ecx
  int endbyte_high; // r8d
  int v4; // r9d
  ogg_int32_t result; // eax
  unsigned __int8 *buffer; // rdi
  unsigned int v7; // eax

  if ( (unsigned int)bits > 0x20 && bits != 0 )
    return -1;
  ptr = (int)b->ptr;
  endbyte_high = HIDWORD(b->endbyte);
  v4 = endbyte_high + bits;
  if ( SLODWORD(b->endbyte) >= ptr - 4 )
  {
    if ( SLODWORD(b->endbyte) <= ptr - ((v4 + 7) >> 3) )
    {
      result = 0;
      if ( !v4 )
        return result;
      goto LABEL_5;
    }
    return -1;
  }
LABEL_5:
  buffer = b->buffer;
  v7 = *buffer << (endbyte_high + 24);
  if ( v4 > 8 )
  {
    v7 |= buffer[1] << (endbyte_high + 16);
    if ( v4 > 16 )
    {
      v7 |= buffer[2] << (endbyte_high + 8);
      if ( v4 > 24 )
      {
        v7 |= buffer[3] << endbyte_high;
        if ( v4 > 32 )
        {
          if ( endbyte_high )
            v7 |= (int)buffer[4] >> (8 - endbyte_high);
        }
      }
    }
  }
  return v7 >> ((32 - bits) >> 1) >> ((33 - bits) >> 1);
}


// Address: 0x226a7d0 | Name: FMOD_oggpack_look1
ogg_int32_t __fastcall FMOD_oggpack_look1(oggpack_buffer *b)
{
  if ( SLODWORD(b->endbyte) >= SLODWORD(b->ptr) )
    return -1;
  else
    return ((int)*b->buffer >> HIDWORD(b->endbyte)) & 1;
}


// Address: 0x226a800 | Name: FMOD_oggpackB_look1
ogg_int32_t __fastcall FMOD_oggpackB_look1(oggpack_buffer *b)
{
  if ( SLODWORD(b->endbyte) >= SLODWORD(b->ptr) )
    return -1;
  else
    return ((int)*b->buffer >> (7 - BYTE4(b->endbyte))) & 1;
}


// Address: 0x226a830 | Name: FMOD_oggpack_adv
void __fastcall FMOD_oggpack_adv(oggpack_buffer *b, int bits)
{
  int v2; // esi
  int ptr; // eax
  int endbyte; // edx
  int v5; // ecx
  int v6; // ecx

  v2 = HIDWORD(b->endbyte) + bits;
  ptr = (int)b->ptr;
  endbyte = b->endbyte;
  v5 = v2 + 7;
  if ( SLODWORD(b->endbyte) <= ptr - ((v2 + 7) >> 3) )
  {
    if ( v2 >= 0 )
      v5 = v2;
    v6 = v5 >> 3;
    HIDWORD(b->endbyte) = v2 & 7;
    b->buffer += v6;
    LODWORD(b->endbyte) = endbyte + v6;
  }
  else
  {
    b->buffer = 0;
    LODWORD(b->endbyte) = ptr;
    HIDWORD(b->endbyte) = 1;
  }
}


// Address: 0x226a880 | Name: FMOD_oggpackB_adv
// Alternative name is 'j_FMOD_oggpack_adv'
// attributes: thunk
void __fastcall FMOD_oggpackB_adv(oggpack_buffer *b, int bits)
{
  FMOD_oggpack_adv(b, bits);
}


// Address: 0x226a890 | Name: FMOD_oggpack_adv1
void __fastcall FMOD_oggpack_adv1(oggpack_buffer *b)
{
  int v1; // eax

  v1 = HIDWORD(b->endbyte) + 1;
  if ( v1 <= 7 )
  {
    HIDWORD(b->endbyte) = v1;
  }
  else
  {
    HIDWORD(b->endbyte) = 0;
    ++b->buffer;
    ++LODWORD(b->endbyte);
  }
}


// Address: 0x226a8c0 | Name: FMOD_oggpackB_adv1
// Alternative name is 'j_FMOD_oggpack_adv1'
// attributes: thunk
void __fastcall FMOD_oggpackB_adv1(oggpack_buffer *b)
{
  FMOD_oggpack_adv1(b);
}


// Address: 0x226a8d0 | Name: FMOD_oggpack_read
ogg_int32_t __fastcall FMOD_oggpack_read(oggpack_buffer *b, int bits)
{
  int endbyte_high; // r8d
  int endbyte; // r10d
  ogg_uint32_t_0 v4; // ebx
  int ptr; // edx
  int v6; // esi
  ogg_int32_t result; // eax
  unsigned __int8 *buffer; // r9
  int v9; // edx

  if ( (unsigned int)bits > 0x20 )
  {
    ptr = (int)b->ptr;
    goto overflow;
  }
  endbyte_high = HIDWORD(b->endbyte);
  endbyte = b->endbyte;
  v4 = mask[bits];
  ptr = (int)b->ptr;
  v6 = endbyte_high + bits;
  if ( SLODWORD(b->endbyte) >= ptr - 4 )
  {
    if ( endbyte <= ptr - ((v6 + 7) >> 3) )
    {
      result = 0;
      if ( !v6 )
        return result;
      goto LABEL_5;
    }
overflow:
    b->buffer = 0;
    HIDWORD(b->endbyte) = 1;
    LODWORD(b->endbyte) = ptr;
    return -1;
  }
LABEL_5:
  buffer = b->buffer;
  v9 = (int)*buffer >> endbyte_high;
  if ( v6 > 8 )
  {
    v9 |= buffer[1] << (8 - endbyte_high);
    if ( v6 > 16 )
    {
      v9 |= buffer[2] << (16 - endbyte_high);
      if ( v6 > 24 )
      {
        v9 |= buffer[3] << (24 - endbyte_high);
        if ( v6 > 32 )
        {
          if ( endbyte_high )
            v9 |= buffer[4] << (32 - endbyte_high);
        }
      }
    }
  }
  HIDWORD(b->endbyte) = v6 & 7;
  LODWORD(b->endbyte) = endbyte + v6 / 8;
  b->buffer = &buffer[v6 / 8];
  return v9 & v4;
}


// Address: 0x226a9e0 | Name: FMOD_oggpackB_read
ogg_int32_t __fastcall FMOD_oggpackB_read(oggpack_buffer *b, int bits)
{
  int endbyte; // r11d
  int endbyte_high; // r9d
  int ptr; // eax
  int v5; // edx
  int v6; // ebx
  ogg_int32_t result; // eax
  unsigned __int8 *buffer; // r10
  unsigned int v9; // eax
  unsigned int v10; // eax

  if ( (unsigned int)bits > 0x20 && bits != 0 )
  {
    ptr = (int)b->ptr;
    goto overflow;
  }
  endbyte = b->endbyte;
  endbyte_high = HIDWORD(b->endbyte);
  ptr = (int)b->ptr;
  v5 = endbyte_high + bits;
  v6 = endbyte_high + bits + 7;
  if ( LODWORD(b->endbyte) + 4 >= ptr )
  {
    if ( endbyte <= ptr - (v6 >> 3) )
    {
      result = 0;
      if ( !v5 )
        return result;
      goto LABEL_5;
    }
overflow:
    LODWORD(b->endbyte) = ptr;
    b->buffer = 0;
    HIDWORD(b->endbyte) = 1;
    return -1;
  }
LABEL_5:
  buffer = b->buffer;
  v9 = *buffer << (endbyte_high + 24);
  if ( v5 > 8 )
  {
    v9 |= buffer[1] << (endbyte_high + 16);
    if ( v5 > 16 )
    {
      v9 |= buffer[2] << (endbyte_high + 8);
      if ( v5 > 24 )
      {
        v9 |= buffer[3] << endbyte_high;
        if ( v5 > 32 )
        {
          if ( endbyte_high )
            v9 |= (int)buffer[4] >> (8 - endbyte_high);
        }
      }
    }
  }
  v10 = v9 >> ((32 - bits) >> 1);
  if ( v5 >= 0 )
    v6 = endbyte_high + bits;
  result = v10 >> ((33 - bits) >> 1);
  HIDWORD(b->endbyte) = v5 & 7;
  LODWORD(b->endbyte) = endbyte + (v6 >> 3);
  b->buffer = &buffer[v6 >> 3];
  return result;
}


// Address: 0x226aaf0 | Name: FMOD_oggpack_read1
ogg_int32_t __fastcall FMOD_oggpack_read1(oggpack_buffer *b)
{
  int endbyte; // edx
  int ptr; // eax
  unsigned __int8 *buffer; // rsi
  int endbyte_high; // ecx
  int v5; // eax
  int v6; // ecx
  ogg_int32_t result; // eax

  endbyte = b->endbyte;
  ptr = (int)b->ptr;
  if ( SLODWORD(b->endbyte) >= ptr )
  {
    LODWORD(b->endbyte) = ptr;
    b->buffer = 0;
    HIDWORD(b->endbyte) = 1;
    return -1;
  }
  else
  {
    buffer = b->buffer;
    endbyte_high = HIDWORD(b->endbyte);
    v5 = (int)*buffer >> endbyte_high;
    v6 = endbyte_high + 1;
    result = v5 & 1;
    if ( v6 <= 7 )
    {
      HIDWORD(b->endbyte) = v6;
    }
    else
    {
      HIDWORD(b->endbyte) = 0;
      b->buffer = buffer + 1;
      LODWORD(b->endbyte) = endbyte + 1;
    }
  }
  return result;
}


// Address: 0x226ab50 | Name: FMOD_oggpackB_read1
ogg_int32_t __fastcall FMOD_oggpackB_read1(oggpack_buffer *b)
{
  int endbyte; // esi
  int ptr; // eax
  unsigned __int8 *buffer; // r8
  int endbyte_high; // edx
  char v5; // cl
  int v6; // edx
  ogg_int32_t result; // eax

  endbyte = b->endbyte;
  ptr = (int)b->ptr;
  if ( SLODWORD(b->endbyte) >= ptr )
  {
    LODWORD(b->endbyte) = ptr;
    b->buffer = 0;
    HIDWORD(b->endbyte) = 1;
    return -1;
  }
  else
  {
    buffer = b->buffer;
    endbyte_high = HIDWORD(b->endbyte);
    v5 = 7 - endbyte_high;
    v6 = endbyte_high + 1;
    result = ((int)*buffer >> v5) & 1;
    if ( v6 <= 7 )
    {
      HIDWORD(b->endbyte) = v6;
    }
    else
    {
      HIDWORD(b->endbyte) = 0;
      b->buffer = buffer + 1;
      LODWORD(b->endbyte) = endbyte + 1;
    }
  }
  return result;
}


// Address: 0x226abb0 | Name: FMOD_oggpack_bytes
ogg_int32_t __fastcall FMOD_oggpack_bytes(oggpack_buffer *b)
{
  int endbyte_high; // edx
  int v2; // eax
  int v3; // edx

  endbyte_high = HIDWORD(b->endbyte);
  v2 = endbyte_high + 14;
  v3 = endbyte_high + 7;
  if ( v3 >= 0 )
    v2 = v3;
  return LODWORD(b->endbyte) + (v2 >> 3);
}


// Address: 0x226abd0 | Name: FMOD_oggpack_bits
ogg_int32_t __fastcall FMOD_oggpack_bits(oggpack_buffer *b)
{
  return HIDWORD(b->endbyte) + 8 * LODWORD(b->endbyte);
}


// Address: 0x226abe0 | Name: FMOD_oggpackB_bytes
// Alternative name is 'j_FMOD_oggpack_bytes'
// attributes: thunk
ogg_int32_t __fastcall FMOD_oggpackB_bytes(oggpack_buffer *b)
{
  return FMOD_oggpack_bytes(b);
}


// Address: 0x226abf0 | Name: FMOD_oggpackB_bits
// Alternative name is 'j_FMOD_oggpack_bits'
// attributes: thunk
ogg_int32_t __fastcall FMOD_oggpackB_bits(oggpack_buffer *b)
{
  return FMOD_oggpack_bits(b);
}


// Address: 0x226ac00 | Name: FMOD_oggpack_get_buffer
unsigned __int8 *__fastcall FMOD_oggpack_get_buffer(oggpack_buffer *b)
{
  return *(unsigned __int8 **)&b->endbit;
}


// Address: 0x226ac10 | Name: FMOD_oggpackB_get_buffer
// Alternative name is 'j_FMOD_oggpack_get_buffer'
// attributes: thunk
unsigned __int8 *__fastcall FMOD_oggpackB_get_buffer(oggpack_buffer *b)
{
  return FMOD_oggpack_get_buffer(b);
}


