// Address: 0x225c690 | Name: _ZN4FMOD8DSPCodec19clearStaticPointersEv
FMOD_RESULT_0 __fastcall FMOD::DSPCodec::clearStaticPointers(FMOD::DSPCodec *const this)
{
  FMOD::Codec *mCodec; // rax

  mCodec = this->mCodec;
  if ( mCodec )
  {
    mCodec->mFile = 0;
    mCodec->mWaveFormatMemory = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225c6c0 | Name: _ZN4FMOD8DSPCodec15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPCodec::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225c6d0 | Name: _ZN4FMOD8DSPCodec16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPCodec::getDescriptionEx()
{
  *(&stru_2B061A0.mHandle + 1) = 1010;
  stru_2B061A0.mDescription = &stru_2870540;
  stru_2B061A0.mSize = 1328;
  return &stru_2B061A0;
}


// Address: 0x225c6f0 | Name: _ZN4FMOD8DSPCodec14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPCodec::createInternal(FMOD::DSPCodec *const this)
{
  this->mNoDMA = &this->mNoDMAMemory;
  FMOD::DSPResampler::createInternal(this);
  this->mContextSize = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x225c720 | Name: _ZN4FMOD8DSPCodec14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPCodec::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPCodec::createInternal((FMOD::DSPCodec *const)dsp_state->instance);
}


// Address: 0x225c730 | Name: _ZN4FMOD8DSPCodec12readInternalEPsPjS2_Pi
FMOD_RESULT_0 __fastcall FMOD::DSPCodec::readInternal(
        FMOD::DSPCodec *const this,
        __int16 *outbuffer,
        unsigned int *offset,
        unsigned int *length,
        int *outchannels)
{
  __int16 *v5; // r14
  unsigned int v7; // r15d
  int mChannels; // eax
  int v9; // r13d
  int v10; // r13d
  int mNewLoopCount; // eax
  unsigned int mLoopCountIncrement; // edx
  unsigned int v13; // r12d
  int v14; // ebp
  FMOD_RESULT_0 v15; // r10d
  unsigned int mCodecPosition; // eax
  unsigned int v17; // ebp
  FMOD::DSPResampler_NODMA *mNoDMA; // rax
  FMOD::Codec *mCodec; // rdi
  unsigned int v20; // r13d
  unsigned int v22; // edx
  unsigned int v23; // eax
  unsigned int v24; // r8d
  FMOD::DSPResampler_NODMA *v25; // rax
  int mLoopCount; // edx
  unsigned int mLoopStart; // ebp
  FMOD::Codec *v28; // rdi
  void (__fastcall *getcontextinfo)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  unsigned int bytespersample; // [rsp+Ch] [rbp-5Ch]
  unsigned int bytespersamplea; // [rsp+Ch] [rbp-5Ch]
  unsigned int bytespersampleb; // [rsp+Ch] [rbp-5Ch]
  unsigned int read; // [rsp+28h] [rbp-40h] BYREF
  unsigned int align[15]; // [rsp+2Ch] [rbp-3Ch] BYREF

  v5 = outbuffer;
  v7 = *length;
  mChannels = this->mDescription.mChannels;
  switch ( this->mOutputFormat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      v9 = 2;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      v9 = 3;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      v9 = 4;
LABEL_3:
      v10 = mChannels * v9;
      bytespersample = v10;
      if ( !this->mJob.mQueuedForDisconnect )
        goto LABEL_4;
      goto LABEL_22;
    default:
      v10 = this->mDescription.mChannels;
      bytespersample = v10;
      if ( this->mJob.mQueuedForDisconnect )
      {
LABEL_22:
        memset(outbuffer, 0, v7 * v10);
        return FMOD_RESULT::FMOD_OK_0;
      }
LABEL_4:
      *outchannels = mChannels;
      mNewLoopCount = this->mNewLoopCount;
      if ( mNewLoopCount >= -1 )
      {
        mLoopCountIncrement = this->mLoopCountIncrement;
        if ( mLoopCountIncrement > this->mLoopCountIncrementPrev )
        {
          this->mLoopCount = mNewLoopCount;
          this->mNewLoopCount = -2;
          this->mLoopCountIncrementPrev = mLoopCountIncrement;
        }
      }
      v13 = 0;
      if ( !v7 )
      {
        v15 = FMOD_RESULT::FMOD_OK_0;
        goto LABEL_43;
      }
      break;
  }
  while ( 1 )
  {
    mNoDMA = this->mNoDMA;
    read = 0;
    if ( (mNoDMA->mMode & 2) != 0 && this->mLoopCount )
    {
      v14 = mNoDMA->mLoopLength + mNoDMA->mLoopStart;
      v15 = FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
      mCodecPosition = this->mCodecPosition;
      v17 = v14 - 1;
      if ( v17 < mCodecPosition )
        goto LABEL_11;
    }
    else
    {
      mCodec = this->mCodec;
      if ( (mCodec->mFlags & 1) == 0 )
      {
        v17 = -1;
LABEL_24:
        v20 = v7;
LABEL_25:
        v15 = FMOD::Codec::read(mCodec, v5, v20, &read);
        v22 = v15 & 0xFFFFFFEF;
        if ( (v15 & 0xFFFFFFEF) != 0 )
          return v15;
        v23 = read;
        v24 = v20;
        this->mCodecPosition += read;
        v5 = (__int16 *)((char *)v5 + v23 * bytespersample);
        if ( v20 > v23 )
          v24 = v23;
        v13 += v24;
        if ( v23 <= v7 )
          v22 = v7 - v23;
        v7 = v22;
        if ( this->mDirection != DSPSOURCE_SPEEDDIR_BACKWARDS )
          goto LABEL_12;
        goto LABEL_31;
      }
      v15 = FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
      v17 = this->mLength - 1;
      mCodecPosition = this->mCodecPosition;
      if ( v17 < mCodecPosition )
        goto LABEL_11;
    }
    if ( v17 >= v7 + mCodecPosition )
    {
      mCodec = this->mCodec;
      goto LABEL_24;
    }
    v20 = v17 - mCodecPosition + 1;
    if ( v17 - mCodecPosition != -1 )
    {
      mCodec = this->mCodec;
      goto LABEL_25;
    }
LABEL_11:
    if ( this->mDirection != DSPSOURCE_SPEEDDIR_BACKWARDS )
      goto LABEL_12;
LABEL_31:
    if ( this->mCodecPosition == read )
      break;
LABEL_12:
    if ( v15 == FMOD_RESULT::FMOD_ERR_FILE_EOF_0 || this->mCodecPosition > v17 )
      break;
    if ( !v7 )
      goto LABEL_43;
  }
  v25 = this->mNoDMA;
  if ( (v25->mMode & 2) != 0 && (mLoopCount = this->mLoopCount) != 0 )
  {
    mLoopStart = v25->mLoopStart;
    this->mCodecPosition = mLoopStart;
    if ( mLoopCount > 0 )
      this->mLoopCount = mLoopCount - 1;
    v28 = this->mCodec;
    getcontextinfo = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v28->mDescription.getcontextinfo;
    if ( getcontextinfo )
    {
      bytespersamplea = v15;
      align[0] = 0;
      getcontextinfo(v28, 0, 0, align, 0, 0);
      v15 = bytespersamplea;
      if ( align[0] )
        mLoopStart = align[0] * (mLoopStart / align[0]);
      v28 = this->mCodec;
    }
    bytespersampleb = v15;
    FMOD::Codec::setPosition(v28, 0, mLoopStart, 2u);
    this->mCodecPosition = mLoopStart;
    v15 = bytespersampleb;
  }
  else
  {
    v15 = FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
    if ( v7 )
    {
      memset(v5, 0, v7 * bytespersample);
      v15 = FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
    }
  }
LABEL_43:
  *length = v13;
  return v15;
}


// Address: 0x225ca80 | Name: _ZN4FMOD8DSPCodec12readCallbackEP14FMOD_DSP_STATEPfPjS4_Pi
FMOD_RESULT_0 __fastcall FMOD::DSPCodec::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *outbuffer,
        unsigned int *offset,
        unsigned int *length,
        int *outchannels)
{
  return FMOD::DSPCodec::readInternal(
           (FMOD::DSPCodec *const)dsp_state->instance,
           (__int16 *)outbuffer,
           offset,
           length,
           outchannels);
}


// Address: 0x225ca90 | Name: _ZN4FMOD8DSPCodec5setupEPNS_6SoundIEPNS_15ChannelSoftwareE
FMOD_RESULT_0 __fastcall FMOD::DSPCodec::setup(
        FMOD::DSPCodec *const this,
        FMOD::SoundI *sound,
        FMOD::ChannelSoftware *channel)
{
  int channels; // r13d
  FMOD_SOUND_FORMAT_0 format; // r14d
  FMOD::DSPCodecPool *mPool; // r12
  FMOD_RESULT_0 result; // eax
  FMOD::Codec *mCodec; // rdi
  void (__fastcall *cleanupcontext)(FMOD::Codec *, void *); // rax
  FMOD::SystemI *mSystem; // rsi
  int (**vptr_SoundI)(...); // r8
  FMOD::FMOD_CODEC_FLAG mFlags; // eax
  FMOD::Codec *v14; // rdi
  unsigned int (__fastcall *getcontextinfo)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  unsigned int v16; // eax
  void *mContextMemory; // rsi
  unsigned int v18; // eax
  FMOD_SOUND_FORMAT_0 v19; // ecx
  __int64 v20; // rsi
  unsigned __int64 v21; // rdx
  FMOD::Codec *v22; // rdi
  unsigned int (__fastcall *setupcontext)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  int mLoopCount; // eax
  unsigned int mLoopStart; // edx
  FMOD::DSPResampler_NODMA *mNoDMA; // rax
  __int64 v27; // rcx
  void *mResampleBufferMemory; // rsi
  void *v29; // rax
  void *v30; // rax
  unsigned int contextsize; // [rsp+14h] [rbp-34h] BYREF
  unsigned int pcmblocksize; // [rsp+18h] [rbp-30h] BYREF
  FMOD_MEMORY_TYPE memtype[11]; // [rsp+1Ch] [rbp-2Ch] BYREF

  channels = this->mWaveFormat.channels;
  format = this->mWaveFormat.format;
  contextsize = 0;
  pcmblocksize = 0;
  memtype[0] = 0;
  mPool = this->mPool;
  result = FMOD::DSPSource::setup(this, sound, channel);
  if ( result )
    return result;
  mCodec = this->mCodec;
  cleanupcontext = (void (__fastcall *)(FMOD::Codec *, void *))mCodec->mDescription.cleanupcontext;
  if ( cleanupcontext && (mCodec->mFlags & 0x200) != 0 )
  {
    cleanupcontext(mCodec, this->mPool->mUserData);
    this->mCodec->mFlags &= ~0x200u;
  }
  result = sound->mCodec->mDescription.getwaveformat(sound->mCodec, sound->mSubSoundIndex, &this->mWaveFormat);
  if ( result )
    return result;
  mSystem = this->mSystem;
  vptr_SoundI = sound[1]._vptr_SoundI;
  mFlags = sound->mCodec->mFlags;
  BYTE1(mFlags) |= 1u;
  this->mCodec->mFlags = mFlags;
  result = FMOD::MemoryFile::init(&this->mMemoryFile, mSystem, sound->mLengthBytes, 0, vptr_SoundI);
  if ( result )
    return result;
  v14 = sound->mCodec;
  getcontextinfo = (unsigned int (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v14->mDescription.getcontextinfo;
  if ( getcontextinfo
    || (v14 = this->mCodec,
        (getcontextinfo = (unsigned int (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v14->mDescription.getcontextinfo) != 0) )
  {
    result = getcontextinfo(
               v14,
               (unsigned int)this->mWaveFormat.channels,
               &contextsize,
               &pcmblocksize,
               memtype,
               this->mPool->mUserData);
    if ( result )
      return result;
  }
  if ( pcmblocksize <= 1 )
  {
    result = FMOD::SystemI::getDSPBufferSize(this->mSystem, &pcmblocksize, 0);
    if ( result )
      return result;
  }
  else if ( pcmblocksize == -1 )
  {
    pcmblocksize = 0;
  }
  v16 = contextsize;
  if ( this->mContextSize != contextsize )
  {
    mContextMemory = this->mContextMemory;
    this->mContextSize = contextsize;
    if ( mContextMemory )
    {
      FMOD::MemPool::free(&mPool->mContextMemoryPool, mContextMemory, (const char *)&uri_string, 0);
      v16 = contextsize;
      this->mContextMemory = 0;
    }
    if ( v16 )
    {
      v29 = FMOD::MemPool::calloc(&mPool->mContextMemoryPool, this->mContextSize, (const char *)&uri_string, 0, 0);
      this->mContextMemory = v29;
      if ( !v29 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
  }
  v18 = pcmblocksize;
  if ( this->mResampleBufferLength != pcmblocksize )
  {
    v19 = this->mWaveFormat.format;
    LODWORD(v20) = this->mWaveFormat.channels;
LABEL_19:
    this->mResampleBufferLength = pcmblocksize;
    v21 = v18 + 8;
    switch ( v19 )
    {
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
        v27 = 8;
        goto LABEL_26;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
        v27 = 16;
        goto LABEL_26;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
        v27 = 24;
        goto LABEL_26;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
        v27 = 32;
LABEL_26:
        v21 = (v27 * v21) >> 3;
        break;
      default:
        break;
    }
    this->mResampleBufferLengthBytes = (v21 * v20 + 15) & 0xFFFFFFF0;
    mResampleBufferMemory = this->mResampleBufferMemory;
    if ( mResampleBufferMemory )
    {
      FMOD::MemPool::free(&mPool->mContextMemoryPool, mResampleBufferMemory, (const char *)&uri_string, 0);
      v18 = pcmblocksize;
      this->mResampleBufferMemory = 0;
      this->mResampleBuffer = 0;
    }
    if ( v18 )
    {
      v30 = FMOD::MemPool::calloc(
              &mPool->mContextMemoryPool,
              this->mResampleBufferLengthBytes + 16,
              (const char *)&uri_string,
              0,
              0);
      this->mResampleBufferMemory = v30;
      if ( !v30 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      this->mResampleBuffer = (void *)(((unsigned __int64)v30 + 15) & 0xFFFFFFFFFFFFFFF0LL);
    }
    v20 = (unsigned int)this->mWaveFormat.channels;
    goto LABEL_21;
  }
  v20 = (unsigned int)this->mWaveFormat.channels;
  v19 = this->mWaveFormat.format;
  if ( __PAIR64__(v20, v19) != __PAIR64__(channels, format) )
    goto LABEL_19;
LABEL_21:
  v22 = this->mCodec;
  setupcontext = (unsigned int (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v22->mDescription.setupcontext;
  if ( !setupcontext )
  {
LABEL_24:
    this->mDescription.mChannels = v20;
    this->mFillCallback = FMOD::DSPCodec::readCallback;
    this->mLength = sound->mLength;
    mLoopCount = sound->mLoopCount;
    this->mPosition.mValue = 0;
    this->mResamplePosition.mHi = 0;
    this->mResamplePosition.mLo = 0;
    mLoopStart = sound->mLoopStart;
    this->mLoopCount = mLoopCount;
    mNoDMA = this->mNoDMA;
    this->mResampleFilled = 0;
    mNoDMA->mLoopStart = mLoopStart;
    mNoDMA->mLoopLength = sound->mLoopLength;
    mNoDMA->mMode = sound->mMode;
    this->mJob.mInfo.mMixLength = 0;
    this->mNewLoopCount = -2;
    this->mJob.mInfo.mMixOffset = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  result = setupcontext(
             v22,
             v20,
             (unsigned int)this->mWaveFormat.frequency,
             (unsigned int)sound->mSubSoundIndex,
             this->mContextMemory,
             sound->mCodec,
             this->mPool->mUserData);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    LODWORD(v20) = this->mWaveFormat.channels;
    this->mCodec->mFlags |= 0x200u;
    goto LABEL_24;
  }
  return result;
}


// Address: 0x225cea0 | Name: _ZN4FMOD8DSPCodec7releaseEv
FMOD_RESULT_0 __fastcall FMOD::DSPCodec::release(FMOD::DSPCodec *const this)
{
  FMOD::Codec *mCodec; // rdi
  void (__fastcall *cleanupcontext)(FMOD::Codec *, void *); // rdx
  unsigned int (*close)(void); // rdx
  FMOD_RESULT_0 result; // eax

  mCodec = this->mCodec;
  if ( !mCodec )
    return FMOD::DSPI::release(this);
  cleanupcontext = (void (__fastcall *)(FMOD::Codec *, void *))mCodec->mDescription.cleanupcontext;
  if ( cleanupcontext && (mCodec->mFlags & 0x200) != 0 )
  {
    cleanupcontext(mCodec, this->mPool->mUserData);
    mCodec = this->mCodec;
    mCodec->mFlags &= ~0x200u;
  }
  close = (unsigned int (*)(void))mCodec->mDescription.close;
  if ( !close )
    return FMOD::DSPI::release(this);
  result = close();
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::DSPI::release(this);
  return result;
}


// Address: 0x225cf10 | Name: _ZN4FMOD8DSPCodec19setPositionInternalE14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::DSPCodec::setPositionInternal(FMOD::DSPCodec *const this, FMOD_UINT32_32 position)
{
  unsigned int mHi; // r12d
  FMOD_RESULT_0 result; // eax
  FMOD::Codec *mCodec; // rbp
  void (__fastcall *getcontextinfo)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  unsigned __int8 *mPCMBuffer; // rdi
  void (__fastcall *reset)(FMOD::Codec *); // rax
  unsigned int align[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  mHi = position.mHi;
  result = FMOD::DSPResampler::setPositionInternal(this, position);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mCodec = this->mCodec;
    align[0] = 0;
    getcontextinfo = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))mCodec->mDescription.getcontextinfo;
    if ( getcontextinfo )
    {
      getcontextinfo(mCodec, 0, 0, align, 0, 0);
      if ( align[0] )
        mHi = align[0] * (position.mHi / align[0]);
      mCodec = this->mCodec;
    }
    mPCMBuffer = mCodec->mPCMBuffer;
    mCodec->mPCMBufferOffset = 0;
    if ( mPCMBuffer )
      memset(mPCMBuffer, 0, mCodec->mPCMBufferLengthBytes);
    reset = (void (__fastcall *)(FMOD::Codec *))mCodec->mDescription.reset;
    if ( reset )
      reset(mCodec);
    FMOD::Codec::setPosition(this->mCodec, 0, mHi, 2u);
    if ( align[0] )
      this->mResamplePosition.mHi += position.mHi % align[0];
    this->mCodecPosition = mHi;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


