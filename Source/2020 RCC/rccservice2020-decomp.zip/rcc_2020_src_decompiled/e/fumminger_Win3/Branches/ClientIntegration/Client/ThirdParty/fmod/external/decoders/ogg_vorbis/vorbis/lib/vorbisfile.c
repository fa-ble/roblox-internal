// Address: 0x2272860 | Name: FMOD_ov_splice
void __fastcall FMOD_ov_splice(float **pcm, float **lappcm, int n1, int n2, int ch1, int ch2, float *w1, float *w2)
{
  __int64 v9; // rbp
  int v10; // ebx
  __int64 v11; // rax
  float *v12; // r11
  float *i; // rcx
  float v14; // xmm0_4
  float **v15; // rsi
  float **v16; // rdi
  __int64 v17; // rax
  float *j; // rcx

  if ( n1 > n2 )
  {
    w1 = w2;
    n1 = n2;
  }
  if ( ch1 <= 0 || ch2 <= 0 )
  {
    v10 = 0;
  }
  else
  {
    v9 = 0;
    v10 = 0;
    do
    {
      v11 = 0;
      v12 = lappcm[v9];
      for ( i = pcm[v9]; n1 > (int)v11; ++v11 )
      {
        v14 = w1[v11] * w1[v11];
        i[v11] = (float)(i[v11] * v14) + (float)(v12[v11] * (float)(1.0 - v14));
      }
      ++v10;
      ++v9;
    }
    while ( ch2 > v10 && ch1 > v10 );
  }
  if ( ch2 > v10 )
  {
    v15 = &pcm[v10];
    v16 = &pcm[ch2 - 1 - v10] + (__int64)v10 + 1;
    do
    {
      v17 = 0;
      for ( j = *v15; n1 > (int)v17; ++v17 )
        j[v17] = (float)(w1[v17] * w1[v17]) * j[v17];
      ++v15;
    }
    while ( v15 != v16 );
  }
}


// Address: 0x2272950 | Name: _decode_clear
void __fastcall decode_clear(void *context, OggVorbis_File *vf)
{
  FMOD_vorbis_dsp_clear(context, &vf->vd);
  FMOD_vorbis_block_clear(context, &vf->vb);
  vf->ready_state = 2;
}


// Address: 0x2272990 | Name: _get_next_page
ogg_int64_t_0 __fastcall get_next_page(void *context, OggVorbis_File *vf, ogg_page *og, ogg_int64_t_0 boundary)
{
  ogg_int64_t_0 v5; // rbp
  ogg_int32_t v6; // eax
  __int64 v7; // r12
  int *v8; // rax
  bool v9; // zf
  int *v10; // r12
  char *v11; // rax
  ogg_int32_t v12; // eax
  int v13; // edx
  ogg_int64_t_0 result; // rax
  ogg_int32_t v15; // [rsp+8h] [rbp-40h]

  v5 = boundary;
  if ( boundary > 0 )
    v5 = vf->offset + boundary;
  while ( 1 )
  {
    while ( 1 )
    {
      if ( v5 > 0 && vf->offset >= v5 )
        return -1;
      v6 = FMOD_ogg_sync_pageseek(&vf->oy, og);
      v7 = v6;
      if ( v6 >= 0 )
        break;
      Roblox_SetCodecParsingAnomaly(context, 1);
      if ( !Roblox_ParsingChecksDisabled(context) )
        return -1;
      vf->offset -= v7;
    }
    if ( v6 )
    {
      result = vf->offset;
      vf->offset = result + v7;
      return result;
    }
    if ( !v5 )
      return -1;
    v8 = __errno_location();
    v9 = vf->callbacks.read_func == 0;
    v10 = v8;
    *v8 = 0;
    if ( v9 )
      return -128;
    if ( !vf->datasource )
      return -2;
    v11 = FMOD_ogg_sync_buffer(context, &vf->oy, 8500);
    if ( !v11 )
      return -139;
    v12 = vf->callbacks.read_func(v11, 1, 8500, vf->datasource);
    v13 = v12;
    if ( v12 > 0 )
    {
      v15 = v12;
      FMOD_ogg_sync_wrote(&vf->oy, v12);
      v13 = v15;
      goto LABEL_13;
    }
    if ( !v12 )
      break;
    if ( v12 == -139 )
      return -139;
LABEL_13:
    if ( v13 < 0 )
      return -128;
  }
  if ( *v10 )
    return -128;
  return -2;
}


// Address: 0x2272b20 | Name: _initial_pcmoffset
ogg_int64_t_0 __fastcall initial_pcmoffset(void *context, OggVorbis_File *vf, vorbis_info_0 *vi)
{
  ogg_stream_state *p_os; // rbp
  ogg_int32_t serialno; // r15d
  int v5; // eax
  ogg_int64_t_0 result; // rax
  ogg_int32_t v7; // eax
  ogg_int32_t lastblock; // [rsp+Ch] [rbp-9Ch]
  ogg_int64_t_0 accumulated; // [rsp+10h] [rbp-98h]
  ogg_page og; // [rsp+20h] [rbp-88h] BYREF
  ogg_packet_0 op; // [rsp+40h] [rbp-68h] BYREF

  p_os = &vf->os;
  serialno = vf->os.serialno;
  lastblock = -1;
  accumulated = 0;
  while ( get_next_page(context, vf, &og, -1) >= 0 && !FMOD_ogg_page_bos(&og) )
  {
    if ( FMOD_ogg_page_serialno(&og) == serialno )
    {
      FMOD_ogg_stream_pagein(context, p_os, &og);
      while ( 1 )
      {
        v5 = FMOD_ogg_stream_packetout(p_os, (ogg_packet *)&op);
        if ( !v5 )
          break;
        if ( v5 > 0 )
        {
          v7 = FMOD_vorbis_packet_blocksize(vi, (ogg_packet *)&op);
          if ( lastblock != -1 )
            accumulated += (v7 + lastblock) >> 2;
          lastblock = v7;
        }
      }
      if ( FMOD_ogg_page_granulepos(&og) != -1 )
      {
        accumulated = FMOD_ogg_page_granulepos(&og) - accumulated;
        break;
      }
    }
  }
  result = 0;
  if ( accumulated >= 0 )
    return accumulated;
  return result;
}


// Address: 0x2272c40 | Name: _seek_helper
int __fastcall seek_helper(OggVorbis_File *vf, ogg_int64_t_0 offset)
{
  void *datasource; // rdi
  int (*seek_func)(void *, ogg_int64_t_0, int); // rax

  datasource = vf->datasource;
  if ( !datasource )
    return -129;
  seek_func = vf->callbacks.seek_func;
  if ( !seek_func || seek_func(datasource, offset, 0) == -1 )
    return -128;
  vf->offset = offset;
  FMOD_ogg_sync_reset(&vf->oy);
  return 0;
}


// Address: 0x2272c90 | Name: _get_prev_page_serial
ogg_int64_t_0 __fastcall get_prev_page_serial(
        void *context,
        OggVorbis_File *vf,
        ogg_int32_t *serial_list,
        int serial_n,
        int *serialno,
        ogg_int64_t_0 *granpos)
{
  ogg_int32_t *v7; // r15
  ogg_int64_t_0 v8; // rax
  ogg_int64_t_0 result; // rax
  ogg_int64_t_0 offset; // rax
  ogg_int32_t *v11; // r13
  __int64 v12; // r15
  ogg_int64_t_0 v13; // r14
  int v14; // r15d
  ogg_int32_t *v15; // rdx
  ogg_int64_t_0 v16; // r14
  ogg_int64_t_0 end; // [rsp+8h] [rbp-A0h]
  int ret_serialno; // [rsp+10h] [rbp-98h]
  ogg_int64_t_0 ret_gran; // [rsp+18h] [rbp-90h]
  ogg_int64_t_0 prefoffset; // [rsp+30h] [rbp-78h]
  ogg_int64_t_0 begin; // [rsp+48h] [rbp-60h]
  ogg_page og; // [rsp+50h] [rbp-58h] BYREF

  end = vf->offset;
  begin = end;
  ret_gran = -1;
  ret_serialno = -1;
  prefoffset = -1;
  v7 = &serial_list[serial_n - 1 + 1];
  while ( 1 )
  {
    v8 = 0;
    if ( begin - 8500 >= 0 )
      v8 = begin - 8500;
    begin = v8;
    result = seek_helper(vf, v8);
    if ( (_DWORD)result )
      return result;
    offset = vf->offset;
    v11 = v7;
    v12 = -1;
    if ( end > offset )
    {
      while ( 1 )
      {
        result = get_next_page(context, vf, &og, end - offset);
        v13 = result;
        if ( result == -128 || result == -139 )
          return result;
        if ( result < 0 )
          goto LABEL_19;
        v14 = FMOD_ogg_page_serialno(&og);
        ret_serialno = v14;
        ret_gran = FMOD_ogg_page_granulepos(&og);
        if ( *serialno == (__int64)v14 )
        {
          prefoffset = v13;
          *granpos = ret_gran;
        }
        if ( !serial_list || !serial_n )
          goto LABEL_17;
        if ( v14 != *serial_list )
          break;
LABEL_18:
        offset = vf->offset;
        v12 = v13;
        if ( end <= offset )
          goto LABEL_19;
      }
      v15 = serial_list;
      while ( ++v15 != v11 )
      {
        if ( v14 == *v15 )
          goto LABEL_18;
      }
LABEL_17:
      prefoffset = -1;
      goto LABEL_18;
    }
LABEL_19:
    v16 = v12;
    v7 = v11;
    if ( v16 != -1 )
    {
      result = prefoffset;
      if ( prefoffset == -1 )
      {
        *serialno = ret_serialno;
        *granpos = ret_gran;
        return v16;
      }
      return result;
    }
  }
}


// Address: 0x2272e60 | Name: _make_decode_ready
int __fastcall make_decode_ready(void *context, OggVorbis_File *vf)
{
  int result; // eax
  vorbis_info_0 *vi; // rdx
  int v4; // eax

  result = 0;
  if ( vf->ready_state <= 3 )
  {
    if ( vf->ready_state != 3 )
      return -129;
    if ( vf->seekable )
      vi = &vf->vi[vf->current_link];
    else
      vi = vf->vi;
    v4 = FMOD_vorbis_synthesis_init(context, &vf->vd, vi);
    if ( v4 == -139 )
      return -139;
    if ( v4 )
      return -137;
    result = FMOD_vorbis_block_init(context, &vf->vd, &vf->vb);
    if ( result )
      return -139;
    vf->ready_state = 4;
    vf->bittrack = 0.0;
    vf->samptrack = 0.0;
  }
  return result;
}


// Address: 0x2272f20 | Name: _fetch_headers
int __fastcall fetch_headers(
        void *context,
        OggVorbis_File *vf,
        vorbis_info_0 *vi,
        vorbis_comment *vc,
        ogg_int32_t **serialno_list,
        int *serialno_n,
        ogg_page *og_ptr)
{
  ogg_page *p_og; // rbx
  ogg_int32_t *v11; // r15
  int v12; // eax
  __int64 v13; // rcx
  int v14; // r15d
  ogg_int32_t *v15; // rsi
  int v16; // edx
  bool v17; // zf
  ogg_int32_t *v18; // rax
  int v19; // eax
  ogg_int64_t_0 v20; // rax
  ogg_int32_t serialno; // r15d
  int v22; // r12d
  int i; // eax
  int v24; // r15d
  ogg_int32_t v25; // r15d
  ogg_int64_t_0 next_page; // rax
  int v28; // [rsp+0h] [rbp-B8h]
  ogg_stream_state *p_os; // [rsp+0h] [rbp-B8h]
  int allbos; // [rsp+8h] [rbp-B0h]
  ogg_stream_state *os; // [rsp+10h] [rbp-A8h]
  int v33; // [rsp+24h] [rbp-94h]
  ogg_page og; // [rsp+30h] [rbp-88h] BYREF
  ogg_packet_0 op; // [rsp+50h] [rbp-68h] BYREF

  p_og = og_ptr;
  if ( !og_ptr )
  {
    p_og = &og;
    next_page = get_next_page(context, vf, &og, 8500);
    if ( next_page == -128 )
      return -128;
    if ( next_page == -139 )
      return -139;
    if ( next_page < 0 )
      return -132;
  }
  v33 = FMOD_vorbis_info_init(context, vi);
  if ( v33 )
    return -139;
  FMOD_vorbis_comment_init(vc);
  vf->ready_state = 2;
  os = &vf->os;
  while ( FMOD_ogg_page_bos(p_og) )
  {
    if ( serialno_list )
    {
      v11 = *serialno_list;
      v28 = *serialno_n;
      v12 = FMOD_ogg_page_serialno(p_og);
      if ( v11 && v28 )
      {
        if ( v12 == *v11 )
        {
LABEL_38:
          if ( *serialno_list )
            FMOD_OggVorbis_Free(context, *serialno_list);
          *serialno_list = 0;
          v24 = -133;
          *serialno_n = 0;
          goto bail_header;
        }
        v13 = (__int64)&v11[v28 - 1 + 1];
        while ( ++v11 != (ogg_int32_t *)v13 )
        {
          if ( v12 == *v11 )
            goto LABEL_38;
        }
      }
      v14 = FMOD_ogg_page_serialno(p_og);
      v15 = *serialno_list;
      v16 = *serialno_n + 1;
      v17 = *serialno_list == 0;
      *serialno_n = v16;
      if ( v17 )
        v18 = (ogg_int32_t *)FMOD_OggVorbis_Malloc(context, 4);
      else
        v18 = (ogg_int32_t *)FMOD_OggVorbis_ReAlloc(context, v15, 4 * v16);
      *serialno_list = v18;
      if ( !v18 )
        return -139;
      v18[*serialno_n - 1] = v14;
    }
    if ( vf->ready_state <= 2 )
    {
      v19 = FMOD_ogg_page_serialno(p_og);
      FMOD_ogg_stream_reset_serialno(os, v19);
      FMOD_ogg_stream_pagein(context, os, p_og);
      if ( FMOD_ogg_stream_packetout(os, (ogg_packet *)&op) > 0 )
      {
        if ( FMOD_vorbis_synthesis_idheader((ogg_packet *)&op) )
        {
          vf->ready_state = 3;
          if ( FMOD_vorbis_synthesis_headerin(context, vi, vc, (ogg_packet *)&op) )
            goto LABEL_45;
        }
      }
    }
    v20 = get_next_page(context, vf, p_og, 8500);
    if ( v20 == -128 || v20 == -139 )
    {
      v24 = v20;
      goto bail_header;
    }
    if ( v20 < 0 )
      goto LABEL_47;
    if ( vf->ready_state == 3 )
    {
      serialno = vf->os.serialno;
      if ( serialno == FMOD_ogg_page_serialno(p_og) )
      {
        FMOD_ogg_stream_pagein(context, &vf->os, p_og);
        break;
      }
    }
  }
  if ( vf->ready_state == 3 )
  {
    allbos = 0;
    v22 = 0;
    p_os = &vf->os;
    for ( i = FMOD_ogg_stream_packetout(&vf->os, (ogg_packet *)&op);
          i;
          i = FMOD_ogg_stream_packetout(p_os, (ogg_packet *)&op) )
    {
      if ( i == -1 )
        goto LABEL_45;
      v24 = FMOD_vorbis_synthesis_headerin(context, vi, vc, (ogg_packet *)&op);
      if ( v24 )
        goto bail_header;
      if ( v22 )
        return v33;
      v22 = 1;
LABEL_31:
      ;
    }
    while ( get_next_page(context, vf, p_og, 8500) >= 0 )
    {
      v25 = vf->os.serialno;
      if ( v25 == FMOD_ogg_page_serialno(p_og) )
      {
        FMOD_ogg_stream_pagein(context, p_os, p_og);
        goto LABEL_31;
      }
      if ( FMOD_ogg_page_bos(p_og) )
      {
        if ( allbos )
          break;
        allbos = 1;
      }
    }
LABEL_45:
    v24 = -133;
    goto bail_header;
  }
LABEL_47:
  v24 = -132;
bail_header:
  FMOD_vorbis_info_clear(context, vi);
  FMOD_vorbis_comment_clear(context, vc);
  vf->ready_state = 2;
  return v24;
}


// Address: 0x2273310 | Name: _bisect_forward_serialno
int __fastcall bisect_forward_serialno(
        void *context,
        OggVorbis_File *vf,
        ogg_int64_t_0 begin,
        ogg_int64_t_0 searched,
        ogg_int64_t_0 end,
        ogg_int64_t_0 endgran,
        int endserial,
        ogg_int32_t *currentno_list,
        int currentnos,
        ogg_int32_t m)
{
  ogg_int64_t_0 v10; // r13
  ogg_int64_t_0 v11; // rbp
  ogg_int32_t v13; // r15d
  ogg_int32_t *v14; // rax
  ogg_int64_t_0 v15; // r14
  ogg_int32_t *v16; // r15
  ogg_int32_t *v17; // rbp
  ogg_int64_t_0 v18; // r12
  ogg_int64_t_0 *next_page; // rax
  int v20; // eax
  ogg_int32_t *v21; // rdx
  ogg_int32_t *v22; // r14
  int v23; // r12d
  ogg_int64_t_0 v24; // rax
  bool v25; // zf
  ogg_int32_t *v26; // r14
  int v27; // r12d
  ogg_int64_t_0 prev_page_serial; // rax
  ogg_int64_t_0 *offsets; // rsi
  ogg_int32_t *serialnos; // rsi
  ogg_int64_t_0 *dataoffsets; // rsi
  ogg_int64_t_0 *v32; // rax
  vorbis_info_0 *v33; // rax
  vorbis_comment *v34; // rax
  ogg_int32_t *v35; // rax
  ogg_int64_t_0 *v36; // rax
  ogg_int64_t_0 *v37; // rdx
  __int64 v38; // rcx
  ogg_int32_t v39; // r12d
  ogg_int64_t_0 v40; // r13
  ogg_int64_t_0 v41; // rbp
  vorbis_info_0 *vi; // rsi
  __int64 v43; // rcx
  ogg_int32_t v44; // edi
  vorbis_info_0 *v45; // rdx
  ogg_int64_t_0 v46; // rdi
  ogg_int64_t_0 *pcmlengths; // rdx
  __int64 v48; // rcx
  ogg_int64_t_0 last; // [rsp+38h] [rbp-F0h]
  ogg_int64_t_0 offset; // [rsp+40h] [rbp-E8h]
  int serialno; // [rsp+54h] [rbp-D4h]
  ogg_int64_t_0 endgrana[2]; // [rsp+58h] [rbp-D0h] BYREF
  int next_serialnos; // [rsp+6Ch] [rbp-BCh] BYREF
  ogg_int64_t_0 searchgran; // [rsp+70h] [rbp-B8h] BYREF
  ogg_int32_t *next_serialno_list; // [rsp+78h] [rbp-B0h] BYREF
  ogg_page og; // [rsp+80h] [rbp-A8h] BYREF
  vorbis_comment vc; // [rsp+A0h] [rbp-88h] BYREF
  _QWORD testserial[13]; // [rsp+C0h] [rbp-68h] BYREF

  v10 = searched;
  v11 = begin;
  v13 = vf->os.serialno;
  endgrana[0] = endgran;
  searchgran = -1;
  if ( currentno_list && currentnos )
  {
    if ( endserial == *currentno_list )
    {
LABEL_31:
      if ( v13 != endserial )
      {
        v26 = currentno_list;
        v27 = currentnos;
        do
        {
          endserial = v13;
          prev_page_serial = get_prev_page_serial(context, vf, v26, v27, &endserial, endgrana);
          v25 = endserial == v13;
          vf->offset = prev_page_serial;
        }
        while ( !v25 );
        v11 = begin;
      }
      offsets = vf->offsets;
      vf->links = m + 1;
      if ( offsets )
      {
        FMOD_OggVorbis_Free(context, offsets);
        vf->offsets = 0;
      }
      serialnos = vf->serialnos;
      if ( serialnos )
      {
        FMOD_OggVorbis_Free(context, serialnos);
        vf->serialnos = 0;
      }
      dataoffsets = vf->dataoffsets;
      if ( dataoffsets )
      {
        FMOD_OggVorbis_Free(context, dataoffsets);
        vf->dataoffsets = 0;
      }
      v32 = (ogg_int64_t_0 *)FMOD_OggVorbis_Malloc(context, 8 * vf->links + 8);
      vf->offsets = v32;
      if ( !v32 )
        goto LABEL_52;
      v33 = (vorbis_info_0 *)FMOD_OggVorbis_ReAlloc(context, vf->vi, 40 * vf->links);
      vf->vi = v33;
      if ( !v33 )
        goto LABEL_52;
      v34 = (vorbis_comment *)FMOD_OggVorbis_ReAlloc(context, vf->vc, 32 * vf->links);
      vf->vc = v34;
      if ( !v34 )
        goto LABEL_52;
      v35 = (ogg_int32_t *)FMOD_OggVorbis_Malloc(context, 4 * vf->links);
      vf->serialnos = v35;
      if ( v35
        && (v36 = (ogg_int64_t_0 *)FMOD_OggVorbis_Malloc(context, 8 * vf->links), (vf->dataoffsets = v36) != 0)
        && (next_page = (ogg_int64_t_0 *)FMOD_OggVorbis_Malloc(context, 16 * vf->links),
            (vf->pcmlengths = next_page) != 0) )
      {
        v37 = vf->offsets;
        v38 = m + 1LL;
        v37[v38] = end;
        v37[v38 - 1] = v11;
        next_page[2 * m + 1] = endgrana[0];
        LODWORD(next_page) = 0;
      }
      else
      {
LABEL_52:
        LODWORD(next_page) = -139;
      }
      return (int)next_page;
    }
    v14 = currentno_list;
    while ( ++v14 != &currentno_list[currentnos - 1 + 1] )
    {
      if ( endserial == *v14 )
        goto LABEL_31;
    }
  }
  next_serialno_list = 0;
  next_serialnos = 0;
  if ( searched < end )
  {
    v15 = end;
    serialno = v13;
    offset = end;
    v16 = currentno_list;
    v17 = &currentno_list[currentnos - 1 + 1];
    while ( 1 )
    {
      v18 = v10;
      if ( v15 - v10 > 8499 )
        v18 = (v10 + v15) / 2;
      LODWORD(next_page) = seek_helper(vf, v18);
      if ( (_DWORD)next_page )
        return (int)next_page;
      next_page = (ogg_int64_t_0 *)get_next_page(context, vf, &og, -1);
      if ( next_page == (ogg_int64_t_0 *)-128LL )
        return (int)next_page;
      last = (ogg_int64_t_0)next_page;
      if ( (__int64)next_page >= 0 )
      {
        v20 = FMOD_ogg_page_serialno(&og);
        if ( v16 && currentnos )
        {
          if ( v20 == *v16 )
          {
LABEL_30:
            v10 = og.header_len + last + og.body_len;
            goto LABEL_22;
          }
          v21 = v16;
          while ( ++v21 != v17 )
          {
            if ( v20 == *v21 )
              goto LABEL_30;
          }
        }
        offset = last;
      }
      v15 = v18;
LABEL_22:
      if ( v15 <= v10 )
      {
        v13 = serialno;
        goto LABEL_24;
      }
    }
  }
  offset = end;
LABEL_24:
  v22 = currentno_list;
  v23 = currentnos;
  vf->offset = offset;
  do
  {
    LODWORD(testserial[0]) = v13;
    v24 = get_prev_page_serial(context, vf, v22, v23, (int *)testserial, &searchgran);
    v25 = LODWORD(testserial[0]) == v13;
    vf->offset = v24;
  }
  while ( !v25 );
  if ( v24 == offset || (LODWORD(next_page) = seek_helper(vf, offset), !(_DWORD)next_page) )
  {
    LODWORD(next_page) = fetch_headers(
                           context,
                           vf,
                           (vorbis_info_0 *)testserial,
                           &vc,
                           &next_serialno_list,
                           &next_serialnos,
                           0);
    if ( !(_DWORD)next_page )
    {
      v39 = vf->os.serialno;
      v40 = vf->offset;
      v41 = initial_pcmoffset(context, vf, (vorbis_info_0 *)testserial);
      LODWORD(next_page) = bisect_forward_serialno(
                             context,
                             vf,
                             offset,
                             vf->offset,
                             end,
                             endgrana[0],
                             endserial,
                             next_serialno_list,
                             next_serialnos,
                             m + 1);
      if ( !(_DWORD)next_page )
      {
        if ( next_serialno_list )
        {
          FMOD_OggVorbis_Free(context, next_serialno_list);
          LODWORD(next_page) = 0;
        }
        vi = vf->vi;
        v43 = m + 1LL;
        vf->offsets[v43] = offset;
        v44 = m;
        vf->serialnos[v43] = v39;
        vf->dataoffsets[v43] = v40;
        v45 = &vi[v43];
        *(_QWORD *)&v45->version = testserial[0];
        *(_QWORD *)&v45->rate = testserial[1];
        *(_QWORD *)&v45->bitrate_nominal = testserial[2];
        *(_QWORD *)&v45->bitrate_window = testserial[3];
        v45->codec_setup = (void *)testserial[4];
        LODWORD(vi) = 2 * v44;
        v46 = searchgran;
        vf->vc[v43] = vc;
        pcmlengths = vf->pcmlengths;
        v48 = (int)vi + 1LL;
        pcmlengths[v48] = v46;
        pcmlengths[(int)vi + 2] = v41;
        pcmlengths[v48 + 2] -= v41;
      }
    }
  }
  return (int)next_page;
}


// Address: 0x22738e0 | Name: _fetch_and_process_packet
int __fastcall fetch_and_process_packet(void *context, OggVorbis_File *vf, ogg_packet *op_in, int readp, int spanp)
{
  ogg_stream_state *p_os; // r14
  int ready_state; // eax
  int v8; // eax
  ogg_int32_t current_serialno; // r15d
  int result; // eax
  ogg_int64_t_0 granulepos; // r15
  int v12; // eax
  int v13; // eax
  ogg_int32_t v14; // eax
  int links; // esi
  ogg_int32_t *serialnos; // rcx
  ogg_int32_t *v17; // rcx
  int v18; // edx
  ogg_int32_t serialno; // eax
  int v20; // edx
  float v21; // xmm0_4
  int v22; // eax
  float v23; // xmm0_4
  int current_link; // r12d
  __int64 v25; // r13
  __int64 v26; // r15
  int v27; // eax
  ogg_int64_t_0 *pcmlengths; // rsi
  ogg_int64_t_0 v29; // rdx
  ogg_int64_t_0 *v30; // rax
  ogg_int64_t_0 v31; // r12
  vorbis_block_0 *vb; // [rsp+10h] [rbp-98h]
  float vba; // [rsp+10h] [rbp-98h]
  int spanpa; // [rsp+1Ch] [rbp-8Ch]
  ogg_page og; // [rsp+20h] [rbp-88h] BYREF
  ogg_packet_0 op; // [rsp+40h] [rbp-68h] BYREF

  p_os = &vf->os;
  spanpa = (int)op_in;
  vb = &vf->vb;
LABEL_2:
  ready_state = vf->ready_state;
  if ( ready_state == 3 )
    goto LABEL_15;
  while ( ready_state != 4 )
  {
LABEL_4:
    if ( ready_state <= 1 )
    {
LABEL_24:
      if ( vf->seekable )
      {
        v14 = FMOD_ogg_page_serialno(&og);
        links = vf->links;
        if ( links <= 0 )
        {
          if ( !links )
            goto LABEL_2;
        }
        else
        {
          serialnos = vf->serialnos;
          if ( v14 != *serialnos )
          {
            v17 = serialnos + 1;
            v18 = 0;
            while ( ++v18 != links )
            {
              if ( v14 == *v17++ )
                goto LABEL_30;
            }
            goto LABEL_2;
          }
        }
        v18 = 0;
LABEL_30:
        vf->current_serialno = v14;
        vf->current_link = v18;
        FMOD_ogg_stream_reset_serialno(p_os, v14);
        vf->ready_state = 3;
      }
      else
      {
        result = fetch_headers(context, vf, vf->vi, vf->vc, 0, 0, &og);
        if ( result )
          return result;
        serialno = vf->os.serialno;
        ++vf->current_link;
        vf->current_serialno = serialno;
      }
    }
    else
    {
      do
      {
        if ( get_next_page(context, vf, &og, -1) < 0 )
          return -2;
        v8 = vf->ready_state;
        vf->bittrack = (float)(8 * og.header_len) + vf->bittrack;
        if ( v8 != 4 )
          goto LABEL_13;
        current_serialno = vf->current_serialno;
        if ( current_serialno == FMOD_ogg_page_serialno(&og) )
          goto LABEL_12;
      }
      while ( !FMOD_ogg_page_bos(&og) );
      if ( !spanpa )
        return -2;
      decode_clear(context, vf);
      if ( !vf->seekable )
      {
        FMOD_vorbis_info_clear(context, vf->vi);
        FMOD_vorbis_comment_clear(context, vf->vc);
      }
LABEL_12:
      v8 = vf->ready_state;
LABEL_13:
      if ( v8 <= 2 )
        goto LABEL_24;
    }
    FMOD_ogg_stream_pagein(context, p_os, &og);
    ready_state = vf->ready_state;
    if ( ready_state == 3 )
    {
LABEL_15:
      result = make_decode_ready(context, vf);
      if ( result < 0 )
        return result;
      ready_state = vf->ready_state;
    }
  }
  do
  {
    v13 = FMOD_ogg_stream_packetout(p_os, (ogg_packet *)&op);
    if ( v13 == -1 )
      return -3;
    if ( v13 == -139 )
      return -139;
    if ( v13 <= 0 )
    {
      ready_state = vf->ready_state;
      goto LABEL_4;
    }
    granulepos = op.granulepos;
    v12 = FMOD_vorbis_synthesis(context, vb, (ogg_packet *)&op);
    if ( v12 == -139 )
      return -139;
  }
  while ( v12 );
  v20 = FMOD_vorbis_synthesis_pcmout(&vf->vd, 0);
  result = -129;
  if ( !v20 )
  {
    FMOD_vorbis_synthesis_blockin(&vf->vd, vb);
    vba = vf->samptrack;
    v21 = (float)FMOD_vorbis_synthesis_pcmout(&vf->vd, 0);
    v22 = 8 * op.bytes;
    vf->samptrack = v21 + vba;
    v23 = (float)v22;
    result = 1;
    vf->bittrack = v23 + vf->bittrack;
    if ( granulepos != -1 && !op.e_o_s )
    {
      if ( vf->seekable && (current_link = vf->current_link, current_link > 0) )
      {
        v25 = 0;
        v26 = granulepos - vf->pcmlengths[2 * current_link];
        if ( v26 >= 0 )
          v25 = v26;
        v27 = FMOD_vorbis_synthesis_pcmout(&vf->vd, 0);
        pcmlengths = vf->pcmlengths;
        v29 = v25 - v27;
        v30 = pcmlengths + 1;
        do
        {
          v29 += *v30;
          v30 += 2;
        }
        while ( v30 != &pcmlengths[2 * (unsigned int)(current_link - 1) + 3] );
      }
      else
      {
        v31 = 0;
        if ( granulepos >= 0 )
          v31 = granulepos;
        v29 = v31 - FMOD_vorbis_synthesis_pcmout(&vf->vd, 0);
      }
      vf->pcm_offset = v29;
      return 1;
    }
  }
  return result;
}


// Address: 0x2273cb0 | Name: FMOD_ov_getlap
void __fastcall FMOD_ov_getlap(
        void *context,
        OggVorbis_File *vf,
        vorbis_info_0 *vi,
        vorbis_dsp_state_0 *vd,
        float **lappcm,
        int lapsize)
{
  int v8; // eax
  int v9; // ecx
  int v10; // r8d
  __int64 v11; // r14
  int v12; // r15d
  float *v13; // rdi
  float *v14; // rsi
  int v15; // eax
  int v16; // ebp
  float *v17; // rdi
  __int64 v18; // rbp
  int v19; // r12d
  size_t v20; // r14
  float *v21; // rdi
  float *v22; // rsi
  int lapcount; // [rsp+4h] [rbp-74h]
  int samples; // [rsp+8h] [rbp-70h]
  float **pcm[8]; // [rsp+38h] [rbp-40h] BYREF

  lapcount = 0;
  if ( lapsize <= 0 )
    return;
  while ( 1 )
  {
    v8 = FMOD_vorbis_synthesis_pcmout(vd, pcm);
    if ( v8 )
    {
      if ( lapsize - lapcount <= v8 )
        v8 = lapsize - lapcount;
      samples = v8;
      if ( vi->version > 0 )
      {
        v11 = 0;
        v12 = 0;
        do
        {
          v13 = &lappcm[v11][lapcount];
          ++v12;
          v14 = pcm[0][v11++];
          memcpy_0(v13, v14, 4LL * samples);
        }
        while ( v12 < vi->version );
      }
      lapcount += samples;
      FMOD_vorbis_synthesis_read(vd, samples);
      goto LABEL_9;
    }
    if ( fetch_and_process_packet(context, vf, 0, v9, v10) == -2 )
      break;
LABEL_9:
    if ( lapsize <= lapcount )
      return;
  }
  v15 = FMOD_vorbis_synthesis_lapout(&vf->vd, pcm);
  if ( v15 )
  {
    if ( lapsize - lapcount <= v15 )
      v15 = lapsize - lapcount;
    if ( vi->version > 0 )
    {
      v18 = 0;
      v19 = 0;
      v20 = 4LL * v15;
      do
      {
        v21 = &lappcm[v18][lapcount];
        ++v19;
        v22 = pcm[0][v18++];
        memcpy_0(v21, v22, v20);
      }
      while ( v19 < vi->version );
    }
  }
  else if ( vi->version > 0 )
  {
    v16 = 0;
    do
    {
      v17 = &(*lappcm)[lapcount];
      ++v16;
      ++lappcm;
      memset(v17, 0, 4LL * lapsize - lapcount);
    }
    while ( v16 < vi->version );
  }
}


// Address: 0x2273e90 | Name: FMOD_ov_initprime
int __fastcall FMOD_ov_initprime(void *context, OggVorbis_File *vf)
{
  int v2; // ecx
  int v3; // r8d
  int result; // eax

  while ( vf->ready_state != 4 || !FMOD_vorbis_synthesis_pcmout(&vf->vd, 0) )
  {
    result = fetch_and_process_packet(context, vf, 0, v2, v3);
    if ( result != -3 && result < 0 )
      return result;
  }
  return 0;
}


// Address: 0x2273ef0 | Name: FMOD_ov_initset
int __fastcall FMOD_ov_initset(void *context, OggVorbis_File *vf)
{
  int v2; // ecx
  int v3; // r8d
  int result; // eax

  while ( vf->ready_state != 4 )
  {
    result = fetch_and_process_packet(context, vf, 0, v2, v3);
    if ( result != -3 && result < 0 )
      return result;
  }
  return 0;
}


// Address: 0x2273f40 | Name: FMOD_ov_clear
int __fastcall FMOD_ov_clear(void *context, OggVorbis_File *vf)
{
  vorbis_info_0 *vi; // rsi
  ogg_int64_t_0 *dataoffsets; // rsi
  ogg_int64_t_0 *pcmlengths; // rsi
  ogg_int32_t *serialnos; // rsi
  ogg_int64_t_0 *offsets; // rsi
  void (*close_func)(void); // rax
  OggVorbis_File *v9; // rdi
  unsigned int v10; // edx
  __int64 v11; // rcx
  void **v12; // rdi
  __int64 v14; // r13
  __int64 v15; // rbp
  vorbis_info_0 *v16; // rsi

  if ( !vf )
    return 0;
  FMOD_vorbis_block_clear(context, &vf->vb);
  FMOD_vorbis_dsp_clear(context, &vf->vd);
  FMOD_ogg_stream_clear(context, &vf->os);
  vi = vf->vi;
  if ( vi && vf->links )
  {
    if ( vf->links > 0 )
    {
      v14 = 0;
      v15 = 0;
      do
      {
        v16 = &vi[v14++];
        FMOD_vorbis_info_clear(context, v16);
        FMOD_vorbis_comment_clear(context, &vf->vc[v15++]);
        vi = vf->vi;
      }
      while ( vf->links > (int)v15 );
    }
    FMOD_OggVorbis_Free(context, vi);
    FMOD_OggVorbis_Free(context, vf->vc);
  }
  dataoffsets = vf->dataoffsets;
  if ( dataoffsets )
    FMOD_OggVorbis_Free(context, dataoffsets);
  pcmlengths = vf->pcmlengths;
  if ( pcmlengths )
    FMOD_OggVorbis_Free(context, pcmlengths);
  serialnos = vf->serialnos;
  if ( serialnos )
    FMOD_OggVorbis_Free(context, serialnos);
  offsets = vf->offsets;
  if ( offsets )
    FMOD_OggVorbis_Free(context, offsets);
  FMOD_ogg_sync_clear(context, &vf->oy);
  if ( vf->datasource )
  {
    close_func = (void (*)(void))vf->callbacks.close_func;
    if ( close_func )
      close_func();
  }
  v9 = vf;
  v10 = 816;
  if ( ((unsigned __int8)vf & 1) != 0 )
  {
    LOBYTE(vf->datasource) = 0;
    v9 = (OggVorbis_File *)((char *)&vf->datasource + 1);
    LOBYTE(v10) = 47;
  }
  if ( ((unsigned __int8)v9 & 2) != 0 )
  {
    v9 = (OggVorbis_File *)((char *)v9 + 2);
    v10 -= 2;
    HIWORD(v9[-1].callbacks.tell_func) = 0;
  }
  if ( ((unsigned __int8)v9 & 4) != 0 )
  {
    LODWORD(v9->datasource) = 0;
    v10 -= 4;
    v9 = (OggVorbis_File *)((char *)v9 + 4);
  }
  v11 = v10 >> 3;
  memset(v9, 0, 8 * v11);
  v12 = &v9->datasource + v11;
  if ( (v10 & 4) == 0 )
  {
    if ( (v10 & 2) == 0 )
      goto LABEL_23;
LABEL_26:
    v12 = (void **)((char *)v12 + 2);
    *((_WORD *)v12 - 1) = 0;
    if ( (v10 & 1) == 0 )
      return 0;
    goto LABEL_25;
  }
  *(_DWORD *)v12 = 0;
  v12 = (void **)((char *)v12 + 4);
  if ( (v10 & 2) != 0 )
    goto LABEL_26;
LABEL_23:
  if ( (v10 & 1) == 0 )
    return 0;
LABEL_25:
  *(_BYTE *)v12 = 0;
  return 0;
}


// Address: 0x2274140 | Name: FMOD_ov_halfrate
int __fastcall FMOD_ov_halfrate(void *context, OggVorbis_File *vf, int flag)
{
  __int64 v4; // rbx
  int v5; // ebp

  if ( !vf->vi || !vf->seekable )
    return -131;
  if ( vf->ready_state > 2 )
    decode_clear(context, vf);
  v4 = 0;
  v5 = 0;
  if ( vf->links <= 0 )
    return 0;
  while ( !FMOD_vorbis_synthesis_halfrate(&vf->vi[v4], flag) )
  {
    ++v5;
    ++v4;
    if ( vf->links <= v5 )
      return 0;
  }
  FMOD_ov_halfrate(context, vf, 0);
  return -131;
}


// Address: 0x22741e0 | Name: FMOD_ov_halfrate_p
int __fastcall FMOD_ov_halfrate_p(OggVorbis_File *vf)
{
  vorbis_info_0 *vi; // rdi

  vi = vf->vi;
  if ( vi )
    return FMOD_vorbis_synthesis_halfrate_p(vi);
  else
    return -131;
}


// Address: 0x2274200 | Name: FMOD_ov_streams
ogg_int32_t __fastcall FMOD_ov_streams(OggVorbis_File *vf)
{
  return vf->links;
}


// Address: 0x2274210 | Name: FMOD_ov_seekable
ogg_int32_t __fastcall FMOD_ov_seekable(OggVorbis_File *vf)
{
  return vf->seekable;
}


// Address: 0x2274220 | Name: FMOD_ov_bitrate_instant
ogg_int32_t __fastcall FMOD_ov_bitrate_instant(OggVorbis_File *vf)
{
  __int64 current_link; // rax
  float samptrack; // xmm1_4
  float v3; // xmm0_4
  float rate; // xmm1_4

  current_link = 0;
  if ( vf->seekable )
    current_link = vf->current_link;
  if ( vf->ready_state <= 1 )
    return -131;
  samptrack = vf->samptrack;
  if ( samptrack == 0.0 )
    return -1;
  v3 = vf->bittrack / samptrack;
  rate = (float)vf->vi[current_link].rate;
  vf->bittrack = 0.0;
  vf->samptrack = 0.0;
  return (int)(float)((float)(v3 * rate) + 0.5);
}


// Address: 0x22742b0 | Name: FMOD_ov_serialnumber
ogg_int32_t __fastcall FMOD_ov_serialnumber(OggVorbis_File *vf, int i)
{
  int links; // eax

  links = vf->links;
  while ( 1 )
  {
    if ( i >= links )
    {
      do
        i = links - 1;
      while ( links - 1 >= links );
    }
    if ( vf->seekable )
      break;
    if ( i < 0 )
      return vf->current_serialno;
    i = -1;
  }
  if ( i >= 0 )
    return vf->serialnos[i];
  return vf->current_serialno;
}


// Address: 0x2274300 | Name: FMOD_ov_raw_total
ogg_int64_t_0 __fastcall FMOD_ov_raw_total(OggVorbis_File *vf, int i)
{
  int links; // eax
  int v4; // ebx
  ogg_int64_t_0 v5; // r12
  int v6; // esi

  if ( vf->ready_state <= 1 )
    return -131;
  if ( !vf->seekable )
    return -131;
  links = vf->links;
  if ( links <= i )
    return -131;
  if ( i >= 0 )
    return vf->offsets[i + 1] - vf->offsets[i];
  if ( links <= 0 )
    return 0;
  v4 = 0;
  v5 = 0;
  do
  {
    v6 = v4++;
    v5 += FMOD_ov_raw_total(vf, v6);
  }
  while ( vf->links > v4 );
  return v5;
}


// Address: 0x2274380 | Name: FMOD_ov_pcm_total
ogg_int64_t_0 __fastcall FMOD_ov_pcm_total(OggVorbis_File *vf, int i)
{
  int links; // eax
  ogg_int64_t_0 v4; // r12
  int v5; // ebx
  int v6; // esi

  if ( vf->ready_state <= 1 )
    return -131;
  if ( !vf->seekable )
    return -131;
  links = vf->links;
  if ( links <= i )
    return -131;
  if ( i >= 0 )
    return vf->pcmlengths[2 * i + 1];
  v4 = 0;
  if ( links > 0 )
  {
    v5 = 0;
    do
    {
      v6 = v5++;
      v4 += FMOD_ov_pcm_total(vf, v6);
    }
    while ( v5 < vf->links );
  }
  return v4;
}


// Address: 0x2274400 | Name: FMOD_ov_raw_seek
int __fastcall FMOD_ov_raw_seek(void *context, OggVorbis_File *vf, ogg_int64_t_0 pos)
{
  int result; // eax
  ogg_int64_t_0 next_page; // r13
  ogg_int32_t v8; // r15d
  int links; // eax
  int v10; // edi
  ogg_int32_t *serialnos; // rsi
  __int64 i; // rcx
  vorbis_info_0 *v13; // rdi
  ogg_int32_t v14; // r13d
  ogg_int64_t_0 granulepos; // rcx
  int current_link; // edi
  ogg_int64_t_0 *pcmlengths; // rsi
  __int64 v18; // rdx
  __int64 v19; // rcx
  ogg_int64_t_0 *v20; // rax
  ogg_int64_t_0 v21; // rax
  __int64 v22; // rdx
  ogg_int32_t current_serialno; // r15d
  ogg_int64_t_0 *dataoffsets; // rax
  int lastblock; // [rsp+Ch] [rbp-22Ch]
  ogg_stream_state *os; // [rsp+10h] [rbp-228h]
  int lastflag; // [rsp+18h] [rbp-220h]
  __int64 lastflaga; // [rsp+18h] [rbp-220h]
  _BOOL4 firstflag; // [rsp+28h] [rbp-210h]
  int accblock; // [rsp+2Ch] [rbp-20Ch]
  ogg_page og; // [rsp+30h] [rbp-208h] BYREF
  ogg_packet_0 op; // [rsp+50h] [rbp-1E8h] BYREF
  ogg_stream_state work_os; // [rsp+80h] [rbp-1B8h] BYREF

  if ( vf->ready_state <= 1 )
    return -131;
  if ( !vf->seekable )
    return -138;
  result = -131;
  if ( pos >= 0 && pos <= vf->end )
  {
    vf->pcm_offset = -1;
    os = &vf->os;
    FMOD_ogg_stream_reset_serialno(&vf->os, vf->current_serialno);
    FMOD_vorbis_synthesis_restart(&vf->vd);
    if ( seek_helper(vf, pos) )
    {
      vf->pcm_offset = -1;
      FMOD_ogg_stream_clear(context, &work_os);
      decode_clear(context, vf);
      return -137;
    }
    if ( FMOD_ogg_stream_init(context, &work_os, vf->current_serialno) < 0 )
      return -139;
    FMOD_ogg_stream_reset(&work_os);
    firstflag = 0;
    lastflag = 0;
    accblock = 0;
    for ( lastblock = 0; ; lastblock = v14 )
    {
      while ( vf->ready_state <= 2 || FMOD_ogg_stream_packetout(&work_os, (ogg_packet *)&op) <= 0 )
      {
        if ( lastblock )
          goto LABEL_48;
LABEL_10:
        next_page = get_next_page(context, vf, &og, -1);
        if ( next_page < 0 )
        {
          vf->pcm_offset = FMOD_ov_pcm_total(vf, -1);
          goto LABEL_35;
        }
        if ( vf->ready_state <= 2 )
          goto LABEL_12;
        current_serialno = vf->current_serialno;
        if ( current_serialno != FMOD_ogg_page_serialno(&og) )
        {
          if ( FMOD_ogg_page_bos(&og) )
          {
            decode_clear(context, vf);
            FMOD_ogg_stream_clear(context, &work_os);
          }
        }
        if ( vf->ready_state <= 2 )
        {
LABEL_12:
          v8 = FMOD_ogg_page_serialno(&og);
          links = vf->links;
          v10 = 0;
          if ( links > 0 )
          {
            serialnos = vf->serialnos;
            if ( *serialnos == v8 )
            {
              lastflaga = 0;
              v10 = 0;
              goto LABEL_43;
            }
            for ( i = 1; ; ++i )
            {
              v10 = i;
              if ( (int)i >= links )
                break;
              if ( serialnos[i] == v8 )
              {
                lastflaga = i;
                goto LABEL_43;
              }
            }
          }
          if ( v10 != links )
          {
            lastflaga = v10;
LABEL_43:
            vf->current_link = v10;
            vf->current_serialno = v8;
            FMOD_ogg_stream_reset_serialno(os, v8);
            FMOD_ogg_stream_reset_serialno(&work_os, v8);
            dataoffsets = vf->dataoffsets;
            vf->ready_state = 3;
            firstflag = dataoffsets[lastflaga] >= next_page;
            goto LABEL_41;
          }
        }
        else
        {
LABEL_41:
          FMOD_ogg_stream_pagein(context, os, &og);
          FMOD_ogg_stream_pagein(context, &work_os, &og);
          lastflag = FMOD_ogg_page_eos(&og);
        }
      }
      v13 = &vf->vi[vf->current_link];
      if ( !v13->codec_setup )
      {
        FMOD_ogg_stream_packetout(os, 0);
        if ( lastblock )
        {
LABEL_48:
          vf->pcm_offset = -1;
          goto LABEL_35;
        }
        goto LABEL_10;
      }
      v14 = FMOD_vorbis_packet_blocksize(v13, (ogg_packet *)&op);
      if ( v14 < 0 )
      {
        v14 = 0;
        FMOD_ogg_stream_packetout(os, 0);
        goto LABEL_26;
      }
      if ( firstflag || !lastflag )
      {
        if ( lastblock )
          accblock += (v14 + lastblock) >> 2;
LABEL_26:
        granulepos = op.granulepos;
        if ( op.granulepos != -1 )
          goto LABEL_27;
        continue;
      }
      FMOD_ogg_stream_packetout(os, 0);
      granulepos = op.granulepos;
      if ( op.granulepos != -1 )
      {
LABEL_27:
        current_link = vf->current_link;
        pcmlengths = vf->pcmlengths;
        v18 = 0;
        v19 = granulepos - pcmlengths[2 * current_link];
        if ( v19 >= 0 )
          v18 = v19;
        if ( current_link > 0 )
        {
          v20 = pcmlengths + 1;
          do
          {
            v18 += *v20;
            v20 += 2;
          }
          while ( v20 != &pcmlengths[2 * (unsigned int)(current_link - 1) + 3] );
        }
        v21 = 0;
        v22 = v18 - accblock;
        if ( v22 >= 0 )
          v21 = v22;
        vf->pcm_offset = v21;
LABEL_35:
        FMOD_ogg_stream_clear(context, &work_os);
        vf->bittrack = 0.0;
        vf->samptrack = 0.0;
        return 0;
      }
    }
  }
  return result;
}


// Address: 0x2274870 | Name: _open_seekable2
int __fastcall open_seekable2(void *context, OggVorbis_File *vf)
{
  ogg_int32_t serialno; // r13d
  vorbis_info_0 *vi; // rdx
  ogg_int64_t_0 v4; // r12
  ogg_int64_t_0 v5; // r14
  int (*seek_func)(void *, ogg_int64_t_0, int); // rax
  ogg_int32_t v7; // eax
  ogg_int64_t_0 prev_page_serial; // rax
  ogg_int64_t_0 *pcmlengths; // rax
  int endserial; // [rsp+24h] [rbp-34h] BYREF
  ogg_int64_t_0 endgran[6]; // [rsp+28h] [rbp-30h] BYREF

  serialno = vf->os.serialno;
  vi = vf->vi;
  v4 = *vf->dataoffsets;
  endgran[0] = -1;
  endserial = serialno;
  v5 = initial_pcmoffset(context, vf, vi);
  seek_func = vf->callbacks.seek_func;
  if ( seek_func && vf->callbacks.tell_func )
  {
    seek_func(vf->datasource, 0, 2);
    v7 = vf->callbacks.tell_func(vf->datasource);
    vf->end = v7;
    vf->offset = v7;
    if ( v7 == -1 )
    {
      LODWORD(prev_page_serial) = -131;
    }
    else
    {
      prev_page_serial = get_prev_page_serial(context, vf, vf->serialnos + 2, vf->serialnos[1], &endserial, endgran);
      if ( prev_page_serial >= 0 )
      {
        if ( bisect_forward_serialno(
               context,
               vf,
               0,
               v4,
               vf->offset,
               endgran[0],
               endserial,
               vf->serialnos + 2,
               vf->serialnos[1],
               0) < 0 )
        {
          LODWORD(prev_page_serial) = -128;
        }
        else
        {
          *vf->offsets = 0;
          *vf->serialnos = serialno;
          *vf->dataoffsets = v4;
          pcmlengths = vf->pcmlengths;
          pcmlengths[1] -= v5;
          *pcmlengths = v5;
          LODWORD(prev_page_serial) = FMOD_ov_raw_seek(context, vf, v4);
        }
      }
    }
  }
  else
  {
    vf->end = -1;
    vf->offset = -1;
    LODWORD(prev_page_serial) = -131;
  }
  return prev_page_serial;
}


// Address: 0x22749d0 | Name: FMOD_ov_open_callbacks
__int64 __fastcall FMOD_ov_open_callbacks(
        void *context,
        void *f,
        OggVorbis_File *vf,
        char *initial,
        ogg_int32_t ibytes,
        ov_callbacks callbacks)
{
  int v6; // r14d
  size_t (*read_func)(void *, size_t, size_t, void *); // r11
  int (*seek_func)(void *, ogg_int64_t_0, int); // r8
  int (*close_func)(void *); // r10
  int v14; // eax
  OggVorbis_File *v15; // rdi
  unsigned int v16; // edx
  __int64 v17; // rcx
  void **v18; // rdi
  char *v19; // rax
  vorbis_info_0 *v20; // rax
  vorbis_comment *v21; // rax
  int headers; // r12d
  ogg_int32_t *v23; // rax
  ogg_int32_t *v24; // rsi
  __int64 v25; // rdx
  ogg_int64_t_0 *v26; // rax
  ogg_int64_t_0 *v27; // rax
  ogg_int32_t serialno; // eax
  __int64 result; // rax
  unsigned int v30; // r12d
  int serialno_n; // [rsp+34h] [rbp-44h] BYREF
  ogg_int32_t *serialno_list; // [rsp+38h] [rbp-40h] BYREF

  v6 = -1;
  read_func = callbacks.read_func;
  seek_func = callbacks.seek_func;
  close_func = callbacks.close_func;
  if ( f && callbacks.seek_func )
  {
    v14 = callbacks.seek_func(f, 0, 1);
    read_func = callbacks.read_func;
    close_func = callbacks.close_func;
    v6 = v14;
    seek_func = callbacks.seek_func;
  }
  serialno_list = 0;
  serialno_n = 0;
  v15 = vf;
  v16 = 816;
  if ( ((unsigned __int8)vf & 1) == 0 )
  {
    if ( ((unsigned __int8)vf & 2) == 0 )
      goto LABEL_6;
LABEL_37:
    v15 = (OggVorbis_File *)((char *)v15 + 2);
    v16 -= 2;
    HIWORD(v15[-1].callbacks.tell_func) = 0;
    if ( ((unsigned __int8)v15 & 4) == 0 )
      goto LABEL_7;
    goto LABEL_38;
  }
  v15 = (OggVorbis_File *)((char *)&vf->datasource + 1);
  LOBYTE(vf->datasource) = 0;
  LOBYTE(v16) = 47;
  if ( (((_BYTE)vf + 1) & 2) != 0 )
    goto LABEL_37;
LABEL_6:
  if ( ((unsigned __int8)v15 & 4) == 0 )
    goto LABEL_7;
LABEL_38:
  LODWORD(v15->datasource) = 0;
  v16 -= 4;
  v15 = (OggVorbis_File *)((char *)v15 + 4);
LABEL_7:
  v17 = v16 >> 3;
  memset(v15, 0, 8 * v17);
  v18 = &v15->datasource + v17;
  if ( (v16 & 4) != 0 )
  {
    *(_DWORD *)v18 = 0;
    v18 = (void **)((char *)v18 + 4);
  }
  if ( (v16 & 2) != 0 )
  {
    v18 = (void **)((char *)v18 + 2);
    *((_WORD *)v18 - 1) = 0;
  }
  if ( (v16 & 1) != 0 )
    *(_BYTE *)v18 = 0;
  vf->datasource = f;
  vf->callbacks.read_func = read_func;
  vf->callbacks.seek_func = seek_func;
  vf->callbacks.close_func = close_func;
  vf->callbacks.tell_func = callbacks.tell_func;
  FMOD_ogg_sync_init(&vf->oy);
  if ( initial )
  {
    v19 = FMOD_ogg_sync_buffer(context, &vf->oy, ibytes);
    if ( !v19 )
      return 4294967157LL;
    memcpy_0(v19, initial, ibytes);
    FMOD_ogg_sync_wrote(&vf->oy, ibytes);
  }
  if ( v6 != -1 )
    vf->seekable = 1;
  vf->links = 1;
  v20 = (vorbis_info_0 *)FMOD_OggVorbis_Calloc(context, 1, 40);
  vf->vi = v20;
  if ( !v20 )
    return 4294967157LL;
  v21 = (vorbis_comment *)FMOD_OggVorbis_Calloc(context, vf->links, 32);
  vf->vc = v21;
  if ( !v21 )
    return 4294967157LL;
  FMOD_ogg_stream_init(context, &vf->os, -1);
  headers = fetch_headers(context, vf, vf->vi, vf->vc, &serialno_list, &serialno_n, 0);
  if ( headers < 0 )
  {
    vf->datasource = 0;
    FMOD_ov_clear(context, vf);
    goto LABEL_25;
  }
  v23 = (ogg_int32_t *)FMOD_OggVorbis_Calloc(context, serialno_n + 2, 4);
  vf->serialnos = v23;
  if ( !v23 )
    return 4294967157LL;
  v24 = serialno_list;
  *v23 = vf->current_serialno;
  v25 = serialno_n;
  v23[1] = serialno_n;
  memcpy_0(v23 + 2, v24, 4 * v25);
  v26 = (ogg_int64_t_0 *)FMOD_OggVorbis_Calloc(context, 1, 8);
  vf->offsets = v26;
  if ( !v26 )
    return 4294967157LL;
  v27 = (ogg_int64_t_0 *)FMOD_OggVorbis_Calloc(context, 1, 8);
  vf->dataoffsets = v27;
  if ( !v27 )
    return 4294967157LL;
  *vf->offsets = 0;
  *v27 = vf->offset;
  serialno = vf->os.serialno;
  vf->ready_state = 1;
  vf->current_serialno = serialno;
LABEL_25:
  if ( serialno_list )
    FMOD_OggVorbis_Free(context, serialno_list);
  result = (unsigned int)headers;
  if ( !headers )
  {
    result = 4294967165LL;
    if ( vf->ready_state == 1 )
    {
      result = (unsigned int)vf->seekable;
      vf->ready_state = 2;
      if ( (_DWORD)result )
      {
        v30 = open_seekable2(context, vf);
        if ( v30 )
        {
          vf->datasource = 0;
          FMOD_ov_clear(context, vf);
        }
        return v30;
      }
      else
      {
        vf->ready_state = 3;
      }
    }
  }
  return result;
}


// Address: 0x2274d70 | Name: FMOD_ov_test_open
int __fastcall FMOD_ov_test_open(void *context, OggVorbis_File *vf)
{
  int result; // eax
  int v3; // r12d

  result = -131;
  if ( vf->ready_state == 1 )
  {
    result = vf->seekable;
    vf->ready_state = 2;
    if ( result )
    {
      v3 = open_seekable2(context, vf);
      if ( v3 )
      {
        vf->datasource = 0;
        FMOD_ov_clear(context, vf);
      }
      return v3;
    }
    else
    {
      vf->ready_state = 3;
    }
  }
  return result;
}


// Address: 0x2274de0 | Name: FMOD_ov_pcm_seek_page
int __fastcall FMOD_ov_pcm_seek_page(void *context, OggVorbis_File *vf, ogg_int64_t_0 pos)
{
  ogg_int64_t_0 v6; // rax
  int v7; // eax
  ogg_int64_t_0 *pcmlengths; // rsi
  __int64 i; // rax
  ogg_int64_t_0 v10; // rdx
  ogg_int64_t_0 v11; // rdi
  int v12; // ecx
  ogg_int64_t_0 *offsets; // rcx
  __int64 v14; // rdi
  ogg_int64_t_0 v15; // r14
  ogg_int64_t_0 offset; // r15
  __int64 v17; // r13
  ogg_int64_t_0 v18; // rax
  ogg_int64_t_0 v19; // r12
  ogg_int64_t_0 next_page; // r12
  ogg_int64_t_0 v22; // rax
  ogg_int32_t *serialnos; // rax
  ogg_int32_t current_serialno; // esi
  int v25; // eax
  __int64 v26; // r15
  ogg_int64_t_0 v27; // r13
  int v28; // eax
  ogg_int64_t_0 j; // r12
  ogg_int64_t_0 v30; // rax
  ogg_int64_t_0 v31; // rdx
  ogg_int64_t_0 v32; // rdx
  int v33; // eax
  ogg_int64_t_0 total; // [rsp+10h] [rbp-E8h]
  ogg_int64_t_0 target; // [rsp+18h] [rbp-E0h]
  int link; // [rsp+24h] [rbp-D4h]
  ogg_int64_t_0 begintime; // [rsp+30h] [rbp-C8h]
  ogg_int64_t_0 best; // [rsp+38h] [rbp-C0h]
  int endtime; // [rsp+40h] [rbp-B8h]
  ogg_page og; // [rsp+50h] [rbp-A8h] BYREF
  ogg_page og_0; // [rsp+70h] [rbp-88h] BYREF
  ogg_packet_0 op; // [rsp+90h] [rbp-68h] BYREF

  v6 = FMOD_ov_pcm_total(vf, -1);
  total = v6;
  if ( vf->ready_state <= 1 )
    goto LABEL_42;
  if ( !vf->seekable )
  {
    LODWORD(next_page) = -138;
    return next_page;
  }
  if ( pos > v6 || pos < 0 )
  {
LABEL_42:
    LODWORD(next_page) = -131;
    return next_page;
  }
  v7 = vf->links - 1;
  link = v7;
  if ( v7 < 0 )
  {
    pcmlengths = vf->pcmlengths;
    i = 2 * v7;
    v10 = pcmlengths[i + 1];
  }
  else
  {
    pcmlengths = vf->pcmlengths;
    LODWORD(i) = 2 * v7;
    v10 = pcmlengths[2 * link + 1];
    total -= v10;
    v11 = total;
    if ( pos >= total )
    {
      i = (int)i;
    }
    else
    {
      v12 = link;
      for ( i = (int)i - 2; ; i -= 2 )
      {
        if ( --v12 == -1 )
        {
          v10 = *(pcmlengths - 1);
          total = v11;
          i = -2;
          link = -1;
          goto LABEL_12;
        }
        v10 = pcmlengths[i + 1];
        v11 -= v10;
        if ( pos >= v11 )
          break;
      }
      total = v11;
      link = v12;
    }
  }
LABEL_12:
  offsets = vf->offsets;
  begintime = pcmlengths[i];
  v14 = link + 1LL;
  endtime = begintime + v10;
  v15 = offsets[v14];
  offset = offsets[v14 - 1];
  best = offset;
  target = begintime + pos - total;
  if ( v15 > offset )
  {
LABEL_13:
    v17 = offset;
    if ( v15 - offset > 8499 )
    {
      v17 = offset
          + (unsigned int)(int)(float)((float)((float)(target - begintime) * (float)(v15 - offset))
                                     / (float)(endtime - begintime))
          - 8500;
      if ( v17 <= offset )
        v17 = offset + 1;
    }
    LODWORD(v18) = seek_helper(vf, v17);
    if ( !(_DWORD)v18 )
    {
      while ( 1 )
      {
        v19 = v15 - vf->offset;
        Roblox_DisableParsingChecks(context);
        next_page = get_next_page(context, vf, &og, v19);
        Roblox_ReenableParsingChecks(context);
        if ( next_page == -128 )
          goto seek_error;
        if ( next_page < 0 )
        {
          if ( offset + 1 >= v17 )
            goto LABEL_23;
          if ( !v17 )
            goto seek_error;
          v17 -= 8500;
          if ( v17 <= offset )
            v17 = offset + 1;
          LODWORD(v18) = seek_helper(vf, v17);
          if ( (_DWORD)v18 )
            goto LABEL_30;
        }
        else if ( FMOD_ogg_page_serialno(&og) == vf->serialnos[link] )
        {
          v22 = FMOD_ogg_page_granulepos(&og);
          if ( v22 != -1 )
          {
            if ( target <= v22 )
            {
              if ( offset + 1 >= v17 )
                goto LABEL_23;
              if ( vf->offset != v15 )
              {
                endtime = v22;
                next_page = best;
                v15 = v17;
                v22 = begintime;
LABEL_73:
                best = next_page;
                if ( v15 <= offset )
                  goto LABEL_23;
                begintime = v22;
                goto LABEL_13;
              }
              v17 -= 8500;
              if ( v17 <= offset )
                v17 = offset + 1;
              LODWORD(v18) = seek_helper(vf, v17);
              if ( (_DWORD)v18 )
                goto LABEL_30;
              v15 = next_page;
            }
            else
            {
              offset = vf->offset;
              if ( target - v22 > 44100 )
                goto LABEL_73;
              v17 = vf->offset;
              best = next_page;
              begintime = v22;
            }
          }
        }
        if ( offset >= v15 )
          goto LABEL_23;
      }
    }
    goto LABEL_30;
  }
LABEL_23:
  LODWORD(next_page) = seek_helper(vf, best);
  vf->pcm_offset = -1;
  if ( (_DWORD)next_page )
  {
seek_error:
    vf->pcm_offset = -1;
    decode_clear(context, vf);
    return next_page;
  }
  v18 = get_next_page(context, vf, &og_0, -1);
  if ( v18 < 0 )
  {
LABEL_30:
    LODWORD(next_page) = v18;
    goto seek_error;
  }
  if ( vf->current_link == link )
  {
    FMOD_vorbis_synthesis_restart(&vf->vd);
    current_serialno = vf->current_serialno;
  }
  else
  {
    decode_clear(context, vf);
    serialnos = vf->serialnos;
    vf->current_link = link;
    current_serialno = serialnos[link];
    vf->ready_state = 3;
    vf->current_serialno = current_serialno;
  }
  FMOD_ogg_stream_reset_serialno(&vf->os, current_serialno);
  FMOD_ogg_stream_pagein(context, &vf->os, &og_0);
  while ( 1 )
  {
    v25 = FMOD_ogg_stream_packetpeek(&vf->os, (ogg_packet *)&op);
    if ( !v25 )
    {
      LODWORD(next_page) = seek_helper(vf, best);
      if ( (int)next_page >= 0 )
      {
        v26 = vf->offset;
        if ( v26 )
        {
          while ( 2 )
          {
            v27 = v26;
            do
            {
              v27 -= 8500LL;
              if ( v27 < 0 )
                v27 = 0;
              v28 = seek_helper(vf, v27);
              if ( v28 )
              {
                v26 = v28;
                goto LABEL_65;
              }
              for ( j = -1; ; j = v18 )
              {
                v30 = vf->offset;
                if ( v30 >= v26 )
                  break;
                memset(&og_0, 0, sizeof(og_0));
                v18 = get_next_page(context, vf, &og_0, v26 - v30);
                if ( v18 == -128 )
                  goto LABEL_68;
                if ( v18 == -139 )
                  goto LABEL_30;
                if ( v18 < 0 )
                  break;
              }
            }
            while ( j == -1 );
            v26 = j;
            if ( !og_0.header_len )
            {
              v33 = seek_helper(vf, j);
              v26 = v33;
              if ( !v33 )
              {
                if ( get_next_page(context, vf, &og_0, 8500) < 0 )
                  goto LABEL_83;
                v26 = j;
              }
            }
LABEL_65:
            if ( v26 < 0 )
            {
              LODWORD(next_page) = v26;
              goto seek_error;
            }
            if ( FMOD_ogg_page_serialno(&og_0) == vf->current_serialno
              && (FMOD_ogg_page_granulepos(&og_0) >= 0 || !FMOD_ogg_page_continued(&og_0)) )
            {
              LODWORD(next_page) = FMOD_ov_raw_seek(context, vf, v26);
              return next_page;
            }
            vf->offset = v26;
            if ( v26 )
              continue;
            break;
          }
        }
LABEL_68:
        LODWORD(next_page) = -128;
      }
      goto seek_error;
    }
    if ( v25 < 0LL )
    {
      LODWORD(next_page) = -136;
      goto seek_error;
    }
    if ( op.granulepos != -1 )
      break;
    FMOD_ogg_stream_packetout(&vf->os, 0);
  }
  v31 = 0;
  if ( op.granulepos - vf->pcmlengths[2 * vf->current_link] > 0 )
    v31 = op.granulepos - vf->pcmlengths[2 * vf->current_link];
  v32 = total + v31;
  vf->pcm_offset = v32;
  if ( pos < v32 || pos > FMOD_ov_pcm_total(vf, -1) )
  {
LABEL_83:
    LODWORD(next_page) = -129;
    goto seek_error;
  }
  vf->bittrack = 0.0;
  vf->samptrack = 0.0;
  LODWORD(next_page) = 0;
  return next_page;
}


// Address: 0x2275460 | Name: FMOD_ov_pcm_seek
int __fastcall FMOD_ov_pcm_seek(void *context, OggVorbis_File *vf, ogg_int64_t_0 pos)
{
  int result; // eax
  ogg_int32_t v6; // r14d
  int v7; // eax
  ogg_int32_t v8; // eax
  ogg_int32_t v9; // ebp
  ogg_int64_t_0 pcm_offset; // r14
  int current_link; // esi
  ogg_int64_t_0 *pcmlengths; // rcx
  ogg_int64_t_0 v13; // rdx
  _QWORD *v14; // rax
  __int64 v15; // rcx
  int v16; // eax
  int links; // edi
  int v18; // ebp
  ogg_int32_t *serialnos; // rcx
  ogg_int32_t *v20; // rcx
  int v21; // edx
  ogg_int64_t_0 v22; // rax
  ogg_int64_t_0 v23; // r12
  int v24; // eax
  ogg_int64_t_0 v25; // rbp
  int v26; // ecx
  int v27; // r8d
  vorbis_block_0 *vb; // [rsp+10h] [rbp-98h]
  vorbis_dsp_state_0 *v; // [rsp+18h] [rbp-90h]
  ogg_page og; // [rsp+20h] [rbp-88h] BYREF
  ogg_packet_0 op; // [rsp+40h] [rbp-68h] BYREF

  result = FMOD_ov_pcm_seek_page(context, vf, pos);
  if ( result < 0 )
    return result;
  result = make_decode_ready(context, vf);
  if ( result )
    return result;
  v6 = 0;
  vb = &vf->vb;
  v = &vf->vd;
  while ( 1 )
  {
LABEL_4:
    v7 = FMOD_ogg_stream_packetpeek(&vf->os, (ogg_packet *)&op);
    if ( v7 <= 0 )
    {
      while ( (v7 == -3 || v7 >= 0) && get_next_page(context, vf, &og, -1) >= 0 )
      {
        if ( FMOD_ogg_page_bos(&og) )
          decode_clear(context, vf);
        if ( vf->ready_state <= 2 )
        {
          v16 = FMOD_ogg_page_serialno(&og);
          links = vf->links;
          v18 = v16;
          if ( links <= 0 )
          {
            if ( !links )
              goto LABEL_4;
          }
          else
          {
            serialnos = vf->serialnos;
            if ( v16 != *serialnos )
            {
              v20 = serialnos + 1;
              v21 = 0;
              while ( ++v21 != links )
              {
                if ( v16 == *v20++ )
                  goto LABEL_28;
              }
              goto LABEL_4;
            }
          }
          v21 = 0;
LABEL_28:
          vf->current_link = v21;
          vf->ready_state = 3;
          vf->current_serialno = FMOD_ogg_page_serialno(&og);
          FMOD_ogg_stream_reset_serialno(&vf->os, v18);
          result = make_decode_ready(context, vf);
          if ( result )
            return result;
          v6 = 0;
        }
        FMOD_ogg_stream_pagein(context, &vf->os, &og);
LABEL_17:
        v7 = FMOD_ogg_stream_packetpeek(&vf->os, (ogg_packet *)&op);
        if ( v7 > 0 )
          goto LABEL_5;
      }
      goto LABEL_32;
    }
LABEL_5:
    v8 = FMOD_vorbis_packet_blocksize(&vf->vi[vf->current_link], (ogg_packet *)&op);
    v9 = v8;
    if ( v8 >= 0 )
      break;
    FMOD_ogg_stream_packetout(&vf->os, 0);
  }
  if ( v6 )
  {
    pcm_offset = vf->pcm_offset + ((v8 + v6) >> 2);
    vf->pcm_offset = pcm_offset;
  }
  else
  {
    pcm_offset = vf->pcm_offset;
  }
  if ( pos <= ((v8 + FMOD_vorbis_info_blocksize(vf->vi, 1)) >> 2) + pcm_offset )
  {
LABEL_32:
    vf->bittrack = 0.0;
    vf->samptrack = 0.0;
    v22 = vf->pcm_offset;
    while ( pos > v22 )
    {
      v23 = pos - v22;
      v24 = FMOD_vorbis_synthesis_pcmout(&vf->vd, 0);
      v25 = v24;
      if ( v23 < v24 )
      {
        v24 = v23;
        v25 = (int)v23;
      }
      FMOD_vorbis_synthesis_read(&vf->vd, v24);
      v22 = vf->pcm_offset + v25;
      vf->pcm_offset = v22;
      if ( v23 > v25 )
      {
        if ( fetch_and_process_packet(context, vf, (ogg_packet *)((char *)&dword_0 + 1), v26, v27) <= 0 )
        {
          v22 = FMOD_ov_pcm_total(vf, -1);
          vf->pcm_offset = v22;
        }
        else
        {
          v22 = vf->pcm_offset;
        }
      }
    }
    return 0;
  }
  FMOD_ogg_stream_packetout(&vf->os, 0);
  result = FMOD_vorbis_synthesis_trackonly(context, vb, (ogg_packet *)&op);
  if ( result >= 0 )
  {
    FMOD_vorbis_synthesis_blockin(v, vb);
    if ( op.granulepos >= 0 )
    {
      current_link = vf->current_link;
      pcmlengths = vf->pcmlengths;
      v13 = 0;
      if ( op.granulepos - pcmlengths[2 * current_link] >= 0 )
        v13 = op.granulepos - pcmlengths[2 * current_link];
      vf->pcm_offset = v13;
      if ( current_link > 0 )
      {
        v14 = pcmlengths + 1;
        v15 = (__int64)&pcmlengths[2 * (unsigned int)(current_link - 1) + 3];
        do
        {
          v13 += *v14;
          v14 += 2;
          vf->pcm_offset = v13;
        }
        while ( v14 != (_QWORD *)v15 );
      }
    }
    v6 = v9;
    goto LABEL_17;
  }
  return result;
}


// Address: 0x22757d0 | Name: FMOD_ov_time_total
float __fastcall FMOD_ov_time_total(OggVorbis_File *vf, int i)
{
  int links; // eax
  float v4; // xmm1_4
  int v5; // ebp
  int v6; // esi

  if ( vf->ready_state <= 1 )
    return -131.0;
  if ( !vf->seekable )
    return -131.0;
  links = vf->links;
  if ( links <= i )
    return -131.0;
  if ( i >= 0 )
    return (float)(int)vf->pcmlengths[2 * i + 1] / (float)vf->vi[i].rate;
  v4 = 0.0;
  if ( links > 0 )
  {
    v5 = 0;
    do
    {
      v6 = v5++;
      v4 = v4 + FMOD_ov_time_total(vf, v6);
    }
    while ( v5 < vf->links );
  }
  return v4;
}


// Address: 0x2275880 | Name: FMOD_ov_bitrate
ogg_int32_t __fastcall FMOD_ov_bitrate(OggVorbis_File *vf, int i)
{
  ogg_int32_t result; // eax
  int links; // ecx
  vorbis_info_0 *vi; // rdx
  int bitrate_lower; // edx
  __int64 v6; // rax
  int v7; // esi
  ogg_int64_t_0 v8; // rdx
  float v9; // xmm0_4
  __m128 v10; // xmm4
  float v11; // xmm0_4
  float v12; // xmm3_4
  float v13; // xmm0_4
  float v14; // [rsp+Ch] [rbp-Ch]
  float v15; // [rsp+Ch] [rbp-Ch]

  result = -131;
  if ( vf->ready_state > 1 )
  {
    links = vf->links;
    if ( links <= i )
    {
      return -131;
    }
    else
    {
      while ( !vf->seekable )
      {
        if ( !i )
        {
          vi = vf->vi;
          result = vi->bitrate_nominal;
          if ( result <= 0 )
          {
            result = vi->bitrate_upper;
            if ( result <= 0 )
            {
              return -1;
            }
            else
            {
              bitrate_lower = vi->bitrate_lower;
              if ( bitrate_lower > 0 )
                return (bitrate_lower + result) >> 1;
            }
          }
          return result;
        }
        i = 0;
        if ( links <= 0 )
          return -131;
      }
      if ( i >= 0 )
      {
        v15 = (float)(8 * (LODWORD(vf->offsets[i + 1]) - LODWORD(vf->dataoffsets[i])));
        v13 = FMOD_ov_time_total(vf, i);
        return (int)rintf(v15 / v13);
      }
      else
      {
        if ( links <= 0 )
        {
          v14 = 0.0;
        }
        else
        {
          v6 = 0;
          v7 = 0;
          do
          {
            v8 = vf->offsets[v6 + 1] - vf->dataoffsets[v6];
            ++v6;
            v7 += 8 * v8;
          }
          while ( links > (int)v6 );
          v14 = (float)v7;
        }
        v9 = FMOD_ov_time_total(vf, -1);
        v10 = (__m128)LODWORD(v14);
        v11 = v14 / v9;
        v10.m128_f32[0] = v11;
        v12 = fabs(v11);
        if ( v12 < 8388608.0 )
          LODWORD(v11) = _mm_andnot_ps((__m128)0x7FFFFFFFu, v10).m128_u32[0]
                       | COERCE_UNSIGNED_INT((float)(v12 + 8388608.0) - 8388608.0);
      }
      return (int)v11;
    }
  }
  return result;
}


// Address: 0x22759c0 | Name: FMOD_ov_time_seek
int __fastcall FMOD_ov_time_seek(void *context, OggVorbis_File *vf, float a3, float seconds)
{
  float v4; // xmm0_4
  int links; // eax
  __int64 v6; // r12
  __int64 v7; // r13
  int v8; // ebx
  float time_total; // [rsp+8h] [rbp-30h]

  if ( vf->ready_state <= 1 )
    return -131;
  if ( vf->seekable )
  {
    v4 = 0.0;
    if ( a3 >= 0.0 )
    {
      links = vf->links;
      if ( links <= 0 )
      {
        LODWORD(v7) = 0;
        v8 = 0;
      }
      else
      {
        v6 = 1;
        time_total = 0.0;
        v7 = 0;
        v8 = 0;
        while ( 1 )
        {
          v4 = FMOD_ov_time_total(vf, v8) + time_total;
          if ( v4 > a3 )
            break;
          ++v8;
          v7 += vf->pcmlengths[v6];
          links = vf->links;
          v6 += 2;
          if ( links <= v8 )
            goto LABEL_10;
          time_total = v4;
        }
        links = vf->links;
        v4 = time_total;
      }
LABEL_10:
      if ( links != v8 )
        return FMOD_ov_pcm_seek(
                 context,
                 vf,
                 (unsigned int)(int)(float)((float)(int)v7 + (float)((float)(a3 - v4) * (float)vf->vi[v8].rate)));
    }
    return -131;
  }
  return -138;
}


// Address: 0x2275ad0 | Name: FMOD_ov_time_seek_page
int __fastcall FMOD_ov_time_seek_page(void *context, OggVorbis_File *vf, float a3, float seconds)
{
  float v4; // xmm0_4
  int links; // eax
  __int64 v6; // r12
  __int64 v7; // r13
  int v8; // ebx
  float time_total; // [rsp+8h] [rbp-30h]

  if ( vf->ready_state <= 1 )
    return -131;
  if ( vf->seekable )
  {
    v4 = 0.0;
    if ( a3 >= 0.0 )
    {
      links = vf->links;
      if ( links <= 0 )
      {
        LODWORD(v7) = 0;
        v8 = 0;
      }
      else
      {
        v6 = 1;
        time_total = 0.0;
        v7 = 0;
        v8 = 0;
        while ( 1 )
        {
          v4 = FMOD_ov_time_total(vf, v8) + time_total;
          if ( v4 > a3 )
            break;
          ++v8;
          v7 += vf->pcmlengths[v6];
          links = vf->links;
          v6 += 2;
          if ( links <= v8 )
            goto LABEL_10;
          time_total = v4;
        }
        links = vf->links;
        v4 = time_total;
      }
LABEL_10:
      if ( links != v8 )
        return FMOD_ov_pcm_seek_page(
                 context,
                 vf,
                 (unsigned int)(int)(float)((float)(int)v7 + (float)((float)(a3 - v4) * (float)vf->vi[v8].rate)));
    }
    return -131;
  }
  return -138;
}


// Address: 0x2275be0 | Name: FMOD_ov_raw_tell
ogg_int64_t_0 __fastcall FMOD_ov_raw_tell(OggVorbis_File *vf)
{
  if ( vf->ready_state <= 1 )
    return -131;
  else
    return vf->offset;
}


// Address: 0x2275c00 | Name: FMOD_ov_pcm_tell
ogg_int64_t_0 __fastcall FMOD_ov_pcm_tell(OggVorbis_File *vf)
{
  if ( vf->ready_state <= 1 )
    return -131;
  else
    return vf->pcm_offset;
}


// Address: 0x2275c20 | Name: FMOD_ov_time_tell
float __fastcall FMOD_ov_time_tell(OggVorbis_File *vf)
{
  ogg_int64_t_0 pcm_offset; // rax
  float v2; // xmm1_4
  __int64 v3; // rdx
  ogg_int64_t_0 v4; // r12
  int v6; // ebp
  __int64 v7; // r13
  float v8; // xmm0_4

  if ( vf->ready_state <= 1 )
    return -131.0;
  if ( vf->seekable )
  {
    v4 = FMOD_ov_pcm_total(vf, -1);
    v2 = FMOD_ov_time_total(vf, -1);
    v6 = vf->links - 1;
    if ( v6 < 0 )
    {
      pcm_offset = vf->pcm_offset;
      v3 = 40LL * v6;
    }
    else
    {
      v7 = 16LL * v6 + 8;
      do
      {
        v4 -= *(ogg_int64_t_0 *)((char *)vf->pcmlengths + v7);
        v8 = FMOD_ov_time_total(vf, v6);
        pcm_offset = vf->pcm_offset;
        v2 = v2 - v8;
        if ( v4 <= pcm_offset )
        {
          v3 = 40LL * v6;
          return (float)((float)(pcm_offset - v4) / (float)*(int *)((char *)&vf->vi->rate + v3)) + v2;
        }
        --v6;
        v7 -= 16;
      }
      while ( v6 != -1 );
      v3 = -40;
    }
  }
  else
  {
    pcm_offset = vf->pcm_offset;
    v2 = 0.0;
    v3 = 0;
    LODWORD(v4) = 0;
  }
  return (float)((float)(pcm_offset - v4) / (float)*(int *)((char *)&vf->vi->rate + v3)) + v2;
}


// Address: 0x2275d40 | Name: FMOD_ov_info
vorbis_info_0 *__fastcall FMOD_ov_info(OggVorbis_File *vf, int link)
{
  if ( !vf->seekable )
    return vf->vi;
  if ( link < 0 )
  {
    if ( vf->ready_state > 2 )
      return &vf->vi[vf->current_link];
    return vf->vi;
  }
  if ( link >= vf->links )
    return 0;
  else
    return &vf->vi[link];
}


// Address: 0x2275d90 | Name: FMOD_ov_64_seek_lap
int __fastcall FMOD_ov_64_seek_lap(
        void *context,
        OggVorbis_File *vf,
        ogg_int64_t_0 pos,
        int (*localseek)(void *, OggVorbis_File *, ogg_int64_t_0))
{
  bool v4; // cc
  int v5; // r14d
  vorbis_info_0 *v7; // r14
  int v8; // r15d
  int channels; // r13d
  void *v10; // rsp
  __int64 v11; // rcx
  signed __int64 v12; // rax
  void *v13; // rsp
  vorbis_info_0 *v14; // rax
  int v15; // eax
  int v16; // r12d
  float *v17; // rbx
  float *v18; // [rsp+10h] [rbp-70h] BYREF
  float *w1; // [rsp+18h] [rbp-68h]
  vorbis_dsp_state_0 *vd; // [rsp+20h] [rbp-60h]
  int (*localseeka)(void *, OggVorbis_File *, ogg_int64_t_0); // [rsp+28h] [rbp-58h]
  ogg_int64_t_0 ch2; // [rsp+30h] [rbp-50h]
  int v23; // [rsp+38h] [rbp-48h]
  int n1; // [rsp+3Ch] [rbp-44h]
  float **pcm; // [rsp+48h] [rbp-38h] BYREF

  v4 = vf->ready_state <= 1;
  ch2 = pos;
  localseeka = localseek;
  if ( v4 )
    return -131;
  v5 = FMOD_ov_initset(context, vf);
  if ( !v5 )
  {
    v7 = FMOD_ov_info(vf, -1);
    v8 = FMOD_ov_halfrate_p(vf);
    channels = v7->channels;
    v23 = v8 + 1;
    n1 = FMOD_vorbis_info_blocksize(v7, 0) >> (v8 + 1);
    vd = &vf->vd;
    w1 = FMOD_vorbis_window(&vf->vd, 0);
    v10 = alloca(8LL * channels + 15);
    if ( channels > 0 )
    {
      v11 = 0;
      v12 = 16 * ((4LL * n1 + 30) / 0x10uLL);
      do
      {
        v13 = alloca(v12);
        (&v18)[v11++] = (float *)&v18;
      }
      while ( channels > (int)v11 );
    }
    FMOD_ov_getlap(context, vf, (vorbis_info_0 *)&v7->channels, vd, &v18, n1);
    v5 = localseeka(context, vf, ch2);
    if ( !v5 )
    {
      v5 = FMOD_ov_initprime(context, vf);
      if ( !v5 )
      {
        v14 = FMOD_ov_info(vf, -1);
        LODWORD(ch2) = v14->channels;
        v15 = FMOD_vorbis_info_blocksize(v14, 0);
        v16 = v15 >> v23;
        v17 = FMOD_vorbis_window(vd, 0);
        FMOD_vorbis_synthesis_lapout(vd, &pcm);
        FMOD_ov_splice(pcm, &v18, n1, v16, channels, ch2, w1, v17);
      }
    }
  }
  return v5;
}


// Address: 0x2275f50 | Name: FMOD_ov_d_seek_lap
__int64 __fastcall FMOD_ov_d_seek_lap(
        void *context,
        OggVorbis_File *vf,
        float pos,
        int (*localseek)(void *, OggVorbis_File *, float))
{
  bool v4; // cc
  unsigned int v5; // r14d
  vorbis_info_0 *v7; // r14
  int v8; // eax
  int channels; // r15d
  int v10; // r13d
  void *v11; // rsp
  __int64 v12; // rcx
  void *v13; // rsp
  vorbis_info_0 *v14; // rax
  int v15; // eax
  int v16; // r12d
  float *v17; // rbx
  float *w1; // [rsp+10h] [rbp-70h] BYREF
  int v19; // [rsp+1Ch] [rbp-64h]
  float **lappcm; // [rsp+20h] [rbp-60h]
  vorbis_dsp_state_0 *hs; // [rsp+28h] [rbp-58h]
  int (*localseeka)(void *, OggVorbis_File *, float); // [rsp+30h] [rbp-50h]
  float **ch2; // [rsp+38h] [rbp-48h]
  float **pcm; // [rsp+48h] [rbp-38h] BYREF

  v4 = vf->ready_state <= 1;
  *(float *)&ch2 = pos;
  localseeka = localseek;
  if ( v4 )
  {
    return (unsigned int)-131;
  }
  else
  {
    v5 = FMOD_ov_initset(context, vf);
    if ( !v5 )
    {
      v7 = FMOD_ov_info(vf, -1);
      v8 = FMOD_ov_halfrate_p(vf);
      channels = v7->channels;
      v19 = v8 + 1;
      v10 = FMOD_vorbis_info_blocksize(v7, 0) >> (v8 + 1);
      hs = &vf->vd;
      w1 = FMOD_vorbis_window(&vf->vd, 0);
      v11 = alloca(8LL * channels + 15);
      if ( channels > 0 )
      {
        v12 = 0;
        do
        {
          v13 = alloca(16 * ((4LL * v10 + 30) / 0x10uLL));
          (&w1)[v12++] = (float *)&w1;
        }
        while ( channels > (int)v12 );
      }
      lappcm = &w1;
      FMOD_ov_getlap(context, vf, (vorbis_info_0 *)&v7->channels, hs, &w1, v10);
      v5 = localseeka(context, vf, *(float *)&ch2);
      if ( !v5 )
      {
        ch2 = lappcm;
        v5 = FMOD_ov_initprime(context, vf);
        if ( !v5 )
        {
          localseeka = (int (*)(void *, OggVorbis_File *, float))ch2;
          v14 = FMOD_ov_info(vf, -1);
          LODWORD(ch2) = v14->channels;
          v15 = FMOD_vorbis_info_blocksize(v14, 0);
          v16 = v15 >> v19;
          v17 = FMOD_vorbis_window(hs, 0);
          FMOD_vorbis_synthesis_lapout(hs, &pcm);
          FMOD_ov_splice(pcm, (float **)localseeka, v10, v16, channels, (int)ch2, w1, v17);
        }
      }
    }
  }
  return v5;
}


// Address: 0x2276130 | Name: FMOD_ov_comment
vorbis_comment *__fastcall FMOD_ov_comment(OggVorbis_File *vf, int link)
{
  if ( !vf->seekable )
    return vf->vc;
  if ( link < 0 )
  {
    if ( vf->ready_state > 2 )
      return &vf->vc[vf->current_link];
    return vf->vc;
  }
  if ( link >= vf->links )
    return 0;
  else
    return &vf->vc[link];
}


// Address: 0x2276180 | Name: FMOD_ov_read_filter
ogg_int32_t __fastcall FMOD_ov_read_filter(
        void *context,
        OggVorbis_File *vf,
        char *buffer,
        int length,
        int bigendianp,
        int word,
        int sgned,
        int *bitstream,
        void (*filter)(float **, ogg_int32_t, ogg_int32_t, void *),
        void *filter_param)
{
  OggVorbis_File *v10; // rbx
  int ready_state; // eax
  vorbis_dsp_state_0 *p_vd; // r14
  ogg_int32_t result; // eax
  ogg_int32_t channels; // ebp
  ogg_int32_t v17; // r8d
  int v18; // eax
  __int16 v19; // r9
  float **v20; // r12
  char *v21; // r13
  __int64 v22; // r11
  float *v23; // rsi
  char *v24; // rdx
  __int64 v25; // rax
  int v26; // ecx
  float **v27; // r12
  __int64 v28; // r13
  char *v29; // rdx
  __int64 v30; // rax
  int v31; // ecx
  __int16 v32; // cx
  float **v33; // r10
  __int64 v34; // r11
  __int64 v35; // rax
  int v36; // edx
  float **v37; // r12
  char *v38; // r13
  __int64 v39; // r11
  float *v40; // rsi
  char *v41; // rdx
  __int64 v42; // rax
  int v43; // ecx
  ogg_int32_t lengthc; // [rsp+8h] [rbp-60h]
  ogg_int32_t lengthb; // [rsp+8h] [rbp-60h]
  ogg_int32_t samples; // [rsp+18h] [rbp-50h]
  ogg_int32_t bytespersample; // [rsp+1Ch] [rbp-4Ch]
  float **pcm; // [rsp+28h] [rbp-40h] BYREF

  v10 = vf;
  ready_state = vf->ready_state;
  if ( ready_state <= 1 )
    return -131;
  p_vd = &vf->vd;
  while ( 1 )
  {
    if ( ready_state == 4 )
    {
      result = FMOD_vorbis_synthesis_pcmout(p_vd, &pcm);
      if ( result )
        break;
    }
    result = fetch_and_process_packet(context, vf, (ogg_packet *)((char *)&dword_0 + 1), length, bigendianp);
    if ( result == -2 )
      return 0;
    if ( result <= 0 )
      return result;
    ready_state = vf->ready_state;
  }
  samples = result;
  if ( result <= 0 )
    return result;
  channels = FMOD_ov_info(vf, -1)->channels;
  v17 = samples;
  bytespersample = channels * word;
  v18 = length / (channels * word);
  if ( v18 < samples )
  {
    if ( v18 > 0 )
    {
      v17 = length / (channels * word);
      goto LABEL_10;
    }
    return -131;
  }
LABEL_10:
  if ( filter )
  {
    lengthc = v17;
    filter(pcm, channels, v17, filter_param);
    v17 = lengthc;
  }
  if ( word == 1 )
  {
    v33 = pcm;
    v34 = 0;
    do
    {
      if ( channels > 0 )
      {
        v35 = 0;
        do
        {
          v36 = (int)(float)(v33[v35][v34] * 128.0);
          if ( v36 < -128 )
            v36 = -128;
          if ( v36 > 127 )
            LOBYTE(v36) = 127;
          buffer[v35++] = (sgned == 0 ? 0x80 : 0) + v36;
        }
        while ( channels > (int)v35 );
        buffer += (unsigned int)(channels - 1) + 1;
      }
      ++v34;
    }
    while ( v17 > (int)v34 );
    goto LABEL_37;
  }
  if ( !sgned )
  {
    v19 = 0x8000;
    if ( !bigendianp )
    {
      if ( channels > 0 )
      {
        v37 = pcm;
        v38 = buffer;
        v39 = 0;
        do
        {
          v40 = v37[v39];
          v41 = v38;
          v42 = 0;
          do
          {
            v43 = (int)(float)(v40[v42] * 32768.0);
            if ( v43 < -32768 )
              v43 = -32768;
            if ( v43 > 0x7FFF )
              LOWORD(v43) = 0x7FFF;
            ++v42;
            *(_WORD *)v41 = v43 + 0x8000;
            v41 += 2 * channels;
          }
          while ( v17 > (int)v42 );
          ++v39;
          v38 += 2;
        }
        while ( channels > (int)v39 );
      }
      goto LABEL_37;
    }
    goto LABEL_26;
  }
  v19 = 0;
  if ( bigendianp )
  {
LABEL_26:
    v27 = pcm;
    v28 = 0;
    do
    {
      if ( channels > 0 )
      {
        v29 = buffer;
        v30 = 0;
        do
        {
          v31 = (int)(float)(v27[v30][v28] * 32768.0);
          if ( v31 < -32768 )
            v31 = -32768;
          if ( v31 > 0x7FFF )
            LOWORD(v31) = 0x7FFF;
          ++v30;
          v29 += 2;
          v32 = v19 + v31;
          *(v29 - 2) = HIBYTE(v32);
          *(v29 - 1) = v32;
        }
        while ( channels > (int)v30 );
        buffer += 2 * (unsigned int)(channels - 1) + 2;
      }
      ++v28;
    }
    while ( v17 > (int)v28 );
    v10 = vf;
    goto LABEL_37;
  }
  if ( channels > 0 )
  {
    v20 = pcm;
    v21 = buffer;
    v22 = 0;
    do
    {
      v23 = v20[v22];
      v24 = v21;
      v25 = 0;
      do
      {
        v26 = (int)(float)(v23[v25] * 32768.0);
        if ( v26 < -32768 )
          v26 = -32768;
        if ( v26 > 0x7FFF )
          LOWORD(v26) = 0x7FFF;
        ++v25;
        *(_WORD *)v24 = v26;
        v24 += 2 * channels;
      }
      while ( v17 > (int)v25 );
      ++v22;
      v21 += 2;
    }
    while ( channels > (int)v22 );
  }
LABEL_37:
  lengthb = v17;
  FMOD_vorbis_synthesis_read(p_vd, v17);
  v10->pcm_offset += lengthb;
  if ( bitstream )
    *bitstream = v10->current_link;
  return lengthb * bytespersample;
}


// Address: 0x2276540 | Name: FMOD_ov_read
ogg_int32_t __fastcall FMOD_ov_read(
        void *context,
        OggVorbis_File *vf,
        char *buffer,
        int length,
        int bigendianp,
        int word,
        int sgned,
        int *bitstream)
{
  return FMOD_ov_read_filter(context, vf, buffer, length, bigendianp, word, sgned, bitstream, 0, 0);
}


// Address: 0x2276580 | Name: FMOD_ov_read_float
ogg_int32_t __fastcall FMOD_ov_read_float(
        void *context,
        OggVorbis_File *vf,
        float ***pcm_channels,
        int length,
        int *bitstream)
{
  int ready_state; // eax
  vorbis_dsp_state_0 *p_vd; // r12
  ogg_int32_t result; // eax
  int v10; // eax
  int v11; // ebp
  float **pcm; // [rsp+18h] [rbp-40h] BYREF

  ready_state = vf->ready_state;
  if ( ready_state <= 1 )
    return -131;
  p_vd = &vf->vd;
  while ( 1 )
  {
    if ( ready_state == 4 )
    {
      v10 = FMOD_vorbis_synthesis_pcmout(p_vd, &pcm);
      if ( v10 )
        break;
    }
    result = fetch_and_process_packet(context, vf, (ogg_packet *)((char *)&dword_0 + 1), length, (int)bitstream);
    if ( result == -2 )
      return 0;
    if ( result <= 0 )
      return result;
    ready_state = vf->ready_state;
  }
  if ( pcm_channels )
    *pcm_channels = pcm;
  v11 = length;
  if ( v10 <= length )
    v11 = v10;
  FMOD_vorbis_synthesis_read(p_vd, v11);
  vf->pcm_offset += v11;
  if ( bitstream )
    *bitstream = vf->current_link;
  return v11;
}


// Address: 0x2276660 | Name: FMOD_ov_crosslap
int __fastcall FMOD_ov_crosslap(void *context, OggVorbis_File *vf1, OggVorbis_File *vf2)
{
  int result; // eax
  vorbis_info_0 *v6; // r13
  char v7; // r14
  void *v8; // rsp
  int v9; // eax
  int v10; // r14d
  vorbis_dsp_state_0 *p_vd; // r15
  float *v12; // rax
  int channels; // r8d
  vorbis_dsp_state_0 *v14; // rcx
  int v15; // r11d
  float **v16; // r10
  __int64 v17; // rsi
  void *v18; // rsp
  float **lappcm; // [rsp+10h] [rbp-70h] BYREF
  int n1; // [rsp+1Ch] [rbp-64h]
  vorbis_dsp_state_0 *vd; // [rsp+20h] [rbp-60h]
  float *w2; // [rsp+28h] [rbp-58h]
  float *hs2; // [rsp+30h] [rbp-50h]
  vorbis_info_0 *vi2; // [rsp+38h] [rbp-48h]
  float **pcm; // [rsp+48h] [rbp-38h] BYREF

  if ( vf1 == vf2 )
    return 0;
  if ( vf1->ready_state <= 1 || vf2->ready_state <= 1 )
    return -131;
  result = FMOD_ov_initset(context, vf1);
  if ( !result )
  {
    result = FMOD_ov_initprime(context, vf2);
    if ( !result )
    {
      v6 = FMOD_ov_info(vf1, -1);
      vi2 = FMOD_ov_info(vf2, -1);
      v7 = FMOD_ov_halfrate_p(vf1);
      LODWORD(hs2) = FMOD_ov_halfrate_p(vf2);
      v8 = alloca(8LL * v6->channels + 15);
      lappcm = (float **)&lappcm;
      n1 = FMOD_vorbis_info_blocksize(v6, 0) >> (v7 + 1);
      v9 = FMOD_vorbis_info_blocksize(vi2, 0);
      v10 = v9 >> ((_BYTE)hs2 + 1);
      vd = &vf1->vd;
      hs2 = FMOD_vorbis_window(&vf1->vd, 0);
      p_vd = &vf2->vd;
      v12 = FMOD_vorbis_window(p_vd, 0);
      channels = v6->channels;
      w2 = v12;
      v14 = vd;
      v15 = n1;
      v16 = lappcm;
      if ( channels > 0 )
      {
        v17 = 0;
        do
        {
          v18 = alloca(16 * ((4LL * v15 + 30) / 0x10uLL));
          v16[v17++] = (float *)&lappcm;
        }
        while ( channels > (int)v17 );
      }
      n1 = v15;
      vd = (vorbis_dsp_state_0 *)v16;
      FMOD_ov_getlap(context, vf1, (vorbis_info_0 *)&v6->channels, v14, v16, v15);
      FMOD_vorbis_synthesis_lapout(p_vd, &pcm);
      FMOD_ov_splice(pcm, (float **)vd, n1, v10, v6->channels, vi2->channels, hs2, w2);
      return 0;
    }
  }
  return result;
}


// Address: 0x2276870 | Name: FMOD_ov_raw_seek_lap
int __fastcall FMOD_ov_raw_seek_lap(void *context, OggVorbis_File *vf, ogg_int64_t_0 pos)
{
  return FMOD_ov_64_seek_lap(context, vf, pos, FMOD_ov_raw_seek);
}


// Address: 0x2276880 | Name: FMOD_ov_pcm_seek_lap
int __fastcall FMOD_ov_pcm_seek_lap(void *context, OggVorbis_File *vf, ogg_int64_t_0 pos)
{
  return FMOD_ov_64_seek_lap(context, vf, pos, FMOD_ov_pcm_seek);
}


// Address: 0x2276890 | Name: FMOD_ov_pcm_seek_page_lap
int __fastcall FMOD_ov_pcm_seek_page_lap(void *context, OggVorbis_File *vf, ogg_int64_t_0 pos)
{
  return FMOD_ov_64_seek_lap(context, vf, pos, FMOD_ov_pcm_seek_page);
}


// Address: 0x22768a0 | Name: FMOD_ov_time_seek_lap
__int64 __fastcall FMOD_ov_time_seek_lap(void *context, OggVorbis_File *vf, float a3, float pos)
{
  return FMOD_ov_d_seek_lap(context, vf, a3, (int (*)(void *, OggVorbis_File *, float))FMOD_ov_time_seek);
}


// Address: 0x22768b0 | Name: FMOD_ov_time_seek_page_lap
__int64 __fastcall FMOD_ov_time_seek_page_lap(void *context, OggVorbis_File *vf, float a3, float pos)
{
  return FMOD_ov_d_seek_lap(context, vf, a3, (int (*)(void *, OggVorbis_File *, float))FMOD_ov_time_seek_page);
}


