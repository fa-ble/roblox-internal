// Address: 0x21b60b0 | Name: _ZN4FMOD23FMOD_DSP_ProcessWrapperEP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS2_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::FMOD_DSP_ProcessWrapper(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  void *instance; // r12
  FMOD_SPEAKERMODE_0 speakermode; // r13d
  unsigned int v10; // ebp
  __int64 v11; // rax
  unsigned int (__fastcall *v12)(FMOD_DSP_STATE *, float *, float *, _QWORD, _QWORD, int *); // r10
  FMOD_RESULT_0 result; // eax
  float **buffers; // rsi
  float **v15; // rax
  unsigned int (__fastcall *v16)(FMOD_DSP_STATE *, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // r10
  int *buffernumchannels; // rdx
  unsigned __int16 v18; // cx
  int outchannels[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  instance = dsp_state->instance;
  if ( inbufferarray )
  {
    speakermode = inbufferarray->speakermode;
    v10 = *inbufferarray->buffernumchannels;
  }
  else
  {
    speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
    v10 = 0;
  }
  v11 = *((_QWORD *)instance + 30);
  if ( op == FMOD_DSP_PROCESS_QUERY )
  {
    v16 = *(unsigned int (__fastcall **)(FMOD_DSP_STATE *, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))(v11 + 176);
    result = FMOD_RESULT::FMOD_OK_0;
    if ( v16 )
      result = v16(dsp_state, (unsigned int)inputsidle, length, 0, v10, (unsigned int)speakermode);
    if ( outbufferarray )
    {
      buffernumchannels = outbufferarray->buffernumchannels;
      if ( buffernumchannels )
      {
        v18 = *((_WORD *)instance + 144);
        if ( v18 )
          v10 = v18;
        *buffernumchannels = v10;
      }
      if ( *((_DWORD *)instance + 51) )
        speakermode = *((_DWORD *)instance + 51);
      outbufferarray->speakermode = speakermode;
    }
  }
  else
  {
    v12 = *(unsigned int (__fastcall **)(FMOD_DSP_STATE *, float *, float *, _QWORD, _QWORD, int *))(v11 + 72);
    result = FMOD_RESULT::FMOD_OK_0;
    if ( v12 )
    {
      buffers = outbufferarray->buffers;
      v15 = inbufferarray->buffers;
      outchannels[0] = v10;
      result = v12(dsp_state, *v15, *buffers, length, v10, outchannels);
      *outbufferarray->buffernumchannels = outchannels[0];
    }
  }
  return result;
}


// Address: 0x21b61a0 | Name: _ZN4FMOD4DSPI19setPositionInternalE14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::DSPI::setPositionInternal(FMOD::DSPI *const this, FMOD_UINT32_32 pcm)
{
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  FMOD_RESULT_0 (__fastcall *setposition)(_QWORD, _QWORD); // rax

  mDescription = this->mDescription.mDescription;
  if ( !mDescription )
    return FMOD_RESULT::FMOD_OK_0;
  setposition = (FMOD_RESULT_0 (__fastcall *)(_QWORD, _QWORD))mDescription->setposition;
  if ( !setposition )
    return FMOD_RESULT::FMOD_OK_0;
  this->mState.instance = this;
  return setposition(&this->mState, pcm.mHi);
}


// Address: 0x21b6200 | Name: _ZN4FMOD9DSPBuffer3getEv
float *__fastcall FMOD::DSPBuffer::get(FMOD::DSPBuffer *const this)
{
  if ( this->mData )
    return this->mData->mBuffer;
  else
    return 0;
}


// Address: 0x21b6220 | Name: _ZN4FMOD9DSPBuffer7releaseEv
FMOD_RESULT_0 __fastcall FMOD::DSPBuffer::release(FMOD::DSPBuffer *const this)
{
  FMOD::DSPMemory *mData; // rdx
  int mRefCount; // eax
  float *mMemory; // rsi
  FMOD::SystemI *mSystem; // rax

  mData = this->mData;
  if ( this->mData )
  {
    mRefCount = mData->mRefCount;
    if ( mRefCount > 0 )
      mData->mRefCount = --mRefCount;
    if ( !mRefCount )
    {
      mMemory = mData->mMemory;
      mSystem = this->mSystem;
      if ( mMemory )
      {
        FMOD::MemPool::free(&mSystem->mDSPLevelsPool, mMemory, (const char *)&uri_string, 0);
      }
      else
      {
        mData->mNext = mSystem->mDSPMemoryFreeHead;
        mSystem->mDSPMemoryFreeHead = mData;
      }
    }
    this->mData = 0;
    this->mChannels = 0;
    this->mSpeakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
    this->mCacheIndex = -1;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b62a0 | Name: _ZN4FMOD9DSPBuffer5allocEPNS_7SystemIEi16FMOD_SPEAKERMODEb
FMOD_RESULT_0 __fastcall FMOD::DSPBuffer::alloc(
        FMOD::DSPBuffer *const this,
        FMOD::SystemI *system,
        int channels,
        FMOD_SPEAKERMODE_0 mode,
        bool clear)
{
  bool v10; // zf
  unsigned int mDSPBlockSize; // r15d
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *mSystem; // rdi
  int v14; // r15d
  FMOD::DSPMemory *mDSPMemoryFreeHead; // rsi
  FMOD::DSPMemory *mNext; // rax
  float *v17; // rdx

  v10 = this->mData == 0;
  this->mSystem = system;
  mDSPBlockSize = system->mDSPBlockSize;
  if ( !v10 )
  {
    result = FMOD::DSPBuffer::release(this);
    if ( result )
      return result;
    mSystem = this->mSystem;
    v14 = channels * mDSPBlockSize;
    if ( channels <= mSystem->mDSPMemoryChannels )
      goto LABEL_4;
LABEL_9:
    v17 = (float *)FMOD::MemPool::alloc(&mSystem->mDSPLevelsPool, 4 * v14 + 48, (const char *)&uri_string, 0, 0, 0);
    result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    if ( v17 )
    {
      mDSPMemoryFreeHead = (FMOD::DSPMemory *)(((unsigned __int64)v17 + 15) & 0xFFFFFFFFFFFFFFF0LL);
      this->mData = mDSPMemoryFreeHead;
      mDSPMemoryFreeHead->mMemory = v17;
      mDSPMemoryFreeHead->mRefCount = 0;
      mDSPMemoryFreeHead->mNext = 0;
      mDSPMemoryFreeHead->mBuffer = (float *)&mDSPMemoryFreeHead[1];
      this->mChannels = channels;
      this->mSpeakerMode = mode;
      if ( !clear )
        goto LABEL_6;
      goto LABEL_11;
    }
    return result;
  }
  mSystem = system;
  v14 = channels * mDSPBlockSize;
  if ( channels > system->mDSPMemoryChannels )
    goto LABEL_9;
LABEL_4:
  mDSPMemoryFreeHead = system->mDSPMemoryFreeHead;
  if ( mDSPMemoryFreeHead )
    goto LABEL_5;
  result = FMOD::SystemI::expandDSPBufferPool(mSystem);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mDSPMemoryFreeHead = system->mDSPMemoryFreeHead;
LABEL_5:
    mNext = mDSPMemoryFreeHead->mNext;
    this->mData = mDSPMemoryFreeHead;
    system->mDSPMemoryFreeHead = mNext;
    this->mChannels = channels;
    this->mSpeakerMode = mode;
    if ( !clear )
    {
LABEL_6:
      ++mDSPMemoryFreeHead->mRefCount;
      return FMOD_RESULT::FMOD_OK_0;
    }
LABEL_11:
    memset(mDSPMemoryFreeHead->mBuffer, 0, 4LL * v14);
    mDSPMemoryFreeHead = this->mData;
    goto LABEL_6;
  }
  return result;
}


// Address: 0x21b63f0 | Name: _ZN4FMOD9DSPBufferD2Ev
void __fastcall FMOD::DSPBuffer::~DSPBuffer(FMOD::DSPBuffer *const this)
{
  if ( this->mData )
    FMOD::DSPBuffer::release(this);
}


// Address: 0x21b6410 | Name: _ZN4FMOD9DSPBuffer6copyToEPS0_
FMOD_RESULT_0 __fastcall FMOD::DSPBuffer::copyTo(FMOD::DSPBuffer *const this, FMOD::DSPBuffer *dest)
{
  FMOD_RESULT_0 result; // eax

  if ( !dest->mData || (result = FMOD::DSPBuffer::release(dest)) == FMOD_RESULT::FMOD_OK_0 )
  {
    *dest = *(FMOD::DSPBuffer *)this;
    ++this->mData->mRefCount;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b6460 | Name: _ZN4FMOD9DSPBuffer6moveToEPS0_
FMOD_RESULT_0 __fastcall FMOD::DSPBuffer::moveTo(FMOD::DSPBuffer *const this, FMOD::DSPBuffer *dest)
{
  FMOD_RESULT_0 result; // eax

  if ( !dest->mData || (result = FMOD::DSPBuffer::release(dest)) == FMOD_RESULT::FMOD_OK_0 )
  {
    *dest = *(FMOD::DSPBuffer *)this;
    this->mData = 0;
    this->mSystem = 0;
    *(_QWORD *)&this->mChannels = 0;
    *(_QWORD *)&this->mCacheIndex = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b64d0 | Name: _ZN4FMOD4DSPI16getInputInternalEiPPS0_PPNS_14DSPConnectionIEbb
FMOD_RESULT_0 __fastcall FMOD::DSPI::getInputInternal(
        FMOD::DSPI *const this,
        int index,
        FMOD::DSPI **inputdsp,
        FMOD::DSPConnectionI **input,
        bool standardonly,
        bool protect)
{
  FMOD::SystemI *mSystem; // r15
  char v10; // cl
  FMOD::DSPConnectionI *mClockNext; // r10
  FMOD_RESULT_0 v12; // edx
  FMOD::DSPI *mInputUnit; // rax
  FMOD::DSPI *mNodeNext; // r11
  int v16; // eax
  int i; // ebx
  bool result; // [rsp+Ch] [rbp-3Ch]
  FMOD_RESULT_0 resulta; // [rsp+Ch] [rbp-3Ch]

  mSystem = this->mSystem;
  if ( protect
    && (result = standardonly, FMOD::SystemI::flushDSPQueue(this->mSystem, 1), standardonly = result, mSystem) )
  {
    FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
    v10 = 1;
    standardonly = result;
  }
  else
  {
    v10 = 0;
  }
  if ( standardonly )
  {
    mClockNext = 0;
    v12 = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
    if ( this->mNumStandardInputs <= index )
      goto LABEL_5;
  }
  else
  {
    mClockNext = 0;
    v12 = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
    if ( this->mNumInputs <= index )
      goto LABEL_5;
  }
  mNodeNext = (FMOD::DSPI *)this->mJob.mInputHead.mNodeNext;
  LOBYTE(v12) = 28;
  if ( mNodeNext != (FMOD::DSPI *)&this->mJob.mInputHead )
  {
    mClockNext = (FMOD::DSPConnectionI *)mNodeNext->mJob.mDelayClock.mClockNext;
    v16 = 0;
    for ( i = standardonly ? 5 : 0; v16 < index || (i & mClockNext->mFlags) != 0; v16 += (i & mClockNext->mFlags) == 0 )
    {
      mNodeNext = (FMOD::DSPI *)mNodeNext->_vptr_DSPI;
      mClockNext = (FMOD::DSPConnectionI *)mNodeNext->mJob.mDelayClock.mClockNext;
    }
    v12 = FMOD_RESULT::FMOD_OK_0;
  }
LABEL_5:
  if ( input )
    *input = mClockNext;
  if ( inputdsp )
  {
    if ( mClockNext )
      mInputUnit = mClockNext->mInputUnit;
    else
      mInputUnit = 0;
    *inputdsp = mInputUnit;
  }
  if ( protect )
  {
    if ( mSystem && v10 )
      goto LABEL_24;
  }
  else if ( v10 && mSystem )
  {
LABEL_24:
    resulta = v12;
    FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
    return resulta;
  }
  return v12;
}


// Address: 0x21b6650 | Name: _ZN4FMOD4DSPI17getOutputInternalEiPPS0_PPNS_14DSPConnectionIEbb
FMOD_RESULT_0 __fastcall FMOD::DSPI::getOutputInternal(
        FMOD::DSPI *const this,
        int index,
        FMOD::DSPI **outputdsp,
        FMOD::DSPConnectionI **output,
        bool standardonly,
        bool protect)
{
  FMOD::SystemI *mSystem; // r15
  char v10; // cl
  FMOD::DSPConnectionI *mClockNext; // r10
  FMOD_RESULT_0 v12; // edx
  FMOD::DSPI *mOutputUnit; // rax
  FMOD::DSPI *mNodeNext; // r11
  int v16; // eax
  int i; // ebx
  bool result; // [rsp+Ch] [rbp-3Ch]
  FMOD_RESULT_0 resulta; // [rsp+Ch] [rbp-3Ch]

  mSystem = this->mSystem;
  if ( protect
    && (result = standardonly, FMOD::SystemI::flushDSPQueue(this->mSystem, 1), standardonly = result, mSystem) )
  {
    FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
    v10 = 1;
    standardonly = result;
  }
  else
  {
    v10 = 0;
  }
  if ( standardonly )
  {
    mClockNext = 0;
    v12 = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
    if ( this->mNumStandardOutputs <= index )
      goto LABEL_5;
  }
  else
  {
    mClockNext = 0;
    v12 = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
    if ( this->mNumOutputs <= index )
      goto LABEL_5;
  }
  mNodeNext = (FMOD::DSPI *)this->mOutputHead.mNodeNext;
  LOBYTE(v12) = 28;
  if ( mNodeNext != (FMOD::DSPI *)&this->mOutputHead )
  {
    mClockNext = (FMOD::DSPConnectionI *)mNodeNext->mJob.mDelayClock.mClockNext;
    v16 = 0;
    for ( i = standardonly ? 5 : 0; v16 < index || (i & mClockNext->mFlags) != 0; v16 += (i & mClockNext->mFlags) == 0 )
    {
      mNodeNext = (FMOD::DSPI *)mNodeNext->_vptr_DSPI;
      mClockNext = (FMOD::DSPConnectionI *)mNodeNext->mJob.mDelayClock.mClockNext;
    }
    v12 = FMOD_RESULT::FMOD_OK_0;
  }
LABEL_5:
  if ( output )
    *output = mClockNext;
  if ( outputdsp )
  {
    if ( mClockNext )
      mOutputUnit = mClockNext->mOutputUnit;
    else
      mOutputUnit = 0;
    *outputdsp = mOutputUnit;
  }
  if ( protect )
  {
    if ( mSystem && v10 )
      goto LABEL_24;
  }
  else if ( v10 && mSystem )
  {
LABEL_24:
    resulta = v12;
    FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
    return resulta;
  }
  return v12;
}


// Address: 0x21b67e0 | Name: _ZN4FMOD4DSPI17setActiveInternalEbb
FMOD_RESULT_0 __fastcall FMOD::DSPI::setActiveInternal(FMOD::DSPI *const this, bool active, bool from_main_mixer)
{
  if ( from_main_mixer && active != this->mJob.mActive )
    *(_DWORD *)(*(unsigned __int64 *)((char *)&stru_10788.r_offset + (unsigned __int64)this->mSystem) + 48) = 1;
  this->mJob.mActive = active;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b6810 | Name: _ZN4FMOD4DSPI9setActiveEbb
FMOD_RESULT_0 __fastcall FMOD::DSPI::setActive(FMOD::DSPI *const this, bool active, bool protect)
{
  unsigned __int16 mFlags; // ax
  FMOD_RESULT_0 result; // eax
  FMOD::DSPQueueCmd_SetActive *v8; // rsi
  FMOD::SystemI *mSystem; // rdi
  FMOD::DSPQueueCmd_SetActive *cmd; // [rsp+8h] [rbp-20h] BYREF

  mFlags = this->mJob.mFlags;
  if ( active == ((mFlags & 0x200) != 0) )
    return FMOD_RESULT::FMOD_OK_0;
  if ( (mFlags & 0x400) != 0 )
  {
    FMOD::DSPI::setActiveInternal(this, active, 0);
  }
  else
  {
    result = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 24, protect);
    if ( result )
      return result;
    v8 = cmd;
    mSystem = this->mSystem;
    *(_BYTE *)&cmd->FMOD::DSPQueueCmd = 14;
    v8->mActive = active;
    v8->mThis = this;
    result = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v8, protect);
    if ( result )
      return result;
  }
  if ( active )
    this->mJob.mFlags |= 0x200u;
  else
    this->mJob.mFlags &= ~0x200u;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b6930 | Name: _ZN4FMOD4DSPI16setChannelFormatEji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPI::setChannelFormat(
        FMOD::DSPI *const this,
        FMOD_CHANNELMASK channelmask,
        int numchannels,
        FMOD_SPEAKERMODE_0 _source_speakermode)
{
  FMOD_RESULT_0 result; // eax
  unsigned __int16 v5; // ax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (unsigned int)numchannels <= 0x20 )
  {
    if ( numchannels > 0 && _source_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
    {
      this->mDescription.mChannels = numchannels;
      LOBYTE(result) = 0;
      return result;
    }
    this->mState.source_speakermode = _source_speakermode;
    if ( numchannels || _source_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
    {
      this->mDescription.mChannels = numchannels;
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( _source_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    {
      v5 = 5;
      goto LABEL_13;
    }
    if ( _source_speakermode <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    {
      if ( _source_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
      {
LABEL_12:
        v5 = 2;
LABEL_13:
        this->mDescription.mChannels = v5;
        return FMOD_RESULT::FMOD_OK_0;
      }
      v5 = 4;
      if ( _source_speakermode > FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
        goto LABEL_13;
      LOBYTE(v5) = 1;
      if ( _source_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0 )
        goto LABEL_13;
    }
    else
    {
      v5 = 8;
      if ( _source_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
        goto LABEL_13;
      LOBYTE(v5) = 6;
      if ( _source_speakermode < FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
        goto LABEL_13;
      LOBYTE(v5) = 12;
      if ( _source_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
        goto LABEL_13;
      if ( _source_speakermode == 1000 )
        goto LABEL_12;
    }
    v5 = 0;
    goto LABEL_13;
  }
  return result;
}


// Address: 0x21b69d0 | Name: _ZN4FMOD4DSPI16getChannelFormatEPjPiP16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPI::getChannelFormat(
        FMOD::DSPI *const this,
        FMOD_CHANNELMASK *_channelmask,
        int *numchannels,
        FMOD_SPEAKERMODE_0 *_source_speakermode)
{
  if ( _channelmask )
    *_channelmask = 0;
  if ( numchannels )
    *numchannels = this->mDescription.mChannels;
  if ( _source_speakermode )
    *_source_speakermode = this->mState.source_speakermode;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b6a00 | Name: _ZN4FMOD4DSPI8setDelayEyyb
FMOD_RESULT_0 __fastcall FMOD::DSPI::setDelay(
        FMOD::DSPI *const this,
        FMOD_CLOCKTIME dspclock_start,
        FMOD_CLOCKTIME dspclock_end,
        bool stopchannels)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *mSystem; // rdi
  FMOD::DSPQueueCmd_SetDelay *v10; // rsi
  FMOD::SystemI *v11; // rdi
  FMOD::DSPQueueCmd_SetDelay *cmd; // [rsp+8h] [rbp-30h] BYREF

  if ( !dspclock_start
    || !dspclock_end
    || (result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0, dspclock_start <= dspclock_end) )
  {
    if ( this->mJob.mDelayClock.mDelayStartShadow == dspclock_start
      && this->mJob.mDelayClock.mDelayEndShadow == dspclock_end
      && this->mJob.mDelayClock.mStopChannelsShadow == stopchannels )
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      mSystem = this->mSystem;
      this->mJob.mDelayClock.mDelayStartShadow = dspclock_start;
      this->mJob.mDelayClock.mDelayEndShadow = dspclock_end;
      this->mJob.mDelayClock.mStopChannelsShadow = stopchannels;
      result = FMOD::SystemI::lockDSPQueueCmd(mSystem, (void **)&cmd, 40, 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v10 = cmd;
        v11 = this->mSystem;
        cmd->mThis = this;
        v10->mStartDelay = dspclock_start;
        v10->mEndDelay = dspclock_end;
        v10->mStopChannels = stopchannels;
        *(_BYTE *)&v10->FMOD::DSPQueueCmd = 15;
        return FMOD::SystemI::unlockDSPQueueCmd(v11, v10, 1);
      }
    }
  }
  return result;
}


// Address: 0x21b6ac0 | Name: _ZN4FMOD4DSPI16setDelayInternalEyyb
FMOD_RESULT_0 __fastcall FMOD::DSPI::setDelayInternal(
        FMOD::DSPI *const this,
        FMOD_CLOCKTIME dspclock_start,
        FMOD_CLOCKTIME dspclock_end,
        bool stopchannels)
{
  FMOD_RESULT_0 result; // eax

  if ( !dspclock_start
    || !dspclock_end
    || (result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0, dspclock_start <= dspclock_end) )
  {
    result = FMOD_RESULT::FMOD_OK_0;
    this->mJob.mDelayClock.mDelayStart = dspclock_start;
    this->mJob.mDelayClock.mDelayEnd = dspclock_end;
    this->mJob.mDelayClock.mStopNow = 0;
    if ( stopchannels )
      this->mJob.mDelayClock.mStopChannels = 1;
  }
  return result;
}


// Address: 0x21b6b00 | Name: _ZN4FMOD4DSPI8getDelayEPyS1_Pb
FMOD_RESULT_0 __fastcall FMOD::DSPI::getDelay(
        FMOD::DSPI *const this,
        FMOD_CLOCKTIME *dspclock_start,
        FMOD_CLOCKTIME *dspclock_end,
        bool *stopchannels)
{
  if ( dspclock_start )
    *dspclock_start = this->mJob.mDelayClock.mDelayStartShadow;
  if ( dspclock_end )
    *dspclock_end = this->mJob.mDelayClock.mDelayEndShadow;
  if ( stopchannels )
    *stopchannels = this->mJob.mDelayClock.mStopChannelsShadow;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b6b30 | Name: _ZN4FMOD10DSPJobList6addJobEPNS_6DSPJobE
FMOD_RESULT_0 __fastcall FMOD::DSPJobList::addJob(FMOD::DSPJobList *const this, FMOD::DSPJob *job)
{
  int mNumJobs; // eax
  FMOD::DSPJobEntry *mJob; // rbp
  __int64 v4; // rdx
  int mMaxJobs; // edx
  int mJobExpand; // eax
  int v8; // edx
  void *mJobMemory; // r12
  char *v10; // rax
  unsigned int v11; // ebp
  FMOD::DSPJobEntry *v12; // rdx

  mNumJobs = this->mNumJobs;
  mJob = this->mJob;
  v4 = mNumJobs++;
  mJob[v4].mJob = job;
  mMaxJobs = this->mMaxJobs;
  job->mInfo.mInJobList = 1;
  this->mNumJobs = mNumJobs;
  if ( mNumJobs >= mMaxJobs )
  {
    mJobExpand = this->mJobExpand;
    if ( !mJobExpand )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v8 = mJobExpand + mMaxJobs;
    mJobMemory = this->mJobMemory;
    this->mMaxJobs = v8;
    v10 = (char *)FMOD::MemPool::realloc(
                    off_286F358->gSystemMemPool,
                    mJobMemory,
                    8 * v8 + 16,
                    "../../../core_api/src/fmod_dspi.cpp",
                    1240,
                    0);
    if ( !v10 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v11 = (_DWORD)mJob - (_DWORD)mJobMemory;
    this->mJobMemory = v10;
    v12 = (FMOD::DSPJobEntry *)((unsigned __int64)(v10 + 15) & 0xFFFFFFFFFFFFFFF0LL);
    this->mJob = v12;
    if ( v11 != (_DWORD)v12 - (_DWORD)v10 )
      memmove(&v10[(_DWORD)v12 - (_DWORD)v10], &v10[v11], 8LL * this->mMaxJobs);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b6c00 | Name: _ZN4FMOD10DSPJobList15addExecutingJobEPNS_6DSPJobE
FMOD_RESULT_0 __fastcall FMOD::DSPJobList::addExecutingJob(FMOD::DSPJobList *const this, FMOD::DSPJob *job)
{
  if ( !job->mInfo.mInJobList )
    FMOD::DSPJobList::addJob(this, job);
  if ( !job->mInfo.mExecute )
  {
    job->mInfo.mExecute = 1;
    ++this->mNumExecutingJobs;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b6c50 | Name: _ZN4FMOD10DSPJobList18addNonExecutingJobEPNS_6DSPJobE
FMOD_RESULT_0 __fastcall FMOD::DSPJobList::addNonExecutingJob(FMOD::DSPJobList *const this, FMOD::DSPJob *job)
{
  if ( !job->mInfo.mInJobList )
    FMOD::DSPJobList::addJob(this, job);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b6c70 | Name: _ZN4FMOD24specificizeChannelFormatEPiP16FMOD_SPEAKERMODES1_
void __fastcall FMOD::specificizeChannelFormat(
        int *numchannels,
        FMOD_SPEAKERMODE_0 *mode,
        FMOD_SPEAKERMODE_0 defaultmode)
{
  FMOD_SPEAKERMODE_0 v3; // eax
  bool v4; // cc
  int v5; // eax
  __int64 v6; // rax

  v3 = *mode;
  if ( *mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
  {
    if ( *numchannels > 0 )
    {
      v6 = (unsigned int)(*numchannels - 1);
      if ( (unsigned int)v6 > 0xB )
      {
        defaultmode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
        *mode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
        goto LABEL_13;
      }
      defaultmode = dword_595CA0[v6];
    }
    *mode = defaultmode;
LABEL_13:
    v4 = defaultmode <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0;
    if ( defaultmode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
      goto LABEL_3;
LABEL_14:
    *numchannels = 5;
    return;
  }
  defaultmode = *mode;
  v4 = v3 <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0;
  if ( v3 == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    goto LABEL_14;
LABEL_3:
  if ( v4 )
  {
    if ( defaultmode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
      goto LABEL_8;
    v5 = 4;
    if ( defaultmode > FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
      goto LABEL_9;
    LOBYTE(v5) = 1;
    if ( defaultmode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0 )
      goto LABEL_9;
  }
  else
  {
    v5 = 8;
    if ( defaultmode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
      goto LABEL_9;
    LOBYTE(v5) = 6;
    if ( defaultmode < FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
      goto LABEL_9;
    LOBYTE(v5) = 12;
    if ( defaultmode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
      goto LABEL_9;
    if ( defaultmode == 1000 )
    {
LABEL_8:
      v5 = 2;
LABEL_9:
      *numchannels = v5;
      return;
    }
  }
  *numchannels = *numchannels;
}


// Address: 0x21b6d00 | Name: _ZN4FMOD20formatCheckShouldMixEi16FMOD_SPEAKERMODEiS0_S0_
bool __fastcall FMOD::formatCheckShouldMix(
        int srcnumchannels,
        FMOD_SPEAKERMODE_0 srcmode,
        int destnumchannels,
        FMOD_SPEAKERMODE_0 destmode,
        FMOD_SPEAKERMODE_0 defaultmode)
{
  bool result; // al
  FMOD_SPEAKERMODE_0 destmodea; // [rsp+10h] [rbp-18h] BYREF
  int destnumchannelsa; // [rsp+14h] [rbp-14h] BYREF
  FMOD_SPEAKERMODE_0 srcmodea; // [rsp+18h] [rbp-10h] BYREF
  int srcnumchannelsa[3]; // [rsp+1Ch] [rbp-Ch] BYREF

  srcnumchannelsa[0] = srcnumchannels;
  srcmodea = srcmode;
  destnumchannelsa = destnumchannels;
  destmodea = destmode;
  if ( srcmode == destmode && srcnumchannels == destnumchannels )
    return 0;
  FMOD::specificizeChannelFormat(srcnumchannelsa, &srcmodea, defaultmode);
  FMOD::specificizeChannelFormat(&destnumchannelsa, &destmodea, defaultmode);
  result = 1;
  if ( srcnumchannelsa[0] == destnumchannelsa && srcmodea == destmodea )
    return 0;
  return result;
}


// Address: 0x21b6d80 | Name: _ZN4FMOD4DSPI8validateEPNS_3DSPEPPS0_PNS_15SystemLockScopeE
FMOD_RESULT_0 __fastcall FMOD::DSPI::validate(FMOD::DSP *dsp, FMOD::DSPI **dspi_out, FMOD::SystemLockScope *lockScope)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v4; // rbx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dspi_out )
  {
    *dspi_out = (FMOD::DSPI *)dsp;
    LOBYTE(result) = 30;
    if ( dsp )
    {
      if ( ((unsigned __int8)dsp & 3) == 0 && (dsp[93].gap0 & 0x10) == 0 && *(_DWORD *)&dsp[160].gap0 == -1395763731 )
      {
        LOBYTE(result) = 0;
        if ( lockScope )
        {
          LOBYTE(result) = 28;
          v4 = *(FMOD::SystemI **)&dsp[176].gap0;
          if ( !lockScope->mSystem )
          {
            if ( v4 )
            {
              result = FMOD::SystemI::enterMainUpdateLock(v4);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
                lockScope->mSystem = v4;
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21b6e00 | Name: _ZN4FMOD4DSPI11getPositionEP14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::DSPI::getPosition(FMOD::DSPI *const this, FMOD_UINT32_32 *pcm)
{
  if ( (this->mJob.mFlags & 0x2000) == 0 )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::DSPI *const, FMOD_UINT32_32 *))this->_vptr_DSPI + 1))(this, pcm);
  pcm->mValue = (FMOD_UINT64)this->mPositionShadow;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b6e30 | Name: _ZN4FMOD4DSPI22calculateSpeakerLevelsEffffffff16FMOD_SPEAKERMODEi17FMOD_CHANNELORDERPfPi
// local variable allocation has failed, the output may be wrong!
__int64 __fastcall FMOD::DSPI::calculateSpeakerLevels(
        float frontleft,
        float frontright,
        float center,
        float lfe,
        float surroundleft,
        float surroundright,
        float backleft,
        float backright,
        int speakermode,
        int channels,
        FMOD_CHANNELORDER_0 channelorder,
        float *outlevels,
        int *numinputlevels)
{
  float *v13; // rbp
  unsigned int v14; // eax
  _BYTE *v15; // rsi
  float *v16; // rdi
  __int64 v17; // rdx
  __int64 v18; // rcx
  float *v19; // rdi
  _DWORD *v20; // rsi
  int *v22; // r8
  int m; // eax
  float v24; // xmm2_4
  __int64 v25; // rdx
  int i; // eax
  int j; // eax
  int n; // eax
  int k; // eax
  int ii; // eax
  _BYTE *v31; // rsi
  float *v32; // rdi
  unsigned int v33; // eax
  __int64 v34; // rdx
  __int64 v35; // rcx
  float *v36; // rdi
  _DWORD *v37; // rsi
  float v38; // xmm2_4
  float v39; // xmm2_4
  float v40; // xmm2_4
  unsigned int v41; // eax
  float *v42; // rdi
  _BYTE *v43; // rsi
  __int64 v44; // rdx
  __int64 v45; // rcx
  float *v46; // rdi
  _DWORD *v47; // rsi
  unsigned int v48; // eax
  _BYTE *v49; // rsi
  float *v50; // rdi
  __int64 v51; // rdx
  __int64 v52; // rcx
  float *v53; // rdi
  _DWORD *v54; // rsi
  float v55; // xmm3_4
  float v56; // xmm3_4
  float v57; // xmm6_4
  float v58; // xmm2_4
  unsigned int v59; // xmm0_4
  unsigned int v60; // xmm1_4
  unsigned int v61; // xmm2_4
  unsigned int v62; // xmm3_4
  float v63; // xmm2_4
  float v64; // xmm3_4
  float v65; // xmm3_4
  float v66; // xmm3_4
  float v67; // xmm3_4
  float v68; // xmm3_4
  unsigned __int64 v69; // r12
  float *v70; // rbp
  __int64 v71; // rax
  float v72; // xmm2_4
  __int64 v73; // rdx
  __int64 v74; // rax
  __int64 v75; // rax
  __int64 v76; // rax
  __int16 v77; // dx
  int v78; // edx
  __int16 v79; // dx
  int v80; // edx
  int v81; // edx
  __int16 v82; // dx
  int v83; // edx
  __int16 v84; // dx
  _BYTE levels[576]; // [rsp+20h] [rbp-258h] OVERLAPPED BYREF

  v13 = outlevels;
  *numinputlevels = 0;
  if ( speakermode == 5 )
  {
    if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLMONO_0 )
    {
      memset(outlevels, 0, 20LL * channels);
      v22 = numinputlevels;
      if ( channels > 0 )
      {
        v75 = 0;
        do
          v13[2 * channels + v75++] = center;
        while ( channels > (int)v75 );
      }
    }
    else
    {
      if ( channelorder != FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLSTEREO_0 && (channels == 12 || channels <= 8) )
      {
        switch ( channels )
        {
          case 1:
            *(_QWORD *)levels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
            *(float *)&levels[8] = center;
            *(float *)&levels[12] = surroundleft;
            *(_QWORD *)outlevels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
            *(float *)&levels[16] = surroundright;
            *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
            outlevels[4] = *(float *)&levels[16];
            *numinputlevels = 1;
            break;
          case 2:
            *(_QWORD *)levels = LODWORD(frontleft);
            *(_DWORD *)&levels[8] = 0;
            *(float *)&levels[12] = frontright;
            *(_QWORD *)&levels[24] = LODWORD(surroundleft);
            *(_DWORD *)&levels[32] = 0;
            *(float *)&levels[36] = surroundright;
            *(_QWORD *)outlevels = LODWORD(frontleft);
            *(float *)&levels[16] = center * 0.5;
            *(float *)&levels[20] = center * 0.5;
            *(_OWORD *)(outlevels + 2) = *(_OWORD *)&levels[8];
            *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
            *numinputlevels = 2;
            break;
          case 4:
            v40 = center * 0.5;
            memset(levels, 0, 0x50u);
            *(float *)levels = frontleft;
            *(float *)&levels[20] = frontright;
            *(float *)&levels[56] = surroundleft;
            *(float *)&levels[76] = surroundright;
            *(float *)&levels[32] = v40;
            *(_QWORD *)outlevels = *(_QWORD *)levels;
            *(float *)&levels[36] = v40;
            *(_OWORD *)(outlevels + 2) = *(_OWORD *)&levels[8];
            *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
            *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
            *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
            *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
            *((_QWORD *)outlevels + 8) = *(_QWORD *)&levels[64];
            *((_QWORD *)outlevels + 9) = *(_QWORD *)&levels[72];
            *numinputlevels = 4;
            break;
          case 6:
            memset(levels, 0, 0x78u);
            *(float *)levels = frontleft;
            if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_PROTOOLS_0 )
            {
              *(float *)&levels[32] = frontright;
              *(float *)&levels[52] = center;
              *(float *)&levels[84] = surroundleft;
              *(float *)&levels[112] = surroundright;
            }
            else
            {
              *(float *)&levels[28] = frontright;
              *(float *)&levels[56] = center;
              *(float *)&levels[88] = surroundleft;
              *(float *)&levels[116] = surroundright;
            }
            *(_OWORD *)outlevels = *(_OWORD *)levels;
            *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
            *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
            *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
            *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
            *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
            *((_QWORD *)outlevels + 8) = *(_QWORD *)&levels[64];
            *((_QWORD *)outlevels + 9) = *(_QWORD *)&levels[72];
            *((_QWORD *)outlevels + 10) = *(_QWORD *)&levels[80];
            *((_QWORD *)outlevels + 11) = *(_QWORD *)&levels[88];
            *((_QWORD *)outlevels + 12) = *(_QWORD *)&levels[96];
            *((_QWORD *)outlevels + 13) = *(_QWORD *)&levels[104];
            *((_QWORD *)outlevels + 14) = *(_QWORD *)&levels[112];
LABEL_121:
            *numinputlevels = 6;
            break;
          case 8:
            v14 = 160;
            v15 = levels;
            memset(levels, 0, 0xA0u);
            *(float *)levels = frontleft;
            v16 = outlevels;
            *(float *)&levels[36] = frontright;
            *(float *)&levels[72] = center;
            *(float *)&levels[112] = surroundleft;
            *(float *)&levels[148] = surroundright;
            *(float *)&levels[24] = backleft * 0.5;
            *(float *)&levels[60] = backright * 0.5;
            *(float *)&levels[120] = backleft * 0.5;
            *(float *)&levels[156] = backright * 0.5;
            if ( ((unsigned __int8)outlevels & 1) != 0 )
            {
              v16 = (float *)((char *)outlevels + 1);
              v15 = &levels[1];
              *(_BYTE *)outlevels = levels[0];
              v14 = 159;
            }
LABEL_33:
            if ( ((unsigned __int8)v16 & 2) != 0 )
            {
              v79 = *(_WORD *)v15;
              v16 = (float *)((char *)v16 + 2);
              v15 += 2;
              v14 -= 2;
              *((_WORD *)v16 - 1) = v79;
            }
            if ( ((unsigned __int8)v16 & 4) != 0 )
            {
              v80 = *(_DWORD *)v15;
              ++v16;
              v15 += 4;
              v14 -= 4;
              *((_DWORD *)v16 - 1) = v80;
            }
            v17 = 0;
            v18 = v14 >> 3;
            qmemcpy(v16, v15, 8 * v18);
            v20 = &v15[8 * v18];
            v19 = &v16[2 * v18];
            if ( (v14 & 4) != 0 )
            {
              *v19 = *(float *)v20;
              v17 = 4;
            }
            if ( (v14 & 2) != 0 )
            {
              *(_WORD *)((char *)v19 + v17) = *(_WORD *)((char *)v20 + v17);
              v17 += 2;
            }
            if ( (v14 & 1) != 0 )
              *((_BYTE *)v19 + v17) = *((_BYTE *)v20 + v17);
            *numinputlevels = 8;
            break;
          case 12:
            v33 = 240;
            v31 = levels;
            memset(levels, 0, 0xF0u);
            *(float *)levels = frontleft;
            v32 = outlevels;
            *(float *)&levels[52] = frontright;
            *(float *)&levels[104] = center;
            *(float *)&levels[160] = surroundleft;
            *(float *)&levels[212] = surroundright;
            *(float *)&levels[24] = backleft * 0.5;
            *(float *)&levels[76] = backright * 0.5;
            *(float *)&levels[168] = backleft * 0.5;
            *(float *)&levels[220] = backright * 0.5;
            if ( ((unsigned __int8)outlevels & 1) != 0 )
            {
              v32 = (float *)((char *)outlevels + 1);
              v31 = &levels[1];
              *(_BYTE *)outlevels = levels[0];
              v33 = 239;
            }
LABEL_103:
            if ( ((unsigned __int8)v32 & 2) != 0 )
            {
              v77 = *(_WORD *)v31;
              v32 = (float *)((char *)v32 + 2);
              v31 += 2;
              v33 -= 2;
              *((_WORD *)v32 - 1) = v77;
            }
            if ( ((unsigned __int8)v32 & 4) != 0 )
            {
              v78 = *(_DWORD *)v31;
              ++v32;
              v31 += 4;
              v33 -= 4;
              *((_DWORD *)v32 - 1) = v78;
            }
            v34 = 0;
            v35 = v33 >> 3;
            qmemcpy(v32, v31, 8 * v35);
            v37 = &v31[8 * v35];
            v36 = &v32[2 * v35];
            if ( (v33 & 4) != 0 )
            {
              *v36 = *(float *)v37;
              v34 = 4;
            }
            if ( (v33 & 2) != 0 )
            {
              *(_WORD *)((char *)v36 + v34) = *(_WORD *)((char *)v37 + v34);
              v34 += 2;
            }
            if ( (v33 & 1) != 0 )
              *((_BYTE *)v36 + v34) = *((_BYTE *)v37 + v34);
            *numinputlevels = 12;
            break;
          default:
            return 0;
        }
        return 0;
      }
      memset(outlevels, 0, 20LL * channels);
      v22 = numinputlevels;
      if ( channels > 0 )
      {
        for ( i = 0; i != channels; ++i )
        {
          if ( (i & 1) != 0 )
            v13[channels] = frontright;
          else
            *v13 = frontleft;
          ++v13;
        }
      }
    }
    goto LABEL_64;
  }
  if ( speakermode <= 5 )
  {
    if ( speakermode != 3 )
    {
      if ( speakermode <= 3 )
      {
        if ( speakermode == 2 )
        {
          switch ( channels )
          {
            case 1:
              *outlevels = fsqrt(
                             (float)((float)(frontleft * frontleft) + (float)((float)(center * center) * 0.5))
                           + (float)((float)(surroundleft * surroundleft) * 0.25));
              *numinputlevels = 1;
              break;
            case 2:
              *(_QWORD *)outlevels = __PAIR64__(
                                       COERCE_UNSIGNED_INT(
                                         fsqrt(
                                           (float)((float)(frontright * frontright)
                                                 + (float)((float)(center * center) * 0.5))
                                         + (float)((float)(surroundleft * surroundleft) * 0.25))),
                                       COERCE_UNSIGNED_INT(
                                         fsqrt(
                                           (float)((float)(frontleft * frontleft)
                                                 + (float)((float)(center * center) * 0.5))
                                         + (float)((float)(surroundleft * surroundleft) * 0.25))));
              *numinputlevels = 2;
              break;
            case 4:
              *(_QWORD *)levels = LODWORD(frontleft);
              *(_DWORD *)&levels[12] = 0;
              *(_QWORD *)outlevels = LODWORD(frontleft);
              *(float *)&levels[8] = surroundleft * 0.5;
              *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
              *numinputlevels = 4;
              break;
            case 6:
              *(_QWORD *)levels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[8] = center;
              *(float *)&levels[12] = lfe;
              *(_QWORD *)outlevels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[16] = surroundleft;
              *(float *)&levels[20] = surroundright;
              *(_OWORD *)(outlevels + 2) = *(_OWORD *)&levels[8];
              *numinputlevels = 6;
              break;
            case 8:
              *(_QWORD *)levels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[8] = center;
              *(float *)&levels[12] = lfe;
              *(_QWORD *)outlevels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[16] = surroundleft;
              *(float *)&levels[20] = surroundright;
              *(_QWORD *)&levels[24] = __PAIR64__(LODWORD(backright), LODWORD(backleft));
              *(_OWORD *)(outlevels + 2) = *(_OWORD *)&levels[8];
              *((_QWORD *)outlevels + 3) = *(_QWORD *)&levels[24];
              *numinputlevels = 8;
              break;
            case 12:
              memset(levels, 0, 0x30u);
              *(_QWORD *)levels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[8] = center;
              *(float *)&levels[12] = lfe;
              *(float *)&levels[16] = surroundleft;
              *(_QWORD *)outlevels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[20] = surroundright;
              *(_QWORD *)&levels[24] = __PAIR64__(LODWORD(backright), LODWORD(backleft));
              *(_OWORD *)(outlevels + 2) = *(_OWORD *)&levels[8];
              *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
              *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
              *numinputlevels = 12;
              break;
            default:
              return 0;
          }
        }
        return 0;
      }
      if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLMONO_0 )
      {
        memset(outlevels, 0, 16LL * channels);
        v22 = numinputlevels;
        if ( channels > 0 )
        {
          v72 = center * 0.70700002;
          v73 = (__int64)&v13[channels - 1 + 1];
          do
          {
            *v13 = v72;
            v13[channels] = v72;
            ++v13;
          }
          while ( v13 != (float *)v73 );
        }
      }
      else
      {
        if ( channelorder != FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLSTEREO_0 && (channels == 12 || channels <= 8) )
        {
          switch ( channels )
          {
            case 1:
              *(float *)&v59 = frontleft + center;
              *(float *)&levels[8] = surroundleft;
              *(float *)&v60 = frontright + center;
              *(float *)&levels[12] = surroundright;
              *(_QWORD *)levels = __PAIR64__(v60, v59);
              *(_QWORD *)outlevels = __PAIR64__(v60, v59);
              *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
              *numinputlevels = 1;
              break;
            case 2:
              *(_QWORD *)levels = LODWORD(frontleft);
              *(_DWORD *)&levels[8] = 0;
              *(float *)&levels[12] = frontright;
              *(_QWORD *)&levels[16] = LODWORD(surroundleft);
              *(_DWORD *)&levels[24] = 0;
              *(_QWORD *)outlevels = LODWORD(frontleft);
              *(float *)&levels[28] = surroundright;
              *(_OWORD *)(outlevels + 2) = *(_OWORD *)&levels[8];
              *((_QWORD *)outlevels + 3) = *(_QWORD *)&levels[24];
              *numinputlevels = 2;
              break;
            case 4:
              memset(levels, 0, 0x40u);
              *(float *)levels = frontleft;
              *(float *)&levels[20] = frontright;
              *(_OWORD *)outlevels = *(_OWORD *)levels;
              *(float *)&levels[40] = surroundleft * 0.5;
              *(float *)&levels[60] = 0.5 * surroundright;
              *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
              *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
              *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
              *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
              *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
              *numinputlevels = 4;
              break;
            case 6:
              v58 = center * 0.5;
              memset(levels, 0, 0x60u);
              *(float *)levels = frontleft;
              if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_PROTOOLS_0 )
              {
                *(float *)&levels[4] = v58;
                *(float *)&levels[28] = v58;
                *(float *)&levels[32] = frontright;
                *(float *)&levels[60] = surroundleft;
                *(float *)&levels[88] = surroundright;
                *(float *)&levels[20] = lfe * 0.25;
                *(float *)&levels[44] = lfe * 0.25;
                *(float *)&levels[68] = lfe * 0.25;
                *(float *)&levels[92] = lfe * 0.25;
              }
              else
              {
                *(float *)&levels[8] = v58;
                *(float *)&levels[28] = frontright;
                *(float *)&levels[32] = v58;
                *(float *)&levels[64] = surroundleft;
                *(float *)&levels[92] = surroundright;
                *(float *)&levels[12] = lfe * 0.25;
                *(float *)&levels[36] = lfe * 0.25;
                *(float *)&levels[60] = lfe * 0.25;
                *(float *)&levels[84] = lfe * 0.25;
              }
              *(_OWORD *)outlevels = *(_OWORD *)levels;
              *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
              *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
              *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
              *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
              *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
              *((_QWORD *)outlevels + 8) = *(_QWORD *)&levels[64];
              *((_QWORD *)outlevels + 9) = *(_QWORD *)&levels[72];
              *((_QWORD *)outlevels + 10) = *(_QWORD *)&levels[80];
              *((_QWORD *)outlevels + 11) = *(_QWORD *)&levels[88];
              goto LABEL_121;
            case 8:
              v56 = lfe * 0.25;
              memset(levels, 0, 0x80u);
              *(float *)levels = frontleft;
              *(float *)&levels[36] = frontright;
              v57 = backleft * 0.5;
              *(float *)&levels[80] = surroundleft;
              *(float *)&levels[12] = v56;
              *(_QWORD *)outlevels = *(_QWORD *)levels;
              *(float *)&levels[44] = v56;
              *(float *)&levels[8] = center * 0.5;
              *(float *)&levels[24] = v57;
              *(float *)&levels[40] = center * 0.5;
              *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
              *(float *)&levels[60] = 0.5 * backright;
              *(float *)&levels[76] = v56;
              *(float *)&levels[88] = v57;
              *(float *)&levels[108] = v56;
              *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
              *(float *)&levels[116] = surroundright;
              *(float *)&levels[124] = 0.5 * backright;
              *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
              *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
              *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
              *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
              *((_QWORD *)outlevels + 8) = *(_QWORD *)&levels[64];
              *((_QWORD *)outlevels + 9) = *(_QWORD *)&levels[72];
              *((_QWORD *)outlevels + 10) = *(_QWORD *)&levels[80];
              *((_QWORD *)outlevels + 11) = *(_QWORD *)&levels[88];
              *((_QWORD *)outlevels + 12) = *(_QWORD *)&levels[96];
              *((_QWORD *)outlevels + 13) = *(_QWORD *)&levels[104];
              *((_QWORD *)outlevels + 14) = *(_QWORD *)&levels[112];
              *((_QWORD *)outlevels + 15) = *(_QWORD *)&levels[120];
              *numinputlevels = 8;
              break;
            case 12:
              v33 = 192;
              v31 = levels;
              memset(levels, 0, 0xC0u);
              *(float *)levels = frontleft;
              v32 = outlevels;
              *(float *)&levels[52] = frontright;
              *(float *)&levels[12] = lfe * 0.25;
              *(float *)&levels[60] = lfe * 0.25;
              *(float *)&levels[108] = lfe * 0.25;
              *(float *)&levels[8] = center * 0.5;
              *(float *)&levels[24] = backleft * 0.5;
              *(float *)&levels[56] = center * 0.5;
              *(float *)&levels[76] = 0.5 * backright;
              *(float *)&levels[112] = surroundleft;
              *(float *)&levels[120] = backleft * 0.5;
              *(float *)&levels[156] = lfe * 0.25;
              *(float *)&levels[164] = surroundright;
              *(float *)&levels[172] = 0.5 * backright;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v32 = (float *)((char *)outlevels + 1);
                v31 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v33 = 191;
              }
              goto LABEL_103;
            default:
              return 0;
          }
          return 0;
        }
        memset(outlevels, 0, 16LL * channels);
        v22 = numinputlevels;
        if ( channels > 0 )
        {
          for ( j = 0; j != channels; ++j )
          {
            if ( (j & 1) != 0 )
              v13[channels] = frontright;
            else
              *v13 = frontleft;
            ++v13;
          }
        }
      }
      goto LABEL_64;
    }
  }
  else
  {
    if ( speakermode == 7 )
    {
      if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLMONO_0 )
      {
        v69 = 8 * channels;
        memset(outlevels, 0, 4 * v69);
        v22 = numinputlevels;
        if ( channels > 0 )
        {
          v70 = &v13[v69 / 4];
          v71 = 0;
          do
            v70[v71++] = center;
          while ( channels > (int)v71 );
        }
      }
      else
      {
        if ( channelorder != FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLSTEREO_0 && (channels == 12 || channels <= 8) )
        {
          switch ( channels )
          {
            case 1:
              *(_QWORD *)levels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[8] = center;
              *(float *)&levels[12] = lfe;
              *(_QWORD *)outlevels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[16] = surroundleft;
              *(float *)&levels[20] = surroundright;
              *(_QWORD *)&levels[24] = __PAIR64__(LODWORD(backright), LODWORD(backleft));
              *(_OWORD *)(outlevels + 2) = *(_OWORD *)&levels[8];
              *((_QWORD *)outlevels + 3) = *(_QWORD *)&levels[24];
              *numinputlevels = 1;
              break;
            case 2:
              memset(levels, 0, 0x40u);
              *(float *)levels = frontleft;
              *(float *)&levels[12] = frontright;
              v66 = lfe * 0.5;
              *(float *)&levels[32] = surroundleft;
              *(float *)&levels[44] = surroundright;
              *(_QWORD *)outlevels = *(_QWORD *)levels;
              *(float *)&levels[48] = backleft;
              *(float *)&levels[16] = center * 0.5;
              *(float *)&levels[20] = center * 0.5;
              *(float *)&levels[24] = v66;
              *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
              *(float *)&levels[28] = v66;
              *(float *)&levels[60] = backright;
              *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
              *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
              *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
              *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
              *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
              *numinputlevels = 2;
              break;
            case 4:
              memset(levels, 0, 0x80u);
              *(float *)levels = frontleft;
              *(float *)&levels[20] = frontright;
              *(_QWORD *)outlevels = *(_QWORD *)levels;
              v65 = lfe * 0.5;
              *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
              *(float *)&levels[32] = center * 0.5;
              *(float *)&levels[36] = center * 0.5;
              *(float *)&levels[48] = v65;
              *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
              *(float *)&levels[52] = v65;
              *(float *)&levels[72] = surroundleft * 0.5;
              *(float *)&levels[92] = surroundright * 0.5;
              *(float *)&levels[104] = backleft * 0.5;
              *((_QWORD *)outlevels + 3) = *(_QWORD *)&levels[24];
              *(float *)&levels[124] = 0.5 * backright;
              *((_OWORD *)outlevels + 2) = *(_OWORD *)&levels[32];
              *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
              *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
              *((_QWORD *)outlevels + 8) = *(_QWORD *)&levels[64];
              *((_QWORD *)outlevels + 9) = *(_QWORD *)&levels[72];
              *((_QWORD *)outlevels + 10) = *(_QWORD *)&levels[80];
              *((_QWORD *)outlevels + 11) = *(_QWORD *)&levels[88];
              *((_QWORD *)outlevels + 12) = *(_QWORD *)&levels[96];
              *((_QWORD *)outlevels + 13) = *(_QWORD *)&levels[104];
              *((_QWORD *)outlevels + 14) = *(_QWORD *)&levels[112];
              *((_QWORD *)outlevels + 15) = *(_QWORD *)&levels[120];
              *numinputlevels = 4;
              break;
            case 6:
              v41 = 0;
              memset(levels, 0, 0xC0u);
              *(float *)levels = frontleft;
              if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_PROTOOLS_0 )
              {
                *(float *)&levels[32] = frontright;
                *(float *)&levels[52] = center;
                *(float *)&levels[92] = lfe;
                *(float *)&levels[108] = surroundleft;
                *(float *)&levels[136] = surroundright;
                *(float *)&levels[144] = backleft * 0.5;
                *(float *)&levels[156] = backleft * 0.5;
                *(float *)&levels[176] = backright * 0.5;
                *(float *)&levels[184] = backright * 0.5;
              }
              else
              {
                *(float *)&levels[28] = frontright;
                *(float *)&levels[56] = center;
                *(float *)&levels[84] = lfe;
                *(float *)&levels[112] = surroundleft;
                *(float *)&levels[140] = surroundright;
                *(float *)&levels[144] = backleft * 0.5;
                *(float *)&levels[160] = backleft * 0.5;
                *(float *)&levels[172] = backright * 0.5;
                *(float *)&levels[188] = backright * 0.5;
              }
              v42 = outlevels;
              v43 = levels;
              LOBYTE(v41) = -64;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v42 = (float *)((char *)outlevels + 1);
                v43 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v41 = 191;
              }
LABEL_137:
              if ( ((unsigned __int8)v42 & 2) != 0 )
              {
                v82 = *(_WORD *)v43;
                v42 = (float *)((char *)v42 + 2);
                v43 += 2;
                v41 -= 2;
                *((_WORD *)v42 - 1) = v82;
              }
              if ( ((unsigned __int8)v42 & 4) != 0 )
              {
                v81 = *(_DWORD *)v43;
                ++v42;
                v43 += 4;
                v41 -= 4;
                *((_DWORD *)v42 - 1) = v81;
              }
              v44 = 0;
              v45 = v41 >> 3;
              qmemcpy(v42, v43, 8 * v45);
              v47 = &v43[8 * v45];
              v46 = &v42[2 * v45];
              if ( (v41 & 4) != 0 )
              {
                *v46 = *(float *)v47;
                v44 = 4;
              }
              if ( (v41 & 2) != 0 )
              {
                *(_WORD *)((char *)v46 + v44) = *(_WORD *)((char *)v47 + v44);
                v44 += 2;
              }
              if ( (v41 & 1) != 0 )
                *((_BYTE *)v46 + v44) = *((_BYTE *)v47 + v44);
              goto LABEL_121;
            case 8:
              v15 = levels;
              memset(levels, 0, 0x100u);
              *(float *)levels = frontleft;
              v16 = outlevels;
              v14 = 256;
              *(float *)&levels[36] = frontright;
              *(float *)&levels[72] = center;
              *(float *)&levels[108] = lfe;
              *(float *)&levels[144] = surroundleft;
              *(float *)&levels[180] = surroundright;
              *(float *)&levels[216] = backleft;
              *(float *)&levels[252] = backright;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v16 = (float *)((char *)outlevels + 1);
                v15 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v14 = 255;
              }
              goto LABEL_33;
            case 12:
              v31 = levels;
              memset(levels, 0, 0x180u);
              *(float *)levels = frontleft;
              v32 = outlevels;
              v33 = 384;
              *(float *)&levels[52] = frontright;
              *(float *)&levels[104] = center;
              *(float *)&levels[156] = lfe;
              *(float *)&levels[208] = surroundleft;
              *(float *)&levels[260] = surroundright;
              *(float *)&levels[312] = backleft;
              *(float *)&levels[364] = backright;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v32 = (float *)((char *)outlevels + 1);
                v31 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v33 = 383;
              }
              goto LABEL_103;
            default:
              return 0;
          }
          return 0;
        }
        memset(outlevels, 0, 32LL * channels);
        v22 = numinputlevels;
        if ( channels > 0 )
        {
          for ( k = 0; k != channels; ++k )
          {
            if ( (k & 1) != 0 )
              v13[channels] = frontright;
            else
              *v13 = frontleft;
            ++v13;
          }
        }
      }
      goto LABEL_64;
    }
    if ( speakermode < 7 )
    {
      if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLMONO_0 )
      {
        memset(outlevels, 0, 24LL * channels);
        v22 = numinputlevels;
        if ( channels > 0 )
        {
          v76 = 0;
          do
            v13[2 * channels + v76++] = center;
          while ( channels > (int)v76 );
        }
      }
      else
      {
        if ( channelorder != FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLSTEREO_0 && (channels == 12 || channels <= 8) )
        {
          switch ( channels )
          {
            case 1:
              *(_QWORD *)levels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[8] = center;
              *(float *)&levels[12] = lfe;
              *(_QWORD *)outlevels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[16] = surroundleft;
              *(float *)&levels[20] = surroundright;
              *(_OWORD *)(outlevels + 2) = *(_OWORD *)&levels[8];
              *numinputlevels = 1;
              break;
            case 2:
              memset(levels, 0, 0x30u);
              *(float *)levels = frontleft;
              *(float *)&levels[12] = frontright;
              v68 = lfe * 0.5;
              *(float *)&levels[32] = surroundleft;
              *(float *)&levels[44] = surroundright;
              *(_QWORD *)outlevels = *(_QWORD *)levels;
              *(float *)&levels[16] = center * 0.5;
              *(float *)&levels[20] = center * 0.5;
              *(float *)&levels[24] = v68;
              *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
              *(float *)&levels[28] = v68;
              *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
              *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
              *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
              *numinputlevels = 2;
              break;
            case 4:
              memset(levels, 0, 0x60u);
              *(float *)levels = frontleft;
              *(float *)&levels[20] = frontright;
              *(float *)&levels[72] = surroundleft;
              *(float *)&levels[92] = surroundright;
              *(_QWORD *)outlevels = *(_QWORD *)levels;
              v67 = lfe * 0.5;
              *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
              *(float *)&levels[32] = center * 0.5;
              *(float *)&levels[36] = center * 0.5;
              *(float *)&levels[48] = v67;
              *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
              *(float *)&levels[52] = v67;
              *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
              *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
              *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
              *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
              *((_QWORD *)outlevels + 8) = *(_QWORD *)&levels[64];
              *((_QWORD *)outlevels + 9) = *(_QWORD *)&levels[72];
              *((_QWORD *)outlevels + 10) = *(_QWORD *)&levels[80];
              *((_QWORD *)outlevels + 11) = *(_QWORD *)&levels[88];
              *numinputlevels = 4;
              break;
            case 6:
              v41 = 0;
              memset(levels, 0, 0x90u);
              *(float *)levels = frontleft;
              if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_PROTOOLS_0 )
              {
                *(float *)&levels[32] = frontright;
                *(float *)&levels[52] = center;
                *(float *)&levels[92] = lfe;
                *(float *)&levels[108] = surroundleft;
                *(float *)&levels[136] = surroundright;
              }
              else
              {
                *(float *)&levels[28] = frontright;
                *(float *)&levels[56] = center;
                *(float *)&levels[84] = lfe;
                *(float *)&levels[112] = surroundleft;
                *(float *)&levels[140] = surroundright;
              }
              v42 = outlevels;
              v43 = levels;
              LOBYTE(v41) = -112;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v42 = (float *)((char *)outlevels + 1);
                v43 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v41 = 143;
              }
              goto LABEL_137;
            case 8:
              v14 = 192;
              v15 = levels;
              memset(levels, 0, 0xC0u);
              *(float *)levels = frontleft;
              v16 = outlevels;
              *(float *)&levels[36] = frontright;
              *(float *)&levels[72] = center;
              *(float *)&levels[108] = lfe;
              *(float *)&levels[144] = surroundleft;
              *(float *)&levels[24] = backleft * 0.5;
              *(float *)&levels[60] = backright * 0.5;
              *(float *)&levels[152] = backleft * 0.5;
              *(float *)&levels[180] = surroundright;
              *(float *)&levels[188] = backright * 0.5;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v16 = (float *)((char *)outlevels + 1);
                v15 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v14 = 191;
              }
              goto LABEL_33;
            case 12:
              v31 = levels;
              memset(levels, 0, 0x120u);
              *(float *)levels = frontleft;
              v32 = outlevels;
              v33 = 288;
              *(float *)&levels[52] = frontright;
              *(float *)&levels[104] = center;
              *(float *)&levels[156] = lfe;
              *(float *)&levels[208] = surroundleft;
              *(float *)&levels[24] = backleft * 0.5;
              *(float *)&levels[76] = backright * 0.5;
              *(float *)&levels[216] = backleft * 0.5;
              *(float *)&levels[260] = surroundright;
              *(float *)&levels[268] = backright * 0.5;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v32 = (float *)((char *)outlevels + 1);
                v31 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v33 = 287;
              }
              goto LABEL_103;
            default:
              return 0;
          }
          return 0;
        }
        memset(outlevels, 0, 24LL * channels);
        v22 = numinputlevels;
        if ( channels > 0 )
        {
          for ( m = 0; m != channels; ++m )
          {
            if ( (m & 1) != 0 )
              v13[channels] = frontright;
            else
              *v13 = frontleft;
            ++v13;
          }
        }
      }
      goto LABEL_64;
    }
    if ( speakermode == 8 )
    {
      if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLMONO_0 )
      {
        memset(outlevels, 0, 48LL * channels);
        v22 = numinputlevels;
        if ( channels > 0 )
        {
          v74 = 0;
          do
            v13[2 * channels + v74++] = center;
          while ( channels > (int)v74 );
        }
      }
      else
      {
        if ( channelorder != FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLSTEREO_0 && (channels == 12 || channels <= 8) )
        {
          switch ( channels )
          {
            case 1:
              memset(levels, 0, 0x30u);
              *(_QWORD *)levels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[8] = center;
              *(float *)&levels[12] = lfe;
              *(float *)&levels[16] = surroundleft;
              *(_QWORD *)outlevels = __PAIR64__(LODWORD(frontright), LODWORD(frontleft));
              *(float *)&levels[20] = surroundright;
              *(_QWORD *)&levels[24] = __PAIR64__(LODWORD(backright), LODWORD(backleft));
              *(_OWORD *)(outlevels + 2) = *(_OWORD *)&levels[8];
              *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
              *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
              *numinputlevels = 1;
              break;
            case 2:
              memset(levels, 0, 0x60u);
              *(float *)levels = frontleft;
              *(float *)&levels[12] = frontright;
              v55 = lfe * 0.5;
              *(float *)&levels[32] = surroundleft;
              *(float *)&levels[44] = surroundright;
              *(_QWORD *)outlevels = *(_QWORD *)levels;
              *(float *)&levels[48] = backleft;
              *(float *)&levels[16] = center * 0.5;
              *(float *)&levels[20] = center * 0.5;
              *(float *)&levels[24] = v55;
              *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
              *(float *)&levels[28] = v55;
              *(float *)&levels[60] = backright;
              *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
              *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
              *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
              *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
              *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
              *((_QWORD *)outlevels + 8) = *(_QWORD *)&levels[64];
              *((_QWORD *)outlevels + 9) = *(_QWORD *)&levels[72];
              *((_QWORD *)outlevels + 10) = *(_QWORD *)&levels[80];
              *((_QWORD *)outlevels + 11) = *(_QWORD *)&levels[88];
              *numinputlevels = 2;
              break;
            case 4:
              v48 = 192;
              v49 = levels;
              memset(levels, 0, 0xC0u);
              *(float *)levels = frontleft;
              v50 = outlevels;
              *(float *)&levels[20] = frontright;
              *(float *)&levels[32] = center * 0.5;
              *(float *)&levels[36] = center * 0.5;
              *(float *)&levels[48] = lfe * 0.5;
              *(float *)&levels[52] = lfe * 0.5;
              *(float *)&levels[72] = surroundleft * 0.5;
              *(float *)&levels[92] = surroundright * 0.5;
              *(float *)&levels[104] = backleft * 0.5;
              *(float *)&levels[124] = 0.5 * backright;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v50 = (float *)((char *)outlevels + 1);
                v49 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v48 = 191;
              }
              if ( ((unsigned __int8)v50 & 2) != 0 )
              {
                v84 = *(_WORD *)v49;
                v50 = (float *)((char *)v50 + 2);
                v49 += 2;
                v48 -= 2;
                *((_WORD *)v50 - 1) = v84;
              }
              if ( ((unsigned __int8)v50 & 4) != 0 )
              {
                v83 = *(_DWORD *)v49;
                ++v50;
                v49 += 4;
                v48 -= 4;
                *((_DWORD *)v50 - 1) = v83;
              }
              v51 = 0;
              v52 = v48 >> 3;
              qmemcpy(v50, v49, 8 * v52);
              v54 = &v49[8 * v52];
              v53 = &v50[2 * v52];
              if ( (v48 & 4) != 0 )
              {
                *v53 = *(float *)v54;
                v51 = 4;
              }
              if ( (v48 & 2) != 0 )
              {
                *(_WORD *)((char *)v53 + v51) = *(_WORD *)((char *)v54 + v51);
                v51 += 2;
              }
              if ( (v48 & 1) != 0 )
                *((_BYTE *)v53 + v51) = *((_BYTE *)v54 + v51);
              *numinputlevels = 4;
              break;
            case 6:
              HIWORD(v41) = 0;
              memset(levels, 0, 0x120u);
              *(float *)levels = frontleft;
              if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_PROTOOLS_0 )
              {
                *(float *)&levels[32] = frontright;
                *(float *)&levels[52] = center;
                *(float *)&levels[92] = lfe;
                *(float *)&levels[108] = surroundleft;
                *(float *)&levels[136] = surroundright;
                *(float *)&levels[144] = backleft * 0.5;
                *(float *)&levels[156] = backleft * 0.5;
                *(float *)&levels[176] = backright * 0.5;
                *(float *)&levels[184] = backright * 0.5;
              }
              else
              {
                *(float *)&levels[28] = frontright;
                *(float *)&levels[56] = center;
                *(float *)&levels[84] = lfe;
                *(float *)&levels[112] = surroundleft;
                *(float *)&levels[140] = surroundright;
                *(float *)&levels[144] = backleft * 0.5;
                *(float *)&levels[160] = backleft * 0.5;
                *(float *)&levels[172] = backright * 0.5;
                *(float *)&levels[188] = backright * 0.5;
              }
              v42 = outlevels;
              v43 = levels;
              LOWORD(v41) = 288;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v42 = (float *)((char *)outlevels + 1);
                v43 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v41 = 287;
              }
              goto LABEL_137;
            case 8:
              v15 = levels;
              memset(levels, 0, 0x180u);
              *(float *)levels = frontleft;
              v16 = outlevels;
              v14 = 384;
              *(float *)&levels[36] = frontright;
              *(float *)&levels[72] = center;
              *(float *)&levels[108] = lfe;
              *(float *)&levels[144] = surroundleft;
              *(float *)&levels[180] = surroundright;
              *(float *)&levels[216] = backleft;
              *(float *)&levels[252] = backright;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v16 = (float *)((char *)outlevels + 1);
                v15 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v14 = 383;
              }
              goto LABEL_33;
            case 12:
              v31 = levels;
              memset(levels, 0, sizeof(levels));
              *(float *)levels = frontleft;
              v32 = outlevels;
              v33 = 576;
              *(float *)&levels[52] = frontright;
              *(float *)&levels[104] = center;
              *(float *)&levels[156] = lfe;
              *(float *)&levels[208] = surroundleft;
              *(float *)&levels[260] = surroundright;
              *(float *)&levels[312] = backleft;
              *(float *)&levels[364] = backright;
              if ( ((unsigned __int8)outlevels & 1) != 0 )
              {
                v32 = (float *)((char *)outlevels + 1);
                v31 = &levels[1];
                *(_BYTE *)outlevels = levels[0];
                v33 = 575;
              }
              goto LABEL_103;
            default:
              return 0;
          }
          return 0;
        }
        memset(outlevels, 0, 48LL * channels);
        v22 = numinputlevels;
        if ( channels > 0 )
        {
          for ( n = 0; n != channels; ++n )
          {
            if ( (n & 1) != 0 )
              v13[channels] = frontright;
            else
              *v13 = frontleft;
            ++v13;
          }
        }
      }
      goto LABEL_64;
    }
    if ( speakermode != 1000 )
      return 0;
  }
  if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLMONO_0 )
  {
    memset(outlevels, 0, 8LL * channels);
    v22 = numinputlevels;
    if ( channels > 0 )
    {
      v24 = center * 0.70700002;
      v25 = (__int64)&v13[channels - 1 + 1];
      do
      {
        *v13 = v24;
        v13[channels] = v24;
        ++v13;
      }
      while ( v13 != (float *)v25 );
    }
  }
  else
  {
    if ( channelorder != FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALLSTEREO_0 && (channels == 12 || channels <= 8) )
    {
      switch ( channels )
      {
        case 1:
          *(_QWORD *)outlevels = __PAIR64__(
                                   COERCE_UNSIGNED_INT(
                                     fsqrt(
                                       (float)((float)(frontright * frontright) + (float)((float)(center * center) * 0.5))
                                     + (float)((float)(surroundright * surroundright) * 0.25))),
                                   COERCE_UNSIGNED_INT(
                                     fsqrt(
                                       (float)((float)(frontleft * frontleft) + (float)((float)(center * center) * 0.5))
                                     + (float)((float)(surroundleft * surroundleft) * 0.25))));
          *numinputlevels = 1;
          break;
        case 2:
          *(_OWORD *)levels = 0u;
          v39 = (float)(center * center) * 0.5;
          *(_DWORD *)levels = fsqrt(
                                (float)((float)(frontleft * frontleft) + v39)
                              + (float)((float)(surroundleft * surroundleft) * 0.25));
          *(_DWORD *)&levels[12] = fsqrt(
                                     (float)((float)(frontright * frontright) + v39)
                                   + (float)((float)(surroundright * surroundright) * 0.25));
          *(_OWORD *)outlevels = *(_OWORD *)levels;
          *numinputlevels = 2;
          break;
        case 4:
          *(_QWORD *)&levels[12] = 0;
          *(float *)&levels[20] = frontright;
          *(_QWORD *)outlevels = LODWORD(frontleft);
          *(_DWORD *)&levels[24] = 0;
          *(float *)&levels[8] = surroundleft * 0.5;
          *(float *)&levels[28] = 0.5 * surroundright;
          *(_OWORD *)(outlevels + 2) = *(_OWORD *)&levels[8];
          *((_QWORD *)outlevels + 3) = *(_QWORD *)&levels[24];
          *numinputlevels = 4;
          break;
        case 6:
          memset(levels, 0, 0x30u);
          *(float *)levels = frontleft;
          v38 = center * 0.5;
          if ( channelorder == FMOD_CHANNELORDER::FMOD_CHANNELORDER_PROTOOLS_0 )
          {
            *(float *)&levels[4] = v38;
            *(float *)&levels[28] = v38;
            *(float *)&levels[32] = frontright;
            *(float *)&levels[20] = lfe * 0.5;
            *(float *)&levels[12] = surroundleft * 0.5;
            *(float *)&levels[40] = 0.5 * surroundright;
            *(float *)&levels[44] = lfe * 0.5;
          }
          else
          {
            *(float *)&levels[8] = v38;
            *(float *)&levels[28] = frontright;
            *(float *)&levels[32] = v38;
            *(float *)&levels[12] = lfe * 0.5;
            *(float *)&levels[16] = surroundleft * 0.5;
            *(float *)&levels[36] = lfe * 0.5;
            *(float *)&levels[44] = 0.5 * surroundright;
          }
          *(_OWORD *)outlevels = *(_OWORD *)levels;
          *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
          *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
          *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
          goto LABEL_121;
        case 8:
          memset(levels, 0, 0x40u);
          *(float *)levels = frontleft;
          v63 = center * 0.5;
          *(float *)&levels[36] = frontright;
          v64 = lfe * 0.5;
          *(_QWORD *)outlevels = *(_QWORD *)levels;
          *(float *)&levels[8] = v63;
          *(float *)&levels[12] = v64;
          *(float *)&levels[16] = surroundleft * 0.5;
          *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
          *(float *)&levels[40] = v63;
          *(float *)&levels[44] = v64;
          *(float *)&levels[52] = 0.5 * surroundright;
          *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
          *(float *)&levels[24] = backleft * 0.75;
          *(float *)&levels[60] = 0.75 * backright;
          *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
          *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
          *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
          *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
          *numinputlevels = 8;
          break;
        case 12:
          memset(levels, 0, 0x60u);
          *(float *)levels = frontleft;
          *(float *)&v61 = center * 0.5;
          *(float *)&levels[52] = frontright;
          *(float *)&v62 = lfe * 0.5;
          *(_QWORD *)outlevels = *(_QWORD *)levels;
          *(_DWORD *)&levels[8] = v61;
          *(_DWORD *)&levels[12] = v62;
          *(float *)&levels[16] = surroundleft * 0.5;
          *((_QWORD *)outlevels + 1) = *(_QWORD *)&levels[8];
          *(_QWORD *)&levels[56] = __PAIR64__(v62, v61);
          *(float *)&levels[68] = 0.5 * surroundright;
          *(float *)&levels[24] = backleft * 0.75;
          *((_QWORD *)outlevels + 2) = *(_QWORD *)&levels[16];
          *(float *)&levels[76] = 0.75 * backright;
          *(_OWORD *)(outlevels + 6) = *(_OWORD *)&levels[24];
          *((_QWORD *)outlevels + 5) = *(_QWORD *)&levels[40];
          *((_QWORD *)outlevels + 6) = *(_QWORD *)&levels[48];
          *((_QWORD *)outlevels + 7) = *(_QWORD *)&levels[56];
          *((_QWORD *)outlevels + 8) = *(_QWORD *)&levels[64];
          *((_QWORD *)outlevels + 9) = *(_QWORD *)&levels[72];
          *((_QWORD *)outlevels + 10) = *(_QWORD *)&levels[80];
          *((_QWORD *)outlevels + 11) = *(_QWORD *)&levels[88];
          *numinputlevels = 12;
          break;
        default:
          return 0;
      }
      return 0;
    }
    memset(outlevels, 0, 8LL * channels);
    v22 = numinputlevels;
    if ( channels > 0 )
    {
      for ( ii = 0; ii != channels; ++ii )
      {
        if ( (ii & 1) != 0 )
          v13[channels] = frontright;
        else
          *v13 = frontleft;
        ++v13;
      }
    }
  }
LABEL_64:
  *v22 = channels;
  return 0;
}


// Address: 0x21b91c0 | Name: _ZN4FMOD4DSPIC2Ev
void __fastcall FMOD::DSPI::DSPI(FMOD::DSPI *const this)
{
  this->mJob.mDelayClock.mDelayEndShadow = 0;
  this->mJob.mDelayClock.mDelayStartShadow = 0;
  this->mJob.mDelayClock.mDelayEnd = 0;
  this->mJob.mDelayClock.mDelayStart = 0;
  this->mJob.mDelayClock.mClockNext = 0;
  this->mJob.mDelayClock.mClock = 0;
  this->mJob.mDelayClock.mRealPitch = 0x100000;
  this->_vptr_DSPI = (int (**)(...))off_29B0CB0;
  this->mJob.mDelayClock.mPitch = 0x100000;
  this->mJob.mDelayClock.mStopChannelsShadow = 0;
  this->mJob.mDelayClock.mStopChannels = 0;
  this->mJob.mInputHead.mNodePrev = &this->mJob.mInputHead;
  this->mJob.mInputHead.mNodeNext = &this->mJob.mInputHead;
  this->mJob.mDelayClock.mStopNow = 0;
  this->mJob.mDelayClock.mDelayParent = 0;
  this->mJob.mGainModifierNode.mNodePrev = &this->mJob.mGainModifierNode;
  this->mJob.mGainModifierNode.mNodeNext = &this->mJob.mGainModifierNode;
  this->mJob.mInputHead.mNodeData = 0;
  this->mJob.mGainModifierNode.mNodeData = 0;
  this->mReleaseNode.mNodePrev = &this->mReleaseNode;
  this->mReleaseNode.mNodeNext = &this->mReleaseNode;
  this->mBuffer.mData = 0;
  this->mBuffer.mSystem = 0;
  this->mBuffer.mChannels = 0;
  this->mBuffer.mSpeakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
  this->mBuffer.mCacheIndex = -1;
  this->mSideChainBuffer.mData = 0;
  this->mSideChainBuffer.mSystem = 0;
  this->mSideChainBuffer.mChannels = 0;
  this->mSideChainBuffer.mSpeakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
  this->mSideChainBuffer.mCacheIndex = -1;
  this->mReleaseNode.mNodeData = 0;
  this->mOutputHead.mNodePrev = &this->mOutputHead;
  this->mOutputHead.mNodeNext = &this->mOutputHead;
  this->mPostWetOld = 1.0;
  this->mOutputHead.mNodeData = 0;
  this->mJob.mFlags = 0;
  this->mPreWetOld = 1.0;
  this->mJob.mActive = 0;
  this->mJob.mQueuedForDisconnect = 0;
  this->mPostWet = 1.0;
  this->mJob.mMagic = -1395763731;
  this->mPreWet = 1.0;
  this->mMixerFlags = 0;
  this->mNumInputs = 0;
  this->mNumOutputs = 0;
  this->mState.functions = 0;
  this->mDryOld = 0.0;
  this->mDry = 0.0;
}


// Address: 0x21b9380 | Name: _ZN4FMOD4DSPI15getSystemObjectEPPNS_6SystemE
FMOD_RESULT_0 __fastcall FMOD::DSPI::getSystemObject(FMOD::DSPI *const this, FMOD::System **system)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( system )
  {
    *system = (FMOD::System *)this->mSystem;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b93a0 | Name: _ZN4FMOD8DSPClock8runClockEPNS_10DSPJobListEPS0_jPjS4_
FMOD_RESULT_0 __fastcall FMOD::DSPClock::runClock(
        FMOD::DSPClock *const this,
        FMOD::DSPJobList *joblist,
        FMOD::DSPClock *parent,
        unsigned int dspblocksize,
        unsigned int *offset,
        unsigned int *length)
{
  FMOD::DSPClock *mDelayParent; // rcx
  bool mStopNow; // al
  FMOD_CLOCKTIME mClockNext; // r10
  unsigned int v9; // r11d
  FMOD_RESULT_0 result; // eax
  __int64 v11; // rbx
  unsigned __int64 v12; // rax
  FMOD_CLOCKTIME mDelayStart; // rax
  unsigned __int64 v14; // rax
  FMOD_CLOCKTIME mDelayEnd; // rax
  unsigned __int64 v16; // rbx

  if ( parent )
  {
    this->mDelayParent = parent;
    mDelayParent = parent;
  }
  else
  {
    mDelayParent = this->mDelayParent;
  }
  mStopNow = mDelayParent->mStopNow;
  mClockNext = this->mClockNext;
  this->mClock = mClockNext;
  this->mStopNow = mStopNow;
  if ( !mDelayParent->mRealPitch )
  {
    *length = 0;
    this->mRealPitch = 0;
  }
  v9 = *length;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( *length )
  {
    v11 = *offset;
    v12 = (mDelayParent->mRealPitch * (unsigned __int64)this->mPitch) >> 20;
    if ( v12 > 0xFFFFFFFF )
      LODWORD(v12) = -1;
    this->mRealPitch = v12;
    mDelayStart = this->mDelayStart;
    if ( mDelayStart )
    {
      if ( mDelayStart >= mDelayParent->mClock )
      {
        v14 = (mDelayStart - mDelayParent->mClock) / mDelayParent->mRealPitch;
        if ( v9 <= v14 )
        {
          *offset = v9;
          *length = 0;
        }
        else
        {
          *offset += v14;
          *length -= v14;
        }
      }
      joblist->mDirty = 1;
    }
    mDelayEnd = this->mDelayEnd;
    if ( mDelayEnd )
    {
      if ( mDelayEnd < mDelayParent->mClockNext )
      {
        if ( mDelayEnd <= mDelayParent->mClock )
        {
          *length = 0;
        }
        else
        {
          v16 = (mDelayEnd - mDelayParent->mClock) / mDelayParent->mRealPitch + v11 - *offset;
          result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          if ( (unsigned int)v16 > *length )
            return result;
          *length = v16;
        }
        if ( this->mStopChannels )
          this->mStopNow = 1;
      }
      joblist->mDirty = 1;
    }
    this->mClockNext = this->mRealPitch * (unsigned __int64)*length + mClockNext;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21b94e0 | Name: _ZN4FMOD10DSPJobList12runClockListEji
FMOD_RESULT_0 __fastcall FMOD::DSPJobList::runClockList(
        FMOD::DSPJobList *const this,
        unsigned int dspblocksize,
        int tick)
{
  int mNumJobs; // edx
  FMOD::DSPJobEntry *mJob; // rax
  int v6; // edx
  __int64 v7; // r14
  FMOD::DSPJob *v8; // rbx
  FMOD::DSPI *mDSP; // r15
  unsigned __int64 v11; // [rsp+8h] [rbp-60h]
  unsigned int offset; // [rsp+28h] [rbp-40h] BYREF
  unsigned int length[15]; // [rsp+2Ch] [rbp-3Ch] BYREF

  mNumJobs = this->mNumJobs;
  offset = 0;
  length[0] = dspblocksize;
  if ( mNumJobs )
  {
    mJob = this->mJob;
    v6 = mNumJobs - 1;
    mJob->mJob->mDelayClock.mRealPitch = 0x100000;
    if ( v6 >= 0 )
    {
      v7 = 8LL * v6;
      v11 = 8 * (v6 - (unsigned __int64)(unsigned int)v6);
      while ( 1 )
      {
        v8 = mJob[(unsigned __int64)v7 / 8].mJob;
        mDSP = v8->mDSP;
        FMOD::DSPClock::runClock(&v8->mDelayClock, this, 0, dspblocksize, &offset, length);
        v8->mInfo.mMixOffset = offset;
        v8->mInfo.mMixLength = length[0];
        mDSP->mMixerFlags |= 2u;
        if ( (mDSP->mDescription.mCommandMask & 1) != 0 )
        {
          mDSP->mState.instance = mDSP;
          mDSP->mDescription.mCommand(&mDSP->mState, 1, 0, 0);
          v8->mTick = tick;
          if ( v7 == v11 )
            return FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          v8->mTick = tick;
          if ( v7 == v11 )
            return FMOD_RESULT::FMOD_OK_0;
        }
        mJob = this->mJob;
        v7 -= 8;
      }
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21b9610 | Name: _ZN4FMOD6DSPJob14updateSendTreeEPNS_10DSPJobListEjjjiPb
FMOD_RESULT_0 __fastcall FMOD::DSPJob::updateSendTree(
        FMOD::DSPJob *const this,
        FMOD::DSPJobList *joblist,
        unsigned int dspblocksize,
        unsigned int offset,
        unsigned int length,
        int tick,
        bool *active)
{
  FMOD::DSPJob *v7; // r15
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *mSingleInput; // rdi
  FMOD::LinkedListNode *mNodeNext; // r15
  FMOD::LinkedListNode *p_mInputHead; // [rsp+10h] [rbp-58h]
  FMOD::DSPJob *thisa; // [rsp+18h] [rbp-50h]
  bool activeChild[57]; // [rsp+2Fh] [rbp-39h] BYREF

  v7 = this;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( !this->mInfo.mInJobList )
  {
    if ( this->mActive )
    {
      mSingleInput = this->mSingleInput;
      activeChild[0] = 0;
      if ( mSingleInput )
      {
        FMOD::DSPJob::updateSendTree(&mSingleInput->mJob, joblist, dspblocksize, offset, length, tick, activeChild);
      }
      else
      {
        p_mInputHead = &v7->mInputHead;
        if ( v7->mInputHead.mNodeNext != &v7->mInputHead )
        {
          thisa = v7;
          mNodeNext = v7->mInputHead.mNodeNext;
          do
          {
            FMOD::DSPJob::updateSendTree(
              (FMOD::DSPJob *const)(*((_QWORD *)mNodeNext->mNodeData + 11) + 8LL),
              joblist,
              dspblocksize,
              offset,
              length,
              tick,
              activeChild);
            mNodeNext = mNodeNext->mNodeNext;
          }
          while ( mNodeNext != p_mInputHead );
          v7 = thisa;
        }
      }
      if ( active )
        *active = 1;
      if ( !v7->mDSP->mDescription.mSize )
        return FMOD_RESULT::FMOD_OK_0;
      if ( v7->mInfo.mInJobList )
        return FMOD_RESULT::FMOD_OK_0;
      result = FMOD::DSPJobList::addNonExecutingJob(joblist, v7);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        return FMOD_RESULT::FMOD_OK_0;
    }
    else if ( active )
    {
      *active = 0;
    }
  }
  return result;
}


// Address: 0x21b9750 | Name: _ZN4FMOD6DSPJob12runClockTreeEPNS_10DSPJobListEPNS_8DSPClockEjjjiPb
FMOD_RESULT_0 __fastcall FMOD::DSPJob::runClockTree(
        FMOD::DSPJob *const this,
        FMOD::DSPJobList *joblist,
        FMOD::DSPClock *parent,
        unsigned int dspblocksize,
        unsigned int offset,
        unsigned int length,
        int tick,
        bool *active)
{
  bool v9; // zf
  unsigned __int16 v12; // ax
  unsigned __int16 mMixLength; // dx
  FMOD::DSPI *mDSP; // rax
  FMOD::DSPI *mSingleInput; // rdi
  char v16; // r14
  FMOD::DSPI *v17; // rdi
  bool v18; // al
  FMOD_RESULT_0 result; // eax
  unsigned int (__fastcall *mProcess)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  __int64 v21; // rsi
  FMOD_RESULT_0 v22; // eax
  FMOD::DSPJob *mNodeNext; // r15
  FMOD_CLOCKTIME mDelayStart; // rax
  __int64 v25; // rdi
  unsigned int v26; // [rsp+28h] [rbp-140h] BYREF
  unsigned int offseta; // [rsp+2Ch] [rbp-13Ch] BYREF
  bool activeChild[312]; // [rsp+30h] [rbp-138h] BYREF

  v9 = tick == this->mTick;
  offseta = offset;
  v26 = length;
  if ( v9 )
  {
    if ( active )
    {
      *active = ((this->mDSP->mMixerFlags >> 3) ^ 1) & 1;
      return FMOD_RESULT::FMOD_OK_0;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( !this->mActive )
    v26 = 0;
  FMOD::DSPClock::runClock(&this->mDelayClock, joblist, parent, dspblocksize, &offseta, &v26);
  v12 = v26;
  this->mInfo.mMixLength = v26;
  mMixLength = v12;
  this->mInfo.mMixOffset = offseta;
  mDSP = this->mDSP;
  mDSP->mMixerFlags |= 2u;
  if ( (mDSP->mDescription.mCommandMask & 1) != 0 )
  {
    mDSP->mState.instance = mDSP;
    v22 = mDSP->mDescription.mCommand(&mDSP->mState, 1, 0, 0);
    if ( v22 && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      activeChild[0] = 0;
      FMOD_ReportError(
        v22,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
        this,
        "DSPI::RunJob",
        (const char *)activeChild);
    }
    mMixLength = this->mInfo.mMixLength;
  }
  if ( !mMixLength && !this->mDelayClock.mStopNow )
    return FMOD_RESULT::FMOD_OK_0;
  mSingleInput = this->mSingleInput;
  this->mTick = tick;
  activeChild[0] = 0;
  if ( mSingleInput )
  {
    FMOD::DSPJob::runClockTree(
      &mSingleInput->mJob,
      joblist,
      &this->mDelayClock,
      dspblocksize,
      offseta,
      v26,
      tick,
      activeChild);
    v16 = activeChild[0];
    goto LABEL_8;
  }
  mNodeNext = (FMOD::DSPJob *)this->mInputHead.mNodeNext;
  v16 = 0;
  if ( &this->mInputHead != (FMOD::LinkedListNode *)mNodeNext )
  {
    do
    {
      mDelayStart = mNodeNext->mDelayClock.mDelayStart;
      v25 = *(_QWORD *)(mDelayStart + 88);
      if ( (*(_BYTE *)(mDelayStart + 124) & 4) != 0 )
        FMOD::DSPJob::updateSendTree(
          (FMOD::DSPJob *const)(v25 + 8),
          joblist,
          dspblocksize,
          offseta,
          v26,
          tick,
          activeChild);
      else
        FMOD::DSPJob::runClockTree(
          (FMOD::DSPJob *const)(v25 + 8),
          joblist,
          &this->mDelayClock,
          dspblocksize,
          offseta,
          v26,
          tick,
          activeChild);
      v16 |= activeChild[0];
      mNodeNext = (FMOD::DSPJob *)mNodeNext->mDelayClock.mClock;
    }
    while ( &this->mInputHead != (FMOD::LinkedListNode *)mNodeNext );
LABEL_8:
    if ( v16 )
      goto LABEL_20;
  }
  if ( (this->mFlags & 0x21) != 0 )
    goto LABEL_10;
  v17 = this->mDSP;
  mProcess = (unsigned int (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v17->mProcess;
  if ( !mProcess )
    goto LABEL_11;
  v21 = this->mInfo.mMixLength;
  v17->mState.instance = v17;
  if ( mProcess(&v17->mState, v21, 0, 0, 1, 1) == 6 )
  {
LABEL_10:
    v17 = this->mDSP;
LABEL_11:
    v17->mMixerFlags |= 8u;
    v18 = 0;
    goto LABEL_12;
  }
LABEL_20:
  v17 = this->mDSP;
  v18 = 1;
  v17->mMixerFlags &= ~8u;
LABEL_12:
  if ( active )
    *active = v18;
  if ( !v17->mDescription.mSize )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD::DSPJobList::addExecutingJob(joblist, this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD_RESULT::FMOD_OK_0;
  return result;
}


// Address: 0x21b9a60 | Name: _ZN4FMOD10DSPJobList18runEntireClockTreeEPNS_4DSPIEji
FMOD_RESULT_0 __fastcall FMOD::DSPJobList::runEntireClockTree(
        FMOD::DSPJobList *const this,
        FMOD::DSPI *dsphead,
        unsigned int dspblocksize,
        int tick)
{
  FMOD_RESULT_0 result; // eax
  int mNumJobs; // ecx
  FMOD::DSPJobEntry *mJob; // r9
  int v8; // r8d
  FMOD::DSPJobEntry *v9; // rdx
  __int64 v10; // rsi
  __int64 v11; // rdi
  FMOD::DSPJob *v12; // rcx
  bool active; // [rsp+1Fh] [rbp-9h] BYREF

  dsphead->mJob.mInfo.mMixOffset = 0;
  dsphead->mJob.mInfo.mMixLength = dspblocksize;
  dsphead->mJob.mDelayClock.mRealPitch = 0x100000;
  this->mNumExecutingJobs = 0;
  active = 0;
  result = FMOD::DSPJob::runClockTree(
             &dsphead->mJob,
             this,
             &dsphead->mJob.mDelayClock,
             dspblocksize,
             0,
             dspblocksize,
             tick,
             &active);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mNumJobs = this->mNumJobs;
    if ( this->mNumExecutingJobs < mNumJobs )
    {
      if ( mNumJobs <= 0 )
      {
        v8 = 0;
      }
      else
      {
        mJob = this->mJob;
        v8 = 0;
        v9 = mJob;
        v10 = (__int64)&mJob[(unsigned int)(mNumJobs - 1) + 1];
        do
        {
          while ( 1 )
          {
            v12 = v9->mJob;
            if ( !v9->mJob->mInfo.mExecute )
              break;
            ++v9;
            v11 = v8++;
            mJob[v11].mJob = v12;
            if ( v9 == (FMOD::DSPJobEntry *)v10 )
              goto LABEL_8;
          }
          ++v9;
          v12->mInfo.mInJobList = 0;
        }
        while ( v9 != (FMOD::DSPJobEntry *)v10 );
      }
LABEL_8:
      this->mNumJobs = v8;
    }
  }
  return result;
}


// Address: 0x21b9b20 | Name: _ZN4FMOD4DSPI17updateSingleInputEv
FMOD_RESULT_0 __fastcall FMOD::DSPI::updateSingleInput(FMOD::DSPI *const this)
{
  void *mNodeData; // rdx

  if ( this->mNumInputs != 1
    || (mNodeData = this->mJob.mInputHead.mNodeNext->mNodeData, (*((_BYTE *)mNodeData + 124) & 4) != 0) )
  {
    this->mJob.mSingleInput = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    this->mJob.mSingleInput = (FMOD::DSPI *)*((_QWORD *)mNodeData + 11);
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21b9b60 | Name: _ZN4FMOD4DSPI16addInputInternalEPS0_PPNS_14DSPConnectionIE23FMOD_DSPCONNECTION_TYPEbS3_b
FMOD_RESULT_0 __fastcall FMOD::DSPI::addInputInternal(
        FMOD::DSPI *const this,
        FMOD::DSPI *target,
        FMOD::DSPConnectionI **connection_out,
        FMOD_DSPCONNECTION_TYPE_0 type,
        bool erroroncircular,
        FMOD::DSPConnectionI *connection_in,
        bool protect)
{
  FMOD::DSPI *v7; // r8
  FMOD_RESULT_0 updated; // edx
  FMOD::SystemI *mSystem; // rbp
  char v12; // r13
  char v13; // r15
  FMOD::DSPConnectionI *v14; // rdi
  char v15; // r9
  FMOD::LinkedListNode *mNodePrev; // r10
  __int16 v17; // si
  __int16 v18; // dx
  __int16 mNumOutputs; // ax
  FMOD_RESULT_0 targeta; // [rsp+8h] [rbp-50h]
  FMOD_RESULT_0 targetb; // [rsp+8h] [rbp-50h]
  FMOD_DSPCONNECTION_TYPE_0 targetc; // [rsp+8h] [rbp-50h]
  FMOD::DSPI *targetd; // [rsp+8h] [rbp-50h]
  FMOD_DSPCONNECTION_TYPE_0 typea; // [rsp+14h] [rbp-44h]
  FMOD_DSPCONNECTION_TYPE_0 typeb; // [rsp+14h] [rbp-44h]
  FMOD::DSPConnectionI *connection_ina; // [rsp+18h] [rbp-40h] BYREF

  v7 = target;
  updated = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mSystem = this->mSystem;
  connection_ina = connection_in;
  if ( !target )
    return updated;
  v12 = 0;
  v13 = 0;
  if ( protect && mSystem )
  {
    typea = type;
    v12 = 1;
    v13 = 1;
    FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
    FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
    type = typea;
    v7 = target;
  }
  v14 = connection_ina;
  v15 = 0;
  if ( !connection_ina )
  {
    typeb = type;
    targetd = v7;
    updated = FMOD::ExpandingPool<FMOD::DSPConnectionI>::alloc(
                &this->mSystem->mDSPConnectionPool,
                &connection_ina,
                protect);
    v7 = targetd;
    type = typeb;
    if ( updated )
      goto LABEL_15;
    v14 = connection_ina;
    v15 = 1;
  }
  v14->mInputNode.mNodePrev = this->mJob.mInputHead.mNodePrev;
  v14->mInputNode.mNodeNext = &this->mJob.mInputHead;
  this->mJob.mInputHead.mNodePrev = &v14->mInputNode;
  mNodePrev = v7->mOutputHead.mNodePrev;
  v14->mInputNode.mNodePrev->mNodeNext = &v14->mInputNode;
  ++this->mNumInputs;
  v17 = type == FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0;
  this->mNumStandardInputs += v17;
  v18 = (type & 0xFFFFFFFD) == 1;
  this->mNumSideChainInputs += v18;
  v14->mOutputNode.mNodePrev = mNodePrev;
  v14->mOutputNode.mNodeNext = &v7->mOutputHead;
  v7->mOutputHead.mNodePrev = &v14->mOutputNode;
  v14->mOutputNode.mNodePrev->mNodeNext = &v14->mOutputNode;
  mNumOutputs = v7->mNumOutputs;
  v7->mNumStandardOutputs += v17;
  v7->mNumSideChainOutputs += v18;
  v7->mNumOutputs = ++mNumOutputs;
  if ( mNumOutputs > 1 )
    v7->mJob.mFlags |= 0x40u;
  v14->mInputUnit = v7;
  v14->mOutputUnit = this;
  if ( v15 )
  {
    targetc = type;
    FMOD::DSPConnectionI::reset(v14, 1, 1);
    type = targetc;
    if ( targetc != FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SIDECHAIN_0 )
    {
LABEL_8:
      if ( type == FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SEND_0 )
      {
        connection_ina->mFlags |= 4u;
      }
      else if ( type == FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SEND_SIDECHAIN_0 )
      {
        connection_ina->mFlags |= 5u;
      }
      goto LABEL_11;
    }
  }
  else if ( type != FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SIDECHAIN_0 )
  {
    goto LABEL_8;
  }
  connection_ina->mFlags |= 1u;
LABEL_11:
  updated = FMOD::DSPI::updateSingleInput(this);
  if ( updated == FMOD_RESULT::FMOD_OK_0 )
  {
    *(_DWORD *)(*(unsigned __int64 *)((char *)&stru_10788.r_offset + (unsigned __int64)this->mSystem) + 48) = 1;
    if ( protect && mSystem && v12 )
    {
      v12 = 0;
      FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
      v13 = 0;
      FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
    }
    updated = FMOD_RESULT::FMOD_OK_0;
    if ( connection_out )
      *connection_out = connection_ina;
  }
LABEL_15:
  if ( v12 )
  {
    if ( mSystem )
    {
      targetb = updated;
      FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
      updated = targetb;
      if ( v13 )
        goto LABEL_18;
    }
  }
  else if ( v13 && mSystem )
  {
LABEL_18:
    targeta = updated;
    FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMIXER);
    return targeta;
  }
  return updated;
}


// Address: 0x21b9e70 | Name: _ZN4FMOD4DSPI8addInputEPS0_PPNS_14DSPConnectionIE23FMOD_DSPCONNECTION_TYPEbS3_
FMOD_RESULT_0 __fastcall FMOD::DSPI::addInput(
        FMOD::DSPI *const this,
        FMOD::DSPI *target,
        FMOD::DSPConnectionI **connection_out,
        FMOD_DSPCONNECTION_TYPE_0 type,
        bool checkcircular,
        FMOD::DSPConnectionI *connection_in)
{
  FMOD_RESULT_0 result; // eax
  const FMOD_DSP_DESCRIPTION *mDescription; // r10
  const FMOD_DSP_DESCRIPTION *v12; // rdx
  bool v13; // r8
  FMOD::DSPQueueCmd_AddInput *v14; // rsi
  FMOD::DSPConnectionI *v15; // rax
  FMOD::SystemI *mSystem; // rdi
  bool v18; // [rsp+14h] [rbp-44h]
  FMOD::DSPConnectionI *connection; // [rsp+20h] [rbp-38h] BYREF
  FMOD::DSPQueueCmd_AddInput *cmd; // [rsp+28h] [rbp-30h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( target )
  {
    mDescription = this->mDescription.mDescription;
    if ( !mDescription || (LOBYTE(result) = 5, mDescription->numinputbuffers) )
    {
      v12 = target->mDescription.mDescription;
      if ( !v12 || (result = FMOD_RESULT::FMOD_ERR_DSP_CONNECTION_0, v12->numoutputbuffers) )
      {
        result = FMOD::ExpandingPool<FMOD::DSPConnectionI>::alloc(&this->mSystem->mDSPConnectionPool, &connection, 1);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          if ( connection_in )
          {
            FMOD::DSPConnectionI::copy(connection, connection_in, 1);
            v13 = checkcircular;
          }
          else
          {
            FMOD::DSPConnectionI::reset(connection, 1, 1);
            v13 = checkcircular;
            switch ( type )
            {
              case FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SEND_0:
                connection->mFlags |= 4u;
                break;
              case FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SEND_SIDECHAIN_0:
                connection->mFlags |= 5u;
                break;
              case FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SIDECHAIN_0:
                connection->mFlags |= 1u;
                break;
            }
          }
          if ( (this->mJob.mFlags & 0x400) != 0 || (target->mJob.mFlags & 0x400) != 0 )
          {
            FMOD::DSPI::addInputInternal(this, target, connection_out, type, v13, connection, 0);
          }
          else
          {
            v18 = v13;
            result = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 40, 1);
            if ( result )
              return result;
            v14 = cmd;
            v15 = connection;
            mSystem = this->mSystem;
            *(_BYTE *)&cmd->FMOD::DSPQueueCmd = v18;
            v14->mThis = this;
            v14->mTarget = target;
            v14->mConnection = v15;
            v14->mType = type;
            result = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v14, 1);
            if ( result )
              return result;
          }
          if ( connection_out )
            *connection_out = connection;
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x21ba040 | Name: _ZN4FMOD4DSPI20getNumInputsInternalEPibb
FMOD_RESULT_0 __fastcall FMOD::DSPI::getNumInputsInternal(
        FMOD::DSPI *const this,
        int *numinputs,
        bool standardonly,
        bool protect)
{
  FMOD_RESULT_0 v4; // ebp
  int mNumStandardInputs; // eax
  bool v7; // [rsp+8h] [rbp-20h]
  bool v8; // [rsp+Ch] [rbp-1Ch]

  v4 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numinputs )
  {
    if ( protect )
    {
      v8 = protect;
      v7 = standardonly;
      FMOD::SystemI::flushDSPQueue(this->mSystem, 1);
      FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
      protect = v8;
      standardonly = v7;
    }
    if ( standardonly )
      mNumStandardInputs = this->mNumStandardInputs;
    else
      mNumStandardInputs = this->mNumInputs;
    v4 = FMOD_RESULT::FMOD_OK_0;
    *numinputs = mNumStandardInputs;
    if ( protect )
      FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
  }
  return v4;
}


// Address: 0x21ba0e0 | Name: _ZN4FMOD4DSPI11setPositionE14FMOD_UINT32_32bb
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::DSPI::setPosition(
        FMOD::DSPI *const this,
        FMOD_UINT32_32 pcm,
        bool processinputs,
        bool deferred)
{
  FMOD_RESULT_0 NumInputsInternal; // ebx
  FMOD::DSPI *v8; // rsi
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 v10; // eax
  int v12; // esi
  int numinputs; // [rsp+4h] [rbp-34h] BYREF
  FMOD::DSPI *dsp[6]; // [rsp+8h] [rbp-30h] BYREF

  if ( (this->mJob.mFlags & 0x400) != 0 || !deferred )
  {
    if ( processinputs )
    {
      numinputs = 0;
      NumInputsInternal = FMOD::DSPI::getNumInputsInternal(this, &numinputs, 0, 0);
      if ( NumInputsInternal )
        return NumInputsInternal;
      if ( numinputs > 0 )
      {
        do
        {
          v12 = NumInputsInternal;
          dsp[0] = 0;
          ++NumInputsInternal;
          FMOD::DSPI::getInputInternal(this, v12, dsp, 0, 0, 0);
          (*dsp[0]->_vptr_DSPI)(dsp[0], pcm.mValue);
        }
        while ( numinputs > NumInputsInternal );
      }
    }
    NumInputsInternal = FMOD_RESULT::FMOD_OK_0;
    (*this->_vptr_DSPI)(this, pcm.mValue, processinputs, deferred);
    return NumInputsInternal;
  }
  NumInputsInternal = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)dsp, 32, 1);
  if ( NumInputsInternal )
    return NumInputsInternal;
  v8 = dsp[0];
  dsp[0]->mJob.mDelayClock.mClockNext = pcm.mValue;
  v8->mJob.mDelayClock.mClock = (FMOD_CLOCKTIME)this;
  LOBYTE(v8->mJob.mDelayClock.mDelayStart) = processinputs;
  LOBYTE(v8->_vptr_DSPI) = 12;
  this->mJob.mFlags |= 0x2000u;
  mSystem = this->mSystem;
  this->mPositionShadow = pcm;
  v10 = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v8, 1);
  if ( v10 )
    return v10;
  return NumInputsInternal;
}


// Address: 0x21ba200 | Name: _ZN4FMOD4DSPI21getNumOutputsInternalEPibb
FMOD_RESULT_0 __fastcall FMOD::DSPI::getNumOutputsInternal(
        FMOD::DSPI *const this,
        int *numoutputs,
        bool standardonly,
        bool protect)
{
  FMOD_RESULT_0 v4; // ebp
  int mNumStandardOutputs; // eax
  bool v7; // [rsp+8h] [rbp-20h]
  bool v8; // [rsp+Ch] [rbp-1Ch]

  v4 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numoutputs )
  {
    if ( protect )
    {
      v8 = protect;
      v7 = standardonly;
      FMOD::SystemI::flushDSPQueue(this->mSystem, 1);
      FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
      protect = v8;
      standardonly = v7;
    }
    if ( standardonly )
      mNumStandardOutputs = this->mNumStandardOutputs;
    else
      mNumStandardOutputs = this->mNumOutputs;
    v4 = FMOD_RESULT::FMOD_OK_0;
    *numoutputs = mNumStandardOutputs;
    if ( protect )
      FMOD::SystemI::leaveCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
  }
  return v4;
}


// Address: 0x21ba2a0 | Name: _ZN4FMOD4DSPI22disconnectFromInternalEPS0_PNS_14DSPConnectionIEbb23FMOD_DSPCONNECTION_TYPE
FMOD_RESULT_0 __fastcall FMOD::DSPI::disconnectFromInternal(
        FMOD::DSPI *const this,
        FMOD::DSPI *target,
        FMOD::DSPConnectionI *connection,
        bool freeconnection,
        bool protect,
        FMOD_DSPCONNECTION_TYPE_0 type)
{
  FMOD::SystemI *mSystem; // rdi
  __int16 mNumInputs; // ax
  FMOD_RESULT_0 updated; // r14d
  FMOD::DSPI *mInputUnit; // rax
  FMOD::LinkedListNode *mNodeNext; // rsi
  FMOD::LinkedListNode *mNodePrev; // rcx
  unsigned int mFlags; // edx
  int v19; // edi
  int v20; // edx
  FMOD::LinkedListNode *v21; // rsi
  __int16 v22; // cx
  FMOD_RESULT_0 InputInternal; // eax
  int v25; // r11d
  bool v26; // al
  unsigned int v27; // eax
  int count; // [rsp+8h] [rbp-80h]
  int numinputs; // [rsp+18h] [rbp-70h] BYREF
  int numoutputs; // [rsp+1Ch] [rbp-6Ch] BYREF
  FMOD::DSPI *output; // [rsp+20h] [rbp-68h] BYREF
  FMOD::DSPConnectionI *inputconnection; // [rsp+28h] [rbp-60h] BYREF
  FMOD::LocalSystemSection crit_dsp; // [rsp+30h] [rbp-58h] BYREF
  FMOD::LocalSystemSection crit_dspconnect; // [rsp+40h] [rbp-48h] BYREF

  mSystem = this->mSystem;
  crit_dsp.mEntered = 0;
  crit_dsp.mCritType = FMOD_SYSTEM_CRIT_DSPMIXER;
  crit_dspconnect.mEntered = 0;
  crit_dsp.mSystem = mSystem;
  crit_dspconnect.mSystem = mSystem;
  crit_dspconnect.mCritType = FMOD_SYSTEM_CRIT_DSPQUEUE;
  if ( !target )
  {
    numinputs = 0;
    numoutputs = 0;
    FMOD::DSPI::getNumInputsInternal(this, &numinputs, 0, protect);
    if ( numinputs )
    {
      while ( 1 )
      {
        InputInternal = FMOD::DSPI::getInputInternal(this, 0, &output, &inputconnection, 0, protect);
        if ( InputInternal )
          break;
        FMOD::DSPI::disconnectFromInternal(
          this,
          output,
          inputconnection,
          1,
          protect,
          FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
        FMOD::DSPI::getNumInputsInternal(this, &numinputs, 0, protect);
        if ( !numinputs )
          goto LABEL_52;
      }
    }
    else
    {
LABEL_52:
      FMOD::DSPI::getNumOutputsInternal(this, &numoutputs, 0, protect);
      if ( !numoutputs )
        goto LABEL_4;
      while ( 1 )
      {
        InputInternal = FMOD::DSPI::getOutputInternal(this, 0, &output, &inputconnection, 0, protect);
        if ( InputInternal )
          break;
        FMOD::DSPI::disconnectFromInternal(
          output,
          this,
          inputconnection,
          1,
          protect,
          FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
        FMOD::DSPI::getNumOutputsInternal(this, &numoutputs, 0, protect);
        if ( !numoutputs )
          goto LABEL_4;
      }
    }
LABEL_37:
    updated = InputInternal;
    goto LABEL_5;
  }
  if ( protect )
  {
    if ( mSystem )
    {
      FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_DSPQUEUE);
      crit_dspconnect.mEntered = 1;
      if ( crit_dsp.mSystem )
      {
        FMOD::SystemI::enterCrit(crit_dsp.mSystem, crit_dsp.mCritType);
        crit_dsp.mEntered = 1;
      }
    }
  }
  mNumInputs = this->mNumInputs;
  this->mJob.mSingleInput = 0;
  if ( !mNumInputs || !target->mNumOutputs )
    goto LABEL_4;
  if ( !connection )
  {
    if ( mNumInputs <= 0 )
    {
LABEL_57:
      updated = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
      goto LABEL_5;
    }
    v25 = 0;
    while ( 1 )
    {
      count = v25;
      InputInternal = FMOD::DSPI::getInputInternal(this, v25, 0, &inputconnection, 0, protect);
      if ( InputInternal )
        goto LABEL_37;
      connection = inputconnection;
      v27 = inputconnection->mFlags & 5;
      if ( type == FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SIDECHAIN_0 )
        break;
      if ( type > FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SIDECHAIN_0 )
      {
        if ( type == FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SEND_0 )
        {
          v26 = v27 == 4;
          goto LABEL_42;
        }
        v26 = v27 == 5;
        if ( type == FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SEND_SIDECHAIN_0 )
          goto LABEL_42;
      }
      else
      {
        v26 = v27 == 0;
        if ( type == FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0 )
          goto LABEL_42;
      }
LABEL_48:
      if ( inputconnection->mInputUnit == target )
        goto LABEL_10;
LABEL_43:
      v25 = count + 1;
      if ( this->mNumInputs <= count + 1 )
        goto LABEL_57;
    }
    v26 = v27 == 1;
LABEL_42:
    if ( !v26 )
      goto LABEL_43;
    goto LABEL_48;
  }
LABEL_10:
  mInputUnit = connection->mInputUnit;
  updated = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
  if ( mInputUnit != target )
    goto LABEL_5;
  mNodeNext = connection->mInputNode.mNodeNext;
  mNodePrev = connection->mInputNode.mNodePrev;
  target->mJob.mDelayClock.mDelayParent = 0;
  mNodePrev->mNodeNext = mNodeNext;
  connection->mInputNode.mNodeNext->mNodePrev = mNodePrev;
  connection->mInputNode.mNodePrev = &connection->mInputNode;
  connection->mInputNode.mNodeNext = &connection->mInputNode;
  mFlags = connection->mFlags;
  --this->mNumInputs;
  v19 = mFlags & 5;
  if ( (mFlags & 5) == 0 )
    --this->mNumStandardInputs;
  v20 = mFlags & 1;
  if ( v20 )
    --this->mNumSideChainInputs;
  v21 = connection->mOutputNode.mNodePrev;
  v21->mNodeNext = connection->mOutputNode.mNodeNext;
  connection->mOutputNode.mNodeNext->mNodePrev = v21;
  connection->mOutputNode.mNodePrev = &connection->mOutputNode;
  connection->mOutputNode.mNodeNext = &connection->mOutputNode;
  v22 = mInputUnit->mNumOutputs - 1;
  mInputUnit->mNumOutputs = v22;
  if ( !v19 )
    --mInputUnit->mNumStandardOutputs;
  if ( v20 )
    --mInputUnit->mNumSideChainOutputs;
  if ( v22 <= 1 )
    mInputUnit->mJob.mFlags &= ~0x40u;
  if ( freeconnection )
  {
    updated = FMOD::ExpandingPool<FMOD::DSPConnectionI>::free(&this->mSystem->mDSPConnectionPool, connection, protect);
    if ( updated )
      goto LABEL_5;
  }
  else
  {
    FMOD::DSPConnectionI::clearInputOutputNodes(connection);
  }
  updated = FMOD::DSPI::updateSingleInput(this);
  if ( updated )
    goto LABEL_5;
  *(_DWORD *)(*(unsigned __int64 *)((char *)&stru_10788.r_offset + (unsigned __int64)this->mSystem) + 48) = 1;
  if ( protect )
  {
    FMOD::LocalSystemSection::leave(&crit_dsp);
    FMOD::LocalSystemSection::leave(&crit_dspconnect);
    goto LABEL_5;
  }
LABEL_4:
  updated = FMOD_RESULT::FMOD_OK_0;
LABEL_5:
  if ( crit_dspconnect.mEntered && crit_dspconnect.mSystem )
  {
    crit_dspconnect.mEntered = 0;
    FMOD::SystemI::leaveCrit(crit_dspconnect.mSystem, crit_dspconnect.mCritType);
  }
  if ( crit_dsp.mEntered && crit_dsp.mSystem )
  {
    crit_dsp.mEntered = 0;
    FMOD::SystemI::leaveCrit(crit_dsp.mSystem, crit_dsp.mCritType);
  }
  return updated;
}


// Address: 0x21ba740 | Name: _ZN4FMOD4DSPI14disconnectFromEPS0_PNS_14DSPConnectionIE23FMOD_DSPCONNECTION_TYPE
FMOD_RESULT_0 __fastcall FMOD::DSPI::disconnectFrom(
        FMOD::DSPI *const this,
        FMOD::DSPI *target,
        FMOD::DSPConnectionI *connection,
        FMOD_DSPCONNECTION_TYPE_0 type)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPQueueCmd_DisconnectFrom *v8; // rsi
  FMOD::DSPQueueCmd_DisconnectFrom *cmd; // [rsp+8h] [rbp-30h] BYREF

  if ( (this->mJob.mFlags & 0x400) != 0 )
    return FMOD::DSPI::disconnectFromInternal(this, target, connection, 1, 0, type);
  result = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 40, 1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v8 = cmd;
    *(_BYTE *)&cmd->FMOD::DSPQueueCmd = 4;
    v8->mThis = this;
    v8->mTarget = target;
    v8->mConnection = connection;
    v8->mType = type;
    if ( target )
      target->mJob.mQueuedForDisconnect = 1;
    else
      this->mJob.mQueuedForDisconnect = 1;
    return FMOD::SystemI::unlockDSPQueueCmd(this->mSystem, v8, 1);
  }
  return result;
}


// Address: 0x21ba7f0 | Name: _ZN4FMOD4DSPI21disconnectAllInternalEbbbb
FMOD_RESULT_0 __fastcall FMOD::DSPI::disconnectAllInternal(
        FMOD::DSPI *const this,
        bool inputs,
        bool outputs,
        bool standardonly,
        bool protect)
{
  int v5; // r13d
  FMOD_RESULT_0 result; // eax
  int v7; // r12d
  int v8; // ebp
  int v9; // r12d
  int v10; // ebp
  int numinputs; // [rsp+28h] [rbp-50h] BYREF
  int numoutputs; // [rsp+2Ch] [rbp-4Ch] BYREF
  FMOD::DSPI *output; // [rsp+30h] [rbp-48h] BYREF
  FMOD::DSPConnectionI *outputconnection[8]; // [rsp+38h] [rbp-40h] BYREF

  if ( !inputs )
    goto LABEL_12;
  v5 = standardonly ? 5 : 0;
  result = FMOD::DSPI::getNumInputsInternal(this, &numinputs, standardonly, protect);
  if ( result )
    return result;
  if ( numinputs > 0 )
  {
    v7 = 0;
    v8 = 0;
    for ( result = FMOD::DSPI::getInputInternal(this, 0, &output, outputconnection, standardonly, protect);
          result == FMOD_RESULT::FMOD_OK_0;
          result = FMOD::DSPI::getInputInternal(this, v7, &output, outputconnection, standardonly, protect) )
    {
      if ( (v5 & outputconnection[0]->mFlags) != 0 )
      {
        ++v7;
      }
      else
      {
        result = FMOD::DSPI::disconnectFromInternal(
                   this,
                   output,
                   outputconnection[0],
                   1,
                   protect,
                   FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
        if ( result )
          return result;
      }
      if ( numinputs <= ++v8 )
        goto LABEL_12;
    }
  }
  else
  {
LABEL_12:
    if ( !outputs )
      return FMOD_RESULT::FMOD_OK_0;
    result = FMOD::DSPI::getNumOutputsInternal(this, &numoutputs, standardonly, protect);
    if ( result )
      return result;
    if ( numoutputs <= 0 )
      return FMOD_RESULT::FMOD_OK_0;
    v9 = 0;
    v10 = 0;
    for ( result = FMOD::DSPI::getOutputInternal(this, 0, &output, outputconnection, standardonly, protect);
          result == FMOD_RESULT::FMOD_OK_0;
          result = FMOD::DSPI::getOutputInternal(this, v9, &output, outputconnection, standardonly, protect) )
    {
      if ( ((standardonly ? 5 : 0) & outputconnection[0]->mFlags) != 0 )
      {
        ++v9;
      }
      else
      {
        result = FMOD::DSPI::disconnectFromInternal(
                   output,
                   this,
                   outputconnection[0],
                   1,
                   protect,
                   FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
        if ( result )
          return result;
      }
      if ( numoutputs <= ++v10 )
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21ba9c0 | Name: _ZN4FMOD4DSPI13disconnectAllEbb
FMOD_RESULT_0 __fastcall FMOD::DSPI::disconnectAll(FMOD::DSPI *const this, bool inputs, bool outputs)
{
  FMOD_RESULT_0 v6; // ebx
  FMOD::DSPQueueCmd_DisconnectAll *v8; // rsi
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 v10; // eax
  FMOD::DSPQueueCmd_DisconnectAll *cmd; // [rsp+8h] [rbp-30h] BYREF

  if ( !inputs && !outputs )
    return FMOD_RESULT::FMOD_OK_0;
  if ( (this->mJob.mFlags & 0x400) != 0 )
    return FMOD::DSPI::disconnectAllInternal(this, inputs, outputs, 0, 0);
  v6 = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 24, 1);
  if ( v6 )
    return v6;
  v8 = cmd;
  mSystem = this->mSystem;
  this->mJob.mQueuedForDisconnect = 1;
  v8->mThis = this;
  v8->mInputs = inputs;
  v8->mOutputs = outputs;
  *(_BYTE *)&v8->FMOD::DSPQueueCmd = 5;
  v8->mAddToReleaseQueue = 0;
  v10 = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v8, 1);
  if ( v10 )
    return v10;
  return v6;
}


// Address: 0x21baa90 | Name: _ZN4FMOD4DSPI25removeToInclusiveInternalEPS0_b
FMOD_RESULT_0 __fastcall FMOD::DSPI::removeToInclusiveInternal(
        FMOD::DSPI *const this,
        FMOD::DSPI *target,
        bool protect)
{
  FMOD_RESULT_0 result; // eax
  int v5; // r13d
  int v6; // r12d
  int numinputs; // [rsp+10h] [rbp-58h] BYREF
  int numoutputs; // [rsp+14h] [rbp-54h] BYREF
  FMOD::DSPI *next; // [rsp+18h] [rbp-50h] BYREF
  FMOD::DSPI *output; // [rsp+20h] [rbp-48h] BYREF
  FMOD::DSPConnectionI *connection[8]; // [rsp+28h] [rbp-40h] BYREF

  result = FMOD::DSPI::getNumOutputsInternal(this, &numoutputs, 1, protect);
  if ( result )
    return result;
  result = FMOD::DSPI::getNumInputsInternal(target, &numinputs, 1, protect);
  if ( result )
    return result;
  if ( numinputs > 1 )
  {
    LOBYTE(result) = 28;
    if ( numoutputs > 1 )
      return result;
LABEL_6:
    next = 0;
    result = FMOD::DSPI::getOutputInternal(this, 0, &next, 0, 1, protect);
    if ( result != FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0 && result )
      return result;
    if ( next )
    {
      result = FMOD::DSPI::disconnectFromInternal(
                 next,
                 this,
                 0,
                 1,
                 protect,
                 FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
      if ( result )
        return result;
    }
    if ( numinputs > 0 )
    {
      v5 = 0;
      while ( 1 )
      {
        result = FMOD::DSPI::getInputInternal(target, 0, &output, connection, 1, protect);
        if ( result )
          break;
        result = FMOD::DSPI::disconnectFromInternal(
                   target,
                   output,
                   connection[0],
                   0,
                   protect,
                   FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
        if ( result )
          break;
        if ( next )
        {
          result = FMOD::DSPI::addInputInternal(
                     next,
                     output,
                     0,
                     FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                     0,
                     connection[0],
                     protect);
          if ( result )
            return result;
        }
        else
        {
          result = FMOD::ExpandingPool<FMOD::DSPConnectionI>::free(
                     &this->mSystem->mDSPConnectionPool,
                     connection[0],
                     protect);
          if ( result )
            return result;
        }
        if ( numinputs <= ++v5 )
          return FMOD_RESULT::FMOD_OK_0;
      }
      return result;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( numinputs == 1 )
  {
    if ( !numoutputs )
      goto LABEL_6;
  }
  else if ( !numoutputs )
  {
    return result;
  }
  next = 0;
  result = FMOD::DSPI::getInputInternal(target, 0, &next, 0, 1, protect);
  if ( result != FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0 && result )
    return result;
  if ( next )
  {
    result = FMOD::DSPI::disconnectFromInternal(
               target,
               next,
               0,
               1,
               protect,
               FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
    if ( result )
      return result;
  }
  if ( numoutputs <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  v6 = 0;
  while ( 1 )
  {
    result = FMOD::DSPI::getOutputInternal(this, 0, &output, connection, 1, protect);
    if ( result )
      break;
    result = FMOD::DSPI::disconnectFromInternal(
               output,
               this,
               connection[0],
               0,
               protect,
               FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
    if ( result )
      break;
    if ( next )
    {
      result = FMOD::DSPI::addInputInternal(
                 output,
                 next,
                 0,
                 FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                 0,
                 connection[0],
                 protect);
      if ( result )
        return result;
    }
    else
    {
      result = FMOD::ExpandingPool<FMOD::DSPConnectionI>::free(
                 &this->mSystem->mDSPConnectionPool,
                 connection[0],
                 protect);
      if ( result )
        return result;
    }
    if ( numoutputs <= ++v6 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21bad80 | Name: _ZN4FMOD4DSPI17removeToInclusiveEPS0_b
FMOD_RESULT_0 __fastcall FMOD::DSPI::removeToInclusive(FMOD::DSPI *const this, FMOD::DSPI *target, bool protect)
{
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 v6; // ebx
  FMOD::DSPQueueCmd_RemoveToInclusive *v9; // rsi
  FMOD::SystemI *v10; // rdi
  FMOD_RESULT_0 v11; // eax
  FMOD::DSPQueueCmd_RemoveToInclusive *cmd; // [rsp+8h] [rbp-30h] BYREF

  mSystem = this->mSystem;
  if ( !mSystem )
    return FMOD_RESULT::FMOD_OK_0;
  v6 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !target )
    return v6;
  if ( (this->mJob.mFlags & 0x400) != 0 )
    return FMOD::DSPI::removeToInclusiveInternal(this, target, 0);
  v6 = FMOD::SystemI::lockDSPQueueCmd(mSystem, (void **)&cmd, 24, protect);
  if ( v6 )
    return v6;
  v9 = cmd;
  v10 = this->mSystem;
  cmd->mThis = this;
  v9->mTarget = target;
  *(_BYTE *)&v9->FMOD::DSPQueueCmd = 6;
  v11 = FMOD::SystemI::unlockDSPQueueCmd(v10, v9, protect);
  if ( v11 )
    return v11;
  return v6;
}


// Address: 0x21bae50 | Name: _ZN4FMOD4DSPI23addInputChainAtInternalEPS0_iiib
FMOD_RESULT_0 __fastcall FMOD::DSPI::addInputChainAtInternal(
        FMOD::DSPI *const this,
        FMOD::DSPI *chainstart,
        int oldindex,
        int index,
        int chainlength,
        bool protect)
{
  bool v7; // bl
  FMOD::DSPI *v8; // rbp
  int v9; // r14d
  FMOD::DSPI *v10; // r15
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *v12; // rdi
  int v13; // r12d
  int v14; // ebp
  int v15; // ebp
  FMOD::DSPI *v16; // rdi
  int v17; // ebp
  FMOD_CLOCKTIME mClockNext; // rax
  int numoutputs; // [rsp+2Ch] [rbp-5Ch] BYREF
  FMOD::DSPI *destination_left; // [rsp+30h] [rbp-58h] BYREF
  FMOD::DSPI *destination_right; // [rsp+38h] [rbp-50h] BYREF
  FMOD::DSPI *output; // [rsp+40h] [rbp-48h] BYREF
  FMOD::DSPConnectionI *connection[8]; // [rsp+48h] [rbp-40h] BYREF

  destination_left = this;
  destination_right = 0;
  if ( chainlength <= 1 )
  {
    if ( chainlength == 1 )
    {
      result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      if ( (this != chainstart) != (oldindex != 0) )
        return result;
    }
    v10 = chainstart;
    v7 = protect;
  }
  else
  {
    v7 = protect;
    v8 = chainstart;
    v9 = 1;
    while ( FMOD::DSPI::getInputInternal(v8, 0, (FMOD::DSPI **)connection, 0, 1, v7) != FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0 )
    {
      v10 = (FMOD::DSPI *)connection[0];
      if ( connection[0] )
      {
        if ( (BYTE5(connection[0]->mInputUnit) & 1) == 0 )
          break;
      }
      if ( ++v9 == chainlength )
        goto LABEL_9;
      v8 = (FMOD::DSPI *)connection[0];
    }
    v10 = v8;
  }
LABEL_9:
  if ( oldindex
    || (result = FMOD::DSPI::getInputInternal(this, 0, &destination_left, 0, 1, v7)) == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD::DSPI::removeToInclusiveInternal(chainstart, v10, v7);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( index )
      {
        v12 = destination_left;
        v13 = 0;
        for ( destination_right = destination_left; ; v12 = destination_right )
        {
          destination_left = v12;
          if ( FMOD::DSPI::getInputInternal(v12, 0, &destination_right, 0, 1, v7) == FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0 )
            break;
          if ( index <= ++v13 )
            break;
        }
        if ( !destination_right )
          goto LABEL_34;
        result = FMOD::DSPI::getNumInputsInternal(destination_left, &numoutputs, 1, v7);
        if ( result )
          return result;
        if ( numoutputs > 0 )
        {
          v14 = 0;
          while ( 1 )
          {
            result = FMOD::DSPI::getInputInternal(destination_left, 0, &output, connection, 1, v7);
            if ( result )
              break;
            result = FMOD::DSPI::disconnectFromInternal(
                       destination_left,
                       output,
                       connection[0],
                       0,
                       v7,
                       FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
            if ( result )
              break;
            result = FMOD::DSPI::addInputInternal(
                       v10,
                       output,
                       0,
                       FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                       0,
                       connection[0],
                       v7);
            if ( result )
              break;
            if ( numoutputs <= ++v14 )
              goto LABEL_34;
          }
        }
        else
        {
LABEL_34:
          result = FMOD::DSPI::addInputInternal(
                     destination_left,
                     chainstart,
                     0,
                     FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                     0,
                     0,
                     v7);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = FMOD_RESULT::FMOD_OK_0;
            if ( oldindex < 0 )
            {
              connection[0] = (FMOD::DSPConnectionI *)chainstart;
              if ( chainlength <= 0 )
              {
                return FMOD_RESULT::FMOD_OK_0;
              }
              else
              {
                v16 = chainstart;
                v17 = 0;
                while ( 1 )
                {
                  mClockNext = destination_left->mJob.mDelayClock.mClockNext;
                  v16->mJob.mDelayClock.mClock = destination_left->mJob.mDelayClock.mClock;
                  v16->mJob.mDelayClock.mClockNext = mClockNext;
                  result = FMOD::DSPI::getInputInternal(v16, 0, (FMOD::DSPI **)connection, 0, 1, v7);
                  if ( result != FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0 )
                  {
                    if ( result )
                      break;
                  }
                  v16 = (FMOD::DSPI *)connection[0];
                  if ( connection[0] )
                  {
                    if ( ++v17 != chainlength )
                      continue;
                  }
                  return FMOD_RESULT::FMOD_OK_0;
                }
              }
            }
          }
        }
      }
      else
      {
        result = FMOD::DSPI::getNumOutputsInternal(this, &numoutputs, 1, v7);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          if ( numoutputs <= 0 )
          {
LABEL_46:
            result = FMOD::DSPI::addInputInternal(
                       v10,
                       this,
                       0,
                       FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                       0,
                       0,
                       v7);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              chainstart->mJob.mDelayClock.mClock = this->mJob.mDelayClock.mClock;
              chainstart->mJob.mDelayClock.mClockNext = this->mJob.mDelayClock.mClockNext;
            }
          }
          else
          {
            v15 = 0;
            while ( 1 )
            {
              result = FMOD::DSPI::getOutputInternal(this, 0, &output, connection, 1, v7);
              if ( result )
                break;
              result = FMOD::DSPI::disconnectFromInternal(
                         output,
                         this,
                         connection[0],
                         0,
                         v7,
                         FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
              if ( result )
                break;
              result = FMOD::DSPI::addInputInternal(
                         output,
                         chainstart,
                         0,
                         FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                         0,
                         connection[0],
                         v7);
              if ( result )
                break;
              if ( numoutputs <= ++v15 )
                goto LABEL_46;
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21bb220 | Name: _ZN4FMOD4DSPI15addInputChainAtEPS0_iiib
FMOD_RESULT_0 __fastcall FMOD::DSPI::addInputChainAt(
        FMOD::DSPI *const this,
        FMOD::DSPI *chainstart,
        int oldindex,
        int index,
        int chainlength,
        bool protect)
{
  const FMOD_DSP_DESCRIPTION *mDescription; // r10
  FMOD_RESULT_0 v11; // ebx
  const FMOD_DSP_DESCRIPTION *v13; // rax
  FMOD::DSPQueueCmd_AddInputChainAt *v15; // rsi
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 v17; // eax
  FMOD::DSPQueueCmd_AddInputChainAt *cmd; // [rsp+18h] [rbp-40h] BYREF

  mDescription = this->mDescription.mDescription;
  if ( !mDescription || (v11 = FMOD_RESULT::FMOD_ERR_DSP_CONNECTION_0, mDescription->numinputbuffers) )
  {
    v13 = chainstart->mDescription.mDescription;
    if ( !v13 || (v11 = FMOD_RESULT::FMOD_ERR_DSP_CONNECTION_0, v13->numoutputbuffers) )
    {
      if ( (this->mJob.mFlags & 0x400) != 0 )
      {
        return FMOD::DSPI::addInputChainAtInternal(this, chainstart, oldindex, index, chainlength, 0);
      }
      else
      {
        v11 = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 40, protect);
        if ( v11 == FMOD_RESULT::FMOD_OK_0 )
        {
          v15 = cmd;
          mSystem = this->mSystem;
          *(_BYTE *)&cmd->FMOD::DSPQueueCmd = 2;
          v15->mThis = this;
          v15->mChainStart = chainstart;
          v15->mOldPosition = oldindex;
          v15->mPosition = index;
          v15->mChainLength = chainlength;
          v17 = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v15, protect);
          if ( v17 )
            return v17;
        }
      }
    }
  }
  return v11;
}


// Address: 0x21bb310 | Name: _ZN4FMOD4DSPI13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPI::resetInternal(FMOD::DSPI *const this)
{
  FMOD::SystemI *mSystem; // rbp
  char v3; // r9
  FMOD::FMOD_DSP_PROFILE_CONTEXT *mProfileContext; // rax
  FMOD::FMOD_DSP_METERING_CONTEXT *p_mOutputMeter; // rdx
  FMOD::FMOD_DSP_PROFILE_CONTEXT *v6; // rsi
  unsigned int v7; // r10d
  FMOD_DSP_METERING_INFO_0 *p_mCachedInfo; // rdi
  __int64 v9; // rcx
  int *v10; // rdi
  _DWORD *mPeaks; // rdi
  unsigned int v12; // r10d
  __int64 v13; // rcx
  _DWORD *v14; // rdi
  _DWORD *v15; // rdi
  unsigned int v16; // r8d
  __int64 v17; // rcx
  _DWORD *v18; // rdi
  FMOD_DSP_METERING_INFO_0 *v19; // rdi
  unsigned int v20; // r8d
  __int64 v21; // rcx
  int *v22; // rdi
  _DWORD *v23; // rdi
  unsigned int v24; // r8d
  __int64 v25; // rcx
  _DWORD *v26; // rdi
  _DWORD *v27; // rdi
  unsigned int v28; // esi
  __int64 v29; // rcx
  _DWORD *v30; // rdi
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  FMOD_RESULT_0 (__fastcall *reset)(FMOD_DSP_STATE *); // rax

  mSystem = this->mSystem;
  if ( mSystem )
  {
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
    v3 = 1;
  }
  else
  {
    v3 = 0;
  }
  mProfileContext = this->mProfileContext;
  if ( !mProfileContext )
    goto LABEL_64;
  p_mOutputMeter = 0;
  v6 = 0;
  if ( mProfileContext->mInputMeter.mActive )
    v6 = this->mProfileContext;
  if ( mProfileContext->mOutputMeter.mActive )
    p_mOutputMeter = &mProfileContext->mOutputMeter;
  if ( !v6 )
    goto LABEL_36;
  v6->mInputMeter.mSampleCount = 0;
  v7 = 264;
  v6->mInputMeter.mNumChannels = 0;
  p_mCachedInfo = &v6->mInputMeter.mCachedInfo;
  if ( ((unsigned __int8)v6 & 1) != 0 )
  {
    LOBYTE(v6->mInputMeter.mCachedInfo.numsamples) = 0;
    p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)&v6->mInputMeter.mCachedInfo.numsamples + 1);
    LOBYTE(v7) = 7;
  }
  if ( ((unsigned __int8)p_mCachedInfo & 2) != 0 )
  {
    p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)p_mCachedInfo + 2);
    v7 -= 2;
    *(&p_mCachedInfo[-1].numchannels + 1) = 0;
  }
  if ( ((unsigned __int8)p_mCachedInfo & 4) != 0 )
  {
    p_mCachedInfo->numsamples = 0;
    v7 -= 4;
    p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)p_mCachedInfo + 4);
  }
  v9 = v7 >> 3;
  memset(p_mCachedInfo, 0, 8 * v9);
  v10 = &p_mCachedInfo->numsamples + 2 * v9;
  if ( (v7 & 4) != 0 )
  {
    *v10++ = 0;
    if ( (v7 & 2) == 0 )
    {
LABEL_17:
      if ( (v7 & 1) == 0 )
        goto LABEL_18;
      goto LABEL_96;
    }
  }
  else if ( (v7 & 2) == 0 )
  {
    goto LABEL_17;
  }
  v10 = (int *)((char *)v10 + 2);
  *((_WORD *)v10 - 1) = 0;
  if ( (v7 & 1) != 0 )
LABEL_96:
    *(_BYTE *)v10 = 0;
LABEL_18:
  mPeaks = (_DWORD *)v6->mInputMeter.mPeaks;
  v12 = 128;
  if ( (((_BYTE)v6 + 0x80) & 1) != 0 )
  {
    LOBYTE(v6->mInputMeter.mPeaks[0]) = 0;
    mPeaks = (_DWORD *)((char *)v6->mInputMeter.mPeaks + 1);
    LOBYTE(v12) = 127;
  }
  if ( ((unsigned __int8)mPeaks & 2) != 0 )
  {
    mPeaks = (_DWORD *)((char *)mPeaks + 2);
    v12 -= 2;
    *((_WORD *)mPeaks - 1) = 0;
  }
  if ( ((unsigned __int8)mPeaks & 4) != 0 )
  {
    *mPeaks = 0;
    v12 -= 4;
    ++mPeaks;
  }
  v13 = v12 >> 3;
  memset(mPeaks, 0, 8 * v13);
  v14 = &mPeaks[2 * v13];
  if ( (v12 & 4) == 0 )
  {
    if ( (v12 & 2) == 0 )
      goto LABEL_26;
LABEL_92:
    v14 = (_DWORD *)((char *)v14 + 2);
    *((_WORD *)v14 - 1) = 0;
    if ( (v12 & 1) == 0 )
      goto LABEL_27;
    goto LABEL_91;
  }
  *v14++ = 0;
  if ( (v12 & 2) != 0 )
    goto LABEL_92;
LABEL_26:
  if ( (v12 & 1) != 0 )
LABEL_91:
    *(_BYTE *)v14 = 0;
LABEL_27:
  v15 = v6;
  v16 = 128;
  if ( ((unsigned __int8)v6 & 1) != 0 )
  {
    LOBYTE(v6->mInputMeter.mAccumulatedSquares[0]) = 0;
    v15 = (_DWORD *)((char *)v6->mInputMeter.mAccumulatedSquares + 1);
    LOBYTE(v16) = 127;
  }
  if ( ((unsigned __int8)v15 & 2) != 0 )
  {
    v15 = (_DWORD *)((char *)v15 + 2);
    v16 -= 2;
    *((_WORD *)v15 - 1) = 0;
  }
  if ( ((unsigned __int8)v15 & 4) != 0 )
  {
    *v15 = 0;
    v16 -= 4;
    ++v15;
  }
  v17 = v16 >> 3;
  memset(v15, 0, 8 * v17);
  v18 = &v15[2 * v17];
  if ( (v16 & 4) != 0 )
  {
    *v18++ = 0;
    if ( (v16 & 2) == 0 )
    {
LABEL_35:
      if ( (v16 & 1) == 0 )
        goto LABEL_36;
      goto LABEL_86;
    }
  }
  else if ( (v16 & 2) == 0 )
  {
    goto LABEL_35;
  }
  v18 = (_DWORD *)((char *)v18 + 2);
  *((_WORD *)v18 - 1) = 0;
  if ( (v16 & 1) != 0 )
LABEL_86:
    *(_BYTE *)v18 = 0;
LABEL_36:
  if ( !p_mOutputMeter )
    goto LABEL_64;
  v19 = &p_mOutputMeter->mCachedInfo;
  p_mOutputMeter->mSampleCount = 0;
  p_mOutputMeter->mNumChannels = 0;
  v20 = 264;
  if ( ((unsigned __int8)p_mOutputMeter & 1) != 0 )
  {
    LOBYTE(p_mOutputMeter->mCachedInfo.numsamples) = 0;
    v19 = (FMOD_DSP_METERING_INFO_0 *)((char *)&p_mOutputMeter->mCachedInfo.numsamples + 1);
    LOBYTE(v20) = 7;
  }
  if ( ((unsigned __int8)v19 & 2) != 0 )
  {
    v19 = (FMOD_DSP_METERING_INFO_0 *)((char *)v19 + 2);
    v20 -= 2;
    *(&v19[-1].numchannels + 1) = 0;
  }
  if ( ((unsigned __int8)v19 & 4) != 0 )
  {
    v19->numsamples = 0;
    v20 -= 4;
    v19 = (FMOD_DSP_METERING_INFO_0 *)((char *)v19 + 4);
  }
  v21 = v20 >> 3;
  memset(v19, 0, 8 * v21);
  v22 = &v19->numsamples + 2 * v21;
  if ( (v20 & 4) != 0 )
  {
    *v22++ = 0;
    if ( (v20 & 2) == 0 )
    {
LABEL_45:
      if ( (v20 & 1) == 0 )
        goto LABEL_46;
      goto LABEL_81;
    }
  }
  else if ( (v20 & 2) == 0 )
  {
    goto LABEL_45;
  }
  v22 = (int *)((char *)v22 + 2);
  *((_WORD *)v22 - 1) = 0;
  if ( (v20 & 1) != 0 )
LABEL_81:
    *(_BYTE *)v22 = 0;
LABEL_46:
  v23 = (_DWORD *)p_mOutputMeter->mPeaks;
  v24 = 128;
  if ( (((_BYTE)p_mOutputMeter + 0x80) & 1) != 0 )
  {
    LOBYTE(p_mOutputMeter->mPeaks[0]) = 0;
    v23 = (_DWORD *)((char *)p_mOutputMeter->mPeaks + 1);
    LOBYTE(v24) = 127;
  }
  if ( ((unsigned __int8)v23 & 2) != 0 )
  {
    v23 = (_DWORD *)((char *)v23 + 2);
    v24 -= 2;
    *((_WORD *)v23 - 1) = 0;
  }
  if ( ((unsigned __int8)v23 & 4) != 0 )
  {
    *v23 = 0;
    v24 -= 4;
    ++v23;
  }
  v25 = v24 >> 3;
  memset(v23, 0, 8 * v25);
  v26 = &v23[2 * v25];
  if ( (v24 & 4) != 0 )
  {
    *v26++ = 0;
    if ( (v24 & 2) == 0 )
    {
LABEL_54:
      if ( (v24 & 1) == 0 )
        goto LABEL_55;
      goto LABEL_76;
    }
  }
  else if ( (v24 & 2) == 0 )
  {
    goto LABEL_54;
  }
  v26 = (_DWORD *)((char *)v26 + 2);
  *((_WORD *)v26 - 1) = 0;
  if ( (v24 & 1) != 0 )
LABEL_76:
    *(_BYTE *)v26 = 0;
LABEL_55:
  v27 = p_mOutputMeter;
  v28 = 128;
  if ( ((unsigned __int8)p_mOutputMeter & 1) != 0 )
  {
    LOBYTE(p_mOutputMeter->mAccumulatedSquares[0]) = 0;
    v27 = (_DWORD *)((char *)p_mOutputMeter->mAccumulatedSquares + 1);
    LOBYTE(v28) = 127;
  }
  if ( ((unsigned __int8)v27 & 2) != 0 )
  {
    v27 = (_DWORD *)((char *)v27 + 2);
    v28 -= 2;
    *((_WORD *)v27 - 1) = 0;
  }
  if ( ((unsigned __int8)v27 & 4) != 0 )
  {
    *v27 = 0;
    v28 -= 4;
    ++v27;
  }
  v29 = v28 >> 3;
  memset(v27, 0, 8 * v29);
  v30 = &v27[2 * v29];
  if ( (v28 & 4) == 0 )
  {
    if ( (v28 & 2) == 0 )
      goto LABEL_63;
    goto LABEL_72;
  }
  *v30++ = 0;
  if ( (v28 & 2) != 0 )
  {
LABEL_72:
    v30 = (_DWORD *)((char *)v30 + 2);
    *((_WORD *)v30 - 1) = 0;
    if ( (v28 & 1) != 0 )
      goto LABEL_69;
LABEL_64:
    if ( !v3 )
      goto LABEL_65;
    goto LABEL_70;
  }
LABEL_63:
  if ( (v28 & 1) == 0 )
    goto LABEL_64;
LABEL_69:
  *(_BYTE *)v30 = 0;
  if ( !v3 )
    goto LABEL_65;
LABEL_70:
  if ( mSystem )
    FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
LABEL_65:
  mDescription = this->mDescription.mDescription;
  if ( !mDescription )
    return FMOD_RESULT::FMOD_OK_0;
  reset = mDescription->reset;
  if ( !reset )
    return FMOD_RESULT::FMOD_OK_0;
  this->mState.instance = this;
  return reset(&this->mState);
}


// Address: 0x21bb980 | Name: _ZN4FMOD4DSPI5resetEv
FMOD_RESULT_0 __fastcall FMOD::DSPI::reset(FMOD::DSPI *const this)
{
  FMOD_RESULT_0 v2; // ebp
  FMOD::DSPQueueCmd_Reset *v4; // rsi
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 v6; // eax
  FMOD::DSPQueueCmd_Reset *cmd; // [rsp+8h] [rbp-20h] BYREF

  if ( (this->mJob.mFlags & 0x400) != 0 )
    return FMOD::DSPI::resetInternal(this);
  v2 = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 16, 1);
  if ( v2 )
    return v2;
  v4 = cmd;
  mSystem = this->mSystem;
  cmd->mThis = this;
  *(_BYTE *)&v4->FMOD::DSPQueueCmd = 17;
  v6 = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v4, 1);
  if ( v6 )
    return v6;
  return v2;
}


// Address: 0x21bba00 | Name: _ZN4FMOD4DSPI17setParameterFloatEif
FMOD_RESULT_0 __fastcall FMOD::DSPI::setParameterFloat(FMOD::DSPI *const this, int index, __m128i a3, double value)
{
  const FMOD_DSP_DESCRIPTION *mDescription; // rdx
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 (__fastcall *setparameterfloat)(FMOD_DSP_STATE *, double, double); // rcx
  FMOD_DSP_PARAMETER_DESC **paramdesc; // rdx
  FMOD_DSP_PARAMETER_DESC *v8; // rdx

  if ( index < 0 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mDescription = this->mDescription.mDescription;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( mDescription && index < mDescription->numparameters )
  {
    setparameterfloat = (FMOD_RESULT_0 (__fastcall *)(FMOD_DSP_STATE *, double, double))mDescription->setparameterfloat;
    if ( !setparameterfloat )
      return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
    paramdesc = mDescription->paramdesc;
    if ( paramdesc )
    {
      v8 = paramdesc[index];
      if ( v8->type )
        return result;
      if ( (_mm_cvtsi128_si32(a3) & 0x7F800000) == 0x7F800000 )
        return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
      *(_QWORD *)&value = (unsigned int)v8->intdesc.min;
      *(float *)&value = fmaxf(*(float *)&value, *(float *)a3.m128i_i32);
      a3.m128i_i64[0] = (unsigned int)v8->intdesc.max;
      *(float *)a3.m128i_i32 = fminf(*(float *)a3.m128i_i32, *(float *)&value);
    }
    this->mState.instance = this;
    return setparameterfloat(&this->mState, *(double *)a3.m128i_i64, value);
  }
  return result;
}


// Address: 0x21bbab0 | Name: _ZN4FMOD4DSPI15setParameterIntEii
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::DSPI::setParameterInt(FMOD::DSPI *const this, int index, int value)
{
  const FMOD_DSP_DESCRIPTION *mDescription; // rcx
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 (__fastcall *setparameterint)(_QWORD, _DWORD, _QWORD); // r8
  FMOD_DSP_PARAMETER_DESC *v6; // rcx
  int min; // eax
  int max; // eax

  if ( index < 0 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mDescription = this->mDescription.mDescription;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( mDescription && index < mDescription->numparameters )
  {
    setparameterint = (FMOD_RESULT_0 (__fastcall *)(_QWORD, _DWORD, _QWORD))mDescription->setparameterint;
    if ( setparameterint )
    {
      v6 = mDescription->paramdesc[index];
      if ( v6->type == FMOD_DSP_PARAMETER_TYPE_INT )
      {
        min = v6->intdesc.min;
        if ( value < min )
          *(_QWORD *)&value = (unsigned int)min;
        max = v6->intdesc.max;
        this->mState.instance = this;
        if ( value > max )
          *(_QWORD *)&value = (unsigned int)max;
        return setparameterint(&this->mState, index, *(_QWORD *)&value);
      }
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
    }
  }
  return result;
}


// Address: 0x21bbb30 | Name: _ZN4FMOD4DSPI16setParameterBoolEib
FMOD_RESULT_0 __fastcall FMOD::DSPI::setParameterBool(FMOD::DSPI *const this, int index, bool value)
{
  const FMOD_DSP_DESCRIPTION *mDescription; // rcx
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 (__fastcall *setparameterbool)(FMOD_DSP_STATE *, int, bool); // r8

  if ( index < 0 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mDescription = this->mDescription.mDescription;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( mDescription && index < mDescription->numparameters )
  {
    setparameterbool = (FMOD_RESULT_0 (__fastcall *)(FMOD_DSP_STATE *, int, bool))mDescription->setparameterbool;
    if ( setparameterbool )
    {
      if ( mDescription->paramdesc[index]->type == FMOD_DSP_PARAMETER_TYPE_BOOL )
      {
        this->mState.instance = this;
        return setparameterbool(&this->mState, index, value);
      }
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
    }
  }
  return result;
}


// Address: 0x21bbbb0 | Name: _ZN4FMOD4DSPI16setParameterDataEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPI::setParameterData(
        FMOD::DSPI *const this,
        int index,
        void *value,
        unsigned int length)
{
  FMOD_RESULT_0 result; // eax
  const FMOD_DSP_DESCRIPTION *mDescription; // r10
  FMOD_DSP_PARAMETER_DESC *v8; // rsi
  FMOD_RESULT_0 (__fastcall *setparameterdata)(_QWORD, _QWORD, _QWORD, _DWORD); // r11
  int min; // eax
  FMOD::SystemI *mSystem; // rsi
  FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *p_attributes; // rdi
  int *v13; // rsi
  __int64 i; // rcx
  float *p_z; // rax
  float *v16; // rdx
  float v17; // xmm1_4
  FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI attributes; // [rsp+0h] [rbp-1E8h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index >= 0 )
  {
    mDescription = this->mDescription.mDescription;
    if ( index < mDescription->numparameters )
    {
      v8 = mDescription->paramdesc[index];
      if ( v8->type == FMOD_DSP_PARAMETER_TYPE_DATA )
      {
        setparameterdata = (FMOD_RESULT_0 (__fastcall *)(_QWORD, _QWORD, _QWORD, _DWORD))mDescription->setparameterdata;
        LOBYTE(result) = 68;
        if ( setparameterdata )
        {
          min = v8->intdesc.min;
          if ( *(&this->mDescription.mHandle + 1) && !min )
          {
            this->mState.instance = this;
            return setparameterdata(&this->mState, (unsigned int)index, value, length);
          }
          if ( value )
          {
            mSystem = this->mSystem;
            this->mState.instance = this;
            if ( (mSystem->mFlags & 4) == 0 || mDescription->pluginsdkversion <= 0x6C )
              return setparameterdata(&this->mState, (unsigned int)index, value, length);
            if ( min == -5 )
            {
              if ( length == 468
                && (qmemcpy(&attributes, value, sizeof(attributes)),
                    LODWORD(attributes.absolute.position.z) ^= 0x80000000,
                    LODWORD(attributes.absolute.velocity.z) ^= 0x80000000,
                    LODWORD(attributes.absolute.forward.z) ^= 0x80000000,
                    attributes.absolute.up.z = -attributes.absolute.up.z,
                    attributes.numlisteners > 0) )
              {
                p_z = &attributes.relative[0].position.z;
                v16 = &attributes.relative[(unsigned int)(attributes.numlisteners - 1) + 1].position.z;
                do
                {
                  v17 = *p_z;
                  p_z += 12;
                  *(p_z - 12) = -v17;
                  *(p_z - 9) = -*(p_z - 9);
                  *(p_z - 6) = -*(p_z - 6);
                  *(p_z - 3) = -*(p_z - 3);
                }
                while ( p_z != v16 );
                return mDescription->setparameterdata(&this->mState, index, &attributes, 468u);
              }
              else
              {
                return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
              }
            }
            else
            {
              if ( min != -2 )
                return setparameterdata(&this->mState, (unsigned int)index, value, length);
              result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
              if ( length == 96 )
              {
                p_attributes = &attributes;
                v13 = (int *)value;
                for ( i = 24; i; --i )
                {
                  p_attributes->numlisteners = *v13++;
                  p_attributes = (FMOD_DSP_PARAMETER_3DATTRIBUTES_MULTI *)((char *)p_attributes + 4);
                }
                LODWORD(attributes.relative[1].position.y) ^= 0x80000000;
                LODWORD(attributes.relative[1].velocity.y) ^= 0x80000000;
                LODWORD(attributes.relative[1].forward.y) ^= 0x80000000;
                LODWORD(attributes.relative[1].up.y) ^= 0x80000000;
                LODWORD(attributes.relative[0].position.y) ^= 0x80000000;
                LODWORD(attributes.relative[0].velocity.y) ^= 0x80000000;
                LODWORD(attributes.relative[0].forward.y) ^= 0x80000000;
                attributes.relative[0].up.y = -attributes.relative[0].up.y;
                return setparameterdata(&this->mState, (unsigned int)index, &attributes, 96);
              }
            }
          }
          else
          {
            return FMOD_RESULT::FMOD_OK_0;
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21bbe20 | Name: _ZN4FMOD4DSPI17getParameterFloatEiPfPci
FMOD_RESULT_0 __fastcall FMOD::DSPI::getParameterFloat(
        FMOD::DSPI *const this,
        int index,
        float *value,
        char *valuestr,
        int valuestrlen)
{
  FMOD_RESULT_0 v5; // ebx
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  __int64 (__fastcall *getparameterfloat)(FMOD_DSP_STATE *, int, float *, char *); // r9
  char *v11; // r13
  float v; // [rsp+1Ch] [rbp-4Ch] BYREF
  char sbuf[72]; // [rsp+20h] [rbp-48h] BYREF

  v5 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v = 0.0;
  if ( index >= 0 )
  {
    mDescription = this->mDescription.mDescription;
    if ( mDescription )
    {
      if ( index < mDescription->numparameters )
      {
        getparameterfloat = (__int64 (__fastcall *)(FMOD_DSP_STATE *, int, float *, char *))mDescription->getparameterfloat;
        LOBYTE(v5) = 68;
        if ( getparameterfloat )
        {
          LOBYTE(v5) = 31;
          if ( mDescription->paramdesc[index]->type == FMOD_DSP_PARAMETER_TYPE_FLOAT )
          {
            this->mState.instance = this;
            sbuf[0] = 0;
            v11 = sbuf;
            if ( !valuestr && *(&this->mDescription.mHandle + 1) )
              v11 = 0;
            v5 = (unsigned int)getparameterfloat(&this->mState, index, &v, v11);
            if ( v5 == FMOD_RESULT::FMOD_OK_0 )
            {
              if ( value )
                *value = v;
              v5 = FMOD_RESULT::FMOD_OK_0;
              if ( valuestr )
                FMOD_strcpy_safe(valuestr, v11, valuestrlen);
            }
          }
        }
      }
    }
  }
  return v5;
}


// Address: 0x21bbf00 | Name: _ZN4FMOD4DSPI15getParameterIntEiPiPci
FMOD_RESULT_0 __fastcall FMOD::DSPI::getParameterInt(
        FMOD::DSPI *const this,
        int index,
        int *value,
        char *valuestr,
        int valuestrlen)
{
  FMOD_RESULT_0 v5; // ebx
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  __int64 (__fastcall *getparameterint)(FMOD_DSP_STATE *, int, int *, char *); // r9
  char *v11; // r13
  int v; // [rsp+1Ch] [rbp-4Ch] BYREF
  char sbuf[72]; // [rsp+20h] [rbp-48h] BYREF

  v5 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v = 0;
  if ( index >= 0 )
  {
    mDescription = this->mDescription.mDescription;
    if ( mDescription )
    {
      if ( index < mDescription->numparameters )
      {
        getparameterint = (__int64 (__fastcall *)(FMOD_DSP_STATE *, int, int *, char *))mDescription->getparameterint;
        LOBYTE(v5) = 68;
        if ( getparameterint )
        {
          LOBYTE(v5) = 31;
          if ( mDescription->paramdesc[index]->type == FMOD_DSP_PARAMETER_TYPE_INT )
          {
            this->mState.instance = this;
            sbuf[0] = 0;
            v11 = sbuf;
            if ( !valuestr && *(&this->mDescription.mHandle + 1) )
              v11 = 0;
            v5 = (unsigned int)getparameterint(&this->mState, index, &v, v11);
            if ( v5 == FMOD_RESULT::FMOD_OK_0 )
            {
              if ( value )
                *value = v;
              v5 = FMOD_RESULT::FMOD_OK_0;
              if ( valuestr )
                FMOD_strcpy_safe(valuestr, v11, valuestrlen);
            }
          }
        }
      }
    }
  }
  return v5;
}


// Address: 0x21bbfe0 | Name: _ZN4FMOD4DSPI16getParameterBoolEiPbPci
FMOD_RESULT_0 __fastcall FMOD::DSPI::getParameterBool(
        FMOD::DSPI *const this,
        int index,
        bool *value,
        char *valuestr,
        int valuestrlen)
{
  FMOD_RESULT_0 v5; // ebx
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  __int64 (__fastcall *getparameterbool)(FMOD_DSP_STATE *, int, FMOD_BOOL *, char *); // r9
  char *v11; // r13
  FMOD_BOOL v; // [rsp+1Ch] [rbp-4Ch] BYREF
  char sbuf[72]; // [rsp+20h] [rbp-48h] BYREF

  v5 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v = 0;
  if ( index >= 0 )
  {
    mDescription = this->mDescription.mDescription;
    if ( mDescription )
    {
      if ( index < mDescription->numparameters )
      {
        getparameterbool = (__int64 (__fastcall *)(FMOD_DSP_STATE *, int, FMOD_BOOL *, char *))mDescription->getparameterbool;
        LOBYTE(v5) = 68;
        if ( getparameterbool )
        {
          LOBYTE(v5) = 31;
          if ( mDescription->paramdesc[index]->type == FMOD_DSP_PARAMETER_TYPE_BOOL )
          {
            this->mState.instance = this;
            sbuf[0] = 0;
            v11 = sbuf;
            if ( !valuestr && *(&this->mDescription.mHandle + 1) )
              v11 = 0;
            v5 = (unsigned int)getparameterbool(&this->mState, index, &v, v11);
            if ( v5 == FMOD_RESULT::FMOD_OK_0 )
            {
              if ( value )
                *value = v != 0;
              v5 = FMOD_RESULT::FMOD_OK_0;
              if ( valuestr )
                FMOD_strcpy_safe(valuestr, v11, valuestrlen);
            }
          }
        }
      }
    }
  }
  return v5;
}


// Address: 0x21bc0c0 | Name: _ZN4FMOD4DSPI16getParameterDataEiPPvPjPci
FMOD_RESULT_0 __fastcall FMOD::DSPI::getParameterData(
        FMOD::DSPI *const this,
        int index,
        void **value,
        unsigned int *length,
        char *valuestr,
        int valuestrlen)
{
  FMOD_RESULT_0 v6; // ebx
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  __int64 (__fastcall *getparameterdata)(FMOD_DSP_STATE *, int, void **, unsigned int *, char *); // r11
  char *v13; // r14
  unsigned int l; // [rsp+14h] [rbp-54h] BYREF
  void *v; // [rsp+18h] [rbp-50h] BYREF
  char sbuf[72]; // [rsp+20h] [rbp-48h] BYREF

  v6 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v = 0;
  l = 0;
  if ( index >= 0 )
  {
    mDescription = this->mDescription.mDescription;
    if ( mDescription )
    {
      if ( index < mDescription->numparameters )
      {
        getparameterdata = (__int64 (__fastcall *)(FMOD_DSP_STATE *, int, void **, unsigned int *, char *))mDescription->getparameterdata;
        LOBYTE(v6) = 68;
        if ( getparameterdata )
        {
          LOBYTE(v6) = 31;
          if ( mDescription->paramdesc[index]->type == FMOD_DSP_PARAMETER_TYPE_DATA )
          {
            this->mState.instance = this;
            sbuf[0] = 0;
            v13 = sbuf;
            if ( !valuestr && *(&this->mDescription.mHandle + 1) )
              v13 = 0;
            v6 = (unsigned int)getparameterdata(&this->mState, index, &v, &l, v13);
            if ( v6 == FMOD_RESULT::FMOD_OK_0 )
            {
              if ( value )
                *value = v;
              if ( length )
                *length = l;
              v6 = FMOD_RESULT::FMOD_OK_0;
              if ( valuestr )
                FMOD_strcpy_safe(valuestr, v13, valuestrlen);
            }
          }
        }
      }
    }
  }
  return v6;
}


// Address: 0x21bc1c0 | Name: _ZN4FMOD4DSPI16getNumParametersEPi
FMOD_RESULT_0 __fastcall FMOD::DSPI::getNumParameters(FMOD::DSPI *const this, int *numparams)
{
  FMOD_RESULT_0 result; // eax
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  int numparameters; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numparams )
  {
    mDescription = this->mDescription.mDescription;
    if ( mDescription )
      numparameters = mDescription->numparameters;
    else
      numparameters = 0;
    *numparams = numparameters;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21bc1f0 | Name: _ZN4FMOD4DSPI16getParameterInfoEiPP23FMOD_DSP_PARAMETER_DESC
FMOD_RESULT_0 __fastcall FMOD::DSPI::getParameterInfo(
        FMOD::DSPI *const this,
        int index,
        FMOD_DSP_PARAMETER_DESC **paramdesc)
{
  FMOD_RESULT_0 result; // eax
  const FMOD_DSP_DESCRIPTION *mDescription; // rcx
  FMOD_DSP_PARAMETER_DESC **v5; // rcx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index >= 0 )
  {
    mDescription = this->mDescription.mDescription;
    if ( mDescription )
    {
      if ( index < mDescription->numparameters && paramdesc )
      {
        v5 = mDescription->paramdesc;
        LOBYTE(result) = 53;
        if ( v5 )
        {
          *paramdesc = v5[index];
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x21bc230 | Name: _ZN4FMOD4DSPI21getDataParameterIndexEiPi
FMOD_RESULT_0 __fastcall FMOD::DSPI::getDataParameterIndex(FMOD::DSPI *const this, int datatype, int *index)
{
  const FMOD_DSP_DESCRIPTION *mDescription; // rdi
  __int64 v5; // rax
  int i; // r8d
  FMOD_DSP_PARAMETER_DESC *v7; // rcx

  mDescription = this->mDescription.mDescription;
  if ( mDescription )
  {
    v5 = 0;
    for ( i = 0; i < mDescription->numparameters; i = v5 )
    {
      v7 = mDescription->paramdesc[v5];
      if ( v7->type == FMOD_DSP_PARAMETER_TYPE_DATA && v7->intdesc.min == datatype )
      {
        if ( index )
          *index = i;
        return FMOD_RESULT::FMOD_OK_0;
      }
      ++v5;
    }
  }
  if ( index )
    *index = -1;
  return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21bc290 | Name: _ZN4FMOD4DSPI16showConfigDialogEPvb
FMOD_RESULT_0 __fastcall FMOD::DSPI::showConfigDialog(FMOD::DSPI *const this, void *hwnd, bool show)
{
  FMOD::FMOD_DSP_COMMAND_CALLBACK mCommand; // rax

  mCommand = this->mDescription.mCommand;
  if ( !mCommand || (this->mDescription.mCommandMask & 8) == 0 )
    return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  this->mState.instance = this;
  return mCommand(&this->mState, 8, hwnd, (void *)show);
}


// Address: 0x21bc2d0 | Name: _ZN4FMOD4DSPI7getInfoEPcPjPiS3_S3_
FMOD_RESULT_0 __fastcall FMOD::DSPI::getInfo(
        FMOD::DSPI *const this,
        char *name,
        unsigned int *version,
        int *channels,
        int *configwidth,
        int *configheight)
{
  const char *mName; // rsi
  const FMOD_DSP_DESCRIPTION *v13; // rax
  unsigned int v14; // eax
  int mChannels; // eax
  FMOD::FMOD_DSP_COMMAND_CALLBACK mCommand; // rax
  const FMOD_DSP_DESCRIPTION *mDescription; // rax

  if ( name )
  {
    mName = this->mDescription.mName;
    if ( !mName )
    {
      mDescription = this->mDescription.mDescription;
      mName = (const char *)&uri_string;
      if ( mDescription )
        mName = mDescription->name;
    }
    FMOD_strcpy_safe(name, mName, 32);
  }
  if ( version )
  {
    v13 = this->mDescription.mDescription;
    if ( v13 )
      v14 = v13->version;
    else
      v14 = 0;
    *version = v14;
  }
  if ( channels )
  {
    if ( this->mDescription.mDescription )
      mChannels = this->mDescription.mChannels;
    else
      mChannels = 0;
    *channels = mChannels;
  }
  if ( configwidth )
    *configwidth = 0;
  if ( configheight )
    *configheight = 0;
  mCommand = this->mDescription.mCommand;
  if ( mCommand && (this->mDescription.mCommandMask & 0x20) != 0 )
    return mCommand(&this->mState, 32, configwidth, configheight);
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21bc3e0 | Name: _ZN4FMOD4DSPI7getTypeEP13FMOD_DSP_TYPE
__int64 __fastcall FMOD::DSPI::getType(FMOD::DSPI *this, FMOD_DSP_TYPE *a2)
{
  __int64 result; // rax

  result = 31;
  if ( a2 )
  {
    *a2 = *((FMOD_DSP_TYPE *)&this->mDescription.mHandle + 1);
    return 0;
  }
  return result;
}


// Address: 0x21bc400 | Name: _ZN4FMOD4DSPI7getIdleEPb
FMOD_RESULT_0 __fastcall FMOD::DSPI::getIdle(FMOD::DSPI *const this, bool *idle)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( idle )
  {
    *idle = this->mMixerFlags & 1;
    *idle = *idle;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21bc420 | Name: _ZN4FMOD4DSPI27calculateInputChannelFormatEPiP16FMOD_SPEAKERMODEPNS_14DSPConnectionIE
FMOD_RESULT_0 __fastcall FMOD::DSPI::calculateInputChannelFormat(
        FMOD::DSPI *const this,
        int *numchannels_out,
        FMOD_SPEAKERMODE_0 *speakermode_out,
        FMOD::DSPConnectionI *sole_input_connection)
{
  int mNumSideChainInputs; // r8d
  int mChannels; // eax
  FMOD_SPEAKERMODE_0 source_speakermode; // ecx
  FMOD::DSPI *mInputUnit; // r8
  unsigned int mLastChannels; // ecx

  if ( sole_input_connection && (sole_input_connection->mFlags & 1) != 0 )
    mNumSideChainInputs = this->mNumSideChainInputs;
  else
    mNumSideChainInputs = this->mNumInputs - this->mNumSideChainInputs;
  mChannels = this->mDescription.mChannels;
  if ( (_WORD)mChannels )
  {
    source_speakermode = this->mState.source_speakermode;
    goto LABEL_6;
  }
  if ( this->mBuffer.mData )
  {
    mChannels = this->mBuffer.mChannels;
    source_speakermode = this->mBuffer.mSpeakerMode;
    goto LABEL_6;
  }
  if ( mNumSideChainInputs <= 1 )
  {
    if ( sole_input_connection )
    {
      mInputUnit = sole_input_connection->mInputUnit;
      if ( sole_input_connection->mMixMatrix.mData )
      {
        mChannels = sole_input_connection->mMixMatrix.mOutChannels;
        source_speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
        if ( mChannels )
          goto LABEL_6;
      }
      else
      {
        mChannels = mInputUnit->mBuffer.mChannels;
        if ( mChannels )
        {
          source_speakermode = mInputUnit->mBuffer.mSpeakerMode;
          goto LABEL_6;
        }
      }
    }
    mLastChannels = this->mLastChannels;
    mChannels = 1;
    if ( mLastChannels )
      mChannels = this->mLastChannels;
    source_speakermode = mLastChannels == 0
                       ? FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0
                       : FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
  }
  else
  {
    source_speakermode = *speakermode_out;
    if ( *speakermode_out == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
      source_speakermode = this->mSystem->mSpeakerMode;
    if ( source_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
    {
      mChannels = this->mSystem->mDSPMaxOutputChannels;
      goto LABEL_6;
    }
    if ( source_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    {
      mChannels = 5;
    }
    else if ( source_speakermode <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    {
      if ( source_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
        goto LABEL_24;
      mChannels = 4;
      if ( source_speakermode <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
      {
        LOBYTE(mChannels) = 1;
        if ( source_speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0 )
          goto LABEL_35;
      }
    }
    else
    {
      mChannels = 8;
      if ( source_speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
      {
        LOBYTE(mChannels) = 6;
        if ( source_speakermode >= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
        {
          LOBYTE(mChannels) = 12;
          if ( source_speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
          {
            if ( source_speakermode == 1000 )
            {
LABEL_24:
              mChannels = 2;
              goto LABEL_6;
            }
LABEL_35:
            mChannels = 0;
          }
        }
      }
    }
  }
LABEL_6:
  if ( numchannels_out )
    *numchannels_out = mChannels;
  if ( speakermode_out )
    *speakermode_out = source_speakermode;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21bc590 | Name: _ZN4FMOD4DSPI30getOutputChannelFormatInternalEi16FMOD_SPEAKERMODEPiPS1_P11FMOD_RESULT
FMOD_RESULT_0 __fastcall FMOD::DSPI::getOutputChannelFormatInternal(
        FMOD::DSPI *const this,
        int inchannels,
        FMOD_SPEAKERMODE_0 inspeakermode,
        int *outchannels,
        FMOD_SPEAKERMODE_0 *outspeakermode,
        FMOD_RESULT_0 *processresult)
{
  FMOD_DSP_PROCESS_CALLBACK mProcess; // rax
  _BOOL8 v10; // r8
  bool v11; // zf
  float mPreWet; // xmm0_4
  const FMOD_DSP_DESCRIPTION *v13; // rcx
  int numinputbuffers; // esi
  int numoutputbuffers; // ecx
  int v16; // eax
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  FMOD_SPEAKERMODE_0 inspeakermodea; // [rsp+8h] [rbp-A0h] BYREF
  int inchannelsa; // [rsp+Ch] [rbp-9Ch] BYREF
  int outchannels_result; // [rsp+14h] [rbp-94h] BYREF
  FMOD_CHANNELMASK inmask; // [rsp+18h] [rbp-90h] BYREF
  FMOD_CHANNELMASK outmask_result; // [rsp+1Ch] [rbp-8Ch] BYREF
  __int64 v24; // [rsp+20h] [rbp-88h] BYREF
  int *p_inchannelsa; // [rsp+28h] [rbp-80h]
  FMOD_CHANNELMASK *p_inmask; // [rsp+30h] [rbp-78h]
  __int64 v27; // [rsp+38h] [rbp-70h]
  __int64 outspeakermode_result; // [rsp+40h] [rbp-68h]
  FMOD_DSP_BUFFER_ARRAY out; // [rsp+50h] [rbp-58h] BYREF

  inchannelsa = inchannels;
  inspeakermodea = inspeakermode;
  if ( inspeakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 && !inchannels )
  {
    mDescription = this->mDescription.mDescription;
    if ( !mDescription
      || (inchannels = mDescription->numinputbuffers) != 0
      || mDescription->read
      || *(&this->mDescription.mHandle + 1) == 1001 )
    {
      FMOD::DSPI::calculateInputChannelFormat(this, &inchannelsa, &inspeakermodea, 0);
      inchannels = inchannelsa;
      inspeakermode = inspeakermodea;
    }
  }
  mProcess = this->mProcess;
  outchannels_result = inchannels;
  if ( !mProcess || (this->mJob.mFlags & 1) != 0 )
  {
    if ( processresult )
      *processresult = FMOD_RESULT::FMOD_ERR_DSP_DONTPROCESS_0;
  }
  else
  {
    v10 = 0;
    v11 = this->mBuffer.mData == 0;
    v24 = 0;
    p_inchannelsa = 0;
    p_inmask = 0;
    v27 = 0;
    outspeakermode_result = 0;
    memset(&out, 0, sizeof(out));
    if ( v11 )
      v10 = this->mSideChainBuffer.mData == 0;
    mPreWet = this->mPreWet;
    inmask = 0;
    outmask_result = 0;
    if ( fabs(mPreWet) < 0.000019999999 && mPreWet == this->mPreWetOld )
      v10 = 1;
    v13 = this->mDescription.mDescription;
    if ( v13 )
    {
      numinputbuffers = v13->numinputbuffers;
      numoutputbuffers = v13->numoutputbuffers;
      LODWORD(outspeakermode_result) = inspeakermode;
      LODWORD(v24) = numinputbuffers;
      p_inmask = &inmask;
      p_inchannelsa = &inchannelsa;
    }
    else
    {
      LODWORD(v24) = 1;
      LODWORD(outspeakermode_result) = inspeakermode;
      p_inmask = &inmask;
      p_inchannelsa = &inchannelsa;
      numoutputbuffers = 1;
    }
    out.numbuffers = numoutputbuffers;
    out.speakermode = inspeakermode;
    this->mState.instance = this;
    out.bufferchannelmask = &outmask_result;
    out.buffernumchannels = &outchannels_result;
    if ( processresult )
      *processresult = mProcess(
                         &this->mState,
                         this->mJob.mInfo.mMixLength,
                         (const FMOD_DSP_BUFFER_ARRAY *)&v24,
                         &out,
                         v10,
                         FMOD_DSP_PROCESS_QUERY);
    else
      mProcess(&this->mState, 0, (const FMOD_DSP_BUFFER_ARRAY *)&v24, &out, 0, FMOD_DSP_PROCESS_QUERY);
    v16 = 32;
    inspeakermode = out.speakermode;
    if ( outchannels_result <= 32 )
      v16 = outchannels_result;
    outchannels_result = v16;
  }
  if ( outchannels )
    *outchannels = outchannels_result;
  if ( outspeakermode )
    *outspeakermode = inspeakermode;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21bc830 | Name: _ZN4FMOD4DSPI22getOutputChannelFormatEji16FMOD_SPEAKERMODEPjPiPS1_
FMOD_RESULT_0 __fastcall FMOD::DSPI::getOutputChannelFormat(
        FMOD::DSPI *const this,
        FMOD_CHANNELMASK a2,
        int inchannels,
        FMOD_SPEAKERMODE_0 inspeakermode,
        FMOD_CHANNELMASK *outmask,
        int *outchannels,
        FMOD_SPEAKERMODE_0 *outspeakermode)
{
  bool v11; // zf
  FMOD_SPEAKERMODE_0 *v12; // r8

  v11 = outmask == 0;
  v12 = outspeakermode;
  if ( !v11 )
    *outmask = 0;
  if ( this->mDescription.mCommand && (this->mDescription.mCommandMask & 1) != 0 )
  {
    FMOD::SystemI::lockDSPInternal(this->mSystem);
    this->mState.instance = this;
    this->mDescription.mCommand(&this->mState, 1, 0, 0);
    FMOD::SystemI::unlockDSPInternal(this->mSystem);
    v12 = outspeakermode;
  }
  return FMOD::DSPI::getOutputChannelFormatInternal(this, inchannels, inspeakermode, outchannels, v12, 0);
}


// Address: 0x21bc8e0 | Name: _ZN4FMOD4DSPI12setWetDryMixEfff
__int64 __fastcall FMOD::DSPI::setWetDryMix(
        FMOD::DSPI *const this,
        float a2,
        __m128i prewet,
        __m128i postwet,
        float dry)
{
  __int64 result; // rax
  float v6; // xmm3_4

  result = 29;
  if ( (LODWORD(a2) & 0x7F800000) != 0x7F800000
    && (_mm_cvtsi128_si32(prewet) & 0x7F800000) != 0x7F800000
    && (_mm_cvtsi128_si32(postwet) & 0x7F800000) != 0x7F800000 )
  {
    if ( a2 >= 1.00001 || (v6 = 1.0, a2 <= 0.99998999) )
      v6 = a2;
    this->mPreWet = v6;
    if ( *(float *)prewet.m128i_i32 < 1.00001 && *(float *)prewet.m128i_i32 > 0.99998999 )
      prewet.m128i_i32[0] = 1065353216;
    LODWORD(this->mPostWet) = prewet.m128i_i32[0];
    if ( *(float *)postwet.m128i_i32 < 1.00001 && *(float *)postwet.m128i_i32 > 0.99998999 )
      postwet.m128i_i32[0] = 1065353216;
    LODWORD(this->mDry) = postwet.m128i_i32[0];
    return 0;
  }
  return result;
}


// Address: 0x21bc9c0 | Name: _ZN4FMOD4DSPI12getWetDryMixEPfS1_S1_
FMOD_RESULT_0 __fastcall FMOD::DSPI::getWetDryMix(FMOD::DSPI *const this, float *prewet, float *postwet, float *dry)
{
  if ( prewet )
    *prewet = this->mPreWet;
  if ( postwet )
    *postwet = this->mPostWet;
  if ( dry )
    *dry = this->mDry;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21bca00 | Name: _ZN4FMOD4DSPI8setPitchEfb
__int64 __fastcall FMOD::DSPI::setPitch(FMOD::DSPI *const this, float a2, float pitch, bool deferred)
{
  FMOD_RESULT_0 v4; // ebx
  float v7; // xmm0_4
  bool v8; // dl
  FMOD::DSPQueueCmd_SetPitch *v9; // rsi
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 v11; // eax
  FMOD::DSPQueueCmd_SetPitch *cmd; // [rsp+18h] [rbp-20h] BYREF

  if ( a2 > 256.0 || a2 < 0.0 )
    return 31;
  if ( deferred )
  {
    v4 = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 16, 1);
    if ( v4 == FMOD_RESULT::FMOD_OK_0 )
    {
      v9 = cmd;
      mSystem = this->mSystem;
      cmd->mPitch = a2;
      *(_BYTE *)&v9->FMOD::DSPQueueCmd = 19;
      v9->mThis = this;
      v11 = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v9, 1);
      if ( v11 )
        return (unsigned int)v11;
    }
    return (unsigned int)v4;
  }
  v7 = a2 * 1048576.0;
  v8 = this->mJob.mDelayClock.mPitch == 0;
  this->mJob.mDelayClock.mPitch = (int)v7;
  if ( v8 == ((int)v7 == 0) )
    return 0;
  *(_DWORD *)(*(unsigned __int64 *)((char *)&stru_10788.r_offset + (unsigned __int64)this->mSystem) + 48) = 1;
  return 0;
}


// Address: 0x21bcaf0 | Name: _ZN4FMOD4DSPI11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::DSPI::setUserData(FMOD::DSPI *const this, void *userdata)
{
  this->mUserData = userdata;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21bcb00 | Name: _ZN4FMOD4DSPI11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::DSPI::getUserData(FMOD::DSPI *const this, void **userdata)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( userdata )
  {
    *userdata = this->mUserData;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21bcb20 | Name: _ZN4FMOD4DSPI15getMeteringInfoEP22FMOD_DSP_METERING_INFOS2_
FMOD_RESULT_0 __fastcall FMOD::DSPI::getMeteringInfo(
        FMOD::DSPI *const this,
        FMOD_DSP_METERING_INFO_0 *inputInfo,
        FMOD_DSP_METERING_INFO_0 *outputInfo)
{
  FMOD::SystemI *mSystem; // rbx
  char v6; // r8
  FMOD::FMOD_DSP_PROFILE_CONTEXT *mProfileContext; // rax
  FMOD::FMOD_DSP_METERING_CONTEXT *p_mOutputMeter; // rdx
  FMOD::FMOD_DSP_PROFILE_CONTEXT *v9; // r9
  FMOD_RESULT_0 v10; // ebp
  FMOD_DSP_METERING_INFO_0 *v12; // rdi
  FMOD_DSP_METERING_INFO_0 *p_mCachedInfo; // rsi
  unsigned int v14; // eax
  __int64 v15; // rcx
  __int64 v16; // rcx
  int *v17; // rdi
  int *v18; // rsi
  FMOD_DSP_METERING_INFO_0 *v19; // rdi
  short *v20; // rsi
  unsigned int v21; // eax
  __int64 v22; // rdx
  __int64 v23; // rcx
  int *v24; // rdi
  int *v25; // rsi
  short v26; // dx
  int v27; // edx
  int v28; // ecx
  short numsamples; // cx

  mSystem = this->mSystem;
  if ( mSystem )
  {
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
    v6 = 1;
  }
  else
  {
    v6 = 0;
  }
  mProfileContext = this->mProfileContext;
  if ( mProfileContext )
  {
    p_mOutputMeter = &mProfileContext->mOutputMeter;
    v9 = 0;
    if ( mProfileContext->mInputMeter.mActive )
      v9 = this->mProfileContext;
    if ( !mProfileContext->mOutputMeter.mActive )
      p_mOutputMeter = 0;
  }
  else
  {
    v9 = 0;
    p_mOutputMeter = 0;
  }
  if ( inputInfo || (v10 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0, outputInfo) )
  {
    if ( v9 || (v10 = FMOD_RESULT::FMOD_ERR_BADCOMMAND_0, !inputInfo) )
    {
      if ( p_mOutputMeter || (v10 = FMOD_RESULT::FMOD_ERR_BADCOMMAND_0, !outputInfo) )
      {
        if ( inputInfo )
        {
          v12 = inputInfo;
          p_mCachedInfo = &v9->mInputMeter.mCachedInfo;
          v14 = 264;
          if ( ((unsigned __int8)inputInfo & 1) != 0 )
          {
            v12 = (FMOD_DSP_METERING_INFO_0 *)((char *)&inputInfo->numsamples + 1);
            p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)&v9->mInputMeter.mCachedInfo.numsamples + 1);
            LOBYTE(inputInfo->numsamples) = v9->mInputMeter.mCachedInfo.numsamples;
            v14 = 263;
          }
          if ( ((unsigned __int8)v12 & 2) != 0 )
          {
            numsamples = p_mCachedInfo->numsamples;
            v12 = (FMOD_DSP_METERING_INFO_0 *)((char *)v12 + 2);
            p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)p_mCachedInfo + 2);
            v14 -= 2;
            *(&v12[-1].numchannels + 1) = numsamples;
          }
          if ( ((unsigned __int8)v12 & 4) != 0 )
          {
            v28 = p_mCachedInfo->numsamples;
            v12 = (FMOD_DSP_METERING_INFO_0 *)((char *)v12 + 4);
            p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)p_mCachedInfo + 4);
            v14 -= 4;
            *(_DWORD *)&v12[-1].numchannels = v28;
          }
          v15 = v14 >> 3;
          qmemcpy(v12, p_mCachedInfo, 8 * v15);
          v18 = &p_mCachedInfo->numsamples + 2 * v15;
          v17 = &v12->numsamples + 2 * v15;
          v16 = 0;
          if ( (v14 & 4) != 0 )
          {
            *v17 = *v18;
            v16 = 4;
          }
          if ( (v14 & 2) != 0 )
          {
            *(_WORD *)((char *)v17 + v16) = *(_WORD *)((char *)v18 + v16);
            v16 += 2;
          }
          if ( (v14 & 1) != 0 )
            *((_BYTE *)v17 + v16) = *((_BYTE *)v18 + v16);
        }
        v10 = FMOD_RESULT::FMOD_OK_0;
        if ( outputInfo )
        {
          v19 = outputInfo;
          v20 = (short *)&p_mOutputMeter->mCachedInfo;
          v21 = 264;
          if ( ((unsigned __int8)outputInfo & 1) != 0 )
          {
            v19 = (FMOD_DSP_METERING_INFO_0 *)((char *)&outputInfo->numsamples + 1);
            v20 = (short *)((char *)&p_mOutputMeter->mCachedInfo.numsamples + 1);
            LOBYTE(outputInfo->numsamples) = p_mOutputMeter->mCachedInfo.numsamples;
            v21 = 263;
          }
          if ( ((unsigned __int8)v19 & 2) != 0 )
          {
            v26 = *v20;
            v19 = (FMOD_DSP_METERING_INFO_0 *)((char *)v19 + 2);
            ++v20;
            v21 -= 2;
            *(&v19[-1].numchannels + 1) = v26;
          }
          if ( ((unsigned __int8)v19 & 4) != 0 )
          {
            v27 = *(_DWORD *)v20;
            v19 = (FMOD_DSP_METERING_INFO_0 *)((char *)v19 + 4);
            v20 += 2;
            v21 -= 4;
            *(_DWORD *)&v19[-1].numchannels = v27;
          }
          v22 = 0;
          v23 = v21 >> 3;
          qmemcpy(v19, v20, 8 * v23);
          v25 = (int *)&v20[4 * v23];
          v24 = &v19->numsamples + 2 * v23;
          if ( (v21 & 4) != 0 )
          {
            *v24 = *v25;
            v22 = 4;
          }
          if ( (v21 & 2) != 0 )
          {
            *(_WORD *)((char *)v24 + v22) = *(_WORD *)((char *)v25 + v22);
            v22 += 2;
          }
          v10 = FMOD_RESULT::FMOD_OK_0;
          if ( (v21 & 1) != 0 )
            *((_BYTE *)v24 + v22) = *((_BYTE *)v25 + v22);
        }
      }
    }
  }
  if ( !v6 || !mSystem )
    return v10;
  FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
  return v10;
}


// Address: 0x21bcdd0 | Name: _ZN4FMOD4DSPI18getMeteringEnabledEPbS1_
FMOD_RESULT_0 __fastcall FMOD::DSPI::getMeteringEnabled(
        FMOD::DSPI *const this,
        bool *inputEnabled,
        bool *outputEnabled)
{
  FMOD::SystemI *mSystem; // rbx
  char v5; // al
  FMOD_RESULT_0 v6; // r14d
  bool v7; // cl
  FMOD::FMOD_DSP_PROFILE_CONTEXT *mProfileContext; // rdx
  bool mActive; // dl
  FMOD::FMOD_DSP_PROFILE_CONTEXT *v11; // rdx

  mSystem = this->mSystem;
  if ( mSystem )
  {
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
    v5 = 1;
  }
  else
  {
    v5 = 0;
  }
  v6 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v7 = inputEnabled == 0 && outputEnabled == 0;
  if ( !v7 )
  {
    if ( inputEnabled )
    {
      mProfileContext = this->mProfileContext;
      if ( mProfileContext )
        mActive = mProfileContext->mInputMeter.mActive;
      else
        mActive = 0;
      *inputEnabled = mActive;
    }
    if ( outputEnabled )
    {
      v11 = this->mProfileContext;
      if ( v11 )
        v7 = v11->mOutputMeter.mActive;
      *outputEnabled = v7;
      v6 = FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      v6 = FMOD_RESULT::FMOD_OK_0;
    }
  }
  if ( !v5 || !mSystem )
    return v6;
  FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
  return v6;
}


// Address: 0x21bcec0 | Name: FMOD::FMOD_UpdateMeteringInfo_NoOpt
void __fastcall FMOD::FMOD_UpdateMeteringInfo_NoOpt(
        const float *buffer,
        int length,
        int channels,
        float *peaks,
        float *accumulatedSquares)
{
  int v5; // esi
  unsigned int v6; // r9d
  unsigned int v7; // eax
  __int64 v8; // r10
  float v9; // xmm1_4
  __int64 v10; // r10
  float *v11; // r11
  float *v12; // r10
  float v13; // xmm2_4
  float v14; // xmm1_4
  float v15; // xmm1_4
  float v16; // xmm2_4
  int v17; // edx
  const float *v18; // rax
  float v19; // xmm3_4
  float v20; // xmm5_4
  float v21; // xmm4_4
  float v22; // xmm1_4
  float v23; // xmm4_4
  float v24; // xmm3_4
  float v25; // xmm2_4
  float v26; // xmm7_4
  int i; // esi
  float v28; // xmm7_4
  float v29; // xmm2_4
  float v30; // xmm1_4
  float v31; // xmm4_4
  float v32; // xmm3_4
  int v33; // edx
  const float *v34; // rax
  float v35; // xmm6_4
  float v36; // xmm7_4
  float v37; // xmm6_4
  float v38; // xmm4_4
  float v39; // xmm2_4
  float v40; // xmm7_4
  float v41; // xmm5_4
  float v42; // xmm1_4
  float v43; // xmm8_4
  float v44; // xmm7_4
  float v45; // xmm4_4
  float v46; // xmm2_4
  float v47; // xmm7_4
  float v48; // xmm5_4
  float v49; // xmm3_4
  float v50; // xmm1_4
  float v51; // xmm5_4
  float v52; // xmm6_4
  float v53; // xmm4_4
  float v54; // xmm7_4
  float v55; // xmm7_4
  int j; // esi
  float v57; // xmm6_4
  float v58; // xmm7_4
  float v59; // xmm7_4
  const float *v60; // rax
  float v61; // xmm12_4
  float v62; // xmm11_4
  float v63; // xmm10_4
  float v64; // xmm9_4
  float v65; // xmm8_4
  float v66; // xmm7_4
  float v67; // xmm13_4
  float v68; // xmm14_4
  float v69; // xmm15_4
  float v70; // xmm6_4
  float v71; // xmm6_4
  float v72; // xmm5_4
  float v73; // xmm4_4
  float v74; // xmm7_4
  float v75; // xmm3_4
  float v76; // xmm6_4
  float v77; // xmm2_4
  float v78; // xmm1_4
  float v79; // xmm7_4
  float v80; // xmm2_4
  float v81; // xmm1_4
  float v82; // xmm15_4
  float v83; // xmm14_4
  float v84; // xmm13_4
  float v85; // xmm12_4
  float v86; // xmm11_4
  float v87; // xmm10_4
  float v88; // xmm9_4
  float v89; // xmm8_4
  float v90; // xmm8_4
  float v91; // xmm7_4
  float v92; // xmm6_4
  float v93; // xmm5_4
  float v94; // xmm4_4
  float v95; // xmm3_4
  float v96; // xmm1_4
  float v97; // xmm2_4
  float v98; // xmm8_4
  float v99; // xmm7_4
  float v100; // xmm1_4
  float v101; // xmm6_4
  float v102; // xmm1_4
  float v103; // xmm5_4
  float v104; // xmm1_4
  float v105; // xmm3_4
  float v106; // xmm1_4
  float v107; // xmm2_4
  float v108; // xmm1_4
  float absvalue_7; // [rsp+0h] [rbp-28h]
  float absvalue_7a; // [rsp+0h] [rbp-28h]
  float v111; // [rsp+4h] [rbp-24h]
  float v112; // [rsp+4h] [rbp-24h]
  float v113; // [rsp+8h] [rbp-20h]
  float v114; // [rsp+8h] [rbp-20h]
  float v115; // [rsp+Ch] [rbp-1Ch]
  float v116; // [rsp+Ch] [rbp-1Ch]
  float v117; // [rsp+10h] [rbp-18h]
  float v118; // [rsp+14h] [rbp-14h]
  float v119; // [rsp+18h] [rbp-10h]
  float v120; // [rsp+1Ch] [rbp-Ch]
  float v121; // [rsp+20h] [rbp-8h]
  float v122; // [rsp+24h] [rbp-4h]

  switch ( channels )
  {
    case 1:
      v15 = *peaks;
      v16 = *accumulatedSquares;
      if ( length >> 2 )
      {
        v17 = length >> 2;
        v18 = buffer;
        do
        {
          v19 = *v18;
          v18 += 4;
          v20 = fabs(v19);
          v21 = fabs(*(v18 - 3));
          v22 = fmaxf(v21, fmaxf(v20, v15));
          v23 = (float)(v21 * v21) + (float)((float)(v20 * v20) + v16);
          v24 = fabs(*(v18 - 2));
          --v17;
          v25 = fabs(*(v18 - 1));
          v26 = fmaxf(v25, fmaxf(v24, v22));
          v16 = (float)(v25 * v25) + (float)((float)(v24 * v24) + v23);
          v15 = v26;
        }
        while ( v17 );
        buffer += 4 * (unsigned int)((length >> 2) - 1) + 4;
      }
      for ( i = length & 3; i; v15 = fmaxf(v28, v15) )
      {
        ++buffer;
        --i;
        v28 = fabs(*(buffer - 1));
        v16 = v16 + (float)(v28 * v28);
      }
      *accumulatedSquares = v16;
      *peaks = v15;
      break;
    case 2:
      v29 = *peaks;
      v30 = peaks[1];
      v31 = *accumulatedSquares;
      v32 = accumulatedSquares[1];
      if ( length >> 2 )
      {
        v33 = length >> 2;
        v34 = buffer;
        do
        {
          v35 = *v34;
          v34 += 8;
          v36 = fabs(v35);
          v37 = (float)(v36 * v36) + v31;
          v38 = fabs(*(v34 - 6));
          v39 = fmaxf(v36, v29);
          v40 = fabs(*(v34 - 7));
          v41 = (float)(v40 * v40) + v32;
          v42 = fmaxf(v40, v30);
          v43 = (float)(v38 * v38) + v37;
          v44 = fmaxf(v38, v39);
          v45 = fabs(*(v34 - 4));
          v46 = fmaxf(v45, v44);
          v47 = (float)(fabs(*(v34 - 5)) * fabs(*(v34 - 5))) + v41;
          v48 = fabs(*(v34 - 3));
          v49 = fabs(*(v34 - 1));
          v50 = fmaxf(v48, fmaxf(fabs(*(v34 - 5)), v42));
          v51 = (float)(v48 * v48) + v47;
          v52 = v45 * v45;
          v53 = fabs(*(v34 - 2));
          --v33;
          v54 = fmaxf(v53, v46);
          v31 = (float)(v53 * v53) + (float)(v52 + v43);
          v29 = v54;
          v55 = fmaxf(v49, v50);
          v32 = (float)(v49 * v49) + v51;
          v30 = v55;
        }
        while ( v33 );
        buffer += 8 * (unsigned int)((length >> 2) - 1) + 8;
      }
      for ( j = length & 3; j; v30 = fmaxf(v59, v30) )
      {
        v57 = *buffer;
        buffer += 2;
        --j;
        v58 = fabs(v57);
        v31 = v31 + (float)(v58 * v58);
        v29 = fmaxf(v58, v29);
        v59 = fabs(*(buffer - 1));
        v32 = v32 + (float)(v59 * v59);
      }
      *peaks = v29;
      peaks[1] = v30;
      *accumulatedSquares = v31;
      accumulatedSquares[1] = v32;
      break;
    case 6:
      if ( length )
      {
        absvalue_7 = *accumulatedSquares;
        v111 = accumulatedSquares[4];
        v60 = &buffer[6 * (length - 1) + 6];
        v113 = accumulatedSquares[5];
        v61 = *peaks;
        v62 = peaks[1];
        v63 = peaks[2];
        v64 = peaks[3];
        v65 = peaks[4];
        v66 = peaks[5];
        v67 = accumulatedSquares[1];
        v68 = accumulatedSquares[2];
        v69 = accumulatedSquares[3];
        do
        {
          v70 = *buffer;
          buffer += 6;
          v71 = fabs(v70);
          v115 = v66;
          v72 = fabs(*(buffer - 5));
          v73 = fabs(*(buffer - 4));
          v74 = fmaxf(v71, v61);
          v75 = fabs(*(buffer - 3));
          v76 = (float)(v71 * v71) + absvalue_7;
          v77 = fabs(*(buffer - 2));
          v61 = v74;
          v78 = fabs(*(buffer - 1));
          absvalue_7 = v76;
          v67 = v67 + (float)(v72 * v72);
          v62 = fmaxf(v72, v62);
          v68 = v68 + (float)(v73 * v73);
          v63 = fmaxf(v73, v63);
          v69 = v69 + (float)(v75 * v75);
          v64 = fmaxf(v75, v64);
          v79 = fmaxf(v77, v65);
          v80 = (float)(v77 * v77) + v111;
          v65 = v79;
          v66 = fmaxf(v78, v115);
          v111 = v80;
          v81 = (float)(v78 * v78) + v113;
          v113 = v81;
        }
        while ( buffer != v60 );
        *peaks = v61;
        peaks[1] = v62;
        peaks[2] = v63;
        peaks[3] = v64;
        peaks[4] = v65;
        peaks[5] = v66;
        *accumulatedSquares = v76;
        accumulatedSquares[1] = v67;
        accumulatedSquares[2] = v68;
        accumulatedSquares[3] = v69;
        accumulatedSquares[4] = v80;
        accumulatedSquares[5] = v81;
      }
      break;
    case 8:
      if ( length )
      {
        v122 = peaks[7];
        v112 = *accumulatedSquares;
        v114 = accumulatedSquares[1];
        v116 = accumulatedSquares[2];
        v117 = accumulatedSquares[3];
        v118 = accumulatedSquares[4];
        v119 = accumulatedSquares[5];
        v120 = accumulatedSquares[6];
        v121 = accumulatedSquares[7];
        v82 = *peaks;
        v83 = peaks[1];
        v84 = peaks[2];
        v85 = peaks[3];
        v86 = peaks[4];
        v87 = peaks[5];
        v88 = peaks[6];
        do
        {
          v89 = *buffer;
          buffer += 8;
          v90 = fabs(v89);
          v91 = fabs(*(buffer - 7));
          absvalue_7a = fabs(*(buffer - 1));
          v92 = fabs(*(buffer - 6));
          v93 = fabs(*(buffer - 5));
          v94 = fabs(*(buffer - 4));
          v82 = fmaxf(v90, v82);
          v95 = fabs(*(buffer - 3));
          v96 = fmaxf(v91, v83);
          v97 = fabs(*(buffer - 2));
          v98 = (float)(v90 * v90) + v112;
          --length;
          v99 = (float)(v91 * v91) + v114;
          v83 = v96;
          v100 = fmaxf(v92, v84);
          v112 = v98;
          v101 = (float)(v92 * v92) + v116;
          v114 = v99;
          v84 = v100;
          v102 = fmaxf(v93, v85);
          v103 = (float)(v93 * v93) + v117;
          v116 = v101;
          v85 = v102;
          v117 = v103;
          v86 = fmaxf(v94, v86);
          v104 = fmaxf(v95, v87);
          v118 = (float)(v94 * v94) + v118;
          v105 = (float)(v95 * v95) + v119;
          v87 = v104;
          v106 = fmaxf(v97, v88);
          v107 = (float)(v97 * v97) + v120;
          v119 = v105;
          v88 = v106;
          v120 = v107;
          v122 = fmaxf(absvalue_7a, v122);
          v108 = (float)(absvalue_7a * absvalue_7a) + v121;
          v121 = v108;
        }
        while ( length );
        accumulatedSquares[4] = v118;
        *peaks = v82;
        peaks[1] = v83;
        peaks[2] = v84;
        peaks[3] = v85;
        peaks[4] = v86;
        peaks[5] = v87;
        *accumulatedSquares = v98;
        accumulatedSquares[1] = v99;
        accumulatedSquares[2] = v101;
        accumulatedSquares[3] = v103;
        accumulatedSquares[5] = v105;
        peaks[6] = v88;
        peaks[7] = v122;
        accumulatedSquares[6] = v107;
        accumulatedSquares[7] = v108;
      }
      break;
    default:
      v5 = channels * length;
      if ( v5 )
      {
        v6 = 0;
        v7 = 0;
        do
        {
          v8 = v6++;
          v9 = fabs(buffer[v8]);
          v10 = v7;
          v11 = &peaks[v10];
          v12 = &accumulatedSquares[v10];
          v13 = fmaxf(v9, *v11);
          v14 = (float)(v9 * v9) + *v12;
          *v11 = v13;
          *v12 = v14;
          v7 = (v7 + 1) & ((int)(v7 + 1 - channels) >> 31);
        }
        while ( v5 != v6 );
      }
      break;
  }
}


// Address: 0x21bd5d0 | Name: _ZN4FMOD4DSPI25cacheAndResetMeteringInfoEPNS_25FMOD_DSP_METERING_CONTEXTEi
FMOD_RESULT_0 __fastcall FMOD::DSPI::cacheAndResetMeteringInfo(
        FMOD::FMOD_DSP_METERING_CONTEXT *context,
        int currentDSPTick)
{
  FMOD_DSP_METERING_INFO_0 *p_mCachedInfo; // rdi
  unsigned int v4; // edx
  __int64 v5; // rcx
  int *v6; // rdi
  int mSampleCount; // r13d
  float *peaklevel; // rbx
  float *mPeaks; // rbp
  int v10; // r12d
  float v11; // xmm0_4
  float v12; // xmm1_4
  float *v13; // rdi
  unsigned int v14; // edx
  __int64 v15; // rcx
  float *v16; // rdi
  FMOD::FMOD_DSP_METERING_CONTEXT *v17; // rdi
  unsigned int v18; // edx
  __int64 v19; // rcx
  _DWORD *v20; // rdi
  unsigned int v22; // edx
  __int64 v23; // rcx
  int *v24; // rdi

  p_mCachedInfo = &context->mCachedInfo;
  if ( context->mLastDSPTick + 2 < currentDSPTick )
  {
    v22 = 264;
    if ( ((unsigned __int8)p_mCachedInfo & 1) != 0 )
    {
      LOBYTE(context->mCachedInfo.numsamples) = 0;
      p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)&context->mCachedInfo.numsamples + 1);
      LOBYTE(v22) = 7;
    }
    if ( ((unsigned __int8)p_mCachedInfo & 2) != 0 )
    {
      p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)p_mCachedInfo + 2);
      v22 -= 2;
      *(&p_mCachedInfo[-1].numchannels + 1) = 0;
    }
    if ( ((unsigned __int8)p_mCachedInfo & 4) != 0 )
    {
      p_mCachedInfo->numsamples = 0;
      v22 -= 4;
      p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)p_mCachedInfo + 4);
    }
    v23 = v22 >> 3;
    memset(p_mCachedInfo, 0, 8 * v23);
    v24 = &p_mCachedInfo->numsamples + 2 * v23;
    if ( (v22 & 4) != 0 )
    {
      *v24++ = 0;
      if ( (v22 & 2) == 0 )
      {
LABEL_60:
        if ( (v22 & 1) == 0 )
          return FMOD_RESULT::FMOD_OK_0;
LABEL_61:
        *(_BYTE *)v24 = 0;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
    else if ( (v22 & 2) == 0 )
    {
      goto LABEL_60;
    }
    v24 = (int *)((char *)v24 + 2);
    *((_WORD *)v24 - 1) = 0;
    if ( (v22 & 1) == 0 )
      return FMOD_RESULT::FMOD_OK_0;
    goto LABEL_61;
  }
  if ( context->mSampleCount > 0 )
  {
    v4 = 264;
    if ( ((unsigned __int8)p_mCachedInfo & 1) != 0 )
    {
      LOBYTE(context->mCachedInfo.numsamples) = 0;
      p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)&context->mCachedInfo.numsamples + 1);
      LOBYTE(v4) = 7;
    }
    if ( ((unsigned __int8)p_mCachedInfo & 2) != 0 )
    {
      p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)p_mCachedInfo + 2);
      v4 -= 2;
      *(&p_mCachedInfo[-1].numchannels + 1) = 0;
    }
    if ( ((unsigned __int8)p_mCachedInfo & 4) != 0 )
    {
      p_mCachedInfo->numsamples = 0;
      v4 -= 4;
      p_mCachedInfo = (FMOD_DSP_METERING_INFO_0 *)((char *)p_mCachedInfo + 4);
    }
    v5 = v4 >> 3;
    memset(p_mCachedInfo, 0, 8 * v5);
    v6 = &p_mCachedInfo->numsamples + 2 * v5;
    if ( (v4 & 4) != 0 )
    {
      *v6++ = 0;
      if ( (v4 & 2) == 0 )
      {
LABEL_11:
        if ( (v4 & 1) == 0 )
        {
LABEL_12:
          mSampleCount = context->mSampleCount;
          peaklevel = context->mCachedInfo.peaklevel;
          context->mSampleCount = 0;
          mPeaks = context->mPeaks;
          v10 = 32;
          context->mCachedInfo.numsamples = mSampleCount;
          do
          {
            *peaklevel = *mPeaks;
            v11 = 0.0;
            if ( mSampleCount > 0 )
            {
              v11 = 0.0;
              v12 = *(mPeaks - 32) / (float)mSampleCount;
              if ( v12 > 0.0 )
                v11 = fsqrt(v12);
            }
            peaklevel[32] = v11;
            ++mPeaks;
            ++peaklevel;
            --v10;
          }
          while ( v10 );
          v13 = context->mPeaks;
          v14 = 128;
          if ( (((_BYTE)context + 0x80) & 1) != 0 )
          {
            LOBYTE(context->mPeaks[0]) = 0;
            v13 = (float *)((char *)context->mPeaks + 1);
            LOBYTE(v14) = 127;
          }
          if ( ((unsigned __int8)v13 & 2) != 0 )
          {
            v13 = (float *)((char *)v13 + 2);
            v14 -= 2;
            *((_WORD *)v13 - 1) = 0;
          }
          if ( ((unsigned __int8)v13 & 4) != 0 )
          {
            *v13 = 0.0;
            v14 -= 4;
            ++v13;
          }
          v15 = v14 >> 3;
          memset(v13, 0, 8 * v15);
          v16 = &v13[2 * v15];
          if ( (v14 & 4) != 0 )
          {
            *v16++ = 0.0;
            if ( (v14 & 2) == 0 )
            {
LABEL_25:
              if ( (v14 & 1) == 0 )
                goto LABEL_26;
              goto LABEL_41;
            }
          }
          else if ( (v14 & 2) == 0 )
          {
            goto LABEL_25;
          }
          v16 = (float *)((char *)v16 + 2);
          *((_WORD *)v16 - 1) = 0;
          if ( (v14 & 1) == 0 )
          {
LABEL_26:
            v17 = context;
            v18 = 128;
            if ( ((unsigned __int8)context & 1) == 0 )
              goto LABEL_27;
LABEL_66:
            LOBYTE(context->mAccumulatedSquares[0]) = 0;
            v17 = (FMOD::FMOD_DSP_METERING_CONTEXT *)((char *)context->mAccumulatedSquares + 1);
            LOBYTE(v18) = 127;
LABEL_27:
            if ( ((unsigned __int8)v17 & 2) != 0 )
            {
              v17 = (FMOD::FMOD_DSP_METERING_CONTEXT *)((char *)v17 + 2);
              v18 -= 2;
              *(_WORD *)&v17[-1].mActive = 0;
            }
            if ( ((unsigned __int8)v17 & 4) != 0 )
            {
              v17->mAccumulatedSquares[0] = 0.0;
              v18 -= 4;
              v17 = (FMOD::FMOD_DSP_METERING_CONTEXT *)((char *)v17 + 4);
            }
            v19 = v18 >> 3;
            memset(v17, 0, 8 * v19);
            v20 = (_DWORD *)&v17->mAccumulatedSquares[2 * v19];
            if ( (v18 & 4) != 0 )
            {
              *v20++ = 0;
              if ( (v18 & 2) == 0 )
              {
LABEL_33:
                if ( (v18 & 1) == 0 )
                {
LABEL_34:
                  context->mCachedInfo.numchannels = context->mNumChannels;
                  return FMOD_RESULT::FMOD_OK_0;
                }
LABEL_36:
                *(_BYTE *)v20 = 0;
                goto LABEL_34;
              }
            }
            else if ( (v18 & 2) == 0 )
            {
              goto LABEL_33;
            }
            v20 = (_DWORD *)((char *)v20 + 2);
            *((_WORD *)v20 - 1) = 0;
            if ( (v18 & 1) == 0 )
              goto LABEL_34;
            goto LABEL_36;
          }
LABEL_41:
          *(_BYTE *)v16 = 0;
          v18 = 128;
          v17 = context;
          if ( ((unsigned __int8)context & 1) == 0 )
            goto LABEL_27;
          goto LABEL_66;
        }
LABEL_47:
        *(_BYTE *)v6 = 0;
        goto LABEL_12;
      }
    }
    else if ( (v4 & 2) == 0 )
    {
      goto LABEL_11;
    }
    v6 = (int *)((char *)v6 + 2);
    *((_WORD *)v6 - 1) = 0;
    if ( (v4 & 1) == 0 )
      goto LABEL_12;
    goto LABEL_47;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21bd9c0 | Name: _ZN4FMOD4DSPI18updateMeteringInfoEPKfjjPNS_25FMOD_DSP_METERING_CONTEXTE
FMOD_RESULT_0 __fastcall FMOD::DSPI::updateMeteringInfo(
        FMOD::DSPI *const this,
        const float *buffer,
        unsigned int length,
        unsigned int numchannels,
        FMOD::FMOD_DSP_METERING_CONTEXT *context)
{
  FMOD::FMOD_DSP_METERING_CONTEXT *v8; // rax

  if ( context )
  {
    context->mNumChannels = numchannels;
    context->mLastDSPTick = this->mJob.mTick;
    if ( buffer )
    {
      ((void (__fastcall *)(const float *, _QWORD, _QWORD, float *))FMOD_Optimised_Routines.UpdateMeteringInfo)(
        buffer,
        length,
        numchannels,
        context->mPeaks);
    }
    else if ( numchannels )
    {
      v8 = context;
      do
      {
        v8->mAccumulatedSquares[0] = 0.0;
        v8->mPeaks[0] = 0.0;
        v8 = (FMOD::FMOD_DSP_METERING_CONTEXT *)((char *)v8 + 4);
      }
      while ( v8 != (FMOD::FMOD_DSP_METERING_CONTEXT *)&context->mAccumulatedSquares[numchannels] );
    }
    context->mSampleCount += length;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21bda50 | Name: _ZN4FMOD4DSPI6runJobEj16FMOD_SPEAKERMODEj
FMOD_RESULT_0 __fastcall FMOD::DSPI::runJob(
        FMOD::DSPI *const this,
        unsigned int origlength,
        FMOD_SPEAKERMODE_0 mixer_speakermode,
        unsigned int mixer_speakermodechannels)
{
  float v4; // xmm1_4
  FMOD_SPEAKERMODE_0 mSpeakerMode; // edx
  int mChannels; // esi
  FMOD::FMOD_DSP_PROFILE_CONTEXT *mProfileContext; // rax
  FMOD_RESULT_0 v9; // ebx
  FMOD::SystemI *mSystem; // r12
  char v11; // r15
  FMOD::FMOD_DSP_METERING_CONTEXT *p_mInputMeter; // r13
  FMOD::DSPBuffer *p_mBuffer; // rdi
  unsigned int v14; // r14d
  float *v15; // rax
  FMOD_RESULT_0 updated; // r13d
  FMOD_RESULT_0 result; // eax
  bool v18; // r13
  FMOD::FMOD_DSP_PROFILE_CONTEXT *v19; // rax
  FMOD::SystemI *v20; // rbx
  char v21; // r13
  FMOD::FMOD_DSP_METERING_CONTEXT *p_mOutputMeter; // r14
  unsigned int v23; // r12d
  float *v24; // rax
  FMOD_RESULT_0 v25; // r12d
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  int numinputbuffers; // ebx
  FMOD_RESULT_0 v28; // eax
  FMOD_DSP_PROCESS_CALLBACK mProcess; // rax
  int v30; // edx
  int v31; // edx
  FMOD_RESULT_0 v32; // eax
  const FMOD_DSP_DESCRIPTION *v33; // rax
  unsigned __int16 mMixOffset; // cx
  int v35; // ebx
  __int64 v36; // r14
  FMOD::SystemI *v37; // rsi
  float *v38; // r14
  float *v39; // rax
  float mDry; // xmm1_4
  FMOD::DSPBuffer *p_drybuff; // rbx
  FMOD::SystemI *v42; // rsi
  int v43; // r9d
  int v44; // r14d
  float *v45; // rbx
  float *v46; // rax
  FMOD::DSPI *mNodeNext; // rax
  __int64 v48; // r12
  FMOD::DSPI *v49; // rdi
  int writedontmix; // r15d
  int v51; // r8d
  bool v52; // cl
  float *v53; // r13
  float *v54; // rax
  FMOD_CLOCKTIME mClockNext; // r14
  __int64 v56; // rbx
  unsigned int v57; // r12d
  float *v58; // rax
  int v59; // r13d
  float *v60; // rax
  unsigned int v61; // r13d
  float *v62; // rax
  FMOD::SystemI *v63; // rsi
  int v64; // r12d
  float *v65; // r14
  float *v66; // rax
  unsigned int v67; // eax
  float v68; // xmm1_4
  float v69; // xmm0_4
  bool v70; // zf
  int v71; // r8d
  float mPreWet; // xmm0_4
  float *v73; // r14
  float *v74; // rax
  size_t v75; // r14
  float *v76; // rax
  float *v77; // rax
  int v78; // edx
  FMOD_RESULT_0 v79; // r12d
  int offset; // [rsp+18h] [rbp-250h]
  int offseta; // [rsp+18h] [rbp-250h]
  float *offsetb; // [rsp+18h] [rbp-250h]
  FMOD::DSPBuffer *outputhead; // [rsp+20h] [rbp-248h]
  unsigned int len; // [rsp+28h] [rbp-240h]
  FMOD_RESULT_0 lena; // [rsp+28h] [rbp-240h]
  FMOD::DSPBuffer *v87; // [rsp+30h] [rbp-238h]
  int inchannelsa; // [rsp+40h] [rbp-228h]
  int inchannelsb; // [rsp+40h] [rbp-228h]
  int inchannelsc; // [rsp+40h] [rbp-228h]
  unsigned __int16 inchannels; // [rsp+40h] [rbp-228h]
  int v92; // [rsp+48h] [rbp-220h]
  bool directmapping; // [rsp+54h] [rbp-214h]
  FMOD::DSPBuffer *v95; // [rsp+58h] [rbp-210h]
  FMOD_RESULT_0 processresult; // [rsp+64h] [rbp-204h] BYREF
  int outchannels; // [rsp+68h] [rbp-200h] BYREF
  FMOD_SPEAKERMODE_0 outmode; // [rsp+6Ch] [rbp-1FCh] BYREF
  FMOD_CHANNELMASK inmask; // [rsp+70h] [rbp-1F8h] BYREF
  FMOD_CHANNELMASK outmask; // [rsp+74h] [rbp-1F4h] BYREF
  int innumchannels; // [rsp+78h] [rbp-1F0h] BYREF
  int outnumchannels; // [rsp+7Ch] [rbp-1ECh] BYREF
  float *src; // [rsp+80h] [rbp-1E8h] BYREF
  float *dest; // [rsp+88h] [rbp-1E0h] BYREF
  FMOD::DSPBuffer destbuff; // [rsp+90h] [rbp-1D8h] BYREF
  FMOD::DSPBuffer drybuff; // [rsp+B0h] [rbp-1B8h] BYREF
  FMOD_DSP_BUFFER_ARRAY in; // [rsp+D0h] [rbp-198h] BYREF
  FMOD_SPEAKERMODE_0 output_mode; // [rsp+100h] [rbp-168h] BYREF
  int *p_outnumchannels; // [rsp+108h] [rbp-160h]
  FMOD_CHANNELMASK *p_outmask; // [rsp+110h] [rbp-158h]
  float **p_dest; // [rsp+118h] [rbp-150h]
  FMOD_SPEAKERMODE_0 v112; // [rsp+120h] [rbp-148h]
  __int64 output_channels; // [rsp+130h] [rbp-138h] BYREF
  __int64 v114; // [rsp+138h] [rbp-130h] BYREF
  __int64 *v115; // [rsp+140h] [rbp-128h]
  __int64 v116; // [rsp+148h] [rbp-120h]
  __int64 v117; // [rsp+150h] [rbp-118h] BYREF
  __int64 *v118; // [rsp+158h] [rbp-110h]
  __int64 v119; // [rsp+160h] [rbp-108h]
  __int16 v120; // [rsp+168h] [rbp-100h]
  __int16 v121; // [rsp+16Ah] [rbp-FEh]
  __int64 v122; // [rsp+170h] [rbp-F8h]
  __int16 v123; // [rsp+178h] [rbp-F0h]
  __int16 v124; // [rsp+17Ah] [rbp-EEh]
  __int64 v125; // [rsp+180h] [rbp-E8h]
  __int64 v126; // [rsp+188h] [rbp-E0h]
  __int64 v127; // [rsp+190h] [rbp-D8h]
  float mPostWet; // [rsp+198h] [rbp-D0h]
  int v129; // [rsp+1B4h] [rbp-B4h]
  __int16 v130; // [rsp+1C8h] [rbp-A0h]
  __int16 v131; // [rsp+1CAh] [rbp-9Eh]
  __int64 v132; // [rsp+1D0h] [rbp-98h]

  mSpeakerMode = this->mBuffer.mSpeakerMode;
  mChannels = this->mBuffer.mChannels;
  processresult = FMOD_RESULT::FMOD_OK_0;
  FMOD::DSPI::getOutputChannelFormatInternal(this, mChannels, mSpeakerMode, &outchannels, &outmode, &processresult);
  mProfileContext = this->mProfileContext;
  v9 = processresult;
  if ( !mProfileContext )
    goto LABEL_14;
  mSystem = this->mSystem;
  if ( mSystem )
  {
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
    mProfileContext = this->mProfileContext;
    if ( !mProfileContext )
    {
      v61 = this->mBuffer.mChannels;
      v62 = FMOD::DSPBuffer::get(&this->mBuffer);
      updated = FMOD::DSPI::updateMeteringInfo(this, v62, origlength, v61, 0);
      if ( updated )
      {
LABEL_108:
        if ( mSystem )
          FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
        return updated;
      }
      goto LABEL_13;
    }
    v11 = 1;
  }
  else
  {
    v11 = 0;
  }
  p_mInputMeter = 0;
  p_mBuffer = &this->mBuffer;
  v14 = this->mBuffer.mChannels;
  if ( mProfileContext->mInputMeter.mActive )
    p_mInputMeter = &mProfileContext->mInputMeter;
  v15 = FMOD::DSPBuffer::get(p_mBuffer);
  updated = FMOD::DSPI::updateMeteringInfo(this, v15, origlength, v14, p_mInputMeter);
  if ( updated == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( v11 && mSystem )
LABEL_13:
      FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
LABEL_14:
    v18 = v9 == FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
    if ( !origlength )
    {
      len = 0;
      offset = 0;
      goto LABEL_16;
    }
    if ( (this->mJob.mFlags & 1) == 0 && (this->mMixerFlags & 4) == 0 )
    {
      if ( v9 == FMOD_RESULT::FMOD_OK_0 )
      {
        mDescription = this->mDescription.mDescription;
        memset(&destbuff, 0, 24);
        destbuff.mCacheIndex = -1;
        memset(&drybuff, 0, 24);
        drybuff.mCacheIndex = -1;
        if ( mDescription )
        {
          numinputbuffers = mDescription->numinputbuffers;
          if ( !this->mBuffer.mData && numinputbuffers )
          {
LABEL_125:
            v28 = FMOD::DSPBuffer::alloc(&this->mBuffer, this->mSystem, outchannels, outmode, 1);
            if ( v28 )
              goto LABEL_126;
          }
        }
        else
        {
          numinputbuffers = 1;
          if ( !this->mBuffer.mData )
            goto LABEL_125;
        }
        v28 = FMOD::DSPBuffer::alloc(&destbuff, this->mSystem, outchannels, outmode, 0);
        if ( v28 == FMOD_RESULT::FMOD_OK_0 )
        {
          outputhead = &this->mSideChainBuffer;
          if ( (this->mJob.mFlags & 0x10) != 0 )
          {
            v77 = FMOD::DSPBuffer::get(&this->mSideChainBuffer);
            v78 = this->mBuffer.mChannels;
            if ( !v77 || this->mSideChainBuffer.mChannels != v78 )
            {
              v79 = FMOD::DSPBuffer::alloc(outputhead, this->mSystem, v78, this->mState.source_speakermode, 1);
              if ( v79 )
              {
                FMOD::DSPBuffer::release(&destbuff);
                v28 = v79;
                goto LABEL_126;
              }
            }
          }
          v87 = &this->mBuffer;
          src = FMOD::DSPBuffer::get(&this->mBuffer);
          dest = FMOD::DSPBuffer::get(&destbuff);
          this->mState.sidechaindata = FMOD::DSPBuffer::get(outputhead);
          this->mState.sidechainchannels = this->mSideChainBuffer.mChannels;
          len = origlength;
          if ( !numinputbuffers )
            len = this->mJob.mInfo.mMixLength;
          if ( this->mPreWet != 1.0 || this->mPreWetOld != 1.0 )
          {
            v116 = 0;
            v119 = 0;
            v122 = 0;
            v120 = 0;
            v115 = &v114;
            v114 = (__int64)&v114;
            v121 = 0;
            v118 = &v117;
            v117 = (__int64)&v117;
            v124 = 0;
            v125 = 0;
            v130 = 0;
            v123 = 0;
            v70 = this->mDry == 0.0;
            v132 = 0;
            v131 = 0;
            output_channels = 0;
            v126 = 0;
            v127 = 0;
            if ( !v70 )
            {
              v28 = FMOD::DSPBuffer::alloc(
                      &drybuff,
                      this->mSystem,
                      this->mBuffer.mChannels,
                      this->mBuffer.mSpeakerMode,
                      0);
              if ( v28 )
                goto LABEL_126;
              v75 = 4LL * this->mBuffer.mChannels * len;
              offsetb = FMOD::DSPBuffer::get(v87);
              v76 = FMOD::DSPBuffer::get(&drybuff);
              memcpy_0(v76, offsetb, v75);
            }
            FMOD::DSPConnectionI::init((FMOD::DSPConnectionI *const)&output_channels, this->mSystem, v4);
            v71 = this->mBuffer.mChannels;
            mPreWet = this->mPreWet;
            v129 = 64;
            mPostWet = mPreWet;
            offseta = v71;
            v73 = FMOD::DSPBuffer::get(v87);
            v74 = FMOD::DSPBuffer::get(v87);
            FMOD::DSPConnectionI::mix(
              (FMOD::DSPConnectionI *const)&output_channels,
              v74,
              v73,
              0,
              offseta,
              offseta,
              origlength,
              1);
            this->mPreWetOld = this->mPreWet;
          }
          mProcess = this->mProcess;
          if ( mProcess )
          {
            v30 = this->mBuffer.mChannels;
            inmask = 0;
            outmask = 0;
            in.numbuffers = numinputbuffers;
            output_mode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
            innumchannels = v30;
            v31 = destbuff.mChannels;
            this->mState.instance = this;
            outnumchannels = v31;
            in.bufferchannelmask = &inmask;
            in.buffernumchannels = &innumchannels;
            in.buffers = &src;
            in.speakermode = this->mBuffer.mSpeakerMode;
            p_outmask = &outmask;
            p_outnumchannels = &outnumchannels;
            p_dest = &dest;
            v112 = destbuff.mSpeakerMode;
            v32 = mProcess(&this->mState, len, &in, (FMOD_DSP_BUFFER_ARRAY *)&output_mode, 0, FMOD_DSP_PROCESS_PERFORM);
            if ( v32 == FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0 )
            {
              v18 = 1;
            }
            else if ( v32 && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
            {
              LOBYTE(output_channels) = 0;
              FMOD_ReportError(
                v32,
                FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSP,
                this,
                "DSPI::RunJob",
                (const char *)&output_channels);
            }
            v33 = this->mDescription.mDescription;
            if ( v33
              && v33->read
              && destbuff.mChannels != outnumchannels
              && outnumchannels <= this->mSystem->mDSPMemoryChannels
              && outnumchannels )
            {
              destbuff.mChannels = outnumchannels;
            }
          }
          offset = 0;
          if ( !numinputbuffers )
          {
            mMixOffset = this->mJob.mInfo.mMixOffset;
            v35 = destbuff.mChannels;
            v36 = destbuff.mChannels;
            if ( mMixOffset )
            {
              offset = mMixOffset;
              inchannels = this->mJob.mInfo.mMixOffset;
              v36 = destbuff.mChannels;
              memmove(&dest[destbuff.mChannels * mMixOffset], dest, 4LL * destbuff.mChannels * len);
              memset(dest, 0, 4 * v35 * (unsigned __int64)inchannels);
            }
            memset(&dest[(len + offset) * v35], 0, (origlength - len - offset) * 4 * v36);
          }
          if ( this->mPostWet != 1.0 || this->mPostWetOld != 1.0 )
          {
            v123 = 0;
            v37 = this->mSystem;
            v115 = &v114;
            v114 = (__int64)&v114;
            v124 = 0;
            v120 = 0;
            v121 = 0;
            v131 = 0;
            v130 = 0;
            v116 = 0;
            v118 = &v117;
            v117 = (__int64)&v117;
            v119 = 0;
            v122 = 0;
            v125 = 0;
            v132 = 0;
            output_channels = 0;
            v126 = 0;
            v127 = 0;
            FMOD::DSPConnectionI::init((FMOD::DSPConnectionI *const)&output_channels, v37, v4);
            mPostWet = this->mPostWet;
            v129 = 64;
            inchannelsa = destbuff.mChannels;
            v38 = FMOD::DSPBuffer::get(&destbuff);
            v39 = FMOD::DSPBuffer::get(&destbuff);
            FMOD::DSPConnectionI::mix(
              (FMOD::DSPConnectionI *const)&output_channels,
              v39,
              v38,
              0,
              inchannelsa,
              inchannelsa,
              len,
              1);
          }
          mDry = this->mDry;
          if ( mDry != 0.0 || this->mDryOld != 0.0 )
          {
            p_drybuff = &this->mBuffer;
            v42 = this->mSystem;
            v116 = 0;
            v115 = &v114;
            v114 = (__int64)&v114;
            v119 = 0;
            v118 = &v117;
            v117 = (__int64)&v117;
            v120 = 0;
            v122 = 0;
            v121 = 0;
            v125 = 0;
            v123 = 0;
            v132 = 0;
            v124 = 0;
            output_channels = 0;
            v130 = 0;
            v131 = 0;
            v126 = 0;
            v127 = 0;
            if ( drybuff.mData )
              p_drybuff = &drybuff;
            FMOD::DSPConnectionI::init((FMOD::DSPConnectionI *const)&output_channels, v42, mDry);
            v43 = p_drybuff->mChannels;
            mPostWet = this->mDry;
            v44 = destbuff.mChannels;
            v129 = 64;
            inchannelsb = v43;
            v45 = FMOD::DSPBuffer::get(p_drybuff);
            v46 = FMOD::DSPBuffer::get(&destbuff);
            FMOD::DSPConnectionI::mix(
              (FMOD::DSPConnectionI *const)&output_channels,
              v46,
              v45,
              0,
              v44,
              inchannelsb,
              len,
              0);
            FMOD::DSPBuffer::release(&drybuff);
            mDry = this->mDry;
          }
          this->mPreWetOld = this->mPreWet;
          this->mPostWetOld = this->mPostWet;
          this->mDryOld = mDry;
          FMOD::DSPBuffer::release(outputhead);
          FMOD::DSPBuffer::release(v87);
          FMOD::DSPBuffer::moveTo(&destbuff, v87);
          this->mMixerFlags |= 4u;
          if ( this->mPostWet == 0.0 && this->mDry == 0.0 )
            v18 = 1;
          this->mLastChannels = this->mBuffer.mChannels;
          FMOD::DSPBuffer::~DSPBuffer(&drybuff);
          FMOD::DSPBuffer::~DSPBuffer(&destbuff);
LABEL_16:
          if ( !v18 )
            goto LABEL_17;
LABEL_86:
          FMOD::DSPBuffer::release(&this->mBuffer);
          goto LABEL_17;
        }
LABEL_126:
        lena = v28;
        FMOD::DSPBuffer::~DSPBuffer(&drybuff);
        FMOD::DSPBuffer::~DSPBuffer(&destbuff);
        return lena;
      }
      if ( (this->mDry != 0.0 || this->mDryOld != 0.0) && this->mBuffer.mData )
      {
        v124 = 0;
        v63 = this->mSystem;
        v115 = &v114;
        v114 = (__int64)&v114;
        v118 = &v117;
        v117 = (__int64)&v117;
        v130 = 0;
        v121 = 0;
        v123 = 0;
        v131 = 0;
        v116 = 0;
        v119 = 0;
        v122 = 0;
        v120 = 0;
        v125 = 0;
        v132 = 0;
        output_channels = 0;
        v126 = 0;
        v127 = 0;
        FMOD::DSPConnectionI::init((FMOD::DSPConnectionI *const)&output_channels, v63, v4);
        mPostWet = this->mDry;
        v64 = this->mBuffer.mChannels;
        v129 = 64;
        v65 = FMOD::DSPBuffer::get(&this->mBuffer);
        v66 = FMOD::DSPBuffer::get(&this->mBuffer);
        FMOD::DSPConnectionI::mix((FMOD::DSPConnectionI *const)&output_channels, v66, v65, 0, v64, v64, origlength, 1);
        v67 = this->mBuffer.mChannels;
        this->mDryOld = this->mDry;
        len = origlength;
        offset = 0;
        this->mLastChannels = v67;
LABEL_17:
        v19 = this->mProfileContext;
        if ( !v19 )
          goto LABEL_65;
        v20 = this->mSystem;
        if ( v20 )
        {
          FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
          v19 = this->mProfileContext;
          if ( !v19 )
          {
            v57 = this->mBuffer.mChannels;
            v58 = FMOD::DSPBuffer::get(&this->mBuffer);
            v25 = FMOD::DSPI::updateMeteringInfo(this, v58, origlength, v57, 0);
            if ( v25 )
              goto LABEL_90;
            goto LABEL_93;
          }
          v21 = 1;
        }
        else
        {
          v21 = 0;
        }
        p_mOutputMeter = 0;
        v23 = this->mBuffer.mChannels;
        if ( v19->mOutputMeter.mActive )
          p_mOutputMeter = &v19->mOutputMeter;
        v24 = FMOD::DSPBuffer::get(&this->mBuffer);
        v25 = FMOD::DSPI::updateMeteringInfo(this, v24, origlength, v23, p_mOutputMeter);
        if ( v25 )
        {
          if ( !v21 )
            return v25;
LABEL_90:
          if ( v20 )
            FMOD::SystemI::leaveCrit(v20, FMOD_SYSTEM_CRIT_DSPMETERING);
          return v25;
        }
        if ( !v21 || !v20 )
        {
LABEL_65:
          if ( this->mBuffer.mData )
            this->mMixerFlags &= ~1u;
          else
            this->mMixerFlags |= 1u;
          if ( this->mNumOutputs )
          {
            mNodeNext = (FMOD::DSPI *)this->mOutputHead.mNodeNext;
            if ( &this->mOutputHead != (FMOD::LinkedListNode *)mNodeNext )
            {
              v95 = &this->mBuffer;
              while ( 1 )
              {
                mClockNext = mNodeNext->mJob.mDelayClock.mClockNext;
                v56 = *(_QWORD *)(mClockNext + 96);
                if ( *(_WORD *)(v56 + 166) )
                  break;
                if ( (*(_BYTE *)(mClockNext + 124) & 1) != 0 )
                  goto LABEL_71;
LABEL_81:
                *(_DWORD *)(v56 + 456) &= ~2u;
                mNodeNext = *(FMOD::DSPI **)(mClockNext + 32);
                if ( &this->mOutputHead == (FMOD::LinkedListNode *)mNodeNext )
                  goto LABEL_87;
              }
              v48 = v56 + 320;
              if ( (*(_BYTE *)(mClockNext + 124) & 1) != 0 )
LABEL_71:
                v48 = v56 + 352;
              v49 = *(FMOD::DSPI **)(mClockNext + 96);
              LODWORD(output_channels) = 0;
              output_mode = mixer_speakermode;
              FMOD::DSPI::calculateInputChannelFormat(
                v49,
                (int *)&output_channels,
                &output_mode,
                (FMOD::DSPConnectionI *)mClockNext);
              if ( !this->mBuffer.mData || !len )
                goto LABEL_96;
              if ( *(_QWORD *)v48 )
              {
                writedontmix = *(_DWORD *)(v56 + 456) & 2;
              }
              else
              {
                if ( *(_QWORD *)(mClockNext + 64) )
                  goto LABEL_99;
                v68 = *(float *)(mClockNext + 104);
                v69 = *(float *)(mClockNext + 128);
                if ( v68 != v69 || v69 != 1.0 || v68 != 1.0 || *(__int16 *)(v56 + 432) > 1 )
                  goto LABEL_99;
                if ( !FMOD::formatCheckShouldMix(
                        this->mBuffer.mChannels,
                        this->mBuffer.mSpeakerMode,
                        output_channels,
                        output_mode,
                        mixer_speakermode) )
                {
                  if ( this->mBuffer.mData )
                    FMOD::DSPBuffer::copyTo(v95, (FMOD::DSPBuffer *)v48);
LABEL_96:
                  if ( *(_DWORD *)(mClockNext + 108) )
                    FMOD::DSPConnectionI::setCurrentToTarget((FMOD::DSPConnectionI *const)mClockNext);
                  goto LABEL_81;
                }
                writedontmix = *(_DWORD *)(v56 + 456) & 2;
                if ( !*(_QWORD *)v48 )
                {
LABEL_99:
                  result = FMOD::DSPBuffer::alloc(
                             (FMOD::DSPBuffer *const)v48,
                             this->mSystem,
                             output_channels,
                             FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0,
                             0);
                  if ( result )
                    return result;
                  writedontmix = 1;
                  *(_DWORD *)(v48 + 20) = output_mode;
                  goto LABEL_101;
                }
              }
              if ( !writedontmix )
              {
                v51 = *(_DWORD *)(v48 + 16);
                goto LABEL_78;
              }
LABEL_101:
              if ( offset || origlength > len )
              {
                v59 = *(_DWORD *)(v48 + 16);
              }
              else
              {
                v51 = *(_DWORD *)(v48 + 16);
                if ( !*(_QWORD *)(mClockNext + 64) )
                  goto LABEL_78;
                v59 = *(_DWORD *)(v48 + 16);
                if ( v51 == *(__int16 *)(mClockNext + 58) )
                  goto LABEL_78;
              }
              writedontmix = 0;
              v60 = FMOD::DSPBuffer::get((FMOD::DSPBuffer *const)v48);
              memset(v60, 0, 4LL * origlength * v59);
              v51 = *(_DWORD *)(v48 + 16);
LABEL_78:
              v52 = 1;
              if ( *(_DWORD *)(v48 + 20) != 1 )
                v52 = this->mBuffer.mSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
              directmapping = v52;
              v92 = v51;
              inchannelsc = this->mBuffer.mChannels;
              v53 = &FMOD::DSPBuffer::get(v95)[inchannelsc * offset];
              v54 = FMOD::DSPBuffer::get((FMOD::DSPBuffer *const)v48);
              FMOD::DSPConnectionI::mix(
                (FMOD::DSPConnectionI *const)mClockNext,
                &v54[*(_DWORD *)(v48 + 16) * offset],
                v53,
                directmapping,
                v92,
                inchannelsc,
                len,
                writedontmix);
              goto LABEL_81;
            }
LABEL_87:
            FMOD::DSPBuffer::release(&this->mBuffer);
          }
          this->mMixerFlags &= ~4u;
          this->mJob.mInfo.mMixOffset = 0;
          this->mJob.mInfo.mMixLength = 0;
          this->mJob.mInfo.mInJobList = 0;
          this->mJob.mInfo.mExecute = 0;
          return FMOD_RESULT::FMOD_OK_0;
        }
LABEL_93:
        FMOD::SystemI::leaveCrit(v20, FMOD_SYSTEM_CRIT_DSPMETERING);
        goto LABEL_65;
      }
    }
    offset = 0;
    len = origlength;
    if ( v9 != FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0 )
      goto LABEL_17;
    goto LABEL_86;
  }
  if ( v11 )
    goto LABEL_108;
  return updated;
}


// Address: 0x21becd0 | Name: _ZN4FMOD10DSPJobList4readEi16FMOD_SPEAKERMODEjPNS_9DSPBufferE
FMOD_RESULT_0 __fastcall FMOD::DSPJobList::read(
        FMOD::DSPJobList *const this,
        int length,
        FMOD_SPEAKERMODE_0 mixer_speakermode,
        unsigned int mixer_speakermodechannels,
        FMOD::DSPBuffer *outbuffer_handle)
{
  float v5; // xmm1_4
  _BOOL4 gForceCPUMeasuring; // r15d
  __int64 i; // rbp
  FMOD::DSPI *mDSP; // rbx
  FMOD_RESULT_0 v11; // eax
  FMOD_RESULT_0 v12; // ebp
  unsigned int v14; // edx
  FMOD::LinkedListNode *mNodeNext; // rax
  _QWORD *mNodeData; // rdx
  FMOD::SystemI *mSystem; // rsi
  FMOD_RESULT_0 v18; // eax
  char v19; // r15
  int mChannels; // r14d
  float *v21; // r13
  float *v22; // rax
  FMOD::DSPJob *job; // [rsp+28h] [rbp-130h]
  unsigned int starttime; // [rsp+48h] [rbp-110h] BYREF
  unsigned int endtime; // [rsp+4Ch] [rbp-10Ch] BYREF
  FMOD::DSPBuffer destbuffer; // [rsp+50h] [rbp-108h] BYREF
  FMOD::DSPConnectionI connection; // [rsp+70h] [rbp-E8h] BYREF

  gForceCPUMeasuring = 1;
  if ( (this->mSystem->mFlags & 0x10000) == 0 )
    gForceCPUMeasuring = off_286F358->gForceCPUMeasuring;
  for ( i = 0; this->mNumJobs > (int)i; ++i )
  {
    while ( 1 )
    {
      job = this->mJob[i].mJob;
      mDSP = job->mDSP;
      if ( gForceCPUMeasuring )
        FMOD_OS_Time_GetUs(&starttime);
      while ( FMOD::DSPI::runJob(mDSP, length, mixer_speakermode, mixer_speakermodechannels) )
      {
        v11 = FMOD::SystemI::expandDSPBufferPool(this->mSystem);
        if ( v11 )
          return v11;
      }
      FMOD::DSPBuffer::moveTo(&mDSP->mBuffer, outbuffer_handle);
      if ( gForceCPUMeasuring )
      {
        FMOD_OS_Time_GetUs(&endtime);
        if ( endtime >= starttime )
        {
          v14 = endtime - starttime;
          mDSP->mCPUTimeUs = endtime - starttime;
          mDSP->mCPUTimeInclusiveUs = v14;
          mNodeNext = job->mInputHead.mNodeNext;
          if ( mNodeNext != &job->mInputHead )
            break;
        }
      }
      if ( this->mNumJobs <= (int)++i )
        goto LABEL_19;
    }
    do
    {
      mNodeData = mNodeNext->mNodeData;
      if ( (*((_BYTE *)mNodeData + 124) & 5) == 0 )
        mDSP->mCPUTimeInclusiveUs += *(_DWORD *)(mNodeData[11] + 492LL);
      mNodeNext = mNodeNext->mNodeNext;
    }
    while ( mNodeNext != &job->mInputHead );
  }
LABEL_19:
  if ( outbuffer_handle->mData
    || (v12 = FMOD::DSPBuffer::alloc(outbuffer_handle, this->mSystem, mixer_speakermodechannels, mixer_speakermode, 1)) == FMOD_RESULT::FMOD_OK_0 )
  {
    v12 = FMOD_RESULT::FMOD_OK_0;
    if ( outbuffer_handle->mChannels != mixer_speakermodechannels )
    {
      connection.mMixMatrixCurrent.mOutChannels = 0;
      mSystem = this->mSystem;
      connection.mMixMatrix.mOutChannels = 0;
      connection.mMixMatrixCurrent.mInChannels = 0;
      connection.mInputNode.mNodePrev = &connection.mInputNode;
      connection.mInputNode.mNodeNext = &connection.mInputNode;
      connection.mUserData.mMixMatrixUser.mInChannels = 0;
      connection.mUserData.mMixMatrixUser.mOutChannels = 0;
      connection.mOutputNode.mNodePrev = &connection.mOutputNode;
      connection.mOutputNode.mNodeNext = &connection.mOutputNode;
      connection.mInputNode.mNodeData = 0;
      connection.mOutputNode.mNodeData = 0;
      connection.mMixMatrix.mData = 0;
      connection.mMixMatrix.mInChannels = 0;
      memset(&connection.mMixMatrixCurrent.mData, 0, 24);
      connection.mUserData.mMixMatrixUser.mData = 0;
      connection.mSystem = 0;
      memset(&destbuffer, 0, 24);
      destbuffer.mCacheIndex = -1;
      v18 = FMOD::DSPBuffer::alloc(
              &destbuffer,
              mSystem,
              mixer_speakermodechannels,
              FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0,
              0);
      if ( v18 || (v18 = FMOD::DSPConnectionI::init(&connection, this->mSystem, v5)) != FMOD_RESULT::FMOD_OK_0 )
      {
        v12 = v18;
      }
      else
      {
        v19 = 1;
        if ( outbuffer_handle->mSpeakerMode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
          v19 = mixer_speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
        mChannels = outbuffer_handle->mChannels;
        v21 = FMOD::DSPBuffer::get(outbuffer_handle);
        v22 = FMOD::DSPBuffer::get(&destbuffer);
        v12 = FMOD::DSPConnectionI::mix(&connection, v22, v21, v19, mixer_speakermodechannels, mChannels, length, 1);
        if ( v12 == FMOD_RESULT::FMOD_OK_0 )
        {
          FMOD::DSPBuffer::release(outbuffer_handle);
          FMOD::DSPBuffer::copyTo(&destbuffer, outbuffer_handle);
          FMOD::DSPBuffer::~DSPBuffer(&destbuffer);
          return v12;
        }
      }
      FMOD::DSPBuffer::~DSPBuffer(&destbuffer);
    }
  }
  return v12;
}


// Address: 0x21bf060 | Name: _ZN4FMOD4DSPI23allocateMeteringContextEv
FMOD_RESULT_0 __fastcall FMOD::DSPI::allocateMeteringContext(FMOD::DSPI *const this)
{
  FMOD::SystemI *mSystem; // rbp
  char v3; // r13
  FMOD_RESULT_0 v4; // r12d
  void *v5; // rax
  FMOD::SystemI *v6; // rdi
  FMOD::FMOD_DSP_PROFILE_CONTEXT *v7; // rsi

  mSystem = this->mSystem;
  if ( mSystem )
  {
    v3 = 1;
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
  }
  else
  {
    v3 = 0;
  }
  v4 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v5 = FMOD::MemPool::calloc(off_286F358->gSystemMemPool, 1104, "../../../core_api/src/fmod_dspi.cpp", 6345, 0);
  this->mProfileContextMemory = v5;
  if ( v5 )
  {
    v6 = this->mSystem;
    v7 = (FMOD::FMOD_DSP_PROFILE_CONTEXT *)(((unsigned __int64)v5 + 15) & 0xFFFFFFFFFFFFFFF0LL);
    v7->mListNode.mNodeData = v7;
    v7->mListNode.mNodePrev = &v7->mListNode;
    v7->mListNode.mNodeNext = &v7->mListNode;
    this->mProfileContext = v7;
    v4 = FMOD::SystemI::addDSPMeteringContext(v6, v7);
  }
  if ( !v3 || !mSystem )
    return v4;
  FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
  return v4;
}


// Address: 0x21bf150 | Name: _ZN4FMOD4DSPI19freeMeteringContextEv
FMOD_RESULT_0 __fastcall FMOD::DSPI::freeMeteringContext(FMOD::DSPI *const this)
{
  FMOD::SystemI *mSystem; // rbp
  char v2; // r13
  FMOD::FMOD_DSP_PROFILE_CONTEXT *mProfileContext; // rsi
  FMOD_RESULT_0 v4; // r12d
  void *mProfileContextMemory; // rsi

  mSystem = this->mSystem;
  if ( mSystem )
  {
    v2 = 1;
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
  }
  else
  {
    v2 = 0;
  }
  mProfileContext = this->mProfileContext;
  if ( mProfileContext
    && (v4 = FMOD::SystemI::removeDSPMeteringContext(this->mSystem, mProfileContext)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( !v2 )
      return v4;
  }
  else
  {
    mProfileContextMemory = this->mProfileContextMemory;
    this->mProfileContext = 0;
    this->mProfileContextMemory = 0;
    if ( mProfileContextMemory )
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        mProfileContextMemory,
        "../../../core_api/src/fmod_dspi.cpp",
        6385);
    v4 = FMOD_RESULT::FMOD_OK_0;
    if ( !v2 )
      return v4;
  }
  if ( !mSystem )
    return v4;
  FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
  return v4;
}


// Address: 0x21bf230 | Name: _ZN4FMOD4DSPI15releaseInternalEb
FMOD_RESULT_0 __fastcall FMOD::DSPI::releaseInternal(FMOD::DSPI *const this, bool protect)
{
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  void (__fastcall *release)(FMOD_DSP_STATE *, bool); // rax
  FMOD_RESULT_0 result; // eax
  int mRefCount; // edx
  unsigned __int16 mFlags; // dx
  void *mMemory; // rsi
  FMOD::MemPool *gSystemMemPool; // rdi
  unsigned __int16 v10; // dx
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *descriptionplugin; // [rsp+18h] [rbp-10h] BYREF

  mDescription = this->mDescription.mDescription;
  if ( mDescription )
  {
    release = (void (__fastcall *)(FMOD_DSP_STATE *, bool))mDescription->release;
    if ( release )
    {
      this->mState.instance = this;
      release(&this->mState, protect);
    }
  }
  if ( !this->mProfileContext
    || !this->mProfileContextMemory
    || (result = FMOD::DSPI::freeMeteringContext(this)) == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( (this->mJob.mFlags & 4) != 0 )
    {
      result = FMOD::PluginFactory::getDSP(
                 this->mSystem->mPluginFactory,
                 this->mDescription.mHandle,
                 &descriptionplugin);
      if ( result )
        return result;
      mRefCount = descriptionplugin->mRefCount;
      if ( mRefCount > 0 )
        descriptionplugin->mRefCount = mRefCount - 1;
    }
    this->mBuffer.mSystem = this->mSystem;
    FMOD::DSPBuffer::release(&this->mBuffer);
    this->mSideChainBuffer.mSystem = this->mSystem;
    FMOD::DSPBuffer::release(&this->mSideChainBuffer);
    mFlags = this->mJob.mFlags;
    if ( (mFlags & 2) != 0 )
    {
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        (void *)this->mDescription.mDescription,
        "../../../core_api/src/fmod_dspi.cpp",
        3236);
      v10 = this->mJob.mFlags;
      result = FMOD_RESULT::FMOD_OK_0;
      this->mDescription.mDescription = 0;
      v10 &= ~2u;
      this->mJob.mFlags = v10;
      if ( (v10 & 0x800) != 0 )
        return result;
    }
    else
    {
      result = FMOD_RESULT::FMOD_OK_0;
      if ( (mFlags & 0x800) != 0 )
        return result;
    }
    mMemory = this->mMemory;
    this->mJob.mMagic = -559038803;
    gSystemMemPool = off_286F358->gSystemMemPool;
    if ( mMemory )
    {
      FMOD::MemPool::free(gSystemMemPool, mMemory, "../../../core_api/src/fmod_dspi.cpp", 3247);
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      FMOD::MemPool::free(gSystemMemPool, this, "../../../core_api/src/fmod_dspi.cpp", 3251);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21bf3c0 | Name: _ZN4FMOD4DSPI7releaseEv
FMOD_RESULT_0 __fastcall FMOD::DSPI::release(FMOD::DSPI *const this)
{
  FMOD::SystemI *mSystem; // rdi
  unsigned __int16 mFlags; // ax
  FMOD_RESULT_0 v4; // ebp
  FMOD::DSPQueueCmd_DisconnectAll *v6; // rsi
  FMOD::SystemI *v7; // rdi
  FMOD_RESULT_0 v8; // eax
  FMOD::DSPQueueCmd_DisconnectAll *cmd; // [rsp+8h] [rbp-20h] BYREF

  mSystem = this->mSystem;
  if ( !mSystem )
    return FMOD_RESULT::FMOD_OK_0;
  mFlags = this->mJob.mFlags;
  v4 = FMOD_RESULT::FMOD_ERR_DSP_RESERVED_0;
  if ( (mFlags & 0x80u) == 0 )
  {
    LOBYTE(v4) = 8;
    if ( (mFlags & 0x100) == 0 )
    {
      v4 = FMOD::SystemI::stopDSP(mSystem, this);
      if ( v4 == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( (this->mJob.mFlags & 0xC00) != 0 )
        {
          FMOD::SystemI::flushDSPQueue(this->mSystem, 1);
          v4 = FMOD::DSPI::disconnectFromInternal(
                 this,
                 0,
                 0,
                 1,
                 1,
                 FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
          if ( v4 == FMOD_RESULT::FMOD_OK_0 )
            return FMOD::DSPI::releaseInternal(this, 1);
        }
        else
        {
          v4 = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 24, 1);
          if ( v4 == FMOD_RESULT::FMOD_OK_0 )
          {
            this->mJob.mFlags |= 0x1000u;
            v6 = cmd;
            v7 = this->mSystem;
            *(_BYTE *)&cmd->FMOD::DSPQueueCmd = 5;
            v6->mThis = this;
            v6->mInputs = 1;
            v6->mOutputs = 1;
            v6->mAddToReleaseQueue = 1;
            v8 = FMOD::SystemI::unlockDSPQueueCmd(v7, v6, 1);
            if ( v8 )
              return v8;
          }
        }
      }
    }
  }
  return v4;
}


// Address: 0x21bf4d0 | Name: _ZN4FMOD4DSPI17setMeteringActiveEPNS_25FMOD_DSP_METERING_CONTEXTEb
FMOD_RESULT_0 __fastcall FMOD::DSPI::setMeteringActive(
        FMOD::DSPI *const this,
        FMOD::FMOD_DSP_METERING_CONTEXT *context,
        bool active)
{
  FMOD::FMOD_DSP_METERING_CONTEXT *v5; // rdi
  unsigned int v6; // edx
  __int64 v7; // rcx
  _DWORD *v8; // rdi
  FMOD::SystemI *mSystem; // rax

  if ( active )
  {
    if ( context->mActive )
      return FMOD_RESULT::FMOD_OK_0;
    mSystem = this->mSystem;
    context->mActive = 1;
    ++mSystem->mNumMeteredDSPs;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( !context->mActive )
      return FMOD_RESULT::FMOD_OK_0;
    v5 = context;
    v6 = 532;
    if ( ((unsigned __int8)context & 1) != 0 )
    {
      LOBYTE(context->mAccumulatedSquares[0]) = 0;
      v5 = (FMOD::FMOD_DSP_METERING_CONTEXT *)((char *)context->mAccumulatedSquares + 1);
      LOBYTE(v6) = 19;
    }
    if ( ((unsigned __int8)v5 & 2) != 0 )
    {
      v5 = (FMOD::FMOD_DSP_METERING_CONTEXT *)((char *)v5 + 2);
      v6 -= 2;
      *(_WORD *)&v5[-1].mActive = 0;
    }
    if ( ((unsigned __int8)v5 & 4) != 0 )
    {
      v5->mAccumulatedSquares[0] = 0.0;
      v6 -= 4;
      v5 = (FMOD::FMOD_DSP_METERING_CONTEXT *)((char *)v5 + 4);
    }
    v7 = v6 >> 3;
    memset(v5, 0, 8 * v7);
    v8 = (_DWORD *)&v5->mAccumulatedSquares[2 * v7];
    if ( (v6 & 4) != 0 )
      *v8++ = 0;
    if ( (v6 & 2) != 0 )
    {
      v8 = (_DWORD *)((char *)v8 + 2);
      *((_WORD *)v8 - 1) = 0;
    }
    if ( (v6 & 1) != 0 )
      *(_BYTE *)v8 = 0;
    --this->mSystem->mNumMeteredDSPs;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21bf5b0 | Name: _ZN4FMOD4DSPI18setMeteringEnabledEbb
FMOD_RESULT_0 __fastcall FMOD::DSPI::setMeteringEnabled(FMOD::DSPI *const this, bool inputEnabled, bool outputEnabled)
{
  FMOD::FMOD_DSP_PROFILE_CONTEXT *mProfileContext; // rsi
  FMOD::SystemI *mSystem; // rbx
  char v7; // r12
  bool v8; // r13
  FMOD_RESULT_0 MeteringContext; // r8d
  char v11; // [rsp+Ch] [rbp-3Ch]
  FMOD_RESULT_0 v12; // [rsp+Ch] [rbp-3Ch]

  mProfileContext = this->mProfileContext;
  mSystem = this->mSystem;
  if ( !mProfileContext && !inputEnabled )
  {
    MeteringContext = FMOD_RESULT::FMOD_OK_0;
    if ( !outputEnabled )
      return MeteringContext;
  }
  if ( mSystem )
  {
    v7 = 1;
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
    mProfileContext = this->mProfileContext;
  }
  else
  {
    v7 = 0;
  }
  if ( mProfileContext && (mProfileContext->mInputMeter.mActive || mProfileContext->mOutputMeter.mActive) )
  {
    v11 = 1;
    v8 = inputEnabled || outputEnabled;
  }
  else
  {
    v8 = inputEnabled || outputEnabled;
    if ( inputEnabled || outputEnabled )
    {
      MeteringContext = FMOD::DSPI::allocateMeteringContext(this);
      if ( MeteringContext )
        goto LABEL_8;
      mProfileContext = this->mProfileContext;
    }
    if ( !mProfileContext )
      goto LABEL_15;
    v11 = 0;
  }
  MeteringContext = FMOD::DSPI::setMeteringActive(this, &mProfileContext->mInputMeter, inputEnabled);
  if ( MeteringContext
    || (MeteringContext = FMOD::DSPI::setMeteringActive(this, &this->mProfileContext->mOutputMeter, outputEnabled)) != FMOD_RESULT::FMOD_OK_0 )
  {
LABEL_8:
    if ( !v7 )
      return MeteringContext;
    goto LABEL_16;
  }
  if ( !v8 && v11 )
  {
    MeteringContext = FMOD::DSPI::freeMeteringContext(this);
    goto LABEL_8;
  }
LABEL_15:
  MeteringContext = FMOD_RESULT::FMOD_OK_0;
  if ( !v7 )
    return MeteringContext;
LABEL_16:
  if ( mSystem )
  {
    v12 = MeteringContext;
    FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPMETERING);
    return v12;
  }
  return MeteringContext;
}


// Address: 0x21bf740 | Name: _ZN4FMOD4DSPI5allocEPNS_23FMOD_DSP_DESCRIPTION_EXE
FMOD_RESULT_0 __fastcall FMOD::DSPI::alloc(FMOD::DSPI *const this, FMOD::FMOD_DSP_DESCRIPTION_EX *description)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *mSystem; // rax
  bool v4; // zf
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  FMOD_RESULT_0 (*process)(FMOD_DSP_STATE *, unsigned int, const FMOD_DSP_BUFFER_ARRAY *, FMOD_DSP_BUFFER_ARRAY *, FMOD_BOOL, FMOD_DSP_PROCESS_OPERATION); // rdx
  FMOD_DSP_CREATE_CALLBACK_0 create; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !description )
    return result;
  mSystem = this->mSystem;
  this->mDescription = *description;
  this->mJob.mDSP = this;
  this->mJob.mActive = 0;
  this->mJob.mFlags &= ~0x100u;
  v4 = (mSystem->mFlags & 0x200000) == 0;
  this->mJob.mTick = 0;
  this->mState.source_speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
  this->mLastChannels = 0;
  this->mMixerFlags = 0;
  if ( v4 )
  {
    mDescription = this->mDescription.mDescription;
    if ( mDescription )
      goto LABEL_4;
LABEL_9:
    if ( FMOD::DSPI::getDataParameterIndex(this, -3, 0) == FMOD_RESULT::FMOD_OK_0 )
      this->mJob.mFlags |= 0x10u;
    return FMOD_RESULT::FMOD_OK_0;
  }
  FMOD::DSPI::setMeteringEnabled(this, 0, 1);
  mDescription = this->mDescription.mDescription;
  if ( !mDescription )
    goto LABEL_9;
LABEL_4:
  this->mUserData = mDescription->userdata;
  process = mDescription->process;
  if ( process )
  {
    this->mProcess = process;
  }
  else if ( mDescription->read )
  {
    this->mProcess = FMOD::FMOD_DSP_ProcessWrapper;
  }
  result = FMOD::SystemI::callInternalCallback(this->mSystem, 0x100010u, this, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    create = this->mDescription.mDescription->create;
    if ( !create )
      goto LABEL_9;
    this->mState.instance = this;
    result = create(&this->mState);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      goto LABEL_9;
  }
  return result;
}


// Address: 0x21bf8c0 | Name: _ZN4FMOD4DSPI11getCPUUsageEPjS1_
FMOD_RESULT_0 __fastcall FMOD::DSPI::getCPUUsage(
        FMOD::DSPI *const this,
        unsigned int *exclusive,
        unsigned int *inclusive)
{
  FMOD_RESULT_0 result; // eax

  if ( (this->mSystem->mFlags & 0x10000) != 0
    || (result = FMOD_RESULT::FMOD_ERR_BADCOMMAND_0, off_286F358->gForceCPUMeasuring) )
  {
    if ( exclusive )
      *exclusive = this->mCPUTimeUs;
    if ( inclusive )
      *inclusive = this->mCPUTimeInclusiveUs;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21bf910 | Name: _ZN4FMOD4DSPI16getClockExternalEP14FMOD_DSP_STATEPyPjS4_
FMOD_RESULT_0 __fastcall FMOD::DSPI::getClockExternal(
        FMOD_DSP_STATE *dsp_state,
        unsigned __int64 *clock,
        unsigned int *offset,
        unsigned int *length)
{
  FMOD_RESULT_0 result; // eax
  _QWORD *instance; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp_state )
  {
    instance = dsp_state->instance;
    if ( clock )
      *clock = instance[1] >> 20;
    if ( offset )
      *offset = *((unsigned __int16 *)instance + 82);
    if ( length )
      *length = *((unsigned __int16 *)instance + 83);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21bf960 | Name: _ZN4FMOD4DSPI19getUserDataExternalEP14FMOD_DSP_STATEPPv
FMOD_RESULT_0 __fastcall FMOD::DSPI::getUserDataExternal(FMOD_DSP_STATE *dsp_state, void **userdata)
{
  if ( !dsp_state || !userdata )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *userdata = (void *)*((_QWORD *)dsp_state->instance + 62);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21bf990 | Name: _ZN4FMOD4DSPI19getSystemSampleRateEP14FMOD_DSP_STATEPi
FMOD_RESULT_0 __fastcall FMOD::DSPI::getSystemSampleRate(FMOD_DSP_STATE *dsp_state, int *rate)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v3; // rdx
  __int64 systemobject; // rdx

  if ( !dsp_state || !rate )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp_state->instance )
  {
    v3 = (FMOD::SystemI *)*((_QWORD *)dsp_state->instance + 22);
  }
  else
  {
    systemobject = dsp_state->systemobject;
    result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    if ( (unsigned int)systemobject > 7 )
      return result;
    v3 = off_286F358->gSystem[systemobject];
  }
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( v3 )
  {
    *rate = v3->mDSPSampleRate;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21bfa00 | Name: _ZN4FMOD4DSPI18getSystemBlockSizeEP14FMOD_DSP_STATEPj
FMOD_RESULT_0 __fastcall FMOD::DSPI::getSystemBlockSize(FMOD_DSP_STATE *dsp_state, unsigned int *blocksize)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v3; // rdx
  __int64 systemobject; // rdx

  if ( !dsp_state || !blocksize )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp_state->instance )
  {
    v3 = (FMOD::SystemI *)*((_QWORD *)dsp_state->instance + 22);
  }
  else
  {
    systemobject = dsp_state->systemobject;
    result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    if ( (unsigned int)systemobject > 7 )
      return result;
    v3 = off_286F358->gSystem[systemobject];
  }
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( v3 )
  {
    *blocksize = v3->mDSPBlockSize;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21bfa70 | Name: _ZN4FMOD4DSPI20getSystemSpeakerModeEP14FMOD_DSP_STATEP16FMOD_SPEAKERMODES4_
FMOD_RESULT_0 __fastcall FMOD::DSPI::getSystemSpeakerMode(
        FMOD_DSP_STATE *dsp_state,
        FMOD_SPEAKERMODE_0 *speakermode_mixer,
        FMOD_SPEAKERMODE_0 *speakermode_output)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v4; // rcx
  __int64 systemobject; // rcx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp_state )
  {
    if ( dsp_state->instance )
    {
      v4 = (FMOD::SystemI *)*((_QWORD *)dsp_state->instance + 22);
    }
    else
    {
      systemobject = dsp_state->systemobject;
      result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
      if ( (unsigned int)systemobject > 7 )
        return result;
      v4 = off_286F358->gSystem[systemobject];
    }
    result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    if ( v4 )
    {
      if ( speakermode_mixer )
        *speakermode_mixer = v4->mSpeakerMode;
      if ( speakermode_output )
      {
        *speakermode_output = v4->mOutput->mSpeakerMode;
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21bfaf0 | Name: _ZN4FMOD4DSPI21getListenerAttributesEP14FMOD_DSP_STATEPiP18FMOD_3D_ATTRIBUTES
FMOD_RESULT_0 __fastcall FMOD::DSPI::getListenerAttributes(
        FMOD_DSP_STATE *dsp_state,
        int *numListeners,
        FMOD_3D_ATTRIBUTES *attributes)
{
  FMOD_RESULT_0 result; // eax
  _QWORD *instance; // rdi
  int v5; // ecx
  __int64 v6; // r8
  __int64 v7; // rax
  int v8; // esi
  __int64 v9; // r8

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp_state )
  {
    if ( numListeners )
    {
      if ( attributes )
      {
        instance = dsp_state->instance;
        if ( instance )
        {
          v5 = *numListeners;
          if ( *numListeners > 0 )
          {
            v6 = instance[22];
            LOBYTE(result) = 28;
            if ( v6 )
            {
              if ( v5 > *(_DWORD *)(v6 + 70480) )
                v5 = *(_DWORD *)(v6 + 70480);
              *numListeners = v5;
              if ( v5 > 0 )
              {
                v7 = v6;
                v8 = *(_DWORD *)(v6 + 72) & 4;
                v9 = v6 + 112LL * (unsigned int)(v5 - 1) + 112;
                do
                {
                  attributes->position = *(FMOD_VECTOR *)(v7 + 69584);
                  attributes->velocity = *(FMOD_VECTOR *)(v7 + 69608);
                  attributes->forward = *(FMOD_VECTOR *)(v7 + 69656);
                  attributes->up = *(FMOD_VECTOR *)(v7 + 69632);
                  if ( v8 )
                  {
                    if ( *(_DWORD *)instance[30] > 0x6Cu )
                    {
                      attributes->position.z = -attributes->position.z;
                      attributes->velocity.z = -attributes->velocity.z;
                      attributes->forward.z = -attributes->forward.z;
                      attributes->up.z = -attributes->up.z;
                    }
                  }
                  v7 += 112;
                  ++attributes;
                }
                while ( v7 != v9 );
              }
              return FMOD_RESULT::FMOD_OK_0;
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21bfc10 | Name: _ZN4FMOD4DSPI23updateIdleTimerCallbackEP14FMOD_DSP_STATEijji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPI::updateIdleTimerCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD_BOOL inputsidle,
        unsigned int length,
        FMOD_CHANNELMASK a4,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  _DWORD *instance; // rcx
  unsigned int v7; // esi
  FMOD_RESULT_0 result; // eax

  instance = dsp_state->instance;
  if ( inputsidle )
  {
    v7 = instance[111];
    result = FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0;
    if ( v7 )
    {
      if ( v7 > length )
      {
        LOBYTE(result) = 0;
        instance[111] = v7 - length;
      }
      else
      {
        instance[111] = 0;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  else
  {
    instance[111] = *(_DWORD *)(*((_QWORD *)instance + 22) + 1704LL);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21bfc70 | Name: _ZN4FMOD4DSPI12deinterleaveEPfPS1_iij
FMOD_RESULT_0 __fastcall FMOD::DSPI::deinterleave(
        float *inbuffer,
        float **outbuffer,
        int inchannels,
        int outchannels,
        unsigned int length)
{
  FMOD_Optimised_Routines.FMOD_DSP_Deinterleave(inbuffer, outbuffer, inchannels, outchannels, length);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21bfc90 | Name: _ZN4FMOD4DSPI10interleaveEPPfS1_ij
FMOD_RESULT_0 __fastcall FMOD::DSPI::interleave(float **inbuffer, float *outbuffer, int channels, unsigned int length)
{
  FMOD_Optimised_Routines.FMOD_DSP_Interleave(inbuffer, outbuffer, channels, length);
  return FMOD_RESULT::FMOD_OK_0;
}


