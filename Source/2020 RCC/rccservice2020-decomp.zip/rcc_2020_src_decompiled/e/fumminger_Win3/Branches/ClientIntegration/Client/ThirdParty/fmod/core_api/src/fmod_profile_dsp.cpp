// Address: 0x220afc0 | Name: _ZNK4FMOD10ProfileDsp17getNextPacketInfoEPNS_10PacketInfoE
FMOD_RESULT_0 __fastcall FMOD::ProfileDsp::getNextPacketInfo(
        const FMOD::ProfileDsp *const this,
        FMOD::PacketInfo *info)
{
  info->type = this->mPreparedNode == 0 ? -1 : 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220afd0 | Name: _ZN4FMOD10ProfileDsp13getNextPacketEPNS_7Profile17PacketWriteHandleE
FMOD_RESULT_0 __fastcall FMOD::ProfileDsp::getNextPacket(
        FMOD::ProfileDsp *const this,
        FMOD::Profile::PacketWriteHandle *handle)
{
  FMOD::ProfilePacketHeader *mPreparedNode; // rcx
  int mWriteCount; // edx
  FMOD_RESULT_0 result; // eax
  FMOD::ProfileInterface *mProfile; // rdi

  mPreparedNode = this->mPreparedNode;
  if ( !mPreparedNode )
    return FMOD_RESULT::FMOD_OK_0;
  mWriteCount = handle->mWriteCount;
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( mWriteCount <= 0 )
  {
    mProfile = handle->mProfile;
    handle->mWriteCount = mWriteCount + 1;
    result = (*mProfile->_vptr_ProfileInterface)(mProfile, mPreparedNode, 0);
    if ( result == FMOD_RESULT::FMOD_ERR_NET_WOULD_BLOCK_0 || result == FMOD_RESULT::FMOD_OK_0 )
    {
      this->mPreparedNode = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x220b030 | Name: _ZN4FMOD10ProfileDsp4initEv
FMOD_RESULT_0 __fastcall FMOD::ProfileDsp::init(FMOD::ProfileDsp *const this)
{
  char *v1; // rdx
  FMOD_RESULT_0 result; // eax

  this->mNumPacketNodes = 0;
  this->mMaxPacketNodes = 300;
  this->mShowMode = FMOD_PROFILE_DSP_SHOW_NONE;
  v1 = (char *)FMOD::MemPool::calloc(
                 off_286F358->gSystemMemPool,
                 28220,
                 "../../../core_api/src/fmod_profile_dsp.cpp",
                 44,
                 0);
  this->mDataPacket = v1;
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v1 )
  {
    this->mPacketHeader = (FMOD::ProfilePacketDspNetwork *)v1;
    this->mPreparedNode = 0;
    this->mPacketNodes = (FMOD::ProfileDspRawNode *)(v1 + 20);
    LOBYTE(result) = 0;
  }
  return result;
}


// Address: 0x220b0a0 | Name: _ZN4FMOD10ProfileDsp10readPacketEPKNS_19ProfilePacketHeaderEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileDsp::readPacket(
        FMOD::ProfileDsp *const this,
        const FMOD::ProfilePacketHeader *packet,
        FMOD::ProfileClient *fromclient)
{
  unsigned __int8 subtype; // al

  if ( (unsigned __int8)(packet->version - 5) <= 1u )
  {
    subtype = packet->subtype;
    switch ( subtype )
    {
      case 1u:
        if ( FMOD_stricmp((const char *)&packet[1], "Show Delays") )
        {
          if ( !FMOD_stricmp((const char *)&packet[1], "Show None") )
            this->mShowMode = FMOD_PROFILE_DSP_SHOW_NONE;
        }
        else
        {
          this->mShowMode = FMOD_PROFILE_DSP_SHOW_DELAYS;
        }
        break;
      case 2u:
        FMOD::DSP::setActive(*(FMOD::DSP *const *)&packet[1].size, packet[1].type != 0);
        break;
      case 3u:
        FMOD::DSP::setBypass(*(FMOD::DSP *const *)&packet[1].size, packet[1].type != 0);
        break;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220b160 | Name: _ZN4FMOD10ProfileDsp7releaseEv
FMOD_RESULT_0 __fastcall FMOD::ProfileDsp::release(FMOD::ProfileDsp *const this)
{
  bool v1; // zf
  bool v2; // cc
  __int64 mSize; // rax
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v4; // rax
  int v5; // ecx
  int v6; // edx
  bool v7; // cc
  bool v8; // cc
  char *mDataPacket; // rsi
  FMOD::ProfileDsp::NodeInfo *v11; // rsi
  unsigned int *mData; // rsi
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v13; // rsi

  v1 = this->mVisited.mBuckets.mCapacity == 0;
  v2 = this->mVisited.mBuckets.mCapacity <= 0;
  this->mVisited.mBuckets.mSize = 0;
  if ( !v1 )
  {
    if ( !v2 )
    {
      mData = this->mVisited.mBuckets.mData;
      if ( mData )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mData, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mVisited.mBuckets.mData = 0;
    this->mVisited.mBuckets.mCapacity = 0;
  }
  mSize = this->mVisited.mNodes.mSize;
  if ( (int)mSize < 0 )
  {
    v4 = &this->mVisited.mNodes.mData[mSize];
    v5 = -this->mVisited.mNodes.mSize;
    v6 = 0;
    do
    {
      if ( v4 )
      {
        v4->key = 0;
        v4->next = -1;
        v4->value = 0;
      }
      ++v6;
      ++v4;
    }
    while ( v5 > v6 );
  }
  v1 = this->mVisited.mNodes.mCapacity == 0;
  v7 = this->mVisited.mNodes.mCapacity <= 0;
  this->mVisited.mNodes.mSize = 0;
  if ( !v1 )
  {
    if ( !v7 )
    {
      v13 = this->mVisited.mNodes.mData;
      if ( v13 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v13, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mVisited.mNodes.mData = 0;
    this->mVisited.mNodes.mCapacity = 0;
  }
  v1 = this->mRemaining.mCapacity == 0;
  v8 = this->mRemaining.mCapacity <= 0;
  this->mVisited.mFreeList = -1;
  this->mVisited.mNodeCount = 0;
  this->mRemaining.mSize = 0;
  if ( !v1 )
  {
    if ( !v8 )
    {
      v11 = this->mRemaining.mData;
      if ( v11 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v11, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mRemaining.mData = 0;
    this->mRemaining.mCapacity = 0;
  }
  mDataPacket = this->mDataPacket;
  if ( mDataPacket )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mDataPacket, "../../../core_api/src/fmod_profile_dsp.cpp", 63);
    this->mDataPacket = 0;
  }
  FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_profile_dsp.cpp", 64);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220b7d0 | Name: _ZN4FMOD10ProfileDsp6createEPNS_7ProfileEPNS_7SystemIEPPS0_
FMOD_RESULT_0 __fastcall FMOD::ProfileDsp::create(
        FMOD::Profile *profile,
        FMOD::SystemI *system,
        FMOD::ProfileDsp **outProfileDSP)
{
  FMOD::ProfileDsp *v4; // rax
  FMOD::ProfileDsp *v5; // rbx
  FMOD::LinkedListNode *v6; // rax
  FMOD_RESULT_0 result; // eax

  *outProfileDSP = 0;
  v4 = (FMOD::ProfileDsp *)FMOD::MemPool::alloc(
                             off_286F358->gSystemMemPool,
                             152,
                             "../../../core_api/src/fmod_profile_dsp.cpp",
                             17,
                             0,
                             0);
  v5 = v4;
  if ( !v4 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v6 = &v4->FMOD::LinkedListNode;
  v5->mNodeData = 0;
  v5->mVisited.mBuckets.mData = 0;
  v5->mVisited.mBuckets.mSize = 0;
  v5->mVisited.mBuckets.mCapacity = 0;
  v5->mNodePrev = v6;
  v5->mNodeNext = v6;
  v5->mVisited.mNodes.mData = 0;
  v5->mVisited.mNodes.mSize = 0;
  v5->mVisited.mNodes.mCapacity = 0;
  v5->mVisited.mFreeList = -1;
  v5->mVisited.mNodeCount = 0;
  v5->mRemaining.mData = 0;
  v5->mRemaining.mSize = 0;
  v5->_vptr_ProfileModule = (int (**)(...))&off_29B1CF0;
  v5->mRemaining.mCapacity = 0;
  v5->mProfile = profile;
  v5->mSystem = system;
  result = FMOD::ProfileDsp::init(v5);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::Profile *, FMOD::ProfileDsp *))profile->_vptr_ProfileInterface + 1))(
               profile,
               v5);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      *outProfileDSP = v5;
  }
  return result;
}


// Address: 0x220b900 | Name: _ZN4FMOD10ProfileDsp17getNextPacketNodeEPPNS_17ProfileDspRawNodeE
FMOD_RESULT_0 __fastcall FMOD::ProfileDsp::getNextPacketNode(
        FMOD::ProfileDsp *const this,
        FMOD::ProfileDspRawNode **node)
{
  __int64 mNumPacketNodes; // rcx
  unsigned int mMaxPacketNodes; // edx
  unsigned int v5; // edi
  FMOD::ProfileDspRawNode *mPacketNodes; // rax
  unsigned int v8; // edx
  char *v9; // rax

  mNumPacketNodes = this->mNumPacketNodes;
  mMaxPacketNodes = this->mMaxPacketNodes;
  v5 = mNumPacketNodes + 1;
  if ( (int)mNumPacketNodes + 1 < mMaxPacketNodes )
  {
    mPacketNodes = this->mPacketNodes;
LABEL_3:
    this->mNumPacketNodes = v5;
    *node = &mPacketNodes[mNumPacketNodes];
    return FMOD_RESULT::FMOD_OK_0;
  }
  v8 = 2 * mMaxPacketNodes;
  this->mMaxPacketNodes = v8;
  v9 = (char *)FMOD::MemPool::realloc(
                 off_286F358->gSystemMemPool,
                 this->mDataPacket,
                 94 * v8 + 20,
                 "../../../core_api/src/fmod_profile_dsp.cpp",
                 276,
                 0);
  this->mDataPacket = v9;
  if ( v9 )
  {
    mNumPacketNodes = this->mNumPacketNodes;
    this->mPacketHeader = (FMOD::ProfilePacketDspNetwork *)v9;
    mPacketNodes = (FMOD::ProfileDspRawNode *)(v9 + 20);
    this->mPacketNodes = mPacketNodes;
    v5 = mNumPacketNodes + 1;
    goto LABEL_3;
  }
  return FMOD_RESULT::FMOD_ERR_MEMORY_0;
}


// Address: 0x220b9b0 | Name: _ZN4FMOD10ProfileDsp12prepareGraphEv
FMOD_RESULT_0 __fastcall FMOD::ProfileDsp::prepareGraph(FMOD::ProfileDsp *const this)
{
  FMOD_RESULT_0 result; // eax
  int mSize; // esi
  unsigned int *mData; // r11
  int v5; // eax
  unsigned int v6; // ecx
  unsigned int *v7; // rdx
  unsigned int i; // r10d
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v9; // rsi
  unsigned int next; // r8d
  __int64 v11; // r9
  int v12; // ebp
  unsigned int *v13; // rdx
  FMOD::SystemI *mSystem; // rdi
  __int64 v15; // rdx
  int mCapacity; // esi
  int v17; // ecx
  int v18; // eax
  int v19; // ebp
  int v20; // eax
  int v21; // edi
  __int64 v22; // rdx
  int v23; // ecx
  FMOD::ProfileDsp::NodeInfo *v24; // r12
  FMOD::ProfileDsp::NodeInfo *v25; // rdx
  int v26; // edx
  FMOD::ProfileDsp::NodeInfo *v27; // rax
  FMOD::DSPI *mDSP; // r15
  FMOD::DSPConnectionI *mConnection; // rbp
  int mNodeCount; // edx
  unsigned int v31; // eax
  int v32; // edx
  unsigned int *p_next; // r14
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v34; // rdx
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v35; // r14
  __int64 v36; // rax
  unsigned int mFreeList; // edx
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v38; // rax
  bool value; // r12
  int v40; // ebp
  __int64 v41; // rdx
  int v42; // esi
  int v43; // ecx
  int v44; // eax
  int v45; // r14d
  int v46; // eax
  FMOD::ProfileDsp::NodeInfo *v47; // rax
  FMOD::ProfileDsp::NodeInfo *v48; // r8
  __int64 v49; // rdx
  FMOD::ProfileDsp::NodeInfo *v50; // rsi
  FMOD::ProfileDsp::NodeInfo *v51; // rax
  _QWORD *p_mDSP; // rdx
  FMOD::ProfileDspRawNode *v53; // rax
  unsigned __int8 numchannels; // dl
  char *v55; // rdi
  FMOD::ProfileDspRawNode *v56; // rdx
  float *peaklevel; // r14
  int v58; // ebp
  __int64 v59; // rdx
  FMOD::ProfileDspRawNode *v60; // rax
  char v61; // cl
  float v62; // xmm0_4
  int v63; // edx
  int v64; // eax
  __int64 v65; // rdx
  int v66; // eax
  FMOD::ProfileDsp::NodeInfo *v67; // rdx
  FMOD::ProfilePacketDspNetwork *mPacketHeader; // rdi
  unsigned int v69; // edx
  __int64 ii; // rcx
  unsigned int v71; // edx
  FMOD::ProfilePacketDspNetwork *v72; // rax
  FMOD::SystemI *v73; // rdx
  FMOD::ProfilePacketDspNetwork *v74; // rax
  int mDSPSampleRate; // ecx
  int v76; // r12d
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v77; // r14
  int v78; // eax
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v79; // rsi
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v80; // rcx
  __int64 j; // rdx
  __int64 v82; // r10
  FMOD::ProfileDsp::NodeInfo *v83; // rax
  __int64 v84; // rdx
  FMOD::ProfileDsp::NodeInfo *v85; // rsi
  int v86; // r10d
  int v87; // edx
  int v88; // eax
  int v89; // r12d
  int v90; // eax
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v91; // rax
  int v92; // edx
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v93; // r9
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v94; // r8
  __int64 n; // rcx
  FMOD::DSPI *key; // rsi
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v97; // rsi
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v98; // rax
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v99; // rsi
  __int64 v100; // rax
  int v101; // r8d
  __int64 k; // rax
  int v103; // ecx
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v104; // rdi
  __int64 v105; // rsi
  unsigned int *m; // rcx
  __int64 v107; // rdx
  unsigned int cpuTimeUs; // [rsp+8h] [rbp-2D0h]
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *cpuTimeUsa; // [rsp+8h] [rbp-2D0h]
  FMOD::DSPReturn *sendTarget; // [rsp+10h] [rbp-2C8h]
  unsigned __int16 mFlags; // [rsp+18h] [rbp-2C0h]
  int v112; // [rsp+18h] [rbp-2C0h]
  char hasSendConnection; // [rsp+1Dh] [rbp-2BBh]
  char hasSidechainConnection; // [rsp+1Eh] [rbp-2BAh]
  char v115; // [rsp+1Fh] [rbp-2B9h]
  FMOD::ChannelControlI *mChannelOwner; // [rsp+20h] [rbp-2B8h]
  FMOD::ProfileDsp::NodeInfo *v117; // [rsp+30h] [rbp-2A8h]
  int numInputs; // [rsp+48h] [rbp-290h] BYREF
  FMOD_DSP_TYPE v119; // [rsp+4Ch] [rbp-28Ch] BYREF
  FMOD::ChannelGroupI *master; // [rsp+50h] [rbp-288h] BYREF
  FMOD::DSPI *headDSP; // [rsp+58h] [rbp-280h] BYREF
  FMOD_CLOCKTIME startClock; // [rsp+60h] [rbp-278h] BYREF
  FMOD_CLOCKTIME endClock; // [rsp+68h] [rbp-270h] BYREF
  FMOD::DSPI *inputDSP; // [rsp+70h] [rbp-268h] BYREF
  FMOD::DSPConnectionI *inputConnection; // [rsp+78h] [rbp-260h] BYREF
  FMOD::ProfileDspRawNode *packetNode; // [rsp+80h] [rbp-258h] BYREF
  FMOD::DSPConnectionI *v127; // [rsp+88h] [rbp-250h]
  char name[256]; // [rsp+90h] [rbp-248h] BYREF
  FMOD_DSP_METERING_INFO_0 metering; // [rsp+190h] [rbp-148h] BYREF

  result = FMOD_RESULT::FMOD_OK_0;
  if ( this->mPreparedNode )
    return result;
  mSize = this->mVisited.mBuckets.mSize;
  if ( mSize )
  {
    mData = this->mVisited.mBuckets.mData;
    v5 = 0;
    v6 = *mData;
    v7 = mData + 1;
    if ( *mData != -1 )
    {
      v5 = 0;
LABEL_6:
      for ( i = v6; ; i = v12 )
      {
        v9 = &this->mVisited.mNodes.mData[i];
        next = v9->next;
        if ( next == -1 )
        {
          if ( v5 == -1 )
          {
            v11 = -1;
            v5 = 0;
          }
          else
          {
            v11 = v5++;
          }
          v21 = this->mVisited.mBuckets.mSize;
          if ( v21 == v5 )
          {
            v12 = -1;
            v5 = -1;
          }
          else
          {
            v12 = mData[v5];
            v22 = (__int64)&mData[v5 + 1];
            if ( v12 == -1 )
            {
              while ( ++v5 != v21 )
              {
                v22 += 4;
                v23 = *(_DWORD *)(v22 - 4);
                if ( v23 != -1 )
                  goto LABEL_31;
              }
              v5 = -1;
            }
            else
            {
              v23 = mData[v5];
LABEL_31:
              v12 = v23;
            }
          }
        }
        else
        {
          v11 = v5;
          v12 = v9->next;
        }
        v13 = &mData[v11];
        if ( i != *v13 )
          break;
        v9->value = 0;
        *v13 = next;
        v9->next = this->mVisited.mFreeList;
        --this->mVisited.mNodeCount;
        this->mVisited.mFreeList = i;
        if ( v12 == -1 )
          goto LABEL_13;
        mData = this->mVisited.mBuckets.mData;
      }
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    }
    while ( ++v5 != mSize )
    {
      v6 = *v7++;
      if ( v6 != -1 )
        goto LABEL_6;
    }
  }
LABEL_13:
  mSystem = this->mSystem;
  this->mRemaining.mSize = 0;
  this->mNumPacketNodes = 0;
  master = 0;
  result = FMOD::SystemI::getMasterChannelGroup(mSystem, &master);
  if ( result )
    return result;
  headDSP = 0;
  result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **))master->_vptr_ChannelControlI
            + 36))(
             master,
             0xFFFFFFFFLL,
             &headDSP);
  if ( result )
    return result;
  v15 = this->mRemaining.mSize;
  mCapacity = this->mRemaining.mCapacity;
  *(_QWORD *)&metering.peaklevel[1] = 0;
  *(_QWORD *)&metering.numsamples = headDSP;
  v17 = v15 + 1;
  v18 = ((mCapacity >> 31) ^ this->mRemaining.mCapacity) - (mCapacity >> 31);
  if ( (int)v15 + 1 <= v18 )
  {
    v24 = this->mRemaining.mData;
  }
  else
  {
    v19 = 4;
    v20 = (int)(float)((float)v18 * 1.5);
    if ( v20 >= v17 )
      v17 = v20;
    result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    if ( v17 > 3 )
      v19 = v17;
    if ( (int)v15 > v19 )
      return result;
    if ( (unsigned int)(16 * v19 - 1) > 0x3FFFFFFE )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v83 = (FMOD::ProfileDsp::NodeInfo *)FMOD::MemPool::alloc(
                                          off_286F358->gSystemMemPool,
                                          16 * v19,
                                          "../../../core_api/src/fmod_memory.h",
                                          232,
                                          0,
                                          0);
    v24 = v83;
    if ( !v83 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v84 = this->mRemaining.mSize;
    if ( (_DWORD)v84 )
      memcpy_0(v83, this->mRemaining.mData, 16 * v84);
    if ( this->mRemaining.mCapacity > 0 )
    {
      v85 = this->mRemaining.mData;
      if ( v85 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v85, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mRemaining.mData = v24;
    this->mRemaining.mCapacity = v19;
    v15 = this->mRemaining.mSize;
  }
  v25 = &v24[v15];
  v25->mDSP = *(FMOD::DSPI **)&metering.numsamples;
  v25->mConnection = *(FMOD::DSPConnectionI **)&metering.peaklevel[1];
  v26 = this->mRemaining.mSize;
  this->mRemaining.mSize = v26 + 1;
  if ( v26 != -1 )
  {
    v27 = &this->mRemaining.mData[v26];
    mDSP = v27->mDSP;
    mConnection = v27->mConnection;
    if ( v26 < 0 )
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    this->mRemaining.mSize = v26;
    mNodeCount = this->mVisited.mNodeCount;
    if ( mNodeCount == -1 )
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    while ( 1 )
    {
      v31 = abs32(this->mVisited.mNodes.mCapacity);
      if ( v31 != this->mVisited.mBuckets.mSize )
        return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      if ( v31 == mNodeCount )
      {
        v76 = 2 * mNodeCount;
        if ( 2 * mNodeCount < 4 )
          v76 = 4;
        if ( mNodeCount >= v76 || mNodeCount != this->mVisited.mNodes.mSize || this->mVisited.mFreeList != -1 )
          return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
        if ( (unsigned int)(16 * v76 - 1) > 0x3FFFFFFE )
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        v77 = (FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *)FMOD::MemPool::alloc(off_286F358->gSystemMemPool, 16 * v76, "../../../core_api/src/fmod_memory.h", 232, 0, 0);
        if ( !v77 )
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        v78 = this->mVisited.mNodes.mSize;
        if ( v78 )
        {
          v79 = this->mVisited.mNodes.mData;
          v80 = v77;
          for ( j = 0; v78 > (int)j; ++j )
          {
            if ( v80 )
            {
              v82 = *(_QWORD *)&v79[j].next;
              v80->key = v79[j].key;
              *(_QWORD *)&v80->next = v82;
            }
            ++v80;
          }
        }
        if ( this->mVisited.mNodes.mCapacity > 0 )
        {
          v99 = this->mVisited.mNodes.mData;
          if ( v99 )
            FMOD::MemPool::free(off_286F358->gSystemMemPool, v99, "../../../core_api/src/fmod_memory.h", 244);
        }
        this->mVisited.mNodes.mData = v77;
        this->mVisited.mNodes.mCapacity = v76;
        result = FMOD::DynamicArray<unsigned int,FMOD::ArrayConstruct_Fast_Uninit,FMOD::AlignedAllocator<1>>::resize(
                   &this->mVisited.mBuckets,
                   v76);
        if ( result )
          return result;
        v100 = 0;
        do
          this->mVisited.mBuckets.mData[v100++] = -1;
        while ( v76 > (int)v100 );
        v101 = this->mVisited.mNodes.mSize;
        for ( k = 0; v101 > (int)k; ++k )
        {
          v103 = this->mVisited.mBuckets.mSize;
          v104 = this->mVisited.mNodes.mData;
          v105 = k;
          if ( !v103 )
            return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          for ( m = &this->mVisited.mBuckets.mData[(int)((v103 - 1)
                                                       & (((unsigned __int64)v104[k].key >> 32)
                                                        ^ (unsigned __int64)v104[k].key))]; ; m = &v104[v107].next )
          {
            v107 = (int)*m;
            if ( (_DWORD)v107 == -1 )
              break;
          }
          *m = k;
          this->mVisited.mNodes.mData[v105].next = -1;
        }
      }
      v32 = this->mVisited.mBuckets.mSize;
      if ( !v32 )
        return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      p_next = &this->mVisited.mBuckets.mData[(v32 - 1) & ((unsigned int)mDSP ^ HIDWORD(mDSP))];
      if ( *p_next != -1 )
      {
        v34 = this->mVisited.mNodes.mData;
        v35 = &v34[*p_next];
        if ( mDSP == v35->key )
        {
LABEL_97:
          value = v35->value;
          goto LABEL_52;
        }
        while ( 1 )
        {
          v36 = (int)v35->next;
          if ( (_DWORD)v36 == -1 )
            break;
          v35 = &v34[v36];
          if ( mDSP == v35->key )
            goto LABEL_97;
        }
        p_next = &v35->next;
      }
      mFreeList = this->mVisited.mFreeList;
      if ( mFreeList == -1 )
      {
        v86 = this->mVisited.mNodes.mSize;
        v87 = v86 + 1;
        v88 = abs32(this->mVisited.mNodes.mCapacity);
        if ( v86 + 1 <= v88 )
        {
          v92 = this->mVisited.mNodes.mSize;
        }
        else
        {
          v89 = 4;
          v90 = (int)(float)((float)v88 * 1.5);
          if ( v90 >= v87 )
            v87 = v90;
          if ( v87 > 3 )
            v89 = v87;
          if ( v86 > v89 )
            return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          if ( (unsigned int)(16 * v89 - 1) > 0x3FFFFFFE )
            return FMOD_RESULT::FMOD_ERR_MEMORY_0;
          v112 = this->mVisited.mNodes.mSize;
          v91 = (FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *)FMOD::MemPool::alloc(off_286F358->gSystemMemPool, 16 * v89, "../../../core_api/src/fmod_memory.h", 232, 0, 0);
          v86 = v112;
          if ( !v91 )
            return FMOD_RESULT::FMOD_ERR_MEMORY_0;
          v92 = this->mVisited.mNodes.mSize;
          if ( v92 )
          {
            v93 = this->mVisited.mNodes.mData;
            v94 = v91;
            for ( n = 0; v92 > (int)n; ++n )
            {
              if ( v94 )
              {
                key = v93[n].key;
                *(_QWORD *)&v94->next = *(_QWORD *)&v93[n].next;
                v94->key = key;
              }
              ++v94;
            }
          }
          if ( this->mVisited.mNodes.mCapacity > 0 )
          {
            v97 = this->mVisited.mNodes.mData;
            if ( v97 )
            {
              cpuTimeUsa = v91;
              FMOD::MemPool::free(off_286F358->gSystemMemPool, v97, "../../../core_api/src/fmod_memory.h", 244);
              v92 = this->mVisited.mNodes.mSize;
              v91 = cpuTimeUsa;
              v86 = v112;
            }
          }
          this->mVisited.mNodes.mData = v91;
          this->mVisited.mNodes.mCapacity = v89;
        }
        v98 = &this->mVisited.mNodes.mData[v92];
        if ( v98 )
        {
          v98->key = mDSP;
          v98->next = -1;
          v98->value = 1;
        }
        this->mVisited.mNodes.mSize = v92 + 1;
        *p_next = v86;
      }
      else
      {
        v38 = &this->mVisited.mNodes.mData[mFreeList];
        this->mVisited.mFreeList = v38->next;
        v38->next = -1;
        v38->key = mDSP;
        v38->value = 1;
        *p_next = mFreeList;
      }
      ++this->mVisited.mNodeCount;
      value = 0;
LABEL_52:
      memset(name, 0, 8LL * (_QWORD)&inputbuff);
      result = FMOD::DSPI::getInfo(mDSP, name, 0, 0, 0, 0);
      if ( result )
        return result;
      result = FMOD::DSPI::getDelay(mDSP, &startClock, &endClock, 0);
      if ( result )
        return result;
      numInputs = 0;
      result = FMOD::DSPI::getNumInputsInternal(mDSP, &numInputs, 0, 0);
      if ( result )
        return result;
      mFlags = mDSP->mJob.mFlags;
      if ( (signed int)(headDSP->mJob.mTick - mDSP->mJob.mTick) <= 2 && (mFlags & 0x200) != 0 )
      {
        v115 = 1;
        cpuTimeUs = mDSP->mCPUTimeUs;
      }
      else
      {
        v115 = 0;
        LOWORD(cpuTimeUs) = 0;
      }
      v119 = FMOD_DSP_TYPE_UNKNOWN;
      result = (unsigned int)FMOD::DSPI::getType(mDSP, &v119);
      if ( result )
        return result;
      sendTarget = 0;
      if ( v119 == FMOD_DSP_TYPE_SEND )
        sendTarget = FMOD::DSPSend::getReturn((const FMOD::DSPSend *const)mDSP);
      if ( mConnection )
      {
        hasSidechainConnection = mConnection->mFlags & 1;
        hasSendConnection = (mConnection->mFlags & 4) != 0;
      }
      else
      {
        hasSidechainConnection = 0;
        hasSendConnection = 0;
      }
      mChannelOwner = mDSP->mChannelOwner;
      memset(&metering, 0, sizeof(metering));
      FMOD::DSPI::getMeteringInfo(mDSP, 0, &metering);
      if ( !value )
      {
        v40 = numInputs - 1;
        if ( numInputs - 1 >= 0 )
        {
          do
          {
            inputDSP = 0;
            inputConnection = 0;
            result = FMOD::DSPI::getInputInternal(mDSP, v40, &inputDSP, &inputConnection, 0, 0);
            if ( result )
              return result;
            v41 = this->mRemaining.mSize;
            v42 = this->mRemaining.mCapacity;
            packetNode = (FMOD::ProfileDspRawNode *)inputDSP;
            v43 = v41 + 1;
            v127 = inputConnection;
            v44 = ((v42 >> 31) ^ this->mRemaining.mCapacity) - (v42 >> 31);
            if ( (int)v41 + 1 <= v44 )
            {
              v51 = this->mRemaining.mData;
            }
            else
            {
              v45 = 4;
              v46 = (int)(float)((float)v44 * 1.5);
              if ( v46 >= v43 )
                v43 = v46;
              if ( v43 > 3 )
                v45 = v43;
              if ( (int)v41 > v45 )
                return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
              if ( (unsigned int)(16 * v45 - 1) > 0x3FFFFFFE )
                return FMOD_RESULT::FMOD_ERR_MEMORY_0;
              v47 = (FMOD::ProfileDsp::NodeInfo *)FMOD::MemPool::alloc(
                                                    off_286F358->gSystemMemPool,
                                                    16 * v45,
                                                    "../../../core_api/src/fmod_memory.h",
                                                    232,
                                                    0,
                                                    0);
              v48 = v47;
              if ( !v47 )
                return FMOD_RESULT::FMOD_ERR_MEMORY_0;
              v49 = this->mRemaining.mSize;
              if ( (_DWORD)v49 )
                v48 = (FMOD::ProfileDsp::NodeInfo *)memcpy_0(v47, this->mRemaining.mData, 16 * v49);
              if ( this->mRemaining.mCapacity > 0 )
              {
                v50 = this->mRemaining.mData;
                if ( v50 )
                {
                  v117 = v48;
                  FMOD::MemPool::free(off_286F358->gSystemMemPool, v50, "../../../core_api/src/fmod_memory.h", 244);
                  v48 = v117;
                }
              }
              v41 = this->mRemaining.mSize;
              this->mRemaining.mData = v48;
              v51 = v48;
              this->mRemaining.mCapacity = v45;
            }
            --v40;
            p_mDSP = &v51[v41].mDSP;
            *p_mDSP = packetNode;
            p_mDSP[1] = v127;
            ++this->mRemaining.mSize;
          }
          while ( v40 != -1 );
        }
      }
      packetNode = 0;
      result = FMOD::ProfileDsp::getNextPacketNode(this, &packetNode);
      if ( result )
        return result;
      v53 = packetNode;
      packetNode->numInputs = numInputs;
      v53->channelOwner = (FMOD_UINT64)mChannelOwner;
      v53->id = (FMOD_UINT64)mDSP;
      v53->sendTarget = (FMOD_UINT64)sendTarget;
      v53->exclusiveCPUTimeUS = cpuTimeUs;
      v53->flags = -hasSidechainConnection & 8 | -hasSendConnection & 4 | v115 | -(mFlags & 1) & 2;
      numchannels = metering.numchannels;
      *(_QWORD *)v53->name = 0;
      *(_QWORD *)&v53->name[8] = 0;
      *(_QWORD *)&v53->name[16] = 0;
      *(_QWORD *)&v53->name[24] = 0;
      v53->numChannels = numchannels;
      v55 = packetNode->name;
      if ( this->mShowMode == FMOD_PROFILE_DSP_SHOW_DELAYS )
        FMOD_snprintf(v55, 32, "%s [%llu %llu]", name, startClock >> 20, endClock >> 20);
      else
        FMOD_snprintf(v55, 32, "%s", name);
      v56 = packetNode;
      peaklevel = metering.peaklevel;
      v58 = 0;
      *(_QWORD *)packetNode->peakLevel = 0;
      *(_QWORD *)&v56->peakLevel[8] = 0;
      *(_QWORD *)&v56->peakLevel[16] = 0;
      for ( *(_QWORD *)&v56->peakLevel[24] = 0; metering.numchannels > v58; v60->peakLevel[v59] = v61 )
      {
        v60 = packetNode;
        v61 = -80;
        if ( *peaklevel > 0.0 )
        {
          v62 = log10f(*peaklevel);
          v60 = packetNode;
          v63 = (int)(float)(v62 * 20.0);
          if ( v63 >= -80 )
          {
            v61 = 10;
            if ( v63 <= 10 )
              v61 = (int)(float)(v62 * 20.0);
          }
          else
          {
            v61 = -80;
          }
        }
        v59 = v58++;
        ++peaklevel;
      }
      v64 = this->mRemaining.mSize;
      if ( !v64 )
        break;
      v65 = v64;
      v66 = v64 - 1;
      v67 = &this->mRemaining.mData[v65 - 1];
      mDSP = v67->mDSP;
      mConnection = v67->mConnection;
      if ( v66 >= 0 )
      {
        mNodeCount = this->mVisited.mNodeCount;
        this->mRemaining.mSize = v66;
        if ( mNodeCount != -1 )
          continue;
      }
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    }
  }
  mPacketHeader = this->mPacketHeader;
  v69 = 20;
  if ( ((unsigned __int8)mPacketHeader & 1) != 0 )
  {
    LOBYTE(mPacketHeader->hdr.size) = 0;
    mPacketHeader = (FMOD::ProfilePacketDspNetwork *)((char *)mPacketHeader + 1);
    LOBYTE(v69) = 19;
  }
  if ( ((unsigned __int8)mPacketHeader & 2) != 0 )
  {
    LOWORD(mPacketHeader->hdr.size) = 0;
    mPacketHeader = (FMOD::ProfilePacketDspNetwork *)((char *)mPacketHeader + 2);
    v69 -= 2;
  }
  for ( ii = v69 >> 2; ii; --ii )
  {
    mPacketHeader->hdr.size = 0;
    mPacketHeader = (FMOD::ProfilePacketDspNetwork *)((char *)mPacketHeader + 4);
  }
  if ( (v69 & 2) != 0 )
  {
    LOWORD(mPacketHeader->hdr.size) = 0;
    mPacketHeader = (FMOD::ProfilePacketDspNetwork *)((char *)mPacketHeader + 2);
  }
  if ( (v69 & 1) != 0 )
    LOBYTE(mPacketHeader->hdr.size) = 0;
  v71 = 94 * this->mNumPacketNodes;
  v72 = this->mPacketHeader;
  v72->hdr.type = 1;
  v72->hdr.size = v71 + 20;
  this->mPacketHeader->hdr.version = 6;
  v73 = this->mSystem;
  v74 = this->mPacketHeader;
  mDSPSampleRate = v73->mDSPSampleRate;
  LODWORD(v73) = v73->mDSPBlockSize;
  v74->sampleRate = mDSPSampleRate;
  v74->blockSize = (int)v73;
  this->mPreparedNode = &v74->hdr;
  return FMOD_RESULT::FMOD_OK_0;
}


