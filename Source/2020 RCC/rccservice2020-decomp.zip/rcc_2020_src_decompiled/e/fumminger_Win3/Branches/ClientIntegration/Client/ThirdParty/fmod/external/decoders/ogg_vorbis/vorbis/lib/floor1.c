// Address: 0x226e330 | Name: icomp
int __fastcall icomp(const void *a, const void *b)
{
  return **(_DWORD **)a - **(_DWORD **)b;
}


// Address: 0x226e340 | Name: FMOD_floor1_inverse2
int __fastcall FMOD_floor1_inverse2(vorbis_block_0 *vb, vorbis_look_floor *in, void *memo, float *out)
{
  int v5; // edi
  int v6; // eax
  int *v7; // r8
  int v8; // r14d
  int *v9; // r13
  int v10; // esi
  __int64 v11; // rax
  int v12; // ebp
  int v13; // ebp
  int v14; // r9d
  unsigned int v15; // r10d
  int v16; // r15d
  int v17; // eax
  int v18; // ecx
  unsigned int v19; // r10d
  int v20; // r11d
  float *v21; // rdx
  __int64 v22; // r11
  int v23; // ecx
  float v24; // xmm0_4
  float v25; // xmm1_4
  float *v26; // rax
  float v27; // xmm0_4
  vorbis_info_floor1 *info; // [rsp+8h] [rbp-50h]
  int n; // [rsp+10h] [rbp-48h]
  int v32; // [rsp+14h] [rbp-44h]
  float *v33; // [rsp+18h] [rbp-40h]

  info = (vorbis_info_floor1 *)*((_QWORD *)in + 130);
  n = *(_DWORD *)(*(_QWORD *)(*(_QWORD *)vb->vd + 32LL) + 4LL * vb->W) / 2;
  if ( memo )
  {
    v32 = *(_DWORD *)(*((_QWORD *)in + 130) + 832LL);
    v5 = v32 * *(_DWORD *)memo;
    v6 = *((_DWORD *)in + 256);
    if ( v6 <= 1 )
    {
      v8 = 0;
    }
    else
    {
      v7 = (int *)((char *)in + 4);
      v8 = 0;
      v9 = (int *)((char *)in + 4 * (unsigned int)(v6 - 2) + 8);
      v10 = 0;
      v33 = out + 1;
      do
      {
        while ( 1 )
        {
          v11 = *v7;
          v12 = *((_DWORD *)memo + v11);
          if ( v12 == (v12 & 0x7FFF) )
            break;
          if ( ++v7 == v9 )
            goto LABEL_19;
        }
        v13 = v32 * v12;
        v8 = info->postlist[v11];
        v14 = v8 - v10;
        v15 = abs32(v13 - v5);
        v16 = (v13 - v5) / (v8 - v10);
        v17 = v16 - 1;
        if ( v13 - v5 >= 0 )
          v17 = v16 + 1;
        v18 = n;
        v19 = v15 - abs32(v16 * v14);
        if ( v8 <= n )
          v18 = v8;
        if ( v18 > v10 )
          out[v10] = out[v10] * FLOOR1_fromdB_LOOKUP[v5];
        v20 = v10 + 1;
        if ( v18 > v10 + 1 )
        {
          v21 = &out[v20];
          v22 = (unsigned int)(-2 - v10 + v18) + (__int64)v20;
          v23 = 0;
          do
          {
            v23 += v19;
            if ( v14 <= v23 )
            {
              v23 -= v14;
              v5 += v17;
            }
            else
            {
              v5 += v16;
            }
            v24 = *v21++;
            *(v21 - 1) = v24 * FLOOR1_fromdB_LOOKUP[v5];
          }
          while ( v21 != &v33[v22] );
        }
        ++v7;
        v5 = v13;
        v10 = v8;
      }
      while ( v7 != v9 );
    }
LABEL_19:
    if ( n > v8 )
    {
      v25 = FLOOR1_fromdB_LOOKUP[v5];
      v26 = &out[v8];
      do
      {
        v27 = *v26++;
        *(v26 - 1) = v27 * v25;
      }
      while ( v26 != &out[(unsigned int)(n - 1 - v8) + 1 + (__int64)v8] );
    }
    return 1;
  }
  else
  {
    memset(out, 0, 4LL * n);
    return 0;
  }
}


// Address: 0x226e580 | Name: FMOD_floor1_inverse1
void *__fastcall FMOD_floor1_inverse1(void *context, vorbis_block_0 *vb, vorbis_look_floor *in)
{
  int *v3; // r15
  int *v4; // r12
  int v5; // esi
  unsigned int v6; // eax
  int v7; // esi
  unsigned int v8; // eax
  __int64 v9; // r12
  int *v10; // rax
  int v11; // ecx
  int v12; // ebx
  ogg_int32_t v13; // r13d
  int v14; // ebx
  __int64 v15; // r12
  ogg_int32_t *v16; // r14
  ogg_int32_t *v17; // rbp
  ogg_int32_t v18; // eax
  ogg_int32_t v19; // eax
  __int64 v20; // rax
  __int64 v21; // rsi
  int *v22; // r8
  int v23; // ecx
  int v24; // edi
  int v25; // ecx
  int v26; // eax
  __int64 v27; // rax
  __int64 v28; // r9
  int v29; // edi
  int v30; // ecx
  int v31; // edx
  int v32; // eax
  int v33; // eax
  oggpack_buffer *b; // [rsp+0h] [rbp-78h]
  codebook_0 *books; // [rsp+8h] [rbp-70h]
  int csubbits; // [rsp+10h] [rbp-68h]
  int csubbitsa; // [rsp+10h] [rbp-68h]
  int csubbitsb; // [rsp+10h] [rbp-68h]
  int csubbitsc; // [rsp+10h] [rbp-68h]
  int cdim; // [rsp+14h] [rbp-64h]
  int *p_class; // [rsp+18h] [rbp-60h]
  int j; // [rsp+20h] [rbp-58h]
  int i; // [rsp+24h] [rbp-54h]
  _DWORD *v46; // [rsp+30h] [rbp-48h]
  int *fit_value; // [rsp+38h] [rbp-40h]

  v3 = (int *)*((_QWORD *)in + 130);
  books = *(codebook_0 **)(*(_QWORD *)(*(_QWORD *)vb->vd + 32LL) + 4896LL);
  b = (oggpack_buffer *)&vb->opb;
  if ( FMOD_oggpack_read((oggpack_buffer *)&vb->opb, 1) != 1 )
    return 0;
  v4 = (int *)FMOD_vorbis_block_alloc(context, vb, 4 * *((_DWORD *)in + 256));
  v5 = 0;
  csubbits = *((_DWORD *)in + 258);
  v6 = csubbits - 1;
  if ( csubbits != 1 )
  {
    do
    {
      ++v5;
      v6 >>= 1;
    }
    while ( v6 );
  }
  *v4 = FMOD_oggpack_read(b, v5);
  v7 = 0;
  csubbitsa = *((_DWORD *)in + 258);
  v8 = csubbitsa - 1;
  if ( csubbitsa != 1 )
  {
    do
    {
      ++v7;
      v8 >>= 1;
    }
    while ( v8 );
  }
  v4[1] = FMOD_oggpack_read(b, v7);
  j = 2;
  i = 0;
  p_class = v3 + 1;
  v46 = v4 + 1;
  if ( *v3 > 0 )
  {
    fit_value = v4;
    do
    {
      v9 = *p_class;
      v10 = &v3[v9];
      v11 = v10[48];
      cdim = v10[32];
      v12 = 1 << v11;
      if ( v11 )
      {
        csubbitsc = v10[48];
        v13 = FMOD_vorbis_book_decode(&books[v10[64]], b);
        v11 = csubbitsc;
        if ( v13 == -1 )
          return 0;
      }
      else
      {
        v13 = 0;
      }
      if ( cdim > 0 )
      {
        v14 = v12 - 1;
        v15 = 8 * v9;
        v16 = &fit_value[j];
        v17 = &v46[(unsigned int)(cdim - 1) + (__int64)j];
        do
        {
          while ( 1 )
          {
            v19 = v13;
            v13 >>= v11;
            v20 = v3[(v14 & v19) + 80 + v15];
            if ( (int)v20 >= 0 )
              break;
            *v16++ = 0;
            if ( v16 == v17 )
              goto LABEL_16;
          }
          csubbitsb = v11;
          v18 = FMOD_vorbis_book_decode(&books[v20], b);
          *v16 = v18;
          v11 = csubbitsb;
          if ( v18 == -1 )
            return 0;
          ++v16;
        }
        while ( v16 != v17 );
      }
LABEL_16:
      ++i;
      ++p_class;
      j += cdim;
    }
    while ( *v3 > i );
    v4 = fit_value;
  }
  if ( *((int *)in + 256) > 2 )
  {
    v21 = 0;
    v22 = (int *)((char *)in + 520);
    do
    {
      v27 = v22[63];
      v28 = *v22;
      v29 = v4[v27] & 0x7FFF;
      v30 = (v4[v28] & 0x7FFF) - v29;
      LODWORD(v27) = (int)((v3[v21 + 211] - v3[v27 + 209]) * abs32(v30)) / (v3[v28 + 209] - v3[v27 + 209]);
      v31 = v29 - v27;
      v32 = v29 + v27;
      if ( v30 >= 0 )
        v31 = v32;
      v33 = v4[v21 + 2];
      if ( v33 )
      {
        v23 = *((_DWORD *)in + 258) - v31;
        v24 = v31;
        if ( v23 <= v31 )
          v24 = *((_DWORD *)in + 258) - v31;
        if ( 2 * v24 > v33 )
        {
          v25 = v33 >> 1;
          if ( (v33 & 1) != 0 )
            v25 = -((v33 + 1) >> 1);
        }
        else if ( v23 <= v31 )
        {
          v25 = ~(v33 - v23);
        }
        else
        {
          v25 = v33 - v31;
        }
        v4[v21 + 2] = v25 + v31;
        v4[v22[63]] &= 0x7FFFu;
        v4[*v22] &= 0x7FFFu;
      }
      else
      {
        BYTE1(v31) |= 0x80u;
        v4[v21 + 2] = v31;
      }
      v26 = v21 + 3;
      ++v22;
      ++v21;
    }
    while ( *((_DWORD *)in + 256) > v26 );
  }
  return v4;
}


// Address: 0x226e8f0 | Name: FMOD_floor1_free_look
void __fastcall FMOD_floor1_free_look(void *context, vorbis_look_floor *i)
{
  _DWORD *v3; // rdi
  unsigned int v4; // r8d
  __int64 v5; // rcx
  _DWORD *v6; // rdi

  if ( i )
  {
    v3 = i;
    v4 = 1064;
    if ( ((unsigned __int8)i & 1) != 0 )
    {
      *(_BYTE *)i = 0;
      v3 = (char *)i + 1;
      LOBYTE(v4) = 39;
    }
    if ( ((unsigned __int8)v3 & 2) != 0 )
    {
      v3 = (_DWORD *)((char *)v3 + 2);
      v4 -= 2;
      *((_WORD *)v3 - 1) = 0;
    }
    if ( ((unsigned __int8)v3 & 4) != 0 )
    {
      *v3 = 0;
      v4 -= 4;
      ++v3;
    }
    v5 = v4 >> 3;
    memset(v3, 0, 8 * v5);
    v6 = &v3[2 * v5];
    if ( (v4 & 4) != 0 )
    {
      *v6++ = 0;
      if ( (v4 & 2) == 0 )
      {
LABEL_10:
        if ( (v4 & 1) == 0 )
        {
LABEL_11:
          FMOD_OggVorbis_Free(context, i);
          return;
        }
        goto LABEL_12;
      }
    }
    else if ( (v4 & 2) == 0 )
    {
      goto LABEL_10;
    }
    v6 = (_DWORD *)((char *)v6 + 2);
    *((_WORD *)v6 - 1) = 0;
    if ( (v4 & 1) == 0 )
      goto LABEL_11;
LABEL_12:
    *(_BYTE *)v6 = 0;
    FMOD_OggVorbis_Free(context, i);
  }
}


// Address: 0x226e9e0 | Name: FMOD_floor1_free_info
void __fastcall FMOD_floor1_free_info(void *context, vorbis_info_floor *i)
{
  _DWORD *v3; // rdi
  unsigned int v4; // r8d
  __int64 v5; // rcx
  _DWORD *v6; // rdi

  if ( i )
  {
    v3 = i;
    v4 = 1120;
    if ( ((unsigned __int8)i & 1) != 0 )
    {
      *(_BYTE *)i = 0;
      v3 = (char *)i + 1;
      LOBYTE(v4) = 95;
    }
    if ( ((unsigned __int8)v3 & 2) != 0 )
    {
      v3 = (_DWORD *)((char *)v3 + 2);
      v4 -= 2;
      *((_WORD *)v3 - 1) = 0;
    }
    if ( ((unsigned __int8)v3 & 4) != 0 )
    {
      *v3 = 0;
      v4 -= 4;
      ++v3;
    }
    v5 = v4 >> 3;
    memset(v3, 0, 8 * v5);
    v6 = &v3[2 * v5];
    if ( (v4 & 4) != 0 )
    {
      *v6++ = 0;
      if ( (v4 & 2) == 0 )
      {
LABEL_10:
        if ( (v4 & 1) == 0 )
        {
LABEL_11:
          FMOD_OggVorbis_Free(context, i);
          return;
        }
        goto LABEL_12;
      }
    }
    else if ( (v4 & 2) == 0 )
    {
      goto LABEL_10;
    }
    v6 = (_DWORD *)((char *)v6 + 2);
    *((_WORD *)v6 - 1) = 0;
    if ( (v4 & 1) == 0 )
      goto LABEL_11;
LABEL_12:
    *(_BYTE *)v6 = 0;
    FMOD_OggVorbis_Free(context, i);
  }
}


// Address: 0x226ead0 | Name: FMOD_floor1_look
vorbis_look_floor *__fastcall FMOD_floor1_look(void *context, vorbis_dsp_state_0 *vd, vorbis_info_floor *in)
{
  _DWORD *v4; // rax
  _DWORD *v5; // rbp
  int v6; // edx
  char *v7; // rax
  int v8; // r12d
  char *v9; // rcx
  __int64 v10; // rdx
  int v11; // r13d
  size_t v12; // rsi
  __int64 v13; // rax
  int *v14; // rdx
  __int64 v15; // rdx
  __int64 v16; // rax
  int v17; // eax
  int v18; // r15d
  __int64 v19; // r11
  int v20; // r14d
  int v21; // edi
  int v22; // r9d
  __int64 v23; // rcx
  int v24; // r8d
  int v25; // edx
  int v26; // eax
  int v27; // esi
  bool v28; // r13
  bool v29; // r13
  int *sortpointer[65]; // [rsp+0h] [rbp-248h] BYREF

  v4 = FMOD_OggVorbis_Calloc(context, 1, 1064);
  v5 = v4;
  if ( !v4 )
    return 0;
  v6 = *(_DWORD *)in;
  *((_QWORD *)v4 + 130) = in;
  v4[257] = *((_DWORD *)in + 210);
  if ( v6 <= 0 )
  {
    v4[256] = 2;
    v12 = 2;
    v8 = 0;
    v11 = 2;
LABEL_6:
    v13 = 0;
    v14 = (int *)((char *)in + 836);
    do
      sortpointer[v13++] = v14++;
    while ( v11 > (int)v13 );
    qsort(sortpointer, v12, 8u, icomp);
    v15 = 0;
    do
    {
      v5[v15] = ((char *)sortpointer[v15] - ((_BYTE *)in + 836)) >> 2;
      ++v15;
    }
    while ( v11 > (int)v15 );
    v16 = 0;
    do
    {
      v5[v5[v16] + 65] = v16;
      ++v16;
    }
    while ( v11 > (int)v16 );
    goto LABEL_12;
  }
  v7 = (char *)in + 4;
  v8 = 0;
  v9 = (char *)in + 4 * (unsigned int)(v6 - 1) + 8;
  do
  {
    v10 = *(int *)v7;
    v7 += 4;
    v8 += *((_DWORD *)in + v10 + 32);
  }
  while ( v7 != v9 );
  v11 = v8 + 2;
  v5[256] = v8 + 2;
  v12 = v8 + 2;
  if ( v8 + 2 > 0 )
    goto LABEL_6;
  qsort(sortpointer, v12, 8u, icomp);
LABEL_12:
  v17 = *((_DWORD *)in + 208);
  if ( v17 == 2 )
  {
    v5[258] = 128;
  }
  else if ( v17 <= 2 )
  {
    if ( v17 == 1 )
      v5[258] = 256;
  }
  else if ( v17 == 3 )
  {
    v5[258] = 86;
  }
  else if ( v17 == 4 )
  {
    v5[258] = 64;
  }
  if ( v8 > 0 )
  {
    v18 = v5[257];
    v19 = 2;
    v20 = 0;
    do
    {
      v21 = *((_DWORD *)in + v19 + 209);
      ++v20;
      v22 = v18;
      v23 = 0;
      v24 = 0;
      v25 = 1;
      v26 = 0;
      do
      {
        v27 = *((_DWORD *)in + v23 + 209);
        if ( v27 < v21 )
        {
          v28 = v27 > v24;
          if ( v27 > v24 )
            v24 = *((_DWORD *)in + v23 + 209);
          if ( v28 )
            v26 = v23;
        }
        if ( v27 > v21 )
        {
          v29 = v27 < v22;
          if ( v27 < v22 )
            v22 = *((_DWORD *)in + v23 + 209);
          if ( v29 )
            v25 = v23;
        }
        ++v23;
      }
      while ( v23 != v19 );
      v5[v23 + 191] = v26;
      v5[v23 + 128] = v25;
      v19 = v23 + 1;
    }
    while ( v20 != v8 );
  }
  return v5;
}


// Address: 0x226ed20 | Name: FMOD_floor1_unpack
vorbis_info_floor *__fastcall FMOD_floor1_unpack(void *context, vorbis_info_0 *vi, oggpack_buffer_0 *opb)
{
  int *v4; // r12
  int v5; // r15d
  ogg_int32_t v6; // eax
  ogg_int32_t *v7; // r14
  int v8; // ebx
  ogg_int32_t v9; // eax
  ogg_int32_t *v11; // r15
  ogg_int32_t v12; // eax
  ogg_int32_t v13; // eax
  int v14; // r14d
  int *i; // r13
  int v16; // eax
  ogg_int32_t v17; // ebx
  int v18; // r15d
  int v19; // r14d
  int v20; // r13d
  ogg_int32_t v21; // eax
  int v22; // ebx
  size_t v23; // rsi
  int *v24; // rdx
  __int64 v25; // rax
  int **v26; // rbp
  int v27; // eax
  int **v28; // rdx
  int v29; // eax
  _DWORD *codec_setup; // [rsp+0h] [rbp-268h]
  int v31; // [rsp+0h] [rbp-268h]
  int *v32; // [rsp+10h] [rbp-258h]
  int v33; // [rsp+10h] [rbp-258h]
  int j; // [rsp+18h] [rbp-250h]
  int *ja; // [rsp+18h] [rbp-250h]
  int *sortpointer[65]; // [rsp+20h] [rbp-248h] BYREF

  codec_setup = vi->codec_setup;
  v4 = (int *)FMOD_OggVorbis_Calloc(context, 1, 1120);
  if ( !v4 )
    goto err_out;
  v5 = 0;
  v6 = FMOD_oggpack_read((oggpack_buffer *)opb, 5);
  *v4 = v6;
  v7 = v4 + 1;
  v8 = -1;
  if ( v6 > 0 )
  {
    while ( 1 )
    {
      v9 = FMOD_oggpack_read((oggpack_buffer *)opb, 4);
      *v7 = v9;
      if ( v9 < 0 )
        goto err_out;
      if ( v8 < v9 )
        v8 = v9;
      ++v5;
      ++v7;
      if ( *v4 <= v5 )
      {
        v11 = v4 + 48;
        j = 0;
        v32 = v4 + 80;
        while ( 1 )
        {
          *(v11 - 16) = FMOD_oggpack_read((oggpack_buffer *)opb, 3) + 1;
          v12 = FMOD_oggpack_read((oggpack_buffer *)opb, 2);
          *v11 = v12;
          if ( v12 < 0 )
            goto err_out;
          if ( v12 )
          {
            v13 = FMOD_oggpack_read((oggpack_buffer *)opb, 8);
            v11[16] = v13;
          }
          else
          {
            v13 = v11[16];
          }
          if ( v13 < 0 || v13 >= codec_setup[6] )
            goto err_out;
          v14 = 0;
          for ( i = v32; 1 << *v11 > v14; ++i )
          {
            v16 = FMOD_oggpack_read((oggpack_buffer *)opb, 8) - 1;
            *i = v16;
            if ( v16 < -1 || v16 >= codec_setup[6] )
              goto err_out;
            ++v14;
          }
          ++j;
          ++v11;
          v32 += 8;
          if ( j > v8 )
            goto LABEL_22;
        }
      }
    }
  }
LABEL_22:
  v4[208] = FMOD_oggpack_read((oggpack_buffer *)opb, 2) + 1;
  v17 = FMOD_oggpack_read((oggpack_buffer *)opb, 4);
  if ( v17 < 0 )
  {
err_out:
    FMOD_floor1_free_info(context, v4);
    return 0;
  }
  if ( *v4 > 0 )
  {
    v18 = 1 << v17;
    v31 = 0;
    v19 = 0;
    ja = v4 + 1;
    v33 = 0;
    do
    {
      v20 = v4[*ja + 32] + v31;
      v31 = v20;
      if ( v20 > v19 )
      {
        do
        {
          v21 = FMOD_oggpack_read((oggpack_buffer *)opb, v17);
          v4[v19 + 211] = v21;
          if ( v21 < 0 || v21 >= v18 )
            goto err_out;
        }
        while ( ++v19 != v20 );
      }
      ++v33;
      ++ja;
    }
    while ( *v4 > v33 );
    v4[209] = 0;
    v22 = v20 + 1;
    v4[210] = v18;
    v23 = v20 + 2;
    if ( v20 + 1 >= 0 )
      goto LABEL_34;
    qsort(sortpointer, v23, 8u, icomp);
    return v4;
  }
  v4[209] = 0;
  v29 = 1 << v17;
  v23 = 2;
  v22 = 1;
  v4[210] = v29;
LABEL_34:
  v24 = v4 + 209;
  v25 = 0;
  do
    sortpointer[v25++] = v24++;
  while ( v22 >= (int)v25 );
  qsort(sortpointer, v23, 8u, icomp);
  if ( v22 > 0 )
  {
    if ( *sortpointer[0] != *sortpointer[1] )
    {
      v26 = &sortpointer[1];
      v27 = 1;
      while ( ++v27 <= v22 )
      {
        v28 = v26++;
        if ( **v28 == *v28[1] )
          goto err_out;
      }
      return v4;
    }
    goto err_out;
  }
  return v4;
}


