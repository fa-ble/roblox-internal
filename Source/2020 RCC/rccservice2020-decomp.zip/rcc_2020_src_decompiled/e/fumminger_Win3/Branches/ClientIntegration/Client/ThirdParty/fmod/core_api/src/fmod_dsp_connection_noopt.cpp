// Address: 0x21c2420 | Name: FMOD_DSP_Connection_MixMonoTo51_NoOpt
void __fastcall FMOD_DSP_Connection_MixMonoTo51_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float v7; // xmm0_4
  float v8; // xmm1_4
  unsigned int v9; // eax
  float v10; // xmm2_4
  float v11; // xmm3_4
  float v12; // xmm4_4
  float v13; // xmm5_4
  float *v14; // rcx
  __int64 v15; // r8
  float *v16; // rax
  float v17; // xmm6_4
  float v18; // xmm6_4
  float v19; // xmm6_4
  float v20; // xmm6_4
  unsigned int v21; // edx
  float *v22; // rdx
  float v23; // xmm6_4
  float *v24; // rcx
  __int64 v25; // r8
  float *v26; // rax
  float v27; // xmm6_4
  float v28; // xmm7_4
  float v29; // xmm6_4
  float v30; // xmm6_4
  float v31; // xmm7_4
  float v32; // xmm6_4
  float v33; // xmm6_4
  float v34; // xmm7_4
  float v35; // xmm6_4
  float v36; // xmm6_4
  float v37; // xmm7_4
  float v38; // xmm6_4
  unsigned int v39; // edx
  float *v40; // rdx
  float v41; // xmm6_4
  float v42; // xmm7_4
  float v43; // xmm6_4

  v7 = *mixmatrix;
  v8 = mixmatrix[32];
  v9 = length >> 2;
  v10 = mixmatrix[64];
  v11 = mixmatrix[96];
  v12 = mixmatrix[128];
  v13 = mixmatrix[160];
  if ( writedontmix )
  {
    if ( v9 )
    {
      v14 = inbuffer;
      v15 = v9 - 1 + 1LL;
      v16 = &outbuffer[24 * v15];
      do
      {
        v17 = *v14;
        outbuffer += 24;
        v14 += 4;
        *(outbuffer - 24) = v17 * v7;
        *(outbuffer - 23) = v8 * v17;
        *(outbuffer - 22) = v10 * v17;
        *(outbuffer - 21) = v11 * v17;
        *(outbuffer - 20) = v12 * v17;
        *(outbuffer - 19) = v17 * v13;
        v18 = *(v14 - 3);
        *(outbuffer - 18) = v18 * v7;
        *(outbuffer - 17) = v8 * v18;
        *(outbuffer - 16) = v10 * v18;
        *(outbuffer - 15) = v11 * v18;
        *(outbuffer - 14) = v12 * v18;
        *(outbuffer - 13) = v18 * v13;
        v19 = *(v14 - 2);
        *(outbuffer - 12) = v19 * v7;
        *(outbuffer - 11) = v8 * v19;
        *(outbuffer - 10) = v10 * v19;
        *(outbuffer - 9) = v11 * v19;
        *(outbuffer - 8) = v12 * v19;
        *(outbuffer - 7) = v19 * v13;
        v20 = *(v14 - 1);
        *(outbuffer - 6) = v20 * v7;
        *(outbuffer - 5) = v8 * v20;
        *(outbuffer - 4) = v10 * v20;
        *(outbuffer - 3) = v11 * v20;
        *(outbuffer - 2) = v12 * v20;
        *(outbuffer - 1) = v20 * v13;
      }
      while ( outbuffer != v16 );
      inbuffer += 4 * v15;
    }
    else
    {
      v16 = outbuffer;
    }
    v21 = length & 3;
    if ( v21 )
    {
      v22 = &v16[6 * v21];
      do
      {
        v23 = *inbuffer;
        v16 += 6;
        ++inbuffer;
        *(v16 - 6) = v23 * v7;
        *(v16 - 5) = v8 * v23;
        *(v16 - 4) = v10 * v23;
        *(v16 - 3) = v11 * v23;
        *(v16 - 2) = v12 * v23;
        *(v16 - 1) = v23 * v13;
      }
      while ( v16 != v22 );
    }
  }
  else
  {
    if ( v9 )
    {
      v24 = inbuffer;
      v25 = v9 - 1 + 1LL;
      v26 = &outbuffer[24 * v25];
      do
      {
        v27 = *v24;
        outbuffer += 24;
        v24 += 4;
        *(outbuffer - 24) = (float)(v27 * v7) + *(outbuffer - 24);
        *(outbuffer - 23) = (float)(v8 * v27) + *(outbuffer - 23);
        *(outbuffer - 22) = (float)(v10 * v27) + *(outbuffer - 22);
        *(outbuffer - 21) = (float)(v11 * v27) + *(outbuffer - 21);
        v28 = v12 * v27;
        v29 = (float)(v27 * v13) + *(outbuffer - 19);
        *(outbuffer - 20) = v28 + *(outbuffer - 20);
        *(outbuffer - 19) = v29;
        v30 = *(v24 - 3);
        *(outbuffer - 18) = (float)(v30 * v7) + *(outbuffer - 18);
        *(outbuffer - 17) = (float)(v8 * v30) + *(outbuffer - 17);
        *(outbuffer - 16) = (float)(v10 * v30) + *(outbuffer - 16);
        *(outbuffer - 15) = (float)(v11 * v30) + *(outbuffer - 15);
        v31 = v12 * v30;
        v32 = (float)(v30 * v13) + *(outbuffer - 13);
        *(outbuffer - 14) = v31 + *(outbuffer - 14);
        *(outbuffer - 13) = v32;
        v33 = *(v24 - 2);
        *(outbuffer - 12) = (float)(v33 * v7) + *(outbuffer - 12);
        *(outbuffer - 11) = (float)(v8 * v33) + *(outbuffer - 11);
        *(outbuffer - 10) = (float)(v10 * v33) + *(outbuffer - 10);
        *(outbuffer - 9) = (float)(v11 * v33) + *(outbuffer - 9);
        v34 = v12 * v33;
        v35 = (float)(v33 * v13) + *(outbuffer - 7);
        *(outbuffer - 8) = v34 + *(outbuffer - 8);
        *(outbuffer - 7) = v35;
        v36 = *(v24 - 1);
        *(outbuffer - 6) = (float)(v36 * v7) + *(outbuffer - 6);
        *(outbuffer - 5) = (float)(v8 * v36) + *(outbuffer - 5);
        *(outbuffer - 4) = (float)(v10 * v36) + *(outbuffer - 4);
        *(outbuffer - 3) = (float)(v11 * v36) + *(outbuffer - 3);
        v37 = (float)(v12 * v36) + *(outbuffer - 2);
        v38 = (float)(v36 * v13) + *(outbuffer - 1);
        *(outbuffer - 2) = v37;
        *(outbuffer - 1) = v38;
      }
      while ( outbuffer != v26 );
      inbuffer += 4 * v25;
    }
    else
    {
      v26 = outbuffer;
    }
    v39 = length & 3;
    if ( v39 )
    {
      v40 = &v26[6 * v39];
      do
      {
        v41 = *inbuffer;
        v26 += 6;
        ++inbuffer;
        *(v26 - 6) = (float)(v41 * v7) + *(v26 - 6);
        *(v26 - 5) = (float)(v8 * v41) + *(v26 - 5);
        *(v26 - 4) = (float)(v10 * v41) + *(v26 - 4);
        *(v26 - 3) = (float)(v11 * v41) + *(v26 - 3);
        v42 = (float)(v12 * v41) + *(v26 - 2);
        v43 = (float)(v41 * v13) + *(v26 - 1);
        *(v26 - 2) = v42;
        *(v26 - 1) = v43;
      }
      while ( v26 != v40 );
    }
  }
}


// Address: 0x21c28b0 | Name: FMOD_DSP_Connection_MixStereoTo51_NoOpt
void __fastcall FMOD_DSP_Connection_MixStereoTo51_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float *v8; // rbp
  float *v9; // rbx
  float v10; // xmm4_4
  float v11; // xmm11_4
  float v12; // xmm5_4
  float v13; // xmm6_4
  float v14; // xmm8_4
  float v15; // xmm12_4
  float v16; // xmm14_4
  float v17; // xmm10_4
  float v18; // xmm7_4
  float v19; // xmm9_4
  float v20; // xmm15_4
  float v21; // xmm13_4
  __int64 v22; // rdx
  float *v23; // rax
  float v24; // xmm0_4
  unsigned int v25; // r12d
  float *v26; // rax
  float v27; // xmm0_4
  float *v28; // rcx
  __int64 v29; // rdx
  float *v30; // rax
  float v31; // xmm1_4
  float v32; // xmm0_4
  float v33; // xmm2_4
  float v34; // xmm1_4
  float v35; // xmm0_4
  float v36; // xmm1_4
  float v37; // xmm3_4
  float v38; // xmm2_4
  float *v39; // rcx
  __int64 v40; // rdx
  float *v41; // rax
  float v42; // xmm1_4
  float v43; // xmm0_4
  float v44; // xmm2_4
  float v45; // xmm1_4
  float v46; // xmm0_4
  float v47; // xmm1_4
  float v48; // xmm1_4
  float v49; // xmm2_4
  float v50; // xmm1_4
  float v51; // xmm1_4
  float v52; // xmm0_4
  float v53; // xmm5_4
  float v54; // xmm6_4
  float v55; // xmm8_4
  float v56; // xmm12_4
  float v57; // xmm1_4
  float l11; // [rsp+Ch] [rbp-1Ch]

  v8 = inbuffer;
  v9 = outbuffer;
  v10 = mixmatrix[1];
  v11 = *mixmatrix;
  v12 = mixmatrix[32];
  v13 = mixmatrix[64];
  v14 = mixmatrix[96];
  v15 = mixmatrix[128];
  v16 = mixmatrix[160];
  v17 = mixmatrix[33];
  v18 = mixmatrix[65];
  v19 = mixmatrix[97];
  v20 = mixmatrix[129];
  v21 = mixmatrix[161];
  if ( fabs(v10) >= 0.000019999999
    || fabs(v12) >= 0.000019999999
    || fabs(v13) >= 0.000019999999
    || fabs(v18) >= 0.000019999999
    || fabs(v14) >= 0.000019999999
    || fabs(v19) >= 0.000019999999
    || fabs(v15) >= 0.000019999999
    || fabs(v20) >= 0.000019999999
    || fabs(v16) >= 0.000019999999
    || fabs(v21) >= 0.000019999999 )
  {
    if ( writedontmix )
    {
      if ( length >> 1 )
      {
        v28 = inbuffer;
        v29 = (length >> 1) - 1 + 1LL;
        v30 = &outbuffer[12 * v29];
        do
        {
          v31 = *v28;
          v9 += 12;
          v28 += 4;
          v32 = *(v28 - 3);
          *(v9 - 12) = (float)(v31 * v11) + (float)(v32 * v10);
          *(v9 - 11) = (float)(v12 * v31) + (float)(v17 * v32);
          *(v9 - 10) = (float)(v13 * v31) + (float)(v18 * v32);
          *(v9 - 9) = (float)(v14 * v31) + (float)(v19 * v32);
          v33 = (float)(v15 * v31) + (float)(v20 * v32);
          v34 = (float)(v31 * v16) + (float)(v32 * v21);
          v35 = *(v28 - 1);
          *(v9 - 8) = v33;
          *(v9 - 7) = v34;
          v36 = *(v28 - 2);
          *(v9 - 6) = (float)(v36 * v11) + (float)(v35 * v10);
          *(v9 - 5) = (float)(v12 * v36) + (float)(v17 * v35);
          *(v9 - 4) = (float)(v13 * v36) + (float)(v18 * v35);
          *(v9 - 3) = (float)(v14 * v36) + (float)(v19 * v35);
          *(v9 - 2) = (float)(v15 * v36) + (float)(v20 * v35);
          *(v9 - 1) = (float)(v36 * v16) + (float)(v35 * v21);
        }
        while ( v9 != v30 );
        v8 = &inbuffer[4 * v29];
      }
      else
      {
        v30 = outbuffer;
      }
      if ( (length & 1) != 0 )
      {
        v37 = *v8;
        v38 = v8[1];
        *v30 = (float)(v11 * *v8) + (float)(v10 * v38);
        v30[1] = (float)(v12 * v37) + (float)(v17 * v38);
        v30[2] = (float)(v13 * v37) + (float)(v18 * v38);
        v30[3] = (float)(v14 * v37) + (float)(v19 * v38);
        v30[4] = (float)(v15 * v37) + (float)(v20 * v38);
        v30[5] = (float)(v37 * v16) + (float)(v38 * v21);
      }
    }
    else
    {
      if ( length >> 1 )
      {
        v39 = inbuffer;
        v40 = (length >> 1) - 1 + 1LL;
        v41 = &outbuffer[12 * v40];
        do
        {
          v42 = *v39;
          v9 += 12;
          v39 += 4;
          v43 = *(v39 - 3);
          *(v9 - 12) = (float)((float)(v42 * v11) + (float)(v43 * v10)) + *(v9 - 12);
          *(v9 - 11) = (float)((float)(v12 * v42) + (float)(v17 * v43)) + *(v9 - 11);
          *(v9 - 10) = (float)((float)(v13 * v42) + (float)(v18 * v43)) + *(v9 - 10);
          *(v9 - 9) = (float)((float)(v14 * v42) + (float)(v19 * v43)) + *(v9 - 9);
          v44 = (float)(v15 * v42) + (float)(v20 * v43);
          v45 = (float)(v42 * v16) + (float)(v43 * v21);
          v46 = *(v39 - 1);
          v47 = v45 + *(v9 - 7);
          *(v9 - 8) = v44 + *(v9 - 8);
          *(v9 - 7) = v47;
          v48 = *(v39 - 2);
          *(v9 - 6) = (float)((float)(v48 * v11) + (float)(v46 * v10)) + *(v9 - 6);
          *(v9 - 5) = (float)((float)(v12 * v48) + (float)(v17 * v46)) + *(v9 - 5);
          *(v9 - 4) = (float)((float)(v13 * v48) + (float)(v18 * v46)) + *(v9 - 4);
          *(v9 - 3) = (float)((float)(v14 * v48) + (float)(v19 * v46)) + *(v9 - 3);
          v49 = (float)((float)(v15 * v48) + (float)(v20 * v46)) + *(v9 - 2);
          v50 = (float)((float)(v48 * v16) + (float)(v46 * v21)) + *(v9 - 1);
          *(v9 - 2) = v49;
          *(v9 - 1) = v50;
        }
        while ( v9 != v41 );
        v8 = &inbuffer[4 * v40];
      }
      else
      {
        v41 = outbuffer;
      }
      if ( (length & 1) != 0 )
      {
        v51 = *v8;
        v52 = v8[1];
        v53 = (float)((float)(v12 * *v8) + (float)(v17 * v52)) + v41[1];
        v54 = (float)((float)(v13 * *v8) + (float)(v18 * v52)) + v41[2];
        v55 = (float)((float)(v14 * *v8) + (float)(v19 * v52)) + v41[3];
        *v41 = (float)((float)(v11 * *v8) + (float)(v10 * v52)) + *v41;
        v56 = (float)((float)(v15 * v51) + (float)(v20 * v52)) + v41[4];
        v41[1] = v53;
        v57 = (float)((float)(v51 * v16) + (float)(v52 * v21)) + v41[5];
        v41[2] = v54;
        v41[3] = v55;
        v41[4] = v56;
        v41[5] = v57;
      }
    }
  }
  else
  {
    if ( writedontmix )
    {
      l11 = mixmatrix[33];
      memset(outbuffer, 0, 24LL * length);
      v17 = l11;
    }
    if ( length >> 2 )
    {
      v22 = (length >> 2) - 1 + 1LL;
      v23 = inbuffer;
      do
      {
        v24 = *v23;
        v9 += 24;
        v23 += 8;
        *(v9 - 24) = (float)(v24 * v11) + *(v9 - 24);
        *(v9 - 23) = (float)(*(v23 - 7) * v17) + *(v9 - 23);
        *(v9 - 18) = (float)(*(v23 - 6) * v11) + *(v9 - 18);
        *(v9 - 17) = (float)(*(v23 - 5) * v17) + *(v9 - 17);
        *(v9 - 12) = (float)(*(v23 - 4) * v11) + *(v9 - 12);
        *(v9 - 11) = (float)(*(v23 - 3) * v17) + *(v9 - 11);
        *(v9 - 6) = (float)(*(v23 - 2) * v11) + *(v9 - 6);
        *(v9 - 5) = (float)(*(v23 - 1) * v17) + *(v9 - 5);
      }
      while ( v9 != &outbuffer[24 * v22] );
      v8 = &inbuffer[8 * v22];
    }
    v25 = length & 3;
    if ( v25 )
    {
      v26 = &v9[6 * v25];
      do
      {
        v27 = *v8;
        v9 += 6;
        v8 += 2;
        *(v9 - 6) = (float)(v27 * v11) + *(v9 - 6);
        *(v9 - 5) = (float)(*(v8 - 1) * v17) + *(v9 - 5);
      }
      while ( v9 != v26 );
    }
  }
}


// Address: 0x21c2f90 | Name: FMOD_DSP_Connection_Mix51To51_Diagonal_NoOpt
void __fastcall FMOD_DSP_Connection_Mix51To51_Diagonal_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float v7; // xmm0_4
  float v8; // xmm1_4
  unsigned int v9; // eax
  float v10; // xmm2_4
  float v11; // xmm3_4
  float v12; // xmm4_4
  float v13; // xmm5_4
  __int64 v14; // r8
  float *v15; // rax
  __int64 v16; // r8
  float *v17; // rcx
  float v18; // xmm6_4
  unsigned int v19; // edx
  float *v20; // rax
  float v21; // xmm6_4
  __int64 v22; // r8
  float *v23; // rax
  __int64 v24; // r8
  float *v25; // rcx
  float v26; // xmm6_4
  unsigned int v27; // edx
  float *v28; // rax
  float v29; // xmm6_4

  v7 = *mixmatrix;
  v8 = mixmatrix[33];
  v9 = length >> 2;
  v10 = mixmatrix[66];
  v11 = mixmatrix[99];
  v12 = mixmatrix[132];
  v13 = mixmatrix[165];
  if ( writedontmix )
  {
    if ( v9 )
    {
      v14 = 3LL * (v9 - 1) + 3;
      v15 = outbuffer;
      v16 = 8 * v14;
      v17 = &inbuffer[v16];
      do
      {
        v18 = *inbuffer;
        inbuffer += 24;
        v15 += 24;
        *(v15 - 24) = v18 * v7;
        *(v15 - 23) = *(inbuffer - 23) * v8;
        *(v15 - 22) = *(inbuffer - 22) * v10;
        *(v15 - 21) = *(inbuffer - 21) * v11;
        *(v15 - 20) = *(inbuffer - 20) * v12;
        *(v15 - 19) = *(inbuffer - 19) * v13;
        *(v15 - 18) = *(inbuffer - 18) * v7;
        *(v15 - 17) = *(inbuffer - 17) * v8;
        *(v15 - 16) = *(inbuffer - 16) * v10;
        *(v15 - 15) = *(inbuffer - 15) * v11;
        *(v15 - 14) = *(inbuffer - 14) * v12;
        *(v15 - 13) = *(inbuffer - 13) * v13;
        *(v15 - 12) = *(inbuffer - 12) * v7;
        *(v15 - 11) = *(inbuffer - 11) * v8;
        *(v15 - 10) = *(inbuffer - 10) * v10;
        *(v15 - 9) = *(inbuffer - 9) * v11;
        *(v15 - 8) = *(inbuffer - 8) * v12;
        *(v15 - 7) = *(inbuffer - 7) * v13;
        *(v15 - 6) = *(inbuffer - 6) * v7;
        *(v15 - 5) = *(inbuffer - 5) * v8;
        *(v15 - 4) = *(inbuffer - 4) * v10;
        *(v15 - 3) = *(inbuffer - 3) * v11;
        *(v15 - 2) = *(inbuffer - 2) * v12;
        *(v15 - 1) = *(inbuffer - 1) * v13;
      }
      while ( inbuffer != v17 );
      outbuffer = (float *)((char *)outbuffer + v16 * 4);
    }
    else
    {
      v17 = inbuffer;
    }
    v19 = length & 3;
    if ( v19 )
    {
      v20 = &v17[6 * v19];
      do
      {
        v21 = *v17;
        v17 += 6;
        outbuffer += 6;
        *(outbuffer - 6) = v21 * v7;
        *(outbuffer - 5) = *(v17 - 5) * v8;
        *(outbuffer - 4) = *(v17 - 4) * v10;
        *(outbuffer - 3) = *(v17 - 3) * v11;
        *(outbuffer - 2) = *(v17 - 2) * v12;
        *(outbuffer - 1) = *(v17 - 1) * v13;
      }
      while ( v17 != v20 );
    }
  }
  else
  {
    if ( v9 )
    {
      v22 = 3LL * (v9 - 1) + 3;
      v23 = outbuffer;
      v24 = 8 * v22;
      v25 = &inbuffer[v24];
      do
      {
        v26 = *inbuffer;
        inbuffer += 24;
        v23 += 24;
        *(v23 - 24) = (float)(v26 * v7) + *(v23 - 24);
        *(v23 - 23) = (float)(*(inbuffer - 23) * v8) + *(v23 - 23);
        *(v23 - 22) = (float)(*(inbuffer - 22) * v10) + *(v23 - 22);
        *(v23 - 21) = (float)(*(inbuffer - 21) * v11) + *(v23 - 21);
        *(v23 - 20) = (float)(*(inbuffer - 20) * v12) + *(v23 - 20);
        *(v23 - 19) = (float)(*(inbuffer - 19) * v13) + *(v23 - 19);
        *(v23 - 18) = (float)(*(inbuffer - 18) * v7) + *(v23 - 18);
        *(v23 - 17) = (float)(*(inbuffer - 17) * v8) + *(v23 - 17);
        *(v23 - 16) = (float)(*(inbuffer - 16) * v10) + *(v23 - 16);
        *(v23 - 15) = (float)(*(inbuffer - 15) * v11) + *(v23 - 15);
        *(v23 - 14) = (float)(*(inbuffer - 14) * v12) + *(v23 - 14);
        *(v23 - 13) = (float)(*(inbuffer - 13) * v13) + *(v23 - 13);
        *(v23 - 12) = (float)(*(inbuffer - 12) * v7) + *(v23 - 12);
        *(v23 - 11) = (float)(*(inbuffer - 11) * v8) + *(v23 - 11);
        *(v23 - 10) = (float)(*(inbuffer - 10) * v10) + *(v23 - 10);
        *(v23 - 9) = (float)(*(inbuffer - 9) * v11) + *(v23 - 9);
        *(v23 - 8) = (float)(*(inbuffer - 8) * v12) + *(v23 - 8);
        *(v23 - 7) = (float)(*(inbuffer - 7) * v13) + *(v23 - 7);
        *(v23 - 6) = (float)(*(inbuffer - 6) * v7) + *(v23 - 6);
        *(v23 - 5) = (float)(*(inbuffer - 5) * v8) + *(v23 - 5);
        *(v23 - 4) = (float)(*(inbuffer - 4) * v10) + *(v23 - 4);
        *(v23 - 3) = (float)(*(inbuffer - 3) * v11) + *(v23 - 3);
        *(v23 - 2) = (float)(*(inbuffer - 2) * v12) + *(v23 - 2);
        *(v23 - 1) = (float)(*(inbuffer - 1) * v13) + *(v23 - 1);
      }
      while ( inbuffer != v25 );
      outbuffer = (float *)((char *)outbuffer + v24 * 4);
    }
    else
    {
      v25 = inbuffer;
    }
    v27 = length & 3;
    if ( v27 )
    {
      v28 = &v25[6 * v27];
      do
      {
        v29 = *v25;
        v25 += 6;
        outbuffer += 6;
        *(outbuffer - 6) = (float)(v29 * v7) + *(outbuffer - 6);
        *(outbuffer - 5) = (float)(*(v25 - 5) * v8) + *(outbuffer - 5);
        *(outbuffer - 4) = (float)(*(v25 - 4) * v10) + *(outbuffer - 4);
        *(outbuffer - 3) = (float)(*(v25 - 3) * v11) + *(outbuffer - 3);
        *(outbuffer - 2) = (float)(*(v25 - 2) * v12) + *(outbuffer - 2);
        *(outbuffer - 1) = (float)(*(v25 - 1) * v13) + *(outbuffer - 1);
      }
      while ( v25 != v28 );
    }
  }
}


// Address: 0x21c3490 | Name: FMOD_DSP_Connection_Mix51To51_OneRow_NoOpt
void __fastcall FMOD_DSP_Connection_Mix51To51_OneRow_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float *v8; // rbp
  float *v9; // rbx
  float v10; // xmm1_4
  float v11; // xmm2_4
  float v12; // xmm3_4
  float v13; // xmm4_4
  float v14; // xmm5_4
  float v15; // xmm6_4
  float *v16; // rcx
  __int64 v17; // rdx
  float *v18; // rax
  float v19; // xmm0_4
  float v20; // xmm7_4
  float v21; // xmm0_4
  float v22; // xmm7_4
  float v23; // xmm0_4
  float v24; // xmm7_4
  unsigned int v25; // r12d
  float *v26; // rdx
  float v27; // xmm0_4
  float l03; // [rsp+14h] [rbp-24h]
  float l04; // [rsp+18h] [rbp-20h]
  float l05; // [rsp+1Ch] [rbp-1Ch]

  v8 = outbuffer;
  v9 = inbuffer;
  v10 = *mixmatrix;
  v11 = mixmatrix[1];
  v12 = mixmatrix[2];
  v13 = mixmatrix[3];
  v14 = mixmatrix[4];
  v15 = mixmatrix[5];
  if ( writedontmix )
  {
    l05 = mixmatrix[5];
    l04 = mixmatrix[4];
    l03 = mixmatrix[3];
    memset(outbuffer, 0, 24LL * length);
    v15 = l05;
    v14 = l04;
    v13 = l03;
  }
  if ( length >> 2 )
  {
    v16 = outbuffer;
    v17 = 8 * (3LL * ((length >> 2) - 1) + 3);
    v18 = &inbuffer[v17];
    do
    {
      v19 = *v9;
      v9 += 24;
      v16 += 24;
      v20 = *(v9 - 17) * v11;
      *(v16 - 24) = (float)((float)((float)((float)((float)((float)(v19 * v10) + (float)(*(v9 - 23) * v11))
                                                  + (float)(*(v9 - 22) * v12))
                                          + (float)(*(v9 - 21) * v13))
                                  + (float)(*(v9 - 20) * v14))
                          + (float)(*(v9 - 19) * v15))
                  + *(v16 - 24);
      v21 = (float)((float)((float)((float)((float)(*(v9 - 18) * v10) + v20) + (float)(*(v9 - 16) * v12))
                          + (float)(*(v9 - 15) * v13))
                  + (float)(*(v9 - 14) * v14))
          + (float)(*(v9 - 13) * v15);
      v22 = *(v9 - 11) * v11;
      *(v16 - 18) = v21 + *(v16 - 18);
      v23 = (float)((float)((float)((float)((float)(*(v9 - 12) * v10) + v22) + (float)(*(v9 - 10) * v12))
                          + (float)(*(v9 - 9) * v13))
                  + (float)(*(v9 - 8) * v14))
          + (float)(*(v9 - 7) * v15);
      v24 = *(v9 - 5) * v11;
      *(v16 - 12) = v23 + *(v16 - 12);
      *(v16 - 6) = (float)((float)((float)((float)((float)((float)(*(v9 - 6) * v10) + v24) + (float)(*(v9 - 4) * v12))
                                         + (float)(*(v9 - 3) * v13))
                                 + (float)(*(v9 - 2) * v14))
                         + (float)(*(v9 - 1) * v15))
                 + *(v16 - 6);
    }
    while ( v9 != v18 );
    v8 = &outbuffer[v17];
  }
  else
  {
    v18 = inbuffer;
  }
  v25 = length & 3;
  if ( v25 )
  {
    v26 = &v18[6 * v25];
    do
    {
      v27 = *v18;
      v18 += 6;
      v8 += 6;
      *(v8 - 6) = (float)((float)((float)((float)((float)((float)(v27 * v10) + (float)(*(v18 - 5) * v11))
                                                + (float)(*(v18 - 4) * v12))
                                        + (float)(*(v18 - 3) * v13))
                                + (float)(*(v18 - 2) * v14))
                        + (float)(*(v18 - 1) * v15))
                + *(v8 - 6);
    }
    while ( v18 != v26 );
  }
}


// Address: 0x21c3750 | Name: FMOD_DSP_Connection_Mix51To51_TwoRow_NoOpt
void __fastcall FMOD_DSP_Connection_Mix51To51_TwoRow_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float *v8; // rbp
  float *v9; // rbx
  float v10; // xmm1_4
  float v11; // xmm2_4
  float v12; // xmm3_4
  float v13; // xmm4_4
  float v14; // xmm5_4
  float v15; // xmm6_4
  float v16; // xmm7_4
  float v17; // xmm8_4
  float *v18; // rax
  __int64 v19; // rdx
  float *v20; // rcx
  float v21; // xmm14_4
  float v22; // xmm13_4
  float v23; // xmm12_4
  float v24; // xmm11_4
  float v25; // xmm0_4
  float v26; // xmm14_4
  float v27; // xmm13_4
  float v28; // xmm0_4
  float v29; // xmm14_4
  float v30; // xmm12_4
  float v31; // xmm0_4
  float v32; // xmm15_4
  float v33; // xmm14_4
  float v34; // xmm11_4
  float v35; // xmm14_4
  float v36; // xmm10_4
  float v37; // xmm0_4
  float v38; // xmm15_4
  float v39; // xmm9_4
  float v40; // xmm0_4
  float v41; // xmm14_4
  float v42; // xmm0_4
  float v43; // xmm14_4
  float v44; // xmm13_4
  float v45; // xmm0_4
  float v46; // xmm14_4
  float v47; // xmm12_4
  float v48; // xmm0_4
  float v49; // xmm15_4
  float v50; // xmm14_4
  float v51; // xmm11_4
  float v52; // xmm14_4
  float v53; // xmm10_4
  float v54; // xmm0_4
  float v55; // xmm15_4
  float v56; // xmm14_4
  float v57; // xmm9_4
  float v58; // xmm0_4
  float v59; // xmm14_4
  float v60; // xmm14_4
  float v61; // xmm13_4
  float v62; // xmm12_4
  float v63; // xmm11_4
  float v64; // xmm14_4
  float v65; // xmm15_4
  float v66; // xmm10_4
  float v67; // xmm0_4
  float v68; // xmm15_4
  float v69; // xmm0_4
  unsigned int v70; // r12d
  float *v71; // rax
  float v72; // xmm14_4
  float v73; // xmm13_4
  float v74; // xmm12_4
  float v75; // xmm11_4
  float v76; // xmm15_4
  float v77; // xmm10_4
  float v78; // xmm0_4
  float v79; // xmm15_4
  float v80; // xmm0_4
  float l00; // [rsp+0h] [rbp-48h]
  float l01; // [rsp+4h] [rbp-44h]
  float l02; // [rsp+8h] [rbp-40h]
  float l03; // [rsp+Ch] [rbp-3Ch]
  float l11; // [rsp+1Ch] [rbp-2Ch]
  float l12; // [rsp+20h] [rbp-28h]
  float l15; // [rsp+2Ch] [rbp-1Ch]

  v8 = outbuffer;
  v9 = inbuffer;
  l00 = *mixmatrix;
  l01 = mixmatrix[1];
  l02 = mixmatrix[2];
  l03 = mixmatrix[3];
  v10 = mixmatrix[4];
  v11 = mixmatrix[5];
  v12 = mixmatrix[32];
  v13 = mixmatrix[33];
  v14 = mixmatrix[34];
  v15 = mixmatrix[35];
  v16 = mixmatrix[36];
  v17 = mixmatrix[37];
  if ( writedontmix )
  {
    l15 = mixmatrix[37];
    l12 = mixmatrix[34];
    l11 = mixmatrix[33];
    memset(outbuffer, 0, 24LL * length);
    v17 = l15;
    v14 = l12;
    v13 = l11;
  }
  if ( length >> 2 )
  {
    v18 = outbuffer;
    v19 = 8 * (3LL * ((length >> 2) - 1) + 3);
    v20 = &inbuffer[v19];
    do
    {
      v21 = *v9;
      v9 += 24;
      v18 += 24;
      v22 = *(v9 - 23);
      v23 = *(v9 - 22);
      v24 = *(v9 - 21);
      v25 = (float)(l00 * v21) + (float)(l01 * v22);
      v26 = (float)(v21 * v12) + (float)(v22 * v13);
      v27 = *(v9 - 17);
      v28 = v25 + (float)(l02 * v23);
      v29 = v26 + (float)(v23 * v14);
      v30 = *(v9 - 16);
      v31 = v28 + (float)(l03 * v24);
      v32 = *(v9 - 20);
      v33 = v29 + (float)(v24 * v15);
      v34 = *(v9 - 15);
      v35 = v33 + (float)(v32 * v16);
      v36 = *(v9 - 14);
      v37 = v31 + (float)(v32 * v10);
      v38 = *(v9 - 19);
      v39 = *(v9 - 13);
      v40 = (float)(v37 + (float)(v38 * v11)) + *(v18 - 24);
      *(v18 - 23) = (float)(v35 + (float)(v38 * v17)) + *(v18 - 23);
      *(v18 - 24) = v40;
      v41 = *(v9 - 18);
      v42 = (float)(l00 * v41) + (float)(l01 * v27);
      v43 = (float)(v41 * v12) + (float)(v27 * v13);
      v44 = *(v9 - 11);
      v45 = v42 + (float)(l02 * v30);
      v46 = v43 + (float)(v30 * v14);
      v47 = *(v9 - 10);
      v48 = v45 + (float)(l03 * v34);
      v49 = v36;
      v50 = v46 + (float)(v34 * v15);
      v51 = *(v9 - 9);
      v52 = v50 + (float)(v36 * v16);
      v53 = *(v9 - 8);
      v54 = v48 + (float)(v49 * v10);
      v55 = v39;
      v56 = v52 + (float)(v39 * v17);
      v57 = *(v9 - 7);
      v58 = (float)(v54 + (float)(v55 * v11)) + *(v18 - 18);
      *(v18 - 17) = v56 + *(v18 - 17);
      *(v18 - 18) = v58;
      v59 = *(v9 - 12);
      *(v18 - 12) = (float)((float)((float)((float)((float)((float)(l00 * v59) + (float)(l01 * v44)) + (float)(l02 * v47))
                                          + (float)(l03 * v51))
                                  + (float)(v53 * v10))
                          + (float)(v57 * v11))
                  + *(v18 - 12);
      v60 = (float)((float)((float)((float)((float)((float)(v59 * v12) + (float)(v44 * v13)) + (float)(v47 * v14))
                                  + (float)(v51 * v15))
                          + (float)(v53 * v16))
                  + (float)(v57 * v17))
          + *(v18 - 11);
      v61 = *(v9 - 5);
      v62 = *(v9 - 4);
      v63 = *(v9 - 3);
      *(v18 - 11) = v60;
      v64 = *(v9 - 6);
      v65 = *(v9 - 2);
      v66 = v65 * v16;
      v67 = (float)((float)((float)((float)(l00 * v64) + (float)(l01 * v61)) + (float)(l02 * v62)) + (float)(l03 * v63))
          + (float)(v65 * v10);
      v68 = *(v9 - 1);
      v69 = (float)(v67 + (float)(v68 * v11)) + *(v18 - 6);
      *(v18 - 5) = (float)((float)((float)((float)((float)((float)(v64 * v12) + (float)(v61 * v13)) + (float)(v62 * v14))
                                         + (float)(v63 * v15))
                                 + v66)
                         + (float)(v68 * v17))
                 + *(v18 - 5);
      *(v18 - 6) = v69;
    }
    while ( v9 != v20 );
    v8 = &outbuffer[v19];
  }
  else
  {
    v20 = inbuffer;
  }
  v70 = length & 3;
  if ( v70 )
  {
    v71 = &v20[6 * v70];
    do
    {
      v72 = *v20;
      v20 += 6;
      v8 += 6;
      v73 = *(v20 - 5);
      v74 = *(v20 - 4);
      v75 = *(v20 - 3);
      v76 = *(v20 - 2);
      v77 = v76 * v16;
      v78 = (float)((float)((float)((float)(l00 * v72) + (float)(l01 * v73)) + (float)(l02 * v74)) + (float)(l03 * v75))
          + (float)(v76 * v10);
      v79 = *(v20 - 1);
      v80 = (float)(v78 + (float)(v79 * v11)) + *(v8 - 6);
      *(v8 - 5) = (float)((float)((float)((float)((float)((float)(v72 * v12) + (float)(v73 * v13)) + (float)(v74 * v14))
                                        + (float)(v75 * v15))
                                + v77)
                        + (float)(v79 * v17))
                + *(v8 - 5);
      *(v8 - 6) = v80;
    }
    while ( v20 != v71 );
  }
}


// Address: 0x21c3cc0 | Name: FMOD_DSP_Connection_Mix51To51_Full_NoOpt
void __fastcall FMOD_DSP_Connection_Mix51To51_Full_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float *v8; // rbp
  float *v9; // rbx
  float v10; // xmm14_4
  float v11; // xmm13_4
  float v12; // xmm12_4
  float v13; // xmm11_4
  float v14; // xmm10_4
  float v15; // xmm9_4
  float v16; // xmm8_4
  float v17; // xmm7_4
  float v18; // xmm6_4
  float v19; // xmm5_4
  float v20; // xmm4_4
  float v21; // xmm3_4
  float v22; // xmm2_4
  float v23; // xmm1_4
  float v24; // xmm0_4
  float mixmatrixa; // [rsp+8h] [rbp-90h]
  float *mixmatrixb; // [rsp+8h] [rbp-90h]
  float v27; // [rsp+14h] [rbp-84h]
  float v28; // [rsp+18h] [rbp-80h]
  float v29; // [rsp+1Ch] [rbp-7Ch]
  float v30; // [rsp+20h] [rbp-78h]
  float v31; // [rsp+24h] [rbp-74h]
  float v32; // [rsp+28h] [rbp-70h]
  float v33; // [rsp+2Ch] [rbp-6Ch]
  float v34; // [rsp+30h] [rbp-68h]
  float v35; // [rsp+34h] [rbp-64h]
  float v36; // [rsp+38h] [rbp-60h]
  float v37; // [rsp+3Ch] [rbp-5Ch]
  float v38; // [rsp+40h] [rbp-58h]
  float v39; // [rsp+44h] [rbp-54h]
  float v40; // [rsp+48h] [rbp-50h]
  float v41; // [rsp+4Ch] [rbp-4Ch]
  float v42; // [rsp+50h] [rbp-48h]
  float v43; // [rsp+54h] [rbp-44h]
  float v44; // [rsp+58h] [rbp-40h]
  float v45; // [rsp+5Ch] [rbp-3Ch]
  float v46; // [rsp+60h] [rbp-38h]
  float v47; // [rsp+64h] [rbp-34h]
  float v48; // [rsp+68h] [rbp-30h]
  float v49; // [rsp+6Ch] [rbp-2Ch]
  float v50; // [rsp+70h] [rbp-28h]
  float v51; // [rsp+74h] [rbp-24h]
  float v52; // [rsp+78h] [rbp-20h]
  float v53; // [rsp+7Ch] [rbp-1Ch]

  v8 = inbuffer;
  v9 = outbuffer;
  if ( writedontmix )
  {
    mixmatrixb = mixmatrix;
    memset(outbuffer, 0, 24LL * length);
    mixmatrix = mixmatrixb;
  }
  if ( (int)length > 0 )
  {
    mixmatrixa = *mixmatrix;
    v27 = mixmatrix[1];
    v28 = mixmatrix[2];
    v29 = mixmatrix[3];
    v30 = mixmatrix[4];
    v31 = mixmatrix[5];
    v32 = mixmatrix[32];
    v33 = mixmatrix[33];
    v34 = mixmatrix[34];
    v35 = mixmatrix[35];
    v36 = mixmatrix[36];
    v37 = mixmatrix[37];
    v38 = mixmatrix[64];
    v39 = mixmatrix[65];
    v40 = mixmatrix[66];
    v41 = mixmatrix[67];
    v42 = mixmatrix[68];
    v43 = mixmatrix[69];
    v44 = mixmatrix[96];
    v45 = mixmatrix[97];
    v46 = mixmatrix[98];
    v47 = mixmatrix[99];
    v48 = mixmatrix[100];
    v49 = mixmatrix[101];
    v50 = mixmatrix[128];
    v51 = mixmatrix[129];
    v52 = mixmatrix[130];
    v53 = mixmatrix[131];
    v10 = mixmatrix[132];
    v11 = mixmatrix[133];
    v12 = mixmatrix[160];
    v13 = mixmatrix[161];
    v14 = mixmatrix[162];
    v15 = mixmatrix[163];
    v16 = mixmatrix[164];
    v17 = mixmatrix[165];
    do
    {
      v18 = *v8;
      v8 += 6;
      v9 += 6;
      v19 = *(v8 - 5);
      v20 = *(v8 - 4);
      v21 = *(v8 - 3);
      v22 = *(v8 - 2);
      v23 = *(v8 - 1);
      *(v9 - 6) = (float)((float)((float)((float)((float)((float)(mixmatrixa * v18) + (float)(v27 * v19))
                                                + (float)(v28 * v20))
                                        + (float)(v29 * v21))
                                + (float)(v30 * v22))
                        + (float)(v31 * v23))
                + *(v9 - 6);
      *(v9 - 5) = (float)((float)((float)((float)((float)((float)(v32 * v18) + (float)(v33 * v19)) + (float)(v34 * v20))
                                        + (float)(v35 * v21))
                                + (float)(v36 * v22))
                        + (float)(v37 * v23))
                + *(v9 - 5);
      *(v9 - 4) = (float)((float)((float)((float)((float)((float)(v38 * v18) + (float)(v39 * v19)) + (float)(v40 * v20))
                                        + (float)(v41 * v21))
                                + (float)(v42 * v22))
                        + (float)(v43 * v23))
                + *(v9 - 4);
      *(v9 - 3) = (float)((float)((float)((float)((float)((float)(v44 * v18) + (float)(v45 * v19)) + (float)(v46 * v20))
                                        + (float)(v47 * v21))
                                + (float)(v48 * v22))
                        + (float)(v49 * v23))
                + *(v9 - 3);
      v24 = (float)((float)((float)((float)((float)((float)(v50 * v18) + (float)(v51 * v19)) + (float)(v52 * v20))
                                  + (float)(v53 * v21))
                          + (float)(v22 * v10))
                  + (float)(v23 * v11))
          + *(v9 - 2);
      *(v9 - 1) = (float)((float)((float)((float)((float)((float)(v18 * v12) + (float)(v19 * v13)) + (float)(v20 * v14))
                                        + (float)(v21 * v15))
                                + (float)(v22 * v16))
                        + (float)(v23 * v17))
                + *(v9 - 1);
      *(v9 - 2) = v24;
    }
    while ( v8 != &inbuffer[6 * length] );
  }
}


// Address: 0x21c4160 | Name: FMOD_DSP_Connection_MixMonoTo71_NoOpt
void __fastcall FMOD_DSP_Connection_MixMonoTo71_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float v7; // xmm10_4
  float v8; // xmm9_4
  float v9; // xmm8_4
  float v10; // xmm7_4
  float v11; // xmm6_4
  float v12; // xmm5_4
  float v13; // xmm4_4
  float v14; // xmm3_4
  unsigned int v15; // r8d
  float *v16; // rax
  float *v17; // rcx
  float v18; // xmm2_4
  float v19; // xmm0_4
  float v20; // xmm2_4
  __int64 v21; // rax
  float v22; // xmm1_4
  unsigned int v23; // r8d
  float *v24; // rax
  float *v25; // rcx
  float v26; // xmm2_4
  float v27; // xmm0_4
  float v28; // xmm0_4
  float v29; // xmm2_4
  float v30; // xmm2_4
  float v31; // xmm0_4
  float v32; // xmm2_4
  __int64 v33; // rax
  float v34; // xmm0_4
  float v35; // xmm9_4
  float v36; // xmm8_4
  float v37; // xmm7_4
  float v38; // xmm6_4
  float v39; // xmm5_4
  float v40; // xmm4_4
  float v41; // xmm0_4

  v7 = *mixmatrix;
  v8 = mixmatrix[32];
  v9 = mixmatrix[64];
  v10 = mixmatrix[96];
  v11 = mixmatrix[128];
  v12 = mixmatrix[160];
  v13 = mixmatrix[192];
  v14 = mixmatrix[224];
  if ( writedontmix )
  {
    if ( length >> 1 )
    {
      v15 = length >> 1;
      v16 = outbuffer;
      v17 = inbuffer;
      do
      {
        v18 = *v17;
        v16 += 16;
        v19 = *v17;
        v17 += 2;
        *(v16 - 16) = v19 * v7;
        *(v16 - 15) = v8 * v18;
        *(v16 - 14) = v9 * v18;
        *(v16 - 13) = v10 * v18;
        *(v16 - 12) = v11 * v18;
        *(v16 - 11) = v12 * v18;
        *(v16 - 10) = v13 * v18;
        *(v16 - 9) = v18 * v14;
        v20 = *(v17 - 1);
        *(v16 - 8) = v20 * v7;
        *(v16 - 7) = v8 * v20;
        *(v16 - 6) = v9 * v20;
        *(v16 - 5) = v10 * v20;
        *(v16 - 4) = v11 * v20;
        *(v16 - 3) = v12 * v20;
        *(v16 - 2) = v13 * v20;
        *(v16 - 1) = v20 * v14;
        --v15;
      }
      while ( v15 );
      v21 = (length >> 1) - 1 + 1LL;
      inbuffer += 2 * v21;
      outbuffer += 16 * v21;
    }
    if ( (length & 1) != 0 )
    {
      v22 = *inbuffer;
      *outbuffer = v7 * *inbuffer;
      outbuffer[1] = v8 * v22;
      outbuffer[2] = v9 * v22;
      outbuffer[3] = v10 * v22;
      outbuffer[4] = v11 * v22;
      outbuffer[5] = v12 * v22;
      outbuffer[6] = v13 * v22;
      outbuffer[7] = v22 * v14;
    }
  }
  else
  {
    if ( length >> 1 )
    {
      v23 = length >> 1;
      v24 = outbuffer;
      v25 = inbuffer;
      do
      {
        v26 = *v25;
        v24 += 16;
        v27 = *v25;
        v25 += 2;
        *(v24 - 16) = (float)(v27 * v7) + *(v24 - 16);
        *(v24 - 15) = (float)(v8 * v26) + *(v24 - 15);
        *(v24 - 14) = (float)(v9 * v26) + *(v24 - 14);
        *(v24 - 13) = (float)(v10 * v26) + *(v24 - 13);
        *(v24 - 12) = (float)(v11 * v26) + *(v24 - 12);
        *(v24 - 11) = (float)(v12 * v26) + *(v24 - 11);
        v28 = v13 * v26;
        v29 = (float)(v26 * v14) + *(v24 - 9);
        *(v24 - 10) = v28 + *(v24 - 10);
        *(v24 - 9) = v29;
        v30 = *(v25 - 1);
        *(v24 - 8) = (float)(v30 * v7) + *(v24 - 8);
        *(v24 - 7) = (float)(v8 * v30) + *(v24 - 7);
        *(v24 - 6) = (float)(v9 * v30) + *(v24 - 6);
        *(v24 - 5) = (float)(v10 * v30) + *(v24 - 5);
        *(v24 - 4) = (float)(v11 * v30) + *(v24 - 4);
        *(v24 - 3) = (float)(v12 * v30) + *(v24 - 3);
        v31 = (float)(v13 * v30) + *(v24 - 2);
        v32 = (float)(v30 * v14) + *(v24 - 1);
        *(v24 - 2) = v31;
        *(v24 - 1) = v32;
        --v23;
      }
      while ( v23 );
      v33 = (length >> 1) - 1 + 1LL;
      inbuffer += 2 * v33;
      outbuffer += 16 * v33;
    }
    if ( (length & 1) != 0 )
    {
      v34 = *inbuffer;
      v35 = (float)(v8 * *inbuffer) + outbuffer[1];
      v36 = (float)(v9 * *inbuffer) + outbuffer[2];
      v37 = (float)(v10 * *inbuffer) + outbuffer[3];
      v38 = (float)(v11 * *inbuffer) + outbuffer[4];
      v39 = (float)(v12 * *inbuffer) + outbuffer[5];
      v40 = (float)(v13 * *inbuffer) + outbuffer[6];
      *outbuffer = (float)(v7 * *inbuffer) + *outbuffer;
      v41 = (float)(v34 * v14) + outbuffer[7];
      outbuffer[1] = v35;
      outbuffer[2] = v36;
      outbuffer[3] = v37;
      outbuffer[4] = v38;
      outbuffer[5] = v39;
      outbuffer[6] = v40;
      outbuffer[7] = v41;
    }
  }
}


// Address: 0x21c44f0 | Name: FMOD_DSP_Connection_MixStereoTo71_NoOpt
void __fastcall FMOD_DSP_Connection_MixStereoTo71_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float *v8; // rbp
  float *v9; // rbx
  float v10; // xmm2_4
  float v11; // xmm8_4
  float v12; // xmm3_4
  float v13; // xmm4_4
  float v14; // xmm6_4
  float v15; // xmm13_4
  float v16; // xmm11_4
  float v17; // xmm7_4
  float v18; // xmm5_4
  float v19; // xmm9_4
  float v20; // xmm12_4
  float v21; // xmm10_4
  unsigned int v22; // esi
  float *v23; // rax
  float *v24; // rcx
  float v25; // xmm1_4
  float v26; // xmm0_4
  float v27; // xmm15_4
  float v28; // xmm14_4
  float v29; // xmm1_4
  float v30; // xmm0_4
  float v31; // xmm1_4
  float v32; // xmm1_4
  float v33; // xmm14_4
  float v34; // xmm1_4
  __int64 v35; // rdx
  float v36; // xmm1_4
  float v37; // xmm0_4
  float v38; // xmm8_4
  float v39; // xmm4_4
  float v40; // xmm6_4
  float v41; // xmm13_4
  float v42; // xmm11_4
  float v43; // xmm2_4
  float v44; // xmm1_4
  unsigned int v45; // esi
  float *v46; // rax
  float *v47; // rdx
  float v48; // xmm0_4
  __int64 v49; // rdx
  unsigned int i; // r12d
  float v51; // xmm0_4
  float v52; // [rsp+0h] [rbp-58h]
  float l11; // [rsp+4h] [rbp-54h]
  float l11a; // [rsp+4h] [rbp-54h]
  float l61; // [rsp+8h] [rbp-50h]
  float l71; // [rsp+Ch] [rbp-4Ch]
  float l20; // [rsp+18h] [rbp-40h]
  float l21; // [rsp+30h] [rbp-28h]
  float l51; // [rsp+3Ch] [rbp-1Ch]

  v8 = inbuffer;
  v9 = outbuffer;
  v10 = mixmatrix[1];
  l61 = mixmatrix[193];
  l71 = mixmatrix[225];
  v52 = mixmatrix[192];
  l11 = mixmatrix[224];
  v11 = *mixmatrix;
  v12 = mixmatrix[32];
  v13 = mixmatrix[64];
  v14 = mixmatrix[96];
  v15 = mixmatrix[128];
  v16 = mixmatrix[160];
  v17 = mixmatrix[33];
  v18 = mixmatrix[65];
  v19 = mixmatrix[97];
  v20 = mixmatrix[129];
  v21 = mixmatrix[161];
  if ( fabs(v10) >= 0.000019999999
    || fabs(v12) >= 0.000019999999
    || fabs(v13) >= 0.000019999999
    || fabs(v18) >= 0.000019999999
    || fabs(v14) >= 0.000019999999
    || fabs(v19) >= 0.000019999999
    || fabs(v15) >= 0.000019999999
    || fabs(v20) >= 0.000019999999
    || fabs(v16) >= 0.000019999999
    || fabs(v21) >= 0.000019999999
    || fabs(v52) >= 0.000019999999
    || fabs(l61) >= 0.000019999999
    || fabs(l11) >= 0.000019999999
    || fabs(l71) >= 0.000019999999 )
  {
    if ( writedontmix )
    {
      l51 = mixmatrix[161];
      l21 = mixmatrix[65];
      l20 = mixmatrix[64];
      memset(outbuffer, 0, 32LL * length);
      v21 = l51;
      v18 = l21;
      v13 = l20;
    }
    if ( length >> 1 )
    {
      v22 = length >> 1;
      v23 = v9;
      v24 = inbuffer;
      do
      {
        v25 = *v24;
        v23 += 16;
        v26 = v24[1];
        v24 += 4;
        *(v23 - 16) = (float)((float)(v25 * v11) + (float)(v26 * v10)) + *(v23 - 16);
        *(v23 - 15) = (float)((float)(v25 * v12) + (float)(v26 * v17)) + *(v23 - 15);
        *(v23 - 14) = (float)((float)(v25 * v13) + (float)(v26 * v18)) + *(v23 - 14);
        *(v23 - 13) = (float)((float)(v25 * v14) + (float)(v26 * v19)) + *(v23 - 13);
        *(v23 - 12) = (float)((float)(v25 * v15) + (float)(v26 * v20)) + *(v23 - 12);
        v27 = l61 * v26;
        *(v23 - 11) = (float)((float)(v25 * v16) + (float)(v26 * v21)) + *(v23 - 11);
        v28 = v52 * v25;
        v29 = (float)(v25 * l11) + (float)(v26 * l71);
        v30 = *(v24 - 1);
        v31 = v29 + *(v23 - 9);
        *(v23 - 10) = (float)(v28 + v27) + *(v23 - 10);
        *(v23 - 9) = v31;
        v32 = *(v24 - 2);
        *(v23 - 8) = (float)((float)(v32 * v11) + (float)(v30 * v10)) + *(v23 - 8);
        *(v23 - 7) = (float)((float)(v32 * v12) + (float)(v30 * v17)) + *(v23 - 7);
        *(v23 - 6) = (float)((float)(v32 * v13) + (float)(v30 * v18)) + *(v23 - 6);
        *(v23 - 5) = (float)((float)(v32 * v14) + (float)(v30 * v19)) + *(v23 - 5);
        *(v23 - 4) = (float)((float)(v32 * v15) + (float)(v30 * v20)) + *(v23 - 4);
        *(v23 - 3) = (float)((float)(v32 * v16) + (float)(v30 * v21)) + *(v23 - 3);
        v33 = (float)((float)(v52 * v32) + (float)(l61 * v30)) + *(v23 - 2);
        v34 = (float)((float)(v32 * l11) + (float)(v30 * l71)) + *(v23 - 1);
        *(v23 - 2) = v33;
        *(v23 - 1) = v34;
        --v22;
      }
      while ( v22 );
      v35 = (length >> 1) - 1 + 1LL;
      v9 += 16 * v35;
      v8 = &inbuffer[4 * v35];
    }
    if ( (length & 1) != 0 )
    {
      v36 = *v8;
      v37 = v8[1];
      v38 = (float)((float)(v11 * *v8) + (float)(v10 * v37)) + *v9;
      v9[1] = (float)((float)(v12 * *v8) + (float)(v17 * v37)) + v9[1];
      v39 = (float)((float)(v13 * v36) + (float)(v18 * v37)) + v9[2];
      v40 = (float)((float)(v14 * v36) + (float)(v19 * v37)) + v9[3];
      *v9 = v38;
      v41 = (float)((float)(v15 * v36) + (float)(v20 * v37)) + v9[4];
      v42 = (float)((float)(v16 * v36) + (float)(v21 * v37)) + v9[5];
      v9[2] = v39;
      v9[3] = v40;
      v9[4] = v41;
      v43 = (float)((float)(v52 * v36) + (float)(l61 * v37)) + v9[6];
      v9[5] = v42;
      v44 = (float)((float)(v36 * l11) + (float)(v37 * l71)) + v9[7];
      v9[6] = v43;
      v9[7] = v44;
    }
  }
  else
  {
    if ( writedontmix )
    {
      l11a = mixmatrix[33];
      memset(outbuffer, 0, 32LL * length);
      v17 = l11a;
    }
    if ( length >> 2 )
    {
      v45 = length >> 2;
      v46 = v9;
      v47 = inbuffer;
      do
      {
        v46 += 32;
        v48 = *v47 * v11;
        v47 += 8;
        *(v46 - 32) = v48 + *(v46 - 32);
        *(v46 - 31) = (float)(*(v47 - 7) * v17) + *(v46 - 31);
        *(v46 - 24) = (float)(*(v47 - 6) * v11) + *(v46 - 24);
        *(v46 - 23) = (float)(*(v47 - 5) * v17) + *(v46 - 23);
        *(v46 - 16) = (float)(*(v47 - 4) * v11) + *(v46 - 16);
        *(v46 - 15) = (float)(*(v47 - 3) * v17) + *(v46 - 15);
        *(v46 - 8) = (float)(*(v47 - 2) * v11) + *(v46 - 8);
        *(v46 - 7) = (float)(*(v47 - 1) * v17) + *(v46 - 7);
        --v45;
      }
      while ( v45 );
      v49 = (length >> 2) - 1 + 1LL;
      v8 = &inbuffer[8 * v49];
      v9 += 32 * v49;
    }
    for ( i = length & 3; i; --i )
    {
      v51 = *v8;
      v9 += 8;
      v8 += 2;
      *(v9 - 8) = (float)(v51 * v11) + *(v9 - 8);
      *(v9 - 7) = (float)(*(v8 - 1) * v17) + *(v9 - 7);
    }
  }
}


// Address: 0x21c4c20 | Name: FMOD_DSP_Connection_Mix71To71_Diagonal_NoOpt
void __fastcall FMOD_DSP_Connection_Mix71To71_Diagonal_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float *v8; // rbp
  float *v9; // rbx
  float v10; // xmm7_4
  float v11; // xmm6_4
  float v12; // xmm5_4
  float v13; // xmm4_4
  float v14; // xmm3_4
  float v15; // xmm2_4
  float v16; // xmm1_4
  float v17; // xmm0_4
  unsigned int v18; // esi
  float *v19; // rax
  float *v20; // rcx
  float v21; // xmm8_4
  __int64 v22; // rax
  float v23; // xmm0_4
  float v24; // xmm6_4
  float v25; // xmm5_4
  float v26; // xmm4_4
  float v27; // xmm3_4
  float v28; // xmm2_4
  float v29; // xmm1_4
  float v30; // xmm0_4
  float l22; // [rsp+8h] [rbp-30h]
  float l33; // [rsp+Ch] [rbp-2Ch]
  float l77; // [rsp+1Ch] [rbp-1Ch]

  v8 = inbuffer;
  v9 = outbuffer;
  v10 = *mixmatrix;
  v11 = mixmatrix[33];
  v12 = mixmatrix[66];
  v13 = mixmatrix[99];
  v14 = mixmatrix[132];
  v15 = mixmatrix[165];
  v16 = mixmatrix[198];
  v17 = mixmatrix[231];
  if ( writedontmix )
  {
    l77 = mixmatrix[231];
    l33 = mixmatrix[99];
    l22 = mixmatrix[66];
    memset(outbuffer, 0, 4LL * length * outchannels);
    v17 = l77;
    v13 = l33;
    v12 = l22;
  }
  if ( length >> 1 )
  {
    v18 = length >> 1;
    v19 = v9;
    v20 = inbuffer;
    do
    {
      v19 += 16;
      v21 = *v20 * v10;
      v20 += 16;
      *(v19 - 16) = v21 + *(v19 - 16);
      *(v19 - 15) = (float)(*(v20 - 15) * v11) + *(v19 - 15);
      *(v19 - 14) = (float)(*(v20 - 14) * v12) + *(v19 - 14);
      *(v19 - 13) = (float)(*(v20 - 13) * v13) + *(v19 - 13);
      *(v19 - 12) = (float)(*(v20 - 12) * v14) + *(v19 - 12);
      *(v19 - 11) = (float)(*(v20 - 11) * v15) + *(v19 - 11);
      *(v19 - 10) = (float)(*(v20 - 10) * v16) + *(v19 - 10);
      *(v19 - 9) = (float)(*(v20 - 9) * v17) + *(v19 - 9);
      *(v19 - 8) = (float)(*(v20 - 8) * v10) + *(v19 - 8);
      *(v19 - 7) = (float)(*(v20 - 7) * v11) + *(v19 - 7);
      *(v19 - 6) = (float)(*(v20 - 6) * v12) + *(v19 - 6);
      *(v19 - 5) = (float)(*(v20 - 5) * v13) + *(v19 - 5);
      *(v19 - 4) = (float)(*(v20 - 4) * v14) + *(v19 - 4);
      *(v19 - 3) = (float)(*(v20 - 3) * v15) + *(v19 - 3);
      *(v19 - 2) = (float)(*(v20 - 2) * v16) + *(v19 - 2);
      *(v19 - 1) = (float)(*(v20 - 1) * v17) + *(v19 - 1);
      --v18;
    }
    while ( v18 );
    v22 = ((length >> 1) - 1 + 1LL) << 6;
    v9 = (float *)((char *)v9 + v22);
    v8 = (float *)((char *)inbuffer + v22);
  }
  if ( (length & 1) != 0 )
  {
    v23 = v17 * v8[7];
    v24 = (float)(v11 * v8[1]) + v9[1];
    v25 = (float)(v12 * v8[2]) + v9[2];
    v26 = (float)(v13 * v8[3]) + v9[3];
    v27 = (float)(v14 * v8[4]) + v9[4];
    v28 = (float)(v15 * v8[5]) + v9[5];
    v29 = (float)(v16 * v8[6]) + v9[6];
    *v9 = (float)(v10 * *v8) + *v9;
    v30 = v23 + v9[7];
    v9[1] = v24;
    v9[2] = v25;
    v9[3] = v26;
    v9[4] = v27;
    v9[5] = v28;
    v9[6] = v29;
    v9[7] = v30;
  }
}


// Address: 0x21c4f30 | Name: FMOD_DSP_Connection_Mix71To71_Full_NoOpt
void __fastcall FMOD_DSP_Connection_Mix71To71_Full_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float *v8; // rbp
  int v10; // edi
  float v11; // xmm9_4
  float v12; // xmm8_4
  float *v13; // rax
  float v14; // xmm7_4
  float *v15; // rsi
  float v16; // xmm6_4
  float v17; // xmm5_4
  float v18; // xmm4_4
  float v19; // xmm3_4
  float v20; // xmm2_4
  float v21; // xmm1_4
  float *mixmatrixa; // [rsp+8h] [rbp-20h]

  v8 = outbuffer;
  if ( writedontmix )
  {
    mixmatrixa = mixmatrix;
    memset(outbuffer, 0, 4LL * length * outchannels);
    mixmatrix = mixmatrixa;
  }
  if ( (int)length > 0 )
  {
    v10 = 0;
    do
    {
      v11 = *inbuffer;
      v12 = inbuffer[1];
      v13 = mixmatrix;
      v14 = inbuffer[2];
      v15 = v8;
      v16 = inbuffer[3];
      v17 = inbuffer[4];
      v18 = inbuffer[5];
      v19 = inbuffer[6];
      v20 = inbuffer[7];
      do
      {
        v21 = *v13;
        ++v15;
        v13 += 32;
        *(v15 - 1) = (float)(*(v13 - 25) * v20)
                   + (float)((float)(*(v13 - 26) * v19)
                           + (float)((float)(*(v13 - 27) * v18)
                                   + (float)((float)(*(v13 - 28) * v17)
                                           + (float)((float)(*(v13 - 29) * v16)
                                                   + (float)((float)(*(v13 - 30) * v14)
                                                           + (float)((float)(*(v13 - 31) * v12)
                                                                   + (float)((float)(v21 * v11) + *(v15 - 1))))))));
      }
      while ( v8 + 8 != v15 );
      ++v10;
      inbuffer += 8;
      v8 += 8;
    }
    while ( v10 != length );
  }
}


// Address: 0x21c5060 | Name: FMOD_DSP_Connection_MixMonoToStereo_NoOpt
void __fastcall FMOD_DSP_Connection_MixMonoToStereo_NoOpt(
        float *in,
        float *out,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  unsigned int v7; // r9d
  float v8; // xmm0_4
  float v9; // xmm1_4
  unsigned int v10; // r8d
  float *v11; // rax
  float *v12; // rcx
  float v13; // xmm3_4
  float v14; // xmm2_4
  float v15; // xmm2_4
  float v16; // xmm3_4
  float v17; // xmm2_4
  float v18; // xmm3_4
  float v19; // xmm2_4
  __int64 v20; // rcx
  unsigned int i; // edx
  float v22; // xmm2_4
  unsigned int v23; // r8d
  float *v24; // rax
  float *v25; // rcx
  float v26; // xmm3_4
  float v27; // xmm2_4
  float v28; // xmm3_4
  float v29; // xmm2_4
  float v30; // xmm3_4
  float v31; // xmm2_4
  float v32; // xmm3_4
  float v33; // xmm2_4
  float v34; // xmm3_4
  __int64 v35; // rcx
  unsigned int j; // edx
  float v37; // xmm2_4
  float v38; // xmm3_4

  v7 = length >> 2;
  v8 = *mixmatrix;
  v9 = mixmatrix[32];
  if ( writedontmix )
  {
    if ( v7 )
    {
      v10 = length >> 2;
      v11 = out;
      v12 = in;
      do
      {
        v11 += 8;
        v13 = *v12;
        v14 = *v12 * v9;
        v12 += 4;
        *(v11 - 7) = v14;
        v15 = *(v12 - 3);
        *(v11 - 8) = v13 * v8;
        v16 = v15;
        *(v11 - 5) = v15 * v9;
        v17 = *(v12 - 2);
        *(v11 - 6) = v16 * v8;
        v18 = v17;
        *(v11 - 3) = v17 * v9;
        v19 = *(v12 - 1);
        *(v11 - 4) = v18 * v8;
        *(v11 - 1) = v19 * v9;
        *(v11 - 2) = v19 * v8;
        --v10;
      }
      while ( v10 );
      v20 = v7 - 1 + 1LL;
      out += 8 * v20;
      in += 4 * v20;
    }
    for ( i = length & 3; i; --i )
    {
      v22 = *in;
      out += 2;
      ++in;
      *(out - 1) = v22 * v9;
      *(out - 2) = v22 * v8;
    }
  }
  else
  {
    if ( v7 )
    {
      v23 = length >> 2;
      v24 = out;
      v25 = in;
      do
      {
        v24 += 8;
        v26 = *v25;
        v27 = *v25 * v9;
        v25 += 4;
        v28 = (float)(v26 * v8) + *(v24 - 8);
        *(v24 - 7) = v27 + *(v24 - 7);
        v29 = *(v25 - 3);
        *(v24 - 8) = v28;
        v30 = (float)(v29 * v8) + *(v24 - 6);
        *(v24 - 5) = (float)(v29 * v9) + *(v24 - 5);
        v31 = *(v25 - 2);
        *(v24 - 6) = v30;
        v32 = (float)(v31 * v8) + *(v24 - 4);
        *(v24 - 3) = (float)(v31 * v9) + *(v24 - 3);
        v33 = *(v25 - 1);
        *(v24 - 4) = v32;
        v34 = (float)(v33 * v8) + *(v24 - 2);
        *(v24 - 1) = (float)(v33 * v9) + *(v24 - 1);
        *(v24 - 2) = v34;
        --v23;
      }
      while ( v23 );
      v35 = v7 - 1 + 1LL;
      out += 8 * v35;
      in += 4 * v35;
    }
    for ( j = length & 3; j; --j )
    {
      v37 = *in;
      out += 2;
      ++in;
      v38 = (float)(v37 * v8) + *(out - 2);
      *(out - 1) = (float)(v37 * v9) + *(out - 1);
      *(out - 2) = v38;
    }
  }
}


// Address: 0x21c5280 | Name: FMOD_DSP_Connection_MixStereoToStereo_NoOpt
void __fastcall FMOD_DSP_Connection_MixStereoToStereo_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  float *v8; // rbp
  float *v9; // rbx
  float v10; // xmm2_4
  float v11; // xmm3_4
  float v12; // xmm4_4
  float v13; // xmm5_4
  unsigned int v14; // esi
  float *v15; // rax
  float *v16; // rcx
  float v17; // xmm0_4
  float v18; // xmm6_4
  float v19; // xmm7_4
  float v20; // xmm1_4
  float v21; // xmm0_4
  float v22; // xmm1_4
  float v23; // xmm0_4
  float v24; // xmm1_4
  float v25; // xmm7_4
  float v26; // xmm1_4
  float v27; // xmm0_4
  float v28; // xmm1_4
  float v29; // xmm0_4
  float v30; // xmm1_4
  float v31; // xmm7_4
  float v32; // xmm1_4
  float v33; // xmm0_4
  float v34; // xmm1_4
  __int64 v35; // rax
  unsigned int v36; // edx
  float v37; // xmm0_4
  float v38; // xmm1_4
  float v39; // xmm0_4
  float l10; // [rsp+8h] [rbp-20h]
  float l11; // [rsp+Ch] [rbp-1Ch]

  v8 = inbuffer;
  v9 = outbuffer;
  v10 = *mixmatrix;
  v11 = mixmatrix[1];
  v12 = mixmatrix[32];
  v13 = mixmatrix[33];
  if ( writedontmix )
  {
    l11 = mixmatrix[33];
    l10 = mixmatrix[32];
    memset(outbuffer, 0, 4LL * length * outchannels);
    v13 = l11;
    v12 = l10;
  }
  if ( length >> 2 )
  {
    v14 = length >> 2;
    v15 = v9;
    v16 = inbuffer;
    do
    {
      v17 = *v16;
      v15 += 8;
      v18 = v16[1];
      v16 += 8;
      v19 = *(v16 - 5);
      v20 = (float)((float)(v17 * v10) + (float)(v18 * v11)) + *(v15 - 8);
      *(v15 - 7) = (float)((float)(v17 * v12) + (float)(v18 * v13)) + *(v15 - 7);
      v21 = *(v16 - 6);
      *(v15 - 8) = v20;
      v22 = v21;
      v23 = (float)(v21 * v12) + (float)(v19 * v13);
      v24 = (float)(v22 * v10) + (float)(v19 * v11);
      v25 = *(v16 - 3);
      v26 = v24 + *(v15 - 6);
      *(v15 - 5) = v23 + *(v15 - 5);
      v27 = *(v16 - 4);
      *(v15 - 6) = v26;
      v28 = v27;
      v29 = (float)(v27 * v12) + (float)(v25 * v13);
      v30 = (float)(v28 * v10) + (float)(v25 * v11);
      v31 = *(v16 - 1);
      v32 = v30 + *(v15 - 4);
      *(v15 - 3) = v29 + *(v15 - 3);
      v33 = *(v16 - 2);
      *(v15 - 4) = v32;
      v34 = (float)((float)(v33 * v10) + (float)(v31 * v11)) + *(v15 - 2);
      *(v15 - 1) = (float)((float)(v33 * v12) + (float)(v31 * v13)) + *(v15 - 1);
      *(v15 - 2) = v34;
      --v14;
    }
    while ( v14 );
    v35 = 8 * ((length >> 2) - 1 + 1LL);
    v8 = &inbuffer[v35];
    v9 = (float *)((char *)v9 + v35 * 4);
  }
  v36 = length & 3;
  if ( (length & 3) != 0 )
  {
    do
    {
      v37 = *v8;
      v9 += 2;
      v8 += 2;
      v38 = (float)((float)(v37 * v10) + (float)(*(v8 - 1) * v11)) + *(v9 - 2);
      v39 = (float)((float)(v37 * v12) + (float)(*(v8 - 1) * v13)) + *(v9 - 1);
      *(v9 - 2) = v38;
      *(v9 - 1) = v39;
      --v36;
    }
    while ( v36 );
  }
}


// Address: 0x21c5490 | Name: FMOD_DSP_Connection_MixMonoToMono_NoOpt
void __fastcall FMOD_DSP_Connection_MixMonoToMono_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float *mixmatrix,
        int inchannels,
        int outchannels,
        int writedontmix)
{
  unsigned int v7; // r9d
  float v8; // xmm0_4
  unsigned int v9; // r8d
  float *v10; // rcx
  float *v11; // rax
  float v12; // xmm1_4
  __int64 v13; // rax
  unsigned int i; // edx
  float v15; // xmm1_4
  unsigned int v16; // r8d
  float *v17; // rax
  float *v18; // rcx
  float v19; // xmm1_4
  __int64 v20; // rax
  unsigned int j; // edx
  float v22; // xmm1_4

  v7 = length >> 2;
  v8 = *mixmatrix;
  if ( writedontmix )
  {
    if ( v7 )
    {
      v9 = length >> 2;
      v10 = outbuffer;
      v11 = inbuffer;
      do
      {
        v10 += 4;
        v12 = *v11 * v8;
        v11 += 4;
        *(v10 - 4) = v12;
        *(v10 - 3) = *(v11 - 3) * v8;
        *(v10 - 2) = *(v11 - 2) * v8;
        *(v10 - 1) = *(v11 - 1) * v8;
        --v9;
      }
      while ( v9 );
      v13 = 16 * (v7 - 1 + 1LL);
      inbuffer = (float *)((char *)inbuffer + v13);
      outbuffer = (float *)((char *)outbuffer + v13);
    }
    for ( i = length & 3; i; --i )
    {
      v15 = *inbuffer;
      ++outbuffer;
      ++inbuffer;
      *(outbuffer - 1) = v15 * v8;
    }
  }
  else
  {
    if ( v7 )
    {
      v16 = length >> 2;
      v17 = outbuffer;
      v18 = inbuffer;
      do
      {
        v17 += 4;
        v19 = *v18 * v8;
        v18 += 4;
        *(v17 - 4) = v19 + *(v17 - 4);
        *(v17 - 3) = (float)(*(v18 - 3) * v8) + *(v17 - 3);
        *(v17 - 2) = (float)(*(v18 - 2) * v8) + *(v17 - 2);
        *(v17 - 1) = (float)(*(v18 - 1) * v8) + *(v17 - 1);
        --v16;
      }
      while ( v16 );
      v20 = 16 * (v7 - 1 + 1LL);
      inbuffer = (float *)((char *)inbuffer + v20);
      outbuffer = (float *)((char *)outbuffer + v20);
    }
    for ( j = length & 3; j; --j )
    {
      v22 = *inbuffer;
      ++outbuffer;
      ++inbuffer;
      *(outbuffer - 1) = (float)(v22 * v8) + *(outbuffer - 1);
    }
  }
}


// Address: 0x21c55f0 | Name: FMOD_DSP_Connection_Mix_Generic_NoOpt
void __fastcall FMOD_DSP_Connection_Mix_Generic_NoOpt(
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        float (*mixmatrix)[32],
        int inchannels,
        int outchannels,
        int writedontmix)
{
  __int64 v10; // rax
  int v11; // r12d
  __int64 v12; // r13
  __int64 v13; // r14
  float *v14; // r9
  __int64 v15; // r11
  float *v16; // r10
  float *v17; // r8
  float v18; // xmm2_4
  float v19; // xmm1_4
  unsigned __int64 v20; // rax
  float v21; // xmm0_4
  __int64 v22; // rax
  int v23; // r12d
  __int64 v24; // r13
  __int64 v25; // r14
  float *v26; // r9
  __int64 v27; // r11
  float *v28; // r10
  float *v29; // r8
  float v30; // xmm1_4
  unsigned __int64 v31; // rax
  float v32; // xmm0_4

  if ( writedontmix )
  {
    if ( (int)length > 0 )
    {
      v22 = (unsigned int)(outchannels - 1);
      v23 = 0;
      v24 = 4LL * inchannels;
      v25 = 4 * v22 + 4;
      v26 = &(*mixmatrix)[32 * v22 + 32];
      v27 = 4LL * (unsigned int)(inchannels - 1) + 4;
      do
      {
        if ( outchannels > 0 )
        {
          v28 = (float *)mixmatrix;
          v29 = outbuffer;
          do
          {
            if ( inchannels <= 0 )
            {
              v30 = 0.0;
            }
            else
            {
              v30 = 0.0;
              v31 = 0;
              do
              {
                v32 = inbuffer[v31 / 4] * v28[v31 / 4];
                v31 += 4LL;
                v30 = v30 + v32;
              }
              while ( v31 != v27 );
            }
            v28 += 32;
            *v29++ = v30;
          }
          while ( v28 != v26 );
          outbuffer = (float *)((char *)outbuffer + v25);
        }
        ++v23;
        inbuffer = (float *)((char *)inbuffer + v24);
      }
      while ( v23 != length );
    }
  }
  else if ( (int)length > 0 )
  {
    v10 = (unsigned int)(outchannels - 1);
    v11 = 0;
    v12 = 4LL * inchannels;
    v13 = 4 * v10 + 4;
    v14 = &(*mixmatrix)[32 * v10 + 32];
    v15 = 4LL * (unsigned int)(inchannels - 1) + 4;
    do
    {
      if ( outchannels > 0 )
      {
        v16 = (float *)mixmatrix;
        v17 = outbuffer;
        do
        {
          v18 = *v17;
          if ( inchannels <= 0 )
          {
            v19 = 0.0;
          }
          else
          {
            v19 = 0.0;
            v20 = 0;
            do
            {
              v21 = inbuffer[v20 / 4] * v16[v20 / 4];
              v20 += 4LL;
              v19 = v19 + v21;
            }
            while ( v20 != v15 );
          }
          v16 += 32;
          *v17++ = v19 + v18;
        }
        while ( v16 != v14 );
        outbuffer = (float *)((char *)outbuffer + v13);
      }
      ++v11;
      inbuffer = (float *)((char *)inbuffer + v12);
    }
    while ( v11 != length );
  }
}


