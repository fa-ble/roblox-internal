// Address: 0x21e7ef0 | Name: _ZN4FMOD16DSPLowPassSimple16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPLowPassSimple::getDescriptionEx()
{
  memset(&stru_2ADB700, 0, sizeof(stru_2ADB700));
  FMOD_strcpy_safe(stru_2ADB700.name, "Cutoff freq", 16);
  FMOD_strcpy_safe(stru_2ADB700.label, "hz", 16);
  *(_QWORD *)&stru_2ADB700.floatdesc.min = 0x46ABE00041200000LL;
  stru_2ADB700.intdesc.defaultval = 1167867904;
  stru_2ADB700.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2ADB700.description = "Lowpass cutoff frequency in hz.  1.0 to 22000.0.  Default = 5000.0";
  *(&stru_2ADB6C0.mHandle + 1) = 20;
  stru_2ADB6C0.mSize = 800;
  stru_2ADB6C0.mDescription = &stru_286B160;
  return &stru_2ADB6C0;
}


// Address: 0x21e7fa0 | Name: _ZN4FMOD16DSPLowPassSimple13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLowPassSimple::resetInternal(FMOD::DSPLowPassSimple *const this)
{
  __int64 i; // rax

  for ( i = 0; i != 256; i += 8 )
  {
    *(_DWORD *)((char *)this + i + 536) = 0;
    *(_DWORD *)((char *)this + i + 532) = 0;
  }
  LOWORD(i) = 0;
  return (int)i;
}


// Address: 0x21e7fd0 | Name: _ZN4FMOD16DSPLowPassSimple13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLowPassSimple::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLowPassSimple::resetInternal((FMOD::DSPLowPassSimple *const)dsp_state->instance);
}


// Address: 0x21e7fe0 | Name: _ZN4FMOD16DSPLowPassSimple18updateCoefficientsEf
__int64 __fastcall FMOD::DSPLowPassSimple::updateCoefficients(
        FMOD::DSPLowPassSimple *const this,
        float a2,
        float cutoffhz)
{
  int v3; // eax
  float v4; // xmm1_4
  float v5; // xmm2_4
  __int64 result; // rax

  v3 = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  if ( a2 >= 22000.0 )
  {
    *((_DWORD *)this + 197) = 1065353216;
    return 0;
  }
  else
  {
    v4 = (float)v3;
    v5 = (float)v3 / 3.1415927;
    result = 0;
    if ( v5 >= a2 )
      *((float *)this + 197) = (float)(1.0 / v4) / (float)((float)(1.0 / (float)(a2 * 6.2831855)) + (float)(1.0 / v4));
    else
      *((float *)this + 197) = (float)((float)(a2 - v5) / (float)((float)(22000.0 - v5) * 3.0)) + 0.66666669;
  }
  return result;
}


// Address: 0x21e8090 | Name: _ZN4FMOD16DSPLowPassSimple14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLowPassSimple::createInternal(FMOD::DSPLowPassSimple *const this)
{
  double v1; // xmm1_8
  __int64 v2; // rbp
  __int64 v3; // rax
  int v4; // ebx
  FMOD_RESULT_0 result; // eax
  float v6; // xmm0_4

  v2 = 0;
  v3 = *((_QWORD *)this + 30);
  v4 = 0;
  if ( *(int *)(v3 + 96) > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v4,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v3 + 104) + v2) + 56LL),
                 v1);
      if ( result )
        break;
      v3 = *((_QWORD *)this + 30);
      ++v4;
      v2 += 8;
      if ( *(_DWORD *)(v3 + 96) <= v4 )
        goto LABEL_6;
    }
  }
  else
  {
LABEL_6:
    FMOD::DSPLowPassSimple::resetInternal(this);
    v6 = *((float *)this + 198);
    *((float *)this + 132) = v6;
    FMOD::DSPLowPassSimple::updateCoefficients(this, v6, *(float *)&v1);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e8120 | Name: _ZN4FMOD16DSPLowPassSimple14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLowPassSimple::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLowPassSimple::createInternal((FMOD::DSPLowPassSimple *const)dsp_state->instance);
}


// Address: 0x21e8130 | Name: _ZN4FMOD16DSPLowPassSimple12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPLowPassSimple::readInternal(
        FMOD::DSPLowPassSimple *const this,
        float *inbuffer_orig,
        float *outbuffer_orig,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float v6; // xmm1_4
  float v9; // xmm0_4
  float v10; // xmm0_4
  float *v11; // r11
  __int64 v12; // r10
  __int64 v13; // rdx
  float *v14; // rdi
  __m128 v15; // xmm4
  float *v16; // rax
  float *v17; // r8
  float v18; // xmm2_4
  float v19; // xmm1_4
  unsigned int v20; // r9d
  float v21; // xmm0_4
  float v22; // xmm0_4
  float v23; // xmm3_4
  FMOD::DSPLowPassSimple *v25; // rax
  float v26; // xmm4_4
  float v27; // xmm2_4
  __m128 v28; // xmm5
  float v29; // xmm1_4
  float v30; // xmm1_4
  float v31; // xmm15_4
  float v32; // xmm14_4
  float v33; // xmm13_4
  float v34; // xmm12_4
  float v35; // xmm11_4
  float v36; // xmm10_4
  float v37; // xmm9_4
  float v38; // xmm8_4
  float v39; // xmm7_4
  float v40; // xmm6_4
  float v41; // xmm5_4
  float v42; // xmm4_4
  __m128 v43; // xmm1
  float *v44; // rax
  float v45; // xmm2_4
  float v46; // xmm2_4
  float v47; // xmm6_4
  float v48; // xmm5_4
  float v49; // xmm4_4
  float v50; // xmm2_4
  __m128 v51; // xmm7
  float v52; // xmm1_4
  float v53; // xmm1_4
  float v54; // xmm3_4
  float v55; // xmm15_4
  float v56; // xmm14_4
  float v57; // xmm13_4
  float v58; // xmm12_4
  float v59; // xmm11_4
  float v60; // xmm10_4
  float v61; // xmm9_4
  float v62; // xmm8_4
  float v63; // xmm7_4
  float v64; // xmm6_4
  float v65; // xmm5_4
  float v66; // xmm4_4
  __m128 v67; // xmm1
  float v68; // xmm2_4
  float v69; // xmm2_4
  int v70; // [rsp+0h] [rbp-38h]
  float v71; // [rsp+0h] [rbp-38h]
  unsigned int fyH1a; // [rsp+8h] [rbp-30h]
  float fyH1; // [rsp+8h] [rbp-30h]
  int fyG2a; // [rsp+Ch] [rbp-2Ch]
  float fyG2; // [rsp+Ch] [rbp-2Ch]

  if ( !inbuffer_orig )
    return FMOD_RESULT::FMOD_OK_0;
  v9 = *((float *)this + 198);
  if ( v9 != *((float *)this + 132) )
  {
    *((float *)this + 132) = v9;
    fyG2a = inchannels;
    fyH1a = length;
    FMOD::DSPLowPassSimple::updateCoefficients(this, v9, v6);
    inchannels = fyG2a;
    length = fyH1a;
  }
  v10 = *((float *)this + 197);
  if ( v10 == 1.0 )
  {
    memcpy_0(outbuffer_orig, inbuffer_orig, length * 4LL * inchannels);
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( v10 == 0.0 )
  {
    v70 = inchannels;
    memset(outbuffer_orig, 0, length * 4LL * inchannels);
    if ( v70 > 0 )
    {
      v25 = (FMOD::DSPLowPassSimple *const)((char *)this + 536);
      do
      {
        *(_DWORD *)v25 = 0;
        *((_DWORD *)v25 - 1) = 0;
        v25 = (FMOD::DSPLowPassSimple *)((char *)v25 + 8);
      }
      while ( v25 != (FMOD::DSPLowPassSimple *const)((char *)this + 8 * (unsigned int)(v70 - 1) + 544) );
      return FMOD_RESULT::FMOD_OK_0;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( inchannels == 1 )
  {
    v26 = *((float *)this + 133);
    v27 = *((float *)this + 134);
    if ( length )
    {
      v28 = (__m128)LODWORD(flt_286B158);
      while ( 1 )
      {
        v29 = *inbuffer_orig;
        ++outbuffer_orig;
        ++inbuffer_orig;
        v30 = v29 + v28.m128_f32[0];
        v28 = _mm_xor_ps(v28, (__m128)0x80000000);
        v26 = v26 + (float)((float)(v30 - v26) * v10);
        v27 = v27 + (float)((float)(v26 - v27) * v10);
        *(outbuffer_orig - 1) = v27;
        if ( !--length )
          break;
        v10 = *((float *)this + 197);
      }
      flt_286B158 = v28.m128_f32[0];
    }
    *((float *)this + 133) = v26;
    *((float *)this + 134) = v27;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    if ( inchannels != 2 )
    {
      if ( inchannels == 6 )
      {
        v31 = *((float *)this + 133);
        v32 = *((float *)this + 134);
        v33 = *((float *)this + 135);
        v34 = *((float *)this + 136);
        v35 = *((float *)this + 137);
        v36 = *((float *)this + 138);
        v37 = *((float *)this + 139);
        v38 = *((float *)this + 140);
        v39 = *((float *)this + 141);
        v40 = *((float *)this + 142);
        v41 = *((float *)this + 143);
        v42 = *((float *)this + 144);
        if ( length )
        {
          v43 = (__m128)LODWORD(flt_286B158);
          v44 = &inbuffer_orig[6 * length];
          while ( 1 )
          {
            v45 = *inbuffer_orig;
            inbuffer_orig += 6;
            outbuffer_orig += 6;
            v31 = v31 + (float)((float)((float)(v45 + v43.m128_f32[0]) - v31) * v10);
            v33 = v33 + (float)((float)((float)(*(inbuffer_orig - 5) + v43.m128_f32[0]) - v33) * v10);
            v35 = v35 + (float)((float)((float)(*(inbuffer_orig - 4) + v43.m128_f32[0]) - v35) * v10);
            v37 = v37 + (float)((float)((float)(*(inbuffer_orig - 3) + v43.m128_f32[0]) - v37) * v10);
            v39 = v39 + (float)((float)((float)(*(inbuffer_orig - 2) + v43.m128_f32[0]) - v39) * v10);
            v46 = *(inbuffer_orig - 1) + v43.m128_f32[0];
            v43 = _mm_xor_ps(v43, (__m128)0x80000000);
            v41 = v41 + (float)((float)(v46 - v41) * v10);
            v32 = v32 + (float)((float)(v31 - v32) * v10);
            *(outbuffer_orig - 6) = v32;
            v34 = v34 + (float)((float)(v33 - v34) * v10);
            *(outbuffer_orig - 5) = v34;
            v36 = v36 + (float)((float)(v35 - v36) * v10);
            *(outbuffer_orig - 4) = v36;
            v38 = v38 + (float)((float)(v37 - v38) * v10);
            *(outbuffer_orig - 3) = v38;
            v40 = v40 + (float)((float)(v39 - v40) * v10);
            *(outbuffer_orig - 2) = v40;
            v42 = v42 + (float)((float)(v41 - v42) * v10);
            *(outbuffer_orig - 1) = v42;
            if ( inbuffer_orig == v44 )
              break;
            v10 = *((float *)this + 197);
          }
          flt_286B158 = v43.m128_f32[0];
        }
        *((float *)this + 133) = v31;
        *((float *)this + 134) = v32;
        *((float *)this + 135) = v33;
        *((float *)this + 136) = v34;
        *((float *)this + 137) = v35;
        *((float *)this + 138) = v36;
        *((float *)this + 139) = v37;
        *((float *)this + 140) = v38;
        *((float *)this + 141) = v39;
        *((float *)this + 142) = v40;
        *((float *)this + 143) = v41;
        *((float *)this + 144) = v42;
      }
      else if ( inchannels == 8 )
      {
        v71 = *((float *)this + 145);
        fyG2 = *((float *)this + 146);
        fyH1 = *((float *)this + 147);
        v54 = *((float *)this + 148);
        v55 = *((float *)this + 133);
        v56 = *((float *)this + 134);
        v57 = *((float *)this + 135);
        v58 = *((float *)this + 136);
        v59 = *((float *)this + 137);
        v60 = *((float *)this + 138);
        v61 = *((float *)this + 139);
        v62 = *((float *)this + 140);
        v63 = *((float *)this + 141);
        v64 = *((float *)this + 142);
        v65 = *((float *)this + 143);
        v66 = *((float *)this + 144);
        if ( length )
        {
          v67 = (__m128)LODWORD(flt_286B158);
          v54 = *((float *)this + 148);
          while ( 1 )
          {
            v68 = *inbuffer_orig;
            outbuffer_orig += 8;
            inbuffer_orig += 8;
            v55 = v55 + (float)((float)((float)(v68 + v67.m128_f32[0]) - v55) * v10);
            v57 = v57 + (float)((float)((float)(*(inbuffer_orig - 7) + v67.m128_f32[0]) - v57) * v10);
            v59 = v59 + (float)((float)((float)(*(inbuffer_orig - 6) + v67.m128_f32[0]) - v59) * v10);
            v61 = v61 + (float)((float)((float)(*(inbuffer_orig - 5) + v67.m128_f32[0]) - v61) * v10);
            v63 = v63 + (float)((float)((float)(*(inbuffer_orig - 4) + v67.m128_f32[0]) - v63) * v10);
            v65 = v65 + (float)((float)((float)(*(inbuffer_orig - 3) + v67.m128_f32[0]) - v65) * v10);
            v71 = (float)((float)((float)(*(inbuffer_orig - 2) + v67.m128_f32[0]) - v71) * v10) + v71;
            v69 = *(inbuffer_orig - 1) + v67.m128_f32[0];
            v67 = _mm_xor_ps(v67, (__m128)0x80000000);
            fyH1 = (float)((float)(v69 - fyH1) * v10) + fyH1;
            v56 = v56 + (float)((float)(v55 - v56) * v10);
            *(outbuffer_orig - 8) = v56;
            v58 = v58 + (float)((float)(v57 - v58) * v10);
            *(outbuffer_orig - 7) = v58;
            v60 = v60 + (float)((float)(v59 - v60) * v10);
            *(outbuffer_orig - 6) = v60;
            v62 = v62 + (float)((float)(v61 - v62) * v10);
            *(outbuffer_orig - 5) = v62;
            v64 = v64 + (float)((float)(v63 - v64) * v10);
            *(outbuffer_orig - 4) = v64;
            v66 = v66 + (float)((float)(v65 - v66) * v10);
            *(outbuffer_orig - 3) = v66;
            fyG2 = (float)((float)(v71 - fyG2) * v10) + fyG2;
            v54 = v54 + (float)((float)(fyH1 - v54) * v10);
            *(outbuffer_orig - 2) = fyG2;
            *(outbuffer_orig - 1) = v54;
            if ( !--length )
              break;
            v10 = *((float *)this + 197);
          }
          flt_286B158 = v67.m128_f32[0];
        }
        *((float *)this + 142) = v64;
        *((float *)this + 145) = v71;
        *((float *)this + 146) = fyG2;
        *((float *)this + 133) = v55;
        *((float *)this + 134) = v56;
        *((float *)this + 135) = v57;
        *((float *)this + 136) = v58;
        *((float *)this + 137) = v59;
        *((float *)this + 138) = v60;
        *((float *)this + 139) = v61;
        *((float *)this + 140) = v62;
        *((float *)this + 141) = v63;
        *((float *)this + 143) = v65;
        *((float *)this + 144) = v66;
        *((float *)this + 147) = fyH1;
        *((float *)this + 148) = v54;
      }
      else if ( inchannels > 0 )
      {
        v11 = (float *)((char *)this + 532);
        v12 = 4LL * inchannels;
        v13 = 0;
        v14 = (float *)((char *)this + 8 * (unsigned int)(inchannels - 1) + 540);
        v15 = (__m128)LODWORD(flt_286B158);
        do
        {
          v16 = &inbuffer_orig[v13];
          v17 = &outbuffer_orig[v13];
          v18 = *v11;
          v19 = v11[1];
          if ( length )
          {
            v20 = length;
            do
            {
              v21 = *v16;
              v16 = (float *)((char *)v16 + v12);
              v22 = v21 + v15.m128_f32[0];
              v23 = *((float *)this + 197);
              v15 = _mm_xor_ps(v15, (__m128)0x80000000);
              v18 = v18 + (float)((float)(v22 - v18) * v23);
              v19 = v19 + (float)((float)(v18 - v19) * v23);
              *v17 = v19;
              v17 = (float *)((char *)v17 + v12);
              --v20;
            }
            while ( v20 );
          }
          *v11 = v18;
          v11 += 2;
          ++v13;
          *(v11 - 1) = v19;
        }
        while ( v11 != v14 );
        flt_286B158 = v15.m128_f32[0];
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    v47 = *((float *)this + 133);
    v48 = *((float *)this + 134);
    v49 = *((float *)this + 135);
    v50 = *((float *)this + 136);
    if ( length )
    {
      v51 = (__m128)LODWORD(flt_286B158);
      while ( 1 )
      {
        v52 = *inbuffer_orig;
        outbuffer_orig += 2;
        inbuffer_orig += 2;
        v47 = v47 + (float)((float)((float)(v52 + v51.m128_f32[0]) - v47) * v10);
        v53 = *(inbuffer_orig - 1) + v51.m128_f32[0];
        v51 = _mm_xor_ps(v51, (__m128)0x80000000);
        v49 = v49 + (float)((float)(v53 - v49) * v10);
        v48 = v48 + (float)((float)(v47 - v48) * v10);
        *(outbuffer_orig - 2) = v48;
        v50 = v50 + (float)((float)(v49 - v50) * v10);
        *(outbuffer_orig - 1) = v50;
        if ( !--length )
          break;
        v10 = *((float *)this + 197);
      }
      flt_286B158 = v51.m128_f32[0];
    }
    *((float *)this + 133) = v47;
    *((float *)this + 134) = v48;
    *((float *)this + 135) = v49;
    *((float *)this + 136) = v50;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21e89d0 | Name: _ZN4FMOD16DSPLowPassSimple12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPLowPassSimple::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPLowPassSimple::readInternal(
           (FMOD::DSPLowPassSimple *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x21e89e0 | Name: _ZN4FMOD16DSPLowPassSimple25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPLowPassSimple::setParameterFloatInternal(
        FMOD::DSPLowPassSimple *const this,
        int index,
        float a3,
        float value)
{
  if ( !index )
    *((float *)this + 198) = a3;
  return 0;
}


// Address: 0x21e89f0 | Name: _ZN4FMOD16DSPLowPassSimple25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPLowPassSimple::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPLowPassSimple::setParameterFloatInternal(
           (FMOD::DSPLowPassSimple *const)dsp_state->instance,
           index,
           a3,
           value);
}


// Address: 0x21e8a00 | Name: _ZN4FMOD16DSPLowPassSimple25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPLowPassSimple::getParameterFloatInternal(
        FMOD::DSPLowPassSimple *const this,
        int index,
        float *value,
        char *valuestr)
{
  if ( index )
    return FMOD_RESULT::FMOD_OK_0;
  *value = *((float *)this + 198);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  sprintf(valuestr, "%.02f", *((float *)this + 198));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e8a50 | Name: _ZN4FMOD16DSPLowPassSimple25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPLowPassSimple::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPLowPassSimple::getParameterFloatInternal(
           (FMOD::DSPLowPassSimple *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


