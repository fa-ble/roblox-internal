// Address: 0x21d5040 | Name: _ZN4FMOD9DSPITEcho16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPITEcho::getDescriptionEx()
{
  memset(&stru_2AD8FC0, 0, sizeof(stru_2AD8FC0));
  FMOD_strcpy_safe(stru_2AD8FC0.name, "WetDryMix", 16);
  FMOD_strcpy_safe(stru_2AD8FC0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AD8FC0.floatdesc.min = 0x42C8000000000000LL;
  stru_2AD8FC0.description = "Ratio of wet (processed) signal to dry (unprocessed) signal. Must be in the range from 0.0 "
                             "through 100.0 (all wet). The default value is 50.";
  memset(&stru_2AD8F60, 0, sizeof(stru_2AD8F60));
  stru_2AD8FC0.intdesc.defaultval = 1112014848;
  stru_2AD8FC0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8F60.name, "Feedback", 16);
  FMOD_strcpy_safe(stru_2AD8F60.label, "%", 16);
  *(_QWORD *)&stru_2AD8F60.floatdesc.min = 0x42C8000000000000LL;
  stru_2AD8F60.description = "Percentage of output fed back into input, in the range from 0.0 through 100.0. The default value is 50.";
  memset(&stru_2AD8F00, 0, sizeof(stru_2AD8F00));
  stru_2AD8F60.intdesc.defaultval = 1112014848;
  stru_2AD8F60.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8F00.name, "LeftDelay", 16);
  FMOD_strcpy_safe(stru_2AD8F00.label, "ms", 16);
  *(_QWORD *)&stru_2AD8F00.floatdesc.min = 0x44FA00003F800000LL;
  stru_2AD8F00.description = "Delay for left channel, in milliseconds, in the range from 1.0 through 2000.0. The default "
                             "value is 500 ms.";
  memset(&stru_2AD8EA0, 0, sizeof(stru_2AD8EA0));
  stru_2AD8F00.intdesc.defaultval = 1140457472;
  stru_2AD8F00.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8EA0.name, "RightDelay", 16);
  FMOD_strcpy_safe(stru_2AD8EA0.label, "ms", 16);
  *(_QWORD *)&stru_2AD8EA0.floatdesc.min = 0x44FA00003F800000LL;
  stru_2AD8EA0.description = "Delay for right channel, in milliseconds, in the range from 1.0 through 2000.0. The default"
                             " value is 500 ms.";
  memset(&stru_2AD8E40, 0, sizeof(stru_2AD8E40));
  stru_2AD8EA0.intdesc.defaultval = 1140457472;
  stru_2AD8EA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AD8E40.name, "PanDelay", 16);
  FMOD_strcpy_safe(stru_2AD8E40.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AD8E40.floatdesc.min = 0x3F80000000000000LL;
  stru_2AD8E40.intdesc.defaultval = 0;
  stru_2AD8E40.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AD8E40.description = "Value that specifies whether to swap left and right delays with each successive echo. The d"
                             "efault value is zero, meaning no swap. Possible values are defined as 0.0 (equivalent to FA"
                             "LSE) and 1.0 (equivalent to TRUE).";
  *(&stru_2AD8E00.mHandle + 1) = 17;
  stru_2AD8E00.mSize = 648;
  stru_2AD8E00.mDescription = &stru_286A960;
  stru_2AD8E00.mCommand = FMOD::DSPITEcho::commandCallback;
  stru_2AD8E00.mCommandMask = 2;
  return &stru_2AD8E00;
}


// Address: 0x21d52f0 | Name: _ZN4FMOD9DSPITEcho15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::releaseInternal(FMOD::DSPITEcho *const this)
{
  __int64 i; // rbx
  void *v2; // rsi

  for ( i = 0; i != 16; i += 8 )
  {
    v2 = *(void **)((char *)this + i + 568);
    if ( v2 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v2, "../../../core_api/src/fmod_dsp_itecho.cpp", 186);
      *(_QWORD *)((char *)this + i + 568) = 0;
      *(_QWORD *)((char *)this + i + 552) = 0;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d5360 | Name: _ZN4FMOD9DSPITEcho15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPITEcho::releaseInternal((FMOD::DSPITEcho *const)dsp_state->instance);
}


// Address: 0x21d5370 | Name: _ZN4FMOD9DSPITEcho13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::resetInternal(FMOD::DSPITEcho *const this)
{
  void *v2; // rdi
  void *v3; // rdi

  *((_DWORD *)this + 148) = 0;
  *((_DWORD *)this + 149) = 0;
  v2 = (void *)*((_QWORD *)this + 69);
  if ( v2 )
    memset(v2, 0, *((unsigned int *)this + 146));
  v3 = (void *)*((_QWORD *)this + 70);
  if ( v3 )
    memset(v3, 0, *((unsigned int *)this + 147));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d53c0 | Name: _ZN4FMOD9DSPITEcho13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPITEcho::resetInternal((FMOD::DSPITEcho *const)dsp_state->instance);
}


// Address: 0x21d53d0 | Name: _ZN4FMOD9DSPITEcho15processInternalEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::processInternal(
        FMOD::DSPITEcho *const this,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  int v7; // r12d
  int v8; // ebp
  float *v9; // rdi
  FMOD::DSPITEcho *v10; // r13
  __int64 v11; // rsi
  unsigned __int64 v12; // r15
  float *v13; // rbp
  float *v14; // r11
  __int64 v15; // r14
  unsigned int v16; // r10d
  unsigned int i; // edx
  unsigned int v18; // ecx
  unsigned int v19; // r9d
  unsigned int v20; // r8d
  __int64 v21; // rax
  __int64 v22; // r12
  float *v23; // rcx
  float *v24; // rdx
  __int64 v25; // r12
  __int64 v26; // rdi
  float v27; // xmm1_4
  unsigned int v28; // eax
  FMOD_RESULT_0 result; // eax
  unsigned int v30; // edx
  float *inbuffer; // [rsp+8h] [rbp-50h]
  float *outbuffer; // [rsp+10h] [rbp-48h]
  __int64 v34; // [rsp+18h] [rbp-40h]

  if ( op != FMOD_DSP_PROCESS_QUERY )
  {
    v7 = 2;
    v8 = *inbufferarray->buffernumchannels;
    if ( v8 <= 2 )
      v7 = *inbufferarray->buffernumchannels;
    v9 = *inbufferarray->buffers;
    inbuffer = v9;
    outbuffer = *outbufferarray->buffers;
    if ( v9 )
    {
      if ( v8 > 2 )
        memcpy_0(*(void **)outbufferarray->buffers, v9, 4LL * v8 * length);
      if ( v7 > 0 )
      {
        v10 = this;
        v11 = 4LL * v8;
        v12 = 0;
        v34 = 4LL * (unsigned int)(v7 - 1) + 4;
        do
        {
          v13 = &inbuffer[v12 / 4];
          v14 = &outbuffer[v12 / 4];
          if ( length )
          {
            v15 = *(_QWORD *)((char *)this + 2 * v12 + 552);
            v16 = *((_DWORD *)v10 + 150);
            for ( i = length; ; i = v19 )
            {
              v18 = *((_DWORD *)v10 + 148);
              v19 = 0;
              v20 = i + v18;
              v21 = v15 + 4LL * v18;
              if ( i + v18 > v16 )
              {
                v20 = v16;
                v19 = i - (v16 - v18);
                i = v16 - v18;
              }
              if ( i )
              {
                v22 = i - 1;
                v23 = v13;
                v24 = v14;
                v25 = v22 + 1;
                v26 = v21 + 4 * v25;
                do
                {
                  v27 = *v23;
                  v21 += 4;
                  v23 = (float *)((char *)v23 + v11);
                  *v24 = (float)((float)(1.0 - *((float *)this + 132)) * v27)
                       + (float)(*((float *)this + 132) * *(float *)(v21 - 4));
                  v24 = (float *)((char *)v24 + v11);
                  *(float *)(v21 - 4) = (float)(*(float *)(v21 - 4) * *((float *)this + 133)) + v27;
                }
                while ( v21 != v26 );
                v13 = (float *)((char *)v13 + v11 * v25);
                v14 = (float *)((char *)v14 + v11 * v25);
              }
              v28 = 0;
              if ( v16 > v20 )
                v28 = v20;
              *((_DWORD *)v10 + 148) = v28;
              if ( !v19 )
                break;
            }
          }
          v12 += 4LL;
          v10 = (FMOD::DSPITEcho *)((char *)v10 + 4);
        }
        while ( v12 != v34 );
      }
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( outbufferarray )
    *outbufferarray->buffernumchannels = *inbufferarray->buffernumchannels;
  v30 = *((_DWORD *)this + 154);
  if ( v30 == -1 )
    return FMOD_RESULT::FMOD_OK_0;
  if ( inputsidle )
  {
    v30 = *((_DWORD *)this + 155);
    result = FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
    if ( !v30 )
      return result;
  }
  else
  {
    *((_DWORD *)this + 155) = v30;
  }
  if ( length < v30 )
  {
    *((_DWORD *)this + 155) = v30 - length;
    return FMOD_RESULT::FMOD_OK_0;
  }
  *((_DWORD *)this + 155) = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d5600 | Name: _ZN4FMOD9DSPITEcho15processCallbackEP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS3_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::processCallback(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  return FMOD::DSPITEcho::processInternal(
           (FMOD::DSPITEcho *const)dsp_state->instance,
           length,
           inbufferarray,
           outbufferarray,
           inputsidle,
           op);
}


// Address: 0x21d5610 | Name: _ZN4FMOD9DSPITEcho25setParameterFloatInternalEifb
__int64 __fastcall FMOD::DSPITEcho::setParameterFloatInternal(FMOD::DSPI *this, int index, float value, bool apply)
{
  FMOD_RESULT_0 v5; // ebx
  FMOD::DSPQueueCmd_UpdateParameters *v7; // rsi
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 v9; // eax
  FMOD::DSPQueueCmd_UpdateParameters *cmd; // [rsp+8h] [rbp-20h] BYREF

  switch ( index )
  {
    case 0:
      *((float *)this + 156) = value / 100.0;
      goto LABEL_3;
    case 1:
      *((float *)this + 157) = value / 100.0;
      goto LABEL_3;
    case 2:
      *((float *)this + 158) = value;
      goto LABEL_3;
    case 3:
      *((float *)this + 159) = value;
LABEL_3:
      v5 = FMOD_RESULT::FMOD_OK_0;
      if ( !apply )
        return (unsigned int)v5;
      goto LABEL_6;
    case 4:
      v5 = FMOD_RESULT::FMOD_OK_0;
      *((_DWORD *)this + 160) = value >= 0.5;
      if ( !apply )
        return (unsigned int)v5;
LABEL_6:
      v5 = FMOD::SystemI::lockDSPQueueCmd(this->mSystem, (void **)&cmd, 16, 1);
      if ( v5 )
        return (unsigned int)v5;
      v7 = cmd;
      mSystem = this->mSystem;
      cmd->mThis = this;
      *(_BYTE *)&v7->FMOD::DSPQueueCmd = 7;
      v9 = FMOD::SystemI::unlockDSPQueueCmd(mSystem, v7, 1);
      if ( v9 )
        return (unsigned int)v9;
      return (unsigned int)v5;
    default:
      return 0;
  }
}


// Address: 0x21d5710 | Name: _ZN4FMOD9DSPITEcho25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPITEcho::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPITEcho::setParameterFloatInternal((FMOD::DSPI *)dsp_state->instance, index, a3, 1);
}


// Address: 0x21d5720 | Name: _ZN4FMOD9DSPITEcho25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::getParameterFloatInternal(
        FMOD::DSPITEcho *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v4; // xmm0_4
  float v6; // xmm0_4
  const char *v7; // rsi

  switch ( index )
  {
    case 0:
      *value = *((float *)this + 156) * 100.0;
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
      v4 = 100.0 * *((float *)this + 156);
      goto LABEL_4;
    case 1:
      *value = *((float *)this + 157) * 100.0;
      if ( valuestr )
      {
        v4 = 100.0 * *((float *)this + 157);
LABEL_4:
        sprintf(valuestr, "%.1f", v4);
      }
      return FMOD_RESULT::FMOD_OK_0;
    case 2:
      *value = *((float *)this + 158);
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
      v6 = *((float *)this + 158);
      goto LABEL_8;
    case 3:
      *value = *((float *)this + 159);
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
      v6 = *((float *)this + 159);
LABEL_8:
      sprintf(valuestr, "%.02f", v6);
      return FMOD_RESULT::FMOD_OK_0;
    case 4:
      if ( !*((_DWORD *)this + 160) )
      {
        *value = 0.0;
        v7 = "off";
        if ( valuestr )
          goto LABEL_11;
        return FMOD_RESULT::FMOD_OK_0;
      }
      *value = 1.0;
      v7 = "on";
      if ( !valuestr )
        return FMOD_RESULT::FMOD_OK_0;
LABEL_11:
      strcpy(valuestr, v7);
      return FMOD_RESULT::FMOD_OK_0;
    default:
      return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21d5870 | Name: _ZN4FMOD9DSPITEcho25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPITEcho::getParameterFloatInternal((FMOD::DSPITEcho *const)dsp_state->instance, index, value, valuestr);
}


// Address: 0x21d5880 | Name: _ZN4FMOD9DSPITEcho15updateDecayTimeEv
void __fastcall FMOD::DSPITEcho::updateDecayTime(FMOD::DSPITEcho *const this)
{
  float v1; // xmm0_4
  float v2; // xmm2_4
  float v3; // xmm0_4
  float v4; // xmm3_4
  int v5; // eax
  float v6; // xmm6_4
  float v7; // xmm5_4
  float v8; // xmm0_4
  float v9; // [rsp+4h] [rbp-14h]

  v1 = *((float *)this + 132);
  v2 = fmaxf(*((float *)this + 134), *((float *)this + 135));
  if ( v1 > 0.0 )
    v3 = log10f(v1) * 20.0;
  else
    v3 = -80.0;
  v4 = *((float *)this + 133);
  v5 = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  if ( v4 >= 1.0 )
  {
    *((_DWORD *)this + 154) = -1;
  }
  else
  {
    v6 = v3 + 100.0;
    v7 = (float)v5;
    v8 = -80.0;
    if ( v4 > 0.0 )
    {
      v9 = (float)v5;
      v8 = log10f(*((float *)this + 133)) * 20.0;
      v7 = v9;
    }
    *((_DWORD *)this + 154) = (int)(float)((float)((float)((float)(1.0 - (float)(v6 / v8)) * v7) * v2) / 1000.0);
  }
}


// Address: 0x21d59b0 | Name: _ZN4FMOD9DSPITEcho15commandInternalEjPvS1_
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::commandInternal(
        FMOD::DSPITEcho *const this,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *commanddata1,
        void *commanddata2)
{
  FMOD_RESULT_0 result; // eax
  __int64 v5; // rax
  float v6; // xmm0_4
  bool v7; // zf
  int v8; // edx
  char v9; // r14
  float v10; // xmm0_4
  float v11; // xmm0_4
  float v12; // xmm0_4
  int v13; // eax
  FMOD::DSPITEcho *v14; // rbp
  FMOD::DSPITEcho *v15; // r12
  __int64 v16; // r13
  char v17; // al
  int v18; // edx
  void *v19; // rsi
  FMOD::Global *v20; // rax
  int v21; // edx
  void *v22; // rax
  float v23; // [rsp+0h] [rbp-54h]
  char v24; // [rsp+0h] [rbp-54h]
  bool reallocbuffer[72]; // [rsp+Ch] [rbp-48h]

  result = FMOD_RESULT::FMOD_OK_0;
  if ( type == 2 )
  {
    v5 = *((_QWORD *)this + 22);
    v6 = *((float *)this + 156);
    reallocbuffer[0] = 0;
    v7 = v6 == *((float *)this + 132);
    reallocbuffer[1] = 0;
    v8 = *(_DWORD *)(v5 + 1696);
    if ( v7 )
    {
      v9 = 0;
    }
    else
    {
      *((float *)this + 132) = v6;
      v9 = 1;
    }
    v10 = *((float *)this + 157);
    if ( v10 != *((float *)this + 133) )
    {
      *((float *)this + 133) = v10;
      v9 = 1;
    }
    v11 = *((float *)this + 158);
    if ( v11 != *((float *)this + 134) )
    {
      *((float *)this + 134) = v11;
      reallocbuffer[0] = 1;
      v9 = 1;
    }
    v12 = *((float *)this + 159);
    if ( v12 != *((float *)this + 135) )
    {
      *((float *)this + 135) = v12;
      reallocbuffer[1] = 1;
      v9 = 1;
    }
    v13 = *((_DWORD *)this + 160);
    if ( *((_DWORD *)this + 136) != v13 )
      *((_DWORD *)this + 136) = v13;
    v14 = this;
    v15 = this;
    v16 = 0;
    v17 = 0;
    v23 = (float)v8;
    do
    {
      if ( reallocbuffer[v16] || !*((_QWORD *)v14 + 69) )
      {
        v18 = (int)(float)(v23 * *((float *)v15 + 134)) / 1000;
        *((_DWORD *)v15 + 150) = v18;
        v19 = (void *)*((_QWORD *)v14 + 71);
        if ( v19 )
        {
          FMOD::MemPool::free(off_286F358->gSystemMemPool, v19, "../../../core_api/src/fmod_dsp_itecho.cpp", 569);
          *((_QWORD *)v14 + 71) = 0;
          *((_QWORD *)v14 + 69) = 0;
          v18 = *((_DWORD *)v15 + 150);
        }
        v20 = off_286F358;
        v21 = 4 * v18;
        *((_DWORD *)v15 + 146) = v21;
        v22 = FMOD::MemPool::calloc(v20->gSystemMemPool, v21 + 128, "../../../core_api/src/fmod_dsp_itecho.cpp", 576, 0);
        *((_QWORD *)v14 + 71) = v22;
        if ( !v22 )
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        *((_QWORD *)v14 + 69) = ((unsigned __int64)v22 + 127) & 0xFFFFFFFFFFFFFF80LL;
        v17 = 1;
      }
      ++v16;
      v14 = (FMOD::DSPITEcho *)((char *)v14 + 8);
      v15 = (FMOD::DSPITEcho *)((char *)v15 + 4);
    }
    while ( v16 != 2 );
    if ( v17 || v9 )
    {
      v24 = v17;
      FMOD::DSPITEcho::updateDecayTime(this);
      if ( v24 )
        FMOD::DSPITEcho::resetInternal(this);
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21d5c10 | Name: _ZN4FMOD9DSPITEcho14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::createInternal(FMOD::DSPITEcho *const this)
{
  __int64 v1; // rbp
  __int64 v2; // rax
  int v3; // ebx
  FMOD_RESULT_0 result; // eax

  v1 = 0;
  v2 = *((_QWORD *)this + 30);
  v3 = 0;
  if ( *(int *)(v2 + 96) <= 0 )
    return FMOD::DSPITEcho::commandInternal(this, 2u, 0, 0);
  while ( 1 )
  {
    result = (unsigned int)FMOD::DSPITEcho::setParameterFloatInternal(
                             (FMOD::DSPI *)this,
                             v3,
                             *(float *)(*(_QWORD *)(*(_QWORD *)(v2 + 104) + v1) + 56LL),
                             0);
    if ( result )
      break;
    v2 = *((_QWORD *)this + 30);
    ++v3;
    v1 += 8;
    if ( *(_DWORD *)(v2 + 96) <= v3 )
      return FMOD::DSPITEcho::commandInternal(this, 2u, 0, 0);
  }
  return result;
}


// Address: 0x21d5c90 | Name: _ZN4FMOD9DSPITEcho14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPITEcho::createInternal((FMOD::DSPITEcho *const)dsp_state->instance);
}


// Address: 0x21d5ca0 | Name: _ZN4FMOD9DSPITEcho15commandCallbackEP14FMOD_DSP_STATEjPvS3_
FMOD_RESULT_0 __fastcall FMOD::DSPITEcho::commandCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *commanddata1,
        void *commanddata2)
{
  return FMOD::DSPITEcho::commandInternal((FMOD::DSPITEcho *const)dsp_state->instance, type, commanddata1, commanddata2);
}


