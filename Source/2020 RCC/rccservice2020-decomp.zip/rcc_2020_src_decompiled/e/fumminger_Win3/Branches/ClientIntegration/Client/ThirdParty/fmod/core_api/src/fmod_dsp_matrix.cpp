// Address: 0x224b930 | Name: _ZN4FMOD9DSPMatrix5resetEPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::DSPMatrix::reset(FMOD::DSPMatrix *const this, FMOD::SystemI *system)
{
  float *mData; // rax

  mData = this->mData;
  if ( mData )
    FMOD::MemPool::free(&system->mDSPLevelsPool, mData, (const char *)&uri_string, 0);
  this->mData = 0;
  this->mInChannels = 0;
  this->mOutChannels = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x224b970 | Name: _ZN4FMOD9DSPMatrix4copyEPNS_7SystemIEPS0_
FMOD_RESULT_0 __fastcall FMOD::DSPMatrix::copy(
        FMOD::DSPMatrix *const this,
        FMOD::SystemI *system,
        FMOD::DSPMatrix *source)
{
  float *mData; // rdi
  FMOD_RESULT_0 result; // eax
  float *v7; // rsi
  int v8; // edx
  int v9; // eax
  __int16 mInChannels; // dx
  __int16 mOutChannels; // ax

  mData = this->mData;
  if ( mData )
  {
    if ( this->mOutChannels * this->mInChannels == source->mOutChannels * source->mInChannels )
      goto LABEL_5;
    result = FMOD::DSPMatrix::reset(this, system);
    if ( result )
      return result;
    mData = this->mData;
    if ( mData )
      goto LABEL_5;
  }
  if ( !source->mData )
    return FMOD_RESULT::FMOD_OK_0;
  mData = (float *)FMOD::MemPool::alloc(
                     &system->mDSPLevelsPool,
                     4 * source->mOutChannels * source->mInChannels,
                     (const char *)&uri_string,
                     0,
                     0,
                     0);
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( mData )
  {
    mInChannels = source->mInChannels;
    mOutChannels = source->mOutChannels;
    this->mData = mData;
    this->mInChannels = mInChannels;
    this->mOutChannels = mOutChannels;
LABEL_5:
    v7 = source->mData;
    if ( v7 )
    {
      if ( this != source )
      {
        v8 = source->mInChannels;
        v9 = source->mOutChannels;
        this->mInChannels = v8;
        this->mOutChannels = v9;
        memcpy_0(mData, v7, 4LL * v9 * v8);
      }
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x224ba50 | Name: _ZN4FMOD9DSPMatrix3setEPfiii
FMOD_RESULT_0 __fastcall FMOD::DSPMatrix::set(
        FMOD::DSPMatrix *const this,
        float *matrix,
        int outchannels,
        int inchannels,
        int inchannel_hop)
{
  FMOD_RESULT_0 result; // eax
  float *mData; // r13
  int mOutChannels; // r14d
  int mInChannels; // r10d
  int v9; // r12d
  int v10; // ebp
  int i; // ebx
  float *v12; // r9
  __int64 v13; // rax
  float v14; // xmm0_4

  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( !inchannel_hop )
    inchannel_hop = inchannels;
  mData = this->mData;
  if ( mData )
  {
    LOBYTE(result) = 31;
    if ( matrix )
    {
      mOutChannels = this->mOutChannels;
      if ( mOutChannels == outchannels && inchannel_hop == inchannels && inchannel_hop == this->mInChannels )
      {
        memcpy_0(this->mData, matrix, 4LL * mOutChannels * inchannel_hop);
      }
      else if ( mOutChannels > 0 )
      {
        mInChannels = this->mInChannels;
        v9 = 0;
        v10 = 0;
        for ( i = 0; i < mOutChannels; ++i )
        {
          if ( mInChannels > 0 )
          {
            v12 = &mData[v9];
            v13 = 0;
            do
            {
              while ( inchannels > (int)v13 && outchannels > i )
              {
                v14 = matrix[v10 + v13++];
                *v12++ = v14;
                if ( mInChannels <= (int)v13 )
                  goto LABEL_14;
              }
              ++v13;
              *v12++ = 0.0;
            }
            while ( mInChannels > (int)v13 );
          }
LABEL_14:
          v10 += inchannel_hop;
          v9 += mInChannels;
        }
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x224bb40 | Name: _ZN4FMOD9DSPMatrix3getEPfPiS2_i
FMOD_RESULT_0 __fastcall FMOD::DSPMatrix::get(
        FMOD::DSPMatrix *const this,
        float *matrix,
        int *outchannels,
        int *inchannels,
        int inchannel_hop)
{
  int v7; // ebx
  int v8; // r11d
  float *mData; // rsi
  int v10; // r12d
  int v11; // ebp
  int v12; // r10d
  float *v13; // rdx
  int v14; // eax
  int mInChannels; // ecx

  if ( matrix )
  {
    if ( outchannels && inchannels )
    {
      if ( !*outchannels )
        *outchannels = this->mOutChannels;
      if ( !*inchannels )
        *inchannels = this->mInChannels;
      v7 = *outchannels;
      if ( *outchannels > 32 )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      v8 = *inchannels;
      if ( (unsigned int)*inchannels > 0x20 || v7 < 0 )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      mData = this->mData;
      if ( !inchannel_hop )
        inchannel_hop = *inchannels;
      if ( mData && v7 == this->mOutChannels && inchannel_hop == this->mInChannels )
      {
        memcpy_0(matrix, mData, 4LL * v8 * v7);
        return FMOD_RESULT::FMOD_OK_0;
      }
      if ( !v7 )
        return FMOD_RESULT::FMOD_OK_0;
      v10 = 0;
      v11 = 0;
      v12 = 0;
      while ( !v8 )
      {
LABEL_36:
        ++v12;
        v11 += inchannel_hop;
        v10 += inchannel_hop + 1;
        if ( v12 == v7 )
          return FMOD_RESULT::FMOD_OK_0;
      }
      v13 = &matrix[v11];
      v14 = 0;
      while ( mData )
      {
        if ( this->mOutChannels <= v12 )
          goto LABEL_26;
        mInChannels = this->mInChannels;
        if ( mInChannels <= v14 )
          goto LABEL_26;
        *v13 = mData[v14 + v12 * mInChannels];
LABEL_23:
        ++v14;
        ++v13;
        if ( v14 == v8 )
          goto LABEL_36;
      }
      if ( v14 == v12 )
      {
        matrix[v10] = 1.0;
        goto LABEL_23;
      }
LABEL_26:
      *v13 = 0.0;
      goto LABEL_23;
    }
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  if ( !outchannels && !inchannels )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( outchannels )
    *outchannels = this->mOutChannels;
  if ( inchannels )
    *inchannels = this->mInChannels;
  return FMOD_RESULT::FMOD_OK_0;
}


