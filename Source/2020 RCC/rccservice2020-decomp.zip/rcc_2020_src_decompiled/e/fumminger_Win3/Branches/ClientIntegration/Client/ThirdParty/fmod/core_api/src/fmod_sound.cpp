// Address: 0x2215e00 | Name: _ZN4FMOD5Sound7releaseEv
FMOD_RESULT_0 __fastcall FMOD::Sound::release(FMOD::Sound *const this)
{
  FMOD_RESULT_0 updated; // ebx
  FMOD::SystemI *mSystem; // r12
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  updated = FMOD::SoundI::validate(this, &soundi, 0);
  if ( updated == FMOD_RESULT::FMOD_OK_0 )
  {
    mSystem = soundi->mSystem;
    if ( mSystem )
    {
      updated = FMOD::SystemI::enterMainUpdateLock(soundi->mSystem);
      if ( updated == FMOD_RESULT::FMOD_OK_0 )
      {
        updated = (*((unsigned int (__fastcall **)(FMOD::SoundI *, __int64))soundi->_vptr_SoundI + 3))(soundi, 1);
        FMOD::SystemI::leaveMainUpdateLock(mSystem);
        if ( updated == FMOD_RESULT::FMOD_OK_0 )
          return updated;
      }
    }
    else
    {
      updated = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    }
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) >= 0 )
    return updated;
  _buffer[0] = 0;
  FMOD_ReportError(
    updated,
    FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
    this,
    "Sound::release",
    _buffer);
  return updated;
}


// Address: 0x2215ec0 | Name: _ZN4FMOD5Sound15getSystemObjectEPPNS_6SystemE
FMOD_RESULT_0 __fastcall FMOD::Sound::getSystemObject(FMOD::Sound *const this, FMOD::System **system)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD::System **))soundi->_vptr_SoundI + 4))(soundi, system);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, system);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
      this,
      "Sound::getSystemObject",
      _buffer);
  }
  return v2;
}


// Address: 0x2215f80 | Name: _ZN4FMOD5Sound4lockEjjPPvS2_PjS3_
FMOD_RESULT_0 __fastcall FMOD::Sound::lock(
        FMOD::Sound *const this,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  FMOD_RESULT_0 v9; // r14d
  int v11; // eax
  int v12; // eax
  int v13; // r13d
  int v14; // r13d
  int v15; // r13d
  int v16; // r13d
  int v17; // r13d
  int v18; // eax
  unsigned int lengthb; // [rsp+18h] [rbp-150h]
  int v22; // [rsp+1Ch] [rbp-14Ch]
  FMOD::SoundLockScope lockScope; // [rsp+20h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+28h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+30h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v9 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v9
    || soundi->mOpenState.m_value
    && (LOBYTE(v9) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v9 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD, _QWORD, void **, void **, unsigned int *, unsigned int *))soundi->_vptr_SoundI
              + 5))(
               soundi,
               offset,
               length,
               ptr1,
               ptr2,
               len1,
               len2)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v22 = FMOD::FMOD_FormatArg(_buffer, 256, offset);
      v11 = FMOD::FMOD_FormatArg(&_buffer[v22], 256 - v22, ", ");
      lengthb = FMOD::FMOD_FormatArg(&_buffer[v11 + v22], 256 - (v11 + v22), length) + v11 + v22;
      v12 = FMOD::FMOD_FormatArg(&_buffer[lengthb], 256 - lengthb, ", ");
      v13 = v12 + lengthb + FMOD::FMOD_FormatArg(&_buffer[v12 + lengthb], 256 - (v12 + lengthb), ptr1);
      v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, ", ") + v13;
      v15 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, ptr2) + v14;
      v16 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ") + v15;
      v17 = FMOD::FMOD_FormatArg(&_buffer[v16], 256 - v16, len1) + v16;
      v18 = FMOD::FMOD_FormatArg(&_buffer[v17], 256 - v17, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v18 + v17], 256 - (v18 + v17), len2);
      FMOD_ReportError(
        v9,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::lock",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v9;
}


// Address: 0x22161b0 | Name: _ZN4FMOD5Sound6unlockEPvS1_jj
FMOD_RESULT_0 __fastcall FMOD::Sound::unlock(
        FMOD::Sound *const this,
        void *ptr1,
        void *ptr2,
        unsigned int len1,
        unsigned int len2)
{
  FMOD_RESULT_0 v7; // r14d
  int v9; // eax
  int v10; // r13d
  int v11; // r13d
  int v12; // r13d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v7
    || soundi->mOpenState.m_value
    && (LOBYTE(v7) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v7 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, void *, void *, _QWORD, _QWORD))soundi->_vptr_SoundI + 6))(
               soundi,
               ptr1,
               ptr2,
               len1,
               len2)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v15 = FMOD::FMOD_FormatArg(_buffer, 256, ptr1);
      v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
      v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), ptr2);
      v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
      v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, len1) + v11;
      v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), len2);
      FMOD_ReportError(
        v7,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::unlock",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v7;
}


// Address: 0x2216360 | Name: _ZN4FMOD5Sound11setDefaultsEfi
__int64 __fastcall FMOD::Sound::setDefaults(FMOD::Sound *const this, float a2, double frequency, unsigned int priority)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r14d
  int v7; // eax
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v4
    || soundi->mOpenState.m_value
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD, float, double))soundi->_vptr_SoundI + 7))(
               soundi,
               priority,
               a2,
               frequency)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, *(float *)&frequency);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), priority);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::setDefaults",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return (unsigned int)v4;
}


// Address: 0x22164a0 | Name: _ZN4FMOD5Sound11getDefaultsEPfPi
FMOD_RESULT_0 __fastcall FMOD::Sound::getDefaults(FMOD::Sound *const this, float *frequency, int *priority)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  v4 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v4
    || soundi->mOpenState.m_value
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, float *, int *))soundi->_vptr_SoundI + 8))(
               soundi,
               frequency,
               priority)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, frequency);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), priority);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getDefaults",
        _buffer);
    }
  }
  return v4;
}


// Address: 0x22165b0 | Name: _ZN4FMOD5Sound19set3DMinMaxDistanceEff
__int64 __fastcall FMOD::Sound::set3DMinMaxDistance(FMOD::Sound *const this, float a2, float min, double max)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v4
    || soundi->mOpenState.m_value
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v4 = (*((unsigned int (__fastcall **)(float, float, double))soundi->_vptr_SoundI + 9))(a2, min, max)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, min);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), min);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::set3DMinMaxDistance",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return (unsigned int)v4;
}


// Address: 0x2216700 | Name: _ZN4FMOD5Sound19get3DMinMaxDistanceEPfS1_
FMOD_RESULT_0 __fastcall FMOD::Sound::get3DMinMaxDistance(FMOD::Sound *const this, float *min, float *max)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  v4 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v4
    || soundi->mOpenState.m_value
    && soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, float *, float *))soundi->_vptr_SoundI + 10))(
               soundi,
               min,
               max)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, min);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), max);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::get3DMinMaxDistance",
        _buffer);
    }
  }
  return v4;
}


// Address: 0x2216810 | Name: _ZN4FMOD5Sound17set3DConeSettingsEfff
__int64 __fastcall FMOD::Sound::set3DConeSettings(
        FMOD::Sound *const this,
        float a2,
        float insideconeangle,
        float outsideconeangle,
        double outsidevolume)
{
  FMOD_RESULT_0 v5; // ebx
  int v7; // r14d
  int v8; // r14d
  int v9; // r14d
  int v10; // eax
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v5 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v5
    || soundi->mOpenState.m_value
    && soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0
    && (LOBYTE(v5) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0)
    || (v5 = (*((unsigned int (__fastcall **)(float, float, float, double))soundi->_vptr_SoundI + 11))(
               a2,
               insideconeangle,
               outsideconeangle,
               outsidevolume)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v7 = FMOD::FMOD_FormatArg(_buffer, 256, insideconeangle);
      v8 = FMOD::FMOD_FormatArg(&_buffer[v7], 256 - v7, ", ") + v7;
      v9 = FMOD::FMOD_FormatArg(&_buffer[v8], 256 - v8, insideconeangle) + v8;
      v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), insideconeangle);
      FMOD_ReportError(
        v5,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::set3DConeSettings",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return (unsigned int)v5;
}


// Address: 0x22169a0 | Name: _ZN4FMOD5Sound17get3DConeSettingsEPfS1_S1_
FMOD_RESULT_0 __fastcall FMOD::Sound::get3DConeSettings(
        FMOD::Sound *const this,
        float *insideconeangle,
        float *outsideconeangle,
        float *outsidevolume)
{
  FMOD_RESULT_0 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  v6 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v6
    || soundi->mOpenState.m_value
    && soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0
    && (LOBYTE(v6) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0)
    || (v6 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, float *, float *, float *))soundi->_vptr_SoundI + 12))(
               soundi,
               insideconeangle,
               outsideconeangle,
               outsidevolume)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v11 = FMOD::FMOD_FormatArg(_buffer, 256, insideconeangle);
      v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
      v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), outsideconeangle);
      v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), outsidevolume);
      FMOD_ReportError(
        v6,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::get3DConeSettings",
        _buffer);
    }
  }
  return v6;
}


// Address: 0x2216b00 | Name: _ZN4FMOD5Sound18set3DCustomRolloffEP11FMOD_VECTORi
FMOD_RESULT_0 __fastcall FMOD::Sound::set3DCustomRolloff(FMOD::Sound *const this, FMOD_VECTOR *points, int numpoints)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v4
    || soundi->mOpenState.m_value
    && soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD_VECTOR *, _QWORD))soundi->_vptr_SoundI + 13))(
               soundi,
               points,
               (unsigned int)numpoints)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, points);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), numpoints);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::set3DCustomRolloff",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v4;
}


// Address: 0x2216c30 | Name: _ZN4FMOD5Sound18get3DCustomRolloffEPP11FMOD_VECTORPi
FMOD_RESULT_0 __fastcall FMOD::Sound::get3DCustomRolloff(FMOD::Sound *const this, FMOD_VECTOR **points, int *numpoints)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  v4 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v4
    || soundi->mOpenState.m_value
    && soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD_VECTOR **, int *))soundi->_vptr_SoundI + 14))(
               soundi,
               points,
               numpoints)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, points);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), numpoints);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::get3DCustomRolloff",
        _buffer);
    }
  }
  return v4;
}


// Address: 0x2216d40 | Name: _ZN4FMOD5Sound11getSubSoundEiPPS0_
FMOD_RESULT_0 __fastcall FMOD::Sound::getSubSound(FMOD::Sound *const this, int index, FMOD::Sound **subsound)
{
  FMOD_RESULT_0 v4; // ebx
  FMOD::AsyncData *mAsyncData; // rax
  int v7; // r12d
  int v8; // eax
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v4 == FMOD_RESULT::FMOD_OK_0 )
  {
    mAsyncData = soundi->mAsyncData;
    if ( mAsyncData )
    {
      if ( soundi->mOpenState.m_value && mAsyncData->mResult != FMOD_RESULT::FMOD_ERR_FILE_DISKEJECTED_0 )
        goto LABEL_5;
    }
    else if ( soundi->mOpenState.m_value )
    {
LABEL_5:
      v4 = FMOD_RESULT::FMOD_ERR_NOTREADY_0;
      goto LABEL_6;
    }
    v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD, FMOD::Sound **))soundi->_vptr_SoundI + 15))(
           soundi,
           (unsigned int)index,
           subsound);
    if ( v4 == FMOD_RESULT::FMOD_OK_0 )
      goto LABEL_8;
  }
LABEL_6:
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v7 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v8 = FMOD::FMOD_FormatArg(&_buffer[v7], 256 - v7, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v8 + v7], 256 - (v8 + v7), subsound);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
      this,
      "Sound::getSubSound",
      _buffer);
  }
LABEL_8:
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v4;
}


// Address: 0x2216e90 | Name: _ZN4FMOD5Sound17getSubSoundParentEPPS0_
FMOD_RESULT_0 __fastcall FMOD::Sound::getSubSoundParent(FMOD::Sound *const this, FMOD::Sound **parentsound)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD::SoundI::validate(this, &soundi, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::SoundI *, FMOD::Sound **))soundi->_vptr_SoundI + 16))(
             soundi,
             parentsound);
  return result;
}


// Address: 0x2216ec0 | Name: _ZN4FMOD5Sound7getNameEPci
FMOD_RESULT_0 __fastcall FMOD::Sound::getName(FMOD::Sound *const this, char *name, int namelen)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v4
    || soundi->mOpenState.m_value
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, char *, _QWORD))soundi->_vptr_SoundI + 18))(
               soundi,
               name,
               (unsigned int)namelen)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, name);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), namelen);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getName",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v4;
}


// Address: 0x2216ff0 | Name: _ZN4FMOD5Sound9getLengthEPjj
FMOD_RESULT_0 __fastcall FMOD::Sound::getLength(
        FMOD::Sound *const this,
        unsigned int *length,
        FMOD_TIMEUNIT lengthtype)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v4
    || soundi->mOpenState.m_value
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, unsigned int *, _QWORD))soundi->_vptr_SoundI + 19))(
               soundi,
               length,
               lengthtype)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, length);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), lengthtype);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getLength",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v4;
}


// Address: 0x2217120 | Name: _ZN4FMOD5Sound9getFormatEP15FMOD_SOUND_TYPEP17FMOD_SOUND_FORMATPiS5_
FMOD_RESULT_0 __fastcall FMOD::Sound::getFormat(
        FMOD::Sound *const this,
        FMOD_SOUND_TYPE_1 *type,
        FMOD_SOUND_FORMAT_1 *format,
        int *channels,
        int *bits)
{
  FMOD_RESULT_0 v8; // eax
  __int64 v9; // r9
  int v11; // eax
  int v12; // r13d
  int v13; // r13d
  int v14; // r13d
  int v15; // eax
  int v16; // [rsp+8h] [rbp-150h]
  FMOD_RESULT_0 __result; // [rsp+Ch] [rbp-14Ch]
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  v8 = FMOD::SoundI::validate(this, &soundi, 0);
  v9 = (unsigned int)v8;
  if ( v8
    || soundi->mOpenState.m_value
    && (LOBYTE(v9) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (LODWORD(v9) = (*((__int64 (__fastcall **)(FMOD::SoundI *, FMOD_SOUND_TYPE_1 *, FMOD_SOUND_FORMAT_1 *, int *, int *, __int64))soundi->_vptr_SoundI
                       + 20))(
                        soundi,
                        type,
                        format,
                        channels,
                        bits,
                        v9),
        (_DWORD)v9) )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      __result = (int)v9;
      v16 = FMOD::FMOD_FormatArg(_buffer, 256, type);
      v11 = FMOD::FMOD_FormatArg(&_buffer[v16], 256 - v16, ", ");
      v12 = v11 + v16 + FMOD::FMOD_FormatArg(&_buffer[v11 + v16], 256 - (v11 + v16), format);
      v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ") + v12;
      v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, channels) + v13;
      v15 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v15 + v14], 256 - (v15 + v14), bits);
      FMOD_ReportError(
        __result,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getFormat",
        _buffer);
      LODWORD(v9) = __result;
    }
  }
  return (int)v9;
}


// Address: 0x22172d0 | Name: _ZN4FMOD5Sound15getNumSubSoundsEPi
FMOD_RESULT_0 __fastcall FMOD::Sound::getNumSubSounds(FMOD::Sound *const this, int *numsubsounds)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( soundi->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_READY_0
      || (LOBYTE(v2) = 46, soundi->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0) )
    {
      v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, int *))soundi->_vptr_SoundI + 21))(soundi, numsubsounds);
      if ( v2 == FMOD_RESULT::FMOD_OK_0 )
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numsubsounds);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
      this,
      "Sound::getNumSubSounds",
      _buffer);
  }
  return v2;
}


// Address: 0x22173b0 | Name: _ZN4FMOD5Sound10getNumTagsEPiS1_
FMOD_RESULT_0 __fastcall FMOD::Sound::getNumTags(FMOD::Sound *const this, int *numtags, int *numtagsupdated)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v4
    || soundi->mOpenState.m_value
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, int *, int *))soundi->_vptr_SoundI + 22))(
               soundi,
               numtags,
               numtagsupdated)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, numtags);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), numtagsupdated);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getNumTags",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v4;
}


// Address: 0x22174e0 | Name: _ZN4FMOD5Sound6getTagEPKciP8FMOD_TAG
FMOD_RESULT_0 __fastcall FMOD::Sound::getTag(FMOD::Sound *const this, const char *name, int index, FMOD_TAG *tag)
{
  FMOD_RESULT_0 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v6
    || soundi->mOpenState.m_value
    && (LOBYTE(v6) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v6 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, const char *, _QWORD, FMOD_TAG *))soundi->_vptr_SoundI + 23))(
               soundi,
               name,
               (unsigned int)index,
               tag)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v11 = FMOD::FMOD_FormatArg(_buffer, 256, name);
      v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
      v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), index);
      v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), tag);
      FMOD_ReportError(
        v6,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getTag",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v6;
}


// Address: 0x2217660 | Name: _ZN4FMOD5Sound12getOpenStateEP14FMOD_OPENSTATEPjPbS4_
FMOD_RESULT_0 __fastcall FMOD::Sound::getOpenState(
        FMOD::Sound *const this,
        FMOD_OPENSTATE_1 *openstate,
        unsigned int *percentbuffered,
        bool *starving,
        bool *diskbusy)
{
  FMOD_RESULT_0 v7; // r13d
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r14d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( (v7
     || (v7 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD_OPENSTATE_1 *, unsigned int *, bool *, bool *))soundi->_vptr_SoundI
               + 24))(
                soundi,
                openstate,
                percentbuffered,
                starving,
                diskbusy)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, openstate);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), percentbuffered);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = v11 + FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, starving);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), diskbusy);
    FMOD_ReportError(
      v7,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
      this,
      "Sound::getOpenState",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v7;
}


// Address: 0x22177f0 | Name: _ZN4FMOD5Sound8readDataEPvjPj
FMOD_RESULT_0 __fastcall FMOD::Sound::readData(
        FMOD::Sound *const this,
        void *buffer,
        unsigned int length,
        unsigned int *read)
{
  FMOD_RESULT_0 v6; // ebx
  int v8; // eax
  int v9; // r13d
  int v10; // eax
  int v11; // [rsp+Ch] [rbp-14Ch]
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v6
    || soundi->mOpenState.m_value
    && (LOBYTE(v6) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v6 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, void *, _QWORD, unsigned int *))soundi->_vptr_SoundI + 25))(
               soundi,
               buffer,
               length,
               read)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v11 = FMOD::FMOD_FormatArg(_buffer, 256, buffer);
      v8 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, ", ");
      v9 = v8 + v11 + FMOD::FMOD_FormatArg(&_buffer[v8 + v11], 256 - (v8 + v11), length);
      v10 = FMOD::FMOD_FormatArg(&_buffer[v9], 256 - v9, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v10 + v9], 256 - (v10 + v9), read);
      FMOD_ReportError(
        v6,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::readData",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v6;
}


// Address: 0x2217970 | Name: _ZN4FMOD5Sound8seekDataEj
FMOD_RESULT_0 __fastcall FMOD::Sound::seekData(FMOD::Sound *const this, unsigned int pcm)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v2
    || soundi->mOpenState.m_value
    && (LOBYTE(v2) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD))soundi->_vptr_SoundI + 26))(soundi, pcm)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      FMOD::FMOD_FormatArg(_buffer, 256, pcm);
      FMOD_ReportError(
        v2,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::seekData",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v2;
}


// Address: 0x2217a60 | Name: _ZN4FMOD5Sound13setSoundGroupEPNS_10SoundGroupE
FMOD_RESULT_0 __fastcall FMOD::Sound::setSoundGroup(FMOD::Sound *const this, FMOD::SoundGroup *soundgroup)
{
  FMOD_RESULT_0 updated; // ebx
  FMOD::SystemI *mSystem; // r12
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  updated = FMOD::SoundI::validate(this, &soundi, 0);
  if ( updated == FMOD_RESULT::FMOD_OK_0 )
  {
    mSystem = soundi->mSystem;
    if ( mSystem )
    {
      updated = FMOD::SystemI::enterMainUpdateLock(soundi->mSystem);
      if ( updated == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( soundi->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_READY_0
          || (LOBYTE(updated) = 46, soundi->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0) )
        {
          updated = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD::SoundGroup *))soundi->_vptr_SoundI + 27))(
                      soundi,
                      soundgroup);
        }
        FMOD::SystemI::leaveMainUpdateLock(mSystem);
        if ( updated == FMOD_RESULT::FMOD_OK_0 )
          return updated;
      }
    }
    else
    {
      updated = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    }
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) >= 0 )
    return updated;
  FMOD::FMOD_FormatArg(_buffer, 256, soundgroup);
  FMOD_ReportError(
    updated,
    FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
    this,
    "Sound::setSoundGroup",
    _buffer);
  return updated;
}


// Address: 0x2217b60 | Name: _ZN4FMOD5Sound13getSoundGroupEPPNS_10SoundGroupE
FMOD_RESULT_0 __fastcall FMOD::Sound::getSoundGroup(FMOD::Sound *const this, FMOD::SoundGroup **soundgroup)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( soundi->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_READY_0
      || (LOBYTE(v2) = 46, soundi->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0) )
    {
      v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD::SoundGroup **))soundi->_vptr_SoundI + 28))(
             soundi,
             soundgroup);
      if ( v2 == FMOD_RESULT::FMOD_OK_0 )
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, soundgroup);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
      this,
      "Sound::getSoundGroup",
      _buffer);
  }
  return v2;
}


// Address: 0x2217c40 | Name: _ZN4FMOD5Sound16getNumSyncPointsEPi
FMOD_RESULT_0 __fastcall FMOD::Sound::getNumSyncPoints(FMOD::Sound *const this, int *numsyncpoints)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v2
    || soundi->mOpenState.m_value
    && (LOBYTE(v2) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, int *))soundi->_vptr_SoundI + 29))(soundi, numsyncpoints)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      FMOD::FMOD_FormatArg(_buffer, 256, numsyncpoints);
      FMOD_ReportError(
        v2,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getNumSyncPoints",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v2;
}


// Address: 0x2217d30 | Name: _ZN4FMOD5Sound12getSyncPointEiPP14FMOD_SYNCPOINT
FMOD_RESULT_0 __fastcall FMOD::Sound::getSyncPoint(FMOD::Sound *const this, int index, FMOD_SYNCPOINT **point)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v4
    || soundi->mOpenState.m_value
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD, FMOD_SYNCPOINT **))soundi->_vptr_SoundI + 30))(
               soundi,
               (unsigned int)index,
               point)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, index);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), point);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getSyncPoint",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v4;
}


// Address: 0x2217e60 | Name: _ZN4FMOD5Sound16getSyncPointInfoEP14FMOD_SYNCPOINTPciPjj
FMOD_RESULT_0 __fastcall FMOD::Sound::getSyncPointInfo(
        FMOD::Sound *const this,
        FMOD_SYNCPOINT *point,
        char *name,
        int namelen,
        unsigned int *offset,
        FMOD_TIMEUNIT offsettype)
{
  FMOD_RESULT_0 v8; // r14d
  int v10; // eax
  int v11; // eax
  int v12; // r13d
  int v13; // r13d
  int v14; // r13d
  int v15; // eax
  int nameb; // [rsp+8h] [rbp-160h]
  int v19; // [rsp+1Ch] [rbp-14Ch]
  FMOD::SoundLockScope lockScope; // [rsp+20h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+28h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+30h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v8 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v8
    || soundi->mOpenState.m_value
    && (LOBYTE(v8) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v8 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD_SYNCPOINT *, char *, _QWORD, unsigned int *, _QWORD))soundi->_vptr_SoundI
              + 31))(
               soundi,
               point,
               name,
               (unsigned int)namelen,
               offset,
               offsettype)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v19 = FMOD::FMOD_FormatArg(_buffer, 256, point);
      v10 = FMOD::FMOD_FormatArg(&_buffer[v19], 256 - v19, ", ");
      nameb = FMOD::FMOD_FormatArg(&_buffer[v10 + v19], 256 - (v10 + v19), name) + v10 + v19;
      v11 = FMOD::FMOD_FormatArg(&_buffer[nameb], 256 - nameb, ", ");
      v12 = v11 + nameb + FMOD::FMOD_FormatArg(&_buffer[v11 + nameb], 256 - (v11 + nameb), namelen);
      v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ") + v12;
      v14 = FMOD::FMOD_FormatArg(&_buffer[v13], 256 - v13, offset) + v13;
      v15 = FMOD::FMOD_FormatArg(&_buffer[v14], 256 - v14, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v15 + v14], 256 - (v15 + v14), offsettype);
      FMOD_ReportError(
        v8,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getSyncPointInfo",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v8;
}


// Address: 0x2218070 | Name: _ZN4FMOD5Sound12addSyncPointEjjPKcPP14FMOD_SYNCPOINT
FMOD_RESULT_0 __fastcall FMOD::Sound::addSyncPoint(
        FMOD::Sound *const this,
        unsigned int offset,
        FMOD_TIMEUNIT offsettype,
        const char *name,
        FMOD_SYNCPOINT **point)
{
  FMOD_RESULT_0 v7; // r14d
  int v9; // eax
  int v10; // r13d
  int v11; // r13d
  int v12; // r13d
  int v13; // eax
  int v15; // [rsp+1Ch] [rbp-14Ch]
  FMOD::SoundLockScope lockScope; // [rsp+20h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+28h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+30h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v7
    || soundi->mOpenState.m_value
    && (LOBYTE(v7) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v7 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD, _QWORD, const char *, FMOD_SYNCPOINT **, __int64, int))soundi->_vptr_SoundI
              + 32))(
               soundi,
               offset,
               offsettype,
               name,
               point,
               0xFFFFFFFFLL,
               1)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v15 = FMOD::FMOD_FormatArg(_buffer, 256, offset);
      v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
      v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), offsettype);
      v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
      v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, name) + v11;
      v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), point);
      FMOD_ReportError(
        v7,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::addSyncPoint",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v7;
}


// Address: 0x2218230 | Name: _ZN4FMOD5Sound15deleteSyncPointEP14FMOD_SYNCPOINT
FMOD_RESULT_0 __fastcall FMOD::Sound::deleteSyncPoint(FMOD::Sound *const this, FMOD_SYNCPOINT *point)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v2
    || soundi->mOpenState.m_value
    && (LOBYTE(v2) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD_SYNCPOINT *))soundi->_vptr_SoundI + 34))(
               soundi,
               point)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      FMOD::FMOD_FormatArg(_buffer, 256, point);
      FMOD_ReportError(
        v2,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::deleteSyncPoint",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v2;
}


// Address: 0x2218320 | Name: _ZN4FMOD5Sound7setModeEj
FMOD_RESULT_0 __fastcall FMOD::Sound::setMode(FMOD::Sound *const this, FMOD_MODE mode)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v2
    || soundi->mOpenState.m_value
    && (LOBYTE(v2) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD))soundi->_vptr_SoundI + 35))(soundi, mode)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      FMOD::FMOD_FormatArg(_buffer, 256, mode);
      FMOD_ReportError(
        v2,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::setMode",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v2;
}


// Address: 0x2218410 | Name: _ZN4FMOD5Sound7getModeEPj
FMOD_RESULT_0 __fastcall FMOD::Sound::getMode(FMOD::Sound *const this, FMOD_MODE *mode)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( soundi->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_READY_0
      || (LOBYTE(v2) = 46, soundi->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0) )
    {
      v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, FMOD_MODE *))soundi->_vptr_SoundI + 36))(soundi, mode);
      if ( v2 == FMOD_RESULT::FMOD_OK_0 )
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, mode);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
      this,
      "Sound::getMode",
      _buffer);
  }
  return v2;
}


// Address: 0x22184f0 | Name: _ZN4FMOD5Sound12setLoopCountEi
FMOD_RESULT_0 __fastcall FMOD::Sound::setLoopCount(FMOD::Sound *const this, int loopcount)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v2
    || soundi->mOpenState.m_value
    && (LOBYTE(v2) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD))soundi->_vptr_SoundI + 37))(
               soundi,
               (unsigned int)loopcount)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      FMOD::FMOD_FormatArg(_buffer, 256, loopcount);
      FMOD_ReportError(
        v2,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::setLoopCount",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v2;
}


// Address: 0x22185e0 | Name: _ZN4FMOD5Sound12getLoopCountEPi
FMOD_RESULT_0 __fastcall FMOD::Sound::getLoopCount(FMOD::Sound *const this, int *loopcount)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( soundi->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_READY_0
      || (LOBYTE(v2) = 46, soundi->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0) )
    {
      v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, int *))soundi->_vptr_SoundI + 38))(soundi, loopcount);
      if ( v2 == FMOD_RESULT::FMOD_OK_0 )
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, loopcount);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
      this,
      "Sound::getLoopCount",
      _buffer);
  }
  return v2;
}


// Address: 0x22186c0 | Name: _ZN4FMOD5Sound13setLoopPointsEjjjj
FMOD_RESULT_0 __fastcall FMOD::Sound::setLoopPoints(
        FMOD::Sound *const this,
        unsigned int loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int loopend,
        FMOD_TIMEUNIT loopendtype)
{
  FMOD_RESULT_0 v7; // r14d
  int v9; // eax
  int v10; // r13d
  int v11; // r13d
  int v12; // r13d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v7
    || soundi->mOpenState.m_value
    && (LOBYTE(v7) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v7 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD, _QWORD, _QWORD, _QWORD))soundi->_vptr_SoundI + 39))(
               soundi,
               loopstart,
               loopstarttype,
               loopend,
               loopendtype)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v15 = FMOD::FMOD_FormatArg(_buffer, 256, loopstart);
      v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
      v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), loopstarttype);
      v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
      v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, loopend) + v11;
      v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), loopendtype);
      FMOD_ReportError(
        v7,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::setLoopPoints",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v7;
}


// Address: 0x2218870 | Name: _ZN4FMOD5Sound13getLoopPointsEPjjS1_j
FMOD_RESULT_0 __fastcall FMOD::Sound::getLoopPoints(
        FMOD::Sound *const this,
        unsigned int *loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int *loopend,
        FMOD_TIMEUNIT loopendtype)
{
  FMOD_RESULT_0 v7; // r14d
  int v9; // eax
  int v10; // r13d
  int v11; // r13d
  int v12; // r13d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v7
    || soundi->mOpenState.m_value
    && (LOBYTE(v7) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0)
    || (v7 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, unsigned int *, _QWORD, unsigned int *, _QWORD))soundi->_vptr_SoundI
              + 40))(
               soundi,
               loopstart,
               loopstarttype,
               loopend,
               loopendtype)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v15 = FMOD::FMOD_FormatArg(_buffer, 256, loopstart);
      v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
      v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), loopstarttype);
      v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
      v12 = FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, loopend) + v11;
      v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), loopendtype);
      FMOD_ReportError(
        v7,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getLoopPoints",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v7;
}


// Address: 0x2218a20 | Name: _ZN4FMOD5Sound19getMusicNumChannelsEPi
FMOD_RESULT_0 __fastcall FMOD::Sound::getMusicNumChannels(FMOD::Sound *const this, int *numchannels)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v2
    || soundi->mOpenState.m_value
    && soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0
    && (LOBYTE(v2) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0)
    || (v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, int *))soundi->_vptr_SoundI + 41))(soundi, numchannels)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      FMOD::FMOD_FormatArg(_buffer, 256, numchannels);
      FMOD_ReportError(
        v2,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getMusicNumChannels",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v2;
}


// Address: 0x2218b10 | Name: _ZN4FMOD5Sound21setMusicChannelVolumeEif
__int64 __fastcall FMOD::Sound::setMusicChannelVolume(
        FMOD::Sound *const this,
        unsigned int channel,
        float a3,
        double volume)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-138h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+20h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v4
    || soundi->mOpenState.m_value
    && soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD, float, double))soundi->_vptr_SoundI + 42))(
               soundi,
               channel,
               a3,
               volume)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, channel);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), *(float *)&volume);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::setMusicChannelVolume",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return (unsigned int)v4;
}


// Address: 0x2218c50 | Name: _ZN4FMOD5Sound21getMusicChannelVolumeEiPf
FMOD_RESULT_0 __fastcall FMOD::Sound::getMusicChannelVolume(FMOD::Sound *const this, int channel, float *volume)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r12d
  int v7; // eax
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v4
    || soundi->mOpenState.m_value
    && soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0
    && (LOBYTE(v4) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0)
    || (v4 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD, float *))soundi->_vptr_SoundI + 43))(
               soundi,
               (unsigned int)channel,
               volume)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      v6 = FMOD::FMOD_FormatArg(_buffer, 256, channel);
      v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
      FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), volume);
      FMOD_ReportError(
        v4,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getMusicChannelVolume",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v4;
}


// Address: 0x2218d80 | Name: _ZN4FMOD5Sound13setMusicSpeedEf
__int64 __fastcall FMOD::Sound::setMusicSpeed(FMOD::Sound *const this, float a2, double speed)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SoundLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::SoundI *soundi; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v3
    || soundi->mOpenState.m_value
    && soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0
    && (LOBYTE(v3) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0)
    || (v3 = (*((unsigned int (__fastcall **)(float, double))soundi->_vptr_SoundI + 44))(a2, speed)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      FMOD::FMOD_FormatArg(_buffer, 256, *(float *)&speed);
      FMOD_ReportError(
        v3,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::setMusicSpeed",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return (unsigned int)v3;
}


// Address: 0x2218e70 | Name: _ZN4FMOD5Sound13getMusicSpeedEPf
FMOD_RESULT_0 __fastcall FMOD::Sound::getMusicSpeed(FMOD::Sound *const this, float *speed)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::SoundI::validate(this, &soundi, &lockScope);
  if ( v2
    || soundi->mOpenState.m_value
    && soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0
    && (LOBYTE(v2) = 46, soundi->mOpenState.m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_SEEKING_0)
    || (v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, float *))soundi->_vptr_SoundI + 45))(soundi, speed)) != FMOD_RESULT::FMOD_OK_0 )
  {
    if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
    {
      FMOD::FMOD_FormatArg(_buffer, 256, speed);
      FMOD_ReportError(
        v2,
        FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
        this,
        "Sound::getMusicSpeed",
        _buffer);
    }
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveCrit(lockScope.mSystem, FMOD_SYSTEM_CRIT_SOUND);
  return v2;
}


// Address: 0x2218f60 | Name: _ZN4FMOD5Sound11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::Sound::setUserData(FMOD::Sound *const this, void *_userdata)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, void *))soundi->_vptr_SoundI + 46))(soundi, _userdata);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
      this,
      "Sound::setUserData",
      _buffer);
  }
  return v2;
}


// Address: 0x2219020 | Name: _ZN4FMOD5Sound11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::Sound::getUserData(FMOD::Sound *const this, void **_userdata)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SoundI *soundi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  v2 = FMOD::SoundI::validate(this, &soundi, 0);
  if ( v2 == FMOD_RESULT::FMOD_OK_0 )
  {
    v2 = (*((unsigned int (__fastcall **)(FMOD::SoundI *, void **))soundi->_vptr_SoundI + 47))(soundi, _userdata);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_SOUND,
      this,
      "Sound::getUserData",
      _buffer);
  }
  return v2;
}


