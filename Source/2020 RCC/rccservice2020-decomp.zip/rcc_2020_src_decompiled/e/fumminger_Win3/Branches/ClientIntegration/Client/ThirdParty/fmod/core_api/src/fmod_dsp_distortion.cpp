// Address: 0x21d4c50 | Name: _ZN4FMOD13DSPDistortion16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPDistortion::getDescriptionEx()
{
  memset(&stru_2AD8DA0, 0, sizeof(stru_2AD8DA0));
  FMOD_strcpy_safe(stru_2AD8DA0.name, "Level", 16);
  FMOD_strcpy_safe(stru_2AD8DA0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AD8DA0.floatdesc.min = 0x3F80000000000000LL;
  stru_2AD8DA0.intdesc.defaultval = 1056964608;
  stru_2AD8DA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AD8DA0.description = "Distortion value.  0.0 to 1.0.  Default = 0.5.";
  *(&stru_2AD8D60.mHandle + 1) = 9;
  stru_2AD8D60.mSize = 544;
  stru_2AD8D60.mDescription = &stru_286A880;
  return &stru_2AD8D60;
}


// Address: 0x21d4d00 | Name: _ZN4FMOD13DSPDistortion14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPDistortion::createInternal(FMOD::DSPDistortion *const this)
{
  double v1; // xmm1_8
  __int64 v2; // rbp
  __int64 v3; // rax
  int v4; // ebx
  FMOD_RESULT_0 result; // eax

  v2 = 0;
  v3 = *((_QWORD *)this + 30);
  v4 = 0;
  if ( *(int *)(v3 + 96) <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    result = FMOD::DSPI::setParameterFloat(
               (FMOD::DSPI *const)this,
               v4,
               (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v3 + 104) + v2) + 56LL),
               v1);
    if ( result )
      break;
    v3 = *((_QWORD *)this + 30);
    ++v4;
    v2 += 8;
    if ( *(_DWORD *)(v3 + 96) <= v4 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21d4d60 | Name: _ZN4FMOD13DSPDistortion14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPDistortion::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPDistortion::createInternal((FMOD::DSPDistortion *const)dsp_state->instance);
}


// Address: 0x21d4d70 | Name: _ZN4FMOD13DSPDistortion15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPDistortion::releaseInternal(FMOD::DSPDistortion *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d4d80 | Name: _ZN4FMOD13DSPDistortion15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPDistortion::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPDistortion::releaseInternal((FMOD::DSPDistortion *const)dsp_state->instance);
}


// Address: 0x21d4d90 | Name: _ZN4FMOD13DSPDistortion13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPDistortion::resetInternal(FMOD::DSPDistortion *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d4da0 | Name: _ZN4FMOD13DSPDistortion13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPDistortion::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPDistortion::resetInternal((FMOD::DSPDistortion *const)dsp_state->instance);
}


// Address: 0x21d4db0 | Name: _ZN4FMOD13DSPDistortion12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPDistortion::readInternal(
        FMOD::DSPDistortion *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float v6; // xmm1_4
  float v7; // xmm0_4
  float v8; // xmm3_4
  float v9; // xmm2_4
  unsigned int v10; // ecx
  unsigned int v11; // r9d
  float *v12; // rdi
  float *v13; // rax
  float v14; // xmm4_4
  __int64 v15; // rax
  int i; // ecx
  float v17; // xmm4_4

  v6 = *((float *)this + 132);
  v7 = *((float *)this + 134);
  if ( v6 != v7 )
  {
    *((float *)this + 132) = v7;
    v6 = v7;
  }
  if ( inbuffer )
  {
    if ( v6 < 1.0 )
    {
      v9 = (float)(v6 + v6) / (float)(1.0 - v6);
      v8 = v9 + 1.0;
    }
    else
    {
      v8 = 19995.682;
      v9 = 19994.682;
    }
    v10 = inchannels * length;
    if ( v10 >> 3 )
    {
      v11 = v10 >> 3;
      v12 = outbuffer;
      v13 = inbuffer;
      do
      {
        v14 = *v13;
        v12 += 8;
        v13 += 8;
        *(v12 - 8) = (float)(v14 * v8) / (float)((float)(fabs(v14) * v9) + 1.0);
        *(v12 - 7) = (float)(*(v13 - 7) * v8)
                   / (float)((float)(COERCE_FLOAT(*(_DWORD *)(v13 - 7) & 0x7FFFFFFF) * v9) + 1.0);
        *(v12 - 6) = (float)(*(v13 - 6) * v8)
                   / (float)((float)(COERCE_FLOAT(*(_DWORD *)(v13 - 6) & 0x7FFFFFFF) * v9) + 1.0);
        *(v12 - 5) = (float)(*(v13 - 5) * v8)
                   / (float)((float)(COERCE_FLOAT(*(_DWORD *)(v13 - 5) & 0x7FFFFFFF) * v9) + 1.0);
        *(v12 - 4) = (float)(*(v13 - 4) * v8)
                   / (float)((float)(COERCE_FLOAT(*(_DWORD *)(v13 - 4) & 0x7FFFFFFF) * v9) + 1.0);
        *(v12 - 3) = (float)(*(v13 - 3) * v8)
                   / (float)((float)(COERCE_FLOAT(*(_DWORD *)(v13 - 3) & 0x7FFFFFFF) * v9) + 1.0);
        *(v12 - 2) = (float)(*(v13 - 2) * v8)
                   / (float)((float)(COERCE_FLOAT(*(_DWORD *)(v13 - 2) & 0x7FFFFFFF) * v9) + 1.0);
        *(v12 - 1) = (float)(*(v13 - 1) * v8) / (float)((float)(fabs(*(v13 - 1)) * v9) + 1.0);
        --v11;
      }
      while ( v11 );
      v15 = 32 * ((v10 >> 3) - 1 + 1LL);
      inbuffer = (float *)((char *)inbuffer + v15);
      outbuffer = (float *)((char *)outbuffer + v15);
    }
    for ( i = v10 & 7; i; --i )
    {
      v17 = *inbuffer;
      ++outbuffer;
      ++inbuffer;
      *(outbuffer - 1) = (float)(v17 * v8) / (float)((float)(fabs(v17) * v9) + 1.0);
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d4fb0 | Name: _ZN4FMOD13DSPDistortion12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPDistortion::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPDistortion::readInternal(
           (FMOD::DSPDistortion *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x21d4fc0 | Name: _ZN4FMOD13DSPDistortion25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPDistortion::setParameterFloatInternal(
        FMOD::DSPDistortion *const this,
        int index,
        float a3,
        float value)
{
  *((float *)this + 134) = a3;
  return 0;
}


// Address: 0x21d4fd0 | Name: _ZN4FMOD13DSPDistortion25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPDistortion::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPDistortion::setParameterFloatInternal(
           (FMOD::DSPDistortion *const)dsp_state->instance,
           index,
           a3,
           value);
}


// Address: 0x21d4fe0 | Name: _ZN4FMOD13DSPDistortion25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPDistortion::getParameterFloatInternal(
        FMOD::DSPDistortion *const this,
        int index,
        float *value,
        char *valuestr)
{
  *value = *((float *)this + 134);
  if ( valuestr )
    sprintf(valuestr, "%.02f", *((float *)this + 134));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d5030 | Name: _ZN4FMOD13DSPDistortion25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPDistortion::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPDistortion::getParameterFloatInternal(
           (FMOD::DSPDistortion *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


