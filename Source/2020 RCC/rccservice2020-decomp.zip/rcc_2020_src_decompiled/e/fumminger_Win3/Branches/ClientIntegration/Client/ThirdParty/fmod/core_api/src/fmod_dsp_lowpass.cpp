// Address: 0x21f7ec0 | Name: _ZN4FMOD10DSPLowPass16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPLowPass::getDescriptionEx()
{
  memset(&stru_2ADC2A0, 0, sizeof(stru_2ADC2A0));
  FMOD_strcpy_safe(stru_2ADC2A0.name, "Cutoff freq", 16);
  FMOD_strcpy_safe(stru_2ADC2A0.label, "hz", 16);
  *(_QWORD *)&stru_2ADC2A0.floatdesc.min = 0x46ABE00041200000LL;
  stru_2ADC2A0.description = "Lowpass cutoff frequency in hz.   1.0 to output 22000.0.  Default = 5000.0.";
  memset(&stru_2ADC240, 0, sizeof(stru_2ADC240));
  stru_2ADC2A0.intdesc.defaultval = 1167867904;
  stru_2ADC2A0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2ADC240.name, "Resonance", 16);
  FMOD_strcpy_safe(stru_2ADC240.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2ADC240.floatdesc.min = 0x412000003F800000LL;
  stru_2ADC240.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2ADC240.description = "Lowpass resonance Q value. 1.0 to 10.0.  Default = 1.0.";
  stru_2ADC240.intdesc.defaultval = 1065353216;
  *(&stru_2ADC200.mHandle + 1) = 3;
  stru_2ADC200.mDescription = &stru_286B8A0;
  stru_2ADC200.mSize = 1160;
  return &stru_2ADC200;
}


// Address: 0x21f7ff0 | Name: _ZN4FMOD10DSPLowPass7processEPfS1_ji
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::process(
        FMOD::DSPLowPass *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int channels)
{
  unsigned int v5; // eax
  float *v6; // rcx
  __int64 v7; // rbx
  __int64 v8; // rbp
  __int64 v9; // r13
  __int64 v10; // rax
  __int64 v11; // r12
  __int64 v12; // r11
  unsigned int v13; // r14d
  float *v14; // r8
  float *v15; // rsi
  float *v16; // r15
  float *v17; // rax
  float v18; // xmm0_4
  float v19; // xmm0_4
  float v20; // xmm2_4
  float v21; // xmm5_4
  float v22; // xmm1_4
  float v23; // xmm0_4
  float v24; // xmm5_4
  float v25; // xmm1_4
  float v26; // xmm0_4
  float *v27; // r15
  float *v28; // rax
  float v29; // xmm0_4
  float v30; // xmm0_4
  float v31; // xmm2_4
  float v32; // xmm5_4
  float v33; // xmm1_4
  float v34; // xmm0_4
  float v35; // xmm5_4
  float v36; // xmm1_4
  float v37; // xmm0_4
  float *v38; // r15
  float *v39; // rax
  float v40; // xmm0_4
  float v41; // xmm0_4
  float v42; // xmm2_4
  float v43; // xmm5_4
  float v44; // xmm1_4
  float v45; // xmm0_4
  float v46; // xmm5_4
  float v47; // xmm1_4
  float v48; // xmm0_4
  float *v49; // r15
  float *v50; // rax
  float v51; // xmm0_4
  float v52; // xmm0_4
  float v53; // xmm2_4
  float v54; // xmm5_4
  float v55; // xmm1_4
  float v56; // xmm0_4
  float v57; // xmm5_4
  float v58; // xmm1_4
  float v59; // xmm0_4
  unsigned int v60; // r14d
  float *v61; // r9
  float *v62; // rax
  float v63; // xmm0_4
  float v64; // xmm0_4
  float v65; // xmm2_4
  float v66; // xmm5_4
  float v67; // xmm1_4
  float v68; // xmm0_4
  float v69; // xmm5_4
  float v70; // xmm1_4
  float v71; // xmm0_4
  __m128 v73; // xmm5
  float *v74; // rax
  float v75; // xmm1_4
  float v76; // xmm4_4
  float v77; // xmm0_4
  float v78; // xmm2_4
  float v79; // xmm3_4
  float v80; // xmm1_4
  float v81; // xmm6_4
  float v82; // xmm1_4
  float v83; // xmm0_4
  float v84; // xmm2_4
  float v85; // xmm1_4
  float v86; // xmm0_4
  float v87; // xmm0_4
  float v88; // xmm2_4
  float v89; // xmm6_4
  float v90; // xmm0_4
  float v91; // xmm2_4
  float v92; // xmm0_4
  float *v93; // rax
  __m128 v94; // xmm14
  float v95; // xmm0_4
  float v96; // xmm6_4
  float v97; // xmm4_4
  float v98; // xmm3_4
  float v99; // xmm5_4
  float v100; // xmm13_4
  float v101; // xmm12_4
  float v102; // xmm1_4
  float v103; // xmm15_4
  float v104; // xmm11_4
  float v105; // xmm1_4
  float v106; // xmm9_4
  float v107; // xmm3_4
  float v108; // xmm7_4
  float v109; // xmm12_4
  float v110; // xmm10_4
  float v111; // xmm8_4
  float v112; // xmm2_4
  float v113; // xmm1_4
  float v114; // xmm1_4
  float v115; // xmm6_4
  float v116; // xmm1_4
  float v117; // xmm4_4
  float v118; // xmm1_4
  float v119; // xmm3_4
  float v120; // xmm0_4
  float v121; // xmm5_4
  float v122; // xmm15_4
  float *v123; // rax
  float v124; // xmm3_4
  float v125; // xmm13_4
  float v126; // xmm6_4
  float v127; // xmm5_4
  float v128; // xmm14_4
  float v129; // xmm4_4
  float v130; // xmm12_4
  float v131; // xmm11_4
  float v132; // xmm10_4
  float v133; // xmm3_4
  float v134; // xmm2_4
  float v135; // xmm1_4
  float v136; // xmm0_4
  float v137; // xmm9_4
  float v138; // xmm7_4
  float v139; // xmm8_4
  float v140; // xmm14_4
  float v141; // xmm6_4
  float v142; // xmm13_4
  float v143; // xmm5_4
  float v144; // xmm4_4
  float v145; // xmm12_4
  float v146; // xmm3_4
  float v147; // xmm11_4
  float v148; // xmm10_4
  float v149; // xmm12_4
  float v150; // xmm2_4
  float v151; // xmm11_4
  float v152; // xmm1_4
  float v153; // xmm10_4
  float v154; // xmm0_4
  float v155; // xmm3_4
  float v156; // xmm0_4
  float v157; // xmm3_4
  float v158; // xmm9_4
  float v159; // xmm9_4
  float v160; // xmm15_4
  float *v161; // rax
  float v162; // xmm9_4
  float v163; // xmm13_4
  float v164; // xmm2_4
  float v165; // xmm1_4
  float v166; // xmm12_4
  float v167; // xmm0_4
  float v168; // xmm9_4
  float v169; // xmm8_4
  float v170; // xmm7_4
  float v171; // xmm6_4
  float v172; // xmm4_4
  float v173; // xmm14_4
  float v174; // xmm5_4
  float v175; // xmm3_4
  float v176; // xmm2_4
  float v177; // xmm11_4
  float v178; // xmm15_4
  float v179; // xmm13_4
  float v180; // xmm12_4
  float v181; // xmm0_4
  float v182; // xmm11_4
  float v183; // xmm1_4
  float v184; // xmm0_4
  float v185; // xmm13_4
  float v186; // xmm9_4
  float v187; // xmm12_4
  float v188; // xmm8_4
  float v189; // xmm11_4
  float v190; // xmm7_4
  float v191; // xmm10_4
  float v192; // xmm8_4
  float v193; // xmm10_4
  float v194; // xmm7_4
  float v195; // xmm10_4
  float v196; // xmm7_4
  float v197; // xmm8_4
  float v198; // xmm6_4
  float v199; // xmm7_4
  float v200; // xmm8_4
  float v201; // xmm6_4
  float v202; // xmm9_4
  float v203; // xmm4_4
  float v204; // xmm6_4
  float v205; // xmm5_4
  float v206; // xmm5_4
  unsigned int v207; // [rsp+0h] [rbp-D8h]
  unsigned int len; // [rsp+10h] [rbp-C8h]
  float lena; // [rsp+10h] [rbp-C8h]
  float lenb; // [rsp+10h] [rbp-C8h]
  float offset1a; // [rsp+14h] [rbp-C4h]
  float offset1b; // [rsp+14h] [rbp-C4h]
  float outbuffera; // [rsp+18h] [rbp-C0h]
  float outbufferb; // [rsp+18h] [rbp-C0h]
  float *inbuffera; // [rsp+20h] [rbp-B8h]
  float inbufferb; // [rsp+20h] [rbp-B8h]
  float inbufferc; // [rsp+20h] [rbp-B8h]
  char *v219; // [rsp+28h] [rbp-B0h]
  float v220; // [rsp+28h] [rbp-B0h]
  float v221; // [rsp+28h] [rbp-B0h]
  char *v222; // [rsp+30h] [rbp-A8h]
  float v223; // [rsp+30h] [rbp-A8h]
  float v224; // [rsp+30h] [rbp-A8h]
  unsigned int count; // [rsp+38h] [rbp-A0h]
  float counta; // [rsp+38h] [rbp-A0h]
  float countb; // [rsp+38h] [rbp-A0h]
  float v228; // [rsp+3Ch] [rbp-9Ch]
  float v229; // [rsp+3Ch] [rbp-9Ch]
  float v230; // [rsp+40h] [rbp-98h]
  float v231; // [rsp+40h] [rbp-98h]
  float v232; // [rsp+44h] [rbp-94h]
  float v233; // [rsp+44h] [rbp-94h]
  float v234; // [rsp+48h] [rbp-90h]
  float v235; // [rsp+48h] [rbp-90h]
  float v236; // [rsp+4Ch] [rbp-8Ch]
  float v237; // [rsp+4Ch] [rbp-8Ch]
  float v238; // [rsp+50h] [rbp-88h]
  float v239; // [rsp+50h] [rbp-88h]
  float v240; // [rsp+54h] [rbp-84h]
  float v241; // [rsp+54h] [rbp-84h]
  float v242; // [rsp+58h] [rbp-80h]
  float v243; // [rsp+58h] [rbp-80h]
  float v244; // [rsp+5Ch] [rbp-7Ch]
  float v245; // [rsp+5Ch] [rbp-7Ch]
  float v246; // [rsp+60h] [rbp-78h]
  float v247; // [rsp+60h] [rbp-78h]
  float v248; // [rsp+64h] [rbp-74h]
  float v249; // [rsp+64h] [rbp-74h]
  float v250; // [rsp+68h] [rbp-70h]
  float v251; // [rsp+68h] [rbp-70h]
  float v252; // [rsp+6Ch] [rbp-6Ch]
  float v253; // [rsp+70h] [rbp-68h]
  float v254; // [rsp+74h] [rbp-64h]
  float v255; // [rsp+78h] [rbp-60h]
  float v256; // [rsp+7Ch] [rbp-5Ch]
  float v257; // [rsp+80h] [rbp-58h]
  float v258; // [rsp+84h] [rbp-54h]
  float v259; // [rsp+88h] [rbp-50h]
  float a7; // [rsp+8Ch] [rbp-4Ch]
  float v261; // [rsp+90h] [rbp-48h]
  float v262; // [rsp+94h] [rbp-44h]
  float v263; // [rsp+98h] [rbp-40h]
  float v264; // [rsp+9Ch] [rbp-3Ch]

  switch ( channels )
  {
    case 1:
      if ( length )
      {
        v73 = (__m128)LODWORD(flt_286B89C);
        v74 = outbuffer;
        do
        {
          v75 = *inbuffer;
          ++v74;
          ++inbuffer;
          v76 = *((float *)this + 137);
          --length;
          v77 = *((float *)this + 266) * v76;
          v78 = *((float *)this + 138);
          v79 = *((float *)this + 139);
          v80 = (float)(v75 + v73.m128_f32[0]) * *((float *)this + 265);
          v81 = *((float *)this + 140);
          *((float *)this + 138) = v76;
          v73 = _mm_xor_ps(v73, (__m128)0x80000000);
          *((float *)this + 140) = v79;
          v82 = v80 - v77;
          v83 = *((float *)this + 267) * v78;
          v84 = v78 * *((float *)this + 269);
          v85 = v82 - v83;
          v86 = *((float *)this + 268);
          *((float *)this + 137) = v85;
          v87 = (float)((float)(v86 * v76) + v84) - (float)(*((float *)this + 270) * v79);
          v88 = *((float *)this + 271) * v81;
          v89 = v81 * *((float *)this + 273);
          v90 = v87 - v88;
          v91 = *((float *)this + 272);
          v92 = v90 + v85;
          *((float *)this + 139) = v92;
          *(v74 - 1) = (float)((float)(v91 * v79) + v89) + v92;
        }
        while ( length );
        flt_286B89C = v73.m128_f32[0];
      }
      break;
    case 2:
      if ( length )
      {
        v93 = outbuffer;
        v94 = (__m128)LODWORD(flt_286B89C);
        do
        {
          v93 += 2;
          inbuffer += 2;
          v95 = *((float *)this + 137);
          v96 = *((float *)this + 265);
          v97 = *((float *)this + 266);
          v98 = *((float *)this + 267);
          v99 = *((float *)this + 141);
          v100 = *((float *)this + 268);
          v101 = *((float *)this + 142);
          v102 = *((float *)this + 138);
          v103 = v102 * *((float *)this + 269);
          v104 = *((float *)this + 270);
          v105 = v102 * v98;
          v106 = *((float *)this + 140);
          v107 = v98 * v101;
          v108 = *((float *)this + 144);
          v109 = v101 * *((float *)this + 269);
          v110 = *((float *)this + 271);
          v111 = *((float *)this + 272);
          v112 = (float)((float)((float)(*(inbuffer - 2) + v94.m128_f32[0]) * v96) - (float)(v95 * v97)) - v105;
          v113 = *(inbuffer - 1);
          *((float *)this + 138) = v95;
          *((float *)this + 142) = v99;
          --length;
          *((float *)this + 137) = v112;
          v114 = (float)(v113 + v94.m128_f32[0]) * v96;
          v115 = *((float *)this + 273);
          v94 = _mm_xor_ps(v94, (__m128)0x80000000);
          v116 = v114 - (float)(v97 * v99);
          v117 = *((float *)this + 139);
          *((float *)this + 140) = v117;
          v118 = v116 - v107;
          v119 = *((float *)this + 143);
          *((float *)this + 144) = v119;
          *((float *)this + 141) = v118;
          v120 = (float)((float)((float)((float)(v95 * v100) + v103) - (float)(v117 * v104)) - (float)(v106 * v110))
               + v112;
          v121 = (float)((float)((float)((float)(v99 * v100) + v109) - (float)(v104 * v119)) - (float)(v110 * v108))
               + v118;
          *((float *)this + 139) = v120;
          *((float *)this + 143) = v121;
          *(v93 - 2) = (float)((float)(v117 * v111) + (float)(v106 * v115)) + v120;
          *(v93 - 1) = (float)((float)(v119 * v111) + (float)(v115 * v108)) + v121;
        }
        while ( length );
        flt_286B89C = v94.m128_f32[0];
      }
      break;
    case 6:
      if ( length )
      {
        v122 = flt_286B89C;
        v123 = &inbuffer[6 * length];
        while ( 1 )
        {
          v124 = *inbuffer;
          outbuffer += 6;
          inbuffer += 6;
          v125 = *((float *)this + 137);
          v126 = *((float *)this + 265);
          v127 = *((float *)this + 266);
          v128 = *((float *)this + 138);
          v129 = *((float *)this + 267);
          v130 = *((float *)this + 141);
          v236 = *((float *)this + 142);
          v131 = *((float *)this + 145);
          v132 = *((float *)this + 149);
          v133 = (float)((float)((float)(v124 + v122) * v126) - (float)(v125 * v127)) - (float)(v128 * v129);
          v238 = *((float *)this + 146);
          v134 = (float)((float)((float)(*(inbuffer - 5) + v122) * v126) - (float)(v127 * v130)) - (float)(v236 * v129);
          v240 = *((float *)this + 150);
          v135 = (float)((float)((float)(*(inbuffer - 4) + v122) * v126) - (float)(v127 * v131)) - (float)(v238 * v129);
          v244 = *((float *)this + 154);
          v136 = (float)((float)((float)(*(inbuffer - 3) + v122) * v126) - (float)(v127 * v132)) - (float)(v240 * v129);
          v242 = *((float *)this + 153);
          v137 = (float)((float)((float)(*(inbuffer - 2) + v122) * v126) - (float)(v242 * v127)) - (float)(v244 * v129);
          inbufferb = *((float *)this + 158);
          outbuffera = *((float *)this + 157);
          v138 = *((float *)this + 270);
          v246 = *((float *)this + 139);
          v139 = (float)((float)((float)(*(inbuffer - 1) + v122) * v126) - (float)(v127 * outbuffera))
               - (float)(v129 * inbufferb);
          v220 = *((float *)this + 140);
          *((float *)this + 138) = v125;
          v140 = v128 * *((float *)this + 269);
          *((float *)this + 137) = v133;
          v141 = *((float *)this + 271);
          counta = *((float *)this + 143);
          v223 = *((float *)this + 144);
          v248 = *((float *)this + 147);
          v228 = *((float *)this + 148);
          lena = *((float *)this + 151);
          v230 = *((float *)this + 152);
          offset1a = *((float *)this + 155);
          v142 = (float)((float)((float)((float)(v125 * *((float *)this + 268)) + v140) - (float)(v246 * v138))
                       - (float)(v220 * v141))
               + v133;
          v232 = *((float *)this + 156);
          v250 = *((float *)this + 159);
          v234 = *((float *)this + 160);
          v143 = *((float *)this + 272);
          v144 = *((float *)this + 273);
          *((float *)this + 140) = v246;
          *((float *)this + 139) = v142;
          *((float *)this + 142) = v130;
          v145 = v130 * *((float *)this + 268);
          v146 = v236 * *((float *)this + 269);
          *((float *)this + 141) = v134;
          *((float *)this + 144) = counta;
          *((float *)this + 146) = v131;
          v147 = v131 * *((float *)this + 268);
          *((float *)this + 145) = v135;
          *((float *)this + 150) = v132;
          v148 = v132 * *((float *)this + 268);
          *((float *)this + 149) = v136;
          *((float *)this + 153) = v137;
          *((float *)this + 148) = v248;
          *((float *)this + 154) = v242;
          v149 = (float)((float)((float)(v145 + v146) - (float)(counta * v138)) - (float)(v223 * v141)) + v134;
          v150 = v238 * *((float *)this + 269);
          *((float *)this + 143) = v149;
          *((float *)this + 152) = lena;
          v151 = (float)((float)((float)(v147 + v150) - (float)(v248 * v138)) - (float)(v228 * v141)) + v135;
          v152 = v240 * *((float *)this + 269);
          *((float *)this + 147) = v151;
          *((float *)this + 156) = offset1a;
          v153 = (float)((float)((float)(v148 + v152) - (float)(lena * v138)) - (float)(v230 * v141)) + v136;
          v154 = *((float *)this + 268) * v242;
          v155 = v244 * *((float *)this + 269);
          *((float *)this + 151) = v153;
          v156 = (float)((float)((float)(v154 + v155) - (float)(offset1a * v138)) - (float)(v232 * v141)) + v137;
          *((float *)this + 155) = v156;
          v157 = inbufferb * *((float *)this + 269);
          *((float *)this + 158) = outbuffera;
          v158 = outbuffera * *((float *)this + 268);
          *((float *)this + 160) = v250;
          *((float *)this + 157) = v139;
          v159 = (float)((float)((float)(v158 + v157) - (float)(v138 * v250)) - (float)(v141 * v234)) + v139;
          *((float *)this + 159) = v159;
          *(outbuffer - 6) = (float)((float)(v246 * v143) + (float)(v220 * v144)) + v142;
          *(outbuffer - 5) = (float)((float)(counta * v143) + (float)(v223 * v144)) + v149;
          *(outbuffer - 4) = (float)((float)(v248 * v143) + (float)(v228 * v144)) + v151;
          *(outbuffer - 3) = (float)((float)(lena * v143) + (float)(v230 * v144)) + v153;
          *(outbuffer - 2) = (float)((float)(offset1a * v143) + (float)(v232 * v144)) + v156;
          *(outbuffer - 1) = (float)((float)(v143 * v250) + (float)(v144 * v234)) + v159;
          if ( inbuffer == v123 )
            break;
          v122 = -v122;
        }
        flt_286B89C = -v122;
      }
      break;
    case 8:
      if ( length )
      {
        v160 = flt_286B89C;
        v161 = outbuffer;
        while ( 1 )
        {
          v162 = *inbuffer;
          v161 += 8;
          inbuffer += 8;
          v163 = *((float *)this + 137);
          v164 = *((float *)this + 265);
          v165 = *((float *)this + 266);
          v249 = *((float *)this + 138);
          v166 = *((float *)this + 141);
          v167 = *((float *)this + 267);
          v251 = *((float *)this + 142);
          v168 = (float)((float)((float)(v162 + v160) * v164) - (float)(v163 * v165)) - (float)(v249 * v167);
          v252 = *((float *)this + 146);
          v229 = *((float *)this + 149);
          v224 = *((float *)this + 145);
          v169 = (float)((float)((float)(*(inbuffer - 7) + v160) * v164) - (float)(v165 * v166)) - (float)(v251 * v167);
          v253 = *((float *)this + 150);
          v170 = (float)((float)((float)(*(inbuffer - 6) + v160) * v164) - (float)(v165 * v224)) - (float)(v252 * v167);
          v255 = *((float *)this + 154);
          v256 = *((float *)this + 157);
          v171 = (float)((float)((float)(*(inbuffer - 5) + v160) * v164) - (float)(v165 * v229)) - (float)(v253 * v167);
          v254 = *((float *)this + 153);
          v172 = (float)((float)((float)(*(inbuffer - 4) + v160) * v164) - (float)(v254 * v165)) - (float)(v255 * v167);
          v257 = *((float *)this + 158);
          v173 = (float)((float)((float)(*(inbuffer - 3) + v160) * v164) - (float)(v256 * v165)) - (float)(v257 * v167);
          v258 = *((float *)this + 161);
          v259 = *((float *)this + 162);
          v233 = *((float *)this + 166);
          --length;
          v174 = (float)((float)((float)(*(inbuffer - 2) + v160) * v164) - (float)(v258 * v165)) - (float)(v259 * v167);
          v231 = *((float *)this + 165);
          v175 = *((float *)this + 270);
          countb = *((float *)this + 139);
          v237 = *((float *)this + 144);
          v235 = *((float *)this + 140);
          v261 = *((float *)this + 143);
          lenb = *((float *)this + 147);
          v239 = *((float *)this + 148);
          v241 = *((float *)this + 152);
          offset1b = *((float *)this + 151);
          outbufferb = *((float *)this + 155);
          v243 = *((float *)this + 156);
          v245 = *((float *)this + 160);
          a7 = (float)((float)(v164 * (float)(*(inbuffer - 1) + v160)) - (float)(v165 * v231)) - (float)(v167 * v233);
          inbufferc = *((float *)this + 159);
          v176 = *((float *)this + 271);
          v221 = *((float *)this + 163);
          v263 = *((float *)this + 168);
          v177 = v160;
          v178 = v249 * *((float *)this + 269);
          *((float *)this + 138) = v163;
          *((float *)this + 137) = v168;
          *((float *)this + 142) = v166;
          v179 = v163 * *((float *)this + 268);
          *((float *)this + 141) = v169;
          v180 = v166 * *((float *)this + 268);
          *((float *)this + 145) = v170;
          v181 = *((float *)this + 164);
          v264 = -v177;
          *((float *)this + 140) = countb;
          *((float *)this + 146) = v224;
          v182 = v224 * *((float *)this + 268);
          v183 = *((float *)this + 272);
          v247 = v181;
          v184 = *((float *)this + 273);
          v262 = *((float *)this + 167);
          *((float *)this + 144) = v261;
          v185 = (float)((float)((float)(v179 + v178) - (float)(countb * v175)) - (float)(v235 * v176)) + v168;
          v186 = v251 * *((float *)this + 269);
          *((float *)this + 139) = v185;
          *((float *)this + 148) = lenb;
          v187 = (float)((float)((float)(v180 + v186) - (float)(v261 * v175)) - (float)(v237 * v176)) + v169;
          v188 = v252 * *((float *)this + 269);
          *((float *)this + 143) = v187;
          v189 = (float)((float)((float)(v182 + v188) - (float)(lenb * v175)) - (float)(v239 * v176)) + v170;
          *((float *)this + 147) = v189;
          v190 = v253 * *((float *)this + 269);
          *((float *)this + 150) = v229;
          v191 = v229 * *((float *)this + 268);
          v192 = v255 * *((float *)this + 269);
          *((float *)this + 152) = offset1b;
          *((float *)this + 149) = v171;
          *((float *)this + 153) = v172;
          *((float *)this + 157) = v173;
          *((float *)this + 156) = outbufferb;
          v193 = (float)((float)(v191 + v190) - (float)(offset1b * v175)) - (float)(v241 * v176);
          *((float *)this + 154) = v254;
          v194 = v254 * *((float *)this + 268);
          v195 = v193 + v171;
          *((float *)this + 158) = v256;
          *((float *)this + 151) = v195;
          v196 = (float)((float)(v194 + v192) - (float)(outbufferb * v175)) - (float)(v243 * v176);
          v197 = *((float *)this + 268) * v256;
          v198 = v257 * *((float *)this + 269);
          v199 = v196 + v172;
          *((float *)this + 160) = inbufferc;
          *((float *)this + 155) = v199;
          *((float *)this + 162) = v258;
          v200 = (float)((float)((float)(v197 + v198) - (float)(inbufferc * v175)) - (float)(v245 * v176)) + v173;
          *((float *)this + 159) = v200;
          *((float *)this + 164) = v221;
          v201 = v258 * *((float *)this + 268);
          v202 = v259 * *((float *)this + 269);
          *((float *)this + 161) = v174;
          *((float *)this + 168) = v262;
          *((float *)this + 165) = a7;
          v203 = v233 * *((float *)this + 269);
          v204 = (float)((float)((float)(v201 + v202) - (float)(v221 * v175)) - (float)(v247 * v176)) + v174;
          *((float *)this + 166) = v231;
          v205 = v231 * *((float *)this + 268);
          *((float *)this + 163) = v204;
          v206 = (float)((float)((float)(v205 + v203) - (float)(v175 * v262)) - (float)(v176 * v263)) + a7;
          *((float *)this + 167) = v206;
          *(v161 - 8) = (float)((float)(countb * v183) + (float)(v235 * v184)) + v185;
          *(v161 - 7) = (float)((float)(v261 * v183) + (float)(v237 * v184)) + v187;
          *(v161 - 6) = (float)((float)(lenb * v183) + (float)(v239 * v184)) + v189;
          *(v161 - 5) = (float)((float)(offset1b * v183) + (float)(v241 * v184)) + v195;
          *(v161 - 4) = (float)((float)(outbufferb * v183) + (float)(v243 * v184)) + v199;
          *(v161 - 3) = (float)((float)(inbufferc * v183) + (float)(v245 * v184)) + v200;
          *(v161 - 2) = (float)((float)(v221 * v183) + (float)(v247 * v184)) + v204;
          *(v161 - 1) = (float)((float)(v183 * v262) + (float)(v184 * v263)) + v206;
          if ( !length )
            break;
          v160 = v264;
        }
        flt_286B89C = v264;
      }
      break;
    default:
      if ( channels )
      {
        v5 = length >> 2;
        v207 = length >> 2;
        len = length & 3;
        v6 = (float *)((char *)this + 1096);
        v7 = channels;
        v8 = 16LL * channels;
        v9 = 2LL * channels;
        v10 = v8 * (v5 - 1 + 1LL);
        v11 = 3LL * channels;
        v12 = 0;
        count = 0;
        inbuffera = inbuffer;
        v219 = (char *)outbuffer + v10;
        v222 = (char *)inbuffer + v10;
        do
        {
          v13 = v207;
          v14 = &inbuffera[v12];
          v15 = &outbuffer[v12];
          if ( v207 )
          {
            do
            {
              v16 = (float *)((char *)this + 16 * (int)count + 552);
              v17 = (float *)((char *)this + 1064);
              v18 = *v14 + unk_286B898;
              unk_286B898 = -unk_286B898;
              v19 = v18 * *((float *)this + 265);
              do
              {
                v20 = *(v16 - 1);
                v17 += 4;
                v16 += 2;
                v21 = *(v16 - 2);
                v22 = v19 - (float)(*(v17 - 4) * v20);
                v23 = *(v17 - 3) * v21;
                v24 = v21 * *(v17 - 1);
                v25 = v22 - v23;
                v26 = *(v17 - 2);
                *(v16 - 2) = v20;
                *(v16 - 3) = v25;
                v19 = (float)((float)(v26 * v20) + v25) + v24;
              }
              while ( v17 != v6 );
              *v15 = v19;
              v27 = (float *)((char *)this + 16 * (int)count + 552);
              v28 = (float *)((char *)this + 1064);
              v29 = v14[v7] + unk_286B898;
              unk_286B898 = -unk_286B898;
              v30 = v29 * *((float *)this + 265);
              do
              {
                v31 = *(v27 - 1);
                v28 += 4;
                v27 += 2;
                v32 = *(v27 - 2);
                v33 = v30 - (float)(*(v28 - 4) * v31);
                v34 = *(v28 - 3) * v32;
                v35 = v32 * *(v28 - 1);
                v36 = v33 - v34;
                v37 = *(v28 - 2);
                *(v27 - 2) = v31;
                *(v27 - 3) = v36;
                v30 = (float)((float)(v37 * v31) + v36) + v35;
              }
              while ( v28 != v6 );
              v15[v7] = v30;
              v38 = (float *)((char *)this + 16 * (int)count + 552);
              v39 = (float *)((char *)this + 1064);
              v40 = v14[v9] + unk_286B898;
              unk_286B898 = -unk_286B898;
              v41 = v40 * *((float *)this + 265);
              do
              {
                v42 = *(v38 - 1);
                v39 += 4;
                v38 += 2;
                v43 = *(v38 - 2);
                v44 = v41 - (float)(*(v39 - 4) * v42);
                v45 = *(v39 - 3) * v43;
                v46 = v43 * *(v39 - 1);
                v47 = v44 - v45;
                v48 = *(v39 - 2);
                *(v38 - 2) = v42;
                *(v38 - 3) = v47;
                v41 = (float)((float)(v48 * v42) + v47) + v46;
              }
              while ( v39 != v6 );
              v15[v9] = v41;
              v49 = (float *)((char *)this + 16 * (int)count + 552);
              v50 = (float *)((char *)this + 1064);
              v51 = v14[v11] + unk_286B898;
              unk_286B898 = -unk_286B898;
              v52 = v51 * *((float *)this + 265);
              do
              {
                v53 = *(v49 - 1);
                v50 += 4;
                v49 += 2;
                v54 = *(v49 - 2);
                v55 = v52 - (float)(*(v50 - 4) * v53);
                v56 = *(v50 - 3) * v54;
                v57 = v54 * *(v50 - 1);
                v58 = v55 - v56;
                v59 = *(v50 - 2);
                *(v49 - 2) = v53;
                *(v49 - 3) = v58;
                v52 = (float)((float)(v59 * v53) + v58) + v57;
              }
              while ( v50 != v6 );
              v15[v11] = v52;
              v14 = (float *)((char *)v14 + v8);
              v15 = (float *)((char *)v15 + v8);
              --v13;
            }
            while ( v13 );
            v15 = (float *)&v219[v12 * 4];
            v14 = (float *)&v222[v12 * 4];
          }
          if ( len )
          {
            v60 = len;
            do
            {
              v61 = (float *)((char *)this + 16 * (int)count + 552);
              v62 = (float *)((char *)this + 1064);
              v63 = *v14 + unk_286B898;
              unk_286B898 = -unk_286B898;
              v64 = v63 * *((float *)this + 265);
              do
              {
                v65 = *(v61 - 1);
                v62 += 4;
                v61 += 2;
                v66 = *(v61 - 2);
                v67 = v64 - (float)(*(v62 - 4) * v65);
                v68 = *(v62 - 3) * v66;
                v69 = v66 * *(v62 - 1);
                v70 = v67 - v68;
                v71 = *(v62 - 2);
                *(v61 - 2) = v65;
                *(v61 - 3) = v70;
                v64 = (float)((float)(v71 * v65) + v70) + v69;
              }
              while ( v62 != v6 );
              *v15 = v64;
              v14 = (float *)((char *)v14 + v7 * 4);
              v15 = (float *)((char *)v15 + v7 * 4);
              --v60;
            }
            while ( v60 );
          }
          ++count;
          ++v12;
        }
        while ( count != channels );
      }
      break;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f9500 | Name: _ZN4FMOD10DSPLowPass22shouldIProcessInternalEiji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::shouldIProcessInternal(
        FMOD::DSPLowPass *const this,
        FMOD_BOOL inputsidle,
        unsigned int length,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  unsigned int v5; // ecx
  FMOD_RESULT_0 result; // eax

  if ( inputsidle )
  {
    v5 = *((_DWORD *)this + 286);
    result = FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
    if ( v5 )
    {
      if ( v5 > length )
      {
        LOBYTE(result) = 0;
        *((_DWORD *)this + 286) = v5 - length;
      }
      else
      {
        *((_DWORD *)this + 286) = 0;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  else
  {
    *((_DWORD *)this + 286) = 4;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21f9550 | Name: _ZN4FMOD10DSPLowPass22shouldIProcessCallbackEP14FMOD_DSP_STATEijji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::shouldIProcessCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD_BOOL inputsidle,
        unsigned int length,
        FMOD_CHANNELMASK a4,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  return FMOD::DSPLowPass::shouldIProcessInternal(
           (FMOD::DSPLowPass *const)dsp_state->instance,
           inputsidle,
           length,
           inchannels,
           speakermode);
}


// Address: 0x21f9560 | Name: _ZN4FMOD10DSPLowPass13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::resetInternal(FMOD::DSPLowPass *const this)
{
  char *v1; // rdx
  unsigned int v2; // esi
  __int64 v3; // rcx
  char *v4; // rdi
  char *v5; // rdx

  v1 = (char *)this + 548;
  v2 = 512;
  if ( (((_BYTE)this + 36) & 1) == 0 )
  {
    if ( ((unsigned __int8)v1 & 2) == 0 )
      goto LABEL_3;
LABEL_12:
    v1 += 2;
    v2 -= 2;
    *((_WORD *)v1 - 1) = 0;
    if ( ((unsigned __int8)v1 & 4) == 0 )
      goto LABEL_4;
    goto LABEL_13;
  }
  v1 = (char *)this + 549;
  *((_BYTE *)this + 548) = 0;
  LOWORD(v2) = 511;
  if ( (((_BYTE)this + 37) & 2) != 0 )
    goto LABEL_12;
LABEL_3:
  if ( ((unsigned __int8)v1 & 4) == 0 )
    goto LABEL_4;
LABEL_13:
  *(_DWORD *)v1 = 0;
  v2 -= 4;
  v1 += 4;
LABEL_4:
  v3 = v2 >> 3;
  memset(v1, 0, 8 * v3);
  v4 = &v1[8 * v3];
  v5 = v4;
  if ( (v2 & 4) != 0 )
  {
    *(_DWORD *)v4 = 0;
    v5 = v4 + 4;
  }
  if ( (v2 & 2) != 0 )
  {
    v5 += 2;
    *((_WORD *)v5 - 1) = 0;
  }
  if ( (v2 & 1) != 0 )
    *v5 = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f9610 | Name: _ZN4FMOD10DSPLowPass13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLowPass::resetInternal((FMOD::DSPLowPass *const)dsp_state->instance);
}


// Address: 0x21f9620 | Name: _ZN4FMOD10DSPLowPass7prewarpEPfS1_S1_ff
__int64 __fastcall FMOD::DSPLowPass::prewarp(
        FMOD::DSPLowPass *const this,
        float *a0,
        float *a1,
        float *a2,
        float fc,
        float fs_0)
{
  float v8; // xmm0_4
  float v10; // xmm1_4

  v8 = tanf((float)(fc * 3.1415927) / fs_0);
  v10 = (float)(fs_0 + fs_0) * v8;
  *a2 = *a2 / (float)(v10 * v10);
  *a1 = *a1 / v10;
  return 0;
}


// Address: 0x21f9680 | Name: _ZN4FMOD10DSPLowPass8bilinearEffffffPffS1_
__int64 __fastcall FMOD::DSPLowPass::bilinear(
        FMOD::DSPLowPass *const this,
        float a0,
        float a1,
        float a2,
        float b0,
        float b1,
        float b2,
        float *k,
        float fs_0,
        float *coef)
{
  float v11; // xmm1_4
  float v12; // xmm4_4
  float v13; // xmm7_4
  float v14; // xmm8_4
  float v15; // xmm9_4
  float v16; // xmm10_4

  v11 = (float)(a1 + a1) * fs_0;
  v12 = (float)(b1 + b1) * fs_0;
  v13 = (float)((float)(a2 * 4.0) * fs_0) * fs_0;
  v14 = (float)((float)(4.0 * b2) * fs_0) * fs_0;
  v15 = (float)(v13 + v11) + a0;
  v16 = (float)(v14 + v12) + b0;
  *k = (float)(v15 / v16) * *k;
  coef[1] = (float)((float)(v14 - v12) + b0) / v16;
  coef[3] = (float)((float)(v13 - v11) + a0) / v15;
  *coef = (float)((float)(b0 + b0) - (float)((float)((float)(b2 * 8.0) * fs_0) * fs_0)) / v16;
  coef[2] = (float)((float)(a0 + a0) - (float)((float)((float)(a2 * 8.0) * fs_0) * fs_0)) / v15;
  return 0;
}


// Address: 0x21f9770 | Name: _ZN4FMOD10DSPLowPass7szxformEPfS1_S1_S1_S1_S1_ffS1_S1_
__int64 __fastcall FMOD::DSPLowPass::szxform(
        FMOD::DSPLowPass *const this,
        float *a0,
        float *a1,
        float *a2,
        float *b0,
        float *b1,
        float fc,
        float fs_0,
        float *b2,
        float *k,
        float *coef)
{
  FMOD::DSPLowPass::prewarp(this, a0, a1, a2, fc, fs_0);
  FMOD::DSPLowPass::prewarp(this, b0, b1, b2, fc, fs_0);
  FMOD::DSPLowPass::bilinear(this, *a0, *a1, *a2, *b0, *b1, *b2, k, fs_0, coef);
  return 0;
}


// Address: 0x21f9820 | Name: _ZN4FMOD10DSPLowPass25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPLowPass::setParameterFloatInternal(
        FMOD::DSPLowPass *const this,
        int index,
        float a3,
        float value)
{
  float v4; // xmm1_4

  if ( !index )
  {
    v4 = *((float *)this + 134);
    *((float *)this + 288) = a3;
    if ( a3 >= v4 )
      *((float *)this + 288) = v4;
    return 0;
  }
  if ( index != 1 )
    return 0;
  *((float *)this + 287) = a3;
  return 0;
}


// Address: 0x21f9860 | Name: _ZN4FMOD10DSPLowPass25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPLowPass::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPLowPass::setParameterFloatInternal((FMOD::DSPLowPass *const)dsp_state->instance, index, a3, value);
}


// Address: 0x21f9870 | Name: _ZN4FMOD10DSPLowPass25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::getParameterFloatInternal(
        FMOD::DSPLowPass *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v4; // xmm0_4

  if ( !index )
  {
    *value = *((float *)this + 288);
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    v4 = *((float *)this + 288);
    goto LABEL_5;
  }
  if ( index == 1 )
  {
    *value = *((float *)this + 287);
    if ( valuestr )
    {
      v4 = *((float *)this + 287);
LABEL_5:
      sprintf(valuestr, "%.02f", v4);
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f98e0 | Name: _ZN4FMOD10DSPLowPass25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPLowPass::getParameterFloatInternal(
           (FMOD::DSPLowPass *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x21f98f0 | Name: _ZN4FMOD10DSPLowPass11updateStateEff
__int64 __fastcall FMOD::DSPLowPass::updateState(
        FMOD::DSPLowPass *const this,
        float xmm0_4_0,
        float resonance,
        float cutoff)
{
  float v5; // xmm5_4
  int v6; // eax
  float v7; // xmm8_4
  float v8; // xmm6_4
  float *coef; // r15
  float v10; // xmm0_4
  float *v11; // r14
  float *v12; // rbp
  float *v13; // rbx
  float v14; // xmm2_4
  float v15; // xmm2_4
  float v16; // xmm4_4
  float *v18; // rax
  float v19; // xmm3_4
  float v20; // xmm2_4
  float ktotal; // [rsp+2Ch] [rbp-9Ch]
  float a0; // [rsp+68h] [rbp-60h] BYREF
  float a1; // [rsp+6Ch] [rbp-5Ch] BYREF
  float a2; // [rsp+70h] [rbp-58h] BYREF
  float b0; // [rsp+74h] [rbp-54h] BYREF
  float b1; // [rsp+78h] [rbp-50h] BYREF
  float b2; // [rsp+7Ch] [rbp-4Ch] BYREF
  float k[18]; // [rsp+80h] [rbp-48h] BYREF

  v5 = 1.0;
  v6 = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  if ( xmm0_4_0 >= 1.0 )
  {
    v7 = (float)v6;
    v8 = resonance;
    coef = (float *)((char *)this + 1064);
    k[0] = 1.0;
    k[1] = 1.0;
    v10 = 0.5 * (float)v6;
    if ( resonance > v10 )
      v8 = v10 - 10.0;
    v11 = k;
    v12 = (float *)((char *)this + 548);
    v13 = (float *)this;
    do
    {
      v14 = v13[278] / xmm0_4_0;
      a0 = v13[274];
      a1 = v13[275];
      a2 = v13[276];
      b0 = v13[277];
      b2 = v13[279];
      ktotal = v5;
      b1 = v14;
      FMOD::DSPLowPass::szxform(this, &a0, &a1, &a2, &b0, &b1, v8, v7, &b2, v11, coef);
      v15 = *(v12 - 2);
      v16 = *v11;
      if ( v15 != 0.0 )
      {
        v18 = v12;
        v19 = v16 / v15;
        do
        {
          v20 = *v18;
          v18 += 4;
          *(v18 - 4) = v20 * v19;
        }
        while ( v18 != v12 + 128 );
      }
      *(v12 - 2) = v16;
      coef += 4;
      v13 += 6;
      ++v11;
      ++v12;
      v5 = ktotal * v16;
    }
    while ( v13 != (float *)((char *)this + 48) );
    *((float *)this + 265) = v5;
  }
  return 0;
}


// Address: 0x21f9b10 | Name: _ZN4FMOD10DSPLowPass14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::createInternal(FMOD::DSPLowPass *const this)
{
  double v1; // xmm1_8
  float v2; // xmm2_4
  __int64 v3; // r12
  __int64 v4; // rax
  int v5; // ebx
  float v6; // xmm0_4
  __int64 v7; // rax
  int v8; // edx
  FMOD_RESULT_0 result; // eax
  float v10; // xmm0_4
  float v11; // xmm1_4

  v3 = 0;
  v4 = *((_QWORD *)this + 22);
  v5 = 0;
  *((_DWORD *)this + 274) = 1065353216;
  *((_DWORD *)this + 275) = 0;
  *((_DWORD *)this + 276) = 0;
  *((_DWORD *)this + 277) = 1065353216;
  v6 = (float)*(int *)(v4 + 1696) * 0.5;
  v7 = *((_QWORD *)this + 30);
  *((_DWORD *)this + 278) = 1061416727;
  *((_DWORD *)this + 279) = 1065353216;
  *((_DWORD *)this + 135) = 1065353216;
  *((_DWORD *)this + 280) = 1065353216;
  v8 = *(_DWORD *)(v7 + 96);
  *((_DWORD *)this + 281) = 0;
  *((_DWORD *)this + 282) = 0;
  *((_DWORD *)this + 283) = 1065353216;
  *((_DWORD *)this + 284) = 1072464734;
  *((_DWORD *)this + 285) = 1065353216;
  *((_DWORD *)this + 136) = 1065353216;
  *((_DWORD *)this + 286) = 0;
  *((float *)this + 134) = v6 - 10.0;
  if ( v8 > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v5,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v7 + 104) + v3) + 56LL),
                 v1);
      if ( result )
        break;
      v7 = *((_QWORD *)this + 30);
      ++v5;
      v3 += 8;
      if ( *(_DWORD *)(v7 + 96) <= v5 )
        goto LABEL_6;
    }
  }
  else
  {
LABEL_6:
    v10 = *((float *)this + 287);
    v11 = *((float *)this + 288);
    *((float *)this + 132) = v10;
    *((float *)this + 133) = v11;
    FMOD::DSPLowPass::updateState(this, v10, v11, v2);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21f9c60 | Name: _ZN4FMOD10DSPLowPass14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLowPass::createInternal((FMOD::DSPLowPass *const)dsp_state->instance);
}


// Address: 0x21f9c70 | Name: _ZN4FMOD10DSPLowPass12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::readInternal(
        FMOD::DSPLowPass *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float *v6; // r12
  __int64 v10; // r14
  float v11; // xmm0_4
  float v12; // xmm2_4
  float v13; // xmm1_4
  float *v14; // rsi
  float v15; // xmm2_4
  float v16; // xmm3_4
  _DWORD *v18; // rax

  v6 = inbuffer;
  if ( !inbuffer )
    return FMOD_RESULT::FMOD_OK_0;
  v10 = 4LL * inchannels;
  while ( 1 )
  {
    v11 = *((float *)this + 132);
    v15 = *((float *)this + 287);
    v13 = *((float *)this + 133);
    if ( v11 == v15 && v13 == *((float *)this + 288) )
      break;
    if ( !length )
      break;
    v16 = (float)(v13 / 100.0) + 10.0;
    if ( v15 > v11 )
    {
      v11 = v11 + 1.0;
      if ( v11 >= v15 )
        goto LABEL_4;
    }
    else
    {
      if ( v11 <= v15 )
        goto LABEL_5;
      v11 = v11 - 1.0;
      if ( v15 >= v11 )
      {
LABEL_4:
        *((float *)this + 132) = v15;
        v11 = v15;
LABEL_5:
        v12 = *((float *)this + 288);
        if ( v12 > v13 )
          goto LABEL_6;
        goto LABEL_15;
      }
    }
    v12 = *((float *)this + 288);
    *((float *)this + 132) = v11;
    if ( v12 > v13 )
    {
LABEL_6:
      v13 = v13 + v16;
      if ( v13 < v12 )
        goto LABEL_17;
      goto LABEL_7;
    }
LABEL_15:
    if ( v13 <= v12 )
      goto LABEL_8;
    v13 = v13 - v16;
    if ( v12 < v13 )
    {
LABEL_17:
      *((float *)this + 133) = v13;
      goto LABEL_8;
    }
LABEL_7:
    *((float *)this + 133) = v12;
    v13 = v12;
LABEL_8:
    FMOD::DSPLowPass::updateState(this, v11, v13, v12);
    v14 = v6;
    v6 = (float *)((char *)v6 + v10);
    FMOD::DSPLowPass::process(this, v14, outbuffer, 1u, inchannels);
    outbuffer = (float *)((char *)outbuffer + v10);
    if ( !--length )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( v13 >= *((float *)this + 134) )
  {
    memcpy_0(outbuffer, v6, v10 * length);
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( v13 >= 10.0 )
    return FMOD::DSPLowPass::process(this, v6, outbuffer, length, inchannels);
  memset(outbuffer, 0, v10 * length);
  if ( inchannels > 0 )
  {
    v18 = (_DWORD *)((char *)this + 548);
    do
    {
      *v18 = 0;
      v18[1] = 0;
      v18 += 4;
      *(v18 - 2) = 0;
      *(v18 - 1) = 0;
    }
    while ( v18 != (_DWORD *)((char *)this + 16 * (unsigned int)(inchannels - 1) + 564) );
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f9e90 | Name: _ZN4FMOD10DSPLowPass12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPLowPass::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPLowPass::readInternal(
           (FMOD::DSPLowPass *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


