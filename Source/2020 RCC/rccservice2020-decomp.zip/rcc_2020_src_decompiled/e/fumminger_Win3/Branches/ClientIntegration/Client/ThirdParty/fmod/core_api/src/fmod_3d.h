// Address: 0x21e4880 | Name: _ZN4FMOD13ChannelGroupI14set3DOcclusionEff
FMOD_RESULT_0 __fastcall FMOD::ChannelGroupI::set3DOcclusion(
        FMOD::ChannelGroupI *const this,
        __m128i a2,
        __m128i direct,
        float reverb)
{
  float v4; // xmm2_4
  int (**vptr_ChannelControlI)(...); // rax

  if ( (_mm_cvtsi128_si32(a2) & 0x7F800000) != 0x7F800000 && (_mm_cvtsi128_si32(direct) & 0x7F800000) != 0x7F800000 )
  {
    v4 = 0.0;
    if ( *(float *)a2.m128i_i32 >= 0.0 || *(float *)a2.m128i_i32 >= 1.0 )
    {
      this->mUserDirectOcclusion = fminf(*(float *)a2.m128i_i32, 1.0);
      if ( *(float *)direct.m128i_i32 >= 0.0 )
        goto LABEL_6;
    }
    else
    {
      this->mUserDirectOcclusion = 0.0;
      if ( *(float *)direct.m128i_i32 >= 0.0 )
        goto LABEL_6;
    }
    if ( *(float *)direct.m128i_i32 < 1.0 )
    {
LABEL_7:
      vptr_ChannelControlI = this->_vptr_ChannelControlI;
      this->mUserReverbOcclusion = v4;
      return (FMOD_RESULT_0)vptr_ChannelControlI[51](this, 0, this->mDirectOcclusion, this->mReverbOcclusion);
    }
LABEL_6:
    v4 = fminf(*(float *)direct.m128i_i32, 1.0);
    goto LABEL_7;
  }
  return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
}


// Address: 0x220e790 | Name: _ZN4FMOD15ChannelControlI8setPitchEf
__int64 __fastcall FMOD::ChannelControlI::setPitch(FMOD::ChannelControlI *const this, __m128i a2, float pitch)
{
  unsigned __int64 v3; // rdx
  __int64 result; // rax

  v3 = (unsigned int)_mm_cvtsi128_si32(a2);
  if ( (unsigned __int8)(v3 >> 23) != 0xFF || (result = 29, (v3 & 0x7FFFFF) == 0) )
  {
    this->mPitch = fmaxf(0.0, *(float *)a2.m128i_i32);
    return 0;
  }
  return result;
}


