// Address: 0x2205700 | Name: _ZN4FMOD10RemoteFile10reallySeekEj
FMOD_RESULT_0 __fastcall FMOD::RemoteFile::reallySeek(FMOD::RemoteFile *const this, unsigned int pos)
{
  unsigned int mFileSize; // eax

  mFileSize = this->mFileSize;
  this->mPosition = pos;
  if ( pos > mFileSize )
    this->mPosition = mFileSize;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2205750 | Name: _ZN4FMOD10RemoteFile10reallyOpenEPKcPj
FMOD_RESULT_0 __fastcall FMOD::RemoteFile::reallyOpen(
        FMOD::RemoteFile *const this,
        const char *name_or_data,
        unsigned int *filesize)
{
  FMOD::SystemI *mSystem; // rax
  FMOD::Profile *v6; // rdi
  FMOD::ProfileRemoteFile *ModuleForType; // rax

  mSystem = this->mSystem;
  *filesize = 0;
  this->mPosition = 0;
  this->mFileHandle = 0;
  if ( !mSystem )
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  v6 = *(FMOD::Profile **)((char *)&stru_125D0.r_offset + (_QWORD)mSystem);
  if ( v6 && (ModuleForType = (FMOD::ProfileRemoteFile *)FMOD::Profile::getModuleForType(v6, 0xAu)) != 0 )
    return FMOD::ProfileRemoteFile::fileOpen(ModuleForType, name_or_data, filesize, &this->mFileHandle);
  else
    return FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0;
}


// Address: 0x22057e0 | Name: _ZN4FMOD10RemoteFile11reallyCloseEv
FMOD_RESULT_0 __fastcall FMOD::RemoteFile::reallyClose(FMOD::RemoteFile *const this)
{
  FMOD::SystemI *mSystem; // rdx
  FMOD_RESULT_0 result; // eax
  FMOD::Profile *v4; // rdi
  FMOD::ProfileRemoteFile *ModuleForType; // rax

  mSystem = this->mSystem;
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( mSystem )
  {
    v4 = *(FMOD::Profile **)((char *)&stru_125D0.r_offset + (_QWORD)mSystem);
    if ( v4 && (ModuleForType = (FMOD::ProfileRemoteFile *)FMOD::Profile::getModuleForType(v4, 0xAu)) != 0 )
      result = FMOD::ProfileRemoteFile::fileClose(ModuleForType, this->mFileHandle);
    else
      result = FMOD_RESULT::FMOD_OK_0;
    this->mFileHandle = 0;
  }
  return result;
}


// Address: 0x2205840 | Name: _ZN4FMOD10RemoteFile10reallyReadEPvjPj
FMOD_RESULT_0 __fastcall FMOD::RemoteFile::reallyRead(
        FMOD::RemoteFile *const this,
        void *buffer,
        unsigned int size,
        unsigned int *read)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *mSystem; // rdx
  FMOD::Profile *v8; // rdi
  FMOD::ProfileRemoteFile *ModuleForType; // rbp
  unsigned int mPosition; // r8d
  unsigned int v12; // r15d
  void *mFileHandle; // rsi
  int v14; // ecx
  unsigned int chunkread[15]; // [rsp+1Ch] [rbp-3Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  mSystem = this->mSystem;
  *read = 0;
  if ( mSystem )
  {
    v8 = *(FMOD::Profile **)((char *)&stru_125D0.r_offset + (_QWORD)mSystem);
    if ( v8 && (ModuleForType = (FMOD::ProfileRemoteFile *)FMOD::Profile::getModuleForType(v8, 0xAu)) != 0 )
    {
      if ( size )
      {
        mPosition = this->mPosition;
        v12 = 0;
        do
        {
          mFileHandle = this->mFileHandle;
          v14 = 0x10000;
          if ( size <= 0x10000 )
            v14 = size;
          chunkread[0] = 0;
          result = FMOD::ProfileRemoteFile::fileRead(
                     ModuleForType,
                     mFileHandle,
                     (char *)buffer + v12,
                     v14,
                     mPosition,
                     chunkread);
          size -= chunkread[0];
          mPosition = chunkread[0] + this->mPosition;
          v12 += chunkread[0];
          this->mPosition = mPosition;
        }
        while ( result == FMOD_RESULT::FMOD_OK_0 && size );
      }
      else
      {
        v12 = 0;
        result = FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
      }
      *read = v12;
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    }
  }
  return result;
}


