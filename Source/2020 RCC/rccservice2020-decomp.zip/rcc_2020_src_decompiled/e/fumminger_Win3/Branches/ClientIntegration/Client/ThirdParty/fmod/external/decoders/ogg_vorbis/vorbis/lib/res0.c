// Address: 0x2270500 | Name: FMOD_res0_free_info
void __fastcall FMOD_res0_free_info(void *context, vorbis_info_residue *i)
{
  _DWORD *v3; // rdi
  unsigned int v4; // r8d
  __int64 v5; // rcx
  _DWORD *v6; // rdi

  if ( i )
  {
    v3 = i;
    v4 = 1812;
    if ( ((unsigned __int8)i & 1) != 0 )
    {
      *(_BYTE *)i = 0;
      v3 = (char *)i + 1;
      LOBYTE(v4) = 19;
    }
    if ( ((unsigned __int8)v3 & 2) != 0 )
    {
      v3 = (_DWORD *)((char *)v3 + 2);
      v4 -= 2;
      *((_WORD *)v3 - 1) = 0;
    }
    if ( ((unsigned __int8)v3 & 4) != 0 )
    {
      *v3 = 0;
      v4 -= 4;
      ++v3;
    }
    v5 = v4 >> 3;
    memset(v3, 0, 8 * v5);
    v6 = &v3[2 * v5];
    if ( (v4 & 4) != 0 )
    {
      *v6++ = 0;
      if ( (v4 & 2) == 0 )
      {
LABEL_10:
        if ( (v4 & 1) == 0 )
        {
LABEL_11:
          FMOD_OggVorbis_Free(context, i);
          return;
        }
        goto LABEL_12;
      }
    }
    else if ( (v4 & 2) == 0 )
    {
      goto LABEL_10;
    }
    v6 = (_DWORD *)((char *)v6 + 2);
    *((_WORD *)v6 - 1) = 0;
    if ( (v4 & 1) == 0 )
      goto LABEL_11;
LABEL_12:
    *(_BYTE *)v6 = 0;
    FMOD_OggVorbis_Free(context, i);
  }
}


// Address: 0x22705f0 | Name: FMOD_res0_free_look
void __fastcall FMOD_res0_free_look(void *context, vorbis_look_residue *i)
{
  __int64 v4; // r12
  int v5; // ebp
  char *j; // rax
  void *v7; // rsi
  __int64 v8; // rbp
  _DWORD *v9; // rdi
  unsigned int v10; // edx
  __int64 v11; // rcx
  _DWORD *v12; // rdi

  if ( i )
  {
    v4 = 0;
    v5 = 0;
    for ( j = (char *)*((_QWORD *)i + 4); *((_DWORD *)i + 2) > v5; v4 += 8 )
    {
      v7 = *(void **)&j[v4];
      if ( v7 )
      {
        FMOD_OggVorbis_Free(context, v7);
        j = (char *)*((_QWORD *)i + 4);
      }
      ++v5;
    }
    v8 = 0;
    FMOD_OggVorbis_Free(context, j);
    if ( *((int *)i + 10) > 0 )
    {
      do
        FMOD_OggVorbis_Free(context, *(void **)(*((_QWORD *)i + 6) + 8 * v8++));
      while ( *((_DWORD *)i + 10) > (int)v8 );
    }
    FMOD_OggVorbis_Free(context, *((void **)i + 6));
    v9 = i;
    v10 = 72;
    if ( ((unsigned __int8)i & 1) != 0 )
    {
      *(_BYTE *)i = 0;
      v9 = (char *)i + 1;
      LOBYTE(v10) = 71;
    }
    if ( ((unsigned __int8)v9 & 2) != 0 )
    {
      v9 = (_DWORD *)((char *)v9 + 2);
      v10 -= 2;
      *((_WORD *)v9 - 1) = 0;
    }
    if ( ((unsigned __int8)v9 & 4) != 0 )
    {
      *v9 = 0;
      v10 -= 4;
      ++v9;
    }
    v11 = v10 >> 3;
    memset(v9, 0, 8 * v11);
    v12 = &v9[2 * v11];
    if ( (v10 & 4) != 0 )
    {
      *v12++ = 0;
      if ( (v10 & 2) == 0 )
      {
LABEL_16:
        if ( (v10 & 1) == 0 )
        {
LABEL_17:
          FMOD_OggVorbis_Free(context, i);
          return;
        }
LABEL_18:
        *(_BYTE *)v12 = 0;
        goto LABEL_17;
      }
    }
    else if ( (v10 & 2) == 0 )
    {
      goto LABEL_16;
    }
    v12 = (_DWORD *)((char *)v12 + 2);
    *((_WORD *)v12 - 1) = 0;
    if ( (v10 & 1) == 0 )
      goto LABEL_17;
    goto LABEL_18;
  }
}


// Address: 0x2270750 | Name: FMOD_res0_unpack
vorbis_info_residue *__fastcall FMOD_res0_unpack(void *context, vorbis_info_0 *vi, oggpack_buffer_0 *opb)
{
  ogg_int32_t *v4; // r14
  ogg_int32_t v5; // eax
  ogg_int32_t *v6; // r12
  int v7; // r13d
  ogg_int32_t v8; // ebp
  ogg_int32_t v9; // r15d
  ogg_int32_t v10; // eax
  int v11; // edx
  unsigned int v12; // eax
  ogg_int32_t *v13; // r12
  ogg_int32_t v14; // eax
  ogg_int32_t v16; // eax
  int books; // esi
  __int64 v18; // rdx
  int *v19; // rdx
  __int64 v20; // rcx
  int *v21; // rax
  int v22; // esi
  int v23; // eax
  int v24; // ecx
  int v25; // edx
  codec_setup_info_0 *ci; // [rsp+0h] [rbp-48h]

  v4 = (ogg_int32_t *)FMOD_OggVorbis_Calloc(context, 1, 1812);
  ci = (codec_setup_info_0 *)vi->codec_setup;
  if ( !v4 )
    goto errout;
  *v4 = FMOD_oggpack_read((oggpack_buffer *)opb, 24);
  v4[1] = FMOD_oggpack_read((oggpack_buffer *)opb, 24);
  v4[2] = FMOD_oggpack_read((oggpack_buffer *)opb, 24) + 1;
  v4[3] = FMOD_oggpack_read((oggpack_buffer *)opb, 6) + 1;
  v5 = FMOD_oggpack_read((oggpack_buffer *)opb, 8);
  v4[4] = v5;
  if ( v5 < 0 )
    goto errout;
  if ( v4[3] > 0 )
  {
    v6 = v4 + 5;
    v7 = 0;
    v8 = 0;
    while ( 1 )
    {
      v9 = FMOD_oggpack_read((oggpack_buffer *)opb, 3);
      v10 = FMOD_oggpack_read((oggpack_buffer *)opb, 1);
      if ( v10 < 0 )
        goto errout;
      if ( v10 )
      {
        v16 = FMOD_oggpack_read((oggpack_buffer *)opb, 5);
        if ( v16 < 0 )
          goto errout;
        v9 |= 8 * v16;
      }
      v11 = 0;
      *v6 = v9;
      v12 = v9;
      if ( v9 )
      {
        do
        {
          v11 += v12 & 1;
          v12 >>= 1;
        }
        while ( v12 );
      }
      v7 += v11;
      ++v8;
      ++v6;
      if ( v4[3] <= v8 )
      {
        if ( v7 > 0 )
        {
          v13 = v4 + 69;
          do
          {
            v14 = FMOD_oggpack_read((oggpack_buffer *)opb, 8);
            if ( v14 < 0 )
              goto errout;
            *v13++ = v14;
          }
          while ( v13 != &v4[v7 - 1 + 70] );
        }
        v5 = v4[4];
        books = ci->books;
        if ( books <= v5 )
          goto errout;
        if ( v7 > 0 )
        {
          v18 = v4[69];
          if ( books <= (int)v18 || !LODWORD(ci->book_param[v18]->lengthlist) )
            goto errout;
          v19 = v4 + 70;
          while ( v19 != &v4[v7 - 1 + 70] )
          {
            v20 = *v19;
            if ( books > (int)v20 )
            {
              ++v19;
              if ( LODWORD(ci->book_param[v20]->lengthlist) )
                continue;
            }
            goto errout;
          }
        }
        goto LABEL_25;
      }
    }
  }
  if ( v5 >= ci->books )
  {
errout:
    FMOD_res0_free_info(context, v4);
    return 0;
  }
LABEL_25:
  v21 = (int *)ci->book_param[v5];
  v22 = v21[1];
  v23 = *v21;
  if ( v23 > 0 )
  {
    v24 = v4[3];
    if ( v22 < v24 )
      goto errout;
    v25 = v4[3];
    while ( --v23 )
    {
      v25 *= v24;
      if ( v22 < v25 )
        goto errout;
    }
  }
  return v4;
}


// Address: 0x2270990 | Name: FMOD_res0_look
vorbis_look_residue *__fastcall FMOD_res0_look(void *context, vorbis_dsp_state_0 *vd, vorbis_info_residue *vr)
{
  void *v3; // r13
  __int64 bitrate_lower; // r10
  __int64 v5; // rdx
  __int64 v6; // rax
  int v7; // esi
  int *v8; // rax
  int v9; // r15d
  void *v10; // rax
  int v11; // eax
  codec_setup_info_0 *v12; // r10
  _DWORD *v13; // r8
  __int64 v14; // r14
  int v15; // r12d
  int v16; // ebp
  unsigned int v17; // ecx
  int v18; // ebx
  __int64 v19; // rcx
  int v20; // edx
  __int64 v21; // rax
  int v22; // ecx
  int i; // edx
  int v24; // esi
  _QWORD *v25; // rax
  int v26; // ebx
  _QWORD *v27; // r9
  __int64 v28; // r14
  int v29; // ebp
  int v30; // ebx
  __int64 v31; // rdi
  __int64 j; // rcx
  int v33; // esi
  int v34; // eax
  vorbis_info_residue0_0 *infoa; // [rsp+8h] [rbp-60h]
  codec_setup_info_0 *ci; // [rsp+18h] [rbp-50h]
  codec_setup_info_0 *v40; // [rsp+20h] [rbp-48h]
  _DWORD *v41; // [rsp+28h] [rbp-40h]

  v3 = FMOD_OggVorbis_Calloc(context, 1, 72);
  bitrate_lower = vd->vi->bitrate_lower;
  if ( v3 )
  {
    v5 = *((int *)vr + 4);
    v6 = *(_QWORD *)(bitrate_lower + 4896);
    v7 = *((_DWORD *)vr + 3);
    *(_QWORD *)v3 = vr;
    ci = (codec_setup_info_0 *)bitrate_lower;
    *((_QWORD *)v3 + 2) = v6;
    *((_DWORD *)v3 + 2) = v7;
    v8 = (int *)(v6 + 72 * v5);
    *((_QWORD *)v3 + 3) = v8;
    v9 = *v8;
    v10 = FMOD_OggVorbis_Calloc(context, v7, 8);
    *((_QWORD *)v3 + 4) = v10;
    if ( v10 )
    {
      v11 = *((_DWORD *)v3 + 2);
      if ( v11 > 0 )
      {
        v12 = ci;
        v13 = vr;
        v14 = 0;
        v15 = 0;
        v16 = 0;
        while ( 1 )
        {
          v17 = v13[v14 + 5];
          if ( v17 )
          {
            v18 = 0;
            do
            {
              ++v18;
              v17 >>= 1;
            }
            while ( v17 );
            if ( v15 < v18 )
              v15 = v18;
            v41 = v13;
            v40 = v12;
            infoa = (vorbis_info_residue0_0 *)(*((_QWORD *)v3 + 4) + 8 * v14);
            *(_QWORD *)&infoa->begin = FMOD_OggVorbis_Calloc(context, v18, 8);
            if ( !*(_QWORD *)(*((_QWORD *)v3 + 4) + 8 * v14) )
              return 0;
            v13 = v41;
            v12 = v40;
            v19 = 0;
            v20 = v41[v14 + 5];
            do
            {
              if ( _bittest(&v20, v19) )
              {
                v21 = v16++;
                *(_QWORD *)(*(_QWORD *)(*((_QWORD *)v3 + 4) + 8 * v14) + 8 * v19) = (char *)v40->fullbooks
                                                                                  + 72 * v41[v21 + 69];
              }
              ++v19;
            }
            while ( v18 > (int)v19 );
            v11 = *((_DWORD *)v3 + 2);
          }
          if ( v11 <= (int)++v14 )
            goto LABEL_17;
        }
      }
      v15 = 0;
LABEL_17:
      *((_DWORD *)v3 + 10) = 1;
      if ( v9 <= 0 )
      {
        v24 = 8;
      }
      else
      {
        v22 = 1;
        for ( i = 0; i != v9; ++i )
          v22 *= v11;
        v24 = 8 * v22;
        *((_DWORD *)v3 + 10) = v22;
      }
      *((_DWORD *)v3 + 3) = v15;
      v25 = FMOD_OggVorbis_Malloc(context, v24);
      *((_QWORD *)v3 + 6) = v25;
      if ( v25 )
      {
        v26 = *((_DWORD *)v3 + 10);
        if ( v26 <= 0 )
          return v3;
        v27 = v25;
        v28 = 0;
        while ( 1 )
        {
          v29 = v28;
          v30 = v26 / *((_DWORD *)v3 + 2);
          v27[v28] = FMOD_OggVorbis_Malloc(context, 4 * v9);
          v27 = (_QWORD *)*((_QWORD *)v3 + 6);
          v31 = v27[v28];
          if ( !v31 )
            break;
          for ( j = 0; v9 > (int)j; v30 = v34 )
          {
            v33 = v29 / v30;
            v29 %= v30;
            v34 = v30 / *((_DWORD *)v3 + 2);
            *(_DWORD *)(v31 + 4 * j++) = v33;
          }
          v26 = *((_DWORD *)v3 + 10);
          if ( (int)++v28 >= v26 )
            return v3;
        }
      }
    }
  }
  return 0;
}


// Address: 0x2270c30 | Name: _FMOD_01inverse
int __fastcall FMOD_01inverse(
        void *context,
        vorbis_block_0 *vb,
        vorbis_look_residue *vl,
        float **in,
        int ch_0,
        ogg_int32_t (*decodepart)(codebook *, float *, oggpack_buffer *, int))
{
  vorbis_info_residue0_0 *v6; // r13
  vorbis_info_residue0_0 *v8; // rbx
  int grouping; // edi
  int *v10; // rax
  int end; // edx
  int v12; // ecx
  int v13; // eax
  int v14; // eax
  int v15; // eax
  void *v16; // rsp
  int ***v17; // r14
  vorbis_block_0 *v18; // r13
  ogg_int32_t v19; // ebx
  int ***v20; // r15
  int **v21; // rax
  vorbis_info_residue0_0 *v23; // r15
  __int64 v24; // rax
  vorbis_info_residue0_0 *v25; // r10
  vorbis_info_residue0_0 *v26; // r14
  __int64 v27; // r13
  int v28; // r15d
  vorbis_info_residue0_0 *v29; // r15
  vorbis_info_residue0_0 *v30; // rbx
  vorbis_info_residue0_0 *v31; // r14
  oggpack_buffer *v32; // r12
  __int64 v33; // rax
  ogg_int32_t v34; // eax
  int v35; // r8d
  __int64 v36; // r15
  vorbis_info_residue0_0 *v37; // r11
  __int64 v38; // r14
  unsigned __int64 v39; // r12
  __int64 v40; // r13
  ogg_int32_t begin; // edx
  __int64 v42; // rax
  codebook *v43; // rdi
  ogg_int32_t v44; // eax
  ogg_int32_t v45; // edi
  bool v46; // dl
  bool v47; // al
  int v48; // eax
  __int64 v49; // [rsp+0h] [rbp-B0h] BYREF
  __int64 v50; // [rsp+8h] [rbp-A8h]
  __int64 v51; // [rsp+10h] [rbp-A0h]
  __int64 v52; // [rsp+18h] [rbp-98h]
  ogg_int32_t s; // [rsp+20h] [rbp-90h]
  ogg_int32_t i; // [rsp+24h] [rbp-8Ch]
  int partvals; // [rsp+28h] [rbp-88h]
  int partitions_per_word; // [rsp+2Ch] [rbp-84h]
  __int64 v57; // [rsp+30h] [rbp-80h]
  oggpack_buffer *b; // [rsp+38h] [rbp-78h]
  vorbis_info_residue0_0 *v59; // [rsp+40h] [rbp-70h]
  ogg_int32_t (*decodeparta)(codebook *, float *, oggpack_buffer *, int); // [rsp+48h] [rbp-68h]
  float **ina; // [rsp+50h] [rbp-60h]
  int ch_0a; // [rsp+58h] [rbp-58h]
  int samples_per_partition; // [rsp+5Ch] [rbp-54h]
  int ***partword; // [rsp+60h] [rbp-50h]
  vorbis_info_residue0_0 *info; // [rsp+68h] [rbp-48h]
  vorbis_info_residue0_0 *v66; // [rsp+70h] [rbp-40h]
  vorbis_block_0 *vba; // [rsp+78h] [rbp-38h]

  v6 = (vorbis_info_residue0_0 *)vl;
  v8 = *(vorbis_info_residue0_0 **)vl;
  ina = in;
  vba = vb;
  ch_0a = ch_0;
  decodeparta = decodepart;
  grouping = v8->grouping;
  samples_per_partition = grouping;
  v10 = (int *)*((_QWORD *)vl + 3);
  end = v8->end;
  v12 = *v10;
  partitions_per_word = *v10;
  v13 = vb->pcmend >> 1;
  if ( v13 > end )
    v13 = end;
  v14 = v13 - v8->begin;
  if ( v14 > 0 )
  {
    partvals = v14 / grouping;
    v15 = (v12 + v14 / grouping - 1) / v12;
    v16 = alloca(8LL * ch_0 + 15);
    v17 = (int ***)&v49;
    if ( ch_0 > 0 )
    {
      v66 = v8;
      info = v6;
      v18 = vba;
      v19 = 8 * v15;
      partword = (int ***)&v49;
      v20 = (int ***)(&v49 + (unsigned int)(ch_0a - 1) + 1);
      do
      {
        v21 = (int **)FMOD_vorbis_block_alloc(context, v18, v19);
        *v17 = v21;
        if ( !v21 )
          return -139;
        ++v17;
      }
      while ( v17 != v20 );
      v8 = v66;
      v6 = info;
      v17 = partword;
    }
    if ( v6->partitions > 0 )
    {
      v52 = 0;
      v23 = v6;
      v24 = (unsigned int)(ch_0a - 1);
      v51 = 8 * v24 + 8;
      v50 = (__int64)&v17[v24 + 1];
      b = (oggpack_buffer *)&vba->opb;
      while ( 1 )
      {
        s = v52;
        if ( partvals > 0 )
          break;
LABEL_35:
        v48 = v52++;
        if ( v23->partitions <= v48 + 1 )
          return 0;
      }
      v25 = (vorbis_info_residue0_0 *)v17;
      partword = (int ***)(8 * v52);
      v26 = v23;
      v27 = 0;
      LODWORD(vba) = 0;
      v28 = 1 << v52;
      while ( s || ch_0a <= 0 )
      {
LABEL_22:
        if ( partvals > (int)vba && partitions_per_word > 0 )
        {
          v35 = v28;
          v36 = v51;
          v37 = v26;
          v57 = 0;
          v38 = v27;
          i = (_DWORD)vba + 1;
          LODWORD(v59) = samples_per_partition * (_DWORD)vba;
          while ( ch_0a <= 0 )
          {
LABEL_31:
            v45 = i;
            v46 = partitions_per_word > (int)v57 + 1;
            v47 = partvals > i;
            ++v57;
            ++i;
            LODWORD(v59) = samples_per_partition + (_DWORD)v59;
            if ( !v47 || !v46 )
            {
              v27 = v38;
              v28 = v35;
              LODWORD(vba) = v45;
              v26 = v37;
              goto LABEL_33;
            }
          }
          v39 = 0;
          v40 = 4 * v57;
          while ( 1 )
          {
            begin = v8->begin;
            v42 = *(int *)(*(_QWORD *)(*(_QWORD *)((char *)&v25->begin + v39) + v38) + v40);
            if ( (v35 & v8->secondstages[v42]) != 0 )
            {
              v43 = *(codebook **)((char *)partword + *(_QWORD *)(*(_QWORD *)&v37->secondstages[3] + 8 * v42));
              if ( v43 )
              {
                info = v25;
                v66 = v37;
                LODWORD(vba) = v35;
                v44 = decodeparta(v43, &ina[v39 / 8][(int)v59 + begin], b, samples_per_partition);
                v35 = (int)vba;
                v37 = v66;
                v25 = info;
                if ( v44 == -1 )
                  return 0;
              }
            }
            v39 += 8LL;
            if ( v39 == v36 )
              goto LABEL_31;
          }
        }
LABEL_33:
        v27 += 8;
        if ( partvals <= (int)vba )
        {
          v23 = v26;
          v17 = (int ***)v25;
          goto LABEL_35;
        }
      }
      v66 = v8;
      LODWORD(info) = v28;
      v29 = v26;
      v30 = (vorbis_info_residue0_0 *)v50;
      v31 = v25;
      v59 = v25;
      v32 = b;
      while ( 1 )
      {
        v34 = FMOD_vorbis_book_decode(*(codebook_0 **)&v29->secondstages[1], v32);
        if ( v34 == -1 )
          break;
        v33 = *(_QWORD *)(*(_QWORD *)&v29->secondstages[7] + 8LL * v34);
        *(_QWORD *)(*(_QWORD *)&v31->begin + v27) = v33;
        if ( !v33 )
          break;
        v31 = (vorbis_info_residue0_0 *)((char *)v31 + 8);
        if ( v31 == v30 )
        {
          v26 = v29;
          v8 = v66;
          v28 = (int)info;
          v25 = v59;
          goto LABEL_22;
        }
      }
    }
  }
  return 0;
}


// Address: 0x2270fa0 | Name: FMOD_res0_inverse
int __fastcall FMOD_res0_inverse(
        void *context,
        vorbis_block_0 *vb,
        vorbis_look_residue *vl,
        float **in,
        int *nonzero,
        int ch_0)
{
  __int64 v6; // rax
  int v7; // r10d
  __int64 v8; // r11

  v6 = 0;
  v7 = 0;
  if ( ch_0 <= 0 )
    return 0;
  do
  {
    if ( nonzero[v6] )
    {
      v8 = v7++;
      in[v8] = in[v6];
    }
    ++v6;
  }
  while ( ch_0 > (int)v6 );
  if ( v7 )
    return FMOD_01inverse(
             context,
             vb,
             vl,
             in,
             v7,
             (ogg_int32_t (*)(codebook *, float *, oggpack_buffer *, int))FMOD_vorbis_book_decodevs_add);
  else
    return 0;
}


// Address: 0x2271000 | Name: FMOD_res1_inverse
int __fastcall FMOD_res1_inverse(
        void *context,
        vorbis_block_0 *vb,
        vorbis_look_residue *vl,
        float **in,
        int *nonzero,
        int ch_0)
{
  __int64 v6; // rax
  int v7; // r10d
  __int64 v8; // r11

  v6 = 0;
  v7 = 0;
  if ( ch_0 <= 0 )
    return 0;
  do
  {
    if ( nonzero[v6] )
    {
      v8 = v7++;
      in[v8] = in[v6];
    }
    ++v6;
  }
  while ( ch_0 > (int)v6 );
  if ( v7 )
    return FMOD_01inverse(
             context,
             vb,
             vl,
             in,
             v7,
             (ogg_int32_t (*)(codebook *, float *, oggpack_buffer *, int))FMOD_vorbis_book_decodev_add);
  else
    return 0;
}


// Address: 0x2271060 | Name: FMOD_res2_inverse
int __fastcall FMOD_res2_inverse(
        void *context,
        vorbis_block_0 *vb,
        vorbis_look_residue *vl,
        float **in,
        int *nonzero,
        int ch_0)
{
  int *v9; // rax
  _DWORD *v10; // r13
  int v11; // edx
  int v12; // r15d
  int v13; // esi
  int v14; // eax
  int v15; // eax
  int *v17; // rdx
  int v18; // eax
  vorbis_look_residue *v20; // r11
  int **v21; // r14
  int v22; // r10d
  int v23; // ecx
  int v24; // ebp
  int **v25; // rax
  __int64 v26; // rbx
  int v27; // r14d
  int **v28; // r10
  int v29; // r12d
  __int64 v30; // rax
  codebook_0 *v31; // rdi
  ogg_int32_t v32; // eax
  bool v33; // dl
  bool v34; // al
  int **v35; // rax
  int v36; // eax
  ogg_int32_t v37; // eax
  int *v38; // rax
  int partvals; // [rsp+4h] [rbp-84h]
  int **v40; // [rsp+8h] [rbp-80h]
  _QWORD *v41; // [rsp+8h] [rbp-80h]
  vorbis_look_residue *v42; // [rsp+10h] [rbp-78h]
  int v43; // [rsp+10h] [rbp-78h]
  int partitions_per_word; // [rsp+28h] [rbp-60h]
  oggpack_buffer *b; // [rsp+30h] [rbp-58h]
  int **partword; // [rsp+38h] [rbp-50h]
  __int64 v49; // [rsp+40h] [rbp-48h]
  int v50; // [rsp+4Ch] [rbp-3Ch]

  v9 = (int *)*((_QWORD *)vl + 3);
  v10 = *(_DWORD **)vl;
  v11 = *(_DWORD *)(*(_QWORD *)vl + 4LL);
  v12 = v10[2];
  v13 = *v9;
  partitions_per_word = *v9;
  v14 = (ch_0 * vb->pcmend) >> 1;
  if ( v14 > v11 )
    v14 = v11;
  v15 = v14 - *v10;
  if ( v15 <= 0 )
    return 0;
  partvals = v15 / v12;
  partword = (int **)FMOD_vorbis_block_alloc(context, vb, 8 * ((v13 + v15 / v12 - 1) / v13));
  if ( partword )
  {
    if ( ch_0 > 0 )
    {
      if ( !*nonzero )
      {
        v17 = nonzero + 1;
        v18 = 0;
        while ( ++v18 != ch_0 )
        {
          if ( *v17++ )
            goto LABEL_12;
        }
        return 0;
      }
      goto LABEL_12;
    }
    if ( ch_0 )
    {
LABEL_12:
      if ( *((int *)vl + 3) > 0 )
      {
        v49 = 0;
        v20 = vl;
        b = (oggpack_buffer *)&vb->opb;
        while ( partvals <= 0 )
        {
LABEL_26:
          v36 = v49++;
          if ( *((_DWORD *)v20 + 3) <= v36 + 1 )
            return 0;
        }
        v21 = partword;
        v22 = 1 << v49;
        v23 = 0;
        while ( 1 )
        {
          if ( !(_DWORD)v49 )
          {
            v50 = v23;
            v43 = v22;
            v41 = v20;
            v37 = FMOD_vorbis_book_decode(*((codebook_0 **)v20 + 3), b);
            if ( v37 == -1 )
              break;
            v20 = v41;
            v22 = v43;
            v23 = v50;
            v38 = *(int **)(v41[6] + 8LL * v37);
            *v21 = v38;
            if ( !v38 )
              break;
          }
          if ( partvals > v23 && partitions_per_word > 0 )
          {
            v24 = v23 + 1;
            v25 = v21;
            v26 = 0;
            v27 = v22;
            v28 = v25;
            v29 = v12 * v23;
            while ( 1 )
            {
              v30 = (*v28)[v26];
              if ( (v27 & v10[v30 + 5]) != 0 )
              {
                v31 = *(codebook_0 **)(*(_QWORD *)(*((_QWORD *)v20 + 4) + 8 * v30) + 8 * v49);
                if ( v31 )
                {
                  v42 = v20;
                  v40 = v28;
                  v32 = FMOD_vorbis_book_decodevv_add(v31, in, v29 + *v10, ch_0, b, v12);
                  v28 = v40;
                  v20 = v42;
                  if ( v32 == -1 )
                    return 0;
                }
              }
              v23 = v24;
              v33 = partitions_per_word > (int)v26 + 1;
              v34 = partvals > v24;
              ++v26;
              ++v24;
              v29 += v12;
              if ( !v34 || !v33 )
              {
                v35 = v28;
                v22 = v27;
                v21 = v35;
                break;
              }
            }
          }
          ++v21;
          if ( partvals <= v23 )
            goto LABEL_26;
        }
      }
    }
    return 0;
  }
  return -1;
}


// Address: 0x22712d0 | Name: FMOD_res1_class
ogg_int32_t **__fastcall FMOD_res1_class(
        void *context,
        vorbis_block_0 *vb,
        vorbis_look_residue *vl,
        float **in,
        int *nonzero,
        int ch_0)
{
  __int64 v6; // rax
  int v7; // r10d
  __int64 v8; // rdx
  int v9; // r14d
  ogg_int32_t **v10; // r15
  __int64 v11; // rbx
  ogg_int32_t *v12; // rax
  unsigned __int64 v13; // r12
  int v14; // r9d
  float v15; // xmm9_4
  __int64 v16; // r8
  __int64 v17; // rax
  __int64 v18; // r13
  __int64 v19; // rdi
  float *v20; // rdx
  float v21; // xmm3_4
  float v22; // xmm1_4
  __int64 v23; // rax
  __m128 v24; // xmm0
  float v25; // xmm2_4
  float v26; // xmm3_4
  float *v27; // rax
  ogg_int32_t v28; // edx
  float v29; // xmm0_4
  ogg_int32_t *v30; // rax
  int used; // [rsp+8h] [rbp-70h]
  int v33; // [rsp+10h] [rbp-68h]
  __int64 v34; // [rsp+10h] [rbp-68h]
  int v36; // [rsp+24h] [rbp-54h]
  _DWORD *v37; // [rsp+28h] [rbp-50h]

  v6 = 0;
  v7 = 0;
  if ( ch_0 > 0 )
  {
    do
    {
      if ( nonzero[v6] )
      {
        v8 = v7++;
        in[v8] = in[v6];
      }
      ++v6;
    }
    while ( ch_0 > (int)v6 );
    if ( v7 )
    {
      used = v7;
      v9 = *(_DWORD *)(*(_QWORD *)vl + 8LL);
      v37 = *(_DWORD **)vl;
      v36 = *(_DWORD *)(*(_QWORD *)vl + 12LL);
      v33 = (v37[1] - *v37) / v9;
      v10 = (ogg_int32_t **)FMOD_vorbis_block_alloc(context, vb, 8 * v7);
      if ( v10 )
      {
        v11 = 0;
        do
        {
          v12 = (ogg_int32_t *)FMOD_vorbis_block_alloc(context, vb, 4 * v33);
          v10[v11] = v12;
          if ( !v12 )
            return 0;
          ++v11;
          memset(v12, 0, 4LL * v33);
        }
        while ( used > (int)v11 );
        if ( v33 <= 0 )
          goto LABEL_26;
        v13 = 0;
        v14 = 0;
        v34 = 4LL * (unsigned int)(v33 - 1) + 4;
        v15 = 100.0 / (float)v9;
LABEL_12:
        v16 = 0;
        v17 = v14 + *v37;
        v18 = 4 * v17;
        v19 = 4 * ((unsigned int)(v9 - 1) + 1LL + v17);
        while ( 1 )
        {
          if ( v9 <= 0 )
          {
            v22 = 0.0;
            v26 = 0.0 * v15;
            if ( v36 > 1 )
              goto LABEL_19;
          }
          else
          {
            v20 = in[v16];
            v21 = 0.0;
            v22 = 0.0;
            v23 = v18;
            do
            {
              v24 = (__m128)*(unsigned int *)((char *)v20 + v23);
              v22 = fmaxf(fabs(*(float *)((char *)v20 + v23)), v22);
              v25 = fabs(*(float *)((char *)v20 + v23));
              if ( v25 < 8388608.0 )
                v24.m128_i32[0] = _mm_andnot_ps((__m128)0x7FFFFFFFu, v24).m128_u32[0]
                                | COERCE_UNSIGNED_INT((float)(v25 + 8388608.0) - 8388608.0);
              v23 += 4;
              v21 = v21 + fabs(v24.m128_f32[0]);
            }
            while ( v23 != v19 );
            v26 = v21 * v15;
            if ( v36 > 1 )
            {
LABEL_19:
              v27 = (float *)(v37 + 325);
              v28 = 0;
              do
              {
                if ( *v27 >= v22 )
                {
                  v29 = v27[64];
                  if ( v29 < 0.0 || v29 > (float)(int)v26 )
                    break;
                }
                ++v28;
                ++v27;
              }
              while ( v28 != v36 - 1 );
              goto LABEL_24;
            }
          }
          v28 = 0;
LABEL_24:
          v30 = v10[v16++];
          v30[v13 / 4] = v28;
          if ( used <= (int)v16 )
          {
            v14 += v9;
            v13 += 4LL;
            if ( v13 == v34 )
            {
LABEL_26:
              ++*((_DWORD *)vl + 16);
              return v10;
            }
            goto LABEL_12;
          }
        }
      }
    }
  }
  return 0;
}


