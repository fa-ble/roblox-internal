// Address: 0x223ae00 | Name: _ZN4FMOD12ProfileStats7releaseEv
FMOD_RESULT_0 __fastcall FMOD::ProfileStats::release(FMOD::ProfileStats *const this)
{
  FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_profile_stats.cpp", 31);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223ae30 | Name: _ZN4FMOD12ProfileStats6createEPNS_7ProfileEPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::ProfileStats::create(FMOD::Profile *profile, FMOD::SystemI *system)
{
  _QWORD *v2; // rax

  v2 = FMOD::MemPool::alloc(off_286F358->gSystemMemPool, 48, "../../../core_api/src/fmod_profile_stats.cpp", 16, 0, 0);
  if ( !v2 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v2[3] = 0;
  v2[4] = profile;
  v2[5] = system;
  v2[2] = v2 + 1;
  v2[1] = v2 + 1;
  *v2 = &off_29B2950;
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::Profile *, _QWORD *))profile->_vptr_ProfileInterface + 1))(profile, v2);
}


// Address: 0x223aec0 | Name: _ZN4FMOD12ProfileStats21getCodecCountFromPoolENS_23FMOD_DSP_CODECPOOL_TYPEEPsS2_
FMOD_RESULT_0 __fastcall FMOD::ProfileStats::getCodecCountFromPool(
        FMOD::ProfileStats *const this,
        FMOD::FMOD_DSP_CODECPOOL_TYPE type,
        __int16 *used,
        __int16 *total)
{
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 result; // eax
  int localUsed; // [rsp+0h] [rbp-28h] BYREF
  int localTotal; // [rsp+4h] [rbp-24h] BYREF
  FMOD::DSPCodecPool *pool; // [rsp+8h] [rbp-20h] BYREF

  *used = 0;
  mSystem = this->mSystem;
  pool = 0;
  *total = 0;
  result = FMOD::SystemI::DSPCodecPoolGet(mSystem, type, &pool);
  if ( result == FMOD_RESULT::FMOD_ERR_DSP_NOTFOUND_0 )
    return FMOD_RESULT::FMOD_OK_0;
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    localUsed = 0;
    localTotal = 0;
    result = FMOD::DSPCodecPool::getNum(pool, &localUsed, &localTotal);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      *used = localUsed;
      *total = localTotal;
    }
  }
  return result;
}


// Address: 0x223af50 | Name: _ZN4FMOD12ProfileStats13getNextPacketEPNS_7Profile17PacketWriteHandleE
FMOD_RESULT_0 __fastcall FMOD::ProfileStats::getNextPacket(
        FMOD::ProfileStats *const this,
        FMOD::Profile::PacketWriteHandle *handle)
{
  int (**vptr_ProfileModule)(...); // rax
  FMOD::SystemI *mSystem; // rax
  FMOD::SystemI *v4; // rax
  FMOD::SystemI *v5; // rax
  int mWriteCount; // edx
  FMOD_RESULT_0 result; // eax
  FMOD::ProfileInterface *mProfile; // rdi
  int real; // [rsp+4h] [rbp-74h] BYREF
  int realMaximum; // [rsp+8h] [rbp-70h] BYREF
  int emulated; // [rsp+Ch] [rbp-6Ch] BYREF
  FMOD::ProfilePacketStatsTotals packet; // [rsp+10h] [rbp-68h] BYREF

  memset(&packet, 0, sizeof(packet));
  vptr_ProfileModule = this->_vptr_ProfileModule;
  packet.hdr.size = 72;
  packet.hdr.type = (*vptr_ProfileModule)(this);
  packet.hdr.version = 0;
  FMOD_Memory_GetStats(&packet.memoryCurrent, &packet.memoryMax, 0);
  FMOD::SystemI::getCPUUsage(
    this->mSystem,
    &packet.cpuDSP.f,
    &packet.cpuStream.f,
    &packet.cpuGeometry.f,
    &packet.cpuUpdate.f,
    0);
  mSystem = this->mSystem;
  real = 0;
  FMOD::ChannelPool::getChannelsUsed(mSystem->mSoftware->mChannelPool, &real);
  v4 = this->mSystem;
  realMaximum = 0;
  FMOD::ChannelPool::getNumChannels(v4->mSoftware->mChannelPool, &realMaximum);
  v5 = this->mSystem;
  emulated = 0;
  FMOD::ChannelPool::getChannelsUsed(v5->mEmulated->mChannelPool, &emulated);
  packet.channelsReal = real;
  packet.channelsRealMaximum = realMaximum;
  packet.channelsEmulated = emulated;
  packet.channelsMaximum = this->mSystem->mNumChannels;
  FMOD::ProfileStats::getCodecCountFromPool(
    this,
    FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_MPEG,
    &packet.codecsMPEG,
    &packet.codecsMPEGMax);
  FMOD::ProfileStats::getCodecCountFromPool(
    this,
    FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_ADPCM,
    &packet.codecsADPCM,
    &packet.codecsADPCMMax);
  FMOD::ProfileStats::getCodecCountFromPool(
    this,
    FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_FADPCM,
    &packet.codecsFADPCM,
    &packet.codecsFADPCMMax);
  FMOD::ProfileStats::getCodecCountFromPool(
    this,
    FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_XMA,
    &packet.codecsXMA,
    &packet.codecsXMAMax);
  FMOD::ProfileStats::getCodecCountFromPool(
    this,
    FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_VORBIS,
    &packet.codecsVorbis,
    &packet.codecsVorbisMax);
  FMOD::ProfileStats::getCodecCountFromPool(
    this,
    FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_AT9,
    &packet.codecsAT9,
    &packet.codecsAT9Max);
  FMOD::ProfileStats::getCodecCountFromPool(
    this,
    FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_PCM,
    &packet.codecsRaw,
    &packet.codecsRawMax);
  mWriteCount = handle->mWriteCount;
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( mWriteCount <= 0 )
  {
    mProfile = handle->mProfile;
    handle->mWriteCount = mWriteCount + 1;
    return (*mProfile->_vptr_ProfileInterface)(mProfile, &packet, 0);
  }
  return result;
}


