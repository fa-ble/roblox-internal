// Address: 0x2213850 | Name: _ZN4FMOD7SystemI9enterCritENS_16FMOD_SYSTEM_CRITE
FMOD_RESULT_0 __fastcall FMOD::SystemI::enterCrit(FMOD::SystemI *const this, FMOD::FMOD_SYSTEM_CRIT crit)
{
  FMOD_OS_CRITICALSECTION *v2; // rdi

  v2 = this->mCrit[crit];
  if ( v2 )
    return FMOD_OS_CriticalSection_Enter(v2);
  else
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
}


// Address: 0x2213870 | Name: _ZN4FMOD7SystemI9leaveCritENS_16FMOD_SYSTEM_CRITE
FMOD_RESULT_0 __fastcall FMOD::SystemI::leaveCrit(FMOD::SystemI *const this, FMOD::FMOD_SYSTEM_CRIT crit)
{
  FMOD_OS_CRITICALSECTION *v2; // rdi

  v2 = this->mCrit[crit];
  if ( v2 )
    return FMOD_OS_CriticalSection_Leave(v2);
  else
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
}


// Address: 0x2213890 | Name: _ZN4FMOD7SystemI17enterUserCallbackEb
FMOD_RESULT_0 __fastcall FMOD::SystemI::enterUserCallback(FMOD::SystemI *const this, bool protectBlocking)
{
  FMOD_OS_CRITICALSECTION *v3; // rdi
  FMOD_RESULT_0 result; // eax
  void *v5; // rdx

  v3 = this->mCrit[13];
  if ( !v3 )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD_OS_CriticalSection_Enter(v3);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( *(__int64 (__fastcall ***)(std::logic_error *))((char *)&off_11808 + (_QWORD)this) )
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    result = FMOD_OS_Thread_GetCurrentID((FMOD_UINT_NATIVE *)((char *)&off_11808 + (_QWORD)this));
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v5 = *(__int64 (__fastcall ***)(std::logic_error *))((char *)&off_11808 + (_QWORD)this);
      if ( v5 )
      {
        byte_11810[(_QWORD)this] = protectBlocking;
        return FMOD::SystemI::callInternalCallback(this, 0x100002u, v5, (void *)protectBlocking);
      }
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    }
  }
  return result;
}


// Address: 0x2213910 | Name: _ZN4FMOD7SystemI17leaveUserCallbackEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::leaveUserCallback(FMOD::SystemI *const this)
{
  void *v1; // rdx
  FMOD_RESULT_0 result; // eax

  if ( !this->mCrit[13] )
    return FMOD_RESULT::FMOD_OK_0;
  v1 = *(__int64 (__fastcall ***)(std::logic_error *))((char *)&off_11808 + (_QWORD)this);
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( v1 )
  {
    *(__int64 (__fastcall ***)(std::logic_error *))((char *)&off_11808 + (_QWORD)this) = 0;
    byte_11810[(_QWORD)this] = 0;
    result = FMOD::SystemI::callInternalCallback(this, 0x100004u, v1, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_OS_CriticalSection_Leave(this->mCrit[13]);
  }
  return result;
}


// Address: 0x2213980 | Name: _ZN4FMOD7SystemI16isInUserCallbackEPbS1_
FMOD_RESULT_0 __fastcall FMOD::SystemI::isInUserCallback(
        FMOD::SystemI *const this,
        bool *inUserCallback,
        bool *protectBlocking)
{
  FMOD_RESULT_0 result; // eax
  bool v5; // zf
  FMOD_UINT_NATIVE id[4]; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD_RESULT::FMOD_OK_0;
  v5 = *(__int64 (__fastcall ***)(std::logic_error *))((char *)&off_11808 + (_QWORD)this) == 0;
  *inUserCallback = 0;
  *protectBlocking = 0;
  if ( !v5 )
  {
    id[0] = 0;
    result = FMOD_OS_Thread_GetCurrentID(id);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( *(__int64 (__fastcall ***)(std::logic_error *))((char *)&off_11808 + (_QWORD)this) == (__int64 (__fastcall **)(std::logic_error *))id[0] )
      {
        *inUserCallback = 1;
        *protectBlocking = byte_11810[(_QWORD)this];
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2213a00 | Name: _ZN4FMOD7SystemI19enterMainUpdateLockEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::enterMainUpdateLock(FMOD::SystemI *const this)
{
  FMOD_RESULT_0 result; // eax
  bool inUserCallback; // [rsp+Eh] [rbp-1Ah] BYREF
  bool protectBlocking; // [rsp+Fh] [rbp-19h] BYREF

  result = FMOD_RESULT::FMOD_OK_0;
  if ( *(unsigned __int64 *)((char *)&stru_114D8.r_offset + (_QWORD)this) )
  {
    result = FMOD::SystemI::isInUserCallback(this, &inUserCallback, &protectBlocking);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD_RESULT::FMOD_ERR_INVALID_THREAD_0;
      if ( !protectBlocking )
      {
        result = FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_MAINUPDATE);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
          return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x2213a60 | Name: _ZN4FMOD7SystemI19leaveMainUpdateLockEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::leaveMainUpdateLock(FMOD::SystemI *const this)
{
  if ( *(unsigned __int64 *)((char *)&stru_114D8.r_offset + (_QWORD)this) )
    return FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_MAINUPDATE);
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2213a80 | Name: _ZN4FMOD7SystemI15lockDSPInternalEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::lockDSPInternal(FMOD::SystemI *const this)
{
  FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_DSPQUEUE);
  FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_DSPMIXER);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2213aa0 | Name: _ZN4FMOD7SystemI17unlockDSPInternalEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::unlockDSPInternal(FMOD::SystemI *const this)
{
  FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPMIXER);
  FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPQUEUE);
  return FMOD_RESULT::FMOD_OK_0;
}


