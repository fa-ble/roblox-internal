// Address: 0x22589c0 | Name: _ZN4FMOD9DSPChorus16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPChorus::getDescriptionEx()
{
  memset(&stru_2B06060, 0, sizeof(stru_2B06060));
  FMOD_strcpy_safe(stru_2B06060.name, "Mix", 16);
  FMOD_strcpy_safe(stru_2B06060.label, "%", 16);
  stru_2B06060.description = "Volume of original signal to pass to output.  0.0 to 100.0. Default = 100.";
  memset(&stru_2B06000, 0, sizeof(stru_2B06000));
  *(_QWORD *)&stru_2B06060.floatdesc.min = 0x42C8000000000000LL;
  stru_2B06060.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2B06060.intdesc.defaultval = 1120403456;
  FMOD_strcpy_safe(stru_2B06000.name, "Rate", 16);
  FMOD_strcpy_safe(stru_2B06000.label, "Hz", 16);
  *(_QWORD *)&stru_2B06000.floatdesc.min = 0x41A0000000000000LL;
  stru_2B06000.description = "Chorus modulation rate in Hz.  0.0 to 20.0.  Default = 0.8 Hz.";
  memset(&stru_2B05FA0, 0, sizeof(stru_2B05FA0));
  stru_2B06000.intdesc.defaultval = 1061997773;
  stru_2B06000.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2B05FA0.name, "Depth", 16);
  FMOD_strcpy_safe(stru_2B05FA0.label, "%", 16);
  *(_QWORD *)&stru_2B05FA0.floatdesc.min = 0x42C8000000000000LL;
  stru_2B05FA0.intdesc.defaultval = 1077936128;
  stru_2B05FA0.description = "Chorus modulation depth.  0.0 to 100.0.  Default = 3.0.";
  stru_2B05FA0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  *(&stru_2B05F60.mHandle + 1) = 14;
  stru_2B05F60.mDescription = &stru_2870440;
  stru_2B05F60.mSize = 33408;
  return &stru_2B05F60;
}


// Address: 0x2258b80 | Name: _ZN4FMOD9DSPChorus15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::releaseInternal(FMOD::DSPChorus *const this)
{
  void *v1; // rsi

  v1 = (void *)*((_QWORD *)this + 71);
  if ( v1 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_dsp_chorus.cpp", 196);
    *((_QWORD *)this + 70) = 0;
    *((_QWORD *)this + 71) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2258bd0 | Name: _ZN4FMOD9DSPChorus15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPChorus::releaseInternal((FMOD::DSPChorus *const)dsp_state->instance);
}


// Address: 0x2258be0 | Name: _ZN4FMOD9DSPChorus13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::resetInternal(FMOD::DSPChorus *const this)
{
  void *v2; // rdi
  float v3; // xmm0_4
  float v4; // xmm5_4
  float v5; // xmm2_4
  float v6; // xmm1_4
  float v7; // xmm5_4
  float v8; // xmm0_4
  float v9; // xmm6_4
  float v10; // xmm3_4
  float v11; // xmm0_4
  float v12; // xmm3_4
  float v14; // xmm0_4
  float v15; // xmm2_4
  float v16; // xmm0_4

  *((_DWORD *)this + 147) = 0;
  *((_DWORD *)this + 146) = 0;
  v2 = (void *)*((_QWORD *)this + 70);
  if ( v2 )
    memset(v2, 0, *((unsigned int *)this + 145));
  v3 = *((float *)this + 8349);
  *((float *)this + 133) = v3;
  v4 = v3 + v3;
  v5 = 200.0 / (float)(v3 + 200.0);
  v6 = 0.0;
  *((float *)this + 134) = v5;
  if ( (float)(v3 + v3) < 0.0 )
  {
    v7 = 0.0;
  }
  else if ( v4 > 100.0 )
  {
    v7 = 1.0;
  }
  else
  {
    v7 = v4 / 100.0;
  }
  v8 = v3 * 4.0;
  *((float *)this + 135) = v7 * v5;
  v9 = v8 - 200.0;
  if ( (float)(v8 - 200.0) < 0.0 )
  {
    v10 = 0.0;
  }
  else if ( v9 > 100.0 )
  {
    v10 = 1.0;
  }
  else
  {
    v10 = v9 / 100.0;
  }
  v11 = v8 - 300.0;
  *((float *)this + 136) = v10 * v5;
  if ( v11 >= 0.0 )
  {
    v6 = 1.0;
    if ( v11 <= 100.0 )
      v6 = v11 / 100.0;
  }
  v12 = *((float *)this + 8350);
  *((_DWORD *)this + 153) = 0;
  *((float *)this + 138) = v12;
  *((_DWORD *)this + 154) = 1048576000;
  *((_DWORD *)this + 155) = 1056964608;
  v14 = *((float *)this + 8348);
  *((float *)this + 132) = v14;
  *((float *)this + 137) = v5 * v6;
  v15 = (float)*((int *)this + 149);
  *((float *)this + 148) = v12 / v15;
  v16 = (float)((float)((float)((float)(v14 * v15) * v14) / 10000.0) / 1000.0) * 100.0;
  *((float *)this + 151) = v16;
  *((float *)this + 152) = v16;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2258db0 | Name: _ZN4FMOD9DSPChorus14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::createInternal(FMOD::DSPChorus *const this)
{
  double v1; // xmm1_8
  float v2; // xmm0_4
  float *v3; // rbp
  int i; // ebx
  __int64 v5; // rax
  __int64 v6; // rbp
  int v7; // ebx
  int v8; // edx
  FMOD_RESULT_0 result; // eax

  v2 = 1.0;
  v3 = (float *)((char *)this + 624);
  for ( i = 0; ; v2 = cosf((float)((float)i * 1.5707964) * 0.00012207031) )
  {
    ++i;
    *v3++ = v2;
    if ( i == 0x2000 )
      break;
  }
  if ( this != (FMOD::DSPChorus *const)-596LL )
    *((_DWORD *)this + 149) = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  v5 = *((_QWORD *)this + 30);
  v6 = 0;
  v7 = 0;
  *((_DWORD *)this + 150) = 0;
  *((_QWORD *)this + 70) = 0;
  *((_DWORD *)this + 144) = 0;
  *((_DWORD *)this + 145) = 0;
  v8 = *(_DWORD *)(v5 + 96);
  *((_DWORD *)this + 147) = 0;
  if ( v8 > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v7,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v5 + 104) + v6) + 56LL),
                 v1);
      if ( result )
        break;
      v5 = *((_QWORD *)this + 30);
      ++v7;
      v6 += 8;
      if ( *(_DWORD *)(v5 + 96) <= v7 )
        goto LABEL_11;
    }
  }
  else
  {
LABEL_11:
    FMOD::DSPChorus::resetInternal(this);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2258ec0 | Name: _ZN4FMOD9DSPChorus14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPChorus::createInternal((FMOD::DSPChorus *const)dsp_state->instance);
}


// Address: 0x2258ed0 | Name: _ZN4FMOD9DSPChorus13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPChorus::resetInternal((FMOD::DSPChorus *const)dsp_state->instance);
}


// Address: 0x2258ee0 | Name: _ZN4FMOD9DSPChorus16reallocateBufferEv
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::reallocateBuffer(FMOD::DSPChorus *const this)
{
  void *v2; // rsi
  unsigned int v3; // ecx
  unsigned int v4; // ecx
  int v5; // esi
  FMOD::MemPool *gSystemMemPool; // rdi
  void *v7; // rdx
  FMOD_RESULT_0 result; // eax
  unsigned int blocksize[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  v2 = (void *)*((_QWORD *)this + 71);
  if ( v2 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v2, "../../../core_api/src/fmod_dsp_chorus.cpp", 260);
    *((_QWORD *)this + 70) = 0;
    *((_QWORD *)this + 71) = 0;
  }
  FMOD::SystemI::getDSPBufferSize(*((FMOD::SystemI *const *)this + 22), blocksize, 0);
  v3 = 2;
  if ( (int)(float)((float)*((int *)this + 149) * 120.0) / 1000 / blocksize[0] + 1 > 1 )
    v3 = (int)(float)((float)*((int *)this + 149) * 120.0) / 1000 / blocksize[0] + 1;
  v4 = blocksize[0] * v3;
  v5 = v4 * 2 * *((_DWORD *)this + 150);
  gSystemMemPool = off_286F358->gSystemMemPool;
  *((_DWORD *)this + 144) = v4;
  *((_DWORD *)this + 145) = v5;
  v7 = FMOD::MemPool::calloc(gSystemMemPool, v5 + 16, "../../../core_api/src/fmod_dsp_chorus.cpp", 283, 0);
  *((_QWORD *)this + 71) = v7;
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v7 )
  {
    *((_QWORD *)this + 70) = ((unsigned __int64)v7 + 15) & 0xFFFFFFFFFFFFFFF0LL;
    FMOD::DSPChorus::resetInternal(this);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2258ff0 | Name: _ZN4FMOD9DSPChorus12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::readInternal(
        FMOD::DSPChorus *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float *v6; // r14
  FMOD_RESULT_0 result; // eax
  unsigned int v11; // r13d
  float v12; // xmm6_4
  float v13; // xmm8_4
  float v14; // xmm3_4
  float v15; // xmm0_4
  float v16; // xmm2_4
  float v17; // xmm7_4
  float v18; // xmm5_4
  float v19; // xmm1_4
  float v20; // xmm7_4
  float v21; // xmm0_4
  float v22; // xmm7_4
  float v23; // xmm4_4
  float v24; // xmm0_4
  float v25; // xmm5_4
  float v26; // xmm1_4
  int v27; // eax
  unsigned int v28; // edi
  unsigned int v29; // eax
  __int64 v30; // r8
  float *v31; // rdx
  unsigned int v32; // edi
  __int64 v33; // rcx
  float v34; // xmm0_4
  int v35; // r9d
  int v36; // r11d
  float v37; // xmm1_4
  float v38; // xmm1_4
  __int64 v39; // r8
  int v40; // esi
  int v41; // ecx
  float v42; // xmm7_4
  float v43; // xmm0_4
  unsigned int v44; // eax
  int v45; // edx
  float v46; // xmm0_4
  float v47; // xmm1_4
  __int64 v48; // rdx
  float *v49; // rdi
  int v50; // r15d
  signed int v51; // eax
  int v52; // edx
  float v53; // xmm0_4
  float v54; // xmm0_4
  unsigned int v56; // [rsp+Ch] [rbp-4Ch]
  unsigned int v57; // [rsp+10h] [rbp-48h]
  unsigned int v58; // [rsp+14h] [rbp-44h]

  v6 = inbuffer;
  if ( *((_DWORD *)this + 150) == inchannels
    || (*((_DWORD *)this + 150) = inchannels,
        (result = FMOD::DSPChorus::reallocateBuffer(this)) == FMOD_RESULT::FMOD_OK_0) )
  {
    v11 = *((_DWORD *)this + 144);
    LODWORD(v12) = COERCE_INT((float)(int)v11) - 1;
    if ( !inbuffer )
      return FMOD_RESULT::FMOD_OK_0;
    v13 = *((float *)this + 132);
    v14 = *((float *)this + 8348);
    v15 = *((float *)this + 8349);
    if ( v13 == v14 )
    {
      v16 = *((float *)this + 8350);
      if ( v15 == *((float *)this + 133) && v16 == *((float *)this + 138) )
      {
LABEL_18:
        if ( length )
        {
          while ( 1 )
          {
            v27 = *((_DWORD *)this + 146);
            v58 = 0;
            v57 = v27 + length;
            if ( v11 < v27 + length )
            {
              v28 = length;
              v57 = v11;
              length = v11 - v27;
              v58 = v28 - (v11 - v27);
            }
            v56 = inchannels * length;
            if ( inchannels * length )
            {
              v29 = inchannels * v27;
              v30 = *((_QWORD *)this + 70);
              v31 = v6;
              v32 = v29 + v56;
              do
              {
                v33 = v29++;
                v34 = *v31++ * 16384.0;
                *(_WORD *)(v30 + 2 * v33) = (int)v34;
              }
              while ( v29 != v32 );
            }
            if ( length )
            {
              v35 = 0;
              v36 = 0;
              do
              {
                v37 = *((float *)this + 152);
                if ( (float)(*((float *)this + 151) - 0.03125) <= v37 )
                {
                  if ( v37 <= (float)(*((float *)this + 151) + 0.03125) )
                    v38 = *((float *)this + 151);
                  else
                    v38 = v37 - 0.03125;
                }
                else
                {
                  v38 = v37 + 0.03125;
                }
                *((float *)this + 152) = v38;
                if ( inchannels > 0 )
                {
                  v39 = *((_QWORD *)this + 70);
                  v40 = 0;
                  v41 = 0;
                  v42 = (float)*((int *)this + 146);
                  while ( 1 )
                  {
                    v49 = (float *)((char *)this + 4 * v40);
                    v50 = v41 + v35;
                    v51 = abs32((int)(float)((float)(*((float *)this + 147) + v49[153]) * 32768.0)) & 0x7FFF;
                    v52 = v51 >> 13;
                    if ( v51 >> 13 == 2 )
                    {
                      v53 = -*((float *)this + v51 - 16228);
                    }
                    else if ( v52 == 3 )
                    {
                      v53 = *((float *)this + 0x7FFF - v51 + 156);
                    }
                    else
                    {
                      v53 = v52 == 1 ? -*((float *)this + 0x3FFF - v51 + 156) : *((float *)this + v51 + 156);
                    }
                    v43 = (float)((float)((float)((float)(v53 - 1.0) * 0.5) * v38) + v42) + (float)v36;
                    if ( v43 >= 0.0 )
                    {
                      if ( v43 > v12 )
                        v43 = v43 - v12;
                    }
                    else
                    {
                      v43 = v43 + v12;
                    }
                    ++v40;
                    v44 = (int)v43 + 1;
                    v45 = *(__int16 *)(v39 + 2LL * (v41 + inchannels * (int)v43));
                    v46 = v43 - (float)(int)v43;
                    v47 = (float)v45 * 0.000061035156;
                    v48 = (int)(v41 + inchannels * (v44 % v11));
                    if ( v40 >= 3 )
                      v40 = 0;
                    ++v41;
                    outbuffer[v50] = (float)((float)((float)(v47 * (float)(1.0 - v46))
                                                   + (float)((float)((float)*(__int16 *)(v39 + 2 * v48) * 0.000061035156)
                                                           * v46))
                                           * v49[135])
                                   + (float)(v6[v50] * *((float *)this + 134));
                    if ( v41 == inchannels )
                      break;
                    v38 = *((float *)this + 152);
                  }
                }
                v54 = *((float *)this + 147) + *((float *)this + 148);
                if ( v54 > 1.0 )
                  v54 = v54 - 1.0;
                ++v36;
                v35 += inchannels;
                *((float *)this + 147) = v54;
              }
              while ( v36 != length );
            }
            *((_DWORD *)this + 146) = v57;
            v6 += v56;
            outbuffer += *outchannels * length;
            if ( v11 <= v57 )
              *((_DWORD *)this + 146) = 0;
            if ( !v58 )
              break;
            length = v58;
          }
        }
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
    else
    {
      v16 = *((float *)this + 8350);
    }
    *((float *)this + 132) = v14;
    *((float *)this + 133) = v15;
    v17 = v15 + v15;
    v18 = 200.0 / (float)(v15 + 200.0);
    v19 = 0.0;
    *((float *)this + 134) = v18;
    if ( (float)(v15 + v15) < 0.0 )
    {
      v20 = 0.0;
    }
    else if ( v17 > 100.0 )
    {
      v20 = 1.0;
    }
    else
    {
      v20 = v17 / 100.0;
    }
    v21 = v15 * 4.0;
    *((float *)this + 135) = v20 * v18;
    v22 = v21 - 200.0;
    if ( (float)(v21 - 200.0) < 0.0 )
    {
      v23 = 0.0;
    }
    else if ( v22 > 100.0 )
    {
      v23 = 1.0;
    }
    else
    {
      v23 = v22 / 100.0;
    }
    v24 = v21 - 300.0;
    *((float *)this + 136) = v23 * v18;
    if ( v24 >= 0.0 )
    {
      v19 = 1.0;
      if ( v24 <= 100.0 )
        v19 = v24 / 100.0;
    }
    *((float *)this + 138) = v16;
    v25 = v18 * v19;
    v26 = (float)*((int *)this + 149);
    *((float *)this + 137) = v25;
    if ( v13 != v14 )
      *((float *)this + 151) = (float)((float)((float)((float)(v14 * v26) * v14) / 10000.0) / 1000.0) * 100.0;
    *((float *)this + 148) = v16 / v26;
    goto LABEL_18;
  }
  return result;
}


// Address: 0x22595a0 | Name: _ZN4FMOD9DSPChorus12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPChorus::readInternal(
           (FMOD::DSPChorus *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x22595b0 | Name: _ZN4FMOD9DSPChorus25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPChorus::setParameterFloatInternal(
        FMOD::DSPChorus *const this,
        int index,
        float a3,
        float value)
{
  if ( index == 1 )
  {
    *((float *)this + 8350) = a3;
    return 0;
  }
  else if ( index == 2 )
  {
    *((float *)this + 8348) = a3;
    return 0;
  }
  else
  {
    if ( !index )
      *((float *)this + 8349) = a3;
    return 0;
  }
}


// Address: 0x2259600 | Name: _ZN4FMOD9DSPChorus25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPChorus::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPChorus::setParameterFloatInternal((FMOD::DSPChorus *const)dsp_state->instance, index, a3, value);
}


// Address: 0x2259610 | Name: _ZN4FMOD9DSPChorus25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::getParameterFloatInternal(
        FMOD::DSPChorus *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v5; // xmm0_4

  if ( index == 1 )
  {
    *value = *((float *)this + 8350);
    if ( valuestr )
    {
      v5 = *((float *)this + 8350);
      goto LABEL_9;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( index == 2 )
  {
    *value = *((float *)this + 8348);
    if ( valuestr )
    {
      v5 = *((float *)this + 8348);
      goto LABEL_9;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( index )
    return FMOD_RESULT::FMOD_OK_0;
  *value = *((float *)this + 8349);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  v5 = *((float *)this + 8349);
LABEL_9:
  sprintf(valuestr, "%.02f", v5);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22596b0 | Name: _ZN4FMOD9DSPChorus25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPChorus::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPChorus::getParameterFloatInternal((FMOD::DSPChorus *const)dsp_state->instance, index, value, valuestr);
}


