// Address: 0x2236980 | Name: _ZN4FMOD12DSPCodecPool4initENS_23FMOD_DSP_CODECPOOL_TYPEEPNS_25FMOD_CODEC_DESCRIPTION_EXEii
FMOD_RESULT_0 __fastcall FMOD::DSPCodecPool::init(
        FMOD::DSPCodecPool *const this,
        FMOD::FMOD_DSP_CODECPOOL_TYPE pooltype,
        FMOD::FMOD_CODEC_DESCRIPTION_EX *codec_desc,
        int numdspcodecs,
        int maxchannels)
{
  FMOD_RESULT_0 v6; // r12d
  bool v7; // zf
  FMOD::SystemI *mSystem; // r14
  int mNumDSPCodecs; // eax
  char v12; // r13
  FMOD::DSPSource **mPool; // rbp
  FMOD::FMOD_DSP_DESCRIPTION_EX *Description; // rax
  void *mUserData; // r9
  FMOD_RESULT_0 DSPBufferSize; // eax
  unsigned int v18; // eax
  int mSize; // edx
  int v20; // ebp
  unsigned int v21; // esi
  unsigned int v22; // ecx
  FMOD::DSPSource **v23; // rax
  bool *v24; // rax
  __int64 v25; // r12
  int v26; // r14d
  FMOD::SystemI *v27; // rdi
  FMOD_RESULT_0 v28; // eax
  FMOD::Codec *v29; // rax
  FMOD_SOUND_TYPE_0 mType; // edx
  FMOD::FMOD_CODEC_DESCRIPTION_EX *p_mDescription; // rdi
  FMOD::FMOD_CODEC_DESCRIPTION_EX *v32; // rsi
  unsigned int v33; // edx
  __int64 v34; // rax
  __int64 v35; // rcx
  char *v36; // rdi
  const char **v37; // rsi
  FMOD::Codec *mCodec; // rax
  FMOD::SystemI *v39; // rdx
  FMOD::DSPSource *v40; // rdi
  int (**vptr_DSPI)(...); // rax
  FMOD::DSPSource *v42; // rax
  bool *mAllocated; // rdx
  void *v44; // rax
  unsigned __int64 v45; // r13
  int v46; // eax
  __int16 name; // ax
  __int64 v48; // r13
  FMOD::DSPSource *v49; // rdi
  char v52; // [rsp+Fh] [rbp-F9h]
  FMOD::MemPool *p_mContextMemoryPool; // [rsp+10h] [rbp-F8h]
  int dspcodec; // [rsp+38h] [rbp-D0h]
  FMOD::DSPCodec *dspcodeca; // [rsp+38h] [rbp-D0h]
  FMOD::FMOD_CODEC_DESCRIPTION_EX *v56; // [rsp+40h] [rbp-C8h]
  FMOD::SystemI *v57; // [rsp+48h] [rbp-C0h]
  unsigned int dspcodecsize; // [rsp+58h] [rbp-B0h]
  unsigned int pcmframesize; // [rsp+6Ch] [rbp-9Ch] BYREF
  unsigned int codeccontextsize; // [rsp+70h] [rbp-98h] BYREF
  FMOD_MEMORY_TYPE memtype; // [rsp+74h] [rbp-94h] BYREF
  FMOD::DSPSource *dspsource; // [rsp+78h] [rbp-90h] BYREF
  FMOD::DSPResampler_Param resampler_param; // [rsp+80h] [rbp-88h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_EX dsp_desc; // [rsp+90h] [rbp-78h] BYREF

  v6 = FMOD_RESULT::FMOD_ERR_PLUGIN_0;
  v7 = codec_desc->getcontextinfo == 0;
  pcmframesize = 0;
  codeccontextsize = 0;
  memtype = 0;
  if ( v7 )
    return v6;
  mSystem = this->mSystem;
  if ( this->mSystem )
  {
    FMOD::SystemI::enterCrit(this->mSystem, FMOD_SYSTEM_CRIT_DSPCODECPOOLINIT);
    v52 = 1;
  }
  else
  {
    v52 = 0;
  }
  mNumDSPCodecs = this->mNumDSPCodecs;
  if ( mNumDSPCodecs > 0 )
  {
    v7 = mNumDSPCodecs == numdspcodecs;
    v12 = 1;
    numdspcodecs = 0;
    mPool = 0;
    if ( !v7 )
    {
      v6 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      goto LABEL_7;
    }
    goto LABEL_56;
  }
  this->mUserData = 0;
  this->mNumAllocated = 0;
  if ( pooltype )
    Description = FMOD::DSPCodec::getDescriptionEx();
  else
    Description = FMOD::DSPWaveTable::getDescriptionEx();
  mUserData = this->mUserData;
  dsp_desc = *Description;
  DSPBufferSize = codec_desc->getcontextinfo(0, maxchannels, &codeccontextsize, &pcmframesize, &memtype, mUserData);
  if ( DSPBufferSize )
    goto LABEL_53;
  v18 = pcmframesize;
  if ( pcmframesize <= 1 )
  {
    DSPBufferSize = FMOD::SystemI::getDSPBufferSize(this->mSystem, &pcmframesize, 0);
    if ( DSPBufferSize == FMOD_RESULT::FMOD_OK_0 )
    {
      v18 = pcmframesize;
      goto LABEL_19;
    }
LABEL_53:
    v6 = DSPBufferSize;
    v12 = 1;
    numdspcodecs = 0;
    mPool = 0;
    goto LABEL_7;
  }
  if ( pcmframesize == -1 )
  {
    pcmframesize = 0;
    v18 = 0;
  }
LABEL_19:
  mSize = codec_desc->mSize;
  v20 = 8 * numdspcodecs;
  if ( mSize )
  {
    dspcodec = mSize + 16;
    v21 = (mSize + 31) & 0xFFFFFFF0;
  }
  else
  {
    v21 = 0;
    dspcodec = 0;
  }
  if ( dsp_desc.mSize )
  {
    dspcodecsize = dsp_desc.mSize + 16;
    v22 = (dsp_desc.mSize + 31) & 0xFFFFFFF0;
  }
  else
  {
    v22 = 0;
    dspcodecsize = 0;
  }
  if ( v18 )
    v18 = (((v18 + 8) * 2 * maxchannels + 15) & 0xFFFFFFF0) + 16;
  p_mContextMemoryPool = &this->mContextMemoryPool;
  DSPBufferSize = FMOD::MemPool::init(
                    &this->mContextMemoryPool,
                    0,
                    numdspcodecs * (v22 + v21 + ((codeccontextsize + 15) & 0xFFFFFFF0) + 64 + v18)
                  + ((numdspcodecs + 15) & 0xFFFFFFF0)
                  + ((v20 + 15) & 0xFFFFFFF0)
                  + 1104,
                    1,
                    memtype);
  if ( DSPBufferSize )
    goto LABEL_53;
  v23 = (FMOD::DSPSource **)FMOD::MemPool::calloc(p_mContextMemoryPool, v20, (const char *)&uri_string, 0, 0);
  this->mPool = v23;
  if ( v23 )
  {
    v24 = (bool *)FMOD::MemPool::calloc(p_mContextMemoryPool, numdspcodecs, (const char *)&uri_string, 0, 0);
    this->mAllocated = v24;
    if ( v24 )
    {
      mPool = this->mPool;
      if ( numdspcodecs > 0 )
      {
        v57 = mSystem;
        v25 = 0;
        v26 = dspcodec;
        v56 = codec_desc;
        while ( 1 )
        {
          resampler_param.format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
          resampler_param.allocbuffer = 0;
          dsp_desc.mParameter = &resampler_param;
          resampler_param.blocklen = pcmframesize;
          resampler_param.channels = maxchannels;
          v44 = FMOD::MemPool::calloc(p_mContextMemoryPool, dspcodecsize, (const char *)&uri_string, 0, 0);
          if ( !v44 )
          {
LABEL_63:
            mSystem = v57;
            v6 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
            goto LABEL_64;
          }
          v45 = ((unsigned __int64)v44 + 15) & 0xFFFFFFFFFFFFFFF0LL;
          if ( pooltype )
          {
            if ( v45 )
            {
              FMOD::DSPResampler::DSPResampler((FMOD::DSPResampler *const)(((unsigned __int64)v44 + 15)
                                                                         & 0xFFFFFFFFFFFFFFF0LL));
              *(_QWORD *)v45 = off_29B2E70;
              FMOD::File::File((FMOD::File *const)(v45 + 792));
              *(_DWORD *)(v45 + 848) = 1;
              *(_QWORD *)(v45 + 792) = off_29B1850;
            }
          }
          else if ( v45 )
          {
            FMOD::DSPI::DSPI((FMOD::DSPI *const)(((unsigned __int64)v44 + 15) & 0xFFFFFFFFFFFFFFF0LL));
            *(_QWORD *)v45 = off_29B2C30;
          }
          v27 = this->mSystem;
          dspsource = (FMOD::DSPSource *)v45;
          v28 = FMOD::SystemI::createDSP(v27, &dsp_desc, 0, &dspsource, 0);
          if ( v28 )
            break;
          if ( v26 )
          {
            dspcodeca = (FMOD::DSPCodec *)dspsource;
            v29 = (FMOD::Codec *)FMOD::MemPool::calloc(p_mContextMemoryPool, v26, (const char *)&uri_string, 0, 0);
            dspcodeca->mCodec = v29;
            if ( !v29 )
              goto LABEL_63;
            mType = v29->mDescription.mType;
            p_mDescription = &v29->mDescription;
            v29->mDecoder = 0;
            v29->mDecoderContext = 0;
            v29->mDecoderContextMemory = 0;
            v29->mPCMBufferMemory = 0;
            v29->mWaveFormatMemory = 0;
            v29->mType = mType;
            v29->mMetadata = 0;
            v29->numsubsounds = 0;
            v29->waveformat = 0;
            v29->waveformatversion = 3;
            v29->fileread = (FMOD_FILE_READ_CALLBACK)FMOD::Codec::defaultFileRead;
            v32 = v56;
            v29->fileseek = (FMOD_FILE_SEEK_CALLBACK)FMOD::Codec::defaultFileSeek;
            v29->metadata = FMOD::Codec::defaultMetaData;
            dspcodeca->mResampleBuffer = 0;
            v33 = 216;
            dspcodeca->mContextMemory = 0;
            if ( (((_BYTE)v29 + 88) & 1) != 0 )
            {
              p_mDescription = (FMOD::FMOD_CODEC_DESCRIPTION_EX *)((char *)&v29->mDescription.name + 1);
              v32 = (FMOD::FMOD_CODEC_DESCRIPTION_EX *)((char *)&v56->name + 1);
              LOBYTE(v29->mDescription.name) = v56->name;
              v33 = 215;
            }
            if ( ((unsigned __int8)p_mDescription & 2) != 0 )
            {
              name = (__int16)v32->name;
              p_mDescription = (FMOD::FMOD_CODEC_DESCRIPTION_EX *)((char *)p_mDescription + 2);
              v32 = (FMOD::FMOD_CODEC_DESCRIPTION_EX *)((char *)v32 + 2);
              v33 -= 2;
              HIWORD(p_mDescription[-1].cleanupcontext) = name;
            }
            if ( ((unsigned __int8)p_mDescription & 4) != 0 )
            {
              v46 = (int)v32->name;
              p_mDescription = (FMOD::FMOD_CODEC_DESCRIPTION_EX *)((char *)p_mDescription + 4);
              v32 = (FMOD::FMOD_CODEC_DESCRIPTION_EX *)((char *)v32 + 4);
              v33 -= 4;
              HIDWORD(p_mDescription[-1].cleanupcontext) = v46;
            }
            v34 = 0;
            v35 = v33 >> 3;
            qmemcpy(p_mDescription, v32, 8 * v35);
            v37 = &v32->name + v35;
            v36 = (char *)(&p_mDescription->name + v35);
            if ( (v33 & 4) != 0 )
            {
              *(_DWORD *)v36 = *(_DWORD *)v37;
              v34 = 4;
            }
            if ( (v33 & 2) != 0 )
            {
              *(_WORD *)&v36[v34] = *(_WORD *)((char *)v37 + v34);
              v34 += 2;
            }
            if ( (v33 & 1) != 0 )
              v36[v34] = *((_BYTE *)v37 + v34);
            mCodec = dspcodeca->mCodec;
            mCodec->mDescription.getwaveformat = FMOD::Codec::defaultGetWaveFormat;
            mCodec->mDescription.mPoolType = pooltype;
            mCodec->mFile = &dspcodeca->mMemoryFile;
            mCodec->waveformat = &dspcodeca->mWaveFormat;
            v39 = this->mSystem;
            mCodec->filehandle = &dspcodeca->mMemoryFile;
            mCodec->mSrcDataOffset = 0;
            mCodec->mSystem = v39;
          }
          v40 = dspsource;
          vptr_DSPI = dspsource->_vptr_DSPI;
          dspsource->mPool = this;
          v40->mPoolIndex = v25;
          v40->mPoolType = pooltype;
          vptr_DSPI[5](v40, 1, 1, 0);
          v42 = dspsource;
          mAllocated = this->mAllocated;
          dspsource->mJob.mFlags |= 0x800u;
          mAllocated[v25] = 0;
          this->mPool[v25++] = v42;
          if ( v25 == (unsigned int)(numdspcodecs - 1) + 1LL )
          {
            mSystem = v57;
            goto LABEL_55;
          }
        }
        mSystem = v57;
        v6 = v28;
LABEL_64:
        v12 = 1;
        goto LABEL_7;
      }
LABEL_55:
      this->mNumDSPCodecs = numdspcodecs;
      v12 = 0;
      this->mType = pooltype;
LABEL_56:
      v6 = FMOD_RESULT::FMOD_OK_0;
      goto LABEL_7;
    }
  }
  v12 = 1;
  numdspcodecs = 0;
  mPool = 0;
  v6 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
LABEL_7:
  if ( v52 && mSystem )
    FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPCODECPOOLINIT);
  if ( v12 && mPool && numdspcodecs > 0 )
  {
    v48 = 0;
    do
    {
      v49 = mPool[v48];
      if ( v49 )
        (*((void (__fastcall **)(FMOD::DSPSource *))v49->_vptr_DSPI + 2))(v49);
      ++v48;
    }
    while ( numdspcodecs > (int)v48 );
  }
  return v6;
}


// Address: 0x22370b0 | Name: _ZN4FMOD12DSPCodecPool5closeEv
FMOD_RESULT_0 __fastcall FMOD::DSPCodecPool::close(FMOD::DSPCodecPool *const this)
{
  FMOD::DSPSource **mPool; // rax
  __int64 v3; // rbx
  int v4; // r12d
  FMOD::DSPSource *v5; // rdi
  FMOD_RESULT_0 result; // eax
  unsigned __int8 *mReadBuffer; // rsi

  mPool = this->mPool;
  if ( mPool )
  {
    v3 = 0;
    v4 = 0;
    if ( this->mNumDSPCodecs > 0 )
    {
      while ( 1 )
      {
        v5 = mPool[v3];
        if ( v5 )
        {
          (*((void (__fastcall **)(FMOD::DSPSource *))v5->_vptr_DSPI + 3))(v5);
          (*((void (__fastcall **)(FMOD::DSPSource *))this->mPool[v3]->_vptr_DSPI + 2))(this->mPool[v3]);
        }
        ++v4;
        ++v3;
        if ( this->mNumDSPCodecs <= v4 )
          break;
        mPool = this->mPool;
      }
    }
    this->mPool = 0;
    this->mNumDSPCodecs = 0;
  }
  result = FMOD::MemPool::close(&this->mContextMemoryPool);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mReadBuffer = this->mReadBuffer;
    if ( mReadBuffer )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, mReadBuffer, "../../../core_api/src/fmod_dsp_codecpool.cpp", 328);
      this->mReadBuffer = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2237170 | Name: _ZN4FMOD12DSPCodecPool5allocEPPNS_9DSPSourceE
FMOD_RESULT_0 __fastcall FMOD::DSPCodecPool::alloc(FMOD::DSPCodecPool *const this, FMOD::DSPSource **dspsource)
{
  __int64 v2; // rbx
  FMOD::DSPSource **mPool; // rax
  FMOD::DSPSource **v4; // rax
  FMOD::DSPSource **v5; // rax
  bool finished; // [rsp+Eh] [rbp-3Ah] BYREF
  bool asyncFinished[57]; // [rsp+Fh] [rbp-39h] BYREF

  v2 = 0;
  if ( this->mNumDSPCodecs <= 0 )
    return FMOD_RESULT::FMOD_ERR_CHANNEL_ALLOC_0;
  while ( 1 )
  {
    if ( !this->mAllocated[v2] )
    {
      mPool = this->mPool;
      finished = 0;
      (*((void (__fastcall **)(FMOD::DSPSource *, bool *))mPool[v2]->_vptr_DSPI + 6))(mPool[v2], &finished);
      if ( finished )
      {
        v4 = this->mPool;
        asyncFinished[0] = 0;
        (*((void (__fastcall **)(FMOD::DSPSource *, bool *))v4[v2]->_vptr_DSPI + 8))(v4[v2], asyncFinished);
        if ( asyncFinished[0] )
          break;
      }
    }
    if ( this->mNumDSPCodecs <= (int)++v2 )
      return FMOD_RESULT::FMOD_ERR_CHANNEL_ALLOC_0;
  }
  this->mAllocated[v2] = 1;
  v5 = this->mPool;
  ++this->mNumAllocated;
  *dspsource = v5[v2];
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2237230 | Name: _ZN4FMOD12DSPCodecPool10areAnyFreeEv
FMOD_RESULT_0 __fastcall FMOD::DSPCodecPool::areAnyFree(FMOD::DSPCodecPool *const this)
{
  __int64 v1; // rbx
  FMOD::DSPSource **mPool; // rax
  FMOD::DSPSource **v3; // rax
  bool finished; // [rsp+Eh] [rbp-2Ah] BYREF
  bool asyncFinished[41]; // [rsp+Fh] [rbp-29h] BYREF

  v1 = 0;
  if ( this->mNumDSPCodecs <= 0 )
    return FMOD_RESULT::FMOD_ERR_CHANNEL_ALLOC_0;
  while ( 1 )
  {
    if ( !this->mAllocated[v1] )
    {
      mPool = this->mPool;
      finished = 0;
      (*((void (__fastcall **)(FMOD::DSPSource *, bool *))mPool[v1]->_vptr_DSPI + 6))(mPool[v1], &finished);
      if ( finished )
      {
        v3 = this->mPool;
        asyncFinished[0] = 0;
        (*((void (__fastcall **)(FMOD::DSPSource *, bool *))v3[v1]->_vptr_DSPI + 8))(v3[v1], asyncFinished);
        if ( asyncFinished[0] )
          break;
      }
    }
    if ( this->mNumDSPCodecs <= (int)++v1 )
      return FMOD_RESULT::FMOD_ERR_CHANNEL_ALLOC_0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22372c0 | Name: _ZN4FMOD12DSPCodecPool7numFreeEPi
FMOD_RESULT_0 __fastcall FMOD::DSPCodecPool::numFree(FMOD::DSPCodecPool *const this, int *numFree)
{
  __int64 v2; // rbx
  FMOD::DSPSource **mPool; // rax
  FMOD::DSPSource **v4; // rax
  bool finished; // [rsp+Eh] [rbp-2Ah] BYREF
  bool asyncFinished[41]; // [rsp+Fh] [rbp-29h] BYREF

  v2 = 0;
  for ( *numFree = 0; (int)v2 < this->mNumDSPCodecs; ++v2 )
  {
    while ( 1 )
    {
      if ( !this->mAllocated[v2] )
      {
        mPool = this->mPool;
        finished = 0;
        (*((void (__fastcall **)(FMOD::DSPSource *, bool *))mPool[v2]->_vptr_DSPI + 6))(mPool[v2], &finished);
        if ( finished )
        {
          v4 = this->mPool;
          asyncFinished[0] = 0;
          (*((void (__fastcall **)(FMOD::DSPSource *, bool *))v4[v2]->_vptr_DSPI + 8))(v4[v2], asyncFinished);
          if ( asyncFinished[0] )
            break;
        }
      }
      if ( (int)++v2 >= this->mNumDSPCodecs )
        return FMOD_RESULT::FMOD_OK_0;
    }
    ++*numFree;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2237370 | Name: _ZN4FMOD12DSPCodecPool6getNumEPiS1_
FMOD_RESULT_0 __fastcall FMOD::DSPCodecPool::getNum(FMOD::DSPCodecPool *const this, int *used, int *total)
{
  if ( used )
    *used = this->mNumAllocated;
  if ( total )
    *total = this->mNumDSPCodecs;
  return FMOD_RESULT::FMOD_OK_0;
}


