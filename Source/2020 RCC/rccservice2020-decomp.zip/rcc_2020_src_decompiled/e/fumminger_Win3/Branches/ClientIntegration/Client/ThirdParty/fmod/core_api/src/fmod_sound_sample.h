// Address: 0x21f7080 | Name: _ZN4FMOD6Sample12lockInternalEjjPPvS2_PjS3_
FMOD_RESULT_0 __fastcall FMOD::Sample::lockInternal(
        FMOD::Sample *const this,
        unsigned int a2,
        unsigned int a3,
        void **a4,
        void **a5,
        unsigned int *a6,
        unsigned int *a7)
{
  return FMOD_RESULT::FMOD_ERR_SUBSOUNDS_0;
}


// Address: 0x21f7090 | Name: _ZN4FMOD6Sample14unlockInternalEPvS1_jj
FMOD_RESULT_0 __fastcall FMOD::Sample::unlockInternal(
        FMOD::Sample *const this,
        void *a2,
        void *a3,
        unsigned int a4,
        unsigned int a5)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f70a0 | Name: _ZN4FMOD6Sample13setBufferDataEPv
FMOD_RESULT_0 __fastcall FMOD::Sample::setBufferData(FMOD::Sample *const this, void *a2)
{
  return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
}


