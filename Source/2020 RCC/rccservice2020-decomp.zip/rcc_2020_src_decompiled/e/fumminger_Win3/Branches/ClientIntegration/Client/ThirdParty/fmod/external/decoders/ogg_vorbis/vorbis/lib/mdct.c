// Address: 0x226c730 | Name: mdct_butterflies
void __fastcall mdct_butterflies(mdct_lookup *init, mdct_lookup *a2, float *x, int points)
{
  float *v4; // r8
  mdct_lookup *v5; // rcx
  float *v6; // rax
  float v7; // xmm4_4
  float v8; // xmm3_4
  float v9; // xmm2_4
  float v10; // xmm1_4
  float v11; // xmm0_4
  float v12; // xmm1_4
  float v13; // xmm3_4
  float v14; // xmm1_4
  float v15; // xmm2_4
  float v16; // xmm0_4
  float v17; // xmm3_4
  float v18; // xmm1_4
  float v19; // xmm2_4
  float v20; // xmm0_4
  float v21; // xmm3_4
  float v22; // xmm1_4
  float v23; // xmm2_4
  float v24; // xmm0_4
  int v25; // ecx
  float *v26; // r11
  int v27; // ebp
  __int64 v28; // r12
  __int64 v29; // rax
  __int64 v30; // r9
  __int64 v31; // r10
  __int64 v32; // rbx
  float *v33; // r8
  float *v34; // rax
  float *p_n; // rdi
  float v36; // xmm4_4
  float v37; // xmm3_4
  float v38; // xmm2_4
  float v39; // xmm1_4
  float v40; // xmm0_4
  float v41; // xmm3_4
  float v42; // xmm1_4
  float v43; // xmm2_4
  float v44; // xmm0_4
  float v45; // xmm3_4
  float v46; // xmm1_4
  float v47; // xmm2_4
  float v48; // xmm0_4
  float v49; // xmm3_4
  float v50; // xmm1_4
  float v51; // xmm2_4
  float v52; // xmm0_4
  float v53; // xmm0_4
  float v54; // xmm2_4
  float *v55; // r15
  float *v56; // r14
  float *v57; // r13
  float *v58; // r12
  float *v59; // rbp
  float *v60; // rbx
  float *v61; // r11
  float *v62; // r10
  float *v63; // r9
  float *v64; // r8
  float *v65; // rdi
  float *v66; // rsi
  unsigned __int64 v67; // rax
  float *v68; // rcx
  float *v69; // rdx
  float *v70; // rcx
  float v71; // xmm1_4
  float v72; // xmm11_4
  float v73; // xmm3_4
  float v74; // xmm1_4
  float *v75; // r11
  float v76; // xmm0_4
  float v77; // xmm12_4
  float v78; // xmm11_4
  float v79; // xmm0_4
  float v80; // xmm13_4
  float v81; // xmm12_4
  float v82; // xmm14_4
  float v83; // xmm11_4
  float v84; // xmm13_4
  float v85; // xmm0_4
  float v86; // xmm2_4
  float v87; // xmm0_4
  float v88; // xmm15_4
  float v89; // xmm4_4
  float v90; // xmm5_4
  float v91; // xmm4_4
  float v92; // xmm8_4
  float v93; // xmm6_4
  float v94; // xmm15_4
  float v95; // xmm10_4
  float v96; // xmm5_4
  float v97; // xmm7_4
  float v98; // xmm8_4
  float v99; // xmm6_4
  float v100; // xmm9_4
  float v101; // xmm14_4
  float v102; // xmm13_4
  float v103; // xmm5_4
  float v104; // xmm9_4
  float v105; // xmm7_4
  float v106; // xmm12_4
  float v107; // xmm2_4
  float v108; // xmm14_4
  float v109; // xmm3_4
  float v110; // xmm12_4
  float v111; // xmm0_4
  float v112; // xmm3_4
  float v113; // xmm12_4
  float v114; // xmm11_4
  float v115; // xmm8_4
  float v116; // xmm14_4
  float v117; // xmm3_4
  float v118; // xmm7_4
  float v119; // xmm11_4
  float v120; // xmm6_4
  float v121; // xmm9_4
  float v122; // xmm1_4
  float v123; // xmm7_4
  float v124; // xmm3_4
  float v125; // xmm2_4
  float v126; // xmm1_4
  float v127; // xmm13_4
  float v128; // xmm3_4
  float v129; // xmm1_4
  float v130; // xmm0_4
  float v131; // xmm4_4
  float v132; // xmm2_4
  float v133; // xmm7_4
  float v134; // xmm1_4
  float v135; // xmm3_4
  float v136; // xmm13_4
  float v137; // xmm14_4
  float v138; // xmm3_4
  float v139; // xmm2_4
  float v140; // xmm15_4
  float v141; // xmm14_4
  float v142; // xmm0_4
  float v143; // xmm14_4
  float v144; // xmm2_4
  float v145; // xmm11_4
  float v146; // xmm1_4
  float v147; // xmm11_4
  float v148; // xmm0_4
  float v149; // xmm8_4
  float v150; // xmm10_4
  float v151; // xmm2_4
  float v152; // xmm1_4
  float v153; // xmm2_4
  float v154; // xmm4_4
  float v155; // xmm0_4
  float v156; // xmm1_4
  float v157; // xmm6_4
  float *pointsb; // [rsp+0h] [rbp-1A0h]
  int v160; // [rsp+8h] [rbp-198h]
  float *v161; // [rsp+8h] [rbp-198h]
  float *v162; // [rsp+10h] [rbp-190h]
  float *v163; // [rsp+18h] [rbp-188h]
  float v164; // [rsp+20h] [rbp-180h]
  float v165; // [rsp+20h] [rbp-180h]
  float *v166; // [rsp+28h] [rbp-178h]
  float v167; // [rsp+28h] [rbp-178h]
  float *v168; // [rsp+30h] [rbp-170h]
  float *v169; // [rsp+38h] [rbp-168h]
  float *v170; // [rsp+40h] [rbp-160h]
  float *v171; // [rsp+48h] [rbp-158h]
  float *v172; // [rsp+50h] [rbp-150h]
  float *v173; // [rsp+58h] [rbp-148h]
  float *v174; // [rsp+60h] [rbp-140h]
  float *v175; // [rsp+68h] [rbp-138h]
  float *v176; // [rsp+70h] [rbp-130h]
  float *v177; // [rsp+78h] [rbp-128h]
  float *v178; // [rsp+80h] [rbp-120h]
  float *v179; // [rsp+88h] [rbp-118h]
  float *v180; // [rsp+90h] [rbp-110h]
  float v181; // [rsp+9Ch] [rbp-104h]
  float v182; // [rsp+A0h] [rbp-100h]
  float v183; // [rsp+A4h] [rbp-FCh]
  float v184; // [rsp+A8h] [rbp-F8h]
  float v185; // [rsp+ACh] [rbp-F4h]
  float v186; // [rsp+B0h] [rbp-F0h]
  float v187; // [rsp+B4h] [rbp-ECh]
  float v188; // [rsp+B8h] [rbp-E8h]
  float v189; // [rsp+BCh] [rbp-E4h]
  float v190; // [rsp+C0h] [rbp-E0h]
  float v191; // [rsp+C4h] [rbp-DCh]
  float v192; // [rsp+C8h] [rbp-D8h]
  float v193; // [rsp+CCh] [rbp-D4h]
  float v194; // [rsp+D0h] [rbp-D0h]
  float v195; // [rsp+D4h] [rbp-CCh]
  float v196; // [rsp+D8h] [rbp-C8h]
  float v197; // [rsp+DCh] [rbp-C4h]
  float v198; // [rsp+E0h] [rbp-C0h]
  float v199; // [rsp+E4h] [rbp-BCh]
  float *v200; // [rsp+F8h] [rbp-A8h]
  float *v201; // [rsp+128h] [rbp-78h]
  __int64 v202; // [rsp+160h] [rbp-40h]

  if ( (int)init > 6 )
  {
    v4 = &x[points - 8];
    v5 = a2;
    v6 = &x[(points >> 1) - 8];
    do
    {
      v7 = v4[6];
      v6 -= 8;
      v4 -= 8;
      v5 += 2;
      v8 = v6[14];
      v9 = v7 - v8;
      v10 = v4[15];
      v11 = v10 - v6[15];
      v4[14] = v8 + v7;
      v4[15] = v10 + v6[15];
      v12 = (float)(*(float *)&v5[-2].log2n * v11) + (float)(*(float *)&v5[-2].n * (float)(v7 - v8));
      v13 = v6[12];
      v6[14] = v12;
      v6[15] = (float)(v11 * *(float *)&v5[-2].n) - (float)(v9 * *(float *)&v5[-2].log2n);
      v14 = v4[13];
      v15 = v4[12] - v13;
      v16 = v14 - v6[13];
      v4[12] = v13 + v4[12];
      v4[13] = v14 + v6[13];
      v17 = v6[10];
      v6[12] = (float)(*((float *)&v5[-2].bitrev + 1) * v16) + (float)(*(float *)&v5[-2].bitrev * v15);
      v6[13] = (float)(v16 * *(float *)&v5[-2].bitrev) - (float)(v15 * *((float *)&v5[-2].bitrev + 1));
      v18 = v4[11];
      v19 = v4[10] - v17;
      v20 = v18 - v6[11];
      v4[10] = v17 + v4[10];
      v4[11] = v18 + v6[11];
      v6[10] = (float)(*(float *)&v5[-1].log2n * v20) + (float)(*(float *)&v5[-1].n * v19);
      v21 = v6[8];
      v6[11] = (float)(v20 * *(float *)&v5[-1].n) - (float)(v19 * *(float *)&v5[-1].log2n);
      v22 = v4[9];
      v23 = v4[8] - v21;
      v24 = v22 - v6[9];
      v4[8] = v21 + v4[8];
      v4[9] = v22 + v6[9];
      v6[8] = (float)(*((float *)&v5[-1].bitrev + 1) * v24) + (float)(*(float *)&v5[-1].bitrev * v23);
      v6[9] = (float)(v24 * *(float *)&v5[-1].bitrev) - (float)(v23 * *((float *)&v5[-1].bitrev + 1));
    }
    while ( x <= v6 );
  }
  v25 = 1;
  v160 = (_DWORD)init - 6;
  if ( (int)init > 7 )
  {
    do
    {
      if ( 1 << v25 > 0 )
      {
        v26 = x;
        v27 = 0;
        v28 = points >> v25;
        v29 = 4 << v25;
        v30 = 2 * v29;
        v31 = 3 * v29;
        v32 = 16 * v29;
        do
        {
          v33 = &v26[v28 - 8];
          v34 = &v26[(points >> v25 >> 1) - 8];
          p_n = (float *)&a2->n;
          do
          {
            v36 = v33[6];
            v34 -= 8;
            v33 -= 8;
            v37 = v34[14];
            v38 = v36 - v37;
            v39 = v33[15];
            v40 = v39 - v34[15];
            v33[14] = v37 + v36;
            v33[15] = v39 + v34[15];
            v41 = v34[12];
            v34[14] = (float)(p_n[1] * v40) + (float)(*p_n * v38);
            v34[15] = (float)(v40 * *p_n) - (float)(v38 * p_n[1]);
            v42 = v33[13];
            v43 = v33[12] - v41;
            v44 = v42 - v34[13];
            v33[12] = v41 + v33[12];
            v33[13] = v42 + v34[13];
            v45 = v34[10];
            v34[12] = (float)(p_n[(unsigned __int64)v30 / 2 + 1] * v44) + (float)(p_n[(unsigned __int64)v30 / 2] * v43);
            v34[13] = (float)(v44 * p_n[(unsigned __int64)v30 / 2]) - (float)(v43 * p_n[(unsigned __int64)v30 / 2 + 1]);
            v46 = v33[11];
            v47 = v33[10] - v45;
            v48 = v46 - v34[11];
            v33[10] = v45 + v33[10];
            v33[11] = v46 + v34[11];
            v34[10] = (float)(p_n[v30 + 1] * v48) + (float)(p_n[v30] * v47);
            v49 = v34[8];
            v34[11] = (float)(v48 * p_n[v30]) - (float)(v47 * p_n[v30 + 1]);
            v50 = v33[9];
            v51 = v33[8] - v49;
            v52 = v50 - v34[9];
            v33[8] = v49 + v33[8];
            v33[9] = v50 + v34[9];
            v34[8] = (float)(p_n[v31 + 1] * v52) + (float)(p_n[v31] * v51);
            v53 = v52 * p_n[v31];
            v54 = v51 * p_n[v31 + 1];
            p_n = (float *)((char *)p_n + v32);
            v34[9] = v53 - v54;
          }
          while ( v26 <= v34 );
          ++v27;
          v26 = (float *)((char *)v26 + v28 * 4);
        }
        while ( v27 != 1 << v25 );
      }
      ++v25;
    }
    while ( v25 != v160 );
  }
  if ( points > 0 )
  {
    v55 = x + 30;
    v56 = x + 14;
    v57 = x + 31;
    v166 = x + 24;
    v202 = (((unsigned int)(points - 1) >> 5) + 1LL) << 7;
    v58 = x + 15;
    v59 = x + 28;
    v60 = x + 12;
    v61 = x + 29;
    v62 = x + 13;
    v180 = x + 25;
    v63 = x + 26;
    v64 = x + 10;
    v65 = x + 27;
    v66 = x + 11;
    v179 = x + 9;
    v67 = 0;
    v163 = x + 22;
    v178 = x + 6;
    v177 = x + 7;
    v176 = x + 23;
    v175 = x + 4;
    v174 = x + 20;
    v173 = x + 5;
    v162 = x + 21;
    v172 = x + 2;
    v171 = x + 18;
    v170 = x + 3;
    v169 = x + 19;
    v168 = x + 16;
    v161 = x + 1;
    v68 = x + 17;
    v69 = x + 8;
    pointsb = v68;
    v70 = v166;
    do
    {
      v184 = *v57 + *v58;
      v181 = *v55 - *v56;
      v71 = *v59 - *v60;
      v201 = v61;
      v182 = *v57 - *v58;
      v183 = *v55 + *v56;
      v72 = *v63 - *v64;
      v185 = *v59 + *v60;
      v186 = *v61 + *v62;
      v73 = (float)(0.9238795 * v71) - (float)(0.38268343 * (float)(*v61 - *v62));
      v74 = (float)(v71 * 0.38268343) + (float)((float)(*v61 - *v62) * 0.9238795);
      v75 = v180;
      v76 = *v65 - *v66;
      v200 = v70;
      v77 = v72 - v76;
      v188 = *v65 + *v66;
      v78 = v72 + v76;
      v79 = *v70 - *v69;
      v80 = *v180 - *v179;
      v190 = *v180 + *v179;
      v81 = v77 * 0.70710677;
      v82 = (float)(0.38268343 * v79) - (float)(0.9238795 * v80);
      v83 = v78 * 0.70710677;
      v187 = *v63 + *v64;
      v84 = (float)(v80 * 0.38268343) + (float)(v79 * 0.9238795);
      v189 = *v70 + *v69;
      v192 = *v163 + *v178;
      v191 = *v163 - *v178;
      v167 = *v177 + *v176;
      v85 = *v173 - *v162;
      v164 = *v177 - *v176;
      v193 = *v175 + *v174;
      v194 = *v173 + *v162;
      v86 = (float)(0.9238795 * v85) + (float)(0.38268343 * (float)(*v175 - *v174));
      v87 = (float)(v85 * 0.38268343) - (float)((float)(*v175 - *v174) * 0.9238795);
      v196 = *v170 + *v169;
      v88 = x[v67 / 4];
      v195 = *v172 + *v171;
      v89 = *v170 - *v169;
      v90 = (float)(*v172 - *v171) + v89;
      v91 = v89 - (float)(*v172 - *v171);
      v92 = *v161 - *pointsb;
      v93 = v88 - *v168;
      v94 = v88 + *v168;
      v95 = *v161 + *pointsb;
      v96 = v90 * 0.70710677;
      v97 = (float)(0.38268343 * v92) + (float)(0.9238795 * v93);
      v98 = (float)(v92 * 0.9238795) - (float)(v93 * 0.38268343);
      v99 = v97 - v82;
      v100 = v98 - v84;
      v197 = v82 + v97;
      v101 = v98 - v84;
      v198 = v84 + v98;
      v102 = v81 - v96;
      v103 = v96 + v81;
      v104 = (float)(v100 - v99) * 0.70710677;
      v105 = 0.70710677 * (float)(v101 + v99);
      v199 = v83 + (float)(v91 * 0.70710677);
      v106 = v73 - v86;
      v107 = v86 + v73;
      v108 = (float)(v91 * 0.70710677) - v83;
      v109 = v106 - (float)(v74 - v87);
      v110 = v106 + (float)(v74 - v87);
      v111 = v87 + v74;
      v112 = v109 * 0.70710677;
      v113 = v110 * 0.70710677;
      v114 = v108 + (float)(v181 - v164);
      v115 = (float)(v181 - v164) - v108;
      v116 = v105 + v112;
      v117 = v112 - v105;
      *v178 = v114 + v116;
      *v175 = v114 - v116;
      v118 = (float)(v182 - v191) - v102;
      v119 = v113 - v104;
      v120 = v102 + (float)(v182 - v191);
      v121 = v104 + v113;
      v122 = v117 + v118;
      v64 += 32;
      v69 += 32;
      v123 = v118 - v117;
      x[v67 / 4] = v115 + v119;
      v124 = v197 + v107;
      *v172 = v115 - v119;
      v125 = v107 - v197;
      *v170 = v122;
      *v161 = v123;
      v67 += 128LL;
      v60 += 32;
      v56 += 32;
      *v177 = v121 + v120;
      *v173 = v120 - v121;
      v126 = v103 + (float)(v181 + v164);
      v58 += 32;
      v127 = (float)(v181 + v164) - v103;
      v62 += 32;
      v66 += 32;
      *(v56 - 32) = v126 + v124;
      *(v60 - 32) = v126 - v124;
      v128 = (float)(v182 + v191) - v199;
      v129 = v111 - v198;
      v130 = v111 + v198;
      v131 = (float)(v182 + v191) + v199;
      *(v69 - 32) = v127 + v129;
      *(v64 - 32) = v127 - v129;
      *(v66 - 32) = v125 + v128;
      *v179 = v128 - v125;
      *(v58 - 32) = v130 + v131;
      *(v62 - 32) = v131 - v130;
      v165 = v95 + v190;
      v132 = (float)((float)(v95 - v190) + (float)(v94 - v189)) * 0.70710677;
      v133 = v189 + v94;
      v134 = (float)((float)(v95 - v190) - (float)(v94 - v189)) * 0.70710677;
      v135 = (float)((float)(v185 - v193) - (float)(v186 - v194)) * 0.70710677;
      v136 = (float)(v183 - v192) - (float)(v196 - v188);
      v137 = v132 + v135;
      v138 = v135 - v132;
      v139 = (float)((float)(v196 - v188) + (float)(v183 - v192)) + v137;
      v140 = (float)((float)(v196 - v188) + (float)(v183 - v192)) - v137;
      v141 = (float)((float)(v186 - v194) + (float)(v185 - v193)) * 0.70710677;
      v142 = v141 + v134;
      *v163 = v139;
      v143 = v141 - v134;
      *v174 = v140;
      v144 = (float)(v184 - v167) - (float)(v187 - v195);
      v145 = (float)(v184 - v167) + (float)(v187 - v195);
      *v168 = v136 + v143;
      *v171 = v136 - v143;
      *v169 = v138 + v144;
      *pointsb = v144 - v138;
      v146 = v142 + v145;
      v59 += 32;
      v147 = v145 - v142;
      v55 += 32;
      v148 = v133 + (float)(v185 + v193);
      *v176 = v146;
      *v162 = v147;
      v149 = (float)(v185 + v193) - v133;
      v150 = (float)(v183 + v192) - (float)(v187 + v195);
      v151 = (float)(v187 + v195) + (float)(v183 + v192);
      v152 = v151 - v148;
      v153 = v151 + v148;
      v154 = (float)(v184 + v167) + (float)(v188 + v196);
      v155 = (float)(v184 + v167) - (float)(v188 + v196);
      *(v55 - 32) = v153;
      *(v59 - 32) = v152;
      v156 = (float)(v186 + v194) - v165;
      v157 = (float)(v186 + v194) + v165;
      v180 += 32;
      v179 += 32;
      v70 += 32;
      v163 += 32;
      v63 += 32;
      v57 += 32;
      v65 += 32;
      *v200 = v150 + v156;
      v178 += 32;
      *(v63 - 32) = v150 - v156;
      v177 += 32;
      v176 += 32;
      *(v65 - 32) = v149 + v155;
      *v75 = v155 - v149;
      v175 += 32;
      v174 += 32;
      v173 += 32;
      v162 += 32;
      v61 = v201 + 32;
      *(v57 - 32) = v157 + v154;
      *v201 = v154 - v157;
      v172 += 32;
      v171 += 32;
      v170 += 32;
      v169 += 32;
      v168 += 32;
      v161 += 32;
      pointsb += 32;
    }
    while ( v67 != v202 );
  }
}


// Address: 0x226d5c0 | Name: FMOD_mdct_init
int __fastcall FMOD_mdct_init(void *context, mdct_lookup *lookup, int n)
{
  __m128 v3; // xmm7
  int v4; // r15d
  int v6; // r15d
  int v7; // esi
  int *v8; // r13
  int v9; // ebp
  __m128 v10; // xmm0
  float v11; // xmm3_4
  __int64 v12; // r14
  float *v13; // rbx
  int v14; // eax
  int v15; // r15d
  int v16; // ecx
  float v17; // xmm4_4
  float v18; // xmm0_4
  float v19; // xmm6_4
  int v20; // ebx
  int v21; // r15d
  __int64 v22; // r14
  double v23; // xmm0_8
  __int64 v24; // r8
  int v25; // esi
  int v26; // eax
  int v27; // edx
  char v28; // cl
  int v29; // eax
  int v31; // [rsp+20h] [rbp-68h]
  float *T; // [rsp+28h] [rbp-60h]
  int log2n; // [rsp+3Ch] [rbp-4Ch]
  double cosx; // [rsp+40h] [rbp-48h] BYREF
  double sinx[8]; // [rsp+48h] [rbp-40h] BYREF

  v4 = n + 3;
  if ( n >= 0 )
    v4 = n;
  v6 = v4 >> 2;
  v7 = n + v6;
  v8 = (int *)FMOD_OggVorbis_Malloc(context, 4 * v6);
  v9 = n >> 1;
  v3.m128_f32[0] = (float)n;
  v10 = v3;
  T = (float *)FMOD_OggVorbis_Malloc(context, 4 * v7);
  v10.m128_f32[0] = logf((float)n) / 0.69314718;
  v11 = fabs(v10.m128_f32[0]);
  if ( v11 < 8388608.0 )
    v10.m128_i32[0] = _mm_andnot_ps((__m128)0x7FFFFFFFu, v10).m128_u32[0]
                    | COERCE_UNSIGNED_INT((float)(v11 + 8388608.0) - 8388608.0);
  log2n = (int)v10.m128_f32[0];
  lookup->log2n = (int)v10.m128_f32[0];
  if ( !T || !v8 )
    return -139;
  lookup->trig = T;
  lookup->bitrev = v8;
  lookup->n = n;
  if ( v6 > 0 )
  {
    v12 = (__int64)&T[v9 + 1];
    v13 = T;
    v14 = 2 * v6;
    v15 = 0;
    v31 = v14;
    do
    {
      v13 += 2;
      v12 += 8;
      sincos((double)(2 * v15) * (3.141592653589793 / (double)n), sinx, &cosx);
      v16 = v15 + 1;
      v15 += 2;
      v17 = cosx;
      v18 = _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)&sinx[0], (__m128d)*(unsigned __int64 *)&sinx[0]).m128d_f64[0];
      *(v13 - 2) = v17;
      *(v13 - 1) = -v18;
      sincos((double)v16 * (3.141592653589793 / (double)(2 * n)), sinx, &cosx);
      v19 = _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)&sinx[0], (__m128d)*(unsigned __int64 *)&sinx[0]).m128d_f64[0];
      *(float *)(v12 - 12) = cosx;
      *(float *)(v12 - 8) = v19;
    }
    while ( v15 != v31 );
  }
  v20 = n / 8;
  if ( n / 8 > 0 )
  {
    v21 = 2;
    v22 = (__int64)&T[n + 1];
    do
    {
      v23 = (double)v21;
      v21 += 4;
      v22 += 8;
      sincos(v23 * (3.141592653589793 / (double)n), sinx, &cosx);
      *(float *)&v23 = -(float)_mm_unpacklo_pd(
                                 (__m128d)*(unsigned __int64 *)&sinx[0],
                                 (__m128d)*(unsigned __int64 *)&sinx[0]).m128d_f64[0];
      *(float *)(v22 - 12) = (float)cosx * 0.5;
      *(float *)(v22 - 8) = *(float *)&v23 * 0.5;
    }
    while ( v21 != 4 * v20 + 2 );
    v24 = 0;
    v25 = 1 << (log2n - 2);
    do
    {
      if ( v25 )
      {
        v26 = 1 << (log2n - 2);
        v27 = 0;
        v28 = 0;
        do
        {
          if ( ((unsigned int)v24 & v26) != 0 )
            v27 |= 1 << v28;
          v26 = v25 >> ++v28;
        }
        while ( v25 >> v28 );
        v29 = ~v27;
      }
      else
      {
        v29 = -1;
        v27 = 0;
      }
      v8[2 * v24 + 1] = v27;
      v8[2 * v24++] = (((1 << (log2n - 1)) - 1) & v29) - 1;
    }
    while ( v20 > (int)v24 );
  }
  lookup->scale = 4.0 / (float)n;
  return 0;
}


// Address: 0x226d910 | Name: FMOD_mdct_clear
void __fastcall FMOD_mdct_clear(void *context, mdct_lookup *l)
{
  float *trig; // rsi
  int *bitrev; // rsi

  if ( l )
  {
    trig = l->trig;
    if ( trig )
      FMOD_OggVorbis_Free(context, trig);
    bitrev = l->bitrev;
    if ( bitrev )
      FMOD_OggVorbis_Free(context, bitrev);
    *(_QWORD *)&l->n = 0;
    l->trig = 0;
    l->bitrev = 0;
    *(_QWORD *)&l->scale = 0;
  }
}


// Address: 0x226d970 | Name: FMOD_mdct_backward
void __fastcall FMOD_mdct_backward(mdct_lookup *init, float *in, float *out)
{
  int v5; // ecx
  __int64 v6; // r12
  __int64 v7; // r14
  __int64 v8; // rdx
  __int64 v9; // r12
  float *v10; // r8
  float *v11; // rbx
  float *v12; // rax
  float *v13; // rdx
  float *v14; // r9
  float v15; // xmm1_4
  float *v16; // rax
  float *v17; // rdx
  float v18; // xmm1_4
  float v19; // xmm2_4
  float *v20; // r13
  float *trig; // rcx
  int *bitrev; // r8
  float *v23; // rdi
  float *v24; // rdx
  float *v25; // rax
  float *v26; // rsi
  __int64 v27; // r9
  float v28; // xmm8_4
  float v29; // xmm2_4
  float *v30; // r10
  float *v31; // r9
  float v32; // xmm4_4
  float v33; // xmm10_4
  float v34; // xmm9_4
  float v35; // xmm4_4
  float v36; // xmm1_4
  float *v37; // r10
  float *v38; // r9
  float v39; // xmm4_4
  float v40; // xmm3_4
  float v41; // xmm1_4
  float v42; // xmm6_4
  float v43; // xmm4_4
  float v44; // xmm3_4
  float v45; // xmm4_4
  float v46; // xmm10_4
  float v47; // xmm9_4
  float v48; // xmm8_4
  float v49; // xmm2_4
  float v50; // xmm4_4
  float v51; // xmm3_4
  float v52; // xmm1_4
  float v53; // xmm2_4
  float *v54; // rcx
  float *v55; // rax
  float *v56; // rdx
  float *v57; // rsi
  float v58; // xmm1_4
  float v59; // xmm1_4
  float v60; // xmm2_4
  float *v61; // rbp
  float *v62; // rcx
  float *v63; // rax
  float v64; // xmm1_4
  float v65; // xmm1_4
  float v66; // xmm1_4
  float v67; // xmm1_4
  float *v68; // rax
  int v69; // xmm0_4

  v5 = init->n >> 1;
  v6 = init->n >> 2;
  v7 = v5;
  v8 = v6 + v5;
  v9 = v6;
  v10 = &init->trig[v9];
  v11 = &out[v8];
  v12 = &in[v7 - 7];
  v13 = v11;
  v14 = v10;
  do
  {
    v15 = v12[2];
    v13 -= 4;
    v12 -= 8;
    v14 += 4;
    *v13 = (float)((float)-v15 * *(v14 - 1)) - (float)(v12[8] * *(v14 - 2));
    v13[1] = (float)(v12[8] * *(v14 - 1)) - (float)(v12[10] * *(v14 - 2));
    v13[2] = (float)((float)-v12[14] * *(v14 - 3)) - (float)(v12[12] * *(v14 - 4));
    v13[3] = (float)(v12[12] * *(v14 - 3)) - (float)(v12[14] * *(v14 - 4));
  }
  while ( in <= v12 );
  v16 = &in[v7 - 8];
  v17 = v11;
  do
  {
    v10 -= 4;
    v18 = v16[4] * v10[3];
    v19 = v16[6] * v10[2];
    v16 -= 8;
    v17 += 4;
    *(v17 - 4) = v18 + v19;
    *(v17 - 3) = (float)(v16[12] * v10[2]) - (float)(v16[14] * v10[3]);
    *(v17 - 2) = (float)(v16[8] * v10[1]) + (float)(v16[10] * *v10);
    *(v17 - 1) = (float)(v16[8] * *v10) - (float)(v16[10] * v10[1]);
  }
  while ( in <= v16 );
  v20 = &out[v7];
  mdct_butterflies((mdct_lookup *)(unsigned int)init->log2n, (mdct_lookup *)init->trig, &out[v7], v5);
  trig = init->trig;
  bitrev = init->bitrev;
  v23 = &out[init->n >> 1];
  v24 = &trig[init->n];
  v25 = out;
  v26 = &out[init->n >> 1];
  do
  {
    v27 = *bitrev;
    v28 = *v24;
    v29 = v24[1];
    v26 -= 4;
    v25 += 4;
    v24 += 4;
    bitrev += 4;
    v30 = &v23[v27];
    v31 = &v23[*(bitrev - 3)];
    v32 = v31[1];
    v33 = *v30 + *v31;
    v34 = v30[1] - v32;
    v35 = v32 + v30[1];
    v36 = *v30 - *v31;
    v37 = &v23[*(bitrev - 2)];
    v38 = &v23[*(bitrev - 1)];
    v39 = v35 * 0.5;
    v40 = (float)(v33 * v28) + (float)(v34 * v29);
    v41 = v36 * 0.5;
    v42 = v40 + v39;
    v43 = v39 - v40;
    v44 = (float)(v29 * v33) - (float)(v28 * v34);
    *(v25 - 4) = v42;
    v26[2] = v43;
    *(v25 - 3) = v44 + v41;
    v26[3] = v44 - v41;
    v45 = v38[1];
    v46 = *v37 + *v38;
    v47 = v37[1] - v45;
    v48 = *(v24 - 2);
    v49 = *(v24 - 1);
    v50 = (float)(v45 + v37[1]) * 0.5;
    v51 = (float)(v46 * v48) + (float)(v47 * v49);
    v52 = (float)(*v37 - *v38) * 0.5;
    v53 = (float)(v49 * v46) - (float)(v48 * v47);
    *(v25 - 2) = v51 + v50;
    *v26 = v50 - v51;
    *(v25 - 1) = v53 + v52;
    v26[1] = v53 - v52;
  }
  while ( v26 > v25 );
  v54 = &trig[v7];
  v55 = out;
  v56 = v11;
  v57 = v11;
  do
  {
    v58 = *v55;
    v57 -= 4;
    v55 += 8;
    v59 = v58 * v54[1];
    v60 = *(v55 - 7) * *v54;
    v56 += 4;
    v54 += 8;
    v57[3] = v59 - v60;
    *(v56 - 4) = -(float)((float)(*(v55 - 8) * *(v54 - 8)) + (float)(*(v55 - 7) * *(v54 - 7)));
    v57[2] = (float)(*(v55 - 6) * *(v54 - 5)) - (float)(*(v55 - 5) * *(v54 - 6));
    *(v56 - 3) = -(float)((float)(*(v55 - 6) * *(v54 - 6)) + (float)(*(v55 - 5) * *(v54 - 5)));
    v57[1] = (float)(*(v55 - 4) * *(v54 - 3)) - (float)(*(v55 - 3) * *(v54 - 4));
    *(v56 - 2) = -(float)((float)(*(v55 - 4) * *(v54 - 4)) + (float)(*(v55 - 3) * *(v54 - 3)));
    *v57 = (float)(*(v55 - 2) * *(v54 - 1)) - (float)(*(v55 - 1) * *(v54 - 2));
    *(v56 - 1) = -(float)((float)(*(v55 - 2) * *(v54 - 2)) + (float)(*(v55 - 1) * *(v54 - 1)));
  }
  while ( v57 > v55 );
  v61 = &out[v9];
  v62 = v11;
  v63 = v61;
  do
  {
    v62 -= 4;
    v64 = v62[3];
    v61 -= 4;
    v61[3] = v64;
    v63 += 4;
    *(v63 - 4) = -v64;
    v65 = v62[2];
    v61[2] = v65;
    *(v63 - 3) = -v65;
    v66 = v62[1];
    v61[1] = v66;
    *(v63 - 2) = -v66;
    v67 = *v62;
    *v61 = *v62;
    *(v63 - 1) = -v67;
  }
  while ( v62 > v63 );
  v68 = v11;
  do
  {
    v69 = *((_DWORD *)v68 + 3);
    v11 -= 4;
    v68 += 4;
    *(_DWORD *)v11 = v69;
    v11[1] = *(v68 - 2);
    v11[2] = *(v68 - 3);
    v11[3] = *(v68 - 4);
  }
  while ( v20 < v11 );
}


// Address: 0x226de70 | Name: FMOD_mdct_forward
void __fastcall FMOD_mdct_forward(mdct_lookup *init, float *in, float *out)
{
  __int64 n; // rax
  int v5; // ecx
  int v6; // r11d
  void *v7; // rsp
  float *v8; // r9
  float *v9; // r13
  float *v10; // rax
  float *v11; // rbx
  float *v12; // r8
  float *v13; // r10
  float *v14; // rdx
  __int64 v15; // r14
  float *v16; // rdi
  float v17; // xmm0_4
  float v18; // xmm1_4
  signed int v19; // r14d
  float *v20; // r10
  float *v21; // r8
  unsigned int v22; // r15d
  float *v23; // r11
  float *v24; // rdx
  float v25; // xmm0_4
  float v26; // xmm1_4
  float *v27; // rsi
  float *v28; // rdx
  __int64 v29; // rdi
  float v30; // xmm0_4
  float v31; // xmm1_4
  float *trig; // r9
  int *bitrev; // rcx
  float *v34; // rsi
  float *v35; // rdx
  float *v36; // rax
  __int64 v37; // rdi
  float v38; // xmm7_4
  float v39; // xmm1_4
  float *v40; // r8
  float *v41; // rdi
  float v42; // xmm3_4
  float v43; // xmm9_4
  float v44; // xmm8_4
  float v45; // xmm3_4
  float v46; // xmm0_4
  float *v47; // r8
  float *v48; // rdi
  float v49; // xmm3_4
  float v50; // xmm2_4
  float v51; // xmm0_4
  float v52; // xmm5_4
  float v53; // xmm3_4
  float v54; // xmm2_4
  float v55; // xmm3_4
  float v56; // xmm9_4
  float v57; // xmm8_4
  float v58; // xmm7_4
  float v59; // xmm1_4
  float v60; // xmm3_4
  float v61; // xmm2_4
  float v62; // xmm0_4
  float v63; // xmm1_4
  float *v64; // rcx
  float *v65; // rdx
  float *v66; // rax
  __int64 v67; // rsi
  float v68; // xmm0_4
  float v69; // xmm0_4
  float v70; // xmm1_4
  __int64 v71; // [rsp+0h] [rbp-60h] BYREF
  float *outa; // [rsp+8h] [rbp-58h]
  unsigned __int64 v73; // [rsp+10h] [rbp-50h]
  unsigned __int64 v74; // [rsp+18h] [rbp-48h]
  int n4; // [rsp+24h] [rbp-3Ch]
  float *w2; // [rsp+28h] [rbp-38h]

  n = init->n;
  outa = out;
  v5 = (int)n >> 1;
  v74 = 4 * n;
  v6 = (int)n >> 3;
  n4 = (int)n >> 2;
  v7 = alloca(4 * n + 15);
  v8 = &in[((int)n >> 2) + (__int64)((int)n >> 1)];
  v9 = (float *)&v71;
  v10 = &init->trig[(int)n >> 1];
  v11 = (float *)&v71;
  v73 = 4LL * v5;
  v12 = v8 + 1;
  w2 = (float *)((char *)&v71 + v73);
  if ( v6 <= 0 )
  {
    v19 = 0;
  }
  else
  {
    v13 = (float *)&v71 + v5;
    v71 = (unsigned int)(v6 - 1) >> 1;
    v14 = v10;
    v15 = (__int64)&v8[-4 * v71 - 4];
    v16 = v8;
    do
    {
      v16 -= 4;
      v17 = v16[2] + *v12;
      v18 = *v16 + v12[2];
      v14 -= 2;
      v12 += 4;
      v13 += 2;
      *(v13 - 2) = (float)(v14[1] * v18) + (float)(*v14 * v17);
      *(v13 - 1) = (float)(v18 * *v14) - (float)(v17 * v14[1]);
    }
    while ( v16 != (float *)v15 );
    v19 = 2 * ((unsigned int)(v6 - 1) >> 1) + 2;
    v10 += 2 * ~v71;
    v8 += 4 * ~v71;
  }
  v20 = in + 1;
  if ( v19 < v5 - v6 )
  {
    v21 = in + 1;
    v22 = (unsigned int)(v5 - v6 - 1 - v19) >> 1;
    v23 = &w2[v19 + 1];
    v71 = v22;
    v24 = v10;
    do
    {
      v8 -= 4;
      v25 = v8[2] - *v21;
      v26 = *v8 - v21[2];
      v24 -= 2;
      v21 += 4;
      v23 += 2;
      *(v23 - 3) = (float)(v24[1] * v26) + (float)(*v24 * v25);
      *(v23 - 2) = (float)(v26 * *v24) - (float)(v25 * v24[1]);
    }
    while ( v21 != &in[4 * v22 + 5] );
    v19 += 2 * v22 + 2;
    v20 += 4 * v71 + 4;
    v10 += -2 * v71 - 2;
  }
  v27 = &in[v74 / 4];
  if ( v5 > v19 )
  {
    v28 = &w2[v19 + 1];
    v29 = (__int64)&v27[-4 * ((unsigned int)(v5 - 1 - v19) >> 1) - 4];
    do
    {
      v27 -= 4;
      v10 -= 2;
      v20 += 4;
      v28 += 2;
      v30 = (float)-v27[2] - *(v20 - 4);
      v31 = (float)-*v27 - *(v20 - 2);
      *(v28 - 3) = (float)(v10[1] * v31) + (float)(*v10 * v30);
      *(v28 - 2) = (float)(v31 * *v10) - (float)(v30 * v10[1]);
    }
    while ( v27 != (float *)v29 );
  }
  mdct_butterflies((mdct_lookup *)(unsigned int)init->log2n, (mdct_lookup *)init->trig, w2, v5);
  trig = init->trig;
  bitrev = init->bitrev;
  v34 = (float *)&v71 + (init->n >> 1);
  v35 = &trig[init->n];
  v36 = v34;
  do
  {
    v37 = *bitrev;
    v38 = *v35;
    v39 = v35[1];
    v36 -= 4;
    v9 += 4;
    v35 += 4;
    bitrev += 4;
    v40 = &v34[v37];
    v41 = &v34[*(bitrev - 3)];
    v42 = v41[1];
    v43 = *v40 + *v41;
    v44 = v40[1] - v42;
    v45 = v42 + v40[1];
    v46 = *v40 - *v41;
    v47 = &v34[*(bitrev - 2)];
    v48 = &v34[*(bitrev - 1)];
    v49 = v45 * 0.5;
    v50 = (float)(v43 * v38) + (float)(v44 * v39);
    v51 = v46 * 0.5;
    v52 = v50 + v49;
    v53 = v49 - v50;
    v54 = (float)(v39 * v43) - (float)(v38 * v44);
    *(v9 - 4) = v52;
    v36[2] = v53;
    *(v9 - 3) = v54 + v51;
    v36[3] = v54 - v51;
    v55 = v48[1];
    v56 = *v47 + *v48;
    v57 = v47[1] - v55;
    v58 = *(v35 - 2);
    v59 = *(v35 - 1);
    v60 = (float)(v55 + v47[1]) * 0.5;
    v61 = (float)(v56 * v58) + (float)(v57 * v59);
    v62 = (float)(*v47 - *v48) * 0.5;
    v63 = (float)(v59 * v56) - (float)(v58 * v57);
    *(v9 - 2) = v61 + v60;
    *v36 = v60 - v61;
    *(v9 - 1) = v63 + v62;
    v36[1] = v63 - v62;
  }
  while ( v36 > v9 );
  v64 = outa;
  v65 = &outa[v73 / 4];
  v66 = &trig[v73 / 4];
  if ( n4 > 0 )
  {
    v67 = (__int64)&v65[-(n4 - 1) - 1];
    do
    {
      v68 = *v11;
      --v65;
      v11 += 2;
      v69 = v68 * *v66;
      v70 = *(v11 - 1) * v66[1];
      ++v64;
      v66 += 2;
      *(v64 - 1) = (float)(v69 + v70) * init->scale;
      *v65 = (float)((float)(*(v11 - 2) * *(v66 - 1)) - (float)(*(v11 - 1) * *(v66 - 2))) * init->scale;
    }
    while ( v65 != (float *)v67 );
  }
}


