// Address: 0x21e61c0 | Name: _ZN4FMOD42fft_conjugate_pair_dit_permutation_builderEPiiiii
void __fastcall FMOD::fft_conjugate_pair_dit_permutation_builder(int *table, int o, int s, int N, int M)
{
  int v7; // ebp
  int v8; // r12d
  int v9; // ebx
  int v10; // ebx
  int v11; // esi
  int v12; // r15d

  v7 = N;
  if ( N == 1 )
  {
LABEL_9:
    *table = M & o;
    return;
  }
  v8 = s;
  if ( N != 2 )
  {
    while ( 1 )
    {
      v9 = v7 + 3;
      v12 = 4 * v8;
      if ( v7 >= 0 )
        v9 = v7;
      FMOD::fft_conjugate_pair_dit_permutation_builder(table, o, 2 * v8, v7 / 2, M);
      v10 = v9 >> 2;
      v11 = o + v8;
      o += v8 * (v7 - 1);
      FMOD::fft_conjugate_pair_dit_permutation_builder(&table[v7 / 2], v11, v12, v10, M);
      table += 3 * v10;
      if ( v10 == 1 )
        goto LABEL_9;
      if ( v10 == 2 )
        goto LABEL_10;
      v7 = v10;
      v8 *= 4;
    }
  }
  v12 = s;
LABEL_10:
  table[1] = M & (o + v12);
  *table = o & M;
}


// Address: 0x21e62c0 | Name: _ZN4FMOD3FFT4initEj
FMOD_RESULT_0 __fastcall FMOD::FFT::init(FMOD::FFT *const this, unsigned int size)
{
  FMOD_RESULT_0 result; // eax
  int mSize; // edx
  float *v4; // rax
  float *v5; // rax
  int v6; // r14d
  float *v7; // rbp
  float *v8; // rbx
  float v9; // xmm0_4
  int v10; // xmm0_4
  float *v11; // rbp
  int v12; // r14d
  float v13; // xmm0_4
  float v14; // xmm0_4
  int *v15; // rax
  float *root; // [rsp+18h] [rbp-50h]
  int n_0; // [rsp+20h] [rbp-48h]
  unsigned int n; // [rsp+24h] [rbp-44h]
  int v19; // [rsp+28h] [rbp-40h] BYREF
  float sinx[15]; // [rsp+2Ch] [rbp-3Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mSize = this->mSize;
  this->mNodePrev = this;
  this->mNodeNext = this;
  this->mNodeData = 0;
  if ( !mSize && size - 16 <= 0xFFF0 && (size & (size - 1)) == 0 )
  {
    result = FMOD_OS_CriticalSection_Create(&this->mCrit, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v4 = (float *)FMOD::MemPool::alloc(
                      off_286F358->gSystemMemPool,
                      8 * size + 16,
                      "../../../core_api/src/fmod_fft.cpp",
                      54,
                      0,
                      0);
      this->mFFTworkspMemory = v4;
      if ( v4
        && (this->mFFTworksp = (float *)(((unsigned __int64)v4 + 15) & 0xFFFFFFFFFFFFFFF0LL),
            n = size >> 1,
            v5 = (float *)FMOD::MemPool::alloc(
                            off_286F358->gSystemMemPool,
                            8 * ((size >> 1) + (size >> 2)) + 16,
                            "../../../core_api/src/fmod_fft.cpp",
                            63,
                            0,
                            0),
            (this->mFFTtableMemory = v5) != 0) )
      {
        v6 = 0;
        v7 = (float *)(((unsigned __int64)v5 + 15) & 0xFFFFFFFFFFFFFFF0LL);
        this->mFFTtable = v7;
        v8 = v7;
        do
        {
          v9 = (float)v6;
          v8 += 2;
          ++v6;
          sincosf((float)(v9 * -6.2831855) / (float)(int)size, sinx, (float *)&v19);
          v10 = v19;
          *(v8 - 2) = sinx[0];
          *((_DWORD *)v8 - 1) = v10;
        }
        while ( v6 != (int)size >> 1 );
        root = &v7[2 * (v6 - 1) + 2];
        n_0 = size >> 1;
        do
        {
          if ( n_0 / 4 > 0 )
          {
            v11 = root;
            v12 = 0;
            do
            {
              v13 = (float)v12++;
              v11 += 2;
              sincosf((float)(v13 * 6.2831855) / (float)n_0, sinx, (float *)&v19);
              v14 = sinx[0];
              *((_DWORD *)v11 - 2) = v19;
              *(v11 - 1) = v14;
            }
            while ( v12 != n_0 / 4 );
            root += 2 * (unsigned int)(v12 - 1) + 2;
          }
          n_0 >>= 1;
        }
        while ( n_0 );
        v15 = (int *)FMOD::MemPool::alloc(
                       off_286F358->gSystemMemPool,
                       4 * n,
                       "../../../core_api/src/fmod_fft.cpp",
                       94,
                       0,
                       0);
        this->mFFTbitrevMemory = v15;
        this->mFFTbitrev = v15;
        FMOD::fft_conjugate_pair_dit_permutation_builder(v15, 0, 1, n, n - 1);
        this->mSize = size;
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
    }
  }
  return result;
}


// Address: 0x21e6550 | Name: _ZN4FMOD3FFT7releaseEv
FMOD_RESULT_0 __fastcall FMOD::FFT::release(FMOD::FFT *const this)
{
  float *mFFTworkspMemory; // rsi
  float *mFFTtableMemory; // rsi
  int *mFFTbitrevMemory; // rsi
  FMOD::LinkedListNode *mNodeNext; // rdx
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD_OS_CRITICALSECTION *mCrit; // rdi

  mFFTworkspMemory = this->mFFTworkspMemory;
  if ( mFFTworkspMemory )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mFFTworkspMemory, "../../../core_api/src/fmod_fft.cpp", 104);
    this->mFFTworkspMemory = 0;
  }
  mFFTtableMemory = this->mFFTtableMemory;
  if ( mFFTtableMemory )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mFFTtableMemory, "../../../core_api/src/fmod_fft.cpp", 105);
    this->mFFTtableMemory = 0;
  }
  mFFTbitrevMemory = this->mFFTbitrevMemory;
  if ( mFFTbitrevMemory )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mFFTbitrevMemory, "../../../core_api/src/fmod_fft.cpp", 106);
    this->mFFTbitrevMemory = 0;
  }
  mNodeNext = this->mNodeNext;
  mNodePrev = this->mNodePrev;
  mCrit = this->mCrit;
  this->mSize = 0;
  mNodePrev->mNodeNext = mNodeNext;
  this->mNodeNext->mNodePrev = mNodePrev;
  this->mNodePrev = this;
  this->mNodeNext = this;
  if ( mCrit )
  {
    FMOD_OS_CriticalSection_Free(mCrit, 0);
    this->mCrit = 0;
  }
  FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_fft.cpp", 115);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e6650 | Name: _ZN4FMOD3FFT7realDFTEPKfP12FMOD_COMPLEXS2_i
FMOD_RESULT_0 __fastcall FMOD::FFT::realDFT(
        FMOD::FFT *const this,
        const float *signal,
        FMOD_COMPLEX *dft,
        const float *window,
        int signalhop)
{
  FMOD_RESULT_0 result; // eax
  FMOD_OS_CRITICALSECTION *mCrit; // rbp
  float *mFFTworksp; // r13
  __int64 mSize; // r10
  int v11; // ecx
  int *v12; // r11
  __int64 v13; // r9
  int v14; // eax
  int v15; // edx
  __int64 v16; // rdi
  int v17; // edx
  int *v18; // rdx
  __int64 v19; // rcx
  __int64 v20; // rdi
  int *mFFTbitrev; // r9
  __int64 v22; // rdx
  int v23; // ecx

  result = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  if ( this->mSize )
  {
    LOBYTE(result) = 31;
    if ( signalhop )
    {
      mCrit = this->mCrit;
      FMOD_OS_CriticalSection_Enter(mCrit);
      mFFTworksp = this->mFFTworksp;
      mSize = this->mSize;
      v11 = (int)window;
      if ( signalhop != 1 || window )
      {
        if ( !window )
        {
          if ( (int)mSize <= 1 )
          {
            LOBYTE(v11) = 2;
            v14 = (int)mSize / v11;
          }
          else
          {
            mFFTbitrev = this->mFFTbitrev;
            v22 = 0;
            v14 = (int)mSize >> 1;
            do
            {
              v23 = signalhop * 2 * mFFTbitrev[v22];
              mFFTworksp[2 * v22] = signal[v23];
              mFFTworksp[2 * v22++ + 1] = signal[signalhop + v23];
            }
            while ( v14 > (int)v22 );
          }
          goto LABEL_9;
        }
        if ( (int)mSize > 1 )
        {
          v12 = this->mFFTbitrev;
          v13 = 0;
          v14 = (int)mSize >> 1;
          do
          {
            v15 = 2 * v12[v13];
            v16 = v15;
            v17 = signalhop * v15;
            mFFTworksp[2 * v13] = signal[v17] * window[v16];
            mFFTworksp[2 * v13++ + 1] = signal[signalhop + v17] * window[v16 + 1];
          }
          while ( v14 > (int)v13 );
          goto LABEL_9;
        }
      }
      else if ( (int)mSize > 1 )
      {
        v18 = this->mFFTbitrev;
        v19 = 0;
        v14 = (int)mSize >> 1;
        do
        {
          v20 = 2 * v18[v19];
          mFFTworksp[2 * v19] = signal[v20];
          mFFTworksp[2 * v19++ + 1] = signal[v20 + 1];
        }
        while ( v14 > (int)v19 );
        goto LABEL_9;
      }
      v14 = (int)mSize / 2;
LABEL_9:
      FMOD_Optimised_Routines.FMOD_FFT_DFT(mFFTworksp, &this->mFFTtable[mSize], v14);
      FMOD_Optimised_Routines.FMOD_FFT_Real_DFT_Postprocess(mFFTworksp, (float *)dft, this->mFFTtable, this->mSize);
      FMOD_OS_CriticalSection_Leave(mCrit);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21e6830 | Name: _ZN4FMOD3FFT14realInverseDFTEPK12FMOD_COMPLEXPfPKfi
FMOD_RESULT_0 __fastcall FMOD::FFT::realInverseDFT(
        FMOD::FFT *const this,
        const FMOD_COMPLEX *dft,
        float *signal,
        const float *window,
        int signalhop)
{
  FMOD_RESULT_0 result; // eax
  __int64 mSize; // r10
  float *mFFTworksp; // rdi
  int v11; // edx
  int *mFFTbitrev; // r9
  __int64 v13; // rax
  int v14; // edx
  float *v15; // r10
  __int64 v16; // rax
  __int64 v17; // rdx
  float v18; // xmm0_4
  int v19; // edx
  float *v20; // rcx
  __int64 v21; // rax
  __int64 v22; // rdx
  int v23; // xmm0_4
  float *v24; // r10
  __int64 v25; // rax
  __int64 v26; // rdx
  int v27; // xmm0_4

  result = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  if ( this->mSize )
  {
    LOBYTE(result) = 31;
    if ( signalhop )
    {
      ((void (__fastcall *)(const FMOD_COMPLEX *, float *, float *))FMOD_Optimised_Routines.FMOD_FFT_Real_IDFT_Preprocess)(
        dft,
        this->mFFTworksp,
        this->mFFTtable);
      mSize = this->mSize;
      mFFTworksp = this->mFFTworksp;
      v11 = this->mSize / 2;
      if ( v11 > 0 )
      {
        mFFTbitrev = this->mFFTbitrev;
        v13 = 0;
        do
        {
          *(_QWORD *)&mFFTworksp[2 * v11 + 2 * v13] = *(_QWORD *)&mFFTworksp[2 * mFFTbitrev[v13]];
          ++v13;
        }
        while ( v11 > (int)v13 );
      }
      ((void (__fastcall *)(float *, float *))FMOD_Optimised_Routines.FMOD_FFT_IDFT)(
        &mFFTworksp[mSize],
        &this->mFFTtable[mSize]);
      if ( signalhop != 1 || window )
      {
        v14 = this->mSize;
        if ( window )
        {
          if ( v14 > 0 )
          {
            v15 = this->mFFTworksp;
            v16 = (__int64)&v15[v14 + 1];
            v17 = (__int64)&v15[4 * ((unsigned int)(v14 - 1) >> 2) + 5 + v14];
            do
            {
              v18 = *(float *)(v16 - 4);
              v16 += 16;
              window += 4;
              *signal = v18 * *(window - 4);
              signal[signalhop] = *(float *)(v16 - 16) * *(window - 3);
              signal[2 * signalhop] = *(float *)(v16 - 12) * *(window - 2);
              signal[3 * signalhop] = *(float *)(v16 - 8) * *(window - 1);
              signal += 4 * signalhop;
            }
            while ( v16 != v17 );
          }
        }
        else if ( v14 > 0 )
        {
          v24 = this->mFFTworksp;
          v25 = (__int64)&v24[v14 + 1];
          v26 = (__int64)&v24[4 * ((unsigned int)(v14 - 1) >> 2) + 5 + v14];
          do
          {
            v27 = *(_DWORD *)(v25 - 4);
            v25 += 16;
            *(_DWORD *)signal = v27;
            signal[signalhop] = *(float *)(v25 - 16);
            signal[2 * signalhop] = *(float *)(v25 - 12);
            signal[3 * signalhop] = *(float *)(v25 - 8);
            signal += 4 * signalhop;
          }
          while ( v25 != v26 );
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
      else
      {
        v19 = this->mSize;
        if ( v19 > 0 )
        {
          v20 = this->mFFTworksp;
          v21 = (__int64)&v20[v19 + 1];
          v22 = (__int64)&v20[4 * ((unsigned int)(v19 - 1) >> 2) + 5 + v19];
          do
          {
            v23 = *(_DWORD *)(v21 - 4);
            v21 += 16;
            signal += 4;
            *((_DWORD *)signal - 4) = v23;
            *(signal - 3) = *(float *)(v21 - 16);
            *(signal - 2) = *(float *)(v21 - 12);
            *(signal - 1) = *(float *)(v21 - 8);
          }
          while ( v21 != v22 );
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


