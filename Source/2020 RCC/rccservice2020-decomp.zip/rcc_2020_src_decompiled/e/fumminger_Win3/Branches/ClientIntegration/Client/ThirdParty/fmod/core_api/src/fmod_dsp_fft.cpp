// Address: 0x21ecfa0 | Name: _ZN4FMOD19windowfunc_triangleEPNS_6DSPFFTEf
float __fastcall FMOD::windowfunc_triangle(FMOD::DSPFFT *fft, float a2, float percent)
{
  float v3; // xmm1_4

  v3 = (float)(a2 + a2) - 1.0;
  if ( v3 < 0.0 )
    v3 = -v3;
  return 1.0 - v3;
}


// Address: 0x21ecfd0 | Name: _ZN4FMOD15windowfunc_rectEPNS_6DSPFFTEf
float __fastcall FMOD::windowfunc_rect(FMOD::DSPFFT *fft, double a2, float percent)
{
  return 1.0;
}


// Address: 0x21ecfe0 | Name: _ZN4FMOD18windowfunc_hammingEPNS_6DSPFFTEf
float __fastcall FMOD::windowfunc_hamming(FMOD::DSPFFT *fft, float a2, float percent)
{
  signed int v3; // eax
  int v4; // edx
  float v5; // xmm0_4

  v3 = abs32((int)(float)(a2 * 32768.0)) & 0x7FFF;
  v4 = v3 >> 13;
  if ( v3 >> 13 == 2 )
  {
    v5 = -*((float *)fft + v3 - 16079);
  }
  else if ( v4 == 3 )
  {
    v5 = *((float *)fft + 0x7FFF - v3 + 305);
  }
  else if ( v4 == 1 )
  {
    v5 = -*((float *)fft + 0x3FFF - v3 + 305);
  }
  else
  {
    v5 = *((float *)fft + v3 + 305);
  }
  return 0.54000002 - (float)(0.46000001 * v5);
}


// Address: 0x21ed090 | Name: _ZN4FMOD18windowfunc_hanningEPNS_6DSPFFTEf
float __fastcall FMOD::windowfunc_hanning(FMOD::DSPFFT *fft, float a2, float percent)
{
  signed int v3; // eax
  int v4; // edx
  float v5; // xmm1_4

  v3 = abs32((int)(float)(a2 * 32768.0)) & 0x7FFF;
  v4 = v3 >> 13;
  if ( v3 >> 13 == 2 )
  {
    v5 = -*((float *)fft + v3 - 16079);
  }
  else if ( v4 == 3 )
  {
    v5 = *((float *)fft + 0x7FFF - v3 + 305);
  }
  else if ( v4 == 1 )
  {
    v5 = -*((float *)fft + 0x3FFF - v3 + 305);
  }
  else
  {
    v5 = *((float *)fft + v3 + 305);
  }
  return (float)(1.0 - v5) * 0.5;
}


// Address: 0x21ed140 | Name: _ZN4FMOD19windowfunc_blackmanEPNS_6DSPFFTEf
float __fastcall FMOD::windowfunc_blackman(FMOD::DSPFFT *fft, float a2, float percent)
{
  signed int v3; // eax
  int v4; // edx
  float v5; // xmm1_4
  float v6; // xmm1_4
  signed int v7; // eax
  int v8; // edx
  float v9; // xmm0_4

  v3 = abs32((int)(float)(a2 * 32768.0)) & 0x7FFF;
  v4 = v3 >> 13;
  if ( v3 >> 13 == 2 )
  {
    v5 = -*((float *)fft + v3 - 16079);
  }
  else if ( v4 == 3 )
  {
    v5 = *((float *)fft + 0x7FFF - v3 + 305);
  }
  else if ( v4 == 1 )
  {
    v5 = -*((float *)fft + 0x3FFF - v3 + 305);
  }
  else
  {
    v5 = *((float *)fft + v3 + 305);
  }
  v6 = 0.41999999 - (float)(0.5 * v5);
  v7 = abs32((int)(float)((float)(a2 + a2) * 32768.0)) & 0x7FFF;
  v8 = v7 >> 13;
  if ( v7 >> 13 == 2 )
    return (float)((float)-*((float *)fft + v7 - 16079) * 0.079999998) + v6;
  if ( v8 == 3 )
    return (float)(*((float *)fft + 0x7FFF - v7 + 305) * 0.079999998) + v6;
  if ( v8 == 1 )
    v9 = -*((float *)fft + 0x3FFF - v7 + 305);
  else
    v9 = *((float *)fft + v7 + 305);
  return (float)(v9 * 0.079999998) + v6;
}


// Address: 0x21ed2d0 | Name: _ZN4FMOD25windowfunc_blackmanharrisEPNS_6DSPFFTEf
float __fastcall FMOD::windowfunc_blackmanharris(FMOD::DSPFFT *fft, float a2, float percent)
{
  signed int v3; // eax
  int v4; // edx
  float v5; // xmm1_4
  float v6; // xmm3_4
  signed int v7; // eax
  int v8; // edx
  float v9; // xmm1_4
  float v10; // xmm1_4
  signed int v11; // eax
  int v12; // edx

  v3 = abs32((int)(float)(a2 * 32768.0)) & 0x7FFF;
  v4 = v3 >> 13;
  if ( v3 >> 13 == 2 )
  {
    v5 = -*((float *)fft + v3 - 16079);
  }
  else if ( v4 == 3 )
  {
    v5 = *((float *)fft + 0x7FFF - v3 + 305);
  }
  else if ( v4 == 1 )
  {
    v5 = -*((float *)fft + 0x3FFF - v3 + 305);
  }
  else
  {
    v5 = *((float *)fft + v3 + 305);
  }
  v6 = 0.35874999 - (float)(v5 * 0.48829001);
  v7 = abs32((int)(float)((float)(a2 + a2) * 32768.0)) & 0x7FFF;
  v8 = v7 >> 13;
  if ( v7 >> 13 == 2 )
  {
    v9 = -*((float *)fft + v7 - 16079);
  }
  else if ( v8 == 3 )
  {
    v9 = *((float *)fft + 0x7FFF - v7 + 305);
  }
  else if ( v8 == 1 )
  {
    v9 = -*((float *)fft + 0x3FFF - v7 + 305);
  }
  else
  {
    v9 = *((float *)fft + v7 + 305);
  }
  v10 = (float)(v9 * 0.14128) + v6;
  v11 = abs32((int)(float)((float)(a2 * 3.0) * 32768.0)) & 0x7FFF;
  v12 = v11 >> 13;
  if ( v11 >> 13 == 2 )
    return v10 - (float)((float)-*((float *)fft + v11 - 16079) * 0.01168);
  if ( v12 == 3 )
    return v10 - (float)(*((float *)fft + 0x7FFF - v11 + 305) * 0.01168);
  if ( v12 == 1 )
    return v10 - (float)((float)-*((float *)fft + 0x3FFF - v11 + 305) * 0.01168);
  else
    return v10 - (float)(*((float *)fft + v11 + 305) * 0.01168);
}


// Address: 0x21ed530 | Name: _ZN4FMOD6DSPFFT16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPFFT::getDescriptionEx()
{
  memset(&stru_2ADB9A0, 0, sizeof(stru_2ADB9A0));
  stru_2ADB9A0.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2ADB9A0.name, "Size", 16);
  FMOD_strcpy_safe(stru_2ADB9A0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2ADB9A0.floatdesc.min = 0x400000000080LL;
  stru_2ADB9A0.description = "FFT Window size. 128, 256, 512, 1024, 2048, 4096, 8192, 16384.  Default = ";
  memset(&stru_2ADB940, 0, sizeof(stru_2ADB940));
  *(_OWORD *)(&stru_2ADB9A0.datadesc + 2) = 0x800u;
  stru_2ADB940.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2ADB940.name, "Type", 16);
  FMOD_strcpy_safe(stru_2ADB940.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2ADB940.floatdesc.min = 0x500000000LL;
  stru_2ADB940.description = "FFT window shape. 0 = rect, 1 = tri, 2 = hamming, 3 = hanning, 4 = blackman, 5 = blackman h"
                             "arris.  Default = 2.";
  memset(&stru_2ADB8E0, 0, sizeof(stru_2ADB8E0));
  *(_OWORD *)(&stru_2ADB940.datadesc + 2) = 2u;
  stru_2ADB8E0.type = FMOD_DSP_PARAMETER_TYPE_DATA;
  FMOD_strcpy_safe(stru_2ADB8E0.name, "Spectrum Data", 16);
  FMOD_strcpy_safe(stru_2ADB8E0.label, (const char *)&uri_string, 16);
  stru_2ADB8E0.intdesc.min = -4;
  stru_2ADB8E0.description = "Spectrum data";
  memset(&stru_2ADB880, 0, sizeof(stru_2ADB880));
  FMOD_strcpy_safe(stru_2ADB880.name, "Dominant Freq", 16);
  FMOD_strcpy_safe(stru_2ADB880.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2ADB880.floatdesc.min = 0x40A0000000000000LL;
  stru_2ADB880.intdesc.defaultval = 0x40000000;
  stru_2ADB880.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2ADB880.description = "Dominant frequency.";
  *(&stru_2ADB840.mHandle + 1) = 29;
  stru_2ADB840.mSize = 34000;
  stru_2ADB840.mDescription = &stru_286B440;
  return &stru_2ADB840;
}


// Address: 0x21ed760 | Name: _ZN4FMOD6DSPFFT7processEi
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::process(FMOD::DSPFFT *const this, int bits)
{
  int v2; // r10d
  int v3; // r8d
  float v4; // xmm9_4
  int v5; // ebx
  int v6; // esi
  int i; // r9d
  int v8; // r14d
  int v9; // ecx
  unsigned int v10; // eax
  int v11; // edx
  int v12; // r15d
  int v13; // edx
  float v14; // xmm0_4
  signed int v15; // eax
  int v16; // edx
  float v17; // xmm5_4
  signed int v18; // eax
  int v19; // edx
  float v20; // xmm6_4
  float v21; // xmm6_4
  __int64 v22; // rax
  int v23; // r15d
  unsigned int v24; // r14d
  float *v25; // rdx
  float v26; // xmm3_4
  float *v27; // rcx
  float v28; // xmm2_4
  float v29; // xmm1_4
  float v30; // xmm0_4
  int v32; // [rsp+0h] [rbp-38h]

  v2 = 1;
  v3 = (1 << bits) / 2;
  v32 = 0;
  v4 = 1.0 / (float)(1 << bits);
  if ( bits > 0 )
  {
    v5 = bits - 1;
    do
    {
      if ( v2 > 0 )
      {
        v6 = v3;
        for ( i = 0; i != v2; ++i )
        {
          v8 = v5;
          v9 = v6 - v3;
          v10 = (v6 - v3) / v3;
          v11 = 0;
          do
          {
            v12 = 2 * v11;
            --v8;
            v13 = v10 & 1;
            v10 >>= 1;
            v11 = v12 | v13;
          }
          while ( v8 != -1 );
          v14 = (float)v11 * v4;
          v15 = abs32((int)(float)(v14 * 32768.0)) & 0x7FFF;
          v16 = v15 >> 13;
          if ( v15 >> 13 == 2 )
          {
            v17 = -*((float *)this + v15 - 16079);
          }
          else if ( v16 == 3 )
          {
            v17 = *((float *)this + 0x7FFF - v15 + 305);
          }
          else if ( v16 == 1 )
          {
            v17 = -*((float *)this + 0x3FFF - v15 + 305);
          }
          else
          {
            v17 = *((float *)this + v15 + 305);
          }
          v18 = abs32((int)(float)((float)(v14 - 0.25) * 32768.0)) & 0x7FFF;
          v19 = v18 >> 13;
          if ( v18 >> 13 == 2 )
          {
            v20 = -*((float *)this + v18 - 16079);
          }
          else if ( v19 == 3 )
          {
            v20 = *((float *)this + 0x7FFF - v18 + 305);
          }
          else if ( v19 == 1 )
          {
            v20 = -*((float *)this + 0x3FFF - v18 + 305);
          }
          else
          {
            v20 = *((float *)this + v18 + 305);
          }
          v21 = -v20;
          if ( v9 < v6 )
          {
            v22 = *((_QWORD *)this + 66);
            v23 = v9 + 2 * v3;
            v24 = v6;
            v25 = (float *)(v22 + 8LL * v9);
            do
            {
              v26 = *v25;
              v27 = (float *)(v22 + 8LL * v24);
              v28 = v25[1];
              ++v24;
              v25 += 2;
              v29 = (float)(*v27 * v17) - (float)(v27[1] * v21);
              v30 = (float)(*v27 * v21) + (float)(v27[1] * v17);
              *(v25 - 2) = v26 + v29;
              *(v25 - 1) = v28 + v30;
              *v27 = v26 - v29;
              v27[1] = v28 - v30;
            }
            while ( v23 != v24 );
          }
          v6 += 2 * v3;
        }
      }
      ++v32;
      v3 = (unsigned int)v3 >> 1;
      v2 *= 2;
    }
    while ( v32 != bits );
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21eda30 | Name: _ZN4FMOD6DSPFFT11getSpectrumEPfjjS1_i19FMOD_DSP_FFT_WINDOWiS1_
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::getSpectrum(
        FMOD::DSPFFT *const this,
        float *pcmbuffer,
        unsigned int pcmposition,
        unsigned int pcmlength,
        float *spectrum,
        int length,
        FMOD_DSP_FFT_WINDOW windowtype,
        int rate,
        float *dominant)
{
  int v9; // eax
  int v11; // ecx
  float v12; // xmm1_4
  unsigned int v13; // eax
  int v14; // esi
  FMOD_COMPLEX *v15; // r15
  unsigned int v16; // ebp
  unsigned int v17; // r14d
  float (__fastcall *v18)(FMOD::DSPFFT *, float, float); // r12
  float v19; // xmm7_4
  float v20; // xmm0_4
  int v21; // r13d
  float *v22; // r12
  unsigned int v23; // ebp
  unsigned int v24; // edx
  int v25; // ecx
  int v26; // eax
  int v27; // esi
  int v28; // eax
  __int64 v29; // rax
  __m128 v30; // xmm0
  __m128 v31; // xmm1
  float v32; // xmm2_4
  __int64 v33; // rax
  float v34; // xmm3_4
  float v35; // xmm1_4
  float delta; // [rsp+8h] [rbp-70h]
  int size_0; // [rsp+Ch] [rbp-6Ch]
  FMOD_COMPLEX *fftbuff; // [rsp+10h] [rbp-68h]
  unsigned int pcmpositiona; // [rsp+1Ch] [rbp-5Ch]
  int size_1; // [rsp+20h] [rbp-58h]
  int v45; // [rsp+3Ch] [rbp-3Ch]

  v9 = length;
  if ( length <= 1 )
  {
    fftbuff = (FMOD_COMPLEX *)*((_QWORD *)this + 66);
    delta = 1.0 / (float)length;
    if ( !length )
    {
      FMOD::DSPFFT::process(this, 0);
      goto LABEL_35;
    }
    v45 = 0;
  }
  else
  {
    v11 = 0;
    do
    {
      v9 >>= 1;
      ++v11;
    }
    while ( v9 > 1 );
    v45 = v11;
    fftbuff = (FMOD_COMPLEX *)*((_QWORD *)this + 66);
    delta = 1.0 / (float)length;
  }
  v12 = 0.0;
  size_0 = length;
  v13 = pcmposition + length;
  if ( pcmposition + length <= pcmlength )
    goto LABEL_15;
LABEL_6:
  pcmpositiona = pcmlength;
  v14 = size_0 - (pcmlength - pcmposition);
  size_0 = pcmlength - pcmposition;
  for ( size_1 = v14; ; size_1 = 0 )
  {
    if ( size_0 > 0 )
    {
      v15 = fftbuff;
      v16 = size_0 + pcmposition;
      v17 = pcmposition;
      v18 = (float (__fastcall *)(FMOD::DSPFFT *, float, float))funcs_21EDB3B[windowtype];
      do
      {
        v19 = pcmbuffer[v17++];
        ++v15;
        v20 = v18(this, v12, v12);
        v15[-1].imag = 0.0000000099999999;
        v12 = v12 + delta;
        v15[-1].real = (float)(v20 * v19) * delta;
      }
      while ( v17 != v16 );
      fftbuff += (unsigned int)(size_0 - 1) + 1;
    }
    pcmposition = 0;
    if ( pcmlength > pcmpositiona )
      pcmposition = pcmpositiona;
    if ( !size_1 )
      break;
    size_0 = size_1;
    v13 = pcmposition + size_1;
    if ( pcmposition + size_1 > pcmlength )
      goto LABEL_6;
LABEL_15:
    pcmpositiona = v13;
  }
  FMOD::DSPFFT::process(this, v45);
  v21 = length / 2 - 1;
  if ( v21 <= 0 )
  {
LABEL_35:
    if ( !dominant )
      return FMOD_RESULT::FMOD_OK_0;
LABEL_29:
    *dominant = 0.0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  v22 = spectrum;
  v23 = 0;
  do
  {
    v24 = v23;
    if ( v45 )
    {
      v25 = v45 - 1;
      v26 = 0;
      do
      {
        v27 = 2 * v26;
        --v25;
        v28 = v24 & 1;
        v24 >>= 1;
        v26 = v27 | v28;
      }
      while ( v25 != -1 );
      v29 = 8LL * v26;
    }
    else
    {
      v29 = 0;
    }
    v30.m128_f32[0] = fsqrt(
                        (float)(*(float *)(*((_QWORD *)this + 66) + v29) * *(float *)(*((_QWORD *)this + 66) + v29))
                      + (float)(*(float *)(*((_QWORD *)this + 66) + v29 + 4)
                              * *(float *)(*((_QWORD *)this + 66) + v29 + 4)))
                    * 2.5;
    ++v23;
    ++v22;
    v31 = _mm_cmpge_ss((__m128)0x3F800000u, v30);
    *((_DWORD *)v22 - 1) = _mm_andnot_ps(v31, (__m128)0x3F800000u).m128_u32[0] | v30.m128_i32[0] & v31.m128_i32[0];
  }
  while ( v23 != v21 );
  if ( dominant )
  {
    v32 = 0.0;
    v33 = 0;
    v34 = 0.0;
    do
    {
      v35 = spectrum[v33];
      if ( v35 > 0.000099999997 )
      {
        v32 = v32 + v35;
        v34 = v34 + (float)((float)((float)((float)(int)v33 * (float)((float)rate * 0.5)) / (float)v21) * v35);
      }
      ++v33;
    }
    while ( v21 > (int)v33 );
    if ( v32 > 0.001 )
    {
      *dominant = v34 / v32;
      return FMOD_RESULT::FMOD_OK_0;
    }
    goto LABEL_29;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21eddc0 | Name: _ZN4FMOD6DSPFFT22updateBufferAllocationEii
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::updateBufferAllocation(FMOD::DSPFFT *const this, int channels, int windowSize)
{
  char *v6; // rbx
  char *v7; // rbp
  void *v8; // rax
  FMOD::SystemI *v10; // rdi
  unsigned int v11; // eax
  void *v12; // rsi
  unsigned int v13; // edx
  void *v14; // rax
  void *v15; // rsi
  void *v16; // rax
  bool channelsChanged; // [rsp+Eh] [rbp-4Ah]
  bool windowSizeChanged; // [rsp+Fh] [rbp-49h]
  unsigned int bufferSize[15]; // [rsp+1Ch] [rbp-3Ch] BYREF

  channelsChanged = *((_DWORD *)this + 272) != channels;
  windowSizeChanged = *((_DWORD *)this + 271) != windowSize;
  if ( channels > 0 )
  {
    v6 = (char *)this + 544;
    v7 = (char *)this + 8 * (unsigned int)(channels - 1) + 552;
    do
    {
      while ( *(_QWORD *)v6 )
      {
        v6 += 8;
        if ( v6 == v7 )
          goto LABEL_7;
      }
      v8 = FMOD::MemPool::calloc(off_286F358->gSystemMemPool, 65552, "../../../core_api/src/fmod_dsp_fft.cpp", 496, 0);
      *(_QWORD *)v6 = v8;
      if ( !v8 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      v6 += 8;
      *((_QWORD *)v6 + 33) = ((unsigned __int64)v8 + 15) & 0xFFFFFFFFFFFFFFF0LL;
    }
    while ( v6 != v7 );
  }
LABEL_7:
  if ( !channelsChanged && !windowSizeChanged )
    return FMOD_RESULT::FMOD_OK_0;
  v10 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  bufferSize[0] = 0;
  FMOD::SystemI::getDSPBufferSize(v10, bufferSize, 0);
  v11 = bufferSize[0];
  v12 = (void *)*((_QWORD *)this + 100);
  if ( windowSize >= bufferSize[0] )
    v11 = windowSize;
  bufferSize[0] = v11;
  if ( v12 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v12, "../../../core_api/src/fmod_dsp_fft.cpp", 513);
    v13 = bufferSize[0];
    *((_QWORD *)this + 100) = 0;
  }
  else
  {
    v13 = v11;
  }
  v14 = FMOD::MemPool::calloc(
          off_286F358->gSystemMemPool,
          v13 * 4 * channels + 16,
          "../../../core_api/src/fmod_dsp_fft.cpp",
          515,
          0);
  *((_QWORD *)this + 100) = v14;
  if ( v14 )
  {
    *((_DWORD *)this + 270) = 0;
    *((_DWORD *)this + 272) = channels;
    *((_QWORD *)this + 134) = ((unsigned __int64)v14 + 15) & 0xFFFFFFFFFFFFFFF0LL;
    *((_DWORD *)this + 271) = bufferSize[0];
    if ( windowSizeChanged )
    {
      v15 = (void *)*((_QWORD *)this + 67);
      if ( v15 )
      {
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v15, "../../../core_api/src/fmod_dsp_fft.cpp", 532);
        *((_QWORD *)this + 67) = 0;
      }
      v16 = FMOD::MemPool::calloc(
              off_286F358->gSystemMemPool,
              8 * windowSize + 16,
              "../../../core_api/src/fmod_dsp_fft.cpp",
              534,
              0);
      *((_QWORD *)this + 67) = v16;
      if ( !v16 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      *((_QWORD *)this + 66) = ((unsigned __int64)v16 + 15) & 0xFFFFFFFFFFFFFFF0LL;
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  return FMOD_RESULT::FMOD_ERR_MEMORY_0;
}


// Address: 0x21ee030 | Name: _ZN4FMOD6DSPFFT14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::createInternal(FMOD::DSPFFT *const this)
{
  float v1; // xmm0_4
  float *v2; // rbp
  int i; // ebx
  __int64 v4; // rax
  __int64 v5; // rbp
  int v6; // ebx
  _DWORD *v7; // rdx
  FMOD_RESULT_0 result; // eax

  v1 = 1.0;
  v2 = (float *)((char *)this + 1220);
  for ( i = 0; ; v1 = cosf((float)((float)i * 1.5707964) * 0.00012207031) )
  {
    ++i;
    *v2++ = v1;
    if ( i == 0x2000 )
      break;
  }
  v4 = *((_QWORD *)this + 30);
  v5 = 0;
  v6 = 0;
  if ( *(int *)(v4 + 96) <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    while ( 1 )
    {
      v7 = *(_DWORD **)(*(_QWORD *)(v4 + 104) + v5);
      if ( *v7 == 1 )
        break;
      ++v6;
      v5 += 8;
      if ( *(_DWORD *)(v4 + 96) <= v6 )
        return FMOD_RESULT::FMOD_OK_0;
    }
    result = FMOD::DSPI::setParameterInt((FMOD::DSPI *const)this, v6, v7[14]);
    if ( result )
      break;
    v4 = *((_QWORD *)this + 30);
    ++v6;
    v5 += 8;
    if ( *(_DWORD *)(v4 + 96) <= v6 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21ee0e0 | Name: _ZN4FMOD6DSPFFT14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPFFT::createInternal((FMOD::DSPFFT *const)dsp_state->instance);
}


// Address: 0x21ee0f0 | Name: _ZN4FMOD6DSPFFT15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::releaseInternal(FMOD::DSPFFT *const this)
{
  void *v1; // rsi
  void *v2; // rsi
  __int64 i; // rbx
  void *v4; // rsi

  v1 = (void *)*((_QWORD *)this + 100);
  if ( v1 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_dsp_fft.cpp", 596);
    *((_QWORD *)this + 100) = 0;
  }
  v2 = (void *)*((_QWORD *)this + 67);
  *((_QWORD *)this + 134) = 0;
  if ( v2 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v2, "../../../core_api/src/fmod_dsp_fft.cpp", 600);
    *((_QWORD *)this + 67) = 0;
  }
  *((_QWORD *)this + 66) = 0;
  for ( i = 0; i != 256; i += 8 )
  {
    v4 = *(void **)((char *)this + i + 544);
    if ( v4 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v4, "../../../core_api/src/fmod_dsp_fft.cpp", 606);
      *(_QWORD *)((char *)this + i + 544) = 0;
    }
    *(_QWORD *)((char *)this + i + 816) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ee1f0 | Name: _ZN4FMOD6DSPFFT15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPFFT::releaseInternal((FMOD::DSPFFT *const)dsp_state->instance);
}


// Address: 0x21ee200 | Name: _ZN4FMOD6DSPFFT13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::resetInternal(FMOD::DSPFFT *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ee210 | Name: _ZN4FMOD6DSPFFT13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPFFT::resetInternal((FMOD::DSPFFT *const)dsp_state->instance);
}


// Address: 0x21ee220 | Name: _ZN4FMOD6DSPFFT12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::readInternal(
        FMOD::DSPFFT *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  int v8; // r15d
  FMOD_RESULT_0 result; // eax
  unsigned int v10; // r10d
  signed int v11; // ecx
  unsigned __int64 v12; // r12
  int v13; // r13d
  __int64 v14; // r15
  int v15; // edx
  signed int v16; // r11d
  float *v17; // rbp
  float *v18; // rdi
  int v19; // r9d
  __int64 i; // rsi
  int v21; // xmm0_4
  int v22; // ebp
  signed int v23; // ebp
  signed int v24; // ebp
  int v25; // r15d
  __int64 v26; // r12
  __int64 v27; // rax
  float *v28; // r8
  int posa; // [rsp+18h] [rbp-70h]
  int windowsize; // [rsp+30h] [rbp-58h]
  FMOD_DSP_FFT_WINDOW windowtype; // [rsp+34h] [rbp-54h]
  float dom[15]; // [rsp+4Ch] [rbp-3Ch] BYREF

  v8 = *((_DWORD *)this + 8497);
  windowsize = v8;
  windowtype = *((_DWORD *)this + 8498);
  memcpy_0(outbuffer, inbuffer, 4LL * length * inchannels);
  result = FMOD::DSPFFT::updateBufferAllocation(this, inchannels, v8);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v10 = length;
    if ( inchannels <= 0 )
    {
      v22 = *((_DWORD *)this + 270);
      v11 = *((_DWORD *)this + 271);
    }
    else
    {
      v11 = *((_DWORD *)this + 271);
      v12 = 0;
      v13 = 0;
      posa = *((_DWORD *)this + 270);
      do
      {
        if ( v10 )
        {
          v14 = *((_QWORD *)this + 134);
          v15 = posa;
          v16 = v10;
          v17 = inbuffer;
          do
          {
            v18 = &v17[v12 / 4];
            v19 = v11 - v15;
            if ( v11 - v15 > v16 )
              v19 = v16;
            for ( i = 0; v19 > (int)i; ++i )
            {
              v21 = *(_DWORD *)v18;
              v18 += inchannels;
              *(_DWORD *)(v14 + 4LL * (v15 + v13) + 4 * i) = v21;
            }
            v17 += inchannels * v19;
            v15 = (v15 + v19) % v11;
            v16 -= v19;
          }
          while ( v16 );
        }
        v13 += v11;
        v12 += 4LL;
      }
      while ( v12 != 4LL * (unsigned int)(inchannels - 1) + 4 );
      v22 = posa;
    }
    v23 = v10 + v22;
    if ( v23 >= v11 )
      v23 -= v11;
    *((_DWORD *)this + 270) = v23;
    v24 = v23 - windowsize;
    if ( v24 < 0 )
      v24 += v11;
    v25 = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
    if ( inchannels > 0 )
    {
      v26 = 0;
      while ( 1 )
      {
        v27 = *((_QWORD *)this + 134);
        v28 = (float *)*((_QWORD *)this + v26 + 102);
        dom[0] = 0.0;
        FMOD::DSPFFT::getSpectrum(
          this,
          (float *)(v27 + 4LL * (int)v26 * v11),
          v24,
          v11,
          v28,
          windowsize,
          windowtype,
          v25,
          dom);
        *((float *)this + v26++ + 273) = dom[0];
        if ( v26 == (unsigned int)(inchannels - 1) + 1LL )
          break;
        v11 = *((_DWORD *)this + 271);
      }
    }
    *((_DWORD *)this + 203) = inchannels;
    *((_DWORD *)this + 202) = windowsize;
    *outchannels = inchannels;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21ee460 | Name: _ZN4FMOD6DSPFFT12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPFFT::readInternal(
           (FMOD::DSPFFT *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x21ee470 | Name: _ZN4FMOD6DSPFFT23setParameterIntInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::setParameterIntInternal(FMOD::DSPFFT *const this, int index, int value)
{
  FMOD_RESULT_0 result; // eax

  if ( index )
  {
    if ( index == 1 )
    {
      *((_DWORD *)this + 8498) = value;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
  }
  else if ( value == 128
         || value == 256
         || value == 512
         || value == 1024
         || value == 2048
         || value == 4096
         || value == 0x2000
         || (result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0, value == 0x4000) )
  {
    *((_DWORD *)this + 8497) = value;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21ee4f0 | Name: _ZN4FMOD6DSPFFT23setParameterIntCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::setParameterIntCallback(FMOD_DSP_STATE *dsp_state, int index, int value)
{
  return FMOD::DSPFFT::setParameterIntInternal((FMOD::DSPFFT *const)dsp_state->instance, index, value);
}


// Address: 0x21ee500 | Name: _ZN4FMOD6DSPFFT23getParameterIntInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::getParameterIntInternal(
        FMOD::DSPFFT *const this,
        int index,
        int *value,
        char *valuestr)
{
  int v4; // eax
  int v5; // edx

  if ( !index )
  {
    *value = *((_DWORD *)this + 8497);
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    v5 = *((_DWORD *)this + 8497);
    goto LABEL_5;
  }
  if ( index == 1 )
  {
    v4 = *((_DWORD *)this + 8498);
    *value = v4;
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    v5 = v4;
LABEL_5:
    sprintf(valuestr, "%d", v5);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21ee560 | Name: _ZN4FMOD6DSPFFT23getParameterIntCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::getParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int *value,
        char *valuestr)
{
  return FMOD::DSPFFT::getParameterIntInternal((FMOD::DSPFFT *const)dsp_state->instance, index, value, valuestr);
}


// Address: 0x21ee570 | Name: _ZN4FMOD6DSPFFT25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::getParameterFloatInternal(
        FMOD::DSPFFT *const this,
        int index,
        float *value,
        char *valuestr)
{
  FMOD_RESULT_0 v4; // ebx

  v4 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index != 3 )
    return v4;
  v4 = FMOD_RESULT::FMOD_OK_0;
  *value = *((float *)this + 273);
  if ( !valuestr )
    return v4;
  sprintf(valuestr, "%.02f", *((float *)this + 273));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ee5c0 | Name: _ZN4FMOD6DSPFFT25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPFFT::getParameterFloatInternal((FMOD::DSPFFT *const)dsp_state->instance, index, value, valuestr);
}


// Address: 0x21ee5d0 | Name: _ZN4FMOD6DSPFFT24getParameterDataInternalEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::getParameterDataInternal(
        FMOD::DSPFFT *const this,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index == 2 )
  {
    result = FMOD_RESULT::FMOD_OK_0;
    *data = (char *)this + 808;
    *length = 264;
    if ( valuestr )
      strcpy(valuestr, "spectrum data");
  }
  return result;
}


// Address: 0x21ee620 | Name: _ZN4FMOD6DSPFFT24getParameterDataCallbackEP14FMOD_DSP_STATEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPFFT::getParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  return FMOD::DSPFFT::getParameterDataInternal((FMOD::DSPFFT *const)dsp_state->instance, index, data, length, valuestr);
}


