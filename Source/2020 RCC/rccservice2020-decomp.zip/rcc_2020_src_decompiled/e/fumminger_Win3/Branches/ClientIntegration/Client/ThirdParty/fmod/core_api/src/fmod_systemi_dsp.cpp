// Address: 0x2239c70 | Name: _ZN4FMOD7SystemI9createDSPEPNS_23FMOD_DSP_DESCRIPTION_EXEP20FMOD_DSP_DESCRIPTIONPPNS_4DSPIEb
FMOD_RESULT_0 __fastcall FMOD::SystemI::createDSP(
        FMOD::SystemI *const this,
        FMOD::FMOD_DSP_DESCRIPTION_EX *description_ex,
        FMOD_DSP_DESCRIPTION_0 *description,
        FMOD::DSPI **dsp,
        bool allocate)
{
  FMOD_RESULT_0 result; // eax

  if ( !dsp )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( allocate )
    *dsp = 0;
  if ( !description_ex )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  result = FMOD::PluginFactory::createDSP(this->mPluginFactory, description_ex, description, dsp);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    (*dsp)->mSystem = this;
  return result;
}


// Address: 0x2239cd0 | Name: _ZN4FMOD7SystemI7stopDSPEPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::stopDSP(FMOD::SystemI *const this, FMOD::DSPI *dsp)
{
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD::ChannelI *p_mChannelUsedListHead; // rbp
  FMOD::SystemI *p_mNodePrev; // rbx
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::ChannelI *v6; // r15
  FMOD::DSPI *channeldsp; // [rsp+8h] [rbp-40h] BYREF

  mNodeNext = this->mChannelUsedListHead.mNodeNext;
  if ( mNodeNext )
  {
    p_mChannelUsedListHead = &this->mChannelUsedListHead;
    p_mNodePrev = (FMOD::SystemI *)&mNodeNext[-16].mNodePrev;
    if ( p_mNodePrev == (FMOD::SystemI *)&this->mChannelUsedListHead )
      return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    p_mChannelUsedListHead = &this->mChannelUsedListHead;
    p_mNodePrev = 0;
  }
  while ( 1 )
  {
    mNodePrev = p_mNodePrev->mSoundListHead.mSoundGroupNode.mNodePrev;
    v6 = (FMOD::ChannelI *)&mNodePrev[-16].mNodePrev;
    if ( !mNodePrev )
      v6 = 0;
    FMOD::ChannelI::getCurrentDSP((FMOD::ChannelI *const)p_mNodePrev, &channeldsp);
    if ( channeldsp == dsp )
      (*((void (__fastcall **)(FMOD::SystemI *))p_mNodePrev->_vptr_SystemI + 1))(p_mNodePrev);
    if ( v6 == p_mChannelUsedListHead )
      break;
    p_mNodePrev = (FMOD::SystemI *)v6;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2239d70 | Name: _ZN4FMOD7SystemI19expandDSPBufferPoolEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::expandDSPBufferPool(FMOD::SystemI *const this)
{
  int DSPBufferPoolSize; // r13d
  signed int v2; // ebp
  int v3; // r12d
  FMOD::LinkedListNode *v4; // rax
  FMOD_RESULT_0 v5; // r10d
  FMOD::LinkedListNode *v6; // rax
  FMOD::DSPMemory *v7; // r14
  FMOD::DSPMemory *v8; // rax
  int v9; // r13d
  __int64 v10; // rsi
  int v11; // edx
  char *v12; // rax
  FMOD::LinkedListNode *s; // [rsp+0h] [rbp-48h]

  DSPBufferPoolSize = this->mAdvancedSettings.DSPBufferPoolSize;
  v2 = this->mDSPBlockSize * this->mDSPMemoryChannels + 8;
  v3 = DSPBufferPoolSize * v2;
  v4 = (FMOD::LinkedListNode *)FMOD::MemPool::alloc(
                                 &this->mDSPLevelsPool,
                                 4 * (DSPBufferPoolSize * v2 + 128),
                                 (const char *)&uri_string,
                                 0,
                                 0,
                                 0);
  v5 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  s = v4;
  if ( v4 )
  {
    v6 = (FMOD::LinkedListNode *)FMOD::MemPool::calloc(
                                   off_286F358->gSystemMemPool,
                                   32,
                                   "../../../core_api/src/fmod_systemi_dsp.cpp",
                                   123,
                                   0);
    if ( v6 )
    {
      v6->mNodePrev = v6;
      v6->mNodeData = 0;
      v6[1].mNodeNext = s;
      v7 = (FMOD::DSPMemory *)(((unsigned __int64)&s[5].mNodeNext + 7) & 0xFFFFFFFFFFFFFF80LL);
      v6->mNodePrev = this->mDSPMemoryBlocks.mNodePrev;
      v6->mNodeNext = (FMOD::LinkedListNode *)((char *)&stru_10758 + (_QWORD)this);
      this->mDSPMemoryBlocks.mNodePrev = v6;
      v6->mNodePrev->mNodeNext = v6;
      memset(s, 0, 4LL * (DSPBufferPoolSize * v2 + 128));
      if ( DSPBufferPoolSize > 1 )
      {
        v8 = v7 + 1;
        v9 = DSPBufferPoolSize - 1;
        v10 = 4LL * v2;
        v11 = 0;
        do
        {
          ++v11;
          v8[-1].mRefCount = 0;
          v8[-1].mBuffer = (float *)v8;
          v8[-1].mNext = (FMOD::DSPMemory *)((char *)v8 + v10 - 32);
          v8 = (FMOD::DSPMemory *)((char *)v8 + v10);
        }
        while ( v11 != v9 );
      }
      v5 = FMOD_RESULT::FMOD_OK_0;
      v12 = (char *)v7 + 4 * (v3 - v2);
      *(_QWORD *)v12 = this->mDSPMemoryFreeHead;
      *((_DWORD *)v12 + 2) = 0;
      *((_QWORD *)v12 + 2) = v12 + 32;
      this->mDSPMemoryFreeHead = v7;
    }
    else
    {
      FMOD::MemPool::free(&this->mDSPLevelsPool, s, (const char *)&uri_string, 0);
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
  }
  return v5;
}


// Address: 0x2239f10 | Name: _ZN4FMOD7SystemI20releaseDSPBufferPoolEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::releaseDSPBufferPool(FMOD::SystemI *const this)
{
  Elf64_Rela *v1; // rbx
  Elf64_Rela *r_offset; // rbp
  _QWORD *r_info; // rax
  FMOD::Global *v4; // rax

  v1 = *(Elf64_Rela **)((char *)&stru_10758.r_offset + (_QWORD)this);
  if ( v1 != (Elf64_Rela *)((char *)&stru_10758 + (_QWORD)this) )
  {
    while ( 1 )
    {
      r_offset = (Elf64_Rela *)v1->r_offset;
      FMOD::MemPool::free(&this->mDSPLevelsPool, (void *)v1[1].r_offset, (const char *)&uri_string, 0);
      r_info = (_QWORD *)v1->r_info;
      *r_info = v1->r_offset;
      *(_QWORD *)(v1->r_offset + 8) = r_info;
      v4 = off_286F358;
      v1->r_info = (unsigned __int64)v1;
      v1->r_offset = (unsigned __int64)v1;
      FMOD::MemPool::free(v4->gSystemMemPool, v1, "../../../core_api/src/fmod_systemi_dsp.cpp", 179);
      if ( r_offset == (Elf64_Rela *)((char *)&stru_10758 + (_QWORD)this) )
        break;
      v1 = r_offset;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2239fb0 | Name: _ZN4FMOD7SystemI19expandFadePointPoolEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::expandFadePointPool(FMOD::SystemI *const this)
{
  FMOD::LinkedListNode *v2; // rax
  FMOD::LinkedListNode *v3; // rbp
  unsigned __int64 *v4; // rax
  unsigned __int64 *v5; // rdx
  int v6; // r8d
  unsigned __int64 v7; // rcx
  unsigned __int64 v8; // rdi

  v2 = (FMOD::LinkedListNode *)FMOD::MemPool::alloc(
                                 off_286F358->gSystemMemPool,
                                 24,
                                 "../../../core_api/src/fmod_systemi_dsp.cpp",
                                 203,
                                 0,
                                 0);
  v3 = v2;
  if ( !v2 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v2->mNodePrev = v2;
  v2->mNodeNext = v2;
  v2->mNodeData = 0;
  v4 = (unsigned __int64 *)FMOD::MemPool::calloc(
                             off_286F358->gSystemMemPool,
                             0x2000,
                             "../../../core_api/src/fmod_systemi_dsp.cpp",
                             209,
                             0);
  if ( v4 )
  {
    v5 = v4;
    v6 = 256;
    do
    {
      if ( v5 )
      {
        v5[1] = (unsigned __int64)v5;
        *v5 = (unsigned __int64)v5;
        v7 = (unsigned __int64)v5;
        v5[2] = 0;
      }
      else
      {
        v7 = 0;
      }
      v5[1] = v7;
      *v5 = v7;
      v5 += 4;
      *(v5 - 1) = -1;
      *(v5 - 2) = 0;
      v8 = *(unsigned __int64 *)((char *)&stru_107E8.r_offset + (_QWORD)this);
      *(v5 - 4) = (unsigned __int64)&this->mDSPFadePointHead;
      *(v5 - 3) = v8;
      *(unsigned __int64 *)((char *)&stru_107E8.r_offset + (_QWORD)this) = v7;
      --v6;
      *(_QWORD *)*(v5 - 3) = v7;
    }
    while ( v6 );
    v3->mNodeData = v4;
    v3->mNodePrev = this->mDSPFadePointMemoryHead.mNodePrev;
    v3->mNodeNext = (FMOD::LinkedListNode *)((char *)&stru_10800 + (_QWORD)this);
    this->mDSPFadePointMemoryHead.mNodePrev = v3;
    v3->mNodePrev->mNodeNext = v3;
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v3, "../../../core_api/src/fmod_systemi_dsp.cpp", 212);
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
}


// Address: 0x223a100 | Name: _ZN4FMOD7SystemI20releaseFadePointPoolEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::releaseFadePointPool(FMOD::SystemI *const this)
{
  FMOD::LinkedListNode *v1; // r13
  Elf64_Rela *v2; // rbx
  FMOD::LinkedListNode *r_offset; // rbp

  v1 = (FMOD::LinkedListNode *)((char *)&stru_10800 + (_QWORD)this);
  v2 = *(Elf64_Rela **)((char *)&stru_10800.r_offset + (_QWORD)this);
  this->mDSPFadePointHead.mNodePriority = -1;
  this->mDSPFadePointHead.mNodeNext = &this->mDSPFadePointHead;
  *(unsigned __int64 *)((char *)&stru_107E8.r_offset + (_QWORD)this) = (unsigned __int64)&this->mDSPFadePointHead;
  this->mDSPFadePointHead.mNodeData = 0;
  if ( v2 != (Elf64_Rela *)((char *)&stru_10800 + (_QWORD)this) )
  {
    while ( 1 )
    {
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        (void *)v2->r_addend,
        "../../../core_api/src/fmod_systemi_dsp.cpp",
        250);
      r_offset = (FMOD::LinkedListNode *)v2->r_offset;
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v2, "../../../core_api/src/fmod_systemi_dsp.cpp", 252);
      if ( r_offset == v1 )
        break;
      v2 = (Elf64_Rela *)r_offset;
    }
  }
  this->mDSPFadePointMemoryHead.mNodePrev = v1;
  *(unsigned __int64 *)((char *)&stru_10800.r_offset + (_QWORD)this) = (unsigned __int64)v1;
  this->mDSPFadePointMemoryHead.mNodeData = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223a1d0 | Name: _ZN4FMOD7SystemI13flushDSPQueueEb
FMOD_RESULT_0 __fastcall FMOD::SystemI::flushDSPQueue(FMOD::SystemI *const this, bool calledfrommainthread)
{
  float v2; // xmm1_4
  char v4; // r12
  int v5; // r14d
  char *v6; // rbx
  __int64 v8; // rax
  void (__fastcall *v9)(__int64, __int64, _QWORD, _QWORD); // r8
  __int64 v10; // rax
  void (__fastcall *v11)(__int64, __int64, _QWORD, _QWORD); // r8
  FMOD::LinkedListNode *v12; // rax
  int v13; // ecx
  int v14; // edx
  float *v15; // rsi
  __int64 v16; // rax
  void (__fastcall *v17)(__int64, __int64, char *, _QWORD); // r8
  __int64 v18; // rax
  FMOD::DSPConnectionI *connection; // [rsp+18h] [rbp-40h]

  if ( this )
  {
    v4 = 1;
    FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_DSPQUEUE);
  }
  else
  {
    v4 = 0;
  }
  if ( !this->mDSPQueueCmdFlushing && this->mDSPQueueCmdOffset > 0 )
  {
    this->mDSPQueueCmdFlushing = 1;
    if ( calledfrommainthread )
    {
      FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_DSPMIXER);
      if ( this->mDSPQueueCmdOffset <= 0 )
      {
        this->mDSPQueueCmdOffset = 0;
        this->mDSPQueueCmdFlushing = 0;
LABEL_10:
        FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPMIXER);
        goto LABEL_11;
      }
    }
    v5 = 0;
    do
    {
      v6 = &this->mDSPQueueBuffer[v5];
      switch ( *v6 )
      {
        case 0:
          FMOD::DSPI::addInputInternal(
            *(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(FMOD::DSPI **)&this->mDSPQueueBuffer[v5 + 16],
            0,
            *(FMOD_DSPCONNECTION_TYPE_0 *)&this->mDSPQueueBuffer[v5 + 32],
            0,
            *(FMOD::DSPConnectionI **)&this->mDSPQueueBuffer[v5 + 24],
            0);
          break;
        case 1:
          FMOD::DSPI::addInputInternal(
            *(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(FMOD::DSPI **)&this->mDSPQueueBuffer[v5 + 16],
            0,
            *(FMOD_DSPCONNECTION_TYPE_0 *)&this->mDSPQueueBuffer[v5 + 32],
            1,
            *(FMOD::DSPConnectionI **)&this->mDSPQueueBuffer[v5 + 24],
            0);
          break;
        case 2:
          FMOD::DSPI::addInputChainAtInternal(
            *(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(FMOD::DSPI **)&this->mDSPQueueBuffer[v5 + 16],
            *(_DWORD *)&this->mDSPQueueBuffer[v5 + 24],
            *(_DWORD *)&this->mDSPQueueBuffer[v5 + 28],
            *(_DWORD *)&this->mDSPQueueBuffer[v5 + 32],
            0);
          break;
        case 3:
          FMOD::DSPI::disconnectFromInternal(
            *(FMOD::DSPI *const *)(*(_QWORD *)&this->mDSPQueueBuffer[v5 + 8] + 96LL),
            *(FMOD::DSPI **)(*(_QWORD *)&this->mDSPQueueBuffer[v5 + 8] + 88LL),
            *(FMOD::DSPConnectionI **)&this->mDSPQueueBuffer[v5 + 8],
            1,
            0,
            FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
          break;
        case 4:
          FMOD::DSPI::disconnectFromInternal(
            *(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(FMOD::DSPI **)&this->mDSPQueueBuffer[v5 + 16],
            *(FMOD::DSPConnectionI **)&this->mDSPQueueBuffer[v5 + 24],
            1,
            0,
            *(FMOD_DSPCONNECTION_TYPE_0 *)&this->mDSPQueueBuffer[v5 + 32]);
          v18 = *(_QWORD *)&this->mDSPQueueBuffer[v5 + 16];
          if ( !v18 )
            v18 = *(_QWORD *)&this->mDSPQueueBuffer[v5 + 8];
          *(_BYTE *)(v18 + 94) = 0;
          break;
        case 5:
          FMOD::DSPI::disconnectAllInternal(
            *(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8],
            this->mDSPQueueBuffer[v5 + 16],
            this->mDSPQueueBuffer[v5 + 17],
            0,
            0);
          *(_BYTE *)(*(_QWORD *)&this->mDSPQueueBuffer[v5 + 8] + 94LL) = 0;
          v8 = *(_QWORD *)&this->mDSPQueueBuffer[v5 + 8];
          v9 = *(void (__fastcall **)(__int64, __int64, _QWORD, _QWORD))(v8 + 296);
          if ( v9 && (*(_BYTE *)(v8 + 290) & 0x10) != 0 )
            v9(v8 + 184, 16, 0, 0);
          if ( this->mDSPQueueBuffer[v5 + 18] )
          {
            v10 = *(_QWORD *)&this->mDSPQueueBuffer[v5 + 8];
            v11 = *(void (__fastcall **)(__int64, __int64, _QWORD, _QWORD))(v10 + 296);
            if ( v11 && *(char *)(v10 + 290) < 0 )
              v11(v10 + 184, 128, 0, 0);
            FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_DSPRELEASE);
            v12 = *(FMOD::LinkedListNode **)&this->mDSPQueueBuffer[v5 + 8];
            v12[16].mNodePrev = this->mDSPReleaseHead.mNodePrev;
            v12[16].mNodeNext = &this->mDSPReleaseHead;
            this->mDSPReleaseHead.mNodePrev = v12 + 16;
            v12[16].mNodePrev->mNodeNext = v12 + 16;
            v12[16].mNodeData = v12;
            FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPRELEASE);
          }
          break;
        case 6:
          FMOD::DSPI::removeToInclusiveInternal(
            *(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(FMOD::DSPI **)&this->mDSPQueueBuffer[v5 + 16],
            0);
          break;
        case 7:
          v16 = *(_QWORD *)&this->mDSPQueueBuffer[v5 + 8];
          v17 = *(void (__fastcall **)(__int64, __int64, char *, _QWORD))(v16 + 296);
          if ( v17 && (*(_BYTE *)(v16 + 290) & 2) != 0 )
            v17(v16 + 184, 2, &this->mDSPQueueBuffer[v5], 0);
          break;
        case 8:
          FMOD::DSPReturn::mixerCreate(*(FMOD::DSPReturn *const *)&this->mDSPQueueBuffer[v5 + 8]);
          break;
        case 9:
          FMOD::DSPSend::connectReturn(
            *(FMOD::DSPSend *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(_DWORD *)&this->mDSPQueueBuffer[v5 + 16]);
          break;
        case 10:
          v13 = *(__int16 *)&this->mDSPQueueBuffer[v5 + 32];
          v14 = *(__int16 *)&this->mDSPQueueBuffer[v5 + 34];
          v15 = *(float **)&this->mDSPQueueBuffer[v5 + 8];
          if ( *(_QWORD *)&this->mDSPQueueBuffer[v5 + 16] )
          {
            FMOD::DSPConnectionI::resizeMatrix(
              *(FMOD::DSPConnectionI *const *)&this->mDSPQueueBuffer[v5 + 24],
              v15,
              *(float **)&this->mDSPQueueBuffer[v5 + 16],
              v13,
              v14);
          }
          else
          {
            connection = *(FMOD::DSPConnectionI **)&this->mDSPQueueBuffer[v5 + 24];
            FMOD::DSPMatrix::set(&connection->mMixMatrix, v15, v14, v13, 0);
            FMOD::DSPConnectionI::rampTo(connection, *(_DWORD *)&this->mDSPQueueBuffer[v5 + 36]);
            FMOD::MemPool::free(
              &this->mDSPLevelsPool,
              *(void **)&this->mDSPQueueBuffer[v5 + 8],
              (const char *)&uri_string,
              0);
          }
          break;
        case 11:
          FMOD::DSPConnectionI::setUnity(
            *(FMOD::DSPConnectionI *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(float *)&this->mDSPQueueBuffer[v5 + 16],
            v2,
            0);
          break;
        case 12:
          FMOD::DSPI::setPosition(
            *(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(FMOD_UINT32_32 *)&this->mDSPQueueBuffer[v5 + 16],
            this->mDSPQueueBuffer[v5 + 24],
            0);
          *(_WORD *)(*(_QWORD *)&this->mDSPQueueBuffer[v5 + 8] + 92LL) &= ~0x2000u;
          break;
        case 13:
          FMOD::DSPConnectionI::setMixInternal(
            *(FMOD::DSPConnectionI *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(float *)&this->mDSPQueueBuffer[v5 + 16],
            *(_DWORD *)&this->mDSPQueueBuffer[v5 + 20],
            this->mDSPQueueBuffer[v5 + 24]);
          break;
        case 14:
          FMOD::DSPI::setActiveInternal(
            *(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8],
            this->mDSPQueueBuffer[v5 + 16],
            1);
          break;
        case 15:
          FMOD::DSPI::setDelayInternal(
            *(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(_QWORD *)&this->mDSPQueueBuffer[v5 + 16],
            *(_QWORD *)&this->mDSPQueueBuffer[v5 + 24],
            this->mDSPQueueBuffer[v5 + 32]);
          break;
        case 16:
          *(_QWORD *)(*(_QWORD *)&this->mDSPQueueBuffer[v5 + 8] + 536LL) = *(_QWORD *)&this->mDSPQueueBuffer[v5 + 16];
          break;
        case 17:
          FMOD::DSPI::resetInternal(*(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8]);
          break;
        case 18:
          FMOD::DSPFader::resetInternal(*(FMOD::DSPFader *const *)&this->mDSPQueueBuffer[v5 + 8], 1, 0);
          break;
        case 19:
          FMOD::DSPI::setPitch(
            *(FMOD::DSPI *const *)&this->mDSPQueueBuffer[v5 + 8],
            *(float *)&this->mDSPQueueBuffer[v5 + 4],
            v2,
            0);
          break;
        default:
          break;
      }
      v5 += *(int *)v6 >> 8;
    }
    while ( this->mDSPQueueCmdOffset > v5 );
    this->mDSPQueueCmdOffset = 0;
    this->mDSPQueueCmdFlushing = 0;
    if ( calledfrommainthread )
      goto LABEL_10;
  }
LABEL_11:
  if ( v4 )
    FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPQUEUE);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223a6f0 | Name: _ZN4FMOD7SystemI15lockDSPQueueCmdEPPvib
FMOD_RESULT_0 __fastcall FMOD::SystemI::lockDSPQueueCmd(
        FMOD::SystemI *const this,
        void **cmdmem,
        int cmdsize,
        bool protect)
{
  __int64 mDSPQueueCmdOffset; // rax
  int v7; // edx
  char *v8; // rax
  FMOD_RESULT_0 v9; // r12d
  FMOD_RESULT_0 v11; // eax

  if ( protect )
  {
    v9 = FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_DSPQUEUE);
    if ( v9 )
      return v9;
  }
  mDSPQueueCmdOffset = this->mDSPQueueCmdOffset;
  v7 = mDSPQueueCmdOffset + cmdsize;
  if ( (int)mDSPQueueCmdOffset + cmdsize <= 0x10000 )
  {
LABEL_3:
    v8 = &this->mDSPQueueBuffer[mDSPQueueCmdOffset];
    v9 = FMOD_RESULT::FMOD_OK_0;
    *(_DWORD *)v8 = (cmdsize << 8) | (unsigned __int8)*v8;
    this->mDSPQueueCmdOffset = v7;
    *cmdmem = v8;
    return v9;
  }
  v11 = FMOD::SystemI::flushDSPQueue(this, 1);
  if ( v11 == FMOD_RESULT::FMOD_OK_0 )
  {
    mDSPQueueCmdOffset = this->mDSPQueueCmdOffset;
    v7 = cmdsize + mDSPQueueCmdOffset;
    goto LABEL_3;
  }
  v9 = v11;
  if ( protect )
    FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPQUEUE);
  return v9;
}


// Address: 0x223a7a0 | Name: _ZN4FMOD7SystemI17unlockDSPQueueCmdEPvb
FMOD_RESULT_0 __fastcall FMOD::SystemI::unlockDSPQueueCmd(FMOD::SystemI *const this, void *cmdmem, bool protect)
{
  if ( protect )
    return FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPQUEUE);
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x223a7c0 | Name: _ZN4FMOD7SystemI20DSPCodecPoolRegisterENS_23FMOD_DSP_CODECPOOL_TYPEEPNS_25FMOD_CODEC_DESCRIPTION_EXEii
FMOD_RESULT_0 __fastcall FMOD::SystemI::DSPCodecPoolRegister(
        FMOD::SystemI *const this,
        FMOD::FMOD_DSP_CODECPOOL_TYPE pooltype,
        FMOD::FMOD_CODEC_DESCRIPTION_EX *codecdesc,
        int numcodecs,
        int maxchannels)
{
  int (***v5)(...); // r12
  FMOD_RESULT_0 result; // eax
  FMOD::DSPCodecPool *v10; // rax
  FMOD::DSPCodecPool *_memory; // [rsp+8h] [rbp-40h]

  v5 = &this->_vptr_SystemI + (int)pooltype;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( !v5[8684] )
  {
    v10 = (FMOD::DSPCodecPool *)FMOD::MemPool::calloc(
                                  off_286F358->gSystemMemPool,
                                  960,
                                  "../../../core_api/src/fmod_systemi_dsp.cpp",
                                  594,
                                  0);
    if ( v10 )
    {
      _memory = v10;
      FMOD::MemPool::MemPool(&v10->mContextMemoryPool);
      _memory->mSystem = this;
      result = FMOD::DSPCodecPool::init(_memory, pooltype, codecdesc, numcodecs, maxchannels);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        v5[8684] = (int (**)(...))_memory;
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
  }
  return result;
}


// Address: 0x223a890 | Name: _ZN4FMOD7SystemI22DSPCodecPoolUnregisterENS_23FMOD_DSP_CODECPOOL_TYPEE
FMOD_RESULT_0 __fastcall FMOD::SystemI::DSPCodecPoolUnregister(
        FMOD::SystemI *const this,
        FMOD::FMOD_DSP_CODECPOOL_TYPE pooltype)
{
  FMOD_RESULT_0 result; // eax
  int (***v3)(...); // rbp
  int (**v4)(...); // rbx

  result = FMOD_RESULT::FMOD_OK_0;
  v3 = &this->_vptr_SystemI + (int)pooltype;
  v4 = v3[8684];
  if ( v4 )
  {
    result = FMOD::DSPCodecPool::close((FMOD::DSPCodecPool *const)v3[8684]);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v4, "../../../core_api/src/fmod_systemi_dsp.cpp", 634);
      v3[8684] = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x223a900 | Name: _ZN4FMOD7SystemI15DSPCodecPoolGetENS_23FMOD_DSP_CODECPOOL_TYPEEPPNS_12DSPCodecPoolE
FMOD_RESULT_0 __fastcall FMOD::SystemI::DSPCodecPoolGet(
        FMOD::SystemI *const this,
        FMOD::FMOD_DSP_CODECPOOL_TYPE pooltype,
        FMOD::DSPCodecPool **pool)
{
  FMOD::DSPCodecPool *v4; // rax

  if ( !pool || (unsigned int)pooltype > FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_FADPCM )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v4 = this->mDSPCodecPool[pooltype];
  *pool = v4;
  return v4 == 0 ? 9 : 0;
}


// Address: 0x223a930 | Name: _ZN4FMOD7SystemI23updateReverbConnectionsEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::updateReverbConnections(FMOD::SystemI *const this, int instance)
{
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::SystemI *p_mNodePrev; // rbx
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::ChannelGroupI *mMasterChannelGroup; // rax
  FMOD::LinkedListNode *v7; // rbx

  mNodeNext = this->mChannelUsedListHead.mNodeNext;
  p_mNodePrev = 0;
  if ( mNodeNext )
    p_mNodePrev = (FMOD::SystemI *)&mNodeNext[-16].mNodePrev;
  while ( p_mNodePrev != (FMOD::SystemI *)&this->mChannelUsedListHead )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::SystemI *, _QWORD))p_mNodePrev->_vptr_SystemI + 15))(
               p_mNodePrev,
               (unsigned int)instance);
    if ( result )
      return result;
    mNodePrev = p_mNodePrev->mSoundListHead.mSoundGroupNode.mNodePrev;
    p_mNodePrev = (FMOD::SystemI *)&mNodePrev[-16].mNodePrev;
    if ( !mNodePrev )
      p_mNodePrev = 0;
  }
  mMasterChannelGroup = this->mMasterChannelGroup;
  v7 = mMasterChannelGroup->mGroupHead.mNodeNext;
  if ( v7 == &mMasterChannelGroup->mGroupHead )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    result = FMOD::ChannelGroupI::updateReverbRecursive((FMOD::ChannelGroupI *const)v7->mNodeData, instance);
    if ( result )
      break;
    v7 = v7->mNodeNext;
    if ( v7 == &this->mMasterChannelGroup->mGroupHead )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x223a9f0 | Name: _ZN4FMOD7SystemI27setReverbPropertiesInternalEiPK22FMOD_REVERB_PROPERTIESb
FMOD_RESULT_0 __fastcall FMOD::SystemI::setReverbPropertiesInternal(
        FMOD::SystemI *const this,
        int instance,
        const FMOD_REVERB_PROPERTIES *prop,
        bool force)
{
  unsigned __int64 v6; // rax
  FMOD::DSPI **v7; // r14
  FMOD_RESULT_0 result; // eax
  char *v9; // rax
  FMOD::DSPI *masterdsp; // [rsp+8h] [rbp-40h] BYREF

  if ( this->mSoftware )
  {
    v6 = 24LL * instance;
    v7 = (FMOD::DSPI **)((char *)this + v6);
    if ( this->mReverb[v6 / 0x18].mDSP )
    {
      if ( !prop )
      {
        result = FMOD::ReverbPhysical::release((FMOD::ReverbPhysical *const)((char *)&stru_12498 + (_QWORD)this + v6));
        if ( result )
          return result;
        result = FMOD::SystemI::updateReverbConnections(this, instance);
        if ( result )
          return result;
      }
    }
    else if ( prop )
    {
      result = FMOD::ReverbPhysical::init(
                 (FMOD::ReverbPhysical *const)((char *)&stru_12498 + (_QWORD)this + v6),
                 instance,
                 this);
      if ( result )
        return result;
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **))this->mMasterChannelGroup->_vptr_ChannelControlI
                + 36))(
                 this->mMasterChannelGroup,
                 4294967293LL,
                 &masterdsp);
      if ( result )
        return result;
      result = FMOD::DSPI::addInput(
                 masterdsp,
                 v7[9364],
                 0,
                 FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                 1,
                 0);
      if ( result )
        return result;
      result = FMOD::SystemI::updateReverbConnections(this, instance);
      if ( result )
        return result;
      result = FMOD::DSPI::setActive(v7[9364], 1, 1);
      if ( result )
        return result;
    }
  }
  else
  {
    v9 = (char *)this + 24 * instance;
    *(unsigned __int64 *)((char *)&stru_12498.r_offset + (_QWORD)v9) = (unsigned __int64)this;
    *((_DWORD *)v9 + 18730) = instance;
  }
  if ( this->mAdvancedSettings.reverb3Dinstance != instance
    || (Elf64_Rela *)((char *)&stru_125B8 + (_QWORD)this) == *(Elf64_Rela **)((char *)&stru_125B8.r_offset + (_QWORD)this)
    && (char *)&stru_125B8 + (_QWORD)this == (char *)this->mReverb3DHead.mNodePrev )
  {
    return FMOD::ReverbPhysical::setProperties(
             (FMOD::ReverbPhysical *const)((char *)&stru_12498 + (_QWORD)this + 24 * instance),
             prop);
  }
  result = FMOD_RESULT::FMOD_OK_0;
  if ( force )
    return FMOD::ReverbPhysical::setProperties(
             (FMOD::ReverbPhysical *const)((char *)&stru_12498 + (_QWORD)this + 24 * instance),
             prop);
  return result;
}


// Address: 0x223aba0 | Name: _ZN4FMOD7SystemI20flushDSPReleaseQueueEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::flushDSPReleaseQueue(FMOD::SystemI *const this)
{
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::DSPI *mNodeData; // rbp
  FMOD_RESULT_0 result; // eax

  FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_DSPRELEASE);
  mNodeNext = this->mDSPReleaseHead.mNodeNext;
  if ( mNodeNext == &this->mDSPReleaseHead )
  {
LABEL_6:
    FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPRELEASE);
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    while ( 1 )
    {
      mNodePrev = mNodeNext->mNodePrev;
      mNodeData = (FMOD::DSPI *)mNodeNext->mNodeData;
      mNodePrev->mNodeNext = mNodeNext->mNodeNext;
      mNodeNext->mNodeNext->mNodePrev = mNodePrev;
      mNodeNext->mNodePrev = mNodeNext;
      mNodeNext->mNodeNext = mNodeNext;
      FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPRELEASE);
      result = FMOD::DSPI::releaseInternal(mNodeData, 0);
      if ( result )
        break;
      FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_DSPRELEASE);
      mNodeNext = this->mDSPReleaseHead.mNodeNext;
      if ( mNodeNext == &this->mDSPReleaseHead )
        goto LABEL_6;
    }
  }
  return result;
}


