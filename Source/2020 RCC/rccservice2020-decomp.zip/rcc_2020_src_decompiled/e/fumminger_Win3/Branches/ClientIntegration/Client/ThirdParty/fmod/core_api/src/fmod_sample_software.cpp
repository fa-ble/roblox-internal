// Address: 0x2227d80 | Name: _ZN4FMOD14SampleSoftware13setBufferDataEPv
FMOD_RESULT_0 __fastcall FMOD::SampleSoftware::setBufferData(FMOD::SampleSoftware *const this, void *data)
{
  this->mBuffer = data;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2227d90 | Name: _ZN4FMOD14SampleSoftwareC2Ev
void __fastcall FMOD::SampleSoftware::SampleSoftware(FMOD::SampleSoftware *const this)
{
  FMOD::Sample::Sample(this);
  this->mBuffer = 0;
  this->mBufferMemory = 0;
  this->mLoopPointDataEndOffset = 0;
  this->_vptr_SoundI = (int (**)(...))&off_29B2470;
}


// Address: 0x2227dd0 | Name: _ZN4FMOD14SampleSoftware16setLoopPointDataEv
FMOD_RESULT_0 __fastcall FMOD::SampleSoftware::setLoopPointData(FMOD::SampleSoftware *const this)
{
  FMOD_SOUND_FORMAT_0 mFormat; // eax
  char *mLoopPointDataEnd; // rdi
  int mChannels; // ecx
  unsigned int v5; // esi
  size_t v6; // rdx
  int v7; // ebp
  __int64 v8; // rsi
  unsigned int v9; // ebp
  __int64 v10; // rax
  unsigned __int64 v11; // rsi
  FMOD_MODE mMode; // eax
  unsigned int v13; // ecx
  unsigned int v14; // r12d
  __int64 mLoopPointDataEndOffset; // rax
  size_t v16; // r13
  char *mBuffer; // rax
  unsigned int v19; // esi
  int v20; // ebp
  unsigned int mLoopStart; // esi
  int v22; // ebp
  __int64 v23; // rbp
  int v24; // edx
  char *v25; // rax
  char *v26; // rcx
  int v27; // edx
  int v28; // esi
  int v29; // ecx
  char *v30; // rax
  char *v31; // rdx
  int v32; // ecx
  char v33; // si
  int v34; // ecx
  char *v35; // rdx
  __int64 v36; // rax
  int v37; // ecx
  char *v38; // rsi
  char *v39; // rax
  __int64 v40; // rsi
  __int16 v41; // cx
  char *v42; // rdx
  int v43; // eax
  int v44; // edi
  char *v45; // rax
  char v46; // cl
  __int64 v47; // rax

  mFormat = this->mFormat;
  if ( (unsigned int)(mFormat - 1) > 4 )
    return FMOD_RESULT::FMOD_OK_0;
  mLoopPointDataEnd = this->mLoopPointDataEnd;
  if ( !mLoopPointDataEnd )
    return FMOD_RESULT::FMOD_OK_0;
  mChannels = this->mChannels;
  if ( mFormat == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0 )
  {
    mLoopStart = this->mLoopStart;
    v6 = (unsigned int)(24 * mChannels);
    v22 = 3 * mLoopStart;
    v8 = this->mLoopLength + mLoopStart;
    v9 = mChannels * v22;
    v10 = 24;
  }
  else
  {
    if ( mFormat <= FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0 )
    {
      if ( mFormat == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0 )
      {
        v19 = this->mLoopStart;
        v6 = (unsigned int)(16 * mChannels);
        v20 = 2 * v19;
        v8 = this->mLoopLength + v19;
        v9 = mChannels * v20;
        v10 = 16;
        goto LABEL_8;
      }
    }
    else if ( mFormat == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0
           || mFormat == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0 )
    {
      v5 = this->mLoopStart;
      v6 = (unsigned int)(32 * mChannels);
      v7 = 4 * v5;
      v8 = this->mLoopLength + v5;
      v9 = mChannels * v7;
      v10 = 32;
      goto LABEL_8;
    }
    v6 = (unsigned int)(8 * mChannels);
    v8 = this->mLoopLength + this->mLoopStart;
    v9 = mChannels * this->mLoopStart;
    v10 = 8;
  }
LABEL_8:
  v11 = v10 * v8;
  mMode = this->mMode;
  v13 = (v11 >> 3) * mChannels;
  v14 = v13;
  if ( (mMode & 4) != 0 )
  {
    v23 = v13;
    memcpy_0(mLoopPointDataEnd, (char *)this->mBuffer + v13, v6);
    this->mLoopPointDataEndOffset = v14;
    switch ( this->mFormat )
    {
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
        v42 = (char *)this->mBuffer + v14;
        v43 = this->mChannels;
        v44 = (_DWORD)v42 - v43;
        if ( v43 > 0 )
        {
          v45 = (char *)this->mBuffer + v23 - v43;
          do
          {
            v46 = *v45--;
            *v42++ = v46;
          }
          while ( 8 * this->mChannels > v44 - (int)v45 );
        }
        break;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
        v34 = this->mChannels;
        v35 = (char *)this->mBuffer + v14;
        v36 = v34;
        v37 = 8 * v34;
        v38 = &v35[-2 * v36];
        v39 = v38;
        if ( v37 > 0 )
        {
          v40 = (__int64)&v38[-2 * (v37 - 1) - 2];
          do
          {
            v41 = *(_WORD *)v39;
            v39 -= 2;
            v35 += 2;
            *((_WORD *)v35 - 1) = v41;
          }
          while ( v39 != (char *)v40 );
        }
        break;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
        v29 = this->mChannels;
        v30 = (char *)this->mBuffer + v14;
        v31 = &v30[-3 * v29];
        if ( v29 > 0 )
        {
          v32 = 0;
          do
          {
            v33 = *v31;
            ++v32;
            v30 += 3;
            v31 -= 3;
            *(v30 - 3) = v33;
            *(v30 - 2) = v31[4];
            *(v30 - 1) = v31[5];
          }
          while ( 8 * this->mChannels > v32 );
        }
        break;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
        v24 = this->mChannels;
        v25 = (char *)this->mBuffer + v14;
        v26 = &v25[-4 * v24];
        if ( v24 > 0 )
        {
          v27 = 0;
          do
          {
            v28 = *(_DWORD *)v26;
            ++v27;
            v25 += 4;
            v26 -= 4;
            *((_DWORD *)v25 - 1) = v28;
          }
          while ( 8 * this->mChannels > v27 );
        }
        break;
      default:
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  else if ( (mMode & 2) != 0 )
  {
    mLoopPointDataEndOffset = this->mLoopPointDataEndOffset;
    v16 = (unsigned int)v6;
    if ( (_DWORD)mLoopPointDataEndOffset )
    {
      memcpy_0((char *)this->mBuffer + mLoopPointDataEndOffset, mLoopPointDataEnd, (unsigned int)v6);
      mLoopPointDataEnd = this->mLoopPointDataEnd;
    }
    memcpy_0(mLoopPointDataEnd, (char *)this->mBuffer + v14, v16);
    mBuffer = (char *)this->mBuffer;
    this->mLoopPointDataEndOffset = v14;
    memcpy_0(&mBuffer[v14], &mBuffer[v9], v16);
    if ( !v9 )
      memcpy_0((char *)this->mBuffer - v16, (char *)this->mBuffer + v14 - v16, v16);
  }
  else if ( (mMode & 1) != 0 )
  {
    v47 = this->mLoopPointDataEndOffset;
    if ( (_DWORD)v47 )
    {
      memcpy_0((char *)this->mBuffer + v47, mLoopPointDataEnd, v6);
      this->mLoopPointDataEndOffset = 0;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2228150 | Name: j__ZN4FMOD14SampleSoftware16setLoopPointDataEv
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::SampleSoftware::setLoopPointData(
        FMOD::SampleSoftware *const this,
        void *ptr1,
        void *ptr2,
        unsigned int len1,
        unsigned int len2)
{
  return _ZN4FMOD14SampleSoftware16setLoopPointDataEv(this);
}


// Address: 0x2228160 | Name: _ZN4FMOD14SampleSoftware20restoreLoopPointDataEv
FMOD_RESULT_0 __fastcall FMOD::SampleSoftware::restoreLoopPointData(FMOD::SampleSoftware *const this)
{
  FMOD_SOUND_FORMAT_0 mFormat; // eax
  char *mLoopPointDataEnd; // rsi
  int mChannels; // ecx
  int v5; // edx
  __int64 mLoopPointDataEndOffset; // rdi

  mFormat = this->mFormat;
  if ( (unsigned int)(mFormat - 1) > 4 )
    return FMOD_RESULT::FMOD_OK_0;
  mLoopPointDataEnd = this->mLoopPointDataEnd;
  if ( !mLoopPointDataEnd )
    return FMOD_RESULT::FMOD_OK_0;
  mChannels = this->mChannels;
  if ( mFormat == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0 )
  {
    v5 = 24;
    goto LABEL_7;
  }
  if ( mFormat <= FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0 )
  {
    v5 = 16;
    if ( mFormat == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0 )
      goto LABEL_7;
    goto LABEL_11;
  }
  v5 = 32;
  if ( mFormat != FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0
    && mFormat != FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0 )
  {
LABEL_11:
    v5 = 8;
  }
LABEL_7:
  mLoopPointDataEndOffset = this->mLoopPointDataEndOffset;
  if ( !(_DWORD)mLoopPointDataEndOffset )
    return FMOD_RESULT::FMOD_OK_0;
  memcpy_0((char *)this->mBuffer + mLoopPointDataEndOffset, mLoopPointDataEnd, (unsigned int)(mChannels * v5));
  this->mLoopPointDataEndOffset = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22281f0 | Name: _ZN4FMOD14SampleSoftware12lockInternalEjjPPvS2_PjS3_
FMOD_RESULT_0 __fastcall FMOD::SampleSoftware::lockInternal(
        FMOD::SampleSoftware *const this,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  int mChannels; // r10d
  int v9; // edi
  unsigned int mLoopPointDataEndOffset; // eax
  unsigned int mLengthBytes; // eax
  char *mBuffer; // rdi
  FMOD_RESULT_0 result; // eax
  unsigned int lengtha; // [rsp+4h] [rbp-24h]
  void **ptr1a; // [rsp+8h] [rbp-20h]
  void **ptr2a; // [rsp+10h] [rbp-18h]
  unsigned int *len1a; // [rsp+18h] [rbp-10h]

  mChannels = this->mChannels;
  switch ( this->mFormat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      v9 = 16;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      v9 = 24;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      v9 = 32;
      break;
    default:
      v9 = 8;
      break;
  }
  mLoopPointDataEndOffset = this->mLoopPointDataEndOffset;
  if ( !mLoopPointDataEndOffset )
    goto LABEL_5;
  if ( mLoopPointDataEndOffset >= offset + length )
    goto LABEL_5;
  if ( offset >= mChannels * v9 + mLoopPointDataEndOffset )
    goto LABEL_5;
  len1a = len1;
  ptr2a = ptr2;
  ptr1a = ptr1;
  lengtha = length;
  result = FMOD::SampleSoftware::restoreLoopPointData(this);
  length = lengtha;
  ptr1 = ptr1a;
  ptr2 = ptr2a;
  len1 = len1a;
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
LABEL_5:
    mLengthBytes = this->mLengthBytes;
    mBuffer = (char *)this->mBuffer;
    if ( offset < mLengthBytes && length <= mLengthBytes )
    {
      if ( mLengthBytes < offset + length )
      {
        *ptr1 = &mBuffer[offset];
        if ( len1 )
          *len1 = mLengthBytes - offset;
        if ( ptr2 )
          *ptr2 = mBuffer;
        if ( len2 )
          *len2 = length - this->mLengthBytes + offset;
      }
      else
      {
        *ptr1 = &mBuffer[offset];
        if ( len1 )
          *len1 = length;
        if ( ptr2 )
          *ptr2 = 0;
        if ( len2 )
        {
          *len2 = 0;
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      *ptr1 = 0;
      if ( ptr2 )
        *ptr2 = 0;
      if ( len1 )
        *len1 = 0;
      if ( len2 )
        *len2 = 0;
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
  }
  return result;
}


// Address: 0x22283c0 | Name: _ZN4FMOD14SampleSoftware7releaseEb
FMOD_RESULT_0 __fastcall FMOD::SampleSoftware::release(FMOD::SampleSoftware *const this, bool freethis)
{
  FMOD::Atomic<FMOD_OPENSTATE> *p_mOpenState; // rbp
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 result; // eax
  void *mBufferMemory; // rsi
  FMOD::SampleSoftware *mLoopPointDataEnd; // rsi

  p_mOpenState = &this->mOpenState;
  while ( p_mOpenState->m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_READY_0 )
  {
    if ( !this->mDontRelease )
      goto LABEL_7;
LABEL_3:
    FMOD_OS_Time_Sleep(2u);
  }
  if ( p_mOpenState->m_value != FMOD_OPENSTATE::FMOD_OPENSTATE_ERROR_0 || this->mDontRelease )
    goto LABEL_3;
LABEL_7:
  mSystem = this->mSystem;
  if ( !mSystem || (result = FMOD::SystemI::stopSound(mSystem, this)) == FMOD_RESULT::FMOD_OK_0 )
  {
    mBufferMemory = this->mBufferMemory;
    if ( mBufferMemory )
    {
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        mBufferMemory,
        "../../../core_api/src/fmod_sample_software.cpp",
        68);
      this->mBufferMemory = 0;
    }
    mLoopPointDataEnd = (FMOD::SampleSoftware *)this->mLoopPointDataEnd;
    if ( mLoopPointDataEnd )
    {
      if ( mLoopPointDataEnd != (FMOD::SampleSoftware *)this->mLoopPointDataEndMemory )
      {
        FMOD::MemPool::free(
          off_286F358->gSystemMemPool,
          mLoopPointDataEnd,
          "../../../core_api/src/fmod_sample_software.cpp",
          74);
        this->mLoopPointDataEnd = 0;
      }
    }
    this->mBuffer = 0;
    return FMOD::Sample::release(this, freethis);
  }
  return result;
}


// Address: 0x22284c0 | Name: _ZN4FMOD14SampleSoftware7setModeEj
FMOD_RESULT_0 __fastcall FMOD::SampleSoftware::setMode(FMOD::SampleSoftware *const this, FMOD_MODE mode)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::Sample::setMode(this, mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::SampleSoftware::setLoopPointData(this);
  return result;
}


// Address: 0x22284e0 | Name: _ZN4FMOD14SampleSoftware13setLoopPointsEjjjj
FMOD_RESULT_0 __fastcall FMOD::SampleSoftware::setLoopPoints(
        FMOD::SampleSoftware *const this,
        unsigned int loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int loopend,
        FMOD_TIMEUNIT loopendtype)
{
  FMOD_RESULT_0 v5; // ebp
  FMOD_TIMEUNIT loopstarttypea; // [rsp+4h] [rbp-24h]
  unsigned int loopenda; // [rsp+8h] [rbp-20h]
  FMOD_TIMEUNIT loopendtypea; // [rsp+Ch] [rbp-1Ch]

  if ( this->mBuffer )
  {
    loopendtypea = loopendtype;
    loopenda = loopend;
    loopstarttypea = loopstarttype;
    FMOD::SampleSoftware::restoreLoopPointData(this);
    loopendtype = loopendtypea;
    loopend = loopenda;
    loopstarttype = loopstarttypea;
  }
  v5 = FMOD::Sample::setLoopPoints(this, loopstart, loopstarttype, loopend, loopendtype);
  if ( v5 == FMOD_RESULT::FMOD_OK_0 && this->mBuffer )
    FMOD::SampleSoftware::setLoopPointData(this);
  return v5;
}


