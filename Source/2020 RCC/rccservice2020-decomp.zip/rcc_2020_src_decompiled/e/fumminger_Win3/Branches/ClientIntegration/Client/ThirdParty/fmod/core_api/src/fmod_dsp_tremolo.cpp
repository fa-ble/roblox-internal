// Address: 0x2214620 | Name: _ZN4FMOD10DSPTremolo16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPTremolo::getDescriptionEx()
{
  memset(&stru_2AF7260, 0, sizeof(stru_2AF7260));
  FMOD_strcpy_safe(stru_2AF7260.name, "Frequency", 16);
  FMOD_strcpy_safe(stru_2AF7260.label, "Hz", 16);
  *(_QWORD *)&stru_2AF7260.floatdesc.min = 0x41A000003C23D70ALL;
  stru_2AF7260.description = "LFO frequency in Hz.  0.01 to 20.  Default = 5.";
  memset(&stru_2AF7200, 0, sizeof(stru_2AF7200));
  stru_2AF7260.intdesc.defaultval = 1084227584;
  stru_2AF7260.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF7200.name, "Depth", 16);
  FMOD_strcpy_safe(stru_2AF7200.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF7200.floatdesc.min = 0x3F80000000000000LL;
  stru_2AF7200.description = "Tremolo depth.  0 to 1.  Default = 1.";
  memset(&stru_2AF71A0, 0, sizeof(stru_2AF71A0));
  stru_2AF7200.intdesc.defaultval = 1065353216;
  stru_2AF7200.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF71A0.name, "Shape", 16);
  FMOD_strcpy_safe(stru_2AF71A0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF71A0.floatdesc.min = 0x3F80000000000000LL;
  stru_2AF71A0.description = "LFO shape morph between triangle and sine.  0 to 1.  Default = 0.";
  memset(&stru_2AF7140, 0, sizeof(stru_2AF7140));
  stru_2AF71A0.intdesc.defaultval = 0;
  stru_2AF71A0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF7140.name, "Skew", 16);
  FMOD_strcpy_safe(stru_2AF7140.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF7140.floatdesc.min = 0x3F800000BF800000LL;
  stru_2AF7140.description = "Time-skewing of LFO cycle.  -1 to 1.  Default = 0.";
  memset(&stru_2AF70E0, 0, sizeof(stru_2AF70E0));
  stru_2AF7140.intdesc.defaultval = 0;
  stru_2AF7140.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF70E0.name, "Duty", 16);
  FMOD_strcpy_safe(stru_2AF70E0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF70E0.floatdesc.min = 0x3F80000000000000LL;
  stru_2AF70E0.description = "LFO on-time.  0 to 1.  Default = 0.5.";
  memset(&stru_2AF7080, 0, sizeof(stru_2AF7080));
  stru_2AF70E0.intdesc.defaultval = 1056964608;
  stru_2AF70E0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF7080.name, "Square", 16);
  FMOD_strcpy_safe(stru_2AF7080.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF7080.floatdesc.min = 0x3F80000000000000LL;
  stru_2AF7080.description = "Flatness of the LFO shape.  0 to 1.  Default = 0.";
  memset(&stru_2AF7020, 0, sizeof(stru_2AF7020));
  stru_2AF7080.intdesc.defaultval = 0;
  stru_2AF7080.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF7020.name, "Phase", 16);
  FMOD_strcpy_safe(stru_2AF7020.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF7020.floatdesc.min = 0x3F80000000000000LL;
  stru_2AF7020.description = "Instantaneous LFO phase.  0 to 1.  Default = 0.";
  memset(&stru_2AF6FC0, 0, sizeof(stru_2AF6FC0));
  stru_2AF7020.intdesc.defaultval = 0;
  stru_2AF7020.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2AF6FC0.name, "Spread", 16);
  FMOD_strcpy_safe(stru_2AF6FC0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF6FC0.floatdesc.min = 0x3F800000BF800000LL;
  stru_2AF6FC0.intdesc.defaultval = 0;
  stru_2AF6FC0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AF6FC0.description = "Rotation / auto-pan effect.  -1 to 1.  Default = 0.";
  *(&stru_2AF6F80.mHandle + 1) = 22;
  stru_2AF6F80.mSize = 1016;
  stru_2AF6F80.mDescription = &stru_286C8C0;
  return &stru_2AF6F80;
}


// Address: 0x2214a30 | Name: _ZN4FMOD10DSPTremolo14createLFOTableEv
void __fastcall FMOD::DSPTremolo::createLFOTable(FMOD::DSPTremolo *const this)
{
  float v1; // xmm2_4
  __int64 v2; // rbx
  float v3; // xmm0_4
  float v4; // xmm3_4
  float rampstep; // [rsp+8h] [rbp-28h]
  float v6; // [rsp+10h] [rbp-20h]

  v1 = 0.0;
  v2 = 0;
  rampstep = *((float *)this + 161);
  v6 = *((float *)this + 134);
  v3 = -1.0;
  v4 = -1.5707964;
  while ( 1 )
  {
    v4 = v4 + (float)(rampstep * 3.1415927);
    *(float *)((char *)this + v2 + 904) = (float)((float)((float)(0.5 * v3) + 0.5) * v6)
                                        + (float)((float)(1.0 - v6) * v1);
    v2 += 4;
    if ( v2 == 68 )
      break;
    v3 = sinf(v4);
    v1 = v1 + rampstep;
  }
}


// Address: 0x2214b00 | Name: _ZN4FMOD10DSPTremolo12readLFOTableEibPf
// local variable allocation has failed, the output may be wrong!
float __fastcall FMOD::DSPTremolo::readLFOTable(FMOD::DSPTremolo *const this, int index, bool forward, float *ramp)
{
  __int64 v5; // rsi

  if ( !forward )
  {
    if ( index )
    {
      *(_QWORD *)&index = index;
      *ramp = (float)(*((float *)this + index + 225) - *((float *)this + index + 226)) * *((float *)this + 157);
      return (float)(*((float *)this + 133) * *((float *)this + *(_QWORD *)&index + 226)) + *((float *)this + 159);
    }
LABEL_7:
    *ramp = 0.0;
    v5 = index;
    return (float)(*((float *)this + 133) * *((float *)this + *(_QWORD *)&index + 226)) + *((float *)this + 159);
  }
  if ( index == 16 )
    goto LABEL_7;
  *(_QWORD *)&index = index;
  *ramp = (float)(*((float *)this + index + 227) - *((float *)this + index + 226)) * *((float *)this + 156);
  return (float)(*((float *)this + 133) * *((float *)this + *(_QWORD *)&index + 226)) + *((float *)this + 159);
}


// Address: 0x2214b90 | Name: _ZN4FMOD10DSPTremolo14updateWaveformEv
void __fastcall FMOD::DSPTremolo::updateWaveform(FMOD::DSPTremolo *const this)
{
  float v1; // xmm4_4
  float v2; // xmm1_4
  float v3; // xmm5_4
  float v4; // xmm2_4
  float v5; // xmm0_4
  float v6; // xmm6_4
  float v7; // xmm1_4

  v1 = *((float *)this + 136);
  v2 = (float)(*((float *)this + 135) + 1.0) * 0.5;
  v3 = 1.0 - *((float *)this + 137);
  v4 = (float)(1.0 - v1) * v2;
  v5 = (float)((float)(1.0 - v2) * v1) + v2;
  v6 = fminf(v4, v2 - v4);
  v7 = fminf(v5 - v2, 1.0 - v5) * v3;
  *((float *)this + 142) = v4 + (float)(v6 * v3);
  *((float *)this + 141) = v4 - (float)(v6 * v3);
  *((float *)this + 143) = v5 - v7;
  *((float *)this + 144) = v5 + v7;
}


// Address: 0x2214c40 | Name: _ZN4FMOD10DSPTremolo12updateTimingEv
void __fastcall FMOD::DSPTremolo::updateTiming(FMOD::DSPTremolo *const this)
{
  __m128 v1; // xmm0
  int v2; // ecx
  __int64 v3; // rax
  float v4; // xmm1_4
  __m128 v5; // xmm2
  float v6; // xmm1_4
  float v7; // xmm2_4
  int v8; // eax
  float v9; // xmm6_4
  float v10; // xmm1_4
  float v11; // xmm4_4
  float v12; // xmm2_4
  float v13; // xmm1_4
  float v14; // xmm0_4
  float v15; // xmm1_4
  int v16; // eax
  float v17; // xmm1_4
  int v18; // eax
  float v19; // xmm1_4
  int v20; // r9d
  __int64 v21; // rax
  int v22; // edx
  int v23; // edx
  float phase[16]; // [rsp+0h] [rbp-88h]
  float nextramp[18]; // [rsp+40h] [rbp-48h]

  v2 = *((_DWORD *)this + 244);
  if ( v2 > 0 )
  {
    v3 = 0;
    v4 = *((float *)this + 160);
    do
    {
      phase[v3] = (float)*((int *)this + v3 + 162) * v4;
      nextramp[v3] = (float)*((int *)this + v3 + 210) * v4;
      ++v3;
    }
    while ( v2 > (int)v3 );
  }
  v1.m128_f32[0] = (float)*((int *)this + 243) / *((float *)this + 132);
  *((_DWORD *)this + 149) = v1.m128_i32[0];
  v5 = _mm_and_ps(v1, (__m128)0x7FFFFFFFu);
  *((float *)this + 160) = 1.0 / v1.m128_f32[0];
  v6 = v1.m128_f32[0];
  if ( v5.m128_f32[0] < 8388608.0 )
  {
    v5.m128_f32[0] = (float)(int)v1.m128_f32[0];
    LODWORD(v6) = COERCE_UNSIGNED_INT(v5.m128_f32[0] - COERCE_FLOAT(_mm_cmpgt_ss(v5, v1).m128_u32[0] & 0x3F800000))
                | _mm_andnot_ps((__m128)0x7FFFFFFFu, v1).m128_u32[0];
  }
  v7 = *((float *)this + 142) - *((float *)this + 141);
  v8 = (int)v6;
  v9 = v1.m128_f32[0] - v6;
  v10 = *((float *)this + 144) - *((float *)this + 143);
  v11 = *((float *)this + 161);
  *((_DWORD *)this + 153) = 0;
  *((float *)this + 151) = v9;
  *((_DWORD *)this + 152) = 0;
  v12 = (float)(v7 * v1.m128_f32[0]) * v11;
  *((_DWORD *)this + 150) = v8;
  v13 = (float)(v10 * v1.m128_f32[0]) * v11;
  *((float *)this + 154) = v12;
  *((float *)this + 155) = v13;
  if ( v12 <= 0.0 )
  {
    *((_DWORD *)this + 154) = 0;
    *((_DWORD *)this + 156) = 0;
    if ( v13 > 0.0 )
      goto LABEL_8;
  }
  else
  {
    *((float *)this + 156) = *((float *)this + 133) / v12;
    if ( v13 > 0.0 )
    {
LABEL_8:
      *((float *)this + 157) = *((float *)this + 133) / v13;
      goto LABEL_9;
    }
  }
  *((_DWORD *)this + 155) = 0;
  *((_DWORD *)this + 157) = 0;
LABEL_9:
  v14 = *((float *)this + 149);
  v15 = *((float *)this + 142) * v14;
  *((_DWORD *)this + 145) = (int)(float)(*((float *)this + 141) * v14);
  v16 = (int)v15;
  v17 = *((float *)this + 143) * v14;
  *((_DWORD *)this + 146) = v16;
  v18 = (int)v17;
  v19 = *((float *)this + 144) * v14;
  *((_DWORD *)this + 147) = v18;
  *((_DWORD *)this + 148) = (int)v19;
  if ( v2 > 0 )
  {
    v20 = *((_DWORD *)this + 150);
    v21 = 0;
    do
    {
      while ( 1 )
      {
        v23 = (int)(float)(phase[v21] * v14);
        *((_DWORD *)this + 162) = (float)v23 < v14 ? v23 : 0;
        v22 = (int)(float)(nextramp[v21] * v14);
        if ( v22 >= v20 )
          break;
        ++v21;
        *((_DWORD *)this + 210) = v22;
        this = (FMOD::DSPTremolo *const)((char *)this + 4);
        if ( v2 <= (int)v21 )
          return;
      }
      ++v21;
      *((_DWORD *)this + 210) = 0;
      this = (FMOD::DSPTremolo *const)((char *)this + 4);
    }
    while ( v2 > (int)v21 );
  }
}


// Address: 0x2214ee0 | Name: _ZN4FMOD10DSPTremolo10applyPhaseEv
void __fastcall FMOD::DSPTremolo::applyPhase(FMOD::DSPTremolo *const this)
{
  int v1; // esi
  int v2; // eax
  int v3; // r8d
  const const struct {int channelcount;float phase[8];} *v4; // rdx
  int v5; // ecx
  __int64 i; // rax
  float v7; // xmm1_4
  int v8; // edx

  v1 = *((_DWORD *)this + 244);
  v2 = 0;
  v3 = -1;
  v4 = FMOD::DSPTremolo::phaseMap;
  do
  {
    if ( v4->channelcount == v1 && v1 <= 8 )
      v3 = v2;
    ++v2;
    ++v4;
  }
  while ( v2 != 5 );
  if ( v1 > 0 )
  {
    v5 = *((_DWORD *)this + 150);
    for ( i = 0; v1 > (int)i; ++i )
    {
      while ( 1 )
      {
        v7 = 5.0 / (float)v1;
        if ( v3 != -1 )
          v7 = FMOD::DSPTremolo::phaseMap[v3].phase[i];
        v8 = (int)(float)((float)(*((float *)this + 138) - (float)(v7 * *((float *)this + 140))) * *((float *)this + 149));
        *((_DWORD *)this + i + 162) = v8;
        if ( v8 < v5 )
          break;
        *((_DWORD *)this + i + 162) = v8 - v5;
LABEL_7:
        if ( v1 <= (int)++i )
          return;
      }
      if ( v8 >= 0 )
        goto LABEL_7;
      *((_DWORD *)this + i + 162) = v5 + v8;
    }
  }
}


// Address: 0x2214fc0 | Name: _ZN4FMOD10DSPTremolo15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPTremolo::releaseInternal(FMOD::DSPTremolo *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2214fd0 | Name: _ZN4FMOD10DSPTremolo15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPTremolo::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPTremolo::releaseInternal((FMOD::DSPTremolo *const)dsp_state->instance);
}


// Address: 0x2214fe0 | Name: _ZN4FMOD10DSPTremolo13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPTremolo::resetInternal(FMOD::DSPTremolo *const this)
{
  FMOD::DSPTremolo *v1; // rax
  int v2; // edx

  v1 = this;
  v2 = 16;
  do
  {
    *((_DWORD *)v1 + 162) = 0;
    *((_DWORD *)v1 + 178) = 0;
    v1 = (FMOD::DSPTremolo *)((char *)v1 + 4);
    *((_DWORD *)v1 + 193) = 0;
    *((_DWORD *)v1 + 209) = 0;
    --v2;
  }
  while ( v2 );
  *((_BYTE *)this + 556) = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2215030 | Name: _ZN4FMOD10DSPTremolo14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPTremolo::createInternal(FMOD::DSPTremolo *const this)
{
  double v1; // xmm1_8
  __int64 v2; // r12
  __int64 v3; // rax
  int v4; // ebx
  FMOD_RESULT_0 result; // eax
  __int64 v6; // rax
  int v7; // xmm0_4
  float v8; // xmm1_4
  int v9; // xmm0_4
  int v10; // xmm0_4

  v2 = 0;
  v3 = *((_QWORD *)this + 30);
  v4 = 0;
  *((_DWORD *)this + 244) = 0;
  if ( *(int *)(v3 + 96) > 0 )
  {
    while ( 1 )
    {
      result = FMOD::DSPI::setParameterFloat(
                 (FMOD::DSPI *const)this,
                 v4,
                 (__m128i)*(unsigned int *)(*(_QWORD *)(*(_QWORD *)(v3 + 104) + v2) + 56LL),
                 v1);
      if ( result )
        break;
      v3 = *((_QWORD *)this + 30);
      ++v4;
      v2 += 8;
      if ( *(_DWORD *)(v3 + 96) <= v4 )
        goto LABEL_6;
    }
  }
  else
  {
LABEL_6:
    v6 = *((_QWORD *)this + 22);
    v7 = *((_DWORD *)this + 245);
    v8 = *((float *)this + 246);
    *((_DWORD *)this + 243) = *(_DWORD *)(v6 + 1696);
    LODWORD(v6) = *(_DWORD *)(v6 + 1700);
    *((_DWORD *)this + 132) = v7;
    v9 = *((_DWORD *)this + 247);
    *((_DWORD *)this + 158) = 1006632960;
    *((_DWORD *)this + 134) = v9;
    *((_DWORD *)this + 161) = 1031798784;
    v10 = *((_DWORD *)this + 248);
    *((_DWORD *)this + 244) = v6;
    *((_DWORD *)this + 135) = v10;
    *((_DWORD *)this + 136) = *((_DWORD *)this + 249);
    *((_DWORD *)this + 137) = *((_DWORD *)this + 250);
    *((_DWORD *)this + 138) = *((_DWORD *)this + 251);
    *((_DWORD *)this + 140) = *((_DWORD *)this + 252);
    *((float *)this + 133) = v8;
    *((float *)this + 159) = 1.0 - v8;
    FMOD::DSPTremolo::resetInternal(this);
    FMOD::DSPTremolo::createLFOTable(this);
    FMOD::DSPTremolo::updateWaveform(this);
    FMOD::DSPTremolo::updateTiming(this);
    FMOD::DSPTremolo::applyPhase(this);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2215190 | Name: _ZN4FMOD10DSPTremolo14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPTremolo::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPTremolo::createInternal((FMOD::DSPTremolo *const)dsp_state->instance);
}


// Address: 0x22151a0 | Name: _ZN4FMOD10DSPTremolo13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPTremolo::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPTremolo::resetInternal((FMOD::DSPTremolo *const)dsp_state->instance);
}


// Address: 0x22151b0 | Name: _ZN4FMOD10DSPTremolo13getRampValuesEiPfS1_Pi
void __fastcall FMOD::DSPTremolo::getRampValues(
        FMOD::DSPTremolo *const this,
        int samplepos,
        float *p_lfolevel,
        float *p_lforamp,
        int *p_nextramppos)
{
  float *v6; // r12
  int v9; // esi
  float v10; // xmm0_4
  int v11; // edi
  int v12; // eax
  float v13; // xmm4_4
  float v14; // xmm3_4
  int v15; // edi
  float LFOTable; // xmm0_4
  float v17; // xmm2_4
  float v18; // xmm1_4
  float v19; // xmm3_4
  int v20; // ecx
  int v21; // eax
  float v22; // xmm4_4
  float v23; // xmm3_4
  int v24; // edi
  int v25; // esi
  float v26; // xmm0_4
  int *v27; // [rsp+0h] [rbp-38h]
  int *v28; // [rsp+0h] [rbp-38h]
  int *v29; // [rsp+0h] [rbp-38h]
  int *p_nextrampposa; // [rsp+8h] [rbp-30h]

  v6 = p_lforamp;
  v9 = *((_DWORD *)this + 148);
  if ( v9 <= samplepos )
  {
    v10 = 1.0 - *((float *)this + 133);
    v11 = *((_DWORD *)this + 145);
    *p_lfolevel = v10;
    *p_lforamp = 0.0;
    *p_nextramppos = v11;
    goto LABEL_3;
  }
  v11 = *((_DWORD *)this + 147);
  if ( samplepos >= v11 )
  {
    v12 = 16 * (samplepos - v11) / (v9 - v11);
    if ( v12 == 15 )
    {
      v14 = 15.0;
      *p_nextramppos = v9;
      if ( *((_DWORD *)this + 147) + (int)(float)((float)(*((float *)this + 155) * 15.0) + 0.5) != samplepos )
      {
LABEL_11:
        p_nextrampposa = p_nextramppos;
        LFOTable = FMOD::DSPTremolo::readLFOTable(this, 16 - v12, 0, p_lforamp);
        v17 = (float)*((int *)this + 147);
        v18 = (float)samplepos;
        *p_lfolevel = LFOTable;
        v19 = v14 * *((float *)this + 155);
LABEL_12:
        p_nextramppos = p_nextrampposa;
        v11 = *p_nextrampposa;
        *p_lfolevel = (float)((float)(v18 - (float)(v17 + v19)) * *v6) + LFOTable;
        goto LABEL_3;
      }
    }
    else
    {
      v13 = *((float *)this + 155);
      v14 = (float)v12;
      v15 = (int)(float)((float)((float)(v12 + 1) * v13)
                       + (float)((float)((float)((float)(v9 - v11) - 0.5) * 0.0625) / (float)(0.0625 * (float)(v9 - v11))))
          + v11;
      if ( samplepos >= v15 )
        v15 = samplepos + 1;
      *p_nextramppos = v15;
      if ( *((_DWORD *)this + 147) + (int)(float)((float)(v13 * (float)v12) + 0.5) != samplepos )
        goto LABEL_11;
      if ( !v12 )
      {
        v28 = p_nextramppos;
        v25 = 16;
LABEL_25:
        v26 = FMOD::DSPTremolo::readLFOTable(this, v25, 1, p_lforamp);
        p_nextramppos = v28;
        *p_lfolevel = v26;
        v11 = *v28;
        goto LABEL_3;
      }
    }
    v27 = p_nextramppos;
    FMOD::DSPTremolo::readLFOTable(this, 16 - v12, 0, p_lforamp);
    p_nextramppos = v27;
    v11 = *v27;
    goto LABEL_3;
  }
  v20 = *((_DWORD *)this + 146);
  if ( samplepos >= v20 )
  {
    *p_lfolevel = 1.0;
    *v6 = 0.0;
    *p_nextramppos = v11;
    goto LABEL_3;
  }
  v11 = *((_DWORD *)this + 145);
  if ( samplepos < v11 )
  {
    *p_lfolevel = 1.0 - *((float *)this + 133);
    *v6 = 0.0;
    *p_nextramppos = v11;
  }
  else
  {
    v21 = 16 * (samplepos - v11) / (v20 - v11);
    if ( v21 == 15 )
    {
      v23 = 15.0;
      *p_nextramppos = v20;
      if ( *((_DWORD *)this + 145) + (int)(float)((float)(*((float *)this + 154) * 15.0) + 0.5) != samplepos )
      {
LABEL_19:
        p_nextrampposa = p_nextramppos;
        LFOTable = FMOD::DSPTremolo::readLFOTable(this, v21, 1, v6);
        v17 = (float)*((int *)this + 145);
        *p_lfolevel = LFOTable;
        v18 = (float)samplepos;
        v19 = v23 * *((float *)this + 154);
        goto LABEL_12;
      }
    }
    else
    {
      v22 = *((float *)this + 154);
      v23 = (float)v21;
      v24 = (int)(float)((float)((float)(v21 + 1) * v22)
                       + (float)((float)((float)((float)(v20 - v11) - 0.5) * 0.0625)
                               / (float)(0.0625 * (float)(v20 - v11))))
          + v11;
      if ( samplepos >= v24 )
        v24 = samplepos + 1;
      *p_nextramppos = v24;
      if ( *((_DWORD *)this + 145) + (int)(float)((float)(v22 * (float)v21) + 0.5) != samplepos )
        goto LABEL_19;
      if ( !v21 )
      {
        v28 = p_nextramppos;
        p_lforamp = v6;
        v25 = 0;
        goto LABEL_25;
      }
    }
    v29 = p_nextramppos;
    FMOD::DSPTremolo::readLFOTable(this, v21, 1, v6);
    p_nextramppos = v29;
    v11 = *v29;
  }
LABEL_3:
  if ( *((_DWORD *)this + 150) <= v11 )
    *p_nextramppos = 0;
}


// Address: 0x2215540 | Name: _ZN4FMOD10DSPTremolo11getLFOLevelEi
float __fastcall FMOD::DSPTremolo::getLFOLevel(FMOD::DSPTremolo *const this, int samplepos)
{
  int v4; // ecx
  int v5; // esi
  int v6; // ecx
  int v7; // edi
  int v9; // r12d
  float LFOTable; // xmm0_4
  int v11; // r12d
  float v12; // xmm0_4
  float ramp[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  v4 = *((_DWORD *)this + 148);
  if ( v4 <= samplepos )
    return 1.0 - *((float *)this + 133);
  v5 = *((_DWORD *)this + 147);
  if ( samplepos >= v5 )
  {
    v9 = 16 * (samplepos - v5) / (v4 - v5);
    LFOTable = FMOD::DSPTremolo::readLFOTable(this, 16 - v9, 0, ramp);
    return (float)((float)((float)samplepos
                         - (float)((float)*((int *)this + 147) + (float)((float)v9 * *((float *)this + 155))))
                 * ramp[0])
         + LFOTable;
  }
  else
  {
    v6 = *((_DWORD *)this + 146);
    if ( samplepos >= v6 )
    {
      return 1.0;
    }
    else
    {
      v7 = *((_DWORD *)this + 145);
      if ( samplepos < v7 )
        return 1.0 - *((float *)this + 133);
      v11 = 16 * (samplepos - v7) / (v6 - v7);
      v12 = FMOD::DSPTremolo::readLFOTable(this, v11, 1, ramp);
      return (float)((float)((float)samplepos
                           - (float)((float)*((int *)this + 145) + (float)((float)v11 * *((float *)this + 154))))
                   * ramp[0])
           + v12;
    }
  }
}


// Address: 0x2215670 | Name: _ZN4FMOD10DSPTremolo12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPTremolo::readInternal(
        FMOD::DSPTremolo *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  float *v6; // r12
  char v7; // r14
  int v10; // ecx
  char v11; // bl
  float v12; // xmm0_4
  float v13; // xmm0_4
  char v14; // di
  float v15; // xmm0_4
  char v16; // si
  float v17; // xmm0_4
  char v18; // cl
  float v19; // xmm0_4
  float v20; // xmm0_4
  int v21; // xmm0_4
  float v22; // xmm0_4
  char v23; // r13
  float v24; // xmm0_4
  float v25; // xmm1_4
  __int64 v26; // r14
  char *v27; // rbx
  __int64 v28; // r13
  int v29; // esi
  int v30; // edx
  int v31; // esi
  __int64 v32; // rax
  char *v34; // r14
  __int64 i; // rbx
  int v36; // esi
  float v37; // xmm0_4
  int v38; // edx
  int v39; // edx
  float v40; // xmm0_4
  float v41; // xmm0_4
  unsigned int v42; // [rsp+8h] [rbp-50h]
  char v43; // [rsp+8h] [rbp-50h]
  __int64 v44; // [rsp+10h] [rbp-48h]

  v6 = inbuffer;
  if ( !inbuffer )
    return FMOD_RESULT::FMOD_OK_0;
  v7 = 0;
  v10 = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  if ( *((_DWORD *)this + 244) != inchannels )
  {
    *((_DWORD *)this + 244) = inchannels;
    v7 = 1;
  }
  v11 = 0;
  if ( *((_DWORD *)this + 243) != v10 )
  {
    *((_DWORD *)this + 243) = v10;
    v11 = 1;
  }
  v12 = *((float *)this + 245);
  if ( v12 != *((float *)this + 132) )
  {
    *((float *)this + 132) = v12;
    v11 = 1;
  }
  v13 = *((float *)this + 246);
  if ( v13 == *((float *)this + 133) )
  {
    v14 = 0;
  }
  else
  {
    *((float *)this + 133) = v13;
    v14 = 1;
  }
  v15 = *((float *)this + 247);
  if ( v15 == *((float *)this + 134) )
  {
    v16 = 0;
  }
  else
  {
    *((float *)this + 134) = v15;
    v16 = 1;
  }
  v17 = *((float *)this + 248);
  if ( v17 == *((float *)this + 135) )
  {
    v18 = 0;
  }
  else
  {
    *((float *)this + 135) = v17;
    v18 = 1;
  }
  v19 = *((float *)this + 249);
  if ( v19 != *((float *)this + 136) )
  {
    *((float *)this + 136) = v19;
    v18 = 1;
  }
  v20 = *((float *)this + 250);
  if ( v20 != *((float *)this + 137) )
  {
    *((float *)this + 137) = v20;
    v18 = 1;
  }
  if ( *((_BYTE *)this + 556) )
  {
    v21 = *((_DWORD *)this + 251);
    *((_BYTE *)this + 556) = 0;
    v7 = 1;
    *((_DWORD *)this + 138) = v21;
  }
  v22 = *((float *)this + 252);
  if ( v22 != *((float *)this + 140) )
  {
    *((float *)this + 140) = v22;
    v7 = 1;
  }
  v23 = 0;
  if ( v14 )
  {
    v24 = *((float *)this + 133);
    v23 = 1;
    *((float *)this + 159) = 1.0 - v24;
    v25 = v24 / *((float *)this + 154);
    *((float *)this + 157) = v24 / *((float *)this + 155);
    *((float *)this + 156) = v25;
  }
  if ( v16 )
  {
    v43 = v18;
    v23 = 1;
    FMOD::DSPTremolo::createLFOTable(this);
    v18 = v43;
  }
  if ( v18 )
  {
    FMOD::DSPTremolo::updateWaveform(this);
    goto LABEL_64;
  }
  if ( v11 )
  {
LABEL_64:
    v23 = 1;
    FMOD::DSPTremolo::updateTiming(this);
  }
  if ( v7 )
  {
    v23 = 1;
    FMOD::DSPTremolo::applyPhase(this);
  }
  if ( !length )
  {
    v42 = -2;
    v44 = 4LL * inchannels;
    goto LABEL_32;
  }
  if ( inchannels > 0 )
  {
    v34 = (char *)this + 712;
    for ( i = 0; i != (unsigned int)(inchannels - 1) + 1LL; ++i )
    {
      if ( v23 )
      {
        v36 = *((_DWORD *)v34 - 16) + 128;
        *((_DWORD *)v34 + 32) = v36;
        if ( v36 >= *((_DWORD *)this + 150) )
        {
          *((_DWORD *)v34 + 32) = 0;
          v36 = 0;
        }
        *((float *)v34 + 16) = (float)(FMOD::DSPTremolo::getLFOLevel(this, v36) - *(float *)v34)
                             * *((float *)this + 158);
      }
      else
      {
        FMOD::DSPTremolo::getRampValues(this, *((_DWORD *)v34 - 16), (float *)v34, (float *)v34 + 16, (int *)v34 + 32);
      }
      outbuffer[i] = v6[i] * *(float *)v34;
      v37 = *(float *)v34 + *((float *)v34 + 16);
      v38 = *((_DWORD *)v34 - 16) + 1;
      *((_DWORD *)v34 - 16) = v38;
      *(float *)v34 = v37;
      if ( v38 < *((_DWORD *)this + 150) )
        goto LABEL_56;
      if ( (_DWORD)i || (v41 = *((float *)this + 152) + *((float *)this + 151), *((float *)this + 152) = v41, v41 < 1.0) )
      {
        v39 = *((_DWORD *)this + 153);
        if ( v39 <= 0 )
        {
          *((_DWORD *)v34 - 16) = 0;
          goto LABEL_56;
        }
      }
      else
      {
        *((_DWORD *)this + 153) = inchannels;
        v39 = inchannels;
        *((float *)this + 152) = v41 - 1.0;
      }
      *((_DWORD *)v34 - 16) = -1;
      *((_DWORD *)this + 153) = v39 - 1;
LABEL_56:
      v34 += 4;
    }
  }
  v32 = 4LL * inchannels;
  v6 = (float *)((char *)v6 + v32);
  outbuffer = (float *)((char *)outbuffer + v32);
  v44 = v32;
  v42 = length - 2;
  if ( length != 1 )
  {
LABEL_32:
    v26 = (unsigned int)(inchannels - 1) + 1LL;
    while ( inchannels <= 0 )
    {
LABEL_45:
      v6 = (float *)((char *)v6 + v44);
      outbuffer = (float *)((char *)outbuffer + v44);
      if ( !v42 )
        return FMOD_RESULT::FMOD_OK_0;
      --v42;
    }
    v27 = (char *)this + 712;
    v28 = 0;
    while ( 1 )
    {
      v31 = *((_DWORD *)v27 - 16);
      if ( v31 >= *((_DWORD *)v27 + 32) )
      {
        FMOD::DSPTremolo::getRampValues(this, v31, (float *)v27, (float *)v27 + 16, (int *)v27 + 32);
        v31 = *((_DWORD *)v27 - 16);
      }
      v29 = v31 + 1;
      outbuffer[v28] = v6[v28] * *(float *)v27;
      *((_DWORD *)v27 - 16) = v29;
      *(float *)v27 = *(float *)v27 + *((float *)v27 + 16);
      if ( v29 < *((_DWORD *)this + 150) )
        goto LABEL_39;
      if ( !(_DWORD)v28 )
      {
        v40 = *((float *)this + 152) + *((float *)this + 151);
        if ( v40 >= 1.0 )
        {
          *((_DWORD *)this + 153) = inchannels;
          v30 = inchannels;
          *((float *)this + 152) = v40 - 1.0;
          goto LABEL_38;
        }
        *((float *)this + 152) = v40;
      }
      v30 = *((_DWORD *)this + 153);
      if ( v30 <= 0 )
      {
        ++v28;
        *((_DWORD *)v27 - 16) = 0;
        v27 += 4;
        if ( v28 == v26 )
          goto LABEL_45;
      }
      else
      {
LABEL_38:
        *((_DWORD *)v27 - 16) = -1;
        *((_DWORD *)this + 153) = v30 - 1;
LABEL_39:
        ++v28;
        v27 += 4;
        if ( v28 == v26 )
          goto LABEL_45;
      }
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2215bc0 | Name: _ZN4FMOD10DSPTremolo12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPTremolo::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPTremolo::readInternal(
           (FMOD::DSPTremolo *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x2215bd0 | Name: _ZN4FMOD10DSPTremolo25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPTremolo::setParameterFloatInternal(
        FMOD::DSPTremolo *const this,
        int index,
        float a3,
        float value)
{
  __int64 result; // rax

  switch ( index )
  {
    case 0:
      *((float *)this + 245) = a3;
      result = 0;
      break;
    case 1:
      *((float *)this + 246) = a3;
      result = 0;
      break;
    case 2:
      *((float *)this + 247) = a3;
      result = 0;
      break;
    case 3:
      *((float *)this + 248) = a3;
      result = 0;
      break;
    case 4:
      *((float *)this + 249) = a3;
      result = 0;
      break;
    case 5:
      *((float *)this + 250) = a3;
      result = 0;
      break;
    case 6:
      *((float *)this + 251) = a3;
      *((_BYTE *)this + 556) = a3 > 0.0;
      result = 0;
      break;
    case 7:
      *((float *)this + 252) = a3;
      goto LABEL_3;
    default:
LABEL_3:
      result = 0;
      break;
  }
  return result;
}


// Address: 0x2215c80 | Name: _ZN4FMOD10DSPTremolo25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPTremolo::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPTremolo::setParameterFloatInternal((FMOD::DSPTremolo *const)dsp_state->instance, index, a3, value);
}


// Address: 0x2215c90 | Name: _ZN4FMOD10DSPTremolo25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPTremolo::getParameterFloatInternal(
        FMOD::DSPTremolo *const this,
        int index,
        float *value,
        char *valuestr)
{
  float v4; // xmm0_4

  switch ( index )
  {
    case 0:
      *value = *((float *)this + 245);
      if ( valuestr )
      {
        v4 = *((float *)this + 245);
        goto LABEL_4;
      }
      break;
    case 1:
      *value = *((float *)this + 246);
      if ( valuestr )
      {
        v4 = *((float *)this + 246);
        goto LABEL_4;
      }
      break;
    case 2:
      *value = *((float *)this + 247);
      if ( valuestr )
      {
        v4 = *((float *)this + 247);
        goto LABEL_4;
      }
      break;
    case 3:
      *value = *((float *)this + 248);
      if ( valuestr )
      {
        v4 = *((float *)this + 248);
        goto LABEL_4;
      }
      break;
    case 4:
      *value = *((float *)this + 249);
      if ( valuestr )
      {
        v4 = *((float *)this + 249);
        goto LABEL_4;
      }
      break;
    case 5:
      *value = *((float *)this + 250);
      if ( valuestr )
      {
        v4 = *((float *)this + 250);
        goto LABEL_4;
      }
      break;
    case 6:
      *value = *((float *)this + 251);
      if ( valuestr )
      {
        v4 = *((float *)this + 251);
        goto LABEL_4;
      }
      break;
    case 7:
      *value = *((float *)this + 252);
      if ( valuestr )
      {
        v4 = *((float *)this + 252);
LABEL_4:
        sprintf(valuestr, "%.02f", v4);
      }
      break;
    default:
      return FMOD_RESULT::FMOD_OK_0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2215df0 | Name: _ZN4FMOD10DSPTremolo25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPTremolo::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPTremolo::getParameterFloatInternal(
           (FMOD::DSPTremolo *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


