// Address: 0x21cfaa0 | Name: _ZN4FMOD7HashMapIiPNS_22ProfileFileEntryRemoteENS_19ArrayConstruct_AutoIS2_EENS_18HashMapDefaultHashEjE6rehashEi
FMOD_RESULT_0 __fastcall FMOD::HashMap<int,FMOD::ProfileFileEntryRemote *,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote *>,FMOD::HashMapDefaultHash,unsigned int>::rehash(
        FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int> *const this,
        int hashSize)
{
  FMOD_RESULT_0 result; // eax
  int mSize; // edx
  int v6; // esi
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v7; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v8; // r12
  __int64 v9; // rdx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // rsi
  unsigned __int64 v11; // rax
  int v12; // r10d
  int v13; // eax
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v14; // rcx
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v15; // rdx
  __int64 v16; // rdi
  __int64 v17; // r8
  unsigned int v18; // esi
  unsigned int *p_next; // rdx
  __int64 next; // rax
  FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v21; // rdx

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  mSize = this->mBuckets.mSize;
  if ( mSize < hashSize && mSize == this->mNodes.mSize && this->mFreeList == -1 )
  {
    if ( hashSize > (int)abs32(this->mNodes.mCapacity) )
    {
      v6 = 16 * hashSize;
      if ( (unsigned int)(v6 - 1) > 0x3FFFFFFE )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      v7 = (FMOD::HashMap<int,FMOD::ProfileFileEntryRemote*,FMOD::ArrayConstruct_Auto<FMOD::ProfileFileEntryRemote*>,FMOD::HashMapDefaultHash,unsigned int>::Node *)FMOD::MemPool::alloc(off_286F358->gSystemMemPool, v6, "../../../core_api/src/fmod_memory.h", 232, 0, 0);
      v8 = v7;
      if ( !v7 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      v9 = this->mNodes.mSize;
      if ( (_DWORD)v9 )
        memcpy_0(v7, this->mNodes.mData, 16 * v9);
      if ( this->mNodes.mCapacity > 0 )
      {
        mData = this->mNodes.mData;
        if ( mData )
          FMOD::MemPool::free(off_286F358->gSystemMemPool, mData, "../../../core_api/src/fmod_memory.h", 244);
      }
      this->mNodes.mData = v8;
      this->mNodes.mCapacity = hashSize;
    }
    result = FMOD::DynamicArray<unsigned int,FMOD::ArrayConstruct_Fast_Uninit,FMOD::AlignedAllocator<1>>::resize(
               &this->mBuckets,
               hashSize);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( hashSize > 0 )
      {
        v11 = 0;
        do
        {
          this->mBuckets.mData[v11 / 4] = -1;
          v11 += 4LL;
        }
        while ( v11 != 4LL * (unsigned int)(hashSize - 1) + 4 );
      }
      v12 = this->mNodes.mSize;
      if ( v12 > 0 )
      {
        v13 = this->mBuckets.mSize;
        v14 = this->mNodes.mData;
        if ( !v13 )
          return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
        v15 = this->mNodes.mData;
        v16 = 1;
        v17 = 0;
        v18 = 0;
        while ( 1 )
        {
          p_next = &this->mBuckets.mData[v15->key & (v13 - 1)];
          next = (int)*p_next;
          if ( (_DWORD)next != -1 )
          {
            do
            {
              v21 = &v14[next];
              next = (int)v21->next;
            }
            while ( (_DWORD)next != -1 );
            p_next = &v21->next;
          }
          *p_next = v18;
          v14 = this->mNodes.mData;
          ++v18;
          *(unsigned int *)((char *)&v14->next + v17) = -1;
          if ( v18 == v12 )
            break;
          v13 = this->mBuckets.mSize;
          v15 = &v14[v16];
          if ( !v13 )
            return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          v17 = v16 * 16;
          ++v16;
        }
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x220cfe0 | Name: _ZN4FMOD11ReturnTable6removeEi
FMOD_RESULT_0 __fastcall FMOD::ReturnTable::remove(FMOD::ReturnTable *const this, int id)
{
  int mSize; // edx
  FMOD_RESULT_0 result; // eax
  signed int *p_next; // r9
  signed int next; // edx
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // r8
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v7; // rcx
  signed int v8; // ecx
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v9; // rax

  if ( !this->mMap.mNodeCount )
    return FMOD_RESULT::FMOD_OK_0;
  mSize = this->mMap.mBuckets.mSize;
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( !mSize )
    return result;
  p_next = (signed int *)&this->mMap.mBuckets.mData[id & (mSize - 1)];
  next = *p_next;
  if ( *p_next == -1 )
    return FMOD_RESULT::FMOD_OK_0;
  mData = this->mMap.mNodes.mData;
  v7 = &mData[next];
  if ( v7->key != id )
  {
    while ( 1 )
    {
      next = v7->next;
      if ( next == -1 )
        return FMOD_RESULT::FMOD_OK_0;
      v9 = &mData[next];
      if ( v9->key == id )
      {
        p_next = (signed int *)&v7->next;
        goto LABEL_12;
      }
      v7 = &mData[next];
    }
  }
  v9 = &mData[next];
LABEL_12:
  v8 = v9->next;
  v9->value = 0;
  *p_next = v8;
  v9->next = this->mMap.mFreeList;
  this->mMap.mFreeList = next;
  --this->mMap.mNodeCount;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220d070 | Name: _ZNK4FMOD11ReturnTable4findEi
FMOD::DSPReturn *__fastcall FMOD::ReturnTable::find(const FMOD::ReturnTable *const this, int id)
{
  int mSize; // edx
  FMOD::DSPReturn *result; // rax
  signed int v4; // ecx
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // rdx
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v6; // rax
  __int64 next; // rax

  if ( !this->mMap.mNodeCount )
    return 0;
  mSize = this->mMap.mBuckets.mSize;
  result = 0;
  if ( mSize )
  {
    v4 = this->mMap.mBuckets.mData[id & (mSize - 1)];
    if ( v4 != -1 )
    {
      mData = this->mMap.mNodes.mData;
      v6 = &mData[v4];
      if ( v6->key == id )
        return v6->value;
      while ( 1 )
      {
        next = (int)v6->next;
        if ( (_DWORD)next == -1 )
          break;
        v6 = &mData[next];
        if ( v6->key == id )
          return v6->value;
      }
      return 0;
    }
  }
  return result;
}


