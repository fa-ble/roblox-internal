// Address: 0x2237390 | Name: _ZN4FMOD4DSPI7convertEPvS1_17FMOD_SOUND_FORMATS2_jiifb
__int64 __fastcall FMOD::DSPI::convert(
        __int16 *outbuffer,
        float *inbuffer,
        int outformat,
        FMOD_SOUND_FORMAT_0 informat,
        unsigned int length,
        int destchannelstep,
        float volume,
        int srcchannelstep,
        bool clamp)
{
  char v9; // r11
  __int64 result; // rax
  float v11; // xmm0_4
  int v12; // eax
  __int64 v13; // r9
  int v14; // edx
  float v15; // xmm1_4
  __m128 v16; // xmm3
  __int64 v17; // r9
  int v18; // eax
  __m128 v19; // xmm1
  float v20; // xmm2_4
  __m128 v21; // xmm1
  float v22; // xmm0_4
  unsigned int v23; // r10d
  unsigned __int64 v24; // r13
  __int64 v25; // rdx
  __int64 v26; // r8
  __int64 v27; // rcx
  __int64 v28; // r9
  float *v29; // rax
  __int64 v30; // rcx
  unsigned int v31; // edx
  float *v32; // r10
  __int64 v33; // rsi
  int v34; // ecx
  __int64 v35; // rax
  __int64 v36; // r9
  int v37; // r11d
  int v38; // eax
  float v39; // xmm0_4
  __int64 v40; // r9
  int v41; // ecx
  int v42; // eax
  int v43; // edx
  float v44; // xmm0_4
  unsigned int v45; // ecx
  int *v46; // rdx
  __int64 v47; // rbx
  __int64 v48; // r10
  float *v49; // rax
  __int64 v50; // r8
  float v51; // xmm1_4
  __int64 v52; // rax
  int v53; // r11d
  __int64 v54; // r9
  float v55; // xmm1_4
  float v56; // xmm0_4
  unsigned int v57; // r8d
  unsigned __int64 v58; // rbp
  unsigned __int64 v59; // r10
  float *v60; // rdx
  __int64 v61; // rbx
  unsigned int v62; // ecx
  float *v63; // rax
  int v64; // esi
  float v65; // xmm1_4
  int v66; // esi
  float v67; // xmm1_4
  int v68; // esi
  int v69; // esi
  float v70; // xmm1_4
  int v71; // esi
  float v72; // xmm1_4
  int v73; // esi
  __int64 v74; // rax
  int v75; // r11d
  __int64 v76; // r9
  int v77; // eax
  float v78; // xmm0_4
  int v79; // edx
  int v80; // eax
  float v81; // xmm0_4
  unsigned int v82; // ecx
  __int64 v83; // r15
  __int16 *v84; // rdx
  __int64 v85; // r14
  __int64 v86; // r12
  float *v87; // rax
  char v88; // r10
  int v89; // r9d
  int v90; // r8d
  int v91; // edi
  int v92; // esi
  char v93; // r9
  char v94; // r8
  char v95; // di
  __int64 v96; // rax
  int v97; // r11d
  char v98; // dl
  int v99; // eax
  unsigned int v100; // ebx
  unsigned int v101; // ecx
  float *v102; // rdx
  __int64 v103; // r10
  float *v104; // rax
  __int64 v105; // r8
  float v106; // xmm1_4
  __int64 v107; // rax
  int v108; // r11d
  __int64 v109; // r9
  float v110; // xmm1_4
  __int64 v111; // [rsp+0h] [rbp-88h]
  unsigned int v112; // [rsp+0h] [rbp-88h]
  __int64 v113; // [rsp+0h] [rbp-88h]
  __int64 v114; // [rsp+0h] [rbp-88h]
  __int64 v115; // [rsp+8h] [rbp-80h]
  __int64 v116; // [rsp+8h] [rbp-80h]
  __int64 v117; // [rsp+8h] [rbp-80h]
  __int64 v118; // [rsp+10h] [rbp-78h]
  unsigned int v119; // [rsp+10h] [rbp-78h]
  __int64 v120; // [rsp+18h] [rbp-70h]
  __int16 *v121; // [rsp+18h] [rbp-70h]
  float *v122; // [rsp+20h] [rbp-68h]
  float *inbuffera; // [rsp+28h] [rbp-60h]
  float *inbufferb; // [rsp+28h] [rbp-60h]
  int inbufferc; // [rsp+28h] [rbp-60h]
  int destchannelstepa; // [rsp+38h] [rbp-50h]
  unsigned int v127; // [rsp+48h] [rbp-40h]

  v9 = length;
  if ( outformat == 5 )
  {
    switch ( informat )
    {
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
        v22 = volume * 0.0078125;
        v23 = length >> 3;
        v127 = length >> 3;
        if ( length >> 3 )
        {
          v24 = 8 * destchannelstep;
          v25 = 6 * destchannelstep;
          v111 = 4 * v24;
          v115 = 8 * srcchannelstep;
          v26 = destchannelstep;
          destchannelstepa = destchannelstep;
          v27 = 5 * destchannelstep;
          v118 = 3LL * destchannelstep;
          v28 = 7LL * destchannelstep;
          v29 = (float *)outbuffer;
          v120 = v27;
          v30 = 4 * v25;
          v31 = v23;
          v32 = inbuffer;
          inbuffera = inbuffer;
          v33 = v30;
          do
          {
            *v29 = (float)*(char *)v32 * v22;
            v29[v26] = (float)*((char *)v32 + srcchannelstep) * v22;
            v29[v24 / 4] = (float)*((char *)v32 + 2 * srcchannelstep) * v22;
            v29[v118] = (float)*((char *)v32 + 3 * srcchannelstep) * v22;
            v29[v26 * 4] = (float)SLOBYTE(v32[srcchannelstep]) * v22;
            v29[v120] = (float)*((char *)v32 + 5 * srcchannelstep) * v22;
            *(float *)((char *)v29 + v33) = (float)*((char *)v32 + 6 * srcchannelstep) * v22;
            v34 = *((char *)v32 + 7 * srcchannelstep);
            v32 = (float *)((char *)v32 + v115);
            v29[v28] = (float)v34 * v22;
            v29 = (float *)((char *)v29 + v111);
            --v31;
          }
          while ( v31 );
          destchannelstep = destchannelstepa;
          v35 = v127 - 1 + 1LL;
          outbuffer = (__int16 *)((char *)outbuffer + v35 * v111);
          inbuffer = (float *)((char *)inbuffera + v115 * v35);
        }
        v36 = 4LL * destchannelstep;
        v37 = v9 & 7;
        if ( !v37 )
          return 0;
        do
        {
          v38 = *(char *)inbuffer;
          inbuffer = (float *)((char *)inbuffer + srcchannelstep);
          *(float *)outbuffer = (float)v38 * v22;
          outbuffer = (__int16 *)((char *)outbuffer + v36);
          --v37;
        }
        while ( v37 );
        return 0;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
        v56 = volume * 0.000030517578;
        v57 = length >> 3;
        if ( v57 )
        {
          v58 = 8 * destchannelstep;
          v113 = 4 * v58;
          v59 = 8 * srcchannelstep;
          v60 = inbuffer;
          v61 = destchannelstep;
          v62 = v57;
          v116 = 2 * v59;
          v63 = (float *)outbuffer;
          inbufferb = inbuffer;
          do
          {
            v64 = *((__int16 *)v60 + srcchannelstep);
            *v63 = (float)*(__int16 *)v60 * v56;
            v65 = (float)v64;
            v66 = SLOWORD(v60[srcchannelstep]);
            v63[v61] = v65 * v56;
            v67 = (float)v66;
            v68 = *((__int16 *)v60 + 3 * srcchannelstep);
            v63[v58 / 4] = v67 * v56;
            v63[3 * destchannelstep] = (float)v68 * v56;
            v69 = *((__int16 *)v60 + 5 * srcchannelstep);
            v63[v61 * 4] = (float)SLOWORD(v60[v59 / 4]) * v56;
            v70 = (float)v69;
            v71 = SLOWORD(v60[3 * srcchannelstep]);
            v63[5 * destchannelstep] = v70 * v56;
            v72 = (float)v71;
            v73 = *((__int16 *)v60 + 7 * srcchannelstep);
            v60 = (float *)((char *)v60 + v116);
            v63[6 * destchannelstep] = v72 * v56;
            v63[7 * destchannelstep] = (float)v73 * v56;
            v63 = (float *)((char *)v63 + v113);
            --v62;
          }
          while ( v62 );
          v74 = v57 - 1 + 1LL;
          outbuffer = (__int16 *)((char *)outbuffer + v74 * v113);
          inbuffer = (float *)((char *)inbufferb + v116 * v74);
        }
        v75 = v9 & 7;
        if ( !v75 )
          return 0;
        v76 = 4LL * destchannelstep;
        do
        {
          v77 = *(__int16 *)inbuffer;
          inbuffer = (float *)((char *)inbuffer + 2 * srcchannelstep);
          *(float *)outbuffer = (float)v77 * v56;
          outbuffer = (__int16 *)((char *)outbuffer + v76);
          --v75;
        }
        while ( v75 );
        return 0;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
        v39 = volume * 0.00000011920929;
        if ( !length )
          return 0;
        v40 = 4LL * destchannelstep;
        v41 = 0;
        do
        {
          ++v41;
          v42 = (*(unsigned __int8 *)inbuffer << 8) | (*((unsigned __int8 *)inbuffer + srcchannelstep) << 16);
          v43 = *((unsigned __int8 *)inbuffer + 2 * srcchannelstep);
          inbuffer = (float *)((char *)inbuffer + 3 * srcchannelstep);
          *(float *)outbuffer = (float)(((v43 << 24) | v42) >> 8) * v39;
          outbuffer = (__int16 *)((char *)outbuffer + v40);
        }
        while ( v41 != length );
        return 0;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        v44 = volume * 4.6566129e-10;
        v45 = length >> 2;
        v112 = length >> 2;
        if ( length >> 2 )
        {
          v46 = (int *)inbuffer;
          v47 = destchannelstep;
          v48 = 1 * v47;
          v49 = (float *)outbuffer;
          v50 = 16LL * srcchannelstep;
          do
          {
            *v49 = (float)*v46 * v44;
            v49[v47] = (float)v46[srcchannelstep] * v44;
            v49[2 * destchannelstep] = (float)v46[2 * srcchannelstep] * v44;
            v51 = (float)v46[3 * srcchannelstep] * v44;
            v46 = (int *)((char *)v46 + v50);
            v49[3 * destchannelstep] = v51;
            v49 = (float *)((char *)v49 + v48);
            --v45;
          }
          while ( v45 );
          v52 = v112 - 1 + 1LL;
          outbuffer = (__int16 *)((char *)outbuffer + v52 * v48);
          inbuffer = (float *)((char *)inbuffer + v50 * v52);
        }
        v53 = v9 & 3;
        if ( !v53 )
          return 0;
        v54 = 4LL * destchannelstep;
        do
        {
          v55 = (float)*(int *)inbuffer * v44;
          inbuffer += srcchannelstep;
          *(float *)outbuffer = v55;
          outbuffer = (__int16 *)((char *)outbuffer + v54);
          --v53;
        }
        while ( v53 );
        return 0;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
        if ( clamp )
        {
          if ( !length )
            return 0;
          v16.m128_i32[0] = -1082130432;
          v17 = 4LL * destchannelstep;
          v18 = 0;
          do
          {
            v19 = (__m128)*(unsigned int *)inbuffer;
            v19.m128_f32[0] = v19.m128_f32[0] * volume;
            ++v18;
            inbuffer += srcchannelstep;
            v20 = fminf(1.0, v19.m128_f32[0]);
            v21 = _mm_cmpge_ss(v19, v16);
            *(_DWORD *)outbuffer = _mm_andnot_ps(v21, (__m128)0xBF800000).m128_u32[0] | LODWORD(v20) & v21.m128_i32[0];
            outbuffer = (__int16 *)((char *)outbuffer + v17);
          }
          while ( v18 != length );
          return 0;
        }
        v100 = length >> 2;
        if ( length >> 2 )
        {
          v101 = length >> 2;
          v102 = inbuffer;
          v103 = 16LL * destchannelstep;
          v104 = (float *)outbuffer;
          v105 = 16LL * srcchannelstep;
          do
          {
            *v104 = *v102 * volume;
            v104[1] = v102[1] * volume;
            v104[2] = v102[2] * volume;
            v106 = v102[3];
            v102 = (float *)((char *)v102 + v105);
            v104[3] = v106 * volume;
            v104 = (float *)((char *)v104 + v103);
            --v101;
          }
          while ( v101 );
          v107 = v100 - 1 + 1LL;
          outbuffer = (__int16 *)((char *)outbuffer + v107 * v103);
          inbuffer = (float *)((char *)inbuffer + v105 * v107);
        }
        v108 = v9 & 3;
        if ( v108 )
        {
          v109 = 4LL * destchannelstep;
          do
          {
            v110 = *inbuffer;
            inbuffer += srcchannelstep;
            *(float *)outbuffer = v110 * volume;
            outbuffer = (__int16 *)((char *)outbuffer + v109);
            --v108;
          }
          while ( v108 );
          return 0;
        }
        break;
      default:
        return 0;
    }
    return 0;
  }
  result = 7;
  if ( informat != FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0 )
    return result;
  if ( outformat == 2 )
  {
    FMOD_Optimised_Routines.FMOD_DSP_Convert_FloatToPCM16(
      outbuffer,
      inbuffer,
      length,
      destchannelstep,
      srcchannelstep,
      volume * 32768.0);
    return 0;
  }
  if ( outformat <= 2 )
  {
    if ( outformat != 1 )
      return 0;
    v81 = volume * 128.0;
    v82 = length >> 2;
    v119 = length >> 2;
    if ( length >> 2 )
    {
      v83 = destchannelstep;
      v121 = outbuffer;
      v122 = inbuffer;
      inbufferc = destchannelstep;
      v84 = outbuffer;
      v85 = destchannelstep;
      v86 = 3 * destchannelstep;
      v114 = 16LL * srcchannelstep;
      v117 = 4 * destchannelstep;
      v87 = inbuffer;
      do
      {
        v88 = 0x80;
        v89 = (int)(float)(*v87 * v81);
        v90 = (int)(float)(v87[srcchannelstep] * v81);
        v91 = (int)(float)(v87[2 * srcchannelstep] * v81);
        v92 = (int)(float)(v87[3 * srcchannelstep] * v81);
        if ( v89 >= -128 )
        {
          v88 = (int)(float)(*v87 * v81);
          if ( v89 > 127 )
            v88 = 127;
        }
        *(_BYTE *)v84 = v88;
        v93 = 0x80;
        if ( v90 >= -128 )
        {
          v93 = v90;
          if ( v90 > 127 )
            v93 = 127;
        }
        *((_BYTE *)v84 + v83) = v93;
        v94 = 0x80;
        if ( v91 >= -128 )
        {
          v94 = v91;
          if ( v91 > 127 )
            v94 = 127;
        }
        LOBYTE(v84[v85]) = v94;
        v95 = 0x80;
        if ( v92 >= -128 )
        {
          v95 = v92;
          if ( v92 > 127 )
            v95 = 127;
        }
        *((_BYTE *)v84 + v86) = v95;
        v87 = (float *)((char *)v87 + v114);
        v84 = (__int16 *)((char *)v84 + v117);
        --v82;
      }
      while ( v82 );
      destchannelstep = inbufferc;
      v96 = v119 - 1 + 1LL;
      inbuffer = (float *)((char *)v122 + v96 * v114);
      outbuffer = (__int16 *)((char *)v121 + v117 * v96);
    }
    v97 = v9 & 3;
    if ( !v97 )
      return 0;
    do
    {
      v98 = 0x80;
      v99 = (int)(float)(*inbuffer * v81);
      if ( v99 >= -128 )
      {
        v98 = (int)(float)(*inbuffer * v81);
        if ( v99 > 127 )
          v98 = 127;
      }
      *(_BYTE *)outbuffer = v98;
      inbuffer += srcchannelstep;
      outbuffer = (__int16 *)((char *)outbuffer + destchannelstep);
      --v97;
    }
    while ( v97 );
    return 0;
  }
  else
  {
    if ( outformat != 3 )
    {
      if ( outformat == 4 )
      {
        v11 = volume * 2147483600.0;
        if ( length )
        {
          v12 = 0;
          v13 = 4LL * destchannelstep;
          do
          {
            v14 = -2147483647;
            v15 = *inbuffer * v11;
            if ( v15 > -2147483600.0 )
            {
              v14 = (int)v15;
              if ( v15 >= 2147483600.0 )
                v14 = 0x7FFFFFFF;
            }
            ++v12;
            *(_DWORD *)outbuffer = v14;
            inbuffer += srcchannelstep;
            outbuffer = (__int16 *)((char *)outbuffer + v13);
          }
          while ( v12 != length );
        }
      }
      return 0;
    }
    v78 = volume * 8388608.0;
    if ( !length )
      return 0;
    v79 = 0;
    do
    {
      v80 = (int)(float)(*inbuffer * v78);
      if ( v80 > (int)&unk_7FFFFF )
        v80 = (unsigned int)&unk_7FFFFF;
      if ( v80 < -8388608 )
        v80 = -8388608;
      ++v79;
      inbuffer += srcchannelstep;
      *(_BYTE *)outbuffer = v80;
      *((_BYTE *)outbuffer + 2) = BYTE2(v80);
      *((_BYTE *)outbuffer + 1) = BYTE1(v80);
      outbuffer = (__int16 *)((char *)outbuffer + 3 * destchannelstep);
    }
    while ( v79 != length );
    return 0;
  }
}


// Address: 0x2237ef0 | Name: _ZN4FMOD4DSPI7reorderEPfii17FMOD_CHANNELORDER
FMOD_RESULT_0 __fastcall FMOD::DSPI::reorder(float *buffer, int length, int channels, FMOD_CHANNELORDER_0 order)
{
  float *v4; // rax
  int v5; // xmm1_4
  int v6; // xmm0_4
  int v7; // xmm2_4
  int v9; // eax
  __int64 v10; // rdx
  int v11; // xmm1_4
  int v12; // xmm0_4
  int v13; // xmm2_4

  if ( order == FMOD_CHANNELORDER::FMOD_CHANNELORDER_WAVEFORMAT_0 && channels == 8 )
  {
    if ( length > 0 )
    {
      v4 = &buffer[8 * (length - 1) + 8];
      do
      {
        v5 = *((_DWORD *)buffer + 4);
        buffer += 8;
        v6 = *((_DWORD *)buffer - 3);
        v7 = *((_DWORD *)buffer - 1);
        *(buffer - 4) = *(buffer - 2);
        *((_DWORD *)buffer - 3) = v7;
        *((_DWORD *)buffer - 2) = v5;
        *((_DWORD *)buffer - 1) = v6;
      }
      while ( buffer != v4 );
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( order != FMOD_CHANNELORDER::FMOD_CHANNELORDER_ALSA_0 || channels != 6 && channels != 8 || length <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  v9 = 0;
  v10 = 4LL * channels;
  do
  {
    v11 = *((_DWORD *)buffer + 2);
    ++v9;
    v12 = *((_DWORD *)buffer + 3);
    v13 = *((_DWORD *)buffer + 5);
    buffer[2] = buffer[4];
    *((_DWORD *)buffer + 3) = v13;
    *((_DWORD *)buffer + 4) = v11;
    *((_DWORD *)buffer + 5) = v12;
    buffer = (float *)((char *)buffer + v10);
  }
  while ( v9 != length );
  return FMOD_RESULT::FMOD_OK_0;
}


