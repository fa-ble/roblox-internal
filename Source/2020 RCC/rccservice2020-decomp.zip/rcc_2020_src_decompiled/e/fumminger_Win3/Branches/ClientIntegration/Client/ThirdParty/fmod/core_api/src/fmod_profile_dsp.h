// Address: 0x220afb0 | Name: _ZNK4FMOD10ProfileDsp7getTypeEv
unsigned __int8 __fastcall FMOD::ProfileDsp::getType(const FMOD::ProfileDsp *const this)
{
  return 1;
}


// Address: 0x220b330 | Name: _ZN4FMOD10ProfileDspD2Ev
void __fastcall FMOD::ProfileDsp::~ProfileDsp(FMOD::ProfileDsp *const this)
{
  bool v1; // zf
  bool v2; // cc
  bool v3; // cc
  __int64 mSize; // rax
  int v5; // ecx
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v6; // rax
  int v7; // ecx
  int v8; // edx
  bool v9; // cc
  bool v10; // cc
  unsigned int *v11; // rsi
  FMOD::ProfileDsp::NodeInfo *mData; // rsi
  unsigned int *v13; // rsi
  __int64 v14; // rax
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v15; // rsi
  int v16; // ecx
  int v17; // edx
  __int64 v18; // rax
  int v19; // ecx

  this->mRemaining.mSize = 0;
  v1 = this->mRemaining.mCapacity == 0;
  v2 = this->mRemaining.mCapacity <= 0;
  this->_vptr_ProfileModule = (int (**)(...))&off_29B1CF0;
  if ( !v1 )
  {
    if ( !v2 )
    {
      mData = this->mRemaining.mData;
      if ( mData )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mData, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mRemaining.mData = 0;
    this->mRemaining.mCapacity = 0;
  }
  v1 = this->mVisited.mBuckets.mCapacity == 0;
  v3 = this->mVisited.mBuckets.mCapacity <= 0;
  this->mVisited.mBuckets.mSize = 0;
  if ( v1 )
  {
    mSize = this->mVisited.mNodes.mSize;
    if ( (int)mSize >= 0 )
      goto LABEL_8;
    goto LABEL_4;
  }
  if ( !v3 )
  {
    v11 = this->mVisited.mBuckets.mData;
    if ( v11 )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v11, "../../../core_api/src/fmod_memory.h", 244);
  }
  mSize = this->mVisited.mNodes.mSize;
  this->mVisited.mBuckets.mData = 0;
  this->mVisited.mBuckets.mCapacity = 0;
  if ( (int)mSize < 0 )
  {
LABEL_4:
    v5 = mSize;
    v6 = &this->mVisited.mNodes.mData[mSize];
    v7 = -v5;
    v8 = 0;
    do
    {
      if ( v6 )
      {
        v6->key = 0;
        v6->next = -1;
        v6->value = 0;
      }
      ++v8;
      ++v6;
    }
    while ( v7 > v8 );
  }
LABEL_8:
  v1 = this->mVisited.mNodes.mCapacity == 0;
  v9 = this->mVisited.mNodes.mCapacity <= 0;
  this->mVisited.mNodes.mSize = 0;
  if ( v1 )
  {
    this->mVisited.mFreeList = -1;
    this->mVisited.mNodeCount = 0;
  }
  else
  {
    v14 = 0;
    if ( !v9 )
    {
      v15 = this->mVisited.mNodes.mData;
      if ( v15 )
      {
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v15, "../../../core_api/src/fmod_memory.h", 244);
        v14 = this->mVisited.mNodes.mSize;
      }
    }
    this->mVisited.mNodes.mData = 0;
    this->mVisited.mNodes.mCapacity = 0;
    this->mVisited.mFreeList = -1;
    this->mVisited.mNodeCount = 0;
    if ( (int)v14 < 0 )
    {
      v16 = v14;
      v17 = 0;
      v18 = 16 * v14;
      v19 = -v16;
      do
      {
        if ( v18 )
        {
          *(_QWORD *)v18 = 0;
          *(_DWORD *)(v18 + 8) = -1;
          *(_BYTE *)(v18 + 12) = 0;
        }
        ++v17;
        v18 += 16;
      }
      while ( v19 > v17 );
    }
  }
  v1 = this->mVisited.mBuckets.mCapacity == 0;
  v10 = this->mVisited.mBuckets.mCapacity <= 0;
  this->mVisited.mNodes.mSize = 0;
  this->mVisited.mBuckets.mSize = 0;
  if ( v1 )
  {
    this->_vptr_ProfileModule = (int (**)(...))&off_29B0E90;
  }
  else
  {
    if ( !v10 )
    {
      v13 = this->mVisited.mBuckets.mData;
      if ( v13 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v13, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mVisited.mBuckets.mData = 0;
    this->mVisited.mBuckets.mCapacity = 0;
    this->_vptr_ProfileModule = (int (**)(...))&off_29B0E90;
  }
}


// Address: 0x220b580 | Name: _ZN4FMOD10ProfileDspD0Ev
void __fastcall FMOD::ProfileDsp::~ProfileDsp(FMOD::ProfileDsp *const this)
{
  bool v1; // zf
  bool v2; // cc
  bool v3; // cc
  __int64 mSize; // rax
  int v5; // ecx
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v6; // rax
  int v7; // ecx
  int v8; // edx
  bool v9; // cc
  bool v10; // cc
  unsigned int *v11; // rsi
  FMOD::ProfileDsp::NodeInfo *mData; // rsi
  unsigned int *v13; // rsi
  __int64 v14; // rax
  FMOD::HashMap<FMOD::DSPI*,bool,FMOD::ArrayConstruct_Auto<bool>,FMOD::HashMapDefaultHash,unsigned int>::Node *v15; // rsi
  int v16; // ecx
  int v17; // edx
  __int64 v18; // rax
  int v19; // ecx

  this->mRemaining.mSize = 0;
  v1 = this->mRemaining.mCapacity == 0;
  v2 = this->mRemaining.mCapacity <= 0;
  this->_vptr_ProfileModule = (int (**)(...))&off_29B1CF0;
  if ( !v1 )
  {
    if ( !v2 )
    {
      mData = this->mRemaining.mData;
      if ( mData )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mData, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mRemaining.mData = 0;
    this->mRemaining.mCapacity = 0;
  }
  v1 = this->mVisited.mBuckets.mCapacity == 0;
  v3 = this->mVisited.mBuckets.mCapacity <= 0;
  this->mVisited.mBuckets.mSize = 0;
  if ( v1 )
  {
    mSize = this->mVisited.mNodes.mSize;
    if ( (int)mSize >= 0 )
      goto LABEL_8;
    goto LABEL_4;
  }
  if ( !v3 )
  {
    v11 = this->mVisited.mBuckets.mData;
    if ( v11 )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v11, "../../../core_api/src/fmod_memory.h", 244);
  }
  mSize = this->mVisited.mNodes.mSize;
  this->mVisited.mBuckets.mData = 0;
  this->mVisited.mBuckets.mCapacity = 0;
  if ( (int)mSize < 0 )
  {
LABEL_4:
    v5 = mSize;
    v6 = &this->mVisited.mNodes.mData[mSize];
    v7 = -v5;
    v8 = 0;
    do
    {
      if ( v6 )
      {
        v6->key = 0;
        v6->next = -1;
        v6->value = 0;
      }
      ++v8;
      ++v6;
    }
    while ( v7 > v8 );
  }
LABEL_8:
  v1 = this->mVisited.mNodes.mCapacity == 0;
  v9 = this->mVisited.mNodes.mCapacity <= 0;
  this->mVisited.mNodes.mSize = 0;
  if ( v1 )
  {
    this->mVisited.mFreeList = -1;
    this->mVisited.mNodeCount = 0;
  }
  else
  {
    v14 = 0;
    if ( !v9 )
    {
      v15 = this->mVisited.mNodes.mData;
      if ( v15 )
      {
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v15, "../../../core_api/src/fmod_memory.h", 244);
        v14 = this->mVisited.mNodes.mSize;
      }
    }
    this->mVisited.mNodes.mData = 0;
    this->mVisited.mNodes.mCapacity = 0;
    this->mVisited.mFreeList = -1;
    this->mVisited.mNodeCount = 0;
    if ( (int)v14 < 0 )
    {
      v16 = v14;
      v17 = 0;
      v18 = 16 * v14;
      v19 = -v16;
      do
      {
        if ( v18 )
        {
          *(_QWORD *)v18 = 0;
          *(_DWORD *)(v18 + 8) = -1;
          *(_BYTE *)(v18 + 12) = 0;
        }
        ++v17;
        v18 += 16;
      }
      while ( v19 > v17 );
    }
  }
  v1 = this->mVisited.mBuckets.mCapacity == 0;
  v10 = this->mVisited.mBuckets.mCapacity <= 0;
  this->mVisited.mNodes.mSize = 0;
  this->mVisited.mBuckets.mSize = 0;
  if ( !v1 )
  {
    if ( !v10 )
    {
      v13 = this->mVisited.mBuckets.mData;
      if ( v13 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v13, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mVisited.mBuckets.mData = 0;
    this->mVisited.mBuckets.mCapacity = 0;
  }
  this->_vptr_ProfileModule = (int (**)(...))&off_29B0E90;
  operator delete(this);
}


