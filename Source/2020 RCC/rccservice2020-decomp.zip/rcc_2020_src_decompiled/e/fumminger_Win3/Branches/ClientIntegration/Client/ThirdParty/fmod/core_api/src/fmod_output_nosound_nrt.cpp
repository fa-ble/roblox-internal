// Address: 0x21fa580 | Name: _ZN4FMOD17OutputNoSound_NRT16getDescriptionExEv
FMOD::FMOD_OUTPUT_DESCRIPTION_EX *__cdecl FMOD::OutputNoSound_NRT::getDescriptionEx()
{
  memset(&stru_2ADC420, 0, sizeof(stru_2ADC420));
  stru_2ADC420.apiversion = 4;
  stru_2ADC420.version = 65792;
  stru_2ADC420.mType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_NOSOUND_NRT_0;
  stru_2ADC420.mSize = 1160;
  stru_2ADC420.name = "FMOD NoSound Output - Non real-time";
  stru_2ADC420.getnumdrivers = FMOD::OutputNoSound_NRT::getNumDriversCallback;
  stru_2ADC420.getdriverinfo = FMOD::OutputNoSound_NRT::getDriverInfoCallback;
  stru_2ADC420.init = FMOD::OutputNoSound_NRT::initCallback;
  stru_2ADC420.close = FMOD::OutputNoSound_NRT::closeCallback;
  stru_2ADC420.update = FMOD::OutputNoSound_NRT::updateCallback;
  return &stru_2ADC420;
}


// Address: 0x21fa600 | Name: _ZN4FMOD17OutputNoSound_NRT13getNumDriversEPi
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound_NRT::getNumDrivers(FMOD::OutputNoSound_NRT *const this, int *numdrivers)
{
  *numdrivers = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21fa610 | Name: _ZN4FMOD17OutputNoSound_NRT21getNumDriversCallbackEP17FMOD_OUTPUT_STATEPi
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound_NRT::getNumDriversCallback(FMOD_OUTPUT_STATE *output, int *numdrivers)
{
  FMOD::OutputNoSound_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound_NRT *)&output[-1].requestreset;
  return FMOD::OutputNoSound_NRT::getNumDrivers(p_requestreset, numdrivers);
}


// Address: 0x21fa630 | Name: _ZN4FMOD17OutputNoSound_NRT13getDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound_NRT::getDriverInfo(
        FMOD::OutputNoSound_NRT *const this,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels)
{
  if ( name )
    FMOD_strcpy_safe(name, "NoSound Driver", namelen);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21fa660 | Name: _ZN4FMOD17OutputNoSound_NRT21getDriverInfoCallbackEP17FMOD_OUTPUT_STATEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES6_
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound_NRT::getDriverInfoCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels)
{
  FMOD::OutputNoSound_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound_NRT *)&output[-1].requestreset;
  return FMOD::OutputNoSound_NRT::getDriverInfo(
           p_requestreset,
           id,
           name,
           namelen,
           guid,
           systemrate,
           speakermode,
           speakermodechannels);
}


// Address: 0x21fa680 | Name: _ZN4FMOD17OutputNoSound_NRT4initEijPiP16FMOD_SPEAKERMODES1_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound_NRT::init(
        FMOD::OutputNoSound_NRT *const this,
        int selecteddriver,
        FMOD_INITFLAGS flags,
        int *outputrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels,
        FMOD_SOUND_FORMAT_0 *outputformat,
        int dspbufferlength,
        int dspnumbuffers,
        void *extradriverdata)
{
  unsigned __int64 v10; // rsi
  __int64 v11; // rdx
  void *v12; // rax

  if ( *speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
  {
    *speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0;
    *speakermodechannels = 2;
  }
  *((_DWORD *)this + 286) = dspbufferlength;
  LODWORD(v10) = dspbufferlength;
  switch ( *outputformat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      v11 = 8;
      goto LABEL_5;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      v11 = 16;
      goto LABEL_5;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      v11 = 24;
      goto LABEL_5;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      v11 = 32;
LABEL_5:
      v10 = (v11 * (unsigned __int64)(unsigned int)dspbufferlength) >> 3;
      break;
    default:
      break;
  }
  v12 = FMOD::MemPool::calloc(
          off_286F358->gSystemMemPool,
          *speakermodechannels * (int)v10,
          "../../../core_api/src/fmod_output_nosound_nrt.cpp",
          124,
          0);
  *((_QWORD *)this + 144) = v12;
  return v12 == 0 ? 0x26 : 0;
}


// Address: 0x21fa740 | Name: _ZN4FMOD17OutputNoSound_NRT12initCallbackEP17FMOD_OUTPUT_STATEijPiP16FMOD_SPEAKERMODES3_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound_NRT::initCallback(
        FMOD_OUTPUT_STATE *output,
        int selecteddriver,
        FMOD_INITFLAGS flags,
        int *outputrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels,
        FMOD_SOUND_FORMAT_0 *outputformat,
        int dspbufferlength,
        int dspnumbuffers,
        void *extradriverdata)
{
  FMOD::OutputNoSound_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound_NRT *)&output[-1].requestreset;
  return FMOD::OutputNoSound_NRT::init(
           p_requestreset,
           selecteddriver,
           flags,
           outputrate,
           speakermode,
           speakermodechannels,
           outputformat,
           dspbufferlength,
           dspnumbuffers,
           extradriverdata);
}


// Address: 0x21fa760 | Name: _ZN4FMOD17OutputNoSound_NRT5closeEv
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound_NRT::close(FMOD::OutputNoSound_NRT *const this)
{
  void *v1; // rsi

  v1 = (void *)*((_QWORD *)this + 144);
  if ( v1 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_output_nosound_nrt.cpp", 151);
    *((_QWORD *)this + 144) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21fa7b0 | Name: _ZN4FMOD17OutputNoSound_NRT13closeCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound_NRT::closeCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputNoSound_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound_NRT *)&output[-1].requestreset;
  return FMOD::OutputNoSound_NRT::close(p_requestreset);
}


// Address: 0x21fa7d0 | Name: _ZN4FMOD17OutputNoSound_NRT6updateEv
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound_NRT::update(FMOD::OutputNoSound_NRT *const this)
{
  return (*((FMOD_RESULT_0 (__fastcall **)(char *, _QWORD, _QWORD))this + 2))(
           (char *)this + 8,
           *((_QWORD *)this + 144),
           *((unsigned int *)this + 286));
}


// Address: 0x21fa7f0 | Name: _ZN4FMOD17OutputNoSound_NRT14updateCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputNoSound_NRT::updateCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputNoSound_NRT *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputNoSound_NRT *)&output[-1].requestreset;
  return FMOD::OutputNoSound_NRT::update(p_requestreset);
}


