// Address: 0x22226a0 | Name: _ZN4FMOD9CodecMPEG10initLayer3Ei
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::initLayer3(int down_sample_sblimit)
{
  int v2; // ebx
  float *v3; // rbp
  float v4; // xmm1_4
  __int64 i; // rbx
  float v6; // xmm2_4
  float v7; // xmm1_4
  int v8; // ebp
  float v9; // xmm0_4
  float *v10; // rbx
  float v11; // xmm3_4
  float j; // xmm2_4
  float v13; // xmm0_4
  float v14; // xmm1_4
  float v15; // xmm2_4
  float *v16; // rbx
  int v17; // ebp
  float v18; // xmm0_4
  float v19; // xmm6_4
  float v20; // xmm5_4
  float v21; // xmm2_4
  float v22; // xmm4_4
  float k; // xmm3_4
  float v24; // xmm0_4
  float *v25; // rbx
  int v26; // ebp
  float m; // xmm0_4
  float v28; // xmm0_4
  float *v29; // rbx
  int v30; // ebp
  float v31; // xmm0_4
  float v32; // xmm2_4
  float v33; // xmm0_4
  int v34; // eax
  float *v35; // rcx
  const int *v36; // r8
  float *v37; // rdx
  int v38; // edi
  unsigned __int64 v39; // rax
  unsigned __int64 v40; // rax
  __int64 v41; // r13
  int n; // ebp
  float v43; // xmm0_4
  float v44; // xmm3_4
  float v45; // xmm2_4
  float v46; // xmm1_4
  int v47; // r12d
  float *v48; // rax
  __int64 v49; // rbx
  float v50; // xmm0_4
  int *v51; // r13
  unsigned __int64 v52; // r11
  int **v53; // rbp
  int *v54; // r8
  int **v55; // rbx
  int *v56; // r12
  int *v57; // r10
  int *v58; // rax
  int v59; // edx
  int v60; // esi
  int *v61; // rcx
  int v62; // edi
  int *v63; // r14
  int v64; // r13d
  int *v65; // r15
  int *v66; // rax
  int v67; // edx
  int v68; // ecx
  int v69; // edi
  int *v70; // r15
  int v71; // esi
  int v72; // r13d
  int *shortDiff; // r14
  int *v74; // rax
  int v75; // edx
  int v76; // ecx
  int v77; // edi
  __int64 v78; // rax
  int v79; // edx
  int *v80; // r9
  int *v81; // r8
  FMOD::bandInfoStruct *v82; // rdi
  __int64 ii; // rcx
  int v84; // edx
  int v85; // edx
  int v86; // ebx
  int jj; // r11d
  int v88; // r8d
  int kk; // r9d
  int mm; // eax
  int v91; // ecx
  int v92; // edx
  int v93; // ebx
  int v94; // r9d
  int v95; // r10d
  int nn; // eax
  int v97; // ecx
  int v98; // edx
  int i1; // esi
  int v100; // ecx
  int v101; // edx
  int v102; // eax
  int v103; // eax
  int v104; // r10d
  int v105; // r9d
  int v106; // r12d
  int i2; // ebp
  int v108; // ebx
  int i3; // r11d
  int v110; // edi
  int i4; // r9d
  int i5; // eax
  int v113; // ecx
  int v114; // edx
  int i6; // ebx
  int v116; // r10d
  int i7; // r9d
  int i8; // eax
  int v119; // ecx
  int v120; // edx
  float y; // [rsp+8h] [rbp-60h]
  float yb; // [rsp+8h] [rbp-60h]
  float yc; // [rsp+8h] [rbp-60h]
  int *ya; // [rsp+8h] [rbp-60h]
  float v126; // [rsp+10h] [rbp-58h]
  float v127; // [rsp+10h] [rbp-58h]
  int *longDiff; // [rsp+10h] [rbp-58h]
  float v129; // [rsp+18h] [rbp-50h]
  float v130; // [rsp+18h] [rbp-50h]
  float v131; // [rsp+20h] [rbp-48h]
  int down_sample_sblimitb; // [rsp+2Ch] [rbp-3Ch]
  int down_sample_sblimita; // [rsp+2Ch] [rbp-3Ch]

  v2 = -46;
  v3 = FMOD::CodecMPEG::gGainPow2;
  do
  {
    v4 = (float)v2++;
    *v3++ = powf(2.0, v4 * -0.25);
  }
  while ( v2 != 332 );
  for ( i = 0; i != 8207; ++i )
    FMOD::CodecMPEG::gIsPowTable[i] = powf((float)(int)i, 1.3333334);
  LOWORD(i) = 0;
  do
  {
    v6 = *(const float *)((char *)flt_596A00 + i);
    v7 = fsqrt((float)(v6 * v6) + 1.0);
    i += 4;
    *(float *)((char *)&FMOD::CodecMPEG::gAaCa[-1] + i) = v6 / v7;
    *(float *)((char *)&FMOD::CodecMPEG::gAaCs[-1] + i) = 1.0 / v7;
  }
  while ( i != 32 );
  v8 = 0;
  v9 = -0.73727733;
  v10 = FMOD::CodecMPEG::gWin[0];
  v11 = 0.99904823;
  y = 0.67559022;
  for ( j = 0.043619391; ; j = v129 )
  {
    ++v10;
    v14 = (float)(0.5 * v11) / v9;
    v15 = (float)(j * 0.5) / y;
    v10[125] = v14;
    v10[17] = v14;
    v10[35] = v15;
    *(v10 - 1) = v15;
    if ( v8 == 34 )
      break;
    v129 = sinf((float)(v8 + 3) * 0.043633234);
    y = cosf((float)((float)(v8 + 21) * 3.1415927) / 72.0);
    v126 = sinf((float)(v8 + 39) * 0.043633234);
    v13 = (float)(v8 + 57);
    v8 += 2;
    v9 = cosf((float)(v13 * 3.1415927) / 72.0);
    v11 = v126;
  }
  v16 = FMOD::CodecMPEG::gWin[0];
  v17 = 0;
  v18 = 0.21643965;
  v19 = 0.1305262;
  v20 = -0.97629601;
  v21 = 0.99144489;
  v22 = -0.30070579;
  for ( k = -0.73727733; ; k = *(float *)&down_sample_sblimitb )
  {
    v16[108] = 0.0;
    v16[66] = 0.0;
    ++v16;
    v16[53] = 0.5 / k;
    v16[59] = (float)(v21 * 0.5) / v20;
    v16[119] = 0.5 / v22;
    v16[113] = (float)(0.5 * v19) / v18;
    if ( v17 == 10 )
      break;
    *(float *)&down_sample_sblimitb = cosf((float)((float)(v17 + 57) * 3.1415927) / 72.0);
    v131 = cosf((float)((float)(v17 + 45) * 3.1415927) / 72.0);
    v130 = sinf((float)(v17 + 15) * 0.1308997);
    v127 = cosf((float)((float)(v17 + 69) * 3.1415927) / 72.0);
    yb = sinf((float)(v17 + 3) * 0.1308997);
    v24 = (float)(v17 + 33);
    v17 += 2;
    v18 = cosf((float)(v24 * 3.1415927) / 72.0);
    v19 = yb;
    v20 = v127;
    v21 = v130;
    v22 = v131;
  }
  v25 = FMOD::CodecMPEG::gTfCos36;
  v26 = 3;
  for ( m = 0.99619472; ; m = cosf((float)(v28 * 3.1415927) / 36.0) )
  {
    *v25++ = 0.5 / m;
    if ( v25 == &FMOD::CodecMPEG::gCos6_2 )
      break;
    v28 = (float)v26;
    v26 += 2;
  }
  v29 = FMOD::CodecMPEG::gWin[2];
  v30 = 3;
  v31 = 0.60876137;
  v32 = 0.1305262;
  FMOD::CodecMPEG::gTfCos12[0] = 0.51763809;
  FMOD::CodecMPEG::gTfCos12[1] = 0.70710677;
  FMOD::CodecMPEG::gTfCos12[2] = 1.9318523;
  FMOD::CodecMPEG::gCos6_1 = 0.86602539;
  FMOD::CodecMPEG::gCos6_2 = 0.49999997;
  FMOD::CodecMPEG::gCos9[0] = 0.93969262;
  FMOD::CodecMPEG::gCos9[1] = -0.1736483;
  FMOD::CodecMPEG::gCos9[2] = -0.76604462;
  FMOD::CodecMPEG::gCos18[0] = 0.98480773;
  FMOD::CodecMPEG::gCos18[1] = -0.34202024;
  FMOD::CodecMPEG::gCos18[2] = -0.64278764;
  while ( 1 )
  {
    *v29++ = (float)(0.5 * v32) / v31;
    if ( v29 == &FMOD::CodecMPEG::gWin[2][12] )
      break;
    v33 = sinf((float)v30 * 0.1308997);
    v34 = v30 + 6;
    yc = v33;
    v30 += 2;
    v31 = cosf((float)((float)v34 * 3.1415927) / 24.0);
    v32 = yc;
  }
  v35 = FMOD::CodecMPEG::gWin1[0];
  v36 = dword_5969E0;
  v37 = FMOD::CodecMPEG::gWin[0];
  do
  {
    v38 = *v36;
    if ( *v36 > 0 )
    {
      v39 = 0;
      do
      {
        v35[v39 / 4] = v37[v39 / 4];
        v39 += 8LL;
      }
      while ( v39 != 8LL * ((unsigned int)(v38 - 1) >> 1) + 8 );
      if ( v38 > 1 )
      {
        v40 = 0;
        do
        {
          v35[v40 / 4 + 1] = -v37[v40 / 4 + 1];
          v40 += 8LL;
        }
        while ( v40 != 8LL * ((unsigned int)(v38 - 2) >> 1) + 8 );
      }
    }
    ++v36;
    v37 += 36;
    v35 += 36;
  }
  while ( v36 != (const int *)&unk_5969F0 );
  v41 = 0;
  for ( n = 0; n != 16; ++n )
  {
    v49 = 0;
    v47 = 0;
    do
    {
      v50 = powf(2.0, (float)((float)v47 + 1.0) * -0.25);
      if ( n )
      {
        if ( (n & 1) != 0 )
        {
          v43 = powf(v50, 0.5 * (float)((float)n + 1.0));
          v44 = 1.4142135 * v43;
          v45 = 1.4142135;
          v46 = 1.0;
        }
        else
        {
          v46 = powf(v50, (float)n * 0.5);
          v45 = 1.4142135 * v46;
          v44 = 1.4142135;
          v43 = 1.0;
        }
      }
      else
      {
        v45 = 1.4142135;
        v46 = 1.0;
        v44 = 1.4142135;
        v43 = 1.0;
      }
      ++v47;
      FMOD::CodecMPEG::gPow1_1[v49][v41] = v43;
      FMOD::CodecMPEG::gPow2_1[v49][v41] = v46;
      FMOD::CodecMPEG::gPow1_2[v49][v41] = v44;
      v48 = FMOD::CodecMPEG::gPow2_2[v49++];
      v48[v41] = v45;
    }
    while ( v47 != 2 );
    ++v41;
  }
  v51 = FMOD::CodecMPEG::gMapBuf0[0];
  v52 = 0;
  v53 = FMOD::CodecMPEG::gMap[0];
  v54 = FMOD::CodecMPEG::gMapBuf2[0];
  v55 = FMOD::CodecMPEG::gMapEnd[0];
  down_sample_sblimita = down_sample_sblimit;
  v56 = FMOD::CodecMPEG::gMapBuf1[0];
  ya = FMOD::CodecMPEG::gMapBuf0[1];
  v57 = FMOD::CodecMPEG::gMapBuf0[1];
  longDiff = FMOD::CodecMPEG::gBandInfo[0].longDiff;
  while ( 1 )
  {
    v58 = v51;
    *v53 = v51;
    v59 = 0;
    v60 = 0;
    v61 = &longDiff[v52 / 4];
    do
    {
      v62 = *v61;
      v58[1] = v60;
      v58 += 4;
      *(v58 - 2) = 3;
      ++v61;
      v60 += v62;
      *(v58 - 4) = v62 >> 1;
      *(v58 - 1) = v59++;
    }
    while ( v59 != 8 );
    v63 = v51 + 32;
    v64 = 3;
    v65 = &FMOD::CodecMPEG::gBandInfo[v52 / 0x120].shortDiff[3];
    do
    {
      ++v65;
      v66 = v63;
      v67 = 0;
      v68 = *(v65 - 1) >> 1;
      do
      {
        v69 = v67 + v60;
        v66[2] = v67++;
        *v66 = v68;
        v66 += 4;
        *(v66 - 3) = v69;
        *(v66 - 1) = v64;
      }
      while ( v67 != 3 );
      v63 += 12;
      ++v64;
      v60 += 6 * v68;
    }
    while ( v63 != v57 );
    *v55 = v57;
    v70 = v56;
    v53[1] = v56;
    v71 = 0;
    v72 = 0;
    shortDiff = FMOD::CodecMPEG::gBandInfo[v52 / 0x120].shortDiff;
    do
    {
      ++shortDiff;
      v74 = v70;
      v75 = 0;
      v76 = *(shortDiff - 1) >> 1;
      do
      {
        v77 = v75 + v72;
        v74[2] = v75++;
        *v74 = v76;
        v74 += 4;
        *(v74 - 3) = v77;
        *(v74 - 1) = v71;
      }
      while ( v75 != 3 );
      ++v71;
      v70 += 12;
      v72 += 6 * v76;
    }
    while ( v71 != 13 );
    v56 += 156;
    v53[2] = v54;
    v78 = 0;
    v55[1] = v56;
    do
    {
      v79 = longDiff[v52 / 4 + v78];
      v54[2 * v78 + 1] = v78;
      v54[2 * v78++] = v79 >> 1;
    }
    while ( v78 != 22 );
    v54 += 44;
    v52 += 288LL;
    v53 += 3;
    v55[2] = v54;
    v57 += 152;
    v55 += 3;
    v51 = ya;
    if ( v52 == 2592 )
      break;
    ya += 152;
  }
  v80 = FMOD::CodecMPEG::gShortLimit[0];
  v81 = FMOD::CodecMPEG::gLongLimit[0];
  v82 = FMOD::CodecMPEG::gBandInfo;
  do
  {
    for ( ii = 0; ii != 92; ii += 4 )
    {
      while ( 1 )
      {
        v84 = (*(int *)((char *)v82->longIdx + ii) + 7) / 18 + 1;
        if ( v84 > down_sample_sblimita )
          break;
        *(int *)((char *)v81 + ii) = v84;
        ii += 4;
        if ( ii == 92 )
          goto LABEL_55;
      }
      *(int *)((char *)v81 + ii) = down_sample_sblimita;
    }
LABEL_55:
    LOBYTE(ii) = 0;
    do
    {
      while ( 1 )
      {
        v85 = (*(int *)((char *)v82->shortIdx + ii) - 1) / 18 + 1;
        if ( down_sample_sblimita < v85 )
          break;
        *(int *)((char *)v80 + ii) = v85;
        ii += 4;
        if ( ii == 56 )
          goto LABEL_59;
      }
      *(int *)((char *)v80 + ii) = down_sample_sblimita;
      ii += 4;
    }
    while ( ii != 56 );
LABEL_59:
    v80 += 14;
    ++v82;
    v81 += 23;
  }
  while ( v80 != (int *)algn_2AFB7D8 );
  v86 = 0;
  for ( jj = 0; jj != 5; ++jj )
  {
    v88 = v86;
    for ( kk = 0; kk != 6; ++kk )
    {
      for ( mm = 0; mm != 6; ++mm )
      {
        v91 = mm + v88;
        v92 = mm;
        FMOD::CodecMPEG::gI_SLen2[v91] = jj | 0x3000 | (8 * kk) | (v92 << 6);
      }
      v88 += 6;
    }
    v86 += 36;
  }
  LOBYTE(jj) = 0;
  do
  {
    v93 = jj;
    v94 = 0;
    v95 = 16 * jj;
    do
    {
      for ( nn = 0; nn != 4; ++nn )
      {
        v97 = v95 + 180 + nn;
        v98 = nn;
        BYTE1(v93) = BYTE1(jj) | 0x40;
        FMOD::CodecMPEG::gI_SLen2[v97] = v93 | (8 * v94) | (v98 << 6);
      }
      ++v94;
      v95 += 4;
    }
    while ( v94 != 4 );
    ++jj;
  }
  while ( jj != 4 );
  LOBYTE(jj) = -12;
  for ( i1 = 0; i1 != 4; ++i1 )
  {
    v100 = jj;
    v101 = 0;
    do
    {
      v102 = 8 * v101++;
      v103 = i1 | v102;
      v104 = v103;
      BYTE1(v103) |= 0xA0u;
      FMOD::CodecMPEG::gI_SLen2[v100] = v104 | 0x5000;
      v105 = v100 + 256;
      ++v100;
      FMOD::CodecMPEG::gN_SLen2[v105] = v103;
    }
    while ( v101 != 3 );
    jj += 3;
  }
  v106 = 0;
  for ( i2 = 0; i2 != 5; ++i2 )
  {
    v108 = v106;
    for ( i3 = 0; i3 != 5; ++i3 )
    {
      v110 = v108;
      for ( i4 = 0; i4 != 4; ++i4 )
      {
        for ( i5 = 0; i5 != 4; ++i5 )
        {
          v113 = i5 + v110;
          v114 = i5;
          FMOD::CodecMPEG::gN_SLen2[v113] = i2 | (8 * i3) | (i4 << 6) | (v114 << 9);
        }
        v110 += 4;
      }
      v108 += 16;
    }
    v106 += 80;
  }
  LOBYTE(i2) = 0;
  for ( i6 = 0; i6 != 5; ++i6 )
  {
    v116 = i2;
    for ( i7 = 0; i7 != 5; ++i7 )
    {
      for ( i8 = 0; i8 != 4; ++i8 )
      {
        v119 = v116 + 400 + i8;
        v120 = i8;
        FMOD::CodecMPEG::gN_SLen2[v119] = i6 | 0x1000 | (8 * i7) | (v120 << 6);
      }
      v116 += 4;
    }
    i2 += 20;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22231f0 | Name: _ZN4FMOD9CodecMPEG19III_get_side_info_1EPNS_12III_sideinfoEiii
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::III_get_side_info_1(
        FMOD::CodecMPEG *const this,
        FMOD::III_sideinfo *si_0,
        int stereo,
        int ms_stereo,
        int sfreq)
{
  FMOD::III_sideinfo *v9; // r14
  int v10; // r12d
  __int64 v11; // r14
  unsigned int *v12; // r15
  FMOD::CodecMPEG_Context *v13; // rax
  unsigned __int8 *v14; // rdi
  int v15; // ecx
  int v16; // esi
  unsigned int v17; // eax
  __int64 v18; // r13
  __int64 v19; // rax
  __int64 v20; // r13
  __int64 v21; // rax
  __int64 v22; // r13
  unsigned int v23; // eax
  unsigned int v24; // edx
  FMOD::CodecMPEG_Context *v25; // rax
  unsigned __int8 *v26; // rdi
  int v27; // ecx
  int v28; // esi
  FMOD::CodecMPEG_Context *v29; // rax
  unsigned __int8 *v30; // rdi
  int v31; // ecx
  int v32; // esi
  FMOD::CodecMPEG_Context *v33; // rax
  unsigned __int8 *v34; // rdi
  int v35; // ecx
  int v36; // esi
  unsigned int BitsFast; // eax
  float *v38; // rax
  FMOD::CodecMPEG_Context *mContext; // rax
  unsigned __int8 *mWordPointer; // rdi
  int mBitIndex; // ecx
  int v42; // esi
  unsigned int v43; // r13d
  unsigned int v44; // eax
  __int64 v45; // rcx
  int v46; // r13d
  unsigned int *p_block_type; // [rsp+10h] [rbp-48h]
  unsigned int *v50; // [rsp+18h] [rbp-40h]

  si_0->main_data_begin = FMOD::CodecMPEG::getBits(this, 9);
  if ( stereo == 1 )
  {
    si_0->private_bits = FMOD::CodecMPEG::getBitsFast(this, 5);
LABEL_3:
    v9 = si_0;
    v10 = 0;
    do
    {
      v9->ch[0].gr[0].scfsi = -1;
      ++v10;
      v9->ch[0].gr[1].scfsi = FMOD::CodecMPEG::getBitsFast(this, 4);
      v9 = (FMOD::III_sideinfo *)((char *)v9 + 240);
    }
    while ( stereo > v10 );
    goto LABEL_5;
  }
  si_0->private_bits = FMOD::CodecMPEG::getBitsFast(this, 3);
  if ( stereo > 0 )
    goto LABEL_3;
LABEL_5:
  p_block_type = &si_0->ch[0].gr[0].block_type;
  v11 = sfreq;
  v50 = &si_0->ch[1].gr[0].block_type;
  while ( stereo <= 0 )
  {
LABEL_22:
    p_block_type += 30;
    if ( p_block_type == v50 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  v12 = p_block_type;
  while ( 1 )
  {
    *(v12 - 3) = FMOD::CodecMPEG::getBits(this, 12);
    BitsFast = FMOD::CodecMPEG::getBitsFast(this, 9);
    *(v12 - 2) = BitsFast;
    if ( BitsFast > 0x120 || *(v12 - 3) > 0x1000 )
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    v38 = &FMOD::CodecMPEG::gGainPow2[-FMOD::CodecMPEG::getBitsFast(this, 8) + 256];
    if ( ms_stereo )
      v38 += 2;
    *((_QWORD *)v12 + 12) = v38;
    *(v12 - 1) = FMOD::CodecMPEG::getBitsFast(this, 4);
    mContext = this->mContext;
    mWordPointer = mContext->mBSI.mWordPointer;
    mBitIndex = mContext->mBSI.mBitIndex;
    v42 = *mWordPointer << mBitIndex;
    mContext->mBSI.mBitIndex = (mBitIndex + 1) & 7;
    mContext->mBSI.mWordPointer = &mWordPointer[(mBitIndex + 1) >> 3];
    if ( (v42 & 0x80) != 0 )
    {
      *v12 = FMOD::CodecMPEG::getBitsFast(this, 2);
      v13 = this->mContext;
      v14 = v13->mBSI.mWordPointer;
      v15 = v13->mBSI.mBitIndex;
      v16 = (unsigned __int8)(*v14 << v15);
      v13->mBSI.mBitIndex = (v15 + 1) & 7;
      v13->mBSI.mWordPointer = &v14[(v15 + 1) >> 3];
      v12[1] = v16 >> 7;
      v12[2] = FMOD::CodecMPEG::getBitsFast(this, 5);
      v17 = FMOD::CodecMPEG::getBitsFast(this, 5);
      v18 = *((_QWORD *)v12 + 12);
      v12[3] = v17;
      v12[4] = 0;
      v19 = v18 + 32LL * FMOD::CodecMPEG::getBitsFast(this, 3);
      v20 = *((_QWORD *)v12 + 12);
      *((_QWORD *)v12 + 9) = v19;
      v21 = v20 + 32LL * FMOD::CodecMPEG::getBitsFast(this, 3);
      v22 = *((_QWORD *)v12 + 12);
      *((_QWORD *)v12 + 10) = v21;
      v23 = FMOD::CodecMPEG::getBitsFast(this, 3);
      v24 = *v12;
      *((_QWORD *)v12 + 11) = v22 + 32LL * v23;
      if ( !v24 )
        return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
      v12[13] = 18;
      v12[14] = 288;
    }
    else
    {
      v12[2] = FMOD::CodecMPEG::getBitsFast(this, 5);
      v12[3] = FMOD::CodecMPEG::getBitsFast(this, 5);
      v12[4] = FMOD::CodecMPEG::getBitsFast(this, 5);
      v43 = FMOD::CodecMPEG::getBitsFast(this, 4);
      v44 = FMOD::CodecMPEG::getBitsFast(this, 3);
      v45 = (int)++v43;
      v46 = v44 + v43;
      v12[13] = FMOD::CodecMPEG::gBandInfo[v11].longIdx[v45] >> 1;
      if ( v46 <= 21 )
        v12[14] = FMOD::CodecMPEG::gBandInfo[v11].longIdx[v46 + 1] >> 1;
      else
        v12[14] = 288;
      *v12 = 0;
      v12[1] = 0;
    }
    v25 = this->mContext;
    v12 += 60;
    v26 = v25->mBSI.mWordPointer;
    v27 = v25->mBSI.mBitIndex;
    v28 = (unsigned __int8)(*v26 << v27);
    v25->mBSI.mBitIndex = (v27 + 1) & 7;
    v25->mBSI.mWordPointer = &v26[(v27 + 1) >> 3];
    *(v12 - 45) = v28 >> 7;
    v29 = this->mContext;
    v30 = v29->mBSI.mWordPointer;
    v31 = v29->mBSI.mBitIndex;
    v32 = (unsigned __int8)(*v30 << v31);
    v29->mBSI.mBitIndex = (v31 + 1) & 7;
    v29->mBSI.mWordPointer = &v30[(v31 + 1) >> 3];
    *(v12 - 44) = v32 >> 7;
    v33 = this->mContext;
    v34 = v33->mBSI.mWordPointer;
    v35 = v33->mBSI.mBitIndex;
    v36 = (unsigned __int8)(*v34 << v35);
    v33->mBSI.mBitIndex = (v35 + 1) & 7;
    v33->mBSI.mWordPointer = &v34[(v35 + 1) >> 3];
    *(v12 - 43) = v36 >> 7;
    if ( v12 == &p_block_type[60 * (stereo - 1) + 60] )
      goto LABEL_22;
  }
}


// Address: 0x2223680 | Name: _ZN4FMOD9CodecMPEG19III_get_side_info_2EPNS_12III_sideinfoEiii
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::III_get_side_info_2(
        FMOD::CodecMPEG *const this,
        FMOD::III_sideinfo *si_0,
        int stereo,
        int ms_stereo,
        int sfreq)
{
  __int64 v6; // r13
  FMOD::III_sideinfo::$D7C0C5A2C1B612DA685E5A32903E50B1 *ch; // rbx
  int v9; // r12d
  unsigned int BitsFast; // eax
  float *v11; // rax
  FMOD::CodecMPEG_Context *v12; // rax
  unsigned __int8 *v13; // rsi
  int v14; // ecx
  int v15; // edx
  FMOD::CodecMPEG_Context *v16; // rax
  FMOD::III_sideinfo::$D7C0C5A2C1B612DA685E5A32903E50B1 *v17; // r14
  unsigned __int8 *v18; // rsi
  int v19; // ecx
  int v20; // edx
  unsigned int v21; // eax
  float *pow2gain; // r15
  unsigned int block_type; // edx
  FMOD::CodecMPEG_Context *v24; // rax
  FMOD::CodecMPEG_Context *v25; // rax
  unsigned __int8 *v26; // rsi
  int v27; // ecx
  int v28; // edx
  FMOD::CodecMPEG_Context *v29; // rax
  unsigned __int8 *v30; // rsi
  int v31; // ecx
  int v32; // edx
  signed int v34; // r13d
  unsigned int v35; // eax
  unsigned __int64 v36; // rdx
  int v37; // r13d
  FMOD::CodecMPEG_Context *mContext; // rax
  unsigned __int8 *mWordPointer; // rsi
  int mBitIndex; // ecx
  int v41; // edx
  unsigned __int64 v44; // [rsp+10h] [rbp-48h]
  __int64 v45; // [rsp+18h] [rbp-40h]

  v6 = sfreq;
  si_0->main_data_begin = FMOD::CodecMPEG::getBits(this, 8);
  if ( stereo == 1 )
  {
    mContext = this->mContext;
    mWordPointer = mContext->mBSI.mWordPointer;
    mBitIndex = mContext->mBSI.mBitIndex;
    v41 = (unsigned __int8)(*mWordPointer << mBitIndex);
    mContext->mBSI.mBitIndex = (mBitIndex + 1) & 7;
    mContext->mBSI.mWordPointer = &mWordPointer[(mBitIndex + 1) >> 3];
    si_0->private_bits = v41 >> 7;
  }
  else
  {
    si_0->private_bits = FMOD::CodecMPEG::getBitsFast(this, 2);
    if ( stereo <= 0 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  ch = si_0->ch;
  v9 = 0;
  v45 = v6;
  v44 = 72 * v6;
  while ( 1 )
  {
    ch->gr[0].part2_3_length = FMOD::CodecMPEG::getBits(this, 12);
    BitsFast = FMOD::CodecMPEG::getBitsFast(this, 9);
    ch->gr[0].big_values = BitsFast;
    if ( BitsFast > 0x120 )
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    v11 = &FMOD::CodecMPEG::gGainPow2[-FMOD::CodecMPEG::getBitsFast(this, 8) + 256];
    if ( ms_stereo )
      v11 += 2;
    ch->gr[0].pow2gain = v11;
    ch->gr[0].scalefac_compress = FMOD::CodecMPEG::getBits(this, 9);
    v12 = this->mContext;
    v13 = v12->mBSI.mWordPointer;
    v14 = v12->mBSI.mBitIndex;
    v15 = *v13 << v14;
    v12->mBSI.mBitIndex = (v14 + 1) & 7;
    v12->mBSI.mWordPointer = &v13[(v14 + 1) >> 3];
    if ( (v15 & 0x80) == 0 )
    {
      ch->gr[0].table_select[0] = FMOD::CodecMPEG::getBitsFast(this, 5);
      ch->gr[0].table_select[1] = FMOD::CodecMPEG::getBitsFast(this, 5);
      ch->gr[0].table_select[2] = FMOD::CodecMPEG::getBitsFast(this, 5);
      v34 = FMOD::CodecMPEG::getBitsFast(this, 4) + 1;
      v35 = FMOD::CodecMPEG::getBitsFast(this, 3);
      v36 = v44 + v34;
      v37 = v35 + v34;
      ch->gr[0].region1start = FMOD::CodecMPEG::gBandInfo[0].longIdx[v36] >> 1;
      if ( v37 <= 21 )
        ch->gr[0].region2start = FMOD::CodecMPEG::gBandInfo[v44 / 0x48].longIdx[v37 + 1] >> 1;
      else
        ch->gr[0].region2start = 288;
      ch->gr[0].block_type = 0;
      ch->gr[0].mixed_block_flag = 0;
      goto LABEL_15;
    }
    ch->gr[0].block_type = FMOD::CodecMPEG::getBitsFast(this, 2);
    v16 = this->mContext;
    v17 = ch;
    v18 = v16->mBSI.mWordPointer;
    v19 = v16->mBSI.mBitIndex;
    v20 = (unsigned __int8)(*v18 << v19);
    v16->mBSI.mBitIndex = (v19 + 1) & 7;
    v16->mBSI.mWordPointer = &v18[(v19 + 1) >> 3];
    ch->gr[0].mixed_block_flag = v20 >> 7;
    ch->gr[0].table_select[0] = FMOD::CodecMPEG::getBitsFast(this, 5);
    v21 = FMOD::CodecMPEG::getBitsFast(this, 5);
    ch->gr[0].table_select[2] = 0;
    ch->gr[0].table_select[1] = v21;
    do
    {
      pow2gain = ch->gr[0].pow2gain;
      v17 = (FMOD::III_sideinfo::$D7C0C5A2C1B612DA685E5A32903E50B1 *)((char *)v17 + 8);
      *(_QWORD *)&v17->gr[0].scalefac_scale = &pow2gain[8 * FMOD::CodecMPEG::getBitsFast(this, 3)];
    }
    while ( v17 != (FMOD::III_sideinfo::$D7C0C5A2C1B612DA685E5A32903E50B1 *)ch->gr[0].table_select );
    block_type = ch->gr[0].block_type;
    if ( !block_type )
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    v24 = this->mContext;
    if ( !v24->mFrame.lsf || block_type == 2 )
    {
      if ( v24->mFrame.mpeg25 )
      {
LABEL_23:
        ch->gr[0].region1start = FMOD::CodecMPEG::gBandInfo[0].longIdx[2 * (*(_QWORD *)&ch->gr[0].block_type != 2)
                                                                     + 6
                                                                     + v44] >> 1;
        ch->gr[0].region2start = FMOD::CodecMPEG::gBandInfo[v45].longIdx[22] >> 1;
        goto LABEL_15;
      }
      ch->gr[0].region1start = 18;
      ch->gr[0].region2start = 288;
    }
    else
    {
      if ( v24->mFrame.mpeg25 )
        goto LABEL_23;
      ch->gr[0].region1start = 27;
      ch->gr[0].region2start = 288;
    }
LABEL_15:
    v25 = this->mContext;
    ++v9;
    ++ch;
    v26 = v25->mBSI.mWordPointer;
    v27 = v25->mBSI.mBitIndex;
    v28 = (unsigned __int8)(*v26 << v27);
    v25->mBSI.mBitIndex = (v27 + 1) & 7;
    v25->mBSI.mWordPointer = &v26[(v27 + 1) >> 3];
    ch[-1].gr[0].scalefac_scale = v28 >> 7;
    v29 = this->mContext;
    v30 = v29->mBSI.mWordPointer;
    v31 = v29->mBSI.mBitIndex;
    v32 = (unsigned __int8)(*v30 << v31);
    v29->mBSI.mBitIndex = (v31 + 1) & 7;
    v29->mBSI.mWordPointer = &v30[(v31 + 1) >> 3];
    ch[-1].gr[0].count1table_select = v32 >> 7;
    if ( stereo <= v9 )
      return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x2223ab0 | Name: _ZN4FMOD9CodecMPEG23III_get_scale_factors_1EPiPNS_9gr_info_sES1_
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::III_get_scale_factors_1(
        FMOD::CodecMPEG *const this,
        int *scf,
        FMOD::gr_info_s *gr_info,
        int *numbits)
{
  int *v5; // rbx
  __int64 scalefac_compress; // rax
  int v7; // r13d
  int v8; // r12d
  int *v9; // r14
  int *v10; // rbx
  int *v11; // r13
  int *v12; // rbx
  int v14; // eax
  int v15; // eax
  int *v16; // r15
  __int64 v17; // r14
  int *v18; // r14
  __int64 v19; // r13
  int *v20; // rbx
  int *v21; // r14
  int *v22; // rdx
  unsigned int BitsFast; // eax
  int scfsi; // [rsp+8h] [rbp-40h]
  int scfsia; // [rsp+8h] [rbp-40h]
  int *scfsib; // [rsp+8h] [rbp-40h]

  v5 = scf;
  scalefac_compress = gr_info->scalefac_compress;
  *numbits = 0;
  v7 = byte_5969C0[0][scalefac_compress];
  v8 = byte_5969C0[1][scalefac_compress];
  if ( gr_info->block_type == 2 )
  {
    *numbits = 18 * (v7 + v8);
    v14 = 18;
    if ( gr_info->mixed_block_flag )
    {
      do
        *v5++ = FMOD::CodecMPEG::getBitsFast(this, v7);
      while ( v5 != scf + 8 );
      *numbits -= v7;
      v14 = 9;
    }
    v15 = v14 - 1;
    v16 = v5;
    v17 = (__int64)&v5[v15 + 1];
    scfsia = v15;
    do
      *v16++ = FMOD::CodecMPEG::getBitsFast(this, v7);
    while ( v16 != (int *)v17 );
    v18 = &v5[scfsia + 1];
    v19 = (__int64)&v5[scfsia + 19];
    v20 = v18;
    do
      *v20++ = FMOD::CodecMPEG::getBitsFast(this, v8);
    while ( v20 != (int *)v19 );
    v18[18] = 0;
    v18[19] = 0;
    v18[20] = 0;
  }
  else
  {
    scfsi = gr_info->scfsi;
    if ( gr_info->scfsi < 0 )
    {
      v21 = scf + 11;
      v22 = scf;
      do
      {
        scfsib = v22 + 1;
        BitsFast = FMOD::CodecMPEG::getBitsFast(this, v7);
        v22 = scfsib;
        *(scfsib - 1) = BitsFast;
      }
      while ( scfsib != v21 );
      do
        *v21++ = FMOD::CodecMPEG::getBitsFast(this, v8);
      while ( v21 != scf + 21 );
      v12 = v21;
      *numbits = v7 + 10 * (v7 + v8);
    }
    else
    {
      v9 = scf + 6;
      if ( (scfsi & 8) == 0 )
      {
        do
          *v5++ = FMOD::CodecMPEG::getBitsFast(this, v7);
        while ( v5 != v9 );
        *numbits += 6 * v7;
      }
      v10 = scf + 11;
      if ( (scfsi & 4) == 0 )
      {
        do
          *v9++ = FMOD::CodecMPEG::getBitsFast(this, v7);
        while ( v9 != v10 );
        *numbits += 5 * v7;
      }
      v11 = scf + 16;
      if ( (scfsi & 2) == 0 )
      {
        do
          *v10++ = FMOD::CodecMPEG::getBitsFast(this, v8);
        while ( v10 != v11 );
        *numbits += 5 * v8;
      }
      v12 = scf + 21;
      if ( (scfsi & 1) == 0 )
      {
        do
          *v11++ = FMOD::CodecMPEG::getBitsFast(this, v8);
        while ( v11 != v12 );
        *numbits += 5 * v8;
      }
    }
    *v12 = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2223d00 | Name: _ZN4FMOD9CodecMPEG23III_get_scale_factors_2EPiPNS_9gr_info_sEiS1_
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::III_get_scale_factors_2(
        FMOD::CodecMPEG *const this,
        int *scf,
        FMOD::gr_info_s *gr_info,
        int i_stereo,
        int *numbits)
{
  int v6; // eax
  __int64 v7; // r14
  unsigned __int8 *v8; // r13
  char v9; // r15
  int v10; // r15d
  int v11; // eax
  __int64 v12; // rax
  int v14; // r12d
  int v15; // eax
  int v16; // [rsp+0h] [rbp-48h]
  unsigned int slen; // [rsp+4h] [rbp-44h]

  *numbits = 0;
  if ( i_stereo )
    slen = FMOD::CodecMPEG::gI_SLen2[gr_info->scalefac_compress >> 1];
  else
    slen = FMOD::CodecMPEG::gN_SLen2[gr_info->scalefac_compress];
  v16 = 0;
  gr_info->preflag = (slen >> 15) & 1;
  v6 = 0;
  if ( gr_info->block_type == 2 )
  {
    v6 = 2 - (gr_info->mixed_block_flag == 0);
    v16 = gr_info->mixed_block_flag == 0 ? 2 : 4;
  }
  v7 = 0;
  v8 = byte_286C9E0[v6][(slen >> 12) & 7];
  do
  {
    while ( 1 )
    {
      v9 = slen;
      slen >>= 3;
      v10 = v9 & 7;
      if ( !v10 )
        break;
      if ( v8[v7] )
      {
        v14 = 0;
        do
        {
          *scf++ = FMOD::CodecMPEG::getBitsFast(this, v10);
          v15 = v8[v7];
          ++v14;
        }
        while ( v15 > v14 );
        *numbits += v15 * v10;
      }
      else
      {
        *numbits = *numbits;
      }
      if ( ++v7 == 4 )
        goto LABEL_10;
    }
    v11 = 0;
    if ( v8[v7] )
    {
      do
      {
        *scf++ = 0;
        ++v11;
      }
      while ( v8[v7] > v11 );
    }
    ++v7;
  }
  while ( v7 != 4 );
LABEL_10:
  v12 = 0;
  do
    scf[v12++] = 0;
  while ( v16 >= (int)v12 );
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2223e90 | Name: _ZN4FMOD9CodecMPEG21III_dequantize_sampleEPA18_fPiPNS_9gr_info_sEii
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::III_dequantize_sample(
        FMOD::CodecMPEG *const this,
        float (*xr)[18],
        int *scf,
        FMOD::gr_info_s *gr_info,
        int sfreq,
        int part2bits)
{
  unsigned int scalefac_scale; // r12d
  unsigned int part2_3_length; // r15d
  unsigned int Bits; // eax
  signed int region1start; // edx
  signed int region2start; // ecx
  signed int big_values; // esi
  int v16; // r11d
  int v18; // ecx
  int v19; // edi
  int v20; // r10d
  int v21; // r14d
  int v22; // r13d
  float v23; // xmm0_4
  int *v24; // rax
  int v25; // r8d
  __int64 v26; // rax
  float *v27; // rbx
  int *v28; // r9
  __int16 *v29; // rax
  int v30; // r12d
  int v31; // edx
  int v32; // eax
  int v33; // ecx
  FMOD::CodecMPEG_Context *v34; // rsi
  unsigned __int8 *v35; // rdx
  unsigned int v36; // eax
  __int64 v37; // rdi
  int v38; // eax
  __int16 *k; // rax
  __int16 *v40; // rdx
  int v41; // eax
  int v42; // edi
  float *v43; // rdx
  int v44; // esi
  int v45; // r12d
  __int16 *v46; // rax
  __int16 v47; // r15
  int v48; // eax
  int v49; // ecx
  FMOD::CodecMPEG_Context *v50; // rsi
  unsigned __int8 *v51; // rdx
  unsigned int v52; // eax
  __int64 v53; // rdi
  __int16 *m; // rax
  float v55; // xmm1_4
  float v56; // xmm1_4
  unsigned int v57; // ebx
  int v58; // eax
  int v59; // ecx
  FMOD::CodecMPEG_Context *v60; // rdi
  unsigned __int8 *v61; // rsi
  unsigned int v62; // eax
  __int64 v63; // rax
  float v64; // xmm1_4
  float *v65; // rdx
  int n; // eax
  int v67; // r12d
  __int64 v68; // r14
  FMOD::CodecMPEG_Context *v69; // rax
  int v70; // ecx
  int v71; // ebx
  unsigned int v72; // r13d
  int v73; // eax
  int v74; // ecx
  FMOD::CodecMPEG_Context *v75; // rsi
  unsigned __int8 *v76; // rdx
  unsigned int v77; // eax
  unsigned int v78; // eax
  __int64 v79; // rax
  float v80; // xmm1_4
  unsigned int mixed_block_flag; // r9d
  __int64 v82; // rdx
  int *v83; // rax
  int *v84; // r9
  float v85; // xmm0_4
  int v86; // r15d
  __int16 *v87; // rax
  __int16 *v88; // rsi
  __int64 v89; // r8
  int v90; // eax
  int v91; // ecx
  FMOD::CodecMPEG_Context *v92; // rsi
  unsigned __int8 *v93; // rdx
  unsigned int v94; // eax
  __int64 v95; // rdi
  int v96; // eax
  __int16 *j; // rax
  __int16 *v98; // rdx
  int v99; // eax
  int v100; // edi
  float *v101; // rbx
  int v102; // r13d
  int v103; // esi
  int v104; // edi
  __int16 *table; // rax
  int v106; // eax
  int v107; // ecx
  FMOD::CodecMPEG_Context *mContext; // rsi
  unsigned __int8 *mWordPointer; // rdx
  unsigned int v110; // eax
  __int64 v111; // r8
  __int16 *i; // rax
  int v113; // edx
  int v114; // eax
  float *pow2gain; // rcx
  bool v116; // zf
  float *v117; // rcx
  float v118; // xmm1_4
  float v119; // xmm1_4
  unsigned int v120; // esi
  int v121; // eax
  int v122; // ecx
  FMOD::CodecMPEG_Context *v123; // rdi
  unsigned __int8 *v124; // rdx
  unsigned int v125; // eax
  unsigned int v126; // eax
  __int64 v127; // rax
  float v128; // xmm1_4
  unsigned int linbits; // r12d
  int v130; // eax
  int v131; // ecx
  FMOD::CodecMPEG_Context *v132; // rsi
  unsigned __int8 *v133; // rdx
  unsigned int v134; // eax
  unsigned int v135; // eax
  __int64 v136; // rax
  float v137; // xmm1_4
  int v138; // edx
  int v139; // ecx
  int v140; // r8d
  signed int v141; // edi
  bool v142; // cc
  int v143; // eax
  unsigned int v144; // eax
  __int64 v145; // rdx
  int cb; // [rsp+14h] [rbp-D4h]
  int cba; // [rsp+14h] [rbp-D4h]
  int cbb; // [rsp+14h] [rbp-D4h]
  int *pretab; // [rsp+18h] [rbp-D0h]
  int pretaba; // [rsp+18h] [rbp-D0h]
  __int16 pretabb; // [rsp+18h] [rbp-D0h]
  int lp; // [rsp+28h] [rbp-C0h]
  int lpa; // [rsp+28h] [rbp-C0h]
  int lpb; // [rsp+28h] [rbp-C0h]
  __int16 *lpc; // [rsp+28h] [rbp-C0h]
  __int16 v158; // [rsp+30h] [rbp-B8h]
  __int16 *v159; // [rsp+30h] [rbp-B8h]
  __int16 v160; // [rsp+30h] [rbp-B8h]
  __int16 *v161; // [rsp+38h] [rbp-B0h]
  int v162; // [rsp+38h] [rbp-B0h]
  FMOD::newhuff *v163; // [rsp+40h] [rbp-A8h]
  int v164; // [rsp+40h] [rbp-A8h]
  char shift; // [rsp+48h] [rbp-A0h]
  int l3; // [rsp+4Ch] [rbp-9Ch]
  __int64 v168; // [rsp+58h] [rbp-90h]
  __int16 *v169; // [rsp+58h] [rbp-90h]
  FMOD::newhuff *h; // [rsp+60h] [rbp-88h]
  __int64 sfreqa; // [rsp+78h] [rbp-70h]
  __int64 sfreqb; // [rsp+78h] [rbp-70h]
  __int64 v173; // [rsp+80h] [rbp-68h]
  int *me; // [rsp+88h] [rbp-60h]
  int l[4]; // [rsp+90h] [rbp-58h]
  int max[18]; // [rsp+A0h] [rbp-48h]

  scalefac_scale = gr_info->scalefac_scale;
  part2_3_length = gr_info->part2_3_length;
  cb = -this->mContext->mBSI.mBitIndex & 7;
  Bits = FMOD::CodecMPEG::getBits(this, cb);
  region1start = gr_info->region1start;
  region2start = gr_info->region2start;
  big_values = gr_info->big_values;
  v16 = cb;
  if ( region1start > region2start )
    return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
  l3 = (288 - big_values) >> 1;
  if ( big_values <= region1start )
  {
    l[0] = gr_info->big_values;
    l[1] = 0;
    region1start = big_values;
    l[2] = 0;
    v18 = 0;
    v19 = 0;
  }
  else
  {
    l[0] = gr_info->region1start;
    if ( big_values > region2start )
    {
      v19 = region2start - region1start;
      v18 = big_values - region2start;
      l[2] = v18;
      l[1] = v19;
    }
    else
    {
      l[2] = 0;
      v18 = 0;
      v19 = big_values - region1start;
      l[1] = big_values - region1start;
    }
  }
  if ( region1start < 0 )
    l[0] = 0;
  if ( v19 < 0 )
    l[1] = 0;
  if ( v18 < 0 )
    l[2] = 0;
  v20 = part2_3_length - part2bits - cb;
  shift = scalefac_scale + 1;
  v21 = Bits << (32 - cb);
  if ( gr_info->block_type == 2 )
  {
    mixed_block_flag = gr_info->mixed_block_flag;
    max[3] = -1;
    if ( mixed_block_flag )
    {
      max[2] = 2;
      max[1] = 2;
      sfreqb = sfreq;
      max[0] = 2;
      v82 = sfreq;
      v83 = FMOD::CodecMPEG::gMapEnd[v82][0];
      v84 = FMOD::CodecMPEG::gMap[v82][0];
    }
    else
    {
      max[2] = -1;
      max[1] = -1;
      sfreqb = sfreq;
      max[0] = -1;
      v145 = sfreq;
      v83 = FMOD::CodecMPEG::gMapEnd[v145][1];
      v84 = FMOD::CodecMPEG::gMap[v145][1];
    }
    me = v83;
    v27 = (float *)xr;
    v85 = 0.0;
    v173 = 0;
    v86 = 0;
    cbb = 0;
    v164 = 0;
    pretaba = 3;
    while ( 1 )
    {
      lpb = l[v173];
      h = &stru_286CC00[gr_info->table_select[v173]];
      if ( lpb )
        break;
LABEL_134:
      if ( ++v173 == 2 )
      {
        v102 = pretaba;
        v103 = v20 + v16;
        if ( !l3 || v103 <= 0 )
          goto LABEL_202;
        if ( v27 >= &(*xr)[581] )
          return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
        v104 = v164;
        table = stru_286CBE0[gr_info->count1table_select].table;
        lpc = table + 1;
        pretabb = *table;
LABEL_139:
        if ( v16 <= 23 )
        {
          v106 = v16;
          v107 = 24 - v16;
          do
          {
            mContext = this->mContext;
            v106 += 8;
            mWordPointer = mContext->mBSI.mWordPointer;
            mContext->mBSI.mWordPointer = mWordPointer + 1;
            LODWORD(mWordPointer) = *mWordPointer << v107;
            v107 -= 8;
            v21 |= (unsigned int)mWordPointer;
          }
          while ( v106 <= 23 );
          v110 = (unsigned int)(23 - v16) >> 3;
          v16 += 8 * v110 + 8;
          v20 = v20 - 8 * v110 - 8;
        }
        v111 = pretabb;
        if ( pretabb < 0 )
        {
          for ( i = lpc; ; ++i )
          {
            if ( v21 < 0 )
              i -= v111;
            v111 = *i;
            --v16;
            v21 *= 2;
            if ( (v111 & 0x8000u) == 0LL )
              break;
          }
        }
        v113 = v20 + v16;
        if ( v20 + v16 <= 0 )
        {
          v103 = 0;
          v16 = -v20;
          goto LABEL_202;
        }
        v114 = 0;
        while ( 1 )
        {
          if ( (v114 & 1) == 0 )
          {
            if ( !v86 )
            {
              v102 = v84[2];
              v86 = *v84;
              v27 = &(*xr)[v84[1]];
              cbb = v84[3];
              if ( v102 == 3 )
              {
                v84 += 4;
                v104 = 1;
                pow2gain = gr_info->pow2gain;
              }
              else
              {
                pow2gain = gr_info->full_gain[v102];
                v84 += 4;
                v104 = 3;
              }
              v85 = pow2gain[*scf++ << shift];
            }
            --v86;
          }
          if ( ((unsigned int)v111 & (8 >> v114)) != 0 )
          {
            max[v102] = cbb;
            if ( v113 <= 0 )
            {
              v103 = v113;
              goto LABEL_202;
            }
            if ( v21 < 0 )
              *v27 = -v85;
            else
              *v27 = v85;
            --v16;
            v21 *= 2;
            v113 = v20 + v16;
          }
          else
          {
            *v27 = 0.0;
          }
          ++v114;
          v27 += v104;
          if ( v114 == 4 )
          {
            v116 = l3-- == 1;
            v103 = v113;
            if ( !v116 && v113 > 0 )
            {
              if ( v27 >= &(*xr)[581] )
                return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
              goto LABEL_139;
            }
LABEL_202:
            if ( v102 <= 2 )
            {
              while ( 1 )
              {
                for ( ; v86 > 0; v27 += 6 )
                {
                  --v86;
                  *v27 = 0.0;
                  v27[3] = 0.0;
                }
                if ( me <= v84 )
                  break;
                v86 = *v84;
                v27 = &(*xr)[v84[1]];
                if ( !v84[2] )
                  break;
                v84 += 4;
              }
            }
            v138 = max[0];
            v139 = max[1];
            v140 = max[2];
            v141 = max[3] + 1;
            v142 = max[1] < max[0];
            gr_info->maxband[0] = max[0] + 1;
            if ( !v142 )
              v138 = v139;
            gr_info->maxbandl = v141;
            gr_info->maxband[1] = v139 + 1;
            v143 = v140 + 1;
            gr_info->maxband[2] = v140 + 1;
            if ( v138 > v140 )
              v143 = v138 + 1;
            if ( v143 )
              v144 = FMOD::CodecMPEG::gShortLimit[sfreqb][v143];
            else
              v144 = FMOD::CodecMPEG::gLongLimit[0][v141 + 24 * sfreqb - sfreqb];
            v67 = v103;
            gr_info->maxb = v144;
            goto LABEL_86;
          }
        }
      }
    }
    v87 = stru_286CC00[gr_info->table_select[v173]].table;
    v88 = v87 + 1;
    LODWORD(v87) = *v87;
    v169 = v88;
    v160 = (__int16)v87;
    v162 = (int)v87;
    while ( 1 )
    {
      if ( v86 )
      {
        v89 = v164;
      }
      else
      {
        v86 = *v84;
        v27 = &(*xr)[v84[1]];
        cbb = v84[3];
        pretaba = v84[2];
        v84 += 4;
        if ( pretaba == 3 )
        {
          v89 = 1;
          v164 = 1;
          v117 = gr_info->pow2gain;
        }
        else
        {
          v89 = 3;
          v164 = 3;
          v117 = gr_info->full_gain[pretaba];
        }
        v85 = v117[*scf++ << shift];
      }
      if ( v16 <= 23 )
      {
        v90 = v16;
        v91 = 24 - v16;
        do
        {
          v92 = this->mContext;
          v90 += 8;
          v93 = v92->mBSI.mWordPointer;
          v92->mBSI.mWordPointer = v93 + 1;
          LODWORD(v93) = *v93 << v91;
          v91 -= 8;
          v21 |= (unsigned int)v93;
        }
        while ( v90 <= 23 );
        v94 = (unsigned int)(23 - v16) >> 3;
        v16 += 8 * v94 + 8;
        v20 = v20 - 8 * v94 - 8;
      }
      v95 = v160;
      v96 = v162;
      if ( v162 < 0 )
      {
        for ( j = v169; ; j = v98 )
        {
          if ( v21 < 0 )
            j -= v95;
          v95 = *j;
          v98 = j + 1;
          --v16;
          v21 *= 2;
          v96 = (__int16)v95;
          if ( (v95 & 0x8000u) == 0LL )
            break;
        }
      }
      v99 = v96 >> 4;
      v100 = v95 & 0xF;
      if ( v99 != 15 )
        break;
      linbits = h->linbits;
      if ( !h->linbits )
        goto LABEL_175;
      max[pretaba] = cbb;
      if ( v16 <= 23 )
      {
        v130 = v16;
        v131 = 24 - v16;
        do
        {
          v132 = this->mContext;
          v130 += 8;
          v133 = v132->mBSI.mWordPointer;
          v132->mBSI.mWordPointer = v133 + 1;
          LODWORD(v133) = *v133 << v131;
          v131 -= 8;
          v21 |= (unsigned int)v133;
        }
        while ( v130 <= 23 );
        v134 = (unsigned int)(23 - v16) >> 3;
        v16 += 8 * v134 + 8;
        v20 = v20 - 8 * v134 - 8;
      }
      v135 = (unsigned int)v21 >> (32 - linbits);
      v16 += ~linbits;
      v21 <<= linbits;
      v136 = (int)(v135 + 15);
      if ( v21 < 0 )
        v137 = -FMOD::CodecMPEG::gIsPowTable[v136];
      else
        v137 = FMOD::CodecMPEG::gIsPowTable[v136];
      *v27 = v137 * v85;
LABEL_178:
      v21 *= 2;
      v101 = &v27[v89];
      if ( v100 == 15 )
      {
LABEL_179:
        v120 = h->linbits;
        if ( h->linbits )
        {
          max[pretaba] = cbb;
          if ( v16 <= 23 )
          {
            v121 = v16;
            v122 = 24 - v16;
            do
            {
              v123 = this->mContext;
              v121 += 8;
              v124 = v123->mBSI.mWordPointer;
              v123->mBSI.mWordPointer = v124 + 1;
              LODWORD(v124) = *v124 << v122;
              v122 -= 8;
              v21 |= (unsigned int)v124;
            }
            while ( v121 <= 23 );
            v125 = (unsigned int)(23 - v16) >> 3;
            v16 += 8 * v125 + 8;
            v20 = v20 - 8 * v125 - 8;
          }
          v126 = (unsigned int)v21 >> (32 - v120);
          v16 += ~v120;
          v21 <<= v120;
          v127 = (int)(v126 + 15);
          if ( v21 < 0 )
            v128 = -FMOD::CodecMPEG::gIsPowTable[v127];
          else
            v128 = FMOD::CodecMPEG::gIsPowTable[v127];
          *v101 = v128 * v85;
        }
        else
        {
LABEL_171:
          max[pretaba] = cbb;
          if ( v21 < 0 )
            v118 = -FMOD::CodecMPEG::gIsPowTable[v100];
          else
            v118 = FMOD::CodecMPEG::gIsPowTable[v100];
          *v101 = v118 * v85;
          --v16;
        }
        v21 *= 2;
        goto LABEL_133;
      }
LABEL_131:
      if ( v100 )
        goto LABEL_171;
      *v101 = 0.0;
LABEL_133:
      v27 = &v101[v89];
      --v86;
      if ( !--lpb )
        goto LABEL_134;
    }
    if ( !v99 )
    {
      *v27 = 0.0;
      v101 = &v27[v89];
      if ( v100 == 15 )
        goto LABEL_179;
      goto LABEL_131;
    }
LABEL_175:
    max[pretaba] = cbb;
    if ( v21 < 0 )
      v119 = -FMOD::CodecMPEG::gIsPowTable[v99];
    else
      v119 = FMOD::CodecMPEG::gIsPowTable[v99];
    *v27 = v119 * v85;
    --v16;
    goto LABEL_178;
  }
  v168 = 0;
  v22 = -1;
  v23 = 0.0;
  v24 = dword_2AF7400;
  if ( gr_info->preflag )
    v24 = dword_286CB80;
  v25 = 0;
  pretab = v24;
  v26 = sfreq;
  v27 = (float *)xr;
  sfreqa = v26;
  cba = 0;
  v28 = FMOD::CodecMPEG::gMap[v26][2];
  do
  {
    lp = l[v168];
    v163 = &stru_286CC00[gr_info->table_select[v168]];
    if ( lp )
    {
      v29 = stru_286CC00[gr_info->table_select[v168]].table;
      v161 = v29 + 1;
      v158 = *v29;
      v30 = *v29;
      while ( 1 )
      {
        if ( !v25 )
        {
          v25 = *v28;
          cba = v28[1];
          v28 += 2;
          if ( cba == 21 )
          {
            v23 = 0.0;
          }
          else
          {
            v31 = *pretab++ + *scf++;
            v23 = gr_info->pow2gain[v31 << shift];
          }
        }
        if ( v16 <= 23 )
        {
          v32 = v16;
          v33 = 24 - v16;
          do
          {
            v34 = this->mContext;
            v32 += 8;
            v35 = v34->mBSI.mWordPointer;
            v34->mBSI.mWordPointer = v35 + 1;
            LODWORD(v35) = *v35 << v33;
            v33 -= 8;
            v21 |= (unsigned int)v35;
          }
          while ( v32 <= 23 );
          v36 = (unsigned int)(23 - v16) >> 3;
          v16 += 8 * v36 + 8;
          v20 = v20 - 8 * v36 - 8;
        }
        v37 = v158;
        v38 = v30;
        if ( v30 < 0 )
        {
          for ( k = v161; ; k = v40 )
          {
            if ( v21 < 0 )
              k -= v37;
            v37 = *k;
            v40 = k + 1;
            --v16;
            v21 *= 2;
            v38 = (__int16)v37;
            if ( (v37 & 0x8000u) == 0LL )
              break;
          }
        }
        v41 = v38 >> 4;
        v42 = v37 & 0xF;
        if ( v41 != 15 )
          break;
        v72 = v163->linbits;
        if ( !v163->linbits )
          goto LABEL_56;
        if ( v16 <= 23 )
        {
          v73 = v16;
          v74 = 24 - v16;
          do
          {
            v75 = this->mContext;
            v73 += 8;
            v76 = v75->mBSI.mWordPointer;
            v75->mBSI.mWordPointer = v76 + 1;
            LODWORD(v76) = *v76 << v74;
            v74 -= 8;
            v21 |= (unsigned int)v76;
          }
          while ( v73 <= 23 );
          v77 = (unsigned int)(23 - v16) >> 3;
          v16 += 8 * v77 + 8;
          v20 = v20 - 8 * v77 - 8;
        }
        v78 = (unsigned int)v21 >> (32 - v72);
        v16 += ~v72;
        v21 <<= v72;
        v43 = v27 + 1;
        v79 = (int)(v78 + 15);
        if ( v21 < 0 )
          v80 = -FMOD::CodecMPEG::gIsPowTable[v79];
        else
          v80 = FMOD::CodecMPEG::gIsPowTable[v79];
        *v27 = v80 * v23;
LABEL_59:
        v21 *= 2;
        v22 = cba;
        if ( v42 == 15 )
        {
LABEL_60:
          v57 = v163->linbits;
          if ( v163->linbits )
          {
            if ( v16 <= 23 )
            {
              v58 = v16;
              v59 = 24 - v16;
              do
              {
                v60 = this->mContext;
                v58 += 8;
                v61 = v60->mBSI.mWordPointer;
                v60->mBSI.mWordPointer = v61 + 1;
                LODWORD(v61) = *v61 << v59;
                v59 -= 8;
                v21 |= (unsigned int)v61;
              }
              while ( v58 <= 23 );
              v62 = (unsigned int)(23 - v16) >> 3;
              v16 += 8 * v62 + 8;
              v20 = v20 - 8 * v62 - 8;
            }
            v16 += ~v57;
            v63 = (int)(((unsigned int)v21 >> (32 - v57)) + 15);
            v21 <<= v57;
            v27 = v43 + 1;
            if ( v21 < 0 )
              v64 = -FMOD::CodecMPEG::gIsPowTable[v63];
            else
              v64 = FMOD::CodecMPEG::gIsPowTable[v63];
            *v43 = v64 * v23;
          }
          else
          {
LABEL_52:
            v27 = v43 + 1;
            if ( v21 < 0 )
              v55 = -FMOD::CodecMPEG::gIsPowTable[v42];
            else
              v55 = FMOD::CodecMPEG::gIsPowTable[v42];
            *v43 = v55 * v23;
            --v16;
          }
          v21 *= 2;
          v22 = cba;
          goto LABEL_37;
        }
LABEL_35:
        if ( v42 )
          goto LABEL_52;
        v27 = v43 + 1;
        *v43 = 0.0;
LABEL_37:
        --v25;
        if ( !--lp )
          goto LABEL_38;
      }
      if ( !v41 )
      {
        v43 = v27 + 1;
        *v27 = 0.0;
        if ( v42 == 15 )
          goto LABEL_60;
        goto LABEL_35;
      }
LABEL_56:
      v43 = v27 + 1;
      if ( v21 < 0 )
        v56 = -FMOD::CodecMPEG::gIsPowTable[v41];
      else
        v56 = FMOD::CodecMPEG::gIsPowTable[v41];
      *v27 = v56 * v23;
      --v16;
      goto LABEL_59;
    }
LABEL_38:
    ++v168;
  }
  while ( v168 != 3 );
  lpa = v22;
  v44 = v20 + v16;
  v45 = cba;
  if ( l3 && v44 > 0 )
  {
    v46 = stru_286CBE0[gr_info->count1table_select].table;
    v47 = *v46;
    v159 = v46 + 1;
    while ( 1 )
    {
      if ( v16 <= 23 )
      {
        v48 = v16;
        v49 = 24 - v16;
        do
        {
          v50 = this->mContext;
          v48 += 8;
          v51 = v50->mBSI.mWordPointer;
          v50->mBSI.mWordPointer = v51 + 1;
          LODWORD(v51) = *v51 << v49;
          v49 -= 8;
          v21 |= (unsigned int)v51;
        }
        while ( v48 <= 23 );
        v52 = (unsigned int)(23 - v16) >> 3;
        v16 += 8 * v52 + 8;
        v20 = v20 - 8 * v52 - 8;
      }
      v53 = v47;
      if ( v47 < 0 )
      {
        for ( m = v159; ; ++m )
        {
          if ( v21 < 0 )
            m -= v53;
          v53 = *m;
          --v16;
          v21 *= 2;
          if ( (v53 & 0x8000u) == 0LL )
            break;
        }
      }
      v44 = v20 + v16;
      if ( v20 + v16 <= 0 )
        break;
      v65 = v27 + 1;
      for ( n = 0; n != 4; ++n )
      {
        v27 = v65 - 1;
        if ( (n & 1) == 0 )
        {
          if ( !v25 )
          {
            v45 = v28[1];
            v25 = *v28;
            if ( v45 == 21 )
            {
              v28 += 2;
              v23 = 0.0;
            }
            else
            {
              v23 = gr_info->pow2gain[(*pretab + *scf) << shift];
              v28 += 2;
              ++scf;
              ++pretab;
            }
          }
          --v25;
        }
        if ( ((unsigned int)v53 & (8 >> n)) != 0 )
        {
          if ( v44 <= 0 )
            goto LABEL_84;
          v27 = v65;
          if ( v21 < 0 )
            *(v65 - 1) = -v23;
          else
            *(v65 - 1) = v23;
          --v16;
          v21 *= 2;
          lpa = v45;
          v44 = v20 + v16;
        }
        else
        {
          v27 = v65;
          *(v65 - 1) = 0.0;
        }
        ++v65;
      }
      if ( !--l3 )
        goto LABEL_85;
      if ( v44 <= 0 )
      {
        v45 = lpa;
LABEL_84:
        lpa = v45;
        goto LABEL_85;
      }
    }
    v44 = 0;
    v16 = -v20;
  }
LABEL_85:
  v67 = v44;
  v68 = (unsigned int)(lpa + 1);
  gr_info->maxbandl = v68;
  gr_info->maxb = FMOD::CodecMPEG::gLongLimit[0][v68 + 24 * sfreqa - sfreqa];
LABEL_86:
  v69 = this->mContext;
  v70 = v69->mBSI.mBitIndex - v16;
  v69->mBSI.mBitIndex = v70 & 7;
  for ( v69->mBSI.mWordPointer += v70 >> 3; &(*xr)[576] > v27; *(v27 - 1) = 0.0 )
    ++v27;
  v71 = v67;
  if ( v67 > 16 )
  {
    do
    {
      v71 -= 16;
      FMOD::CodecMPEG::getBits(this, 16);
    }
    while ( v71 > 16 );
    v67 = v67 - ((v67 - 17) & 0xFFFFFFF0) - 16;
  }
  if ( v67 <= 0 )
  {
    if ( !v67 )
      return FMOD_RESULT::FMOD_OK_0;
    return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
  }
  FMOD::CodecMPEG::getBits(this, v67);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2225070 | Name: _ZN4FMOD9CodecMPEG24III_dequantize_sample_msEPA32_A18_fPiPNS_9gr_info_sEii
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::III_dequantize_sample_ms(
        FMOD::CodecMPEG *const this,
        float (*xr)[32][18],
        int *scf,
        FMOD::gr_info_s *gr_info,
        int sfreq,
        int part2bits)
{
  signed int big_values; // eax
  int v8; // ebx
  signed int region1start; // ecx
  float *v12; // rdx
  signed int region2start; // edi
  int v14; // eax
  int v15; // esi
  FMOD::gr_info_s *v16; // rax
  float *v17; // r12
  float v18; // xmm0_4
  int *v19; // rax
  int v20; // r14d
  int *v21; // r8
  int v22; // eax
  FMOD::newhuff *v23; // r9
  float *v24; // r13
  float *v25; // r15
  int *v26; // rdi
  int v27; // r8d
  __int16 *v28; // rax
  __int64 v29; // r10
  __int16 *v30; // rdx
  int v31; // eax
  FMOD::CodecMPEG_Context *v32; // rax
  unsigned __int8 *v33; // rdi
  int v34; // ecx
  int v35; // esi
  int v36; // eax
  int v37; // r10d
  FMOD::CodecMPEG_Context *v38; // rdx
  unsigned __int8 *v39; // rdi
  int v40; // ecx
  int v41; // esi
  float v42; // xmm2_4
  float *v43; // r11
  FMOD::CodecMPEG_Context *v44; // rax
  unsigned __int8 *v45; // rsi
  int v46; // ecx
  int v47; // edx
  bool v48; // zf
  float v49; // xmm2_4
  int *v50; // r15
  int *v51; // r11
  __int64 v52; // r9
  __int16 *v53; // r10
  FMOD::CodecMPEG_Context *mContext; // rax
  unsigned __int8 *mWordPointer; // r8
  int mBitIndex; // ecx
  int v57; // esi
  __int16 *v58; // rax
  float *v59; // rdi
  float *v60; // rax
  int v61; // esi
  int v62; // ecx
  int v63; // r8d
  int v64; // r10d
  FMOD::CodecMPEG_Context *v65; // rdx
  unsigned __int8 *v66; // rbx
  int v67; // ecx
  int v68; // r8d
  float v69; // xmm1_4
  int i; // eax
  float v71; // xmm0_4
  __int64 v72; // rax
  int j; // r12d
  unsigned int v75; // edi
  FMOD::CodecMPEG_Context *v76; // rax
  unsigned __int8 *v77; // rsi
  int v78; // ecx
  int v79; // edx
  float v80; // xmm2_4
  unsigned int v81; // edi
  FMOD::CodecMPEG_Context *v82; // rax
  unsigned __int8 *v83; // rsi
  int v84; // ecx
  int v85; // edx
  float v86; // xmm2_4
  unsigned int mixed_block_flag; // r11d
  __int64 v88; // rcx
  int *v89; // rax
  int *v90; // r11
  float *v91; // r12
  float v92; // xmm0_4
  int v93; // r15d
  float *v94; // r14
  FMOD::newhuff *v95; // rdx
  __int64 v96; // r13
  __int16 *v97; // rax
  __int64 v98; // r9
  __int16 *v99; // rsi
  int v100; // eax
  FMOD::CodecMPEG_Context *v101; // rax
  unsigned __int8 *v102; // r8
  int v103; // ecx
  int v104; // edi
  int v105; // eax
  int v106; // r9d
  FMOD::CodecMPEG_Context *v107; // rsi
  unsigned __int8 *v108; // r8
  int v109; // ecx
  int v110; // edi
  float v111; // xmm2_4
  float v112; // xmm2_4
  float *v113; // r14
  float *v114; // r12
  FMOD::CodecMPEG_Context *v115; // rax
  unsigned __int8 *v116; // rdi
  int v117; // ecx
  int v118; // esi
  float v119; // xmm2_4
  float *v120; // rdx
  int v121; // r14d
  __int16 *v122; // rax
  FMOD::CodecMPEG_Context *v123; // rax
  unsigned __int8 *v124; // r9
  int v125; // ecx
  int v126; // esi
  __int16 *v127; // r8
  __int64 v128; // r10
  int v129; // eax
  float *v130; // rcx
  FMOD::CodecMPEG_Context *v131; // rsi
  unsigned __int8 *v132; // r8
  int v133; // ecx
  int v134; // edi
  float v135; // xmm1_4
  __int64 v136; // rcx
  int v137; // ecx
  __int64 v138; // rax
  float v139; // xmm0_4
  int *v140; // r12
  _DWORD *v141; // rdx
  int v142; // xmm0_4
  bool v143; // cl
  __int64 v144; // rcx
  float *pow2gain; // rcx
  float v146; // xmm1_4
  unsigned int v147; // r8d
  FMOD::CodecMPEG_Context *v148; // rax
  unsigned __int8 *v149; // r9
  int v150; // ecx
  int v151; // esi
  float v152; // xmm2_4
  unsigned int v153; // r8d
  FMOD::CodecMPEG_Context *v154; // rax
  unsigned __int8 *v155; // r10
  int v156; // ecx
  int v157; // esi
  float v158; // xmm2_4
  int v159; // edx
  int v160; // ecx
  int v161; // edi
  signed int v162; // esi
  bool v163; // cc
  int v164; // eax
  unsigned int v165; // eax
  int step; // [rsp+Ch] [rbp-DCh]
  int stepa; // [rsp+Ch] [rbp-DCh]
  int cb; // [rsp+10h] [rbp-D8h]
  FMOD::newhuff *cbb; // [rsp+10h] [rbp-D8h]
  FMOD::newhuff *cbc; // [rsp+10h] [rbp-D8h]
  int cba; // [rsp+10h] [rbp-D8h]
  int *lwin; // [rsp+18h] [rbp-D0h]
  int lwina; // [rsp+18h] [rbp-D0h]
  __int16 *lwinb; // [rsp+18h] [rbp-D0h]
  __int64 v177; // [rsp+30h] [rbp-B8h]
  __int16 *table; // [rsp+30h] [rbp-B8h]
  int v179; // [rsp+30h] [rbp-B8h]
  int shift; // [rsp+38h] [rbp-B0h]
  int l3; // [rsp+3Ch] [rbp-ACh]
  float *v; // [rsp+48h] [rbp-A0h]
  int *va; // [rsp+48h] [rbp-A0h]
  int ya; // [rsp+50h] [rbp-98h]
  __int64 y; // [rsp+50h] [rbp-98h]
  int *m; // [rsp+58h] [rbp-90h]
  int *ma; // [rsp+58h] [rbp-90h]
  int *mb; // [rsp+58h] [rbp-90h]
  int *mc; // [rsp+58h] [rbp-90h]
  __int64 v191; // [rsp+60h] [rbp-88h]
  __int64 sfreqa; // [rsp+78h] [rbp-70h]
  __int64 sfreqb; // [rsp+78h] [rbp-70h]
  int *v194; // [rsp+80h] [rbp-68h]
  int v195; // [rsp+80h] [rbp-68h]
  int *v196; // [rsp+88h] [rbp-60h]
  int l[4]; // [rsp+90h] [rbp-58h]
  int max_0[18]; // [rsp+A0h] [rbp-48h]

  big_values = gr_info->big_values;
  v8 = gr_info->part2_3_length - part2bits;
  l3 = (288 - big_values) >> 1;
  shift = gr_info->scalefac_scale + 1;
  region1start = gr_info->region1start;
  v12 = (*xr)[32];
  region2start = gr_info->region2start;
  if ( big_values <= region1start )
  {
    l[0] = big_values;
    region1start = big_values;
    l[1] = 0;
    l[2] = 0;
    v14 = 0;
    v15 = 0;
    goto LABEL_3;
  }
  l[0] = region1start;
  if ( big_values > region2start )
  {
    v14 = big_values - region2start;
    v15 = region2start - region1start;
    l[2] = v14;
    l[1] = region2start - region1start;
LABEL_3:
    if ( region1start >= 0 )
      goto LABEL_4;
    goto LABEL_81;
  }
  l[2] = 0;
  v15 = big_values - region1start;
  l[1] = big_values - region1start;
  v14 = 0;
  if ( region1start >= 0 )
  {
LABEL_4:
    if ( v15 >= 0 )
      goto LABEL_5;
    goto LABEL_82;
  }
LABEL_81:
  l[0] = 0;
  if ( v15 >= 0 )
  {
LABEL_5:
    if ( v14 >= 0 )
      goto LABEL_6;
    goto LABEL_83;
  }
LABEL_82:
  l[1] = 0;
  if ( v14 >= 0 )
  {
LABEL_6:
    v16 = gr_info;
    if ( gr_info->block_type != 2 )
    {
LABEL_7:
      v17 = (float *)xr;
      v191 = 0;
      v18 = 0.0;
      step = 0;
      cb = -1;
      v19 = dword_2AF7400;
      if ( gr_info->preflag )
        v19 = dword_286CB80;
      v20 = 0;
      lwin = v19;
      sfreqa = sfreq;
      v21 = FMOD::CodecMPEG::gMap[sfreq][2];
      while ( 1 )
      {
        v22 = l[v191];
        v23 = &stru_286CC00[gr_info->table_select[v191]];
        if ( !v22 )
        {
LABEL_32:
          if ( ++v191 != 3 )
            continue;
LABEL_33:
          v50 = v21;
          if ( v8 <= 0 || !l3 )
            goto LABEL_54;
          v51 = scf;
          table = stru_286CBE0[gr_info->count1table_select].table;
LABEL_36:
          v52 = *table;
          v53 = table + 1;
          if ( (v52 & 0x8000u) != 0LL )
          {
            while ( v8 )
            {
              mContext = this->mContext;
              mWordPointer = mContext->mBSI.mWordPointer;
              mBitIndex = mContext->mBSI.mBitIndex;
              v57 = *mWordPointer << mBitIndex;
              mContext->mBSI.mBitIndex = (mBitIndex + 1) & 7;
              mContext->mBSI.mWordPointer = &mWordPointer[(mBitIndex + 1) >> 3];
              v58 = v53;
              if ( (v57 & 0x80) != 0 )
                v58 = &v53[-v52];
              v52 = *v58;
              --v8;
              v53 = v58 + 1;
              if ( (v52 & 0x8000u) == 0LL )
                goto LABEL_41;
            }
            LODWORD(v52) = 0;
          }
LABEL_41:
          v59 = v12 + 1;
          v60 = v17 + 1;
          v61 = 0;
          while ( 1 )
          {
            v12 = v59 - 1;
            v17 = v60 - 1;
            if ( (v61 & 1) == 0 )
            {
              if ( !v20 )
              {
                v62 = v50[1];
                v50 += 2;
                v63 = *v51;
                v20 = *(v50 - 2);
                ++v51;
                step = v62;
                v18 = gr_info->pow2gain[(*lwin++ + v63) << shift];
              }
              --v20;
            }
            if ( ((unsigned int)v52 & (8 >> v61)) != 0 )
            {
              v64 = v8 - 1;
              if ( v8 - 1 <= 0 )
              {
                cb = step;
LABEL_52:
                --l3;
                if ( v8 <= 0 || !l3 )
                {
LABEL_54:
                  for ( i = (int)((*xr)[64] - v12) >> 1; i; *(v12 - 1) = *(v17 - 1) )
                  {
                    v71 = *v17;
                    v17 += 2;
                    v12 += 2;
                    *(v12 - 2) = v71;
                    --i;
                  }
                  v72 = (unsigned int)(cb + 1);
                  gr_info->maxbandl = v72;
                  gr_info->maxb = FMOD::CodecMPEG::gLongLimit[0][v72 + 24 * sfreqa - sfreqa];
                  goto LABEL_57;
                }
                goto LABEL_36;
              }
              v65 = this->mContext;
              v66 = v65->mBSI.mWordPointer;
              v67 = v65->mBSI.mBitIndex;
              v68 = *v66 << v67;
              v65->mBSI.mBitIndex = (v67 + 1) & 7;
              v17 = v60;
              v65->mBSI.mWordPointer = &v66[(v67 + 1) >> 3];
              v12 = v59;
              if ( (v68 & 0x80) != 0 )
              {
                *(v59 - 1) = *(v60 - 1) + v18;
                v69 = *(v60 - 1) - v18;
              }
              else
              {
                *(v59 - 1) = *(v60 - 1) - v18;
                v69 = *(v60 - 1) + v18;
              }
              *(v60 - 1) = v69;
              cb = step;
              v8 = v64;
            }
            else
            {
              v12 = v59;
              v17 = v60;
              *(v59 - 1) = *(v60 - 1);
            }
            ++v61;
            ++v59;
            ++v60;
            if ( v61 == 4 )
              goto LABEL_52;
          }
        }
        v24 = v12 + 2;
        v25 = v12 + 1;
        v177 = (__int64)&v12[2 * (v22 - 1) + 4];
        while ( 1 )
        {
          v12 = v24 - 2;
          if ( v20 )
            goto LABEL_15;
          v26 = v21 + 2;
          v20 = *v21;
          step = v21[1];
          v27 = (*lwin + *scf) << shift;
          if ( v27 > 377 )
            break;
          ++lwin;
          ++scf;
          v18 = gr_info->pow2gain[v27];
          v21 = v26;
LABEL_15:
          v28 = v23->table;
          v29 = *v28;
          v30 = v28 + 1;
          v31 = (__int16)v29;
          if ( (v29 & 0x8000u) != 0LL )
          {
            while ( 1 )
            {
              v32 = this->mContext;
              v33 = v32->mBSI.mWordPointer;
              v34 = v32->mBSI.mBitIndex;
              v35 = *v33 << v34;
              v32->mBSI.mBitIndex = (v34 + 1) & 7;
              v32->mBSI.mWordPointer = &v33[(v34 + 1) >> 3];
              if ( (v35 & 0x80) != 0 )
                v30 -= v29;
              v29 = *v30;
              --v8;
              v31 = (__int16)v29;
              if ( (v29 & 0x8000u) == 0LL )
                break;
              ++v30;
            }
          }
          v36 = v31 >> 4;
          v37 = v29 & 0xF;
          if ( v36 == 15 )
          {
            ma = v21;
            ya = v37;
            cbc = v23;
            v8 += ~v23->linbits;
            v81 = FMOD::CodecMPEG::getBits(this, v23->linbits) + 15;
            v82 = this->mContext;
            v23 = cbc;
            v37 = ya;
            v21 = ma;
            v83 = v82->mBSI.mWordPointer;
            v84 = v82->mBSI.mBitIndex;
            v85 = *v83 << v84;
            v82->mBSI.mBitIndex = (v84 + 1) & 7;
            v82->mBSI.mWordPointer = &v83[(v84 + 1) >> 3];
            v86 = FMOD::CodecMPEG::gIsPowTable[v81] * v18;
            v43 = v17 + 1;
            cb = step;
            if ( (v85 & 0x80) != 0 )
            {
              *(v24 - 2) = *v17 + v86;
              *v17 = *v17 - v86;
            }
            else
            {
              *(v24 - 2) = *v17 - v86;
              *v17 = v86 + *v17;
            }
            goto LABEL_26;
          }
          if ( v36 )
          {
            v38 = this->mContext;
            v39 = v38->mBSI.mWordPointer;
            v40 = v38->mBSI.mBitIndex;
            v41 = *v39 << v40;
            v38->mBSI.mBitIndex = (v40 + 1) & 7;
            v38->mBSI.mWordPointer = &v39[(v40 + 1) >> 3];
            v42 = FMOD::CodecMPEG::gIsPowTable[v36] * v18;
            v43 = v17 + 1;
            if ( (v41 & 0x80) != 0 )
            {
              *(v24 - 2) = *v17 + v42;
              *v17 = *v17 - v42;
            }
            else
            {
              *(v24 - 2) = *v17 - v42;
              *v17 = v42 + *v17;
            }
            --v8;
            cb = step;
LABEL_26:
            if ( v37 != 15 )
              goto LABEL_27;
            goto LABEL_65;
          }
          v43 = v17 + 1;
          *(v24 - 2) = *v17;
          if ( v37 != 15 )
          {
LABEL_27:
            if ( v37 )
            {
              v44 = this->mContext;
              v45 = v44->mBSI.mWordPointer;
              v46 = v44->mBSI.mBitIndex;
              v47 = *v45 << v46;
              v44->mBSI.mBitIndex = (v46 + 1) & 7;
              v48 = (v47 & 0x80) == 0;
              v12 = v24;
              v44->mBSI.mWordPointer = &v45[(v46 + 1) >> 3];
              v49 = FMOD::CodecMPEG::gIsPowTable[v37] * v18;
              v17 = v43 + 1;
              if ( v48 )
              {
                *v25 = *v43 - v49;
                *v43 = v49 + *v43;
              }
              else
              {
                *v25 = *v43 + v49;
                *v43 = *v43 - v49;
              }
              --v8;
              cb = step;
            }
            else
            {
              v12 = v24;
              v17 = v43 + 1;
              *v25 = *v43;
            }
            goto LABEL_31;
          }
LABEL_65:
          m = v21;
          v = v43;
          cbb = v23;
          v8 += ~v23->linbits;
          v75 = FMOD::CodecMPEG::getBits(this, v23->linbits) + 15;
          v76 = this->mContext;
          v23 = cbb;
          v21 = m;
          v77 = v76->mBSI.mWordPointer;
          v78 = v76->mBSI.mBitIndex;
          v79 = *v77 << v78;
          v76->mBSI.mBitIndex = (v78 + 1) & 7;
          v48 = (v79 & 0x80) == 0;
          v12 = v24;
          v76->mBSI.mWordPointer = &v77[(v78 + 1) >> 3];
          v80 = FMOD::CodecMPEG::gIsPowTable[v75] * v18;
          v17 = v + 1;
          cb = step;
          if ( v48 )
          {
            *v25 = *v - v80;
            *v = v80 + *v;
          }
          else
          {
            *v25 = *v + v80;
            *v = *v - v80;
          }
LABEL_31:
          --v20;
          v24 += 2;
          v25 += 2;
          if ( v24 == (float *)v177 )
            goto LABEL_32;
        }
        ++v191;
        v21 = v26;
        ++lwin;
        ++scf;
        if ( v191 == 3 )
          goto LABEL_33;
      }
    }
    goto LABEL_84;
  }
LABEL_83:
  v16 = gr_info;
  l[2] = 0;
  if ( gr_info->block_type != 2 )
    goto LABEL_7;
LABEL_84:
  mixed_block_flag = v16->mixed_block_flag;
  max_0[3] = -1;
  if ( mixed_block_flag )
  {
    max_0[2] = 2;
    max_0[1] = 2;
    sfreqb = sfreq;
    max_0[0] = 2;
    v144 = sfreq;
    v89 = FMOD::CodecMPEG::gMapEnd[v144][0];
    v90 = FMOD::CodecMPEG::gMap[v144][0];
  }
  else
  {
    max_0[2] = -1;
    max_0[1] = -1;
    sfreqb = sfreq;
    max_0[0] = -1;
    v88 = sfreq;
    v89 = FMOD::CodecMPEG::gMapEnd[v88][1];
    v90 = FMOD::CodecMPEG::gMap[v88][1];
  }
  va = v89;
  v91 = (float *)xr;
  v92 = 0.0;
  lwina = 0;
  y = 0;
  v93 = 0;
  cba = 0;
  stepa = 0;
  v94 = v12;
  do
  {
    v179 = l[y];
    v95 = &stru_286CC00[gr_info->table_select[y]];
    if ( v179 )
    {
      while ( 1 )
      {
        if ( v93 )
        {
          v96 = stepa;
        }
        else
        {
          v93 = *v90;
          cba = v90[3];
          v94 = &(*xr)[32][v90[1]];
          v91 = &(*xr)[0][v90[1]];
          lwina = v90[2];
          v90 += 4;
          if ( lwina == 3 )
          {
            v96 = 1;
            stepa = 1;
            pow2gain = gr_info->pow2gain;
          }
          else
          {
            v96 = 3;
            stepa = 3;
            pow2gain = gr_info->full_gain[lwina];
          }
          v92 = pow2gain[*scf++ << shift];
        }
        v97 = v95->table;
        v98 = *v97;
        v99 = v97 + 1;
        v100 = (__int16)v98;
        if ( (v98 & 0x8000u) != 0LL )
        {
          while ( 1 )
          {
            v101 = this->mContext;
            v102 = v101->mBSI.mWordPointer;
            v103 = v101->mBSI.mBitIndex;
            v104 = *v102 << v103;
            v101->mBSI.mBitIndex = (v103 + 1) & 7;
            v101->mBSI.mWordPointer = &v102[(v103 + 1) >> 3];
            if ( (v104 & 0x80) != 0 )
              v99 -= v98;
            v98 = *v99;
            --v8;
            v100 = (__int16)v98;
            if ( (v98 & 0x8000u) == 0LL )
              break;
            ++v99;
          }
        }
        v105 = v100 >> 4;
        v106 = v98 & 0xF;
        if ( v105 == 15 )
          break;
        if ( v105 )
        {
          max_0[lwina] = cba;
          v107 = this->mContext;
          v108 = v107->mBSI.mWordPointer;
          v109 = v107->mBSI.mBitIndex;
          v110 = *v108 << v109;
          v107->mBSI.mBitIndex = (v109 + 1) & 7;
          v111 = FMOD::CodecMPEG::gIsPowTable[v105];
          v107->mBSI.mWordPointer = &v108[(v109 + 1) >> 3];
          v112 = v111 * v92;
          if ( (v110 & 0x80) != 0 )
          {
            *v94 = *v91 + v112;
            *v91 = *v91 - v112;
          }
          else
          {
            *v94 = *v91 - v112;
            *v91 = v112 + *v91;
          }
          --v8;
LABEL_101:
          v113 = &v94[v96];
          v114 = &v91[v96];
          if ( v106 != 15 )
            goto LABEL_102;
          goto LABEL_147;
        }
        v146 = *v91;
        v114 = &v91[v96];
        *v94 = v146;
        v113 = &v94[v96];
        if ( v106 != 15 )
        {
LABEL_102:
          if ( v106 )
          {
            max_0[lwina] = cba;
            v115 = this->mContext;
            v116 = v115->mBSI.mWordPointer;
            v117 = v115->mBSI.mBitIndex;
            v118 = *v116 << v117;
            v115->mBSI.mBitIndex = (v117 + 1) & 7;
            v115->mBSI.mWordPointer = &v116[(v117 + 1) >> 3];
            v119 = FMOD::CodecMPEG::gIsPowTable[v106] * v92;
            if ( (v118 & 0x80) != 0 )
            {
              *v113 = *v114 + v119;
              *v114 = *v114 - v119;
            }
            else
            {
              *v113 = *v114 - v119;
              *v114 = v119 + *v114;
            }
            --v8;
          }
          else
          {
            *v113 = *v114;
          }
          goto LABEL_106;
        }
LABEL_147:
        v194 = v90;
        mb = (int *)v95;
        max_0[lwina] = cba;
        v8 += ~v95->linbits;
        v147 = FMOD::CodecMPEG::getBits(this, v95->linbits) + 15;
        v148 = this->mContext;
        v95 = (FMOD::newhuff *)mb;
        v90 = v194;
        v149 = v148->mBSI.mWordPointer;
        v150 = v148->mBSI.mBitIndex;
        v151 = *v149 << v150;
        v148->mBSI.mBitIndex = (v150 + 1) & 7;
        v148->mBSI.mWordPointer = &v149[(v150 + 1) >> 3];
        v152 = FMOD::CodecMPEG::gIsPowTable[v147] * v92;
        if ( (v151 & 0x80) != 0 )
        {
          *v113 = *v114 + v152;
          *v114 = *v114 - v152;
        }
        else
        {
          *v113 = *v114 - v152;
          *v114 = v152 + *v114;
        }
LABEL_106:
        v94 = &v113[v96];
        v91 = &v114[v96];
        --v93;
        if ( !--v179 )
          goto LABEL_107;
      }
      v196 = v90;
      v195 = v106;
      mc = (int *)v95;
      max_0[lwina] = cba;
      v8 += ~v95->linbits;
      v153 = FMOD::CodecMPEG::getBits(this, v95->linbits) + 15;
      v154 = this->mContext;
      v95 = (FMOD::newhuff *)mc;
      v106 = v195;
      v90 = v196;
      v155 = v154->mBSI.mWordPointer;
      v156 = v154->mBSI.mBitIndex;
      v157 = *v155 << v156;
      v154->mBSI.mBitIndex = (v156 + 1) & 7;
      v154->mBSI.mWordPointer = &v155[(v156 + 1) >> 3];
      v158 = FMOD::CodecMPEG::gIsPowTable[v153] * v92;
      if ( (v157 & 0x80) != 0 )
      {
        *v94 = *v91 + v158;
        *v91 = *v91 - v158;
      }
      else
      {
        *v94 = *v91 - v158;
        *v91 = v158 + *v91;
      }
      goto LABEL_101;
    }
LABEL_107:
    ++y;
  }
  while ( y != 2 );
  v120 = v94;
  v121 = lwina;
  if ( v8 > 0 && l3 )
  {
    lwinb = stru_286CBE0[gr_info->count1table_select].table;
    do
    {
      v122 = lwinb;
      while ( 1 )
      {
        v128 = *v122;
        v127 = v122 + 1;
        if ( (v128 & 0x8000u) == 0LL )
          break;
        if ( !v8 )
        {
          LODWORD(v128) = 0;
          break;
        }
        v123 = this->mContext;
        v124 = v123->mBSI.mWordPointer;
        v125 = v123->mBSI.mBitIndex;
        v126 = *v124 << v125;
        v123->mBSI.mBitIndex = (v125 + 1) & 7;
        v123->mBSI.mWordPointer = &v124[(v125 + 1) >> 3];
        if ( (v126 & 0x80) != 0 )
          v127 -= v128;
        v122 = v127;
        --v8;
      }
      v129 = 0;
      do
      {
        if ( (v129 & 1) == 0 )
        {
          if ( !v93 )
          {
            v121 = v90[2];
            v93 = *v90;
            v91 = &(*xr)[0][v90[1]];
            v120 = &(*xr)[32][v90[1]];
            cba = v90[3];
            v90 += 4;
            if ( v121 == 3 )
            {
              stepa = 1;
              v130 = gr_info->pow2gain;
            }
            else
            {
              stepa = 3;
              v130 = gr_info->full_gain[v121];
            }
            v92 = v130[*scf++ << shift];
          }
          --v93;
        }
        if ( ((unsigned int)v128 & (8 >> v129)) != 0 )
        {
          max_0[v121] = cba;
          if ( v8 - 1 < 0 )
            break;
          v131 = this->mContext;
          v132 = v131->mBSI.mWordPointer;
          v133 = v131->mBSI.mBitIndex;
          v134 = *v132 << v133;
          v131->mBSI.mBitIndex = (v133 + 1) & 7;
          v131->mBSI.mWordPointer = &v132[(v133 + 1) >> 3];
          --v8;
          if ( (v134 & 0x80) != 0 )
          {
            *v120 = *v91 + v92;
            v135 = *v91 - v92;
          }
          else
          {
            *v120 = *v91 - v92;
            v135 = *v91 + v92;
          }
          *v91 = v135;
        }
        else
        {
          *v120 = *v91;
        }
        ++v129;
        v136 = 4LL * stepa;
        v120 = (float *)((char *)v120 + v136);
        v91 = (float *)((char *)v91 + v136);
      }
      while ( v129 != 4 );
      --l3;
    }
    while ( v8 > 0 && l3 );
  }
  if ( va > v90 )
  {
    v137 = stepa;
    do
    {
      if ( v93 )
      {
        v138 = 4LL * v137;
      }
      else
      {
        v93 = *v90;
        v120 = &(*xr)[32][v90[1]];
        v91 = &(*xr)[0][v90[1]];
        v143 = v90[2] != 3;
        v90 += 4;
        v138 = 8LL * v143 + 4;
        v137 = 2 * v143 + 1;
      }
      v139 = *v91;
      v140 = (int *)((char *)v91 + v138);
      --v93;
      *v120 = v139;
      v141 = (_DWORD *)((char *)v120 + v138);
      v142 = *v140;
      v91 = (float *)((char *)v140 + v138);
      *v141 = v142;
      v120 = (float *)((char *)v141 + v138);
    }
    while ( va > v90 );
  }
  v159 = max_0[0];
  v160 = max_0[1];
  v161 = max_0[2];
  v162 = max_0[3] + 1;
  v163 = max_0[1] < max_0[0];
  gr_info->maxband[0] = max_0[0] + 1;
  if ( !v163 )
    v159 = v160;
  gr_info->maxbandl = v162;
  gr_info->maxband[1] = v160 + 1;
  v164 = v161 + 1;
  gr_info->maxband[2] = v161 + 1;
  if ( v159 > v161 )
    v164 = v159 + 1;
  if ( v164 )
    v165 = FMOD::CodecMPEG::gShortLimit[sfreqb][v164];
  else
    v165 = FMOD::CodecMPEG::gLongLimit[0][v162 + 24 * sfreqb - sfreqb];
  gr_info->maxb = v165;
LABEL_57:
  if ( v8 > 16 )
  {
    for ( j = v8; j > 16; j -= 16 )
      FMOD::CodecMPEG::getBits(this, 16);
    v8 = v8 - ((v8 - 17) & 0xFFFFFFF0) - 16;
  }
  if ( v8 <= 0 )
    return v8 != 0 ? 0xD : 0;
  FMOD::CodecMPEG::getBits(this, v8);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2226440 | Name: _ZN4FMOD9CodecMPEG12III_i_stereoEPA32_A18_fPiPNS_9gr_info_sEiii
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::III_i_stereo(
        FMOD::CodecMPEG *const this,
        float (*xr_buf)[32][18],
        int *scalefac,
        FMOD::gr_info_s *gr_info,
        int sfreq,
        int ms_stereo,
        int lsf)
{
  FMOD::bandInfoStruct *v7; // r10
  __int64 v10; // rdx
  const float *v11; // rcx
  const float *v12; // rdx
  int v13; // r15d
  __int64 v14; // r12
  int v15; // r9d
  int v16; // r11d
  int v17; // ebx
  __int64 v18; // r8
  float v19; // xmm2_4
  int *v20; // rax
  float v21; // xmm3_4
  int v22; // edi
  int v23; // esi
  int v24; // eax
  int v25; // r8d
  __int64 v26; // rdi
  float *v27; // rdi
  float v28; // xmm1_4
  __int64 v29; // rdi
  float v30; // xmm2_4
  float v31; // xmm3_4
  int v32; // eax
  __int64 v33; // rdi
  float *v34; // rdi
  float v35; // xmm1_4
  signed int maxbandl; // r9d
  int v37; // r11d
  int *v38; // rbx
  int v39; // ebp
  __int64 v40; // rax
  float v41; // xmm2_4
  float v42; // xmm3_4
  int v43; // eax
  __int64 v44; // rdi
  float *v45; // rdi
  float v46; // xmm1_4
  signed int v48; // r11d
  int v49; // r9d
  int *v50; // r12
  int v51; // ebx
  __int64 v52; // rax
  float v53; // xmm2_4
  float v54; // xmm3_4
  int v55; // eax
  __int64 v56; // rdi
  float *v57; // rdi
  float v58; // xmm1_4
  __int64 v59; // rax
  float v60; // xmm3_4
  int v61; // edx
  float v62; // xmm2_4
  int v63; // edx
  __int64 v64; // rax
  float *v65; // rax
  float v66; // xmm1_4
  float *v67; // [rsp+0h] [rbp-48h]
  _BOOL4 do_l; // [rsp+Ch] [rbp-3Ch]
  int v69; // [rsp+10h] [rbp-38h]
  unsigned int mixed_block_flag; // [rsp+14h] [rbp-34h]

  v7 = &FMOD::CodecMPEG::gBandInfo[sfreq];
  if ( !lsf )
  {
    v12 = flt_596A20;
    v11 = flt_596AA0;
    if ( !ms_stereo )
    {
      v12 = flt_596A60;
      v11 = flt_596AE0;
    }
LABEL_32:
    if ( gr_info->block_type == 2 )
      goto LABEL_4;
    goto LABEL_33;
  }
  v10 = (__int64)(gr_info->scalefac_compress & 1) << 6;
  if ( !ms_stereo )
  {
    v11 = (float *)((char *)FMOD::CodecMPEG::gPow1_1[0] + v10);
    v12 = (float *)((char *)FMOD::CodecMPEG::gPow2_1[0] + v10);
    goto LABEL_32;
  }
  v11 = (float *)((char *)FMOD::CodecMPEG::gPow1_2[0] + v10);
  v12 = (float *)((char *)FMOD::CodecMPEG::gPow2_2[0] + v10);
  if ( gr_info->block_type == 2 )
  {
LABEL_4:
    v13 = v7->shortDiff[12];
    mixed_block_flag = gr_info->mixed_block_flag;
    do_l = mixed_block_flag != 0;
    v14 = 0;
    v69 = v7->shortIdx[12];
    v15 = v69 + 3 * v13;
    do
    {
      v16 = gr_info->maxband[v14];
      if ( v16 <= 3 || (do_l = 0, v16 <= 11) )
      {
        v67 = (float *)xr_buf;
        v17 = v14 + 3 * v16 - mixed_block_flag;
        do
        {
          v18 = scalefac[v17];
          if ( (_DWORD)v18 != 7 )
          {
            v19 = v11[v18];
            v20 = &v7->longIdx[v16];
            v21 = v12[v18];
            v22 = v20[59];
            v23 = v14 + v20[45];
            v24 = v23;
            if ( v22 > 0 )
            {
              v25 = v23 + 3 * v22;
              do
              {
                v26 = v24;
                v24 += 3;
                v27 = &v67[v26];
                v28 = *v27;
                v27[576] = *v27 * v21;
                *v27 = v28 * v19;
              }
              while ( v24 != v25 );
            }
          }
          ++v16;
          v17 += 3;
        }
        while ( v16 != 12 );
        xr_buf = (float (*)[32][18])v67;
      }
      v29 = scalefac[33 - mixed_block_flag + (unsigned int)v14];
      if ( (_DWORD)v29 != 7 )
      {
        v30 = v11[v29];
        v31 = v12[v29];
        if ( v13 > 0 )
        {
          v32 = v69 + v14;
          do
          {
            v33 = v32;
            v32 += 3;
            v34 = &(*xr_buf)[0][v33];
            v35 = *v34;
            v34[576] = *v34 * v31;
            *v34 = v35 * v30;
          }
          while ( v32 != v15 );
        }
      }
      ++v14;
      ++v15;
    }
    while ( v14 != 3 );
    if ( do_l )
    {
      maxbandl = gr_info->maxbandl;
      v37 = v7->longIdx[maxbandl];
      if ( maxbandl <= 7 )
      {
        v38 = &scalefac[maxbandl];
        v39 = v7->longDiff[maxbandl];
        v40 = *v38;
        if ( (_DWORD)v40 == 7 )
          goto LABEL_28;
        while ( 1 )
        {
          v41 = v11[v40];
          v42 = v12[v40];
          if ( v39 > 0 )
          {
            v43 = v37;
            do
            {
              v44 = v43++;
              v45 = &(*xr_buf)[0][v44];
              v46 = *v45;
              v45[576] = *v45 * v42;
              *v45 = v46 * v41;
            }
            while ( v43 != v39 + v37 );
            v37 += v39;
          }
          ++maxbandl;
          ++v38;
          if ( maxbandl == 8 )
            break;
          while ( 1 )
          {
            v39 = v7->longDiff[maxbandl];
            v40 = *v38;
            if ( (_DWORD)v40 != 7 )
              break;
LABEL_28:
            ++maxbandl;
            v37 += v39;
            ++v38;
            if ( maxbandl == 8 )
              return FMOD_RESULT::FMOD_OK_0;
          }
        }
      }
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
LABEL_33:
  v48 = gr_info->maxbandl;
  v49 = v7->longIdx[v48];
  if ( v48 <= 20 )
  {
    v50 = &scalefac[v48];
    v51 = v7->longDiff[v48];
    v52 = *v50;
    if ( (_DWORD)v52 == 7 )
      goto LABEL_41;
    while ( 1 )
    {
      v53 = v11[v52];
      v54 = v12[v52];
      if ( v51 > 0 )
      {
        v55 = v49;
        do
        {
          v56 = v55++;
          v57 = &(*xr_buf)[0][v56];
          v58 = *v57;
          v57[576] = *v57 * v54;
          *v57 = v58 * v53;
        }
        while ( v55 != v51 + v49 );
        v49 += v51;
      }
      ++v48;
      ++v50;
      if ( v48 == 21 )
        break;
      while ( 1 )
      {
        v51 = v7->longDiff[v48];
        v52 = *v50;
        if ( (_DWORD)v52 != 7 )
          break;
LABEL_41:
        ++v48;
        v49 += v51;
        ++v50;
        if ( v48 == 21 )
          goto LABEL_42;
      }
    }
  }
LABEL_42:
  if ( v49 > 575 )
    return FMOD_RESULT::FMOD_OK_0;
  v59 = scalefac[20];
  if ( (_DWORD)v59 == 7 )
    return FMOD_RESULT::FMOD_OK_0;
  v60 = v12[v59];
  v61 = v7->longDiff[21];
  v62 = v11[v59];
  if ( v61 <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  v63 = v49 + v61;
  do
  {
    v64 = v49++;
    v65 = &(*xr_buf)[0][v64];
    v66 = *v65;
    v65[576] = *v65 * v60;
    *v65 = v66 * v62;
  }
  while ( v49 != v63 );
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2226810 | Name: _ZN4FMOD9CodecMPEG13III_antialiasEPA18_fPNS_9gr_info_sE
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::III_antialias(
        FMOD::CodecMPEG *const this,
        float (*xr)[18],
        FMOD::gr_info_s *gr_info)
{
  FMOD_RESULT_0 result; // eax
  signed int v4; // r9d
  float *v5; // rsi
  float *v6; // rdi
  float *v7; // rcx
  float *v8; // rdx
  float *v9; // rax
  float v10; // xmm0_4
  float v11; // xmm1_4
  float v12; // xmm2_4

  if ( gr_info->block_type == 2 )
  {
    result = FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    if ( gr_info->mixed_block_flag )
    {
      v5 = &(*xr)[18];
      v4 = 1;
      goto LABEL_4;
    }
  }
  else
  {
    result = FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    v4 = gr_info->maxb - 1;
    if ( v4 >= 0 )
    {
      v5 = &(*xr)[18];
      if ( gr_info->maxb == 1 )
        return FMOD_RESULT::FMOD_OK_0;
      do
      {
LABEL_4:
        v6 = v5;
        v7 = v5;
        v8 = FMOD::CodecMPEG::gAaCa;
        v9 = FMOD::CodecMPEG::gAaCs;
        do
        {
          --v6;
          v10 = *v7;
          v11 = *v9;
          ++v8;
          ++v9;
          v12 = *v6;
          ++v7;
          *v6 = (float)(v11 * *v6) - (float)(*(v8 - 1) * v10);
          *(v7 - 1) = (float)(v10 * *(v9 - 1)) + (float)(v12 * *(v8 - 1));
        }
        while ( v9 != FMOD::CodecMPEG::gAaCa );
        v5 += 18;
        --v4;
      }
      while ( v4 );
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x22268e0 | Name: _ZN4FMOD9CodecMPEG5dct36EPfS1_S1_S1_S1_
void __fastcall FMOD::CodecMPEG::dct36(float *inbuf, float *o1, float *o2, float *wintab, float *tsbuf)
{
  float v5; // xmm9_4
  float v6; // xmm12_4
  float v7; // xmm0_4
  float v8; // xmm11_4
  float v9; // xmm6_4
  float v10; // xmm14_4
  float v11; // xmm3_4
  float v12; // xmm9_4
  float v13; // xmm7_4
  float v14; // xmm14_4
  float v15; // xmm15_4
  float v16; // xmm12_4
  float v17; // xmm2_4
  float v18; // xmm7_4
  float v19; // xmm13_4
  float v20; // xmm0_4
  float v21; // xmm1_4
  float v22; // xmm15_4
  float v23; // xmm11_4
  float v24; // xmm5_4
  float v25; // xmm2_4
  float v26; // xmm10_4
  float v27; // xmm6_4
  float v28; // xmm4_4
  float v29; // xmm13_4
  float v30; // xmm3_4
  float v31; // xmm8_4
  float v32; // xmm1_4
  float v33; // xmm5_4
  float v34; // xmm4_4
  float v35; // xmm15_4
  float v36; // xmm3_4
  float v37; // xmm10_4
  float v38; // xmm3_4
  float v39; // xmm10_4
  float v40; // xmm7_4
  float v41; // xmm2_4
  float v42; // xmm13_4
  float v43; // xmm1_4
  float v44; // xmm4_4
  float v45; // xmm14_4
  float v46; // xmm4_4
  float v47; // xmm7_4
  float v48; // xmm0_4
  float v49; // xmm13_4
  float v50; // xmm7_4
  float v51; // xmm7_4
  float v52; // xmm6_4
  float v53; // xmm9_4
  float v54; // xmm15_4
  float v55; // xmm5_4
  float v56; // xmm10_4
  float v57; // xmm9_4
  float v58; // xmm13_4
  float v59; // xmm6_4
  float v60; // xmm7_4
  float v61; // xmm10_4
  float v62; // xmm7_4
  float v63; // xmm11_4
  float v64; // xmm8_4
  float v65; // xmm7_4
  float v66; // xmm8_4
  float v67; // xmm15_4
  float v68; // xmm6_4
  float v69; // xmm8_4
  float v70; // xmm12_4
  float v71; // xmm10_4
  float v72; // xmm6_4
  float v73; // xmm7_4
  float v74; // xmm5_4
  float v75; // xmm4_4
  float v76; // xmm3_4
  float v77; // xmm7_4
  float v78; // xmm2_4
  float v79; // xmm4_4
  float v80; // xmm1_4
  float v81; // xmm3_4
  float v82; // xmm5_4
  float v83; // xmm1_4
  float v84; // xmm4_4
  float v85; // xmm9_4
  float v86; // xmm6_4
  float v87; // xmm14_4
  float v88; // xmm2_4
  float v89; // xmm8_4
  float v90; // xmm4_4
  float v91; // xmm2_4
  float v92; // xmm4_4
  float v93; // xmm8_4
  float v94; // xmm11_4
  float v95; // xmm9_4
  float v96; // xmm6_4
  float v97; // xmm1_4
  float v98; // xmm0_4
  float v99; // xmm6_4
  float v100; // xmm14_4
  float v101; // xmm7_4
  float v102; // xmm5_4
  float v103; // xmm0_4
  float v104; // xmm4_4
  float v105; // xmm12_4
  float v106; // xmm4_4
  float v107; // xmm0_4
  float v108; // xmm10_4
  float v109; // xmm0_4
  float v110; // xmm0_4
  float v111; // xmm15_4
  float v112; // xmm0_4
  float v113; // [rsp+0h] [rbp-44h]
  float v114; // [rsp+0h] [rbp-44h]
  float v115; // [rsp+4h] [rbp-40h]
  float v116; // [rsp+8h] [rbp-3Ch]
  float v117; // [rsp+8h] [rbp-3Ch]
  float v118; // [rsp+Ch] [rbp-38h]
  float v119; // [rsp+Ch] [rbp-38h]
  float v120; // [rsp+18h] [rbp-2Ch]
  float v121; // [rsp+20h] [rbp-24h]
  float v122; // [rsp+24h] [rbp-20h]
  float v123; // [rsp+28h] [rbp-1Ch]
  float t5; // [rsp+2Ch] [rbp-18h]
  float t5a; // [rsp+2Ch] [rbp-18h]
  float tmp_4; // [rsp+30h] [rbp-14h]
  float tmp_0; // [rsp+34h] [rbp-10h]
  float v128; // [rsp+38h] [rbp-Ch]
  float v129; // [rsp+3Ch] [rbp-8h]
  float v130; // [rsp+40h] [rbp-4h]

  v5 = inbuf[16];
  v6 = inbuf[14];
  v7 = inbuf[12];
  v8 = inbuf[10];
  v9 = inbuf[8];
  v113 = inbuf[17] + v5;
  v10 = inbuf[15];
  v11 = inbuf[6];
  v12 = v5 + v10;
  v13 = inbuf[13];
  v14 = v10 + v6;
  v15 = inbuf[11];
  v16 = v6 + v13;
  v17 = inbuf[9];
  v18 = v13 + v7;
  v19 = inbuf[7];
  v20 = v7 + v15;
  v21 = inbuf[5];
  v22 = v15 + v8;
  v23 = v8 + v17;
  v24 = inbuf[4];
  v25 = v17 + v9;
  v26 = inbuf[2];
  v27 = v9 + v19;
  v28 = inbuf[3];
  v29 = v19 + v11;
  v116 = v22;
  v30 = v11 + v21;
  v31 = *inbuf;
  v32 = v21 + v24;
  inbuf[16] = v12;
  v33 = v24 + v28;
  inbuf[14] = v16;
  v34 = v28 + v26;
  inbuf[12] = v20;
  inbuf[6] = v30;
  v35 = v30;
  v36 = inbuf[1];
  v37 = v26 + v36;
  inbuf[10] = v23;
  v38 = v36 + v31;
  inbuf[8] = v27;
  inbuf[4] = v33;
  inbuf[2] = v37;
  v118 = v37;
  inbuf[1] = v38;
  inbuf[17] = v113 + v14;
  v114 = v113 + v14;
  v115 = v14 + v18;
  v39 = v18 + v116;
  inbuf[15] = v14 + v18;
  v40 = v116 + v25;
  v41 = v25 + v29;
  v42 = v29 + v32;
  v43 = v32 + v34;
  inbuf[13] = v39;
  v44 = v34 + v38;
  v45 = v40;
  inbuf[11] = v40;
  inbuf[7] = v42;
  v123 = v42;
  inbuf[3] = v44;
  v117 = v44;
  v46 = FMOD::CodecMPEG::gCos6_2;
  v47 = v20 * FMOD::CodecMPEG::gCos6_2;
  v122 = v39;
  inbuf[9] = v41;
  inbuf[5] = v43;
  v48 = (float)((float)(v12 + v27) - v33) * v46;
  v49 = v31 + v47;
  v50 = (float)(v31 - v47) - v47;
  t5 = v50 - v48;
  tmp_4 = v48 + (float)(v50 + v48);
  v120 = FMOD::CodecMPEG::gCos9[2];
  v51 = (float)(v27 + v33) * FMOD::CodecMPEG::gCos9[0];
  v52 = (float)(v27 - v12) * FMOD::CodecMPEG::gCos9[1];
  v53 = (float)(v12 + v33) * v120;
  v54 = v35 * FMOD::CodecMPEG::gCos6_1;
  v55 = (float)(v49 - v51) - v53;
  v56 = (float)(v49 + v52) + v51;
  v57 = (float)(v53 - v52) + v49;
  v58 = (float)(v118 + v23) * FMOD::CodecMPEG::gCos18[0];
  v121 = FMOD::CodecMPEG::gCos18[1];
  v59 = (float)(v23 - v16) * v121;
  v60 = (float)(v58 + v59) + v54;
  v128 = v56 - v60;
  tmp_0 = v56 + v60;
  v61 = v118;
  v62 = v16 + v118;
  v119 = FMOD::CodecMPEG::gCos18[2];
  v63 = (float)((float)(v23 + v16) - v61) * FMOD::CodecMPEG::gCos6_1;
  v64 = v62 * v119;
  v65 = (float)(v62 * v119) + v54;
  v66 = v64 - v54;
  v67 = t5 + v63;
  v68 = v59 - v65;
  v69 = v66 + v58;
  t5a = t5 - v63;
  v70 = v55 + v68;
  v71 = v55 - v68;
  v129 = v57 + v69;
  v130 = v57 - v69;
  v72 = v38 + (float)(v122 * v46);
  v73 = (float)(v38 - (float)(v122 * v46)) - (float)(v122 * v46);
  v74 = (float)((float)(v114 + v41) - v43) * v46;
  v75 = v41 + v43;
  v76 = v73 + v74;
  v77 = v73 - v74;
  v78 = (float)(v41 - v114) * FMOD::CodecMPEG::gCos9[1];
  v79 = v75 * FMOD::CodecMPEG::gCos9[0];
  v80 = (float)(v43 + v114) * v120;
  v81 = (float)(v76 + v74) * FMOD::CodecMPEG::gTfCos36[4];
  v82 = (float)(v72 - v79) - v80;
  v83 = (float)(v80 - v78) + v72;
  v84 = (float)(v72 + v78) + v79;
  v85 = v121 * (float)(v45 - v115);
  v86 = (float)(v117 + v45) * FMOD::CodecMPEG::gCos18[0];
  v87 = (float)((float)(v45 + v115) - v117) * FMOD::CodecMPEG::gCos6_1;
  v88 = (float)(v86 + v85) + (float)(v123 * FMOD::CodecMPEG::gCos6_1);
  v89 = v84 - v88;
  v90 = v84 + v88;
  v91 = FMOD::CodecMPEG::gTfCos36[8] * v89;
  v92 = v90 * FMOD::CodecMPEG::gTfCos36[0];
  v93 = (float)(v117 + v115) * v119;
  v94 = (float)(v93 - (float)(v123 * FMOD::CodecMPEG::gCos6_1)) + v86;
  v95 = v85 - (float)((float)(v123 * FMOD::CodecMPEG::gCos6_1) + v93);
  v96 = v83 + v94;
  v97 = (float)(v83 - v94) * FMOD::CodecMPEG::gTfCos36[5];
  v98 = FMOD::CodecMPEG::gTfCos36[1] * (float)(v77 - v87);
  v99 = v96 * FMOD::CodecMPEG::gTfCos36[3];
  v100 = (float)(v87 + v77) * FMOD::CodecMPEG::gTfCos36[7];
  v101 = (float)(v82 + v95) * FMOD::CodecMPEG::gTfCos36[2];
  v102 = (float)(v82 - v95) * FMOD::CodecMPEG::gTfCos36[6];
  o2[9] = wintab[27] * (float)(tmp_0 + v92);
  o2[8] = (float)(tmp_0 + v92) * wintab[26];
  tsbuf[256] = (float)(wintab[8] * (float)(tmp_0 - v92)) + o1[8];
  tsbuf[288] = (float)((float)(tmp_0 - v92) * wintab[9]) + o1[9];
  o2[10] = wintab[28] * (float)(t5a + v98);
  o2[7] = (float)(t5a + v98) * wintab[25];
  v103 = t5a - v98;
  tsbuf[224] = (float)(v103 * wintab[7]) + o1[7];
  v104 = v70;
  v105 = v70 - v101;
  v106 = v104 + v101;
  tsbuf[320] = (float)(v103 * wintab[10]) + o1[10];
  o2[11] = v106 * wintab[29];
  o2[6] = v106 * wintab[24];
  tsbuf[192] = o1[6] + (float)(wintab[6] * v105);
  tsbuf[352] = (float)(v105 * wintab[11]) + o1[11];
  o2[12] = wintab[30] * (float)(v129 + v99);
  o2[5] = (float)(v129 + v99) * wintab[23];
  tsbuf[160] = (float)(wintab[5] * (float)(v129 - v99)) + o1[5];
  tsbuf[384] = (float)((float)(v129 - v99) * wintab[12]) + o1[12];
  o2[13] = wintab[31] * (float)(tmp_4 + v81);
  o2[4] = (float)(tmp_4 + v81) * wintab[22];
  tsbuf[128] = o1[4] + (float)(wintab[4] * (float)(tmp_4 - v81));
  tsbuf[416] = (float)((float)(tmp_4 - v81) * wintab[13]) + o1[13];
  o2[14] = wintab[32] * (float)(v130 + v97);
  o2[3] = (float)(v130 + v97) * wintab[21];
  tsbuf[96] = (float)(wintab[3] * (float)(v130 - v97)) + o1[3];
  v107 = v71;
  v108 = v71 - v102;
  v109 = v107 + v102;
  tsbuf[448] = (float)((float)(v130 - v97) * wintab[14]) + o1[14];
  o2[15] = wintab[33] * v109;
  o2[2] = v109 * wintab[20];
  tsbuf[64] = (float)(wintab[2] * v108) + o1[2];
  v110 = v67;
  v111 = v67 - v100;
  v112 = v110 + v100;
  tsbuf[480] = (float)(v108 * wintab[15]) + o1[15];
  o2[16] = wintab[34] * v112;
  o2[1] = v112 * wintab[19];
  tsbuf[32] = (float)(wintab[1] * v111) + o1[1];
  tsbuf[512] = (float)(v111 * wintab[16]) + o1[16];
  o2[17] = wintab[35] * (float)(v128 + v91);
  *o2 = (float)(v128 + v91) * wintab[18];
  *tsbuf = (float)(*wintab * (float)(v128 - v91)) + *o1;
  tsbuf[544] = (float)((float)(v128 - v91) * wintab[17]) + o1[17];
}


// Address: 0x22270f0 | Name: _ZN4FMOD9CodecMPEG5dct12EPfS1_S1_S1_S1_
void __fastcall FMOD::CodecMPEG::dct12(float *in, float *rawout1, float *rawout2, float *wi, float *ts)
{
  float v5; // xmm7_4
  float v6; // xmm5_4
  float v7; // xmm4_4
  float v8; // xmm3_4
  float v9; // xmm2_4
  float v10; // xmm0_4
  float v11; // xmm8_4
  float v12; // xmm4_4
  float v13; // xmm6_4
  float v14; // xmm3_4
  float v15; // xmm2_4
  float v16; // xmm6_4
  float v17; // xmm0_4
  float v18; // xmm2_4
  float v19; // xmm9_4
  float v20; // xmm1_4
  float v21; // xmm3_4
  float v22; // xmm10_4
  float v23; // xmm9_4
  float v24; // xmm1_4
  float v25; // xmm4_4
  float v26; // xmm8_4
  float v27; // xmm9_4
  float v28; // xmm4_4
  float v29; // xmm9_4
  float v30; // xmm2_4
  float v31; // xmm0_4
  float v32; // xmm2_4
  float v33; // xmm10_4
  float v34; // xmm3_4
  float v35; // xmm9_4
  float v36; // xmm4_4
  float v37; // xmm9_4
  float v38; // xmm4_4
  float v39; // xmm2_4
  float v40; // xmm3_4
  float v41; // xmm6_4
  float v42; // xmm0_4
  float v43; // xmm4_4
  float v44; // xmm2_4
  float v45; // xmm3_4
  float v46; // xmm6_4
  float v47; // xmm10_4
  float v48; // xmm0_4
  float v49; // xmm3_4
  float v50; // xmm4_4
  float v51; // xmm2_4
  float v52; // xmm5_4
  float v53; // xmm7_4
  float v54; // xmm1_4
  float v55; // xmm0_4
  float v56; // xmm5_4
  float v57; // xmm1_4
  float v58; // xmm0_4
  float v59; // xmm5_4
  float v60; // xmm4_4
  float v61; // xmm3_4
  float v62; // xmm5_4
  float v63; // xmm3_4
  float v64; // xmm1_4
  float v65; // xmm4_4
  float v66; // xmm1_4
  float v67; // xmm0_4
  float v68; // xmm6_4
  float v69; // xmm3_4
  float v70; // xmm2_4
  float v71; // xmm1_4
  float v72; // xmm5_4
  float v73; // xmm0_4
  float v74; // xmm3_4
  float v75; // xmm2_4
  float v76; // xmm1_4
  float v77; // xmm5_4
  float v78; // xmm0_4
  float v79; // xmm1_4
  float v80; // xmm2_4
  float v81; // xmm4_4
  float v82; // xmm7_4
  float v83; // xmm4_4
  float v84; // xmm6_4
  float v85; // xmm3_4
  float v86; // xmm6_4
  float v87; // xmm1_4
  float v88; // xmm0_4
  float v89; // xmm1_4
  float v90; // xmm4_4
  float v91; // xmm6_4
  float v92; // xmm1_4
  float v93; // xmm3_4
  float v94; // xmm1_4
  float v95; // xmm0_4

  *ts = *rawout1;
  ts[32] = rawout1[1];
  v5 = FMOD::CodecMPEG::gTfCos12[1];
  ts[64] = rawout1[2];
  v6 = FMOD::CodecMPEG::gCos6_1;
  ts[96] = rawout1[3];
  ts[128] = rawout1[4];
  ts[160] = rawout1[5];
  v7 = in[12];
  v8 = in[9];
  v9 = in[6];
  v10 = in[15] + v7;
  v11 = *in;
  v12 = v7 + v8;
  v13 = in[3];
  v14 = v8 + v9;
  v15 = v9 + v13;
  v16 = v13 + *in;
  v17 = v10 + v14;
  v18 = v15 * v6;
  v19 = *in - v12;
  v20 = (float)(v16 - v17) * v5;
  v21 = (float)(v14 + v16) * v6;
  v22 = v19 - v20;
  v23 = v19 + v20;
  ts[512] = (float)(wi[10] * v23) + rawout1[16];
  ts[416] = (float)(v23 * wi[7]) + rawout1[13];
  ts[224] = (float)(wi[1] * v22) + rawout1[7];
  ts[320] = (float)(v22 * wi[4]) + rawout1[10];
  v24 = FMOD::CodecMPEG::gCos6_2;
  v25 = (float)(v12 * FMOD::CodecMPEG::gCos6_2) + v11;
  v26 = FMOD::CodecMPEG::gTfCos12[0];
  v27 = v25;
  v28 = v25 - v18;
  v29 = v27 + v18;
  v30 = (float)(v17 * FMOD::CodecMPEG::gCos6_2) + v16;
  v31 = (float)(v30 - v21) * FMOD::CodecMPEG::gTfCos12[2];
  v32 = (float)(v30 + v21) * FMOD::CodecMPEG::gTfCos12[0];
  v33 = v29 + v32;
  v34 = v28 + v31;
  v35 = v29 - v32;
  v36 = v28 - v31;
  ts[544] = (float)(wi[11] * v34) + rawout1[17];
  ts[384] = (float)(v34 * wi[6]) + rawout1[12];
  ts[448] = (float)(wi[8] * v33) + rawout1[14];
  ts[480] = (float)(wi[9] * v33) + rawout1[15];
  ts[192] = (float)(*wi * v36) + rawout1[6];
  ts[352] = (float)(v36 * wi[5]) + rawout1[11];
  ts[256] = (float)(wi[2] * v35) + rawout1[8];
  ts[288] = (float)(wi[3] * v35) + rawout1[9];
  v37 = in[1];
  v38 = in[13];
  v39 = in[10];
  v40 = in[7];
  v41 = in[4];
  v42 = in[16] + v38;
  v43 = v38 + v39;
  v44 = v39 + v40;
  v45 = v40 + v41;
  v46 = v41 + v37;
  v47 = v37 - v43;
  v48 = v42 + v44;
  v49 = v45 * v6;
  v50 = (float)(v43 * v24) + v37;
  v51 = (float)(v44 + v46) * v6;
  v52 = (float)(v46 - v48) * v5;
  v53 = v47 + v52;
  v54 = (float)(v48 * v24) + v46;
  v55 = v54 - v51;
  v56 = v47 - v52;
  v57 = (float)(v54 + v51) * v26;
  rawout2[4] = wi[10] * v53;
  rawout2[1] = v53 * wi[7];
  v58 = v55 * FMOD::CodecMPEG::gTfCos12[2];
  ts[416] = (float)(wi[1] * v56) + ts[416];
  ts[512] = (float)(v56 * wi[4]) + ts[512];
  v59 = v50;
  v60 = v50 - v49;
  v61 = v59 + v49;
  v62 = v61 - v57;
  v63 = v61 + v57;
  v64 = v60;
  v65 = v60 - v58;
  v66 = v64 + v58;
  rawout2[5] = wi[11] * v66;
  *rawout2 = v66 * wi[6];
  rawout2[2] = wi[8] * v63;
  rawout2[3] = v63 * wi[9];
  v67 = ts[480];
  ts[384] = (float)(*wi * v65) + ts[384];
  ts[544] = (float)(v65 * wi[5]) + ts[544];
  ts[448] = (float)(wi[2] * v62) + ts[448];
  ts[480] = v67 + (float)(v62 * wi[3]);
  rawout2[17] = 0.0;
  rawout2[16] = 0.0;
  rawout2[15] = 0.0;
  rawout2[14] = 0.0;
  rawout2[13] = 0.0;
  rawout2[12] = 0.0;
  v68 = in[2];
  v69 = in[14];
  v70 = in[11];
  v71 = in[8];
  v72 = in[5];
  v73 = in[17] + v69;
  v74 = v69 + v70;
  v75 = v70 + v71;
  v76 = v71 + v72;
  v77 = v72 + v68;
  v78 = v73 + v75;
  v79 = v76 * FMOD::CodecMPEG::gCos6_1;
  v80 = (float)(v75 + v77) * FMOD::CodecMPEG::gCos6_1;
  v81 = (float)(v77 - v78) * FMOD::CodecMPEG::gTfCos12[1];
  v82 = (float)(v68 - v74) + v81;
  v83 = (float)(v68 - v74) - v81;
  rawout2[10] = wi[10] * v82;
  rawout2[7] = v82 * wi[7];
  rawout2[1] = (float)(wi[1] * v83) + rawout2[1];
  rawout2[4] = (float)(v83 * wi[4]) + rawout2[4];
  v84 = (float)(v74 * FMOD::CodecMPEG::gCos6_2) + v68;
  v85 = v84 - v79;
  v86 = v84 + v79;
  v87 = (float)(v78 * FMOD::CodecMPEG::gCos6_2) + v77;
  v88 = (float)(v87 - v80) * FMOD::CodecMPEG::gTfCos12[2];
  v89 = (float)(v87 + v80) * FMOD::CodecMPEG::gTfCos12[0];
  v90 = v86 + v89;
  v91 = v86 - v89;
  v92 = v85;
  v93 = v85 - v88;
  v94 = v92 + v88;
  rawout2[11] = wi[11] * v94;
  rawout2[6] = v94 * wi[6];
  rawout2[8] = wi[8] * v90;
  rawout2[9] = v90 * wi[9];
  *rawout2 = (float)(*wi * v93) + *rawout2;
  rawout2[5] = (float)(v93 * wi[5]) + rawout2[5];
  v95 = rawout2[3];
  rawout2[2] = (float)(wi[2] * v91) + rawout2[2];
  rawout2[3] = v95 + (float)(v91 * wi[3]);
}


// Address: 0x2227650 | Name: _ZN4FMOD9CodecMPEG10III_hybridEPA18_fPA32_fiPNS_9gr_info_sE
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::III_hybrid(
        FMOD::CodecMPEG *const this,
        float (*fsIn)[18],
        float (*tsOut)[32],
        int ch_0,
        FMOD::gr_info_s *gr_info)
{
  __int64 v6; // rdx
  FMOD::CodecMPEG_Context *mContext; // rsi
  char *v10; // rdi
  int v11; // ecx
  float *v12; // r9
  int v13; // r15d
  float *v14; // rbx
  float *v15; // r10
  float *v16; // rbp
  __int64 block_type; // rdx
  float *v18; // r12
  float *v19; // rdx
  float *v20; // rsi
  float *v21; // rdi
  float *v22; // r8
  float *v23; // rcx
  float *v24; // rdx
  __int64 i; // rax
  float *v27; // r8
  float *v28; // r12
  float *v29; // rdx
  float *v30; // rsi
  float *v31; // rdi
  float *v32; // r8
  float *v33; // [rsp+0h] [rbp-48h]
  float *v34; // [rsp+0h] [rbp-48h]
  float *wintab; // [rsp+8h] [rbp-40h]
  float *wintaba; // [rsp+8h] [rbp-40h]

  v6 = 576LL * ch_0;
  mContext = this->mContext;
  v10 = (char *)mContext + 4 * ch_0;
  v11 = *((_DWORD *)v10 + 4654);
  *((_DWORD *)v10 + 4654) = 1 - v11;
  v12 = &mContext->mSynthBuffsMem[1152 * v11 + 1168 + v6];
  v13 = 0;
  v14 = v12 + 2;
  v15 = &mContext->mSynthBuffsMem[1152 * (1 - v11) + 1168 + v6];
  v16 = v15 + 2;
  if ( gr_info->mixed_block_flag )
  {
    wintaba = &mContext->mSynthBuffsMem[1152 * (1 - v11) + 1168 + v6];
    v34 = &mContext->mSynthBuffsMem[1152 * v11 + 1168 + v6];
    LOBYTE(v13) = 2;
    FMOD::CodecMPEG::dct36((float *)fsIn, v12 + 2, v15 + 2, FMOD::CodecMPEG::gWin[0], (float *)tsOut);
    v27 = &(*tsOut)[1];
    tsOut = (float (*)[32])((char *)tsOut + 8);
    FMOD::CodecMPEG::dct36(&(*fsIn)[18], v34 + 20, wintaba + 20, FMOD::CodecMPEG::gWin1[0], v27);
    block_type = (int)gr_info->block_type;
    v14 = v34 + 38;
    v16 = wintaba + 38;
    if ( (_DWORD)block_type != 2 )
    {
LABEL_3:
      if ( v13 < (signed int)gr_info->maxb )
      {
        v18 = &(*fsIn)[18 * v13];
        wintab = FMOD::CodecMPEG::gWin[block_type];
        v33 = FMOD::CodecMPEG::gWin1[block_type];
        do
        {
          v13 += 2;
          FMOD::CodecMPEG::dct36(v18, v14, v16, wintab, (float *)tsOut);
          v19 = v16 + 18;
          v20 = v14 + 18;
          v21 = v18 + 18;
          v22 = &(*tsOut)[1];
          v14 += 36;
          tsOut = (float (*)[32])((char *)tsOut + 8);
          v16 += 36;
          v18 += 36;
          FMOD::CodecMPEG::dct36(v21, v20, v19, v33, v22);
        }
        while ( (signed int)gr_info->maxb > v13 );
        goto LABEL_6;
      }
      goto LABEL_7;
    }
  }
  else
  {
    block_type = (int)gr_info->block_type;
    if ( (_DWORD)block_type != 2 )
      goto LABEL_3;
  }
  if ( v13 < (signed int)gr_info->maxb )
  {
    v28 = &(*fsIn)[18 * v13];
    do
    {
      v13 += 2;
      FMOD::CodecMPEG::dct12(v28, v14, v16, FMOD::CodecMPEG::gWin[2], (float *)tsOut);
      v29 = v16 + 18;
      v30 = v14 + 18;
      v31 = v28 + 18;
      v32 = &(*tsOut)[1];
      v14 += 36;
      tsOut = (float (*)[32])((char *)tsOut + 8);
      v16 += 36;
      v28 += 36;
      FMOD::CodecMPEG::dct12(v31, v30, v29, FMOD::CodecMPEG::gWin1[2], v32);
    }
    while ( (signed int)gr_info->maxb > v13 );
LABEL_6:
    if ( v13 > 31 )
      return FMOD_RESULT::FMOD_OK_0;
  }
LABEL_7:
  v23 = &v14[18 * (31 - v13) + 18];
  do
  {
    v24 = (float *)tsOut;
    for ( i = 0; i != 18; ++i )
    {
      v24 += 32;
      *(v24 - 32) = v14[i];
      v16[i] = 0.0;
    }
    v14 += 18;
    v16 += 18;
    tsOut = (float (*)[32])((char *)tsOut + 4);
  }
  while ( v14 != v23 );
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22278f0 | Name: _ZN4FMOD9CodecMPEG12decodeLayer3EPvPj
FMOD_RESULT_0 __fastcall FMOD::CodecMPEG::decodeLayer3(
        FMOD::CodecMPEG *const this,
        void *pcm_sample,
        unsigned int *samples_out)
{
  FMOD::CodecMPEG_Context *mContext; // rdx
  int sampling_frequency; // eax
  int stereo; // ebp
  bool v9; // zf
  FMOD_RESULT_0 result; // eax
  FMOD::CodecMPEG_Context *v11; // rcx
  int mFrameSizeOld; // esi
  FMOD::CodecMPEG_Context *v13; // rax
  unsigned int main_data_begin; // eax
  __int64 mBSNum; // r8
  size_t v16; // rdx
  unsigned __int8 *v17; // rdi
  int v18; // r12d
  FMOD::gr_info_s *v19; // r15
  float *v20; // r13
  FMOD::III_sideinfo::$D7C0C5A2C1B612DA685E5A32903E50B1 *v21; // rbp
  float *v22; // r14
  int v23; // ecx
  float *v24; // r13
  int channels; // r8d
  unsigned int maxb; // edx
  unsigned int v27; // eax
  int v28; // [rsp+14h] [rbp-27E4h]
  FMOD::III_sideinfo::$D7C0C5A2C1B612DA685E5A32903E50B1 *i; // [rsp+18h] [rbp-27E0h]
  void *pcm_samplea; // [rsp+38h] [rbp-27C0h]
  int gr; // [rsp+40h] [rbp-27B8h]
  int sfreq; // [rsp+44h] [rbp-27B4h]
  int granules; // [rsp+50h] [rbp-27A8h]
  int ms_stereo; // [rsp+54h] [rbp-27A4h]
  int i_stereo; // [rsp+60h] [rbp-2798h]
  int part2bits; // [rsp+88h] [rbp-2770h] BYREF
  int part2bits_0; // [rsp+8Ch] [rbp-276Ch] BYREF
  int scalefacs[2][39]; // [rsp+90h] [rbp-2768h] BYREF
  FMOD::III_sideinfo sideinfo; // [rsp+1D0h] [rbp-2628h] BYREF
  float hybridout[2][18][32]; // [rsp+3C0h] [rbp-2438h] BYREF
  float hybridin[2][32][18]; // [rsp+15C0h] [rbp-1238h] BYREF

  mContext = this->mContext;
  i_stereo = 0;
  ms_stereo = 0;
  sampling_frequency = mContext->mFrame.sampling_frequency;
  stereo = mContext->mFrame.stereo;
  *samples_out = 0;
  sfreq = sampling_frequency;
  v9 = mContext->mFrame.mode == 1;
  memset(hybridout, 0, sizeof(hybridout));
  memset(hybridin, 0, sizeof(hybridin));
  memset(&sideinfo, 0, sizeof(sideinfo));
  if ( v9 )
  {
    i_stereo = mContext->mFrame.mode_ext & 1;
    ms_stereo = mContext->mFrame.mode_ext & 2;
  }
  if ( mContext->mFrame.lsf )
  {
    result = FMOD::CodecMPEG::III_get_side_info_2(this, &sideinfo, stereo, ms_stereo, sampling_frequency);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      granules = 1;
      goto LABEL_10;
    }
  }
  else
  {
    result = FMOD::CodecMPEG::III_get_side_info_1(this, &sideinfo, stereo, ms_stereo, sampling_frequency);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      granules = 2;
LABEL_10:
      v11 = this->mContext;
      mFrameSizeOld = v11->mFrameSizeOld;
      v13 = v11;
      if ( mFrameSizeOld < 0 )
      {
        if ( sideinfo.main_data_begin )
          goto LABEL_14;
      }
      else
      {
        main_data_begin = sideinfo.main_data_begin;
        mBSNum = v11->mBSNum;
        v16 = sideinfo.main_data_begin;
        v17 = &v11->mBSI.mWordPointer[-sideinfo.main_data_begin];
        v9 = sideinfo.main_data_begin == 0;
        v11->mBSI.mWordPointer = v17;
        if ( !v9 )
        {
          memcpy_0(v17, &v11->mBSSpace[mBSNum][mFrameSizeOld - main_data_begin + 512], v16);
          v11 = this->mContext;
        }
      }
      v13 = v11;
      v11->mBSI.mBitIndex = 0;
LABEL_14:
      gr = 0;
      for ( i = &sideinfo.ch[1]; ; i = (FMOD::III_sideinfo::$D7C0C5A2C1B612DA685E5A32903E50B1 *)((char *)i + 120) )
      {
        if ( v13->mFrame.lsf )
          FMOD::CodecMPEG::III_get_scale_factors_2(this, scalefacs[0], i[-1].gr, 0, &part2bits);
        else
          FMOD::CodecMPEG::III_get_scale_factors_1(this, scalefacs[0], i[-1].gr, &part2bits);
        result = FMOD::CodecMPEG::III_dequantize_sample(this, hybridin[0], scalefacs[0], i[-1].gr, sfreq, part2bits);
        if ( result )
          return result;
        if ( stereo == 2 )
          break;
        if ( stereo > 0 )
          goto LABEL_20;
LABEL_24:
        v24 = hybridout[0][0];
        do
        {
          channels = this->waveformat->channels;
          if ( channels < 3 )
            channels = stereo;
          FMOD::CodecMPEG::synth(this, pcm_sample, v24, stereo, channels);
          if ( pcm_sample )
            pcm_sample = (char *)pcm_sample + 64 * this->waveformat->channels;
          v24 += 32;
        }
        while ( v24 != (float *)hybridout[1] );
        if ( granules <= ++gr )
        {
          *samples_out = 576 * granules;
          return FMOD_RESULT::FMOD_OK_0;
        }
        v13 = this->mContext;
      }
      if ( this->mContext->mFrame.lsf )
        FMOD::CodecMPEG::III_get_scale_factors_2(this, scalefacs[1], i->gr, i_stereo, &part2bits_0);
      else
        FMOD::CodecMPEG::III_get_scale_factors_1(this, scalefacs[1], i->gr, &part2bits_0);
      if ( ms_stereo )
      {
        FMOD::CodecMPEG::III_dequantize_sample_ms(this, hybridin, scalefacs[1], i->gr, sfreq, part2bits_0);
        if ( !i_stereo )
          goto LABEL_37;
      }
      else
      {
        FMOD::CodecMPEG::III_dequantize_sample(this, hybridin[1], scalefacs[1], i->gr, sfreq, part2bits_0);
        if ( !i_stereo )
          goto LABEL_37;
      }
      FMOD::CodecMPEG::III_i_stereo(this, hybridin, scalefacs[1], i->gr, sfreq, ms_stereo, this->mContext->mFrame.lsf);
LABEL_37:
      if ( ms_stereo | i_stereo )
      {
        maxb = i->gr[0].maxb;
        v27 = i[-1].gr[0].maxb;
        if ( maxb <= v27 )
          i->gr[0].maxb = v27;
        else
          i[-1].gr[0].maxb = maxb;
      }
LABEL_20:
      v18 = 0;
      v28 = stereo;
      pcm_samplea = pcm_sample;
      v19 = i[-1].gr;
      v20 = hybridin[0][0];
      v21 = i;
      v22 = hybridout[0][0];
      while ( 1 )
      {
        FMOD::CodecMPEG::III_antialias(this, (float (*)[18])v20, v19);
        v23 = v18++;
        FMOD::CodecMPEG::III_hybrid(this, (float (*)[18])v20, (float (*)[32])v22, v23, v19);
        v20 += 576;
        v22 += 576;
        if ( v28 <= v18 )
          break;
        v19 = (FMOD::gr_info_s *)v21++;
      }
      stereo = v28;
      pcm_sample = pcm_samplea;
      goto LABEL_24;
    }
  }
  return result;
}


