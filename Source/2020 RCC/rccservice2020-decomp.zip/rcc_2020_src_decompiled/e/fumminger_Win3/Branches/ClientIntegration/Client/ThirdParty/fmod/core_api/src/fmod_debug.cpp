// Address: 0x21a78f0 | Name: FMOD_Debug_Initialize
FMOD_RESULT_0 __fastcall FMOD_Debug_Initialize(
        FMOD_DEBUG_FLAGS flags,
        FMOD_DEBUG_MODE mode,
        FMOD_DEBUG_CALLBACK callback,
        const char *filename)
{
  return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
}


// Address: 0x21a7900 | Name: _Z16FMOD_ReportError11FMOD_RESULT31FMOD_ERRORCALLBACK_INSTANCETYPEPKvPKcS4_
void __fastcall FMOD_ReportError(
        FMOD_RESULT_0 result,
        FMOD_ERRORCALLBACK_INSTANCETYPE instanceType,
        const void *instance,
        const char *functionName,
        const char *functionParams)
{
  FMOD::Global *v5; // rax
  FMOD_SYSTEM_CALLBACK gSystemCallback; // r9
  int gErrorCallbackReentrancy; // edx
  FMOD_RESULT_0 v8; // [rsp+0h] [rbp-28h] BYREF
  FMOD_ERRORCALLBACK_INSTANCETYPE instanceTypea; // [rsp+4h] [rbp-24h]
  const void *instancea; // [rsp+8h] [rbp-20h]
  const char *functionNamea; // [rsp+10h] [rbp-18h]
  const char *functionParamsa; // [rsp+18h] [rbp-10h]

  v5 = off_286F358;
  if ( SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    gSystemCallback = off_286F358->gSystemCallback;
    if ( gSystemCallback )
    {
      instancea = instance;
      gErrorCallbackReentrancy = off_286F358->gErrorCallbackReentrancy;
      v8 = result;
      functionNamea = functionName;
      functionParamsa = functionParams;
      instanceTypea = instanceType;
      if ( !gErrorCallbackReentrancy )
      {
        off_286F358->gErrorCallbackReentrancy = 1;
        gSystemCallback(0, 128, &v8, 0, v5->gSystemUserData);
        --off_286F358->gErrorCallbackReentrancy;
      }
    }
  }
}


