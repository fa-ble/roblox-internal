// Address: 0x226bea0 | Name: FMOD_mapping0_inverse
int __fastcall FMOD_mapping0_inverse(void *context, vorbis_block_0 *vb, vorbis_info_mapping *l)
{
  _DWORD *v4; // rbx
  vorbis_dsp_state *vd; // rax
  int *v6; // r12
  int v7; // ecx
  void *v8; // rsp
  void *v9; // rsp
  void *v10; // rsp
  void *v11; // rsp
  _QWORD *p_zerobundle; // r10
  size_t v13; // r11
  private_state_1 *v15; // rbx
  __int64 v16; // r15
  __int64 v17; // rax
  void *v18; // rax
  size_t v19; // rdx
  int v20; // esi
  int *v21; // rax
  _DWORD *v22; // rdx
  _DWORD *v23; // rcx
  int v24; // r15d
  _QWORD *v25; // r14
  __int64 v26; // rax
  __int64 v27; // r9
  int *v28; // r10
  __int64 v29; // rdx
  int v30; // esi
  float **pcm; // rdi
  int v32; // r8d
  _DWORD *v33; // rdx
  float *v34; // rax
  float *v35; // rdx
  float *v36; // rcx
  float v37; // xmm0_4
  float v38; // xmm1_4
  vorbis_block_0 *v39; // r15
  _DWORD *v40; // r12
  void **v41; // r13
  private_state_1 *v42; // rbx
  __int64 v43; // r14
  __int64 v44; // rax
  int v45; // eax
  _DWORD *v46; // r12
  vorbis_block_0 *v47; // r13
  private_state_1 *v48; // r15
  __int64 v49; // r14
  int v50; // ebx
  float *v51; // rsi
  int *zerobundle; // [rsp+0h] [rbp-80h] BYREF
  float **pcmbundle; // [rsp+8h] [rbp-78h]
  ogg_int32_t n; // [rsp+14h] [rbp-6Ch]
  private_state_1 *b; // [rsp+18h] [rbp-68h]
  int *nonzero; // [rsp+20h] [rbp-60h]
  size_t v58; // [rsp+28h] [rbp-58h]
  void **floormemo; // [rsp+30h] [rbp-50h]
  void *contexta; // [rsp+38h] [rbp-48h]
  const vorbis_func_floor *const *v61; // [rsp+40h] [rbp-40h]
  codec_setup_info_0 *ci; // [rsp+48h] [rbp-38h]

  v4 = l;
  vd = vb->vd;
  contexta = context;
  v6 = *(int **)&vd->analysisp;
  b = (private_state_1 *)vd->time_bits;
  v7 = v6[1];
  LODWORD(vd) = *(_DWORD *)(*((_QWORD *)v6 + 4) + 4LL * vb->W);
  ci = (codec_setup_info_0 *)*((_QWORD *)v6 + 4);
  n = (int)vd;
  vb->pcmend = (int)vd;
  v8 = alloca(8LL * v7 + 15);
  v9 = alloca(4LL * v7 + 15);
  v10 = alloca(4LL * v7 + 15);
  v11 = alloca(8LL * v7 + 15);
  p_zerobundle = &zerobundle;
  v13 = (size_t)&zerobundle;
  floormemo = (void **)&zerobundle;
  if ( v7 > 0 )
  {
    nonzero = v6;
    v15 = b;
    v16 = 0;
    pcmbundle = (float **)&zerobundle;
    zerobundle = (int *)&zerobundle;
    v58 = 4LL * n;
    v58 >>= 1;
    v61 = FMOD_floor_P;
    do
    {
      v17 = *((int *)l + *((int *)l + v16 + 1) + 257);
      v18 = (void *)((__int64 (__fastcall *)(void *, vorbis_block_0 *, vorbis_look_floor *))v61[ci->floor_type[v17]]->inverse1)(
                      contexta,
                      vb,
                      v15->flr[v17]);
      v19 = v58;
      floormemo[v16] = v18;
      *((_DWORD *)&zerobundle + v16) = v18 != 0;
      memset(vb->pcm[v16++], 0, v19);
    }
    while ( nonzero[1] > (int)v16 );
    p_zerobundle = pcmbundle;
    v13 = (size_t)zerobundle;
    v4 = l;
    v6 = nonzero;
  }
  v20 = v4[289];
  if ( v20 > 0 )
  {
    v21 = v4 + 546;
    do
    {
      v22 = (_DWORD *)&zerobundle + *(v21 - 256);
      v23 = (_DWORD *)&zerobundle + *v21;
      if ( *v22 || *v23 )
      {
        *v22 = 1;
        *v23 = 1;
      }
      ++v21;
    }
    while ( v21 != &v4[v20 - 1 + 547] );
  }
  if ( (int)*v4 > 0 )
  {
    nonzero = (int *)&zerobundle;
    v61 = (const vorbis_func_floor *const *)v4;
    v24 = 0;
    v25 = p_zerobundle;
    do
    {
      if ( v6[1] <= 0 )
      {
        v27 = 0;
      }
      else
      {
        v26 = 0;
        v27 = 0;
        v28 = nonzero;
        do
        {
          while ( v4[v26 + 1] != v24 )
          {
            if ( v6[1] <= (int)++v26 )
              goto LABEL_20;
          }
          v29 = (int)v27;
          if ( v28[v26] )
            *(_DWORD *)(v13 + 4LL * (int)v27) = 1;
          else
            *(_DWORD *)(v13 + 4LL * (int)v27) = 0;
          v27 = (unsigned int)(v27 + 1);
          v25[v29] = vb->pcm[v26++];
        }
        while ( v6[1] > (int)v26 );
      }
LABEL_20:
      v58 = v13;
      ++v24;
      ((void (__fastcall *)(void *, vorbis_block_0 *, vorbis_look_residue *, _QWORD *, size_t, __int64))FMOD_residue_P[ci->residue_type[*((int *)v61 + 273)]]->inverse)(
        contexta,
        vb,
        b->residue[*((int *)v61 + 273)],
        v25,
        v13,
        v27);
      v61 = (const vorbis_func_floor *const *)((char *)v61 + 4);
      v13 = v58;
    }
    while ( *v4 > v24 );
    v20 = v4[289];
  }
  v30 = v20 - 1;
  if ( v30 >= 0 )
  {
    pcm = vb->pcm;
    v32 = n / 2;
    while ( 1 )
    {
      v33 = &v4[v30];
      v34 = pcm[v33[290]];
      v35 = pcm[v33[546]];
      v36 = &v34[v32 - 1 + 1];
      if ( v32 > 0 )
        break;
LABEL_32:
      if ( --v30 == -1 )
        goto LABEL_33;
    }
    while ( 1 )
    {
      v37 = *v34;
      v38 = *v35;
      if ( *v34 > 0.0 )
        break;
      if ( v38 <= 0.0 )
      {
        *v35 = v37;
        *v34 = v37 - v38;
LABEL_28:
        ++v34;
        ++v35;
        if ( v34 == v36 )
          goto LABEL_32;
      }
      else
      {
        ++v34;
        *v35++ = v37 + v38;
        if ( v34 == v36 )
          goto LABEL_32;
      }
    }
    if ( v38 <= 0.0 )
    {
      *v35 = v37;
      *v34 = v37 + v38;
    }
    else
    {
      *v35 = v37 - v38;
    }
    goto LABEL_28;
  }
LABEL_33:
  if ( v6[1] > 0 )
  {
    contexta = v6;
    v39 = vb;
    v40 = v4;
    v41 = floormemo;
    v42 = b;
    v43 = 0;
    v61 = FMOD_floor_P;
    do
    {
      v44 = (int)v40[v40[v43 + 1] + 257];
      v61[ci->floor_type[v44]]->inverse2((vorbis_block *)v39, v42->flr[v44], v41[v43], v39->pcm[v43]);
      ++v43;
      v45 = *((_DWORD *)contexta + 1);
    }
    while ( (int)v43 < v45 );
    v46 = contexta;
    v47 = v39;
    if ( v45 > 0 )
    {
      v48 = b;
      v49 = 0;
      v50 = 0;
      do
      {
        ++v50;
        v51 = v47->pcm[v49++];
        FMOD_mdct_backward(*(mdct_lookup **)v48->transform[v47->W], v51, v51);
      }
      while ( v46[1] > v50 );
    }
  }
  return 0;
}


// Address: 0x226c300 | Name: FMOD_mapping0_free_info
void __fastcall FMOD_mapping0_free_info(void *context, vorbis_info_mapping *i)
{
  _DWORD *v3; // rdi
  unsigned int v4; // r8d
  __int64 v5; // rcx
  _DWORD *v6; // rdi

  if ( i )
  {
    v3 = i;
    v4 = 3208;
    if ( ((unsigned __int8)i & 1) != 0 )
    {
      *(_BYTE *)i = 0;
      v3 = (char *)i + 1;
      LOBYTE(v4) = -121;
    }
    if ( ((unsigned __int8)v3 & 2) != 0 )
    {
      v3 = (_DWORD *)((char *)v3 + 2);
      v4 -= 2;
      *((_WORD *)v3 - 1) = 0;
    }
    if ( ((unsigned __int8)v3 & 4) != 0 )
    {
      *v3 = 0;
      v4 -= 4;
      ++v3;
    }
    v5 = v4 >> 3;
    memset(v3, 0, 8 * v5);
    v6 = &v3[2 * v5];
    if ( (v4 & 4) != 0 )
    {
      *v6++ = 0;
      if ( (v4 & 2) == 0 )
      {
LABEL_10:
        if ( (v4 & 1) == 0 )
        {
LABEL_11:
          FMOD_OggVorbis_Free(context, i);
          return;
        }
        goto LABEL_12;
      }
    }
    else if ( (v4 & 2) == 0 )
    {
      goto LABEL_10;
    }
    v6 = (_DWORD *)((char *)v6 + 2);
    *((_WORD *)v6 - 1) = 0;
    if ( (v4 & 1) == 0 )
      goto LABEL_11;
LABEL_12:
    *(_BYTE *)v6 = 0;
    FMOD_OggVorbis_Free(context, i);
  }
}


// Address: 0x226c3f0 | Name: FMOD_mapping0_unpack
vorbis_info_mapping *__fastcall FMOD_mapping0_unpack(void *context, vorbis_info_0 *vi, oggpack_buffer_0 *opb)
{
  ogg_int32_t *v5; // rbp
  ogg_int32_t *v6; // rdi
  unsigned int v7; // edx
  __int64 v8; // rcx
  ogg_int32_t *v9; // rdi
  ogg_int32_t v10; // eax
  ogg_int32_t v11; // eax
  int v12; // eax
  int channels; // edx
  ogg_int32_t *v14; // r12
  ogg_int32_t v15; // r14d
  int v16; // esi
  unsigned int v17; // eax
  ogg_int32_t v18; // eax
  int v19; // edx
  int v20; // esi
  int v21; // r15d
  unsigned int i; // edx
  ogg_int32_t v23; // eax
  int v24; // edx
  int v25; // r14d
  ogg_int32_t *v26; // r12
  ogg_int32_t v27; // eax
  int v29; // eax
  ogg_int32_t *v30; // r12
  ogg_int32_t v31; // r13d
  ogg_int32_t v32; // eax
  bool v33; // cc
  ogg_int32_t v34; // eax
  _DWORD *codec_setup; // [rsp+0h] [rbp-48h]

  v5 = (ogg_int32_t *)FMOD_OggVorbis_Calloc(context, 1, 3208);
  codec_setup = vi->codec_setup;
  if ( !v5 )
    goto err_out;
  v6 = v5;
  v7 = 3208;
  if ( ((unsigned __int8)v5 & 1) != 0 )
  {
    *(_BYTE *)v5 = 0;
    v6 = (ogg_int32_t *)((char *)v5 + 1);
    LOBYTE(v7) = -121;
  }
  if ( ((unsigned __int8)v6 & 2) != 0 )
  {
    v6 = (ogg_int32_t *)((char *)v6 + 2);
    v7 -= 2;
    *((_WORD *)v6 - 1) = 0;
    if ( ((unsigned __int8)v6 & 4) == 0 )
      goto LABEL_6;
  }
  else if ( ((unsigned __int8)v6 & 4) == 0 )
  {
    goto LABEL_6;
  }
  *v6 = 0;
  v7 -= 4;
  ++v6;
LABEL_6:
  v8 = v7 >> 3;
  memset(v6, 0, 8 * v8);
  v9 = &v6[2 * v8];
  if ( (v7 & 4) == 0 )
  {
    if ( (v7 & 2) == 0 )
      goto LABEL_8;
LABEL_37:
    v9 = (ogg_int32_t *)((char *)v9 + 2);
    *((_WORD *)v9 - 1) = 0;
    if ( (v7 & 1) == 0 )
      goto LABEL_9;
    goto LABEL_36;
  }
  *v9++ = 0;
  if ( (v7 & 2) != 0 )
    goto LABEL_37;
LABEL_8:
  if ( (v7 & 1) != 0 )
LABEL_36:
    *(_BYTE *)v9 = 0;
LABEL_9:
  v10 = FMOD_oggpack_read((oggpack_buffer *)opb, 1);
  if ( v10 < 0 )
    goto err_out;
  if ( v10 )
  {
    v29 = FMOD_oggpack_read((oggpack_buffer *)opb, 4) + 1;
    *v5 = v29;
    if ( v29 <= 0 )
      goto err_out;
  }
  else
  {
    *v5 = 1;
  }
  v11 = FMOD_oggpack_read((oggpack_buffer *)opb, 1);
  if ( v11 < 0 )
    goto err_out;
  if ( v11 )
  {
    v12 = FMOD_oggpack_read((oggpack_buffer *)opb, 8) + 1;
    v5[289] = v12;
    if ( v12 > 0 )
    {
      channels = vi->channels;
      v14 = v5 + 546;
      v15 = 0;
      while ( 1 )
      {
        v16 = 0;
        if ( channels )
        {
          v17 = channels - 1;
          if ( channels != 1 )
          {
            do
            {
              ++v16;
              v17 >>= 1;
            }
            while ( v17 );
          }
        }
        v18 = FMOD_oggpack_read((oggpack_buffer *)opb, v16);
        v19 = vi->channels;
        v20 = 0;
        v21 = v18;
        *(v14 - 256) = v18;
        if ( v19 )
        {
          for ( i = v19 - 1; i; i >>= 1 )
            ++v20;
        }
        v23 = FMOD_oggpack_read((oggpack_buffer *)opb, v20);
        *v14 = v23;
        if ( v21 < 0 )
          break;
        if ( v23 < 0 )
          break;
        if ( v21 == v23 )
          break;
        channels = vi->channels;
        if ( v21 >= channels || v23 >= channels )
          break;
        ++v15;
        ++v14;
        if ( v5[289] <= v15 )
          goto LABEL_28;
      }
    }
    goto err_out;
  }
LABEL_28:
  if ( FMOD_oggpack_read((oggpack_buffer *)opb, 2) )
  {
err_out:
    FMOD_mapping0_free_info(context, v5);
    return 0;
  }
  v24 = *v5;
  if ( *v5 > 1 )
  {
    v25 = 0;
    v26 = v5 + 1;
    if ( vi->channels > 0 )
    {
      while ( 1 )
      {
        v27 = FMOD_oggpack_read((oggpack_buffer *)opb, 4);
        *v26 = v27;
        v24 = *v5;
        if ( v27 >= *v5 || v27 < 0 )
          goto err_out;
        ++v25;
        ++v26;
        if ( vi->channels <= v25 )
          goto LABEL_43;
      }
    }
    goto LABEL_44;
  }
LABEL_43:
  if ( v24 > 0 )
  {
LABEL_44:
    v30 = v5 + 257;
    v31 = 0;
    while ( 1 )
    {
      FMOD_oggpack_read((oggpack_buffer *)opb, 8);
      v34 = FMOD_oggpack_read((oggpack_buffer *)opb, 8);
      *v30 = v34;
      if ( v34 >= codec_setup[4] )
        break;
      if ( v34 < 0 )
        break;
      v32 = FMOD_oggpack_read((oggpack_buffer *)opb, 8);
      v33 = v32 < codec_setup[5];
      v30[16] = v32;
      if ( !v33 || v32 < 0 )
        break;
      ++v31;
      ++v30;
      if ( *v5 <= v31 )
        return v5;
    }
    goto err_out;
  }
  return v5;
}


