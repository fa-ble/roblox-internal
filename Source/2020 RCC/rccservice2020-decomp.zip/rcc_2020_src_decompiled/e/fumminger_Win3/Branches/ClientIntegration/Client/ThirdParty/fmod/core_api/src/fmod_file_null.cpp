// Address: 0x21f23d0 | Name: _ZN4FMOD8NullFile10reallyOpenEPKcPj
FMOD_RESULT_0 __fastcall FMOD::NullFile::reallyOpen(
        FMOD::NullFile *const this,
        const char *name_or_data,
        unsigned int *filesize)
{
  this->mPosition = 0;
  *filesize = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f23f0 | Name: _ZN4FMOD8NullFile11reallyCloseEv
FMOD_RESULT_0 __fastcall FMOD::NullFile::reallyClose(FMOD::NullFile *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f2400 | Name: _ZN4FMOD8NullFile10reallyReadEPvjPj
FMOD_RESULT_0 __fastcall FMOD::NullFile::reallyRead(
        FMOD::NullFile *const this,
        void *buffer,
        unsigned int size,
        unsigned int *read)
{
  unsigned int mPosition; // esi
  unsigned int mLength; // r8d
  FMOD_RESULT_0 result; // eax

  mPosition = this->mPosition;
  mLength = this->mLength;
  result = FMOD_RESULT::FMOD_OK_0;
  if ( size + mPosition > mLength )
  {
    LOBYTE(result) = 31;
    size = mLength - mPosition;
  }
  *read = size;
  this->mPosition += size;
  return result;
}


// Address: 0x21f2430 | Name: _ZN4FMOD8NullFile10reallySeekEj
FMOD_RESULT_0 __fastcall FMOD::NullFile::reallySeek(FMOD::NullFile *const this, unsigned int pos)
{
  unsigned int mLength; // eax

  mLength = this->mLength;
  this->mPosition = pos;
  if ( pos > mLength )
    this->mPosition = mLength;
  return FMOD_RESULT::FMOD_OK_0;
}


