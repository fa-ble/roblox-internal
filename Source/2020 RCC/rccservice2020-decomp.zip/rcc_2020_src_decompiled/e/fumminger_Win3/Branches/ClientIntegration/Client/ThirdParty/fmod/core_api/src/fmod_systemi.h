// Address: 0x21b61e0 | Name: _ZN4FMOD18LocalSystemSection5leaveEv
void __fastcall FMOD::LocalSystemSection::leave(FMOD::LocalSystemSection *const this)
{
  FMOD::SystemI *mSystem; // rax
  FMOD::FMOD_SYSTEM_CRIT mCritType; // esi

  mSystem = this->mSystem;
  if ( this->mSystem )
  {
    if ( this->mEntered )
    {
      mCritType = this->mCritType;
      this->mEntered = 0;
      FMOD::SystemI::leaveCrit(mSystem, mCritType);
    }
  }
}


// Address: 0x21c6a90 | Name: _ZN4FMOD7SystemI9pluginLogEjPKciS2_S2_z
void FMOD::SystemI::pluginLog(
        FMOD_DEBUG_FLAGS level,
        const char *file,
        int line,
        const char *function,
        const char *string,
        ...)
{
  ;
}


// Address: 0x21c7270 | Name: _ZN4FMOD7SystemID2Ev
void __fastcall FMOD::SystemI::~SystemI(FMOD::SystemI *const this)
{
  __int64 mSize; // rax
  bool v3; // zf
  bool v4; // cc
  bool v5; // cc
  __int64 v6; // rdi
  int mCapacity; // eax
  bool v8; // cc
  void *v9; // rsi
  __int64 v10; // rdi
  void *v11; // rsi
  int v12; // eax
  void *v13; // rsi
  unsigned int *v14; // rsi
  unsigned int *mData; // rsi

  this->_vptr_SystemI = (int (**)(...))off_29B0E70;
  mSize = this->mObject3DHead.mSize;
  if ( (int)mSize < 0 )
    memset(
      (void *)(*(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) + 8 * mSize),
      0,
      8LL * -(int)mSize);
  v3 = this->mObject3DHead.mCapacity == 0;
  v4 = this->mObject3DHead.mCapacity <= 0;
  this->mObject3DHead.mSize = 0;
  if ( !v3 )
  {
    if ( !v4 )
    {
      v9 = *(void **)((char *)&stru_12618.r_offset + (_QWORD)this);
      if ( v9 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v9, "../../../core_api/src/fmod_memory.h", 244);
    }
    *(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) = 0;
    this->mObject3DHead.mCapacity = 0;
  }
  v3 = this->mReturnTable.mMap.mBuckets.mCapacity == 0;
  v5 = this->mReturnTable.mMap.mBuckets.mCapacity <= 0;
  this->mReturnTable.mMap.mBuckets.mSize = 0;
  if ( v3 )
  {
    v6 = this->mReturnTable.mMap.mNodes.mSize;
    if ( (int)v6 >= 0 )
      goto LABEL_6;
    goto LABEL_32;
  }
  if ( !v5 )
  {
    mData = this->mReturnTable.mMap.mBuckets.mData;
    if ( mData )
      FMOD::MemPool::free(off_286F358->gSystemMemPool, mData, "../../../core_api/src/fmod_memory.h", 244);
  }
  v6 = this->mReturnTable.mMap.mNodes.mSize;
  this->mReturnTable.mMap.mBuckets.mData = 0;
  this->mReturnTable.mMap.mBuckets.mCapacity = 0;
  if ( (int)v6 < 0 )
LABEL_32:
    memset((void *)(*(unsigned __int64 *)((char *)&stru_12600.r_offset + (_QWORD)this) + 16 * v6), 0, 16LL * -(int)v6);
LABEL_6:
  mCapacity = this->mReturnTable.mMap.mNodes.mCapacity;
  this->mReturnTable.mMap.mNodes.mSize = 0;
  if ( !mCapacity )
  {
    this->mReturnTable.mMap.mFreeList = -1;
    this->mReturnTable.mMap.mNodeCount = 0;
LABEL_8:
    this->mReturnTable.mMap.mNodes.mSize = 0;
    goto LABEL_9;
  }
  v10 = 0;
  if ( mCapacity > 0 )
  {
    v11 = *(void **)((char *)&stru_12600.r_offset + (_QWORD)this);
    if ( v11 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v11, "../../../core_api/src/fmod_memory.h", 244);
      v10 = this->mReturnTable.mMap.mNodes.mSize;
    }
  }
  *(unsigned __int64 *)((char *)&stru_12600.r_offset + (_QWORD)this) = 0;
  this->mReturnTable.mMap.mNodes.mCapacity = 0;
  this->mReturnTable.mMap.mFreeList = -1;
  this->mReturnTable.mMap.mNodeCount = 0;
  if ( (int)v10 >= 0 )
    goto LABEL_8;
  memset((void *)(16 * v10), 0, 16LL * -(int)v10);
  v12 = this->mReturnTable.mMap.mNodes.mCapacity;
  this->mReturnTable.mMap.mNodes.mSize = 0;
  if ( v12 )
  {
    if ( v12 > 0 )
    {
      v13 = *(void **)((char *)&stru_12600.r_offset + (_QWORD)this);
      if ( v13 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v13, "../../../core_api/src/fmod_memory.h", 244);
    }
    *(unsigned __int64 *)((char *)&stru_12600.r_offset + (_QWORD)this) = 0;
    this->mReturnTable.mMap.mNodes.mCapacity = 0;
  }
LABEL_9:
  v3 = this->mReturnTable.mMap.mBuckets.mCapacity == 0;
  v8 = this->mReturnTable.mMap.mBuckets.mCapacity <= 0;
  this->mReturnTable.mMap.mBuckets.mSize = 0;
  if ( !v3 )
  {
    if ( !v8 )
    {
      v14 = this->mReturnTable.mMap.mBuckets.mData;
      if ( v14 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v14, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mReturnTable.mMap.mBuckets.mData = 0;
    this->mReturnTable.mMap.mBuckets.mCapacity = 0;
  }
  FMOD::GeometryMgr::~GeometryMgr(&this->mGeometryMgr);
  this->mStreamThread._vptr_Thread = (int (**)(...))&off_29B0E30;
  FMOD::MemPool::close(&this->mDSPLevelsPool);
  FMOD::MemPool::close((FMOD::MemPool *const)((char *)&stru_10818 + (_QWORD)this));
}


// Address: 0x21c7590 | Name: _ZN4FMOD7SystemID0Ev
void __fastcall FMOD::SystemI::~SystemI(FMOD::SystemI *const this)
{
  __int64 mSize; // rax
  bool v2; // zf
  bool v3; // cc
  bool v4; // cc
  int v5; // eax
  int mCapacity; // eax
  int v7; // eax
  bool v8; // cc
  void *v9; // rsi
  unsigned int *mData; // rsi
  unsigned int *v11; // rsi

  this->_vptr_SystemI = (int (**)(...))off_29B0E70;
  mSize = this->mObject3DHead.mSize;
  if ( (int)mSize < 0 )
    memset(
      (void *)(*(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) + 8 * mSize),
      0,
      8LL * -(int)mSize);
  v2 = this->mObject3DHead.mCapacity == 0;
  v3 = this->mObject3DHead.mCapacity <= 0;
  this->mObject3DHead.mSize = 0;
  if ( !v2 )
  {
    if ( !v3 )
    {
      v9 = *(void **)((char *)&stru_12618.r_offset + (_QWORD)this);
      if ( v9 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v9, "../../../core_api/src/fmod_memory.h", 244);
    }
    *(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) = 0;
    this->mObject3DHead.mCapacity = 0;
  }
  v2 = this->mReturnTable.mMap.mBuckets.mCapacity == 0;
  v4 = this->mReturnTable.mMap.mBuckets.mCapacity <= 0;
  this->mReturnTable.mMap.mBuckets.mSize = 0;
  if ( !v2 )
  {
    if ( !v4 )
    {
      mData = this->mReturnTable.mMap.mBuckets.mData;
      if ( mData )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mData, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mReturnTable.mMap.mBuckets.mData = 0;
    this->mReturnTable.mMap.mBuckets.mCapacity = 0;
  }
  v5 = this->mReturnTable.mMap.mNodes.mSize;
  if ( v5 < 0 )
    memset((void *)(*(unsigned __int64 *)((char *)&stru_12600.r_offset + (_QWORD)this) + 16LL * v5), 0, 16LL * -v5);
  mCapacity = this->mReturnTable.mMap.mNodes.mCapacity;
  this->mReturnTable.mMap.mNodes.mSize = 0;
  if ( !mCapacity
    || (v2 = FMOD::DynamicArray<FMOD::HashMap<int,FMOD::DSPReturn *,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::AlignedAllocator<1>>::reallocate(
               (FMOD::DynamicArray<FMOD::HashMap<int,FMOD::DSPReturn*>::Node,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::AlignedAllocator<1> > *const)((char *)&stru_12600 + (_QWORD)this),
               0) == FMOD_RESULT::FMOD_OK_0,
        mCapacity = this->mReturnTable.mMap.mNodes.mSize,
        v2) )
  {
    this->mReturnTable.mMap.mFreeList = -1;
    this->mReturnTable.mMap.mNodeCount = 0;
  }
  if ( mCapacity < 0 )
    memset(
      (void *)(*(unsigned __int64 *)((char *)&stru_12600.r_offset + (_QWORD)this) + 16LL * mCapacity),
      0,
      16LL * -mCapacity);
  v7 = this->mReturnTable.mMap.mNodes.mCapacity;
  this->mReturnTable.mMap.mNodes.mSize = 0;
  if ( v7 )
    FMOD::DynamicArray<FMOD::HashMap<int,FMOD::DSPReturn *,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::AlignedAllocator<1>>::reallocate(
      (FMOD::DynamicArray<FMOD::HashMap<int,FMOD::DSPReturn*>::Node,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::AlignedAllocator<1> > *const)((char *)&stru_12600 + (_QWORD)this),
      0);
  v2 = this->mReturnTable.mMap.mBuckets.mCapacity == 0;
  v8 = this->mReturnTable.mMap.mBuckets.mCapacity <= 0;
  this->mReturnTable.mMap.mBuckets.mSize = 0;
  if ( !v2 )
  {
    if ( !v8 )
    {
      v11 = this->mReturnTable.mMap.mBuckets.mData;
      if ( v11 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v11, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mReturnTable.mMap.mBuckets.mData = 0;
    this->mReturnTable.mMap.mBuckets.mCapacity = 0;
  }
  FMOD::GeometryMgr::~GeometryMgr(&this->mGeometryMgr);
  this->mStreamThread._vptr_Thread = (int (**)(...))&off_29B0E30;
  FMOD::MemPool::close(&this->mDSPLevelsPool);
  FMOD::MemPool::close((FMOD::MemPool *const)((char *)&stru_10818 + (_QWORD)this));
  operator delete(this);
}


// Address: 0x21c7840 | Name: _ZN4FMOD7SystemI26getChannelsFromSpeakerModeE16FMOD_SPEAKERMODE
int __fastcall FMOD::SystemI::getChannelsFromSpeakerMode(FMOD_SPEAKERMODE_0 speakermode)
{
  int result; // eax

  if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    return 5;
  if ( speakermode <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
  {
    if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
      return 2;
    result = 4;
    if ( speakermode <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
    {
      LOBYTE(result) = 1;
      if ( speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0 )
        return 0;
    }
  }
  else
  {
    result = 8;
    if ( speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
    {
      LOBYTE(result) = 6;
      if ( speakermode >= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
      {
        LOBYTE(result) = 12;
        if ( speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
        {
          if ( speakermode == 1000 )
            return 2;
          return 0;
        }
      }
    }
  }
  return result;
}


// Address: 0x21c9fe0 | Name: _ZN4FMOD7SystemI18getSpeakerPositionE12FMOD_SPEAKERPfS2_Pb
FMOD_RESULT_0 __fastcall FMOD::SystemI::getSpeakerPosition(
        FMOD::SystemI *const this,
        FMOD_SPEAKER_0 speaker,
        float *x,
        float *y,
        bool *active)
{
  FMOD_RESULT_0 result; // eax

  result = this->mSpeakerMode;
  if ( result == FMOD_RESULT::FMOD_ERR_DMA_0 )
  {
    LOBYTE(result) = 31;
    if ( (unsigned int)(speaker - 2) <= 1 )
      return result;
    if ( (unsigned int)(speaker - 4) <= 1 )
      speaker -= 2;
  }
  else if ( result == FMOD_RESULT::FMOD_ERR_DSP_CONNECTION_0 )
  {
    LOBYTE(result) = 31;
    if ( speaker == FMOD_SPEAKER::FMOD_SPEAKER_LOW_FREQUENCY_0 )
      return result;
    if ( (unsigned int)(speaker - 4) <= 1 )
      --speaker;
  }
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( speaker < this->mDSPMaxOutputChannels )
  {
    if ( x )
      *x = this->mSpeaker[speaker].mPosition.x;
    if ( y )
      *y = this->mSpeaker[speaker].mPosition.z;
    if ( active )
      *active = this->mSpeaker[speaker].mActive;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2220080 | Name: _ZN4FMOD7SystemI10pluginFreeEPvPKci
void __fastcall FMOD::SystemI::pluginFree(void *ptr, const char *file, int line)
{
  FMOD::MemPool::alignedFree(off_286F358->gSystemMemPool, ptr, file, line);
}


// Address: 0x22200b0 | Name: _ZN4FMOD7SystemI11pluginAllocEjjPKci
void *__fastcall FMOD::SystemI::pluginAlloc(unsigned int size, unsigned int align, const char *file, int line)
{
  return FMOD::MemPool::alignedAlloc(off_286F358->gSystemMemPool, size, align, file, line, 0x10u, 0);
}


// Address: 0x2229ed0 | Name: _ZN4FMOD10DSPParamEq25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPParamEq::setParameterFloatInternal(
        FMOD::DSPParamEq *const this,
        int index,
        __m128 a3,
        __m128 value)
{
  __m128 v5; // xmm2

  if ( index == 1 )
  {
    *((_DWORD *)this + 271) = a3.m128_i32[0];
    return 0;
  }
  else if ( index == 2 )
  {
    *((_DWORD *)this + 272) = a3.m128_i32[0];
    return 0;
  }
  else
  {
    if ( !index )
    {
      value.m128_f32[0] = (float)((float)*(int *)(*((_QWORD *)this + 22) + 1696LL) * 0.5) - 100.0;
      v5 = _mm_cmple_ss(value, a3);
      *((_DWORD *)this + 270) = _mm_andnot_ps(v5, a3).m128_u32[0] | value.m128_i32[0] & v5.m128_i32[0];
    }
    return 0;
  }
}


// Address: 0x223c0a0 | Name: _ZN4FMOD10DSPThreeEQ16updateSampleRateEv
void __fastcall FMOD::DSPThreeEQ::updateSampleRate(FMOD::DSPThreeEQ *const this)
{
  *((float *)this + 2421) = (float)*(int *)(*((_QWORD *)this + 22) + 1696LL);
}


