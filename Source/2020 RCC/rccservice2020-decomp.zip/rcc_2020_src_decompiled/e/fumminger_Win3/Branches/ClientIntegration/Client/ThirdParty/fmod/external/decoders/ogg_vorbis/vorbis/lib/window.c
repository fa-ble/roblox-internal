// Address: 0x2272530 | Name: _FMOD_vorbis_window_init
void __cdecl FMOD_vorbis_window_init()
{
  int v0; // r13d
  int v1; // ebp
  float *v2; // r12
  __int64 v3; // rbx
  __m128d v4; // xmm0

  v0 = 8;
  v1 = 32;
  do
  {
    while ( 1 )
    {
      if ( v1 == 256 )
      {
        v2 = vwin512;
        goto LABEL_8;
      }
      if ( v1 <= 256 )
      {
        switch ( v1 )
        {
          case 64:
            v2 = vwin128;
            break;
          case 128:
            v2 = vwin256;
            break;
          case 32:
            v2 = vwin64;
            break;
          default:
            goto LABEL_10;
        }
LABEL_8:
        v3 = 0;
        do
        {
          v4.m128d_f64[1] = (float)((float)((float)(int)v3 + 0.5) / (float)v1);
          v4.m128d_f64[0] = v4.m128d_f64[1] * 3.141592653589793 * 0.5;
          *(float *)v4.m128d_f64 = _mm_unpacklo_pd(v4, v4).m128d_f64[0];
          *(float *)v4.m128d_f64 = sinf(*(float *)v4.m128d_f64);
          v4.m128d_f64[1] = (float)(*(float *)v4.m128d_f64 * *(float *)v4.m128d_f64);
          v4.m128d_f64[0] = v4.m128d_f64[1] * 1.570796326794897;
          v2[v3++] = sinf(_mm_unpacklo_pd(v4, v4).m128d_f64[0]);
        }
        while ( v1 > (int)v3 );
        goto LABEL_10;
      }
      if ( v1 == 1024 )
      {
        v2 = vwin2048;
        goto LABEL_8;
      }
      if ( v1 <= 1024 )
        break;
      if ( v1 == 2048 )
      {
        v2 = vwin4096;
        goto LABEL_8;
      }
      v2 = vwin8192;
      if ( v1 == 4096 )
        goto LABEL_8;
LABEL_10:
      v1 *= 2;
      if ( !--v0 )
        return;
    }
    v2 = vwin1024;
    if ( v1 == 512 )
      goto LABEL_8;
    v1 *= 2;
    --v0;
  }
  while ( v0 );
}


// Address: 0x22726c0 | Name: _FMOD_vorbis_window_get
float *__fastcall FMOD_vorbis_window_get(int n)
{
  return vwin[n];
}


// Address: 0x22726d0 | Name: _FMOD_vorbis_apply_window
void __fastcall FMOD_vorbis_apply_window(float *d, int *winno, ogg_int32_t *blocksizes, int lW, int W, int nW)
{
  __int64 v6; // r10
  __int64 v7; // rcx
  ogg_int32_t v8; // r8d
  float *v9; // r11
  float *v10; // rax
  ogg_int32_t v11; // r9d
  ogg_int32_t v12; // edx
  int v13; // r9d
  int v14; // ecx
  int v15; // esi
  int v16; // r10d
  int v17; // ebx
  __int64 v18; // rdx
  float *v19; // rdx
  __int64 v20; // rcx
  float v21; // xmm0_4
  int v22; // r10d
  float *v23; // rdx
  float *v24; // rax
  float v25; // xmm0_4
  float *v26; // rax

  if ( W )
  {
    v6 = nW;
    v7 = lW;
  }
  else
  {
    v6 = 0;
    v7 = 0;
  }
  v8 = blocksizes[W];
  v9 = vwin[winno[v6]];
  v10 = vwin[winno[v7]];
  v11 = blocksizes[v7];
  v12 = blocksizes[v6];
  v13 = v8 / 4 - v11 / 4 + v11 / 2;
  v14 = v8 / 4 - ((int)(v7 * 4) >> 2);
  v15 = v8 / 4 + v8 / 2 - v12 / 4;
  v16 = v12 / 2;
  v17 = v12 / 2 + v15;
  if ( v14 <= 0 )
  {
    v14 = 0;
  }
  else
  {
    v18 = 0;
    do
      d[v18++] = 0.0;
    while ( v14 > (int)v18 );
  }
  if ( v14 < v13 )
  {
    v19 = &d[v14];
    v20 = (__int64)&v10[v13 - 1 - v14 + 1];
    do
    {
      v21 = *v19;
      *v19++ = v21 * *v10++;
    }
    while ( v10 != (float *)v20 );
  }
  v22 = v16 - 1;
  if ( v15 < v17 )
  {
    v23 = &v9[v22];
    v24 = &d[v15];
    do
    {
      v25 = *v24++;
      --v23;
      *(v24 - 1) = v25 * v23[1];
    }
    while ( v24 != &d[(unsigned int)(v17 - v15 - 1) + 1 + (__int64)v15] );
    v15 = v17;
  }
  if ( v8 > v15 )
  {
    v26 = &d[v15];
    do
      *v26++ = 0.0;
    while ( v26 != &d[(unsigned int)(v8 - 1 - v15) + 1 + (__int64)v15] );
  }
}


