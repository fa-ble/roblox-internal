// Address: 0x2247bb0 | Name: _Z25FMOD_PortHead_setparamintP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD_PortHead_setparamint(FMOD_DSP_STATE *dsp_state, int param, int value)
{
  int *plugindata; // rax
  float v4; // xmm3_4
  float v5; // xmm2_4
  unsigned __int64 v6; // rdx

  plugindata = (int *)dsp_state->plugindata;
  if ( param )
    return FMOD_RESULT::FMOD_OK_0;
  v4 = (float)value;
  v5 = (float)plugindata[11];
  plugindata[10] = value;
  v6 = (unsigned int)(int)(float)((float)(v5 / (float)value) * 4294967300.0);
  *((_QWORD *)plugindata + 7) = v6;
  if ( v6 <= 0x100 )
  {
    *((_QWORD *)plugindata + 8) = -1;
    return FMOD_RESULT::FMOD_OK_0;
  }
  *((_QWORD *)plugindata + 8) = (unsigned int)(int)(float)((float)(v4 / v5) * 4294967300.0);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2247c10 | Name: _Z25FMOD_PortHead_getparamintP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD_PortHead_getparamint(FMOD_DSP_STATE *a1, int a2, int *a3, char *a4)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2247c20 | Name: _Z21FMOD_PortHead_releaseP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD_PortHead_release(FMOD_DSP_STATE *dsp_state)
{
  void **plugindata; // rbp

  plugindata = (void **)dsp_state->plugindata;
  dsp_state->functions->free(plugindata[1], 0, "../../../core_api/src/fmod_dsp_porthead.cpp");
  dsp_state->functions->free(plugindata, 0, "../../../core_api/src/fmod_dsp_porthead.cpp");
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2247c60 | Name: _Z19FMOD_PortHead_resetP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD_PortHead_reset(FMOD_DSP_STATE *dsp_state)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2247c70 | Name: _Z20FMOD_PortHead_createP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD_PortHead_create(FMOD_DSP_STATE *dsp_state)
{
  _DWORD *v1; // rbx
  FMOD_RESULT_0 result; // eax
  FMOD_DSP_STATE_FUNCTIONS *functions; // rcx
  __int64 v4; // rax
  int v5; // edx
  __int64 v6; // r12
  __int64 v7; // rax
  void *v8; // rdi
  __int64 v9; // rax
  unsigned int v10; // eax
  int v11; // edx
  int mInputFrequency; // [rsp+8h] [rbp-20h] BYREF
  unsigned int blockLength[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  dsp_state->functions->getsamplerate(dsp_state, &mInputFrequency);
  dsp_state->functions->getblocksize(dsp_state, blockLength);
  v1 = (_DWORD *)dsp_state->functions->alloc(80, 0, "../../../core_api/src/fmod_dsp_porthead.cpp");
  dsp_state->plugindata = v1;
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v1 )
  {
    functions = dsp_state->functions;
    v4 = *((_QWORD *)dsp_state->instance + 22);
    v5 = *(_DWORD *)(v4 + 1700);
    *((_QWORD *)v1 + 9) = v4;
    v6 = v5;
    v1[11] = mInputFrequency;
    v7 = (__int64)functions->alloc(
                    4 * v5 * (3 * blockLength[0] + 2) + 16,
                    0,
                    "../../../core_api/src/fmod_dsp_porthead.cpp");
    *((_QWORD *)v1 + 1) = v7;
    v8 = (void *)((v7 + 15) & 0xFFFFFFFFFFFFFFF0LL);
    v9 = 3 * blockLength[0] + 2;
    *((_QWORD *)v1 + 2) = v8;
    memset(v8, 0, v9 * 4 * v6);
    v10 = blockLength[0];
    *v1 = 0;
    v1[1] = 0;
    v1[8] = 2;
    v1[6] = 0;
    v1[7] = 2;
    v11 = 3 * v10;
    v1[12] = v10;
    v1[9] = v11;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2247d70 | Name: _ZN4FMOD8PortHead16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::PortHead::getDescriptionEx()
{
  memset(&p_outputRate, 0, sizeof(p_outputRate));
  p_outputRate.type = FMOD_DSP_PARAMETER_TYPE_INT;
  *(_DWORD *)&p_outputRate.name[8] = (_DWORD)&unk_657461;
  *(_QWORD *)p_outputRate.name = 0x522074757074754FLL;
  *(_QWORD *)p_outputRate.label = 31304;
  p_outputRate.intdesc.min = 22000;
  p_outputRate.intdesc.max = (int)&stru_17700;
  p_outputRate.description = "Device output rate. Default = 48000";
  p_outputRate.intdesc.defaultval = 48000;
  porthead_ex.mDescription = &FMOD_PortHead_Desc;
  *(&porthead_ex.mHandle + 1) = 0;
  porthead_ex.mSize = 80;
  return &porthead_ex;
}


// Address: 0x2247e00 | Name: _ZN12InstanceData16getOutputSamplesE12FMOD_UINT64P
int __fastcall InstanceData::getOutputSamples(InstanceData *const this, FMOD_UINT64P inputSamples)
{
  return (inputSamples.mLo * (this->mInvResampleSpeed.mValue >> 32)
        + this->mInvResampleSpeed.mValue * (int)inputSamples.mHi
        + 0xFFFFFFFFLL
        + ((inputSamples.mLo * (unsigned __int64)(unsigned int)this->mInvResampleSpeed.mValue) >> 32)) >> 32;
}


// Address: 0x2247e40 | Name: _ZN12InstanceData4feedEPfii
void __fastcall InstanceData::feed(InstanceData *const this, float *samples, int numsamples, int numchannels)
{
  int mInputWrite; // ecx
  int v7; // eax
  int v8; // r15d
  int v9; // r12d
  __int64 v10; // r14
  FMOD_UINT64 v11; // rdx
  int v12; // r12d
  int v13; // eax
  FMOD_UINT32_32 resamplepos; // [rsp+0h] [rbp-48h] BYREF

  if ( this->mOutputFrequency == this->mInputFrequency )
  {
    memcpy_0(&this->mInputBuffer[numchannels * this->mInputWrite], samples, 4LL * numsamples * numchannels);
    v12 = this->mInputWrite + numsamples;
    v13 = this->mInputLength + 2;
    this->mInputWrite = v12;
    if ( v12 == v13 )
      this->mInputWrite = 2;
  }
  else
  {
    if ( this->mFeedCount )
    {
      mInputWrite = this->mInputWrite;
    }
    else
    {
      (*(void (__fastcall **)(_QWORD, FMOD_UINT32_32 *))(**(_QWORD **)((char *)&stru_10F50.r_offset
                                                                     + (unsigned __int64)this->mSystem)
                                                       + 8LL))(
        *(unsigned __int64 *)((char *)&stru_10F50.r_offset + (unsigned __int64)this->mSystem),
        &resamplepos);
      v11 = resamplepos.mValue & 0xFFFFFFFFFFLL;
      this->mInputRead.mValue = 0x200000000LL;
      v11 = 0x10000000000LL - v11;
      this->mInputRead.mValue -= (unsigned int)v11;
      mInputWrite = HIDWORD(v11);
      this->mInputWrite = HIDWORD(v11);
    }
    v7 = this->mInputLength - mInputWrite;
    if ( numsamples <= v7 + 1 )
    {
      memcpy_0(&this->mInputBuffer[numchannels * mInputWrite], samples, 4LL * numsamples * numchannels);
      this->mInputWrite += numsamples;
    }
    else
    {
      v8 = v7 + 2;
      v9 = numsamples - (v7 + 2);
      v10 = (v7 + 2) * numchannels;
      memcpy_0(&this->mInputBuffer[numchannels * mInputWrite], samples, v10 * 4);
      this->mInputWrite += v8;
      if ( v9 )
      {
        memcpy_0(this->mInputBuffer, &this->mInputBuffer[numchannels * this->mInputLength], 8LL * numchannels);
        memcpy_0(&this->mInputBuffer[2 * numchannels], &samples[v10], 4LL * v9 * numchannels);
        this->mInputWrite = v9 + 2;
      }
    }
  }
  ++this->mFeedCount;
}


// Address: 0x2247ff0 | Name: _Z21FMOD_PortHead_processP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD_PortHead_process(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  float *v7; // r12

  if ( op != FMOD_DSP_PROCESS_QUERY )
  {
    v7 = *inbufferarray->buffers;
    InstanceData::feed((InstanceData *const)dsp_state->plugindata, v7, length, *inbufferarray->buffernumchannels);
    memcpy_0(*(void **)outbufferarray->buffers, v7, length * 4LL * *outbufferarray->buffernumchannels);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2248040 | Name: _ZN12InstanceData4pullEPfii
void __fastcall InstanceData::pull(InstanceData *const this, float *samples, int numsamples, int numchannels)
{
  unsigned int mInputWrite; // eax
  unsigned int v8; // eax
  unsigned __int64 v9; // r15
  FMOD_UINT64P v10; // r15
  unsigned int mBlockLength; // r14d
  int v12; // r12d
  size_t v13; // rdx
  unsigned int v14; // r12d
  int v15; // eax
  int v16; // eax
  float *v17; // rdi
  int v18; // r14d
  int OutputSamples; // eax
  FMOD_SINT64 v20; // r15
  FMOD_UINT64 v21; // rax
  __int64 v22; // rcx
  __int64 outputLen1; // [rsp+8h] [rbp-50h]
  int outputLen1a; // [rsp+8h] [rbp-50h]

  if ( this->mOutputFrequency == this->mInputFrequency )
  {
    v13 = 4LL * numchannels * numsamples;
    if ( this->mFeedCount )
    {
      memcpy_0(samples, &this->mInputBuffer[this->mInputRead.mHi * numchannels], v13);
      v14 = this->mInputRead.mHi + numsamples;
      v15 = this->mInputLength + 2;
      this->mInputRead.mHi = v14;
      if ( v14 == v15 )
        this->mInputRead.mHi = 2;
    }
    else
    {
      memset(samples, 0, v13);
    }
  }
  else
  {
    mInputWrite = this->mInputWrite;
    if ( this->mInputRead.mHi >= mInputWrite )
    {
      v8 = mInputWrite - 3;
      v9 = (unsigned __int64)(unsigned int)(this->mInputLength + 1) << 32;
    }
    else
    {
      v8 = 0;
      v9 = (unsigned __int64)(unsigned int)this->mInputWrite << 32;
    }
    v10.mValue = v9 - this->mInputRead.mValue;
    if ( numsamples > InstanceData::getOutputSamples(
                        this,
                        (FMOD_UINT64P)(((unsigned __int64)(v10.mHi + v8) << 32) | v10.mLo)) )
    {
      OutputSamples = InstanceData::getOutputSamples(
                        this,
                        (FMOD_UINT64P)((unsigned __int64)(unsigned int)this->mBlockLength << 32));
      v20 = this->mResampleSpeed.mValue * OutputSamples;
      v12 = OutputSamples;
      memset(samples, 0, OutputSamples * 4LL * numchannels);
      mBlockLength = this->mBlockLength;
      v21 = this->mInputRead.mValue + v20 - ((unsigned __int64)mBlockLength << 32);
      this->mInputRead.mValue = v21;
      v22 = (unsigned int)this->mInputWrite;
      if ( HIDWORD(v21) >= (unsigned int)v22 )
        v22 = (unsigned int)(this->mInputLength + 1);
      v10.mValue = (v22 << 32) - v21;
      outputLen1 = v12 * numchannels;
    }
    else
    {
      mBlockLength = this->mBlockLength;
      outputLen1 = 0;
      v12 = 0;
    }
    if ( (int)(mBlockLength - v12) >= InstanceData::getOutputSamples(this, v10) )
    {
      v16 = InstanceData::getOutputSamples(this, v10);
      v17 = &samples[outputLen1];
      v18 = this->mBlockLength - v12 - v16;
      outputLen1a = v16;
      FMOD_Resampler_Linear(
        v17,
        v16,
        this->mInputBuffer,
        FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0,
        &this->mInputRead,
        &this->mResampleSpeed,
        numchannels);
      if ( v18 )
      {
        this->mInputRead.mValue -= (__int64)this->mInputLength << 32;
        FMOD_Resampler_Linear(
          &samples[numchannels * (outputLen1a + v12)],
          v18,
          this->mInputBuffer,
          FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0,
          &this->mInputRead,
          &this->mResampleSpeed,
          numchannels);
      }
    }
    else
    {
      FMOD_Resampler_Linear(
        &samples[outputLen1],
        this->mBlockLength - v12,
        this->mInputBuffer,
        FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0,
        &this->mInputRead,
        &this->mResampleSpeed,
        numchannels);
    }
    ++this->mPullCount;
  }
}


// Address: 0x22482b0 | Name: _ZN4FMOD8PortHead4PullEPNS_4DSPIEPfii
FMOD_RESULT_0 __fastcall FMOD::PortHead::Pull(FMOD::DSPI *dsp, float *samples, int length, int channels)
{
  InstanceData::pull((InstanceData *const)dsp->mState.plugindata, samples, length, channels);
  return FMOD_RESULT::FMOD_OK_0;
}


