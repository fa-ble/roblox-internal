// Address: 0x21f3250 | Name: _ZN4FMOD10DSPLimiter16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPLimiter::getDescriptionEx()
{
  memset(&stru_2ADBC40, 0, sizeof(stru_2ADBC40));
  FMOD_strcpy_safe(stru_2ADBC40.name, "Release Time", 16);
  FMOD_strcpy_safe(stru_2ADBC40.label, "ms", 16);
  *(_QWORD *)&stru_2ADBC40.floatdesc.min = 0x447A00003F800000LL;
  stru_2ADBC40.description = "Time to ramp the silence to full in ms.  0.0 to 1000.0. Default = 10.0.";
  memset(&stru_2ADBBE0, 0, sizeof(stru_2ADBBE0));
  stru_2ADBC40.intdesc.defaultval = 1092616192;
  stru_2ADBC40.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  FMOD_strcpy_safe(stru_2ADBBE0.name, "Ceiling", 16);
  FMOD_strcpy_safe(stru_2ADBBE0.label, "dB", 16);
  stru_2ADBBE0.description = "Maximum level of the output signal in dB.  -12.0 to 0.0.  Default = 0.0.";
  memset(&stru_2ADBB80, 0, sizeof(stru_2ADBB80));
  *(_QWORD *)&stru_2ADBBE0.floatdesc.min = 3242196992LL;
  stru_2ADBBE0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2ADBBE0.intdesc.defaultval = 0;
  FMOD_strcpy_safe(stru_2ADBB80.name, "Maximizer Gain", 16);
  FMOD_strcpy_safe(stru_2ADBB80.label, "dB", 16);
  stru_2ADBB80.description = "Maximum amplification allowed in dB.  0.0 to 12.0.  Default = 0.0. 0.0 = no amplifaction, h"
                             "igher values allow more boost.";
  memset(&stru_2ADBB20, 0, sizeof(stru_2ADBB20));
  stru_2ADBB80.intdesc.min = 0;
  *(_QWORD *)(&stru_2ADBB80.datadesc + 1) = 0x3F80000041400000LL;
  stru_2ADBB80.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2ADBB20.type = FMOD_DSP_PARAMETER_TYPE_BOOL;
  FMOD_strcpy_safe(stru_2ADBB20.name, "Mode", 16);
  FMOD_strcpy_safe(stru_2ADBB20.label, (const char *)&uri_string, 16);
  stru_2ADBB20.intdesc.min = 0;
  stru_2ADBB20.booldesc.valuenames = 0;
  *(&stru_2ADBAE0.mHandle + 1) = 11;
  stru_2ADBAE0.mSize = 680;
  stru_2ADBB20.description = "Channel processing mode.  true or false.  Default = false.  false = Independent (limiter pe"
                             "r channel), true = Linked";
  stru_2ADBAE0.mDescription = &stru_286B540;
  return &stru_2ADBAE0;
}


// Address: 0x21f3480 | Name: _ZN4FMOD10DSPLimiter14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::createInternal(FMOD::DSPLimiter *const this)
{
  double v1; // xmm1_8
  __int64 i; // rax
  __int64 v3; // rax
  __int64 v4; // r12
  int v5; // ebp
  FMOD_RESULT_0 result; // eax
  _DWORD *v7; // rcx

  for ( i = 0; i != 128; i += 4 )
    *(_DWORD *)((char *)this + i + 528) = 1065353216;
  if ( this != (FMOD::DSPLimiter *const)-656LL )
    *((_DWORD *)this + 164) = *(_DWORD *)(*((_QWORD *)this + 22) + 1696LL);
  v3 = *((_QWORD *)this + 30);
  v4 = 0;
  v5 = 0;
  if ( *(int *)(v3 + 96) > 0 )
  {
    while ( 1 )
    {
      v7 = *(_DWORD **)(*(_QWORD *)(v3 + 104) + v4);
      if ( !*v7 )
        break;
      if ( *v7 == 2 )
      {
        result = FMOD::DSPI::setParameterBool((FMOD::DSPI *const)this, v5, v7[12] != 0);
        if ( result )
          return result;
LABEL_9:
        v3 = *((_QWORD *)this + 30);
      }
      ++v5;
      v4 += 8;
      if ( *(_DWORD *)(v3 + 96) <= v5 )
        return FMOD_RESULT::FMOD_OK_0;
    }
    result = FMOD::DSPI::setParameterFloat((FMOD::DSPI *const)this, v5, (__m128i)(unsigned int)v7[14], v1);
    if ( result )
      return result;
    goto LABEL_9;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f3550 | Name: _ZN4FMOD10DSPLimiter14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLimiter::createInternal((FMOD::DSPLimiter *const)dsp_state->instance);
}


// Address: 0x21f3560 | Name: _ZN4FMOD10DSPLimiter15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::releaseInternal(FMOD::DSPLimiter *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f3570 | Name: _ZN4FMOD10DSPLimiter15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLimiter::releaseInternal((FMOD::DSPLimiter *const)dsp_state->instance);
}


// Address: 0x21f3580 | Name: _ZN4FMOD10DSPLimiter13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::resetInternal(FMOD::DSPLimiter *const this)
{
  __int64 i; // rax

  for ( i = 0; i != 128; i += 4 )
    *(_DWORD *)((char *)this + i + 528) = 1065353216;
  LOBYTE(i) = 0;
  return (int)i;
}


// Address: 0x21f35b0 | Name: _ZN4FMOD10DSPLimiter13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPLimiter::resetInternal((FMOD::DSPLimiter *const)dsp_state->instance);
}


// Address: 0x21f35c0 | Name: _ZN4FMOD10DSPLimiter12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::readInternal(
        FMOD::DSPLimiter *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  int v6; // ebp
  float v7; // xmm3_4
  float v8; // xmm4_4
  int v9; // ebx
  int i; // r12d
  int v11; // eax
  float v12; // xmm0_4
  __int64 v13; // r11
  __int64 v14; // r9
  float *v15; // r10
  float v16; // xmm1_4
  float v17; // xmm2_4
  float *v18; // r9

  v6 = *((_DWORD *)this + 169);
  v7 = *((float *)this + 167);
  v8 = *((float *)this + 166);
  if ( inbuffer && length )
  {
    v9 = 0;
    for ( i = 0; i != length; ++i )
    {
      if ( v6 )
        *((float *)this + 132) = *((float *)this + 132) * *((float *)this + 168);
      v11 = 0;
      if ( inchannels )
      {
        do
        {
          if ( v6 )
          {
            v12 = *((float *)this + 132);
            v13 = 0;
          }
          else
          {
            v13 = v11;
            v18 = (float *)((char *)this + 4 * v11);
            v12 = v18[132] * *((float *)this + 168);
            v18[132] = v12;
          }
          v14 = (unsigned int)(v9 + v11);
          v15 = &inbuffer[v14];
          v16 = *v15;
          v17 = fabs(*v15);
          if ( v17 > v12 )
          {
            *((float *)this + v13 + 132) = v17;
            v12 = v17;
            v16 = *v15;
          }
          ++v11;
          outbuffer[v14] = fminf(v7, v8 / v12) * v16;
        }
        while ( inchannels != v11 );
      }
      v9 += inchannels;
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f36d0 | Name: _ZN4FMOD10DSPLimiter12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPLimiter::readInternal(
           (FMOD::DSPLimiter *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x21f36e0 | Name: _ZN4FMOD10DSPLimiter25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPLimiter::setParameterFloatInternal(
        FMOD::DSPLimiter *const this,
        int index,
        float a3,
        float value)
{
  __int64 result; // rax
  float v5; // xmm0_4
  float v6; // xmm0_4

  if ( index == 1 )
  {
    if ( a3 > -80.0 )
      v6 = powf(10.0, a3 / 20.0);
    else
      v6 = 0.0;
    *((float *)this + 166) = v6;
    a3 = *((float *)this + 165);
  }
  else if ( index == 2 )
  {
    if ( a3 > -80.0 )
      v5 = powf(10.0, a3 / 20.0);
    else
      v5 = 0.0;
    *((float *)this + 167) = v5;
    a3 = *((float *)this + 165);
  }
  else
  {
    result = 31;
    if ( index )
      return result;
    *((float *)this + 165) = a3;
  }
  *((float *)this + 168) = (float)(a3 / 1000.0)
                         / (float)((float)(1.0 / (float)*((int *)this + 164)) + (float)(a3 / 1000.0));
  return 0;
}


// Address: 0x21f37e0 | Name: _ZN4FMOD10DSPLimiter25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPLimiter::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPLimiter::setParameterFloatInternal((FMOD::DSPLimiter *const)dsp_state->instance, index, a3, value);
}


// Address: 0x21f37f0 | Name: _ZN4FMOD10DSPLimiter25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::getParameterFloatInternal(
        FMOD::DSPLimiter *const this,
        int index,
        float *value,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax
  double v5; // xmm0_8
  float v6; // xmm0_4
  float v7; // xmm0_4
  float v8; // xmm0_4
  float v9; // xmm0_4
  float v10; // xmm0_4
  float v11; // xmm0_4
  char *v12; // [rsp+0h] [rbp-28h]
  float *valuea; // [rsp+8h] [rbp-20h]
  float *valueb; // [rsp+8h] [rbp-20h]
  char *valuestra; // [rsp+10h] [rbp-18h]
  char *valuestrb; // [rsp+10h] [rbp-18h]

  if ( index == 1 )
  {
    v6 = *((float *)this + 166);
    if ( v6 > 0.0 )
    {
      valuestra = valuestr;
      valuea = value;
      v7 = log10f(v6) * 20.0;
      value = valuea;
      valuestr = valuestra;
    }
    else
    {
      v7 = -80.0;
    }
    *value = v7;
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    v8 = *((float *)this + 166);
    if ( v8 > 0.0 )
    {
LABEL_17:
      v12 = valuestr;
      v11 = log10f(v8);
      valuestr = v12;
      v5 = (float)(v11 * 20.0);
      goto LABEL_11;
    }
LABEL_10:
    v5 = -80.0;
    goto LABEL_11;
  }
  if ( index == 2 )
  {
    v9 = *((float *)this + 167);
    if ( v9 > 0.0 )
    {
      valuestrb = valuestr;
      valueb = value;
      v10 = log10f(v9) * 20.0;
      value = valueb;
      valuestr = valuestrb;
    }
    else
    {
      v10 = -80.0;
    }
    *value = v10;
    if ( !valuestr )
      return FMOD_RESULT::FMOD_OK_0;
    v8 = *((float *)this + 167);
    if ( v8 > 0.0 )
      goto LABEL_17;
    goto LABEL_10;
  }
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index )
    return result;
  *value = *((float *)this + 165);
  if ( valuestr )
  {
    v5 = *((float *)this + 165);
LABEL_11:
    sprintf(valuestr, "%.02f", v5);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f3960 | Name: _ZN4FMOD10DSPLimiter25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPLimiter::getParameterFloatInternal(
           (FMOD::DSPLimiter *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


// Address: 0x21f3970 | Name: _ZN4FMOD10DSPLimiter24setParameterBoolInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::setParameterBoolInternal(FMOD::DSPLimiter *const this, int index, int value)
{
  if ( index != 3 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *((_DWORD *)this + 169) = value != 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f3990 | Name: _ZN4FMOD10DSPLimiter24setParameterBoolCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::setParameterBoolCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        FMOD_BOOL value)
{
  return FMOD::DSPLimiter::setParameterBoolInternal((FMOD::DSPLimiter *const)dsp_state->instance, index, value);
}


// Address: 0x21f39a0 | Name: _ZN4FMOD10DSPLimiter24getParameterBoolInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::getParameterBoolInternal(
        FMOD::DSPLimiter *const this,
        int index,
        FMOD_BOOL *value,
        char *valuestr)
{
  const char *v5; // rsi

  if ( index != 3 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *value = *((_DWORD *)this + 169);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  v5 = "Linked";
  if ( !*((_DWORD *)this + 169) )
    v5 = "Independent";
  strcpy(valuestr, v5);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f3a00 | Name: _ZN4FMOD10DSPLimiter24getParameterBoolCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPLimiter::getParameterBoolCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        FMOD_BOOL *value,
        char *valuestr)
{
  return FMOD::DSPLimiter::getParameterBoolInternal(
           (FMOD::DSPLimiter *const)dsp_state->instance,
           index,
           value,
           valuestr);
}


