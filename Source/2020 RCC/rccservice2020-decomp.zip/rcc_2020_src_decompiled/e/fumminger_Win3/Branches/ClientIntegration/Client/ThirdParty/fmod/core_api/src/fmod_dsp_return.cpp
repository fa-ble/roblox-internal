// Address: 0x220cd50 | Name: _ZN4FMOD9DSPReturn22shouldIProcessCallbackEP14FMOD_DSP_STATEijji16FMOD_SPEAKERMODE
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::shouldIProcessCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD_BOOL inputsidle,
        unsigned int length,
        FMOD_CHANNELMASK a4,
        int inchannels,
        FMOD_SPEAKERMODE_0 speakermode)
{
  _BYTE *instance; // rax

  instance = dsp_state->instance;
  if ( *((_QWORD *)dsp_state->instance + 1) == *((_QWORD *)dsp_state->instance + 71) )
    return instance[576] == 0 ? 0xB : 0;
  else
    return instance[577] == 0 ? 0xB : 0;
}


// Address: 0x220cd80 | Name: _ZN4FMOD9DSPReturn16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPReturn::getDescriptionEx()
{
  memset(&stru_2AF6D00, 0, sizeof(stru_2AF6D00));
  stru_2AF6D00.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2AF6D00.name, "ID", 16);
  FMOD_strcpy_safe(stru_2AF6D00.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF6D00.floatdesc.min = 0xF4240FFFFFFFFLL;
  stru_2AF6D00.description = "ID of this Return DSP (read-only). Used for connecting sends.";
  memset(&stru_2AF6CA0, 0, sizeof(stru_2AF6CA0));
  *(_OWORD *)(&stru_2AF6D00.datadesc + 2) = 0xFFFFFFFF;
  stru_2AF6CA0.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2AF6CA0.name, "Input Speaker Mode", 16);
  FMOD_strcpy_safe(stru_2AF6CA0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF6CA0.floatdesc.min = 0x700000000LL;
  stru_2AF6CA0.description = "Input Speaker Mode";
  *(_OWORD *)(&stru_2AF6CA0.datadesc + 2) = 0u;
  *(&stru_2AF6C60.mHandle + 1) = 25;
  stru_2AF6C60.mSize = 624;
  stru_2AF6C60.mDescription = &stru_286C5E0;
  stru_2AF6C60.mCommand = FMOD::DSPReturn::commandCallback;
  stru_2AF6C60.mCommandMask = 129;
  return &stru_2AF6C60;
}


// Address: 0x220cef0 | Name: _ZN4FMOD11ReturnTable5closeEv
FMOD_RESULT_0 __fastcall FMOD::ReturnTable::close(FMOD::ReturnTable *const this)
{
  bool v1; // zf
  bool v2; // cc
  __int64 mSize; // rdi
  bool v5; // cc
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v7; // rsi
  unsigned int *mData; // rsi

  v1 = this->mMap.mBuckets.mCapacity == 0;
  v2 = this->mMap.mBuckets.mCapacity <= 0;
  this->mMap.mBuckets.mSize = 0;
  if ( !v1 )
  {
    if ( !v2 )
    {
      mData = this->mMap.mBuckets.mData;
      if ( mData )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mData, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mMap.mBuckets.mData = 0;
    this->mMap.mBuckets.mCapacity = 0;
  }
  mSize = this->mMap.mNodes.mSize;
  if ( (int)mSize < 0 )
    memset(&this->mMap.mNodes.mData[mSize], 0, 16LL * -this->mMap.mNodes.mSize);
  v1 = this->mMap.mNodes.mCapacity == 0;
  v5 = this->mMap.mNodes.mCapacity <= 0;
  this->mMap.mNodes.mSize = 0;
  if ( !v1 )
  {
    if ( !v5 )
    {
      v7 = this->mMap.mNodes.mData;
      if ( v7 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v7, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mMap.mNodes.mData = 0;
    this->mMap.mNodes.mCapacity = 0;
  }
  this->mMap.mFreeList = -1;
  this->mMap.mNodeCount = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220d0e0 | Name: _ZN4FMOD9DSPReturn14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::createInternal(FMOD::DSPReturn *const this)
{
  int v1; // edx
  FMOD::SystemI *v3; // rdi
  int v4; // eax
  FMOD_RESULT_0 v5; // ebp
  FMOD::DSPQueueCmd_CreateReturn *v7; // rsi
  FMOD::SystemI *v8; // rdi
  FMOD_RESULT_0 v9; // eax
  FMOD::DSPQueueCmd_CreateReturn *cmd; // [rsp+8h] [rbp-20h] BYREF

  v1 = 0;
  *((_QWORD *)this + 75) = (char *)this + 592;
  *((_QWORD *)this + 74) = (char *)this + 592;
  *((_QWORD *)this + 76) = 0;
  v3 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  v4 = *(_DWORD *)((char *)&stru_125E8.r_offset + (_QWORD)v3);
  if ( v4 != 0x7FFFFFFF )
    v1 = v4 + 1;
  *(_DWORD *)((char *)&stru_125E8.r_offset + (_QWORD)v3) = v1;
  *((_DWORD *)this + 154) = v4;
  *((_DWORD *)this + 138) = 0;
  *((_DWORD *)this + 139) = 0;
  *((_DWORD *)this + 140) = 0;
  *((_QWORD *)this + 67) = 0;
  *((_QWORD *)this + 68) = 0;
  *((_QWORD *)this + 71) = 0;
  *((_DWORD *)this + 155) = 1065353216;
  *((_DWORD *)this + 146) = 0;
  v5 = FMOD::SystemI::lockDSPQueueCmd(v3, (void **)&cmd, 16, 1);
  if ( v5 )
    return v5;
  v7 = cmd;
  v8 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  cmd->mThis = (FMOD::DSPI *)this;
  *(_BYTE *)&v7->FMOD::DSPQueueCmd = 8;
  v9 = FMOD::SystemI::unlockDSPQueueCmd(v8, v7, 1);
  if ( v9 )
    return v9;
  return v5;
}


// Address: 0x220d1e0 | Name: _ZN4FMOD9DSPReturn14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPReturn::createInternal((FMOD::DSPReturn *const)dsp_state->instance);
}


// Address: 0x220d1f0 | Name: _ZN4FMOD9DSPReturn15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::releaseInternal(FMOD::DSPReturn *const this)
{
  void *v1; // rsi

  v1 = (void *)*((_QWORD *)this + 66);
  if ( v1 )
  {
    FMOD::MemPool::alignedFree(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_dsp_return.cpp", 229);
    *((_QWORD *)this + 66) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220d240 | Name: _ZN4FMOD9DSPReturn15releaseCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::releaseCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPReturn::releaseInternal((FMOD::DSPReturn *const)dsp_state->instance);
}


// Address: 0x220d2d0 | Name: _ZN4FMOD9DSPReturn13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::resetInternal(FMOD::DSPReturn *const this)
{
  *((_BYTE *)this + 577) = 0;
  *((_BYTE *)this + 576) = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220d2f0 | Name: _ZN4FMOD9DSPReturn13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPReturn::resetInternal((FMOD::DSPReturn *const)dsp_state->instance);
}


// Address: 0x220d300 | Name: _ZN4FMOD9DSPReturn12readInternalEPfS1_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::readInternal(
        FMOD::DSPReturn *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  FMOD_RESULT_0 result; // eax
  signed int v7; // ecx
  __int64 v8; // rax
  const void *v10; // rsi
  char v11; // dl

  if ( !inbuffer )
    return FMOD_RESULT::FMOD_OK_0;
  *outchannels = *((_DWORD *)this + 139);
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  v7 = *((_DWORD *)this + 139) * length;
  if ( v7 <= *((_DWORD *)this + 140) )
  {
    v8 = *((_QWORD *)this + 1);
    v10 = (const void *)*((_QWORD *)this + 68);
    if ( v8 == *((_QWORD *)this + 71) )
    {
      v10 = (const void *)*((_QWORD *)this + 67);
    }
    else
    {
      *((_QWORD *)this + 68) = *((_QWORD *)this + 67);
      v11 = *((_BYTE *)this + 577);
      *((_QWORD *)this + 67) = v10;
      *((_BYTE *)this + 577) = 0;
      *((_QWORD *)this + 71) = v8;
      *((_BYTE *)this + 576) = v11;
    }
    memcpy_0(outbuffer, v10, 4LL * v7);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x220d3b0 | Name: _ZN4FMOD9DSPReturn12readCallbackEP14FMOD_DSP_STATEPfS3_jiPi
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::readCallback(
        FMOD_DSP_STATE *dsp_state,
        float *inbuffer,
        float *outbuffer,
        unsigned int length,
        int inchannels,
        int *outchannels)
{
  return FMOD::DSPReturn::readInternal(
           (FMOD::DSPReturn *const)dsp_state->instance,
           inbuffer,
           outbuffer,
           length,
           inchannels,
           outchannels);
}


// Address: 0x220d3c0 | Name: _ZN4FMOD9DSPReturn23setParameterIntInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::setParameterIntInternal(FMOD::DSPReturn *const this, int index, int value)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  if ( index )
  {
    LOBYTE(result) = 0;
    if ( index == 1 )
    {
      LOBYTE(result) = 31;
      if ( value != 1 )
      {
        *((_DWORD *)this + 146) = value;
        LOBYTE(result) = 0;
      }
    }
  }
  return result;
}


// Address: 0x220d3f0 | Name: _ZN4FMOD9DSPReturn23setParameterIntCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::setParameterIntCallback(FMOD_DSP_STATE *dsp_state, int index, int value)
{
  return FMOD::DSPReturn::setParameterIntInternal((FMOD::DSPReturn *const)dsp_state->instance, index, value);
}


// Address: 0x220d400 | Name: _ZN4FMOD9DSPReturn23getParameterIntInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::getParameterIntInternal(
        FMOD::DSPReturn *const this,
        int index,
        int *value,
        char *valuestr)
{
  if ( !index )
  {
    *value = *((_DWORD *)this + 154);
    if ( valuestr )
      sprintf(valuestr, "%d", *((_DWORD *)this + 154));
    return FMOD_RESULT::FMOD_OK_0;
  }
  if ( index != 1 )
    return FMOD_RESULT::FMOD_OK_0;
  *value = *((_DWORD *)this + 146);
  if ( !valuestr )
    return FMOD_RESULT::FMOD_OK_0;
  sprintf(valuestr, "%d", *((_DWORD *)this + 146));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220d470 | Name: _ZN4FMOD9DSPReturn23getParameterIntCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::getParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int *value,
        char *valuestr)
{
  return FMOD::DSPReturn::getParameterIntInternal((FMOD::DSPReturn *const)dsp_state->instance, index, value, valuestr);
}


// Address: 0x220d480 | Name: _ZN4FMOD9DSPReturn15commandInternalEj
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::commandInternal(
        FMOD::DSPReturn *const this,
        FMOD::FMOD_DSP_COMMAND_TYPE type)
{
  FMOD_RESULT_0 result; // eax
  char *v4; // rax
  char *v5; // rbp
  FMOD::DSPSend *v6; // rdi
  FMOD_SPEAKERMODE_0 v7; // esi
  FMOD::SystemI *v8; // rdi
  void *v9; // rsi
  unsigned int v10; // eax
  char *v11; // rax
  __int64 v12; // rdx
  unsigned int bufferlength[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  if ( type == 1 )
  {
    v7 = *((_DWORD *)this + 146);
    if ( *((_DWORD *)this + 138) != v7 || (result = FMOD_RESULT::FMOD_OK_0, !*((_DWORD *)this + 140)) )
    {
      v8 = (FMOD::SystemI *)*((_QWORD *)this + 22);
      *((_DWORD *)this + 138) = v7;
      result = FMOD::SystemI::getSpeakerModeChannels(v8, v7, (int *)this + 139);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD::SystemI::getDSPBufferSize(*((FMOD::SystemI *const *)this + 22), bufferlength, 0);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          v9 = (void *)*((_QWORD *)this + 66);
          v10 = bufferlength[0] * *((_DWORD *)this + 139);
          *((_DWORD *)this + 140) = v10;
          if ( v9 )
          {
            FMOD::MemPool::alignedFree(
              off_286F358->gSystemMemPool,
              v9,
              "../../../core_api/src/fmod_dsp_return.cpp",
              425);
            v10 = *((_DWORD *)this + 140);
          }
          v11 = (char *)FMOD::MemPool::alignedCalloc(
                          off_286F358->gSystemMemPool,
                          8 * v10,
                          16,
                          "../../../core_api/src/fmod_dsp_return.cpp",
                          428,
                          0);
          *((_QWORD *)this + 66) = v11;
          if ( v11 )
          {
            v12 = *((int *)this + 140);
            *((_QWORD *)this + 67) = v11;
            *((_BYTE *)this + 576) = 0;
            *((_BYTE *)this + 577) = 0;
            *((_QWORD *)this + 68) = &v11[4 * v12];
            return FMOD_RESULT::FMOD_OK_0;
          }
          else
          {
            return FMOD_RESULT::FMOD_ERR_MEMORY_0;
          }
        }
      }
    }
  }
  else
  {
    result = FMOD_RESULT::FMOD_OK_0;
    if ( type == 128 )
    {
      v4 = (char *)*((_QWORD *)this + 74);
      v5 = (char *)this + 592;
      if ( v4 == (char *)this + 592 )
      {
LABEL_19:
        result = FMOD::ReturnTable::remove(
                   (FMOD::ReturnTable *const)(*((_QWORD *)this + 22) + 75232LL),
                   *((_DWORD *)this + 154));
        if ( result == FMOD_RESULT::FMOD_OK_0 )
          *((_DWORD *)this + 154) = -1;
      }
      else
      {
        while ( 1 )
        {
          v6 = (FMOD::DSPSend *)*((_QWORD *)v4 + 2);
          if ( !v6 )
            return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          result = FMOD::DSPSend::disconnectReturn(v6);
          if ( result )
            return result;
          v4 = (char *)*((_QWORD *)this + 74);
          if ( v4 == v5 )
            goto LABEL_19;
        }
      }
    }
  }
  return result;
}


// Address: 0x220d650 | Name: _ZN4FMOD9DSPReturn15commandCallbackEP14FMOD_DSP_STATEjPvS3_
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::commandCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *commanddata1,
        void *commanddata2)
{
  return FMOD::DSPReturn::commandInternal((FMOD::DSPReturn *const)dsp_state->instance, type);
}


// Address: 0x220d740 | Name: _ZN4FMOD11ReturnTable6insertEiPNS_9DSPReturnE
FMOD_RESULT_0 __fastcall FMOD::ReturnTable::insert(FMOD::ReturnTable *const this, int id, FMOD::DSPReturn *dsp)
{
  FMOD_RESULT_0 result; // eax
  int mNodeCount; // edi
  int v7; // ecx
  unsigned int *v8; // r12
  __int64 v9; // rcx
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v10; // rsi
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v11; // rcx
  __int64 v12; // rax
  unsigned int mFreeList; // eax
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v14; // rcx
  FMOD_RESULT_0 v15; // r12d
  __int64 v16; // rax
  int mSize; // r9d
  __int64 i; // rax
  int v19; // ecx
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // r8
  __int64 v21; // rdi
  unsigned int *p_next; // rsi
  __int64 next; // rcx
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v24; // rsi
  int v25; // r13d
  int v26; // edx
  int v27; // eax
  int v28; // ebx
  int v29; // eax
  __int64 v30; // rax
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v31; // rax
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v32; // rax
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v33; // r14
  __int64 v34; // rdx
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v35; // rsi
  FMOD::DSPReturn *dspa; // [rsp+8h] [rbp-50h]
  unsigned __int64 ida; // [rsp+10h] [rbp-48h]
  FMOD::DSPReturn *v38; // [rsp+18h] [rbp-40h]

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  mNodeCount = this->mMap.mNodeCount;
  if ( mNodeCount == -1 )
    return result;
  v7 = abs32(this->mMap.mNodes.mCapacity);
  if ( v7 != this->mMap.mBuckets.mSize )
    return result;
  if ( mNodeCount == v7 )
  {
    v15 = 2 * mNodeCount;
    LOBYTE(result) = 4;
    if ( 2 * mNodeCount < 4 )
      v15 = result;
    if ( mNodeCount >= v15 || mNodeCount != this->mMap.mNodes.mSize || this->mMap.mFreeList != -1 )
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    dspa = dsp;
    result = FMOD::DynamicArray<FMOD::HashMap<int,FMOD::DSPReturn *,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::AlignedAllocator<1>>::reserve(
               &this->mMap.mNodes,
               v15);
    if ( result )
      return result;
    result = FMOD::DynamicArray<unsigned int,FMOD::ArrayConstruct_Fast_Uninit,FMOD::AlignedAllocator<1>>::resize(
               &this->mMap.mBuckets,
               v15);
    if ( result )
      return result;
    dsp = dspa;
    v16 = 0;
    do
      this->mMap.mBuckets.mData[v16++] = -1;
    while ( v15 > (int)v16 );
    mSize = this->mMap.mNodes.mSize;
    for ( i = 0; mSize > (int)i; ++i )
    {
      v19 = this->mMap.mBuckets.mSize;
      mData = this->mMap.mNodes.mData;
      v21 = i;
      if ( !v19 )
        return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      p_next = &this->mMap.mBuckets.mData[mData[i].key & (v19 - 1)];
      next = (int)*p_next;
      if ( (_DWORD)next != -1 )
      {
        do
        {
          v24 = &mData[next];
          next = (int)v24->next;
        }
        while ( (_DWORD)next != -1 );
        p_next = &v24->next;
      }
      *p_next = i;
      this->mMap.mNodes.mData[v21].next = -1;
    }
    v7 = this->mMap.mBuckets.mSize;
  }
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( !v7 )
    return result;
  v8 = &this->mMap.mBuckets.mData[id & (v7 - 1)];
  v9 = (int)*v8;
  if ( (_DWORD)v9 != -1 )
  {
    v10 = this->mMap.mNodes.mData;
    v11 = &v10[v9];
    if ( v11->key == id )
      return result;
    while ( 1 )
    {
      v12 = (int)v11->next;
      if ( (_DWORD)v12 == -1 )
        break;
      v11 = &v10[v12];
      if ( v11->key == id )
        return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    }
    v8 = &v11->next;
  }
  mFreeList = this->mMap.mFreeList;
  if ( mFreeList != -1 )
  {
    v14 = &this->mMap.mNodes.mData[mFreeList];
    this->mMap.mFreeList = v14->next;
    v14->next = -1;
    v14->key = id;
    v14->value = dsp;
    *v8 = mFreeList;
LABEL_14:
    ++this->mMap.mNodeCount;
    return FMOD_RESULT::FMOD_OK_0;
  }
  v25 = this->mMap.mNodes.mSize;
  v38 = dsp;
  ida = (unsigned int)id | 0xFFFFFFFF00000000LL;
  v26 = v25 + 1;
  v27 = abs32(this->mMap.mNodes.mCapacity);
  if ( v25 + 1 <= v27 )
  {
    v30 = v25;
LABEL_41:
    v31 = &this->mMap.mNodes.mData[v30];
    *(_QWORD *)&v31->key = ida;
    v31->value = v38;
    ++this->mMap.mNodes.mSize;
    *v8 = v25;
    goto LABEL_14;
  }
  v28 = 4;
  v29 = (int)(float)((float)v27 * 1.5);
  if ( v29 >= v26 )
    v26 = v29;
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( v26 > 3 )
    v28 = v26;
  if ( v25 <= v28 )
  {
    if ( (unsigned int)(16 * v28 - 1) > 0x3FFFFFFE )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v32 = (FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *)FMOD::MemPool::alloc(off_286F358->gSystemMemPool, 16 * v28, "../../../core_api/src/fmod_memory.h", 232, 0, 0);
    v33 = v32;
    if ( !v32 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v34 = this->mMap.mNodes.mSize;
    if ( (_DWORD)v34 )
      memcpy_0(v32, this->mMap.mNodes.mData, 16 * v34);
    if ( this->mMap.mNodes.mCapacity > 0 )
    {
      v35 = this->mMap.mNodes.mData;
      if ( v35 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v35, "../../../core_api/src/fmod_memory.h", 244);
    }
    this->mMap.mNodes.mData = v33;
    this->mMap.mNodes.mCapacity = v28;
    v30 = this->mMap.mNodes.mSize;
    goto LABEL_41;
  }
  return result;
}


// Address: 0x220da40 | Name: _ZN4FMOD9DSPReturn11mixerCreateEv
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::mixerCreate(FMOD::DSPReturn *const this)
{
  return FMOD::ReturnTable::insert(
           (FMOD::ReturnTable *const)(*((_QWORD *)this + 22) + 75232LL),
           *((_DWORD *)this + 154),
           this);
}


// Address: 0x220da60 | Name: _ZN4FMOD11ReturnTable4initEPNS_7SystemIE
FMOD_RESULT_0 __fastcall FMOD::ReturnTable::init(FMOD::ReturnTable *const this, FMOD::SystemI *system)
{
  FMOD_RESULT_0 result; // eax
  int mSize; // edx
  __int64 i; // rax
  int v6; // r8d
  __int64 j; // rsi
  int v8; // eax
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *mData; // rcx
  __int64 v10; // rdi
  unsigned int *p_next; // rdx
  __int64 next; // rax
  FMOD::HashMap<int,FMOD::DSPReturn*,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn*>,FMOD::HashMapDefaultHash,unsigned int>::Node *v13; // rdx

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  mSize = this->mMap.mBuckets.mSize;
  this->mSystem = system;
  this->mNextID = 0;
  if ( !mSize )
  {
    if ( this->mMap.mNodes.mSize || this->mMap.mFreeList != -1 )
    {
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    }
    else
    {
      result = FMOD::DynamicArray<FMOD::HashMap<int,FMOD::DSPReturn *,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::HashMapDefaultHash,unsigned int>::Node,FMOD::ArrayConstruct_Auto<FMOD::DSPReturn *>,FMOD::AlignedAllocator<1>>::reserve(
                 &this->mMap.mNodes,
                 64);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD::DynamicArray<unsigned int,FMOD::ArrayConstruct_Fast_Uninit,FMOD::AlignedAllocator<1>>::resize(
                   &this->mMap.mBuckets,
                   64);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          for ( i = 0; i != 64; ++i )
            this->mMap.mBuckets.mData[i] = -1;
          v6 = this->mMap.mNodes.mSize;
          for ( j = 0; v6 > (int)j; ++j )
          {
            v8 = this->mMap.mBuckets.mSize;
            mData = this->mMap.mNodes.mData;
            if ( !v8 )
              return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
            v10 = j;
            p_next = &this->mMap.mBuckets.mData[mData[j].key & (v8 - 1)];
            next = (int)*p_next;
            if ( (_DWORD)next != -1 )
            {
              do
              {
                v13 = &mData[next];
                next = (int)v13->next;
              }
              while ( (_DWORD)next != -1 );
              p_next = &v13->next;
            }
            *p_next = j;
            this->mMap.mNodes.mData[v10].next = -1;
          }
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


