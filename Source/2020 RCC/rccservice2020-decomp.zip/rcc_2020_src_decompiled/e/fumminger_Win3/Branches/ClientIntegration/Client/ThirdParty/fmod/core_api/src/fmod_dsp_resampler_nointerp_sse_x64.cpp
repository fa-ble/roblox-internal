// Address: 0x222fd40 | Name: FMOD_Resampler_NoInterp_PCM16_Mono_SSE_X64
void __fastcall FMOD_Resampler_NoInterp_PCM16_Mono_SSE_X64(
        float *dst,
        int dstlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  FMOD_SINT64 mValue; // rax
  FMOD_SINT64 v6; // r9
  __m128i v7; // xmm0
  __m128i v8; // xmm4
  __m128i v9; // xmm7
  __m128i v10; // xmm4
  __m128i v11; // xmm3
  __m128i v12; // xmm2
  float *v13; // r9
  int v14; // eax
  __m128i v15; // xmm1
  __m128i v16; // xmm0
  __m128i v17; // xmm0
  __m128i v18; // xmm1
  __m128i v19; // xmm0
  __m128i v20; // xmm1
  __m128i v21; // xmm0
  __m128i v22; // xmm5
  __int64 v23; // r9
  int v24; // eax
  int v25; // esi
  FMOD_SINT64 v26; // r8
  __m128i v27; // [rsp+0h] [rbp-20h] BYREF
  __int32 v28; // [rsp+10h] [rbp-10h]
  __int32 v29; // [rsp+14h] [rbp-Ch]

  mValue = speed->mValue;
  v6 = 2 * speed->mValue;
  v7 = _mm_shuffle_epi32(_mm_loadl_epi64((const __m128i *)position), 68);
  v27.m128i_i64[0] = 4 * speed->mValue;
  v27.m128i_i64[1] = v6;
  v8 = _mm_loadl_epi64(&v27);
  v27.m128i_i64[0] = mValue;
  v9 = _mm_loadl_epi64(&v27);
  v27.m128i_i64[0] = v6 + mValue;
  v10 = _mm_shuffle_epi32(v8, 68);
  v11 = _mm_add_epi64((__m128i)_mm_loadh_ps((const double *)v27.m128i_i64), v7);
  v12 = _mm_add_epi64(_mm_unpacklo_epi64((__m128i)0LL, _mm_move_epi64(v9)), v7);
  if ( dstlength - 3 <= 0 )
  {
    v24 = 0;
  }
  else
  {
    v13 = dst;
    v14 = 0;
    do
    {
      v15 = _mm_shuffle_epi32(v11, 13);
      v14 += 4;
      v13 += 4;
      v16 = _mm_shuffle_epi32(v12, 13);
      v11 = _mm_add_epi64(v11, v10);
      v12 = _mm_add_epi64(v12, v10);
      v17 = _mm_unpacklo_epi64(v16, v15);
      v27.m128i_i32[0] = _mm_cvtsi128_si32(v17);
      v27.m128i_i32[2] = v17.m128i_i32[1];
      v29 = v17.m128i_i32[3];
      v28 = v17.m128i_i32[2];
      v18 = _mm_cvtsi32_si128(*((__int16 *)src + v17.m128i_i32[2]));
      v19 = _mm_cvtsi32_si128(*((__int16 *)src + v17.m128i_i32[3]));
      v28 = *((__int16 *)src + v29);
      v20 = _mm_unpacklo_epi32(v18, v19);
      v21 = _mm_cvtsi32_si128(*((__int16 *)src + v27.m128i_i32[0]));
      v22 = _mm_cvtsi32_si128(*((__int16 *)src + v27.m128i_i32[2]));
      v27.m128i_i32[0] = *((__int16 *)src + v27.m128i_i32[2]);
      *((__m128 *)v13 - 1) = _mm_mul_ps(
                               _mm_cvtepi32_ps(_mm_unpacklo_epi64(_mm_unpacklo_epi32(v21, v22), v20)),
                               *(__m128 *)scale16data_1);
    }
    while ( v14 < dstlength - 3 );
    v23 = (unsigned int)(dstlength - 4) >> 2;
    v24 = 4 * v23 + 4;
    dst += 4 * v23 + 4;
  }
  v25 = dstlength - v24;
  position->mValue = *(FMOD_UINT64 *)v12.m128i_i8;
  if ( v25 )
  {
    v26 = speed->mValue;
    do
    {
      *dst++ = (float)*((__int16 *)src + position->mHi) * 0.000030517578;
      position->mValue += v26;
      --v25;
    }
    while ( v25 );
  }
}


// Address: 0x222fed0 | Name: FMOD_Resampler_NoInterp_PCM16_Stereo_SSE_X64
void __fastcall FMOD_Resampler_NoInterp_PCM16_Stereo_SSE_X64(
        float *dst,
        int dstlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  __m128i v5; // xmm0
  __m128i v6; // xmm1
  __m128i v7; // xmm2
  __m128i v8; // xmm5
  float *v9; // r9
  int v10; // eax
  __m128i v11; // xmm0
  __int64 v12; // r10
  __m128i v13; // xmm1
  __m128i v14; // xmm0
  __m128i v15; // xmm3
  __int64 v16; // r9
  int v17; // eax
  int v18; // esi
  FMOD_SINT64 mValue; // r9
  __int64 v20; // rax
  float v21; // xmm0_4
  __m128i v22; // [rsp+0h] [rbp-28h] BYREF

  v5 = _mm_loadl_epi64((const __m128i *)position);
  v6 = _mm_loadl_epi64((const __m128i *)speed);
  v22.m128i_i64[0] = 2 * speed->mValue;
  v7 = _mm_add_epi64(_mm_unpacklo_epi64((__m128i)0LL, v6), _mm_shuffle_epi32(v5, 68));
  v8 = _mm_shuffle_epi32(_mm_loadl_epi64(&v22), 68);
  if ( dstlength - 1 <= 0 )
  {
    v17 = 0;
  }
  else
  {
    v9 = dst;
    v10 = 0;
    do
    {
      v11 = _mm_shuffle_epi32(v7, 13);
      v10 += 2;
      v9 += 4;
      v7 = _mm_add_epi64(v7, v8);
      v22.m128i_i32[0] = _mm_cvtsi128_si32(v11);
      v22.m128i_i32[3] = v11.m128i_i32[1];
      v12 = 2 * v22.m128i_i32[0];
      v13 = _mm_unpacklo_epi32(
              _mm_cvtsi32_si128(*((__int16 *)src + 2 * v11.m128i_i32[1])),
              _mm_cvtsi32_si128(*((__int16 *)src + 2 * v11.m128i_i32[1] + 1)));
      v14 = _mm_cvtsi32_si128(*((__int16 *)src + v12));
      v15 = _mm_cvtsi32_si128(*((__int16 *)src + v12 + 1));
      v22.m128i_i32[0] = *((__int16 *)src + v12 + 1);
      *((__m128 *)v9 - 1) = _mm_mul_ps(
                              _mm_cvtepi32_ps(_mm_unpacklo_epi64(_mm_unpacklo_epi32(v14, v15), v13)),
                              *(__m128 *)scale16data_1);
    }
    while ( v10 < dstlength - 1 );
    v16 = (unsigned int)(dstlength - 2) >> 1;
    v17 = 2 * v16 + 2;
    dst += 4 * v16 + 4;
  }
  v18 = dstlength - v17;
  position->mValue = *(FMOD_UINT64 *)v7.m128i_i8;
  if ( v18 )
  {
    mValue = speed->mValue;
    do
    {
      dst += 2;
      v20 = 2 * position->mHi;
      v21 = (float)*((__int16 *)src + (unsigned int)(v20 + 1)) * 0.000030517578;
      *(dst - 2) = (float)*((__int16 *)src + v20) * 0.000030517578;
      *(dst - 1) = v21;
      position->mValue += mValue;
      --v18;
    }
    while ( v18 );
  }
}


