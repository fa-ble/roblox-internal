// Address: 0x2269a70 | Name: FMOD_ogg_toupper
char __fastcall FMOD_ogg_toupper(char in)
{
  char result; // al

  result = in - 32;
  if ( (unsigned __int8)(in - 97) > 0x19u )
    return in;
  return result;
}


// Address: 0x2269a80 | Name: FMOD_vorbis_comment_init
void __fastcall FMOD_vorbis_comment_init(vorbis_comment *vc)
{
  vc->user_comments = 0;
  vc->comment_lengths = 0;
  *(_QWORD *)&vc->comments = 0;
  vc->vendor = 0;
}


// Address: 0x2269aa0 | Name: FMOD_vorbis_comment_clear
void __fastcall FMOD_vorbis_comment_clear(void *context, vorbis_comment *vc)
{
  char **user_comments; // rax
  __int64 v4; // rbp
  int v5; // ebx
  char *v6; // rsi
  int *comment_lengths; // rsi
  char *vendor; // rsi

  if ( vc )
  {
    user_comments = vc->user_comments;
    if ( vc->user_comments )
    {
      if ( vc->comments > 0 )
      {
        v4 = 0;
        v5 = 0;
        do
        {
          v6 = user_comments[v4];
          if ( v6 )
          {
            FMOD_OggVorbis_Free(context, v6);
            user_comments = vc->user_comments;
          }
          ++v5;
          ++v4;
        }
        while ( vc->comments > v5 );
      }
      FMOD_OggVorbis_Free(context, user_comments);
    }
    comment_lengths = vc->comment_lengths;
    if ( comment_lengths )
      FMOD_OggVorbis_Free(context, comment_lengths);
    vendor = vc->vendor;
    if ( vendor )
      FMOD_OggVorbis_Free(context, vendor);
    vc->user_comments = 0;
    vc->comment_lengths = 0;
    *(_QWORD *)&vc->comments = 0;
    vc->vendor = 0;
  }
}


// Address: 0x2269b50 | Name: FMOD_vorbis_info_blocksize
int __fastcall FMOD_vorbis_info_blocksize(vorbis_info_0 *vi, int zo)
{
  _DWORD *codec_setup; // rax

  codec_setup = vi->codec_setup;
  if ( codec_setup )
    return codec_setup[zo];
  else
    return -1;
}


// Address: 0x2269b70 | Name: FMOD_vorbis_info_init
int __fastcall FMOD_vorbis_info_init(void *context, vorbis_info_0 *vi)
{
  void *v2; // rax
  int result; // eax

  *(_QWORD *)&vi->version = 0;
  *(_QWORD *)&vi->rate = 0;
  *(_QWORD *)&vi->bitrate_nominal = 0;
  *(_QWORD *)&vi->bitrate_window = 0;
  vi->codec_setup = 0;
  v2 = FMOD_OggVorbis_Calloc(context, 1, 4912);
  vi->codec_setup = v2;
  result = -(v2 == 0);
  LOBYTE(result) = result & 0x75;
  return result;
}


// Address: 0x2269bc0 | Name: FMOD_vorbis_info_clear
void __fastcall FMOD_vorbis_info_clear(void *context, vorbis_info_0 *vi)
{
  char *codec_setup; // rbx
  void **v4; // r14
  int v5; // ebp
  __int64 v6; // rbp
  __int64 v7; // rbp
  __int64 v8; // rbp
  __int64 v9; // rbp
  int v10; // r14d
  static_codebook_0 *v11; // rsi
  __int64 v12; // rax
  void *v13; // rsi

  codec_setup = (char *)vi->codec_setup;
  if ( codec_setup )
  {
    if ( *((int *)codec_setup + 2) > 0 )
    {
      v4 = (void **)(codec_setup + 32);
      v5 = 0;
      do
      {
        if ( *v4 )
          FMOD_OggVorbis_Free(context, *v4);
        ++v5;
        ++v4;
      }
      while ( *((_DWORD *)codec_setup + 2) > v5 );
    }
    if ( *((int *)codec_setup + 3) > 0 )
    {
      v6 = 0;
      do
      {
        if ( *(_QWORD *)&codec_setup[8 * v6 + 800] )
          FMOD_mapping_P[*(int *)&codec_setup[4 * v6 + 544]]->free_info(context);
        ++v6;
      }
      while ( *((_DWORD *)codec_setup + 3) > (int)v6 );
    }
    if ( *((int *)codec_setup + 4) > 0 )
    {
      v7 = 0;
      do
      {
        if ( *(_QWORD *)&codec_setup[8 * v7 + 1568] )
          FMOD_floor_P[*(int *)&codec_setup[4 * v7 + 1312]]->free_info(context);
        ++v7;
      }
      while ( *((_DWORD *)codec_setup + 4) > (int)v7 );
    }
    if ( *((int *)codec_setup + 5) > 0 )
    {
      v8 = 0;
      do
      {
        if ( *(_QWORD *)&codec_setup[8 * v8 + 2336] )
          FMOD_residue_P[*(int *)&codec_setup[4 * v8 + 2080]]->free_info(context);
        ++v8;
      }
      while ( *((_DWORD *)codec_setup + 5) > (int)v8 );
    }
    if ( *((int *)codec_setup + 6) > 0 )
    {
      v9 = 0;
      v10 = 0;
      do
      {
        v11 = *(static_codebook_0 **)&codec_setup[v9 + 2848];
        if ( v11 )
          FMOD_vorbis_staticbook_destroy(context, v11);
        v12 = *((_QWORD *)codec_setup + 612);
        if ( v12 )
          FMOD_vorbis_book_clear(context, (codebook_0 *)(v12 + 9 * v9));
        ++v10;
        v9 += 8;
      }
      while ( *((_DWORD *)codec_setup + 6) > v10 );
    }
    v13 = (void *)*((_QWORD *)codec_setup + 612);
    if ( v13 )
      FMOD_OggVorbis_Free(context, v13);
    FMOD_OggVorbis_Free(context, codec_setup);
  }
  *(_QWORD *)&vi->rate = 0;
  *(_QWORD *)&vi->bitrate_nominal = 0;
  *(_QWORD *)&vi->bitrate_window = 0;
  vi->codec_setup = 0;
  *(_QWORD *)&vi->version = 0;
}


// Address: 0x2269d70 | Name: FMOD_vorbis_synthesis_idheader
int __fastcall FMOD_vorbis_synthesis_idheader(ogg_packet *op)
{
  char *v2; // rbx
  char buffer[6]; // [rsp+0h] [rbp-58h] BYREF
  char v4; // [rsp+6h] [rbp-52h] BYREF
  oggpack_buffer_0 opb; // [rsp+10h] [rbp-48h] BYREF

  if ( !op )
    return 0;
  FMOD_oggpack_readinit((oggpack_buffer *)&opb, op->packet, op->bytes);
  if ( !HIDWORD(op->bytes) || FMOD_oggpack_read((oggpack_buffer *)&opb, 8) != 1 )
    return 0;
  memset(buffer, 0, sizeof(buffer));
  v2 = buffer;
  do
    *v2++ = FMOD_oggpack_read((oggpack_buffer *)&opb, 8);
  while ( v2 != &v4 );
  return memcmp(buffer, "vorbis", 6u) == 0;
}


// Address: 0x2269e20 | Name: FMOD_vorbis_synthesis_headerin
int __fastcall FMOD_vorbis_synthesis_headerin(void *context, vorbis_info_0 *vi, vorbis_comment *vc, ogg_packet *op)
{
  ogg_int32_t v5; // r14d
  char *v6; // r15
  int v7; // r13d
  int *codec_setup; // rbp
  char v9; // al
  ogg_int32_t rate; // edi
  int v11; // r14d
  _DWORD *v13; // rbp
  int v14; // r13d
  int v15; // eax
  static_codebook_0 **v16; // r12
  int v17; // eax
  static_codebook_0 *v18; // rax
  ogg_int32_t v19; // r14d
  int v20; // ebx
  __int64 v21; // r12
  int v22; // eax
  vorbis_info_mapping *v23; // rax
  int v24; // eax
  _DWORD *v25; // r12
  int v26; // r15d
  _DWORD *v27; // r14
  __int64 v28; // r14
  __int64 v29; // r14
  __int64 v30; // r14
  __int64 v31; // rax
  int v32; // eax
  int v33; // r12d
  ogg_int32_t v34; // eax
  int v35; // r13d
  char *v36; // rbp
  __int64 v37; // r12
  ogg_int32_t v38; // ebp
  ogg_int32_t storage; // r12d
  char **v40; // rax
  int *v41; // rax
  __int64 v42; // r12
  ogg_int32_t v43; // r14d
  ogg_int32_t v44; // ebp
  char **v45; // rbp
  char *v46; // r15
  __int64 v47; // rbp
  __int64 v48; // r12
  int v49; // eax
  __int64 v50; // rax
  ogg_int32_t v51; // eax
  __int64 v52; // r12
  int v53; // eax
  __int64 v54; // rax
  unsigned int v55; // eax
  int vcb; // [rsp+18h] [rbp-70h]
  char buffer[6]; // [rsp+20h] [rbp-68h] BYREF
  __int16 v60; // [rsp+26h] [rbp-62h] BYREF
  oggpack_buffer_0 opb; // [rsp+30h] [rbp-58h] BYREF

  if ( !op )
    return -133;
  FMOD_oggpack_readinit((oggpack_buffer *)&opb, op->packet, op->bytes);
  v5 = FMOD_oggpack_read((oggpack_buffer *)&opb, 8);
  memset(buffer, 0, sizeof(buffer));
  v6 = buffer;
  do
    *v6++ = FMOD_oggpack_read((oggpack_buffer *)&opb, 8);
  while ( v6 != (char *)&v60 );
  v7 = memcmp(buffer, "vorbis", 6u);
  if ( v7 )
    return -132;
  if ( v5 == 3 )
  {
    if ( !vi->rate )
      return -133;
    v19 = FMOD_oggpack_read((oggpack_buffer *)&opb, 32);
    if ( v19 < 0 || v19 >= opb.storage - 7 )
      goto LABEL_35;
    v36 = (char *)FMOD_OggVorbis_Calloc(context, v19 + 1, 1);
    vc->vendor = v36;
    if ( v36 )
    {
      v37 = (__int64)&v36[v19 - 1 + 1];
      if ( v19 )
      {
        do
          *v36++ = FMOD_oggpack_read((oggpack_buffer *)&opb, 8);
        while ( v36 != (char *)v37 );
      }
      v38 = FMOD_oggpack_read((oggpack_buffer *)&opb, 32);
      if ( v38 < 0 || (storage = opb.storage, v38 > (storage - FMOD_oggpack_bytes((oggpack_buffer *)&opb)) >> 2) )
      {
LABEL_35:
        v20 = -133;
LABEL_36:
        v7 = v20;
        FMOD_vorbis_comment_clear(context, vc);
        return v7;
      }
      vc->comments = v38;
      v40 = (char **)FMOD_OggVorbis_Calloc(context, v38 + 1, 8);
      vc->user_comments = v40;
      if ( v40 )
      {
        v41 = (int *)FMOD_OggVorbis_Calloc(context, vc->comments + 1, 4);
        vc->comment_lengths = v41;
        if ( v41 )
        {
          v42 = 0;
          if ( vc->comments <= 0 )
          {
LABEL_70:
            if ( FMOD_oggpack_read((oggpack_buffer *)&opb, 1) == 1 )
              return v7;
          }
          else
          {
            while ( 1 )
            {
              v43 = FMOD_oggpack_read((oggpack_buffer *)&opb, 32);
              if ( v43 < 0 )
                break;
              v44 = opb.storage;
              if ( v43 > v44 - FMOD_oggpack_bytes((oggpack_buffer *)&opb) )
                break;
              vc->comment_lengths[v42] = v43;
              v45 = &vc->user_comments[v42];
              *v45 = (char *)FMOD_OggVorbis_Calloc(context, v43 + 1, 1);
              v46 = vc->user_comments[v42];
              if ( !v46 )
                goto LABEL_79;
              v47 = (__int64)&v46[v43 - 1 + 1];
              if ( v43 )
              {
                do
                  *v46++ = FMOD_oggpack_read((oggpack_buffer *)&opb, 8);
                while ( v46 != (char *)v47 );
              }
              if ( vc->comments <= (int)++v42 )
                goto LABEL_70;
            }
          }
          goto LABEL_35;
        }
      }
    }
LABEL_79:
    v20 = -139;
    goto LABEL_36;
  }
  v7 = -133;
  if ( v5 != 5 )
  {
    if ( v5 != 1 || !HIDWORD(op->bytes) || vi->rate )
      return v7;
    codec_setup = (int *)vi->codec_setup;
    if ( codec_setup )
    {
      v7 = FMOD_oggpack_read((oggpack_buffer *)&opb, 32);
      vi->version = v7;
      if ( v7 )
        return -134;
      vi->channels = FMOD_oggpack_read((oggpack_buffer *)&opb, 8);
      vi->rate = FMOD_oggpack_read((oggpack_buffer *)&opb, 32);
      vi->bitrate_upper = FMOD_oggpack_read((oggpack_buffer *)&opb, 32);
      vi->bitrate_nominal = FMOD_oggpack_read((oggpack_buffer *)&opb, 32);
      vi->bitrate_lower = FMOD_oggpack_read((oggpack_buffer *)&opb, 32);
      *codec_setup = 1 << FMOD_oggpack_read((oggpack_buffer *)&opb, 4);
      v9 = FMOD_oggpack_read((oggpack_buffer *)&opb, 4);
      rate = vi->rate;
      v11 = 1 << v9;
      codec_setup[1] = 1 << v9;
      if ( rate <= 0
        || vi->channels <= 0
        || *codec_setup <= 63
        || v11 < *codec_setup
        || v11 > 0x2000
        || FMOD_oggpack_read((oggpack_buffer *)&opb, 1) != 1 )
      {
        v7 = -133;
        FMOD_vorbis_info_clear(context, vi);
      }
      return v7;
    }
    return -129;
  }
  if ( !vi->rate || !vc->vendor )
    return v7;
  v13 = vi->codec_setup;
  if ( !v13 )
    return -129;
  v14 = 0;
  v15 = FMOD_oggpack_read((oggpack_buffer *)&opb, 8) + 1;
  v16 = (static_codebook_0 **)(v13 + 712);
  v13[6] = v15;
  if ( v15 > 0 )
  {
    do
    {
      v18 = (static_codebook_0 *)FMOD_OggVorbis_Calloc(context, 1, 56);
      *v16 = v18;
      if ( !v18 )
      {
LABEL_29:
        v17 = -139;
        goto LABEL_30;
      }
      v17 = FMOD_vorbis_staticbook_unpack(context, (oggpack_buffer *)&opb, v18);
      if ( v17 )
        goto LABEL_30;
      ++v14;
      ++v16;
    }
    while ( v14 < v13[6] );
    v33 = 0;
    v34 = FMOD_oggpack_read((oggpack_buffer *)&opb, 6);
    v35 = v34 + 1;
    if ( v34 >= 0 )
    {
      while ( !FMOD_oggpack_read((oggpack_buffer *)&opb, 16) )
      {
        if ( ++v33 == v35 )
        {
          v48 = 0;
          v49 = FMOD_oggpack_read((oggpack_buffer *)&opb, 6) + 1;
          v13[4] = v49;
          if ( v49 > 0 )
          {
            do
            {
              v51 = FMOD_oggpack_read((oggpack_buffer *)&opb, 16);
              v13[v48 + 328] = v51;
              if ( !v51 )
              {
                v17 = -134;
                goto LABEL_30;
              }
              if ( v51 != 1 )
                goto LABEL_50;
              v50 = ((__int64 (__fastcall *)(void *, vorbis_info_0 *, oggpack_buffer_0 *))FMOD_floor_P[1]->unpack)(
                      context,
                      vi,
                      &opb);
              *(_QWORD *)&v13[2 * v48 + 392] = v50;
              if ( !v50 )
                goto LABEL_50;
              ++v48;
            }
            while ( v13[4] > (int)v48 );
            v52 = 0;
            v53 = FMOD_oggpack_read((oggpack_buffer *)&opb, 6) + 1;
            v13[5] = v53;
            if ( v53 > 0 )
            {
              while ( 1 )
              {
                v55 = FMOD_oggpack_read((oggpack_buffer *)&opb, 16);
                v13[v52 + 520] = v55;
                if ( v55 > 2 )
                  break;
                v54 = ((__int64 (__fastcall *)(void *, vorbis_info_0 *, oggpack_buffer_0 *))FMOD_residue_P[v55]->unpack)(
                        context,
                        vi,
                        &opb);
                *(_QWORD *)&v13[2 * v52 + 584] = v54;
                if ( !v54 )
                  break;
                if ( v13[5] <= (int)++v52 )
                {
                  v21 = 0;
                  v22 = FMOD_oggpack_read((oggpack_buffer *)&opb, 6) + 1;
                  v13[3] = v22;
                  if ( v22 > 0 )
                  {
                    while ( 1 )
                    {
                      v7 = FMOD_oggpack_read((oggpack_buffer *)&opb, 16);
                      v13[v21 + 136] = v7;
                      if ( v7 )
                        break;
                      v23 = FMOD_mapping0_exportbundle.unpack(context, vi, &opb);
                      *(_QWORD *)&v13[2 * v21 + 200] = v23;
                      if ( !v23 )
                        break;
                      if ( v13[3] <= (int)++v21 )
                      {
                        v24 = FMOD_oggpack_read((oggpack_buffer *)&opb, 6) + 1;
                        v13[2] = v24;
                        if ( v24 <= 0 )
                          goto LABEL_50;
                        v25 = v13 + 8;
                        v26 = 0;
                        while ( 1 )
                        {
                          v27 = FMOD_OggVorbis_Calloc(context, 1, 16);
                          *(_QWORD *)v25 = v27;
                          if ( !v27 )
                            goto LABEL_29;
                          *v27 = FMOD_oggpack_read((oggpack_buffer *)&opb, 1);
                          v28 = *(_QWORD *)v25;
                          *(_DWORD *)(v28 + 4) = FMOD_oggpack_read((oggpack_buffer *)&opb, 16);
                          v29 = *(_QWORD *)v25;
                          *(_DWORD *)(v29 + 8) = FMOD_oggpack_read((oggpack_buffer *)&opb, 16);
                          v30 = *(_QWORD *)v25;
                          *(_DWORD *)(v30 + 12) = FMOD_oggpack_read((oggpack_buffer *)&opb, 8);
                          v31 = *(_QWORD *)v25;
                          if ( *(int *)(*(_QWORD *)v25 + 4LL) > 0 )
                            goto LABEL_50;
                          if ( *(int *)(v31 + 8) > 0 )
                            goto LABEL_50;
                          v32 = *(_DWORD *)(v31 + 12);
                          if ( v32 >= v13[3] || v32 < 0 )
                            goto LABEL_50;
                          ++v26;
                          v25 += 2;
                          if ( v26 >= v13[2] )
                          {
                            if ( FMOD_oggpack_read((oggpack_buffer *)&opb, 1) == 1 )
                              return v7;
                            goto LABEL_50;
                          }
                        }
                      }
                    }
                  }
                  goto LABEL_50;
                }
              }
            }
          }
          break;
        }
      }
    }
  }
LABEL_50:
  v17 = -133;
LABEL_30:
  vcb = v17;
  FMOD_vorbis_info_clear(context, vi);
  return vcb;
}


