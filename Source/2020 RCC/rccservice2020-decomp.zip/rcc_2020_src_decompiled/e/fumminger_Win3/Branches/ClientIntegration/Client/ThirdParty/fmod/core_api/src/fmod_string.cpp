// Address: 0x22190e0 | Name: FMOD_strlen
int __fastcall FMOD_strlen(const char *s)
{
  const char *v1; // rax

  if ( !*s )
    return 0;
  v1 = s;
  do
    ++v1;
  while ( *v1 );
  return (_DWORD)v1 - (_DWORD)s;
}


// Address: 0x2219100 | Name: _Z11FMOD_strcpyPcPKc
char *__fastcall FMOD_strcpy(char *dest, const char *src)
{
  char *result; // rax
  char *v3; // rdx
  char v4; // cl

  result = dest;
  v3 = dest;
  do
  {
    v4 = *src++;
    *v3++ = v4;
  }
  while ( v4 );
  return result;
}


// Address: 0x2219130 | Name: _Z12FMOD_strncpyPcPKci
char *__fastcall FMOD_strncpy(char *dest, const char *src, int count)
{
  char *result; // rax
  char *v4; // rcx
  char *v5; // rdx
  char v6; // r8

  result = dest;
  v4 = dest;
  v5 = &dest[count];
  do
  {
    if ( v4 == v5 )
      break;
    v6 = *src++;
    *v4++ = v6;
  }
  while ( v6 );
  return result;
}


// Address: 0x2219160 | Name: FMOD_validate_utf8
int __fastcall FMOD_validate_utf8(const char *in)
{
  char v1; // al
  int v2; // edx

  v1 = *in;
  if ( *in )
  {
    v2 = 0;
    while ( 1 )
    {
      while ( v2 )
      {
        if ( (v1 & 0xC0) != 0x80 )
          return 0;
        v1 = *++in;
        --v2;
        if ( !*in )
          return (v2 - 1) >> 31;
      }
      if ( v1 < 0 )
      {
        if ( (v1 & 0xE0) == 0xC0 )
        {
          v2 = 1;
        }
        else if ( (v1 & 0xF0) == 0xE0 )
        {
          v2 = 2;
        }
        else
        {
          if ( (v1 & 0xF8) != 0xF0 )
            return 0;
          v2 = 3;
        }
      }
      v1 = *++in;
      if ( !*in )
        return (v2 - 1) >> 31;
    }
  }
  return -1;
}


// Address: 0x2219210 | Name: _Z11utf8codelenc
int __fastcall utf8codelen(const char code)
{
  int result; // eax

  result = 1;
  if ( code < 0 )
  {
    LOBYTE(result) = 2;
    if ( (code & 0xE0) != 0xC0 )
    {
      LOBYTE(result) = 3;
      if ( (code & 0xF0) != 0xE0 )
        return 3 * ((code & 0xF8) == 240) + 1;
    }
  }
  return result;
}


// Address: 0x2219260 | Name: FMOD_strcpy_safe
char *__fastcall FMOD_strcpy_safe(char *dst, const char *src, int destBytes)
{
  int v3; // ebx
  char *v4; // r12
  const char *v5; // rbp
  int v6; // eax

  v3 = destBytes;
  if ( destBytes > 0 )
  {
    v4 = dst;
    v5 = src;
    v6 = utf8codelen(*src);
LABEL_3:
    if ( v3 != 1 )
    {
      while ( v3 > v6 && *v5 )
      {
        *v4++ = *v5++;
        --v3;
        if ( v6 <= 1 )
        {
          v6 = utf8codelen(*v5);
          goto LABEL_3;
        }
        --v6;
        if ( v3 == 1 )
          break;
      }
    }
    *v4 = 0;
  }
  return dst;
}


// Address: 0x22192e0 | Name: FMOD_strcat_safe
char *__fastcall FMOD_strcat_safe(char *dst, const char *src, int destBytes)
{
  char *i; // rbx

  for ( i = dst; *dst; --destBytes )
  {
    if ( !destBytes )
      break;
    ++dst;
  }
  FMOD_strcpy_safe(dst, src, destBytes);
  return i;
}


// Address: 0x2219310 | Name: FMOD_strncat_safe
char *__fastcall FMOD_strncat_safe(char *dst, int destBytes, const char *src, int catLen)
{
  char *i; // rbx
  int v6; // edx

  for ( i = dst; *dst; --destBytes )
  {
    if ( !destBytes )
      break;
    ++dst;
  }
  v6 = catLen + 1;
  if ( destBytes <= catLen + 1 )
    v6 = destBytes;
  FMOD_strcpy_safe(dst, src, v6);
  return i;
}


// Address: 0x2219350 | Name: _Z11FMOD_strcatPcPKc
char *__fastcall FMOD_strcat(char *dest, const char *src)
{
  char *result; // rax
  char *i; // rdx
  char v4; // cl

  result = dest;
  for ( i = dest; *i; ++i )
    ;
  do
  {
    v4 = *src++;
    *i++ = v4;
  }
  while ( v4 );
  return result;
}


// Address: 0x2219390 | Name: _Z12FMOD_strncatPcPKci
char *__fastcall FMOD_strncat(char *dest, const char *src, int count)
{
  char *result; // rax
  char *i; // rcx
  __int64 v5; // r9
  char v6; // r8

  result = dest;
  if ( count )
  {
    for ( i = dest; *i; ++i )
      ;
    v5 = (__int64)&i[count - 1 + 1];
    while ( 1 )
    {
      v6 = *src++;
      *i = v6;
      if ( !v6 )
        break;
      if ( i + 1 == (char *)v5 )
      {
        i[1] = 0;
        return result;
      }
      ++i;
    }
  }
  return result;
}


// Address: 0x22193f0 | Name: FMOD_tolower
char __fastcall FMOD_tolower(char in)
{
  char result; // al

  result = in + 32;
  if ( (unsigned __int8)(in - 65) > 0x19u )
    return in;
  return result;
}


// Address: 0x2219400 | Name: FMOD_strupr
char *__fastcall FMOD_strupr(char *string)
{
  char v1; // dl
  char *result; // rax
  char *i; // rcx

  v1 = *string;
  result = string;
  for ( i = string; *i; v1 = *i )
  {
    if ( (unsigned __int8)(v1 - 97) <= 0x19u )
      *i = v1 - 32;
    ++i;
  }
  return result;
}


// Address: 0x2219430 | Name: FMOD_strlwr
char *__fastcall FMOD_strlwr(char *string)
{
  char v1; // dl
  char *result; // rax
  char *i; // rcx

  v1 = *string;
  result = string;
  for ( i = string; *i; v1 = *i )
  {
    if ( (unsigned __int8)(v1 - 65) <= 0x19u )
      *i = v1 + 32;
    ++i;
  }
  return result;
}


// Address: 0x2219460 | Name: FMOD_strcmp
int __fastcall FMOD_strcmp(const char *string1, const char *string2)
{
  int v2; // eax

  do
  {
    ++string1;
    ++string2;
    v2 = *(string1 - 1);
  }
  while ( *(string1 - 1) == *(string2 - 1) && (_BYTE)v2 );
  return v2 - *(string2 - 1);
}


// Address: 0x2219480 | Name: FMOD_strncmp
int __fastcall FMOD_strncmp(const char *string1, const char *string2, int len)
{
  __int64 v3; // rcx
  int v4; // eax
  int v5; // r8d

  v3 = 0;
  do
  {
    v4 = string1[v3];
    v5 = string2[v3];
    if ( string1[v3] != string2[v3] )
      break;
    if ( !(_BYTE)v4 )
      break;
    ++v3;
  }
  while ( len > (int)v3 );
  return v4 - v5;
}


// Address: 0x22194b0 | Name: FMOD_stricmp
int __fastcall FMOD_stricmp(const char *string1, const char *string2)
{
  int v4; // r12d
  char v5; // al

  do
  {
    ++string1;
    ++string2;
    v4 = FMOD_tolower(*(string1 - 1));
    v5 = FMOD_tolower(*(string2 - 1));
  }
  while ( (_BYTE)v4 == v5 && (_BYTE)v4 );
  return v4 - v5;
}


// Address: 0x2219500 | Name: FMOD_strnicmp
int __fastcall FMOD_strnicmp(const char *string1, const char *string2, int len)
{
  const char *v5; // rbx
  int v6; // r12d
  char v7; // al

  v5 = string1;
  do
  {
    ++v5;
    ++string2;
    v6 = FMOD_tolower(*(v5 - 1));
    v7 = FMOD_tolower(*(string2 - 1));
  }
  while ( (_BYTE)v6 == v7 && (_BYTE)v6 && len > (int)v5 - (int)string1 );
  return v6 - v7;
}


// Address: 0x2219570 | Name: FMOD_strchr
char *__fastcall FMOD_strchr(const char *s1, int c)
{
  char *v2; // rbx
  int v3; // eax

  v2 = (char *)s1;
  v3 = FMOD_strlen(s1);
  if ( !v3 )
    return 0;
  while ( 1 )
  {
    --v3;
    if ( *v2 == c )
      break;
    ++v2;
    if ( !v3 )
      return 0;
  }
  return v2;
}


// Address: 0x22195c0 | Name: FMOD_strrchr
char *__fastcall FMOD_strrchr(const char *s1, int c)
{
  int v2; // eax
  char *v3; // rdx

  v2 = FMOD_strlen(s1);
  v3 = (char *)&s1[v2 - 1];
  if ( !v2 )
    return 0;
  while ( 1 )
  {
    --v2;
    if ( *v3 == c )
      break;
    --v3;
    if ( !v2 )
      return 0;
  }
  return v3;
}


// Address: 0x2219610 | Name: FMOD_strstr
char *__fastcall FMOD_strstr(const char *s1, const char *s2)
{
  const char *v2; // rbx
  int v3; // r12d
  char *result; // rax
  int v5; // ebp

  v2 = s1;
  v3 = FMOD_strlen(s2);
  result = (char *)s1;
  if ( v3 )
  {
    v5 = FMOD_strlen(s1);
    if ( v3 > v5 )
    {
      return 0;
    }
    else
    {
      while ( 1 )
      {
        --v5;
        if ( !memcmp(v2, s2, v3) )
          break;
        ++v2;
        if ( v3 > v5 )
          return 0;
      }
      return (char *)v2;
    }
  }
  return result;
}


// Address: 0x22196a0 | Name: FMOD_strdup
char *__fastcall FMOD_strdup(const char *src)
{
  int v1; // r12d
  char *v2; // rax
  char *v3; // rbx

  v1 = FMOD_strlen(src) + 1;
  v2 = (char *)FMOD::MemPool::alloc(off_286F358->gSystemMemPool, v1, "../../../core_api/src/fmod_string.cpp", 362, 0, 0);
  v3 = v2;
  if ( v2 )
    FMOD_strcpy_safe(v2, src, v1);
  return v3;
}


// Address: 0x2219700 | Name: FMOD_eatwhite
char *__fastcall FMOD_eatwhite(const char *string)
{
  char v1; // dl
  char *result; // rax

  v1 = *string;
  for ( result = (char *)string; *result; v1 = *++result )
  {
    if ( (unsigned __int8)(v1 - 9) > 1u && v1 != 32 )
      break;
  }
  return result;
}


// Address: 0x2219740 | Name: FMOD_atoi
int __fastcall FMOD_atoi(const char *s)
{
  const char *i; // rdx
  const char *v2; // rdx
  const char *v3; // rdi
  int v4; // ecx
  int result; // eax
  int v6; // esi
  int v7; // esi

  if ( !s )
    return 0;
  for ( i = s; *i; ++i )
    ;
  v2 = i - 1;
  if ( s > v2 )
    return 0;
  v3 = s - 1;
  v4 = 1;
  result = 0;
  do
  {
    v6 = *v2--;
    v7 = v4 * (v6 - 48);
    v4 *= 10;
    result += v7;
  }
  while ( v2 != v3 );
  return result;
}


// Address: 0x22197a0 | Name: FMOD_atoi_hex
int __fastcall FMOD_atoi_hex(const char *s)
{
  int v1; // edx
  int result; // eax

  if ( !s )
    return 0;
  v1 = *s;
  for ( result = 0; *s; v1 = *s )
  {
    while ( 1 )
    {
      result *= 16;
      if ( (unsigned __int8)(v1 - 48) > 9u )
        break;
      result = result + v1 - 48;
LABEL_5:
      v1 = *++s;
      if ( !*s )
        return result;
    }
    if ( (unsigned __int8)(v1 - 65) > 5u )
    {
      if ( (unsigned __int8)(v1 - 97) <= 5u )
        result = result + v1 - 87;
      goto LABEL_5;
    }
    ++s;
    result = result + v1 - 55;
  }
  return result;
}


// Address: 0x2219810 | Name: FMOD_vsnprintf
int __fastcall FMOD_vsnprintf(char *str, int size, const char *format, ___va_list_tag *arglist)
{
  int v4; // ebx
  int v5; // eax

  v4 = size;
  if ( size <= 0 )
    return 0;
  *str = 0;
  v5 = vsnprintf(str, size, format, (__va_list_tag *)arglist);
  if ( v5 >= 0 && size > v5 )
    v4 = v5;
  str[size - 1] = 0;
  return v4;
}


// Address: 0x2219860 | Name: _Z20FMOD_OS_Debug_OutputPKcz
FMOD_RESULT_0 FMOD_OS_Debug_Output(const char *format, ...)
{
  va_list arglist; // [rsp+8h] [rbp-2D0h] BYREF
  char buf[512]; // [rsp+20h] [rbp-2B8h] BYREF

  va_start(arglist, format);
  FMOD_vsnprintf(buf, 512, format, (___va_list_tag *)arglist);
  return FMOD_OS_Debug_OutputStr(buf);
}


// Address: 0x2219930 | Name: FMOD_snprintf
int FMOD_snprintf(char *str, int size, const char *format, ...)
{
  va_list arglist; // [rsp+8h] [rbp-D0h] BYREF

  va_start(arglist, format);
  return FMOD_vsnprintf(str, size, format, (___va_list_tag *)arglist);
}


// Address: 0x22199c0 | Name: FMOD_strfromlatin1
char *__fastcall FMOD_strfromlatin1(char *dest, int destBytes, const char *src)
{
  char *result; // rax
  int v4; // ecx
  int v5; // esi
  char v6; // r8
  __int64 v7; // rdi
  int v8; // r9d
  __int64 v9; // r10

  result = dest;
  v4 = 0;
  v5 = destBytes - 2;
LABEL_2:
  v6 = *src;
  if ( *src )
  {
    while ( v4 < v5 )
    {
      ++src;
      if ( v6 < 0 )
      {
        v8 = v4 + 1;
        v9 = v4;
        v4 += 2;
        result[v9] = ((unsigned __int8)v6 >> 6) | 0xC0;
        result[v8] = v6 & 0x3F | 0x80;
        goto LABEL_2;
      }
      v7 = v4++;
      result[v7] = v6;
      v6 = *src;
      if ( !*src )
        break;
    }
  }
  result[v4] = 0;
  return result;
}


