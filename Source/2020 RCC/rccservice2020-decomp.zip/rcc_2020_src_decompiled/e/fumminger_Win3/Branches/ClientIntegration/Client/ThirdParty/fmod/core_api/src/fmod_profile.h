// Address: 0x21cde20 | Name: _ZNK4FMOD13ProfileModule12hasAsyncReadEv
bool __fastcall FMOD::ProfileModule::hasAsyncRead(const FMOD::ProfileModule *const this)
{
  return 0;
}


// Address: 0x21cde30 | Name: _ZN4FMOD13ProfileModule7releaseEv
FMOD_RESULT_0 __fastcall FMOD::ProfileModule::release(FMOD::ProfileModule *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cde40 | Name: _ZNK4FMOD13ProfileModule17getNextPacketInfoEPNS_10PacketInfoE
FMOD_RESULT_0 __fastcall FMOD::ProfileModule::getNextPacketInfo(
        const FMOD::ProfileModule *const this,
        FMOD::PacketInfo *info)
{
  info->type = (*this->_vptr_ProfileModule)(this);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cde50 | Name: _ZN4FMOD13ProfileModule10readPacketEPKNS_19ProfilePacketHeaderEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileModule::readPacket(
        FMOD::ProfileModule *const this,
        const FMOD::ProfilePacketHeader *packet,
        FMOD::ProfileClient *fromclient)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cde60 | Name: _ZN4FMOD13ProfileModule18getAsyncReadBufferEPKNS_19ProfilePacketHeaderEPPc
FMOD_RESULT_0 __fastcall FMOD::ProfileModule::getAsyncReadBuffer(
        FMOD::ProfileModule *const this,
        const FMOD::ProfilePacketHeader *packet,
        char **buffer)
{
  *buffer = 0;
  return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
}


// Address: 0x21cde70 | Name: _ZN4FMOD13ProfileModule15readPacketAsyncEPKNS_19ProfilePacketHeaderEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileModule::readPacketAsync(
        FMOD::ProfileModule *const this,
        const FMOD::ProfilePacketHeader *packet,
        FMOD::ProfileClient *fromclient)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cde80 | Name: _ZN4FMOD13ProfileModule15clientConnectedEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileModule::clientConnected(FMOD::ProfileModule *const this, FMOD::ProfileClient *a2)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cde90 | Name: _ZN4FMOD13ProfileModule18clientDisconnectedEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::ProfileModule::clientDisconnected(
        FMOD::ProfileModule *const this,
        FMOD::ProfileClient *a2)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cdea0 | Name: _ZN4FMOD13ProfileModule30clientStartRequestingDataAsyncEPNS_13ProfileClientEhh
FMOD_RESULT_0 __fastcall FMOD::ProfileModule::clientStartRequestingDataAsync(
        FMOD::ProfileModule *const this,
        FMOD::ProfileClient *client,
        unsigned __int8 type,
        unsigned __int8 subtype)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cdeb0 | Name: _ZN4FMOD13ProfileModule29clientStopRequestingDataAsyncEPNS_13ProfileClientEhh
FMOD_RESULT_0 __fastcall FMOD::ProfileModule::clientStopRequestingDataAsync(
        FMOD::ProfileModule *const this,
        FMOD::ProfileClient *client,
        unsigned __int8 type,
        unsigned __int8 subtype)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cdec0 | Name: _ZN4FMOD13ProfileModuleD2Ev
void __fastcall FMOD::ProfileModule::~ProfileModule(FMOD::ProfileModule *const this)
{
  this->_vptr_ProfileModule = (int (**)(...))&off_29B0E90;
}


// Address: 0x21cded0 | Name: _ZN4FMOD13ProfileModule4initEv
FMOD_RESULT_0 __fastcall FMOD::ProfileModule::init(FMOD::ProfileModule *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cdf70 | Name: _ZN4FMOD13ProfileModuleD0Ev
void __fastcall FMOD::ProfileModule::~ProfileModule(FMOD::ProfileModule *const this)
{
  this->_vptr_ProfileModule = (int (**)(...))&off_29B0E90;
  operator delete(this);
}


// Address: 0x223add0 | Name: _ZN4FMOD12ProfileStatsD2Ev
void __fastcall FMOD::ProfileStats::~ProfileStats(FMOD::ProfileStats *const this)
{
  this->_vptr_ProfileModule = (int (**)(...))&off_29B0E90;
}


// Address: 0x223ade0 | Name: _ZN4FMOD12ProfileStatsD0Ev
void __fastcall FMOD::ProfileStats::~ProfileStats(FMOD::ProfileStats *const this)
{
  this->_vptr_ProfileModule = (int (**)(...))&off_29B0E90;
  operator delete(this);
}


// Address: 0x22596c0 | Name: _ZNK4FMOD7Profile10isListenerEv
bool __fastcall FMOD::Profile::isListener(const FMOD::Profile *const this)
{
  return this->mListen;
}


