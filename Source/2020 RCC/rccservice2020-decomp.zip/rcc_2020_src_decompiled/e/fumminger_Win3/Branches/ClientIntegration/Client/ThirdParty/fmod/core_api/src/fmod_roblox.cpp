// Address: 0x222a820 | Name: FMOD_Roblox_getVersion0x00020002
unsigned int __cdecl FMOD_Roblox_getVersion0x00020002()
{
  return 131074;
}


// Address: 0x222a830 | Name: FMOD_Roblox_SetFlag
FMOD_RESULT_0 __fastcall FMOD_Roblox_SetFlag(int flagId, FMOD_BOOL value)
{
  return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


