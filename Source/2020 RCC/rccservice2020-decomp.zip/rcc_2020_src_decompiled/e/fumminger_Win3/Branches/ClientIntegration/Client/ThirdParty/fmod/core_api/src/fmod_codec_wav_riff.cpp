// Address: 0x2235af0 | Name: _ZN4FMOD8CodecWav10parseChunkEj
FMOD_RESULT_0 __fastcall FMOD::CodecWav::parseChunk(FMOD::CodecWav *const this, unsigned int chunksize)
{
  FMOD::CodecWav *v2; // rbx
  FMOD_RESULT_0 result; // eax
  __int64 v4; // r12
  unsigned int v5; // esi
  unsigned int size; // esi
  FMOD::WAVE_FORMATEXTENSIBLE *v7; // rax
  FMOD_RESULT_0 v8; // eax
  char v9; // r8
  unsigned __int64 v10; // rax
  unsigned __int64 v11; // rcx
  FMOD_RESULT_0 v12; // ebp
  FMOD_RESULT_0 v13; // eax
  int mNumSyncPoints; // edx
  FMOD_RESULT_0 v15; // r15d
  FMOD::SyncPointNamed *mSyncPoint; // rsi
  FMOD::SyncPointNamed *v17; // rax
  FMOD::CodecWav *v18; // r12
  int v19; // ebp
  FMOD::SyncPointNamed *v20; // r15
  __int64 v21; // rbx
  __int32 dwSampleOffset; // eax
  bool v23; // cc
  char *v24; // r15
  FMOD::File *v25; // rdi
  int v26; // ecx
  FMOD::SyncPointNamed *v27; // rdx
  FMOD::SyncPointNamed *v28; // rax
  __int64 v29; // rdi
  unsigned int v30; // ecx
  FMOD::File *mFile; // rdi
  FMOD_CODEC_WAVEFORMAT *waveformat; // rdx
  unsigned int mSrcDataOffset; // ecx
  unsigned int *pos; // [rsp+20h] [rbp-A8h]
  unsigned int offset; // [rsp+28h] [rbp-A0h]
  FMOD_RESULT_0 v37; // [rsp+2Ch] [rbp-9Ch]
  unsigned int fileoffset; // [rsp+38h] [rbp-90h] BYREF
  unsigned int rd; // [rsp+3Ch] [rbp-8Ch] BYREF
  FMOD::WAVE_CHUNK chunk; // [rsp+40h] [rbp-88h] BYREF
  FMOD::WAVE_CUEPOINT cue; // [rsp+50h] [rbp-78h] BYREF
  int v42; // [rsp+6Ch] [rbp-5Ch]
  unsigned int v43; // [rsp+7Ch] [rbp-4Ch]
  unsigned int v44; // [rsp+80h] [rbp-48h]

  v2 = this;
  result = FMOD::File::tell(this->mFile, &fileoffset);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v4 = 4;
    v5 = fileoffset - 8;
    pos = &this->mSrcDataOffset;
    for ( fileoffset -= 8; ; v5 = fileoffset )
    {
      v12 = FMOD::File::seek(v2->mFile, v5 + 8, 0);
      if ( v12 || (v12 = FMOD::File::read(v2->mFile, &chunk, 1u, 8u, 0)) != FMOD_RESULT::FMOD_OK_0 )
      {
LABEL_36:
        result = FMOD_RESULT::FMOD_OK_0;
        if ( v12 != FMOD_RESULT::FMOD_ERR_FILE_EOF_0 )
          return v12;
        return result;
      }
      if ( !FMOD_strncmp((const char *)&chunk, "fmt ", 4) )
        break;
      if ( !FMOD_strncmp((const char *)&chunk, "cue ", 4) )
      {
        v13 = FMOD::File::read(v2->mFile, &v2->mNumSyncPoints, 4u, 1u, 0);
        mNumSyncPoints = v2->mNumSyncPoints;
        v15 = v13;
        if ( !mNumSyncPoints )
          goto LABEL_42;
        mSyncPoint = v2->mSyncPoint;
        if ( mSyncPoint )
        {
          FMOD::MemPool::free(
            off_286F358->gSystemMemPool,
            mSyncPoint,
            "../../../core_api/src/fmod_codec_wav_riff.cpp",
            119);
          mNumSyncPoints = v2->mNumSyncPoints;
        }
        v17 = (FMOD::SyncPointNamed *)FMOD::MemPool::calloc(
                                        off_286F358->gSystemMemPool,
                                        312 * mNumSyncPoints,
                                        "../../../core_api/src/fmod_codec_wav_riff.cpp",
                                        122,
                                        0);
        v2->mSyncPoint = v17;
        if ( !v17 )
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        if ( v2->mNumSyncPoints > 0 )
        {
          offset = v4;
          v37 = v12;
          v18 = v2;
          v19 = 0;
          v20 = v17;
          v21 = 0;
          while ( 1 )
          {
            v24 = (char *)v20 + v21;
            dwSampleOffset = FMOD::File::read(v18->mFile, &cue, 1u, 0x18u, 0);
            if ( dwSampleOffset )
            {
              v2 = v18;
              v12 = dwSampleOffset;
              v4 = offset;
              v9 = 0;
              goto LABEL_8;
            }
            *(_QWORD *)(v24 + 28) = v24 + 56;
            if ( cue.dwSampleOffset >= 0 )
              dwSampleOffset = cue.dwSampleOffset;
            ++v19;
            v21 += 312;
            v23 = v18->mNumSyncPoints <= v19;
            *((_DWORD *)v24 + 11) = dwSampleOffset;
            *((_WORD *)v24 + 25) = cue.dwIdentifier;
            if ( v23 )
              break;
            v20 = v18->mSyncPoint;
          }
          v2 = v18;
          v12 = v37;
          v4 = offset;
        }
        else
        {
LABEL_42:
          v12 = v15;
        }
LABEL_7:
        v9 = 0;
        goto LABEL_8;
      }
      if ( FMOD_strncmp((const char *)&chunk, "fact", 4) )
      {
        if ( FMOD_strncmp((const char *)&chunk, "LIST", 4) )
        {
          if ( FMOD_strncmp((const char *)&chunk, "labl", 4) )
          {
            if ( FMOD_strncmp((const char *)&chunk, "smpl", 4) )
            {
              if ( FMOD_strncmp((const char *)&chunk, "data", 4) )
              {
                FMOD::File::seek(v2->mFile, chunk.size, 1);
                v9 = 0;
                goto LABEL_8;
              }
              if ( v2->mSrcDataOffset == -1 )
              {
                mFile = v2->mFile;
                v2->waveformat->lengthbytes = chunk.size;
                v8 = FMOD::File::tell(mFile, pos);
                if ( v8
                  || (v8 = (*((unsigned int (__fastcall **)(FMOD::File *, FMOD::WAVE_CUEPOINT *))v2->mFile->_vptr_File
                            + 3))(
                             v2->mFile,
                             &cue)) != FMOD_RESULT::FMOD_OK_0 )
                {
LABEL_35:
                  v12 = v8;
                  goto LABEL_36;
                }
                if ( cue.dwIdentifier != -1 )
                {
                  waveformat = v2->waveformat;
                  mSrcDataOffset = v2->mSrcDataOffset;
                  if ( cue.dwIdentifier < mSrcDataOffset + waveformat->lengthbytes )
                    waveformat->lengthbytes = cue.dwIdentifier - mSrcDataOffset;
                }
              }
              v25 = v2->mFile;
              if ( (v25->mFlags & 1) == 0 )
              {
                v9 = 1;
                goto LABEL_8;
              }
              v8 = FMOD::File::seek(v25, chunk.size, 1);
              if ( v8 )
                goto LABEL_35;
            }
            else
            {
              v12 = FMOD::File::read(v2->mFile, &cue, 1u, 0x3Cu, &rd);
              if ( v12 )
                goto LABEL_36;
              if ( rd == 60 && v42 )
              {
                v2->mLoopPoints[0] = v43;
                v2->mLoopPoints[1] = v44;
              }
            }
          }
          else if ( v2->mSyncPoint )
          {
            v12 = FMOD::File::read(v2->mFile, &cue, 4u, 1u, 0);
            if ( v12 )
              goto LABEL_36;
            v26 = v2->mNumSyncPoints;
            if ( v26 > 0 )
            {
              v27 = v2->mSyncPoint;
              if ( HIWORD(v27->mOffset) == cue.dwIdentifier )
              {
LABEL_52:
                v30 = chunk.size - 4;
                if ( chunk.size - 4 > 0xFF )
                  v30 = 255;
                v12 = FMOD::File::read(v2->mFile, *(void **)(&v27->mNodePriority + 1), 1u, v30, 0);
              }
              else
              {
                v28 = (FMOD::SyncPointNamed *)&v27->mNameMemory[252];
                v29 = (__int64)&v27->mNameMemory[312 * (v26 - 1) + 252];
                while ( v28 != (FMOD::SyncPointNamed *)v29 )
                {
                  v27 = v28;
                  v28 = (FMOD::SyncPointNamed *)((char *)v28 + 312);
                  if ( HIWORD(v27->mOffset) == cue.dwIdentifier )
                    goto LABEL_52;
                }
              }
            }
          }
        }
        else
        {
          v12 = FMOD::File::read(v2->mFile, &cue, 1u, 4u, 0);
          if ( v12 )
            goto LABEL_36;
          v12 = FMOD::CodecWav::parseChunk(v2, chunk.size);
          if ( v12 )
            goto LABEL_36;
        }
        goto LABEL_7;
      }
      v12 = FMOD::File::read(v2->mFile, &cue, 4u, 1u, 0);
      if ( v12 )
        goto LABEL_36;
      v9 = 0;
      v2->waveformat->lengthpcm = cue.dwIdentifier;
LABEL_8:
      v10 = chunk.size + v4 + 8;
      if ( v10 > 0xFFFFFFFE )
        return FMOD_RESULT::FMOD_ERR_FORMAT_0;
      v11 = chunk.size + (unsigned __int64)fileoffset + 8;
      if ( v11 > 0xFFFFFFFE )
        return FMOD_RESULT::FMOD_ERR_FORMAT_0;
      v4 = (unsigned int)v10;
      if ( (chunk.size & 1) != 0 )
      {
        v4 = (unsigned int)(v10 + 1);
        LODWORD(v11) = chunk.size + fileoffset + 9;
      }
      fileoffset = v11;
      if ( (unsigned int)v4 >= chunksize || v9 )
        goto LABEL_36;
    }
    size = 40;
    if ( chunk.size >= 0x28 )
      size = chunk.size;
    v7 = (FMOD::WAVE_FORMATEXTENSIBLE *)FMOD::MemPool::calloc(
                                          off_286F358->gSystemMemPool,
                                          size,
                                          "../../../core_api/src/fmod_codec_wav_riff.cpp",
                                          72,
                                          0);
    v2->mSrcFormat = v7;
    if ( !v7 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    v8 = FMOD::File::read(v2->mFile, v7, 1u, chunk.size, 0);
    if ( v8 )
      goto LABEL_35;
    goto LABEL_7;
  }
  return result;
}


