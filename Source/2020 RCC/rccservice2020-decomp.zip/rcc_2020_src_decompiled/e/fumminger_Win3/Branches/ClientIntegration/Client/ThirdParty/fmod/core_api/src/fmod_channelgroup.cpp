// Address: 0x220c690 | Name: _ZN4FMOD12ChannelGroup7releaseEv
FMOD_RESULT_0 __fastcall FMOD::ChannelGroup::release(FMOD::ChannelGroup *const this)
{
  FMOD_RESULT_0 v1; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-128h] BYREF
  FMOD::ChannelGroupI *channelgroupi; // [rsp+8h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+10h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v1 = FMOD::ChannelGroupI::validate(this, &channelgroupi, &lockScope);
  if ( (v1 || (v1 = FMOD::ChannelGroupI::release(channelgroupi)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    _buffer[0] = 0;
    FMOD_ReportError(
      v1,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELGROUP,
      this,
      "ChannelGroup::release",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v1;
}


// Address: 0x220c730 | Name: _ZN4FMOD12ChannelGroup8addGroupEPS0_bPPNS_13DSPConnectionE
FMOD_RESULT_0 __fastcall FMOD::ChannelGroup::addGroup(
        FMOD::ChannelGroup *const this,
        FMOD::ChannelGroup *group,
        bool propagatedspclock,
        FMOD::DSPConnection **connection)
{
  FMOD_RESULT_0 v6; // ebx
  int v8; // r13d
  int v9; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelGroupI *channelgroupi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v6 = FMOD::ChannelGroupI::validate(this, &channelgroupi, &lockScope);
  if ( (v6
     || (v6 = FMOD::ChannelGroupI::addGroup(
                channelgroupi,
                (FMOD::ChannelGroupI *)group,
                propagatedspclock,
                (FMOD::DSPConnectionI **)connection)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v8 = FMOD::FMOD_FormatArg(_buffer, 256, group);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v8], 256 - v8, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v9 + v8], 256 - (v9 + v8), propagatedspclock);
    FMOD_ReportError(
      v6,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELGROUP,
      this,
      "ChannelGroup::addGroup",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v6;
}


// Address: 0x220c840 | Name: _ZN4FMOD12ChannelGroup12getNumGroupsEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelGroup::getNumGroups(FMOD::ChannelGroup *const this, int *numgroups)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelGroupI *channelgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelGroupI::validate(this, &channelgroupi, &lockScope);
  if ( (v2 || (v2 = FMOD::ChannelGroupI::getNumGroups(channelgroupi, numgroups)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numgroups);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELGROUP,
      this,
      "ChannelGroup::getNumGroups",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x220c8f0 | Name: _ZN4FMOD12ChannelGroup8getGroupEiPPS0_
FMOD_RESULT_0 __fastcall FMOD::ChannelGroup::getGroup(
        FMOD::ChannelGroup *const this,
        int index,
        FMOD::ChannelGroup **group)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelGroupI *channelgroupi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelGroupI::validate(this, &channelgroupi, &lockScope);
  if ( (v4
     || (v4 = FMOD::ChannelGroupI::getGroup(channelgroupi, index, (FMOD::ChannelGroupI **)group)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), group);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELGROUP,
      this,
      "ChannelGroup::getGroup",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x220c9f0 | Name: _ZN4FMOD12ChannelGroup14getParentGroupEPPS0_
FMOD_RESULT_0 __fastcall FMOD::ChannelGroup::getParentGroup(FMOD::ChannelGroup *const this, FMOD::ChannelGroup **group)
{
  FMOD_RESULT_0 ParentGroup; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelGroupI *channelgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  ParentGroup = FMOD::ChannelGroupI::validate(this, &channelgroupi, &lockScope);
  if ( (ParentGroup
     || (ParentGroup = FMOD::ChannelGroupI::getParentGroup(channelgroupi, (FMOD::ChannelGroupI **)group)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, group);
    FMOD_ReportError(
      ParentGroup,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELGROUP,
      this,
      "ChannelGroup::getParentGroup",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return ParentGroup;
}


// Address: 0x220caa0 | Name: _ZN4FMOD12ChannelGroup7getNameEPci
FMOD_RESULT_0 __fastcall FMOD::ChannelGroup::getName(FMOD::ChannelGroup *const this, char *name, int namelen)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelGroupI *channelgroupi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelGroupI::validate(this, &channelgroupi, &lockScope);
  if ( (v4 || (v4 = FMOD::ChannelGroupI::getName(channelgroupi, name, namelen)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, name);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), namelen);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELGROUP,
      this,
      "ChannelGroup::getName",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


// Address: 0x220cba0 | Name: _ZN4FMOD12ChannelGroup14getNumChannelsEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelGroup::getNumChannels(FMOD::ChannelGroup *const this, int *numchannels)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::ChannelGroupI *channelgroupi; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::ChannelGroupI::validate(this, &channelgroupi, &lockScope);
  if ( (v2 || (v2 = FMOD::ChannelGroupI::getNumChannels(channelgroupi, numchannels)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, numchannels);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELGROUP,
      this,
      "ChannelGroup::getNumChannels",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x220cc50 | Name: _ZN4FMOD12ChannelGroup10getChannelEiPPNS_7ChannelE
FMOD_RESULT_0 __fastcall FMOD::ChannelGroup::getChannel(
        FMOD::ChannelGroup *const this,
        int index,
        FMOD::Channel **channel)
{
  FMOD_RESULT_0 v4; // ebx
  int v6; // r13d
  int v7; // eax
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-148h] BYREF
  FMOD::ChannelGroupI *channelgroupi; // [rsp+8h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+10h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v4 = FMOD::ChannelGroupI::validate(this, &channelgroupi, &lockScope);
  if ( (v4 || (v4 = FMOD::ChannelGroupI::getChannel(channelgroupi, index, channel)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v6 = FMOD::FMOD_FormatArg(_buffer, 256, index);
    v7 = FMOD::FMOD_FormatArg(&_buffer[v6], 256 - v6, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v7 + v6], 256 - (v7 + v6), channel);
    FMOD_ReportError(
      v4,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_CHANNELGROUP,
      this,
      "ChannelGroup::getChannel",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v4;
}


