// Address: 0x2261b80 | Name: _ZN4FMOD10OutputALSA16getDescriptionExEv
FMOD::FMOD_OUTPUT_DESCRIPTION_EX *__cdecl FMOD::OutputALSA::getDescriptionEx()
{
  memset(&stru_2B06220, 0, sizeof(stru_2B06220));
  stru_2B06220.apiversion = 4;
  stru_2B06220.version = (unsigned int)&stru_30000;
  stru_2B06220.mType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_ALSA_0;
  stru_2B06220.mSize = 1840;
  stru_2B06220.name = "FMOD ALSA Output";
  stru_2B06220.getnumdrivers = FMOD::OutputALSA::getNumDriversCallback;
  stru_2B06220.getdriverinfo = FMOD::OutputALSA::getDriverInfoCallback;
  stru_2B06220.init = FMOD::OutputALSA::initCallback;
  stru_2B06220.close = FMOD::OutputALSA::closeCallback;
  stru_2B06220.start = FMOD::OutputALSA::startCallback;
  stru_2B06220.stop = FMOD::OutputALSA::stopCallback;
  stru_2B06220.gethandle = FMOD::OutputALSA::getHandleCallback;
  stru_2B06220.record_getnumdrivers = FMOD::OutputALSA::recordGetNumDriversCallback;
  stru_2B06220.record_getdriverinfo = FMOD::OutputALSA::recordGetDriverInfoCallback;
  stru_2B06220.record_start = FMOD::OutputALSA::recordStartCallback;
  stru_2B06220.record_stop = FMOD::OutputALSA::recordStopCallback;
  stru_2B06220.record_getposition = FMOD::OutputALSA::recordGetPositionCallback;
  stru_2B06220.record_lock = FMOD::OutputALSA::recordLockCallback;
  return &stru_2B06220;
}


// Address: 0x2261c90 | Name: _ZN4FMOD10OutputALSA11registerLibEv
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::registerLib(FMOD::OutputALSA *const this)
{
  FMOD_RESULT_0 ProcAddress; // ebx

  ProcAddress = FMOD_RESULT::FMOD_OK_0;
  if ( !*((_QWORD *)this + 176) )
  {
    ProcAddress = FMOD_OS_Library_Load("libasound.so.2", (FMOD_OS_LIBRARY **)this + 176);
    if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
    {
      ProcAddress = FMOD_OS_Library_GetProcAddress(
                      *((FMOD_OS_LIBRARY **)this + 176),
                      "snd_strerror",
                      (void **)this + 147);
      if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
      {
        ProcAddress = FMOD_OS_Library_GetProcAddress(
                        *((FMOD_OS_LIBRARY **)this + 176),
                        "snd_pcm_hw_params_sizeof",
                        (void **)this + 148);
        if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
        {
          ProcAddress = FMOD_OS_Library_GetProcAddress(
                          *((FMOD_OS_LIBRARY **)this + 176),
                          "snd_pcm_sw_params_sizeof",
                          (void **)this + 149);
          if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
          {
            ProcAddress = FMOD_OS_Library_GetProcAddress(
                            *((FMOD_OS_LIBRARY **)this + 176),
                            "snd_pcm_hw_params_any",
                            (void **)this + 150);
            if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
            {
              ProcAddress = FMOD_OS_Library_GetProcAddress(
                              *((FMOD_OS_LIBRARY **)this + 176),
                              "snd_pcm_hw_params_set_access",
                              (void **)this + 151);
              if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
              {
                ProcAddress = FMOD_OS_Library_GetProcAddress(
                                *((FMOD_OS_LIBRARY **)this + 176),
                                "snd_pcm_hw_params_set_format",
                                (void **)this + 152);
                if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                {
                  ProcAddress = FMOD_OS_Library_GetProcAddress(
                                  *((FMOD_OS_LIBRARY **)this + 176),
                                  "snd_pcm_hw_params_set_rate",
                                  (void **)this + 153);
                  if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                  {
                    ProcAddress = FMOD_OS_Library_GetProcAddress(
                                    *((FMOD_OS_LIBRARY **)this + 176),
                                    "snd_pcm_hw_params_set_channels",
                                    (void **)this + 154);
                    if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                    {
                      ProcAddress = FMOD_OS_Library_GetProcAddress(
                                      *((FMOD_OS_LIBRARY **)this + 176),
                                      "snd_pcm_hw_params_set_period_size_near",
                                      (void **)this + 155);
                      if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                      {
                        ProcAddress = FMOD_OS_Library_GetProcAddress(
                                        *((FMOD_OS_LIBRARY **)this + 176),
                                        "snd_pcm_hw_params_set_buffer_size_near",
                                        (void **)this + 156);
                        if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                        {
                          ProcAddress = FMOD_OS_Library_GetProcAddress(
                                          *((FMOD_OS_LIBRARY **)this + 176),
                                          "snd_pcm_hw_params_test_rate",
                                          (void **)this + 157);
                          if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                          {
                            ProcAddress = FMOD_OS_Library_GetProcAddress(
                                            *((FMOD_OS_LIBRARY **)this + 176),
                                            "snd_pcm_hw_params",
                                            (void **)this + 158);
                            if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                            {
                              ProcAddress = FMOD_OS_Library_GetProcAddress(
                                              *((FMOD_OS_LIBRARY **)this + 176),
                                              "snd_pcm_sw_params_current",
                                              (void **)this + 159);
                              if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                              {
                                ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                *((FMOD_OS_LIBRARY **)this + 176),
                                                "snd_pcm_sw_params_set_start_threshold",
                                                (void **)this + 160);
                                if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                {
                                  ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                  *((FMOD_OS_LIBRARY **)this + 176),
                                                  "snd_pcm_sw_params_set_avail_min",
                                                  (void **)this + 161);
                                  if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                  {
                                    ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                    *((FMOD_OS_LIBRARY **)this + 176),
                                                    "snd_pcm_sw_params",
                                                    (void **)this + 162);
                                    if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                    {
                                      ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                      *((FMOD_OS_LIBRARY **)this + 176),
                                                      "snd_pcm_open",
                                                      (void **)this + 163);
                                      if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                      {
                                        ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                        *((FMOD_OS_LIBRARY **)this + 176),
                                                        "snd_pcm_close",
                                                        (void **)this + 164);
                                        if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                        {
                                          ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                          *((FMOD_OS_LIBRARY **)this + 176),
                                                          "snd_pcm_prepare",
                                                          (void **)this + 165);
                                          if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                          {
                                            ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                            *((FMOD_OS_LIBRARY **)this + 176),
                                                            "snd_pcm_start",
                                                            (void **)this + 166);
                                            if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                            {
                                              ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                              *((FMOD_OS_LIBRARY **)this + 176),
                                                              "snd_pcm_resume",
                                                              (void **)this + 167);
                                              if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                              {
                                                ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                                *((FMOD_OS_LIBRARY **)this + 176),
                                                                "snd_pcm_writei",
                                                                (void **)this + 169);
                                                if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                                {
                                                  ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                                  *((FMOD_OS_LIBRARY **)this + 176),
                                                                  "snd_pcm_readi",
                                                                  (void **)this + 170);
                                                  if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                                  {
                                                    ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                                    *((FMOD_OS_LIBRARY **)this + 176),
                                                                    "snd_pcm_avail_update",
                                                                    (void **)this + 171);
                                                    if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                                    {
                                                      ProcAddress = FMOD_OS_Library_GetProcAddress(
                                                                      *((FMOD_OS_LIBRARY **)this + 176),
                                                                      "snd_pcm_nonblock",
                                                                      (void **)this + 168);
                                                      if ( ProcAddress == FMOD_RESULT::FMOD_OK_0 )
                                                      {
                                                        FMOD_OS_Library_GetProcAddress(
                                                          *((FMOD_OS_LIBRARY **)this + 176),
                                                          "snd_asoundlib_version",
                                                          (void **)this + 172);
                                                        FMOD_OS_Library_GetProcAddress(
                                                          *((FMOD_OS_LIBRARY **)this + 176),
                                                          "snd_device_name_hint",
                                                          (void **)this + 175);
                                                        FMOD_OS_Library_GetProcAddress(
                                                          *((FMOD_OS_LIBRARY **)this + 176),
                                                          "snd_device_name_get_hint",
                                                          (void **)this + 173);
                                                        FMOD_OS_Library_GetProcAddress(
                                                          *((FMOD_OS_LIBRARY **)this + 176),
                                                          "snd_device_name_free_hint",
                                                          (void **)this + 174);
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return ProcAddress;
}


// Address: 0x22620c0 | Name: _ZN4FMOD10OutputALSA9enumerateEv
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::enumerate(FMOD::OutputALSA *const this)
{
  FMOD_RESULT_0 result; // eax
  char *v3; // r15
  unsigned int (__fastcall *v4)(__int64, const char *, void ***); // rax
  unsigned __int64 v5; // rsi
  void **v6; // r12
  void *v7; // rdi
  bool v8; // zf
  const char *v9; // rdi
  __int64 v10; // rcx
  char v11; // r14
  char v12; // r13
  bool v13; // zf
  const char *v14; // rdi
  __int64 v15; // rcx
  char *v16; // rax
  __int64 v17; // rdx
  int v18; // esi
  int v19; // ecx
  int v20; // eax
  int v21; // r14d
  int v22; // eax
  char *v23; // rbp
  char *v24; // rax
  char *v25; // rax
  __int64 v26; // rdx
  int v27; // esi
  int v28; // ecx
  int v29; // eax
  int v30; // r13d
  int v31; // eax
  void *v32; // r14
  __int64 v33; // rax
  _QWORD *v34; // rax
  unsigned __int64 *v35; // rax
  unsigned __int64 v36; // rcx
  void **v37; // rdi
  _QWORD *v38; // rax
  char *v39; // rax
  __int64 v40; // rdx
  int v41; // esi
  int v42; // ecx
  int v43; // eax
  int v44; // ebp
  int v45; // eax
  char *v46; // rax
  __int64 v47; // rdx
  int v48; // esi
  int v49; // ecx
  int v50; // eax
  int v51; // ebp
  int v52; // eax
  void *v53; // r12
  __int64 v54; // rax
  void *v55; // rsi
  _QWORD *v56; // rax
  _QWORD *v57; // rax
  void *v58; // r8
  __int64 v59; // rax
  void *v60; // r12
  __int64 v61; // rax
  void *v62; // rsi
  int v63; // [rsp+0h] [rbp-58h]
  bool foundSpecifiedDefault; // [rsp+7h] [rbp-51h]
  void *v65; // [rsp+8h] [rbp-50h]
  void **hintList; // [rsp+10h] [rbp-48h] BYREF
  char *v67; // [rsp+18h] [rbp-40h]

  result = FMOD_RESULT::FMOD_OK_0;
  if ( !*((_BYTE *)this + 784) )
  {
    result = FMOD::OutputALSA::registerLib(this);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v3 = getenv("FMOD_ALSA_DEVICE");
      v4 = (unsigned int (__fastcall *)(__int64, const char *, void ***))*((_QWORD *)this + 175);
      if ( v4 )
      {
        hintList = 0;
        v5 = (unsigned __int64)"pcm";
        if ( v4(0xFFFFFFFFLL, "pcm", &hintList) )
          return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
        v6 = hintList;
        v7 = *hintList;
        if ( !*hintList )
        {
          v37 = hintList;
          goto LABEL_57;
        }
        foundSpecifiedDefault = 0;
        v63 = -1;
        while ( 1 )
        {
          v5 = (unsigned __int64)"IOID";
          v23 = (char *)(*((__int64 (__fastcall **)(void *, const char *))this + 173))(v7, "NAME");
          v24 = (char *)(*((__int64 (__fastcall **)(void *, const char *))this + 173))(*v6, "IOID");
          if ( v24 )
          {
            v8 = strcmp(v24, "Output") == 0;
            v9 = "Input";
            v5 = (unsigned __int64)v24;
            v10 = 6;
            v11 = v8;
            do
            {
              if ( !v10 )
                break;
              v8 = *(_BYTE *)v5++ == *v9++;
              --v10;
            }
            while ( v8 );
            v12 = v8;
            free(v24);
          }
          else
          {
            v12 = 1;
            v11 = 1;
          }
          v13 = v23 == 0;
          if ( !v23 )
            goto LABEL_30;
          v14 = "null";
          v15 = 5;
          v5 = (unsigned __int64)v23;
          do
          {
            if ( !v15 )
              break;
            v13 = *(_BYTE *)v5++ == *v14++;
            --v15;
          }
          while ( v13 );
          if ( v13 )
            goto LABEL_29;
          if ( v11 )
          {
            if ( v3 && !strcmp(v23, v3) )
            {
              foundSpecifiedDefault = 1;
              v63 = *((_DWORD *)this + 288);
            }
            else if ( !foundSpecifiedDefault
                   && (!strcmp(v23, "default")
                    || v63 == -1 && (!memcmp(v23, "default:", 8u) || !memcmp(v23, "sysdefault:", 0xBu))) )
            {
              v63 = *((_DWORD *)this + 288);
            }
            v16 = FMOD_strdup(v23);
            v17 = *((int *)this + 288);
            v18 = *((_DWORD *)this + 289);
            v67 = v16;
            v5 = (unsigned int)(v18 >> 31);
            v19 = v17 + 1;
            v20 = (v5 ^ *((_DWORD *)this + 289)) - v5;
            if ( (int)v17 + 1 <= v20 )
            {
              v38 = (_QWORD *)*((_QWORD *)this + 143);
LABEL_60:
              v38[v17] = v67;
              ++*((_DWORD *)this + 288);
              goto LABEL_28;
            }
            v21 = 8;
            v22 = (int)(float)((float)v20 * 1.5);
            if ( v22 >= v19 )
              v19 = v22;
            if ( v19 > 7 )
              v21 = v19;
            if ( (int)v17 <= v21 )
            {
              v5 = (unsigned int)(8 * v21);
              if ( (unsigned int)(v5 - 1) <= 0x3FFFFFFE )
              {
                v58 = FMOD::MemPool::alloc(
                        off_286F358->gSystemMemPool,
                        v5,
                        "../../../core_api/src/fmod_memory.h",
                        232,
                        0,
                        0);
                if ( v58 )
                {
                  v59 = *((int *)this + 288);
                  if ( (_DWORD)v59 )
                  {
                    v5 = *((_QWORD *)this + 143);
                    v58 = memcpy_0(v58, (const void *)v5, 8 * v59);
                  }
                  if ( *((int *)this + 289) > 0 )
                  {
                    v5 = *((_QWORD *)this + 143);
                    if ( v5 )
                    {
                      v65 = v58;
                      FMOD::MemPool::free(
                        off_286F358->gSystemMemPool,
                        (void *)v5,
                        "../../../core_api/src/fmod_memory.h",
                        244);
                      v58 = v65;
                    }
                  }
                  *((_QWORD *)this + 143) = v58;
                  *((_DWORD *)this + 289) = v21;
                  v38 = v58;
                  v17 = *((int *)this + 288);
                  goto LABEL_60;
                }
              }
            }
          }
LABEL_28:
          if ( v12 )
          {
            v25 = FMOD_strdup(v23);
            v26 = *((int *)this + 292);
            v27 = *((_DWORD *)this + 293);
            v67 = v25;
            v5 = (unsigned int)(v27 >> 31);
            v28 = v26 + 1;
            v29 = (v5 ^ *((_DWORD *)this + 293)) - v5;
            if ( (int)v26 + 1 <= v29 )
            {
              v34 = (_QWORD *)*((_QWORD *)this + 145);
            }
            else
            {
              v30 = 8;
              v31 = (int)(float)((float)v29 * 1.5);
              if ( v31 >= v28 )
                v28 = v31;
              if ( v28 > 7 )
                v30 = v28;
              if ( (int)v26 > v30 )
                goto LABEL_29;
              v5 = (unsigned int)(8 * v30);
              if ( (unsigned int)(v5 - 1) > 0x3FFFFFFE )
                goto LABEL_29;
              v32 = FMOD::MemPool::alloc(
                      off_286F358->gSystemMemPool,
                      v5,
                      "../../../core_api/src/fmod_memory.h",
                      232,
                      0,
                      0);
              if ( !v32 )
                goto LABEL_29;
              v33 = *((int *)this + 292);
              if ( (_DWORD)v33 )
                memcpy_0(v32, *((const void **)this + 145), 8 * v33);
              v5 = *((unsigned int *)this + 293);
              if ( (int)v5 > 0 )
              {
                v5 = *((_QWORD *)this + 145);
                if ( v5 )
                  FMOD::MemPool::free(
                    off_286F358->gSystemMemPool,
                    (void *)v5,
                    "../../../core_api/src/fmod_memory.h",
                    244);
              }
              v26 = *((int *)this + 292);
              *((_QWORD *)this + 145) = v32;
              v34 = v32;
              *((_DWORD *)this + 293) = v30;
            }
            v34[v26] = v67;
            ++*((_DWORD *)this + 292);
          }
LABEL_29:
          free(v23);
LABEL_30:
          v7 = *++v6;
          if ( !*v6 )
          {
            if ( v63 > 0 )
            {
              v35 = (unsigned __int64 *)*((_QWORD *)this + 143);
              v36 = *v35;
              v5 = v35[v63];
              *v35 = v5;
              *(_QWORD *)(*((_QWORD *)this + 143) + 8LL * v63) = v36;
            }
            v37 = hintList;
LABEL_57:
            if ( !(*((unsigned int (__fastcall **)(void **, unsigned __int64))this + 174))(v37, v5) )
            {
LABEL_58:
              *((_BYTE *)this + 784) = 1;
              return FMOD_RESULT::FMOD_OK_0;
            }
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          }
        }
      }
      v39 = FMOD_strdup("default");
      v40 = *((int *)this + 288);
      v41 = *((_DWORD *)this + 289);
      v67 = v39;
      v42 = v40 + 1;
      v43 = ((v41 >> 31) ^ *((_DWORD *)this + 289)) - (v41 >> 31);
      if ( (int)v40 + 1 <= v43 )
      {
        v57 = (_QWORD *)*((_QWORD *)this + 143);
      }
      else
      {
        v44 = 8;
        v45 = (int)(float)((float)v43 * 1.5);
        if ( v45 >= v42 )
          v42 = v45;
        if ( v42 > 7 )
          v44 = v42;
        if ( (int)v40 > v44
          || (unsigned int)(8 * v44 - 1) > 0x3FFFFFFE
          || (v60 = FMOD::MemPool::alloc(
                      off_286F358->gSystemMemPool,
                      8 * v44,
                      "../../../core_api/src/fmod_memory.h",
                      232,
                      0,
                      0)) == 0 )
        {
LABEL_67:
          v46 = FMOD_strdup("default");
          v47 = *((int *)this + 292);
          v48 = *((_DWORD *)this + 293);
          v67 = v46;
          v49 = v47 + 1;
          v50 = ((v48 >> 31) ^ *((_DWORD *)this + 293)) - (v48 >> 31);
          if ( (int)v47 + 1 <= v50 )
          {
            v56 = (_QWORD *)*((_QWORD *)this + 145);
          }
          else
          {
            v51 = 8;
            v52 = (int)(float)((float)v50 * 1.5);
            if ( v52 >= v49 )
              v49 = v52;
            if ( v49 > 7 )
              v51 = v49;
            if ( (int)v47 > v51 )
              goto LABEL_58;
            if ( (unsigned int)(8 * v51 - 1) > 0x3FFFFFFE )
              goto LABEL_58;
            v53 = FMOD::MemPool::alloc(
                    off_286F358->gSystemMemPool,
                    8 * v51,
                    "../../../core_api/src/fmod_memory.h",
                    232,
                    0,
                    0);
            if ( !v53 )
              goto LABEL_58;
            v54 = *((int *)this + 292);
            if ( (_DWORD)v54 )
              memcpy_0(v53, *((const void **)this + 145), 8 * v54);
            if ( *((int *)this + 293) > 0 )
            {
              v55 = (void *)*((_QWORD *)this + 145);
              if ( v55 )
                FMOD::MemPool::free(off_286F358->gSystemMemPool, v55, "../../../core_api/src/fmod_memory.h", 244);
            }
            v47 = *((int *)this + 292);
            *((_QWORD *)this + 145) = v53;
            v56 = v53;
            *((_DWORD *)this + 293) = v51;
          }
          v56[v47] = v67;
          ++*((_DWORD *)this + 292);
          goto LABEL_58;
        }
        v61 = *((int *)this + 288);
        if ( (_DWORD)v61 )
          memcpy_0(v60, *((const void **)this + 143), 8 * v61);
        if ( *((int *)this + 289) > 0 )
        {
          v62 = (void *)*((_QWORD *)this + 143);
          if ( v62 )
            FMOD::MemPool::free(off_286F358->gSystemMemPool, v62, "../../../core_api/src/fmod_memory.h", 244);
        }
        *((_QWORD *)this + 143) = v60;
        *((_DWORD *)this + 289) = v44;
        v57 = v60;
        v40 = *((int *)this + 288);
      }
      v57[v40] = v67;
      ++*((_DWORD *)this + 288);
      goto LABEL_67;
    }
  }
  return result;
}


// Address: 0x2262860 | Name: _ZN4FMOD10OutputALSA13getNumDriversEPi
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::getNumDrivers(FMOD::OutputALSA *const this, int *numDrivers)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::OutputALSA::enumerate(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( numDrivers )
      *numDrivers = *((_DWORD *)this + 288);
  }
  return result;
}


// Address: 0x2262890 | Name: _ZN4FMOD10OutputALSA21getNumDriversCallbackEP17FMOD_OUTPUT_STATEPi
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::getNumDriversCallback(FMOD_OUTPUT_STATE *output, int *numDrivers)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::getNumDrivers(p_requestreset, numDrivers);
}


// Address: 0x22628b0 | Name: _ZN4FMOD15getGUIDFromNameEPKcP9FMOD_GUID
FMOD_RESULT_0 __fastcall FMOD::getGUIDFromName(const char *name, FMOD_GUID *guid)
{
  int v2; // eax
  unsigned int i; // edx

  v2 = *name;
  for ( i = -2128831035; *name; v2 = *name )
  {
    ++name;
    i = 16777619 * (i ^ v2);
  }
  *(_QWORD *)&guid->Data1 = 0;
  *(_QWORD *)guid->Data4 = 0;
  guid->Data1 = i;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22628f0 | Name: _ZN4FMOD22getSpeakerModeFromNameEPKcP16FMOD_SPEAKERMODEPi
FMOD_RESULT_0 __fastcall FMOD::getSpeakerModeFromName(
        const char *name,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels)
{
  if ( FMOD_strstr(name, "surround40") )
  {
    *speakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_QUAD_0;
    *speakerModeChannels = 4;
  }
  else if ( FMOD_strstr(name, "surround50") )
  {
    *speakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0;
    *speakerModeChannels = 5;
  }
  else if ( FMOD_strstr(name, "surround51") )
  {
    *speakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_5POINT1_0;
    *speakerModeChannels = 6;
  }
  else if ( FMOD_strstr(name, "surround71") )
  {
    *speakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0;
    *speakerModeChannels = 8;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22629a0 | Name: _ZN4FMOD10OutputALSA22getSupportedSampleRateEPKcPi15_snd_pcm_stream
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::getSupportedSampleRate(
        FMOD::OutputALSA *const this,
        const char *deviceName,
        int *rate,
        snd_pcm_stream_t stream)
{
  void *v5; // rsp
  size_t v6; // rax
  int *v7; // r15
  unsigned int v8; // r12d
  __int64 v9; // [rsp+0h] [rbp-80h] BYREF
  int *ratea; // [rsp+8h] [rbp-78h]
  snd_pcm_t *pcm; // [rsp+18h] [rbp-68h] BYREF
  int rates[9]; // [rsp+20h] [rbp-60h] BYREF
  int v13; // [rsp+44h] [rbp-3Ch] BYREF

  ratea = rate;
  pcm = 0;
  if ( !(*((unsigned int (__fastcall **)(snd_pcm_t **, const char *, _QWORD, __int64))this + 163))(
          &pcm,
          deviceName,
          (unsigned int)stream,
          1) )
  {
    v5 = alloca((*((__int64 (**)(void))this + 148))() + 15);
    v6 = (*((__int64 (**)(void))this + 148))();
    memset(&v9, 0, v6);
    if ( (*((int (__fastcall **)(snd_pcm_t *, __int64 *))this + 150))(pcm, &v9) >= 0 )
    {
      rates[1] = 48000;
      rates[2] = 44100;
      rates[3] = 32000;
      v7 = &rates[1];
      rates[4] = 24000;
      rates[5] = 22050;
      v8 = *ratea;
      rates[6] = 16000;
      rates[7] = 11025;
      rates[8] = 8000;
      rates[0] = v8;
      while ( (*((unsigned int (__fastcall **)(snd_pcm_t *, __int64 *, _QWORD, _QWORD))this + 157))(pcm, &v9, v8, 0) )
      {
        if ( v7 == &v13 )
          goto LABEL_8;
        v8 = *v7++;
      }
      *ratea = v8;
    }
LABEL_8:
    (*((void (__fastcall **)(snd_pcm_t *))this + 164))(pcm);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2262ad0 | Name: _ZN4FMOD10OutputALSA13getDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::getDriverInfo(
        FMOD::OutputALSA *const this,
        int id,
        char *name,
        int nameLen,
        FMOD_GUID *guid,
        int *systemRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels)
{
  FMOD_RESULT_0 result; // eax
  __int64 v12; // r13
  __int64 v13; // rax

  result = FMOD::OutputALSA::enumerate(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( name && nameLen > 0 )
    {
      v12 = 8LL * id;
      FMOD_strcpy_safe(name, *(const char **)(*((_QWORD *)this + 143) + v12), nameLen);
    }
    else
    {
      v12 = 8LL * id;
    }
    if ( !guid
      || (result = FMOD::getGUIDFromName(*(const char **)(*((_QWORD *)this + 143) + v12), guid)) == FMOD_RESULT::FMOD_OK_0 )
    {
      *systemRate = 48000;
      result = FMOD::OutputALSA::getSupportedSampleRate(
                 this,
                 *(const char **)(*((_QWORD *)this + 143) + v12),
                 systemRate,
                 _snd_pcm_stream::SND_PCM_STREAM_PLAYBACK);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        *speakerModeChannels = 2;
        v13 = *((_QWORD *)this + 143);
        *speakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0;
        return FMOD::getSpeakerModeFromName(*(const char **)(v13 + v12), speakerMode, speakerModeChannels);
      }
    }
  }
  return result;
}


// Address: 0x2262bd0 | Name: _ZN4FMOD10OutputALSA21getDriverInfoCallbackEP17FMOD_OUTPUT_STATEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES6_
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::getDriverInfoCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        char *name,
        int nameLen,
        FMOD_GUID *guid,
        int *systemRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::getDriverInfo(
           p_requestreset,
           id,
           name,
           nameLen,
           guid,
           systemRate,
           speakerMode,
           speakerModeChannels);
}


// Address: 0x2262bf0 | Name: _ZN4FMOD10OutputALSA4initEijPiP16FMOD_SPEAKERMODES1_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::init(
        FMOD::OutputALSA *const this,
        int id,
        FMOD_INITFLAGS a3,
        int *outputRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels,
        FMOD_SOUND_FORMAT_0 *outputFormat,
        int dspBufferLength,
        int dspNumBuffers,
        void *a10)
{
  FMOD_RESULT_0 result; // eax
  int v15; // edx
  __int64 v16; // rax
  void *v17; // rsp
  size_t v18; // rax
  __int64 v19; // rdi
  __int64 v20; // rdi
  void *v21; // rsp
  size_t v22; // rax
  snd_pcm_uframes_t v23; // rdx
  int v24; // eax
  void *v25; // rax
  snd_pcm_uframes_t periodSize; // [rsp+0h] [rbp-40h] BYREF
  snd_pcm_uframes_t bufferSize[7]; // [rsp+8h] [rbp-38h] BYREF

  result = FMOD::OutputALSA::enumerate(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v15 = *((_DWORD *)this + 288);
    result = FMOD_RESULT::FMOD_ERR_OUTPUT_NODRIVERS_0;
    if ( v15 )
    {
      LOBYTE(result) = 31;
      if ( id >= 0 && v15 > id )
      {
        if ( *speakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
        {
          *speakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0;
          *speakerModeChannels = 2;
        }
        result = FMOD::OutputALSA::getSupportedSampleRate(
                   this,
                   *(const char **)(*((_QWORD *)this + 143) + 8LL * id),
                   outputRate,
                   _snd_pcm_stream::SND_PCM_STREAM_PLAYBACK);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          *outputFormat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
          v16 = *((_QWORD *)this + 143);
          *((_DWORD *)this + 23) = 5;
          if ( (*((unsigned int (__fastcall **)(char *, _QWORD, _QWORD, __int64))this + 163))(
                 (char *)this + 1416,
                 *(_QWORD *)(v16 + 8LL * id),
                 0,
                 1) )
          {
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          }
          if ( (*((unsigned int (__fastcall **)(_QWORD, _QWORD))this + 168))(*((_QWORD *)this + 177), 0) )
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          v17 = alloca((*((__int64 (**)(void))this + 148))() + 15);
          v18 = (*((__int64 (**)(void))this + 148))();
          memset(&periodSize, 0, v18);
          if ( (*((int (__fastcall **)(_QWORD, snd_pcm_uframes_t *))this + 150))(*((_QWORD *)this + 177), &periodSize) < 0 )
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          if ( (*((unsigned int (__fastcall **)(_QWORD, snd_pcm_uframes_t *, __int64))this + 151))(
                 *((_QWORD *)this + 177),
                 &periodSize,
                 3) )
          {
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          }
          if ( (*((unsigned int (__fastcall **)(_QWORD, snd_pcm_uframes_t *, __int64))this + 152))(
                 *((_QWORD *)this + 177),
                 &periodSize,
                 2) )
          {
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          }
          if ( (*((unsigned int (__fastcall **)(_QWORD, snd_pcm_uframes_t *, _QWORD, _QWORD))this + 153))(
                 *((_QWORD *)this + 177),
                 &periodSize,
                 (unsigned int)*outputRate,
                 0) )
          {
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          }
          if ( (*((unsigned int (__fastcall **)(_QWORD, snd_pcm_uframes_t *, _QWORD))this + 154))(
                 *((_QWORD *)this + 177),
                 &periodSize,
                 (unsigned int)*speakerModeChannels) )
          {
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          }
          v19 = *((_QWORD *)this + 177);
          periodSize = dspBufferLength;
          if ( (*((unsigned int (__fastcall **)(__int64, snd_pcm_uframes_t *, snd_pcm_uframes_t *, _QWORD))this + 155))(
                 v19,
                 &periodSize,
                 &periodSize,
                 0) )
          {
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          }
          v20 = *((_QWORD *)this + 177);
          bufferSize[0] = periodSize * dspNumBuffers;
          if ( (*((unsigned int (__fastcall **)(__int64, snd_pcm_uframes_t *, snd_pcm_uframes_t *))this + 156))(
                 v20,
                 &periodSize,
                 bufferSize) )
          {
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          }
          if ( (*((unsigned int (__fastcall **)(_QWORD, snd_pcm_uframes_t *))this + 158))(
                 *((_QWORD *)this + 177),
                 &periodSize) )
          {
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          }
          v21 = alloca((*((__int64 (**)(void))this + 149))() + 15);
          v22 = (*((__int64 (**)(void))this + 149))();
          memset(&periodSize, 0, v22);
          if ( (*((unsigned int (__fastcall **)(_QWORD, snd_pcm_uframes_t *))this + 159))(
                 *((_QWORD *)this + 177),
                 &periodSize)
            || (*((unsigned int (__fastcall **)(_QWORD, snd_pcm_uframes_t *, snd_pcm_uframes_t))this + 160))(
                 *((_QWORD *)this + 177),
                 &periodSize,
                 periodSize * (bufferSize[0] / periodSize))
            || (*((unsigned int (__fastcall **)(_QWORD, snd_pcm_uframes_t *, snd_pcm_uframes_t))this + 161))(
                 *((_QWORD *)this + 177),
                 &periodSize,
                 periodSize)
            || (*((unsigned int (__fastcall **)(_QWORD, snd_pcm_uframes_t *))this + 162))(
                 *((_QWORD *)this + 177),
                 &periodSize) )
          {
            return FMOD_RESULT::FMOD_ERR_OUTPUT_INIT_0;
          }
          else
          {
            LODWORD(v23) = 2;
            if ( (dspBufferLength + 2 * periodSize - 1) / dspBufferLength >= 2 )
              v23 = (dspBufferLength + 2 * periodSize - 1) / dspBufferLength;
            result = FMOD::OutputRingBuffer::init(
                       (FMOD::OutputRingBuffer *const)((char *)this + 1424),
                       dspBufferLength,
                       v23,
                       2 * *speakerModeChannels,
                       0);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              v24 = periodSize;
              *((_DWORD *)this + 370) = periodSize;
              v25 = FMOD::MemPool::calloc(
                      off_286F358->gSystemMemPool,
                      2 * *speakerModeChannels * v24,
                      "../../../core_api/platforms/linux/src/fmod_output_alsa.cpp",
                      514,
                      0);
              *((_QWORD *)this + 184) = v25;
              return v25 == 0 ? 0x26 : 0;
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x2262f10 | Name: _ZN4FMOD10OutputALSA12initCallbackEP17FMOD_OUTPUT_STATEijPiP16FMOD_SPEAKERMODES3_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::initCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        FMOD_INITFLAGS flags,
        int *outputRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels,
        FMOD_SOUND_FORMAT_0 *outputFormat,
        int dspBufferLength,
        int dspNumBuffers,
        void *extraDriverData)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::init(
           p_requestreset,
           id,
           flags,
           outputRate,
           speakerMode,
           speakerModeChannels,
           outputFormat,
           dspBufferLength,
           dspNumBuffers,
           extraDriverData);
}


// Address: 0x2262f30 | Name: _ZN4FMOD10OutputALSA5closeEv
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::close(FMOD::OutputALSA *const this)
{
  void *v2; // rsi
  __int64 v3; // rax
  __int64 v4; // r12
  int v5; // ebp
  void *v6; // rsi
  bool v7; // zf
  bool v8; // cc
  __int64 v9; // rax
  __int64 v10; // r12
  int v11; // ebp
  void *v12; // rsi
  bool v13; // cc
  FMOD_OS_LIBRARY *v14; // rdi
  FMOD_RESULT_0 result; // eax
  void *v16; // rsi
  void *v17; // rsi

  v2 = (void *)*((_QWORD *)this + 184);
  if ( v2 )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      v2,
      "../../../core_api/platforms/linux/src/fmod_output_alsa.cpp",
      536);
    *((_QWORD *)this + 184) = 0;
  }
  FMOD::OutputRingBuffer::release((FMOD::OutputRingBuffer *const)((char *)this + 1424));
  if ( *((_QWORD *)this + 177) )
  {
    (*((void (**)(void))this + 164))();
    *((_QWORD *)this + 177) = 0;
  }
  v3 = *((int *)this + 288);
  if ( (int)v3 > 0 )
  {
    v4 = 0;
    v5 = 0;
    do
    {
      ++v5;
      v6 = *(void **)(*((_QWORD *)this + 143) + v4);
      v4 += 8;
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        v6,
        "../../../core_api/platforms/linux/src/fmod_output_alsa.cpp",
        549);
      v3 = *((int *)this + 288);
    }
    while ( (int)v3 > v5 );
  }
  if ( (int)v3 < 0 )
    memset((void *)(*((_QWORD *)this + 143) + 8 * v3), 0, 8LL * -(int)v3);
  v7 = *((_DWORD *)this + 289) == 0;
  v8 = *((_DWORD *)this + 289) <= 0;
  *((_DWORD *)this + 288) = 0;
  if ( !v7 )
  {
    if ( !v8 )
    {
      v17 = (void *)*((_QWORD *)this + 143);
      if ( v17 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v17, "../../../core_api/src/fmod_memory.h", 244);
    }
    *((_QWORD *)this + 143) = 0;
    *((_DWORD *)this + 289) = 0;
  }
  v9 = *((int *)this + 292);
  if ( (int)v9 > 0 )
  {
    v10 = 0;
    v11 = 0;
    do
    {
      ++v11;
      v12 = *(void **)(*((_QWORD *)this + 145) + v10);
      v10 += 8;
      FMOD::MemPool::free(
        off_286F358->gSystemMemPool,
        v12,
        "../../../core_api/platforms/linux/src/fmod_output_alsa.cpp",
        555);
      v9 = *((int *)this + 292);
    }
    while ( (int)v9 > v11 );
  }
  if ( (int)v9 < 0 )
    memset((void *)(*((_QWORD *)this + 145) + 8 * v9), 0, 8LL * -(int)v9);
  v7 = *((_DWORD *)this + 293) == 0;
  v13 = *((_DWORD *)this + 293) <= 0;
  *((_DWORD *)this + 292) = 0;
  if ( !v7 )
  {
    if ( !v13 )
    {
      v16 = (void *)*((_QWORD *)this + 145);
      if ( v16 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v16, "../../../core_api/src/fmod_memory.h", 244);
    }
    *((_QWORD *)this + 145) = 0;
    *((_DWORD *)this + 293) = 0;
  }
  v14 = (FMOD_OS_LIBRARY *)*((_QWORD *)this + 176);
  result = FMOD_RESULT::FMOD_OK_0;
  *((_BYTE *)this + 784) = 0;
  if ( v14 )
  {
    result = FMOD_OS_Library_Free(v14);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      *((_QWORD *)this + 176) = 0;
  }
  return result;
}


// Address: 0x22631b0 | Name: _ZN4FMOD10OutputALSA13closeCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::closeCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::close(p_requestreset);
}


// Address: 0x22631d0 | Name: _ZN4FMOD10OutputALSA5startEv
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::start(FMOD::OutputALSA *const this)
{
  return FMOD::Thread::initThread(
           (FMOD::Thread *const)((char *)this + 1488),
           "FMOD mixer thread",
           FMOD::OutputALSA::updateMixer,
           this,
           FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_MIXER,
           FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_CRITICAL,
           *(_DWORD *)(*((_QWORD *)this + 9) + 71044LL),
           0,
           0,
           *((FMOD::SystemI **)this + 9),
           1);
}


// Address: 0x2263230 | Name: _ZN4FMOD10OutputALSA13startCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::startCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::start(p_requestreset);
}


// Address: 0x2263250 | Name: _ZN4FMOD10OutputALSA4stopEv
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::stop(FMOD::OutputALSA *const this)
{
  return FMOD::Thread::closeThread((FMOD::Thread *const)((char *)this + 1488));
}


// Address: 0x2263260 | Name: _ZN4FMOD10OutputALSA12stopCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::stopCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::stop(p_requestreset);
}


// Address: 0x2263280 | Name: _ZN4FMOD10OutputALSA11updateMixerEv
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::updateMixer(FMOD::OutputALSA *const this)
{
  FMOD::OutputRingBuffer *v1; // rbp
  unsigned int v2; // r13d
  unsigned int (__fastcall *v3)(char *, char *, _QWORD); // r14
  char *v4; // rax
  FMOD_RESULT_0 result; // eax
  unsigned int v6; // ecx
  signed int v7; // esi
  int v8; // eax

  v1 = (FMOD::OutputRingBuffer *)((char *)this + 1424);
  while ( 1 )
  {
    v6 = *((_DWORD *)this + 362);
    v7 = *((_DWORD *)this + 370);
    if ( v7 <= (int)((*((_DWORD *)this + 367) - *((_DWORD *)this + 366)) / v6) )
      break;
    v2 = *((_DWORD *)this + 358);
    v3 = (unsigned int (__fastcall *)(char *, char *, _QWORD))*((_QWORD *)this + 2);
    v4 = FMOD::OutputRingBuffer::writePtrAdvance(v1);
    result = v3((char *)this + 8, v4, v2);
    if ( result )
      return result;
  }
  FMOD::OutputRingBuffer::read(v1, *((char **)this + 184), v7 * v6);
  v8 = (*((__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))this + 169))(
         *((_QWORD *)this + 177),
         *((_QWORD *)this + 184),
         *((int *)this + 370));
  if ( *((_DWORD *)this + 370) == v8 )
    return FMOD_RESULT::FMOD_OK_0;
  switch ( v8 )
  {
    case -86:
      while ( 1 )
      {
        v8 = (*((__int64 (__fastcall **)(_QWORD))this + 167))(*((_QWORD *)this + 177));
        if ( v8 != -11 )
          break;
        FMOD_OS_Time_Sleep(0x3E8u);
      }
      if ( v8 == -38 )
        return (*((unsigned int (__fastcall **)(_QWORD))this + 165))(*((_QWORD *)this + 177)) != 0 ? 0x31 : 0;
      break;
    case -38:
      return (*((unsigned int (__fastcall **)(_QWORD))this + 165))(*((_QWORD *)this + 177)) != 0 ? 0x31 : 0;
    case -32:
      return (*((unsigned int (__fastcall **)(_QWORD))this + 165))(*((_QWORD *)this + 177)) != 0 ? 0x31 : 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2263390 | Name: j__ZN4FMOD10OutputALSA11updateMixerEv
// attributes: thunk
void __fastcall FMOD::OutputALSA::updateMixer(void *userData)
{
  _ZN4FMOD10OutputALSA11updateMixerEv((FMOD::OutputALSA *const)userData);
}


// Address: 0x22633a0 | Name: _ZN4FMOD10OutputALSA9getHandleEPPv
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::getHandle(FMOD::OutputALSA *const this, void **handle)
{
  *handle = (void *)*((_QWORD *)this + 177);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22633b0 | Name: _ZN4FMOD10OutputALSA17getHandleCallbackEP17FMOD_OUTPUT_STATEPPv
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::getHandleCallback(FMOD_OUTPUT_STATE *output, void **handle)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::getHandle(p_requestreset, handle);
}


// Address: 0x22633d0 | Name: _ZN4FMOD10OutputALSA19recordGetNumDriversEPiS1_
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordGetNumDrivers(
        FMOD::OutputALSA *const this,
        int *numDrivers,
        FMOD_BOOL *enumerationChanged)
{
  *numDrivers = *((_DWORD *)this + 292);
  *enumerationChanged = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22633f0 | Name: _ZN4FMOD10OutputALSA27recordGetNumDriversCallbackEP17FMOD_OUTPUT_STATEPiS3_
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordGetNumDriversCallback(
        FMOD_OUTPUT_STATE *output,
        int *numDrivers,
        FMOD_BOOL *enumerationChanged)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::recordGetNumDrivers(p_requestreset, numDrivers, enumerationChanged);
}


// Address: 0x2263410 | Name: _ZN4FMOD10OutputALSA19recordGetDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordGetDriverInfo(
        FMOD::OutputALSA *const this,
        int id,
        char *name,
        int nameLen,
        FMOD_GUID *guid,
        int *systemRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels)
{
  FMOD_RESULT_0 result; // eax
  __int64 v11; // rax

  FMOD_strcpy_safe(name, *(const char **)(*((_QWORD *)this + 145) + 8LL * id), nameLen);
  result = FMOD::getGUIDFromName(*(const char **)(*((_QWORD *)this + 145) + 8LL * id), guid);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    *systemRate = 48000;
    result = FMOD::OutputALSA::getSupportedSampleRate(
               this,
               *(const char **)(*((_QWORD *)this + 145) + 8LL * id),
               systemRate,
               _snd_pcm_stream::SND_PCM_STREAM_CAPTURE);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      *speakerModeChannels = 1;
      v11 = *((_QWORD *)this + 145);
      *speakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0;
      return FMOD::getSpeakerModeFromName(*(const char **)(v11 + 8LL * id), speakerMode, speakerModeChannels);
    }
  }
  return result;
}


// Address: 0x22634d0 | Name: _ZN4FMOD10OutputALSA27recordGetDriverInfoCallbackEP17FMOD_OUTPUT_STATEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES6_
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordGetDriverInfoCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        char *name,
        int nameLen,
        FMOD_GUID *guid,
        int *systemRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::recordGetDriverInfo(
           p_requestreset,
           id,
           name,
           nameLen,
           guid,
           systemRate,
           speakerMode,
           speakerModeChannels);
}


// Address: 0x22634f0 | Name: _ZN4FMOD10OutputALSA11recordStartEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordStart(
        FMOD::OutputALSA *const this,
        FMOD::FMOD_RECORDING_INFO *recordInfo)
{
  FMOD_RESULT_0 result; // eax
  __int64 mRecordId; // rcx
  void *v6; // rsp
  size_t v7; // rax
  __int64 v8; // rdi
  int v9; // eax
  unsigned int v10; // esi
  void *v11; // rdx
  _BYTE v12[12]; // [rsp+0h] [rbp-40h] BYREF
  int supportedRate; // [rsp+Ch] [rbp-34h] BYREF
  snd_pcm_uframes_t periodSize; // [rsp+10h] [rbp-30h] BYREF
  snd_pcm_uframes_t bufferSize[5]; // [rsp+18h] [rbp-28h] BYREF

  result = FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  if ( !*((_QWORD *)this + 229) )
  {
    mRecordId = recordInfo->mRecordId;
    supportedRate = recordInfo->mRecordRate;
    result = FMOD::OutputALSA::getSupportedSampleRate(
               this,
               *(const char **)(*((_QWORD *)this + 145) + 8 * mRecordId),
               &supportedRate,
               _snd_pcm_stream::SND_PCM_STREAM_CAPTURE);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( (*((unsigned int (__fastcall **)(char *, _QWORD, __int64, __int64))this + 163))(
             (char *)this + 1824,
             *(_QWORD *)(*((_QWORD *)this + 145) + 8LL * recordInfo->mRecordId),
             1,
             1) )
      {
        return FMOD_RESULT::FMOD_ERR_RECORD_0;
      }
      v6 = alloca((*((__int64 (**)(void))this + 148))() + 15);
      v7 = (*((__int64 (**)(void))this + 148))();
      memset(v12, 0, v7);
      if ( (*((unsigned int (__fastcall **)(_QWORD, _BYTE *))this + 150))(*((_QWORD *)this + 228), v12) )
        return FMOD_RESULT::FMOD_ERR_RECORD_0;
      if ( (*((unsigned int (__fastcall **)(_QWORD, _BYTE *, __int64))this + 151))(*((_QWORD *)this + 228), v12, 3) )
        return FMOD_RESULT::FMOD_ERR_RECORD_0;
      if ( (*((unsigned int (__fastcall **)(_QWORD, _BYTE *, __int64))this + 152))(*((_QWORD *)this + 228), v12, 2) )
        return FMOD_RESULT::FMOD_ERR_RECORD_0;
      if ( (*((unsigned int (__fastcall **)(_QWORD, _BYTE *, _QWORD, _QWORD))this + 153))(
             *((_QWORD *)this + 228),
             v12,
             (unsigned int)supportedRate,
             0) )
      {
        return FMOD_RESULT::FMOD_ERR_RECORD_0;
      }
      if ( (*((unsigned int (__fastcall **)(_QWORD, _BYTE *, _QWORD))this + 154))(
             *((_QWORD *)this + 228),
             v12,
             (unsigned int)recordInfo->mRecordChannels) )
      {
        return FMOD_RESULT::FMOD_ERR_RECORD_0;
      }
      periodSize = 1024;
      if ( (*((unsigned int (__fastcall **)(_QWORD, _BYTE *, snd_pcm_uframes_t *, _QWORD))this + 155))(
             *((_QWORD *)this + 228),
             v12,
             &periodSize,
             0) )
      {
        return FMOD_RESULT::FMOD_ERR_RECORD_0;
      }
      v8 = *((_QWORD *)this + 228);
      bufferSize[0] = 8 * periodSize;
      if ( (*((unsigned int (__fastcall **)(__int64, _BYTE *, snd_pcm_uframes_t *))this + 156))(v8, v12, bufferSize) )
        return FMOD_RESULT::FMOD_ERR_RECORD_0;
      if ( (*((unsigned int (__fastcall **)(_QWORD, _BYTE *))this + 158))(*((_QWORD *)this + 228), v12) )
        return FMOD_RESULT::FMOD_ERR_RECORD_0;
      v9 = supportedRate;
      v10 = bufferSize[0];
      recordInfo->mRecordFormat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
      recordInfo->mRecordRate = v9;
      recordInfo->mRecordBufferLength = v10;
      v11 = FMOD::MemPool::calloc(
              off_286F358->gSystemMemPool,
              recordInfo->mRecordChannels * 2 * v10,
              "../../../core_api/platforms/linux/src/fmod_output_alsa.cpp",
              786,
              0);
      *((_QWORD *)this + 229) = v11;
      result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
      if ( v11 )
      {
        result = (*((unsigned int (__fastcall **)(_QWORD))this + 166))(*((_QWORD *)this + 228));
        if ( result )
          return FMOD_RESULT::FMOD_ERR_RECORD_0;
      }
    }
  }
  return result;
}


// Address: 0x2263710 | Name: _ZN4FMOD10OutputALSA19recordStartCallbackEP17FMOD_OUTPUT_STATEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordStartCallback(
        FMOD_OUTPUT_STATE *output,
        FMOD::FMOD_RECORDING_INFO *recordInfo)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::recordStart(p_requestreset, recordInfo);
}


// Address: 0x2263730 | Name: _ZN4FMOD10OutputALSA10recordStopEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordStop(
        FMOD::OutputALSA *const this,
        FMOD::FMOD_RECORDING_INFO *recordInfo)
{
  void *v2; // rsi

  v2 = (void *)*((_QWORD *)this + 229);
  if ( v2 )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      v2,
      "../../../core_api/platforms/linux/src/fmod_output_alsa.cpp",
      812);
    *((_QWORD *)this + 229) = 0;
  }
  if ( *((_QWORD *)this + 228) )
  {
    (*((void (**)(void))this + 164))();
    *((_QWORD *)this + 228) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2263790 | Name: _ZN4FMOD10OutputALSA18recordStopCallbackEP17FMOD_OUTPUT_STATEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordStopCallback(
        FMOD_OUTPUT_STATE *output,
        FMOD::FMOD_RECORDING_INFO *recordInfo)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::recordStop(p_requestreset, recordInfo);
}


// Address: 0x22637b0 | Name: _ZN4FMOD10OutputALSA17recordGetPositionEPNS_19FMOD_RECORDING_INFOEPj
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordGetPosition(
        FMOD::OutputALSA *const this,
        FMOD::FMOD_RECORDING_INFO *recordInfo,
        unsigned int *pcm)
{
  __int64 v4; // rax
  FMOD_RESULT_0 v5; // ecx

  v4 = (*((__int64 (__fastcall **)(_QWORD))this + 171))(*((_QWORD *)this + 228));
  v5 = FMOD_RESULT::FMOD_ERR_OUTPUT_DRIVERCALL_0;
  if ( v4 >= 0 )
  {
    v5 = FMOD_RESULT::FMOD_OK_0;
    *pcm = (recordInfo->mRecordLastCursorPos + v4) % recordInfo->mRecordBufferLength;
  }
  return v5;
}


// Address: 0x2263800 | Name: _ZN4FMOD10OutputALSA25recordGetPositionCallbackEP17FMOD_OUTPUT_STATEPNS_19FMOD_RECORDING_INFOEPj
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordGetPositionCallback(
        FMOD_OUTPUT_STATE *output,
        FMOD::FMOD_RECORDING_INFO *recordInfo,
        unsigned int *pcm)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::recordGetPosition(p_requestreset, recordInfo, pcm);
}


// Address: 0x2263820 | Name: _ZN4FMOD10OutputALSA10recordLockEPNS_19FMOD_RECORDING_INFOEjjPPvS4_PjS5_
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordLock(
        FMOD::OutputALSA *const this,
        FMOD::FMOD_RECORDING_INFO *recordInfo,
        unsigned int a3,
        unsigned int lengthBytes,
        void **ptr1,
        void **a6,
        unsigned int *len1,
        unsigned int *a8)
{
  unsigned __int64 v8; // rax
  unsigned __int64 v11; // rcx
  unsigned __int64 v12; // rbp
  int v13; // eax
  FMOD_RESULT_0 result; // eax
  int v15; // edx

  v8 = lengthBytes;
  v11 = 2LL * recordInfo->mRecordChannels;
  v12 = v8 / v11;
  v13 = (*((__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD, unsigned __int64, void **, void **))this + 170))(
          *((_QWORD *)this + 228),
          *((_QWORD *)this + 229),
          (int)(v8 / v11),
          v11,
          ptr1,
          a6);
  if ( v13 == (_DWORD)v12 )
    goto LABEL_5;
  if ( v13 == -86 )
  {
    while ( 1 )
    {
      v13 = (*((__int64 (__fastcall **)(_QWORD))this + 167))(*((_QWORD *)this + 228));
      if ( v13 != -11 )
        break;
      FMOD_OS_Time_Sleep(0x3E8u);
    }
    if ( v13 == -38 )
      goto LABEL_10;
  }
  else if ( v13 == -38 )
  {
    goto LABEL_10;
  }
  if ( v13 != -32 )
  {
LABEL_5:
    *ptr1 = (void *)*((_QWORD *)this + 229);
    *len1 = lengthBytes;
    return FMOD_RESULT::FMOD_OK_0;
  }
LABEL_10:
  v15 = (*((__int64 (__fastcall **)(_QWORD))this + 165))(*((_QWORD *)this + 228));
  result = FMOD_RESULT::FMOD_ERR_OUTPUT_DRIVERCALL_0;
  if ( !v15 )
  {
    if ( (*((unsigned int (__fastcall **)(_QWORD))this + 166))(*((_QWORD *)this + 228)) )
      return FMOD_RESULT::FMOD_ERR_RECORD_0;
    goto LABEL_5;
  }
  return result;
}


// Address: 0x22638f0 | Name: _ZN4FMOD10OutputALSA18recordLockCallbackEP17FMOD_OUTPUT_STATEPNS_19FMOD_RECORDING_INFOEjjPPvS6_PjS7_
FMOD_RESULT_0 __fastcall FMOD::OutputALSA::recordLockCallback(
        FMOD_OUTPUT_STATE *output,
        FMOD::FMOD_RECORDING_INFO *recordInfo,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  FMOD::OutputALSA *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputALSA *)&output[-1].requestreset;
  return FMOD::OutputALSA::recordLock(p_requestreset, recordInfo, offset, length, ptr1, ptr2, len1, len2);
}


