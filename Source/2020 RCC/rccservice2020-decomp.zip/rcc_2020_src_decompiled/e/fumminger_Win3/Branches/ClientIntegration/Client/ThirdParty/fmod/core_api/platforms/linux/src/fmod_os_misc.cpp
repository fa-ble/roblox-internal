// Address: 0x2261130 | Name: _Z23FMOD_OS_Thread_CallbackPv
void *__fastcall FMOD_OS_Thread_Callback(void *param)
{
  void (__fastcall *v1)(__int64); // rbp
  __int64 v2; // r12
  pthread_t v3; // rax

  v1 = *(void (__fastcall **)(__int64))param;
  v2 = *((_QWORD *)param + 1);
  v3 = pthread_self();
  if ( (unsigned int)pthread_setschedparam(v3, 1, (const struct sched_param *)param + 4) <= 1 )
  {
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      param,
      "../../../core_api/platforms/linux/src/fmod_os_misc.cpp",
      450);
    v1(v2);
  }
  return 0;
}


// Address: 0x2261190 | Name: _Z12FMOD_OS_Initv
FMOD_RESULT_0 __cdecl FMOD_OS_Init()
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22611a0 | Name: _Z15FMOD_OS_Releasev
FMOD_RESULT_0 __cdecl FMOD_OS_Release()
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22611b0 | Name: _Z20FMOD_OS_Memory_Allocij
void *__fastcall FMOD_OS_Memory_Alloc(int size, FMOD_MEMORY_TYPE a2)
{
  return malloc(size);
}


// Address: 0x22611c0 | Name: _Z22FMOD_OS_Memory_ReallocPvij
void *__fastcall FMOD_OS_Memory_Realloc(void *ptr, int size, FMOD_MEMORY_TYPE a3)
{
  return realloc(ptr, size);
}


// Address: 0x22611d0 | Name: _Z19FMOD_OS_Memory_FreePvj
// Alternative name is 'j_.free_3'
// attributes: thunk
void __fastcall FMOD_OS_Memory_Free(void *ptr, FMOD_MEMORY_TYPE a2)
{
  free(ptr);
}


// Address: 0x22611e0 | Name: _Z17FMOD_OS_File_OpenPKc14FMOD_FILE_MODEPjPP12FMOD_OS_FILE
FMOD_RESULT_0 __fastcall FMOD_OS_File_Open(
        const char *name,
        FMOD_FILE_MODE mode,
        unsigned int *fileSize,
        FMOD_OS_FILE **handle)
{
  unsigned int v6; // r13d
  FILE *v7; // rbx
  FILE *v9; // rax
  __off64_t v10; // rax

  if ( mode )
  {
    v6 = 0;
    v7 = 0;
    if ( mode == FMOD_FILE_MODE::FMOD_FILE_MODE_WRITE )
    {
      v7 = fopen64(name, "wb");
      if ( !v7 )
        return FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0;
    }
LABEL_3:
    *handle = (FMOD_OS_FILE *)v7;
    *fileSize = v6;
    return FMOD_RESULT::FMOD_OK_0;
  }
  v9 = fopen64(name, "rb");
  v7 = v9;
  if ( v9 )
  {
    if ( fseeko64(v9, 0, 2) )
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    v10 = ftello64(v7);
    v6 = v10;
    if ( v10 < 0 || fseeko64(v7, 0, 0) )
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
    goto LABEL_3;
  }
  return FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0;
}


// Address: 0x22612b0 | Name: _Z18FMOD_OS_File_CloseP12FMOD_OS_FILE
FMOD_RESULT_0 __fastcall FMOD_OS_File_Close(FMOD_OS_FILE *handle)
{
  return fclose((FILE *)handle) != 0 ? 0xD : 0;
}


// Address: 0x22612d0 | Name: _Z17FMOD_OS_File_ReadP12FMOD_OS_FILEPvjPj
FMOD_RESULT_0 __fastcall FMOD_OS_File_Read(
        FMOD_OS_FILE *handle,
        void *buffer,
        unsigned int bytesToRead,
        unsigned int *bytesRead)
{
  unsigned int v6; // eax
  FMOD_RESULT_0 v7; // esi

  v6 = fread(buffer, 1u, bytesToRead, (FILE *)handle);
  v7 = FMOD_RESULT::FMOD_OK_0;
  *bytesRead = v6;
  if ( bytesToRead != v6 )
    return feof((FILE *)handle) == 0 ? 13 : 16;
  return v7;
}


// Address: 0x2261320 | Name: _Z18FMOD_OS_File_WriteP12FMOD_OS_FILEPKvjb
FMOD_RESULT_0 __fastcall FMOD_OS_File_Write(
        FMOD_OS_FILE *handle,
        const void *buffer,
        unsigned int bytesToWrite,
        bool flush)
{
  FMOD_RESULT_0 v5; // ebx

  if ( bytesToWrite != fwrite(buffer, 1u, bytesToWrite, (FILE *)handle) )
    return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
  v5 = FMOD_RESULT::FMOD_OK_0;
  if ( flush )
  {
    if ( fflush((FILE *)handle) )
      return FMOD_RESULT::FMOD_ERR_FILE_BAD_0;
  }
  return v5;
}


// Address: 0x2261370 | Name: _Z17FMOD_OS_File_SeekP12FMOD_OS_FILEj
FMOD_RESULT_0 __fastcall FMOD_OS_File_Seek(FMOD_OS_FILE *handle, unsigned int offset)
{
  return fseek((FILE *)handle, offset, 0) != 0 ? 0xD : 0;
}


// Address: 0x2261390 | Name: _Z23FMOD_OS_Debug_OutputStrPKc
FMOD_RESULT_0 __fastcall FMOD_OS_Debug_OutputStr(const char *string)
{
  fputs(string, stderr);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22613b0 | Name: _Z18FMOD_OS_Time_GetUsPj
FMOD_RESULT_0 __fastcall FMOD_OS_Time_GetUs(unsigned int *us)
{
  unsigned int gStartTimeSeconds; // ecx
  timespec currentTime; // [rsp+0h] [rbp-18h] BYREF

  currentTime.tv_sec = 0;
  currentTime.tv_nsec = 0;
  if ( clock_gettime(1, &currentTime) )
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  gStartTimeSeconds = off_286F358->gStartTimeSeconds;
  if ( gStartTimeSeconds )
    gStartTimeSeconds = 1000000 * (LODWORD(currentTime.tv_sec) - gStartTimeSeconds);
  else
    off_286F358->gStartTimeSeconds = currentTime.tv_sec;
  *us = LODWORD(currentTime.tv_nsec) / 0x3E8 + gStartTimeSeconds;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2261440 | Name: _Z18FMOD_OS_Time_GetMsPj
FMOD_RESULT_0 __fastcall FMOD_OS_Time_GetMs(unsigned int *ms)
{
  unsigned int gStartTimeSeconds; // ecx
  int *v3; // rax
  timespec currentTime; // [rsp+0h] [rbp-18h] BYREF

  currentTime.tv_sec = 0;
  currentTime.tv_nsec = 0;
  if ( clock_gettime(1, &currentTime) )
  {
    v3 = __errno_location();
    fprintf(stderr, "FMOD: FMOD_OS_Time_GetMs : clock_gettime failed, errno = %d\n", *v3);
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  }
  else
  {
    gStartTimeSeconds = off_286F358->gStartTimeSeconds;
    if ( gStartTimeSeconds )
      gStartTimeSeconds = 1000 * (LODWORD(currentTime.tv_sec) - gStartTimeSeconds);
    else
      off_286F358->gStartTimeSeconds = currentTime.tv_sec;
    *ms = LODWORD(currentTime.tv_nsec) / 0xF4240 + gStartTimeSeconds;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x22614f0 | Name: _Z18FMOD_OS_Time_Sleepj
FMOD_RESULT_0 __fastcall FMOD_OS_Time_Sleep(unsigned int ms)
{
  timespec sleepTime; // [rsp+0h] [rbp-18h] BYREF

  sleepTime.tv_sec = ms / 0x3E8;
  sleepTime.tv_nsec = 1000000 * (ms - 1000 * sleepTime.tv_sec);
  nanosleep(&sleepTime, 0);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2261530 | Name: _Z27FMOD_OS_Thread_GetCurrentIDPy
FMOD_RESULT_0 __fastcall FMOD_OS_Thread_GetCurrentID(FMOD_UINT_NATIVE *id)
{
  *id = pthread_self();
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2261540 | Name: _Z21FMOD_OS_Thread_CreatePKcPFvPvES1_20FMOD_THREAD_PRIORITYiPS1_
FMOD_RESULT_0 __fastcall FMOD_OS_Thread_Create(
        const char *a1,
        void (*func)(void *),
        void *param,
        FMOD_THREAD_PRIORITY priority,
        int stackSize,
        void **handle)
{
  _QWORD *v10; // rbx
  FMOD_RESULT_0 result; // eax
  pthread_t thread; // [rsp+8h] [rbp-80h] BYREF
  pthread_attr_t attr; // [rsp+10h] [rbp-78h] BYREF

  v10 = FMOD::MemPool::calloc(
          off_286F358->gSystemMemPool,
          24,
          "../../../core_api/platforms/linux/src/fmod_os_misc.cpp",
          471,
          0);
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v10 )
  {
    *v10 = func;
    v10[1] = param;
    if ( priority == FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_VERYLOW )
    {
      *((_DWORD *)v10 + 4) = 75;
    }
    else if ( priority == FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_LOW )
    {
      *((_DWORD *)v10 + 4) = 80;
    }
    else if ( priority )
    {
      switch ( priority )
      {
        case FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_HIGH:
          *((_DWORD *)v10 + 4) = 90;
          break;
        case FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_VERYHIGH:
          *((_DWORD *)v10 + 4) = 95;
          break;
        case FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_CRITICAL:
          *((_DWORD *)v10 + 4) = 99;
          break;
      }
    }
    else
    {
      *((_DWORD *)v10 + 4) = 85;
    }
    if ( pthread_attr_init(&attr)
      || pthread_attr_setdetachstate(&attr, 1)
      || pthread_attr_setstacksize(&attr, stackSize + 0x4000)
      || pthread_create(&thread, &attr, FMOD_OS_Thread_Callback, v10)
      || pthread_attr_destroy(&attr) )
    {
      return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    }
    else
    {
      *handle = (void *)thread;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x22616c0 | Name: _Z22FMOD_OS_Thread_DestroyPv
FMOD_RESULT_0 __fastcall FMOD_OS_Thread_Destroy(void *a1)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22616d0 | Name: _Z30FMOD_OS_CriticalSection_CreatePP23FMOD_OS_CRITICALSECTIONb
FMOD_RESULT_0 __fastcall FMOD_OS_CriticalSection_Create(FMOD_OS_CRITICALSECTION **crit, bool isMemoryCrit)
{
  pthread_mutex_t *v2; // rbx
  FMOD_RESULT_0 result; // eax
  pthread_mutexattr_t attr; // [rsp+0h] [rbp-28h] BYREF

  v2 = &stru_2B061E0;
  if ( !isMemoryCrit )
  {
    v2 = (pthread_mutex_t *)FMOD::MemPool::alloc(
                              off_286F358->gSystemMemPool,
                              40,
                              "../../../core_api/platforms/linux/src/fmod_os_misc.cpp",
                              556,
                              0,
                              0);
    if ( !v2 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
  if ( pthread_mutexattr_init(&attr) )
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( pthread_mutexattr_settype(&attr, 1) )
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( pthread_mutex_init(v2, &attr) )
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  result = pthread_mutexattr_destroy(&attr);
  if ( result )
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  *crit = (FMOD_OS_CRITICALSECTION *)v2;
  return result;
}


// Address: 0x2261790 | Name: _Z28FMOD_OS_CriticalSection_FreeP23FMOD_OS_CRITICALSECTIONb
FMOD_RESULT_0 __fastcall FMOD_OS_CriticalSection_Free(FMOD_OS_CRITICALSECTION *crit, bool isMemoryCrit)
{
  FMOD_RESULT_0 v2; // ebx

  v2 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( pthread_mutex_destroy((pthread_mutex_t *)crit) )
    return v2;
  LOBYTE(v2) = 0;
  if ( isMemoryCrit )
    return v2;
  FMOD::MemPool::free(off_286F358->gSystemMemPool, crit, "../../../core_api/platforms/linux/src/fmod_os_misc.cpp", 616);
  return v2;
}


// Address: 0x22617f0 | Name: _Z29FMOD_OS_CriticalSection_EnterP23FMOD_OS_CRITICALSECTION
FMOD_RESULT_0 __fastcall FMOD_OS_CriticalSection_Enter(FMOD_OS_CRITICALSECTION *crit)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( crit )
    return pthread_mutex_lock((pthread_mutex_t *)crit) != 0 ? 0x1C : 0;
  return result;
}


// Address: 0x2261820 | Name: _Z29FMOD_OS_CriticalSection_LeaveP23FMOD_OS_CRITICALSECTION
FMOD_RESULT_0 __fastcall FMOD_OS_CriticalSection_Leave(FMOD_OS_CRITICALSECTION *crit)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( crit )
    return pthread_mutex_unlock((pthread_mutex_t *)crit) != 0 ? 0x1C : 0;
  return result;
}


// Address: 0x2261850 | Name: _Z32FMOD_OS_CriticalSection_TryEnterP23FMOD_OS_CRITICALSECTIONPb
FMOD_RESULT_0 __fastcall FMOD_OS_CriticalSection_TryEnter(FMOD_OS_CRITICALSECTION *crit, bool *entered)
{
  int v2; // edx
  FMOD_RESULT_0 result; // eax

  v2 = pthread_mutex_trylock((pthread_mutex_t *)crit);
  if ( v2 )
  {
    result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    if ( v2 == 16 )
    {
      *entered = 0;
      LOBYTE(result) = 0;
    }
  }
  else
  {
    *entered = 1;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2261890 | Name: _Z32FMOD_OS_CriticalSection_IsLockedP23FMOD_OS_CRITICALSECTIONPb
FMOD_RESULT_0 __fastcall FMOD_OS_CriticalSection_IsLocked(FMOD_OS_CRITICALSECTION *crit, bool *locked)
{
  return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
}


// Address: 0x22618a0 | Name: _Z24FMOD_OS_Semaphore_CreatePP17FMOD_OS_SEMAPHORE
FMOD_RESULT_0 __fastcall FMOD_OS_Semaphore_Create(FMOD_OS_SEMAPHORE **sema)
{
  sem_t *v1; // rbx
  FMOD_RESULT_0 result; // eax
  int v3; // edx

  v1 = (sem_t *)FMOD::MemPool::alloc(
                  off_286F358->gSystemMemPool,
                  32,
                  "../../../core_api/platforms/linux/src/fmod_os_misc.cpp",
                  732,
                  0,
                  0);
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v1 )
  {
    v3 = sem_init(v1, 0, 0);
    result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    if ( !v3 )
    {
      *sema = (FMOD_OS_SEMAPHORE *)v1;
      LOBYTE(result) = 0;
    }
  }
  return result;
}


// Address: 0x2261920 | Name: _Z22FMOD_OS_Semaphore_FreeP17FMOD_OS_SEMAPHORE
FMOD_RESULT_0 __fastcall FMOD_OS_Semaphore_Free(FMOD_OS_SEMAPHORE *sema)
{
  if ( sem_destroy((sem_t *)sema) )
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  FMOD::MemPool::free(off_286F358->gSystemMemPool, sema, "../../../core_api/platforms/linux/src/fmod_os_misc.cpp", 768);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2261970 | Name: _Z22FMOD_OS_Semaphore_WaitP17FMOD_OS_SEMAPHORE
FMOD_RESULT_0 __fastcall FMOD_OS_Semaphore_Wait(FMOD_OS_SEMAPHORE *sema)
{
  return sem_wait((sem_t *)sema) != 0 ? 0x1C : 0;
}


// Address: 0x2261990 | Name: _Z24FMOD_OS_Semaphore_SignalP17FMOD_OS_SEMAPHORE
FMOD_RESULT_0 __fastcall FMOD_OS_Semaphore_Signal(FMOD_OS_SEMAPHORE *sema)
{
  return sem_post((sem_t *)sema) != 0 ? 0x1C : 0;
}


// Address: 0x22619b0 | Name: _Z20FMOD_OS_Library_LoadPKcPP15FMOD_OS_LIBRARY
FMOD_RESULT_0 __fastcall FMOD_OS_Library_Load(const char *name, FMOD_OS_LIBRARY **handle)
{
  FMOD_OS_LIBRARY *v2; // rax

  v2 = (FMOD_OS_LIBRARY *)dlopen(name, 1);
  *handle = v2;
  return v2 == 0 ? 0x12 : 0;
}


// Address: 0x22619d0 | Name: _Z30FMOD_OS_Library_GetProcAddressP15FMOD_OS_LIBRARYPKcPPv
FMOD_RESULT_0 __fastcall FMOD_OS_Library_GetProcAddress(FMOD_OS_LIBRARY *handle, const char *name, void **address)
{
  void *v4; // rax

  v4 = dlsym(handle, name);
  *address = v4;
  return v4 == 0 ? 0xD : 0;
}


// Address: 0x22619f0 | Name: _Z20FMOD_OS_Library_FreeP15FMOD_OS_LIBRARY
FMOD_RESULT_0 __fastcall FMOD_OS_Library_Free(FMOD_OS_LIBRARY *handle)
{
  return dlclose(handle) != 0 ? 0x1C : 0;
}


// Address: 0x2261a10 | Name: _Z23FMOD_OS_CheckDriverListPb
FMOD_RESULT_0 __fastcall FMOD_OS_CheckDriverList(bool *a1)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2261a20 | Name: _Z28FMOD_OS_SetFastFloatingPointPj
FMOD_RESULT_0 __fastcall FMOD_OS_SetFastFloatingPoint(unsigned int *prevState)
{
  int v1; // edx
  unsigned int v2; // eax
  unsigned int csr_caps[6]; // [rsp+4h] [rbp-208h] BYREF
  unsigned int v5; // [rsp+1Ch] [rbp-1F0h]
  int v6; // [rsp+20h] [rbp-1ECh]

  _fxsave(csr_caps);
  v1 = v6;
  v2 = v5;
  *prevState = v5;
  if ( v1 && (v1 & 0x40) != 0 )
    v2 |= 0x40u;
  BYTE1(v2) |= 0x88u;
  _mm_setcsr(v2);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2261a70 | Name: _Z20FMOD_OS_SupportsNeonv
int __cdecl FMOD_OS_SupportsNeon()
{
  return gHasNEON;
}


