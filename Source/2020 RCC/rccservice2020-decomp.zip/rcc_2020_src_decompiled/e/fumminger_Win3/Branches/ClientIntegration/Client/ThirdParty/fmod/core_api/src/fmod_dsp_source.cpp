// Address: 0x21f6f90 | Name: _ZN4FMOD9DSPSource5setupEPNS_6SoundIEPNS_15ChannelSoftwareE
FMOD_RESULT_0 __fastcall FMOD::DSPSource::setup(
        FMOD::DSPSource *const this,
        FMOD::SoundI *sound,
        FMOD::ChannelSoftware *channel)
{
  const FMOD_DSP_DESCRIPTION *mDescription; // rax
  unsigned int (__fastcall *reset)(FMOD_DSP_STATE *); // rax
  FMOD_RESULT_0 result; // eax
  int mLoopCount; // eax

  mDescription = this->mDescription.mDescription;
  if ( !mDescription
    || (reset = (unsigned int (__fastcall *)(FMOD_DSP_STATE *))mDescription->reset) == 0
    || (result = reset(&this->mState)) == FMOD_RESULT::FMOD_OK_0 )
  {
    this->mChannel = channel;
    this->mSound = sound;
    if ( !sound
      || (result = FMOD::DSPI::setChannelFormat(this, 0, sound->mChannels, FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0)) == FMOD_RESULT::FMOD_OK_0 )
    {
      (*((void (__fastcall **)(FMOD::DSPSource *const, _QWORD, _QWORD, _QWORD))this->_vptr_DSPI + 5))(this, 0, 0, 0);
      FMOD::DSPI::setActive(this, 0, 1);
      mLoopCount = this->mSound->mLoopCount;
      this->mLoopCountIncrementPrev = 0;
      this->mLoopCountIncrement = 0;
      this->mNewLoopCount = -2;
      this->mLoopCount = mLoopCount;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21f7040 | Name: _ZN4FMOD9DSPSource14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPSource::createInternal(FMOD::DSPSource *const this)
{
  this->mLoopCount = 0;
  this->mLoopCountIncrementPrev = 0;
  this->mLoopCountIncrement = 0;
  this->mNewLoopCount = -2;
  return FMOD_RESULT::FMOD_OK_0;
}


