// Address: 0x221ed20 | Name: FMOD_DSP_Convert_FloatToPCM16_SSE_X64
void __fastcall FMOD_DSP_Convert_FloatToPCM16_SSE_X64(
        __int16 *outbuffer,
        float *inbuffer,
        unsigned int length,
        int destchannelstep,
        int srcchannelstep,
        __m128 volume)
{
  int v6; // r9d
  __m128 v7; // xmm0
  float *v8; // rdx
  __int64 v9; // r11
  __int64 v10; // r10
  __int16 *v11; // rax
  int v12; // esi
  __m128 v13; // xmm3
  __m128 v14; // xmm1
  __m128 v15; // xmm2
  __m128i v16; // xmm1
  __int64 v17; // rdx
  int v18; // eax
  int v19; // eax
  __m128 v20; // xmm2
  __m128 v21; // xmm3
  __m128 v22; // xmm1
  __m128i v23; // xmm1
  unsigned __int64 v24; // [rsp+0h] [rbp-68h]
  unsigned __int64 v25; // [rsp+0h] [rbp-68h]
  __int16 *v26; // [rsp+18h] [rbp-50h]
  float *v27; // [rsp+20h] [rbp-48h]

  v6 = length - 3;
  v7 = _mm_shuffle_ps(volume, volume, 0);
  v26 = outbuffer;
  v27 = inbuffer;
  if ( (int)(length - 3) <= 0 )
  {
    v18 = 0;
  }
  else
  {
    v8 = inbuffer;
    v9 = 16LL * srcchannelstep;
    v10 = 8LL * destchannelstep;
    v11 = outbuffer;
    v12 = 0;
    do
    {
      v12 += 4;
      v13 = (__m128)LODWORD(v8[3 * srcchannelstep]);
      v14 = _mm_unpacklo_ps((__m128)*(unsigned int *)v8, (__m128)LODWORD(v8[srcchannelstep]));
      v15 = (__m128)LODWORD(v8[2 * srcchannelstep]);
      v8 = (float *)((char *)v8 + v9);
      v16 = _mm_cvtps_epi32(_mm_mul_ps(_mm_movelh_ps(v14, _mm_unpacklo_ps(v15, v13)), v7));
      v24 = _mm_packs_epi32(v16, v16).m128i_u64[0];
      *v11 = v24;
      v11[destchannelstep] = WORD1(v24);
      v11[2 * destchannelstep] = WORD2(v24);
      v11[3 * destchannelstep] = HIWORD(v24);
      v11 = (__int16 *)((char *)v11 + v10);
    }
    while ( v12 < v6 );
    v17 = (length - 4) >> 2;
    v18 = 4 * v17++ + 4;
    v27 = (float *)((char *)v27 + v17 * v9);
    v26 = (__int16 *)((char *)outbuffer + v17 * v10);
  }
  v19 = length - v18;
  if ( v19 == 1 )
  {
    v20 = 0;
    v21 = 0;
    goto LABEL_11;
  }
  if ( v19 > 1 )
  {
    if ( v19 == 2 )
    {
      v20 = 0;
      goto LABEL_10;
    }
    if ( v19 == 3 )
    {
      v20 = (__m128)LODWORD(v27[2 * srcchannelstep]);
LABEL_10:
      v21 = (__m128)LODWORD(v27[srcchannelstep]);
LABEL_11:
      v22 = (__m128)*(unsigned int *)v27;
      goto LABEL_12;
    }
LABEL_21:
    v20 = 0;
    v21 = 0;
    v22 = 0;
LABEL_12:
    v23 = _mm_cvtps_epi32(_mm_mul_ps(_mm_movelh_ps(_mm_unpacklo_ps(v22, v21), v20), v7));
    v25 = _mm_packs_epi32(v23, v23).m128i_u64[0];
    if ( v19 != 2 )
    {
      if ( v19 != 3 )
      {
        if ( v19 != 1 )
          return;
LABEL_19:
        *v26 = v25;
        return;
      }
      v26[2 * destchannelstep] = WORD2(v25);
    }
    v26[destchannelstep] = WORD1(v25);
    goto LABEL_19;
  }
  if ( v19 )
    goto LABEL_21;
}


