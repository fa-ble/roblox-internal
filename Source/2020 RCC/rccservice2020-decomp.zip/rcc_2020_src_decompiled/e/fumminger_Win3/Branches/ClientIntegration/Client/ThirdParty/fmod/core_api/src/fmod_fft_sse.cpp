// Address: 0x2248a20 | Name: FMOD_FFT_Real_IDFT_Preprocess_SSE
void __fastcall FMOD_FFT_Real_IDFT_Preprocess_SSE(float *in, float *out, float *table, int N)
{
  int v4; // ecx
  __int64 v5; // rax
  __m128 v6; // xmm4
  float *v7; // r9
  unsigned __int64 v8; // rax
  __m128 v9; // xmm0
  __m128 v10; // xmm6
  __m128 v11; // xmm4
  __m128 v12; // xmm1
  __m128 v13; // xmm0

  v4 = N / 2;
  v5 = 2LL * v4;
  v6 = *(__m128 *)&in[v5];
  if ( v4 > 0 )
  {
    v7 = &in[v5 - 4];
    v8 = 0;
    while ( 1 )
    {
      v9 = *(__m128 *)&table[v8 / 4];
      v10 = *(__m128 *)&v7[v8 / 0xFFFFFFFFFFFFFFFCLL];
      v11 = _mm_shuffle_ps(v6, v10, 228);
      v12 = _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v9, v9), *(__m128 *)one_data), *(__m128 *)neg_imag_data);
      v13 = _mm_xor_ps(_mm_add_ps(_mm_shuffle_ps(v9, v9, 238), *(__m128 *)one_data), *(__m128 *)neg_imag_data);
      *(__m128 *)&out[v8 / 4] = _mm_add_ps(
                                  _mm_mul_ps(_mm_shuffle_ps(v12, v13, 0), *(__m128 *)&in[v8 / 4]),
                                  _mm_add_ps(
                                    _mm_mul_ps(
                                      _mm_xor_ps(
                                        _mm_shuffle_ps(*(__m128 *)&in[v8 / 4], *(__m128 *)&in[v8 / 4], 177),
                                        *(__m128 *)neg_even_data),
                                      _mm_shuffle_ps(v12, v13, 85)),
                                    _mm_add_ps(
                                      _mm_mul_ps(_mm_shuffle_ps(v11, v11, 160), _mm_shuffle_ps(v12, v13, 238)),
                                      _mm_mul_ps(
                                        _mm_xor_ps(_mm_shuffle_ps(v11, v11, 245), *(__m128 *)neg_odd_data),
                                        _mm_shuffle_ps(v12, v13, 187)))));
      v8 += 16LL;
      if ( v8 == 16 * (((unsigned int)(v4 - 1) >> 1) + 1LL) )
        break;
      v6 = v10;
    }
  }
}


// Address: 0x2248b10 | Name: FMOD_FFT_IDFT_conjugate_pair_dit_SSE
void __fastcall FMOD_FFT_IDFT_conjugate_pair_dit_SSE(float *out, float *root_table, int N)
{
  int v4; // ecx
  int v5; // edx
  int v6; // r14d
  __int64 v7; // rbx
  __int64 v8; // r12
  __int64 v9; // rbp
  float *v10; // r13
  __m128 v11; // xmm1
  __m128 v12; // xmm7
  __m128 v13; // xmm6
  __m128 v14; // xmm4
  __m128 v15; // xmm8
  __m128 v16; // xmm0
  __m128 v17; // xmm5
  __m128 v18; // xmm3
  __m128 v19; // xmm0
  __m128 v20; // xmm4
  __m128 v21; // xmm2
  __m128 v22; // xmm8
  __m128 v23; // xmm5
  __m128 v24; // xmm4
  __m128 v25; // xmm3
  __m128 v26; // xmm1
  __m128 v27; // xmm2
  __m128 v28; // xmm7
  __m128 v29; // xmm6
  __m128 v30; // xmm10
  __m128 v31; // xmm5
  __m128 v32; // xmm8
  __m128 v33; // xmm9
  __m128 v34; // xmm8
  __m128 v35; // xmm10
  __m128 v36; // xmm4
  __m128 v37; // xmm7
  __m128 v38; // xmm5
  __m128 v39; // xmm7
  __m128 v40; // xmm10
  __m128 v41; // xmm1
  __m128 v42; // xmm6
  __m128 v43; // xmm4
  __m128 v44; // xmm6
  __m128 v45; // xmm1
  __m128 v46; // xmm10
  __m128 v47; // xmm1
  __m128 v48; // xmm12
  __m128 v49; // xmm2
  __m128 v50; // xmm11
  __m128 v51; // xmm2
  __m128 v52; // xmm13
  __m128 v53; // xmm3
  __m128 v54; // xmm10
  __m128 v55; // xmm1
  __m128 v56; // xmm13
  __m128 v57; // xmm14
  __m128 v58; // xmm13
  __m128 v59; // xmm5
  __m128 v60; // xmm2
  __m128 v61; // xmm12
  __m128 v62; // xmm11
  __m128 v63; // xmm1
  __m128 v64; // xmm14
  __m128 v65; // xmm4
  __m128 v66; // xmm1
  __m128 v67; // xmm8
  __m128 v68; // xmm14
  __m128 v69; // xmm8
  __m128 v70; // xmm7
  __m128 v71; // xmm4
  __m128 v72; // xmm7
  __m128 v73; // xmm6
  __m128 v74; // xmm1
  __m128 v75; // xmm4
  __m128 v76; // xmm3
  __m128 v77; // xmm4
  __m128 v78; // xmm0
  __m128 v79; // xmm2
  __m128 v80; // xmm1
  __m128 v81; // xmm5
  __m128 v82; // xmm0
  __m128 v83; // xmm7
  __m128 v84; // xmm4
  __m128 v85; // xmm6
  __m128 v86; // xmm4
  __m128 v87; // xmm7
  __m128 v88; // xmm0
  __m128 v89; // xmm5
  __m128 v90; // xmm0
  __m128 v91; // xmm6
  __m128 v92; // xmm1
  __m128 v93; // xmm4
  float *u; // [rsp+18h] [rbp-40h]

  if ( N == 8 )
  {
    v77 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)out, *(__m128 *)out),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)out, *(__m128 *)out, 238), *(__m128 *)neg_upper_data));
    v78 = *(__m128 *)(out + 4);
    v79 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 8), *(__m128 *)(out + 8)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 8), *(__m128 *)(out + 8), 238), *(__m128 *)neg_upper_data));
    v80 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 12), *(__m128 *)(out + 12)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 12), *(__m128 *)(out + 12), 238), *(__m128 *)neg_upper_data));
    v81 = _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v78, v78), _mm_shuffle_ps(v78, v78, 238)), *(__m128 *)neg_upper_data);
    v82 = _mm_sub_ps(v78, _mm_shuffle_ps(v78, v78, 78));
    v83 = _mm_add_ps(_mm_shuffle_ps(v77, v77, 238), _mm_shuffle_ps(v82, v82, 57));
    v84 = _mm_add_ps(_mm_movelh_ps(v77, v77), v81);
    v85 = _mm_movelh_ps(v84, v83);
    v86 = _mm_shuffle_ps(v84, v83, 238);
    v87 = _mm_movelh_ps(v85, v85);
    v88 = _mm_sub_ps(_mm_movelh_ps(v79, v80), _mm_movelh_ps(v80, v79));
    v89 = _mm_add_ps(_mm_movelh_ps(v86, v86), _mm_shuffle_ps(v88, v88, 57));
    v90 = _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v79, v80, 238), *(__m128 *)root_w_1_2_real_data),
            _mm_mul_ps(_mm_shuffle_ps(v79, v80, 187), *(__m128 *)root_w_1_2_imag_inverse_data));
    v91 = _mm_add_ps(
            _mm_shuffle_ps(v85, v85, 238),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v90, v90), _mm_shuffle_ps(v90, v90, 238)), *(__m128 *)neg_upper_data));
    v92 = _mm_add_ps(
            v87,
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v79, v79), _mm_movelh_ps(v80, v80)), *(__m128 *)neg_upper_data));
    v93 = _mm_add_ps(
            _mm_shuffle_ps(v86, v86, 238),
            _mm_sub_ps(_mm_shuffle_ps(v90, v90, 57), _mm_shuffle_ps(v90, v90, 147)));
    *(__m128 *)out = _mm_movelh_ps(v92, v91);
    *((__m128 *)out + 2) = _mm_shuffle_ps(v92, v91, 238);
    *((__m128 *)out + 3) = _mm_shuffle_ps(v89, v93, 238);
    *((__m128 *)out + 1) = _mm_movelh_ps(v89, v93);
  }
  else if ( N == 16 )
  {
    v22 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)out, *(__m128 *)out),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)out, *(__m128 *)out, 238), *(__m128 *)neg_upper_data));
    v23 = *(__m128 *)(out + 4);
    v24 = *(__m128 *)(out + 20);
    v25 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 8), *(__m128 *)(out + 8)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 8), *(__m128 *)(out + 8), 238), *(__m128 *)neg_upper_data));
    v26 = *(__m128 *)(out + 28);
    v27 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 12), *(__m128 *)(out + 12)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 12), *(__m128 *)(out + 12), 238), *(__m128 *)neg_upper_data));
    v28 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 16), *(__m128 *)(out + 16)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 16), *(__m128 *)(out + 16), 238), *(__m128 *)neg_upper_data));
    v29 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 24), *(__m128 *)(out + 24)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 24), *(__m128 *)(out + 24), 238), *(__m128 *)neg_upper_data));
    v30 = _mm_add_ps(
            _mm_movelh_ps(v22, v22),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v23, v23), _mm_shuffle_ps(v23, v23, 238)), *(__m128 *)neg_upper_data));
    v31 = _mm_sub_ps(v23, _mm_shuffle_ps(v23, v23, 78));
    v32 = _mm_add_ps(_mm_shuffle_ps(v22, v22, 238), _mm_shuffle_ps(v31, v31, 57));
    v33 = _mm_movelh_ps(v30, v32);
    v34 = _mm_shuffle_ps(v30, v32, 238);
    v35 = _mm_add_ps(
            _mm_movelh_ps(v28, v28),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v24, v24), _mm_shuffle_ps(v24, v24, 238)), *(__m128 *)neg_upper_data));
    v36 = _mm_sub_ps(v24, _mm_shuffle_ps(v24, v24, 78));
    v37 = _mm_add_ps(_mm_shuffle_ps(v28, v28, 238), _mm_shuffle_ps(v36, v36, 57));
    v38 = _mm_movelh_ps(v35, v37);
    v39 = _mm_shuffle_ps(v35, v37, 238);
    v40 = _mm_add_ps(
            _mm_movelh_ps(v29, v29),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v26, v26), _mm_shuffle_ps(v26, v26, 238)), *(__m128 *)neg_upper_data));
    v41 = _mm_sub_ps(v26, _mm_shuffle_ps(v26, v26, 78));
    v42 = _mm_add_ps(_mm_shuffle_ps(v29, v29, 238), _mm_shuffle_ps(v41, v41, 57));
    v43 = _mm_movelh_ps(v40, v42);
    v44 = _mm_shuffle_ps(v40, v42, 238);
    v45 = _mm_sub_ps(_mm_movelh_ps(v25, v27), _mm_movelh_ps(v27, v25));
    v46 = _mm_add_ps(_mm_movelh_ps(v34, v34), _mm_shuffle_ps(v45, v45, 57));
    v47 = _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v25, v27, 238), *(__m128 *)root_w_1_2_real_data),
            _mm_mul_ps(_mm_shuffle_ps(v25, v27, 187), *(__m128 *)root_w_1_2_imag_inverse_data));
    v48 = _mm_add_ps(
            _mm_shuffle_ps(v33, v33, 238),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v47, v47), _mm_shuffle_ps(v47, v47, 238)), *(__m128 *)neg_upper_data));
    v49 = _mm_add_ps(
            _mm_movelh_ps(v33, v33),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v25, v25), _mm_movelh_ps(v27, v27)), *(__m128 *)neg_upper_data));
    v50 = _mm_shuffle_ps(v49, v48, 238);
    v51 = _mm_movelh_ps(v49, v48);
    v52 = _mm_add_ps(
            _mm_shuffle_ps(v34, v34, 238),
            _mm_sub_ps(_mm_shuffle_ps(v47, v47, 57), _mm_shuffle_ps(v47, v47, 147)));
    v53 = _mm_movelh_ps(v46, v52);
    v54 = _mm_shuffle_ps(v46, v52, 238);
    v55 = _mm_sub_ps(_mm_movelh_ps(v38, v43), _mm_movelh_ps(v43, v38));
    v56 = _mm_add_ps(
            _mm_movelh_ps(v51, v51),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v38, v38), _mm_movelh_ps(v43, v43)), *(__m128 *)neg_upper_data));
    v57 = _mm_shuffle_ps(v56, v38, 238);
    v58 = _mm_shuffle_ps(v56, v51, 228);
    v59 = v57;
    v60 = _mm_add_ps(_mm_movelh_ps(v50, v50), _mm_shuffle_ps(v55, v55, 57));
    v61 = _mm_shuffle_ps(v60, v43, 238);
    v62 = _mm_shuffle_ps(v60, v50, 228);
    v63 = _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v59, v61, 238), *(__m128 *)root_w_1_4_real_data),
            _mm_mul_ps(_mm_shuffle_ps(v59, v61, 187), *(__m128 *)root_w_1_4_imag_inverse_data));
    v64 = _mm_add_ps(
            _mm_shuffle_ps(v58, v58, 238),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v63, v63), _mm_shuffle_ps(v63, v63, 238)), *(__m128 *)neg_upper_data));
    *(__m128 *)out = _mm_movelh_ps(v58, v64);
    v65 = _mm_add_ps(
            _mm_shuffle_ps(v62, v62, 238),
            _mm_sub_ps(_mm_shuffle_ps(v63, v63, 57), _mm_shuffle_ps(v63, v63, 147)));
    *((__m128 *)out + 4) = _mm_shuffle_ps(v59, v64, 228);
    *((__m128 *)out + 2) = _mm_movelh_ps(v62, v65);
    v66 = _mm_add_ps(
            _mm_mul_ps(_mm_movelh_ps(v39, v44), *(__m128 *)root_w_1_2_real_data),
            _mm_mul_ps(_mm_shuffle_ps(v39, v44, 17), *(__m128 *)root_w_1_2_imag_inverse_data));
    *((__m128 *)out + 6) = _mm_shuffle_ps(v61, v65, 228);
    v67 = _mm_add_ps(
            _mm_movelh_ps(v53, v53),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v66, v66), _mm_shuffle_ps(v66, v66, 238)), *(__m128 *)neg_upper_data));
    v68 = _mm_shuffle_ps(v67, v39, 238);
    v69 = _mm_shuffle_ps(v67, v53, 228);
    v70 = _mm_add_ps(_mm_movelh_ps(v54, v54), _mm_sub_ps(_mm_shuffle_ps(v66, v66, 57), _mm_shuffle_ps(v66, v66, 147)));
    v71 = _mm_shuffle_ps(v70, v44, 238);
    v72 = _mm_shuffle_ps(v70, v54, 228);
    v73 = v71;
    v74 = _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v68, v71, 238), *(__m128 *)root_w_3_4_real_data),
            _mm_mul_ps(_mm_shuffle_ps(v68, v71, 187), *(__m128 *)root_w_3_4_imag_inverse_data));
    v75 = _mm_add_ps(
            _mm_shuffle_ps(v69, v69, 238),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v74, v74), _mm_shuffle_ps(v74, v74, 238)), *(__m128 *)neg_upper_data));
    v76 = _mm_add_ps(
            _mm_shuffle_ps(v72, v72, 238),
            _mm_sub_ps(_mm_shuffle_ps(v74, v74, 57), _mm_shuffle_ps(v74, v74, 147)));
    *((__m128 *)out + 1) = _mm_movelh_ps(v69, v75);
    *((__m128 *)out + 5) = _mm_shuffle_ps(v68, v75, 228);
    *((__m128 *)out + 7) = _mm_shuffle_ps(v73, v76, 228);
    *((__m128 *)out + 3) = _mm_movelh_ps(v72, v76);
  }
  else
  {
    v4 = N + 3;
    u = out;
    v5 = N / 2;
    if ( N >= 0 )
      v4 = N;
    v6 = v4 >> 2;
    v7 = 2 * v5;
    v8 = 2 * (v4 >> 2);
    v9 = 6 * (v4 >> 2);
    FMOD_FFT_IDFT_conjugate_pair_dit_SSE(out, &root_table[v8], v5);
    v10 = &root_table[2 * v6 + 2 * (N / 8)];
    FMOD_FFT_IDFT_conjugate_pair_dit_SSE(&out[v7], v10, v6);
    FMOD_FFT_IDFT_conjugate_pair_dit_SSE(&out[v9], v10, v6);
    if ( v6 > 0 )
    {
      do
      {
        v11 = *(__m128 *)root_table;
        root_table += 4;
        v12 = *(__m128 *)&out[v7];
        v13 = *(__m128 *)&out[v9];
        v14 = *(__m128 *)out;
        v15 = *(__m128 *)&out[v8];
        v16 = _mm_add_ps(
                _mm_mul_ps(_mm_movelh_ps(v12, v13), _mm_shuffle_ps(v11, v11, 0)),
                _mm_mul_ps(
                  _mm_shuffle_ps(v12, v13, 17),
                  _mm_xor_ps(_mm_shuffle_ps(v11, v11, 85), *(__m128 *)neg_imag_inverse_data)));
        v17 = _mm_add_ps(
                _mm_movelh_ps(v14, v14),
                _mm_xor_ps(
                  _mm_add_ps(_mm_movelh_ps(v16, v16), _mm_shuffle_ps(v16, v16, 238)),
                  *(__m128 *)neg_upper_data));
        v18 = _mm_add_ps(
                _mm_movelh_ps(v15, v15),
                _mm_sub_ps(_mm_shuffle_ps(v16, v16, 57), _mm_shuffle_ps(v16, v16, 147)));
        v19 = _mm_add_ps(
                _mm_mul_ps(_mm_shuffle_ps(v12, v13, 238), _mm_shuffle_ps(v11, v11, 170)),
                _mm_mul_ps(
                  _mm_shuffle_ps(v12, v13, 187),
                  _mm_xor_ps(_mm_shuffle_ps(v11, v11, 255), *(__m128 *)neg_imag_inverse_data)));
        v20 = _mm_add_ps(
                _mm_shuffle_ps(v14, v14, 238),
                _mm_xor_ps(
                  _mm_add_ps(_mm_movelh_ps(v19, v19), _mm_shuffle_ps(v19, v19, 238)),
                  *(__m128 *)neg_upper_data));
        v21 = _mm_add_ps(
                _mm_shuffle_ps(v15, v15, 238),
                _mm_sub_ps(_mm_shuffle_ps(v19, v19, 57), _mm_shuffle_ps(v19, v19, 147)));
        *(__m128 *)out = _mm_movelh_ps(v17, v20);
        *(__m128 *)&out[v8] = _mm_movelh_ps(v18, v21);
        *(__m128 *)&out[v7] = _mm_shuffle_ps(v17, v20, 238);
        *(__m128 *)&out[v9] = _mm_shuffle_ps(v18, v21, 238);
        out += 4;
      }
      while ( out != &u[4 * ((unsigned int)(v6 - 1) >> 1) + 4] );
    }
  }
}


// Address: 0x2249450 | Name: FMOD_FFT_DFT_conjugate_pair_dit_SSE
void __fastcall FMOD_FFT_DFT_conjugate_pair_dit_SSE(float *out, float *root_table, int N)
{
  int v4; // ecx
  int v5; // edx
  int v6; // r14d
  __int64 v7; // rbx
  __int64 v8; // r12
  __int64 v9; // rbp
  float *v10; // r13
  __m128 v11; // xmm1
  __m128 v12; // xmm7
  __m128 v13; // xmm6
  __m128 v14; // xmm4
  __m128 v15; // xmm8
  __m128 v16; // xmm0
  __m128 v17; // xmm5
  __m128 v18; // xmm3
  __m128 v19; // xmm0
  __m128 v20; // xmm4
  __m128 v21; // xmm2
  __m128 v22; // xmm8
  __m128 v23; // xmm5
  __m128 v24; // xmm11
  __m128 v25; // xmm10
  __m128 v26; // xmm3
  __m128 v27; // xmm4
  __m128 v28; // xmm1
  __m128 v29; // xmm2
  __m128 v30; // xmm7
  __m128 v31; // xmm6
  __m128 v32; // xmm8
  __m128 v33; // xmm11
  __m128 v34; // xmm10
  __m128 v35; // xmm9
  __m128 v36; // xmm8
  __m128 v37; // xmm13
  __m128 v38; // xmm10
  __m128 v39; // xmm5
  __m128 v40; // xmm7
  __m128 v41; // xmm5
  __m128 v42; // xmm7
  __m128 v43; // xmm10
  __m128 v44; // xmm4
  __m128 v45; // xmm6
  __m128 v46; // xmm4
  __m128 v47; // xmm6
  __m128 v48; // xmm1
  __m128 v49; // xmm12
  __m128 v50; // xmm1
  __m128 v51; // xmm9
  __m128 v52; // xmm2
  __m128 v53; // xmm13
  __m128 v54; // xmm2
  __m128 v55; // xmm8
  __m128 v56; // xmm3
  __m128 v57; // xmm12
  __m128 v58; // xmm1
  __m128 v59; // xmm9
  __m128 v60; // xmm14
  __m128 v61; // xmm9
  __m128 v62; // xmm5
  __m128 v63; // xmm2
  __m128 v64; // xmm8
  __m128 v65; // xmm13
  __m128 v66; // xmm1
  __m128 v67; // xmm14
  __m128 v68; // xmm4
  __m128 v69; // xmm1
  __m128 v70; // xmm10
  __m128 v71; // xmm14
  __m128 v72; // xmm10
  __m128 v73; // xmm7
  __m128 v74; // xmm4
  __m128 v75; // xmm7
  __m128 v76; // xmm6
  __m128 v77; // xmm1
  __m128 v78; // xmm4
  __m128 v79; // xmm3
  __m128 v80; // xmm4
  __m128 v81; // xmm0
  __m128 v82; // xmm8
  __m128 v83; // xmm7
  __m128 v84; // xmm2
  __m128 v85; // xmm1
  __m128 v86; // xmm4
  __m128 v87; // xmm8
  __m128 v88; // xmm7
  __m128 v89; // xmm6
  __m128 v90; // xmm4
  __m128 v91; // xmm7
  __m128 v92; // xmm0
  __m128 v93; // xmm5
  __m128 v94; // xmm0
  __m128 v95; // xmm6
  __m128 v96; // xmm1
  __m128 v97; // xmm4
  float *u; // [rsp+18h] [rbp-40h]

  if ( N == 8 )
  {
    v80 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)out, *(__m128 *)out),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)out, *(__m128 *)out, 238), *(__m128 *)neg_upper_data));
    v81 = *(__m128 *)(out + 4);
    v82 = _mm_movelh_ps(v80, v80);
    v83 = _mm_shuffle_ps(v80, v80, 238);
    v84 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 8), *(__m128 *)(out + 8)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 8), *(__m128 *)(out + 8), 238), *(__m128 *)neg_upper_data));
    v85 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 12), *(__m128 *)(out + 12)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 12), *(__m128 *)(out + 12), 238), *(__m128 *)neg_upper_data));
    v86 = _mm_sub_ps(_mm_shuffle_ps(v81, v81, 78), v81);
    v87 = _mm_add_ps(
            v82,
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v81, v81), _mm_shuffle_ps(v81, v81, 238)), *(__m128 *)neg_upper_data));
    v88 = _mm_add_ps(v83, _mm_shuffle_ps(v86, v86, 57));
    v89 = _mm_movelh_ps(v87, v88);
    v90 = _mm_shuffle_ps(v87, v88, 238);
    v91 = _mm_movelh_ps(v89, v89);
    v92 = _mm_sub_ps(_mm_movelh_ps(v85, v84), _mm_movelh_ps(v84, v85));
    v93 = _mm_add_ps(_mm_movelh_ps(v90, v90), _mm_shuffle_ps(v92, v92, 57));
    v94 = _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v84, v85, 238), *(__m128 *)root_w_1_2_real_data),
            _mm_mul_ps(_mm_shuffle_ps(v84, v85, 187), *(__m128 *)root_w_1_2_imag_data));
    v95 = _mm_add_ps(
            _mm_shuffle_ps(v89, v89, 238),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v94, v94), _mm_shuffle_ps(v94, v94, 238)), *(__m128 *)neg_upper_data));
    v96 = _mm_add_ps(
            v91,
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v84, v84), _mm_movelh_ps(v85, v85)), *(__m128 *)neg_upper_data));
    v97 = _mm_add_ps(
            _mm_shuffle_ps(v90, v90, 238),
            _mm_sub_ps(_mm_shuffle_ps(v94, v94, 147), _mm_shuffle_ps(v94, v94, 57)));
    *(__m128 *)out = _mm_movelh_ps(v96, v95);
    *((__m128 *)out + 2) = _mm_shuffle_ps(v96, v95, 238);
    *((__m128 *)out + 3) = _mm_shuffle_ps(v93, v97, 238);
    *((__m128 *)out + 1) = _mm_movelh_ps(v93, v97);
  }
  else if ( N == 16 )
  {
    v22 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)out, *(__m128 *)out),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)out, *(__m128 *)out, 238), *(__m128 *)neg_upper_data));
    v23 = *(__m128 *)(out + 4);
    v24 = _mm_movelh_ps(v22, v22);
    v25 = _mm_shuffle_ps(v22, v22, 238);
    v26 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 8), *(__m128 *)(out + 8)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 8), *(__m128 *)(out + 8), 238), *(__m128 *)neg_upper_data));
    v27 = *(__m128 *)(out + 20);
    v28 = *(__m128 *)(out + 28);
    v29 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 12), *(__m128 *)(out + 12)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 12), *(__m128 *)(out + 12), 238), *(__m128 *)neg_upper_data));
    v30 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 16), *(__m128 *)(out + 16)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 16), *(__m128 *)(out + 16), 238), *(__m128 *)neg_upper_data));
    v31 = _mm_add_ps(
            _mm_movelh_ps(*(__m128 *)(out + 24), *(__m128 *)(out + 24)),
            _mm_xor_ps(_mm_shuffle_ps(*(__m128 *)(out + 24), *(__m128 *)(out + 24), 238), *(__m128 *)neg_upper_data));
    v32 = _mm_sub_ps(_mm_shuffle_ps(v23, v23, 78), v23);
    v33 = _mm_add_ps(
            v24,
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v23, v23), _mm_shuffle_ps(v23, v23, 238)), *(__m128 *)neg_upper_data));
    v34 = _mm_add_ps(v25, _mm_shuffle_ps(v32, v32, 57));
    v35 = _mm_movelh_ps(v33, v34);
    v36 = _mm_shuffle_ps(v33, v34, 238);
    v37 = _mm_movelh_ps(v35, v35);
    v38 = _mm_add_ps(
            _mm_movelh_ps(v30, v30),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v27, v27), _mm_shuffle_ps(v27, v27, 238)), *(__m128 *)neg_upper_data));
    v39 = _mm_sub_ps(_mm_shuffle_ps(v27, v27, 78), v27);
    v40 = _mm_add_ps(_mm_shuffle_ps(v30, v30, 238), _mm_shuffle_ps(v39, v39, 57));
    v41 = _mm_movelh_ps(v38, v40);
    v42 = _mm_shuffle_ps(v38, v40, 238);
    v43 = _mm_add_ps(
            _mm_movelh_ps(v31, v31),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v28, v28), _mm_shuffle_ps(v28, v28, 238)), *(__m128 *)neg_upper_data));
    v44 = _mm_sub_ps(_mm_shuffle_ps(v28, v28, 78), v28);
    v45 = _mm_add_ps(_mm_shuffle_ps(v31, v31, 238), _mm_shuffle_ps(v44, v44, 57));
    v46 = _mm_movelh_ps(v43, v45);
    v47 = _mm_shuffle_ps(v43, v45, 238);
    v48 = _mm_sub_ps(_mm_movelh_ps(v29, v26), _mm_movelh_ps(v26, v29));
    v49 = _mm_add_ps(_mm_movelh_ps(v36, v36), _mm_shuffle_ps(v48, v48, 57));
    v50 = _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v26, v29, 238), *(__m128 *)root_w_1_2_real_data),
            _mm_mul_ps(_mm_shuffle_ps(v26, v29, 187), *(__m128 *)root_w_1_2_imag_data));
    v51 = _mm_add_ps(
            _mm_shuffle_ps(v35, v35, 238),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v50, v50), _mm_shuffle_ps(v50, v50, 238)), *(__m128 *)neg_upper_data));
    v52 = _mm_add_ps(
            v37,
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v26, v26), _mm_movelh_ps(v29, v29)), *(__m128 *)neg_upper_data));
    v53 = _mm_shuffle_ps(v52, v51, 238);
    v54 = _mm_movelh_ps(v52, v51);
    v55 = _mm_add_ps(
            _mm_shuffle_ps(v36, v36, 238),
            _mm_sub_ps(_mm_shuffle_ps(v50, v50, 147), _mm_shuffle_ps(v50, v50, 57)));
    v56 = _mm_movelh_ps(v49, v55);
    v57 = _mm_shuffle_ps(v49, v55, 238);
    v58 = _mm_sub_ps(_mm_movelh_ps(v46, v41), _mm_movelh_ps(v41, v46));
    v59 = _mm_add_ps(
            _mm_movelh_ps(v54, v54),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v41, v41), _mm_movelh_ps(v46, v46)), *(__m128 *)neg_upper_data));
    v60 = _mm_shuffle_ps(v59, v41, 238);
    v61 = _mm_shuffle_ps(v59, v54, 228);
    v62 = v60;
    v63 = _mm_add_ps(_mm_movelh_ps(v53, v53), _mm_shuffle_ps(v58, v58, 57));
    v64 = _mm_shuffle_ps(v63, v46, 238);
    v65 = _mm_shuffle_ps(v63, v53, 228);
    v66 = _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v62, v64, 238), *(__m128 *)root_w_1_4_real_data),
            _mm_mul_ps(_mm_shuffle_ps(v62, v64, 187), *(__m128 *)root_w_1_4_imag_data));
    v67 = _mm_add_ps(
            _mm_shuffle_ps(v61, v61, 238),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v66, v66), _mm_shuffle_ps(v66, v66, 238)), *(__m128 *)neg_upper_data));
    *(__m128 *)out = _mm_movelh_ps(v61, v67);
    v68 = _mm_add_ps(
            _mm_shuffle_ps(v65, v65, 238),
            _mm_sub_ps(_mm_shuffle_ps(v66, v66, 147), _mm_shuffle_ps(v66, v66, 57)));
    *((__m128 *)out + 4) = _mm_shuffle_ps(v62, v67, 228);
    *((__m128 *)out + 2) = _mm_movelh_ps(v65, v68);
    v69 = _mm_add_ps(
            _mm_mul_ps(_mm_movelh_ps(v42, v47), *(__m128 *)root_w_1_2_real_data),
            _mm_mul_ps(_mm_shuffle_ps(v42, v47, 17), *(__m128 *)root_w_1_2_imag_data));
    *((__m128 *)out + 6) = _mm_shuffle_ps(v64, v68, 228);
    v70 = _mm_add_ps(
            _mm_movelh_ps(v56, v56),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v69, v69), _mm_shuffle_ps(v69, v69, 238)), *(__m128 *)neg_upper_data));
    v71 = _mm_shuffle_ps(v70, v42, 238);
    v72 = _mm_shuffle_ps(v70, v56, 228);
    v73 = _mm_add_ps(_mm_movelh_ps(v57, v57), _mm_sub_ps(_mm_shuffle_ps(v69, v69, 147), _mm_shuffle_ps(v69, v69, 57)));
    v74 = _mm_shuffle_ps(v73, v47, 238);
    v75 = _mm_shuffle_ps(v73, v57, 228);
    v76 = v74;
    v77 = _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v71, v74, 238), *(__m128 *)root_w_3_4_real_data),
            _mm_mul_ps(_mm_shuffle_ps(v71, v74, 187), *(__m128 *)root_w_3_4_imag_data));
    v78 = _mm_add_ps(
            _mm_shuffle_ps(v72, v72, 238),
            _mm_xor_ps(_mm_add_ps(_mm_movelh_ps(v77, v77), _mm_shuffle_ps(v77, v77, 238)), *(__m128 *)neg_upper_data));
    v79 = _mm_add_ps(
            _mm_shuffle_ps(v75, v75, 238),
            _mm_sub_ps(_mm_shuffle_ps(v77, v77, 147), _mm_shuffle_ps(v77, v77, 57)));
    *((__m128 *)out + 1) = _mm_movelh_ps(v72, v78);
    *((__m128 *)out + 5) = _mm_shuffle_ps(v71, v78, 228);
    *((__m128 *)out + 7) = _mm_shuffle_ps(v76, v79, 228);
    *((__m128 *)out + 3) = _mm_movelh_ps(v75, v79);
  }
  else
  {
    v4 = N + 3;
    u = out;
    v5 = N / 2;
    if ( N >= 0 )
      v4 = N;
    v6 = v4 >> 2;
    v7 = 2 * v5;
    v8 = 2 * (v4 >> 2);
    v9 = 6 * (v4 >> 2);
    FMOD_FFT_DFT_conjugate_pair_dit_SSE(out, &root_table[v8], v5);
    v10 = &root_table[2 * v6 + 2 * (N / 8)];
    FMOD_FFT_DFT_conjugate_pair_dit_SSE(&out[v7], v10, v6);
    FMOD_FFT_DFT_conjugate_pair_dit_SSE(&out[v9], v10, v6);
    if ( v6 > 0 )
    {
      do
      {
        v11 = *(__m128 *)root_table;
        root_table += 4;
        v12 = *(__m128 *)&out[v7];
        v13 = *(__m128 *)&out[v9];
        v14 = *(__m128 *)out;
        v15 = *(__m128 *)&out[v8];
        v16 = _mm_add_ps(
                _mm_mul_ps(_mm_movelh_ps(v12, v13), _mm_shuffle_ps(v11, v11, 0)),
                _mm_mul_ps(
                  _mm_shuffle_ps(v12, v13, 17),
                  _mm_xor_ps(_mm_shuffle_ps(v11, v11, 85), *(__m128 *)neg_imag_data)));
        v17 = _mm_add_ps(
                _mm_movelh_ps(v14, v14),
                _mm_xor_ps(
                  _mm_add_ps(_mm_movelh_ps(v16, v16), _mm_shuffle_ps(v16, v16, 238)),
                  *(__m128 *)neg_upper_data));
        v18 = _mm_add_ps(
                _mm_movelh_ps(v15, v15),
                _mm_sub_ps(_mm_shuffle_ps(v16, v16, 147), _mm_shuffle_ps(v16, v16, 57)));
        v19 = _mm_add_ps(
                _mm_mul_ps(_mm_shuffle_ps(v12, v13, 238), _mm_shuffle_ps(v11, v11, 170)),
                _mm_mul_ps(
                  _mm_shuffle_ps(v12, v13, 187),
                  _mm_xor_ps(_mm_shuffle_ps(v11, v11, 255), *(__m128 *)neg_imag_data)));
        v20 = _mm_add_ps(
                _mm_shuffle_ps(v14, v14, 238),
                _mm_xor_ps(
                  _mm_add_ps(_mm_movelh_ps(v19, v19), _mm_shuffle_ps(v19, v19, 238)),
                  *(__m128 *)neg_upper_data));
        v21 = _mm_add_ps(
                _mm_shuffle_ps(v15, v15, 238),
                _mm_sub_ps(_mm_shuffle_ps(v19, v19, 147), _mm_shuffle_ps(v19, v19, 57)));
        *(__m128 *)out = _mm_movelh_ps(v17, v20);
        *(__m128 *)&out[v8] = _mm_movelh_ps(v18, v21);
        *(__m128 *)&out[v7] = _mm_shuffle_ps(v17, v20, 238);
        *(__m128 *)&out[v9] = _mm_shuffle_ps(v18, v21, 238);
        out += 4;
      }
      while ( out != &u[4 * ((unsigned int)(v6 - 1) >> 1) + 4] );
    }
  }
}


