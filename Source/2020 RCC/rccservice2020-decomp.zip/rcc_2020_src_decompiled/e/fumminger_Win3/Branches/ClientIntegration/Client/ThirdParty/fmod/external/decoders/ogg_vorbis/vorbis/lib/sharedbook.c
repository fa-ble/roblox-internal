// Address: 0x22715b0 | Name: bitreverse
ogg_uint32_t_0 __fastcall bitreverse(ogg_uint32_t_0 x)
{
  unsigned __int32 v1; // edi
  unsigned int v2; // eax
  unsigned int v3; // edi

  v1 = _byteswap_ulong(x);
  v2 = (v1 >> 4) & 0xF0F0F0F | (16 * v1) & 0xF0F0F0F0;
  v3 = (v2 >> 2) & 0x33333333 | (4 * v2) & 0xCCCCCCCC;
  return (v3 >> 1) & 0x55555555 | (2 * v3) & 0xAAAAAAAA;
}


// Address: 0x22715f0 | Name: sort32a
int __fastcall sort32a(const void *a, const void *b)
{
  return (__PAIR64__(**(_DWORD **)a > **(_DWORD **)b, **(_DWORD **)a) - **(unsigned int **)b) >> 32;
}


// Address: 0x2271610 | Name: _FMOD_ilog
int __fastcall FMOD_ilog(unsigned int v)
{
  int result; // eax

  for ( result = 0; v; v >>= 1 )
    ++result;
  return result;
}


// Address: 0x2271630 | Name: _FMOD_float32_pack
__int64 __fastcall FMOD_float32_pack(float a1, float val)
{
  float v2; // xmm2_4
  unsigned int v3; // ebp
  __m128d v4; // xmm0
  __m128d v5; // xmm1
  __m128d v6; // xmm3
  __m128d v7; // xmm0
  int v8; // ebx
  __m128 v9; // xmm0
  float v10; // xmm3_4

  v2 = a1;
  v3 = 0;
  if ( a1 < 0.0 )
  {
    v3 = 0x80000000;
    v2 = -a1;
  }
  v4.m128d_f64[1] = logf(v2);
  v4.m128d_f64[0] = v4.m128d_f64[1] / 0.6931471805599453;
  v5 = v4;
  v6 = _mm_and_pd(v4, (__m128d)0x7FFFFFFFFFFFFFFFuLL);
  if ( v6.m128d_f64[0] < 4.503599627370496e15 )
  {
    v6.m128d_f64[0] = (double)(int)v4.m128d_f64[0];
    v6.m128d_f64[0] = v6.m128d_f64[0] - COERCE_DOUBLE(*(_OWORD *)&_mm_cmpgt_sd(v6, v4) & 0x3FF0000000000000LL);
    v5 = _mm_or_pd(v6, _mm_andn_pd((__m128d)0x7FFFFFFFFFFFFFFFuLL, v4));
  }
  v7.m128d_f64[1] = v2;
  v8 = (int)(float)_mm_unpacklo_pd(v5, v5).m128d_f64[0];
  v7.m128d_f64[0] = ldexp(v2, 20 - v8);
  v9 = _mm_cvtpd_ps(_mm_unpacklo_pd(v7, v7));
  v10 = fabs(v9.m128_f32[0]);
  if ( v10 < 8388608.0 )
    v9.m128_i32[0] = _mm_andnot_ps((__m128)0x7FFFFFFFu, v9).m128_u32[0]
                   | COERCE_UNSIGNED_INT((float)(v10 + 8388608.0) - 8388608.0);
  return ((v8 + 768) << 21) | v3 | (int)v9.m128_f32[0];
}


// Address: 0x2271740 | Name: _FMOD_float32_unpack
float __fastcall FMOD_float32_unpack(ogg_int32_t val)
{
  __m128d v1; // xmm0

  v1.m128d_f64[0] = (double)(val & 0x1FFFFF);
  if ( val < 0 )
    v1 = _mm_xor_pd(v1, (__m128d)0x8000000000000000LL);
  v1.m128d_f64[0] = ldexp(v1.m128d_f64[0], (unsigned int)((__int64)(val & 0x7FE00000) >> 21) - 788);
  *(float *)v1.m128d_f64 = _mm_unpacklo_pd(v1, v1).m128d_f64[0];
  return *(float *)v1.m128d_f64;
}


// Address: 0x2271790 | Name: _FMOD_make_words
ogg_uint32_t_0 *__fastcall FMOD_make_words(void *context, ogg_int32_t *l, ogg_int32_t n, ogg_int32_t sparsecount)
{
  int v7; // esi
  _DWORD *v9; // rsi
  __int64 v10; // r8
  __int64 v11; // rdi
  ogg_int32_t v12; // ecx
  ogg_uint32_t_0 v13; // eax
  int v14; // r14d
  ogg_uint32_t_0 v15; // r10d
  ogg_int32_t v16; // r9d
  __int64 v17; // r11
  int v18; // r8d
  __int64 v19; // r9
  ogg_uint32_t_0 v20; // r11d
  int v21; // eax
  __int64 v22; // rax
  __int64 v24; // r9
  int v25; // r11d
  int v26; // edx
  int v27; // edi
  int v28; // ecx
  int *v29; // r10
  int v30; // eax
  unsigned int v31; // edi
  ogg_uint32_t_0 marker[46]; // [rsp+0h] [rbp-B8h] BYREF

  v7 = 4 * sparsecount;
  if ( !sparsecount )
    v7 = 4 * n;
  v9 = FMOD_OggVorbis_Malloc(context, v7);
  if ( !v9 )
    return 0;
  memset(marker, 0, 132);
  v10 = 0;
  v11 = 0;
  if ( n > 0 )
  {
    v12 = *l;
    if ( *l <= 0 )
      goto LABEL_20;
    while ( 1 )
    {
      v13 = marker[v12];
      if ( v12 <= 31 )
      {
        if ( v13 >> v12 )
          goto LABEL_25;
      }
      v14 = v10 + 1;
      v9[v10] = v13;
      v15 = v13;
      v16 = v12;
      while ( (v15 & 1) == 0 )
      {
        v17 = v16--;
        marker[v17] = v15 + 1;
        if ( !v16 )
          goto LABEL_12;
        v15 = marker[v16];
      }
      if ( v16 == 1 )
        ++marker[1];
      else
        marker[v16] = 2 * marker[v16 - 1];
LABEL_12:
      v18 = v12 + 1;
      if ( v12 + 1 <= 32 )
      {
        v19 = v18;
        v20 = marker[v18];
        if ( v13 == v20 >> 1 )
        {
          while ( 1 )
          {
            v21 = v18++ - 1;
            marker[v19] = 2 * marker[v21];
            if ( v18 == 33 )
              break;
            v19 = v18;
            if ( marker[v18] >> 1 != v20 )
              break;
            v20 = marker[v18];
          }
        }
      }
      if ( n <= (int)++v11 )
        break;
      while ( 1 )
      {
        v12 = l[v11];
        v10 = v14;
        if ( v12 > 0 )
          break;
LABEL_20:
        v14 = (sparsecount == 0) + (_DWORD)v10;
        if ( n <= (int)++v11 )
          goto LABEL_21;
      }
    }
  }
LABEL_21:
  v22 = 0;
  if ( sparsecount != 1 )
  {
    while ( ((0xFFFFFFFFuLL >> (31 - (unsigned __int8)v22)) & marker[v22 + 1]) == 0 )
    {
      if ( ++v22 == 32 )
        goto LABEL_29;
    }
LABEL_25:
    FMOD_OggVorbis_Free(context, v9);
    return 0;
  }
LABEL_29:
  if ( n > 0 )
  {
    v24 = 0;
    v25 = 0;
    do
    {
      v26 = l[v24];
      if ( v26 <= 0 )
      {
        if ( sparsecount && !v26 )
          goto LABEL_35;
        v27 = 0;
        v29 = &v9[v25];
      }
      else
      {
        v27 = 0;
        v28 = 0;
        v29 = &v9[v25];
        do
        {
          v30 = 2 * v27;
          v31 = (unsigned int)*v29 >> v28++;
          v27 = v30 | v31 & 1;
        }
        while ( v28 != v26 );
      }
      ++v25;
      *v29 = v27;
LABEL_35:
      ++v24;
    }
    while ( n > (int)v24 );
  }
  return v9;
}


// Address: 0x22719d0 | Name: _FMOD_book_maptype1_quantvals
ogg_int32_t __fastcall FMOD_book_maptype1_quantvals(const static_codebook_0 *b)
{
  __m128 v1; // xmm2
  __m128 v2; // xmm0
  __m128 v3; // xmm1
  ogg_int32_t result; // eax
  ogg_int32_t entries; // r9d
  ogg_int32_t dim; // edi
  int v7; // edx
  int v8; // esi
  int v9; // ecx

  *(double *)&v2.m128_u64[1] = (float)b->entries;
  *(double *)v2.m128_u64 = pow(*(double *)&v2.m128_u64[1], (float)(1.0 / (float)b->dim));
  v1 = _mm_cvtpd_ps(_mm_unpacklo_pd((__m128d)v2, (__m128d)v2));
  v2.m128_i32[0] = v1.m128_i32[0];
  v3 = _mm_and_ps(v1, (__m128)0x7FFFFFFFu);
  if ( v3.m128_f32[0] < 8388608.0 )
  {
    v3.m128_f32[0] = (float)(int)v1.m128_f32[0];
    v2.m128_i32[0] = COERCE_UNSIGNED_INT(v3.m128_f32[0] - COERCE_FLOAT(_mm_cmpgt_ss(v3, v2).m128_u32[0] & 0x3F800000))
                   | _mm_andnot_ps((__m128)0x7FFFFFFFu, v1).m128_u32[0];
  }
  result = (int)v2.m128_f32[0];
  entries = b->entries;
  dim = b->dim;
  while ( 1 )
  {
    if ( dim > 0 )
      goto LABEL_5;
    while ( 2 )
    {
      v8 = 1;
      if ( entries < 1 )
        goto LABEL_11;
LABEL_8:
      if ( entries < v8 )
        return result;
      ++result;
      if ( dim <= 0 )
        continue;
      break;
    }
LABEL_5:
    v7 = 0;
    v8 = 1;
    v9 = 1;
    do
    {
      ++v7;
      v9 *= result;
      v8 *= result + 1;
    }
    while ( v7 != dim );
    if ( entries >= v9 )
      goto LABEL_8;
LABEL_11:
    --result;
  }
}


// Address: 0x2271ab0 | Name: _FMOD_book_unquantize
float *__fastcall FMOD_book_unquantize(void *context, const static_codebook_0 *b, int n, int *sparsemap)
{
  __m128 v4; // xmm1
  float *v8; // rbp
  int maptype; // eax
  ogg_int32_t entries; // r12d
  __int64 v11; // r8
  int i; // r10d
  ogg_int32_t v13; // edx
  int v14; // edi
  float v15; // xmm3_4
  ogg_int32_t *v16; // rsi
  __int64 v17; // rax
  int v18; // ecx
  ogg_int32_t v20; // r10d
  __int64 v21; // r15
  ogg_int32_t dim; // r8d
  ogg_int32_t *quantlist; // r12
  __int64 v24; // rcx
  int q_sequencep; // r11d
  float v26; // xmm3_4
  int v27; // esi
  int v28; // r9d
  float delta; // [rsp+8h] [rbp-50h]
  float deltaa; // [rsp+8h] [rbp-50h]
  float mindel; // [rsp+14h] [rbp-44h]
  ogg_int32_t mindela; // [rsp+14h] [rbp-44h]
  ogg_int32_t count; // [rsp+18h] [rbp-40h]
  float v34; // [rsp+1Ch] [rbp-3Ch]

  if ( (unsigned int)(b->maptype - 1) > 1 )
    return 0;
  mindel = FMOD_float32_unpack(b->q_min);
  delta = FMOD_float32_unpack(b->q_delta);
  v8 = (float *)FMOD_OggVorbis_Calloc(context, n * b->dim, 4);
  if ( !v8 )
    return 0;
  maptype = b->maptype;
  if ( maptype == 1 )
  {
    v34 = delta;
    deltaa = mindel;
    v20 = FMOD_book_maptype1_quantvals(b);
    mindela = b->entries;
    if ( mindela > 0 )
    {
      v21 = 0;
      count = 0;
      do
      {
        if ( !sparsemap || b->lengthlist[v21] )
        {
          dim = b->dim;
          if ( b->dim > 0 )
          {
            quantlist = b->quantlist;
            v24 = 0;
            q_sequencep = b->q_sequencep;
            v26 = 0.0;
            v27 = 1;
            do
            {
              while ( 1 )
              {
                v28 = v24;
                v4.m128_f32[0] = (float)quantlist[(int)v21 / v27 % v20];
                v4 = _mm_and_ps(v4, (__m128)0x7FFFFFFFu);
                v4.m128_f32[0] = (float)((float)(v4.m128_f32[0] * v34) + deltaa) + v26;
                if ( q_sequencep )
                  v26 = v4.m128_f32[0];
                if ( !sparsemap )
                  break;
                ++v24;
                v27 *= v20;
                v8[dim * sparsemap[count] + v28] = v4.m128_f32[0];
                if ( dim <= (int)v24 )
                  goto LABEL_30;
              }
              v27 *= v20;
              v8[dim * count + v24++] = v4.m128_f32[0];
            }
            while ( dim > (int)v24 );
          }
LABEL_30:
          ++count;
        }
        ++v21;
      }
      while ( mindela > (int)v21 );
    }
  }
  else if ( maptype == 2 )
  {
    entries = b->entries;
    v11 = 0;
    for ( i = 0; entries > (int)v11; ++v11 )
    {
      if ( !sparsemap || b->lengthlist[v11] )
      {
        v13 = b->dim;
        if ( b->dim > 0 )
        {
          v14 = b->q_sequencep;
          v15 = 0.0;
          v16 = &b->quantlist[v13 * (int)v11];
          v17 = 0;
          do
          {
            while ( 1 )
            {
              v4.m128_f32[0] = (float)v16[v17];
              v4 = _mm_and_ps(v4, (__m128)0x7FFFFFFFu);
              v18 = v17;
              v4.m128_f32[0] = (float)((float)(v4.m128_f32[0] * delta) + mindel) + v15;
              if ( v14 )
                v15 = v4.m128_f32[0];
              if ( !sparsemap )
                break;
              ++v17;
              v8[v13 * sparsemap[i] + v18] = v4.m128_f32[0];
              if ( v13 <= (int)v17 )
                goto LABEL_15;
            }
            v8[v13 * i + v17++] = v4.m128_f32[0];
          }
          while ( v13 > (int)v17 );
        }
LABEL_15:
        ++i;
      }
    }
  }
  return v8;
}


// Address: 0x2271d80 | Name: FMOD_vorbis_staticbook_clear
void __fastcall FMOD_vorbis_staticbook_clear(void *context, static_codebook_0 *b)
{
  ogg_int32_t *quantlist; // rsi
  ogg_int32_t *lengthlist; // rsi
  static_codebook_0 *v5; // rdi
  unsigned int v6; // edx
  __int64 v7; // rcx
  ogg_int32_t *v8; // rdi

  if ( b->allocedp )
  {
    quantlist = b->quantlist;
    if ( quantlist )
      FMOD_OggVorbis_Free(context, quantlist);
    lengthlist = b->lengthlist;
    if ( lengthlist )
      FMOD_OggVorbis_Free(context, lengthlist);
    v5 = b;
    v6 = 56;
    if ( ((unsigned __int8)b & 1) != 0 )
    {
      LOBYTE(b->dim) = 0;
      v5 = (static_codebook_0 *)((char *)&b->dim + 1);
      LOBYTE(v6) = 55;
    }
    if ( ((unsigned __int8)v5 & 2) != 0 )
    {
      v5 = (static_codebook_0 *)((char *)v5 + 2);
      v6 -= 2;
      *((_WORD *)&v5[-1].allocedp + 3) = 0;
    }
    if ( ((unsigned __int8)v5 & 4) != 0 )
    {
      v5->dim = 0;
      v6 -= 4;
      v5 = (static_codebook_0 *)((char *)v5 + 4);
    }
    v7 = v6 >> 3;
    memset(v5, 0, 8 * v7);
    v8 = &v5->dim + 2 * v7;
    if ( (v6 & 4) != 0 )
    {
      *v8++ = 0;
      if ( (v6 & 2) == 0 )
      {
LABEL_14:
        if ( (v6 & 1) == 0 )
          return;
LABEL_16:
        *(_BYTE *)v8 = 0;
        return;
      }
    }
    else if ( (v6 & 2) == 0 )
    {
      goto LABEL_14;
    }
    v8 = (ogg_int32_t *)((char *)v8 + 2);
    *((_WORD *)v8 - 1) = 0;
    if ( (v6 & 1) != 0 )
      goto LABEL_16;
  }
}


// Address: 0x2271e80 | Name: FMOD_vorbis_staticbook_destroy
void __fastcall FMOD_vorbis_staticbook_destroy(void *context, static_codebook_0 *b)
{
  if ( b->allocedp )
  {
    FMOD_vorbis_staticbook_clear(context, b);
    FMOD_OggVorbis_Free(context, b);
  }
}


// Address: 0x2271ec0 | Name: FMOD_vorbis_book_clear
void __fastcall FMOD_vorbis_book_clear(void *context, codebook_0 *b)
{
  float *valuelist; // rsi
  ogg_uint32_t_0 *codelist; // rsi
  int *dec_index; // rsi
  char *dec_codelengths; // rsi
  ogg_uint32_t_0 *dec_firsttable; // rsi
  codebook_0 *v8; // rdi
  unsigned int v9; // edx
  __int64 v10; // rcx
  ogg_int32_t *v11; // rdi

  valuelist = b->valuelist;
  if ( valuelist )
    FMOD_OggVorbis_Free(context, valuelist);
  codelist = b->codelist;
  if ( codelist )
    FMOD_OggVorbis_Free(context, codelist);
  dec_index = b->dec_index;
  if ( dec_index )
    FMOD_OggVorbis_Free(context, dec_index);
  dec_codelengths = b->dec_codelengths;
  if ( dec_codelengths )
    FMOD_OggVorbis_Free(context, dec_codelengths);
  dec_firsttable = b->dec_firsttable;
  if ( dec_firsttable )
    FMOD_OggVorbis_Free(context, dec_firsttable);
  v8 = b;
  v9 = 72;
  if ( ((unsigned __int8)b & 1) == 0 )
  {
    if ( ((unsigned __int8)b & 2) == 0 )
      goto LABEL_13;
LABEL_22:
    v8 = (codebook_0 *)((char *)v8 + 2);
    v9 -= 2;
    HIWORD(v8[-1].dec_maxlength) = 0;
    if ( ((unsigned __int8)v8 & 4) == 0 )
      goto LABEL_14;
    goto LABEL_23;
  }
  v8 = (codebook_0 *)((char *)&b->dim + 1);
  LOBYTE(b->dim) = 0;
  LOBYTE(v9) = 71;
  if ( (((_BYTE)b + 1) & 2) != 0 )
    goto LABEL_22;
LABEL_13:
  if ( ((unsigned __int8)v8 & 4) == 0 )
    goto LABEL_14;
LABEL_23:
  v8->dim = 0;
  v9 -= 4;
  v8 = (codebook_0 *)((char *)v8 + 4);
LABEL_14:
  v10 = v9 >> 3;
  memset(v8, 0, 8 * v10);
  v11 = &v8->dim + 2 * v10;
  if ( (v9 & 4) != 0 )
    *v11++ = 0;
  if ( (v9 & 2) != 0 )
  {
    v11 = (ogg_int32_t *)((char *)v11 + 2);
    *((_WORD *)v11 - 1) = 0;
  }
  if ( (v9 & 1) != 0 )
    *(_BYTE *)v11 = 0;
}


// Address: 0x2271fb0 | Name: FMOD_vorbis_book_init_decode
int __fastcall FMOD_vorbis_book_init_decode(void *context, codebook_0 *c, const static_codebook_0 *s)
{
  unsigned int v5; // edx
  codebook_0 *v6; // rdi
  __int64 v7; // rcx
  ogg_int32_t *v8; // rdi
  int entries; // edx
  ogg_int32_t *lengthlist; // rsi
  __int64 v11; // rax
  ogg_int32_t v12; // r12d
  __int64 v13; // rcx
  ogg_int32_t v14; // eax
  ogg_uint32_t_0 *words; // r15
  void *v16; // rsp
  ogg_uint32_t_0 **v17; // r9
  ogg_uint32_t_0 *v18; // rdx
  __int64 v19; // rbx
  ogg_uint32_t_0 v20; // edi
  ogg_uint32_t_0 v21; // eax
  ogg_uint32_t_0 *v22; // rdx
  size_t v23; // rbx
  void *v24; // rsp
  ogg_uint32_t_0 *v25; // rax
  ogg_uint32_t_0 **v26; // r9
  __int64 v27; // rcx
  __int64 v28; // rdx
  __int64 v29; // rcx
  ogg_uint32_t_0 v30; // esi
  ogg_uint32_t_0 *v31; // rsi
  void *v32; // r15
  float *v33; // rax
  int *v34; // rax
  ogg_int32_t *v35; // rcx
  int v36; // esi
  ogg_int32_t v37; // edx
  __int64 v38; // rdi
  char *v39; // rax
  __int64 v40; // rdx
  signed int v41; // r15d
  ogg_int32_t v42; // eax
  int v43; // ecx
  __int64 v44; // rsi
  int v45; // ecx
  ogg_uint32_t_0 *v46; // r9
  char *dec_codelengths; // r10
  int dec_firsttablen; // edx
  int v49; // r8d
  __int64 v50; // r13
  int i; // eax
  int v52; // ebx
  int v53; // edi
  ogg_uint32_t_0 *codelist; // rax
  ogg_uint32_t_0 v55; // eax
  int v56; // esi
  int v57; // edx
  ogg_int32_t dim; // eax
  signed int v60; // ebx
  unsigned int v61; // r12d
  int v62; // r13d
  int v63; // r10d
  ogg_uint32_t_0 v64; // eax
  unsigned int *v65; // rdi
  __int64 v66; // rdx
  unsigned int v67; // eax
  ogg_uint32_t_0 *v68; // rax
  ogg_uint32_t_0 v69; // r8d
  ogg_uint32_t_0 *v70; // rax
  int v71; // edx
  int v72; // eax
  unsigned int v73; // edx
  unsigned int v74; // eax
  int v75[3]; // [rsp+0h] [rbp-60h] BYREF
  int v76; // [rsp+Ch] [rbp-54h]
  size_t tabn; // [rsp+10h] [rbp-50h]
  void *mask; // [rsp+18h] [rbp-48h]
  ogg_uint32_t_0 **codep; // [rsp+20h] [rbp-40h]
  ogg_uint32_t_0 *word; // [rsp+28h] [rbp-38h]

  v5 = 72;
  mask = context;
  v6 = c;
  if ( ((unsigned __int8)c & 1) == 0 )
  {
    if ( ((unsigned __int8)c & 2) == 0 )
      goto LABEL_3;
LABEL_70:
    v6 = (codebook_0 *)((char *)v6 + 2);
    v5 -= 2;
    HIWORD(v6[-1].dec_maxlength) = 0;
    if ( ((unsigned __int8)v6 & 4) == 0 )
      goto LABEL_4;
    goto LABEL_71;
  }
  v6 = (codebook_0 *)((char *)&c->dim + 1);
  LOBYTE(c->dim) = 0;
  LOBYTE(v5) = 71;
  if ( (((_BYTE)c + 1) & 2) != 0 )
    goto LABEL_70;
LABEL_3:
  if ( ((unsigned __int8)v6 & 4) == 0 )
    goto LABEL_4;
LABEL_71:
  v6->dim = 0;
  v5 -= 4;
  v6 = (codebook_0 *)((char *)v6 + 4);
LABEL_4:
  v7 = v5 >> 3;
  memset(v6, 0, 8 * v7);
  v8 = &v6->dim + 2 * v7;
  if ( (v5 & 4) != 0 )
    *v8++ = 0;
  if ( (v5 & 2) != 0 )
  {
    v8 = (ogg_int32_t *)((char *)v8 + 2);
    *((_WORD *)v8 - 1) = 0;
  }
  if ( (v5 & 1) != 0 )
    *(_BYTE *)v8 = 0;
  entries = s->entries;
  if ( entries <= 0 )
  {
    dim = s->dim;
    c->entries = entries;
    c->used_entries = 0;
    c->dim = dim;
    return 0;
  }
  lengthlist = s->lengthlist;
  v11 = 0;
  v12 = 0;
  do
  {
    v13 = lengthlist[v11++] > 0;
    v12 += v13;
  }
  while ( entries > (int)v11 );
  v14 = s->dim;
  c->entries = entries;
  c->used_entries = v12;
  c->dim = v14;
  if ( !v12 )
    return 0;
  words = FMOD_make_words(mask, lengthlist, entries, v12);
  tabn = v12;
  v16 = alloca(8LL * v12 + 15);
  v17 = (ogg_uint32_t_0 **)v75;
  if ( words )
  {
    v18 = words;
    v19 = 0;
    do
    {
      v20 = *v18;
      codep = v17;
      word = v18;
      v21 = bitreverse(v20);
      v22 = word;
      v17 = codep;
      *word = v21;
      v17[v19++] = v22;
      v18 = v22 + 1;
    }
    while ( v12 > (int)v19 );
    v23 = tabn;
    qsort(v17, tabn, 8u, sort32a);
    v24 = alloca(4 * v23 + 15);
    LODWORD(word) = 4 * v12;
    v25 = (ogg_uint32_t_0 *)FMOD_OggVorbis_Malloc(mask, 4 * v12);
    c->codelist = v25;
    if ( v25 )
    {
      v26 = codep;
      v27 = 0;
      do
      {
        v75[(int)(v26[v27] - words)] = v27;
        ++v27;
      }
      while ( v12 > (int)v27 );
      v28 = 0;
      do
      {
        v29 = v75[v28];
        v30 = words[v28++];
        v25[v29] = v30;
      }
      while ( v12 > (int)v28 );
      v31 = words;
      v32 = mask;
      FMOD_OggVorbis_Free(mask, v31);
      v33 = FMOD_book_unquantize(v32, s, v12, v75);
      LODWORD(v31) = (_DWORD)word;
      c->valuelist = v33;
      v34 = (int *)FMOD_OggVorbis_Malloc(v32, (int)v31);
      c->dec_index = v34;
      if ( v34 )
      {
        if ( s->entries <= 0 )
        {
          v36 = 0;
        }
        else
        {
          v35 = s->lengthlist;
          v36 = 0;
          v37 = 0;
          do
          {
            if ( *v35 > 0 )
            {
              v38 = v36++;
              v34[v75[v38]] = v37;
            }
            ++v37;
            ++v35;
          }
          while ( s->entries > v37 );
        }
        v39 = (char *)FMOD_OggVorbis_Malloc(mask, v36);
        c->dec_codelengths = v39;
        if ( v39 )
        {
          if ( s->entries <= 0 )
          {
            v41 = 0;
          }
          else
          {
            v40 = 0;
            v41 = 0;
            v42 = 0;
            do
            {
              v43 = s->lengthlist[v40];
              if ( v43 > 0 )
              {
                v44 = v41++;
                c->dec_codelengths[v75[v44]] = v43;
              }
              ++v42;
              ++v40;
            }
            while ( s->entries > v42 );
          }
          v45 = FMOD_ilog(c->used_entries) - 4;
          if ( v45 > 4 )
          {
            if ( v45 <= 8 )
            {
              LODWORD(tabn) = 1;
              c->dec_firsttablen = v45;
              LODWORD(tabn) = (_DWORD)tabn << v45;
            }
            else
            {
              c->dec_firsttablen = 8;
              LODWORD(tabn) = 256;
            }
          }
          else
          {
            c->dec_firsttablen = 5;
            LODWORD(tabn) = 32;
          }
          v46 = (ogg_uint32_t_0 *)FMOD_OggVorbis_Calloc(mask, tabn, 4);
          c->dec_firsttable = v46;
          if ( v46 )
          {
            c->dec_maxlength = 0;
            if ( v41 )
            {
              dec_codelengths = c->dec_codelengths;
              dec_firsttablen = c->dec_firsttablen;
              v49 = 1;
              v50 = 0;
              for ( i = 0; ; i = c->dec_maxlength )
              {
                v52 = dec_codelengths[v50];
                if ( v52 > i )
                {
                  c->dec_maxlength = v52;
                  v52 = dec_codelengths[v50];
                }
                v53 = v49;
                if ( v52 <= dec_firsttablen )
                {
                  codelist = c->codelist;
                  v76 = dec_firsttablen;
                  mask = dec_codelengths;
                  LODWORD(codep) = v49;
                  word = v46;
                  v55 = bitreverse(codelist[v50]);
                  dec_firsttablen = v76;
                  v49 = (int)codep;
                  v56 = 0;
                  v46 = word;
                  dec_codelengths = (char *)mask;
                  v53 = (int)codep;
                  if ( 1 << (v76 - v52) > 0 )
                  {
                    do
                    {
                      v57 = v56++ << v52;
                      v46[v55 | v57] = v49;
                      dec_firsttablen = c->dec_firsttablen;
                      LOBYTE(v52) = dec_codelengths[v50];
                    }
                    while ( 1 << (LOBYTE(c->dec_firsttablen) - v52) > v56 );
                  }
                }
                ++v50;
                ++v49;
                if ( v41 <= v53 )
                  break;
              }
            }
            else
            {
              dec_firsttablen = c->dec_firsttablen;
            }
            v60 = 0;
            v61 = 0;
            v62 = 0;
            v63 = -2 << (31 - dec_firsttablen);
            while ( 1 )
            {
              LODWORD(mask) = v63;
              codep = (ogg_uint32_t_0 **)v46;
              LODWORD(word) = v62 << (32 - dec_firsttablen);
              v64 = bitreverse((ogg_uint32_t_0)word);
              v46 = (ogg_uint32_t_0 *)codep;
              v63 = (int)mask;
              v65 = (unsigned int *)codep + v64;
              if ( !*v65 )
              {
                v66 = 4LL * (int)v61 + 4;
                while ( (int)(v61 + 1) < v41 )
                {
                  v67 = *(ogg_uint32_t_0 *)((char *)c->codelist + v66);
                  v66 += 4;
                  if ( (unsigned int)word < v67 )
                    break;
                  ++v61;
                }
                if ( v41 > v60 )
                {
                  v68 = c->codelist;
                  v69 = v68[v60];
                  v70 = &v68[v60 + 1];
                  if ( (unsigned int)word >= ((unsigned int)mask & v69) )
                  {
                    do
                    {
                      if ( ++v60 == v41 )
                        break;
                      v71 = *v70++;
                    }
                    while ( (unsigned int)word >= ((unsigned int)mask & v71) );
                  }
                }
                v72 = 0x7FFF;
                v73 = v41 - v60;
                if ( v61 <= 0x7FFF )
                  v72 = v61;
                v74 = (v72 << 15) | 0x80000000;
                if ( v73 > 0x7FFF )
                  v73 = 0x7FFF;
                *v65 = v73 | v74;
              }
              if ( ++v62 == (_DWORD)tabn )
                break;
              dec_firsttablen = c->dec_firsttablen;
            }
            return 0;
          }
        }
      }
    }
  }
  FMOD_vorbis_book_clear(mask, c);
  return -1;
}


