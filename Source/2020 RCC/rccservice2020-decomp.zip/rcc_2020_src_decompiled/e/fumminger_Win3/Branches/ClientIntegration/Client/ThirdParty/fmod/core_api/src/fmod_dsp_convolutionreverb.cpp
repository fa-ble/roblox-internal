// Address: 0x22029a0 | Name: _Z35FMOD_ConvolutionReverb_setparamboolP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD_ConvolutionReverb_setparambool(FMOD_DSP_STATE *dsp_state, int index, FMOD_BOOL value)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index == 3 )
  {
    *((_BYTE *)dsp_state->plugindata + 12) = value != 0;
    LOBYTE(result) = 0;
  }
  return result;
}


// Address: 0x22029c0 | Name: _Z35FMOD_ConvolutionReverb_getparamboolP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD_ConvolutionReverb_getparambool(
        FMOD_DSP_STATE *dsp_state,
        int index,
        FMOD_BOOL *value,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index == 3 )
  {
    *value = *((unsigned __int8 *)dsp_state->plugindata + 12);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x22029e0 | Name: FMODGetDSPDescription
FMOD_DSP_DESCRIPTION_0 *__cdecl FMODGetDSPDescription()
{
  memset(&p_ir, 0, sizeof(p_ir));
  qmemcpy(p_ir.name, "Impulse Respons", 15);
  p_ir.type = FMOD_DSP_PARAMETER_TYPE_DATA;
  p_ir.description = (const char *)&uri_string;
  memset(&p_wet, 0, sizeof(p_wet));
  strcpy(p_wet.name, "Wet Level");
  *(_WORD *)&p_wet.name[10] = 0;
  *(_QWORD *)p_wet.label = 16996;
  p_wet.intdesc.min = -1029701632;
  p_wet.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  p_wet.description = "Gain in dB. -80 to 10. Default = 0";
  memset(&p_dry, 0, sizeof(p_dry));
  strcpy(p_dry.name, "Dry Level");
  *(_WORD *)&p_dry.name[10] = 0;
  *(_QWORD *)p_dry.label = 16996;
  p_dry.intdesc.min = -1029701632;
  p_dry.description = "Gain in dB. -80 to 10. Default = -80";
  p_dry.intdesc.defaultval = -1029701632;
  p_dry.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  memset(&p_linked, 0, sizeof(p_linked));
  p_linked.type = FMOD_DSP_PARAMETER_TYPE_BOOL;
  p_linked.intdesc.min = 1;
  *(_QWORD *)p_linked.name = 0x64656B6E694CLL;
  p_linked.description = "TRUE = Channels are mixed to mono, Default = TRUE";
  return &FMOD_ConvolutionReverb_Desc;
}


// Address: 0x2202b50 | Name: _Z29FMOD_ConvolutionReverb_sysmixP14FMOD_DSP_STATEi
FMOD_RESULT_0 __fastcall FMOD_ConvolutionReverb_sysmix(FMOD_DSP_STATE *dsp_state, int stage)
{
  FMOD::GpuCompute *v3; // rax
  FMOD::GpuCompute *v4; // rax
  FMOD_RESULT_0 v5; // ebx
  FMOD::GpuCompute *v6; // rax

  if ( stage != 1 )
    return FMOD_RESULT::FMOD_OK_0;
  if ( !FMOD::GpuCompute::IsAvaliable() )
    return FMOD_RESULT::FMOD_OK_0;
  v3 = FMOD::GpuCompute::Get();
  (**(void (__fastcall ***)(FMOD::GpuCompute *))v3)(v3);
  v4 = FMOD::GpuCompute::Get();
  v5 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)v4 + 96LL))(v4);
  v6 = FMOD::GpuCompute::Get();
  (*(void (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)v6 + 8LL))(v6);
  return v5;
}


// Address: 0x2202ba0 | Name: _Z36FMOD_ConvolutionReverb_setparamfloatP14FMOD_DSP_STATEif
__int64 __fastcall FMOD_ConvolutionReverb_setparamfloat(FMOD_DSP_STATE *dsp_state, int index, float a3, float value)
{
  float *plugindata; // rbx
  float v5; // xmm0_4
  float v7; // xmm0_4

  plugindata = (float *)dsp_state->plugindata;
  if ( index == 1 )
  {
    if ( a3 > -80.0 )
      v7 = powf(10.0, a3 / 20.0);
    else
      v7 = 0.0;
    plugindata[8] = v7;
    return 0;
  }
  else if ( index == 2 )
  {
    if ( a3 > -80.0 )
      v5 = powf(10.0, a3 / 20.0);
    else
      v5 = 0.0;
    plugindata[9] = v5;
    return 0;
  }
  else
  {
    return 31;
  }
}


// Address: 0x2202c40 | Name: _Z36FMOD_ConvolutionReverb_getparamfloatP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD_ConvolutionReverb_getparamfloat(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  float *plugindata; // rax
  float v5; // xmm0_4
  float v6; // xmm0_4
  float v8; // xmm0_4
  float *v9; // [rsp+0h] [rbp-18h]
  char *valuestra; // [rsp+8h] [rbp-10h]

  plugindata = (float *)dsp_state->plugindata;
  if ( index != 1 )
  {
    if ( index != 2 )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    v5 = plugindata[9];
    if ( v5 <= 0.0 )
      goto LABEL_4;
LABEL_10:
    valuestra = valuestr;
    v9 = value;
    v8 = log10f(v5);
    value = v9;
    v6 = v8 * 20.0;
    valuestr = valuestra;
    goto LABEL_5;
  }
  v5 = plugindata[8];
  if ( v5 > 0.0 )
    goto LABEL_10;
LABEL_4:
  v6 = -80.0;
LABEL_5:
  *value = v6;
  if ( valuestr )
    sprintf(valuestr, "%.1f", v6);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2202ce0 | Name: _Z12isPowerOfTwoi
bool __fastcall isPowerOfTwo(int x)
{
  bool result; // al

  result = 0;
  if ( x )
    return (x & (x - 1)) == 0;
  return result;
}


// Address: 0x2202cf0 | Name: _ZN4FMOD18FrequencyDelayLine20GetGpuMemoryRequiredEiiiPiS1_S1_
void __fastcall FMOD::FrequencyDelayLine::GetGpuMemoryRequired(
        int blockSize,
        int numBlocksImpulse,
        int numBlocksDelay,
        int *gpuOnlySizeBytes,
        int *cpuWriteSizeBytes,
        int *cpuReadWriteSizeBytes)
{
  *gpuOnlySizeBytes = 8 * blockSize
                    + 8
                    * (2 * blockSize
                     + numBlocksImpulse * 2 * blockSize
                     + (numBlocksImpulse + numBlocksDelay - 1) * 2 * blockSize);
  *cpuWriteSizeBytes = 4 * blockSize;
  *cpuReadWriteSizeBytes = 8 * blockSize;
}


// Address: 0x2202d20 | Name: _ZN4FMOD18FrequencyDelayLine6GpuFFTEPNS_16GpuComputeBufferES2_i
FMOD_RESULT_0 __fastcall FMOD::FrequencyDelayLine::GpuFFT(
        FMOD::FrequencyDelayLine *const this,
        FMOD::GpuComputeBuffer *input,
        FMOD::GpuComputeBuffer *output,
        int outputOffset)
{
  int mFFTSize; // ebx
  FMOD_RESULT_0 result; // eax
  int v8; // r14d
  unsigned int v9; // r12d
  char v10; // r14
  int v11; // r13d
  float v12; // [rsp+Ch] [rbp-3Ch]
  int v13; // [rsp+Ch] [rbp-3Ch]

  mFFTSize = this->mFFTSize;
  v12 = logf((float)mFFTSize);
  result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, FMOD::GpuComputeBuffer *, _QWORD, __int64))(*(_QWORD *)this->mFFTResources + 32LL))(
             this->mFFTResources,
             1,
             input,
             0,
             0xFFFFFFFFLL);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, _QWORD, FMOD::GpuComputeBuffer *, _QWORD, _QWORD))(*(_QWORD *)this->mFFTResources + 40LL))(
               this->mFFTResources,
               0,
               output,
               (unsigned int)outputOffset,
               (unsigned int)this->mFFTSize);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, _QWORD, _QWORD))(*(_QWORD *)this->mFFTResources
                                                                                                 + 8LL))(
                 this->mFFTResources,
                 0,
                 (unsigned int)(mFFTSize / 2));
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v8 = (int)(float)(v12 / 0.69314718);
        result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, _QWORD))(*(_QWORD *)this->mFFTResources + 8LL))(
                   this->mFFTResources,
                   1,
                   (unsigned int)((1 << (v8 - 1)) - 1));
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          v9 = mFFTSize / 2 / 64;
          result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeShader *, _QWORD, __int64, __int64))(*(_QWORD *)this->mGpuCompute + 64LL))(
                     this->mGpuCompute,
                     this->mFFT0Shader,
                     v9,
                     1,
                     1);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, __int64))(*(_QWORD *)this->mGpuCompute + 72LL))(
                       this->mGpuCompute,
                       output,
                       2);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              v10 = v8 - 2;
              v11 = mFFTSize / 4;
              if ( mFFTSize <= 3 )
              {
                return FMOD_RESULT::FMOD_OK_0;
              }
              else
              {
                v13 = 4;
                while ( 1 )
                {
                  result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, _QWORD, _QWORD))(*(_QWORD *)this->mFFTResources + 8LL))(
                             this->mFFTResources,
                             0,
                             (unsigned int)v11);
                  if ( result )
                    break;
                  result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, _QWORD))(*(_QWORD *)this->mFFTResources + 8LL))(
                             this->mFFTResources,
                             1,
                             (unsigned int)((1 << v10) - 1));
                  if ( result )
                    break;
                  result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeShader *, _QWORD, __int64, __int64))(*(_QWORD *)this->mGpuCompute + 64LL))(
                             this->mGpuCompute,
                             this->mFFT1Shader,
                             v9,
                             1,
                             1);
                  if ( result )
                    break;
                  result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, __int64))(*(_QWORD *)this->mGpuCompute + 72LL))(
                             this->mGpuCompute,
                             output,
                             2);
                  if ( result )
                    break;
                  v13 *= 2;
                  v11 >>= 1;
                  --v10;
                  if ( mFFTSize < v13 )
                    return FMOD_RESULT::FMOD_OK_0;
                }
              }
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x2202f10 | Name: _ZN4FMOD18FrequencyDelayLine7GpuIFFTEPNS_16GpuComputeBufferES2_
FMOD_RESULT_0 __fastcall FMOD::FrequencyDelayLine::GpuIFFT(
        FMOD::FrequencyDelayLine *const this,
        FMOD::GpuComputeBuffer *input,
        FMOD::GpuComputeBuffer *output)
{
  FMOD_RESULT_0 result; // eax
  int mFFTSize; // r13d
  unsigned int v5; // ebx
  unsigned int v6; // ebp
  __int64 v7; // rdx
  int m; // [rsp+8h] [rbp-40h]

  result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, _QWORD, FMOD::GpuComputeBuffer *, _QWORD, __int64))(*(_QWORD *)this->mIFFTResources + 40LL))(
             this->mIFFTResources,
             0,
             input,
             0,
             0xFFFFFFFFLL);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, FMOD::GpuComputeBuffer *, _QWORD, __int64))(*(_QWORD *)this->mIFFTResources + 40LL))(
               this->mIFFTResources,
               1,
               output,
               0,
               0xFFFFFFFFLL);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mFFTSize = this->mFFTSize;
      m = mFFTSize / 2;
      v5 = (int)(float)(logf((float)mFFTSize) / 0.69314718) - 1;
      if ( mFFTSize <= 2 )
      {
LABEL_13:
        result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, _QWORD, _QWORD))(*(_QWORD *)this->mIFFTResources + 8LL))(
                   this->mIFFTResources,
                   0,
                   (unsigned int)m);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, _QWORD))(*(_QWORD *)this->mIFFTResources + 8LL))(
                     this->mIFFTResources,
                     1,
                     0);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, _QWORD))(*(_QWORD *)this->mIFFTResources + 8LL))(
                       this->mIFFTResources,
                       2,
                       0);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, float))(*(_QWORD *)this->mIFFTResources + 16LL))(
                         this->mIFFTResources,
                         3,
                         1.0 / (float)mFFTSize);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeShader *, _QWORD, __int64, __int64))(*(_QWORD *)this->mGpuCompute + 64LL))(
                           this->mGpuCompute,
                           this->mIFFT1Shader,
                           (unsigned int)(m / 64),
                           1,
                           1);
                if ( result == FMOD_RESULT::FMOD_OK_0 )
                {
                  result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, __int64))(*(_QWORD *)this->mGpuCompute + 72LL))(
                             this->mGpuCompute,
                             output,
                             2);
                  if ( result == FMOD_RESULT::FMOD_OK_0 )
                    return (*(FMOD_RESULT_0 (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, __int64))(*(_QWORD *)this->mGpuCompute + 72LL))(
                             this->mGpuCompute,
                             input,
                             2);
                }
              }
            }
          }
        }
      }
      else
      {
        v6 = 2;
        v7 = 1;
        while ( 1 )
        {
          result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, _QWORD, __int64))(*(_QWORD *)this->mIFFTResources + 8LL))(
                     this->mIFFTResources,
                     0,
                     v7);
          if ( result )
            break;
          result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, _QWORD))(*(_QWORD *)this->mIFFTResources + 8LL))(
                     this->mIFFTResources,
                     1,
                     (unsigned int)((1 << v5) - 1));
          if ( result )
            break;
          result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, _QWORD))(*(_QWORD *)this->mIFFTResources + 8LL))(
                     this->mIFFTResources,
                     2,
                     v5);
          if ( result )
            break;
          result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeShader *, _QWORD, __int64, __int64))(*(_QWORD *)this->mGpuCompute + 64LL))(
                     this->mGpuCompute,
                     this->mIFFT0Shader,
                     (unsigned int)(m / 64),
                     1,
                     1);
          if ( result )
            break;
          result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, __int64))(*(_QWORD *)this->mGpuCompute + 72LL))(
                     this->mGpuCompute,
                     input,
                     2);
          if ( result )
            break;
          --v5;
          if ( mFFTSize <= (int)(2 * v6) )
            goto LABEL_13;
          v7 = v6;
          v6 *= 2;
        }
      }
    }
  }
  return result;
}


// Address: 0x2203180 | Name: _ZN4FMOD18FrequencyDelayLine4InitEPNS_7SystemIEiiiPNS_10GpuComputeEPNS_21GpuComputeMemoryBlockES6_S6_
FMOD_RESULT_0 __fastcall FMOD::FrequencyDelayLine::Init(
        FMOD::FrequencyDelayLine *const this,
        FMOD::SystemI *system,
        int blockSize,
        int numBlocksImpulse,
        int numBlocksDelay,
        FMOD::GpuCompute *compute,
        FMOD::GpuComputeMemoryBlock *gpuOnly,
        FMOD::GpuComputeMemoryBlock *cpuWrite,
        FMOD::GpuComputeMemoryBlock *cpuReadWrite)
{
  FMOD::Global *v11; // rax
  float *v12; // rax
  FMOD_RESULT_0 v13; // edx
  int mNumBlocksDelay; // eax
  float *v16; // rax
  float *v17; // rax
  FMOD_COMPLEX *v18; // rax
  FMOD_COMPLEX *v19; // rax
  FMOD_COMPLEX *v20; // rax
  int mNumBlocksTotal; // eax
  int v22; // edx
  __int64 v23; // rax
  FMOD::GpuComputeBuffer *mFFT0InputBuffer; // rdi

  this->mFFTSize = 2 * blockSize;
  this->mNumBlocksImpulse = numBlocksImpulse;
  this->mSystem = system;
  this->mBlockSize = blockSize;
  this->mNumBlocksDelay = numBlocksDelay;
  v11 = off_286F358;
  this->mNumBlocksTotal = numBlocksDelay + numBlocksImpulse;
  v12 = (float *)FMOD::MemPool::alignedCalloc(
                   v11->gSystemMemPool,
                   4 * blockSize,
                   16,
                   "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
                   209,
                   0);
  this->mOutputHistoryTimeDomain = v12;
  v13 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( !v12 )
    return v13;
  this->mUseGpu = compute != 0;
  if ( compute )
  {
    mNumBlocksDelay = this->mNumBlocksDelay;
    LOBYTE(v13) = 28;
    if ( mNumBlocksDelay <= 0 )
      return v13;
    this->mGpuCompute = compute;
    this->mNumBlocksDelay = mNumBlocksDelay - 1;
    v22 = this->mNumBlocksTotal - 1;
    v23 = *(_QWORD *)compute;
    this->mNumBlocksTotal = v22;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeMemoryBlock *, _QWORD, __int64, __int64, FMOD::GpuComputeBuffer **))(v23 + 40))(
            compute,
            gpuOnly,
            (unsigned int)(this->mFFTSize * v22),
            8,
            3,
            &this->mHistoryBuffer);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeMemoryBlock *, _QWORD, __int64, __int64, FMOD::GpuComputeBuffer **))(*(_QWORD *)this->mGpuCompute + 40LL))(
            this->mGpuCompute,
            gpuOnly,
            (unsigned int)this->mFFTSize,
            8,
            2,
            &this->mAccumulatorBuffer);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeMemoryBlock *, _QWORD, __int64, __int64, FMOD::GpuComputeBuffer **))(*(_QWORD *)this->mGpuCompute + 40LL))(
            this->mGpuCompute,
            gpuOnly,
            (unsigned int)this->mFFTSize,
            4,
            2,
            &this->mOutputBuffer);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeMemoryBlock *, _QWORD, __int64, __int64, FMOD::GpuComputeBuffer **))(*(_QWORD *)this->mGpuCompute + 40LL))(
            this->mGpuCompute,
            cpuReadWrite,
            (unsigned int)this->mFFTSize,
            4,
            4,
            &this->mOutputBufferStaging);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeMemoryBlock *, _QWORD, __int64, __int64, FMOD::GpuComputeBuffer **))(*(_QWORD *)this->mGpuCompute + 40LL))(
            this->mGpuCompute,
            gpuOnly,
            (unsigned int)(this->mNumBlocksImpulse * this->mFFTSize),
            8,
            3,
            &this->mImpulseBuffer);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, _QWORD))(*(_QWORD *)this->mGpuCompute
                                                                                               + 88LL))(
            this->mGpuCompute,
            this->mHistoryBuffer,
            0);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, _QWORD))(*(_QWORD *)this->mGpuCompute
                                                                                               + 88LL))(
            this->mGpuCompute,
            this->mOutputBuffer,
            0);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, _QWORD, FMOD::GpuComputeBuffer *, _QWORD, __int64))(*(_QWORD *)this->mGpuCompute + 80LL))(
            this->mGpuCompute,
            this->mOutputBufferStaging,
            0,
            this->mOutputBuffer,
            0,
            0xFFFFFFFFLL);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, __int64, FMOD::GpuComputeShader **))(*(_QWORD *)this->mGpuCompute
                                                                                                 + 24LL))(
            this->mGpuCompute,
            4,
            &this->mConvolutionShader);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeShaderResources **, _QWORD))(*(_QWORD *)this->mGpuCompute + 56LL))(
            this->mGpuCompute,
            &this->mConvolutionResources,
            0);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShader *, FMOD::GpuComputeShaderResources *, _QWORD))(*(_QWORD *)this->mConvolutionShader + 8LL))(
            this->mConvolutionShader,
            this->mConvolutionResources,
            0);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, _QWORD))(*(_QWORD *)this->mConvolutionResources
                                                                                             + 8LL))(
            this->mConvolutionResources,
            1,
            (unsigned int)this->mFFTSize);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, _QWORD))(*(_QWORD *)this->mConvolutionResources
                                                                                             + 8LL))(
            this->mConvolutionResources,
            2,
            (unsigned int)this->mNumBlocksTotal);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, _QWORD))(*(_QWORD *)this->mConvolutionResources
                                                                                             + 8LL))(
            this->mConvolutionResources,
            3,
            (unsigned int)this->mNumBlocksImpulse);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, _QWORD, FMOD::GpuComputeBuffer *, _QWORD, __int64))(*(_QWORD *)this->mConvolutionResources + 32LL))(
            this->mConvolutionResources,
            0,
            this->mImpulseBuffer,
            0,
            0xFFFFFFFFLL);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, __int64, FMOD::GpuComputeBuffer *, _QWORD, __int64))(*(_QWORD *)this->mConvolutionResources + 32LL))(
            this->mConvolutionResources,
            1,
            this->mHistoryBuffer,
            0,
            0xFFFFFFFFLL);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, _QWORD, FMOD::GpuComputeBuffer *, _QWORD, __int64))(*(_QWORD *)this->mConvolutionResources + 40LL))(
            this->mConvolutionResources,
            0,
            this->mAccumulatorBuffer,
            0,
            0xFFFFFFFFLL);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeMemoryBlock *, _QWORD, __int64, __int64, FMOD::GpuComputeBuffer **))(*(_QWORD *)this->mGpuCompute + 40LL))(
            this->mGpuCompute,
            cpuWrite,
            (unsigned int)this->mBlockSize,
            4,
            1,
            &this->mFFT0InputBuffer);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeShaderResources **, _QWORD))(*(_QWORD *)this->mGpuCompute + 56LL))(
            this->mGpuCompute,
            &this->mFFTResources,
            0);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeShaderResources **, _QWORD))(*(_QWORD *)this->mGpuCompute + 56LL))(
            this->mGpuCompute,
            &this->mIFFTResources,
            0);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, _QWORD, FMOD::GpuComputeShader **))(*(_QWORD *)this->mGpuCompute
                                                                                                + 24LL))(
            this->mGpuCompute,
            0,
            &this->mFFT0Shader);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, __int64, FMOD::GpuComputeShader **))(*(_QWORD *)this->mGpuCompute
                                                                                                 + 24LL))(
            this->mGpuCompute,
            1,
            &this->mFFT1Shader);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, __int64, FMOD::GpuComputeShader **))(*(_QWORD *)this->mGpuCompute
                                                                                                 + 24LL))(
            this->mGpuCompute,
            2,
            &this->mIFFT0Shader);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, __int64, FMOD::GpuComputeShader **))(*(_QWORD *)this->mGpuCompute
                                                                                                 + 24LL))(
            this->mGpuCompute,
            3,
            &this->mIFFT1Shader);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShader *, FMOD::GpuComputeShaderResources *, _QWORD))(*(_QWORD *)this->mFFT0Shader + 8LL))(
            this->mFFT0Shader,
            this->mFFTResources,
            0);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShader *, FMOD::GpuComputeShaderResources *, _QWORD))(*(_QWORD *)this->mFFT1Shader + 8LL))(
            this->mFFT1Shader,
            this->mFFTResources,
            0);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShader *, FMOD::GpuComputeShaderResources *, _QWORD))(*(_QWORD *)this->mIFFT0Shader + 8LL))(
            this->mIFFT0Shader,
            this->mIFFTResources,
            0);
    if ( v13 )
      return v13;
    v13 = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShader *, FMOD::GpuComputeShaderResources *, _QWORD))(*(_QWORD *)this->mIFFT1Shader + 8LL))(
            this->mIFFT1Shader,
            this->mIFFTResources,
            0);
    if ( v13 )
      return v13;
    mFFT0InputBuffer = this->mFFT0InputBuffer;
    this->mGpuSyncFrame = 0;
    v13 = (**(unsigned int (__fastcall ***)(FMOD::GpuComputeBuffer *, float **, _QWORD))mFFT0InputBuffer)(
            mFFT0InputBuffer,
            &this->mConvolveInput,
            0);
    if ( v13 )
      return v13;
    goto LABEL_10;
  }
  v16 = (float *)FMOD::MemPool::alignedCalloc(
                   off_286F358->gSystemMemPool,
                   4 * this->mFFTSize,
                   16,
                   "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
                   289,
                   0);
  this->mConvolveInput = v16;
  if ( v16 )
  {
    v17 = (float *)FMOD::MemPool::alignedCalloc(
                     off_286F358->gSystemMemPool,
                     4 * this->mFFTSize,
                     16,
                     "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
                     291,
                     0);
    this->mConvolveOutput = v17;
    if ( v17 )
    {
      v18 = (FMOD_COMPLEX *)FMOD::MemPool::alignedCalloc(
                              off_286F358->gSystemMemPool,
                              8 * this->mNumBlocksTotal * (this->mBlockSize + 1),
                              16,
                              "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
                              294,
                              0);
      this->mHistory = v18;
      if ( v18 )
      {
        v19 = (FMOD_COMPLEX *)FMOD::MemPool::alignedAlloc(
                                off_286F358->gSystemMemPool,
                                8 * this->mNumBlocksImpulse * (this->mBlockSize + 1),
                                16,
                                "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
                                296,
                                0,
                                0);
        this->mImpulse = v19;
        if ( v19 )
        {
          v20 = (FMOD_COMPLEX *)FMOD::MemPool::alignedCalloc(
                                  off_286F358->gSystemMemPool,
                                  8 * this->mFFTSize,
                                  16,
                                  "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
                                  298,
                                  0);
          this->mAccumulator = v20;
          if ( v20 )
          {
LABEL_10:
            mNumBlocksTotal = this->mNumBlocksTotal;
            this->mDSPSampleCount = 0;
            v13 = FMOD_RESULT::FMOD_OK_0;
            this->mHistoryWritePosition = mNumBlocksTotal - 1;
            return v13;
          }
        }
      }
    }
  }
  return FMOD_RESULT::FMOD_ERR_MEMORY_0;
}


// Address: 0x2203760 | Name: _ZN4FMOD18FrequencyDelayLine7DestroyEv
FMOD_RESULT_0 __fastcall FMOD::FrequencyDelayLine::Destroy(FMOD::FrequencyDelayLine *const this)
{
  __int64 v2; // rbp

  if ( this->mUseGpu )
  {
    v2 = (*(__int64 (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)this->mGpuCompute + 112LL))(this->mGpuCompute);
    (*(void (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)this->mGpuCompute + 96LL))(this->mGpuCompute);
    (*(void (__fastcall **)(FMOD::GpuCompute *, __int64))(*(_QWORD *)this->mGpuCompute + 104LL))(this->mGpuCompute, v2);
    (*(void (__fastcall **)(FMOD::GpuComputeBuffer *))(*(_QWORD *)this->mImpulseBuffer + 16LL))(this->mImpulseBuffer);
    (*(void (__fastcall **)(FMOD::GpuComputeBuffer *))(*(_QWORD *)this->mHistoryBuffer + 16LL))(this->mHistoryBuffer);
    (*(void (__fastcall **)(FMOD::GpuComputeBuffer *))(*(_QWORD *)this->mAccumulatorBuffer + 16LL))(this->mAccumulatorBuffer);
    (*(void (__fastcall **)(FMOD::GpuComputeBuffer *))(*(_QWORD *)this->mOutputBuffer + 16LL))(this->mOutputBuffer);
    (*(void (__fastcall **)(FMOD::GpuComputeBuffer *))(*(_QWORD *)this->mOutputBufferStaging + 16LL))(this->mOutputBufferStaging);
    (**(void (__fastcall ***)(FMOD::GpuComputeShader *))this->mConvolutionShader)(this->mConvolutionShader);
    (**(void (__fastcall ***)(FMOD::GpuComputeShaderResources *))this->mConvolutionResources)(this->mConvolutionResources);
    (*(void (__fastcall **)(FMOD::GpuComputeBuffer *))(*(_QWORD *)this->mFFT0InputBuffer + 8LL))(this->mFFT0InputBuffer);
    (*(void (__fastcall **)(FMOD::GpuComputeBuffer *))(*(_QWORD *)this->mFFT0InputBuffer + 16LL))(this->mFFT0InputBuffer);
    (**(void (__fastcall ***)(FMOD::GpuComputeShader *))this->mFFT0Shader)(this->mFFT0Shader);
    (**(void (__fastcall ***)(FMOD::GpuComputeShader *))this->mFFT1Shader)(this->mFFT1Shader);
    (**(void (__fastcall ***)(FMOD::GpuComputeShader *))this->mIFFT0Shader)(this->mIFFT0Shader);
    (**(void (__fastcall ***)(FMOD::GpuComputeShader *))this->mIFFT1Shader)(this->mIFFT1Shader);
    (**(void (__fastcall ***)(FMOD::GpuComputeShaderResources *))this->mFFTResources)(this->mFFTResources);
    (**(void (__fastcall ***)(FMOD::GpuComputeShaderResources *))this->mIFFTResources)(this->mIFFTResources);
  }
  else
  {
    FMOD::MemPool::alignedFree(
      off_286F358->gSystemMemPool,
      this->mConvolveInput,
      "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
      339);
    FMOD::MemPool::alignedFree(
      off_286F358->gSystemMemPool,
      this->mConvolveOutput,
      "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
      340);
    FMOD::MemPool::alignedFree(
      off_286F358->gSystemMemPool,
      this->mHistory,
      "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
      341);
    FMOD::MemPool::alignedFree(
      off_286F358->gSystemMemPool,
      this->mAccumulator,
      "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
      342);
    FMOD::MemPool::alignedFree(
      off_286F358->gSystemMemPool,
      this->mImpulse,
      "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
      343);
  }
  FMOD::MemPool::alignedFree(
    off_286F358->gSystemMemPool,
    this->mOutputHistoryTimeDomain,
    "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
    345);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2203930 | Name: _ZN4FMOD18FrequencyDelayLine15SetIRTimeDomainEPh17FMOD_SOUND_FORMATii
FMOD_RESULT_0 __fastcall FMOD::FrequencyDelayLine::SetIRTimeDomain(
        FMOD::FrequencyDelayLine *const this,
        unsigned __int8 *data,
        FMOD_SOUND_FORMAT_0 format,
        int stride,
        int samples)
{
  __int64 mBlockSize; // rbp
  __int64 v9; // r12
  unsigned __int64 v10; // r12
  int v11; // r12d
  __int64 v12; // rax
  int v13; // r12d
  FMOD_RESULT_0 result; // eax
  FMOD_UINT64 v15; // rax
  int v16; // r12d
  int v17; // ecx
  signed int v18; // ebp
  FMOD_UINT64 frame; // [rsp+18h] [rbp-50h]
  FMOD_UINT64 framea; // [rsp+18h] [rbp-50h]
  __int64 bytesPerBlock; // [rsp+28h] [rbp-40h]

  mBlockSize = this->mBlockSize;
  switch ( format )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      v9 = 8;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      v9 = 16;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      v9 = 24;
      goto LABEL_3;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      v9 = 32;
LABEL_3:
      v10 = ((unsigned __int64)(unsigned int)mBlockSize * v9) >> 3;
      break;
    default:
      LODWORD(v10) = this->mBlockSize;
      break;
  }
  v11 = stride * v10;
  if ( this->mUseGpu )
  {
    if ( this->mNumBlocksImpulse <= 0 )
    {
LABEL_26:
      result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, __int64))(*(_QWORD *)this->mGpuCompute + 72LL))(
                 this->mGpuCompute,
                 this->mImpulseBuffer,
                 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        return (*(FMOD_RESULT_0 (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)this->mGpuCompute + 96LL))(this->mGpuCompute);
    }
    else
    {
      v12 = v11;
      v13 = 0;
      bytesPerBlock = v12;
      while ( 1 )
      {
        if ( (int)mBlockSize > samples )
          LODWORD(mBlockSize) = samples;
        FMOD::DSPI::convert(
          this->mConvolveInput,
          data,
          FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0,
          format,
          mBlockSize,
          1,
          stride,
          1.0,
          1);
        memset(&this->mConvolveInput[(int)mBlockSize], 0, 4LL * (this->mBlockSize - (int)mBlockSize));
        result = FMOD::FrequencyDelayLine::GpuFFT(
                   this,
                   this->mFFT0InputBuffer,
                   this->mImpulseBuffer,
                   v13 * this->mFFTSize);
        if ( result )
          break;
        frame = (*(__int64 (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)this->mGpuCompute + 112LL))(this->mGpuCompute);
        result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)this->mGpuCompute + 96LL))(this->mGpuCompute);
        if ( result )
          break;
        result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD_UINT64))(*(_QWORD *)this->mGpuCompute + 104LL))(
                   this->mGpuCompute,
                   frame);
        if ( result )
          break;
        samples -= mBlockSize;
        ++v13;
        data += bytesPerBlock;
        if ( this->mNumBlocksImpulse <= v13 )
          goto LABEL_26;
        LODWORD(mBlockSize) = this->mBlockSize;
      }
    }
  }
  else
  {
    memset(&this->mConvolveInput[mBlockSize], 0, 4 * mBlockSize);
    v15 = v11;
    v16 = 0;
    framea = v15;
    if ( this->mNumBlocksImpulse > 0 )
    {
      while ( 1 )
      {
        v18 = this->mBlockSize;
        if ( samples <= v18 )
          v18 = samples;
        FMOD::DSPI::convert(
          this->mConvolveInput,
          data,
          FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0,
          format,
          v18,
          1,
          stride,
          1.0,
          1);
        memset(&this->mConvolveInput[v18], 0, 4LL * (this->mFFTSize - v18));
        result = FMOD::SystemI::performRealFFT(
                   this->mSystem,
                   this->mFFTSize,
                   this->mConvolveInput,
                   this->mAccumulator,
                   0,
                   1);
        if ( result )
          break;
        v17 = v16;
        samples -= v18;
        ++v16;
        memcpy_0(&this->mImpulse[(this->mBlockSize + 1) * v17], this->mAccumulator, 8LL * (this->mBlockSize + 1));
        data += framea;
        if ( this->mNumBlocksImpulse <= v16 )
          goto LABEL_28;
      }
    }
    else
    {
LABEL_28:
      memset(this->mConvolveInput, 0, 4LL * this->mBlockSize);
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2203c30 | Name: _ZN4FMOD18FrequencyDelayLine8ConvolveEv
FMOD_RESULT_0 __fastcall FMOD::FrequencyDelayLine::Convolve(FMOD::FrequencyDelayLine *const this)
{
  FMOD::FrequencyDelayLine *v1; // rbx
  FMOD_RESULT_0 result; // eax
  int mNumBlocksImpulse; // edx
  int mBlockSize; // r11d
  FMOD_COMPLEX *mImpulse; // r13
  FMOD_COMPLEX *mHistory; // r15
  __int64 v7; // rax
  float *v8; // r12
  int v9; // edi
  __int64 v10; // r14
  float *p_imag; // rbp
  int v12; // edx
  const FMOD_COMPLEX *v13; // rcx
  float *v14; // r9
  FMOD_COMPLEX *v15; // rsi
  float *v16; // r8
  int v17; // eax
  float *v18; // r10
  float real; // xmm1_4
  float v20; // xmm12_4
  float v21; // xmm14_4
  float v22; // xmm13_4
  float v23; // xmm11_4
  float v24; // xmm9_4
  float v25; // xmm10_4
  float v26; // xmm7_4
  float v27; // xmm0_4
  float v28; // xmm1_4
  float v29; // xmm6_4
  float v30; // xmm5_4
  float v31; // xmm3_4
  float v32; // xmm13_4
  float v33; // xmm15_4
  float v34; // xmm4_4
  float v35; // xmm2_4
  float v36; // xmm9_4
  float v37; // xmm9_4
  float v38; // xmm0_4
  float v39; // xmm0_4
  float v40; // xmm5_4
  float v41; // xmm4_4
  float v42; // xmm3_4
  float *v43; // rax
  float v44; // xmm5_4
  float v45; // xmm0_4
  float v46; // xmm1_4
  float v47; // xmm0_4
  int mFFTSize; // esi
  __int64 v49; // rdx
  const FMOD_COMPLEX *v50; // rax
  float imag; // xmm0_4
  int v52; // edi
  float v53; // xmm4_4
  float *mConvolveOutput; // rdx
  float *mOutputHistoryTimeDomain; // rax
  float *v56; // rsi
  __int64 v57; // rcx
  __int64 v58; // rdi
  float v59; // xmm1_4
  float v60; // xmm0_4
  int v61; // xmm7_4
  int v62; // xmm6_4
  float v63; // xmm3_4
  int v64; // xmm5_4
  float v65; // xmm2_4
  int v66; // edx
  float v67; // [rsp+0h] [rbp-58h]
  float v68; // [rsp+4h] [rbp-54h]
  const FMOD_COMPLEX *dft; // [rsp+8h] [rbp-50h]
  int v70; // [rsp+10h] [rbp-48h]
  int mNumBlocksTotal; // [rsp+14h] [rbp-44h]

  v1 = this;
  if ( this->mUseGpu )
  {
    result = FMOD::FrequencyDelayLine::GpuFFT(
               this,
               this->mFFT0InputBuffer,
               this->mHistoryBuffer,
               this->mFFTSize * this->mHistoryWritePosition);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, __int64))(*(_QWORD *)this->mGpuCompute + 72LL))(
                 this->mGpuCompute,
                 this->mHistoryBuffer,
                 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = (*(unsigned int (__fastcall **)(FMOD::GpuComputeShaderResources *, _QWORD, _QWORD))(*(_QWORD *)this->mConvolutionResources + 8LL))(
                   this->mConvolutionResources,
                   0,
                   (unsigned int)(this->mNumBlocksDelay + this->mHistoryWritePosition));
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeShader *, _QWORD, __int64, __int64))(*(_QWORD *)this->mGpuCompute + 64LL))(
                     this->mGpuCompute,
                     this->mConvolutionShader,
                     (unsigned int)(this->mFFTSize / 64),
                     1,
                     1);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, __int64))(*(_QWORD *)this->mGpuCompute + 72LL))(
                       this->mGpuCompute,
                       this->mAccumulatorBuffer,
                       2);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, _QWORD))(*(_QWORD *)this->mGpuCompute + 72LL))(
                         this->mGpuCompute,
                         this->mHistoryBuffer,
                         0);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                result = FMOD::FrequencyDelayLine::GpuIFFT(this, this->mAccumulatorBuffer, this->mOutputBuffer);
                if ( result == FMOD_RESULT::FMOD_OK_0 )
                {
                  result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *, _QWORD, FMOD::GpuComputeBuffer *, _QWORD, __int64))(*(_QWORD *)this->mGpuCompute + 80LL))(
                             this->mGpuCompute,
                             this->mOutputBufferStaging,
                             0,
                             this->mOutputBuffer,
                             0,
                             0xFFFFFFFFLL);
                  if ( result == FMOD_RESULT::FMOD_OK_0 )
                  {
                    this->mGpuSyncFrame = (*(__int64 (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)this->mGpuCompute
                                                                                        + 112LL))(this->mGpuCompute);
LABEL_20:
                    v66 = v1->mHistoryWritePosition - 1;
                    result = FMOD_RESULT::FMOD_OK_0;
                    v1->mHistoryWritePosition = v66;
                    if ( v66 < 0 )
                      v1->mHistoryWritePosition = v1->mNumBlocksTotal - 1;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  else
  {
    result = FMOD::SystemI::performRealFFT(
               this->mSystem,
               this->mFFTSize,
               this->mConvolveInput,
               this->mAccumulator,
               0,
               1);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      memcpy_0(
        &this->mHistory[(this->mBlockSize + 1) * this->mHistoryWritePosition],
        this->mAccumulator,
        8LL * (this->mBlockSize + 1));
      memset(this->mAccumulator, 0, 8LL * (this->mBlockSize + 1));
      mNumBlocksImpulse = this->mNumBlocksImpulse;
      if ( mNumBlocksImpulse <= 0 )
      {
        mBlockSize = this->mBlockSize;
        dft = this->mAccumulator;
      }
      else
      {
        mBlockSize = this->mBlockSize;
        mImpulse = this->mImpulse;
        mHistory = this->mHistory;
        mNumBlocksTotal = this->mNumBlocksTotal;
        dft = this->mAccumulator;
        v7 = mBlockSize;
        v8 = (float *)&dft[v7];
        v9 = this->mNumBlocksDelay + this->mHistoryWritePosition;
        v10 = v7 * 8 + 8;
        p_imag = &mImpulse[v7].imag;
        v70 = mNumBlocksImpulse + v9;
        do
        {
          v12 = (mBlockSize + 1) * (v9 % mNumBlocksTotal);
          if ( mBlockSize > 0 )
          {
            v13 = dft;
            v14 = &mImpulse->imag;
            v15 = &mHistory[v12];
            v16 = (float *)mImpulse;
            v17 = 0;
            v18 = &v15->imag;
            do
            {
              real = v15[3].real;
              v17 += 4;
              v15 += 4;
              v20 = *v16;
              v18 += 8;
              v21 = *v14;
              v16 += 8;
              v68 = real;
              v14 += 8;
              v22 = v15[-4].real;
              v13 += 4;
              v23 = *(v18 - 8);
              v24 = v15[-3].real;
              v25 = *(v14 - 6);
              v26 = *(v18 - 6);
              v27 = (float)(v20 * v22) - (float)(v21 * v23);
              v28 = *(v16 - 6) * v24;
              v67 = *(v16 - 2);
              v29 = *(v14 - 4);
              v30 = v15[-2].real;
              v31 = *(v18 - 4);
              v32 = (float)((float)(v22 * v21) + (float)(v23 * v20)) + v13[-4].imag;
              v33 = *(v18 - 2);
              v34 = *(v16 - 4);
              v35 = *(v14 - 2);
              v36 = (float)(v24 * v25) + (float)(v26 * *(v16 - 6));
              v13[-4].real = v27 + v13[-4].real;
              v37 = v36 + v13[-3].imag;
              v13[-4].imag = v32;
              v38 = (float)(v28 - (float)(v25 * v26)) + v13[-3].real;
              v13[-3].imag = v37;
              v13[-3].real = v38;
              v39 = v34 * v30;
              v40 = (float)((float)(v30 * v29) + (float)(v31 * v34)) + v13[-2].imag;
              v13[-2].real = (float)(v39 - (float)(v29 * v31)) + v13[-2].real;
              v13[-2].imag = v40;
              v13[-1].real = (float)((float)(v67 * v68) - (float)(v35 * v33)) + v13[-1].real;
              v13[-1].imag = (float)((float)(v68 * v35) + (float)(v67 * v33)) + v13[-1].imag;
            }
            while ( v17 < mBlockSize );
          }
          v41 = *(p_imag - 1);
          v42 = *p_imag;
          v43 = (float *)&mHistory[mBlockSize + v12];
          v44 = *p_imag;
          ++v9;
          p_imag = (float *)((char *)p_imag + v10);
          v45 = v43[1];
          mImpulse = (FMOD_COMPLEX *)((char *)mImpulse + v10);
          v46 = (float)((float)(v41 * *v43) - (float)(v44 * v45)) + *v8;
          v47 = (float)((float)(v45 * v41) + (float)(*v43 * v42)) + v8[1];
          *v8 = v46;
          v8[1] = v47;
        }
        while ( v9 != v70 );
        v1 = this;
      }
      mFFTSize = v1->mFFTSize;
      if ( mBlockSize > 1 )
      {
        v49 = (__int64)&dft[mFFTSize - 1];
        v50 = dft + 1;
        do
        {
          imag = v50->imag;
          ++v50;
          v49 -= 8;
          *(float *)(v49 + 8) = v50[-1].real;
          *(float *)(v49 + 12) = -imag;
        }
        while ( v50 != &dft[(unsigned int)(mBlockSize - 2) + 2] );
      }
      result = FMOD::SystemI::performRealInverseFFT(v1->mSystem, mFFTSize, dft, v1->mConvolveOutput, 0, 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v52 = v1->mBlockSize;
        v53 = 1.0 / (float)v1->mFFTSize;
        if ( v52 > 0 )
        {
          mConvolveOutput = v1->mConvolveOutput;
          mOutputHistoryTimeDomain = v1->mOutputHistoryTimeDomain;
          v56 = mConvolveOutput + 4;
          v57 = (__int64)&mConvolveOutput[v52 + 1];
          v58 = (__int64)&mConvolveOutput[4 * ((unsigned int)(v52 - 1) >> 2) + 4];
          while ( 1 )
          {
            mOutputHistoryTimeDomain += 4;
            v57 += 16;
            v59 = mConvolveOutput[2] + *(mOutputHistoryTimeDomain - 2);
            v60 = mConvolveOutput[3] + *(mOutputHistoryTimeDomain - 1);
            v61 = *(_DWORD *)(v57 - 16);
            v62 = *(_DWORD *)(v57 - 12);
            v63 = (float)(*mConvolveOutput + *(mOutputHistoryTimeDomain - 4)) * v53;
            v64 = *(_DWORD *)(v57 - 8);
            v65 = (float)(mConvolveOutput[1] + *(mOutputHistoryTimeDomain - 3)) * v53;
            *(mOutputHistoryTimeDomain - 4) = *(float *)(v57 - 20);
            *((_DWORD *)mOutputHistoryTimeDomain - 3) = v61;
            *((_DWORD *)mOutputHistoryTimeDomain - 2) = v62;
            *((_DWORD *)mOutputHistoryTimeDomain - 1) = v64;
            *mConvolveOutput = v63;
            mConvolveOutput[1] = v65;
            mConvolveOutput[2] = v59 * v53;
            mConvolveOutput[3] = v60 * v53;
            mConvolveOutput = v56;
            if ( v56 == (float *)v58 )
              break;
            v56 += 4;
          }
        }
        goto LABEL_20;
      }
    }
  }
  return result;
}


// Address: 0x22041d0 | Name: _ZN4FMOD18FrequencyDelayLine7ProcessEPfS1_iffi
FMOD_RESULT_0 __fastcall FMOD::FrequencyDelayLine::Process(
        FMOD::FrequencyDelayLine *const this,
        float *input,
        float *output,
        int length,
        double wet,
        float deltaWet,
        int wetRamp)
{
  FMOD_RESULT_0 result; // eax
  int v12; // r8d
  int v13; // eax
  bool v14; // zf
  float *v15; // rdx
  __int64 v16; // rax
  float v17; // xmm2_4
  float *v18; // rax
  float *v19; // rdx
  float v20; // xmm1_4
  size_t mBlockSize; // rdx
  __int64 v22; // rax
  float *mOutputHistoryTimeDomain; // rdi
  float *i; // rsi
  size_t v25; // rdx
  float *v26; // rsi
  float *mConvolveOutput; // rdx
  int v28; // r8d
  __int64 v29; // rax
  float v30; // xmm2_4
  __int64 v31; // rdx
  float *v32; // rax
  float v33; // xmm1_4

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( wetRamp <= length )
  {
    if ( this->mUseGpu )
    {
      result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, FMOD_UINT64))(*(_QWORD *)this->mGpuCompute + 104LL))(
                 this->mGpuCompute,
                 this->mGpuSyncFrame);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = (**(unsigned int (__fastcall ***)(FMOD::GpuComputeBuffer *, float **))this->mOutputBufferStaging)(
                   this->mOutputBufferStaging,
                   &this->mConvolveOutput);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          mBlockSize = this->mBlockSize;
          v22 = 0;
          mOutputHistoryTimeDomain = this->mOutputHistoryTimeDomain;
          for ( i = this->mConvolveOutput; (int)mBlockSize > (int)v22; ++v22 )
            i[v22] = i[v22] + mOutputHistoryTimeDomain[v22];
          v25 = mBlockSize;
          v26 = &i[v25];
          memcpy_0(mOutputHistoryTimeDomain, v26, v25 * 4);
          v28 = wetRamp;
          *(_QWORD *)&wet = LODWORD(wet);
          if ( wetRamp <= 0 )
          {
            v28 = 0;
          }
          else
          {
            mConvolveOutput = this->mConvolveOutput;
            v29 = 0;
            do
            {
              v30 = mConvolveOutput[v29] * *(float *)&wet;
              *(float *)&wet = *(float *)&wet + deltaWet;
              output[v29] = v30 + output[v29];
              ++v29;
            }
            while ( wetRamp > (int)v29 );
          }
          if ( length > v28 )
          {
            v31 = v28;
            v32 = &output[v31];
            mConvolveOutput = &this->mConvolveOutput[v31];
            do
            {
              v33 = *mConvolveOutput;
              ++v32;
              ++mConvolveOutput;
              *(v32 - 1) = (float)(v33 * *(float *)&wet) + *(v32 - 1);
            }
            while ( v32 != &output[(unsigned int)(length - 1 - v28) + 1 + (__int64)v28] );
          }
          (*(void (__fastcall **)(FMOD::GpuComputeBuffer *, float *, float *, double))(*(_QWORD *)this->mOutputBufferStaging
                                                                                     + 8LL))(
            this->mOutputBufferStaging,
            v26,
            mConvolveOutput,
            wet);
          memcpy_0(this->mConvolveInput, input, 4LL * this->mBlockSize);
          return FMOD::FrequencyDelayLine::Convolve(this);
        }
      }
    }
    else
    {
      memcpy_0(&this->mConvolveInput[this->mDSPSampleCount], input, 4LL * length);
      v12 = wetRamp;
      v13 = length + this->mDSPSampleCount;
      v14 = v13 == this->mBlockSize;
      this->mDSPSampleCount = v13;
      if ( !v14
        || (result = FMOD::FrequencyDelayLine::Convolve(this),
            this->mDSPSampleCount = 0,
            v12 = wetRamp,
            result == FMOD_RESULT::FMOD_OK_0) )
      {
        if ( v12 <= 0 )
        {
          v12 = 0;
        }
        else
        {
          v15 = &this->mConvolveOutput[this->mDSPSampleCount];
          v16 = 0;
          do
          {
            v17 = v15[v16] * *(float *)&wet;
            *(float *)&wet = *(float *)&wet + deltaWet;
            output[v16] = v17 + output[v16];
            ++v16;
          }
          while ( v12 > (int)v16 );
        }
        if ( length > v12 )
        {
          v18 = &output[v12];
          v19 = &this->mConvolveOutput[v12 + (__int64)this->mDSPSampleCount];
          do
          {
            v20 = *v19;
            ++v18;
            ++v19;
            *(v18 - 1) = (float)(v20 * *(float *)&wet) + *(v18 - 1);
          }
          while ( v18 != &output[(unsigned int)(length - 1 - v12) + 1 + (__int64)v12] );
        }
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x22044a0 | Name: _ZN4FMOD18FrequencyDelayLine5ResetEv
FMOD_RESULT_0 __fastcall FMOD::FrequencyDelayLine::Reset(FMOD::FrequencyDelayLine *const this)
{
  memset(this->mOutputHistoryTimeDomain, 0, 4LL * this->mBlockSize);
  if ( this->mUseGpu )
  {
    (*(void (__fastcall **)(FMOD::GpuCompute *, FMOD::GpuComputeBuffer *))(*(_QWORD *)this->mGpuCompute + 88LL))(
      this->mGpuCompute,
      this->mHistoryBuffer);
  }
  else
  {
    memset(this->mHistory, 0, (this->mBlockSize + 1) * 8LL * this->mNumBlocksTotal);
    memset(this->mConvolveInput, 0, 4LL * this->mFFTSize);
    memset(this->mConvolveOutput, 0, 4LL * this->mBlockSize);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2204530 | Name: _ZN4FMOD11ConvolutionC2Ev
void __fastcall FMOD::Convolution::Convolution(FMOD::Convolution *const this)
{
  this->mSystem = 0;
  this->mSystemBlockSize = 0;
  this->mLinked = 1;
  this->mNumIRChannels = 2;
  this->mCurrentWetLevel = 1.0;
  this->mNumDelayLines = 0;
  this->mCurrentDryLevel = 0.0;
  this->mIdleCountdown = 0;
  this->mTargetWetLevel = 1.0;
  this->mImpulseSamples = 0;
  this->mTargetDryLevel = 0.0;
  this->mUseGpu = 0;
  this->mGpuOnly = 0;
  this->mCpuWrite = 0;
  this->mCpuReadWrite = 0;
  this->mDelayLines = 0;
}


// Address: 0x22045b0 | Name: _Z29FMOD_ConvolutionReverb_createP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD_ConvolutionReverb_create(FMOD_DSP_STATE *dsp_state)
{
  float v1; // xmm1_4
  FMOD::SystemI *v2; // r13
  FMOD_DSP_DESCRIPTION_0 *v3; // rbp
  FMOD::Convolution *v4; // rax
  FMOD::Convolution *v5; // rbx
  int numparameters; // eax
  __int64 v7; // rbx
  FMOD_RESULT_0 result; // eax
  FMOD_DSP_PARAMETER_DESC *v9; // rdx
  unsigned int systemBlockSize[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  v2 = off_286F358->gSystem[dsp_state->systemobject];
  v3 = FMODGetDSPDescription();
  v4 = (FMOD::Convolution *)FMOD::MemPool::alloc(
                              off_286F358->gSystemMemPool,
                              88,
                              "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
                              883,
                              0,
                              0);
  v5 = v4;
  if ( !v4 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  FMOD::Convolution::Convolution(v4);
  v5->mSystem = v2;
  FMOD::SystemI::getDSPBufferSize(v2, systemBlockSize, 0);
  v5->mSystemBlockSize = systemBlockSize[0];
  numparameters = v3->numparameters;
  dsp_state->plugindata = v5;
  v7 = 0;
  if ( numparameters > 0 )
  {
    do
    {
      v9 = v3->paramdesc[v7];
      if ( v9->type )
      {
        if ( v9->type == FMOD_DSP_PARAMETER_TYPE_BOOL )
        {
          result = FMOD_ConvolutionReverb_setparambool(dsp_state, v7, v9->intdesc.min);
          if ( result )
            return result;
        }
      }
      else
      {
        result = (unsigned int)FMOD_ConvolutionReverb_setparamfloat(dsp_state, v7, v9->floatdesc.defaultval, v1);
        if ( result )
          return result;
      }
      ++v7;
    }
    while ( (int)v7 < v3->numparameters );
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22046b0 | Name: _ZN4FMOD11Convolution4InitEPh17FMOD_SOUND_FORMATii
FMOD_RESULT_0 __fastcall FMOD::Convolution::Init(
        FMOD::Convolution *const this,
        unsigned __int8 *impulseData,
        const FMOD_SOUND_FORMAT_0 impulseFormat,
        const int impulseChannels,
        const int impulseSamples)
{
  FMOD_RESULT_0 result; // eax
  int mSystemBlockSize; // edi
  FMOD::GpuCompute *v9; // rax
  FMOD::GpuCompute *v10; // rax
  FMOD::GpuCompute *v11; // rax
  int v12; // esi
  int v13; // eax
  FMOD::FrequencyDelayLine **v14; // rax
  int v15; // r12d
  FMOD::Convolution *v16; // r14
  int v17; // eax
  int v18; // ebp
  int v19; // r13d
  int v20; // ebx
  int v21; // r15d
  void **v22; // r15
  FMOD::FrequencyDelayLine *v23; // rdi
  int v24; // r15d
  FMOD::FrequencyDelayLine **v25; // rbp
  FMOD::FrequencyDelayLine *v26; // rax
  int mNumDelayLines; // edx
  FMOD::FrequencyDelayLine *v28; // rdi
  FMOD::FrequencyDelayLine **v29; // rbp
  FMOD::FrequencyDelayLine *v30; // rax
  int v31; // edx
  FMOD::GpuComputeMemoryBlock *cpuReadWrite; // rbx
  FMOD::GpuComputeMemoryBlock *cpuWrite; // r13
  FMOD::GpuComputeMemoryBlock *gpuOnly; // rbp
  FMOD::GpuCompute *v35; // rax
  int bytesPerChannel; // [rsp+34h] [rbp-64h]
  unsigned __int8 *data; // [rsp+38h] [rbp-60h]
  int impulseChannelsa; // [rsp+48h] [rbp-50h]
  int gpuOnlySizeBytes; // [rsp+54h] [rbp-44h] BYREF
  int cpuWriteSizeBytes; // [rsp+58h] [rbp-40h] BYREF
  int cpuReadWriteSizeBytes[15]; // [rsp+5Ch] [rbp-3Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( !this->mSystem || impulseChannels <= 0 || impulseSamples <= 0 || !impulseData )
    return result;
  if ( FMOD::GpuCompute::IsAvaliable() )
  {
    mSystemBlockSize = this->mSystemBlockSize;
    if ( impulseSamples > mSystemBlockSize )
    {
      this->mUseGpu = 1;
      this->mNumDelayLines = 2;
      FMOD::FrequencyDelayLine::GetGpuMemoryRequired(
        mSystemBlockSize,
        (impulseSamples - 1) / mSystemBlockSize + 1,
        1,
        &gpuOnlySizeBytes,
        &cpuWriteSizeBytes,
        cpuReadWriteSizeBytes);
      gpuOnlySizeBytes *= impulseChannels;
      cpuWriteSizeBytes *= impulseChannels;
      cpuReadWriteSizeBytes[0] *= impulseChannels;
      v9 = FMOD::GpuCompute::Get();
      result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, _QWORD, _QWORD, FMOD::GpuComputeMemoryBlock **))(*(_QWORD *)v9 + 32LL))(
                 v9,
                 0,
                 (unsigned int)gpuOnlySizeBytes,
                 &this->mGpuOnly);
      if ( result )
        return result;
      v10 = FMOD::GpuCompute::Get();
      result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, __int64, _QWORD, FMOD::GpuComputeMemoryBlock **))(*(_QWORD *)v10 + 32LL))(
                 v10,
                 1,
                 (unsigned int)cpuWriteSizeBytes,
                 &this->mCpuWrite);
      if ( result )
        return result;
      v11 = FMOD::GpuCompute::Get();
      result = (*(unsigned int (__fastcall **)(FMOD::GpuCompute *, __int64, _QWORD, FMOD::GpuComputeMemoryBlock **))(*(_QWORD *)v11 + 32LL))(
                 v11,
                 2,
                 (unsigned int)cpuReadWriteSizeBytes[0],
                 &this->mCpuReadWrite);
      if ( result )
        return result;
      v12 = 8 * this->mNumDelayLines;
      goto LABEL_19;
    }
    this->mUseGpu = 0;
    this->mNumDelayLines = 1;
    v13 = impulseSamples - 4 * mSystemBlockSize;
  }
  else
  {
    mSystemBlockSize = this->mSystemBlockSize;
    this->mUseGpu = 0;
    this->mNumDelayLines = 1;
    v13 = impulseSamples - 4 * mSystemBlockSize;
  }
  if ( v13 <= 0 || 4 * mSystemBlockSize > 0xFFFF )
  {
    v12 = 8;
  }
  else if ( v13 - 16 * mSystemBlockSize <= 0 || 16 * mSystemBlockSize > 0xFFFF )
  {
    this->mNumDelayLines = 2;
    v12 = 16;
  }
  else
  {
    this->mNumDelayLines = 3;
    v12 = 24;
  }
LABEL_19:
  this->mNumIRChannels = impulseChannels;
  this->mImpulseSamples = impulseSamples;
  switch ( impulseFormat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      bytesPerChannel = 2;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      bytesPerChannel = 3;
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      bytesPerChannel = 4;
      break;
    default:
      bytesPerChannel = 1;
      break;
  }
  v14 = (FMOD::FrequencyDelayLine **)FMOD::MemPool::alloc(
                                       off_286F358->gSystemMemPool,
                                       impulseChannels * v12,
                                       "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
                                       675,
                                       0,
                                       0);
  this->mDelayLines = v14;
  if ( !v14 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( this->mNumIRChannels <= 0 )
    return FMOD_RESULT::FMOD_OK_0;
  impulseChannelsa = impulseChannels;
  v15 = 0;
  v16 = this;
  data = impulseData;
  while ( v16->mUseGpu )
  {
    v24 = (impulseSamples - 1) / v16->mSystemBlockSize;
    v25 = &v16->mDelayLines[v15 * v16->mNumDelayLines];
    v26 = (FMOD::FrequencyDelayLine *)FMOD::MemPool::calloc(
                                        off_286F358->gSystemMemPool,
                                        216,
                                        "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
                                        685,
                                        0);
    mNumDelayLines = v16->mNumDelayLines;
    *v25 = v26;
    v28 = v16->mDelayLines[v15 * mNumDelayLines];
    if ( !v28 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    result = FMOD::FrequencyDelayLine::Init(v28, v16->mSystem, v16->mSystemBlockSize, 1, 0, 0, 0, 0, 0);
    if ( result )
      return result;
    result = FMOD::FrequencyDelayLine::SetIRTimeDomain(
               v16->mDelayLines[v15 * v16->mNumDelayLines],
               data,
               impulseFormat,
               impulseChannelsa,
               v16->mSystemBlockSize);
    if ( result )
      return result;
    v29 = &v16->mDelayLines[v15 * v16->mNumDelayLines + 1];
    v30 = (FMOD::FrequencyDelayLine *)FMOD::MemPool::calloc(
                                        off_286F358->gSystemMemPool,
                                        216,
                                        "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
                                        693,
                                        0);
    v31 = v16->mNumDelayLines;
    *v29 = v30;
    if ( !v16->mDelayLines[v15 * v31 + 1] )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    cpuReadWrite = v16->mCpuReadWrite;
    cpuWrite = v16->mCpuWrite;
    gpuOnly = v16->mGpuOnly;
    v35 = FMOD::GpuCompute::Get();
    result = FMOD::FrequencyDelayLine::Init(
               v16->mDelayLines[v15 * v16->mNumDelayLines + 1],
               v16->mSystem,
               v16->mSystemBlockSize,
               v24,
               1,
               v35,
               gpuOnly,
               cpuWrite,
               cpuReadWrite);
    if ( result )
      return result;
    result = FMOD::FrequencyDelayLine::SetIRTimeDomain(
               v16->mDelayLines[v15 * v16->mNumDelayLines + 1],
               &impulseData[bytesPerChannel * (v15 + v16->mSystemBlockSize * v16->mNumIRChannels)],
               impulseFormat,
               impulseChannelsa,
               impulseSamples - v16->mSystemBlockSize);
    if ( result )
      return result;
LABEL_44:
    ++v15;
    data += bytesPerChannel;
    if ( v16->mNumIRChannels <= v15 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  v17 = v16->mNumDelayLines;
  v18 = v16->mSystemBlockSize;
  if ( v17 <= 0 )
    goto LABEL_44;
  v19 = 0;
  v20 = 0;
  while ( 1 )
  {
    v22 = (void **)(&v16->mDelayLines[v20] + v15 * v17);
    *v22 = FMOD::MemPool::calloc(
             off_286F358->gSystemMemPool,
             216,
             "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
             705,
             0);
    v23 = (FMOD::FrequencyDelayLine *)*((_QWORD *)&v16->mDelayLines[v20] + v15 * v16->mNumDelayLines);
    if ( !v23 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    if ( v16->mNumDelayLines - 1 > v20 )
    {
      result = FMOD::FrequencyDelayLine::Init(v23, v16->mSystem, v18, 3, 0, 0, 0, 0, 0);
      if ( result )
        return result;
      v21 = 3 * v18;
      result = FMOD::FrequencyDelayLine::SetIRTimeDomain(
                 *((FMOD::FrequencyDelayLine *const *)&v16->mDelayLines[v20] + v15 * v16->mNumDelayLines),
                 &impulseData[bytesPerChannel * (v15 + v19 * v16->mNumIRChannels)],
                 impulseFormat,
                 impulseChannelsa,
                 3 * v18);
      if ( result )
        return result;
    }
    else
    {
      result = FMOD::FrequencyDelayLine::Init(
                 v23,
                 v16->mSystem,
                 v18,
                 (impulseSamples - v19 - 1) / v18 + 1,
                 0,
                 0,
                 0,
                 0,
                 0);
      if ( result )
        return result;
      v21 = 3 * v18;
      FMOD::FrequencyDelayLine::SetIRTimeDomain(
        *((FMOD::FrequencyDelayLine *const *)&v16->mDelayLines[v20] + v15 * v16->mNumDelayLines),
        &impulseData[bytesPerChannel * (v15 + v19 * v16->mNumIRChannels)],
        impulseFormat,
        impulseChannelsa,
        impulseSamples - v19);
    }
    v17 = v16->mNumDelayLines;
    ++v20;
    v19 += v21;
    v18 *= 4;
    if ( v17 <= v20 )
      goto LABEL_44;
  }
}


// Address: 0x2204d30 | Name: _ZN4FMOD11Convolution7DestroyEv
FMOD_RESULT_0 __fastcall FMOD::Convolution::Destroy(FMOD::Convolution *const this)
{
  FMOD::FrequencyDelayLine **mDelayLines; // rsi
  int mNumDelayLines; // eax
  int v4; // r12d
  int v5; // ebx
  int v6; // edx
  FMOD::GpuComputeMemoryBlock *mCpuReadWrite; // rdi
  FMOD::GpuComputeMemoryBlock *mCpuWrite; // rdi

  mDelayLines = this->mDelayLines;
  if ( mDelayLines )
  {
    if ( this->mNumIRChannels > 0 )
    {
      mNumDelayLines = this->mNumDelayLines;
      v4 = 0;
      do
      {
        if ( mNumDelayLines > 0 )
        {
          v5 = 0;
          do
          {
            FMOD::FrequencyDelayLine::Destroy(*(&mDelayLines[v5] + v4 * mNumDelayLines));
            v6 = v5 + v4 * this->mNumDelayLines;
            ++v5;
            FMOD::MemPool::free(
              off_286F358->gSystemMemPool,
              this->mDelayLines[v6],
              "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
              739);
            mNumDelayLines = this->mNumDelayLines;
            mDelayLines = this->mDelayLines;
          }
          while ( mNumDelayLines > v5 );
        }
        ++v4;
      }
      while ( this->mNumIRChannels > v4 );
    }
    FMOD::MemPool::free(
      off_286F358->gSystemMemPool,
      mDelayLines,
      "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
      743);
    this->mDelayLines = 0;
  }
  if ( this->mUseGpu )
  {
    (**(void (__fastcall ***)(FMOD::GpuComputeMemoryBlock *))this->mGpuOnly)(this->mGpuOnly);
    mCpuReadWrite = this->mCpuReadWrite;
    this->mGpuOnly = 0;
    (**(void (__fastcall ***)(FMOD::GpuComputeMemoryBlock *))mCpuReadWrite)(mCpuReadWrite);
    mCpuWrite = this->mCpuWrite;
    this->mCpuReadWrite = 0;
    (**(void (__fastcall ***)(FMOD::GpuComputeMemoryBlock *))mCpuWrite)(mCpuWrite);
    this->mCpuWrite = 0;
    this->mUseGpu = 0;
  }
  this->mNumDelayLines = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2204e50 | Name: _Z30FMOD_ConvolutionReverb_releaseP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD_ConvolutionReverb_release(FMOD_DSP_STATE *dsp)
{
  FMOD::Convolution *plugindata; // rbx
  FMOD::GpuCompute *v3; // rax
  FMOD::GpuCompute *v4; // rax

  plugindata = (FMOD::Convolution *)dsp->plugindata;
  if ( plugindata->mUseGpu )
  {
    v3 = FMOD::GpuCompute::Get();
    (**(void (__fastcall ***)(FMOD::GpuCompute *))v3)(v3);
    FMOD::Convolution::Destroy(plugindata);
    v4 = FMOD::GpuCompute::Get();
    (*(void (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)v4 + 8LL))(v4);
  }
  else
  {
    FMOD::Convolution::Destroy((FMOD::Convolution *const)dsp->plugindata);
  }
  FMOD::MemPool::free(
    off_286F358->gSystemMemPool,
    plugindata,
    "../../../core_api/src/fmod_dsp_convolutionreverb.cpp",
    931);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2204ec0 | Name: _Z35FMOD_ConvolutionReverb_setparamdataP14FMOD_DSP_STATEiPvj
FMOD_RESULT_0 __fastcall FMOD_ConvolutionReverb_setparamdata(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void *data,
        unsigned int len)
{
  FMOD_RESULT_0 result; // eax
  FMOD::Convolution *plugindata; // rbx
  FMOD::SystemI *v8; // r13
  bool mUseGpu; // r14
  FMOD_RESULT_0 v10; // r15d
  FMOD::GpuCompute *v11; // rax
  FMOD::GpuCompute *v12; // rax
  unsigned int systemBlockSize[15]; // [rsp+Ch] [rbp-3Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  plugindata = (FMOD::Convolution *)dsp_state->plugindata;
  if ( !index )
  {
    v8 = off_286F358->gSystem[dsp_state->systemobject];
    FMOD::SystemI::lockDSPInternal(v8);
    mUseGpu = plugindata->mUseGpu;
    if ( mUseGpu )
    {
      v11 = FMOD::GpuCompute::Get();
      (**(void (__fastcall ***)(FMOD::GpuCompute *))v11)(v11);
    }
    v10 = FMOD_RESULT::FMOD_OK_0;
    FMOD::Convolution::Destroy(plugindata);
    if ( data )
    {
      FMOD::SystemI::getDSPBufferSize(v8, systemBlockSize, 0);
      if ( isPowerOfTwo(systemBlockSize[0]) )
        v10 = FMOD::Convolution::Init(
                plugindata,
                (unsigned __int8 *)data + 2,
                FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0,
                *(__int16 *)data,
                ((unsigned __int64)len - 2) / (2LL * *(__int16 *)data));
    }
    if ( mUseGpu )
    {
      v12 = FMOD::GpuCompute::Get();
      (*(void (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)v12 + 8LL))(v12);
    }
    FMOD::SystemI::unlockDSPInternal(v8);
    return v10;
  }
  return result;
}


// Address: 0x2204fc0 | Name: _ZN4FMOD11Convolution5ResetEv
FMOD_RESULT_0 __fastcall FMOD::Convolution::Reset(FMOD::Convolution *const this)
{
  int mNumDelayLines; // eax
  int v2; // r12d
  int i; // ebx
  int v4; // eax

  if ( this->mDelayLines )
  {
    if ( this->mNumIRChannels > 0 )
    {
      mNumDelayLines = this->mNumDelayLines;
      v2 = 0;
      do
      {
        if ( mNumDelayLines > 0 )
        {
          for ( i = 0; i < mNumDelayLines; ++i )
          {
            v4 = i + v2 * mNumDelayLines;
            FMOD::FrequencyDelayLine::Reset(this->mDelayLines[v4]);
            mNumDelayLines = this->mNumDelayLines;
          }
        }
        ++v2;
      }
      while ( this->mNumIRChannels > v2 );
    }
    this->mIdleCountdown = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2205030 | Name: _Z28FMOD_ConvolutionReverb_resetP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD_ConvolutionReverb_reset(FMOD_DSP_STATE *dsp)
{
  FMOD::Convolution *plugindata; // rbx
  FMOD::GpuCompute *v3; // rax
  FMOD::GpuCompute *v4; // rax

  plugindata = (FMOD::Convolution *)dsp->plugindata;
  if ( plugindata->mUseGpu )
  {
    v3 = FMOD::GpuCompute::Get();
    (**(void (__fastcall ***)(FMOD::GpuCompute *))v3)(v3);
    FMOD::Convolution::Reset(plugindata);
    v4 = FMOD::GpuCompute::Get();
    (*(void (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)v4 + 8LL))(v4);
  }
  else
  {
    FMOD::Convolution::Reset((FMOD::Convolution *const)dsp->plugindata);
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2205080 | Name: _ZN4FMOD11Convolution7ProcessEPfS1_i
FMOD_RESULT_0 __fastcall FMOD::Convolution::Process(
        FMOD::Convolution *const this,
        float *input,
        float *output,
        int channels)
{
  FMOD::SystemI *mSystem; // rsi
  __int64 v6; // rbp
  int v7; // r15d
  float **v8; // rbp
  float *v9; // rax
  unsigned int mSystemBlockSize; // r8d
  int v11; // edx
  float mCurrentDryLevel; // xmm0_4
  float mTargetDryLevel; // xmm2_4
  float v14; // xmm2_4
  bool v15; // al
  int v16; // r11d
  float mTargetWetLevel; // xmm1_4
  int mNumIRChannels; // edx
  unsigned __int64 v19; // rcx
  bool mLinked; // r8
  __int64 v21; // rax
  int v22; // edi
  float *v23; // rsi
  int v24; // ecx
  __int64 v25; // rsi
  bool v26; // r9
  __int64 v27; // rax
  int v28; // r8d
  float *v29; // rdi
  int mNumDelayLines; // eax
  __int64 v31; // rbx
  int i; // ebp
  __int64 v33; // rsi
  FMOD_RESULT_0 v34; // eax
  FMOD_RESULT_0 v35; // r12d
  size_t v37; // r12
  float *v38; // rax
  float wetDeltaa; // [rsp+8h] [rbp-2A0h]
  int wet; // [rsp+10h] [rbp-298h]
  float weta; // [rsp+10h] [rbp-298h]
  int wetRampa; // [rsp+14h] [rbp-294h]
  FMOD::DSPBuffer inputTemp; // [rsp+30h] [rbp-278h] BYREF
  FMOD::DSPBuffer outputTemp; // [rsp+50h] [rbp-258h] BYREF
  float *deinterleavedInput[32]; // [rsp+70h] [rbp-238h] BYREF
  float *deinterleavedOutput[32]; // [rsp+170h] [rbp-138h] BYREF

  wet = 1;
  if ( !this->mLinked )
    wet = this->mNumIRChannels;
  mSystem = this->mSystem;
  memset(&inputTemp, 0, 24);
  inputTemp.mCacheIndex = -1;
  memset(&outputTemp, 0, 24);
  outputTemp.mCacheIndex = -1;
  FMOD::DSPBuffer::alloc(&inputTemp, mSystem, wet, FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0, 0);
  FMOD::DSPBuffer::alloc(
    &outputTemp,
    this->mSystem,
    this->mNumIRChannels,
    FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0,
    0);
  if ( wet > 0 )
  {
    v6 = 0;
    do
    {
      deinterleavedInput[v6] = &FMOD::DSPBuffer::get(&inputTemp)[(int)v6 * this->mSystemBlockSize];
      ++v6;
    }
    while ( v6 != (unsigned int)(wet - 1) + 1LL );
  }
  v7 = 0;
  v8 = deinterleavedOutput;
  if ( this->mNumIRChannels <= 0 )
  {
    mSystemBlockSize = this->mSystemBlockSize;
  }
  else
  {
    do
    {
      ++v8;
      v9 = FMOD::DSPBuffer::get(&outputTemp);
      mSystemBlockSize = this->mSystemBlockSize;
      v11 = v7 * mSystemBlockSize;
      ++v7;
      *(v8 - 1) = &v9[v11];
    }
    while ( this->mNumIRChannels > v7 );
  }
  FMOD::DSPI::deinterleave(input, deinterleavedInput, channels, wet, mSystemBlockSize);
  mCurrentDryLevel = this->mCurrentDryLevel;
  mTargetDryLevel = this->mTargetDryLevel;
  weta = this->mCurrentWetLevel;
  if ( mCurrentDryLevel == mTargetDryLevel )
  {
    v14 = 0.0;
    v15 = mCurrentDryLevel > 0.0;
    v16 = 0;
  }
  else
  {
    v15 = 1;
    v16 = 128;
    v14 = (float)(mTargetDryLevel - mCurrentDryLevel) * 0.0078125;
  }
  mTargetWetLevel = this->mTargetWetLevel;
  if ( weta != mTargetWetLevel )
  {
    wetRampa = 128;
    wetDeltaa = (float)(mTargetWetLevel - weta) * 0.0078125;
    if ( v15 )
      goto LABEL_12;
LABEL_39:
    v37 = 4 * this->mSystemBlockSize * (__int64)this->mNumIRChannels;
    v38 = FMOD::DSPBuffer::get(&outputTemp);
    memset(v38, 0, v37);
    mNumIRChannels = this->mNumIRChannels;
    v24 = this->mSystemBlockSize;
    goto LABEL_28;
  }
  wetRampa = 0;
  wetDeltaa = 0.0;
  if ( !v15 )
    goto LABEL_39;
LABEL_12:
  mNumIRChannels = this->mNumIRChannels;
  if ( v16 )
  {
    v19 = 0;
    do
    {
      if ( mNumIRChannels > 0 )
      {
        mLinked = this->mLinked;
        v21 = 0;
        do
        {
          v22 = 0;
          v23 = &deinterleavedOutput[v21][v19 / 4];
          if ( !mLinked )
            v22 = v21;
          ++v21;
          *v23 = deinterleavedInput[v22][v19 / 4] * mCurrentDryLevel;
        }
        while ( v21 != (unsigned int)(mNumIRChannels - 1) + 1LL );
      }
      v19 += 4LL;
      mCurrentDryLevel = mCurrentDryLevel + v14;
    }
    while ( v19 != 4LL * (unsigned int)(v16 - 1) + 4 );
  }
  v24 = this->mSystemBlockSize;
  if ( v16 < v24 )
  {
    v25 = v16;
    do
    {
      if ( mNumIRChannels > 0 )
      {
        v26 = this->mLinked;
        v27 = 0;
        do
        {
          v28 = 0;
          v29 = &deinterleavedOutput[v27][v25];
          if ( !v26 )
            v28 = v27;
          ++v27;
          *v29 = deinterleavedInput[v28][v25] * mCurrentDryLevel;
        }
        while ( v27 != (unsigned int)(mNumIRChannels - 1) + 1LL );
      }
      ++v25;
    }
    while ( v25 != v16 + (unsigned __int64)(unsigned int)(v24 - 1 - v16) + 1 );
  }
LABEL_28:
  if ( mNumIRChannels > 0 )
  {
    mNumDelayLines = this->mNumDelayLines;
    v31 = 0;
    do
    {
      if ( mNumDelayLines > 0 )
      {
        for ( i = 0; i < mNumDelayLines; ++i )
        {
          v33 = 0;
          if ( !this->mLinked )
            v33 = (int)v31;
          v34 = FMOD::FrequencyDelayLine::Process(
                  *((FMOD::FrequencyDelayLine *const *)&this->mDelayLines[i] + (int)v31 * mNumDelayLines),
                  deinterleavedInput[v33],
                  deinterleavedOutput[v31],
                  v24,
                  COERCE_DOUBLE((unsigned __int64)LODWORD(weta)),
                  wetDeltaa,
                  wetRampa);
          if ( v34 )
          {
            v35 = v34;
            goto LABEL_37;
          }
          mNumDelayLines = this->mNumDelayLines;
          v24 = this->mSystemBlockSize;
        }
        mNumIRChannels = this->mNumIRChannels;
      }
      ++v31;
    }
    while ( (int)v31 < mNumIRChannels );
  }
  this->mCurrentWetLevel = this->mTargetWetLevel;
  v35 = FMOD_RESULT::FMOD_OK_0;
  this->mCurrentDryLevel = this->mTargetDryLevel;
  FMOD::DSPI::interleave(deinterleavedOutput, output, mNumIRChannels, v24);
LABEL_37:
  FMOD::DSPBuffer::~DSPBuffer(&outputTemp);
  FMOD::DSPBuffer::~DSPBuffer(&inputTemp);
  return v35;
}


// Address: 0x22054d0 | Name: _Z30FMOD_ConvolutionReverb_processP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD_ConvolutionReverb_process(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  FMOD::Convolution *plugindata; // rbx
  FMOD_RESULT_0 result; // eax
  __int64 v8; // rdi
  FMOD_SPEAKERMODE_0 v9; // eax
  int v10; // eax
  signed int mIdleCountdown; // eax
  int v12; // eax
  FMOD::GpuCompute *v13; // rax
  FMOD_RESULT_0 v14; // ebx
  FMOD::GpuCompute *v15; // rax
  float mCurrentWetLevel; // xmm1_4
  float mCurrentDryLevel; // xmm1_4

  plugindata = (FMOD::Convolution *)dsp_state->plugindata;
  if ( op != FMOD_DSP_PROCESS_QUERY )
  {
    if ( !plugindata->mUseGpu )
      return FMOD::Convolution::Process(
               (FMOD::Convolution *const)dsp_state->plugindata,
               *inbufferarray->buffers,
               *outbufferarray->buffers,
               *inbufferarray->buffernumchannels);
    v13 = FMOD::GpuCompute::Get();
    (**(void (__fastcall ***)(FMOD::GpuCompute *))v13)(v13);
    v14 = FMOD::Convolution::Process(
            plugindata,
            *inbufferarray->buffers,
            *outbufferarray->buffers,
            *inbufferarray->buffernumchannels);
    v15 = FMOD::GpuCompute::Get();
    (*(void (__fastcall **)(FMOD::GpuCompute *))(*(_QWORD *)v15 + 8LL))(v15);
    return v14;
  }
  if ( outbufferarray )
  {
    *outbufferarray->buffernumchannels = plugindata->mNumIRChannels;
    v8 = (unsigned int)(plugindata->mNumIRChannels - 1);
    v9 = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
    if ( (unsigned int)v8 <= 0xB )
      v9 = dword_596460[v8];
    outbufferarray->speakermode = v9;
  }
  if ( inbufferarray )
    v10 = *inbufferarray->buffernumchannels;
  else
    v10 = 0;
  if ( inputsidle )
  {
    mIdleCountdown = plugindata->mIdleCountdown;
    if ( (int)length >= mIdleCountdown )
    {
      plugindata->mIdleCountdown = 0;
    }
    else
    {
      v12 = mIdleCountdown - length;
      plugindata->mIdleCountdown = v12;
      if ( v12 )
      {
        if ( plugindata->mCurrentWetLevel > 0.0 )
          return FMOD_RESULT::FMOD_OK_0;
        if ( plugindata->mTargetWetLevel > 0.0 )
          return FMOD_RESULT::FMOD_OK_0;
      }
    }
    return FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
  }
  mCurrentWetLevel = plugindata->mCurrentWetLevel;
  plugindata->mIdleCountdown = plugindata->mImpulseSamples;
  if ( mCurrentWetLevel > 0.0 || plugindata->mTargetWetLevel > 0.0 || v10 != plugindata->mNumIRChannels )
    return FMOD_RESULT::FMOD_OK_0;
  mCurrentDryLevel = plugindata->mCurrentDryLevel;
  if ( mCurrentDryLevel <= 0.0 && plugindata->mTargetDryLevel <= 0.0 )
    return FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
  if ( mCurrentDryLevel != 1.0 )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD_RESULT::FMOD_ERR_DSP_DONTPROCESS_0;
  if ( plugindata->mTargetDryLevel != 1.0 )
    return FMOD_RESULT::FMOD_OK_0;
  return result;
}


// Address: 0x22056b0 | Name: _ZN4FMOD17ConvolutionReverb16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::ConvolutionReverb::getDescriptionEx()
{
  FMODGetDSPDescription();
  *(&dspConvolutionReverb_ex.mHandle + 1) = 32;
  dspConvolutionReverb_ex.mDescription = &FMOD_ConvolutionReverb_Desc;
  dspConvolutionReverb_ex.mSize = 88;
  return &dspConvolutionReverb_ex;
}


