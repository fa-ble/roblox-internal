// Address: 0x2232a60 | Name: _ZN4FMOD7SystemI14updateChannelsEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::updateChannels(FMOD::SystemI *const this, int delta)
{
  FMOD::LinkedListNode *mNodeNext; // rcx
  FMOD::ChannelI *p_mNodePrev; // r15
  FMOD::ChannelI *p_mChannelUsedListHead; // r12
  FMOD::LinkedListNode *v5; // rax
  FMOD::ChannelI *v6; // rbx
  FMOD::OutputEmulated *mEmulated; // rax
  FMOD::ChannelPool *mChannelPool; // rdi
  FMOD::SortedLinkedListNode *p_mChannelSortedListHead; // r12
  FMOD::LinkedListNode *v10; // r15
  FMOD::SortedLinkedListNode *mNodePrev; // r13
  int v12; // r14d
  FMOD::ChannelI *mNodeData; // rbx
  FMOD::SoundI *mSound; // rdx
  FMOD::ChannelReal *v15; // rax
  FMOD::SoundI *v16; // rdx
  FMOD_MODE mMode; // ecx
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // edx
  FMOD::ChannelReal *v19; // rax
  FMOD::ChannelReal *v20; // rdx
  FMOD::ChannelGroupI *mChannelGroupParent; // rdx
  char v22; // si
  FMOD::ChannelReal *v23; // rax
  FMOD::ChannelI *v24; // r14
  __int64 v25; // rax
  FMOD::CHANNELREAL_FLAG v26; // eax
  FMOD::LinkedListNode *v27; // rax
  FMOD::DSPCodecPool **pool; // [rsp+0h] [rbp-B8h]
  bool isvirtual; // [rsp+3Bh] [rbp-7Dh] BYREF
  int emulatedused; // [rsp+3Ch] [rbp-7Ch] BYREF
  FMOD::ChannelReal *emu_channelreal; // [rsp+40h] [rbp-78h] BYREF
  FMOD::ChannelReal *real_channelreal; // [rsp+48h] [rbp-70h] BYREF
  FMOD::SoundI *sound; // [rsp+50h] [rbp-68h] BYREF
  FMOD::DSPI *dsp; // [rsp+58h] [rbp-60h] BYREF
  FMOD::FMOD_CHANNEL_INFO realinfo; // [rsp+60h] [rbp-58h] BYREF

  mNodeNext = this->mChannelUsedListHead.mNodeNext;
  if ( !mNodeNext )
  {
    p_mNodePrev = 0;
    p_mChannelUsedListHead = &this->mChannelUsedListHead;
    goto LABEL_7;
  }
  p_mNodePrev = (FMOD::ChannelI *)&mNodeNext[-16].mNodePrev;
  p_mChannelUsedListHead = &this->mChannelUsedListHead;
  if ( &mNodeNext[-16].mNodePrev != (FMOD::LinkedListNode **)&this->mChannelUsedListHead )
  {
    while ( 1 )
    {
LABEL_7:
      v5 = p_mNodePrev->mNodeNext;
      LOBYTE(realinfo.mMode) = 0;
      v6 = (FMOD::ChannelI *)&v5[-16].mNodePrev;
      if ( !v5 )
        v6 = 0;
      (*((void (__fastcall **)(FMOD::ChannelI *, FMOD::FMOD_CHANNEL_INFO *))p_mNodePrev->_vptr_ChannelControlI + 21))(
        p_mNodePrev,
        &realinfo);
      if ( LOBYTE(realinfo.mMode) )
        FMOD::ChannelI::update(p_mNodePrev, delta, 0);
      (*((void (__fastcall **)(FMOD::ChannelI *, FMOD::FMOD_CHANNEL_INFO *))p_mNodePrev->_vptr_ChannelControlI + 21))(
        p_mNodePrev,
        &realinfo);
      if ( LOBYTE(realinfo.mMode) )
      {
        if ( v6 == p_mChannelUsedListHead )
          break;
      }
      else
      {
        FMOD::ChannelI::stopEx(p_mNodePrev, 0x5Bu);
        if ( v6 == p_mChannelUsedListHead )
          break;
      }
      p_mNodePrev = v6;
    }
  }
  mEmulated = this->mEmulated;
  if ( !mEmulated )
    return (int)mEmulated;
  mChannelPool = mEmulated->mChannelPool;
  emulatedused = 0;
  FMOD::ChannelPool::getChannelsUsed(mChannelPool, &emulatedused);
  if ( !emulatedused )
    goto LABEL_44;
  p_mChannelSortedListHead = &this->mChannelSortedListHead;
  v10 = this->mChannelSortedListHead.mNodeNext;
  mNodePrev = &this->mChannelSortedListHead;
LABEL_15:
  while ( 2 )
  {
    emu_channelreal = 0;
    real_channelreal = 0;
    v12 = 0;
    isvirtual = 0;
    while ( 1 )
    {
      mNodeData = (FMOD::ChannelI *)v10->mNodeData;
      if ( !mNodeData )
        break;
      v12 = (*((__int64 (__fastcall **)(void *, bool *))mNodeData->_vptr_ChannelControlI + 62))(
              v10->mNodeData,
              &isvirtual);
      if ( !isvirtual || (mNodeData->mFlags & 0x20000) != 0 )
      {
        if ( v10->mNodeNext && v10->mNodeNext != (FMOD::LinkedListNode *)&inputbuff.encodingTable[21] )
        {
          v10 = v10->mNodeNext;
          goto LABEL_43;
        }
        v10 = 0;
      }
      else
      {
        mSound = mNodeData->mRealChannel->mSound;
        if ( !mSound )
          break;
        pool = (FMOD::DSPCodecPool **)mNodeData->mRealChannel->mSound;
        if ( !(*mSound->_vptr_SoundI)(mSound) )
          break;
        v22 = 0;
        if ( ((_DWORD)pool[11] & 0x800) != 0 )
          v22 = ((*((_DWORD *)pool + 22) >> 6) ^ 1) & 1;
        if ( *((_DWORD *)pool + 68) != 7 && *((_DWORD *)pool + 68) != 5 && !v22 )
          break;
        v10 = v10->mNodeNext;
LABEL_43:
        if ( v10 == p_mChannelSortedListHead )
          goto LABEL_44;
      }
    }
    if ( v10 == p_mChannelSortedListHead || v10 == mNodePrev || v12 )
    {
LABEL_44:
      LODWORD(mEmulated) = 0;
      return (int)mEmulated;
    }
    LODWORD(mEmulated) = FMOD::ChannelI::getRealChannel(mNodeData, &emu_channelreal);
    if ( !(_DWORD)mEmulated )
    {
      v15 = emu_channelreal;
      v16 = emu_channelreal->mSound;
      if ( !v16 && !emu_channelreal->mDSP )
        goto LABEL_58;
      mMode = emu_channelreal->mMode;
      if ( (mMode & 0x200) != 0 )
      {
        if ( FMOD::SystemI::DSPCodecPoolGet(this, v16->mCodec->mDescription.mPoolType, (FMOD::DSPCodecPool **)&realinfo)
          || FMOD::DSPCodecPool::areAnyFree(*(FMOD::DSPCodecPool *const *)&realinfo.mMode) )
        {
          goto LABEL_33;
        }
        v15 = emu_channelreal;
        goto LABEL_30;
      }
      if ( (mMode & 0x10080) != 0 )
      {
        if ( v16 )
        {
          if ( v16->mOpenState.m_value == FMOD_OPENSTATE::FMOD_OPENSTATE_SETPOSITION_0 )
            goto LABEL_33;
LABEL_30:
          v16 = v15->mSound;
          goto LABEL_31;
        }
      }
      else
      {
LABEL_31:
        if ( v16 )
        {
LABEL_32:
          FMOD::Output::getFreeChannel(this->mSoftware, &real_channelreal, 1);
LABEL_33:
          if ( real_channelreal )
          {
LABEL_34:
            FMOD::ChannelI::getChannelInfo(mNodeData, &realinfo);
            FMOD::ChannelI::getCurrentSound(mNodeData, &sound);
            FMOD::ChannelI::getCurrentDSP(mNodeData, &dsp);
            FMOD::ChannelI::stopEx(mNodeData, 4u);
            mFlags = mNodeData->mFlags;
            mNodeData->mFlags = mFlags | 0x200000;
            if ( sound && SLOBYTE(sound->mMode) < 0 )
            {
              v19 = (FMOD::ChannelReal *)sound[1].mNodeData;
              v20 = real_channelreal;
              mNodeData->mRealChannel = v19;
              *(_QWORD *)&v19[1].mDirection = v20;
            }
            else
            {
              v23 = real_channelreal;
              mNodeData->mFlags = mFlags & 0xFFDEFFFF | 0x200000;
              mNodeData->mRealChannel = v23;
            }
            mChannelGroupParent = mNodeData->mChannelGroupParent;
            if ( dsp )
              FMOD::ChannelI::play(mNodeData, dsp, mChannelGroupParent, 1, 0, 0);
            else
              FMOD::ChannelI::play(mNodeData, sound, mChannelGroupParent, 1, 0, 0);
            FMOD::ChannelI::setChannelInfo(mNodeData, &realinfo);
            (*((void (__fastcall **)(FMOD::ChannelI *, bool))mNodeData->_vptr_ChannelControlI + 2))(
              mNodeData,
              realinfo.mPaused);
            mNodeData->mFlags &= ~0x200000u;
          }
          else
          {
            if ( mNodePrev != p_mChannelSortedListHead
              || (mNodePrev = (FMOD::SortedLinkedListNode *)this->mChannelSortedListHead.mNodePrev, v10 != mNodePrev)
              && p_mChannelSortedListHead != mNodePrev )
            {
              do
              {
                v24 = (FMOD::ChannelI *)mNodePrev->mNodeData;
                (*((void (__fastcall **)(FMOD::ChannelI *, bool *))v24->_vptr_ChannelControlI + 62))(v24, &isvirtual);
                if ( isvirtual )
                {
                  v24->mFlags &= ~0x10000u;
                }
                else if ( (emu_channelreal->mMode & 0x200) == 0
                       || FMOD::SystemI::DSPCodecPoolGet(
                            this,
                            emu_channelreal->mSound->mCodec->mDescription.mPoolType,
                            (FMOD::DSPCodecPool **)&dsp) == FMOD_RESULT::FMOD_OK_0
                       && FMOD::DSPCodecPool::areAnyFree((FMOD::DSPCodecPool *const)dsp) == FMOD_RESULT::FMOD_OK_0
                       || ((*((void (__fastcall **)(FMOD::ChannelI *, FMOD::SoundI **))v24->_vptr_ChannelControlI + 19))(
                             v24,
                             &sound),
                           (BYTE1(sound) & 2) != 0)
                       && (*(_QWORD *)&realinfo.mMode = 0,
                           FMOD::ChannelI::getRealChannel(v24, (FMOD::ChannelReal **)&realinfo),
                           (v25 = *(_QWORD *)(*(_QWORD *)&realinfo.mMode + 40LL)) != 0)
                       && *(_DWORD *)(v25 + 40) == emu_channelreal->mSound->mFormat )
                {
                  FMOD::ChannelI::getRealChannel(v24, &real_channelreal);
                  if ( !real_channelreal )
                    goto LABEL_82;
                  FMOD::ChannelI::getChannelInfo(v24, &realinfo);
                  FMOD::ChannelI::getCurrentSound(v24, &sound);
                  FMOD::ChannelI::getCurrentDSP(v24, &dsp);
                  FMOD::ChannelI::stopEx(v24, 4u);
                  v26 = real_channelreal->mFlags & 0xFFFFFE8F;
                  LOBYTE(v26) = real_channelreal->mFlags & 0xF | 0x80;
                  real_channelreal->mFlags = v26;
                  FMOD::Output::getFreeChannel(this->mEmulated, &emu_channelreal, 0);
                  v24->mRealChannel = emu_channelreal;
                  if ( sound )
                  {
                    FMOD::ChannelI::play(v24, sound, v24->mChannelGroupParent, 1, 0, 0);
                    goto LABEL_76;
                  }
                  if ( dsp )
                  {
                    FMOD::ChannelI::play(v24, dsp, v24->mChannelGroupParent, 1, 0, 0);
LABEL_76:
                    FMOD::ChannelI::setChannelInfo(v24, &realinfo);
                    (*((void (__fastcall **)(FMOD::ChannelI *, bool))v24->_vptr_ChannelControlI + 2))(
                      v24,
                      realinfo.mPaused);
                  }
                  v27 = v10->mNodeNext;
                  v10 = 0;
                  if ( v27 && v27 != (FMOD::LinkedListNode *)&inputbuff.encodingTable[21] )
                    v10 = v27;
                  goto LABEL_15;
                }
                mNodePrev = (FMOD::SortedLinkedListNode *)mNodePrev->mNodePrev;
              }
              while ( v10 != mNodePrev && p_mChannelSortedListHead != mNodePrev );
              if ( real_channelreal )
                goto LABEL_34;
            }
LABEL_82:
            mNodeData->mFlags &= ~0x10000u;
          }
          continue;
        }
      }
      if ( v15->mDSP )
        goto LABEL_32;
LABEL_58:
      LODWORD(mEmulated) = 28;
    }
    return (int)mEmulated;
  }
}


// Address: 0x22330d0 | Name: _ZN4FMOD7SystemI19updateChannelGroupsEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::updateChannelGroups(FMOD::SystemI *const this, int delta)
{
  FMOD::LinkedListNode *i; // rax
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD_RESULT_0 result; // eax

  for ( i = this->mChannelGroupUpdateListHead.mNodeNext; i != &this->mChannelGroupUpdateListHead; i = mNodeNext )
  {
    mNodeNext = i->mNodeNext;
    result = FMOD::ChannelGroupI::update((FMOD::ChannelGroupI *const)i->mNodeData, delta, 0);
    if ( result )
      return result;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2233120 | Name: _ZN4FMOD7SystemI17updateSoundGroupsEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::updateSoundGroups(FMOD::SystemI *const this, int delta)
{
  FMOD::SoundGroupI *mNodeNext; // r15
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::LinkedListNode *v6; // rax
  bool v7; // zf
  FMOD::SoundGroupI *v8; // rbp
  FMOD::LinkedListNode *v9; // r14
  FMOD::SortedLinkedListNode *p_mChannelListHead; // rbx
  float *mNodeData; // rdi
  float v12; // xmm0_4
  float v13; // xmm1_4
  float mFadeSpeed; // xmm2_4
  int mMaxAudible; // eax
  int v16; // esi
  FMOD::LinkedListNode *p_mSoundGroupUsedHead; // [rsp+8h] [rbp-50h]
  int numaudible[15]; // [rsp+1Ch] [rbp-3Ch] BYREF

  FMOD_OS_CriticalSection_Enter(off_286F358->gSoundListCrit);
  mNodeNext = (FMOD::SoundGroupI *)this->mSoundGroupUsedHead.mNodeNext;
  p_mSoundGroupUsedHead = &this->mSoundGroupUsedHead;
  if ( mNodeNext != &this->mSoundGroupUsedHead )
  {
    while ( 1 )
    {
      v7 = mNodeNext->mMaxAudibleBehavior == FMOD_SOUNDGROUP_BEHAVIOR::FMOD_SOUNDGROUP_BEHAVIOR_MUTE;
      numaudible[0] = 0;
      v8 = (FMOD::SoundGroupI *)mNodeNext->mNodeNext;
      mNodeNext->mPlayCount = 0;
      if ( v7 && (FMOD::SoundGroupI::getNumPlaying(mNodeNext, numaudible), numaudible[0]) )
      {
        v9 = mNodeNext->mChannelListHead.mNodeNext;
        p_mChannelListHead = &mNodeNext->mChannelListHead;
        while ( 2 )
        {
          if ( v9 != p_mChannelListHead )
          {
            mNodeData = (float *)v9->mNodeData;
            v9 = v9->mNodeNext;
            if ( mNodeNext->mMaxAudibleBehavior != FMOD_SOUNDGROUP_BEHAVIOR::FMOD_SOUNDGROUP_BEHAVIOR_MUTE )
            {
LABEL_11:
              v12 = mNodeData[135];
              goto LABEL_12;
            }
LABEL_18:
            mMaxAudible = mNodeNext->mMaxAudible;
            if ( mMaxAudible < 0 )
              goto LABEL_11;
            v16 = mNodeNext->mPlayCount + 1;
            mNodeNext->mPlayCount = v16;
            if ( mMaxAudible >= v16 )
            {
              mNodeData[135] = 1.0;
              v12 = 1.0;
            }
            else
            {
              mNodeData[135] = 0.0;
              v12 = 0.0;
            }
LABEL_12:
            v13 = mNodeData[134];
            if ( v13 == v12 )
              continue;
            mFadeSpeed = mNodeNext->mFadeSpeed;
            if ( mFadeSpeed < 0.001 )
            {
LABEL_23:
              mNodeData[134] = v12;
            }
            else
            {
              if ( v12 > v13 )
              {
                mNodeData[134] = fminf(v12, (float)((float)delta / (float)(mFadeSpeed * 1000.0)) + v13);
                goto LABEL_16;
              }
              if ( v13 > v12 )
              {
                v12 = fmaxf(v12, v13 - (float)((float)delta / (float)(mFadeSpeed * 1000.0)));
                goto LABEL_23;
              }
            }
LABEL_16:
            (*(void (__fastcall **)(float *, __int64, float))(*(_QWORD *)mNodeData + 32LL))(mNodeData, 1, mNodeData[12]);
            if ( v9 == p_mChannelListHead )
              break;
            mNodeData = (float *)v9->mNodeData;
            v9 = v9->mNodeNext;
            if ( mNodeNext->mMaxAudibleBehavior != FMOD_SOUNDGROUP_BEHAVIOR::FMOD_SOUNDGROUP_BEHAVIOR_MUTE )
              goto LABEL_11;
            goto LABEL_18;
          }
          break;
        }
      }
      else
      {
        mNodePrev = mNodeNext->mNodePrev;
        mNodePrev->mNodeNext = mNodeNext->mNodeNext;
        mNodeNext->mNodeNext->mNodePrev = mNodePrev;
        mNodeNext->mNodeNext = mNodeNext;
        v6 = this->mSoundGroupFreeHead.mNodeNext;
        mNodeNext->mNodePrev = &this->mSoundGroupFreeHead;
        mNodeNext->mNodeNext = v6;
        v6->mNodePrev = mNodeNext;
        mNodeNext->mNodePrev->FMOD::LinkedListNode::mNodeNext = mNodeNext;
      }
      if ( v8 == p_mSoundGroupUsedHead )
        break;
      mNodeNext = v8;
    }
  }
  FMOD_OS_CriticalSection_Leave(off_286F358->gSoundListCrit);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2233320 | Name: _ZN4FMOD7SystemI13updateStreamsEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::updateStreams(FMOD::SystemI *const this)
{
  FMOD::TimeStamp *p_mStreamTimeStamp; // rbp
  FMOD::LinkedListNode *mStreamListChannelNext; // rax
  _BYTE *mNodeData; // r12
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *i; // rsi
  int *v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // rcx
  __int64 v10; // rdi
  __int64 v12; // rdx

  p_mStreamTimeStamp = &this->mStreamTimeStamp;
  FMOD::TimeStamp::stampIn(&this->mStreamTimeStamp);
  FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_STREAMLIST);
  mStreamListChannelNext = *(FMOD::LinkedListNode **)((char *)&stru_120C0.r_offset + (_QWORD)this);
  for ( *(unsigned __int64 *)((char *)&stru_120D8.r_offset + (_QWORD)this) = (unsigned __int64)mStreamListChannelNext;
        mStreamListChannelNext != (FMOD::LinkedListNode *)((char *)&stru_120C0 + (_QWORD)this);
        *(unsigned __int64 *)((char *)&stru_120D8.r_offset + (_QWORD)this) = (unsigned __int64)mStreamListChannelNext )
  {
    mNodeData = mStreamListChannelNext->mNodeData;
    this->mStreamListChannelNext = mStreamListChannelNext->mNodeNext;
    FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_STREAMLIST);
    FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_STREAMUPDATE);
    if ( !mNodeData[136] )
      (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)mNodeData + 72LL))(mNodeData);
    FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_STREAMUPDATE);
    FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_STREAMLIST);
    mStreamListChannelNext = this->mStreamListChannelNext;
  }
  this->mStreamListChannelNext = 0;
  FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_STREAMLIST);
  FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_STREAMLIST);
  mNodeNext = this->mStreamListSoundHead.mNodeNext;
  for ( i = &this->mStreamListSoundHead; i != mNodeNext; mNodeNext = mNodeNext->mNodeNext )
  {
    v7 = (int *)mNodeNext->mNodeData;
    v8 = *((_QWORD *)v7 + 47);
    if ( v8 )
    {
      if ( *(_BYTE *)(v8 + 136) )
      {
        _InterlockedOr(v7 + 22, 0x40u);
        v9 = *((_QWORD *)v7 + 20);
        if ( v9 )
        {
          v10 = *((_QWORD *)v7 + 21);
          if ( v10 )
          {
            _InterlockedOr((volatile signed __int32 *)(v10 + 88), 0x40u);
          }
          else
          {
            v12 = *(_QWORD *)(v9 + 8LL * v7[48]);
            if ( v12 )
              _InterlockedOr((volatile signed __int32 *)(v12 + 88), 0x40u);
          }
        }
      }
    }
  }
  FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_STREAMLIST);
  FMOD::TimeStamp::stampOut(p_mStreamTimeStamp, 95);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22334b0 | Name: j__ZN4FMOD7SystemI13updateStreamsEv
// attributes: thunk
void __fastcall FMOD::SystemI::updateStreams(void *data)
{
  _ZN4FMOD7SystemI13updateStreamsEv((FMOD::SystemI *const)data);
}


// Address: 0x2233540 | Name: _ZN4FMOD7SystemI17updateDSPMeteringEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::updateDSPMetering(FMOD::SystemI *const this)
{
  char v1; // r15
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD::LinkedListNode *p_mDSPMeteringNodes; // r12
  unsigned int mDSPTick; // r13d
  FMOD::FMOD_DSP_METERING_CONTEXT *mNodeData; // rbp

  if ( this )
  {
    v1 = 1;
    FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_DSPMETERING);
  }
  else
  {
    v1 = 0;
  }
  mNodeNext = this->mDSPMeteringNodes.mNodeNext;
  p_mDSPMeteringNodes = &this->mDSPMeteringNodes;
  mDSPTick = this->mOutput->mDSPTick;
  if ( mNodeNext != &this->mDSPMeteringNodes )
  {
    while ( 1 )
    {
      mNodeData = (FMOD::FMOD_DSP_METERING_CONTEXT *)mNodeNext->mNodeData;
      if ( mNodeData->mActive )
      {
        FMOD::DSPI::cacheAndResetMeteringInfo((FMOD::FMOD_DSP_METERING_CONTEXT *)mNodeNext->mNodeData, mDSPTick);
        if ( mNodeData[1].mActive )
          goto LABEL_9;
LABEL_6:
        mNodeNext = mNodeNext->mNodeNext;
        if ( mNodeNext == p_mDSPMeteringNodes )
          break;
      }
      else
      {
        if ( !mNodeData[1].mActive )
          goto LABEL_6;
LABEL_9:
        FMOD::DSPI::cacheAndResetMeteringInfo(mNodeData + 1, mDSPTick);
        mNodeNext = mNodeNext->mNodeNext;
        if ( mNodeNext == p_mDSPMeteringNodes )
          break;
      }
    }
  }
  if ( v1 )
    FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPMETERING);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2233610 | Name: _ZN4FMOD7SystemI15update3DReverbsEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::update3DReverbs(FMOD::SystemI *const this)
{
  float v1; // xmm1_4
  FMOD::LinkedListNode *v2; // rbp
  Elf64_Rela *v3; // r15
  FMOD::ReverbI *r_addend; // rbx
  float v5; // xmm0_4
  float v6; // xmm0_4
  FMOD_RESULT_0 result; // eax
  int reverb3Dinstance; // esi
  float transmissionfrom3dreverb; // [rsp+24h] [rbp-B4h]
  bool active; // [rsp+33h] [rbp-A5h] BYREF
  float distance_gain; // [rsp+34h] [rbp-A4h] BYREF
  float distance_coeff; // [rsp+38h] [rbp-A0h] BYREF
  float reverb_occlusion; // [rsp+3Ch] [rbp-9Ch] BYREF
  FMOD_REVERB_PROPERTIES stdprops; // [rsp+40h] [rbp-98h] BYREF
  FMOD_REVERB_PROPERTIES ambience; // [rsp+70h] [rbp-68h] BYREF

  v2 = (FMOD::LinkedListNode *)((char *)&stru_125B8 + (_QWORD)this);
  v3 = *(Elf64_Rela **)((char *)&stru_125B8.r_offset + (_QWORD)this);
  memset(&stdprops, 0, sizeof(stdprops));
  if ( v3 == (Elf64_Rela *)((char *)&stru_125B8 + (_QWORD)this) )
  {
    transmissionfrom3dreverb = 0.0;
  }
  else
  {
    transmissionfrom3dreverb = 0.0;
    do
    {
      while ( 1 )
      {
        r_addend = (FMOD::ReverbI *)v3->r_addend;
        FMOD::ReverbI::getActive(r_addend, &active);
        if ( active )
        {
          FMOD::ReverbI::calculateDistanceGain(r_addend, &this->mListener[0].mPosition, &distance_gain, &distance_coeff);
          if ( distance_gain > 0.0 )
          {
            FMOD::ReverbI::get3DAttributes(r_addend, (FMOD_VECTOR *)&ambience, 0, 0);
            result = FMOD::GeometryMgr::lineTestAll(
                       &this->mGeometryMgr,
                       &this->mListener[0].mPosition,
                       (const FMOD_VECTOR *)&ambience,
                       0,
                       &reverb_occlusion);
            if ( result )
              return result;
            v1 = distance_gain * (float)(1.0 - reverb_occlusion);
            v5 = (float)(1.0 - reverb_occlusion) * distance_coeff;
            distance_gain = v1;
            distance_coeff = v5;
          }
          else
          {
            v5 = distance_coeff;
          }
          if ( v5 >= 0.001 )
            break;
        }
        v3 = (Elf64_Rela *)v3->r_offset;
        if ( v3 == (Elf64_Rela *)v2 )
          goto LABEL_9;
      }
      memset(&ambience, 0, sizeof(ambience));
      FMOD::ReverbI::getProperties(r_addend, &ambience);
      FMOD::ReverbI::sumProps(&stdprops, &ambience, distance_coeff, v1);
      v3 = (Elf64_Rela *)v3->r_offset;
      transmissionfrom3dreverb = transmissionfrom3dreverb + distance_coeff;
    }
    while ( v3 != (Elf64_Rela *)v2 );
LABEL_9:
    if ( *(FMOD::LinkedListNode **)((char *)&stru_125B8.r_offset + (_QWORD)this) != v2 )
      goto LABEL_10;
  }
  if ( this->mReverb3DHead.mNodePrev == v2 )
    return FMOD_RESULT::FMOD_OK_0;
LABEL_10:
  if ( transmissionfrom3dreverb < 1.0 )
  {
    reverb3Dinstance = this->mAdvancedSettings.reverb3Dinstance;
    memset(&ambience, 0, sizeof(ambience));
    FMOD::SystemI::getReverbProperties(this, reverb3Dinstance, &ambience);
    FMOD::ReverbI::sumProps(&stdprops, &ambience, 1.0 - transmissionfrom3dreverb, 1.0);
    v6 = 1.0;
  }
  else
  {
    v6 = 1.0 / transmissionfrom3dreverb;
  }
  FMOD::ReverbI::factorProps(&ambience, &stdprops, v6, 1.0);
  FMOD::SystemI::setReverbPropertiesInternal(this, this->mAdvancedSettings.reverb3Dinstance, &ambience, 1);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2233870 | Name: _ZN4FMOD7SystemI14updateInternalEb
FMOD_RESULT_0 __fastcall FMOD::SystemI::updateInternal(FMOD::SystemI *const this, bool checkdriverlist)
{
  FMOD_RESULT_0 updated; // ebp
  void (__fastcall *v5)(FMOD::SystemI *const, __int64, _QWORD, _QWORD, _QWORD); // rax
  unsigned int v6; // eax
  unsigned int mLastUpdateMs; // edx
  FMOD::OutputEmulated *mEmulated; // rdi
  int v9; // r14d
  __int64 v10; // rbp
  int v11; // r14d
  FMOD::FMOD_RECORDING_INFO *info; // rax
  FMOD_RESULT_0 v13; // eax
  int mNumListeners; // edx
  FMOD::SystemI *v15; // rax
  unsigned int *v16; // rdx
  bool v17; // zf
  FMOD::LinkedListNode *mNodeNext; // rbp
  FMOD::LinkedListNode *p_mDSPSystemUpdateHead; // r12
  _QWORD *mNodeData; // rax
  void (__fastcall *v21)(_QWORD *, __int64, _QWORD, _QWORD); // r8
  FMOD::Profile *v22; // rdi
  void (__fastcall *v23)(FMOD::SystemI *const, __int64, _QWORD, _QWORD, _QWORD); // rax
  FMOD_RESULT_0 v24; // eax
  unsigned int currenttimestamp[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  updated = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  if ( this->mInitialized )
  {
    v5 = *(void (__fastcall **)(FMOD::SystemI *const, __int64, _QWORD, _QWORD, _QWORD))((char *)&stru_11748.r_offset
                                                                                      + (_QWORD)this);
    if ( v5 && (this->mCallbackMask & 0x400) != 0 )
      v5(this, 1024, 0, 0, *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)this));
    FMOD::TimeStamp::stampIn(&this->mUpdateTimeStamp);
    if ( !this->mLastUpdateMs )
      FMOD_OS_Time_GetMs(&this->mLastUpdateMs);
    FMOD_OS_Time_GetMs(currenttimestamp);
    v6 = currenttimestamp[0];
    mLastUpdateMs = this->mLastUpdateMs;
    mEmulated = this->mEmulated;
    this->mLastUpdateMs = currenttimestamp[0];
    v9 = v6 - mLastUpdateMs;
    if ( mLastUpdateMs > v6 )
      v9 = v6;
    if ( !mEmulated || (updated = FMOD::OutputEmulated::update(mEmulated)) == FMOD_RESULT::FMOD_OK_0 )
    {
      updated = FMOD::SystemI::update3DReverbs(this);
      if ( updated == FMOD_RESULT::FMOD_OK_0 )
      {
        updated = FMOD::SystemI::updateChannelGroups(this, v9);
        if ( updated == FMOD_RESULT::FMOD_OK_0 )
        {
          updated = FMOD::SystemI::updateChannels(this, v9);
          if ( updated == FMOD_RESULT::FMOD_OK_0 )
          {
            updated = FMOD::SystemI::updateSoundGroups(this, v9);
            if ( updated == FMOD_RESULT::FMOD_OK_0 )
            {
              if ( this->mOutput )
              {
                FMOD::TimeStamp::setPaused(&this->mUpdateTimeStamp, 1);
                updated = FMOD::Output::update(this->mOutput);
                if ( updated )
                  return updated;
                FMOD::TimeStamp::setPaused(&this->mUpdateTimeStamp, 0);
              }
              if ( !checkdriverlist || (updated = FMOD::SystemI::checkDriverList(this, 1)) == FMOD_RESULT::FMOD_OK_0 )
              {
                v10 = 0;
                v11 = 0;
                if ( this->mNumRecordDrivers > 0 )
                {
                  while ( 1 )
                  {
                    info = this->mRecordCache[v10].info;
                    if ( info )
                    {
                      if ( info->mRecordFinished )
                      {
                        v13 = FMOD::SystemI::recordStop(this, v11);
                        if ( v13 )
                          return v13;
                      }
                    }
                    ++v11;
                    ++v10;
                    if ( this->mNumRecordDrivers <= v11 )
                      goto LABEL_27;
                  }
                }
                else
                {
LABEL_27:
                  if ( checkdriverlist )
                  {
                    if ( *(unsigned __int64 *)((char *)&stru_11748.r_offset + (_QWORD)this) )
                    {
                      if ( (this->mCallbackMask & 0x1000) != 0 )
                      {
                        v24 = FMOD::SystemI::updateRecordCache(this);
                        if ( v24 != FMOD_RESULT::FMOD_ERR_RECORD_0 )
                        {
                          updated = v24;
                          if ( v24 )
                            return updated;
                          if ( this->mRecordListChanged )
                          {
                            this->mRecordListChanged = 0;
                            (*(void (__fastcall **)(boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *))((char *)&stru_11748.r_offset + (_QWORD)this))((boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)this);
                          }
                        }
                      }
                    }
                  }
                  mNumListeners = this->mNumListeners;
                  if ( mNumListeners > 0 )
                  {
                    v15 = this;
                    v16 = &this->mSoundListHead.mMagic + 28 * (unsigned int)(mNumListeners - 1);
                    do
                    {
                      v15->mListener[0].mMoved = 0;
                      v15->mListener[0].mRotated = 0;
                      v15 = (FMOD::SystemI *)((char *)v15 + 112);
                    }
                    while ( v15 != (FMOD::SystemI *)v16 );
                  }
                  v17 = (this->mFlags & 1) == 0;
                  *((_BYTE *)&stru_122A0.r_offset + (_QWORD)this) = 0;
                  if ( !v17 )
                    FMOD::SystemI::updateStreams(this);
                  if ( !this->mOutput
                    || this->mNumMeteredDSPs <= 0
                    || (updated = FMOD::SystemI::updateDSPMetering(this)) == FMOD_RESULT::FMOD_OK_0 )
                  {
                    updated = FMOD::SystemI::flushDSPReleaseQueue(this);
                    if ( updated == FMOD_RESULT::FMOD_OK_0 )
                    {
                      mNodeNext = this->mDSPSystemUpdateHead.mNodeNext;
                      p_mDSPSystemUpdateHead = &this->mDSPSystemUpdateHead;
                      while ( mNodeNext != p_mDSPSystemUpdateHead )
                      {
                        while ( 1 )
                        {
                          mNodeData = mNodeNext->mNodeData;
                          mNodeNext = mNodeNext->mNodeNext;
                          v21 = (void (__fastcall *)(_QWORD *, __int64, _QWORD, _QWORD))mNodeData[37];
                          if ( !v21
                            || (*((_BYTE *)mNodeData + 290) & 0x40) == 0
                            || (*((_BYTE *)mNodeData + 93) & 0x10) != 0 )
                          {
                            break;
                          }
                          v21(mNodeData + 23, 64, 0, 0);
                          if ( mNodeNext == p_mDSPSystemUpdateHead )
                            goto LABEL_45;
                        }
                      }
LABEL_45:
                      v22 = *(FMOD::Profile **)((char *)&stru_125D0.r_offset + (_QWORD)this);
                      if ( !v22 || (updated = FMOD::Profile::update(v22)) == FMOD_RESULT::FMOD_OK_0 )
                      {
                        updated = FMOD_RESULT::FMOD_OK_0;
                        FMOD::TimeStamp::stampOut(&this->mUpdateTimeStamp, 95);
                        v23 = *(void (__fastcall **)(FMOD::SystemI *const, __int64, _QWORD, _QWORD, _QWORD))((char *)&stru_11748.r_offset + (_QWORD)this);
                        if ( v23 && (this->mCallbackMask & 0x800) != 0 )
                          v23(this, 2048, 0, 0, *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)this));
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return updated;
}


