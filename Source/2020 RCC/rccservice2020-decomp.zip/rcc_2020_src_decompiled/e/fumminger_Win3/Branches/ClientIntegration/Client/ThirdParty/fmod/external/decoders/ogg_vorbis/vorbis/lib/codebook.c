// Address: 0x226ac20 | Name: FMOD_vorbis_staticbook_unpack
int __fastcall FMOD_vorbis_staticbook_unpack(void *context, oggpack_buffer *opb, static_codebook_0 *s)
{
  static_codebook_0 *v4; // rdi
  unsigned int v7; // edx
  __int64 v8; // rcx
  ogg_int32_t *v9; // rdi
  int v10; // ebp
  int result; // eax
  ogg_int32_t v12; // eax
  int v13; // ebp
  ogg_int32_t v14; // eax
  int v15; // r14d
  ogg_int32_t *v16; // rax
  ogg_int32_t entries; // edi
  ogg_int32_t v18; // ebp
  int v19; // eax
  ogg_int32_t v20; // eax
  int v21; // eax
  ogg_int32_t *v22; // rdx
  ogg_int32_t v23; // eax
  int maptype; // eax
  int v25; // esi
  ogg_int32_t *v26; // rax
  ogg_int32_t *quantlist; // rbp
  unsigned __int64 v28; // r15
  ogg_int32_t *v29; // rbp
  ogg_int32_t *v30; // rax
  __int64 j; // rbp
  ogg_int32_t v32; // eax
  ogg_int32_t *v33; // rax
  __int64 v34; // r14
  ogg_int32_t i; // ebp
  ogg_int32_t v36; // eax
  ogg_int32_t quantvals; // [rsp+Ch] [rbp-3Ch]

  v4 = s;
  v7 = 56;
  if ( ((unsigned __int8)s & 1) == 0 )
  {
    if ( ((unsigned __int8)v4 & 2) == 0 )
      goto LABEL_3;
LABEL_42:
    v4 = (static_codebook_0 *)((char *)v4 + 2);
    v7 -= 2;
    *((_WORD *)&v4[-1].allocedp + 3) = 0;
    if ( ((unsigned __int8)v4 & 4) == 0 )
      goto LABEL_4;
    goto LABEL_43;
  }
  v4 = (static_codebook_0 *)((char *)&s->dim + 1);
  LOBYTE(s->dim) = 0;
  LOBYTE(v7) = 55;
  if ( (((_BYTE)s + 1) & 2) != 0 )
    goto LABEL_42;
LABEL_3:
  if ( ((unsigned __int8)v4 & 4) == 0 )
    goto LABEL_4;
LABEL_43:
  v4->dim = 0;
  v7 -= 4;
  v4 = (static_codebook_0 *)((char *)v4 + 4);
LABEL_4:
  v8 = v7 >> 3;
  memset(v4, 0, 8 * v8);
  v9 = &v4->dim + 2 * v8;
  if ( (v7 & 4) != 0 )
    *v9++ = 0;
  if ( (v7 & 2) != 0 )
  {
    v9 = (ogg_int32_t *)((char *)v9 + 2);
    *((_WORD *)v9 - 1) = 0;
  }
  if ( (v7 & 1) != 0 )
    *(_BYTE *)v9 = 0;
  s->allocedp = 1;
  if ( FMOD_oggpack_read(opb, 24) != 5653314 )
    goto LABEL_11;
  s->dim = FMOD_oggpack_read(opb, 16);
  v12 = FMOD_oggpack_read(opb, 24);
  s->entries = v12;
  if ( v12 == -1 )
    goto LABEL_11;
  v13 = FMOD_ilog(s->dim);
  if ( FMOD_ilog(s->entries) + v13 > 24 )
    goto LABEL_11;
  v14 = FMOD_oggpack_read(opb, 1);
  if ( v14 )
  {
    if ( v14 != 1 )
      return -1;
    v15 = FMOD_oggpack_read(opb, 5) + 1;
    v16 = (ogg_int32_t *)FMOD_OggVorbis_Malloc(context, 4 * s->entries);
    s->lengthlist = v16;
    if ( !v16 )
      goto LABEL_54;
    entries = s->entries;
    if ( entries > 0 )
    {
      v18 = 0;
      do
      {
        v19 = FMOD_ilog(entries - v18);
        v20 = FMOD_oggpack_read(opb, v19);
        if ( v20 == -1 )
          goto LABEL_11;
        if ( v20 > 0 )
        {
          if ( s->entries <= v18 )
            break;
          v21 = v18 + v20;
          v22 = &s->lengthlist[v18];
          while ( 1 )
          {
            ++v18;
            *v22 = v15;
            if ( v18 == v21 )
              break;
            ++v22;
            if ( s->entries <= v18 )
              goto LABEL_28;
          }
        }
        entries = s->entries;
        ++v15;
      }
      while ( entries > v18 );
    }
  }
  else
  {
    v30 = (ogg_int32_t *)FMOD_OggVorbis_Malloc(context, 4 * s->entries);
    s->lengthlist = v30;
    if ( !v30 )
      goto LABEL_54;
    if ( FMOD_oggpack_read(opb, 1) )
    {
      if ( s->entries > 0 )
      {
        v34 = 0;
        for ( i = 0; s->entries > i; ++i )
        {
          if ( FMOD_oggpack_read(opb, 1) )
          {
            v36 = FMOD_oggpack_read(opb, 5);
            if ( v36 == -1 )
              goto LABEL_11;
            s->lengthlist[v34] = v36 + 1;
          }
          else
          {
            s->lengthlist[v34] = 0;
          }
          ++v34;
        }
      }
    }
    else
    {
      for ( j = 0; s->entries > (int)j; s->lengthlist[j++] = v32 + 1 )
      {
        v32 = FMOD_oggpack_read(opb, 5);
        if ( v32 == -1 )
          goto LABEL_11;
      }
    }
  }
LABEL_28:
  result = FMOD_oggpack_read(opb, 4);
  s->maptype = result;
  if ( result )
  {
    if ( (unsigned int)result <= 2 )
    {
      s->q_min = FMOD_oggpack_read(opb, 32);
      s->q_delta = FMOD_oggpack_read(opb, 32);
      s->q_quant = FMOD_oggpack_read(opb, 4) + 1;
      v23 = FMOD_oggpack_read(opb, 1);
      s->q_sequencep = v23;
      if ( v23 != -1 )
      {
        maptype = s->maptype;
        if ( maptype == 1 )
        {
          if ( !s->dim )
          {
            v33 = (ogg_int32_t *)FMOD_OggVorbis_Malloc(context, 0);
            s->quantlist = v33;
            if ( v33 )
              return 0;
            goto LABEL_54;
          }
          quantvals = FMOD_book_maptype1_quantvals(s);
          v25 = 4 * quantvals;
        }
        else if ( maptype == 2 )
        {
          v25 = 4 * s->dim * s->entries;
          quantvals = s->dim * s->entries;
        }
        else
        {
          v25 = 0;
          quantvals = 0;
        }
        v26 = (ogg_int32_t *)FMOD_OggVorbis_Malloc(context, v25);
        s->quantlist = v26;
        if ( v26 )
        {
          if ( quantvals <= 0 )
          {
            if ( !quantvals )
              return 0;
          }
          else
          {
            quantlist = v26;
            v28 = 0;
            while ( 1 )
            {
              v29 = &quantlist[v28 / 4];
              v28 += 4LL;
              *v29 = FMOD_oggpack_read(opb, s->q_quant);
              if ( v28 == 4LL * (unsigned int)(quantvals - 1) + 4 )
                break;
              quantlist = s->quantlist;
            }
          }
          if ( s->quantlist[quantvals - 1] == -1 )
            goto LABEL_11;
          return 0;
        }
LABEL_54:
        v10 = -139;
        goto _errout;
      }
    }
LABEL_11:
    v10 = -1;
_errout:
    FMOD_vorbis_staticbook_clear(context, s);
    return v10;
  }
  return result;
}


// Address: 0x226b060 | Name: FMOD_vorbis_book_decode
ogg_int32_t __fastcall FMOD_vorbis_book_decode(codebook_0 *book, oggpack_buffer *b)
{
  int dec_maxlength; // ebp
  ogg_int32_t v4; // eax
  int v5; // r14d
  __int64 v6; // rbx
  ogg_int32_t used_entries; // r14d
  ogg_int32_t v8; // eax
  unsigned __int32 v9; // eax
  unsigned int v10; // edx
  unsigned int v11; // eax
  int v12; // edx
  unsigned int i; // esi
  int v14; // edx
  int v15; // eax
  int v16; // esi

  if ( book->used_entries <= 0 )
    return -1;
  dec_maxlength = book->dec_maxlength;
  v4 = FMOD_oggpack_look(b, book->dec_firsttablen);
  if ( v4 < 0 )
  {
    used_entries = book->used_entries;
    LODWORD(v6) = 0;
    goto LABEL_7;
  }
  v5 = book->dec_firsttable[v4];
  if ( v5 < 0 )
  {
    LODWORD(v6) = (v5 >> 15) & 0x7FFF;
    used_entries = book->used_entries - (book->dec_firsttable[v4] & 0x7FFF);
LABEL_7:
    while ( 1 )
    {
      v8 = FMOD_oggpack_look(b, dec_maxlength);
      if ( v8 >= 0 || dec_maxlength <= 1 )
        break;
      --dec_maxlength;
    }
    if ( v8 >= 0 )
    {
      v9 = _byteswap_ulong(v8);
      v10 = (v9 >> 4) & 0xF0F0F0F | (16 * v9) & 0xF0F0F0F0;
      v11 = (v10 >> 2) & 0x33333333 | (4 * v10) & 0xCCCCCCCC;
      v12 = used_entries - v6;
      for ( i = (v11 >> 1) & 0x55555555 | (2 * v11) & 0xAAAAAAAA; used_entries - (int)v6 > 1; v12 = used_entries - v6 )
      {
        v14 = v12 >> 1;
        v15 = book->codelist[v14 + (int)v6] > i;
        used_entries -= v14 & -v15;
        LODWORD(v6) = (v14 & (v15 - 1)) + v6;
      }
      v6 = (int)v6;
      v16 = book->dec_codelengths[(int)v6];
      if ( v16 <= dec_maxlength )
      {
        FMOD_oggpack_adv(b, v16);
        return book->dec_index[v6];
      }
      FMOD_oggpack_adv(b, dec_maxlength);
    }
    return -1;
  }
  LODWORD(v6) = v5 - 1;
  FMOD_oggpack_adv(b, book->dec_codelengths[v5 - 1]);
  if ( v5 )
  {
    v6 = (int)v6;
    return book->dec_index[v6];
  }
  return -1;
}


// Address: 0x226b1d0 | Name: FMOD_vorbis_book_decodevs_add
ogg_int32_t __fastcall FMOD_vorbis_book_decodevs_add(codebook_0 *book, float *a, oggpack_buffer *b, int n)
{
  ogg_int32_t used_entries; // eax
  ogg_int32_t dim; // esi
  void *v7; // rsp
  void *v8; // rsp
  float **v9; // r14
  int dec_maxlength; // r15d
  ogg_int32_t v11; // eax
  int v12; // r13d
  int v13; // r14d
  ogg_int32_t v14; // r13d
  ogg_int32_t j; // eax
  unsigned __int32 v16; // eax
  unsigned int v17; // esi
  unsigned int v18; // eax
  int v19; // esi
  unsigned int k; // r9d
  int v21; // esi
  int v22; // eax
  int v23; // esi
  ogg_int32_t v24; // edx
  ogg_int32_t v25; // eax
  float *v26; // rdx
  __int64 v27; // rcx
  float *v28; // rdi
  __int64 v29; // r10
  int v30; // r9d
  __int64 v31; // r8
  unsigned __int64 v32; // rsi
  float *v33; // rdx
  __int64 v34; // rax
  float *v35; // rcx
  float v36; // xmm0_4
  __int64 v38; // [rsp+0h] [rbp-70h] BYREF
  __int64 v39; // [rsp+8h] [rbp-68h]
  oggpack_buffer *ba; // [rsp+10h] [rbp-60h]
  float *aa; // [rsp+18h] [rbp-58h]
  float **t; // [rsp+20h] [rbp-50h]
  int step; // [rsp+2Ch] [rbp-44h]
  ogg_int32_t *entry; // [rsp+30h] [rbp-40h]
  __int64 i; // [rsp+38h] [rbp-38h]

  used_entries = book->used_entries;
  aa = a;
  ba = b;
  if ( used_entries <= 0 )
    return 0;
  dim = book->dim;
  step = n / book->dim;
  v39 = 4LL * step;
  v7 = alloca(v39 + 15);
  entry = (ogg_int32_t *)&v38;
  v8 = alloca(8LL * step + 15);
  v9 = (float **)&v38;
  if ( step <= 0 )
  {
    v25 = dim;
LABEL_18:
    if ( v25 > 0 )
    {
      v28 = aa;
      v29 = v39;
      v30 = step;
      v31 = 4LL * (unsigned int)(v25 - 1) + 4;
      v32 = 0;
      do
      {
        if ( v30 > 0 )
        {
          v33 = v28;
          v34 = 0;
          do
          {
            v35 = v9[v34];
            v36 = *v33;
            ++v34;
            *v33++ = v36 + v35[v32 / 4];
          }
          while ( v30 > (int)v34 );
        }
        v32 += 4LL;
        v28 = (float *)((char *)v28 + v29);
      }
      while ( v32 != v31 );
    }
    return 0;
  }
  i = 0;
  t = (float **)&v38;
  while ( 1 )
  {
    dec_maxlength = book->dec_maxlength;
    v11 = FMOD_oggpack_look(b, book->dec_firsttablen);
    if ( v11 < 0 )
    {
      v14 = book->used_entries;
      v13 = 0;
    }
    else
    {
      v12 = book->dec_firsttable[v11];
      if ( v12 >= 0 )
      {
        FMOD_oggpack_adv(b, book->dec_codelengths[v12 - 1]);
        v24 = v12 - 1;
        entry[i] = v12 - 1;
        if ( !v12 )
          return v24;
        goto LABEL_16;
      }
      v13 = (v12 >> 15) & 0x7FFF;
      v14 = book->used_entries - (book->dec_firsttable[v11] & 0x7FFF);
    }
    for ( j = FMOD_oggpack_look(b, dec_maxlength); j < 0; j = FMOD_oggpack_look(b, --dec_maxlength) )
    {
      if ( dec_maxlength <= 1 )
        break;
    }
    if ( j < 0 )
      return -1;
    v16 = _byteswap_ulong(j);
    v17 = (v16 >> 4) & 0xF0F0F0F | (16 * v16) & 0xF0F0F0F0;
    v18 = (v17 >> 2) & 0x33333333 | (4 * v17) & 0xCCCCCCCC;
    v19 = v14 - v13;
    for ( k = (v18 >> 1) & 0x55555555 | (2 * v18) & 0xAAAAAAAA; v14 - v13 > 1; v19 = v14 - v13 )
    {
      v21 = v19 >> 1;
      v22 = book->codelist[v21 + v13] > k;
      v14 -= v21 & -v22;
      v13 += v21 & (v22 - 1);
    }
    v23 = book->dec_codelengths[v13];
    if ( v23 > dec_maxlength )
      break;
    FMOD_oggpack_adv(b, v23);
    v24 = v13;
    entry[i] = v13;
LABEL_16:
    v25 = book->dim;
    v26 = &book->valuelist[book->dim * v24];
    v27 = i++;
    t[v27] = v26;
    if ( step <= (int)i )
    {
      v9 = t;
      goto LABEL_18;
    }
  }
  FMOD_oggpack_adv(ba, dec_maxlength);
  return -1;
}


// Address: 0x226b4a0 | Name: FMOD_vorbis_book_decodev_add
ogg_int32_t __fastcall FMOD_vorbis_book_decodev_add(codebook_0 *book, float *a, oggpack_buffer *b, int n)
{
  int v5; // r12d
  int v7; // r12d
  int dec_maxlength; // r15d
  ogg_int32_t v9; // eax
  int v10; // r13d
  int v11; // r14d
  ogg_int32_t v12; // r13d
  ogg_int32_t v13; // eax
  unsigned __int32 v14; // eax
  unsigned int v15; // ecx
  unsigned int v16; // eax
  int v17; // ecx
  unsigned int j; // edi
  int v19; // ecx
  int v20; // eax
  int v21; // esi
  ogg_int32_t dim; // ecx
  float *v23; // rsi
  float *v24; // rdx
  __int64 v25; // rax
  float v26; // xmm0_4
  float v27; // xmm0_4
  __int64 v29; // rsi
  __int64 v30; // rdi
  __int64 v31; // r8
  __int64 v32; // r9
  __int64 v33; // r10
  __int64 v34; // rcx
  __int64 v35; // r11
  int v36; // edx
  int v37; // edx
  int v38; // ecx
  int v39; // edx
  ogg_int32_t v40; // eax
  int v41; // r13d
  int v42; // r14d
  ogg_int32_t used_entries; // r13d
  ogg_int32_t v44; // eax
  unsigned __int32 v45; // eax
  unsigned int v46; // esi
  unsigned int v47; // eax
  int v48; // esi
  unsigned int i; // r9d
  int v50; // esi
  int v51; // eax
  int v52; // esi
  int v53; // edx
  float *v54; // rax
  __int64 v55; // rdx

  if ( book->used_entries <= 0 )
    return 0;
  v5 = 0;
  if ( book->dim <= 8 )
  {
    while ( 1 )
    {
      if ( n <= v5 )
        return 0;
      while ( 2 )
      {
        dec_maxlength = book->dec_maxlength;
        v40 = FMOD_oggpack_look(b, book->dec_firsttablen);
        if ( v40 < 0 )
        {
          used_entries = book->used_entries;
          v42 = 0;
        }
        else
        {
          v41 = book->dec_firsttable[v40];
          if ( v41 >= 0 )
          {
            FMOD_oggpack_adv(b, book->dec_codelengths[v41 - 1]);
            v53 = v41 - 1;
            if ( !v41 )
              return -1;
            goto LABEL_42;
          }
          v42 = (v41 >> 15) & 0x7FFF;
          used_entries = book->used_entries - (book->dec_firsttable[v40] & 0x7FFF);
        }
        while ( 1 )
        {
          v44 = FMOD_oggpack_look(b, dec_maxlength);
          if ( v44 >= 0 || dec_maxlength <= 1 )
            break;
          --dec_maxlength;
        }
        if ( v44 < 0 )
          return -1;
        v45 = _byteswap_ulong(v44);
        v46 = (v45 >> 4) & 0xF0F0F0F | (16 * v45) & 0xF0F0F0F0;
        v47 = (v46 >> 2) & 0x33333333 | (4 * v46) & 0xCCCCCCCC;
        v48 = used_entries - v42;
        for ( i = (v47 >> 1) & 0x55555555 | (2 * v47) & 0xAAAAAAAA; used_entries - v42 > 1; v48 = used_entries - v42 )
        {
          v50 = v48 >> 1;
          v51 = book->codelist[v50 + v42] > i;
          used_entries -= v50 & -v51;
          v42 += v50 & (v51 - 1);
        }
        v52 = book->dec_codelengths[v42];
        if ( v52 > dec_maxlength )
        {
LABEL_56:
          FMOD_oggpack_adv(b, dec_maxlength);
          return -1;
        }
        FMOD_oggpack_adv(b, v52);
        v53 = v42;
LABEL_42:
        v54 = &book->valuelist[book->dim * v53];
        switch ( book->dim )
        {
          case 1:
            v39 = v5;
            v29 = 0;
            goto LABEL_29;
          case 2:
            v38 = v5;
            v29 = 1;
            v30 = 0;
            goto LABEL_28;
          case 3:
            v29 = 2;
            v30 = 1;
            v31 = 0;
            goto LABEL_27;
          case 4:
            v37 = v5;
            v29 = 3;
            v30 = 2;
            v31 = 1;
            v32 = 0;
            goto LABEL_26;
          case 5:
            v29 = 4;
            v30 = 3;
            v31 = 2;
            v32 = 1;
            v33 = 0;
            goto LABEL_25;
          case 6:
            v36 = v5;
            v29 = 5;
            v30 = 4;
            v31 = 3;
            v32 = 2;
            v33 = 1;
            v34 = 0;
            goto LABEL_24;
          case 7:
            v29 = 6;
            v30 = 5;
            v31 = 4;
            v32 = 3;
            v33 = 2;
            v34 = 1;
            v35 = 0;
            goto LABEL_23;
          case 8:
            v55 = v5;
            v29 = 7;
            ++v5;
            v31 = 5;
            v32 = 4;
            v33 = 3;
            v34 = 2;
            v35 = 1;
            v30 = 6;
            a[v55] = a[v55] + *v54;
LABEL_23:
            v36 = v5 + 1;
            a[v5] = a[v5] + v54[v35];
LABEL_24:
            v5 = v36 + 1;
            a[v36] = a[v36] + v54[v34];
LABEL_25:
            v37 = v5 + 1;
            a[v5] = a[v5] + v54[v33];
LABEL_26:
            v5 = v37 + 1;
            a[v37] = a[v37] + v54[v32];
LABEL_27:
            v38 = v5 + 1;
            a[v5] = a[v5] + v54[v31];
LABEL_28:
            v39 = v38 + 1;
            a[v38] = a[v38] + v54[v30];
LABEL_29:
            v5 = v39 + 1;
            a[v39] = a[v39] + v54[v29];
            break;
          default:
            continue;
        }
        break;
      }
    }
  }
  if ( n > 0 )
  {
    v7 = 0;
    do
    {
      dec_maxlength = book->dec_maxlength;
      v9 = FMOD_oggpack_look(b, book->dec_firsttablen);
      if ( v9 < 0 )
      {
        v12 = book->used_entries;
        v11 = 0;
      }
      else
      {
        v10 = book->dec_firsttable[v9];
        if ( v10 >= 0 )
        {
          v11 = v10 - 1;
          FMOD_oggpack_adv(b, book->dec_codelengths[v10 - 1]);
          if ( !v10 )
            return -1;
          goto LABEL_16;
        }
        v11 = (v10 >> 15) & 0x7FFF;
        v12 = book->used_entries - (book->dec_firsttable[v9] & 0x7FFF);
      }
      while ( 1 )
      {
        v13 = FMOD_oggpack_look(b, dec_maxlength);
        if ( v13 >= 0 || dec_maxlength <= 1 )
          break;
        --dec_maxlength;
      }
      if ( v13 < 0 )
        return -1;
      v14 = _byteswap_ulong(v13);
      v15 = (v14 >> 4) & 0xF0F0F0F | (16 * v14) & 0xF0F0F0F0;
      v16 = (v15 >> 2) & 0x33333333 | (4 * v15) & 0xCCCCCCCC;
      v17 = v12 - v11;
      for ( j = (v16 >> 1) & 0x55555555 | (2 * v16) & 0xAAAAAAAA; v12 - v11 > 1; v17 = v12 - v11 )
      {
        v19 = v17 >> 1;
        v20 = book->codelist[v19 + v11] > j;
        v12 -= v19 & -v20;
        v11 += v19 & (v20 - 1);
      }
      v21 = book->dec_codelengths[v11];
      if ( v21 > dec_maxlength )
        goto LABEL_56;
      FMOD_oggpack_adv(b, v21);
LABEL_16:
      dim = book->dim;
      v23 = &book->valuelist[book->dim * v11];
      if ( book->dim > 0 )
      {
        v24 = &a[v7];
        v25 = 0;
        do
        {
          v26 = *v24++;
          v27 = v26 + v23[v25++];
          *(v24 - 1) = v27;
        }
        while ( dim > (int)v25 );
        v7 += dim;
      }
    }
    while ( n > v7 );
  }
  return 0;
}


// Address: 0x226ba30 | Name: FMOD_vorbis_book_decodev_set
ogg_int32_t __fastcall FMOD_vorbis_book_decodev_set(codebook_0 *book, float *a, oggpack_buffer *b, int n)
{
  int v6; // r12d
  int dec_maxlength; // r14d
  ogg_int32_t v8; // eax
  int v9; // r13d
  int v10; // r15d
  ogg_int32_t used_entries; // r13d
  ogg_int32_t v12; // eax
  unsigned __int32 v13; // eax
  unsigned int v14; // ecx
  unsigned int v15; // eax
  int v16; // ecx
  unsigned int j; // edi
  int v18; // ecx
  int v19; // eax
  int v20; // esi
  ogg_int32_t result; // eax
  ogg_int32_t dim; // edx
  float *v23; // rcx
  __int64 v24; // rax
  float *i; // r13

  if ( book->used_entries <= 0 )
  {
    if ( n > 0 )
    {
      if ( book->dim > 0 )
      {
        for ( i = a; ; ++i )
          *i = 0.0;
      }
      while ( 1 )
        ;
    }
    return 0;
  }
  if ( n <= 0 )
    return 0;
  v6 = 0;
  while ( 1 )
  {
    dec_maxlength = book->dec_maxlength;
    v8 = FMOD_oggpack_look(b, book->dec_firsttablen);
    if ( v8 < 0 )
    {
      used_entries = book->used_entries;
      v10 = 0;
    }
    else
    {
      v9 = book->dec_firsttable[v8];
      if ( v9 >= 0 )
      {
        FMOD_oggpack_adv(b, book->dec_codelengths[v9 - 1]);
        result = v9 - 1;
        if ( !v9 )
          return result;
        goto LABEL_15;
      }
      v10 = (v9 >> 15) & 0x7FFF;
      used_entries = book->used_entries - (book->dec_firsttable[v8] & 0x7FFF);
    }
    while ( 1 )
    {
      v12 = FMOD_oggpack_look(b, dec_maxlength);
      if ( v12 >= 0 || dec_maxlength <= 1 )
        break;
      --dec_maxlength;
    }
    if ( v12 < 0 )
      return -1;
    v13 = _byteswap_ulong(v12);
    v14 = (v13 >> 4) & 0xF0F0F0F | (16 * v13) & 0xF0F0F0F0;
    v15 = (v14 >> 2) & 0x33333333 | (4 * v14) & 0xCCCCCCCC;
    v16 = used_entries - v10;
    for ( j = (v15 >> 1) & 0x55555555 | (2 * v15) & 0xAAAAAAAA; used_entries - v10 > 1; v16 = used_entries - v10 )
    {
      v18 = v16 >> 1;
      v19 = book->codelist[v18 + v10] > j;
      used_entries -= v18 & -v19;
      v10 += v18 & (v19 - 1);
    }
    v20 = book->dec_codelengths[v10];
    if ( v20 > dec_maxlength )
      break;
    FMOD_oggpack_adv(b, v20);
    result = v10;
LABEL_15:
    dim = book->dim;
    v23 = &book->valuelist[book->dim * result];
    if ( book->dim > 0 )
    {
      v24 = 0;
      do
      {
        a[v6 + v24] = v23[v24];
        ++v24;
      }
      while ( dim > (int)v24 );
      v6 += dim;
    }
    if ( n <= v6 )
      return 0;
  }
  FMOD_oggpack_adv(b, dec_maxlength);
  return -1;
}


// Address: 0x226bc50 | Name: FMOD_vorbis_book_decodevv_add
ogg_int32_t __fastcall FMOD_vorbis_book_decodevv_add(
        codebook_0 *book,
        float **a,
        ogg_int32_t offset,
        int ch_0,
        oggpack_buffer *b,
        int n)
{
  int v7; // r12d
  int v8; // ebx
  int dec_maxlength; // r15d
  ogg_int32_t v10; // eax
  int v11; // r13d
  int v12; // ebp
  ogg_int32_t used_entries; // r13d
  ogg_int32_t v14; // eax
  unsigned __int32 v15; // eax
  unsigned int v16; // esi
  unsigned int v17; // eax
  int v18; // esi
  unsigned int i; // r10d
  int v20; // esi
  int v21; // eax
  int v22; // esi
  ogg_int32_t result; // eax
  ogg_int32_t dim; // edi
  float *v25; // r8
  __int64 v26; // rcx
  __int64 v27; // rax
  float *v28; // rcx
  int v32; // [rsp+1Ch] [rbp-3Ch]

  if ( book->used_entries > 0 )
  {
    v7 = 0;
    v8 = offset / ch_0;
    v32 = (offset + n) / ch_0;
    while ( 1 )
    {
      if ( v8 >= v32 )
        return 0;
      dec_maxlength = book->dec_maxlength;
      v10 = FMOD_oggpack_look(b, book->dec_firsttablen);
      if ( v10 < 0 )
      {
        used_entries = book->used_entries;
        v12 = 0;
      }
      else
      {
        v11 = book->dec_firsttable[v10];
        if ( v11 >= 0 )
        {
          FMOD_oggpack_adv(b, book->dec_codelengths[v11 - 1]);
          result = v11 - 1;
          if ( !v11 )
            return result;
          goto LABEL_15;
        }
        v12 = (v11 >> 15) & 0x7FFF;
        used_entries = book->used_entries - (book->dec_firsttable[v10] & 0x7FFF);
      }
      while ( 1 )
      {
        v14 = FMOD_oggpack_look(b, dec_maxlength);
        if ( v14 >= 0 || dec_maxlength <= 1 )
          break;
        --dec_maxlength;
      }
      if ( v14 < 0 )
        return -1;
      v15 = _byteswap_ulong(v14);
      v16 = (v15 >> 4) & 0xF0F0F0F | (16 * v15) & 0xF0F0F0F0;
      v17 = (v16 >> 2) & 0x33333333 | (4 * v16) & 0xCCCCCCCC;
      v18 = used_entries - v12;
      for ( i = (v17 >> 1) & 0x55555555 | (2 * v17) & 0xAAAAAAAA; used_entries - v12 > 1; v18 = used_entries - v12 )
      {
        v20 = v18 >> 1;
        v21 = book->codelist[v20 + v12] > i;
        used_entries -= v20 & -v21;
        v12 += v20 & (v21 - 1);
      }
      v22 = book->dec_codelengths[v12];
      if ( v22 > dec_maxlength )
      {
        FMOD_oggpack_adv(b, dec_maxlength);
        return -1;
      }
      FMOD_oggpack_adv(b, v22);
      result = v12;
LABEL_15:
      dim = book->dim;
      v25 = &book->valuelist[book->dim * result];
      if ( book->dim > 0 )
      {
        v26 = v7;
        v27 = 0;
        while ( 1 )
        {
          ++v7;
          v28 = &a[v26][v8];
          *v28 = *v28 + v25[v27];
          if ( v7 == ch_0 )
          {
            ++v8;
            v7 = 0;
          }
          if ( dim <= (int)++v27 )
            break;
          v26 = v7;
        }
      }
    }
  }
  return 0;
}


