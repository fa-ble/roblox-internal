// Address: 0x221fa10 | Name: _ZN4FMOD15ChannelEmulated9isVirtualEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelEmulated::isVirtual(FMOD::ChannelEmulated *const this, bool *isvirtual)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( isvirtual )
  {
    *isvirtual = 1;
    LOBYTE(result) = 0;
  }
  return result;
}


