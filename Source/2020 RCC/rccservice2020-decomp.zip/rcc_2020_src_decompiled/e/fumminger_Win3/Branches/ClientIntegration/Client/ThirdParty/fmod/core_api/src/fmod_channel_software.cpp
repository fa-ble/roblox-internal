// Address: 0x2256e90 | Name: _ZN4FMOD15ChannelSoftware6updateEi
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::update(FMOD::ChannelSoftware *const this, int delta_ms)
{
  FMOD::ChannelI *mParent; // rax
  float mAudibility; // xmm0_4
  bool v4; // zf

  mParent = this->mParent;
  mAudibility = mParent->mChannelGroupParent->mAudibility;
  if ( mAudibility == this->mChannelGroupAudibility )
    return FMOD_RESULT::FMOD_OK_0;
  v4 = (this->mMode & 8) == 0;
  this->mChannelGroupAudibility = mAudibility;
  if ( v4 )
    return FMOD_RESULT::FMOD_OK_0;
  else
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelSoftware *const, float))this->_vptr_ChannelReal + 13))(
             this,
             mParent->mVolume);
}


// Address: 0x2256ee0 | Name: _ZN4FMOD15ChannelSoftware14setLowPassGainEf
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setLowPassGain(
        FMOD::ChannelSoftware *const this,
        double a2,
        float gain)
{
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelSoftware *const, float, float))this->_vptr_ChannelReal + 13))(
           this,
           this->mParent->mVolume,
           gain);
}


// Address: 0x2256f00 | Name: _ZN4FMOD15ChannelSoftware13setFinishTickEv
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setFinishTick(FMOD::ChannelSoftware *const this)
{
  unsigned int v1; // eax

  v1 = 0;
  if ( (this->mFlags & 0x10000) == 0 )
    v1 = *(_DWORD *)((char *)&stru_11610.r_offset + (unsigned __int64)this->mSystem) + 2;
  this->mFinishTick = v1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2256f20 | Name: _ZN4FMOD15ChannelSoftware5startEv
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::start(FMOD::ChannelSoftware *const this)
{
  FMOD::DSPResampler *mDSPResampler; // rdi
  FMOD::DSPI *mDSPLowPass; // rdi
  FMOD::DSPI *mDSPHighPass; // rdi
  FMOD::DSPCodec *mDSPCodec; // rdi
  FMOD::DSPI *mDSP; // rdi

  if ( (this->mFlags & 0x20) == 0 )
  {
    if ( this->mDSPWaveTable.mSound )
      FMOD::DSPI::setActive(&this->mDSPWaveTable, 1, 1);
    mDSPResampler = this->mDSPResampler;
    if ( mDSPResampler )
      FMOD::DSPI::setActive(mDSPResampler, 1, 1);
    mDSPLowPass = this->mDSPLowPass;
    if ( mDSPLowPass )
      FMOD::DSPI::setActive(mDSPLowPass, 1, 1);
    mDSPHighPass = this->mDSPHighPass;
    if ( mDSPHighPass )
      FMOD::DSPI::setActive(mDSPHighPass, 1, 1);
    mDSPCodec = this->mDSPCodec;
    if ( mDSPCodec )
      FMOD::DSPI::setActive(mDSPCodec, 1, 1);
    mDSP = this->mDSP;
    if ( mDSP )
      FMOD::DSPI::setActive(mDSP, 1, 1);
  }
  return FMOD::ChannelReal::start(this);
}


// Address: 0x2256fe0 | Name: _ZN4FMOD15ChannelSoftware4stopEv
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::stop(FMOD::ChannelSoftware *const this)
{
  FMOD::ChannelI *mParent; // rdx
  int i; // r12d
  __int64 v4; // rbp
  FMOD::DSPI *mDSP; // rdi
  FMOD::DSPCodec *mDSPCodec; // rdi
  FMOD::DSPCodec *v7; // rdx
  FMOD::DSPCodecPool *mPool; // rax
  FMOD::DSPResampler *mDSPResampler; // rdi
  FMOD::DSPI *v10; // rdi

  if ( (this->mFlags & 0x10000) == 0 && this->mDSPReverb )
  {
    mParent = this->mParent;
    for ( i = 0; i != 4; ++i )
    {
      v4 = i;
      mDSP = this->mSystem->mReverb[i].mDSP;
      if ( mDSP )
      {
        FMOD::DSPI::disconnectFrom(
          mDSP,
          this->mDSPReverb,
          mParent->mReverbConnection[i],
          FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
        mParent = this->mParent;
      }
      mParent->mReverbConnection[v4] = 0;
    }
    this->mDSPReverb = 0;
  }
  mDSPCodec = this->mDSPCodec;
  if ( mDSPCodec )
  {
    (*((void (__fastcall **)(FMOD::DSPCodec *, __int64, _QWORD, _QWORD))mDSPCodec->_vptr_DSPI + 5))(mDSPCodec, 1, 0, 0);
    FMOD::DSPI::setActive(this->mDSPCodec, 0, 1);
    FMOD::DSPI::disconnectAll(this->mDSPCodec, 0, 1);
    v7 = this->mDSPCodec;
    mPool = v7->mPool;
    if ( mPool )
    {
      mPool->mAllocated[v7->mPoolIndex] = 0;
      --mPool->mNumAllocated;
    }
    this->mDSPCodec = 0;
    this->mMinFrequency = FMOD::ChannelReal::DEFAULT_MIN_FREQUENCY;
    this->mMaxFrequency = FMOD::ChannelReal::DEFAULT_MAX_FREQUENCY;
  }
  mDSPResampler = this->mDSPResampler;
  if ( mDSPResampler )
  {
    (*((void (__fastcall **)(FMOD::DSPResampler *, __int64, _QWORD, _QWORD))mDSPResampler->_vptr_DSPI + 5))(
      mDSPResampler,
      1,
      0,
      0);
    FMOD::DSPI::setActive(this->mDSPResampler, 0, 1);
    (*((void (__fastcall **)(FMOD::DSPResampler *))this->mDSPResampler->_vptr_DSPI + 2))(this->mDSPResampler);
    this->mDSPResampler = 0;
  }
  if ( this->mDSPWaveTable.mSound )
  {
    FMOD::DSPWaveTable::setFinished(&this->mDSPWaveTable, 1, 0, 0);
    FMOD::DSPI::setActive(&this->mDSPWaveTable, 0, 1);
    FMOD::DSPI::disconnectAll(&this->mDSPWaveTable, 0, 1);
  }
  v10 = this->mDSP;
  if ( v10 )
  {
    FMOD::DSPI::setActive(v10, 0, 1);
    FMOD::DSPI::disconnectAll(this->mDSP, 0, 1);
  }
  return FMOD::ChannelReal::stop(this);
}


// Address: 0x22571b0 | Name: _ZN4FMOD15ChannelSoftware9setPausedEb
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setPaused(FMOD::ChannelSoftware *const this, bool paused)
{
  FMOD::CHANNELREAL_FLAG mFlags; // eax
  FMOD::DSPResampler *mDSPResampler; // rdi
  FMOD::DSPCodec *mDSPCodec; // rdi
  FMOD::DSPI *mDSP; // rdi
  FMOD::DSPI *mDSPLowPass; // rdi
  FMOD::DSPI *mDSPHighPass; // rdi
  FMOD_RESULT_0 result; // eax

  if ( paused
    || (mFlags = this->mFlags, (mFlags & 0x20000) == 0)
    || (this->mFlags = mFlags & 0xFFFDFFFF,
        (result = FMOD::DSPFader::setRampFrom0(this->mParent->mDSPFader)) == FMOD_RESULT::FMOD_OK_0) )
  {
    if ( (this->mParent->mChannelGroupParent->mFlags & 0x10) == 0 )
    {
      if ( this->mSound && this->mDSPWaveTable.mSound )
        FMOD::DSPI::setActive(&this->mDSPWaveTable, !paused, 1);
      mDSPResampler = this->mDSPResampler;
      if ( mDSPResampler )
        FMOD::DSPI::setActive(mDSPResampler, !paused, 1);
      mDSPCodec = this->mDSPCodec;
      if ( mDSPCodec )
        FMOD::DSPI::setActive(mDSPCodec, !paused, 1);
      mDSP = this->mDSP;
      if ( mDSP )
        FMOD::DSPI::setActive(mDSP, !paused, 1);
      mDSPLowPass = this->mDSPLowPass;
      if ( mDSPLowPass )
        FMOD::DSPI::setActive(mDSPLowPass, !paused, 1);
      mDSPHighPass = this->mDSPHighPass;
      if ( mDSPHighPass )
        FMOD::DSPI::setActive(mDSPHighPass, !paused, 1);
    }
    return FMOD::ChannelReal::setPaused(this, paused);
  }
  return result;
}


// Address: 0x22572d0 | Name: _ZN4FMOD15ChannelSoftware12setFrequencyEf
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setFrequency(
        FMOD::ChannelSoftware *const this,
        float a2,
        float frequency)
{
  float v4; // xmm1_4
  float mMaxFrequency; // xmm0_4
  FMOD::DSPCodec *mDSPCodec; // rdi

  v4 = (float)((float)(1.0 - this->mParent->m3DLevel) + (float)(this->mParent->m3DLevel * this->mParent->mPitch3D)) * a2;
  mMaxFrequency = this->mMaxFrequency;
  if ( v4 <= mMaxFrequency )
    mMaxFrequency = fmaxf(this->mMinFrequency, v4);
  mDSPCodec = this->mDSPCodec;
  if ( mDSPCodec )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::DSPCodec *))mDSPCodec->_vptr_DSPI + 7))(mDSPCodec);
  mDSPCodec = (FMOD::DSPCodec *)this->mDSPResampler;
  if ( mDSPCodec )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::DSPCodec *))mDSPCodec->_vptr_DSPI + 7))(mDSPCodec);
  if ( this->mDSPWaveTable.mSound )
    return (unsigned int)FMOD::DSPWaveTable::setFrequency(&this->mDSPWaveTable, mMaxFrequency, v4);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2257350 | Name: _ZN4FMOD15ChannelSoftware11setPositionE14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setPosition(FMOD::ChannelSoftware *const this, FMOD_UINT32_32 pcm)
{
  FMOD::DSPI *mDSPHead; // r12
  FMOD_RESULT_0 result; // eax
  FMOD::SoundI *mSound; // rax
  unsigned int mLength; // ecx
  FMOD::DSPI *mDSPCodec; // rdi
  bool v8; // dl

  mDSPHead = this->mParent->mDSPHead;
  result = FMOD::ChannelReal::setPosition(this, pcm);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mSound = this->mSound;
    if ( mSound )
    {
      if ( (this->mMode & 1) != 0 || !this->mLoopCount )
      {
        mLength = mSound->mLength;
        result = FMOD_RESULT::FMOD_ERR_INVALID_POSITION_0;
        if ( mLength - 1 < pcm.mHi )
          return result;
      }
      else
      {
        result = FMOD_RESULT::FMOD_ERR_INVALID_POSITION_0;
        if ( this->mLoopLength + this->mLoopStart - 1 < pcm.mHi )
          return result;
      }
    }
    if ( (this->mParent->FMOD::ChannelReal::mFlags & 0x40000) != 0 )
    {
      if ( pcm.mValue )
        this->mFlags |= 0x20000u;
    }
    mDSPCodec = this->mDSPCodec;
    if ( mDSPCodec )
      goto LABEL_12;
    mDSPCodec = this->mDSP;
    if ( mDSPCodec )
      goto LABEL_15;
    mDSPCodec = &this->mDSPWaveTable;
    if ( this->mDSPWaveTable.mSound )
    {
LABEL_12:
      v8 = 0;
      return FMOD::DSPI::setPosition(mDSPCodec, pcm, v8, 1);
    }
    mDSPCodec = this->mDSPResampler;
    if ( mDSPCodec )
    {
LABEL_15:
      v8 = 1;
      return FMOD::DSPI::setPosition(mDSPCodec, pcm, v8, 1);
    }
    return FMOD::DSPI::setPosition(mDSPHead, pcm, 1, 1);
  }
  return result;
}


// Address: 0x2257450 | Name: _ZN4FMOD15ChannelSoftware9isPlayingEPbb
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::isPlaying(
        FMOD::ChannelSoftware *const this,
        bool *isplaying,
        bool includethreadlatency)
{
  FMOD_RESULT_0 result; // eax
  FMOD::CHANNELREAL_FLAG mFlags; // eax
  unsigned int mFinishTick; // edx
  FMOD::DSPCodec *mDSPCodec; // rdi
  bool v8; // al

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( isplaying )
  {
    mFlags = this->mFlags;
    if ( (mFlags & 0x10) == 0 )
    {
      mFinishTick = this->mFinishTick;
      if ( mFinishTick != -1 )
      {
        if ( (mFlags & 0x10000) == 0
          && mFinishTick > *(_DWORD *)((char *)&stru_11610.r_offset + (unsigned __int64)this->mSystem) )
        {
          goto LABEL_9;
        }
        goto LABEL_5;
      }
      mDSPCodec = this->mDSPCodec;
      if ( mDSPCodec || (mDSPCodec = (FMOD::DSPCodec *)this->mDSPResampler) != 0 )
      {
        (*((void (__fastcall **)(FMOD::DSPCodec *, bool *))mDSPCodec->_vptr_DSPI + 6))(mDSPCodec, isplaying);
        v8 = !*isplaying;
        *isplaying = v8;
        goto LABEL_12;
      }
      if ( this->mDSPWaveTable.mSound )
      {
        if ( !this->mSound )
        {
LABEL_5:
          *isplaying = 0;
LABEL_6:
          this->mFlags = mFlags & 0xFFFFFFAF;
          return FMOD_RESULT::FMOD_OK_0;
        }
        FMOD::DSPWaveTable::getFinished(&this->mDSPWaveTable, isplaying);
        v8 = !*isplaying;
        *isplaying = v8;
LABEL_12:
        if ( v8 )
          return FMOD_RESULT::FMOD_OK_0;
        mFlags = this->mFlags;
        goto LABEL_6;
      }
    }
LABEL_9:
    *isplaying = 1;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2257520 | Name: _ZN4FMOD15ChannelSoftware13setPositionExEjjb
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setPositionEx(
        FMOD::ChannelSoftware *const this,
        unsigned int position,
        FMOD_TIMEUNIT postype,
        bool fromasync)
{
  __int64 v4; // rdx
  FMOD_RESULT_0 result; // eax
  int (**vptr_ChannelReal)(...); // rax
  FMOD_UINT32_32 pcm; // [rsp+0h] [rbp-28h] BYREF

  v4 = postype & 0x10;
  result = FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  if ( (_DWORD)v4 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelSoftware *const, FMOD_UINT32_32 *, __int64, bool))this->_vptr_ChannelReal
              + 17))(
               this,
               &pcm,
               v4,
               fromasync);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      vptr_ChannelReal = this->_vptr_ChannelReal;
      pcm.mLo = position;
      return vptr_ChannelReal[16](this, pcm.mValue);
    }
  }
  return result;
}


// Address: 0x2257570 | Name: _ZN4FMOD15ChannelSoftware13getPositionExEPjj
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::getPositionEx(
        FMOD::ChannelSoftware *const this,
        unsigned int *position,
        FMOD_TIMEUNIT postype)
{
  FMOD_RESULT_0 result; // eax
  __int64 v4; // rdx
  FMOD_UINT32_32 pcm; // [rsp+0h] [rbp-18h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( position )
  {
    v4 = postype & 0x10;
    LOBYTE(result) = 68;
    if ( (_DWORD)v4 )
    {
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelSoftware *const, FMOD_UINT32_32 *, __int64))this->_vptr_ChannelReal
                + 17))(
                 this,
                 &pcm,
                 v4);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        *position = pcm.mLo;
    }
  }
  return result;
}


// Address: 0x22575b0 | Name: _ZN4FMOD15ChannelSoftware5closeEv
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::close(FMOD::ChannelSoftware *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPResampler *mDSPResampler; // rdi
  FMOD::DSPI *mDSPLowPass; // rdi
  FMOD::DSPI *mDSPHighPass; // rdi

  result = FMOD::ChannelReal::close(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    FMOD::DSPI::release(&this->mDSPWaveTable);
    mDSPResampler = this->mDSPResampler;
    if ( mDSPResampler )
    {
      (*((void (__fastcall **)(FMOD::DSPResampler *))mDSPResampler->_vptr_DSPI + 2))(mDSPResampler);
      this->mDSPResampler = 0;
    }
    mDSPLowPass = this->mDSPLowPass;
    if ( mDSPLowPass )
    {
      (*((void (__fastcall **)(FMOD::DSPI *))mDSPLowPass->_vptr_DSPI + 2))(mDSPLowPass);
      this->mDSPLowPass = 0;
    }
    mDSPHighPass = this->mDSPHighPass;
    if ( mDSPHighPass )
    {
      (*((void (__fastcall **)(FMOD::DSPI *))mDSPHighPass->_vptr_DSPI + 2))(mDSPHighPass);
      this->mDSPHighPass = 0;
    }
    this->mDSPCodec = 0;
    this->mMaxFrequency = FMOD::ChannelReal::DEFAULT_MAX_FREQUENCY;
    this->mMinFrequency = FMOD::ChannelReal::DEFAULT_MIN_FREQUENCY;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2257650 | Name: _ZN4FMOD15ChannelSoftware13setLoopPointsEjj
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setLoopPoints(
        FMOD::ChannelSoftware *const this,
        unsigned int loopstart,
        unsigned int looplength)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPCodec *mDSPCodec; // rdx
  FMOD::DSPResampler_NODMA *mNoDMA; // rdx

  result = FMOD::ChannelReal::setLoopPoints(this, loopstart, looplength);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mDSPCodec = this->mDSPCodec;
    if ( mDSPCodec )
    {
      mNoDMA = mDSPCodec->mNoDMA;
      mNoDMA->mLoopStart = this->mLoopStart;
      mNoDMA->mLoopLength = this->mLoopLength;
    }
  }
  return result;
}


// Address: 0x2257680 | Name: _ZN4FMOD15ChannelSoftware7setModeEj
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setMode(FMOD::ChannelSoftware *const this, FMOD_MODE mode)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPCodec *mDSPCodec; // rdx

  result = FMOD::ChannelReal::setMode(this, mode);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mDSPCodec = this->mDSPCodec;
    if ( mDSPCodec )
      mDSPCodec->mNoDMA->mMode = this->mMode;
  }
  return result;
}


// Address: 0x22576b0 | Name: _ZN4FMOD15ChannelSoftware4initEiPNS_7SystemIEPNS_6OutputE
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::init(
        FMOD::ChannelSoftware *const this,
        int index,
        FMOD::SystemI *system,
        FMOD::Output *output)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *mSystem; // rdi
  FMOD::FMOD_DSP_DESCRIPTION_EX *Description; // rax
  FMOD::DSPI *v8; // rbp
  FMOD::DSPI *dspi; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD::ChannelReal::init(this, index, system, output);
  if ( result )
    return result;
  mSystem = this->mSystem;
  if ( (mSystem->mFlags & 0x300) != 0 )
  {
    result = (unsigned int)FMOD::SystemI::createDSPByType(mSystem, FMOD_DSP_TYPE_LOWPASS_SIMPLE, &this->mDSPLowPass);
    if ( result )
      return result;
    mSystem = this->mSystem;
    if ( (mSystem->mFlags & 0x200) == 0 )
      goto LABEL_5;
    goto LABEL_4;
  }
  if ( (mSystem->mFlags & 0x200) != 0 )
  {
LABEL_4:
    result = (unsigned int)FMOD::SystemI::createDSPByType(mSystem, FMOD_DSP_TYPE_HIGHPASS_SIMPLE, &this->mDSPHighPass);
    if ( result )
      return result;
  }
LABEL_5:
  dspi = &this->mDSPWaveTable;
  Description = FMOD::DSPWaveTable::getDescriptionEx();
  result = FMOD::SystemI::createDSP(this->mSystem, Description, 0, &dspi, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v8 = dspi;
    result = (*((unsigned int (__fastcall **)(FMOD::DSPI *, __int64, __int64, _QWORD))dspi->_vptr_DSPI + 5))(
               dspi,
               1,
               1,
               0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::DSPI::setUserData(v8, this);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        *(float *)&v8[1].mJob.mDelayClock.mDelayStart = (float)this->mSystem->mDSPSampleRate;
        v8->mJob.mFlags |= 0x800u;
        this->mMinFrequency = -this->mMaxFrequency;
      }
    }
  }
  return result;
}


// Address: 0x22577b0 | Name: _ZN4FMOD15ChannelSoftware9getPausedEPb
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::getPaused(FMOD::ChannelSoftware *const this, bool *paused)
{
  FMOD::DSPResampler *mDSPResampler; // rax
  FMOD::DSPCodec *mDSPCodec; // rax
  FMOD::DSPI *mDSP; // rax

  if ( (this->mParent->mDSPHead->mJob.mFlags & 0x200) != 0
    && (!this->mSound || !this->mDSPWaveTable.mSound || (this->mDSPWaveTable.mJob.mFlags & 0x200) != 0) )
  {
    mDSPResampler = this->mDSPResampler;
    if ( !mDSPResampler || (mDSPResampler->mJob.mFlags & 0x200) != 0 )
    {
      mDSPCodec = this->mDSPCodec;
      if ( !mDSPCodec || (mDSPCodec->mJob.mFlags & 0x200) != 0 )
      {
        mDSP = this->mDSP;
        if ( !mDSP || (mDSP->mJob.mFlags & 0x200) != 0 )
          return FMOD::ChannelReal::getPaused(this, paused);
      }
    }
  }
  *paused = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2257820 | Name: _ZN4FMOD15ChannelSoftware11getPositionEP14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::getPosition(FMOD::ChannelSoftware *const this, FMOD_UINT32_32 *pcm)
{
  FMOD::DSPI *p_mDSPWaveTable; // rdi

  if ( !pcm )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( this->mDSPCodec )
    return FMOD::DSPI::getPosition(this->mDSPCodec, pcm);
  if ( this->mSound && this->mDSPWaveTable.mSound )
  {
    p_mDSPWaveTable = &this->mDSPWaveTable;
    return FMOD::DSPI::getPosition(p_mDSPWaveTable, pcm);
  }
  p_mDSPWaveTable = this->mDSPResampler;
  if ( p_mDSPWaveTable )
    return FMOD::DSPI::getPosition(p_mDSPWaveTable, pcm);
  return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x2257890 | Name: _ZN4FMOD15ChannelSoftware12setLoopCountEi
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setLoopCount(FMOD::ChannelSoftware *const this, int loopcount)
{
  FMOD_RESULT_0 result; // eax
  _DWORD *mDSPCodec; // rdx
  int mLoopCount; // eax

  result = FMOD::ChannelReal::setLoopCount(this, loopcount);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mDSPCodec = this->mDSPCodec;
    if ( mDSPCodec
      || (mDSPCodec = this->mDSPResampler) != 0
      || (mDSPCodec = &this->mDSPWaveTable, this->mDSPWaveTable.mSound) )
    {
      mLoopCount = this->mLoopCount;
      ++mDSPCodec[150];
      mDSPCodec[149] = mLoopCount;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x22578e0 | Name: _ZN4FMOD15ChannelSoftware12getLoopCountEPi
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::getLoopCount(FMOD::ChannelSoftware *const this, int *loopcount)
{
  int *mDSPCodec; // rax

  if ( !loopcount )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mDSPCodec = (int *)this->mDSPCodec;
  if ( !mDSPCodec )
  {
    mDSPCodec = (int *)this->mDSPResampler;
    if ( !mDSPCodec )
    {
      mDSPCodec = (int *)&this->mDSPWaveTable;
      if ( !this->mDSPWaveTable.mSound )
        return FMOD::ChannelReal::getLoopCount(this, loopcount);
    }
  }
  if ( mDSPCodec[150] <= (unsigned int)mDSPCodec[151] )
    *loopcount = mDSPCodec[148];
  else
    *loopcount = mDSPCodec[149];
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2257a00 | Name: _ZN4FMOD15ChannelSoftwareC2Ev
void __fastcall FMOD::ChannelSoftware::ChannelSoftware(FMOD::ChannelSoftware *const this)
{
  FMOD::ChannelReal::ChannelReal(this);
  this->_vptr_ChannelReal = (int (**)(...))&off_29B2CB0;
  FMOD::DSPI::DSPI(&this->mDSPWaveTable);
  this->mDSPResampler = 0;
  this->mDSPCodec = 0;
  this->mDSPLowPass = 0;
  this->mDSPHighPass = 0;
  this->mDSP = 0;
  this->mDSPReverb = 0;
  this->mFinishTick = 0;
  this->mDSPWaveTable._vptr_DSPI = (int (**)(...))off_29B2C30;
  this->mChannelGroupAudibility = 1.0;
}


// Address: 0x2257a90 | Name: _ZN4FMOD15ChannelSoftware15updateDirectMixEf
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::updateDirectMix(
        FMOD::ChannelSoftware *const this,
        float a2,
        float volume)
{
  FMOD::ChannelI *mParent; // rax
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // ecx
  FMOD::DSPConnectionI *const *mDSPFader; // rbp
  FMOD::SoundI *mSound; // rdx
  double v8; // xmm1_8
  FMOD::SoundGroupI *mSoundGroup; // rdx
  FMOD::DSPI *mDSPLowPass; // rdx
  float v11; // xmm0_4
  float v12; // xmm4_4
  float mDistanceFilterCustomLevel; // xmm0_4
  FMOD::ChannelGroupI *mChannelGroupParent; // rax
  bool v15; // cl
  unsigned int v16; // esi
  FMOD::DSPI *mDSPHighPass; // rdi
  float v19; // xmm2_4
  __m128i mDistanceFilterCentreFreq_low; // xmm0
  __m128i v21; // xmm0
  FMOD::FMOD_CHANNELCONTROL_FLAG v22; // eax
  float mDistance; // xmm0_4
  float mMaxDistance; // xmm2_4
  float mMinDistance; // xmm5_4
  float v26; // [rsp+0h] [rbp-28h]
  float distance_filtering; // [rsp+4h] [rbp-24h]
  float transmission; // [rsp+8h] [rbp-20h]
  float transmissiona; // [rsp+8h] [rbp-20h]

  mParent = this->mParent;
  mFlags = mParent->mFlags;
  mDSPFader = (FMOD::DSPConnectionI *const *)mParent->mDSPFader;
  if ( (mFlags & 2) != 0 )
    a2 = 0.0;
  *(_QWORD *)&v8 = LODWORD(mParent->m3DLevel);
  mSound = this->mSound;
  *(float *)&v8 = (float)((float)(*(float *)&v8 * mParent->mConeVolume3D) + (float)(1.0 - *(float *)&v8))
                * (float)((float)((float)(mParent->mVolume3D * *(float *)&v8) + (float)(1.0 - *(float *)&v8))
                        * (float)(a2 * mParent->mSoundGroupFadeVolume));
  if ( mSound )
  {
    mSoundGroup = mSound->mSoundGroup;
    if ( mSoundGroup )
      *(float *)&v8 = *(float *)&v8 * mSoundGroup->mVolume;
  }
  mDSPLowPass = this->mDSPLowPass;
  v11 = (float)(1.0 - mParent->mDirectOcclusion) * (float)(1.0 - mParent->mUserDirectOcclusion);
  if ( !mDSPLowPass )
  {
    *(float *)&v8 = *(float *)&v8 * v11;
    goto LABEL_11;
  }
  v12 = mParent->mLowPassGain * v11;
  if ( (this->mSystem->FMOD::ChannelReal::mFlags & 0x200) != 0 )
  {
    mDSPHighPass = this->mDSPHighPass;
    if ( mDSPHighPass )
    {
      if ( (mFlags & 0x100000) != 0 )
      {
        mDistanceFilterCustomLevel = mParent->mDistanceFilterCustomLevel;
      }
      else
      {
        mDistance = mParent->mDistance;
        mMaxDistance = mParent->mMaxDistance;
        if ( mDistance > mMaxDistance )
        {
          v19 = 0.0;
          v26 = 1.0;
          goto LABEL_21;
        }
        mMinDistance = mParent->mMinDistance;
        if ( mDistance <= mMinDistance )
        {
          mDistanceFilterCustomLevel = 0.0;
LABEL_31:
          transmissiona = v12;
          FMOD::DSPI::setBypass(mDSPHighPass, 1);
          mDSPLowPass = this->mDSPLowPass;
          *(_QWORD *)&v8 = LODWORD(v8);
          v12 = transmissiona;
          goto LABEL_9;
        }
        mDistanceFilterCustomLevel = (float)(mDistance - mMinDistance) / (float)(mMaxDistance - mMinDistance);
      }
      if ( mDistanceFilterCustomLevel > 0.0 )
      {
        v19 = (float)(1.0 - mDistanceFilterCustomLevel) * (float)(1.0 - mDistanceFilterCustomLevel);
        v26 = mDistanceFilterCustomLevel * mDistanceFilterCustomLevel;
LABEL_21:
        transmission = v12;
        FMOD::DSPI::setBypass(mDSPHighPass, 0);
        mDistanceFilterCentreFreq_low = (__m128i)LODWORD(this->mParent->mDistanceFilterCentreFreq);
        *(float *)mDistanceFilterCentreFreq_low.m128i_i32 = (float)((float)(*(float *)mDistanceFilterCentreFreq_low.m128i_i32
                                                                          - 10.0)
                                                                  * v26)
                                                          + 10.0;
        FMOD::DSPI::setParameterFloat(this->mDSPHighPass, 0, mDistanceFilterCentreFreq_low, v8);
        mDSPLowPass = this->mDSPLowPass;
        *(_QWORD *)&v8 = LODWORD(v8);
        v12 = transmission;
        goto LABEL_22;
      }
      goto LABEL_31;
    }
  }
  mDistanceFilterCustomLevel = 0.0;
LABEL_9:
  if ( v12 < 1.0 )
  {
    v19 = (float)(1.0 - mDistanceFilterCustomLevel) * (float)(1.0 - mDistanceFilterCustomLevel);
LABEL_22:
    distance_filtering = v12;
    FMOD::DSPI::setBypass(mDSPLowPass, 0);
    v21 = (__m128i)0x46AC4400u;
    *(float *)v21.m128i_i32 = fminf(
                                (float)((float)(22050.0 - this->mParent->mDistanceFilterCentreFreq) * v19)
                              + this->mParent->mDistanceFilterCentreFreq,
                                (float)(distance_filtering * 22050.0) * distance_filtering);
    FMOD::DSPI::setParameterFloat(this->mDSPLowPass, 0, v21, v8);
    mParent = this->mParent;
    mFlags = mParent->mFlags;
    if ( (mFlags & 0x200000) != 0 )
      goto LABEL_23;
    goto LABEL_12;
  }
  FMOD::DSPI::setBypass(mDSPLowPass, 1);
  mParent = this->mParent;
  mFlags = mParent->mFlags;
LABEL_11:
  if ( (mFlags & 0x200000) != 0 )
  {
LABEL_23:
    v15 = 1;
    v16 = 64;
    return FMOD::DSPFader::setMix(mDSPFader, *(float *)&v8, v16, (HIWORD(this->mFlags) ^ 1) & 1, v15);
  }
LABEL_12:
  mChannelGroupParent = mParent->mChannelGroupParent;
  if ( mChannelGroupParent && (mChannelGroupParent->mFlags & 0x10) != 0 )
  {
    v15 = 0;
    v16 = 0;
  }
  else
  {
    v22 = mFlags;
    v15 = 0;
    v16 = (v22 & 0xC0020) == 0 ? 0x40 : 0;
  }
  return FMOD::DSPFader::setMix(mDSPFader, *(float *)&v8, v16, (HIWORD(this->mFlags) ^ 1) & 1, v15);
}


// Address: 0x2257dd0 | Name: _ZN4FMOD15ChannelSoftware15updateReverbMixEPNS_14ReverbPhysicalEf
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::updateReverbMix(
        FMOD::ChannelSoftware *const this,
        FMOD::ReverbPhysical *reverb,
        float a3,
        float volume)
{
  FMOD::ChannelI *mParent; // rax
  FMOD::FMOD_CHANNELCONTROL_FLAG mFlags; // edx
  __int64 mInstance; // rsi
  FMOD::DSPConnectionI *v7; // r8
  FMOD::ChannelGroupI *mChannelGroupParent; // rcx
  float m3DLevel; // xmm3_4
  float v10; // xmm2_4
  float v11; // xmm3_4
  float v12; // xmm1_4
  FMOD::SoundI *mSound; // rax
  float v14; // xmm2_4
  FMOD::SoundGroupI *mSoundGroup; // rax
  float v16; // xmm0_4
  bool v17; // cl
  unsigned int v18; // esi

  if ( !reverb )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mParent = this->mParent;
  mFlags = mParent->mFlags;
  if ( (mFlags & 2) != 0 )
    a3 = 0.0;
  if ( !reverb->mDSP )
    return FMOD_RESULT::FMOD_OK_0;
  mInstance = reverb->mInstance;
  v7 = mParent->mReverbConnection[mInstance];
  if ( !v7 )
    return FMOD_RESULT::FMOD_OK_0;
  mChannelGroupParent = mParent->mChannelGroupParent;
  m3DLevel = mParent->m3DLevel;
  v10 = 1.0 - m3DLevel;
  v11 = m3DLevel * mParent->mVolume3D;
  v12 = (float)((float)((float)((float)(1.0 - mParent->mReverbOcclusion) * (float)(1.0 - mParent->mUserReverbOcclusion))
                      * mChannelGroupParent->mRealReverbOcclusionVolume)
              * mParent->mReverbLevel[mInstance])
      * mParent->mSoundGroupFadeVolume;
  mSound = this->mSound;
  v14 = (float)((float)(v10 + v11) * v12) * mChannelGroupParent->mAudibility;
  if ( mSound )
  {
    mSoundGroup = mSound->mSoundGroup;
    if ( mSoundGroup )
      v14 = v14 * mSoundGroup->mVolume;
  }
  v16 = a3 * v14;
  if ( (mFlags & 0x200000) != 0 )
  {
    v17 = 1;
    v18 = 64;
  }
  else if ( (mChannelGroupParent->mFlags & 0x10) != 0 )
  {
    v17 = 0;
    v18 = 0;
  }
  else
  {
    v17 = 0;
    v18 = (mFlags & 0xC0020) == 0 ? 0x40 : 0;
  }
  return FMOD::DSPConnectionI::setMix(v7, v16, v18, (HIWORD(this->mFlags) ^ 1) & 1, v17);
}


// Address: 0x2257f00 | Name: _ZN4FMOD15ChannelSoftware9setVolumeEf
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setVolume(FMOD::ChannelSoftware *const this, float a2, float volume)
{
  FMOD_RESULT_0 result; // eax
  int v4; // ebp

  if ( SLOBYTE(this->mFlags) < 0 )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD::ChannelSoftware::updateDirectMix(this, a2, volume);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( !this->mDSPReverb )
      return FMOD_RESULT::FMOD_OK_0;
    v4 = 0;
    while ( 1 )
    {
      result = FMOD::ChannelSoftware::updateReverbMix(
                 this,
                 (FMOD::ReverbPhysical *)((char *)&stru_12498 + (unsigned __int64)this->mSystem + 24 * v4),
                 a2,
                 volume);
      if ( result )
        break;
      if ( ++v4 == 4 )
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2257f70 | Name: _ZN4FMOD15ChannelSoftware11addToReverbEPNS_4DSPIEi
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::addToReverb(
        FMOD::ChannelSoftware *const this,
        FMOD::DSPI *dsptarget,
        int instance)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *mDSP; // rdi
  __int64 v6; // rbp
  FMOD::DSPConnectionI *connection; // [rsp+0h] [rbp-20h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsptarget )
  {
    mDSP = this->mSystem->mReverb[instance].mDSP;
    if ( !mDSP )
      return FMOD_RESULT::FMOD_OK_0;
    v6 = instance + 42LL;
    connection = (FMOD::DSPConnectionI *)*((_QWORD *)&this->mParent->_vptr_ChannelControlI + v6);
    if ( connection )
      return FMOD_RESULT::FMOD_OK_0;
    result = FMOD::DSPI::addInput(
               mDSP,
               dsptarget,
               &connection,
               FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_SEND_0,
               0,
               0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      *((_QWORD *)&this->mParent->_vptr_ChannelControlI + v6) = connection;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2257ff0 | Name: _ZN4FMOD15ChannelSoftware5allocEv
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::alloc(FMOD::ChannelSoftware *const this)
{
  FMOD::DSPI *mDSPTail; // rbp
  FMOD_RESULT_0 result; // eax
  FMOD::DSPI *v4; // rdi
  FMOD::DSPI *v5; // rdi
  bool v6; // zf
  FMOD::DSPI *mDSPLowPass; // rdi
  FMOD::DSPI *mDSPHighPass; // rdi
  FMOD::SoundI *mSound; // rsi
  FMOD::DSPI *v10; // rdi
  FMOD::DSPI *v11; // rdi
  FMOD::DSPI *v12; // rax
  FMOD::DSPI *v13; // rax
  FMOD::DSPI *v14; // rdi
  FMOD::ChannelI *v15; // rax
  FMOD::DSPSource *v16; // rdi
  FMOD::SoundI *v17; // rsi
  int (**vptr_DSPI)(...); // rax
  FMOD::DSPI *v19; // rax
  FMOD::ChannelI *mParent; // rdx
  FMOD::DSPI *v21; // rax
  FMOD::ChannelI *v22; // rdx
  FMOD::DSPCodec *mDSPCodec; // rsi
  FMOD::DSPI *v24; // rdi
  int v25; // ebp
  FMOD::DSPCodecPool *pool; // [rsp+0h] [rbp-28h] BYREF
  FMOD::DSPSource *dspsource; // [rsp+8h] [rbp-20h] BYREF

  mDSPTail = this->mParent->mDSPTail;
  result = FMOD::ChannelReal::alloc(this);
  if ( result )
    return result;
  if ( (this->mMode & 0x200) == 0 )
  {
    v6 = (this->mFlags & 0x10000) == 0;
    this->mDSPCodec = 0;
    if ( !v6 )
      this->mDSPWaveTable.mJob.mFlags |= 0x400u;
    mDSPLowPass = this->mDSPLowPass;
    if ( mDSPLowPass )
    {
      result = FMOD::DSPI::disconnectFrom(mDSPLowPass, 0, 0, FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
      if ( result )
        return result;
    }
    mDSPHighPass = this->mDSPHighPass;
    if ( mDSPHighPass )
    {
      result = FMOD::DSPI::disconnectFrom(mDSPHighPass, 0, 0, FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
      if ( result )
        return result;
    }
    result = FMOD::DSPI::disconnectFrom(
               &this->mDSPWaveTable,
               0,
               0,
               FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
    if ( result )
      return result;
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelSoftware *const, _QWORD, _QWORD))this->_vptr_ChannelReal + 18))(
               this,
               this->mSound->mLoopStart,
               this->mSound->mLoopLength);
    if ( result )
      return result;
    mSound = this->mSound;
    this->mMinFrequency = -this->mMaxFrequency;
    FMOD::DSPSource::setup(&this->mDSPWaveTable, mSound, this);
    v10 = this->mDSPLowPass;
    if ( v10 )
      FMOD::DSPI::setActive(v10, 0, 1);
    v11 = this->mDSPHighPass;
    if ( v11 )
      FMOD::DSPI::setActive(v11, 0, 1);
    v12 = this->mDSPLowPass;
    if ( v12 )
    {
      v12->mChannelOwner = this->mParent;
      result = FMOD::DSPI::addInput(
                 mDSPTail,
                 this->mDSPLowPass,
                 0,
                 FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                 0,
                 0);
      if ( result )
        return result;
      v13 = this->mDSPHighPass;
      if ( v13 )
      {
        v13->mChannelOwner = this->mParent;
        result = FMOD::DSPI::addInput(
                   this->mDSPLowPass,
                   this->mDSPHighPass,
                   0,
                   FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                   0,
                   0);
        if ( result )
          return result;
        v14 = this->mDSPHighPass;
        this->mDSPWaveTable.mChannelOwner = this->mParent;
      }
      else
      {
        v14 = this->mDSPLowPass;
        this->mDSPWaveTable.mChannelOwner = this->mParent;
      }
      result = FMOD::DSPI::addInput(
                 v14,
                 &this->mDSPWaveTable,
                 0,
                 FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                 0,
                 0);
      if ( result )
        return result;
    }
    else
    {
      this->mDSPWaveTable.mChannelOwner = this->mParent;
      result = FMOD::DSPI::addInput(
                 mDSPTail,
                 &this->mDSPWaveTable,
                 0,
                 FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                 0,
                 0);
      if ( result )
        return result;
    }
    goto LABEL_29;
  }
  v4 = this->mDSPLowPass;
  if ( v4 )
  {
    result = FMOD::DSPI::disconnectFrom(v4, 0, 0, FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
    if ( result )
      return result;
  }
  v5 = this->mDSPHighPass;
  if ( v5 )
  {
    result = FMOD::DSPI::disconnectFrom(v5, 0, 0, FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
    if ( result )
      return result;
  }
  if ( this->mDSPWaveTable.mSound )
  {
    result = FMOD::DSPI::disconnectFrom(
               &this->mDSPWaveTable,
               0,
               0,
               FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0);
    if ( result )
      return result;
  }
  result = FMOD::SystemI::DSPCodecPoolGet(this->mSystem, this->mSound->mCodec->mDescription.mPoolType, &pool);
  if ( result )
    return result;
  result = FMOD::DSPCodecPool::alloc(pool, &dspsource);
  if ( result )
    return result;
  v16 = dspsource;
  v17 = this->mSound;
  vptr_DSPI = dspsource->_vptr_DSPI;
  this->mDSPCodec = (FMOD::DSPCodec *)dspsource;
  result = vptr_DSPI[4](v16, v17, this);
  if ( result )
    return result;
  if ( this->mMinFrequency < 100.0 )
    this->mMinFrequency = FMOD::ChannelReal::DEFAULT_MIN_FREQUENCY;
  v19 = this->mDSPLowPass;
  mParent = this->mParent;
  if ( !v19 )
  {
    this->mDSPCodec->mChannelOwner = mParent;
    result = FMOD::DSPI::addInput(
               mDSPTail,
               this->mDSPCodec,
               0,
               FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
               0,
               0);
    if ( result )
      return result;
    goto LABEL_29;
  }
  v19->mChannelOwner = mParent;
  result = FMOD::DSPI::addInput(
             mDSPTail,
             this->mDSPLowPass,
             0,
             FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
             0,
             0);
  if ( result )
    return result;
  v21 = this->mDSPHighPass;
  v22 = this->mParent;
  if ( v21 )
  {
    v21->mChannelOwner = v22;
    result = FMOD::DSPI::addInput(
               this->mDSPLowPass,
               this->mDSPHighPass,
               0,
               FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
               0,
               0);
    if ( result )
      return result;
    this->mDSPCodec->mChannelOwner = this->mParent;
    mDSPCodec = this->mDSPCodec;
    v24 = this->mDSPHighPass;
  }
  else
  {
    this->mDSPCodec->mChannelOwner = v22;
    mDSPCodec = this->mDSPCodec;
    v24 = this->mDSPLowPass;
  }
  result = FMOD::DSPI::addInput(v24, mDSPCodec, 0, FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0, 0, 0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
LABEL_29:
    if ( (this->mFlags & 0x10000) != 0 )
    {
LABEL_30:
      v15 = this->mParent;
      this->mFinishTick = -1;
      this->mChannelGroupAudibility = v15->mChannelGroupParent->mAudibility;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *, __int64, FMOD::DSPI **))this->mParent->_vptr_ChannelControlI
                + 36))(
                 this->mParent,
                 4294967293LL,
                 &this->mDSPReverb);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v25 = 0;
        while ( 1 )
        {
          result = FMOD::ChannelSoftware::addToReverb(this, this->mDSPReverb, v25);
          if ( result )
            break;
          if ( ++v25 == 4 )
            goto LABEL_30;
        }
      }
    }
  }
  return result;
}


// Address: 0x2258470 | Name: _ZN4FMOD15ChannelSoftware5allocEPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::alloc(FMOD::ChannelSoftware *const this, FMOD::DSPI *dsp)
{
  FMOD::ChannelI *mParent; // rax
  FMOD::DSPI *mDSPTail; // r12
  FMOD_RESULT_0 result; // eax
  FMOD_DSP_PROCESS_CALLBACK mProcess; // rax
  __int64 mChannels; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *Description; // rax
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 (*mCommand)(FMOD_DSP_STATE *, FMOD::FMOD_DSP_COMMAND_TYPE, void *, void *); // rax
  FMOD::DSPI *v11; // rdi
  FMOD::DSPI *mDSPLowPass; // rdi
  FMOD::DSPI *mDSPHighPass; // rdi
  int v14; // r12d
  FMOD::DSPResampler *mDSPResampler; // rdi
  unsigned int mLoopStart; // edx
  FMOD::DSPResampler_NODMA *mNoDMA; // rax
  FMOD::ChannelI *v18; // rax
  FMOD_CHANNELMASK outmask_result; // [rsp+Ch] [rbp-8Ch] BYREF
  FMOD::DSPI *channelgroup_dsphead; // [rsp+10h] [rbp-88h] BYREF
  FMOD::DSPI *dspresampler; // [rsp+18h] [rbp-80h] BYREF
  FMOD::DSPResampler_Param resampler_param; // [rsp+20h] [rbp-78h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_EX resampler_desc; // [rsp+30h] [rbp-68h] BYREF

  mParent = this->mParent;
  dspresampler = 0;
  mDSPTail = mParent->mDSPTail;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( dsp )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, _QWORD, FMOD::DSPI **))this->mSystem->mMasterChannelGroup->_vptr_ChannelControlI
              + 36))(
               this->mSystem->mMasterChannelGroup,
               0,
               &channelgroup_dsphead);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( dsp == channelgroup_dsphead )
      {
        this->mDSP = 0;
        LOBYTE(result) = 5;
        return result;
      }
      result = FMOD::ChannelReal::alloc(this);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        mProcess = dsp->mProcess;
        this->mDSPCodec = 0;
        if ( mProcess )
        {
          resampler_desc.mDescription = (const FMOD_DSP_DESCRIPTION *)(&dword_0 + 1);
          *(_QWORD *)&resampler_desc.mSize = &outmask_result;
          outmask_result = 0;
          resampler_param.blocklen = 0;
          *(_QWORD *)(&resampler_desc.mHandle + 1) = 0;
          resampler_desc.mParameter = 0;
          resampler_desc.mName = (const char *)&resampler_param;
          dsp->mState.instance = dsp;
          result = mProcess(&dsp->mState, 0, 0, (FMOD_DSP_BUFFER_ARRAY *)&resampler_desc, 0, FMOD_DSP_PROCESS_QUERY);
          if ( result != FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0
            && result != FMOD_RESULT::FMOD_ERR_DSP_DONTPROCESS_0
            && result )
          {
            return result;
          }
          LOWORD(mChannels) = resampler_param.blocklen;
          dsp->mDescription.mChannels = resampler_param.blocklen;
        }
        else
        {
          mChannels = dsp->mDescription.mChannels;
        }
        if ( !(_WORD)mChannels )
          dsp->mDescription.mChannels = 1;
        Description = FMOD::DSPResampler::getDescriptionEx();
        mSystem = this->mSystem;
        resampler_desc.mDescription = Description->mDescription;
        resampler_desc.mName = Description->mName;
        *(_QWORD *)&resampler_desc.mSize = *(_QWORD *)&Description->mSize;
        *(_QWORD *)(&resampler_desc.mHandle + 1) = *(_QWORD *)(&Description->mHandle + 1);
        resampler_desc.mParameter = Description->mParameter;
        resampler_desc.mModule = Description->mModule;
        *(_QWORD *)&resampler_desc.mChannels = *(_QWORD *)&Description->mChannels;
        mCommand = Description->mCommand;
        resampler_param.blocklen = 0;
        resampler_param.format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_NONE_0;
        resampler_param.allocbuffer = 1;
        resampler_desc.mParameter = &resampler_param;
        resampler_desc.mCommand = mCommand;
        resampler_desc.mChannels = dsp->mDescription.mChannels;
        resampler_param.channels = resampler_desc.mChannels;
        result = FMOD::SystemI::createDSP(mSystem, &resampler_desc, 0, &dspresampler, 1);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          v11 = dspresampler;
          this->mDSPResampler = (FMOD::DSPResampler *)dspresampler;
          result = FMOD::DSPI::setUserData(v11, this);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            mDSPLowPass = this->mDSPLowPass;
            this->mDSPResampler->mTargetFrequency = (float)this->mSystem->mDSPSampleRate;
            this->mMinFrequency = 0.0;
            if ( !mDSPLowPass
              || (result = FMOD::DSPI::disconnectFrom(
                             mDSPLowPass,
                             0,
                             0,
                             FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0)) == FMOD_RESULT::FMOD_OK_0 )
            {
              mDSPHighPass = this->mDSPHighPass;
              if ( (!mDSPHighPass
                 || (result = FMOD::DSPI::disconnectFrom(
                                mDSPHighPass,
                                0,
                                0,
                                FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0)) == FMOD_RESULT::FMOD_OK_0)
                && (!this->mDSPWaveTable.mSound
                 || (result = FMOD::DSPI::disconnectFrom(
                                &this->mDSPWaveTable,
                                0,
                                0,
                                FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_MAX_0)) == FMOD_RESULT::FMOD_OK_0) )
              {
                FMOD::DSPWaveTable::resetInternal(&this->mDSPWaveTable);
                this->mDSPResampler->mChannelOwner = this->mParent;
                result = FMOD::DSPI::addInput(
                           mDSPTail,
                           this->mDSPResampler,
                           0,
                           FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                           0,
                           0);
                if ( result == FMOD_RESULT::FMOD_OK_0 )
                {
                  if ( (this->mFlags & 0x10000) != 0 )
                  {
LABEL_29:
                    mDSPResampler = this->mDSPResampler;
                    mLoopStart = this->mLoopStart;
                    mDSPResampler->mJobHead = &dsp->mJob;
                    mDSPResampler->mLength = this->mLength;
                    mDSPResampler->mLoopCount = this->mLoopCount;
                    mNoDMA = mDSPResampler->mNoDMA;
                    mNoDMA->mLoopStart = mLoopStart;
                    mNoDMA->mLoopLength = this->mLoopLength;
                    mNoDMA->mMode = this->mMode;
                    LODWORD(mNoDMA) = dsp->mState.source_speakermode;
                    mDSPResampler->mNewLoopCount = -2;
                    mDSPResampler->mState.source_speakermode = (int)mNoDMA;
                    dsp->mJob.mInfo.mMixOffset = 0;
                    dsp->mJob.mInfo.mMixLength = mDSPResampler->mResampleBlockLength;
                    (*((void (__fastcall **)(FMOD::DSPResampler *, _QWORD, _QWORD, _QWORD))mDSPResampler->_vptr_DSPI + 5))(
                      mDSPResampler,
                      0,
                      0,
                      0);
                    FMOD::DSPI::setActive(this->mDSPResampler, 0, 1);
                    FMOD::DSPI::setActive(dsp, 0, 1);
                    v18 = this->mParent;
                    this->mFinishTick = -1;
                    this->mChannelGroupAudibility = v18->mChannelGroupParent->mAudibility;
                    return FMOD_RESULT::FMOD_OK_0;
                  }
                  else
                  {
                    result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *, __int64, FMOD::DSPI **))this->mParent->_vptr_ChannelControlI
                              + 36))(
                               this->mParent,
                               4294967293LL,
                               &this->mDSPReverb);
                    if ( result == FMOD_RESULT::FMOD_OK_0 )
                    {
                      v14 = 0;
                      while ( 1 )
                      {
                        result = FMOD::ChannelSoftware::addToReverb(this, this->mDSPReverb, v14);
                        if ( result )
                          break;
                        if ( ++v14 == 4 )
                          goto LABEL_29;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x2258870 | Name: _ZN4FMOD15ChannelSoftware19setReverbPropertiesEif
FMOD_RESULT_0 __fastcall FMOD::ChannelSoftware::setReverbProperties(
        FMOD::ChannelSoftware *const this,
        int instance,
        double a3,
        float wet)
{
  __int64 v6; // rbx
  FMOD::SystemI *mSystem; // rdi
  FMOD::ChannelI *mParent; // rax
  __int64 v9; // r14
  FMOD::DSPConnectionI *v10; // r13
  FMOD_RESULT_0 result; // eax
  FMOD::DSPQueueCmd_Disconnect *v12; // rsi
  FMOD::SystemI *v13; // rdi
  FMOD::DSPI *mDSPReverb; // rsi
  FMOD::DSPQueueCmd_Disconnect *cmd; // [rsp+8h] [rbp-30h] BYREF

  v6 = instance;
  mSystem = this->mSystem;
  mParent = this->mParent;
  if ( !mSystem->mReverb[instance].mDSP )
  {
    mParent->mReverbConnection[instance] = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  v9 = instance + 42LL;
  v10 = (FMOD::DSPConnectionI *)*((_QWORD *)&mParent->_vptr_ChannelControlI + v9);
  if ( *(float *)&a3 == 0.0 )
  {
    result = FMOD_RESULT::FMOD_OK_0;
    if ( v10 )
    {
      result = FMOD::SystemI::lockDSPQueueCmd(mSystem, (void **)&cmd, 16, 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v12 = cmd;
        v13 = this->mSystem;
        *(_BYTE *)&cmd->FMOD::DSPQueueCmd = 3;
        v12->mConnection = v10;
        result = FMOD::SystemI::unlockDSPQueueCmd(v13, v12, 1);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          *((_QWORD *)&this->mParent->_vptr_ChannelControlI + v9) = 0;
          this->mDSPReverb = 0;
        }
      }
    }
  }
  else
  {
    if ( v10 )
      return FMOD::ChannelSoftware::updateReverbMix(
               this,
               (FMOD::ReverbPhysical *)((char *)stru_12498 + (_QWORD)mSystem + 24 * v6),
               mParent->mVolume,
               wet);
    mDSPReverb = this->mDSPReverb;
    if ( !mDSPReverb )
    {
      result = (*((unsigned int (__fastcall **)(FMOD::ChannelI *, __int64, FMOD::DSPI **, double, float))mParent->_vptr_ChannelControlI
                + 36))(
                 this->mParent,
                 4294967293LL,
                 &this->mDSPReverb,
                 a3,
                 wet);
      if ( result )
        return result;
      mDSPReverb = this->mDSPReverb;
    }
    result = FMOD::ChannelSoftware::addToReverb(this, mDSPReverb, instance);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mParent = this->mParent;
      mSystem = this->mSystem;
      return FMOD::ChannelSoftware::updateReverbMix(
               this,
               (FMOD::ReverbPhysical *)((char *)stru_12498 + (_QWORD)mSystem + 24 * v6),
               mParent->mVolume,
               wet);
    }
  }
  return result;
}


