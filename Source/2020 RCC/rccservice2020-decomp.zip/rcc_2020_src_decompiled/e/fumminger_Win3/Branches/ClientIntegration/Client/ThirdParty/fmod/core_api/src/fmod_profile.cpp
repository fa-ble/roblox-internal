// Address: 0x22596d0 | Name: _ZN4FMOD7Profile30clientStartRequestingDataAsyncEPNS_13ProfileClientEhh
FMOD_RESULT_0 __fastcall FMOD::Profile::clientStartRequestingDataAsync(
        FMOD::Profile *const this,
        FMOD::ProfileClient *client,
        unsigned __int8 type,
        unsigned __int8 subtype)
{
  FMOD::LinkedListNode *mNodeNext; // r13
  void **p_mNodeData; // r9
  void **v7; // r14
  FMOD_RESULT_0 result; // eax
  unsigned int subtypea; // [rsp+8h] [rbp-40h]
  unsigned int typea; // [rsp+Ch] [rbp-3Ch]

  mNodeNext = this->mModuleHead.mNodeNext;
  subtypea = subtype;
  typea = type;
  if ( mNodeNext == &this->mModuleHead )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    p_mNodeData = &mNodeNext[-1].mNodeData;
    if ( !mNodeNext )
      p_mNodeData = 0;
    v7 = p_mNodeData;
    if ( (*(unsigned __int8 (__fastcall **)(void **))*p_mNodeData)(p_mNodeData) == type )
    {
      result = (*((unsigned int (__fastcall **)(void **, FMOD::ProfileClient *, _QWORD, _QWORD))*v7 + 10))(
                 v7,
                 client,
                 typea,
                 subtypea);
      if ( result )
        break;
    }
    mNodeNext = mNodeNext->mNodeNext;
    if ( mNodeNext == &this->mModuleHead )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2259770 | Name: _ZN4FMOD7Profile29clientStopRequestingDataAsyncEPNS_13ProfileClientEhh
FMOD_RESULT_0 __fastcall FMOD::Profile::clientStopRequestingDataAsync(
        FMOD::Profile *const this,
        FMOD::ProfileClient *client,
        unsigned __int8 type,
        unsigned __int8 subtype)
{
  FMOD::LinkedListNode *mNodeNext; // r13
  void **p_mNodeData; // r9
  void **v7; // r14
  FMOD_RESULT_0 result; // eax
  unsigned int subtypea; // [rsp+8h] [rbp-40h]
  unsigned int typea; // [rsp+Ch] [rbp-3Ch]

  mNodeNext = this->mModuleHead.mNodeNext;
  subtypea = subtype;
  typea = type;
  if ( mNodeNext == &this->mModuleHead )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    p_mNodeData = &mNodeNext[-1].mNodeData;
    if ( !mNodeNext )
      p_mNodeData = 0;
    v7 = p_mNodeData;
    if ( (*(unsigned __int8 (__fastcall **)(void **))*p_mNodeData)(p_mNodeData) == type )
    {
      result = (*((unsigned int (__fastcall **)(void **, FMOD::ProfileClient *, _QWORD, _QWORD))*v7 + 11))(
                 v7,
                 client,
                 typea,
                 subtypea);
      if ( result )
        break;
    }
    mNodeNext = mNodeNext->mNodeNext;
    if ( mNodeNext == &this->mModuleHead )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2259810 | Name: _ZN4FMOD7Profile13disconnectAllEv
FMOD_RESULT_0 __fastcall FMOD::Profile::disconnectAll(FMOD::Profile *const this)
{
  FMOD::LinkedListNode *p_mClientHead; // rbp
  FMOD_OS_CRITICALSECTION *mCrit; // r12
  FMOD::ProfileClient *mNodeNext; // rbx
  FMOD_RESULT_0 v4; // eax
  FMOD_RESULT_0 v5; // ebx

  p_mClientHead = &this->mClientHead;
  mCrit = this->mCrit;
  FMOD_OS_CriticalSection_Enter(mCrit);
  mNodeNext = (FMOD::ProfileClient *)this->mClientHead.mNodeNext;
  if ( p_mClientHead->mNodeNext == p_mClientHead )
  {
LABEL_6:
    FMOD_OS_CriticalSection_Leave(mCrit);
    return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    while ( 1 )
    {
      v4 = FMOD::ProfileClient::markDead(mNodeNext);
      if ( v4 )
        break;
      mNodeNext = (FMOD::ProfileClient *)mNodeNext->mNodeNext;
      if ( mNodeNext == p_mClientHead )
        goto LABEL_6;
    }
    v5 = v4;
    FMOD_OS_CriticalSection_Leave(mCrit);
    return v5;
  }
}


// Address: 0x2259880 | Name: _ZN4FMOD7Profile11requestDataEhhjPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::Profile::requestData(
        FMOD::Profile *const this,
        unsigned __int8 type,
        unsigned __int8 subtype,
        unsigned int updatetime,
        FMOD::ProfileClient *toclient)
{
  FMOD_RESULT_0 v7; // ebx
  FMOD::LinkedListNode *p_mClientHead; // r12
  FMOD::ProfileClient *mNodeNext; // r15
  FMOD_RESULT_0 v11; // eax
  FMOD_OS_CRITICALSECTION *crit; // [rsp+8h] [rbp-60h]
  FMOD::ProfilePacketHeader packet; // [rsp+10h] [rbp-58h] BYREF
  unsigned __int8 typea; // [rsp+1Ch] [rbp-4Ch]
  unsigned __int8 v15; // [rsp+1Dh] [rbp-4Bh]
  unsigned int v16; // [rsp+1Eh] [rbp-4Ah]

  *(_DWORD *)&packet.type = 0;
  *(_QWORD *)&packet.size = 18;
  typea = type;
  v15 = subtype;
  v16 = updatetime;
  if ( toclient )
    return FMOD::ProfileClient::writePacket(toclient, &packet);
  p_mClientHead = &this->mClientHead;
  crit = this->mCrit;
  FMOD_OS_CriticalSection_Enter(crit);
  mNodeNext = (FMOD::ProfileClient *)this->mClientHead.mNodeNext;
  if ( p_mClientHead->mNodeNext == p_mClientHead )
  {
LABEL_10:
    v7 = FMOD_RESULT::FMOD_OK_0;
    FMOD_OS_CriticalSection_Leave(crit);
  }
  else
  {
    while ( 1 )
    {
      v11 = FMOD::ProfileClient::writePacket(mNodeNext, &packet);
      if ( v11 )
        break;
      v11 = FMOD::ProfileClient::requestDataType(mNodeNext, type, subtype, updatetime);
      if ( v11 )
        break;
      mNodeNext = (FMOD::ProfileClient *)mNodeNext->mNodeNext;
      if ( mNodeNext == p_mClientHead )
        goto LABEL_10;
    }
    v7 = v11;
    FMOD_OS_CriticalSection_Leave(crit);
  }
  return v7;
}


// Address: 0x2259970 | Name: _ZN4FMOD7Profile16disconnectClientEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::Profile::disconnectClient(FMOD::Profile *const this, FMOD::ProfileClient *client)
{
  if ( client )
    return FMOD::ProfileClient::markDead(client);
  else
    return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
}


// Address: 0x2259990 | Name: _ZN4FMOD7Profile14registerModuleEPNS_13ProfileModuleE
FMOD_RESULT_0 __fastcall FMOD::Profile::registerModule(FMOD::Profile *const this, FMOD::ProfileModule_0 *module)
{
  FMOD_RESULT_0 v2; // r12d
  FMOD_OS_CRITICALSECTION *mCrit; // r13
  FMOD::LinkedListNode *p_mClientHead; // rax

  v2 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( module )
  {
    mCrit = this->mCrit;
    LOBYTE(v2) = 28;
    FMOD_OS_CriticalSection_Enter(mCrit);
    module->mNodePrev = this->mModuleHead.mNodePrev;
    module->mNodeNext = &this->mModuleHead;
    this->mModuleHead.mNodePrev = &module->FMOD::LinkedListNode;
    module->mNodePrev->FMOD::LinkedListNode::mNodeNext = &module->FMOD::LinkedListNode;
    p_mClientHead = &this->mClientHead;
    if ( p_mClientHead == p_mClientHead->mNodeNext && p_mClientHead == this->mClientHead.mNodePrev )
      v2 = FMOD_RESULT::FMOD_OK_0;
    FMOD_OS_CriticalSection_Leave(mCrit);
  }
  return v2;
}


// Address: 0x2259a10 | Name: _ZN4FMOD7Profile11writePacketEPNS_19ProfilePacketHeaderEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::Profile::writePacket(
        FMOD::Profile *const this,
        FMOD::ProfilePacketHeader *packet,
        FMOD::ProfileClient *toclient)
{
  FMOD_RESULT_0 result; // eax
  FMOD_OS_CRITICALSECTION *mCrit; // r14
  FMOD::ProfileClient *mNodeNext; // rbx
  FMOD_RESULT_0 v7; // r12d
  unsigned int currentTime[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  currentTime[0] = 0;
  result = FMOD_OS_Time_GetMs(currentTime);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    packet->timestamp = currentTime[0] - this->mInitialTimestamp;
    if ( toclient )
    {
      return FMOD::ProfileClient::writePacket(toclient, packet);
    }
    else
    {
      mCrit = this->mCrit;
      FMOD_OS_CriticalSection_Enter(mCrit);
      mNodeNext = (FMOD::ProfileClient *)this->mClientHead.mNodeNext;
      if ( mNodeNext == &this->mClientHead )
      {
LABEL_10:
        FMOD_OS_CriticalSection_Leave(mCrit);
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        while ( 1 )
        {
          v7 = FMOD::ProfileClient::writePacket(mNodeNext, packet);
          if ( v7 )
            break;
          mNodeNext = (FMOD::ProfileClient *)mNodeNext->mNodeNext;
          if ( mNodeNext == &this->mClientHead )
            goto LABEL_10;
        }
        FMOD_OS_CriticalSection_Leave(mCrit);
        return v7;
      }
    }
  }
  return result;
}


// Address: 0x2259ad0 | Name: _ZN4FMOD7Profile7connectEtPKc
FMOD_RESULT_0 __fastcall FMOD::Profile::connect(FMOD::Profile *const this, unsigned __int16 port, const char *ip_0)
{
  FMOD_RESULT_0 v3; // ebx
  unsigned __int16 v5; // ax
  FMOD_OS_CRITICALSECTION *mCrit; // r14
  FMOD::ProfileClient *v7; // rax
  FMOD::ProfileClient *v8; // r13
  FMOD::LinkedListNode *p_mModuleHead; // r12
  FMOD::LinkedListNode *mNodeNext; // rbp
  void **p_mNodeData; // rdx
  FMOD_RESULT_0 v12; // eax
  void *socket; // [rsp+8h] [rbp-40h] BYREF

  v3 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( !this->mListen )
  {
    v5 = 9264;
    socket = 0;
    if ( port )
      v5 = port;
    v3 = FMOD_OS_Net_Connect(ip_0, v5, 0, &socket);
    if ( v3 == FMOD_RESULT::FMOD_OK_0 )
    {
      mCrit = this->mCrit;
      FMOD_OS_CriticalSection_Enter(mCrit);
      v7 = (FMOD::ProfileClient *)FMOD::MemPool::alloc(
                                    off_286F358->gSystemMemPool,
                                    1392,
                                    "../../../core_api/src/fmod_profile.cpp",
                                    93,
                                    0,
                                    0);
      v8 = v7;
      if ( v7 )
      {
        FMOD::ProfileClient::ProfileClient(v7);
        v3 = FMOD::ProfileClient::init(v8, socket, this);
        if ( v3 == FMOD_RESULT::FMOD_OK_0 )
        {
          v8->mNodePrev = this->mClientHead.mNodePrev;
          p_mModuleHead = &this->mModuleHead;
          v8->mNodeNext = &this->mClientHead;
          this->mClientHead.mNodePrev = v8;
          v8->mNodePrev->FMOD::LinkedListNode::mNodeNext = v8;
          mNodeNext = this->mModuleHead.mNodeNext;
          if ( p_mModuleHead->mNodeNext == p_mModuleHead )
          {
LABEL_16:
            v3 = FMOD_RESULT::FMOD_OK_0;
          }
          else
          {
            while ( 1 )
            {
              p_mNodeData = &mNodeNext[-1].mNodeData;
              if ( !mNodeNext )
                p_mNodeData = 0;
              v12 = (*((unsigned int (__fastcall **)(void **, FMOD::ProfileClient *))*p_mNodeData + 8))(p_mNodeData, v8);
              if ( v12 )
                break;
              mNodeNext = mNodeNext->mNodeNext;
              if ( mNodeNext == p_mModuleHead )
                goto LABEL_16;
            }
            v3 = v12;
          }
        }
      }
      else
      {
        v3 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
      FMOD_OS_CriticalSection_Leave(mCrit);
    }
  }
  return v3;
}


// Address: 0x2259c10 | Name: _ZN4FMOD7ProfileC2Ev
void __fastcall FMOD::Profile::Profile(FMOD::Profile *const this)
{
  this->mClientHead.mNodeData = 0;
  this->mModuleHead.mNodeData = 0;
  this->mListenSocket = (void *)-1LL;
  this->mCrit = 0;
  this->mInitialTimestamp = 0;
  this->mListen = 1;
  this->_vptr_ProfileInterface = (int (**)(...))&off_29B2E10;
  this->mClientHead.mNodePrev = &this->mClientHead;
  this->mClientHead.mNodeNext = &this->mClientHead;
  this->mModuleHead.mNodePrev = &this->mModuleHead;
  this->mModuleHead.mNodeNext = &this->mModuleHead;
  this->mPort = 9264;
}


// Address: 0x2259c70 | Name: _ZN4FMOD7Profile4initEt
FMOD_RESULT_0 __fastcall FMOD::Profile::init(FMOD::Profile *const this, unsigned __int16 port)
{
  FMOD_RESULT_0 result; // eax

  if ( port )
    this->mPort = port;
  result = FMOD_Net_Init();
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_OS_CriticalSection_Create(&this->mCrit, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return FMOD_OS_Time_GetMs(&this->mInitialTimestamp);
  }
  return result;
}


// Address: 0x2259cb0 | Name: _ZNK4FMOD7Profile22allClientsReadyForDataERKNS_10PacketInfoEj
bool __fastcall FMOD::Profile::allClientsReadyForData(
        const FMOD::Profile *const this,
        const FMOD::PacketInfo *const info,
        unsigned int time)
{
  FMOD::LinkedListNode *p_mClientHead; // r12
  int v4; // ebp
  FMOD_OS_CRITICALSECTION *mCrit; // r14
  FMOD::LinkedListNode *mNodeNext; // rbx
  bool isDataRequested; // al
  const FMOD::ProfileClient *v8; // rbx
  int i; // r15d
  bool isReadyForData; // al
  bool v11; // bl

  p_mClientHead = &this->mClientHead;
  v4 = 0;
  mCrit = this->mCrit;
  FMOD_OS_CriticalSection_Enter(mCrit);
  mNodeNext = this->mClientHead.mNodeNext;
  if ( mNodeNext == &this->mClientHead )
    goto LABEL_8;
  do
  {
    isDataRequested = FMOD::ProfileClient::isDataRequested((const FMOD::ProfileClient *const)mNodeNext, info);
    mNodeNext = mNodeNext->mNodeNext;
    v4 -= !isDataRequested - 1;
  }
  while ( mNodeNext != p_mClientHead );
  if ( !v4 )
  {
LABEL_8:
    v11 = 0;
  }
  else
  {
    v8 = (const FMOD::ProfileClient *)this->mClientHead.mNodeNext;
    for ( i = 0; v8 != p_mClientHead; i -= !isReadyForData - 1 )
    {
      isReadyForData = FMOD::ProfileClient::isReadyForData(v8, info);
      v8 = (const FMOD::ProfileClient *)v8->mNodeNext;
    }
    v11 = v4 == i;
  }
  FMOD_OS_CriticalSection_Leave(mCrit);
  return v11;
}


// Address: 0x2259d60 | Name: _ZN4FMOD7Profile6updateEv
FMOD_RESULT_0 __fastcall FMOD::Profile::update(FMOD::Profile *const this)
{
  void *mListenSocket; // rdi
  FMOD_RESULT_0 v3; // eax
  FMOD_RESULT_0 Ms; // ebx
  FMOD::Profile *mNodeNext; // r14
  FMOD::LinkedListNode *p_mModuleHead; // r15
  char *p_mInitialTimestamp; // rbx
  FMOD_RESULT_0 v8; // eax
  FMOD::LinkedListNode *i; // rbx
  void **p_mNodeData; // rdi
  unsigned int v12; // edx
  __int64 v13; // rax
  FMOD_RESULT_0 v14; // eax
  FMOD::ProfileClient *v15; // rax
  FMOD::ProfileClient *v16; // r13
  FMOD_OS_CRITICALSECTION *mCrit; // rdi
  FMOD::Profile *k; // r12
  unsigned int *v19; // rdi
  FMOD_RESULT_0 v20; // eax
  FMOD::ProfilePacketHeader *v21; // rsi
  FMOD_RESULT_0 v22; // eax
  FMOD::LinkedListNode *v23; // r13
  FMOD::ProfilePacketHeader *j; // r14
  void **v25; // r8
  void **v26; // r12
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::ProfileClient *client; // [rsp+8h] [rbp-A0h]
  FMOD::ProfileClient *v29; // [rsp+28h] [rbp-80h]
  unsigned int currentTime; // [rsp+3Ch] [rbp-6Ch] BYREF
  FMOD::ProfilePacketHeader *packet[2]; // [rsp+40h] [rbp-68h] BYREF
  FMOD::ProfileRingBuffer::LockedBuffer lock; // [rsp+50h] [rbp-58h] BYREF

  if ( !this->mListen )
  {
LABEL_6:
    currentTime = 0;
    Ms = FMOD_OS_Time_GetMs(&currentTime);
    if ( Ms )
      return Ms;
    mNodeNext = (FMOD::Profile *)this->mModuleHead.mNodeNext;
    p_mModuleHead = &this->mModuleHead;
    currentTime -= this->mInitialTimestamp;
    if ( mNodeNext != (FMOD::Profile *)&this->mModuleHead )
    {
      do
      {
        p_mInitialTimestamp = 0;
        LOWORD(packet[0]) = 0;
        if ( mNodeNext )
          p_mInitialTimestamp = (char *)&mNodeNext[-1].mInitialTimestamp;
        v8 = (*(unsigned int (__fastcall **)(char *, FMOD::ProfilePacketHeader **))(*(_QWORD *)p_mInitialTimestamp + 24LL))(
               p_mInitialTimestamp,
               packet);
        if ( v8 )
          return v8;
        if ( LOBYTE(packet[0]) != 0xFF )
        {
          v12 = currentTime;
          do
          {
            if ( !FMOD::Profile::allClientsReadyForData(this, (const FMOD::PacketInfo *const)packet, v12) )
              break;
            lock.mLock = (FMOD_OS_CRITICALSECTION *)this;
            v13 = *(_QWORD *)p_mInitialTimestamp;
            LODWORD(lock.mPtr1) = 0;
            v8 = (*(unsigned int (__fastcall **)(char *, FMOD::ProfileRingBuffer::LockedBuffer *))(v13 + 32))(
                   p_mInitialTimestamp,
                   &lock);
            if ( v8 )
              return v8;
            if ( !LODWORD(lock.mPtr1) )
              break;
            v14 = (*(unsigned int (__fastcall **)(char *, FMOD::ProfilePacketHeader **))(*(_QWORD *)p_mInitialTimestamp
                                                                                       + 24LL))(
                    p_mInitialTimestamp,
                    packet);
            if ( v14 )
              return v14;
            v8 = FMOD_OS_Time_GetMs(&currentTime);
            if ( v8 )
              return v8;
            v12 = currentTime - this->mInitialTimestamp;
            currentTime = v12;
          }
          while ( LOBYTE(packet[0]) != 0xFF );
        }
        mNodeNext = (FMOD::Profile *)mNodeNext->_vptr_ProfileInterface;
      }
      while ( mNodeNext != (FMOD::Profile *)p_mModuleHead );
    }
    FMOD_OS_CriticalSection_Enter(this->mCrit);
    for ( client = (FMOD::ProfileClient *)this->mClientHead.mNodeNext; ; client = v29 )
    {
      if ( client == &this->mClientHead )
      {
        Ms = FMOD_RESULT::FMOD_OK_0;
        FMOD_OS_CriticalSection_Leave(this->mCrit);
        return Ms;
      }
      v29 = (FMOD::ProfileClient *)client->mNodeNext;
      v8 = FMOD::ProfileClient::update(client);
      if ( v8 )
        return v8;
      if ( client->mDead )
      {
        for ( i = this->mModuleHead.mNodeNext; i != p_mModuleHead; i = i->mNodeNext )
        {
          p_mNodeData = &i[-1].mNodeData;
          if ( !i )
            p_mNodeData = 0;
          v8 = (*((unsigned int (__fastcall **)(void **, FMOD::ProfileClient *))*p_mNodeData + 9))(p_mNodeData, client);
          if ( v8 )
            return v8;
        }
        mNodePrev = client->mNodePrev;
        mNodePrev->mNodeNext = client->mNodeNext;
        client->mNodeNext->mNodePrev = mNodePrev;
        client->mNodePrev = client;
        client->mNodeNext = client;
        v8 = FMOD::ProfileClient::release(client);
        if ( v8 )
          return v8;
      }
      else
      {
        while ( 1 )
        {
          memset(&lock, 0, sizeof(lock));
          v22 = FMOD::ProfileClient::receivePacket(client, packet, &lock);
          if ( v22 )
          {
LABEL_60:
            Ms = v22;
            if ( lock.mLock )
              FMOD_OS_CriticalSection_Leave(lock.mLock);
            return Ms;
          }
          if ( !packet[0] )
            break;
          v23 = this->mModuleHead.mNodeNext;
          if ( v23 == p_mModuleHead )
          {
            v21 = packet[0];
          }
          else
          {
            for ( j = packet[0]; ; j = packet[0] )
            {
              v25 = &v23[-1].mNodeData;
              if ( !v23 )
                v25 = 0;
              v26 = v25;
              if ( (*(unsigned __int8 (__fastcall **)(void **))*v25)(v25) == j->type )
                (*((void (__fastcall **)(void **, FMOD::ProfilePacketHeader *, FMOD::ProfileClient *))*v26 + 5))(
                  v26,
                  packet[0],
                  client);
              v23 = v23->mNodeNext;
              if ( v23 == p_mModuleHead )
                break;
            }
            v21 = packet[0];
          }
          v22 = FMOD::ProfileClient::finishReceivePacket(client, v21, &lock);
          if ( v22 )
            goto LABEL_60;
          if ( lock.mLock )
            FMOD_OS_CriticalSection_Leave(lock.mLock);
        }
        if ( lock.mLock )
          FMOD_OS_CriticalSection_Leave(lock.mLock);
      }
    }
  }
  mListenSocket = this->mListenSocket;
  if ( mListenSocket == (void *)-1LL )
  {
    Ms = FMOD_OS_Net_Listen(this->mPort, 1, &this->mListenSocket);
    if ( Ms )
      return Ms;
    mListenSocket = this->mListenSocket;
  }
  lock.mLock = 0;
  v3 = FMOD_OS_Net_Accept(mListenSocket, 0, (void **)&lock.mLock);
  if ( v3 )
  {
    if ( v3 != FMOD_RESULT::FMOD_ERR_NET_WOULD_BLOCK_0 )
    {
      FMOD_OS_Net_Close(this->mListenSocket);
      this->mListenSocket = (void *)-1LL;
    }
    goto LABEL_6;
  }
  v15 = (FMOD::ProfileClient *)FMOD::MemPool::alloc(
                                 off_286F358->gSystemMemPool,
                                 1392,
                                 "../../../core_api/src/fmod_profile.cpp",
                                 260,
                                 0,
                                 0);
  v16 = v15;
  if ( !v15 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  FMOD::ProfileClient::ProfileClient(v15);
  Ms = FMOD::ProfileClient::init(v16, lock.mLock, this);
  if ( Ms == FMOD_RESULT::FMOD_OK_0 )
  {
    FMOD_OS_CriticalSection_Enter(this->mCrit);
    mCrit = this->mCrit;
    v16->mNodePrev = this->mClientHead.mNodePrev;
    v16->mNodeNext = &this->mClientHead;
    this->mClientHead.mNodePrev = v16;
    v16->mNodePrev->FMOD::LinkedListNode::mNodeNext = v16;
    FMOD_OS_CriticalSection_Leave(mCrit);
    for ( k = (FMOD::Profile *)this->mModuleHead.mNodeNext;
          &this->mModuleHead != (FMOD::LinkedListNode *)k;
          k = (FMOD::Profile *)k->_vptr_ProfileInterface )
    {
      v19 = &k[-1].mInitialTimestamp;
      if ( !k )
        v19 = 0;
      v20 = (*(unsigned int (__fastcall **)(unsigned int *, FMOD::ProfileClient *))(*(_QWORD *)v19 + 64LL))(v19, v16);
      if ( v20 )
        return v20;
    }
    goto LABEL_6;
  }
  return Ms;
}


// Address: 0x225a1e0 | Name: _ZN4FMOD7Profile7releaseEv
FMOD_RESULT_0 __fastcall FMOD::Profile::release(FMOD::Profile *const this)
{
  FMOD_RESULT_0 result; // eax
  void *mListenSocket; // rdi
  FMOD::ProfileClient *i; // rdi
  FMOD::ProfileClient *mNodeNext; // rbx
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::LinkedListNode *v7; // rbx
  void **p_mNodeData; // rax
  FMOD::LinkedListNode **v9; // rcx
  FMOD_OS_CRITICALSECTION *mCrit; // rdi

  result = (*((unsigned int (__fastcall **)(FMOD::Profile *const))this->_vptr_ProfileInterface + 5))(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    this->mListen = 0;
    result = FMOD::Profile::update(this);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mListenSocket = this->mListenSocket;
      if ( mListenSocket != (void *)-1LL )
        FMOD_OS_Net_Close(mListenSocket);
      for ( i = (FMOD::ProfileClient *)this->mClientHead.mNodeNext; i != &this->mClientHead; i = mNodeNext )
      {
        mNodeNext = (FMOD::ProfileClient *)i->mNodeNext;
        mNodePrev = i->mNodePrev;
        mNodePrev->mNodeNext = i->mNodeNext;
        i->mNodeNext->mNodePrev = mNodePrev;
        i->mNodePrev = i;
        i->mNodeNext = i;
        result = FMOD::ProfileClient::release(i);
        if ( result )
          return result;
      }
      v7 = this->mModuleHead.mNodeNext;
      while ( v7 != &this->mModuleHead )
      {
        p_mNodeData = &v7[-1].mNodeData;
        if ( !v7 )
          p_mNodeData = 0;
        v7 = (FMOD::LinkedListNode *)p_mNodeData[1];
        v9 = (FMOD::LinkedListNode **)p_mNodeData[2];
        *v9 = v7;
        *((_QWORD *)p_mNodeData[1] + 1) = v9;
        p_mNodeData[2] = p_mNodeData + 1;
        p_mNodeData[1] = p_mNodeData + 1;
        result = (*((unsigned int (__fastcall **)(void **))*p_mNodeData + 2))(p_mNodeData);
        if ( result )
          return result;
      }
      mCrit = this->mCrit;
      if ( mCrit )
        FMOD_OS_CriticalSection_Free(mCrit, 0);
      result = FMOD_Net_Shutdown();
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_profile.cpp", 232);
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x225a300 | Name: _ZN4FMOD7Profile13createProfileEPPS0_bt
FMOD_RESULT_0 __fastcall FMOD::Profile::createProfile(FMOD::Profile **profile, bool listen, unsigned __int16 port)
{
  FMOD_RESULT_0 result; // eax
  FMOD::Profile *v5; // rax
  FMOD::Profile *v6; // rbx
  FMOD_RESULT_0 v7; // r12d

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( profile )
  {
    v5 = (FMOD::Profile *)FMOD::MemPool::alloc(
                            off_286F358->gSystemMemPool,
                            80,
                            "../../../core_api/src/fmod_profile.cpp",
                            24,
                            0,
                            0);
    v6 = v5;
    if ( v5 )
    {
      FMOD::Profile::Profile(v5);
      v6->mListen = listen;
      v7 = FMOD::Profile::init(v6, port);
      if ( v7 )
      {
        FMOD::Profile::release(v6);
        return v7;
      }
      else
      {
        *profile = v6;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
  }
  return result;
}


// Address: 0x225a3a0 | Name: _ZN4FMOD7Profile21getModuleForAsyncReadEPKNS_19ProfilePacketHeaderE
FMOD::ProfileModule_0 *__fastcall FMOD::Profile::getModuleForAsyncRead(
        FMOD::Profile *const this,
        const FMOD::ProfilePacketHeader *packet)
{
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD::ProfileModule_0 *p_mNodeData; // rbp

  mNodeNext = this->mModuleHead.mNodeNext;
  if ( mNodeNext == &this->mModuleHead )
    return 0;
  while ( 1 )
  {
    p_mNodeData = (FMOD::ProfileModule_0 *)&mNodeNext[-1].mNodeData;
    if ( !mNodeNext )
      p_mNodeData = 0;
    if ( (unsigned __int8)(*p_mNodeData->_vptr_ProfileModule)(p_mNodeData) == packet->type
      && (*((unsigned __int8 (__fastcall **)(FMOD::ProfileModule_0 *))p_mNodeData->_vptr_ProfileModule + 1))(p_mNodeData) )
    {
      break;
    }
    mNodeNext = mNodeNext->mNodeNext;
    if ( mNodeNext == &this->mModuleHead )
      return 0;
  }
  return p_mNodeData;
}


// Address: 0x225a410 | Name: _ZN4FMOD7Profile16getModuleForTypeEh
FMOD::ProfileModule_0 *__fastcall FMOD::Profile::getModuleForType(FMOD::Profile *const this, unsigned __int8 type)
{
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD::ProfileModule_0 *p_mNodeData; // rbp

  mNodeNext = this->mModuleHead.mNodeNext;
  if ( mNodeNext == &this->mModuleHead )
    return 0;
  while ( 1 )
  {
    p_mNodeData = (FMOD::ProfileModule_0 *)&mNodeNext[-1].mNodeData;
    if ( !mNodeNext )
      p_mNodeData = 0;
    if ( (unsigned __int8)(*p_mNodeData->_vptr_ProfileModule)(p_mNodeData) == type )
      break;
    mNodeNext = mNodeNext->mNodeNext;
    if ( mNodeNext == &this->mModuleHead )
      return 0;
  }
  return p_mNodeData;
}


// Address: 0x225a470 | Name: _ZN4FMOD7Profile10readPacketEPKNS_19ProfilePacketHeaderEPNS_13ProfileClientE
FMOD_RESULT_0 __fastcall FMOD::Profile::readPacket(
        FMOD::Profile *const this,
        const FMOD::ProfilePacketHeader *packet,
        FMOD::ProfileClient *fromclient)
{
  FMOD::LinkedListNode *mNodeNext; // rbx
  char *p_mNodeData; // rbp
  FMOD_RESULT_0 result; // eax

  mNodeNext = this->mModuleHead.mNodeNext;
  if ( mNodeNext == &this->mModuleHead )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    p_mNodeData = (char *)&mNodeNext[-1].mNodeData;
    if ( !mNodeNext )
      p_mNodeData = 0;
    if ( (**(unsigned __int8 (__fastcall ***)(char *))p_mNodeData)(p_mNodeData) == packet->type )
    {
      result = (*(unsigned int (__fastcall **)(char *, const FMOD::ProfilePacketHeader *, FMOD::ProfileClient *))(*(_QWORD *)p_mNodeData + 40LL))(
                 p_mNodeData,
                 packet,
                 fromclient);
      if ( result )
        break;
    }
    mNodeNext = mNodeNext->mNodeNext;
    if ( mNodeNext == &this->mModuleHead )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


