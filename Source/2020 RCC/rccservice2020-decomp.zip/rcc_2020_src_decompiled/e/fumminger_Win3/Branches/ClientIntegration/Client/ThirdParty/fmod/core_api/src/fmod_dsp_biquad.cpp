// Address: 0x2242570 | Name: _ZNK4FMOD18BiquadCoefficients28calculateLowpassCoefficientsEfffPfS1_S1_S1_S1_
void __fastcall FMOD::BiquadCoefficients::calculateLowpassCoefficients(
        const FMOD::BiquadCoefficients *const this,
        float samplerate,
        float cutoff,
        float Q,
        float *_b0,
        float *_b1,
        float *_b2,
        float *_a1,
        float *_a2)
{
  float v13; // xmm3_4
  float v14; // xmm1_4
  float v15; // xmm0_4
  float v16; // xmm3_4
  float v17; // xmm4_4
  float v18; // xmm2_4
  float v19; // xmm2_4
  float cos_wc; // [rsp+8h] [rbp-30h] BYREF
  float sinx[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  if ( cutoff <= 10.0 )
  {
    cutoff = 10.0;
LABEL_6:
    v13 = 0.49000001 * samplerate;
    if ( (float)(0.49000001 * samplerate) > cutoff )
    {
      v14 = cutoff * 6.2831855;
      goto LABEL_4;
    }
LABEL_8:
    v14 = v13 * 6.2831855;
    goto LABEL_4;
  }
  if ( cutoff < 22000.0 )
    goto LABEL_6;
  v13 = 0.49000001 * samplerate;
  v14 = 138230.08;
  if ( (float)(0.49000001 * samplerate) <= 22000.0 )
    goto LABEL_8;
LABEL_4:
  sincosf(v14 / samplerate, sinx, &cos_wc);
  v15 = sinx[0] / (float)(Q + Q);
  v16 = 1.0 / (float)(v15 + 1.0);
  v17 = cos_wc * -2.0;
  v18 = (float)(1.0 - cos_wc) * v16;
  *_b1 = v18;
  v19 = v18 * 0.5;
  *_b2 = v19;
  *_b0 = v19;
  *_a1 = v17 * v16;
  *_a2 = (float)(1.0 - v15) * v16;
}


// Address: 0x22426b0 | Name: _ZNK4FMOD18BiquadCoefficients29calculateHighpassCoefficientsEfffPfS1_S1_S1_S1_
void __fastcall FMOD::BiquadCoefficients::calculateHighpassCoefficients(
        const FMOD::BiquadCoefficients *const this,
        float samplerate,
        float cutoff,
        float Q,
        float *_b0,
        float *_b1,
        float *_b2,
        float *_a1,
        float *_a2)
{
  float v13; // xmm1_4
  float v14; // xmm3_4
  float v15; // xmm4_4
  float v16; // xmm0_4
  float v17; // xmm2_4
  float v18; // xmm0_4
  float cos_wc; // [rsp+8h] [rbp-30h] BYREF
  float sinx[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  if ( cutoff <= 10.0 )
  {
    cutoff = 10.0;
LABEL_7:
    if ( (float)(0.49000001 * samplerate) <= cutoff )
      v13 = 6.2831855 * (float)(0.49000001 * samplerate);
    else
      v13 = cutoff * 6.2831855;
    goto LABEL_5;
  }
  if ( cutoff < 22000.0 )
    goto LABEL_7;
  v13 = 138230.08;
  if ( (float)(0.49000001 * samplerate) <= 22000.0 )
    v13 = (float)(0.49000001 * samplerate) * 6.2831855;
LABEL_5:
  sincosf(v13 / samplerate, sinx, &cos_wc);
  v14 = 1.0 / (float)((float)(sinx[0] / (float)(Q + Q)) + 1.0);
  v15 = cos_wc * -2.0;
  v16 = (float)-(float)(cos_wc + 1.0) * v14;
  v17 = (float)(1.0 - (float)(sinx[0] / (float)(Q + Q))) * v14;
  *_b1 = v16;
  v18 = (float)-v16 * 0.5;
  *_b2 = v18;
  *_b0 = v18;
  *_a1 = v15 * v14;
  *_a2 = v17;
}


// Address: 0x2242800 | Name: _ZN4FMOD25RampingBiquadCoefficients5applyEi
void __fastcall FMOD::RampingBiquadCoefficients::apply(FMOD::RampingBiquadCoefficients *const this, int steps)
{
  float b0; // xmm11_4
  float target_b1; // xmm8_4
  float b1; // xmm9_4
  float target_b2; // xmm6_4
  float b2; // xmm7_4
  float target_a1; // xmm4_4
  float a1; // xmm5_4
  float target_a2; // xmm2_4
  float v10; // xmm0_4
  float a2; // xmm3_4
  float v12; // xmm1_4
  float v13; // xmm4_4
  float v14; // xmm2_4
  float v15; // xmm1_4
  float v16; // xmm0_4

  this->steps_left = steps;
  if ( steps )
  {
    b0 = this->b0;
    target_b1 = this->target_b1;
    b1 = this->b1;
    target_b2 = this->target_b2;
    b2 = this->b2;
    target_a1 = this->target_a1;
    a1 = this->a1;
    target_a2 = this->target_a2;
    v10 = 1.0 / (float)steps;
    a2 = this->a2;
    v12 = this->target_b0 - b0;
    this->target_diff_b0 = b0 - this->target_b0;
    this->step_b0 = v12 * v10;
    this->target_diff_b1 = b1 - target_b1;
    this->step_b1 = (float)(target_b1 - b1) * v10;
    this->target_diff_b2 = b2 - target_b2;
    this->step_b2 = (float)(target_b2 - b2) * v10;
    this->target_diff_a1 = a1 - target_a1;
    this->step_a1 = (float)(target_a1 - a1) * v10;
    this->target_diff_a2 = a2 - target_a2;
    this->step_a2 = (float)(target_a2 - a2) * v10;
  }
  else
  {
    v13 = this->target_a1;
    v14 = this->target_a2;
    this->a1 = v13;
    this->a2 = v14;
    v15 = this->target_b1;
    this->b0 = this->target_b0;
    v16 = this->target_b2;
    this->b1 = v15;
    this->b2 = v16;
    this->coeff[0] = -v13;
    this->coeff[1] = -v14;
    this->coeff[2] = v15;
    this->coeff[3] = v16;
  }
}


