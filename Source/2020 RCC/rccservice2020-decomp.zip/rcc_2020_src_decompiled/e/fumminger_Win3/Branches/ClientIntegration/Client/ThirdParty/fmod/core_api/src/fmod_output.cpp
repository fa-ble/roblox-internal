// Address: 0x2244d00 | Name: FMOD::qSortCompare
int __fastcall FMOD::qSortCompare(const void *a, const void *b)
{
  float v2; // xmm0_4
  float v3; // xmm1_4
  __int64 v4; // rax

  v2 = *(float *)(*(_QWORD *)a + 40LL);
  v3 = *(float *)(*(_QWORD *)b + 40LL);
  if ( v2 > v3 )
    LODWORD(v4) = -1;
  else
    return v3 > v2;
  return v4;
}


// Address: 0x2244d30 | Name: _ZN4FMOD6Output7releaseEv
FMOD_RESULT_0 __fastcall FMOD::Output::release(FMOD::Output *const this)
{
  FMOD_OUTPUT_CLOSE_CALLBACK_0 close; // rax

  close = this->mDescription.close;
  if ( close )
    close(&this->FMOD_OUTPUT_STATE);
  FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_output.cpp", 74);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2244d70 | Name: _ZN4FMOD6OutputC2Ev
void __fastcall FMOD::Output::Output(FMOD::Output *const this)
{
  FMOD::Thread *p_mBufferedMixerThread; // rdi

  p_mBufferedMixerThread = &this->mBufferedMixerThread;
  *(_QWORD *)&p_mBufferedMixerThread[-1].mName[216] = &off_29B2A60;
  FMOD::Thread::Thread(p_mBufferedMixerThread);
  FMOD::Thread::Thread(&this->mMixerThread);
  this->mPortInfoHead.mNodeData = 0;
  this->mEnumerated = 0;
  this->mSystem = 0;
  this->mMixAheadBlocks = 0;
  this->mPortInfoHead.mNodePrev = &this->mPortInfoHead;
  this->mPortInfoHead.mNodeNext = &this->mPortInfoHead;
  this->mDSPTick = 1;
  this->mFormat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
  this->mSpeakerMode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
  this->mChannelOrder = FMOD_CHANNELORDER::FMOD_CHANNELORDER_DEFAULT_0;
}


// Address: 0x2244e00 | Name: _ZN4FMOD6Output10recordReadEPNS_19FMOD_RECORDING_INFOEPfj
FMOD_RESULT_0 __fastcall FMOD::Output::recordRead(
        FMOD::Output *const this,
        FMOD::FMOD_RECORDING_INFO *recordInfo,
        float *outBuffer,
        unsigned int length)
{
  float *v4; // r13
  unsigned int v6; // ebp
  unsigned int mRecordLastCursorPos; // edx
  FMOD_SOUND_FORMAT_0 mRecordFormat; // esi
  int mRecordChannels; // eax
  unsigned int v11; // r15d
  __int64 v12; // rcx
  __int64 v13; // rdx
  __int64 v14; // rcx
  unsigned __int64 v15; // rcx
  FMOD_RESULT_0 result; // eax
  unsigned int v17; // esi
  unsigned int v18; // r14d
  FMOD_SOUND_FORMAT_0 v19; // ecx
  FMOD::FMOD_OUTPUT_RECORD_UNLOCK_CALLBACK record_unlock; // rax
  FMOD::DownMix *mRecordDownMix; // rdi
  FMOD::DownMix *v22; // rax
  int v23; // ecx
  _BYTE *v24; // rax
  int v25; // ecx
  _BYTE *v26; // rax
  unsigned int v27; // eax
  __int64 v28; // r15
  unsigned __int64 v29; // r8
  FMOD_OUTPUT_STATE *v30; // [rsp+10h] [rbp-98h]
  float *convertDst; // [rsp+18h] [rbp-90h]
  float *downMixSrc; // [rsp+20h] [rbp-88h]
  unsigned int champles; // [rsp+4Ch] [rbp-5Ch]
  unsigned int lockLen1Bytes; // [rsp+58h] [rbp-50h] BYREF
  unsigned int lockLen2Bytes; // [rsp+5Ch] [rbp-4Ch] BYREF
  void *lockPtr1; // [rsp+60h] [rbp-48h] BYREF
  void *lockPtr2; // [rsp+68h] [rbp-40h] BYREF

  v4 = outBuffer;
  v6 = length;
  if ( recordInfo->mRecordDownMix )
  {
    convertDst = recordInfo->mRecordDownMixBuffer;
    downMixSrc = convertDst;
  }
  else
  {
    downMixSrc = recordInfo->mRecordDownMixBuffer;
    convertDst = outBuffer;
  }
  if ( !length )
    return FMOD_RESULT::FMOD_OK_0;
  mRecordLastCursorPos = recordInfo->mRecordLastCursorPos;
  v30 = &this->FMOD_OUTPUT_STATE;
  while ( 1 )
  {
    mRecordFormat = recordInfo->mRecordFormat;
    switch ( mRecordFormat )
    {
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
        mRecordChannels = recordInfo->mRecordChannels;
        v12 = 8;
        v11 = 8;
        goto LABEL_8;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
        mRecordChannels = recordInfo->mRecordChannels;
        v11 = 16;
LABEL_35:
        v12 = 16;
        goto LABEL_8;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
        mRecordChannels = recordInfo->mRecordChannels;
        v11 = 24;
LABEL_33:
        v12 = 24;
        goto LABEL_8;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
        mRecordChannels = recordInfo->mRecordChannels;
        v11 = 32;
LABEL_7:
        v12 = 32;
LABEL_8:
        v13 = mRecordChannels * (unsigned int)((v12 * (unsigned __int64)mRecordLastCursorPos) >> 3);
LABEL_9:
        switch ( mRecordFormat )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v14 = 8;
            break;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v14 = 16;
            break;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v14 = 24;
            break;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v14 = 32;
            break;
          default:
            goto LABEL_39;
        }
        v15 = ((unsigned __int64)v6 * v14) >> 3;
        break;
      default:
        mRecordChannels = recordInfo->mRecordChannels;
        switch ( mRecordFormat )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v12 = 8;
            v11 = 0;
            goto LABEL_8;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v11 = 0;
            goto LABEL_35;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v11 = 0;
            goto LABEL_33;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v11 = 0;
            goto LABEL_7;
          default:
            v11 = 0;
            v13 = mRecordChannels * mRecordLastCursorPos;
            if ( (unsigned int)mRecordFormat <= FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0 )
              goto LABEL_9;
LABEL_39:
            LODWORD(v15) = v6;
            break;
        }
        break;
    }
    lockPtr1 = 0;
    lockPtr2 = 0;
    lockLen1Bytes = 0;
    lockLen2Bytes = 0;
    result = this->mDescription.record_lock(
               v30,
               recordInfo,
               v13,
               mRecordChannels * v15,
               &lockPtr1,
               &lockPtr2,
               &lockLen1Bytes,
               &lockLen2Bytes);
    if ( result )
      return result;
    v17 = recordInfo->mRecordChannels;
    v18 = 0;
    v19 = recordInfo->mRecordFormat;
    if ( v17 )
    {
      v18 = lockLen2Bytes + lockLen1Bytes;
      switch ( v19 )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
          v29 = 8;
          goto LABEL_51;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          v29 = 16;
          goto LABEL_51;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          v29 = 24;
          goto LABEL_51;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          v29 = 32;
LABEL_51:
          v18 = (unsigned int)(8 * (unsigned __int64)v18 / v29) / v17;
          break;
        default:
          break;
      }
    }
    if ( v19 == FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0 )
    {
      v23 = (int)lockPtr1;
      if ( lockPtr1 && lockLen1Bytes )
      {
        v24 = lockPtr1;
        do
          *v24++ += 0x80;
        while ( (int)v24 - v23 < lockLen1Bytes );
      }
      v25 = (int)lockPtr2;
      if ( lockPtr2 && lockLen2Bytes )
      {
        v26 = lockPtr2;
        do
          *v26++ += 0x80;
        while ( lockLen2Bytes > (int)v26 - v25 );
      }
    }
    if ( lockPtr1 && lockLen1Bytes )
    {
      champles = 8 * lockLen1Bytes / v11;
      FMOD::DSPI::convert(
        (__int16 *)convertDst,
        (float *)lockPtr1,
        5,
        recordInfo->mRecordFormat,
        champles,
        1,
        1.0,
        1,
        1);
      convertDst += champles;
    }
    if ( lockPtr2 && lockLen2Bytes )
    {
      v27 = 8 * lockLen2Bytes / v11;
      v28 = v27;
      FMOD::DSPI::convert((__int16 *)convertDst, (float *)lockPtr2, 5, recordInfo->mRecordFormat, v27, 1, 1.0, 1, 1);
      convertDst += v28;
    }
    record_unlock = this->mDescription.record_unlock;
    if ( record_unlock )
    {
      result = record_unlock(v30, recordInfo, lockPtr1, lockPtr2, lockLen1Bytes, lockLen2Bytes);
      if ( result )
        return result;
    }
    mRecordDownMix = recordInfo->mRecordDownMix;
    if ( mRecordDownMix )
    {
      result = (*((unsigned int (__fastcall **)(FMOD::DownMix *, float *, float *, _QWORD))mRecordDownMix->_vptr_DownMix
                + 2))(
                 mRecordDownMix,
                 downMixSrc,
                 v4,
                 v18);
      if ( result )
        return result;
      v22 = recordInfo->mRecordDownMix;
      v4 += v22->mNumOutputChannels * v18;
      downMixSrc += v22->mNumInputChannels * v18;
    }
    mRecordLastCursorPos = (v18 + recordInfo->mRecordLastCursorPos) % recordInfo->mRecordBufferLength;
    v6 -= v18;
    recordInfo->mRecordLastCursorPos = mRecordLastCursorPos;
    if ( !v6 )
      return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x22452a0 | Name: _ZN4FMOD6Output27recordResamplerReadCallbackEP14FMOD_DSP_STATEPfPjS4_Pi
FMOD_RESULT_0 __fastcall FMOD::Output::recordResamplerReadCallback(
        FMOD_DSP_STATE *dsp_state,
        float *outbuffer,
        unsigned int *offset,
        unsigned int *length,
        int *outchannels)
{
  FMOD_DSP_STATE_FUNCTIONS *functions; // rax
  FMOD_RESULT_0 result; // eax
  FMOD::Output *output; // [rsp+8h] [rbp-20h] BYREF

  functions = dsp_state->functions;
  output = 0;
  result = ((unsigned int (__fastcall *)(FMOD_DSP_STATE *, FMOD::Output **, unsigned int *, unsigned int *, int *))functions->getuserdata)(
             dsp_state,
             &output,
             offset,
             length,
             outchannels);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::Output::recordRead(output, output->mRecordInfoForResampler, outbuffer, *length);
  return result;
}


// Address: 0x22452f0 | Name: _ZN4FMOD6Output10recordFillEPNS_19FMOD_RECORDING_INFOEj
FMOD_RESULT_0 __fastcall FMOD::Output::recordFill(
        FMOD::Output *const this,
        FMOD::FMOD_RECORDING_INFO *recordinfo,
        unsigned int length)
{
  FMOD::SoundI *mRecordSound; // rdi
  FMOD_RESULT_0 result; // eax
  FMOD_SOUND_FORMAT_0 v7; // eax
  int v8; // edx
  int v9; // ecx
  unsigned int v10; // ebp
  unsigned int mRecordOffset; // r14d
  unsigned int v12; // ebx
  unsigned __int64 v13; // rcx
  __int64 v14; // rsi
  unsigned int v15; // r14d
  __int64 v16; // rax
  unsigned __int64 v17; // r15
  FMOD::DSPResampler *mRecordResamplerDSP; // rdi
  unsigned int v19; // r15d
  float *mRecordTempBuffer; // rsi
  float *v21; // r14
  char *v22; // r11
  __int64 v23; // r8
  signed int v24; // eax
  int v25; // eax
  unsigned int pblockalign; // [rsp+3Ch] [rbp-6Ch]
  int channels; // [rsp+4Ch] [rbp-5Ch] BYREF
  unsigned int plen1; // [rsp+50h] [rbp-58h] BYREF
  unsigned int plen2; // [rsp+54h] [rbp-54h] BYREF
  unsigned int soundlength; // [rsp+58h] [rbp-50h] BYREF
  FMOD_SOUND_FORMAT_0 pformat; // [rsp+5Ch] [rbp-4Ch] BYREF
  char *pptr1; // [rsp+60h] [rbp-48h] BYREF
  char *pptr2; // [rsp+68h] [rbp-40h] BYREF

  mRecordSound = recordinfo->mRecordSound;
  pptr1 = 0;
  pptr2 = 0;
  plen1 = 0;
  plen2 = 0;
  result = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD, FMOD_SOUND_FORMAT_0 *, int *, _QWORD))mRecordSound->_vptr_SoundI
            + 20))(
             mRecordSound,
             0,
             &pformat,
             &channels,
             0);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::SoundI *, unsigned int *, __int64))recordinfo->mRecordSound->_vptr_SoundI
              + 19))(
               recordinfo->mRecordSound,
               &soundlength,
               2);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v7 = pformat;
      v8 = channels;
      switch ( pformat )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          v9 = 2;
          break;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          v9 = 3;
          break;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          v9 = 4;
          break;
        default:
          v9 = 1;
          break;
      }
      pblockalign = channels * v9;
      v10 = (int)(float)((float)((float)(int)length * recordinfo->mRecordSound->mDefaultFrequency)
                       / (float)recordinfo->mRecordRate);
      if ( v10 )
      {
        mRecordOffset = recordinfo->mRecordOffset;
        while ( 1 )
        {
          v12 = 2048;
          LODWORD(v13) = mRecordOffset;
          if ( v10 <= 0x800 )
            v12 = v10;
          switch ( v7 )
          {
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
              v14 = 8;
              goto LABEL_12;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
              v14 = 16;
              goto LABEL_12;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
              v14 = 24;
              goto LABEL_12;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
              v14 = 32;
LABEL_12:
              v13 = ((unsigned __int64)mRecordOffset * v14) >> 3;
              break;
            default:
              break;
          }
          v15 = v8 * v13;
          switch ( v7 )
          {
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
              v16 = 8;
              goto LABEL_15;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
              v16 = 16;
              goto LABEL_15;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
              v16 = 24;
              goto LABEL_15;
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
            case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
              v16 = 32;
LABEL_15:
              v17 = (v16 * (unsigned __int64)v12) >> 3;
              break;
            default:
              LODWORD(v17) = v12;
              break;
          }
          mRecordResamplerDSP = recordinfo->mRecordResamplerDSP;
          v19 = v8 * v17;
          if ( mRecordResamplerDSP )
          {
            mRecordTempBuffer = recordinfo->mRecordTempBuffer;
            this->mRecordInfoForResampler = recordinfo;
            result = (*((unsigned int (__fastcall **)(FMOD::DSPResampler *, float *, int *, _QWORD))mRecordResamplerDSP->_vptr_DSPI
                      + 9))(
                       mRecordResamplerDSP,
                       mRecordTempBuffer,
                       &channels,
                       v12);
            if ( result )
              return result;
          }
          else
          {
            result = FMOD::Output::recordRead(this, recordinfo, recordinfo->mRecordTempBuffer, v12);
            if ( result )
              return result;
          }
          result = (*((unsigned int (__fastcall **)(FMOD::SoundI *, _QWORD, _QWORD, char **, char **, unsigned int *, unsigned int *))recordinfo->mRecordSound->_vptr_SoundI
                    + 5))(
                     recordinfo->mRecordSound,
                     v15,
                     v19,
                     &pptr1,
                     &pptr2,
                     &plen1,
                     &plen2);
          if ( result )
            break;
          v21 = recordinfo->mRecordTempBuffer;
          if ( pptr1 && plen1 )
          {
            FMOD::DSPI::convert(
              (__int16 *)pptr1,
              recordinfo->mRecordTempBuffer,
              pformat,
              FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0,
              plen1 / pblockalign * channels,
              1,
              1.0,
              1,
              1);
            v21 += channels * (plen1 / pblockalign);
          }
          v22 = pptr2;
          v23 = plen2;
          if ( pptr2 )
          {
            v23 = 0;
            if ( plen2 )
            {
              FMOD::DSPI::convert(
                (__int16 *)pptr2,
                v21,
                pformat,
                FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0,
                plen2 / pblockalign * channels,
                1,
                1.0,
                1,
                1);
              v23 = plen2;
              v22 = pptr2;
            }
          }
          result = (*((unsigned int (__fastcall **)(FMOD::SoundI *, char *, char *, _QWORD, __int64))recordinfo->mRecordSound->_vptr_SoundI
                    + 6))(
                     recordinfo->mRecordSound,
                     pptr1,
                     v22,
                     plen1,
                     v23);
          if ( result )
            break;
          v24 = v12 + recordinfo->mRecordOffset;
          if ( plen2 || (mRecordOffset = v12 + recordinfo->mRecordOffset, v24 >= (int)soundlength) )
          {
            if ( !recordinfo->mRecordLoop )
            {
              recordinfo->mRecordFinished = 1;
              return FMOD_RESULT::FMOD_OK_0;
            }
            mRecordOffset = 0;
            v25 = v24 - soundlength;
            if ( v25 >= 0 )
              mRecordOffset = v25;
          }
          v10 -= v12;
          recordinfo->mRecordOffset = mRecordOffset;
          if ( !v10 )
            return FMOD_RESULT::FMOD_OK_0;
          v7 = pformat;
          v8 = channels;
        }
      }
      else
      {
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x22456f0 | Name: _ZN4FMOD6Output12recordUpdateEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::Output::recordUpdate(FMOD::Output *const this, FMOD::FMOD_RECORDING_INFO *current)
{
  FMOD_RESULT_0 result; // eax
  FMOD::FMOD_OUTPUT_RECORD_GETPOSITION_CALLBACK record_getposition; // rcx
  signed int v4; // eax
  FMOD::DSPResampler *mRecordResamplerDSP; // rdx
  signed int mResampleBlockLength; // ecx
  unsigned int cursorpos[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  result = FMOD_RESULT::FMOD_ERR_UNIMPLEMENTED_0;
  record_getposition = this->mDescription.record_getposition;
  if ( record_getposition )
  {
    if ( !current->mRecordBufferLength || current->mRecordFinished )
      return FMOD_RESULT::FMOD_OK_0;
    cursorpos[0] = 0;
    if ( record_getposition(&this->FMOD_OUTPUT_STATE, current, cursorpos) )
      goto LABEL_13;
    v4 = cursorpos[0] - current->mRecordLastCursorPos;
    if ( v4 < 0 && (v4 += current->mRecordBufferLength, v4 < 0) || (signed int)current->mRecordBufferLength < v4 )
    {
      mRecordResamplerDSP = current->mRecordResamplerDSP;
      v4 = 0;
      if ( !mRecordResamplerDSP )
        return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      mRecordResamplerDSP = current->mRecordResamplerDSP;
      if ( !mRecordResamplerDSP )
      {
        if ( v4 <= 0 )
          return FMOD_RESULT::FMOD_OK_0;
        goto LABEL_12;
      }
    }
    mResampleBlockLength = mRecordResamplerDSP->mResampleBlockLength;
    if ( 3 * mResampleBlockLength > v4 )
      return FMOD_RESULT::FMOD_OK_0;
    v4 = mResampleBlockLength * (v4 / mResampleBlockLength) - mResampleBlockLength;
LABEL_12:
    if ( FMOD::Output::recordFill(this, current, v4) )
LABEL_13:
      current->mRecordFinished = 1;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x22457b0 | Name: _ZN4FMOD6Output11recordStartEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::Output::recordStart(FMOD::Output *const this, FMOD::FMOD_RECORDING_INFO *recordinfo)
{
  FMOD_RESULT_0 result; // eax
  FMOD::FMOD_OUTPUT_RECORD_START_CALLBACK record_start; // rdx
  int mChannels; // esi
  FMOD::DownMix *v7; // rax
  int mRecordChannels; // r9d
  float *v9; // rax
  float *v10; // rax
  float mRecordRate; // xmm0_4
  FMOD::FMOD_DSP_DESCRIPTION_EX *Description; // rax
  const char *mName; // rdx
  __int64 v14; // rdx
  FMOD::DSPResampler *v15; // rax
  FMOD::DSPResampler *v16; // r12
  FMOD::SystemI *mSystem; // rax
  FMOD_DSP_STATE_FUNCTIONS *p_mDSPFunctions; // rdx
  FMOD::DSPResampler *mRecordResamplerDSP; // rdi
  FMOD::DSPResampler_Param resampler_param; // [rsp+20h] [rbp-78h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_EX description_ex; // [rsp+30h] [rbp-68h] BYREF

  result = FMOD_RESULT::FMOD_ERR_UNIMPLEMENTED_0;
  record_start = this->mDescription.record_start;
  if ( record_start )
  {
    result = ((unsigned int (__fastcall *)(FMOD_OUTPUT_STATE *))record_start)(&this->FMOD_OUTPUT_STATE);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mChannels = recordinfo->mRecordSound->mChannels;
      if ( recordinfo->mRecordChannels == mChannels )
        goto LABEL_8;
      v7 = (FMOD::DownMix *)FMOD::MemPool::calloc(
                              off_286F358->gSystemMemPool,
                              200,
                              "../../../core_api/src/fmod_output.cpp",
                              445,
                              0);
      if ( !v7 )
      {
        recordinfo->mRecordDownMix = 0;
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
      v7->mConnection.mMixMatrix.mOutChannels = 0;
      v7->mConnection.mMixMatrixCurrent.mInChannels = 0;
      v7->mConnection.mMixMatrixCurrent.mOutChannels = 0;
      v7->mConnection.mUserData.mMixMatrixUser.mInChannels = 0;
      v7->_vptr_DownMix = (int (**)(...))&off_29B2730;
      v7->mConnection.mUserData.mMixMatrixUser.mOutChannels = 0;
      v7->mConnection.mInputNode.mNodeData = 0;
      v7->mConnection.mOutputNode.mNodeData = 0;
      v7->mConnection.mInputNode.mNodePrev = &v7->mConnection.mInputNode;
      v7->mConnection.mInputNode.mNodeNext = &v7->mConnection.mInputNode;
      v7->mConnection.mMixMatrix.mData = 0;
      v7->mConnection.mMixMatrixCurrent.mData = 0;
      v7->mConnection.mOutputNode.mNodePrev = &v7->mConnection.mOutputNode;
      v7->mConnection.mOutputNode.mNodeNext = &v7->mConnection.mOutputNode;
      v7->mConnection.mMixMatrix.mInChannels = 0;
      v7->mConnection.mUserData.mMixMatrixUser.mData = 0;
      v7->mConnection.mSystem = 0;
      v7->mConnection.mInputUnit = 0;
      v7->mConnection.mOutputUnit = 0;
      mRecordChannels = recordinfo->mRecordChannels;
      recordinfo->mRecordDownMix = v7;
      result = FMOD::DownMix::init(
                 v7,
                 this->mSystem,
                 0,
                 0,
                 FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MAX_0,
                 mRecordChannels,
                 FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MAX_0,
                 recordinfo->mRecordSound->mChannels,
                 0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v9 = (float *)FMOD::MemPool::calloc(
                        off_286F358->gSystemMemPool,
                        recordinfo->mRecordChannels << 13,
                        "../../../core_api/src/fmod_output.cpp",
                        458,
                        0);
        recordinfo->mRecordDownMixBuffer = v9;
        if ( !v9 )
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        mChannels = recordinfo->mRecordSound->mChannels;
LABEL_8:
        v10 = (float *)FMOD::MemPool::calloc(
                         off_286F358->gSystemMemPool,
                         mChannels << 13,
                         "../../../core_api/src/fmod_output.cpp",
                         477,
                         0);
        recordinfo->mRecordTempBuffer = v10;
        if ( v10 )
        {
          mRecordRate = (float)recordinfo->mRecordRate;
          if ( mRecordRate == recordinfo->mRecordSound->mDefaultFrequency )
            return FMOD_RESULT::FMOD_OK_0;
          resampler_param.blocklen = 0;
          resampler_param.channels = 0;
          resampler_param.format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_NONE_0;
          resampler_param.allocbuffer = 1;
          memset(&description_ex, 0, sizeof(description_ex));
          Description = FMOD::DSPResampler::getDescriptionEx();
          description_ex.mDescription = Description->mDescription;
          mName = Description->mName;
          resampler_param.format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
          description_ex.mName = mName;
          *(_QWORD *)&description_ex.mSize = *(_QWORD *)&Description->mSize;
          v14 = *(_QWORD *)(&Description->mHandle + 1);
          resampler_param.blocklen = 16 * ((unsigned int)(int)(float)(mRecordRate * 0.0099999998) >> 4);
          *(_QWORD *)(&description_ex.mHandle + 1) = v14;
          description_ex.mParameter = Description->mParameter;
          description_ex.mModule = Description->mModule;
          *(_QWORD *)&description_ex.mChannels = *(_QWORD *)&Description->mChannels;
          description_ex.mCommand = Description->mCommand;
          resampler_param.channels = recordinfo->mRecordSound->mChannels;
          description_ex.mParameter = &resampler_param;
          v15 = (FMOD::DSPResampler *)FMOD::MemPool::calloc(
                                        off_286F358->gSystemMemPool,
                                        728,
                                        "../../../core_api/src/fmod_output.cpp",
                                        509,
                                        0);
          v16 = v15;
          if ( v15 )
          {
            FMOD::DSPResampler::DSPResampler(v15);
            v16[1]._vptr_DSPI = 0;
            v16[1].mJob.mDelayClock.mClock = 0;
            v16[1].mJob.mDelayClock.mClockNext = 0;
            v16->_vptr_DSPI = (int (**)(...))off_29B10F0;
            v16->mNoDMA = (FMOD::DSPResampler_NODMA *)&v16[1];
            mSystem = this->mSystem;
            recordinfo->mRecordResamplerDSP = v16;
            p_mDSPFunctions = &mSystem->mDSPFunctions;
            v16->mSystem = mSystem;
            LODWORD(mSystem) = *(_DWORD *)((char *)&stru_115E0.r_offset + (_QWORD)mSystem);
            v16->mState.functions = p_mDSPFunctions;
            v16->mState.systemobject = (int)mSystem;
            FMOD::DSPI::alloc(v16, &description_ex);
            mRecordResamplerDSP = recordinfo->mRecordResamplerDSP;
            mRecordResamplerDSP->mFillCallback = FMOD::Output::recordResamplerReadCallback;
            mRecordResamplerDSP->mTargetFrequency = recordinfo->mRecordSound->mDefaultFrequency;
            FMOD::DSPI::setUserData(mRecordResamplerDSP, this);
            (*((void (__fastcall **)(FMOD::DSPResampler *, float))recordinfo->mRecordResamplerDSP->_vptr_DSPI + 7))(
              recordinfo->mRecordResamplerDSP,
              (float)recordinfo->mRecordRate);
            (*((void (__fastcall **)(FMOD::DSPResampler *, _QWORD, _QWORD, _QWORD))recordinfo->mRecordResamplerDSP->_vptr_DSPI
             + 5))(
              recordinfo->mRecordResamplerDSP,
              0,
              0,
              0);
            return FMOD_RESULT::FMOD_OK_0;
          }
          recordinfo->mRecordResamplerDSP = 0;
        }
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
    }
  }
  return result;
}


// Address: 0x2245b60 | Name: _ZN4FMOD6Output10recordStopEPNS_19FMOD_RECORDING_INFOE
FMOD_RESULT_0 __fastcall FMOD::Output::recordStop(FMOD::Output *const this, FMOD::FMOD_RECORDING_INFO *recordinfo)
{
  FMOD_RESULT_0 v2; // ebp
  FMOD::FMOD_OUTPUT_RECORD_STOP_CALLBACK record_stop; // rax
  float *mRecordTempBuffer; // rsi
  FMOD::DSPResampler *mRecordResamplerDSP; // rax
  void *mResampleBufferMemory; // rsi
  float *mRecordDownMixBuffer; // rsi
  FMOD::DownMix *mRecordDownMix; // rdi

  v2 = FMOD_RESULT::FMOD_ERR_UNIMPLEMENTED_0;
  record_stop = this->mDescription.record_stop;
  if ( record_stop )
  {
    v2 = ((unsigned int (__fastcall *)(FMOD_OUTPUT_STATE *))record_stop)(&this->FMOD_OUTPUT_STATE);
    if ( v2 == FMOD_RESULT::FMOD_OK_0 )
    {
      mRecordTempBuffer = recordinfo->mRecordTempBuffer;
      if ( mRecordTempBuffer )
      {
        FMOD::MemPool::free(
          off_286F358->gSystemMemPool,
          mRecordTempBuffer,
          "../../../core_api/src/fmod_output.cpp",
          547);
        recordinfo->mRecordTempBuffer = 0;
      }
      mRecordResamplerDSP = recordinfo->mRecordResamplerDSP;
      if ( mRecordResamplerDSP )
      {
        mResampleBufferMemory = mRecordResamplerDSP->mResampleBufferMemory;
        if ( mResampleBufferMemory )
        {
          FMOD::MemPool::free(
            off_286F358->gSystemMemPool,
            mResampleBufferMemory,
            "../../../core_api/src/fmod_output.cpp",
            550);
          mRecordResamplerDSP = recordinfo->mRecordResamplerDSP;
          mRecordResamplerDSP->mResampleBufferMemory = 0;
        }
        FMOD::MemPool::free(
          off_286F358->gSystemMemPool,
          mRecordResamplerDSP,
          "../../../core_api/src/fmod_output.cpp",
          551);
        recordinfo->mRecordResamplerDSP = 0;
      }
      mRecordDownMixBuffer = recordinfo->mRecordDownMixBuffer;
      if ( mRecordDownMixBuffer )
      {
        FMOD::MemPool::free(
          off_286F358->gSystemMemPool,
          mRecordDownMixBuffer,
          "../../../core_api/src/fmod_output.cpp",
          555);
        recordinfo->mRecordDownMixBuffer = 0;
      }
      mRecordDownMix = recordinfo->mRecordDownMix;
      v2 = FMOD_RESULT::FMOD_OK_0;
      if ( mRecordDownMix )
      {
        (*((void (__fastcall **)(FMOD::DownMix *))mRecordDownMix->_vptr_DownMix + 1))(mRecordDownMix);
        recordinfo->mRecordDownMix = 0;
      }
    }
  }
  return v2;
}


// Address: 0x2245c90 | Name: _ZN4FMOD6Output18callDSPMixCallbackEi
FMOD_RESULT_0 __fastcall FMOD::Output::callDSPMixCallback(FMOD::Output *const this, int stage)
{
  FMOD::PluginFactory *mPluginFactory; // rax
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD::LinkedListNode *i; // r12
  __int64 *mNodeData; // rdx
  FMOD::SystemI *mSystem; // rax
  int v7; // ecx
  __int64 v8; // rax
  FMOD_DSP_STATE state_dummy; // [rsp+0h] [rbp+0h] BYREF

  mPluginFactory = this->mSystem->mPluginFactory;
  mNodeNext = mPluginFactory->mDSPHead.mMixCallbackNode.mNodeNext;
  for ( i = &mPluginFactory->mDSPHead.mMixCallbackNode; i != mNodeNext; mNodeNext = mNodeNext->mNodeNext )
  {
    mNodeData = (__int64 *)mNodeNext->mNodeData;
    if ( *(_QWORD *)(*mNodeData + 208) )
    {
      memset(&state_dummy, 0, sizeof(state_dummy));
      mSystem = this->mSystem;
      v7 = *(_DWORD *)((char *)&stru_115E0.r_offset + (_QWORD)mSystem);
      state_dummy.functions = &mSystem->mDSPFunctions;
      v8 = *mNodeData;
      state_dummy.systemobject = v7;
      (*(void (__fastcall **)(FMOD_DSP_STATE *, _QWORD))(v8 + 208))(&state_dummy, (unsigned int)stage);
    }
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2245d30 | Name: _ZN4FMOD6Output14object3DUpdateEPfii
FMOD_RESULT_0 __fastcall FMOD::Output::object3DUpdate(
        FMOD::Output *const this,
        float *buffer,
        int channels,
        int length)
{
  FMOD::SystemI *mSystem; // rax
  FMOD::SystemI *v6; // rdi
  FMOD_OUTPUT_OBJECT3DGETINFO_CALLBACK_0 object3dgetinfo; // rax
  FMOD_RESULT_0 v8; // ebx
  int v9; // edx
  FMOD::SystemI *v10; // rax
  int mSize; // ebx
  unsigned __int16 v12; // r14
  FMOD::SystemI *v13; // rax
  FMOD::Object3DState *v14; // r12
  unsigned __int16 v15; // bx
  int k; // edx
  signed int v17; // r10d
  __int64 v18; // rbp
  __int16 v19; // r13
  __int64 v20; // rax
  FMOD::DSPConnectionI *mConnection; // rdi
  float v22; // xmm0_4
  bool v23; // cf
  FMOD_RESULT_0 v24; // eax
  void *mContext; // rsi
  unsigned int v26; // eax
  FMOD::Object3DState *m; // rsi
  FMOD::Object3DState *mDeleteNext; // rbx
  _BYTE *p_mValid; // rcx
  __int64 v31; // rax
  __int64 v32; // rsi
  char v33; // dl
  FMOD::Object3DState *v34; // rax
  __int64 v35; // r12
  int v36; // ebp
  unsigned int v37; // r10d
  unsigned __int16 mObjectReadOffset; // r14
  unsigned __int16 mObjectReadIndex; // r13
  _QWORD *j; // rdi
  __int64 v41; // r11
  unsigned __int16 v42; // cx
  unsigned __int16 v43; // dx
  unsigned __int16 v44; // r8
  int v45; // r9d
  __int64 v46; // rax
  signed int v47; // esi
  unsigned int v48; // esi
  FMOD::SystemI *v49; // rcx
  unsigned __int16 v50; // ax
  unsigned __int16 v51; // dx
  int v52; // eax
  unsigned __int16 srcIndex; // [rsp+10h] [rbp-D8h]
  float *ptr; // [rsp+18h] [rbp-D0h]
  __int64 i; // [rsp+28h] [rbp-C0h]
  int v57; // [rsp+30h] [rbp-B8h]
  bool isValid; // [rsp+36h] [rbp-B2h]
  char v59; // [rsp+37h] [rbp-B1h]
  FMOD::MemPool *p_mDSPLevelsPool; // [rsp+38h] [rbp-B0h]
  FMOD::SystemI *v61; // [rsp+40h] [rbp-A8h]
  FMOD_OUTPUT_STATE *v62; // [rsp+48h] [rbp-A0h]
  int numVirtualObjects; // [rsp+58h] [rbp-90h]
  FMOD::Object3DState *deleteHead; // [rsp+60h] [rbp-88h]
  int mixBlockCount; // [rsp+74h] [rbp-74h] BYREF
  unsigned int mixBlockLength; // [rsp+78h] [rbp-70h] BYREF
  int maxRealObjects; // [rsp+7Ch] [rbp-6Ch] BYREF
  FMOD_OUTPUT_OBJECT3DINFO dstState; // [rsp+80h] [rbp-68h] BYREF

  mSystem = this->mSystem;
  v61 = mSystem;
  if ( mSystem )
  {
    FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_OBJECT3D_INFO);
    v6 = this->mSystem;
    v59 = 1;
  }
  else
  {
    v59 = 0;
    v6 = 0;
  }
  mixBlockCount = 0;
  mixBlockLength = 0;
  FMOD::SystemI::getDSPBufferSize(v6, &mixBlockLength, &mixBlockCount);
  maxRealObjects = 0;
  object3dgetinfo = this->mDescription.object3dgetinfo;
  if ( object3dgetinfo
    && this->mDescription.object3dalloc
    && this->mDescription.object3dfree
    && this->mDescription.object3dupdate )
  {
    v8 = object3dgetinfo(&this->FMOD_OUTPUT_STATE, &maxRealObjects);
    if ( v8 )
      goto LABEL_38;
    v9 = maxRealObjects;
  }
  else
  {
    v9 = 0;
  }
  v10 = this->mSystem;
  mSize = v10->mObject3DHead.mSize;
  v57 = mSize;
  if ( v9 > mSize )
    v9 = v10->mObject3DHead.mSize;
  numVirtualObjects = mSize - v9;
  if ( mSize != v9 && v9 )
  {
    v35 = 0;
    v36 = mixBlockCount;
    v37 = mixBlockLength;
    mObjectReadOffset = v10->mObjectReadOffset;
    mObjectReadIndex = v10->mObjectReadIndex;
    for ( j = *(_QWORD **)((char *)&stru_12618.r_offset + (_QWORD)v10); mSize > (int)v35; ++v35 )
    {
      v41 = j[v35];
      v42 = mObjectReadOffset;
      v43 = mObjectReadIndex;
      v44 = 0;
      *(_DWORD *)(v41 + 40) = 1092616192;
      while ( 1 )
      {
        v45 = v44;
        if ( length <= v44 )
          break;
        while ( 1 )
        {
          v46 = *(_QWORD *)v41 + 88LL * v43;
          v47 = v37 - v42;
          if ( length - v45 <= v47 )
            LOWORD(v47) = length - v45;
          if ( *(_BYTE *)v46 && *(float *)(v41 + 40) == 10.0 )
            *(_DWORD *)(v41 + 40) = *(_DWORD *)(v46 + 12);
          v42 += v47;
          v44 += v47;
          if ( v37 != v42 )
            break;
          v45 = v44;
          v42 = 0;
          v43 = (v43 + 1) % v36;
          if ( length <= v44 )
            goto LABEL_64;
        }
      }
LABEL_64:
      ;
    }
    qsort(j, mSize, 8u, FMOD::qSortCompare);
    v10 = this->mSystem;
  }
  p_mDSPLevelsPool = &v10->mDSPLevelsPool;
  ptr = (float *)FMOD::MemPool::alloc(&v10->mDSPLevelsPool, 4 * length, (const char *)&uri_string, 0, 0, 0);
  if ( !ptr )
  {
    v8 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
    goto LABEL_38;
  }
  i = 0;
  deleteHead = 0;
  v62 = &this->FMOD_OUTPUT_STATE;
  if ( mSize <= 0 )
  {
LABEL_71:
    v48 = mixBlockLength;
    v49 = this->mSystem;
    v50 = v49->mObjectReadOffset + length;
    v49->mObjectReadOffset = v50;
    if ( v50 >= v48 )
    {
      v51 = v50 % v48;
      v52 = v49->mObjectReadIndex + 1;
      v49->mObjectReadOffset = v51;
      v49->mObjectReadIndex = v52 % mixBlockCount;
    }
    v8 = FMOD_RESULT::FMOD_OK_0;
    goto LABEL_37;
  }
  do
  {
    v12 = 0;
    isValid = 0;
    v13 = this->mSystem;
    v14 = *(FMOD::Object3DState **)(*(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)v13) + 8 * i);
    dstState.bufferlength = length;
    dstState.buffer = ptr;
    srcIndex = v13->mObjectReadIndex;
    v15 = v13->mObjectReadOffset;
LABEL_16:
    for ( k = v12; length > v12; k = v12 )
    {
      v17 = length - k;
      v18 = (__int64)&v14->mMetaData[srcIndex];
      if ( (int)(mixBlockLength - v15) <= length - k )
        v17 = mixBlockLength - v15;
      v19 = v17;
      if ( *(_BYTE *)v18 )
      {
        memcpy_0(&ptr[v12], (const void *)(*(_QWORD *)(v18 + 80) + 4LL * v15), 4LL * v17);
        if ( !isValid )
        {
          v20 = *(_QWORD *)(v18 + 64);
          dstState.gain = *(float *)(v18 + 4);
          mConnection = v14->mConnection;
          dstState.spread = *(float *)(v18 + 8);
          v22 = *(float *)(v18 + 12);
          *(_QWORD *)&dstState.position.x = v20;
          LODWORD(v20) = *(_DWORD *)(v18 + 72);
          dstState.priority = v22;
          v23 = mConnection->mMixMatrix.mData == 0;
          LODWORD(dstState.position.z) = v20;
          v24 = FMOD::DSPConnectionI::setMixMatrix(
                  mConnection,
                  (float *)(v18 + 16),
                  this->mSystem->mDSPMaxOutputChannels,
                  1,
                  1,
                  v23 ? FMOD_RESULT::FMOD_OK_0 : FMOD_RESULT::FMOD_ERR_TOOMANYCHANNELS_0,
                  0);
          if ( v24 )
            goto LABEL_36;
          v24 = FMOD::DSPConnectionI::setMix(v14->mConnection, *(float *)(v18 + 4), 0x40u, 0, 0);
          if ( v24 )
            goto LABEL_36;
        }
        isValid = 1;
      }
      else
      {
        memset(&ptr[v12], 0, 4LL * v17);
      }
      v15 += v19;
      v12 += v19;
      if ( v15 != mixBlockLength )
        goto LABEL_16;
      v15 = 0;
      *(_BYTE *)v18 = 0;
      srcIndex = (srcIndex + 1) % mixBlockCount;
    }
    mContext = v14->mContext;
    if ( isValid && numVirtualObjects <= (int)i )
    {
      if ( mContext || (this->mDescription.object3dalloc(v62, &v14->mContext), (mContext = v14->mContext) != 0) )
      {
        this->mDescription.object3dupdate(v62, mContext, &dstState);
        goto LABEL_30;
      }
    }
    else
    {
      if ( mContext )
      {
        ((void (__fastcall *)(FMOD_OUTPUT_STATE *))this->mDescription.object3dfree)(v62);
        v14->mContext = 0;
      }
      if ( !isValid )
      {
        if ( v14->mFinished )
        {
          if ( mixBlockCount <= 0 )
            goto LABEL_50;
          p_mValid = &v14->mMetaData->mValid;
          v31 = (__int64)&v14->mMetaData[1];
          v32 = v31 + 88LL * (unsigned int)(mixBlockCount - 1);
          v33 = 0;
          while ( 1 )
          {
            v33 |= *p_mValid;
            p_mValid = (_BYTE *)v31;
            if ( v31 == v32 )
              break;
            v31 += 88;
          }
          if ( !v33 )
          {
LABEL_50:
            v34 = deleteHead;
            deleteHead = v14;
            v14->mDeleteNext = v34;
          }
        }
        goto LABEL_30;
      }
    }
    v24 = FMOD::DSPConnectionI::mix(v14->mConnection, buffer, dstState.buffer, 0, channels, 1, length, 0);
    if ( v24 )
      goto LABEL_36;
LABEL_30:
    v26 = i++;
    v14->mArrayIndex = v26;
  }
  while ( v57 > (int)i );
  if ( !deleteHead )
    goto LABEL_71;
  for ( m = deleteHead; ; m = mDeleteNext )
  {
    mDeleteNext = m->mDeleteNext;
    v24 = FMOD::SystemI::cleanUpObject3DHandle(this->mSystem, m);
    if ( v24 )
      break;
    if ( !mDeleteNext )
      goto LABEL_71;
  }
LABEL_36:
  v8 = v24;
LABEL_37:
  FMOD::MemPool::free(p_mDSPLevelsPool, ptr, (const char *)&uri_string, 0);
LABEL_38:
  if ( v59 && v61 )
    FMOD::SystemI::leaveCrit(v61, FMOD_SYSTEM_CRIT_OBJECT3D_INFO);
  return v8;
}


// Address: 0x22463a0 | Name: _ZN4FMOD6Output6premixEjPNS_18LocalSystemSectionES2_
FMOD_RESULT_0 __fastcall FMOD::Output::premix(
        FMOD::Output *const this,
        unsigned int length,
        FMOD::LocalSystemSection *lockDSPFull,
        FMOD::LocalSystemSection *lockDSPMixer)
{
  FMOD::SystemI *mSystem; // rbx
  void (__fastcall *v9)(FMOD::SystemI *, __int64, _QWORD, _QWORD, _QWORD); // rax
  FMOD_RESULT_0 updated; // ebp
  FMOD::SystemI *v12; // rax
  unsigned int mDSPTick; // edx
  FMOD::DSPJobList *v14; // r13
  FMOD_RESULT_0 v15; // eax
  FMOD::SystemI *v16; // rdi
  void (__fastcall *v17)(FMOD::SystemI *, __int64, _QWORD, _QWORD, _QWORD); // rax
  unsigned int v18; // ecx
  FMOD::DSPI *v19; // rsi
  FMOD::DSPI *dsphead; // [rsp+8h] [rbp-30h] BYREF

  mSystem = this->mSystem;
  v9 = *(void (__fastcall **)(FMOD::SystemI *, __int64, _QWORD, _QWORD, _QWORD))((char *)&stru_11748.r_offset
                                                                               + (_QWORD)mSystem);
  if ( v9 && (mSystem->mCallbackMask & 0x20) != 0 )
    v9(this->mSystem, 32, 0, 0, *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)mSystem));
  if ( lockDSPFull->mSystem && !lockDSPFull->mEntered )
  {
    FMOD::SystemI::enterCrit(lockDSPFull->mSystem, lockDSPFull->mCritType);
    lockDSPFull->mEntered = 1;
  }
  FMOD::SystemI::enterCrit(mSystem, FMOD_SYSTEM_CRIT_DSPCLOCK);
  updated = FMOD::SystemI::flushDSPQueue(this->mSystem, 0);
  if ( updated )
    goto LABEL_8;
  if ( lockDSPMixer->mSystem && !lockDSPMixer->mEntered )
  {
    FMOD::SystemI::enterCrit(lockDSPMixer->mSystem, lockDSPMixer->mCritType);
    lockDSPMixer->mEntered = 1;
  }
  FMOD::Output::callDSPMixCallback(this, 0);
  v12 = this->mSystem;
  mDSPTick = this->mDSPTick;
  v14 = *(FMOD::DSPJobList **)((char *)&stru_10788.r_offset + (_QWORD)v12);
  *(_DWORD *)((char *)&stru_11610.r_offset + (_QWORD)v12) = mDSPTick;
  if ( v14->mDirty )
  {
    updated = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, _QWORD, FMOD::DSPI **))v12->mMasterChannelGroup->_vptr_ChannelControlI
               + 36))(
                v12->mMasterChannelGroup,
                0,
                &dsphead);
    if ( updated )
    {
LABEL_8:
      FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPCLOCK);
      return updated;
    }
    v18 = this->mDSPTick;
    v19 = dsphead;
    v14->mNumJobs = 0;
    v14->mDirty = 0;
    v14->mChanged = 1;
    this->mDSPTick = v18 + 1;
    updated = FMOD::DSPJobList::runEntireClockTree(v14, v19, length, v18);
  }
  else
  {
    this->mDSPTick = mDSPTick + 1;
    v15 = FMOD::DSPJobList::runClockList(v14, length, mDSPTick);
    v14->mChanged = 0;
    updated = v15;
  }
  FMOD::SystemI::leaveCrit(mSystem, FMOD_SYSTEM_CRIT_DSPCLOCK);
  if ( updated == FMOD_RESULT::FMOD_OK_0 )
  {
    updated = FMOD::SystemI::updateRecordBuffers(this->mSystem);
    if ( updated == FMOD_RESULT::FMOD_OK_0 )
    {
      FMOD::SystemI::callInternalCallback(this->mSystem, 0x100001u, 0, 0);
      v16 = this->mSystem;
      v17 = *(void (__fastcall **)(FMOD::SystemI *, __int64, _QWORD, _QWORD, _QWORD))((char *)&stru_11748.r_offset
                                                                                    + (_QWORD)v16);
      if ( v17 && (v16->mCallbackMask & 0x100) != 0 )
        v17(v16, 256, 0, 0, *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)v16));
      updated = FMOD_RESULT::FMOD_OK_0;
      FMOD::Output::callDSPMixCallback(this, 2);
    }
  }
  return updated;
}


// Address: 0x22465c0 | Name: _ZN4FMOD6Output7postmixEPNS_18LocalSystemSectionES2_
FMOD_RESULT_0 __fastcall FMOD::Output::postmix(
        FMOD::Output *const this,
        FMOD::LocalSystemSection *lockDSPFull,
        FMOD::LocalSystemSection *lockDSPMixer)
{
  FMOD::SystemI *mSystem; // rax
  FMOD::ProfileDsp *mProfileDSP; // rdi
  FMOD_RESULT_0 v8; // ebp
  FMOD::SystemI *v9; // rdi
  bool v10; // zf
  FMOD::SystemI *v11; // rdi
  FMOD::SystemI *v12; // rdi
  void (__fastcall *v13)(FMOD::SystemI *, __int64, _QWORD, _QWORD, _QWORD); // rax
  FMOD::FMOD_SYSTEM_CRIT v15; // esi
  FMOD::FMOD_SYSTEM_CRIT mCritType; // esi
  int blockCount[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  FMOD::Output::callDSPMixCallback(this, 1);
  mSystem = this->mSystem;
  mProfileDSP = mSystem->mProfileDSP;
  if ( mProfileDSP )
  {
    v8 = FMOD::ProfileDsp::prepareGraph(mProfileDSP);
    if ( v8 )
      return v8;
    mSystem = this->mSystem;
  }
  blockCount[0] = 0;
  FMOD::SystemI::getDSPBufferSize(mSystem, 0, blockCount);
  v9 = lockDSPMixer->mSystem;
  v10 = lockDSPMixer->mSystem == 0;
  this->mSystem->mObjectWriteIndex = (this->mSystem->mObjectWriteIndex + 1) % blockCount[0];
  if ( !v10 && lockDSPMixer->mEntered )
  {
    mCritType = lockDSPMixer->mCritType;
    lockDSPMixer->mEntered = 0;
    FMOD::SystemI::leaveCrit(v9, mCritType);
  }
  v11 = lockDSPFull->mSystem;
  if ( lockDSPFull->mSystem && lockDSPFull->mEntered )
  {
    v15 = lockDSPFull->mCritType;
    lockDSPFull->mEntered = 0;
    FMOD::SystemI::leaveCrit(v11, v15);
  }
  v12 = this->mSystem;
  v8 = FMOD_RESULT::FMOD_OK_0;
  v13 = *(void (__fastcall **)(FMOD::SystemI *, __int64, _QWORD, _QWORD, _QWORD))((char *)&stru_11748.r_offset
                                                                                + (_QWORD)v12);
  if ( !v13 || (v12->mCallbackMask & 0x40) == 0 )
    return v8;
  v13(v12, 64, 0, 0, *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)v12));
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22466d0 | Name: _ZN4FMOD6Output9mixSystemEPfj
FMOD_RESULT_0 __fastcall FMOD::Output::mixSystem(FMOD::Output *const this, float *buffer, unsigned int length)
{
  FMOD::SystemI *mSystem; // rdi
  FMOD_SPEAKERMODE_0 v6; // ebp
  unsigned int mDSPMaxOutputChannels; // ebx
  FMOD_RESULT_0 v8; // ecx
  FMOD::SystemI *v10; // rax
  FMOD::SystemI *v11; // rax
  FMOD::DSPJobList *v12; // rdi
  FMOD_RESULT_0 v13; // ecx
  __int64 v14; // rbx
  float *v15; // rax
  FMOD_RESULT_0 v16; // [rsp+8h] [rbp-90h]
  FMOD_RESULT_0 v17; // [rsp+8h] [rbp-90h]
  FMOD_RESULT_0 v18; // [rsp+8h] [rbp-90h]
  unsigned int blockSize; // [rsp+1Ch] [rbp-7Ch] BYREF
  FMOD::LocalSystemSection lockDSPFull; // [rsp+20h] [rbp-78h] BYREF
  FMOD::LocalSystemSection lockDSPMixer; // [rsp+30h] [rbp-68h] BYREF
  FMOD::DSPBuffer bufferHandle; // [rsp+40h] [rbp-58h] BYREF

  mSystem = this->mSystem;
  v6 = *(int *)((char *)&dword_1181C + (_QWORD)mSystem);
  mDSPMaxOutputChannels = mSystem->mDSPMaxOutputChannels;
  FMOD::SystemI::getDSPBufferSize(mSystem, &blockSize, 0);
  v8 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( length == blockSize )
  {
    v10 = this->mSystem;
    lockDSPFull.mEntered = 0;
    lockDSPFull.mCritType = FMOD_SYSTEM_CRIT_DSPFULL;
    lockDSPMixer.mEntered = 0;
    lockDSPMixer.mCritType = FMOD_SYSTEM_CRIT_DSPMIXER;
    lockDSPFull.mSystem = v10;
    lockDSPMixer.mSystem = v10;
    v8 = FMOD::Output::premix(this, length, &lockDSPFull, &lockDSPMixer);
    if ( v8 == FMOD_RESULT::FMOD_OK_0 )
    {
      v11 = this->mSystem;
      memset(&bufferHandle, 0, 24);
      v12 = *(FMOD::DSPJobList **)((char *)&stru_10788.r_offset + (_QWORD)v11);
      bufferHandle.mCacheIndex = -1;
      v13 = FMOD::DSPJobList::read(v12, blockSize, v6, mDSPMaxOutputChannels, &bufferHandle);
      if ( v13 == FMOD_RESULT::FMOD_OK_0 )
      {
        v14 = blockSize * mDSPMaxOutputChannels;
        v15 = FMOD::DSPBuffer::get(&bufferHandle);
        memcpy_0(buffer, v15, 4 * v14);
        FMOD::DSPBuffer::release(&bufferHandle);
        v13 = FMOD::Output::postmix(this, &lockDSPFull, &lockDSPMixer);
      }
      v18 = v13;
      FMOD::DSPBuffer::~DSPBuffer(&bufferHandle);
      v8 = v18;
    }
    if ( lockDSPMixer.mEntered && lockDSPMixer.mSystem )
    {
      v17 = v8;
      lockDSPMixer.mEntered = 0;
      FMOD::SystemI::leaveCrit(lockDSPMixer.mSystem, lockDSPMixer.mCritType);
      v8 = v17;
    }
    if ( lockDSPFull.mEntered && lockDSPFull.mSystem )
    {
      v16 = v8;
      lockDSPFull.mEntered = 0;
      FMOD::SystemI::leaveCrit(lockDSPFull.mSystem, lockDSPFull.mCritType);
      return v16;
    }
  }
  return v8;
}


// Address: 0x2246870 | Name: _ZN4FMOD6Output14getFreeChannelEPPNS_11ChannelRealEb
FMOD_RESULT_0 __fastcall FMOD::Output::getFreeChannel(
        FMOD::Output *const this,
        FMOD::ChannelReal **realchannel,
        bool ignorereserved)
{
  FMOD::ChannelPool *mChannelPool; // rdi

  if ( !realchannel )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mChannelPool = this->mChannelPool;
  if ( mChannelPool )
    return FMOD::ChannelPool::allocateChannel(mChannelPool, realchannel, -1, ignorereserved);
  else
    return FMOD_RESULT::FMOD_ERR_CHANNEL_ALLOC_0;
}


// Address: 0x22468b0 | Name: _ZN4FMOD6Output20requestResetCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::Output::requestResetCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD_OUTPUT_REQUESTRESET_FUNC *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = &output[-1].requestreset;
  *((_BYTE *)p_requestreset + 785) = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22468d0 | Name: _ZN4FMOD6Output17polledMixerThreadEv
FMOD_RESULT_0 __fastcall FMOD::Output::polledMixerThread(FMOD::Output *const this)
{
  FMOD::SystemI *mSystem; // rdi
  FMOD_RESULT_0 result; // eax
  int v4; // eax
  FMOD::Output *mOutput; // rdx
  unsigned int mSpeakerModeChannels; // ebp
  FMOD_OUTPUT_GETPOSITION_CALLBACK_0 getposition; // rdx
  unsigned int v8; // ecx
  unsigned int v9; // esi
  unsigned int v10; // edx
  int mCursorBlock; // ecx
  int v12; // ecx
  FMOD_SOUND_FORMAT_0 mFormat; // eax
  __int64 v14; // rsi
  unsigned __int64 v15; // rcx
  FMOD_OUTPUT_LOCK_CALLBACK_0 lock; // r10
  FMOD_SOUND_FORMAT_0 v17; // edx
  __int64 v18; // rax
  __int64 v19; // rdx
  unsigned __int64 v20; // rdx
  __int64 v21; // rdx
  unsigned __int64 v22; // rcx
  FMOD_OUTPUT_UNLOCK_CALLBACK_0 unlock; // rax
  bool v24; // cc
  unsigned int pcm; // [rsp+1Ch] [rbp-5Ch] BYREF
  unsigned int blocksize; // [rsp+20h] [rbp-58h] BYREF
  int numblocks; // [rsp+24h] [rbp-54h] BYREF
  unsigned int len1; // [rsp+28h] [rbp-50h] BYREF
  unsigned int len2; // [rsp+2Ch] [rbp-4Ch] BYREF
  void *ptr1; // [rsp+30h] [rbp-48h] BYREF
  void *ptr2; // [rsp+38h] [rbp-40h] BYREF

  mSystem = this->mSystem;
  pcm = 0;
  result = FMOD::SystemI::getDSPBufferSize(mSystem, &blocksize, &numblocks);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v4 = numblocks + this->mMixAheadBlocks;
    mOutput = this->mSystem->mOutput;
    numblocks = v4;
    mSpeakerModeChannels = mOutput->mSpeakerModeChannels;
    getposition = this->mDescription.getposition;
    if ( getposition )
    {
      result = getposition(&this->FMOD_OUTPUT_STATE, &pcm);
      if ( result )
        return result;
      v8 = numblocks;
    }
    else
    {
      v8 = v4;
    }
    v9 = blocksize;
    v10 = pcm / blocksize % v8;
    mCursorBlock = this->mCursorBlock;
    pcm = v10;
    if ( mCursorBlock == v10 )
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      while ( 1 )
      {
        v12 = mCursorBlock - this->mMixAheadBlocks;
        ptr1 = 0;
        ptr2 = 0;
        len1 = 0;
        len2 = 0;
        if ( v12 < 0 )
          v12 += numblocks;
        mFormat = this->mFormat;
        switch ( mFormat )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v19 = 8;
            goto LABEL_18;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v19 = 16;
            goto LABEL_18;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v19 = 24;
            goto LABEL_18;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v19 = 32;
LABEL_18:
            v20 = ((unsigned __int64)v9 * v19) >> 3;
            break;
          default:
            LODWORD(v20) = v9;
            break;
        }
        v21 = mSpeakerModeChannels * (unsigned int)v20;
        v15 = v9 * v12;
        switch ( mFormat )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v14 = 8;
            goto LABEL_10;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v14 = 16;
            goto LABEL_10;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v14 = 24;
            goto LABEL_10;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v14 = 32;
LABEL_10:
            v15 = (v14 * v15) >> 3;
            break;
          default:
            break;
        }
        lock = this->mDescription.lock;
        if ( lock )
        {
          result = lock(&this->FMOD_OUTPUT_STATE, mSpeakerModeChannels * v15, v21, &ptr1, &ptr2, &len1, &len2);
          if ( result )
            return result;
          v17 = this->mFormat;
          v18 = len1;
        }
        else
        {
          v17 = this->mFormat;
          v18 = 0;
        }
        if ( !mSpeakerModeChannels )
          return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
        switch ( v17 )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
            v22 = 8;
            goto LABEL_28;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
            v22 = 16;
            goto LABEL_28;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
            v22 = 24;
            goto LABEL_28;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
            v22 = 32;
LABEL_28:
            LODWORD(v18) = (unsigned int)(8 * v18 / v22) / mSpeakerModeChannels;
            break;
          default:
            break;
        }
        result = this->readfrommixer(&this->FMOD_OUTPUT_STATE, ptr1, v18);
        if ( result )
          return result;
        unlock = this->mDescription.unlock;
        if ( unlock )
        {
          result = unlock(&this->FMOD_OUTPUT_STATE, ptr1, ptr2, len1, len2);
          if ( result )
            return result;
        }
        mCursorBlock = this->mCursorBlock + 1;
        v24 = mCursorBlock < numblocks;
        this->mCursorBlock = mCursorBlock;
        if ( !v24 )
        {
          this->mCursorBlock = 0;
          mCursorBlock = 0;
        }
        if ( pcm == mCursorBlock )
          return FMOD_RESULT::FMOD_OK_0;
        v9 = blocksize;
      }
    }
  }
  return result;
}


// Address: 0x2246be0 | Name: _ZN4FMOD6Output19mixerThreadCallbackEPv
void __fastcall FMOD::Output::mixerThreadCallback(void *param)
{
  if ( *((_DWORD *)param + 225) )
    FMOD::Output::polledMixerThread((FMOD::Output *const)param);
  else
    (*((void (__fastcall **)(char *))param + 124))((char *)param + 8);
}


// Address: 0x2246c10 | Name: _ZN4FMOD6Output5startEv
FMOD_RESULT_0 __fastcall FMOD::Output::start(FMOD::Output *const this)
{
  FMOD_OUTPUT_START_CALLBACK_0 start; // rax
  FMOD::SystemI *system; // rcx
  FMOD_RESULT_0 result; // eax
  int sleepperiod; // ebp
  int v5; // edx
  unsigned int blockSize[7]; // [rsp+3Ch] [rbp-1Ch] BYREF

  start = this->mDescription.start;
  system = this->mSystem;
  system->mObjectReadOffset = 0;
  system->mObjectReadIndex = 0;
  system->mObjectWriteIndex = 0;
  if ( start )
  {
    result = start(&this->FMOD_OUTPUT_STATE);
    if ( result )
      return result;
    system = this->mSystem;
  }
  if ( !this->mDescription.polling || (system->mFlags & 2) != 0 )
  {
    sleepperiod = -(this->mDescription.mixer == 0);
  }
  else
  {
    blockSize[0] = 0;
    result = FMOD::SystemI::getDSPBufferSize(system, blockSize, 0);
    if ( result )
      return result;
    system = this->mSystem;
    sleepperiod = 1;
    v5 = (int)(1000 * blockSize[0] / system->mDSPSampleRate) / 3;
    if ( v5 > 0 )
    {
      LOBYTE(sleepperiod) = 10;
      if ( v5 <= 10 )
        sleepperiod = (int)(1000 * blockSize[0] / system->mDSPSampleRate) / 3;
    }
  }
  if ( !system->mDSPRingBuffer
    || (result = FMOD::Thread::initThread(
                   &this->mBufferedMixerThread,
                   "FMOD mixer thread",
                   FMOD::Output::bufferedMixerThreadCallback,
                   this,
                   FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_MIXER,
                   FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_CRITICAL,
                   system->mAdvancedSettings.stackSizeMixer,
                   1,
                   0,
                   system,
                   1)) == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_OK_0;
    if ( sleepperiod != -1 )
      return FMOD::Thread::initThread(
               &this->mMixerThread,
               "FMOD mixer thread",
               FMOD::Output::mixerThreadCallback,
               this,
               FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_MIXER,
               FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_CRITICAL,
               this->mSystem->mAdvancedSettings.stackSizeMixer,
               0,
               sleepperiod,
               this->mSystem,
               1);
  }
  return result;
}


// Address: 0x2246da0 | Name: _ZN4FMOD6Output4stopEv
FMOD_RESULT_0 __fastcall FMOD::Output::stop(FMOD::Output *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD_OUTPUT_STOP_CALLBACK_0 stop; // rax
  FMOD::SystemI *mSystem; // rax
  int mSize; // edx
  __int64 v5; // rbx
  __int64 v6; // r13
  __int64 v7; // r12

  result = FMOD::Thread::closeThread(&this->mMixerThread);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD::Thread::closeThread(&this->mBufferedMixerThread);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      stop = this->mDescription.stop;
      if ( !stop || (result = stop(&this->FMOD_OUTPUT_STATE)) == FMOD_RESULT::FMOD_OK_0 )
      {
        mSystem = this->mSystem;
        mSize = mSystem->mObject3DHead.mSize;
        if ( mSize > 0 )
        {
          v5 = 0;
          v6 = 8LL * (unsigned int)(mSize - 1) + 8;
          while ( 1 )
          {
            v7 = *(_QWORD *)(*(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)mSystem) + v5);
            if ( *(_QWORD *)(v7 + 24) )
            {
              ((void (__fastcall *)(FMOD_OUTPUT_STATE *))this->mDescription.object3dfree)(&this->FMOD_OUTPUT_STATE);
              *(_QWORD *)(v7 + 24) = 0;
            }
            v5 += 8;
            if ( v5 == v6 )
              break;
            mSystem = this->mSystem;
          }
        }
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x2246e50 | Name: _ZN4FMOD6Output6updateEv
FMOD_RESULT_0 __fastcall FMOD::Output::update(FMOD::Output *const this)
{
  FMOD_OUTPUT_UPDATE_CALLBACK_0 update; // rax
  FMOD_RESULT_0 result; // eax

  update = this->mDescription.update;
  if ( !update || (result = update(&this->FMOD_OUTPUT_STATE)) == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( this->mDescription.polling )
    {
      result = FMOD_RESULT::FMOD_OK_0;
      if ( (this->mSystem->mFlags & 2) != 0 )
        return FMOD::Output::polledMixerThread(this);
    }
    else
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2246ea0 | Name: _ZN4FMOD16OutputRingBuffer4initEiiii
FMOD_RESULT_0 __fastcall FMOD::OutputRingBuffer::init(
        FMOD::OutputRingBuffer *const this,
        int blockSize,
        int numBlocks,
        int bytesPerSample,
        int additionalBlocks)
{
  int v5; // r8d
  int v6; // ecx
  FMOD::Global *v7; // rax
  char *v8; // rax

  v5 = numBlocks + additionalBlocks;
  this->mBytesPerSample = bytesPerSample;
  this->mBlockSize = blockSize;
  v6 = blockSize * bytesPerSample;
  this->mCurrentBlockCount = numBlocks;
  this->mWritePosBytes = 0;
  this->mReadPosBytes = 0;
  this->mReadBytes = 0;
  v7 = off_286F358;
  this->mBlockSizeBytes = v6;
  this->mBufferSize = v5 * blockSize;
  this->mBufferSizeBytes = v6 * v5;
  this->mWriteBytes = v6 * v5;
  v8 = (char *)FMOD::MemPool::calloc(v7->gSystemMemPool, v6 * v5, "../../../core_api/src/fmod_output.cpp", 1746, 0);
  this->mBuffer = v8;
  return v8 == 0 ? 0x26 : 0;
}


// Address: 0x2246f20 | Name: _ZN4FMOD6Output8openportEjyPiPPNS_4DSPIE
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::Output::openport(
        FMOD::Output *const this,
        FMOD_PORT_TYPE portType,
        FMOD_PORT_INDEX portIndex,
        int *portId,
        FMOD::DSPI **dspreturn)
{
  FMOD_RESULT_0 v5; // eax
  FMOD::FMOD_PORT_INFO *mNodeNext; // rbx
  FMOD::FMOD_PORT_INFO *p_mPortInfoHead; // rbp
  FMOD::DSPI **v12; // r11
  FMOD::DSPI *mDSPReturn; // rax
  FMOD_RESULT_1 v14; // eax
  FMOD::DSPI **v15; // r11
  FMOD::SystemI *mSystem; // rdi
  FMOD::FMOD_DSP_DESCRIPTION_EX *Description; // rax
  FMOD::SystemI *v18; // rdi
  FMOD_RESULT_0 v19; // eax
  FMOD_SPEAKERMODE_0 v20; // ecx
  __int64 v21; // rax
  FMOD_RESULT_0 v22; // eax
  int v23; // eax
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::OutputRingBuffer *v25; // rax
  int v26; // esi
  int v27; // edx
  FMOD_RESULT_0 resulta; // [rsp+10h] [rbp-A8h]
  FMOD_RESULT_0 resultb; // [rsp+10h] [rbp-A8h]
  FMOD_RESULT_0 resultc; // [rsp+10h] [rbp-A8h]
  FMOD::DSPI **v32; // [rsp+18h] [rbp-A0h]
  int portRate; // [rsp+20h] [rbp-98h] BYREF
  int portChannels; // [rsp+24h] [rbp-94h] BYREF
  FMOD::DSPI *dspreturna; // [rsp+28h] [rbp-90h] BYREF
  FMOD::DSPConnectionI *portConnection; // [rsp+30h] [rbp-88h] BYREF
  FMOD::DSPI *blockCount; // [rsp+38h] [rbp-80h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_EX blockSize; // [rsp+40h] [rbp-78h] OVERLAPPED BYREF

  v5 = FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  if ( !this->mDescription.openport )
    return v5;
  mNodeNext = (FMOD::FMOD_PORT_INFO *)this->mPortInfoHead.mNodeNext;
  p_mPortInfoHead = &this->mPortInfoHead;
  v12 = dspreturn;
  if ( mNodeNext != &this->mPortInfoHead )
  {
    while ( mNodeNext->mType != portType || mNodeNext->mIndex != portIndex )
    {
      mNodeNext = (FMOD::FMOD_PORT_INFO *)mNodeNext->mNodeNext;
      if ( mNodeNext == p_mPortInfoHead )
        goto LABEL_9;
    }
    goto LABEL_7;
  }
LABEL_9:
  mNodeNext = (FMOD::FMOD_PORT_INFO *)FMOD::MemPool::calloc(
                                        off_286F358->gSystemMemPool,
                                        72,
                                        "../../../core_api/src/fmod_output.cpp",
                                        1188,
                                        0);
  if ( !mNodeNext )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  mNodeNext->mNodePrev = mNodeNext;
  mNodeNext->mNodeNext = mNodeNext;
  mNodeNext->mNodeData = 0;
  v14 = this->mDescription.openport(
          &this->FMOD_OUTPUT_STATE,
          portType,
          portIndex,
          &mNodeNext->mDriverId,
          &portRate,
          &portChannels,
          &mNodeNext->mFormat);
  v15 = dspreturn;
  if ( v14 )
  {
    resulta = v14;
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mNodeNext, "../../../core_api/src/fmod_output.cpp", 1200);
    return resulta;
  }
  mSystem = this->mSystem;
  if ( mSystem->mOutputType == FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_WINSONIC_0 )
  {
    LODWORD(blockCount) = 0;
    LODWORD(blockSize.mDescription) = 0;
    FMOD::SystemI::getDSPBufferSize(mSystem, (unsigned int *)&blockSize, (int *)&blockCount);
    v25 = (FMOD::OutputRingBuffer *)FMOD::MemPool::calloc(
                                      off_286F358->gSystemMemPool,
                                      48,
                                      "../../../core_api/src/fmod_output.cpp",
                                      1210,
                                      0);
    if ( v25 )
    {
      v26 = portChannels;
      v27 = (int)blockCount;
      mNodeNext->mRingBuffer = v25;
      v5 = FMOD::OutputRingBuffer::init(v25, (int)blockSize.mDescription, v27, 4 * v26, 0);
      v15 = dspreturn;
      if ( v5 )
        return v5;
      goto LABEL_12;
    }
    mNodeNext->mRingBuffer = 0;
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
LABEL_12:
  v32 = v15;
  Description = FMOD::PortHead::getDescriptionEx();
  v18 = this->mSystem;
  blockSize = *Description;
  blockSize.mName = "Output Port Head";
  v19 = FMOD::SystemI::createDSP(v18, &blockSize, 0, &dspreturna, 1);
  if ( v19 )
  {
    resultb = v19;
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mNodeNext, "../../../core_api/src/fmod_output.cpp", 1230);
    return resultb;
  }
  FMOD::DSPI::setParameterInt(dspreturna, 0, portRate);
  mNodeNext->mDSPReturn = dspreturna;
  v5 = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, _QWORD, FMOD::DSPI **))this->mSystem->mMasterChannelGroup->_vptr_ChannelControlI
        + 36))(
         this->mSystem->mMasterChannelGroup,
         0,
         &blockCount);
  if ( v5 == FMOD_RESULT::FMOD_OK_0 )
  {
    v20 = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
    v21 = (unsigned int)(portChannels - 1);
    if ( (unsigned int)v21 <= 0xB )
      v20 = dword_596D40[v21];
    v5 = FMOD::DSPI::setChannelFormat(dspreturna, 0, portChannels, v20);
    if ( v5 == FMOD_RESULT::FMOD_OK_0 )
    {
      v22 = FMOD::DSPI::addInput(
              blockCount,
              dspreturna,
              &portConnection,
              FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
              1,
              0);
      if ( v22 )
      {
        resultc = v22;
        (*((void (__fastcall **)(FMOD::DSPI *))dspreturna->_vptr_DSPI + 2))(dspreturna);
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mNodeNext, "../../../core_api/src/fmod_output.cpp", 1252);
        return resultc;
      }
      v5 = FMOD::DSPConnectionI::setMix(portConnection, 0.0, 0, 1, 0);
      if ( v5 == FMOD_RESULT::FMOD_OK_0 )
      {
        v5 = FMOD::DSPI::setActive(dspreturna, 1, 1);
        if ( v5 == FMOD_RESULT::FMOD_OK_0 )
        {
          v23 = portChannels;
          mNodeNext->mType = portType;
          mNodeNext->mIndex = portIndex;
          v12 = v32;
          mNodeNext->mChannels = v23;
          mNodePrev = this->mPortInfoHead.mNodePrev;
          mNodeNext->mNodeNext = p_mPortInfoHead;
          mNodeNext->mNodePrev = mNodePrev;
          this->mPortInfoHead.mNodePrev = mNodeNext;
          mNodeNext->mNodePrev->FMOD::LinkedListNode::mNodeNext = mNodeNext;
LABEL_7:
          mDSPReturn = mNodeNext->mDSPReturn;
          ++mNodeNext->mRefCount;
          *v12 = mDSPReturn;
          *portId = mNodeNext->mDriverId;
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return v5;
}


// Address: 0x2247350 | Name: _ZN4FMOD16OutputRingBuffer7releaseEv
FMOD_RESULT_0 __fastcall FMOD::OutputRingBuffer::release(FMOD::OutputRingBuffer *const this)
{
  if ( this->mBuffer )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, this->mBuffer, "../../../core_api/src/fmod_output.cpp", 1766);
    this->mBuffer = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2247390 | Name: _ZN4FMOD6Output9closeportEi
FMOD_RESULT_0 __fastcall FMOD::Output::closeport(FMOD::Output *const this, int portId)
{
  FMOD_OUTPUT_CLOSEPORT_CALLBACK_0 closeport; // rdx
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rbx
  FMOD::LinkedListNode *mNodePrev; // rax
  __int64 mNodeData_high; // rsi
  FMOD::OutputRingBuffer *mNodeData; // rdi

  closeport = this->mDescription.closeport;
  result = FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
  if ( closeport )
  {
    mNodeNext = this->mPortInfoHead.mNodeNext;
    if ( &this->mPortInfoHead == mNodeNext )
    {
      return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    }
    else
    {
      while ( HIDWORD(mNodeNext[1].mNodeData) != portId )
      {
        mNodeNext = mNodeNext->mNodeNext;
        if ( &this->mPortInfoHead == mNodeNext )
          return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
      }
      if ( LODWORD(mNodeNext[2].mNodeNext)-- == 1 )
      {
        mNodePrev = mNodeNext->mNodePrev;
        mNodeData_high = HIDWORD(mNodeNext[1].mNodeData);
        mNodePrev->mNodeNext = mNodeNext->mNodeNext;
        mNodeNext->mNodeNext->mNodePrev = mNodePrev;
        mNodeNext->mNodePrev = mNodeNext;
        mNodeNext->mNodeNext = mNodeNext;
        closeport(&this->FMOD_OUTPUT_STATE, mNodeData_high);
        FMOD::DSPI::disconnectAll((FMOD::DSPI *const)mNodeNext[1].mNodeNext, 1, 1);
        ((void (__fastcall *)(FMOD::LinkedListNode *))mNodeNext[1].mNodeNext->mNodeNext->mNodeData)(mNodeNext[1].mNodeNext);
        mNodeData = (FMOD::OutputRingBuffer *)mNodeNext[2].mNodeData;
        if ( mNodeData )
        {
          FMOD::OutputRingBuffer::release(mNodeData);
          FMOD::MemPool::free(
            off_286F358->gSystemMemPool,
            mNodeNext[2].mNodeData,
            "../../../core_api/src/fmod_output.cpp",
            1313);
        }
        FMOD::MemPool::free(off_286F358->gSystemMemPool, mNodeNext, "../../../core_api/src/fmod_output.cpp", 1316);
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x22474a0 | Name: _ZN4FMOD16OutputRingBuffer4readEPci
FMOD_RESULT_0 __fastcall FMOD::OutputRingBuffer::read(FMOD::OutputRingBuffer *const this, char *ptr, int bytes)
{
  FMOD_RESULT_0 result; // eax
  int v5; // ebp
  signed int v6; // r13d
  __int64 mReadPosBytes; // rsi
  int mBufferSizeBytes; // eax
  int v9; // eax
  int v10; // edx
  int v11; // eax
  __int64 v12; // r14
  int v13; // r13d
  int mCurrentBlockCount; // ecx

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( ptr )
  {
    v5 = bytes;
    if ( bytes > 0 )
    {
      if ( this->mBuffer )
      {
        if ( bytes > this->mBufferSizeBytes )
        {
          memset(ptr, 0, bytes);
          v5 = 0;
        }
        v6 = this->mWriteBytes - this->mReadBytes;
        if ( v5 > v6 )
        {
          memset(ptr, 0, v5);
          mCurrentBlockCount = this->mCurrentBlockCount;
          v5 = v6;
          if ( mCurrentBlockCount < this->mBufferSize / this->mBlockSize )
            this->mCurrentBlockCount = mCurrentBlockCount + 1;
        }
        mReadPosBytes = this->mReadPosBytes;
        mBufferSizeBytes = this->mBufferSizeBytes;
        if ( (int)mReadPosBytes + v5 > mBufferSizeBytes )
        {
          v11 = mBufferSizeBytes - mReadPosBytes;
          v12 = v11;
          v13 = v11;
          memcpy_0(ptr, &this->mBuffer[mReadPosBytes], v11);
          memcpy_0(&ptr[v12], this->mBuffer, v5 - v13);
        }
        else
        {
          memcpy_0(ptr, &this->mBuffer[mReadPosBytes], v5);
        }
        v9 = this->mReadPosBytes;
        this->mReadBytes += v5;
        v10 = (v5 + v9) % this->mBufferSizeBytes;
        result = FMOD_RESULT::FMOD_OK_0;
        this->mReadPosBytes = v10;
      }
    }
  }
  return result;
}


// Address: 0x2247590 | Name: _ZN4FMOD6Output9mixOutputEPfj
FMOD_RESULT_0 __fastcall FMOD::Output::mixOutput(FMOD::Output *const this, float *buffer, unsigned int length)
{
  unsigned int v3; // r12d
  FMOD::SystemI *mSystem; // rbx
  int mDSPMaxOutputChannels; // r14d
  float *v7; // r15
  FMOD_RESULT_0 result; // eax
  float *v9; // r13
  FMOD::OutputRingBuffer *mDSPRingBuffer; // rdi
  FMOD::SystemI *v11; // rax
  FMOD_OS_SEMAPHORE *mSema; // rdi
  FMOD::DownMix *mDownMix; // rdi
  FMOD_RESULT_0 destBuffer; // [rsp+8h] [rbp-40h]

  v3 = length;
  mSystem = this->mSystem;
  mDSPMaxOutputChannels = mSystem->mDSPMaxOutputChannels;
  if ( !mSystem->mDownMix )
  {
    v9 = 0;
    v7 = buffer;
    mDSPRingBuffer = mSystem->mDSPRingBuffer;
    if ( mDSPRingBuffer )
      goto LABEL_4;
LABEL_18:
    result = FMOD::Output::mixSystem(this, v7, length);
    if ( result )
      goto LABEL_14;
    goto LABEL_5;
  }
  v7 = (float *)FMOD::MemPool::alloc(
                  &mSystem->mDSPLevelsPool,
                  4 * mDSPMaxOutputChannels * length,
                  (const char *)&uri_string,
                  0,
                  0,
                  0);
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( !v7 )
    return result;
  v9 = v7;
  length = v3;
  mDSPRingBuffer = this->mSystem->mDSPRingBuffer;
  if ( !mDSPRingBuffer )
    goto LABEL_18;
LABEL_4:
  result = FMOD::OutputRingBuffer::read(mDSPRingBuffer, (char *)v7, mDSPRingBuffer->mBytesPerSample * length);
  if ( result )
    goto LABEL_14;
LABEL_5:
  result = FMOD::Output::object3DUpdate(this, v7, mDSPMaxOutputChannels, v3);
  if ( result )
    goto LABEL_14;
  v11 = this->mSystem;
  if ( v11->mDSPRingBuffer )
  {
    mSema = this->mBufferedMixerThread.mSema;
    if ( mSema )
    {
      result = FMOD_OS_Semaphore_Signal(mSema);
      if ( result )
        goto LABEL_14;
      v11 = this->mSystem;
    }
  }
  mDownMix = v11->mDownMix;
  if ( mDownMix )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::DownMix *, float *, float *, _QWORD))mDownMix->_vptr_DownMix + 2))(
               mDownMix,
               v7,
               buffer,
               v3);
    if ( result )
      goto LABEL_14;
    v11 = this->mSystem;
  }
  result = FMOD::DSPI::reorder(buffer, v3, v11->mOutput->mSpeakerModeChannels, v11->mOutput->mChannelOrder);
LABEL_14:
  if ( v9 )
  {
    destBuffer = result;
    FMOD::MemPool::free(&mSystem->mDSPLevelsPool, v9, (const char *)&uri_string, 0);
    return destBuffer;
  }
  return result;
}


// Address: 0x2247710 | Name: _ZN4FMOD6Output19mixResampleCallbackEP14FMOD_DSP_STATEPfPjS4_Pi
FMOD_RESULT_0 __fastcall FMOD::Output::mixResampleCallback(
        FMOD_DSP_STATE *state,
        float *buffer,
        unsigned int *a3,
        unsigned int *length,
        int *a5)
{
  FMOD_DSP_STATE_FUNCTIONS *functions; // rax
  FMOD_RESULT_0 result; // eax
  FMOD::Output *output; // [rsp+8h] [rbp-20h] BYREF

  functions = state->functions;
  output = 0;
  result = ((unsigned int (__fastcall *)(FMOD_DSP_STATE *, FMOD::Output **, unsigned int *, unsigned int *, int *))functions->getuserdata)(
             state,
             &output,
             a3,
             length,
             a5);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::Output::mixOutput(output, buffer, *length);
  return result;
}


// Address: 0x2247750 | Name: _ZN4FMOD6Output3mixEPvj
FMOD_RESULT_0 __fastcall FMOD::Output::mix(FMOD::Output *const this, void *buffer, unsigned int length)
{
  bool v4; // r13
  FMOD::SystemI *mSystem; // rbp
  float *v6; // r12
  float *v7; // r15
  __int64 v8; // rdi
  FMOD_RESULT_0 v9; // ebx
  FMOD_RESULT_0 v10; // eax
  FMOD::LocalFastFloatingPoint fastFloatingPointScope; // [rsp+20h] [rbp-48h] BYREF
  int outChannels[15]; // [rsp+2Ch] [rbp-3Ch] BYREF

  v4 = this->mFormat != FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
  outChannels[0] = this->mSystem->mOutput->mSpeakerModeChannels;
  FMOD_OS_SetFastFloatingPoint(&fastFloatingPointScope.mPreviousState);
  FMOD::TimeStamp::stampIn(&this->mSystem->mDSPTimeStamp);
  mSystem = this->mSystem;
  if ( !v4 )
  {
    v6 = 0;
    v7 = (float *)buffer;
    v8 = *(unsigned __int64 *)((char *)&stru_10F50.r_offset + (_QWORD)mSystem);
    if ( v8 )
      goto LABEL_3;
LABEL_12:
    v9 = FMOD::Output::mixOutput(this, v7, length);
    if ( v9 == FMOD_RESULT::FMOD_OK_0 )
      goto LABEL_4;
    goto LABEL_7;
  }
  v9 = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v7 = (float *)FMOD::MemPool::alloc(
                  &mSystem->mDSPLevelsPool,
                  4 * outChannels[0] * length,
                  (const char *)&uri_string,
                  0,
                  0,
                  0);
  if ( !v7 )
    goto LABEL_9;
  v6 = v7;
  v8 = *(unsigned __int64 *)((char *)&stru_10F50.r_offset + (unsigned __int64)this->mSystem);
  if ( !v8 )
    goto LABEL_12;
LABEL_3:
  v9 = (*(unsigned int (__fastcall **)(__int64, float *, int *, _QWORD))(*(_QWORD *)v8 + 72LL))(
         v8,
         v7,
         outChannels,
         length);
  if ( v9 == FMOD_RESULT::FMOD_OK_0 )
  {
LABEL_4:
    if ( v4
      && (v10 = (unsigned int)FMOD::DSPI::convert(
                                (__int16 *)buffer,
                                v7,
                                this->mFormat,
                                FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0,
                                outChannels[0] * length,
                                1,
                                1.0,
                                1,
                                1)) != FMOD_RESULT::FMOD_OK_0 )
    {
      v9 = v10;
    }
    else
    {
      v9 = FMOD_RESULT::FMOD_OK_0;
      FMOD::TimeStamp::stampOut(&this->mSystem->mDSPTimeStamp, 95);
    }
  }
LABEL_7:
  if ( v6 )
    FMOD::MemPool::free(&mSystem->mDSPLevelsPool, v6, (const char *)&uri_string, 0);
LABEL_9:
  FMOD_OS_RestoreFloatingPoint(fastFloatingPointScope.mPreviousState);
  return v9;
}


// Address: 0x2247900 | Name: _ZN4FMOD6Output11mixCallbackEP17FMOD_OUTPUT_STATEPvj
FMOD_RESULT_0 __fastcall FMOD::Output::mixCallback(FMOD_OUTPUT_STATE *output, void *buffer, unsigned int length)
{
  FMOD::Output *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::Output *)&output[-1].requestreset;
  return FMOD::Output::mix(p_requestreset, buffer, length);
}


// Address: 0x2247920 | Name: _ZN4FMOD16OutputRingBuffer15writePtrAdvanceEv
char *__fastcall FMOD::OutputRingBuffer::writePtrAdvance(FMOD::OutputRingBuffer *const this)
{
  __int64 mWritePosBytes; // rcx
  int mBlockSizeBytes; // esi
  char *result; // rax

  mWritePosBytes = this->mWritePosBytes;
  mBlockSizeBytes = this->mBlockSizeBytes;
  this->mWriteBytes += mBlockSizeBytes;
  result = &this->mBuffer[mWritePosBytes];
  this->mWritePosBytes = (mBlockSizeBytes + (int)mWritePosBytes) % this->mBufferSizeBytes;
  return result;
}


// Address: 0x2247940 | Name: _ZN4FMOD6Output8copyPortEiPvj
FMOD_RESULT_0 __fastcall FMOD::Output::copyPort(FMOD::Output *const this, int id, void *buffer, unsigned int length)
{
  FMOD::LinkedListNode *mNodeNext; // r15
  FMOD_RESULT_0 result; // eax
  FMOD::OutputRingBuffer *mNodeData; // rdi
  char *v8; // r12
  char *v9; // r13
  int mBlockSize; // ebx
  int mNodePrev; // r14d
  float *v12; // rax
  FMOD::OutputRingBuffer *v13; // rdi
  char *v14; // rax
  FMOD_RESULT_0 destBuffera; // [rsp+18h] [rbp-50h]
  FMOD::SystemI *mSystem; // [rsp+20h] [rbp-48h]
  bool convert; // [rsp+2Fh] [rbp-39h]

  mNodeNext = this->mPortInfoHead.mNodeNext;
  if ( mNodeNext == &this->mPortInfoHead )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  while ( HIDWORD(mNodeNext[1].mNodeData) != id )
  {
    mNodeNext = mNodeNext->mNodeNext;
    if ( mNodeNext == &this->mPortInfoHead )
      return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  }
  mSystem = this->mSystem;
  convert = HIDWORD(mNodeNext[2].mNodeNext) != 5;
  if ( HIDWORD(mNodeNext[2].mNodeNext) == 5 )
  {
    mNodeData = (FMOD::OutputRingBuffer *)mNodeNext[2].mNodeData;
    v8 = 0;
    v9 = (char *)buffer;
    if ( mNodeData )
    {
LABEL_10:
      result = FMOD::OutputRingBuffer::read(mNodeData, v9, length * mNodeData->mBytesPerSample);
      if ( result )
        goto LABEL_11;
      while ( 1 )
      {
        v13 = (FMOD::OutputRingBuffer *)mNodeNext[2].mNodeData;
        if ( (signed int)(v13->mWriteBytes - v13->mReadBytes) > v13->mBlockSizeBytes * (v13->mCurrentBlockCount - 1) )
          break;
        mBlockSize = v13->mBlockSize;
        mNodePrev = (int)mNodeNext[2].mNodePrev;
        v12 = (float *)FMOD::OutputRingBuffer::writePtrAdvance(v13);
        result = FMOD::PortHead::Pull((FMOD::DSPI *)mNodeNext[1].mNodeNext, v12, mBlockSize, mNodePrev);
        if ( result )
          goto LABEL_11;
      }
LABEL_15:
      result = FMOD_RESULT::FMOD_OK_0;
      if ( convert )
        result = (unsigned int)FMOD::DSPI::convert(
                                 (__int16 *)buffer,
                                 (float *)v9,
                                 HIDWORD(mNodeNext[2].mNodeNext),
                                 FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0,
                                 length * LODWORD(mNodeNext[2].mNodePrev),
                                 1,
                                 1.0,
                                 1,
                                 1);
      goto LABEL_11;
    }
  }
  else
  {
    v14 = (char *)FMOD::MemPool::alloc(
                    &mSystem->mDSPLevelsPool,
                    4 * length * LODWORD(mNodeNext[2].mNodePrev),
                    (const char *)&uri_string,
                    0,
                    0,
                    0);
    v9 = v14;
    if ( !v14 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    mNodeData = (FMOD::OutputRingBuffer *)mNodeNext[2].mNodeData;
    v8 = v14;
    if ( mNodeData )
      goto LABEL_10;
  }
  result = FMOD::PortHead::Pull((FMOD::DSPI *)mNodeNext[1].mNodeNext, (float *)v9, length, (int)mNodeNext[2].mNodePrev);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    goto LABEL_15;
LABEL_11:
  if ( v8 )
  {
    destBuffera = result;
    FMOD::MemPool::free(&mSystem->mDSPLevelsPool, v8, (const char *)&uri_string, 0);
    return destBuffera;
  }
  return result;
}


// Address: 0x2247b10 | Name: _ZN4FMOD6Output16copyPortCallbackEP17FMOD_OUTPUT_STATEiPvj
FMOD_RESULT_0 __fastcall FMOD::Output::copyPortCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        void *buffer,
        unsigned int length)
{
  FMOD::Output *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::Output *)&output[-1].requestreset;
  return FMOD::Output::copyPort(p_requestreset, id, buffer, length);
}


// Address: 0x2247b30 | Name: _ZN4FMOD6Output27bufferedMixerThreadCallbackEPv
void __fastcall FMOD::Output::bufferedMixerThreadCallback(void *param)
{
  FMOD::OutputRingBuffer *v1; // rbx
  unsigned int mBlockSize; // ebp
  float *v3; // rax
  FMOD::LocalFastFloatingPoint fastFloatingPointScope; // [rsp+0h] [rbp-28h] BYREF

  v1 = *(FMOD::OutputRingBuffer **)(*((_QWORD *)param + 9) + 69464LL);
  FMOD_OS_SetFastFloatingPoint(&fastFloatingPointScope.mPreviousState);
  while ( (signed int)(v1->mWriteBytes - v1->mReadBytes) <= v1->mBlockSizeBytes * (v1->mCurrentBlockCount - 1) )
  {
    mBlockSize = v1->mBlockSize;
    v3 = (float *)FMOD::OutputRingBuffer::writePtrAdvance(v1);
    FMOD::Output::mixSystem((FMOD::Output *const)param, v3, mBlockSize);
  }
  FMOD_OS_RestoreFloatingPoint(fastFloatingPointScope.mPreviousState);
}


// Address: 0x2247b90 | Name: _ZN4FMOD16OutputRingBuffer14readPtrAdvanceEv
char *__fastcall FMOD::OutputRingBuffer::readPtrAdvance(FMOD::OutputRingBuffer *const this)
{
  __int64 mReadPosBytes; // rcx
  int mBlockSizeBytes; // esi
  char *result; // rax

  mReadPosBytes = this->mReadPosBytes;
  mBlockSizeBytes = this->mBlockSizeBytes;
  this->mReadBytes += mBlockSizeBytes;
  result = &this->mBuffer[mReadPosBytes];
  this->mReadPosBytes = (mBlockSizeBytes + (int)mReadPosBytes) % this->mBufferSizeBytes;
  return result;
}


