// Address: 0x2213ac0 | Name: _ZN4FMOD7DSPSend16getDescriptionExEv
FMOD::FMOD_DSP_DESCRIPTION_EX *__cdecl FMOD::DSPSend::getDescriptionEx()
{
  memset(&stru_2AF6F20, 0, sizeof(stru_2AF6F20));
  stru_2AF6F20.type = FMOD_DSP_PARAMETER_TYPE_INT;
  FMOD_strcpy_safe(stru_2AF6F20.name, "Return ID", 16);
  FMOD_strcpy_safe(stru_2AF6F20.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF6F20.floatdesc.min = 0xF4240FFFFFFFFLL;
  stru_2AF6F20.description = "ID of the Return DSP this send is connected to (integer values only). -1 indicates no conne"
                             "cted Return DSP.";
  memset(&stru_2AF6EC0, 0, sizeof(stru_2AF6EC0));
  *(_OWORD *)(&stru_2AF6F20.datadesc + 2) = 0xFFFFFFFF;
  FMOD_strcpy_safe(stru_2AF6EC0.name, "Send Level", 16);
  FMOD_strcpy_safe(stru_2AF6EC0.label, (const char *)&uri_string, 16);
  *(_QWORD *)&stru_2AF6EC0.floatdesc.min = 0x4120000000000000LL;
  stru_2AF6EC0.description = "Send Level";
  memset(&stru_2AF6E60, 0, sizeof(stru_2AF6E60));
  stru_2AF6EC0.intdesc.defaultval = 1065353216;
  stru_2AF6EC0.floatdesc.mapping.type = FMOD_DSP_PARAMETER_FLOAT_MAPPING_TYPE_AUTO;
  stru_2AF6E60.type = FMOD_DSP_PARAMETER_TYPE_DATA;
  FMOD_strcpy_safe(stru_2AF6E60.name, "Overall Gain", 16);
  FMOD_strcpy_safe(stru_2AF6E60.label, (const char *)&uri_string, 16);
  stru_2AF6E60.intdesc.min = -1;
  *(&stru_2AF6E20.mHandle + 1) = 24;
  stru_2AF6E20.mSize = 600;
  stru_2AF6E60.description = "Overall Gain";
  stru_2AF6E20.mDescription = &stru_286C7C0;
  stru_2AF6E20.mCommand = FMOD::DSPSend::commandCallback;
  stru_2AF6E20.mCommandMask = 128;
  return &stru_2AF6E20;
}


// Address: 0x2213c80 | Name: _ZN4FMOD7DSPSend14createInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPSend::createInternal(FMOD::DSPSend *const this)
{
  double v1; // xmm1_8
  __int64 v2; // rbp
  __int64 v3; // rdx
  int v4; // ebx
  int v5; // eax
  _DWORD *v6; // rcx
  FMOD_RESULT_0 result; // eax

  v2 = 0;
  v3 = *((_QWORD *)this + 30);
  v4 = 0;
  *((_BYTE *)this + 596) = 0;
  *((_WORD *)this + 46) |= 0x20u;
  *((_DWORD *)this + 137) = 1065353216;
  *((_DWORD *)this + 132) = 1065353216;
  v5 = *(_DWORD *)(v3 + 96);
  *((_DWORD *)this + 134) = 1065353216;
  *((_DWORD *)this + 148) = -1;
  *((_DWORD *)this + 136) = -1;
  if ( v5 > 0 )
  {
    do
    {
      while ( 1 )
      {
        v6 = *(_DWORD **)(*(_QWORD *)(v3 + 104) + v2);
        if ( *v6 != 1 )
          break;
        result = FMOD::DSPI::setParameterInt((FMOD::DSPI *const)this, v4, v6[14]);
        if ( result )
          return result;
LABEL_7:
        v3 = *((_QWORD *)this + 30);
        ++v4;
        v2 += 8;
        if ( *(_DWORD *)(v3 + 96) <= v4 )
          return FMOD_RESULT::FMOD_OK_0;
      }
      if ( !*v6 )
      {
        result = FMOD::DSPI::setParameterFloat((FMOD::DSPI *const)this, v4, (__m128i)(unsigned int)v6[14], v1);
        if ( result )
          return result;
        goto LABEL_7;
      }
      ++v4;
      v2 += 8;
    }
    while ( *(_DWORD *)(v3 + 96) > v4 );
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2213d50 | Name: _ZN4FMOD7DSPSend14createCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPSend::createCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPSend::createInternal((FMOD::DSPSend *const)dsp_state->instance);
}


// Address: 0x2213d60 | Name: _ZN4FMOD7DSPSend13resetInternalEv
FMOD_RESULT_0 __fastcall FMOD::DSPSend::resetInternal(FMOD::DSPSend *const this)
{
  *((_DWORD *)this + 132) = *((_DWORD *)this + 134);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2213d80 | Name: _ZN4FMOD7DSPSend13resetCallbackEP14FMOD_DSP_STATE
FMOD_RESULT_0 __fastcall FMOD::DSPSend::resetCallback(FMOD_DSP_STATE *dsp_state)
{
  return FMOD::DSPSend::resetInternal((FMOD::DSPSend *const)dsp_state->instance);
}


// Address: 0x2213d90 | Name: _ZNK4FMOD7DSPSend9getReturnEv
FMOD::DSPReturn *__fastcall FMOD::DSPSend::getReturn(const FMOD::DSPSend *const this)
{
  return (FMOD::DSPReturn *)*((_QWORD *)this + 70);
}


// Address: 0x2213da0 | Name: _ZN4FMOD7DSPSend15processInternalEjPK21FMOD_DSP_BUFFER_ARRAYPS1_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPSend::processInternal(
        FMOD::DSPSend *const this,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  float v6; // xmm1_4
  float *v8; // r12
  float *v9; // r13
  int v10; // r14d
  FMOD::DSPReturn *Return; // rax
  __int64 v12; // rdx
  bool v13; // zf
  float *v14; // rcx
  float *v15; // r10
  char v16; // si
  unsigned __int8 v17; // cl
  int v18; // r8d
  unsigned int v19; // edx
  FMOD_RESULT_0 result; // eax
  float *v21; // r10
  int v22; // r8d
  unsigned __int8 v23; // cl
  size_t v24; // rdx
  float *backbuffer; // [rsp+10h] [rbp-F8h]
  int outchannels; // [rsp+18h] [rbp-F0h]
  unsigned __int8 v27; // [rsp+1Ch] [rbp-ECh]
  FMOD::DSPConnectionI connection; // [rsp+20h] [rbp-E8h] BYREF

  if ( op == FMOD_DSP_PROCESS_QUERY )
  {
    if ( outbufferarray )
    {
      *outbufferarray->buffernumchannels = *inbufferarray->buffernumchannels;
      outbufferarray->speakermode = inbufferarray->speakermode;
    }
    result = FMOD_RESULT::FMOD_ERR_DSP_SILENCE_0;
    if ( !inputsidle )
    {
      if ( FMOD::DSPSend::getReturn(this) )
      {
        if ( *((float *)this + 134) != 0.0 )
          return FMOD_RESULT::FMOD_OK_0;
        result = FMOD_RESULT::FMOD_ERR_DSP_DONTPROCESS_0;
        if ( *((float *)this + 132) != 0.0 )
          return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        return FMOD_RESULT::FMOD_ERR_DSP_DONTPROCESS_0;
      }
    }
  }
  else
  {
    v8 = *inbufferarray->buffers;
    v9 = *outbufferarray->buffers;
    v10 = *inbufferarray->buffernumchannels;
    if ( !FMOD::DSPSend::getReturn(this) )
      goto LABEL_9;
    Return = FMOD::DSPSend::getReturn(this);
    connection.mInputNode.mNodePrev = &connection.mInputNode;
    connection.mInputNode.mNodeNext = &connection.mInputNode;
    connection.mMixMatrix.mOutChannels = 0;
    connection.mInputNode.mNodeData = 0;
    connection.mOutputNode.mNodePrev = &connection.mOutputNode;
    connection.mOutputNode.mNodeNext = &connection.mOutputNode;
    connection.mMixMatrix.mInChannels = 0;
    v12 = *((_QWORD *)Return + 1);
    v13 = v12 == *((_QWORD *)Return + 71);
    connection.mOutputNode.mNodeData = 0;
    connection.mMixMatrix.mData = 0;
    memset(&connection.mMixMatrixCurrent.mData, 0, 24);
    connection.mMixMatrixCurrent.mInChannels = 0;
    connection.mMixMatrixCurrent.mOutChannels = 0;
    connection.mUserData.mMixMatrixUser.mData = 0;
    connection.mUserData.mMixMatrixUser.mInChannels = 0;
    connection.mUserData.mMixMatrixUser.mOutChannels = 0;
    connection.mSystem = 0;
    v14 = (float *)*((_QWORD *)Return + 67);
    v15 = (float *)*((_QWORD *)Return + 68);
    if ( v13 )
    {
      v17 = *((_BYTE *)Return + 577);
    }
    else
    {
      v16 = *((_BYTE *)Return + 577);
      *((_QWORD *)Return + 67) = v15;
      v15 = v14;
      *((_QWORD *)Return + 68) = v14;
      *((_QWORD *)Return + 71) = v12;
      v17 = 0;
      *((_BYTE *)Return + 576) = v16;
    }
    v18 = *((_DWORD *)Return + 139);
    v19 = *((_DWORD *)Return + 140);
    *((_BYTE *)Return + 577) = 1;
    result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
    if ( length * v18 <= v19 )
    {
      v27 = v17;
      outchannels = v18;
      backbuffer = v15;
      if ( (unsigned int)(*((_DWORD *)this + 22) - *((_DWORD *)this + 135)) <= 1 )
      {
        FMOD::DSPConnectionI::init(&connection, *((FMOD::SystemI **)this + 22), *((float *)this + 132), v6);
        FMOD::DSPConnectionI::setMixInternal(&connection, *((float *)this + 134), 0x40u, 0);
        v23 = v27;
        v22 = outchannels;
        v21 = backbuffer;
      }
      else
      {
        FMOD::DSPConnectionI::init(&connection, *((FMOD::SystemI **)this + 22), *((float *)this + 134), v6);
        v21 = backbuffer;
        v22 = outchannels;
        v23 = v27;
      }
      *((_DWORD *)this + 132) = *((_DWORD *)this + 134);
      result = FMOD::DSPConnectionI::mix(&connection, v21, v8, 0, v22, v10, length, v23 ^ 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
LABEL_9:
        v24 = 4LL * v10 * length;
        if ( *((_BYTE *)this + 596) )
        {
          memset(v9, 0, v24);
          return FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          memcpy_0(v9, v8, v24);
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x22140a0 | Name: _ZN4FMOD7DSPSend15processCallbackEP14FMOD_DSP_STATEjPK21FMOD_DSP_BUFFER_ARRAYPS3_i26FMOD_DSP_PROCESS_OPERATION
FMOD_RESULT_0 __fastcall FMOD::DSPSend::processCallback(
        FMOD_DSP_STATE *dsp_state,
        unsigned int length,
        const FMOD_DSP_BUFFER_ARRAY *inbufferarray,
        FMOD_DSP_BUFFER_ARRAY *outbufferarray,
        FMOD_BOOL inputsidle,
        FMOD_DSP_PROCESS_OPERATION op)
{
  return FMOD::DSPSend::processInternal(
           (FMOD::DSPSend *const)dsp_state->instance,
           length,
           inbufferarray,
           outbufferarray,
           inputsidle,
           op);
}


// Address: 0x22140b0 | Name: _ZN4FMOD7DSPSend25setParameterFloatInternalEif
__int64 __fastcall FMOD::DSPSend::setParameterFloatInternal(
        FMOD::DSPSend *const this,
        int index,
        float a3,
        float value)
{
  int v4; // eax

  if ( index == 1 )
  {
    v4 = *((_DWORD *)this + 22);
    *((float *)this + 134) = a3;
    *((_DWORD *)this + 135) = v4;
  }
  return 0;
}


// Address: 0x22140d0 | Name: _ZN4FMOD7DSPSend25setParameterFloatCallbackEP14FMOD_DSP_STATEif
__int64 __fastcall FMOD::DSPSend::setParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float a3,
        float value)
{
  return FMOD::DSPSend::setParameterFloatInternal((FMOD::DSPSend *const)dsp_state->instance, index, a3, value);
}


// Address: 0x22140e0 | Name: _ZN4FMOD7DSPSend25getParameterFloatInternalEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPSend::getParameterFloatInternal(
        FMOD::DSPSend *const this,
        int index,
        float *value,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( value )
  {
    if ( index == 1 && (*value = *((float *)this + 134), valuestr) )
    {
      sprintf(valuestr, "%.02f", *((float *)this + 134));
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2214140 | Name: _ZN4FMOD7DSPSend25getParameterFloatCallbackEP14FMOD_DSP_STATEiPfPc
FMOD_RESULT_0 __fastcall FMOD::DSPSend::getParameterFloatCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        float *value,
        char *valuestr)
{
  return FMOD::DSPSend::getParameterFloatInternal((FMOD::DSPSend *const)dsp_state->instance, index, value, valuestr);
}


// Address: 0x2214150 | Name: _ZN4FMOD7DSPSend23setParameterIntInternalEii
FMOD_RESULT_0 __fastcall FMOD::DSPSend::setParameterIntInternal(FMOD::DSPSend *const this, int index, int value)
{
  FMOD_RESULT_0 result; // eax
  FMOD::DSPQueueCmd_ConnectSendToReturn *v6; // rsi
  FMOD::SystemI *v7; // rdi
  FMOD::DSPQueueCmd_ConnectSendToReturn *cmd; // [rsp+0h] [rbp-20h] BYREF

  result = FMOD_RESULT::FMOD_OK_0;
  if ( !index )
  {
    result = FMOD::SystemI::lockDSPQueueCmd(*((FMOD::SystemI *const *)this + 22), (void **)&cmd, 24, 1);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v6 = cmd;
      v7 = (FMOD::SystemI *)*((_QWORD *)this + 22);
      *(_BYTE *)&cmd->FMOD::DSPQueueCmd = 9;
      v6->mThis = (FMOD::DSPI *)this;
      v6->mReturnID = value;
      result = FMOD::SystemI::unlockDSPQueueCmd(v7, v6, 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
        *((_DWORD *)this + 136) = value;
    }
  }
  return result;
}


// Address: 0x22141d0 | Name: _ZN4FMOD7DSPSend23setParameterIntCallbackEP14FMOD_DSP_STATEii
FMOD_RESULT_0 __fastcall FMOD::DSPSend::setParameterIntCallback(FMOD_DSP_STATE *dsp_state, int index, int value)
{
  return FMOD::DSPSend::setParameterIntInternal((FMOD::DSPSend *const)dsp_state->instance, index, value);
}


// Address: 0x22141e0 | Name: _ZN4FMOD7DSPSend23getParameterIntInternalEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPSend::getParameterIntInternal(
        FMOD::DSPSend *const this,
        int index,
        int *value,
        char *valuestr)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( value )
  {
    if ( index )
      return FMOD_RESULT::FMOD_OK_0;
    *value = *((_DWORD *)this + 136);
    if ( !valuestr )
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      sprintf(valuestr, "%d", *((_DWORD *)this + 136));
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x2214230 | Name: _ZN4FMOD7DSPSend23getParameterIntCallbackEP14FMOD_DSP_STATEiPiPc
FMOD_RESULT_0 __fastcall FMOD::DSPSend::getParameterIntCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        int *value,
        char *valuestr)
{
  return FMOD::DSPSend::getParameterIntInternal((FMOD::DSPSend *const)dsp_state->instance, index, value, valuestr);
}


// Address: 0x2214240 | Name: _ZN4FMOD7DSPSend24setParameterDataInternalEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPSend::setParameterDataInternal(
        FMOD::DSPSend *const this,
        int index,
        void *data,
        unsigned int length)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( index == 2 )
    return FMOD_RESULT::FMOD_OK_0;
  return result;
}


// Address: 0x2214260 | Name: _ZN4FMOD7DSPSend24setParameterDataCallbackEP14FMOD_DSP_STATEiPvj
FMOD_RESULT_0 __fastcall FMOD::DSPSend::setParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void *data,
        unsigned int length)
{
  return FMOD::DSPSend::setParameterDataInternal((FMOD::DSPSend *const)dsp_state->instance, index, data, length);
}


// Address: 0x2214270 | Name: _ZN4FMOD7DSPSend24getParameterDataInternalEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPSend::getParameterDataInternal(
        FMOD::DSPSend *const this,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  float v6; // xmm0_4
  FMOD::DSPReturn *Return; // rax
  void **dataa; // [rsp+0h] [rbp-20h]
  unsigned int *lengtha; // [rsp+8h] [rbp-18h]
  char *valuestra; // [rsp+10h] [rbp-10h]

  if ( index != 2 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v6 = 0.0;
  if ( *((_DWORD *)this + 136) != -1 )
  {
    valuestra = valuestr;
    lengtha = length;
    dataa = data;
    Return = FMOD::DSPSend::getReturn(this);
    data = dataa;
    length = lengtha;
    valuestr = valuestra;
    if ( Return )
      v6 = *((float *)Return + 155);
    else
      v6 = 1.0;
  }
  *((float *)this + 138) = v6 * *((float *)this + 134);
  *data = (char *)this + 548;
  *length = 8;
  if ( valuestr )
    *valuestr = 0;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2214310 | Name: _ZN4FMOD7DSPSend24getParameterDataCallbackEP14FMOD_DSP_STATEiPPvPjPc
FMOD_RESULT_0 __fastcall FMOD::DSPSend::getParameterDataCallback(
        FMOD_DSP_STATE *dsp_state,
        int index,
        void **data,
        unsigned int *length,
        char *valuestr)
{
  return FMOD::DSPSend::getParameterDataInternal(
           (FMOD::DSPSend *const)dsp_state->instance,
           index,
           data,
           length,
           valuestr);
}


// Address: 0x2214320 | Name: _ZN4FMOD7DSPSend13connectReturnEi
FMOD_RESULT_0 __fastcall FMOD::DSPSend::connectReturn(FMOD::DSPSend *const this, int id)
{
  FMOD::DSPReturn *v2; // rbp
  FMOD::DSPReturn *v4; // rdi
  FMOD_RESULT_0 v5; // edx
  FMOD::SystemI *v6; // r12
  FMOD::SystemI *v7; // r13
  char v8; // r14
  char v9; // r15
  FMOD_RESULT_0 v10; // eax
  FMOD_RESULT_0 v12; // [rsp+Ch] [rbp-3Ch]
  FMOD_RESULT_0 v13; // [rsp+Ch] [rbp-3Ch]

  v2 = 0;
  if ( id != -1 )
    v2 = FMOD::ReturnTable::find((const FMOD::ReturnTable *const)(*((_QWORD *)this + 22) + 75232LL), id);
  v4 = (FMOD::DSPReturn *)*((_QWORD *)this + 70);
  v5 = FMOD_RESULT::FMOD_OK_0;
  if ( v4 != v2 )
  {
    v6 = (FMOD::SystemI *)*((_QWORD *)this + 22);
    if ( v6 )
    {
      FMOD::SystemI::enterCrit(*((FMOD::SystemI *const *)this + 22), FMOD_SYSTEM_CRIT_DSPMIXER);
      v7 = (FMOD::SystemI *)*((_QWORD *)this + 22);
      if ( v7 )
      {
        v8 = 1;
        FMOD::SystemI::enterCrit(*((FMOD::SystemI *const *)this + 22), FMOD_SYSTEM_CRIT_DSPQUEUE);
        v4 = (FMOD::DSPReturn *)*((_QWORD *)this + 70);
        v9 = 1;
      }
      else
      {
        v4 = (FMOD::DSPReturn *)*((_QWORD *)this + 70);
        v8 = 1;
        v9 = 0;
      }
    }
    else
    {
      v8 = 0;
      v9 = 0;
      v7 = 0;
    }
    if ( v4 && (v10 = FMOD::DSPReturn::removeSend(v4, this)) != FMOD_RESULT::FMOD_OK_0
      || v2 && (v10 = FMOD::DSPReturn::addSend(v2, this)) != FMOD_RESULT::FMOD_OK_0 )
    {
      v5 = v10;
      if ( v9 && v7 )
      {
        v13 = v10;
        FMOD::SystemI::leaveCrit(v7, FMOD_SYSTEM_CRIT_DSPQUEUE);
        v5 = v13;
      }
      if ( v8 && v6 )
      {
        v12 = v5;
        FMOD::SystemI::leaveCrit(v6, FMOD_SYSTEM_CRIT_DSPMIXER);
        return v12;
      }
    }
    else
    {
      *((_QWORD *)this + 70) = v2;
      if ( v9 && v7 )
        FMOD::SystemI::leaveCrit(v7, FMOD_SYSTEM_CRIT_DSPQUEUE);
      if ( v8 && v6 )
      {
        FMOD::SystemI::leaveCrit(v6, FMOD_SYSTEM_CRIT_DSPMIXER);
        return FMOD_RESULT::FMOD_OK_0;
      }
      else
      {
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return v5;
}


// Address: 0x22144c0 | Name: _ZN4FMOD7DSPSend16disconnectReturnEv
FMOD_RESULT_0 __fastcall FMOD::DSPSend::disconnectReturn(FMOD::DSPSend *const this)
{
  FMOD::SystemI *v1; // rbp
  FMOD::SystemI *v2; // r12
  char v3; // r14
  char v4; // r15
  FMOD_RESULT_0 v5; // r13d
  FMOD::DSPReturn *Return; // rax

  v1 = (FMOD::SystemI *)*((_QWORD *)this + 22);
  if ( v1 )
  {
    FMOD::SystemI::enterCrit(*((FMOD::SystemI *const *)this + 22), FMOD_SYSTEM_CRIT_DSPMIXER);
    v2 = (FMOD::SystemI *)*((_QWORD *)this + 22);
    v3 = 1;
    if ( v2 )
    {
      v4 = 1;
      FMOD::SystemI::enterCrit(*((FMOD::SystemI *const *)this + 22), FMOD_SYSTEM_CRIT_DSPQUEUE);
    }
    else
    {
      v4 = 0;
    }
  }
  else
  {
    v2 = 0;
    v3 = 0;
    v4 = 0;
  }
  v5 = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( FMOD::DSPSend::getReturn(this)
    && (Return = FMOD::DSPSend::getReturn(this),
        (v5 = FMOD::DSPReturn::removeSend(Return, this)) == FMOD_RESULT::FMOD_OK_0) )
  {
    *((_QWORD *)this + 70) = 0;
    if ( !v4 )
      goto LABEL_7;
  }
  else if ( !v4 )
  {
    goto LABEL_7;
  }
  if ( !v2 )
  {
LABEL_7:
    if ( !v3 )
      return v5;
    goto LABEL_12;
  }
  FMOD::SystemI::leaveCrit(v2, FMOD_SYSTEM_CRIT_DSPQUEUE);
  if ( !v3 )
    return v5;
LABEL_12:
  if ( v1 )
    FMOD::SystemI::leaveCrit(v1, FMOD_SYSTEM_CRIT_DSPMIXER);
  return v5;
}


// Address: 0x22145d0 | Name: _ZN4FMOD7DSPSend15commandInternalEjPvS1_
FMOD_RESULT_0 __fastcall FMOD::DSPSend::commandInternal(
        FMOD::DSPSend *const this,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *param1,
        void *param2)
{
  if ( type != 128 )
    return FMOD_RESULT::FMOD_OK_0;
  if ( FMOD::DSPSend::getReturn(this) )
    return FMOD::DSPSend::disconnectReturn(this);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2214610 | Name: _ZN4FMOD7DSPSend15commandCallbackEP14FMOD_DSP_STATEjPvS3_
FMOD_RESULT_0 __fastcall FMOD::DSPSend::commandCallback(
        FMOD_DSP_STATE *dsp_state,
        FMOD::FMOD_DSP_COMMAND_TYPE type,
        void *param1,
        void *param2)
{
  return FMOD::DSPSend::commandInternal((FMOD::DSPSend *const)dsp_state->instance, type, param1, param2);
}


