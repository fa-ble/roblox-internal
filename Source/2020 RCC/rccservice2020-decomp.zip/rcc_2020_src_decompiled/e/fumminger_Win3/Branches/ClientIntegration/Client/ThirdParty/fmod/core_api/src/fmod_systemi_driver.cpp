// Address: 0x21deea0 | Name: _ZN4FMOD7SystemI10stopDriverEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::stopDriver(FMOD::SystemI *const this)
{
  FMOD_RESULT_0 updated; // ebp
  __int64 v4; // r12
  FMOD_RESULT_0 v5; // eax
  FMOD::Output *mOutput; // rdi
  void (__fastcall *close)(FMOD_OUTPUT_STATE *); // rax
  __int64 v8; // rdi
  FMOD::OutputRingBuffer *mDSPRingBuffer; // rdi

  updated = FMOD::SystemI::updateInternal(this, 0);
  if ( updated == FMOD_RESULT::FMOD_OK_0 )
  {
    updated = FMOD::SystemI::flushDSPQueue(this, 1);
    if ( updated == FMOD_RESULT::FMOD_OK_0 )
    {
      v4 = 0;
      if ( this->mNumRecordDrivers <= 0 )
      {
LABEL_8:
        FMOD::Output::stop(this->mOutput);
        mOutput = this->mOutput;
        close = (void (__fastcall *)(FMOD_OUTPUT_STATE *))mOutput->mDescription.close;
        if ( close )
          close(&mOutput->FMOD_OUTPUT_STATE);
        v8 = *(unsigned __int64 *)((char *)&stru_10F50.r_offset + (_QWORD)this);
        if ( v8 )
        {
          updated = (*(unsigned int (__fastcall **)(__int64))(*(_QWORD *)v8 + 16LL))(v8);
          if ( updated )
            return updated;
          FMOD::MemPool::free(
            off_286F358->gSystemMemPool,
            *(void **)((char *)&stru_10F50.r_offset + (_QWORD)this),
            "../../../core_api/src/fmod_systemi_driver.cpp",
            263);
          *(unsigned __int64 *)((char *)&stru_10F50.r_offset + (_QWORD)this) = 0;
        }
        mDSPRingBuffer = this->mDSPRingBuffer;
        updated = FMOD_RESULT::FMOD_OK_0;
        if ( mDSPRingBuffer )
        {
          FMOD::OutputRingBuffer::release(mDSPRingBuffer);
          FMOD::MemPool::free(
            off_286F358->gSystemMemPool,
            this->mDSPRingBuffer,
            "../../../core_api/src/fmod_systemi_driver.cpp",
            272);
          this->mDSPRingBuffer = 0;
        }
      }
      else
      {
        while ( 1 )
        {
          if ( this->mRecordCache[v4].info )
          {
            v5 = FMOD::SystemI::recordStop(this, updated);
            if ( v5 )
              return v5;
          }
          ++updated;
          ++v4;
          if ( updated >= this->mNumRecordDrivers )
            goto LABEL_8;
        }
      }
    }
  }
  return updated;
}


// Address: 0x21defe0 | Name: _ZN4FMOD7SystemI21createOutputResamplerEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::createOutputResampler(FMOD::SystemI *const this)
{
  unsigned int mDSPBlockSize; // eax
  FMOD::FMOD_DSP_DESCRIPTION_EX *Description; // rax
  void *mModule; // rdx
  FMOD::DSPResampler *v5; // rax
  unsigned __int64 v6; // rbx
  FMOD_RESULT_0 result; // eax
  __int64 *v8; // rdi
  FMOD::Output *mOutput; // rax
  float mSampleRate; // xmm0_4
  __int64 v11; // rax
  FMOD::DSPResampler_Param param; // [rsp+0h] [rbp-68h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_EX desc; // [rsp+10h] [rbp-58h] BYREF

  mDSPBlockSize = this->mDSPBlockSize;
  param.allocbuffer = 1;
  param.format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
  param.blocklen = mDSPBlockSize;
  param.channels = this->mOutput->mSpeakerModeChannels;
  Description = FMOD::DSPResampler::getDescriptionEx();
  desc.mDescription = Description->mDescription;
  desc.mName = Description->mName;
  *(_QWORD *)&desc.mSize = *(_QWORD *)&Description->mSize;
  *(_QWORD *)(&desc.mHandle + 1) = *(_QWORD *)(&Description->mHandle + 1);
  desc.mParameter = Description->mParameter;
  mModule = Description->mModule;
  desc.mParameter = &param;
  desc.mModule = mModule;
  *(_QWORD *)&desc.mChannels = *(_QWORD *)&Description->mChannels;
  desc.mCommand = Description->mCommand;
  v5 = (FMOD::DSPResampler *)FMOD::MemPool::calloc(
                               off_286F358->gSystemMemPool,
                               728,
                               "../../../core_api/src/fmod_systemi_driver.cpp",
                               404,
                               0);
  v6 = (unsigned __int64)v5;
  if ( v5 )
  {
    FMOD::DSPResampler::DSPResampler(v5);
    *(_QWORD *)(v6 + 704) = 0;
    *(_QWORD *)(v6 + 712) = 0;
    *(_QWORD *)(v6 + 720) = 0;
    *(_QWORD *)v6 = off_29B10F0;
    *(_QWORD *)(v6 + 696) = v6 + 704;
    *(unsigned __int64 *)((char *)&stru_10F50.r_offset + (_QWORD)this) = v6;
    *(_QWORD *)(v6 + 176) = this;
    *(_QWORD *)(v6 + 224) = &this->mDSPFunctions;
    *(_DWORD *)(v6 + 232) = *(_DWORD *)((char *)&stru_115E0.r_offset + (_QWORD)this);
    result = FMOD::DSPI::alloc((FMOD::DSPI *const)v6, &desc);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v8 = *(__int64 **)((char *)&stru_10F50.r_offset + (_QWORD)this);
      v8[82] = (__int64)FMOD::Output::mixResampleCallback;
      mOutput = this->mOutput;
      *((_DWORD *)v8 + 172) = -1;
      mSampleRate = (float)mOutput->mSampleRate;
      v8[62] = (__int64)mOutput;
      v11 = *v8;
      *((float *)v8 + 138) = mSampleRate;
      result = (*(unsigned int (__fastcall **)(float))(v11 + 56))((float)this->mDSPSampleRate);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = (*(unsigned int (__fastcall **)(_QWORD, _QWORD, _QWORD, _QWORD))(**(_QWORD **)((char *)&stru_10F50.r_offset
                                                                                              + (_QWORD)this)
                                                                                + 40LL))(
                   *(unsigned __int64 *)((char *)&stru_10F50.r_offset + (_QWORD)this),
                   0,
                   0,
                   0);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          result = FMOD::DSPI::setActive(*(FMOD::DSPI *const *)((char *)&stru_10F50.r_offset + (_QWORD)this), 1, 1);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
            *(_WORD *)(*(unsigned __int64 *)((char *)&stru_10F50.r_offset + (_QWORD)this) + 92) |= 0x800u;
        }
      }
    }
  }
  else
  {
    *(unsigned __int64 *)((char *)&stru_10F50.r_offset + (_QWORD)this) = 0;
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
  return result;
}


// Address: 0x21df1d0 | Name: _ZN4FMOD7SystemI22createOutputRingBufferEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::createOutputRingBuffer(FMOD::SystemI *const this)
{
  int mDSPMaxOutputChannels; // ebp
  FMOD::OutputRingBuffer *v2; // rax
  int v3; // edx
  unsigned int v4; // esi
  int blockCount; // [rsp+8h] [rbp-20h] BYREF
  unsigned int blockSize[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  blockCount = 0;
  blockSize[0] = 0;
  FMOD::SystemI::getDSPBufferSize(this, blockSize, &blockCount);
  mDSPMaxOutputChannels = this->mDSPMaxOutputChannels;
  v2 = (FMOD::OutputRingBuffer *)FMOD::MemPool::calloc(
                                   off_286F358->gSystemMemPool,
                                   48,
                                   "../../../core_api/src/fmod_systemi_driver.cpp",
                                   451,
                                   0);
  if ( v2 )
  {
    v3 = blockCount;
    v4 = blockSize[0];
    this->mDSPRingBuffer = v2;
    return FMOD::OutputRingBuffer::init(v2, v4, v3, 4 * mDSPMaxOutputChannels, 0);
  }
  else
  {
    this->mDSPRingBuffer = 0;
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
}


// Address: 0x21df270 | Name: _ZN4FMOD7SystemI11startDriverEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::startDriver(FMOD::SystemI *const this, int driver)
{
  FMOD::Output *mOutput; // rdi
  unsigned int (__fastcall *getnumdrivers)(FMOD_OUTPUT_STATE *, int *); // rax
  FMOD_RESULT_0 result; // eax
  FMOD::Output *v7; // rdi
  unsigned int (__fastcall *init)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _DWORD, _DWORD, _QWORD); // r10
  int mDSPSampleRate; // eax
  int mDSPMaxOutputChannels; // edx
  unsigned int mDSPBlockSize; // esi
  FMOD_INITFLAGS mFlags; // r11d
  unsigned int mDSPBufferSize; // eax
  FMOD::Output *v14; // rax
  FMOD_SPEAKERMODE_0 v15; // edx
  FMOD::DownMix *mDownMix; // rdi
  FMOD::DownMix *v17; // rax
  FMOD::Output *v18; // rsi
  int v19; // r9d
  int numDrivers; // [rsp+2Ch] [rbp-2Ch] BYREF
  int rate; // [rsp+30h] [rbp-28h] BYREF
  FMOD_SPEAKERMODE_0 speakermode; // [rsp+34h] [rbp-24h] BYREF
  FMOD_SOUND_FORMAT_0 format; // [rsp+38h] [rbp-20h] BYREF
  int speakermodechannels[7]; // [rsp+3Ch] [rbp-1Ch] BYREF

  mOutput = this->mOutput;
  numDrivers = 0;
  getnumdrivers = (unsigned int (__fastcall *)(FMOD_OUTPUT_STATE *, int *))mOutput->mDescription.getnumdrivers;
  if ( getnumdrivers )
  {
    result = getnumdrivers(&mOutput->FMOD_OUTPUT_STATE, &numDrivers);
    if ( result )
      return result;
  }
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( driver < -1 || driver >= numDrivers )
    return result;
  v7 = this->mOutput;
  init = (unsigned int (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _DWORD, _DWORD, _QWORD))v7->mDescription.init;
  if ( init )
  {
    mDSPSampleRate = this->mDSPSampleRate;
    format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
    rate = mDSPSampleRate;
    speakermode = this->mSpeakerMode;
    if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
    {
      mDSPMaxOutputChannels = this->mDSPMaxOutputChannels;
      goto LABEL_15;
    }
    if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    {
      mDSPMaxOutputChannels = 5;
      goto LABEL_15;
    }
    if ( speakermode <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    {
      if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
      {
LABEL_14:
        mDSPMaxOutputChannels = 2;
LABEL_15:
        mDSPBlockSize = this->mDSPBlockSize;
        mFlags = this->mFlags;
        mDSPBufferSize = this->mDSPBufferSize;
        speakermodechannels[0] = mDSPMaxOutputChannels;
        result = init(
                   &v7->FMOD_OUTPUT_STATE,
                   (unsigned int)driver,
                   mFlags,
                   &rate,
                   &speakermode,
                   speakermodechannels,
                   &format,
                   mDSPBlockSize,
                   mDSPBufferSize / mDSPBlockSize,
                   0);
        if ( result )
          return result;
        v14 = this->mOutput;
        v14->mSampleRate = rate;
        v15 = speakermode;
        v14->mNeedReset = 0;
        v14->mSpeakerMode = v15;
        v14->mFormat = format;
        v14->mSpeakerModeChannels = speakermodechannels[0];
        goto LABEL_17;
      }
      mDSPMaxOutputChannels = 4;
      if ( speakermode > FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
        goto LABEL_15;
      LOBYTE(mDSPMaxOutputChannels) = 1;
      if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0 )
        goto LABEL_15;
    }
    else
    {
      mDSPMaxOutputChannels = 8;
      if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
        goto LABEL_15;
      LOBYTE(mDSPMaxOutputChannels) = 6;
      if ( speakermode < FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
        goto LABEL_15;
      LOBYTE(mDSPMaxOutputChannels) = 12;
      if ( speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
        goto LABEL_15;
      if ( speakermode == 1000 )
        goto LABEL_14;
    }
    mDSPMaxOutputChannels = 0;
    goto LABEL_15;
  }
LABEL_17:
  result = FMOD::SystemI::setSpeakerMode(this, this->mSpeakerMode, this->mDSPMaxOutputChannels);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    mDownMix = this->mDownMix;
    if ( !mDownMix
      || !(*mDownMix->_vptr_DownMix)(
            mDownMix,
            this,
            this->mDSPBlockSize,
            (unsigned int)this->mDSPSampleRate,
            (unsigned int)this->mSpeakerMode,
            (unsigned int)this->mDSPMaxOutputChannels,
            this->mOutput->mSpeakerMode,
            this->mOutput->mSpeakerModeChannels,
            0) )
    {
      goto LABEL_39;
    }
    result = (*((unsigned int (__fastcall **)(FMOD::DownMix *))this->mDownMix->_vptr_DownMix + 1))(this->mDownMix);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v17 = (FMOD::DownMix *)FMOD::MemPool::calloc(
                               off_286F358->gSystemMemPool,
                               200,
                               "../../../core_api/src/fmod_systemi_driver.cpp",
                               340,
                               0);
      if ( !v17 )
      {
        this->mDownMix = 0;
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      }
      v17->mConnection.mMixMatrixCurrent.mInChannels = 0;
      v18 = this->mOutput;
      v17->mConnection.mMixMatrix.mOutChannels = 0;
      v17->mConnection.mMixMatrixCurrent.mOutChannels = 0;
      v17->mConnection.mUserData.mMixMatrixUser.mInChannels = 0;
      v17->_vptr_DownMix = (int (**)(...))&off_29B2730;
      v17->mConnection.mUserData.mMixMatrixUser.mOutChannels = 0;
      v17->mConnection.mInputNode.mNodeData = 0;
      v17->mConnection.mOutputNode.mNodeData = 0;
      v17->mConnection.mInputNode.mNodePrev = &v17->mConnection.mInputNode;
      v17->mConnection.mInputNode.mNodeNext = &v17->mConnection.mInputNode;
      v17->mConnection.mMixMatrix.mData = 0;
      v17->mConnection.mMixMatrixCurrent.mData = 0;
      v17->mConnection.mOutputNode.mNodePrev = &v17->mConnection.mOutputNode;
      v17->mConnection.mOutputNode.mNodeNext = &v17->mConnection.mOutputNode;
      v17->mConnection.mMixMatrix.mInChannels = 0;
      v17->mConnection.mUserData.mMixMatrixUser.mData = 0;
      v17->mConnection.mSystem = 0;
      v17->mConnection.mInputUnit = 0;
      v17->mConnection.mOutputUnit = 0;
      v19 = this->mDSPMaxOutputChannels;
      this->mDownMix = v17;
      result = FMOD::DownMix::init(
                 v17,
                 this,
                 this->mDSPBlockSize,
                 this->mDSPSampleRate,
                 this->mSpeakerMode,
                 v19,
                 v18->mSpeakerMode,
                 v18->mSpeakerModeChannels,
                 0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
LABEL_39:
        if ( this->mOutput->mSampleRate == this->mDSPSampleRate
          || (result = FMOD::SystemI::createOutputResampler(this)) == FMOD_RESULT::FMOD_OK_0 )
        {
          if ( this->mOutputType != FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_WINSONIC_0 )
            return FMOD::Output::start(this->mOutput);
          result = FMOD::SystemI::createOutputRingBuffer(this);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
            return FMOD::Output::start(this->mOutput);
        }
      }
    }
  }
  return result;
}


// Address: 0x21df610 | Name: _ZN4FMOD7SystemI17setOutputInternalE15FMOD_OUTPUTTYPEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::setOutputInternal(
        FMOD::SystemI *const this,
        FMOD_OUTPUTTYPE_0 outputtype,
        int outputhandle)
{
  FMOD::Output *mOutput; // rdi
  int mDSPTick; // r12d
  FMOD_RESULT_0 result; // eax
  FMOD::Output *v8; // rax
  __int64 v9; // rax
  int v10; // eax
  int v11; // ebp
  FMOD_OUTPUTTYPE_0 outputtypea; // [rsp+Ch] [rbp-3Ch] BYREF
  int numoutputs; // [rsp+10h] [rbp-38h] BYREF
  unsigned int handle; // [rsp+14h] [rbp-34h] BYREF
  FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN *outputdesc[6]; // [rsp+18h] [rbp-30h] BYREF

  mOutput = this->mOutput;
  outputtypea = outputtype;
  outputdesc[0] = 0;
  if ( mOutput )
  {
    if ( this->mOutputType == outputtype || this->mOutputHandle == outputhandle )
      return FMOD_RESULT::FMOD_OK_0;
    if ( this->mInitialized )
    {
      FMOD::SystemI::stopDriver(this);
      mOutput = this->mOutput;
    }
    mDSPTick = mOutput->mDSPTick;
    (*mOutput->_vptr_Output)();
    this->mOutput = 0;
    this->mOutputType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_AUTODETECT_0;
    this->mOutputHandle = 0;
  }
  else
  {
    mDSPTick = 1;
  }
  if ( this->mPluginsLoaded )
  {
    if ( outputhandle > 0 )
      goto LABEL_9;
  }
  else
  {
    result = FMOD::SystemI::setUpPlugins(this);
    if ( result )
      return result;
    if ( outputhandle > 0 )
    {
LABEL_9:
      result = FMOD::PluginFactory::getOutput(this->mPluginFactory, outputhandle, outputdesc);
      if ( result )
        return result;
      goto LABEL_10;
    }
  }
  result = FMOD::PluginFactory::getNumOutputs(this->mPluginFactory, &numoutputs);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( outputtypea == FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_AUTODETECT_0 )
      FMOD_OS_Output_GetDefault(&outputtypea);
    v10 = numoutputs;
    v11 = 0;
    if ( numoutputs <= 0 )
    {
LABEL_31:
      if ( v11 == v10 )
        return FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0;
LABEL_10:
      result = FMOD::PluginFactory::createOutput(this->mPluginFactory, &outputdesc[0]->mDescription, &this->mOutput);
      if ( result )
        return result;
      v8 = this->mOutput;
      this->mOutputType = v8->mDescription.mType;
      this->mOutputHandle = v8->mDescription.mHandle;
      v8->mDSPTick = mDSPTick;
      v9 = *(unsigned __int64 *)((char *)&stru_10788.r_offset + (_QWORD)this);
      if ( v9 )
        *(_DWORD *)(v9 + 48) = 1;
      if ( this->mInitialized && FMOD::SystemI::startDriver(this, 0) )
        return FMOD::SystemI::setOutputInternal(this, FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_NOSOUND_0, 0);
      return FMOD_RESULT::FMOD_OK_0;
    }
    while ( 1 )
    {
      result = FMOD::PluginFactory::getOutputHandle(this->mPluginFactory, v11, &handle);
      if ( result )
        break;
      result = FMOD::PluginFactory::getOutput(this->mPluginFactory, handle, outputdesc);
      if ( result )
        break;
      if ( outputdesc[0]->mDescription.mType == outputtypea )
      {
        v10 = numoutputs;
        goto LABEL_31;
      }
      v10 = numoutputs;
      if ( numoutputs <= ++v11 )
        goto LABEL_31;
    }
  }
  return result;
}


// Address: 0x21df860 | Name: _ZN4FMOD7SystemI15checkDriverListEb
FMOD_RESULT_0 __fastcall FMOD::SystemI::checkDriverList(FMOD::SystemI *const this, bool fromsystemupdate)
{
  FMOD_RESULT_0 result; // eax
  FMOD::Output *mOutput; // rdi
  void (__fastcall *v5)(FMOD_OUTPUT_STATE *); // rax
  void (__fastcall *v6)(FMOD::SystemI *const, __int64, _QWORD, _QWORD, _QWORD); // rax
  bool devicelistchanged; // [rsp+Bh] [rbp-1Dh] BYREF
  unsigned int timestamp[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  devicelistchanged = 0;
  timestamp[0] = 0;
  FMOD_OS_Time_GetMs(timestamp);
  if ( !fromsystemupdate || timestamp[0] - this->mDeviceListLastCheckedTime > 0x3E7 || this->mOutput->mNeedReset )
  {
    this->mDeviceListLastCheckedTime = timestamp[0];
    result = FMOD_OS_CheckDriverList(&devicelistchanged);
    if ( result )
      return result;
    if ( devicelistchanged )
    {
      mOutput = this->mOutput;
      this->mDeviceListChanged = 1;
      v5 = (void (__fastcall *)(FMOD_OUTPUT_STATE *))mOutput->mDescription.devicelistchanged;
      mOutput->mEnumerated = 0;
      if ( v5 )
        v5(&mOutput->FMOD_OUTPUT_STATE);
    }
    if ( !fromsystemupdate )
      return FMOD_RESULT::FMOD_OK_0;
  }
  if ( this->mDeviceListChanged )
  {
    v6 = *(void (__fastcall **)(FMOD::SystemI *const, __int64, _QWORD, _QWORD, _QWORD))((char *)&stru_11748.r_offset
                                                                                      + (_QWORD)this);
    if ( v6 )
    {
      if ( (this->mCallbackMask & 1) != 0 )
        v6(this, 1, 0, 0, *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)this));
    }
    this->mDeviceListChanged = 0;
  }
  if ( !this->mOutput->mNeedReset )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD::SystemI::stopDriver(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( FMOD::SystemI::startDriver(this, this->mSelectedDriver) )
      return FMOD::SystemI::setOutputInternal(this, FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_NOSOUND_0, 0);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21df980 | Name: _ZN4FMOD7SystemI17setDriverInternalEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::setDriverInternal(FMOD::SystemI *const this, int driver)
{
  int v2; // ebx
  FMOD_RESULT_0 result; // eax
  int v4; // edx
  __int64 v5; // rax
  __int64 v6; // rax
  int numdrivers; // [rsp+1Ch] [rbp-3Ch] BYREF
  FMOD_GUID guid; // [rsp+20h] [rbp-38h] BYREF

  v2 = driver;
  numdrivers = 0;
  result = FMOD::SystemI::getNumDrivers(this, &numdrivers);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( driver >= -1 && driver < numdrivers )
    {
      if ( driver == -1 )
        v2 = 0;
      result = FMOD::SystemI::getDriverInfo(this, v2, 0, 0, &guid, 0, 0, 0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v4 = memcmp(&guid, &this->mSelectedDriverGUID, 0x10u);
        result = FMOD_RESULT::FMOD_OK_0;
        if ( v4 )
        {
          if ( !this->mInitialized )
            goto LABEL_14;
          result = FMOD::SystemI::stopDriver(this);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            v5 = *(unsigned __int64 *)((char *)&stru_10788.r_offset + (_QWORD)this);
            if ( v5 )
              *(_DWORD *)(v5 + 48) = 1;
            if ( FMOD::SystemI::startDriver(this, v2) == FMOD_RESULT::FMOD_OK_0
              || (result = FMOD::SystemI::setOutputInternal(this, FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_NOSOUND_0, 0)) == FMOD_RESULT::FMOD_OK_0 )
            {
LABEL_14:
              v6 = *(_QWORD *)&guid.Data1;
              this->mSelectedDriver = v2;
              *(_QWORD *)&this->mSelectedDriverGUID.Data1 = v6;
              *(_QWORD *)this->mSelectedDriverGUID.Data4 = *(_QWORD *)guid.Data4;
              return FMOD_RESULT::FMOD_OK_0;
            }
          }
        }
      }
    }
  }
  return result;
}


