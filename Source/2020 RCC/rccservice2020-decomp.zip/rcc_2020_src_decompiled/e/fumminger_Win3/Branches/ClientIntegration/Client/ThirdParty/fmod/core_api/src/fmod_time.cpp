// Address: 0x22388e0 | Name: _ZN4FMOD9TimeStampC2Ev
void __fastcall FMOD::TimeStamp::TimeStamp(FMOD::TimeStamp *const this)
{
  this->mIn = 0;
  this->mOut = 0;
  this->mDelta = 0;
  this->mTotalIn = 0;
  this->mTotalOut = 0;
  this->mPercent = 0.0;
  this->mPaused = 0;
  this->mPausedIn = 0;
  this->mAvTotal = 0.0;
  this->mPausedOut = 0;
  this->mPausedTotal = 0;
  this->mAvCurrent = 0.0;
  this->mPausedRefCount = 0;
  this->mCPUUsage = 0.0;
  this->mTiming = 0;
}


// Address: 0x2238940 | Name: _ZN4FMOD9TimeStamp7stampInEv
FMOD_RESULT_0 __fastcall FMOD::TimeStamp::stampIn(FMOD::TimeStamp *const this)
{
  FMOD_OS_Time_GetUs(&this->mIn);
  this->mTiming = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2238960 | Name: _ZN4FMOD9TimeStamp8stampOutEi
FMOD_RESULT_0 __fastcall FMOD::TimeStamp::stampOut(FMOD::TimeStamp *const this, int damppercentage)
{
  unsigned int v2; // eax
  float v3; // xmm1_4
  unsigned int mTotalIn; // edx
  float v5; // xmm0_4
  unsigned int mIn; // edx
  float v7; // xmm2_4
  float v8; // xmm1_4
  float v9; // xmm0_4
  signed int v10; // edx
  unsigned int val[3]; // [rsp+10h] [rbp-Ch] BYREF

  FMOD_OS_Time_GetUs(val);
  v2 = val[0];
  v3 = 0.0;
  mTotalIn = this->mTotalIn;
  v5 = (float)damppercentage / 100.0;
  this->mOut = val[0];
  this->mTotalOut = v2;
  if ( v2 >= mTotalIn )
    v3 = (float)(int)(v2 - mTotalIn);
  mIn = this->mIn;
  v7 = (float)(this->mAvTotal * v5) + v3;
  v8 = 1.0 - v5;
  v9 = v5 * this->mPercent;
  this->mAvTotal = v7;
  this->mPercent = v9;
  if ( v2 > mIn )
  {
    v10 = v2 - mIn - this->mPausedTotal;
    this->mDelta = v10;
    v9 = v9 + (float)((float)((float)v10 * 100.0) / (float)(v7 * v8));
    this->mPercent = v9;
  }
  this->mTotalIn = v2;
  this->mPausedTotal = 0;
  this->mPausedRefCount = 0;
  this->mTiming = 0;
  this->mCPUUsage = v8 * v9;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2238a30 | Name: _ZN4FMOD9TimeStamp11getCPUUsageEPf
FMOD_RESULT_0 __fastcall FMOD::TimeStamp::getCPUUsage(FMOD::TimeStamp *const this, float *cpuusage)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( cpuusage )
  {
    LOBYTE(result) = 0;
    *cpuusage = this->mCPUUsage;
  }
  return result;
}


// Address: 0x2238a50 | Name: _ZN4FMOD9TimeStamp9setPausedEb
FMOD_RESULT_0 __fastcall FMOD::TimeStamp::setPaused(FMOD::TimeStamp *const this, bool paused)
{
  int mPausedRefCount; // eax
  int v4; // eax
  unsigned int mPausedOut; // edx
  unsigned int mPausedIn; // eax

  if ( this->mTiming )
  {
    mPausedRefCount = this->mPausedRefCount;
    if ( paused )
    {
      if ( !mPausedRefCount )
      {
        FMOD_OS_Time_GetUs(&this->mPausedIn);
        mPausedRefCount = this->mPausedRefCount;
      }
      this->mPausedRefCount = mPausedRefCount + 1;
    }
    else
    {
      v4 = mPausedRefCount - 1;
      this->mPausedRefCount = v4;
      if ( !v4 )
      {
        FMOD_OS_Time_GetUs(&this->mPausedOut);
        mPausedOut = this->mPausedOut;
        mPausedIn = this->mPausedIn;
        if ( mPausedOut > mPausedIn )
          this->mPausedTotal = this->mPausedTotal + mPausedOut - mPausedIn;
      }
    }
    this->mPaused = paused;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


