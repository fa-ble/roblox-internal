// Address: 0x21e8a60 | Name: FMOD_Resampler_Linear_PCM8_Mono_NoOpt
void __fastcall FMOD_Resampler_Linear_PCM8_Mono_NoOpt(
        float *out,
        int outlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  FMOD_UINT64 mValue; // r10
  int v6; // ebp
  float *v7; // rax
  FMOD_SINT64 v8; // rbx
  FMOD_SINT64 v9; // r12
  FMOD_UINT64 v10; // r9
  FMOD_UINT64 v11; // r10
  float mLo; // xmm2_4
  __int64 mHi; // r14
  __int64 v14; // r11
  float v15; // xmm2_4
  float v16; // xmm4_4
  float v17; // xmm1_4
  float v18; // xmm4_4
  float v19; // xmm1_4
  FMOD_UINT64 v20; // r14
  float v21; // xmm2_4
  float v22; // xmm3_4
  float v23; // xmm1_4
  float v24; // xmm5_4
  float v25; // xmm3_4
  float v26; // xmm2_4
  float v27; // xmm1_4
  FMOD_UINT64 v28; // r11
  float v29; // xmm8_4
  int v30; // esi
  FMOD_SINT64 v31; // r10
  FMOD_UINT64 v32; // rax

  if ( outlength >> 2 )
  {
    mValue = position->mValue;
    v6 = outlength >> 2;
    v7 = out;
    v8 = 2 * speed->mValue;
    v9 = 4 * speed->mValue;
    v10 = position->mValue + speed->mValue;
    do
    {
      v11 = v8 + mValue;
      v7 += 4;
      mLo = (float)(int)position->mLo;
      mHi = position->mHi;
      v14 = (unsigned int)(mHi + 1);
      LODWORD(mHi) = *((char *)src + mHi);
      LODWORD(v14) = *((char *)src + v14);
      position->mValue = v10;
      v15 = mLo * 2.3283064e-10;
      v16 = (float)(1.0 - v15) * (float)((float)(int)mHi * 0.0078125);
      v17 = (float)((float)(int)v14 * 0.0078125) * v15;
      LODWORD(mHi) = *((char *)src + HIDWORD(v10));
      LODWORD(v14) = *((char *)src + (unsigned int)(HIDWORD(v10) + 1));
      position->mValue = v11;
      v18 = v16 + v17;
      v19 = (float)(int)mHi;
      v20 = HIDWORD(v11);
      v21 = (float)(int)v10 * 2.3283064e-10;
      v22 = (float)(1.0 - v21) * (float)(v19 * 0.0078125);
      v23 = (float)(int)v14;
      LODWORD(v14) = v11;
      mValue = v8 + v11;
      v24 = (float)(int)v14 * 2.3283064e-10;
      v25 = v22 + (float)((float)(v23 * 0.0078125) * v21);
      v26 = (float)(1.0 - v24) * (float)((float)*((char *)src + (unsigned int)v20) * 0.0078125);
      v27 = (float)*((char *)src + (unsigned int)(v20 + 1));
      v28 = v8 + v10;
      v10 += v9;
      position->mValue = v28;
      LODWORD(v20) = v28;
      v28 >>= 32;
      v29 = (float)(int)v20;
      LODWORD(v20) = *((char *)src + (unsigned int)v28);
      LODWORD(v28) = *((char *)src + (unsigned int)(v28 + 1));
      position->mValue = mValue;
      *(v7 - 4) = v18;
      *(v7 - 3) = v25;
      *(v7 - 2) = v26 + (float)((float)(v27 * 0.0078125) * v24);
      *(v7 - 1) = (float)((float)(1.0 - (float)(v29 * 2.3283064e-10)) * (float)((float)(int)v20 * 0.0078125))
                + (float)((float)((float)(int)v28 * 0.0078125) * (float)(v29 * 2.3283064e-10));
      --v6;
    }
    while ( v6 );
    out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
  }
  v30 = outlength & 3;
  if ( v30 )
  {
    v31 = speed->mValue;
    v32 = position->mValue + speed->mValue;
    do
    {
      *out++ = (float)((float)(1.0 - (float)((float)(int)position->mLo * 2.3283064e-10))
                     * (float)((float)*((char *)src + position->mHi) * 0.0078125))
             + (float)((float)((float)*((char *)src + position->mHi + 1) * 0.0078125)
                     * (float)((float)(int)position->mLo * 2.3283064e-10));
      position->mValue = v32;
      v32 += v31;
      --v30;
    }
    while ( v30 );
  }
}


// Address: 0x21e8cc0 | Name: FMOD_Resampler_Linear_PCM8_Stereo_NoOpt
void __fastcall FMOD_Resampler_Linear_PCM8_Stereo_NoOpt(
        float *out,
        int outlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  FMOD_UINT64 mValue; // r10
  int v6; // ebp
  float *v7; // rax
  FMOD_SINT64 v8; // rbx
  FMOD_SINT64 v9; // r12
  FMOD_UINT64 v10; // r9
  FMOD_UINT64 v11; // r10
  unsigned int v12; // r11d
  float v13; // xmm8_4
  float v14; // xmm2_4
  float v15; // xmm1_4
  __int64 v16; // r14
  int v17; // r11d
  float v18; // xmm8_4
  float v19; // xmm7_4
  float v20; // xmm6_4
  float v21; // xmm2_4
  float v22; // xmm1_4
  int v23; // r11d
  float v24; // xmm6_4
  float v25; // xmm5_4
  float v26; // xmm1_4
  float v27; // xmm2_4
  int v28; // r11^4
  float v29; // xmm5_4
  float v30; // xmm2_4
  float v31; // xmm3_4
  float v32; // xmm4_4
  float v33; // xmm1_4
  FMOD_UINT64 v34; // r11
  float v35; // xmm3_4
  float v36; // xmm1_4
  float v37; // xmm2_4
  float v38; // xmm12_4
  float v39; // xmm3_4
  float v40; // xmm1_4
  int v41; // esi
  FMOD_SINT64 v42; // r10
  FMOD_UINT64 v43; // r8
  unsigned int v44; // eax
  float v45; // xmm1_4
  float v46; // xmm4_4
  float v47; // xmm2_4

  if ( outlength >> 2 )
  {
    mValue = position->mValue;
    v6 = outlength >> 2;
    v7 = out;
    v8 = 2 * speed->mValue;
    v9 = 4 * speed->mValue;
    v10 = position->mValue + speed->mValue;
    do
    {
      v11 = v8 + mValue;
      v7 += 8;
      v12 = 2 * position->mHi;
      v13 = (float)*((char *)src + v12);
      v14 = (float)(int)position->mLo * 2.3283064e-10;
      v15 = (float)*((char *)src + v12 + 2);
      v16 = v12 + 1;
      v17 = *((char *)src + v12 + 3);
      LODWORD(v16) = *((char *)src + v16);
      position->mValue = v10;
      v18 = (float)((float)(v13 * 0.0078125) * (float)(1.0 - v14)) + (float)((float)(v15 * 0.0078125) * v14);
      v19 = (float)((float)((float)(int)v16 * 0.0078125) * (float)(1.0 - v14))
          + (float)((float)((float)v17 * 0.0078125) * v14);
      v20 = (float)*((char *)src + (unsigned int)(2 * HIDWORD(v10)));
      v21 = (float)(int)v10 * 2.3283064e-10;
      v22 = (float)*((char *)src + (unsigned int)(2 * HIDWORD(v10) + 2));
      v23 = *((char *)src + (unsigned int)(2 * HIDWORD(v10) + 3));
      LODWORD(v16) = *((char *)src + (unsigned int)(2 * HIDWORD(v10) + 1));
      position->mValue = v11;
      v24 = (float)((float)(v20 * 0.0078125) * (float)(1.0 - v21)) + (float)((float)(v22 * 0.0078125) * v21);
      v25 = (float)((float)(int)v16 * 0.0078125) * (float)(1.0 - v21);
      v26 = (float)((float)v23 * 0.0078125) * v21;
      v27 = (float)(int)v11;
      v28 = HIDWORD(v11);
      mValue = v8 + v11;
      v29 = v25 + v26;
      v30 = v27 * 2.3283064e-10;
      v31 = (float)*((char *)src + (unsigned int)(2 * v28 + 1)) * 0.0078125;
      v32 = (float)((float)((float)*((char *)src + (unsigned int)(2 * v28)) * 0.0078125) * (float)(1.0 - v30))
          + (float)((float)((float)*((char *)src + (unsigned int)(2 * v28 + 2)) * 0.0078125) * v30);
      v33 = (float)*((char *)src + (unsigned int)(2 * v28 + 3));
      v34 = v8 + v10;
      v10 += v9;
      position->mValue = v34;
      v35 = v31 * (float)(1.0 - v30);
      v36 = (float)(v33 * 0.0078125) * v30;
      v37 = (float)*((char *)src + (unsigned int)(2 * HIDWORD(v34)));
      v38 = (float)(int)v34 * 2.3283064e-10;
      v39 = v35 + v36;
      v40 = (float)*((char *)src + (unsigned int)(2 * HIDWORD(v34) + 2));
      LODWORD(v16) = *((char *)src + (unsigned int)(2 * HIDWORD(v34) + 1));
      LODWORD(v34) = *((char *)src + (unsigned int)(2 * HIDWORD(v34) + 3));
      position->mValue = mValue;
      *(v7 - 8) = v18;
      *(v7 - 7) = v19;
      *(v7 - 6) = v24;
      *(v7 - 5) = v29;
      *(v7 - 4) = v32;
      *(v7 - 3) = v39;
      *(v7 - 2) = (float)((float)(v37 * 0.0078125) * (float)(1.0 - v38)) + (float)((float)(v40 * 0.0078125) * v38);
      *(v7 - 1) = (float)((float)((float)(int)v16 * 0.0078125) * (float)(1.0 - v38))
                + (float)((float)((float)(int)v34 * 0.0078125) * v38);
      --v6;
    }
    while ( v6 );
    out += 8 * (unsigned int)((outlength >> 2) - 1) + 8;
  }
  v41 = outlength & 3;
  if ( v41 )
  {
    v42 = speed->mValue;
    v43 = position->mValue + speed->mValue;
    do
    {
      out += 2;
      v44 = 2 * position->mHi;
      v45 = (float)*((char *)src + v44 + 1);
      v46 = (float)(int)position->mLo * 2.3283064e-10;
      v47 = (float)*((char *)src + v44 + 3);
      *(out - 2) = (float)((float)((float)*((char *)src + v44) * 0.0078125) * (float)(1.0 - v46))
                 + (float)((float)((float)*((char *)src + v44 + 2) * 0.0078125) * v46);
      *(out - 1) = (float)((float)(v45 * 0.0078125) * (float)(1.0 - v46)) + (float)((float)(v47 * 0.0078125) * v46);
      position->mValue = v43;
      v43 += v42;
      --v41;
    }
    while ( v41 );
  }
}


// Address: 0x21e9040 | Name: FMOD_Resampler_Linear_PCM16_Mono_NoOpt
void __fastcall FMOD_Resampler_Linear_PCM16_Mono_NoOpt(
        float *dst,
        int dstlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  FMOD_UINT64 mValue; // r10
  int v6; // ebp
  float *v7; // rax
  FMOD_SINT64 v8; // rbx
  FMOD_SINT64 v9; // r12
  FMOD_UINT64 v10; // r9
  FMOD_UINT64 v11; // r10
  float mLo; // xmm2_4
  __int64 mHi; // r14
  __int64 v14; // r11
  float v15; // xmm2_4
  float v16; // xmm4_4
  float v17; // xmm1_4
  float v18; // xmm4_4
  float v19; // xmm1_4
  FMOD_UINT64 v20; // r14
  float v21; // xmm2_4
  float v22; // xmm3_4
  float v23; // xmm1_4
  float v24; // xmm5_4
  float v25; // xmm3_4
  float v26; // xmm2_4
  float v27; // xmm1_4
  FMOD_UINT64 v28; // r11
  float v29; // xmm8_4
  int v30; // esi
  FMOD_SINT64 v31; // r10
  FMOD_UINT64 v32; // rax

  if ( dstlength >> 2 )
  {
    mValue = position->mValue;
    v6 = dstlength >> 2;
    v7 = dst;
    v8 = 2 * speed->mValue;
    v9 = 4 * speed->mValue;
    v10 = position->mValue + speed->mValue;
    do
    {
      v11 = v8 + mValue;
      v7 += 4;
      mLo = (float)(int)position->mLo;
      mHi = position->mHi;
      v14 = (unsigned int)(mHi + 1);
      LODWORD(mHi) = *((__int16 *)src + mHi);
      LODWORD(v14) = *((__int16 *)src + v14);
      position->mValue = v10;
      v15 = mLo * 2.3283064e-10;
      v16 = (float)(1.0 - v15) * (float)((float)(int)mHi * 0.000030517578);
      v17 = (float)((float)(int)v14 * 0.000030517578) * v15;
      LODWORD(mHi) = *((__int16 *)src + HIDWORD(v10));
      LODWORD(v14) = *((__int16 *)src + (unsigned int)(HIDWORD(v10) + 1));
      position->mValue = v11;
      v18 = v16 + v17;
      v19 = (float)(int)mHi;
      v20 = HIDWORD(v11);
      v21 = (float)(int)v10 * 2.3283064e-10;
      v22 = (float)(1.0 - v21) * (float)(v19 * 0.000030517578);
      v23 = (float)(int)v14;
      LODWORD(v14) = v11;
      mValue = v8 + v11;
      v24 = (float)(int)v14 * 2.3283064e-10;
      v25 = v22 + (float)((float)(v23 * 0.000030517578) * v21);
      v26 = (float)(1.0 - v24) * (float)((float)*((__int16 *)src + (unsigned int)v20) * 0.000030517578);
      v27 = (float)*((__int16 *)src + (unsigned int)(v20 + 1));
      v28 = v8 + v10;
      v10 += v9;
      position->mValue = v28;
      LODWORD(v20) = v28;
      v28 >>= 32;
      v29 = (float)(int)v20;
      LODWORD(v20) = *((__int16 *)src + (unsigned int)v28);
      LODWORD(v28) = *((__int16 *)src + (unsigned int)(v28 + 1));
      position->mValue = mValue;
      *(v7 - 4) = v18;
      *(v7 - 3) = v25;
      *(v7 - 2) = v26 + (float)((float)(v27 * 0.000030517578) * v24);
      *(v7 - 1) = (float)((float)(1.0 - (float)(v29 * 2.3283064e-10)) * (float)((float)(int)v20 * 0.000030517578))
                + (float)((float)((float)(int)v28 * 0.000030517578) * (float)(v29 * 2.3283064e-10));
      --v6;
    }
    while ( v6 );
    dst += 4 * (unsigned int)((dstlength >> 2) - 1) + 4;
  }
  v30 = dstlength & 3;
  if ( v30 )
  {
    v31 = speed->mValue;
    v32 = position->mValue + speed->mValue;
    do
    {
      *dst++ = (float)((float)(1.0 - (float)((float)(int)position->mLo * 2.3283064e-10))
                     * (float)((float)*((__int16 *)src + position->mHi) * 0.000030517578))
             + (float)((float)((float)*((__int16 *)src + position->mHi + 1) * 0.000030517578)
                     * (float)((float)(int)position->mLo * 2.3283064e-10));
      position->mValue = v32;
      v32 += v31;
      --v30;
    }
    while ( v30 );
  }
}


// Address: 0x21e92a0 | Name: FMOD_Resampler_Linear_PCM16_Stereo_NoOpt
void __fastcall FMOD_Resampler_Linear_PCM16_Stereo_NoOpt(
        float *dst,
        int dstlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  FMOD_UINT64 mValue; // r10
  int v6; // ebp
  float *v7; // rax
  FMOD_SINT64 v8; // rbx
  FMOD_SINT64 v9; // r12
  FMOD_UINT64 v10; // r9
  FMOD_UINT64 v11; // r10
  unsigned int v12; // r11d
  float v13; // xmm8_4
  float v14; // xmm2_4
  float v15; // xmm1_4
  __int64 v16; // r14
  int v17; // r11d
  float v18; // xmm8_4
  float v19; // xmm7_4
  float v20; // xmm6_4
  float v21; // xmm2_4
  float v22; // xmm1_4
  int v23; // r11d
  float v24; // xmm6_4
  float v25; // xmm5_4
  float v26; // xmm1_4
  float v27; // xmm2_4
  int v28; // r11^4
  float v29; // xmm5_4
  float v30; // xmm2_4
  float v31; // xmm3_4
  float v32; // xmm4_4
  float v33; // xmm1_4
  FMOD_UINT64 v34; // r11
  float v35; // xmm3_4
  float v36; // xmm1_4
  float v37; // xmm2_4
  float v38; // xmm12_4
  float v39; // xmm3_4
  float v40; // xmm1_4
  int v41; // esi
  FMOD_SINT64 v42; // r10
  FMOD_UINT64 v43; // r8
  unsigned int v44; // eax
  float v45; // xmm1_4
  float v46; // xmm4_4
  float v47; // xmm2_4
  int v48; // r9d
  int v49; // eax

  if ( dstlength >> 2 )
  {
    mValue = position->mValue;
    v6 = dstlength >> 2;
    v7 = dst;
    v8 = 2 * speed->mValue;
    v9 = 4 * speed->mValue;
    v10 = position->mValue + speed->mValue;
    do
    {
      v11 = v8 + mValue;
      v7 += 8;
      v12 = 2 * position->mHi;
      v13 = (float)*((__int16 *)src + v12);
      v14 = (float)(int)position->mLo * 2.3283064e-10;
      v15 = (float)*((__int16 *)src + v12 + 2);
      v16 = v12 + 1;
      v17 = *((__int16 *)src + v12 + 3);
      LODWORD(v16) = *((__int16 *)src + v16);
      position->mValue = v10;
      v18 = (float)((float)(v13 * 0.000030517578) * (float)(1.0 - v14)) + (float)((float)(v15 * 0.000030517578) * v14);
      v19 = (float)((float)((float)(int)v16 * 0.000030517578) * (float)(1.0 - v14))
          + (float)((float)((float)v17 * 0.000030517578) * v14);
      v20 = (float)*((__int16 *)src + (unsigned int)(2 * HIDWORD(v10)));
      v21 = (float)(int)v10 * 2.3283064e-10;
      v22 = (float)*((__int16 *)src + (unsigned int)(2 * HIDWORD(v10) + 2));
      v23 = *((__int16 *)src + (unsigned int)(2 * HIDWORD(v10) + 3));
      LODWORD(v16) = *((__int16 *)src + (unsigned int)(2 * HIDWORD(v10) + 1));
      position->mValue = v11;
      v24 = (float)((float)(v20 * 0.000030517578) * (float)(1.0 - v21)) + (float)((float)(v22 * 0.000030517578) * v21);
      v25 = (float)((float)(int)v16 * 0.000030517578) * (float)(1.0 - v21);
      v26 = (float)((float)v23 * 0.000030517578) * v21;
      v27 = (float)(int)v11;
      v28 = HIDWORD(v11);
      mValue = v8 + v11;
      v29 = v25 + v26;
      v30 = v27 * 2.3283064e-10;
      v31 = (float)*((__int16 *)src + (unsigned int)(2 * v28 + 1)) * 0.000030517578;
      v32 = (float)((float)((float)*((__int16 *)src + (unsigned int)(2 * v28)) * 0.000030517578) * (float)(1.0 - v30))
          + (float)((float)((float)*((__int16 *)src + (unsigned int)(2 * v28 + 2)) * 0.000030517578) * v30);
      v33 = (float)*((__int16 *)src + (unsigned int)(2 * v28 + 3));
      v34 = v8 + v10;
      v10 += v9;
      position->mValue = v34;
      v35 = v31 * (float)(1.0 - v30);
      v36 = (float)(v33 * 0.000030517578) * v30;
      v37 = (float)*((__int16 *)src + (unsigned int)(2 * HIDWORD(v34)));
      v38 = (float)(int)v34 * 2.3283064e-10;
      v39 = v35 + v36;
      v40 = (float)*((__int16 *)src + (unsigned int)(2 * HIDWORD(v34) + 2));
      LODWORD(v16) = *((__int16 *)src + (unsigned int)(2 * HIDWORD(v34) + 1));
      LODWORD(v34) = *((__int16 *)src + (unsigned int)(2 * HIDWORD(v34) + 3));
      position->mValue = mValue;
      *(v7 - 8) = v18;
      *(v7 - 7) = v19;
      *(v7 - 6) = v24;
      *(v7 - 5) = v29;
      *(v7 - 4) = v32;
      *(v7 - 3) = v39;
      *(v7 - 2) = (float)((float)(v37 * 0.000030517578) * (float)(1.0 - v38))
                + (float)((float)(v40 * 0.000030517578) * v38);
      *(v7 - 1) = (float)((float)((float)(int)v16 * 0.000030517578) * (float)(1.0 - v38))
                + (float)((float)((float)(int)v34 * 0.000030517578) * v38);
      --v6;
    }
    while ( v6 );
    dst += 8 * (unsigned int)((dstlength >> 2) - 1) + 8;
  }
  v41 = dstlength & 3;
  if ( v41 )
  {
    v42 = speed->mValue;
    v43 = position->mValue + speed->mValue;
    do
    {
      dst += 2;
      v44 = 2 * position->mHi;
      v45 = (float)*((__int16 *)src + v44 + 1);
      v46 = (float)(int)position->mLo * 2.3283064e-10;
      v47 = (float)*((__int16 *)src + v44 + 3);
      v48 = *((__int16 *)src + v44);
      v49 = *((__int16 *)src + v44 + 2);
      *(dst - 1) = (float)((float)(v45 * 0.000030517578) * (float)(1.0 - v46))
                 + (float)((float)(v47 * 0.000030517578) * v46);
      *(dst - 2) = (float)((float)((float)v48 * 0.000030517578) * (float)(1.0 - v46))
                 + (float)((float)((float)v49 * 0.000030517578) * v46);
      position->mValue = v43;
      v43 += v42;
      --v41;
    }
    while ( v41 );
  }
}


// Address: 0x21e9620 | Name: FMOD_Resampler_Linear_Float_Mono_NoOpt
void __fastcall FMOD_Resampler_Linear_Float_Mono_NoOpt(
        float *out,
        int outlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  FMOD_UINT64 mValue; // r10
  int v6; // ebp
  float *v7; // rax
  FMOD_SINT64 v8; // rbx
  FMOD_SINT64 v9; // r12
  FMOD_UINT64 v10; // r9
  FMOD_UINT64 v11; // r10
  __int64 mHi; // r14
  float v13; // xmm0_4
  float v14; // xmm3_4
  float v15; // xmm0_4
  float v16; // xmm3_4
  float v17; // xmm3_4
  float v18; // xmm0_4
  float v19; // xmm2_4
  float v20; // xmm0_4
  int v21; // r11d
  float v22; // xmm2_4
  FMOD_UINT64 v23; // r14
  float v24; // xmm2_4
  float v25; // xmm0_4
  float v26; // xmm1_4
  float v27; // xmm0_4
  FMOD_UINT64 v28; // r11
  float v29; // xmm1_4
  float v30; // xmm1_4
  float v31; // xmm6_4
  float v32; // xmm0_4
  float v33; // xmm6_4
  float v34; // xmm0_4
  int v35; // esi
  FMOD_SINT64 v36; // r10
  FMOD_UINT64 v37; // rax

  if ( outlength >> 2 )
  {
    mValue = position->mValue;
    v6 = outlength >> 2;
    v7 = out;
    v8 = 2 * speed->mValue;
    v9 = 4 * speed->mValue;
    v10 = position->mValue + speed->mValue;
    do
    {
      v11 = v8 + mValue;
      v7 += 4;
      mHi = position->mHi;
      v13 = (float)(int)position->mLo * 2.3283064e-10;
      v14 = 1.0 - v13;
      v15 = v13 * *((float *)src + (unsigned int)(mHi + 1));
      v16 = v14 * *((float *)src + mHi);
      position->mValue = v10;
      v17 = v16 + v15;
      v18 = (float)(int)v10 * 2.3283064e-10;
      v19 = 1.0 - v18;
      v20 = v18 * *((float *)src + (unsigned int)(HIDWORD(v10) + 1));
      v21 = v11;
      v22 = v19 * *((float *)src + HIDWORD(v10));
      position->mValue = v11;
      v23 = HIDWORD(v11);
      mValue = v8 + v11;
      v24 = v22 + v20;
      v25 = (float)v21 * 2.3283064e-10;
      v26 = 1.0 - v25;
      v27 = v25 * *((float *)src + (unsigned int)(v23 + 1));
      v28 = v8 + v10;
      v10 += v9;
      v29 = v26 * *((float *)src + (unsigned int)v23);
      position->mValue = v28;
      v30 = v29 + v27;
      v31 = (float)(int)v28 * 2.3283064e-10;
      v32 = 1.0 - v31;
      v33 = v31 * *((float *)src + (unsigned int)(HIDWORD(v28) + 1));
      v34 = v32 * *((float *)src + HIDWORD(v28));
      position->mValue = mValue;
      *(v7 - 4) = v17;
      *(v7 - 3) = v24;
      *(v7 - 2) = v30;
      *(v7 - 1) = v34 + v33;
      --v6;
    }
    while ( v6 );
    out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
  }
  v35 = outlength & 3;
  if ( v35 )
  {
    v36 = speed->mValue;
    v37 = position->mValue + speed->mValue;
    do
    {
      *out++ = (float)((float)(1.0 - (float)((float)(int)position->mLo * 2.3283064e-10))
                     * *((float *)src + position->mHi))
             + (float)((float)((float)(int)position->mLo * 2.3283064e-10) * *((float *)src + position->mHi + 1));
      position->mValue = v37;
      v37 += v36;
      --v35;
    }
    while ( v35 );
  }
}


// Address: 0x21e97e0 | Name: FMOD_Resampler_Linear_Float_Stereo_NoOpt
void __fastcall FMOD_Resampler_Linear_Float_Stereo_NoOpt(
        float *out,
        int outlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  FMOD_UINT64 mValue; // r9
  FMOD_SINT64 v6; // rbx
  int v7; // r11d
  float *v8; // rax
  FMOD_UINT64 v9; // r9
  unsigned int v10; // r10d
  float v11; // xmm0_4
  float v12; // xmm3_4
  float v13; // xmm1_4
  float v14; // xmm0_4
  float v15; // xmm4_4
  float v16; // xmm3_4
  float v17; // xmm4_4
  float v18; // xmm3_4
  float v19; // xmm0_4
  int v20; // r10^4
  float v21; // xmm0_4
  float v22; // xmm1_4
  float v23; // xmm7_4
  float v24; // xmm0_4
  float v25; // xmm2_4
  float v26; // xmm1_4
  unsigned int v27; // eax
  float v28; // xmm0_4
  float v29; // xmm1_4

  if ( outlength >> 1 )
  {
    mValue = position->mValue;
    v6 = speed->mValue;
    v7 = outlength >> 1;
    v8 = out;
    do
    {
      v9 = v6 + mValue;
      v8 += 4;
      v10 = 2 * position->mHi;
      v11 = (float)(int)position->mLo * 2.3283064e-10;
      v12 = 1.0 - v11;
      v13 = *((float *)src + v10 + 2) * v11;
      v14 = v11 * *((float *)src + v10 + 3);
      v15 = *((float *)src + v10) * v12;
      v16 = v12 * *((float *)src + v10 + 1);
      position->mValue = v9;
      v17 = v15 + v13;
      v18 = v16 + v14;
      v19 = (float)(int)v9;
      v20 = HIDWORD(v9);
      mValue = v6 + v9;
      v21 = v19 * 2.3283064e-10;
      v22 = 1.0 - v21;
      v23 = *((float *)src + (unsigned int)(2 * v20 + 2)) * v21;
      v24 = v21 * *((float *)src + (unsigned int)(2 * v20 + 3));
      v25 = *((float *)src + (unsigned int)(2 * v20)) * v22;
      v26 = v22 * *((float *)src + (unsigned int)(2 * v20 + 1));
      position->mValue = mValue;
      *(v8 - 4) = v17;
      *(v8 - 3) = v18;
      *(v8 - 2) = v25 + v23;
      *(v8 - 1) = v26 + v24;
      --v7;
    }
    while ( v7 );
    out += 4 * (unsigned int)((outlength >> 1) - 1) + 4;
  }
  if ( (outlength & 1) != 0 )
  {
    v27 = 2 * position->mHi;
    v28 = (float)(int)position->mLo * 2.3283064e-10;
    v29 = (float)((float)(1.0 - v28) * *((float *)src + v27)) + (float)(v28 * *((float *)src + v27 + 2));
    out[1] = (float)(*((float *)src + v27 + 1) * (float)(1.0 - v28)) + (float)(*((float *)src + v27 + 3) * v28);
    *out = v29;
    position->mValue += speed->mValue;
  }
}


