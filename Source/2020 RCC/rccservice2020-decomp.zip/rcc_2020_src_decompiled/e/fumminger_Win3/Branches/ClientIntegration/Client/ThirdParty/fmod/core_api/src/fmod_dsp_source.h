// Address: 0x21dee80 | Name: _ZN4FMOD9DSPSource19clearStaticPointersEv
FMOD_RESULT_0 __fastcall FMOD::DSPSource::clearStaticPointers(FMOD::DSPSource *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21dee90 | Name: _ZN4FMOD9DSPSource16getAsyncFinishedEPb
FMOD_RESULT_0 __fastcall FMOD::DSPSource::getAsyncFinished(FMOD::DSPSource *const this, bool *finished)
{
  *finished = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f6f70 | Name: _ZN4FMOD9DSPSource11setFinishedEbbb
FMOD_RESULT_0 __fastcall FMOD::DSPSource::setFinished(
        FMOD::DSPSource *const this,
        bool finished,
        bool force,
        bool fromthread)
{
  return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
}


// Address: 0x21f6f80 | Name: _ZN4FMOD9DSPSource11getFinishedEPb
FMOD_RESULT_0 __fastcall FMOD::DSPSource::getFinished(FMOD::DSPSource *const this, bool *finished)
{
  return FMOD_RESULT::FMOD_ERR_UNSUPPORTED_0;
}


