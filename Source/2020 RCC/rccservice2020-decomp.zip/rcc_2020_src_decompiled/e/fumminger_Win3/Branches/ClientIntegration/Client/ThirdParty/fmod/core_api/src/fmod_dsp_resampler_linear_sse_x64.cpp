// Address: 0x221b630 | Name: FMOD_Resampler_Linear_PCM16_Mono_SSE_X64
void __fastcall FMOD_Resampler_Linear_PCM16_Mono_SSE_X64(
        float *dst,
        int dstlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  __m128i v5; // xmm0
  FMOD_SINT64 mValue; // rax
  FMOD_SINT64 v7; // r9
  __m128i v8; // xmm7
  __m128i v9; // xmm3
  __m128i v10; // xmm7
  __m128i v11; // xmm2
  __m128i v12; // xmm3
  __m128i v13; // xmm2
  float *v14; // r9
  int v15; // eax
  __m128i v16; // xmm1
  __m128i v17; // xmm4
  __m128i v18; // xmm0
  __m128i v19; // xmm1
  __m128 v20; // xmm0
  __m128i v21; // xmm1
  __m128i v22; // xmm5
  __m128 v23; // xmm4
  __m128i v24; // xmm1
  __m128i v25; // xmm10
  __int64 v26; // r9
  int v27; // eax
  int v28; // esi
  FMOD_SINT64 v29; // r9
  __m128i v30; // [rsp+0h] [rbp-40h] BYREF
  __int32 v31; // [rsp+10h] [rbp-30h]
  __int32 v32; // [rsp+14h] [rbp-2Ch]

  v5 = _mm_shuffle_epi32(_mm_loadl_epi64((const __m128i *)position), 68);
  mValue = speed->mValue;
  v7 = 2 * speed->mValue;
  v30.m128i_i64[0] = 4 * speed->mValue;
  v30.m128i_i64[1] = v7;
  v8 = _mm_loadl_epi64(&v30);
  v30.m128i_i64[0] = mValue;
  v9 = _mm_loadl_epi64(&v30);
  v30.m128i_i64[0] = v7 + mValue;
  v10 = _mm_shuffle_epi32(v8, 68);
  v11 = _mm_unpacklo_epi64((__m128i)0LL, _mm_move_epi64(v9));
  v12 = _mm_add_epi64((__m128i)_mm_loadh_ps((const double *)v30.m128i_i64), v5);
  v13 = _mm_add_epi64(v11, v5);
  if ( dstlength - 3 <= 0 )
  {
    v27 = 0;
  }
  else
  {
    v14 = dst;
    v15 = 0;
    do
    {
      v16 = _mm_shuffle_epi32(v12, 8);
      v15 += 4;
      v14 += 4;
      v17 = _mm_shuffle_epi32(v12, 13);
      v12 = _mm_add_epi64(v12, v10);
      v18 = _mm_unpacklo_epi64(_mm_shuffle_epi32(v13, 8), v16);
      v19 = _mm_shuffle_epi32(v13, 13);
      v13 = _mm_add_epi64(v13, v10);
      v20 = _mm_mul_ps(_mm_cvtepi32_ps(_mm_srli_epi32(v18, 1u)), *(__m128 *)scale32data);
      v21 = _mm_unpacklo_epi64(v19, v17);
      v30.m128i_i32[0] = _mm_cvtsi128_si32(v21);
      v30.m128i_i32[2] = v21.m128i_i32[1];
      v32 = v21.m128i_i32[3];
      v31 = v21.m128i_i32[2];
      v22 = _mm_unpacklo_epi32(
              _mm_cvtsi32_si128(*((__int16 *)src + v21.m128i_i32[2] + 1)),
              _mm_cvtsi32_si128(*((__int16 *)src + v21.m128i_i32[3] + 1)));
      v23 = _mm_mul_ps(
              _mm_cvtepi32_ps(
                _mm_unpacklo_epi64(
                  _mm_unpacklo_epi32(
                    _mm_cvtsi32_si128(*((__int16 *)src + v30.m128i_i32[0])),
                    _mm_cvtsi32_si128(*((__int16 *)src + v21.m128i_i32[1]))),
                  _mm_unpacklo_epi32(
                    _mm_cvtsi32_si128(*((__int16 *)src + v21.m128i_i32[2])),
                    _mm_cvtsi32_si128(*((__int16 *)src + v21.m128i_i32[3]))))),
              *(__m128 *)scale16data);
      v24 = _mm_cvtsi32_si128(*((__int16 *)src + v30.m128i_i32[0] + 1));
      v25 = _mm_cvtsi32_si128(*((__int16 *)src + v30.m128i_i32[2] + 1));
      v30.m128i_i32[0] = *((__int16 *)src + v30.m128i_i32[2] + 1);
      *((__m128 *)v14 - 1) = _mm_add_ps(
                               _mm_mul_ps(_mm_sub_ps(*(__m128 *)onedata, v20), v23),
                               _mm_mul_ps(
                                 _mm_mul_ps(
                                   _mm_cvtepi32_ps(_mm_unpacklo_epi64(_mm_unpacklo_epi32(v24, v25), v22)),
                                   *(__m128 *)scale16data),
                                 v20));
    }
    while ( v15 < dstlength - 3 );
    v26 = (unsigned int)(dstlength - 4) >> 2;
    v27 = 4 * v26 + 4;
    dst += 4 * v26 + 4;
  }
  v28 = dstlength - v27;
  position->mValue = *(FMOD_UINT64 *)v13.m128i_i8;
  if ( v28 )
  {
    v29 = speed->mValue;
    do
    {
      *dst++ = (float)((float)(1.0 - (float)((float)(position->mLo >> 1) * 4.6566129e-10))
                     * (float)((float)*((__int16 *)src + position->mHi) * 0.000030517578))
             + (float)((float)((float)*((__int16 *)src + position->mHi + 1) * 0.000030517578)
                     * (float)((float)(position->mLo >> 1) * 4.6566129e-10));
      position->mValue += v29;
      --v28;
    }
    while ( v28 );
  }
}


// Address: 0x221b880 | Name: FMOD_Resampler_Linear_PCM16_Stereo_SSE_X64
void __fastcall FMOD_Resampler_Linear_PCM16_Stereo_SSE_X64(
        float *dst,
        int dstlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  __m128i v5; // xmm0
  __m128i v6; // xmm1
  __m128i v7; // xmm8
  __m128i v8; // xmm2
  float *v9; // r11
  int v10; // r10d
  __m128i v11; // xmm1
  __m128i v12; // xmm0
  __m128 v13; // xmm0
  __int64 v14; // rax
  __int64 v15; // r9
  __m128 v16; // xmm3
  __m128i v17; // xmm4
  __m128i v18; // xmm1
  __int64 v19; // r9
  int v20; // eax
  int v21; // esi
  FMOD_SINT64 mValue; // r9
  unsigned int v23; // eax
  float v24; // xmm0_4
  float v25; // xmm3_4
  float v26; // xmm1_4
  __m128i v27; // [rsp+0h] [rbp-38h] BYREF

  v5 = _mm_loadl_epi64((const __m128i *)position);
  v6 = _mm_loadl_epi64((const __m128i *)speed);
  v27.m128i_i64[0] = 2 * speed->mValue;
  v7 = _mm_shuffle_epi32(_mm_loadl_epi64(&v27), 68);
  v8 = _mm_add_epi64(_mm_unpacklo_epi64((__m128i)0LL, v6), _mm_shuffle_epi32(v5, 68));
  if ( dstlength - 1 <= 0 )
  {
    v20 = 0;
  }
  else
  {
    v9 = dst;
    v10 = 0;
    do
    {
      v11 = _mm_shuffle_epi32(v8, 13);
      v10 += 2;
      v9 += 4;
      v12 = _mm_shuffle_epi32(v8, 160);
      v8 = _mm_add_epi64(v8, v7);
      v27.m128i_i32[0] = _mm_cvtsi128_si32(v11);
      v27.m128i_i32[3] = v11.m128i_i32[1];
      v13 = _mm_mul_ps(_mm_cvtepi32_ps(_mm_srli_epi32(v12, 1u)), *(__m128 *)scale32data);
      v14 = 2 * v27.m128i_i32[0];
      v15 = 2 * v11.m128i_i32[1];
      v16 = _mm_mul_ps(
              _mm_cvtepi32_ps(
                _mm_unpacklo_epi64(
                  _mm_unpacklo_epi32(
                    _mm_cvtsi32_si128(*((__int16 *)src + v14)),
                    _mm_cvtsi32_si128(*((__int16 *)src + v14 + 1))),
                  _mm_unpacklo_epi32(
                    _mm_cvtsi32_si128(*((__int16 *)src + v15)),
                    _mm_cvtsi32_si128(*((__int16 *)src + v15 + 1))))),
              *(__m128 *)scale16data);
      v17 = _mm_unpacklo_epi32(
              _mm_cvtsi32_si128(*((__int16 *)src + v15 + 2)),
              _mm_cvtsi32_si128(*((__int16 *)src + v15 + 3)));
      v18 = _mm_cvtsi32_si128(*((__int16 *)src + v14 + 2));
      v27.m128i_i32[0] = *((__int16 *)src + v14 + 3);
      *((__m128 *)v9 - 1) = _mm_add_ps(
                              _mm_mul_ps(_mm_sub_ps(*(__m128 *)onedata, v13), v16),
                              _mm_mul_ps(
                                _mm_mul_ps(
                                  _mm_cvtepi32_ps(
                                    _mm_unpacklo_epi64(
                                      _mm_unpacklo_epi32(v18, _mm_cvtsi32_si128(v27.m128i_u32[0])),
                                      v17)),
                                  *(__m128 *)scale16data),
                                v13));
    }
    while ( v10 < dstlength - 1 );
    v19 = (unsigned int)(dstlength - 2) >> 1;
    v20 = 2 * v19 + 2;
    dst += 4 * v19 + 4;
  }
  v21 = dstlength - v20;
  position->mValue = *(FMOD_UINT64 *)v8.m128i_i8;
  if ( v21 )
  {
    mValue = speed->mValue;
    do
    {
      dst += 2;
      v23 = 2 * position->mHi;
      v24 = (float)*((__int16 *)src + v23 + 1);
      v25 = (float)(position->mLo >> 1) * 4.6566129e-10;
      v26 = (float)*((__int16 *)src + v23 + 3);
      *(dst - 2) = (float)((float)((float)*((__int16 *)src + v23) * 0.000030517578) * (float)(1.0 - v25))
                 + (float)((float)((float)*((__int16 *)src + v23 + 2) * 0.000030517578) * v25);
      *(dst - 1) = (float)((float)(v24 * 0.000030517578) * (float)(1.0 - v25))
                 + (float)((float)(v26 * 0.000030517578) * v25);
      position->mValue += mValue;
      --v21;
    }
    while ( v21 );
  }
}


