// Address: 0x2219a30 | Name: checkSSE
int __cdecl checkSSE()
{
  _RAX = 0;
  __asm { cpuid }
  if ( (int)_RAX <= 0 )
    return 0;
  _RAX = 1;
  __asm { cpuid }
  if ( (_RDX & 0x6000000) == 0x6000000 )
    return _RCX & 1;
  else
    return 0;
}


// Address: 0x2219a70 | Name: checkAVX
int __cdecl checkAVX()
{
  _RAX = 0;
  __asm { cpuid }
  if ( (int)_RAX <= 0 )
    return 0;
  _RAX = 1;
  __asm { cpuid }
  if ( (_RCX & 0x18000000) != 0x18000000 )
    return 0;
  __asm { xgetbv }
  return (_RAX & 6) == 6;
}


// Address: 0x2219ac0 | Name: _GLOBAL__sub_I_fmod_optimised_routines_sse_avx.cpp
void __cdecl GLOBAL__sub_I_fmod_optimised_routines_sse_avx_cpp()
{
  const _FMOD_Optimised_Routines *v0; // rsi

  v0 = &FMOD_Optimised_Routines_AVX;
  if ( !checkAVX() )
  {
    v0 = &FMOD_Optimised_Routines_SSE;
    if ( !checkSSE() )
      v0 = &FMOD_Optimised_Routines_NoOpt;
  }
  qmemcpy((void *)&FMOD_Optimised_Routines, v0, sizeof(FMOD_Optimised_Routines));
}


