// Address: 0x21bfd10 | Name: _ZN4FMOD14DSPConnectionI21clearInputOutputNodesEv
FMOD_RESULT_0 __fastcall FMOD::DSPConnectionI::clearInputOutputNodes(FMOD::DSPConnectionI *const this)
{
  FMOD::LinkedListNode *mNodePrev; // rdx
  FMOD::LinkedListNode *mNodeNext; // rcx
  FMOD::LinkedListNode *v3; // rcx
  FMOD::LinkedListNode *v4; // rdx

  mNodePrev = this->mInputNode.mNodePrev;
  mNodeNext = this->mInputNode.mNodeNext;
  this->mInputUnit = 0;
  mNodePrev->mNodeNext = mNodeNext;
  this->mInputNode.mNodeNext->mNodePrev = mNodePrev;
  v3 = this->mOutputNode.mNodeNext;
  v4 = this->mOutputNode.mNodePrev;
  this->mInputNode.mNodePrev = &this->mInputNode;
  this->mInputNode.mNodeNext = &this->mInputNode;
  this->mInputNode.mNodeData = this;
  this->mOutputUnit = 0;
  v4->mNodeNext = v3;
  this->mOutputNode.mNodeNext->mNodePrev = v4;
  this->mOutputNode.mNodePrev = &this->mOutputNode;
  this->mOutputNode.mNodeNext = &this->mOutputNode;
  this->mOutputNode.mNodeData = this;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e7cd0 | Name: _ZN4FMOD8Metadata6addTagEPNS_7TagNodeE
FMOD_RESULT_0 __fastcall FMOD::Metadata::addTag(FMOD::Metadata *const this, FMOD::TagNode *node)
{
  FMOD::LinkedListNode *mNodePrev; // rax

  mNodePrev = this->mList.mNodePrev;
  node->mNodeNext = &this->mList;
  node->mNodePrev = mNodePrev;
  this->mList.mNodePrev = node;
  node->mNodePrev->FMOD::LinkedListNode::mNodeNext = node;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21eb820 | Name: _ZN4FMOD8DSPFader18updateMaxFadeValueEv
FMOD_RESULT_0 __fastcall FMOD::DSPFader::updateMaxFadeValue(FMOD::DSPFader *const this)
{
  float *v1; // rax
  float *v2; // rdx
  float v3; // xmm0_4

  v1 = (float *)*((_QWORD *)this + 70);
  v2 = (float *)((char *)this + 560);
  v3 = 0.0;
  if ( (float *)((char *)this + 560) == v1 )
  {
    if ( v2 == *((float **)this + 71) )
      return FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    do
    {
      v3 = fmaxf(v3, v1[4]);
      v1 = *(float **)v1;
    }
    while ( v2 != v1 );
  }
  *((float *)this + 166) = v3;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220d250 | Name: _ZN4FMOD9DSPReturn7addSendEPNS_7DSPSendE
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::addSend(FMOD::DSPReturn *const this, FMOD::DSPSend *send)
{
  *((_QWORD *)send + 72) = *((_QWORD *)this + 75);
  *((_QWORD *)send + 71) = (char *)this + 592;
  *((_QWORD *)this + 75) = (char *)send + 568;
  **((_QWORD **)send + 72) = (char *)send + 568;
  *((_QWORD *)send + 73) = send;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x220d290 | Name: _ZN4FMOD9DSPReturn10removeSendEPNS_7DSPSendE
FMOD_RESULT_0 __fastcall FMOD::DSPReturn::removeSend(FMOD::DSPReturn *const this, FMOD::DSPSend *send)
{
  _QWORD *v2; // rdx

  v2 = (_QWORD *)*((_QWORD *)send + 72);
  *v2 = *((_QWORD *)send + 71);
  *(_QWORD *)(*((_QWORD *)send + 71) + 8LL) = v2;
  *((_QWORD *)send + 72) = (char *)send + 568;
  *((_QWORD *)send + 71) = (char *)send + 568;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22334c0 | Name: _ZN4FMOD7SystemI21addDSPMeteringContextEPNS_24FMOD_DSP_PROFILE_CONTEXTE
FMOD_RESULT_0 __fastcall FMOD::SystemI::addDSPMeteringContext(
        FMOD::SystemI *const this,
        FMOD::FMOD_DSP_PROFILE_CONTEXT *context)
{
  context->mListNode.mNodePrev = this->mDSPMeteringNodes.mNodePrev;
  context->mListNode.mNodeNext = &this->mDSPMeteringNodes;
  this->mDSPMeteringNodes.mNodePrev = &context->mListNode;
  context->mListNode.mNodePrev->mNodeNext = &context->mListNode;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2233500 | Name: _ZN4FMOD7SystemI24removeDSPMeteringContextEPNS_24FMOD_DSP_PROFILE_CONTEXTE
FMOD_RESULT_0 __fastcall FMOD::SystemI::removeDSPMeteringContext(
        FMOD::SystemI *const this,
        FMOD::FMOD_DSP_PROFILE_CONTEXT *context)
{
  FMOD::LinkedListNode *mNodePrev; // rdx

  mNodePrev = context->mListNode.mNodePrev;
  mNodePrev->mNodeNext = context->mListNode.mNodeNext;
  context->mListNode.mNodeNext->mNodePrev = mNodePrev;
  context->mListNode.mNodePrev = &context->mListNode;
  context->mListNode.mNodeNext = &context->mListNode;
  return FMOD_RESULT::FMOD_OK_0;
}


