// Address: 0x21f70b0 | Name: _ZN4FMOD6Sample4lockEjjPPvS2_PjS3_
FMOD_RESULT_0 __fastcall FMOD::Sample::lock(
        FMOD::Sample *const this,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  if ( ptr1 )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::Sample *const, unsigned int, unsigned int, void **, void **, unsigned int *))this->_vptr_SoundI
            + 48))(
             this,
             offset,
             length,
             ptr1,
             ptr2,
             len1);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21f70d0 | Name: _ZN4FMOD6Sample6unlockEPvS1_jj
FMOD_RESULT_0 __fastcall FMOD::Sample::unlock(
        FMOD::Sample *const this,
        void *ptr1,
        void *ptr2,
        unsigned int len1,
        unsigned int len2)
{
  if ( ptr1 && len1 )
    return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::Sample *const, void *, void *, unsigned int, unsigned int))this->_vptr_SoundI
            + 49))(
             this,
             ptr1,
             ptr2,
             len1,
             len2);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21f70f0 | Name: _ZN4FMOD6SampleC2Ev
void __fastcall FMOD::Sample::Sample(FMOD::Sample *const this)
{
  FMOD::SoundI::SoundI(this);
  this->mLockCanRead = 1;
  this->_vptr_SoundI = (int (**)(...))&off_29B1AB0;
}


// Address: 0x21f7110 | Name: _ZN4FMOD6Sample7releaseEb
FMOD_RESULT_0 __fastcall FMOD::Sample::release(FMOD::Sample *const this, bool freethis)
{
  FMOD::SystemI *mSystem; // rdi

  mSystem = this->mSystem;
  if ( mSystem )
    FMOD::SystemI::stopSound(mSystem, this);
  return FMOD::SoundI::release(this, freethis);
}


// Address: 0x21f7150 | Name: _ZN4FMOD6Sample11setDefaultsEfi
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::Sample::setDefaults(FMOD::Sample *const this, double a2, float frequency, int priority)
{
  return FMOD::SoundI::setDefaults(this, frequency, priority);
}


// Address: 0x21f7160 | Name: _ZN4FMOD6Sample19set3DMinMaxDistanceEff
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::Sample::set3DMinMaxDistance(FMOD::Sample *const this, double a2, float min, float max)
{
  return FMOD::SoundI::set3DMinMaxDistance(this, min, max);
}


// Address: 0x21f7170 | Name: _ZN4FMOD6Sample17set3DConeSettingsEfff
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::Sample::set3DConeSettings(
        FMOD::Sample *const this,
        double a2,
        float insideconeangle,
        float outsideconeangle,
        float outsidevolume)
{
  return FMOD::SoundI::set3DConeSettings(this, insideconeangle, outsideconeangle, outsidevolume);
}


// Address: 0x21f7180 | Name: _ZN4FMOD6Sample7setModeEj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::Sample::setMode(FMOD::Sample *const this, FMOD_MODE mode)
{
  return FMOD::SoundI::setMode(this, mode);
}


// Address: 0x21f7190 | Name: _ZN4FMOD6Sample12setLoopCountEi
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::Sample::setLoopCount(FMOD::Sample *const this, int loopcount)
{
  return FMOD::SoundI::setLoopCount(this, loopcount);
}


// Address: 0x21f71a0 | Name: _ZN4FMOD6Sample13setLoopPointsEjjjj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::Sample::setLoopPoints(
        FMOD::Sample *const this,
        unsigned int loopstart,
        FMOD_TIMEUNIT loopstarttype,
        unsigned int loopend,
        FMOD_TIMEUNIT loopendtype)
{
  return FMOD::SoundI::setLoopPoints(this, loopstart, loopstarttype, loopend, loopendtype);
}


