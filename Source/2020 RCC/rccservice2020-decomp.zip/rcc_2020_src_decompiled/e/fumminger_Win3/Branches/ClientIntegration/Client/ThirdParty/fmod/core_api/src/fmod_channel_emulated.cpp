// Address: 0x221fa60 | Name: _ZN4FMOD15ChannelEmulated4initEiPNS_7SystemIEPNS_6OutputE
FMOD_RESULT_0 __fastcall FMOD::ChannelEmulated::init(
        FMOD::ChannelEmulated *const this,
        int index,
        FMOD::SystemI *system,
        FMOD::Output *output)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::ChannelReal::init(this, index, system, output);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    this->mMinFrequency = -this->mMaxFrequency;
  return result;
}


// Address: 0x221fa90 | Name: _ZN4FMOD15ChannelEmulated4stopEv
FMOD_RESULT_0 __fastcall FMOD::ChannelEmulated::stop(FMOD::ChannelEmulated *const this)
{
  FMOD::SoundI *mSound; // rdi
  _BYTE *mNodeData; // rax

  mSound = this->mSound;
  if ( mSound )
  {
    if ( (unsigned __int8)(*mSound->_vptr_SoundI)(mSound) )
    {
      mNodeData = this->mSound[1].mNodeData;
      if ( mNodeData )
        mNodeData[136] = 1;
    }
  }
  return FMOD::ChannelReal::stop(this);
}


// Address: 0x221fad0 | Name: _ZN4FMOD15ChannelEmulated6updateEi
FMOD_RESULT_0 __fastcall FMOD::ChannelEmulated::update(FMOD::ChannelEmulated *const this, int delta)
{
  int v2; // ebp
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelI *mParent; // rdi
  int (**vptr_ChannelControlI)(...); // rax
  FMOD::DSPI *mDSPHead; // r12
  FMOD::DSPClock *mDelayParent; // rdx
  FMOD::ChannelI *v9; // rax
  int v10; // eax
  FMOD::SoundI *mSound; // rax
  FMOD_MODE mMode; // esi
  int v13; // edx
  unsigned int mLoopStart; // eax
  int v15; // esi
  float mFrequency; // xmm1_4
  unsigned int mLoopLength; // ecx
  int mLoopCount; // eax
  _BOOL4 v19; // ecx
  bool delaystop; // [rsp+Fh] [rbp-29h] BYREF
  FMOD_CLOCKTIME delaystart; // [rsp+10h] [rbp-28h] BYREF
  FMOD_CLOCKTIME delayend[4]; // [rsp+18h] [rbp-20h] BYREF

  v2 = delta;
  result = FMOD::ChannelReal::update(this, delta);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( (this->mFlags & 0x60) != 0x40 )
      return FMOD_RESULT::FMOD_OK_0;
    mParent = this->mParent;
    if ( (mParent->mFlags & 0x30000) == 0x10000 || (this->mMode & 0x80000000) != 0 )
      return FMOD_RESULT::FMOD_OK_0;
    vptr_ChannelControlI = mParent->_vptr_ChannelControlI;
    delaystart = 0;
    delayend[0] = 0;
    delaystop = 0;
    mDSPHead = mParent->mDSPHead;
    result = vptr_ChannelControlI[29](mParent, &delaystart, delayend, &delaystop);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( delaystart || delayend[0] )
      {
        if ( mDSPHead )
        {
          mDelayParent = mDSPHead->mJob.mDelayClock.mDelayParent;
          if ( mDelayParent )
            mDelayParent = (FMOD::DSPClock *)mDelayParent->mClock;
        }
        else
        {
          mDelayParent = 0;
        }
        if ( delaystart && (unsigned __int64)mDelayParent < delaystart )
        {
          v2 = 0;
        }
        else if ( delayend[0] )
        {
          if ( (unsigned __int64)mDelayParent >= delayend[0] )
          {
            v2 = 0;
            if ( delaystop )
              this->mFlags &= ~0x40u;
          }
        }
      }
      if ( mDSPHead && mDSPHead->mJob.mDelayClock.mStopNow )
        this->mFlags &= ~0x40u;
      if ( v2 )
      {
        v9 = this->mParent;
        LODWORD(v9) = v2
                    * (int)(float)((float)((float)((float)((float)(1.0 - v9->m3DLevel)
                                                         + (float)(v9->m3DLevel * v9->mPitch3D))
                                                 * v9->mFrequency)
                                         * v9->mPitch)
                                 * v9->mChannelGroupParent->mRealPitch);
        v2 = (int)v9 / 1000;
        v10 = (int)v9 / -1000;
        if ( this->mDirection == 1 )
          v2 = v10;
        this->mPosition.mHi += v2;
      }
      mSound = this->mSound;
      if ( mSound )
      {
        mMode = this->mMode;
        v13 = mMode & 2;
        if ( (mMode & 2) != 0 || (mMode & 4) != 0 && this->mLoopCount )
        {
          v15 = mMode & 4;
          mFrequency = this->mParent->mFrequency;
          while ( mFrequency > 0.0 && this->mPosition.mHi >= this->mLoopStart + this->mLoopLength
               || mFrequency < 0.0 && this->mPosition.mHi <= this->mLoopStart )
          {
            mLoopCount = this->mLoopCount;
            if ( !mLoopCount )
            {
              if ( !this->mDirection && mFrequency > 0.0 )
              {
                this->mPosition.mHi = this->mLoopStart + this->mLoopLength;
                goto LABEL_28;
              }
              mLoopStart = this->mLoopStart;
              goto LABEL_27;
            }
            if ( v13 )
            {
              mLoopLength = this->mLoopLength;
              if ( mFrequency <= 0.0 )
                this->mPosition.mHi += mLoopLength;
              else
                this->mPosition.mHi -= mLoopLength;
            }
            else if ( v15 )
            {
              v19 = this->mDirection == 0;
              this->mPosition.mHi -= v2;
              this->mDirection = v19;
            }
            if ( mLoopCount >= 0 )
              this->mLoopCount = mLoopCount - 1;
          }
        }
        else
        {
          mLoopStart = mSound->mLength;
          if ( this->mPosition.mHi >= mLoopStart )
          {
LABEL_27:
            this->mPosition.mHi = mLoopStart;
LABEL_28:
            this->mFlags &= ~0x40u;
          }
        }
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


