// Address: 0x2249ba0 | Name: FMOD_Resampler_Cubic
void __fastcall FMOD_Resampler_Cubic(
        float *out,
        int outlength,
        void *src,
        FMOD_SOUND_FORMAT_0 srcformat,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed,
        int channels)
{
  FMOD_UINT64 mValue; // r10
  int v8; // ebp
  float *v9; // rax
  FMOD_SINT64 v10; // rbx
  FMOD_SINT64 v11; // r12
  FMOD_UINT64 v12; // rcx
  FMOD_UINT64 v13; // r10
  float mLo; // xmm8_4
  unsigned int mHi; // r11d
  int v16; // r15d
  float v17; // xmm7_4
  __int64 v18; // r14
  int v19; // r11d
  float v20; // xmm10_4
  float v21; // xmm3_4
  float v22; // xmm12_4
  int v23; // r15d
  float v24; // xmm4_4
  int v25; // r11d
  float v26; // xmm5_4
  int v27; // r11d
  float v28; // xmm2_4
  float v29; // xmm5_4
  int v30; // r11d
  __int64 v31; // r14
  int v32; // r15d
  float v33; // xmm5_4
  __int64 v34; // r14
  float v35; // xmm15_4
  FMOD_UINT64 v36; // r11
  float v37; // xmm6_4
  float v38; // xmm15_4
  int v39; // r15d
  float v40; // xmm14_4
  __int64 v41; // r14
  float v42; // xmm1_4
  int v43; // esi
  FMOD_SINT64 v44; // r11
  FMOD_UINT64 v45; // rcx
  unsigned int v46; // eax
  int v47; // r10d
  float v48; // xmm2_4
  float v49; // xmm1_4
  float v50; // xmm7_4
  FMOD_SINT64 v51; // r13
  FMOD_UINT64 v52; // r12
  float v53; // xmm6_4
  __int64 v54; // rax
  int v55; // r11d
  __int64 v56; // rbx
  __int64 v57; // rax
  char *v58; // rbx
  float v59; // xmm0_4
  float v60; // xmm3_4
  float v61; // xmm8_4
  FMOD_SINT64 v62; // r13
  FMOD_UINT64 v63; // r12
  float v64; // xmm8_4
  __int64 v65; // rax
  unsigned int v66; // r11d
  char *v67; // rbx
  float v68; // xmm3_4
  float v69; // xmm2_4
  float v70; // xmm1_4
  float v71; // xmm6_4
  FMOD_SINT64 v72; // r13
  FMOD_UINT64 v73; // r12
  float v74; // xmm8_4
  __int64 v75; // rax
  int v76; // r11d
  __int64 v77; // rbx
  __int64 v78; // rax
  char *v79; // rbx
  float v80; // xmm3_4
  float v81; // xmm2_4
  float v82; // xmm1_4
  float v83; // xmm6_4
  FMOD_UINT64 v84; // r14
  float v85; // xmm8_4
  __int64 v86; // rax
  __int64 v87; // rcx
  int v88; // ebp
  unsigned __int8 *v89; // rsi
  int v90; // r15d
  float v91; // xmm3_4
  float v92; // xmm2_4
  float v93; // xmm1_4
  float v94; // xmm6_4
  FMOD_SINT64 v95; // r13
  FMOD_UINT64 v96; // r12
  float v97; // xmm8_4
  __int64 v98; // rax
  int v99; // r11d
  __int64 v100; // rbx
  __int64 v101; // rax
  char *v102; // rbx
  float v103; // xmm3_4
  float v104; // xmm2_4
  float v105; // xmm1_4
  float v106; // xmm6_4
  FMOD_UINT64 v107; // r10
  int v108; // ebp
  float *v109; // rax
  FMOD_SINT64 v110; // rbx
  FMOD_SINT64 v111; // r12
  FMOD_UINT64 v112; // rcx
  FMOD_UINT64 v113; // r10
  float v114; // xmm3_4
  unsigned int v115; // r11d
  float v116; // xmm12_4
  float v117; // xmm5_4
  float v118; // xmm9_4
  float v119; // xmm7_4
  float v120; // xmm15_4
  float v121; // xmm8_4
  float v122; // xmm4_4
  float v123; // xmm1_4
  int v124; // r11d
  __int64 v125; // r14
  float v126; // xmm14_4
  float v127; // xmm4_4
  __int64 v128; // r14
  float v129; // xmm2_4
  float v130; // xmm0_4
  FMOD_UINT64 v131; // r11
  float v132; // xmm7_4
  float v133; // xmm10_4
  float v134; // xmm6_4
  int v135; // esi
  FMOD_SINT64 v136; // r10
  FMOD_UINT64 v137; // rcx
  unsigned int v138; // eax
  float v139; // xmm6_4
  __int64 v140; // r9
  float v141; // xmm3_4
  float v142; // xmm7_4
  FMOD_UINT64 v143; // r10
  int v144; // ebp
  float *v145; // rax
  FMOD_SINT64 v146; // rbx
  FMOD_SINT64 v147; // r12
  FMOD_UINT64 v148; // rcx
  FMOD_UINT64 v149; // r10
  float v150; // xmm8_4
  unsigned int v151; // r11d
  float v152; // xmm10_4
  float v153; // xmm7_4
  float v154; // xmm6_4
  float v155; // xmm2_4
  float v156; // xmm12_4
  float v157; // xmm3_4
  float v158; // xmm4_4
  float v159; // xmm5_4
  int v160; // r11d
  float v161; // xmm1_4
  FMOD_UINT64 v162; // r14
  float v163; // xmm5_4
  float v164; // xmm15_4
  FMOD_UINT64 v165; // r11
  float v166; // xmm6_4
  float v167; // xmm14_4
  float v168; // xmm0_4
  float v169; // xmm3_4
  int v170; // esi
  FMOD_SINT64 v171; // r10
  FMOD_UINT64 v172; // rcx
  unsigned int v173; // eax
  float v174; // xmm4_4
  float v175; // xmm2_4
  float v176; // xmm1_4
  float v177; // xmm7_4
  FMOD_SINT64 v178; // r11
  FMOD_UINT64 v179; // r10
  unsigned int v180; // eax
  __int64 v181; // rbx
  float v182; // xmm4_4
  float v183; // xmm2_4
  float v184; // xmm1_4
  float v185; // xmm7_4
  FMOD_UINT64 v186; // r10
  int v187; // ebp
  float *v188; // rax
  FMOD_SINT64 v189; // rbx
  FMOD_SINT64 v190; // r12
  FMOD_UINT64 v191; // rcx
  FMOD_UINT64 v192; // r10
  float v193; // xmm8_4
  unsigned int v194; // r11d
  int v195; // r15d
  float v196; // xmm7_4
  __int64 v197; // r14
  int v198; // r11d
  float v199; // xmm10_4
  float v200; // xmm3_4
  float v201; // xmm12_4
  int v202; // r15d
  float v203; // xmm4_4
  int v204; // r11d
  float v205; // xmm5_4
  int v206; // r11d
  float v207; // xmm2_4
  float v208; // xmm5_4
  int v209; // r11d
  __int64 v210; // r14
  int v211; // r15d
  float v212; // xmm5_4
  __int64 v213; // r14
  float v214; // xmm15_4
  FMOD_UINT64 v215; // r11
  float v216; // xmm6_4
  float v217; // xmm15_4
  int v218; // r15d
  float v219; // xmm14_4
  __int64 v220; // r14
  float v221; // xmm1_4
  int v222; // esi
  FMOD_SINT64 v223; // r11
  FMOD_UINT64 v224; // rcx
  unsigned int v225; // eax
  int v226; // r10d
  float v227; // xmm2_4
  float v228; // xmm1_4
  float v229; // xmm7_4
  FMOD_SINT64 v230; // [rsp+0h] [rbp-70h]
  int outlengtha; // [rsp+Ch] [rbp-64h]
  float v232; // [rsp+10h] [rbp-60h]
  float p3; // [rsp+18h] [rbp-58h]
  float p3a; // [rsp+18h] [rbp-58h]
  float p3b; // [rsp+18h] [rbp-58h]
  float p3c; // [rsp+18h] [rbp-58h]
  float f; // [rsp+20h] [rbp-50h]
  float fa; // [rsp+20h] [rbp-50h]
  float fb; // [rsp+20h] [rbp-50h]
  float fc; // [rsp+20h] [rbp-50h]
  float p0; // [rsp+24h] [rbp-4Ch]
  float p0a; // [rsp+24h] [rbp-4Ch]
  float p0b; // [rsp+24h] [rbp-4Ch]
  float p0c; // [rsp+24h] [rbp-4Ch]
  float v245; // [rsp+28h] [rbp-48h]
  float v246; // [rsp+28h] [rbp-48h]
  float v247; // [rsp+28h] [rbp-48h]
  float v248; // [rsp+2Ch] [rbp-44h]
  float v249; // [rsp+2Ch] [rbp-44h]
  float v250; // [rsp+2Ch] [rbp-44h]
  float v251; // [rsp+30h] [rbp-40h]
  float v252; // [rsp+30h] [rbp-40h]
  float v253; // [rsp+30h] [rbp-40h]
  float v254; // [rsp+34h] [rbp-3Ch]
  float v255; // [rsp+34h] [rbp-3Ch]

  switch ( srcformat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      if ( channels == 1 )
      {
        if ( outlength >> 2 )
        {
          mValue = position->mValue;
          v8 = outlength >> 2;
          v9 = out;
          v10 = 2 * speed->mValue;
          v11 = 4 * speed->mValue;
          v12 = position->mValue + speed->mValue;
          do
          {
            v13 = v10 + mValue;
            v9 += 4;
            mLo = (float)(int)position->mLo;
            mHi = position->mHi;
            v16 = *((char *)src + mHi - 1);
            v17 = (float)*((char *)src + mHi);
            v18 = mHi + 1;
            v19 = *((char *)src + mHi + 2);
            LODWORD(v18) = *((char *)src + v18);
            position->mValue = v12;
            v20 = (float)v16 * 0.0078125;
            v21 = (float)(int)v18 * 0.0078125;
            v22 = (float)v19 * 0.0078125;
            v23 = *((char *)src + HIDWORD(v12) - 1);
            v24 = (float)*((char *)src + HIDWORD(v12));
            v25 = *((char *)src + (unsigned int)(HIDWORD(v12) + 2));
            LODWORD(v18) = *((char *)src + (unsigned int)(HIDWORD(v12) + 1));
            position->mValue = v13;
            v26 = (float)v25;
            v27 = v13;
            f = (float)(int)v12 * 2.3283064e-10;
            p0 = (float)v23 * 0.0078125;
            v28 = (float)(int)v18;
            HIDWORD(v18) = HIDWORD(v13);
            mValue = v10 + v13;
            p3 = v26 * 0.0078125;
            v29 = (float)v27;
            v30 = HIDWORD(v18);
            v31 = HIDWORD(v18);
            v32 = *((char *)src + v31 - 1);
            v245 = v29 * 2.3283064e-10;
            v33 = (float)*((char *)src + v31);
            v34 = (unsigned int)(v30 + 1);
            v35 = (float)*((char *)src + (unsigned int)(v30 + 2));
            v36 = v10 + v12;
            v37 = (float)*((char *)src + v34);
            v12 += v11;
            LODWORD(v34) = v36;
            position->mValue = v36;
            v36 >>= 32;
            v248 = (float)v32 * 0.0078125;
            v251 = v35 * 0.0078125;
            v38 = (float)(int)v34;
            v39 = *((char *)src + (unsigned int)v36 - 1);
            v40 = (float)*((char *)src + (unsigned int)v36);
            v41 = (unsigned int)(v36 + 1);
            LODWORD(v36) = *((char *)src + (unsigned int)(v36 + 2));
            LODWORD(v41) = *((char *)src + v41);
            position->mValue = mValue;
            v42 = (float)(int)v41 * 0.0078125;
            *(v9 - 4) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v17 * 0.0078125) - v21)
                                                                                              * 3.0)
                                                                                      - v20)
                                                                              + v22)
                                                                      * 0.5)
                                                              * (float)(mLo * 2.3283064e-10))
                                                      + (float)((float)((float)(v21 + v21) + v20)
                                                              - (float)((float)((float)(5.0 * (float)(v17 * 0.0078125))
                                                                              + v22)
                                                                      * 0.5)))
                                              * (float)(mLo * 2.3283064e-10))
                                      + (float)((float)(v21 - v20) * 0.5))
                              * (float)(mLo * 2.3283064e-10))
                      + (float)(v17 * 0.0078125);
            *(v9 - 3) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v24 * 0.0078125) - (float)(v28 * 0.0078125))
                                                                                              * 3.0)
                                                                                      - p0)
                                                                              + p3)
                                                                      * 0.5)
                                                              * f)
                                                      + (float)((float)((float)((float)(v28 * 0.0078125)
                                                                              + (float)(v28 * 0.0078125))
                                                                      + p0)
                                                              - (float)((float)((float)(5.0 * (float)(v24 * 0.0078125))
                                                                              + p3)
                                                                      * 0.5)))
                                              * f)
                                      + (float)((float)((float)(v28 * 0.0078125) - p0) * 0.5))
                              * f)
                      + (float)(v24 * 0.0078125);
            *(v9 - 2) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v33 * 0.0078125) - (float)(v37 * 0.0078125))
                                                                                              * 3.0)
                                                                                      - v248)
                                                                              + v251)
                                                                      * 0.5)
                                                              * v245)
                                                      + (float)((float)((float)((float)(v37 * 0.0078125)
                                                                              + (float)(v37 * 0.0078125))
                                                                      + v248)
                                                              - (float)((float)((float)(5.0 * (float)(v33 * 0.0078125))
                                                                              + v251)
                                                                      * 0.5)))
                                              * v245)
                                      + (float)((float)((float)(v37 * 0.0078125) - v248) * 0.5))
                              * v245)
                      + (float)(v33 * 0.0078125);
            *(v9 - 1) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v40 * 0.0078125) - v42)
                                                                                              * 3.0)
                                                                                      - (float)((float)v39 * 0.0078125))
                                                                              + (float)((float)(int)v36 * 0.0078125))
                                                                      * 0.5)
                                                              * (float)(v38 * 2.3283064e-10))
                                                      + (float)((float)((float)(v42 + v42)
                                                                      + (float)((float)v39 * 0.0078125))
                                                              - (float)((float)((float)(5.0 * (float)(v40 * 0.0078125))
                                                                              + (float)((float)(int)v36 * 0.0078125))
                                                                      * 0.5)))
                                              * (float)(v38 * 2.3283064e-10))
                                      + (float)((float)(v42 - (float)((float)v39 * 0.0078125)) * 0.5))
                              * (float)(v38 * 2.3283064e-10))
                      + (float)(v40 * 0.0078125);
            --v8;
          }
          while ( v8 );
          out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
        }
        v43 = outlength & 3;
        if ( v43 )
        {
          v44 = speed->mValue;
          v45 = position->mValue + speed->mValue;
          do
          {
            ++out;
            v46 = position->mHi;
            v47 = *((char *)src + v46 - 1);
            v48 = (float)*((char *)src + v46) * 0.0078125;
            v49 = (float)*((char *)src + v46 + 1) * 0.0078125;
            v50 = (float)*((char *)src + v46 + 2) * 0.0078125;
            *(out - 1) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v48 - v49) * 3.0)
                                                                                       - (float)((float)v47 * 0.0078125))
                                                                               + v50)
                                                                       * 0.5)
                                                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                                                       + (float)((float)((float)(v49 + v49)
                                                                       + (float)((float)v47 * 0.0078125))
                                                               - (float)((float)((float)(v48 * 5.0) + v50) * 0.5)))
                                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                                       + (float)((float)(v49 - (float)((float)v47 * 0.0078125)) * 0.5))
                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                       + v48;
            position->mValue = v45;
            v45 += v44;
            --v43;
          }
          while ( v43 );
        }
      }
      else if ( outlength )
      {
        v62 = speed->mValue;
        v63 = position->mValue + speed->mValue;
        do
        {
          v64 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v65 = 0;
            v66 = channels * position->mHi;
            v67 = (char *)src + channels * (position->mHi - 1LL);
            do
            {
              v68 = (float)v67[v65] * 0.0078125;
              v69 = (float)*((char *)src + v66 + (unsigned int)v65) * 0.0078125;
              v70 = (float)*((char *)src + channels + v66 + (unsigned int)v65) * 0.0078125;
              v71 = (float)*((char *)src + channels + channels + v66 + (unsigned int)v65) * 0.0078125;
              out[v65++] = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v69 - v70)
                                                                                                 * 3.0)
                                                                                         - v68)
                                                                                 + v71)
                                                                         * 0.5)
                                                                 * v64)
                                                         + (float)((float)((float)(v70 + v70) + v68)
                                                                 - (float)((float)((float)(v69 * 5.0) + v71) * 0.5)))
                                                 * v64)
                                         + (float)((float)(v70 - v68) * 0.5))
                                 * v64)
                         + v69;
            }
            while ( channels > (int)v65 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v63;
          v63 += v62;
          --outlength;
        }
        while ( outlength );
      }
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      if ( channels == 1 )
      {
        if ( outlength >> 2 )
        {
          v186 = position->mValue;
          v187 = outlength >> 2;
          v188 = out;
          v189 = 2 * speed->mValue;
          v190 = 4 * speed->mValue;
          v191 = position->mValue + speed->mValue;
          do
          {
            v192 = v189 + v186;
            v188 += 4;
            v193 = (float)(int)position->mLo;
            v194 = position->mHi;
            v195 = *((__int16 *)src + v194 - 1);
            v196 = (float)*((__int16 *)src + v194);
            v197 = v194 + 1;
            v198 = *((__int16 *)src + v194 + 2);
            LODWORD(v197) = *((__int16 *)src + v197);
            position->mValue = v191;
            v199 = (float)v195 * 0.000030517578;
            v200 = (float)(int)v197 * 0.000030517578;
            v201 = (float)v198 * 0.000030517578;
            v202 = *((__int16 *)src + HIDWORD(v191) - 1);
            v203 = (float)*((__int16 *)src + HIDWORD(v191));
            v204 = *((__int16 *)src + (unsigned int)(HIDWORD(v191) + 2));
            LODWORD(v197) = *((__int16 *)src + (unsigned int)(HIDWORD(v191) + 1));
            position->mValue = v192;
            v205 = (float)v204;
            v206 = v192;
            fc = (float)(int)v191 * 2.3283064e-10;
            p0c = (float)v202 * 0.000030517578;
            v207 = (float)(int)v197;
            HIDWORD(v197) = HIDWORD(v192);
            v186 = v189 + v192;
            p3c = v205 * 0.000030517578;
            v208 = (float)v206;
            v209 = HIDWORD(v197);
            v210 = HIDWORD(v197);
            v211 = *((__int16 *)src + v210 - 1);
            v247 = v208 * 2.3283064e-10;
            v212 = (float)*((__int16 *)src + v210);
            v213 = (unsigned int)(v209 + 1);
            v214 = (float)*((__int16 *)src + (unsigned int)(v209 + 2));
            v215 = v189 + v191;
            v216 = (float)*((__int16 *)src + v213);
            v191 += v190;
            LODWORD(v213) = v215;
            position->mValue = v215;
            v215 >>= 32;
            v250 = (float)v211 * 0.000030517578;
            v253 = v214 * 0.000030517578;
            v217 = (float)(int)v213;
            v218 = *((__int16 *)src + (unsigned int)v215 - 1);
            v219 = (float)*((__int16 *)src + (unsigned int)v215);
            v220 = (unsigned int)(v215 + 1);
            LODWORD(v215) = *((__int16 *)src + (unsigned int)(v215 + 2));
            LODWORD(v220) = *((__int16 *)src + v220);
            position->mValue = v186;
            v221 = (float)(int)v220 * 0.000030517578;
            *(v188 - 4) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v196 * 0.000030517578) - v200)
                                                                                                * 3.0)
                                                                                        - v199)
                                                                                + v201)
                                                                        * 0.5)
                                                                * (float)(v193 * 2.3283064e-10))
                                                        + (float)((float)((float)(v200 + v200) + v199)
                                                                - (float)((float)((float)(5.0
                                                                                        * (float)(v196 * 0.000030517578))
                                                                                + v201)
                                                                        * 0.5)))
                                                * (float)(v193 * 2.3283064e-10))
                                        + (float)((float)(v200 - v199) * 0.5))
                                * (float)(v193 * 2.3283064e-10))
                        + (float)(v196 * 0.000030517578);
            *(v188 - 3) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v203 * 0.000030517578) - (float)(v207 * 0.000030517578))
                                                                                                * 3.0)
                                                                                        - p0c)
                                                                                + p3c)
                                                                        * 0.5)
                                                                * fc)
                                                        + (float)((float)((float)((float)(v207 * 0.000030517578)
                                                                                + (float)(v207 * 0.000030517578))
                                                                        + p0c)
                                                                - (float)((float)((float)(5.0
                                                                                        * (float)(v203 * 0.000030517578))
                                                                                + p3c)
                                                                        * 0.5)))
                                                * fc)
                                        + (float)((float)((float)(v207 * 0.000030517578) - p0c) * 0.5))
                                * fc)
                        + (float)(v203 * 0.000030517578);
            *(v188 - 2) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v212 * 0.000030517578) - (float)(v216 * 0.000030517578))
                                                                                                * 3.0)
                                                                                        - v250)
                                                                                + v253)
                                                                        * 0.5)
                                                                * v247)
                                                        + (float)((float)((float)((float)(v216 * 0.000030517578)
                                                                                + (float)(v216 * 0.000030517578))
                                                                        + v250)
                                                                - (float)((float)((float)(5.0
                                                                                        * (float)(v212 * 0.000030517578))
                                                                                + v253)
                                                                        * 0.5)))
                                                * v247)
                                        + (float)((float)((float)(v216 * 0.000030517578) - v250) * 0.5))
                                * v247)
                        + (float)(v212 * 0.000030517578);
            *(v188 - 1) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v219 * 0.000030517578) - v221)
                                                                                                * 3.0)
                                                                                        - (float)((float)v218
                                                                                                * 0.000030517578))
                                                                                + (float)((float)(int)v215
                                                                                        * 0.000030517578))
                                                                        * 0.5)
                                                                * (float)(v217 * 2.3283064e-10))
                                                        + (float)((float)((float)(v221 + v221)
                                                                        + (float)((float)v218 * 0.000030517578))
                                                                - (float)((float)((float)(5.0
                                                                                        * (float)(v219 * 0.000030517578))
                                                                                + (float)((float)(int)v215
                                                                                        * 0.000030517578))
                                                                        * 0.5)))
                                                * (float)(v217 * 2.3283064e-10))
                                        + (float)((float)(v221 - (float)((float)v218 * 0.000030517578)) * 0.5))
                                * (float)(v217 * 2.3283064e-10))
                        + (float)(v219 * 0.000030517578);
            --v187;
          }
          while ( v187 );
          out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
        }
        v222 = outlength & 3;
        if ( v222 )
        {
          v223 = speed->mValue;
          v224 = position->mValue + speed->mValue;
          do
          {
            ++out;
            v225 = position->mHi;
            v226 = *((__int16 *)src + v225 - 1);
            v227 = (float)*((__int16 *)src + v225) * 0.000030517578;
            v228 = (float)*((__int16 *)src + v225 + 1) * 0.000030517578;
            v229 = (float)*((__int16 *)src + v225 + 2) * 0.000030517578;
            *(out - 1) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v227 - v228)
                                                                                               * 3.0)
                                                                                       - (float)((float)v226
                                                                                               * 0.000030517578))
                                                                               + v229)
                                                                       * 0.5)
                                                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                                                       + (float)((float)((float)(v228 + v228)
                                                                       + (float)((float)v226 * 0.000030517578))
                                                               - (float)((float)((float)(v227 * 5.0) + v229) * 0.5)))
                                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                                       + (float)((float)(v228 - (float)((float)v226 * 0.000030517578)) * 0.5))
                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                       + v227;
            position->mValue = v224;
            v224 += v223;
            --v222;
          }
          while ( v222 );
        }
      }
      else if ( outlength )
      {
        v72 = speed->mValue;
        v73 = position->mValue + speed->mValue;
        do
        {
          v74 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v75 = position->mHi;
            v76 = v75 * channels;
            v77 = 2 * v75 - 2;
            v78 = 0;
            v79 = (char *)src + channels * v77;
            do
            {
              v80 = (float)*(__int16 *)&v79[2 * v78] * 0.000030517578;
              v81 = (float)*((__int16 *)src + (unsigned int)(v76 + v78)) * 0.000030517578;
              v82 = (float)*((__int16 *)src + (unsigned int)(channels + v76 + v78)) * 0.000030517578;
              v83 = (float)*((__int16 *)src + (unsigned int)(channels + channels + v76 + v78)) * 0.000030517578;
              out[v78++] = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v81 - v82)
                                                                                                 * 3.0)
                                                                                         - v80)
                                                                                 + v83)
                                                                         * 0.5)
                                                                 * v74)
                                                         + (float)((float)((float)(v82 + v82) + v80)
                                                                 - (float)((float)((float)(v81 * 5.0) + v83) * 0.5)))
                                                 * v74)
                                         + (float)((float)(v82 - v80) * 0.5))
                                 * v74)
                         + v81;
            }
            while ( channels > (int)v78 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v73;
          v73 += v72;
          --outlength;
        }
        while ( outlength );
      }
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      if ( channels == 1 )
      {
        if ( outlength )
        {
          v178 = speed->mValue;
          v179 = position->mValue + speed->mValue;
          do
          {
            ++out;
            v180 = position->mHi;
            v181 = 3LL * v180;
            v182 = (float)((((unsigned __int8)*((char *)src + v181 - 1) << 24)
                          | ((unsigned __int8)*((char *)src + v181 - 3) << 8)
                          | ((unsigned __int8)*((char *)src + v181 - 2) << 16)) >> 8)
                 * 0.00000011920929;
            v183 = (float)(((*((unsigned __int8 *)src + v181 + 2) << 24)
                          | (*((unsigned __int8 *)src + v181) << 8)
                          | (*((unsigned __int8 *)src + v181 + 1) << 16)) >> 8)
                 * 0.00000011920929;
            v184 = (float)(((*((unsigned __int8 *)src + 3 * v180 + 5) << 24)
                          | (*((unsigned __int8 *)src + 3 * v180 + 3) << 8)
                          | (*((unsigned __int8 *)src + 3 * v180 + 4) << 16)) >> 8)
                 * 0.00000011920929;
            v185 = (float)(((*((unsigned __int8 *)src + 3 * v180 + 8) << 24)
                          | (*((unsigned __int8 *)src + 3 * v180 + 6) << 8)
                          | (*((unsigned __int8 *)src + 3 * v180 + 7) << 16)) >> 8)
                 * 0.00000011920929;
            *(out - 1) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v183 - v184)
                                                                                               * 3.0)
                                                                                       - v182)
                                                                               + v185)
                                                                       * 0.5)
                                                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                                                       + (float)((float)((float)(v184 + v184) + v182)
                                                               - (float)((float)((float)(v183 * 5.0) + v185) * 0.5)))
                                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                                       + (float)((float)(v184 - v182) * 0.5))
                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                       + v183;
            position->mValue = v179;
            v179 += v178;
            --outlength;
          }
          while ( outlength );
        }
      }
      else if ( outlength )
      {
        outlengtha = outlength;
        v230 = speed->mValue;
        v84 = position->mValue + speed->mValue;
        do
        {
          v85 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v86 = position->mHi;
            v87 = 0;
            v88 = channels + v86 * channels;
            v89 = (unsigned __int8 *)src + channels * (3 * v86 - 3);
            do
            {
              v90 = *v89;
              v89 += 3;
              v91 = (float)(((*(v89 - 1) << 24) | (v90 << 8) | (*(v89 - 2) << 16)) >> 8) * 0.00000011920929;
              v92 = (float)(((*((unsigned __int8 *)src + 3 * (unsigned int)(v86 * channels + v87) + 2) << 24)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(v86 * channels + v87)) << 8)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(v86 * channels + v87) + 1) << 16)) >> 8)
                  * 0.00000011920929;
              v93 = (float)(((*((unsigned __int8 *)src + 3 * (unsigned int)(v88 + v87) + 2) << 24)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(v88 + v87)) << 8)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(v88 + v87) + 1) << 16)) >> 8)
                  * 0.00000011920929;
              v94 = (float)(((*((unsigned __int8 *)src + 3 * (unsigned int)(channels + v88 + v87) + 2) << 24)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(channels + v88 + v87)) << 8)
                           | (*((unsigned __int8 *)src + 3 * (unsigned int)(channels + v88 + v87) + 1) << 16)) >> 8)
                  * 0.00000011920929;
              out[v87++] = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v92 - v93)
                                                                                                 * 3.0)
                                                                                         - v91)
                                                                                 + v94)
                                                                         * 0.5)
                                                                 * v85)
                                                         + (float)((float)((float)(v93 + v93) + v91)
                                                                 - (float)((float)((float)(v92 * 5.0) + v94) * 0.5)))
                                                 * v85)
                                         + (float)((float)(v93 - v91) * 0.5))
                                 * v85)
                         + v92;
            }
            while ( channels > (int)v87 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v84;
          v84 += v230;
          --outlengtha;
        }
        while ( outlengtha );
      }
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      if ( channels == 1 )
      {
        if ( outlength >> 2 )
        {
          v143 = position->mValue;
          v144 = outlength >> 2;
          v145 = out;
          v146 = 2 * speed->mValue;
          v147 = 4 * speed->mValue;
          v148 = position->mValue + speed->mValue;
          do
          {
            v149 = v146 + v143;
            v145 += 4;
            v150 = (float)(int)position->mLo;
            v151 = position->mHi;
            v152 = (float)*((int *)src + v151 - 1);
            v153 = (float)*((int *)src + v151) * 4.6566129e-10;
            v154 = (float)*((int *)src + v151 + 2) * 4.6566129e-10;
            v155 = (float)*((int *)src + v151 + 1);
            position->mValue = v148;
            v156 = v154;
            v157 = (float)*((int *)src + HIDWORD(v148) - 1);
            v158 = (float)*((int *)src + HIDWORD(v148));
            v232 = v154;
            v159 = (float)*((int *)src + (unsigned int)(HIDWORD(v148) + 2)) * 4.6566129e-10;
            v160 = v149;
            v161 = (float)*((int *)src + (unsigned int)(HIDWORD(v148) + 1));
            position->mValue = v149;
            v162 = HIDWORD(v149);
            v143 = v146 + v149;
            p3b = v159;
            p0b = v157 * 4.6566129e-10;
            v249 = (float)*((int *)src + (unsigned int)v162 - 1) * 4.6566129e-10;
            fb = (float)(int)v148 * 2.3283064e-10;
            v246 = (float)v160 * 2.3283064e-10;
            v163 = (float)*((int *)src + (unsigned int)v162) * 4.6566129e-10;
            v164 = (float)*((int *)src + (unsigned int)(v162 + 2)) * 4.6566129e-10;
            v165 = v146 + v148;
            v166 = (float)*((int *)src + (unsigned int)(v162 + 1)) * 4.6566129e-10;
            v148 += v147;
            LODWORD(v162) = v165;
            position->mValue = v165;
            v165 >>= 32;
            v255 = (float)*((int *)src + (unsigned int)v165 - 1) * 4.6566129e-10;
            v167 = (float)*((int *)src + (unsigned int)v165) * 4.6566129e-10;
            v168 = (float)*((int *)src + (unsigned int)(v165 + 2)) * 4.6566129e-10;
            v169 = (float)*((int *)src + (unsigned int)(v165 + 1));
            position->mValue = v143;
            *(v145 - 4) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v153 - (float)(v155 * 4.6566129e-10))
                                                                                                * 3.0)
                                                                                        - (float)(v152 * 4.6566129e-10))
                                                                                + v156)
                                                                        * 0.5)
                                                                * (float)(v150 * 2.3283064e-10))
                                                        + (float)((float)((float)((float)(v155 * 4.6566129e-10)
                                                                                + (float)(v155 * 4.6566129e-10))
                                                                        + (float)(v152 * 4.6566129e-10))
                                                                - (float)((float)((float)(5.0 * v153) + v232) * 0.5)))
                                                * (float)(v150 * 2.3283064e-10))
                                        + (float)((float)((float)(v155 * 4.6566129e-10) - (float)(v152 * 4.6566129e-10))
                                                * 0.5))
                                * (float)(v150 * 2.3283064e-10))
                        + v153;
            *(v145 - 3) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v158 * 4.6566129e-10) - (float)(v161 * 4.6566129e-10))
                                                                                                * 3.0)
                                                                                        - p0b)
                                                                                + p3b)
                                                                        * 0.5)
                                                                * fb)
                                                        + (float)((float)((float)((float)(v161 * 4.6566129e-10)
                                                                                + (float)(v161 * 4.6566129e-10))
                                                                        + p0b)
                                                                - (float)((float)((float)(5.0
                                                                                        * (float)(v158 * 4.6566129e-10))
                                                                                + p3b)
                                                                        * 0.5)))
                                                * fb)
                                        + (float)((float)((float)(v161 * 4.6566129e-10) - p0b) * 0.5))
                                * fb)
                        + (float)(v158 * 4.6566129e-10);
            *(v145 - 2) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v163 - v166)
                                                                                                * 3.0)
                                                                                        - v249)
                                                                                + v164)
                                                                        * 0.5)
                                                                * v246)
                                                        + (float)((float)((float)(v166 + v166) + v249)
                                                                - (float)((float)((float)(5.0 * v163) + v164) * 0.5)))
                                                * v246)
                                        + (float)((float)(v166 - v249) * 0.5))
                                * v246)
                        + v163;
            *(v145 - 1) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v167 - (float)(v169 * 4.6566129e-10))
                                                                                                * 3.0)
                                                                                        - v255)
                                                                                + v168)
                                                                        * 0.5)
                                                                * (float)((float)(int)v162 * 2.3283064e-10))
                                                        + (float)((float)((float)((float)(v169 * 4.6566129e-10)
                                                                                + (float)(v169 * 4.6566129e-10))
                                                                        + v255)
                                                                - (float)((float)((float)(5.0 * v167) + v168) * 0.5)))
                                                * (float)((float)(int)v162 * 2.3283064e-10))
                                        + (float)((float)((float)(v169 * 4.6566129e-10) - v255) * 0.5))
                                * (float)((float)(int)v162 * 2.3283064e-10))
                        + v167;
            --v144;
          }
          while ( v144 );
          out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
        }
        v170 = outlength & 3;
        if ( v170 )
        {
          v171 = speed->mValue;
          v172 = position->mValue + speed->mValue;
          do
          {
            ++out;
            v173 = position->mHi;
            v174 = (float)*((int *)src + v173 - 1);
            v175 = (float)*((int *)src + v173) * 4.6566129e-10;
            v176 = (float)*((int *)src + v173 + 1) * 4.6566129e-10;
            v177 = (float)*((int *)src + v173 + 2) * 4.6566129e-10;
            *(out - 1) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v175 - v176)
                                                                                               * 3.0)
                                                                                       - (float)(v174 * 4.6566129e-10))
                                                                               + v177)
                                                                       * 0.5)
                                                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                                                       + (float)((float)((float)(v176 + v176)
                                                                       + (float)(v174 * 4.6566129e-10))
                                                               - (float)((float)((float)(v175 * 5.0) + v177) * 0.5)))
                                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                                       + (float)((float)(v176 - (float)(v174 * 4.6566129e-10)) * 0.5))
                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                       + v175;
            position->mValue = v172;
            v172 += v171;
            --v170;
          }
          while ( v170 );
        }
      }
      else if ( outlength )
      {
        v95 = speed->mValue;
        v96 = position->mValue + speed->mValue;
        do
        {
          v97 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v98 = position->mHi;
            v99 = v98 * channels;
            v100 = 4 * v98 - 4;
            v101 = 0;
            v102 = (char *)src + channels * v100;
            do
            {
              v103 = (float)*(int *)&v102[4 * v101] * 4.6566129e-10;
              v104 = (float)*((int *)src + (unsigned int)(v99 + v101)) * 4.6566129e-10;
              v105 = (float)*((int *)src + (unsigned int)(channels + v99 + v101)) * 4.6566129e-10;
              v106 = (float)*((int *)src + (unsigned int)(channels + channels + v99 + v101)) * 4.6566129e-10;
              out[v101++] = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v104 - v105)
                                                                                                  * 3.0)
                                                                                          - v103)
                                                                                  + v106)
                                                                          * 0.5)
                                                                  * v97)
                                                          + (float)((float)((float)(v105 + v105) + v103)
                                                                  - (float)((float)((float)(v104 * 5.0) + v106) * 0.5)))
                                                  * v97)
                                          + (float)((float)(v105 - v103) * 0.5))
                                  * v97)
                          + v104;
            }
            while ( channels > (int)v101 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v96;
          v96 += v95;
          --outlength;
        }
        while ( outlength );
      }
      break;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      if ( channels == 1 )
      {
        if ( outlength >> 2 )
        {
          v107 = position->mValue;
          v108 = outlength >> 2;
          v109 = out;
          v110 = 2 * speed->mValue;
          v111 = 4 * speed->mValue;
          v112 = position->mValue + speed->mValue;
          do
          {
            v113 = v110 + v107;
            v109 += 4;
            v114 = (float)(int)position->mLo;
            v115 = position->mHi;
            v116 = *((float *)src + v115);
            v117 = *((float *)src + v115 - 1);
            v118 = *((float *)src + v115 + 1);
            v119 = *((float *)src + v115 + 2);
            position->mValue = v112;
            p3a = v119;
            v120 = *((float *)src + HIDWORD(v112));
            p0a = *((float *)src + HIDWORD(v112) - 1);
            v121 = *((float *)src + (unsigned int)(HIDWORD(v112) + 1));
            v122 = *((float *)src + (unsigned int)(HIDWORD(v112) + 2));
            position->mValue = v113;
            v123 = (float)(int)v113;
            v124 = HIDWORD(v113);
            v125 = HIDWORD(v113);
            fa = v122;
            v126 = *((float *)src + HIDWORD(v113));
            v107 = v110 + v113;
            v127 = *((float *)src + v125 - 1);
            v128 = (unsigned int)(v124 + 1);
            v129 = (float)(int)v112 * 2.3283064e-10;
            v130 = *((float *)src + (unsigned int)(v124 + 2));
            v131 = v110 + v112;
            v132 = *((float *)src + v128);
            v112 += v111;
            LODWORD(v128) = v131;
            position->mValue = v131;
            v131 >>= 32;
            v133 = *((float *)src + (unsigned int)v131);
            v252 = *((float *)src + (unsigned int)v131 - 1);
            v254 = *((float *)src + (unsigned int)(v131 + 2));
            v134 = *((float *)src + (unsigned int)(v131 + 1));
            position->mValue = v107;
            *(v109 - 4) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v116 - v118)
                                                                                                * 3.0)
                                                                                        - v117)
                                                                                + p3a)
                                                                        * 0.5)
                                                                * (float)(v114 * 2.3283064e-10))
                                                        + (float)((float)((float)(v118 + v118) + v117)
                                                                - (float)((float)((float)(5.0 * v116) + p3a) * 0.5)))
                                                * (float)(v114 * 2.3283064e-10))
                                        + (float)((float)(v118 - v117) * 0.5))
                                * (float)(v114 * 2.3283064e-10))
                        + v116;
            *(v109 - 3) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v120 - v121)
                                                                                                * 3.0)
                                                                                        - p0a)
                                                                                + fa)
                                                                        * 0.5)
                                                                * v129)
                                                        + (float)((float)((float)(v121 + v121) + p0a)
                                                                - (float)((float)((float)(5.0 * v120) + fa) * 0.5)))
                                                * v129)
                                        + (float)((float)(v121 - p0a) * 0.5))
                                * v129)
                        + v120;
            *(v109 - 2) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v126 - v132)
                                                                                                * 3.0)
                                                                                        - v127)
                                                                                + v130)
                                                                        * 0.5)
                                                                * (float)(v123 * 2.3283064e-10))
                                                        + (float)((float)((float)(v132 + v132) + v127)
                                                                - (float)((float)((float)(5.0 * v126) + v130) * 0.5)))
                                                * (float)(v123 * 2.3283064e-10))
                                        + (float)((float)(v132 - v127) * 0.5))
                                * (float)(v123 * 2.3283064e-10))
                        + v126;
            *(v109 - 1) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v133 - v134)
                                                                                                * 3.0)
                                                                                        - v252)
                                                                                + v254)
                                                                        * 0.5)
                                                                * (float)((float)(int)v128 * 2.3283064e-10))
                                                        + (float)((float)((float)(v134 + v134) + v252)
                                                                - (float)((float)((float)(5.0 * v133) + v254) * 0.5)))
                                                * (float)((float)(int)v128 * 2.3283064e-10))
                                        + (float)((float)(v134 - v252) * 0.5))
                                * (float)((float)(int)v128 * 2.3283064e-10))
                        + v133;
            --v108;
          }
          while ( v108 );
          out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
        }
        v135 = outlength & 3;
        if ( v135 )
        {
          v136 = speed->mValue;
          v137 = position->mValue + speed->mValue;
          do
          {
            ++out;
            v138 = position->mHi;
            v139 = *((float *)src + v138 - 1);
            v140 = v138 + 1;
            v141 = *((float *)src + v138);
            v142 = *((float *)src + v138 + 2);
            *(out - 1) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v141 - *((float *)src + v140))
                                                                                               * 3.0)
                                                                                       - v139)
                                                                               + v142)
                                                                       * 0.5)
                                                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                                                       + (float)((float)((float)(*((float *)src + v140)
                                                                               + *((float *)src + v140))
                                                                       + v139)
                                                               - (float)((float)((float)(v141 * 5.0) + v142) * 0.5)))
                                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                                       + (float)((float)(*((float *)src + v140) - v139) * 0.5))
                               * (float)((float)(int)position->mLo * 2.3283064e-10))
                       + v141;
            position->mValue = v137;
            v137 += v136;
            --v135;
          }
          while ( v135 );
        }
      }
      else if ( outlength )
      {
        v51 = speed->mValue;
        v52 = position->mValue + speed->mValue;
        do
        {
          v53 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v54 = position->mHi;
            v55 = v54 * channels;
            v56 = 4 * v54 - 4;
            v57 = 0;
            v58 = (char *)src + channels * v56;
            do
            {
              v59 = *((float *)src + (unsigned int)(v55 + v57));
              v60 = *((float *)src + (unsigned int)(channels + v55 + v57));
              v61 = *((float *)src + (unsigned int)(channels + channels + v55 + v57));
              out[v57] = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v59 - v60) * 3.0)
                                                                                       - *(float *)&v58[4 * v57])
                                                                               + v61)
                                                                       * 0.5)
                                                               * v53)
                                                       + (float)((float)((float)(v60 + v60) + *(float *)&v58[4 * v57])
                                                               - (float)((float)((float)(v59 * 5.0) + v61) * 0.5)))
                                               * v53)
                                       + (float)((float)(v60 - *(float *)&v58[4 * v57]) * 0.5))
                               * v53)
                       + v59;
              ++v57;
            }
            while ( channels > (int)v57 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v52;
          v52 += v51;
          --outlength;
        }
        while ( outlength );
      }
      break;
    default:
      return;
  }
}


