// Address: 0x21c6c00 | Name: _ZN4FMOD7SystemI17updateRecordCacheEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::updateRecordCache(FMOD::SystemI *const this)
{
  FMOD::Output *mOutput; // rax
  unsigned int mRecordListLastCheckedTime; // edx
  int mNumRecordConnected; // esi
  FMOD_RESULT_0 result; // eax
  int mNumRecordDrivers; // ecx
  FMOD::SystemI::RecordCache *mRecordCache; // rdx
  FMOD::SystemI::RecordCache *v8; // rax
  __int64 v9; // rcx
  FMOD::Output *v10; // rdi
  void (__fastcall *record_getdriverinfo)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  int v12; // r14d
  __int64 v13; // rax
  FMOD_SPEAKERMODE_0 v14; // edx
  int v15; // eax
  FMOD::SystemI::RecordCache *v16; // r15
  __int64 v17; // r12
  FMOD::SystemI::RecordCache *v18; // rbx
  __int64 v19; // rax
  int v20; // edx
  char *v21; // rax
  int v22; // eax
  FMOD::SystemI::RecordCache *v23; // rax
  __int64 v24; // rax
  unsigned int v25; // edx
  _DWORD *v26; // rdi
  __int64 v27; // rcx
  _DWORD *v28; // rdi
  int v29; // [rsp+1Ch] [rbp-19Ch]
  int connected; // [rsp+4Ch] [rbp-16Ch] BYREF
  FMOD_BOOL enumerationChanged; // [rsp+50h] [rbp-168h] BYREF
  int rate; // [rsp+54h] [rbp-164h] BYREF
  FMOD_SPEAKERMODE_0 mode; // [rsp+58h] [rbp-160h] BYREF
  int channels; // [rsp+5Ch] [rbp-15Ch] BYREF
  FMOD_GUID guid; // [rsp+60h] [rbp-158h] BYREF
  FMOD_GUID nullGUID; // [rsp+70h] [rbp-148h] BYREF
  unsigned int name[78]; // [rsp+80h] [rbp-138h] BYREF

  mOutput = this->mOutput;
  connected = 0;
  enumerationChanged = 0;
  if ( mOutput->mDescription.record_getnumdrivers )
  {
    name[0] = 0;
    FMOD_OS_Time_GetMs(name);
    mRecordListLastCheckedTime = this->mRecordListLastCheckedTime;
    mNumRecordConnected = this->mNumRecordConnected;
    connected = mNumRecordConnected;
    if ( name[0] - mRecordListLastCheckedTime <= 0x3E7 && mRecordListLastCheckedTime )
      goto LABEL_32;
    this->mRecordListLastCheckedTime = name[0];
    result = this->mOutput->mDescription.record_getnumdrivers(
               &this->mOutput->FMOD_OUTPUT_STATE,
               &connected,
               &enumerationChanged);
    if ( result )
      return result;
    mNumRecordConnected = connected;
    if ( !enumerationChanged )
    {
LABEL_32:
      if ( this->mNumRecordConnected == mNumRecordConnected )
        return FMOD_RESULT::FMOD_OK_0;
    }
  }
  else
  {
    mNumRecordConnected = 0;
    if ( !this->mNumRecordConnected )
      return FMOD_RESULT::FMOD_OK_0;
  }
  mNumRecordDrivers = this->mNumRecordDrivers;
  if ( mNumRecordDrivers > 0 )
  {
    mRecordCache = this->mRecordCache;
    v8 = mRecordCache + 1;
    v9 = (__int64)&mRecordCache[(unsigned int)(mNumRecordDrivers - 1) + 1];
    while ( 1 )
    {
      mRecordCache->state &= ~1u;
      mRecordCache = v8;
      if ( v8 == (FMOD::SystemI::RecordCache *)v9 )
        break;
      ++v8;
    }
  }
  this->mNumRecordConnected = 0;
  if ( mNumRecordConnected <= 0 )
  {
LABEL_56:
    this->mRecordListChanged = 1;
    return FMOD_RESULT::FMOD_OK_0;
  }
  *(_QWORD *)&guid.Data1 = 0;
  *(_QWORD *)guid.Data4 = 0;
  rate = 0;
  memset(name, 0, 0x100u);
  v10 = this->mOutput;
  mode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
  channels = 0;
  record_getdriverinfo = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v10->mDescription.record_getdriverinfo;
  if ( record_getdriverinfo )
  {
    v12 = 0;
    do
    {
      record_getdriverinfo(&v10->FMOD_OUTPUT_STATE, (unsigned int)v12, name, 256, &guid, &rate, &mode, &channels);
      *(_QWORD *)&nullGUID.Data1 = 0;
      *(_QWORD *)nullGUID.Data4 = 0;
      if ( !memcmp(&guid, &nullGUID, 0x10u) )
        return FMOD_RESULT::FMOD_ERR_INTERNAL_0;
      if ( channels )
      {
        v13 = (unsigned int)(channels - 1);
        v14 = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
        if ( (unsigned int)v13 <= 0xB )
          v14 = dword_595D00[v13];
        mode = v14;
        goto LABEL_17;
      }
      if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
      {
        mode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0;
        channels = 1;
        goto LABEL_17;
      }
      if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
      {
        v20 = 5;
        goto LABEL_42;
      }
      if ( mode <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
      {
        if ( mode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
        {
          v20 = 4;
          if ( mode > FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
            goto LABEL_42;
          LOBYTE(v20) = 1;
          if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0 )
            goto LABEL_42;
LABEL_52:
          v20 = 0;
          goto LABEL_42;
        }
      }
      else
      {
        v20 = 8;
        if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
          goto LABEL_42;
        LOBYTE(v20) = 6;
        if ( mode < FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
          goto LABEL_42;
        LOBYTE(v20) = 12;
        if ( mode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
          goto LABEL_42;
        if ( mode != 1000 )
          goto LABEL_52;
      }
      v20 = 2;
LABEL_42:
      channels = v20;
LABEL_17:
      if ( !rate )
        rate = 48000;
      v15 = this->mNumRecordDrivers;
      v29 = v15;
      if ( v15 <= 0 )
        goto LABEL_47;
      v16 = this->mRecordCache;
      v17 = (__int64)&v16[(unsigned int)(v15 - 1) + 1];
      while ( 1 )
      {
        v18 = v16;
        if ( !memcmp(&v16->guid, &guid, 0x10u) )
          break;
        if ( ++v16 == (FMOD::SystemI::RecordCache *)v17 )
          goto LABEL_47;
      }
      if ( !v16 )
      {
LABEL_47:
        if ( this->mNumRecordCapacity != v29 )
        {
LABEL_48:
          this->mNumRecordDrivers = v29 + 1;
          v18 = &this->mRecordCache[v29];
          goto LABEL_24;
        }
        FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_RECORD_INFO);
        v22 = this->mNumRecordCapacity + 8;
        this->mNumRecordCapacity = v22;
        v23 = (FMOD::SystemI::RecordCache *)FMOD::MemPool::realloc(
                                              off_286F358->gSystemMemPool,
                                              this->mRecordCache,
                                              56 * v22,
                                              "../../../core_api/src/fmod_systemi.cpp",
                                              4973,
                                              0);
        this->mRecordCache = v23;
        if ( !v23 )
        {
          FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_RECORD_INFO);
          return FMOD_RESULT::FMOD_ERR_MEMORY_0;
        }
        v24 = (__int64)&v23[this->mNumRecordCapacity - 8];
        v25 = 448;
        v26 = (_DWORD *)v24;
        if ( (v24 & 1) != 0 )
        {
          *(_BYTE *)v24 = 0;
          v26 = (_DWORD *)(v24 + 1);
          LOBYTE(v25) = -65;
        }
        if ( ((unsigned __int8)v26 & 2) != 0 )
        {
          v26 = (_DWORD *)((char *)v26 + 2);
          v25 -= 2;
          *((_WORD *)v26 - 1) = 0;
        }
        if ( ((unsigned __int8)v26 & 4) != 0 )
        {
          *v26 = 0;
          v25 -= 4;
          ++v26;
        }
        v27 = v25 >> 3;
        memset(v26, 0, 8 * v27);
        v28 = &v26[2 * v27];
        if ( (v25 & 4) != 0 )
        {
          *v28++ = 0;
          if ( (v25 & 2) != 0 )
            goto LABEL_70;
LABEL_66:
          if ( (v25 & 1) != 0 )
LABEL_69:
            *(_BYTE *)v28 = 0;
        }
        else
        {
          if ( (v25 & 2) == 0 )
            goto LABEL_66;
LABEL_70:
          v28 = (_DWORD *)((char *)v28 + 2);
          *((_WORD *)v28 - 1) = 0;
          if ( (v25 & 1) != 0 )
            goto LABEL_69;
        }
        FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_RECORD_INFO);
        v29 = this->mNumRecordDrivers;
        goto LABEL_48;
      }
LABEL_24:
      if ( v18->name )
      {
        if ( FMOD_strcmp(v18->name, (const char *)name) )
        {
          FMOD::MemPool::free(off_286F358->gSystemMemPool, v18->name, "../../../core_api/src/fmod_systemi.cpp", 4988);
          v18->name = 0;
        }
        else if ( v18->name )
        {
          goto LABEL_27;
        }
      }
      v21 = FMOD_strdup((const char *)name);
      v18->name = v21;
      if ( !v21 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
LABEL_27:
      *(_QWORD *)&v18->guid.Data1 = *(_QWORD *)&guid.Data1;
      v19 = *(_QWORD *)guid.Data4;
      v18->index = v12;
      *(_QWORD *)v18->guid.Data4 = v19;
      v18->systemRate = rate;
      v18->speakerMode = mode;
      v18->speakerModeChannels = channels;
      LODWORD(v19) = -(v12++ == 0);
      v18->state = (v19 & 2) + 1;
      ++this->mNumRecordConnected;
      if ( v12 >= connected )
        goto LABEL_56;
      *(_QWORD *)&guid.Data1 = 0;
      *(_QWORD *)guid.Data4 = 0;
      rate = 0;
      mode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
      memset(name, 0, 0x100u);
      v10 = this->mOutput;
      channels = 0;
      record_getdriverinfo = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v10->mDescription.record_getdriverinfo;
    }
    while ( record_getdriverinfo );
  }
  return FMOD_RESULT::FMOD_ERR_UNIMPLEMENTED_0;
}


// Address: 0x21c78a0 | Name: _ZN4FMOD7SystemI11getInstanceEjPPS0_
FMOD_RESULT_0 __fastcall FMOD::SystemI::getInstance(unsigned int id, FMOD::SystemI **sys)
{
  FMOD::SystemI *v3; // rax

  if ( sys && (*sys = 0, id <= 7) && (v3 = off_286F358->gSystem[id], (*sys = v3) != 0) )
    return FMOD_RESULT::FMOD_OK_0;
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21c78e0 | Name: _ZN4FMOD7SystemI8validateEPNS_6SystemEPPS0_PNS_15SystemLockScopeE
FMOD_RESULT_0 __fastcall FMOD::SystemI::validate(
        FMOD::System *system,
        FMOD::SystemI **systemi,
        FMOD::SystemLockScope *lockScope)
{
  __int64 v3; // rax
  FMOD_RESULT_0 result; // eax

  *systemi = 0;
  v3 = 0;
  while ( system != (FMOD::System *)off_286F358->gSystem[v3] )
  {
    if ( ++v3 == 8 )
      return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  }
  *systemi = (FMOD::SystemI *)system;
  if ( !system )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( !lockScope )
    return FMOD_RESULT::FMOD_OK_0;
  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( !lockScope->mSystem )
  {
    result = FMOD::SystemI::enterMainUpdateLock((FMOD::SystemI *const)system);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      lockScope->mSystem = (FMOD::SystemI *)system;
  }
  return result;
}


// Address: 0x21c7960 | Name: _ZN4FMOD7SystemI19createClientProfileEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::createClientProfile(FMOD::SystemI *const this)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
  if ( !*(unsigned __int64 *)((char *)&stru_125D0.r_offset + (_QWORD)this) )
  {
    result = FMOD::Profile::createProfile((FMOD::Profile **)((char *)&stru_125D0 + (_QWORD)this), 0, 0x2430u);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      return FMOD::ProfileRemoteFile::create(*(FMOD::Profile **)((char *)&stru_125D0.r_offset + (_QWORD)this));
  }
  return result;
}


// Address: 0x21c79a0 | Name: _ZN4FMOD7SystemI12setUpPluginsEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::setUpPlugins(FMOD::SystemI *const this)
{
  FMOD::PluginFactory *v2; // rax
  FMOD::PluginFactory *v3; // rbp
  FMOD_RESULT_0 v4; // ebp
  FMOD::PluginFactory *mPluginFactory; // rdi
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *Description; // rax
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *v8; // rax
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *v9; // rax
  FMOD::FMOD_OUTPUT_DESCRIPTION_EX *v10; // rax
  FMOD::FMOD_CODEC_DESCRIPTION_EX *v11; // rax
  FMOD::FMOD_CODEC_DESCRIPTION_EX *v12; // rax
  FMOD::FMOD_CODEC_DESCRIPTION_EX *v13; // rax
  FMOD::FMOD_CODEC_DESCRIPTION_EX *v14; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v15; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v16; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v17; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v18; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v19; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v20; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v21; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v22; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v23; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v24; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v25; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v26; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v27; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v28; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v29; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v30; // rax
  FMOD_DSP_DESCRIPTION *v31; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v32; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v33; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v34; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v35; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v36; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v37; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v38; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v39; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v40; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v41; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v42; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v43; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v44; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v45; // rax
  FMOD::FMOD_DSP_DESCRIPTION_EX *v46; // rax
  FMOD_RESULT_0 v47; // eax

  v2 = (FMOD::PluginFactory *)FMOD::MemPool::alloc(
                                off_286F358->gSystemMemPool,
                                1248,
                                "../../../core_api/src/fmod_systemi.cpp",
                                325,
                                0,
                                0);
  v3 = v2;
  if ( v2 )
  {
    FMOD::PluginFactory::PluginFactory(v2);
    this->mPluginFactory = v3;
    v4 = FMOD::PluginFactory::setSystem(v3, this);
    if ( v4 == FMOD_RESULT::FMOD_OK_0 )
    {
      FMOD::PluginFactory::setPluginPath(this->mPluginFactory, (const char *)&stru_11370 + (_QWORD)this);
      v4 = FMOD_OS_Output_Register(this->mPluginFactory);
      if ( v4 == FMOD_RESULT::FMOD_OK_0 )
      {
        Description = FMOD::OutputWavWriter::getDescriptionEx();
        v4 = FMOD::PluginFactory::registerOutput(this->mPluginFactory, Description, 0, 0);
        if ( v4 == FMOD_RESULT::FMOD_OK_0 )
        {
          v8 = FMOD::OutputWavWriter_NRT::getDescriptionEx();
          v4 = FMOD::PluginFactory::registerOutput(this->mPluginFactory, v8, 0, 0);
          if ( v4 == FMOD_RESULT::FMOD_OK_0 )
          {
            v9 = FMOD::OutputNoSound::getDescriptionEx();
            v4 = FMOD::PluginFactory::registerOutput(this->mPluginFactory, v9, 0, 0);
            if ( v4 == FMOD_RESULT::FMOD_OK_0 )
            {
              v10 = FMOD::OutputNoSound_NRT::getDescriptionEx();
              v4 = FMOD::PluginFactory::registerOutput(this->mPluginFactory, v10, 0, 0);
              if ( v4 == FMOD_RESULT::FMOD_OK_0 )
              {
                v11 = FMOD::CodecWav::getDescriptionEx();
                v4 = FMOD::PluginFactory::registerCodec(this->mPluginFactory, v11, &this->mWAVPluginHandle, 0x258u, 0);
                if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                {
                  v12 = FMOD::CodecOggVorbis::getDescriptionEx();
                  v4 = FMOD::PluginFactory::registerCodec(this->mPluginFactory, v12, 0, 0x320u, 0);
                  if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                  {
                    v13 = FMOD::CodecMPEG::getDescriptionEx();
                    v4 = FMOD::PluginFactory::registerCodec(
                           this->mPluginFactory,
                           v13,
                           (unsigned int *)((char *)&stru_11478 + (_QWORD)this),
                           0x960u,
                           0);
                    if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                    {
                      v14 = FMOD::CodecUser::getDescriptionEx();
                      v4 = FMOD::PluginFactory::registerCodec(this->mPluginFactory, v14, 0, 0xA28u, 0);
                      if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                      {
                        v15 = FMOD::DSPOscillator::getDescriptionEx();
                        v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v15, 0, 0, 0);
                        if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                        {
                          v16 = FMOD::DSPThreeEQ::getDescriptionEx();
                          v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v16, 0, 0, 0);
                          if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                          {
                            v17 = FMOD::DSPLowPass::getDescriptionEx();
                            v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v17, 0, 0, 0);
                            if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                            {
                              v18 = FMOD::DSPLowPass2::getDescriptionEx();
                              v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v18, 0, 0, 0);
                              if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                              {
                                v19 = FMOD::DSPLowPassSimple::getDescriptionEx();
                                v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v19, 0, 0, 0);
                                if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                {
                                  v20 = FMOD::DSPHighPass::getDescriptionEx();
                                  v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v20, 0, 0, 0);
                                  if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                  {
                                    v21 = FMOD::DSPHighPassSimple::getDescriptionEx();
                                    v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v21, 0, 0, 0);
                                    if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                    {
                                      v22 = FMOD::DSPEcho::getDescriptionEx();
                                      v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v22, 0, 0, 0);
                                      if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                      {
                                        v23 = FMOD::DSPDelay::getDescriptionEx();
                                        v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v23, 0, 0, 0);
                                        if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                        {
                                          v24 = FMOD::DSPFlange::getDescriptionEx();
                                          v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v24, 0, 0, 0);
                                          if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                          {
                                            v25 = FMOD::DSPTremolo::getDescriptionEx();
                                            v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v25, 0, 0, 0);
                                            if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                            {
                                              v26 = FMOD::DSPTransceiver::getDescriptionEx();
                                              v4 = FMOD::PluginFactory::registerDSP(this->mPluginFactory, v26, 0, 0, 0);
                                              if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                              {
                                                v27 = FMOD::DSPDistortion::getDescriptionEx();
                                                v4 = FMOD::PluginFactory::registerDSP(
                                                       this->mPluginFactory,
                                                       v27,
                                                       0,
                                                       0,
                                                       0);
                                                if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                {
                                                  v28 = FMOD::DSPNormalize::getDescriptionEx();
                                                  v4 = FMOD::PluginFactory::registerDSP(
                                                         this->mPluginFactory,
                                                         v28,
                                                         0,
                                                         0,
                                                         0);
                                                  if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                  {
                                                    v29 = FMOD::DSPLimiter::getDescriptionEx();
                                                    v4 = FMOD::PluginFactory::registerDSP(
                                                           this->mPluginFactory,
                                                           v29,
                                                           0,
                                                           0,
                                                           0);
                                                    if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                    {
                                                      v30 = FMOD::DSPParamEq::getDescriptionEx();
                                                      v4 = FMOD::PluginFactory::registerDSP(
                                                             this->mPluginFactory,
                                                             v30,
                                                             0,
                                                             0,
                                                             0);
                                                      if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                      {
                                                        v31 = FMOD_MultibandEQ_GetDescription();
                                                        v4 = (unsigned int)FMOD::PluginFactory::registerDSP(
                                                                             this->mPluginFactory,
                                                                             v31,
                                                                             0,
                                                                             0,
                                                                             FMOD_DSP_TYPE_MULTIBAND_EQ);
                                                        if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                        {
                                                          v32 = FMOD::DSPPitchShift::getDescriptionEx();
                                                          v4 = FMOD::PluginFactory::registerDSP(
                                                                 this->mPluginFactory,
                                                                 v32,
                                                                 0,
                                                                 0,
                                                                 0);
                                                          if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                          {
                                                            v33 = FMOD::DSPChorus::getDescriptionEx();
                                                            v4 = FMOD::PluginFactory::registerDSP(
                                                                   this->mPluginFactory,
                                                                   v33,
                                                                   0,
                                                                   0,
                                                                   0);
                                                            if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                            {
                                                              v34 = FMOD::DSPITEcho::getDescriptionEx();
                                                              v4 = FMOD::PluginFactory::registerDSP(
                                                                     this->mPluginFactory,
                                                                     v34,
                                                                     0,
                                                                     0,
                                                                     0);
                                                              if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                              {
                                                                v35 = FMOD::DSPCompressor::getDescriptionEx();
                                                                v4 = FMOD::PluginFactory::registerDSP(
                                                                       this->mPluginFactory,
                                                                       v35,
                                                                       0,
                                                                       0,
                                                                       0);
                                                                if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                {
                                                                  v36 = FMOD::DSPSfxReverb::getDescriptionEx();
                                                                  v4 = FMOD::PluginFactory::registerDSP(
                                                                         this->mPluginFactory,
                                                                         v36,
                                                                         0,
                                                                         0,
                                                                         0);
                                                                  if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                  {
                                                                    v37 = FMOD::ConvolutionReverb::getDescriptionEx();
                                                                    v4 = FMOD::PluginFactory::registerDSP(
                                                                           this->mPluginFactory,
                                                                           v37,
                                                                           0,
                                                                           0,
                                                                           0);
                                                                    if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                    {
                                                                      v38 = FMOD::DSPSend::getDescriptionEx();
                                                                      v4 = FMOD::PluginFactory::registerDSP(
                                                                             this->mPluginFactory,
                                                                             v38,
                                                                             0,
                                                                             0,
                                                                             0);
                                                                      if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                      {
                                                                        v39 = FMOD::DSPReturn::getDescriptionEx();
                                                                        v4 = FMOD::PluginFactory::registerDSP(
                                                                               this->mPluginFactory,
                                                                               v39,
                                                                               0,
                                                                               0,
                                                                               0);
                                                                        if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                        {
                                                                          v40 = FMOD::DSPFader::getDescriptionEx();
                                                                          v4 = FMOD::PluginFactory::registerDSP(
                                                                                 this->mPluginFactory,
                                                                                 v40,
                                                                                 0,
                                                                                 0,
                                                                                 0);
                                                                          if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                          {
                                                                            v41 = FMOD::DSPPanner::getDescriptionEx();
                                                                            v4 = FMOD::PluginFactory::registerDSP(
                                                                                   this->mPluginFactory,
                                                                                   v41,
                                                                                   0,
                                                                                   0,
                                                                                   0);
                                                                            if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                            {
                                                                              v42 = FMOD::DSPFFT::getDescriptionEx();
                                                                              v4 = FMOD::PluginFactory::registerDSP(
                                                                                     this->mPluginFactory,
                                                                                     v42,
                                                                                     0,
                                                                                     0,
                                                                                     0);
                                                                              if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                              {
                                                                                v43 = FMOD::DSPLoudnessMeter::getDescriptionEx();
                                                                                v4 = FMOD::PluginFactory::registerDSP(
                                                                                       this->mPluginFactory,
                                                                                       v43,
                                                                                       0,
                                                                                       0,
                                                                                       0);
                                                                                if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                                {
                                                                                  v44 = FMOD::DSPEnvelopeFollower::getDescriptionEx();
                                                                                  v4 = FMOD::PluginFactory::registerDSP(
                                                                                         this->mPluginFactory,
                                                                                         v44,
                                                                                         0,
                                                                                         0,
                                                                                         0);
                                                                                  if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                                  {
                                                                                    v45 = FMOD::DSPChannelMix::getDescriptionEx();
                                                                                    v4 = FMOD::PluginFactory::registerDSP(
                                                                                           this->mPluginFactory,
                                                                                           v45,
                                                                                           0,
                                                                                           0,
                                                                                           0);
                                                                                    if ( v4 == FMOD_RESULT::FMOD_OK_0 )
                                                                                    {
                                                                                      v46 = FMOD::DSPObjectPan::getDescriptionEx();
                                                                                      v47 = FMOD::PluginFactory::registerDSP(
                                                                                              this->mPluginFactory,
                                                                                              v46,
                                                                                              0,
                                                                                              0,
                                                                                              0);
                                                                                      if ( v47 == FMOD_RESULT::FMOD_OK_0 )
                                                                                      {
                                                                                        this->mPluginsLoaded = 1;
                                                                                        return v4;
                                                                                      }
                                                                                      v4 = v47;
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    mPluginFactory = this->mPluginFactory;
    if ( mPluginFactory )
    {
      FMOD::PluginFactory::release(mPluginFactory, 0);
      this->mPluginFactory = 0;
    }
    return v4;
  }
  this->mPluginFactory = 0;
  return FMOD_RESULT::FMOD_ERR_MEMORY_0;
}


// Address: 0x21c8050 | Name: _ZN4FMOD7SystemI18freeObject3DHandleEPv
FMOD_RESULT_0 __fastcall FMOD::SystemI::freeObject3DHandle(FMOD::SystemI *const this, void *handle)
{
  *((_BYTE *)handle + 36) = 1;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c8060 | Name: _ZN4FMOD7SystemI21cleanUpObject3DHandleEPv
FMOD_RESULT_0 __fastcall FMOD::SystemI::cleanUpObject3DHandle(FMOD::SystemI *const this, void *handle)
{
  char v2; // r8
  int v3; // edx
  int v4; // eax
  FMOD_RESULT_0 result; // eax

  if ( this )
  {
    FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_OBJECT3D_INFO);
    v2 = 1;
  }
  else
  {
    v2 = 0;
  }
  v3 = *((_DWORD *)handle + 8);
  v4 = this->mObject3DHead.mSize - 1;
  *(_QWORD *)(*(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) + 8LL * v3) = *(_QWORD *)(*(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) + 8LL * v4);
  *(_DWORD *)(*(_QWORD *)(*(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) + 8LL * v3) + 32LL) = v3;
  if ( v4 >= 0 )
    this->mObject3DHead.mSize = v4;
  if ( v2 )
    FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_OBJECT3D_INFO);
  result = FMOD::ExpandingPool<FMOD::DSPConnectionI>::free(
             &this->mDSPConnectionPool,
             *((FMOD::DSPConnectionI **)handle + 2),
             1);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, handle, "../../../core_api/src/fmod_systemi.cpp", 1046);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21c8130 | Name: _ZN4FMOD7SystemI18commitObject3DInfoEPvPNS_16Object3DMetaDataE
FMOD_RESULT_0 __fastcall FMOD::SystemI::commitObject3DInfo(
        FMOD::SystemI *const this,
        void *handle,
        FMOD::Object3DMetaData *info)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c8140 | Name: _ZN4FMOD7SystemI20callInternalCallbackEjPvS1_
FMOD_RESULT_0 __fastcall FMOD::SystemI::callInternalCallback(
        FMOD::SystemI *const this,
        FMOD_SYSTEM_CALLBACK_TYPE type,
        void *commanddata1,
        void *commanddata2)
{
  FMOD_RESULT_0 (*v4)(FMOD_SYSTEM *, FMOD_SYSTEM_CALLBACK_TYPE, void *, void *, void *); // rax

  v4 = this->mInternalCallback[0];
  if ( v4 )
    return v4(
             (FMOD_SYSTEM *)this,
             type,
             commanddata1,
             commanddata2,
             *(void **)((char *)&stru_11760.r_offset + (_QWORD)this));
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c8160 | Name: _ZN4FMOD7SystemIC2Ev
void __fastcall FMOD::SystemI::SystemI(FMOD::SystemI *const this)
{
  FMOD::Listener *mListener; // rbp
  int *p_mNumListeners; // r12
  FMOD::Listener *v4; // rdi
  FMOD::SpeakerPair *mReflexPair; // rcx
  FMOD::SystemI *v6; // rsi
  FMOD::SpeakerPair *v7; // rax
  FMOD::SystemI *v8; // rdx
  signed __int64 v9; // rdx
  Elf64_Rela *v10; // rax
  char *v11; // rdi
  unsigned int v12; // edx
  __int64 v13; // rcx
  char *v14; // rdi
  FMOD_ADVANCEDSETTINGS *p_mAdvancedSettings; // rdi
  unsigned int v16; // edx
  __int64 v17; // rcx
  int *v18; // rdi

  this->_vptr_SystemI = (int (**)(...))off_29B0E70;
  mListener = this->mListener;
  p_mNumListeners = &this->mNumListeners;
  FMOD::SoundI::SoundI(&this->mSoundListHead);
  FMOD::ChannelI::ChannelI(&this->mChannelUsedListHead);
  FMOD::ChannelI::ChannelI(&this->mChannelFreeListHead);
  this->mChannelSortedListHead.mNodeData = 0;
  this->mChannelSortedListHead.mNodePriority = -1;
  this->mChannelSortedListHead.mNodePrev = &this->mChannelSortedListHead;
  this->mChannelSortedListHead.mNodeNext = &this->mChannelSortedListHead;
  FMOD::TimeStamp::TimeStamp(&this->mDSPTimeStamp);
  this->mDSPConnectionPool.mFreeListHead.mNodeData = 0;
  this->mDSPConnectionPool.mUsedListHead.mNodeData = 0;
  this->mDSPMemoryBlocks.mNodeData = 0;
  this->mDSPConnectionPool.mFreeListHead.mNodePrev = &this->mDSPConnectionPool.mFreeListHead;
  this->mDSPConnectionPool.mFreeListHead.mNodeNext = &this->mDSPConnectionPool.mFreeListHead;
  *(unsigned __int64 *)((char *)&stru_10770.r_offset + (_QWORD)this) = 0;
  this->mDSPFadePointHead.mNodeData = 0;
  this->mDSPConnectionPool.mUsedListHead.mNodePrev = &this->mDSPConnectionPool.mUsedListHead;
  this->mDSPConnectionPool.mUsedListHead.mNodeNext = &this->mDSPConnectionPool.mUsedListHead;
  this->mDSPFadePointHead.mNodePriority = -1;
  this->mDSPFadePointMemoryHead.mNodeData = 0;
  this->mDSPMemoryBlocks.mNodePrev = (FMOD::LinkedListNode *)((char *)&stru_10758 + (_QWORD)this);
  *(unsigned __int64 *)((char *)&stru_10758.r_offset + (_QWORD)this) = (unsigned __int64)&stru_10758 + (_QWORD)this;
  *(unsigned __int64 *)((char *)&stru_107E8.r_offset + (_QWORD)this) = (unsigned __int64)&this->mDSPFadePointHead;
  this->mDSPFadePointHead.mNodeNext = &this->mDSPFadePointHead;
  this->mDSPFadePointMemoryHead.mNodePrev = (FMOD::LinkedListNode *)((char *)&stru_10800 + (_QWORD)this);
  *(unsigned __int64 *)((char *)&stru_10800.r_offset + (_QWORD)this) = (unsigned __int64)&stru_10800 + (_QWORD)this;
  FMOD::MemPool::MemPool((FMOD::MemPool *const)((char *)&stru_10818 + (_QWORD)this));
  FMOD::MemPool::MemPool(&this->mDSPLevelsPool);
  *(unsigned __int64 *)((char *)&stru_10F38.r_offset + (_QWORD)this) = 0;
  *(unsigned __int64 *)((char *)&stru_10FB0.r_offset + (_QWORD)this) = 0;
  *(unsigned __int64 *)((char *)&stru_10FC8.r_offset + (_QWORD)this) = 0;
  this->mDSPMeteringNodes.mNodePrev = &this->mDSPMeteringNodes;
  this->mDSPMeteringNodes.mNodeNext = &this->mDSPMeteringNodes;
  this->mDSPReleaseHead.mNodePrev = &this->mDSPReleaseHead;
  this->mDSPReleaseHead.mNodeNext = &this->mDSPReleaseHead;
  this->mDSPSystemUpdateHead.mNodePrev = &this->mDSPSystemUpdateHead;
  this->mDSPSystemUpdateHead.mNodeNext = &this->mDSPSystemUpdateHead;
  do
  {
    v4 = mListener++;
    FMOD::Listener::Listener(v4);
  }
  while ( mListener != (FMOD::Listener *)p_mNumListeners );
  FMOD::TimeStamp::TimeStamp(&this->mUpdateTimeStamp);
  mReflexPair = this->mChannelLayoutList[0].mReflexPair;
  *(unsigned __int64 *)((char *)&stru_11628.r_offset + (_QWORD)this) = 0;
  *(unsigned __int64 *)((char *)&stru_11640.r_offset + (_QWORD)this) = 0;
  this->mChannelGroupListHead.mNodePrev = &this->mChannelGroupListHead;
  this->mChannelGroupListHead.mNodeNext = &this->mChannelGroupListHead;
  this->mSoundGroupUsedHead.mNodeData = 0;
  this->mSoundGroupFreeHead.mNodeData = 0;
  v6 = (FMOD::SystemI *)this->mChannelLayoutList[0].mReflexPair;
  this->mChannelGroupUpdateListHead.mNodePrev = &this->mChannelGroupUpdateListHead;
  this->mChannelGroupUpdateListHead.mNodeNext = &this->mChannelGroupUpdateListHead;
  *(unsigned __int64 *)((char *)&stru_116A0.r_offset + (_QWORD)this) = 0;
  *(_DWORD *)((char *)&stru_116E8.r_offset + (_QWORD)this) = -554307887;
  *(unsigned __int64 *)((char *)&stru_11658.r_offset + (_QWORD)this) = (unsigned __int64)&this->mSoundGroupUsedHead;
  this->mSoundGroupUsedHead.mNodeNext = &this->mSoundGroupUsedHead;
  this->mRandom.mState.y = 554307886;
  this->mRandom.mState.z = -1341294569;
  *(unsigned __int64 *)((char *)&stru_11670.r_offset + (_QWORD)this) = (unsigned __int64)&this->mSoundGroupFreeHead;
  this->mSoundGroupFreeHead.mNodeNext = &this->mSoundGroupFreeHead;
  this->mRandom.mState.w = 170156318;
  this->mFFTHead.mNodePrev = &this->mFFTHead;
  this->mFFTHead.mNodeNext = &this->mFFTHead;
  v7 = &this->mChannelLayoutList[0].mReflexPair[1];
  do
  {
    v8 = v6;
    v6 = (FMOD::SystemI *)((char *)v6 + 192);
    v7 += 8;
    v9 = (char *)v8 - ((char *)&stru_11AC0 + (_QWORD)this);
    *(_QWORD *)((char *)&mReflexPair[-3] + v9 - 16) = 0;
    *(_QWORD *)((char *)&mReflexPair[-3] + v9 - 8) = 0;
    *(_DWORD *)((char *)&mReflexPair[-3].mSpeakerA + v9) = 0;
    *(_DWORD *)((char *)&mReflexPair[-2] + v9 - 20) = 0;
    v7[-8].mSpeakerA = 0;
    v7[-8].mSpeakerB = 0;
    v7[-8].mCenter = 0.0;
    v7[-8].mExtent = 0.0;
  }
  while ( v6 != (FMOD::SystemI *)&this->mStreamThread.mName[16] );
  this->mStreamListChannelHead.mNodeData = 0;
  this->mStreamListSoundHead.mNodeData = 0;
  this->mStreamListChannelHead.mNodePrev = (FMOD::LinkedListNode *)((char *)&stru_120C0 + (_QWORD)this);
  *(unsigned __int64 *)((char *)&stru_120C0.r_offset + (_QWORD)this) = (unsigned __int64)&stru_120C0 + (_QWORD)this;
  *(unsigned __int64 *)((char *)&stru_120F0.r_offset + (_QWORD)this) = (unsigned __int64)&this->mStreamListSoundHead;
  this->mStreamListSoundHead.mNodeNext = &this->mStreamListSoundHead;
  FMOD::Thread::Thread(&this->mStreamThread);
  FMOD::TimeStamp::TimeStamp(&this->mStreamTimeStamp);
  FMOD::GeometryMgr::GeometryMgr(&this->mGeometryMgr);
  FMOD::TimeStamp::TimeStamp(&this->mGeometryTimeStamp);
  v10 = (Elf64_Rela *)((char *)&stru_12498 + (_QWORD)this);
  do
  {
    v10->r_offset = 0;
    v10->r_info = 0;
    ++v10;
    LODWORD(v10[-1].r_addend) = 0;
  }
  while ( v10 != (Elf64_Rela *)((char *)&stru_124F8 + (_QWORD)this) );
  v11 = (char *)&stru_11370 + (_QWORD)this;
  this->mReverb3DHead.mNodeData = 0;
  this->mReturnTable.mSystem = 0;
  *(_DWORD *)((char *)&stru_125E8.r_offset + (_QWORD)this) = 0;
  v12 = 256;
  this->mReverb3DHead.mNodePrev = (FMOD::LinkedListNode *)((char *)&stru_125B8 + (_QWORD)this);
  *(unsigned __int64 *)((char *)&stru_125B8.r_offset + (_QWORD)this) = (unsigned __int64)&stru_125B8 + (_QWORD)this;
  this->mReturnTable.mMap.mBuckets.mData = 0;
  this->mReturnTable.mMap.mBuckets.mSize = 0;
  this->mReturnTable.mMap.mBuckets.mCapacity = 0;
  *(unsigned __int64 *)((char *)&stru_12600.r_offset + (_QWORD)this) = 0;
  this->mReturnTable.mMap.mNodes.mSize = 0;
  this->mReturnTable.mMap.mNodes.mCapacity = 0;
  this->mReturnTable.mMap.mFreeList = -1;
  this->mReturnTable.mMap.mNodeCount = 0;
  *(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) = 0;
  this->mObject3DHead.mSize = 0;
  this->mObject3DHead.mCapacity = 0;
  this->mInitialized = 0;
  this->mPluginsLoaded = 0;
  this->mOutputType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_AUTODETECT_0;
  this->mOutput = 0;
  this->mEmulated = 0;
  this->mChannel = 0;
  this->mPluginFactory = 0;
  this->mLastUpdateMs = 0;
  this->mStreamFileBufferSize = 0x4000;
  this->mStreamFileBufferSizeType = 8;
  this->mDeviceListLastCheckedTime = 0;
  this->mDeviceListChanged = 0;
  *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)this) = 0;
  this->mNumSoftwareChannels = 64;
  this->mBufferSize = 2048;
  this->mUsesUserCallbacks = 0;
  this->mDSPBlockSize = 1024;
  this->mDSPBufferSize = 4096;
  this->mSoftware = 0;
  this->mDSPMaxOutputChannels = 0;
  *(_DWORD *)((char *)&stru_11610.r_offset + (_QWORD)this) = 0;
  this->mNumChannels = 0;
  this->mNumChannelsPlaying = 0;
  this->mDSPSampleRate = 48000;
  this->mOutputHandle = 0;
  this->mSelectedDriver = 0;
  this->mDeviceListPreferredOutputType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_AUTODETECT_0;
  this->mDeviceListPreferredOutputHandle = 0;
  *(unsigned __int64 *)((char *)&stru_115F8.r_offset + (_QWORD)this) = -1;
  *(_QWORD *)this->mDeviceListPreferredDriverGUID.Data4 = -1;
  *(_QWORD *)&this->mSelectedDriverGUID.Data1 = -1;
  *(_QWORD *)this->mSelectedDriverGUID.Data4 = -1;
  this->mNumListeners = 1;
  this->mDistanceScale = 1.0;
  *(_DWORD *)((char *)&stru_11358.r_offset + (_QWORD)this) = 1065353216;
  this->mDopplerScale = 1.0;
  this->mGeometryList = 0;
  if ( (((__int64)&stru_11370 + (_QWORD)this) & 1) == 0 )
  {
    if ( ((unsigned __int8)v11 & 2) == 0 )
      goto LABEL_9;
LABEL_27:
    v11 += 2;
    v12 -= 2;
    *((_WORD *)v11 - 1) = 0;
    if ( ((unsigned __int8)v11 & 4) == 0 )
      goto LABEL_10;
    goto LABEL_28;
  }
  v11 = &this->mPluginPath[1];
  *((_BYTE *)&stru_11370.r_offset + (_QWORD)this) = 0;
  LOWORD(v12) = 255;
  if ( (((_BYTE)this + 113) & 2) != 0 )
    goto LABEL_27;
LABEL_9:
  if ( ((unsigned __int8)v11 & 4) == 0 )
    goto LABEL_10;
LABEL_28:
  *(_DWORD *)v11 = 0;
  v12 -= 4;
  v11 += 4;
LABEL_10:
  v13 = v12 >> 3;
  memset(v11, 0, 8 * v13);
  v14 = &v11[8 * v13];
  if ( (v12 & 4) != 0 )
  {
    *(_DWORD *)v14 = 0;
    v14 += 4;
  }
  if ( (v12 & 2) != 0 )
  {
    v14 += 2;
    *((_WORD *)v14 - 1) = 0;
  }
  if ( (v12 & 1) != 0 )
    *v14 = 0;
  p_mAdvancedSettings = &this->mAdvancedSettings;
  v16 = 112;
  if ( (((_BYTE)this + 40) & 1) == 0 )
  {
    if ( ((unsigned __int8)p_mAdvancedSettings & 2) == 0 )
      goto LABEL_18;
LABEL_30:
    p_mAdvancedSettings = (FMOD_ADVANCEDSETTINGS *)((char *)p_mAdvancedSettings + 2);
    v16 -= 2;
    *((_WORD *)&p_mAdvancedSettings[-1].randomSeed + 3) = 0;
    if ( ((unsigned __int8)p_mAdvancedSettings & 4) == 0 )
      goto LABEL_19;
    goto LABEL_31;
  }
  p_mAdvancedSettings = (FMOD_ADVANCEDSETTINGS *)((char *)&this->mAdvancedSettings.cbSize + 1);
  LOBYTE(this->mAdvancedSettings.cbSize) = 0;
  LOBYTE(v16) = 111;
  if ( (((_BYTE)this + 41) & 2) != 0 )
    goto LABEL_30;
LABEL_18:
  if ( ((unsigned __int8)p_mAdvancedSettings & 4) == 0 )
    goto LABEL_19;
LABEL_31:
  p_mAdvancedSettings->cbSize = 0;
  v16 -= 4;
  p_mAdvancedSettings = (FMOD_ADVANCEDSETTINGS *)((char *)p_mAdvancedSettings + 4);
LABEL_19:
  v17 = v16 >> 3;
  memset(p_mAdvancedSettings, 0, 8 * v17);
  v18 = &p_mAdvancedSettings->cbSize + 2 * v17;
  if ( (v16 & 4) != 0 )
    *v18++ = 0;
  if ( (v16 & 2) != 0 )
  {
    v18 = (int *)((char *)v18 + 2);
    *((_WORD *)v18 - 1) = 0;
  }
  if ( (v16 & 1) != 0 )
    *(_BYTE *)v18 = 0;
  this->mAdvancedSettings.distanceFilterCenterFreq = 1500.0;
  this->mAdvancedSettings.defaultDecodeBufferSize = 400;
  this->mAdvancedSettings.DSPBufferPoolSize = 8;
  this->mAdvancedSettings.stackSizeStream = 0x10000;
  this->mAdvancedSettings.stackSizeMixer = 49152;
  this->mDSPFunctions.log = FMOD::SystemI::pluginLog;
  *(_DWORD *)((char *)&stru_11580.r_offset + (_QWORD)this) = 0x10000;
  this->mAdvancedSettings.resamplerMethod = FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_LINEAR;
  *(_DWORD *)((char *)&stru_11478.r_offset + (_QWORD)this) = -1;
  this->mFSBPluginHandle = -1;
  this->mDSPFunctions.alloc = FMOD::DSPI::memoryAlloc;
  this->mWAVPluginHandle = -1;
  this->mDownMix = 0;
  this->mDSPFunctions.realloc = FMOD::DSPI::memoryRealloc;
  *(unsigned __int64 *)((char *)&stru_11778.r_offset + (_QWORD)this) = (unsigned __int64)FMOD::DSPI::memoryFree;
  this->mDSPFunctions.getsamplerate = FMOD::DSPI::getSystemSampleRate;
  this->mDSPFunctions.getblocksize = FMOD::DSPI::getSystemBlockSize;
  this->mDSPFunctions.getspeakermode = FMOD::DSPI::getSystemSpeakerMode;
  *(unsigned __int64 *)((char *)&stru_117A8.r_offset + (_QWORD)this) = (unsigned __int64)FMOD::DSPI::getClockExternal;
  this->mDSPFunctions.getlistenerattributes = FMOD::DSPI::getListenerAttributes;
  *(unsigned __int64 *)((char *)&stru_117C0.r_offset + (_QWORD)this) = (unsigned __int64)FMOD::DSPI::getUserDataExternal;
  *(unsigned __int64 *)((char *)&stru_11790.r_offset + (_QWORD)this) = (unsigned __int64)&this->mDSPDFTFunctions;
  this->mDSPFunctions.pan = (FMOD_DSP_STATE_PAN_FUNCTIONS *)((char *)&stru_117D8 + (_QWORD)this);
  this->mDSPDFTFunctions.fftreal = FMOD::SystemI::realFFT;
  this->mDSPDFTFunctions.inversefftreal = FMOD::SystemI::realInverseFFT;
  *(unsigned __int64 *)((char *)&stru_117D8.r_offset + (_QWORD)this) = (unsigned __int64)FMOD::SystemI::sumMonoMatrix;
  this->mDSPPanFunctions.sumstereomatrix = FMOD::SystemI::sumStereoMatrix;
  this->mDSPPanFunctions.sumsurroundmatrix = FMOD::SystemI::sumSurroundMatrix;
  *(unsigned __int64 *)((char *)&stru_117F0.r_offset + (_QWORD)this) = (unsigned __int64)FMOD::SystemI::sumMonoToSurroundMatrix;
  this->mDSPPanFunctions.sumstereotosurroundmatrix = FMOD::SystemI::sumStereoToSurroundMatrix;
  this->mDSPPanFunctions.getrolloffgain = FMOD::SystemI::getRolloffGain;
}


// Address: 0x21c8a20 | Name: _ZN4FMOD7SystemI9setOutputE15FMOD_OUTPUTTYPE
FMOD_RESULT_0 __fastcall FMOD::SystemI::setOutput(FMOD::SystemI *const this, FMOD_OUTPUTTYPE_0 outputtype)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INITIALIZED_0;
  if ( !this->mInitialized )
  {
    result = FMOD::SystemI::setOutputInternal(this, outputtype, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      this->mDeviceListPreferredOutputType = outputtype;
      this->mDeviceListPreferredOutputHandle = 0;
    }
  }
  return result;
}


// Address: 0x21c8a70 | Name: _ZN4FMOD7SystemI9getOutputEP15FMOD_OUTPUTTYPE
FMOD_RESULT_0 __fastcall FMOD::SystemI::getOutput(FMOD::SystemI *const this, FMOD_OUTPUTTYPE_0 *output)
{
  FMOD_RESULT_0 result; // eax
  FMOD_OUTPUTTYPE_0 mOutputType; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( output )
  {
    mOutputType = this->mOutputType;
    if ( mOutputType )
      *output = mOutputType;
    else
      FMOD_OS_Output_GetDefault(output);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21c8ab0 | Name: _ZN4FMOD7SystemI17setSoftwareFormatEi16FMOD_SPEAKERMODEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::setSoftwareFormat(
        FMOD::SystemI *const this,
        int samplerate,
        FMOD_SPEAKERMODE_0 speakermode,
        int numrawspeakers)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INITIALIZED_0;
  if ( !this->mInitialized )
  {
    if ( (unsigned int)(samplerate - 8000) <= 0x2CEC0 || (result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0, !samplerate) )
    {
      result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      if ( speakermode <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0
        && (speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 || numrawspeakers) )
      {
        result = FMOD_RESULT::FMOD_ERR_TOOMANYCHANNELS_0;
        if ( numrawspeakers <= 32 )
        {
          if ( samplerate )
            this->mDSPSampleRate = samplerate;
          this->mSpeakerMode = speakermode;
          if ( speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
          {
            switch ( speakermode )
            {
              case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0:
                numrawspeakers = 1;
                break;
              case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0:
                numrawspeakers = 2;
                break;
              case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_QUAD_0:
                numrawspeakers = 4;
                break;
              case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0:
                numrawspeakers = 5;
                break;
              case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_5POINT1_0:
                numrawspeakers = 6;
                break;
              case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0:
                numrawspeakers = 8;
                break;
              case FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0:
                numrawspeakers = 12;
                break;
              default:
                numrawspeakers = 0;
                break;
            }
          }
          this->mDSPMaxOutputChannels = numrawspeakers;
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x21c8b70 | Name: _ZN4FMOD7SystemI13getNumDriversEPi
FMOD_RESULT_0 __fastcall FMOD::SystemI::getNumDrivers(FMOD::SystemI *const this, int *numdrivers)
{
  FMOD_RESULT_0 result; // eax
  FMOD::Output *mOutput; // rdi
  FMOD_RESULT_0 (__fastcall *getnumdrivers)(FMOD_OUTPUT_STATE *, int *); // rax

  if ( !numdrivers )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !this->mInitialized
    && (result = FMOD::SystemI::setOutputInternal(this, this->mOutputType, this->mOutputHandle)) != FMOD_RESULT::FMOD_OK_0 )
  {
    *numdrivers = 0;
  }
  else
  {
    result = FMOD::SystemI::checkDriverList(this, 0);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      mOutput = this->mOutput;
      getnumdrivers = mOutput->mDescription.getnumdrivers;
      if ( getnumdrivers )
      {
        return getnumdrivers(&mOutput->FMOD_OUTPUT_STATE, numdrivers);
      }
      else
      {
        *numdrivers = 0;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21c8c00 | Name: _ZN4FMOD7SystemI13getDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_
FMOD_RESULT_0 __fastcall FMOD::SystemI::getDriverInfo(
        FMOD::SystemI *const this,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels)
{
  FMOD_RESULT_0 result; // eax
  int v13; // edx
  __int64 v14; // rax
  FMOD_SPEAKERMODE_0 v15; // edx
  int numdrivers; // [rsp+10h] [rbp-48h] BYREF
  int rate; // [rsp+14h] [rbp-44h] BYREF
  int channels; // [rsp+18h] [rbp-40h] BYREF
  FMOD_SPEAKERMODE_0 mode[15]; // [rsp+1Ch] [rbp-3Ch] BYREF

  result = FMOD::SystemI::getNumDrivers(this, &numdrivers);
  if ( result )
    return result;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( id < 0 )
    return result;
  if ( id >= numdrivers )
    return result;
  if ( !this->mInitialized )
  {
    result = FMOD::SystemI::setOutputInternal(this, this->mOutputType, this->mOutputHandle);
    if ( result )
      return result;
  }
  if ( !this->mOutput->mDescription.getdriverinfo )
    return FMOD_RESULT::FMOD_OK_0;
  rate = 0;
  channels = 0;
  mode[0] = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0;
  if ( name )
    memset(name, 0, namelen);
  if ( guid )
  {
    *(_QWORD *)&guid->Data1 = 0;
    *(_QWORD *)guid->Data4 = 0;
  }
  result = this->mOutput->mDescription.getdriverinfo(
             &this->mOutput->FMOD_OUTPUT_STATE,
             id,
             name,
             namelen,
             guid,
             &rate,
             mode,
             &channels);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( channels )
    {
      v14 = (unsigned int)(channels - 1);
      v15 = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
      if ( (unsigned int)v14 <= 0xB )
        v15 = dword_595D00[v14];
      mode[0] = v15;
      goto LABEL_22;
    }
    if ( mode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
    {
      mode[0] = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0;
      channels = 2;
      goto LABEL_22;
    }
    if ( mode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    {
      v13 = 5;
      goto LABEL_21;
    }
    if ( mode[0] <= FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
    {
      if ( mode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
      {
LABEL_20:
        v13 = 2;
LABEL_21:
        channels = v13;
LABEL_22:
        if ( !rate )
          rate = 48000;
        if ( speakermode )
          *speakermode = mode[0];
        if ( speakermodechannels )
          *speakermodechannels = channels;
        if ( systemrate )
          *systemrate = rate;
        return FMOD_RESULT::FMOD_OK_0;
      }
      v13 = 4;
      if ( mode[0] > FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0 )
        goto LABEL_21;
      LOBYTE(v13) = 1;
      if ( mode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_MONO_0 )
        goto LABEL_21;
    }
    else
    {
      v13 = 8;
      if ( mode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
        goto LABEL_21;
      LOBYTE(v13) = 6;
      if ( mode[0] < FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1_0 )
        goto LABEL_21;
      LOBYTE(v13) = 12;
      if ( mode[0] == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_7POINT1POINT4_0 )
        goto LABEL_21;
      if ( mode[0] == 1000 )
        goto LABEL_20;
    }
    v13 = 0;
    goto LABEL_21;
  }
  return result;
}


// Address: 0x21c8e20 | Name: _ZN4FMOD7SystemI9setDriverEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::setDriver(FMOD::SystemI *const this, int driver)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::SystemI::setDriverInternal(this, driver);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::SystemI::getDriverInfo(
             this,
             this->mSelectedDriver,
             0,
             0,
             (FMOD_GUID *)((char *)&stru_115F8 + (_QWORD)this),
             0,
             0,
             0);
  return result;
}


// Address: 0x21c8e70 | Name: _ZN4FMOD7SystemI9getDriverEPi
FMOD_RESULT_0 __fastcall FMOD::SystemI::getDriver(FMOD::SystemI *const this, int *driver)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( driver )
  {
    *driver = this->mSelectedDriver;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21c8e90 | Name: _ZN4FMOD7SystemI19setSoftwareChannelsEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::setSoftwareChannels(FMOD::SystemI *const this, int numsoftwarechannels)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numsoftwarechannels >= 0 )
  {
    LOBYTE(result) = 27;
    if ( !this->mInitialized )
    {
      this->mNumSoftwareChannels = numsoftwarechannels;
      LOBYTE(result) = 0;
    }
  }
  return result;
}


// Address: 0x21c8ec0 | Name: _ZN4FMOD7SystemI19getSoftwareChannelsEPi
FMOD_RESULT_0 __fastcall FMOD::SystemI::getSoftwareChannels(FMOD::SystemI *const this, int *numsoftwarechannels)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numsoftwarechannels )
  {
    *numsoftwarechannels = this->mNumSoftwareChannels;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21c8ee0 | Name: _ZN4FMOD7SystemI16setDSPBufferSizeEji
FMOD_RESULT_0 __fastcall FMOD::SystemI::setDSPBufferSize(
        FMOD::SystemI *const this,
        unsigned int bufferlength,
        int numbuffers)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INITIALIZED_0;
  if ( !this->mInitialized )
  {
    if ( bufferlength && numbuffers > 1 )
    {
      result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
      if ( ((numbuffers * (unsigned __int64)bufferlength) & 0xFFFFFFFF80000000LL) == 0 )
      {
        if ( (bufferlength & 3) != 0 )
          bufferlength = (bufferlength + 3) & 0xFFFFFFFC;
        this->mDSPBlockSize = bufferlength;
        this->mDSPBufferSize = bufferlength * numbuffers;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
    else
    {
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
  }
  return result;
}


// Address: 0x21c8f40 | Name: _ZN4FMOD7SystemI16getDSPBufferSizeEPjPi
FMOD_RESULT_0 __fastcall FMOD::SystemI::getDSPBufferSize(
        FMOD::SystemI *const this,
        unsigned int *bufferlength,
        int *numbuffers)
{
  if ( bufferlength )
    *bufferlength = this->mDSPBlockSize;
  if ( numbuffers )
    *numbuffers = this->mDSPBufferSize / this->mDSPBlockSize;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c8f70 | Name: _ZN4FMOD7SystemI19prepareObject3DInfoEPvPPNS_16Object3DMetaDataE
FMOD_RESULT_0 __fastcall FMOD::SystemI::prepareObject3DInfo(
        FMOD::SystemI *const this,
        void *handle,
        FMOD::Object3DMetaData **info)
{
  __int64 mObjectWriteIndex; // rdi
  __int64 v5; // rcx
  __int64 v6; // rdx
  __int64 v7; // rax
  int v8; // xmm0_4
  int blockCount[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  blockCount[0] = 0;
  FMOD::SystemI::getDSPBufferSize(this, 0, blockCount);
  mObjectWriteIndex = this->mObjectWriteIndex;
  v5 = *(_QWORD *)handle
     + 88LL * (unsigned __int16)((blockCount[0] + (unsigned __int16)mObjectWriteIndex - 1) % blockCount[0]);
  v6 = *(_QWORD *)(v5 + 64);
  v7 = *(_QWORD *)handle + 88 * mObjectWriteIndex;
  *(_DWORD *)(v7 + 4) = *(_DWORD *)(v5 + 4);
  *(_BYTE *)v7 = 1;
  *(_DWORD *)(v7 + 8) = *(_DWORD *)(v5 + 8);
  v8 = *(_DWORD *)(v5 + 12);
  *(_QWORD *)(v7 + 64) = v6;
  LODWORD(v6) = *(_DWORD *)(v5 + 72);
  *(_DWORD *)(v7 + 12) = v8;
  *(_DWORD *)(v7 + 72) = v6;
  *(_QWORD *)(v7 + 16) = *(_QWORD *)(v5 + 16);
  *(_QWORD *)(v7 + 24) = *(_QWORD *)(v5 + 24);
  *(_QWORD *)(v7 + 32) = *(_QWORD *)(v5 + 32);
  *(_QWORD *)(v7 + 40) = *(_QWORD *)(v5 + 40);
  *(_QWORD *)(v7 + 48) = *(_QWORD *)(v5 + 48);
  *(_QWORD *)(v7 + 56) = *(_QWORD *)(v5 + 56);
  *info = (FMOD::Object3DMetaData *)v7;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c9040 | Name: _ZN4FMOD7SystemI19allocObject3DHandleEPPv
FMOD_RESULT_0 __fastcall FMOD::SystemI::allocObject3DHandle(FMOD::SystemI *const this, void **handle)
{
  FMOD::Object3DState *v4; // r13
  FMOD_RESULT_0 result; // eax
  int v6; // edi
  unsigned __int64 v7; // rcx
  FMOD::Object3DState *v8; // rdx
  __int64 v9; // rsi
  char v10; // r14
  __int64 mSize; // rdx
  int v12; // esi
  int v13; // eax
  int v14; // ecx
  int v15; // eax
  int v16; // r15d
  int v17; // eax
  void *v18; // r8
  __int64 v19; // rax
  void *v20; // rsi
  _QWORD *v21; // rax
  void *v22; // [rsp+8h] [rbp-50h]
  int blockCount; // [rsp+10h] [rbp-48h] BYREF
  unsigned int blockSize; // [rsp+14h] [rbp-44h] BYREF
  FMOD::Object3DState *state; // [rsp+18h] [rbp-40h]

  blockCount = 0;
  blockSize = 0;
  FMOD::SystemI::getDSPBufferSize(this, &blockSize, &blockCount);
  v4 = (FMOD::Object3DState *)FMOD::MemPool::calloc(
                                off_286F358->gSystemMemPool,
                                blockCount * 4 * blockSize + 88 * blockCount + 64,
                                "../../../core_api/src/fmod_systemi.cpp",
                                955,
                                0);
  state = v4;
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v4 )
  {
    v6 = blockCount;
    v4->mMetaData = (FMOD::Object3DMetaData *)&v4[1];
    v7 = ((unsigned __int64)&v4[1].mDeleteNext + 88 * v6 + 7) & 0xFFFFFFFFFFFFFFF0LL;
    if ( v6 > 0 )
    {
      v8 = v4;
      v9 = 4LL * blockSize;
      do
      {
        *(_QWORD *)&v8[2].mArrayIndex = v7;
        v8 = (FMOD::Object3DState *)((char *)v8 + 88);
        v7 += v9;
      }
      while ( v8 != (FMOD::Object3DState *)(&v4[1].mSortPriority + 22 * (unsigned int)(v6 - 1)) );
    }
    result = FMOD::ExpandingPool<FMOD::DSPConnectionI>::alloc(&this->mDSPConnectionPool, &v4->mConnection, 1);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::DSPConnectionI::reset(v4->mConnection, 1, 1);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( this )
        {
          v10 = 1;
          FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_OBJECT3D_INFO);
        }
        else
        {
          v10 = 0;
        }
        mSize = this->mObject3DHead.mSize;
        v12 = this->mObject3DHead.mCapacity >> 31;
        v13 = v12 ^ this->mObject3DHead.mCapacity;
        v14 = mSize + 1;
        v4->mArrayIndex = mSize;
        v15 = v13 - v12;
        if ( (int)mSize + 1 <= v15 )
        {
          v21 = *(_QWORD **)((char *)&stru_12618.r_offset + (_QWORD)this);
        }
        else
        {
          v16 = 8;
          v17 = (int)(float)((float)v15 * 1.5);
          if ( v17 >= v14 )
            v14 = v17;
          if ( v14 > 7 )
            v16 = v14;
          if ( (int)mSize > v16 )
            goto LABEL_16;
          if ( (unsigned int)(8 * v16 - 1) > 0x3FFFFFFE )
            goto LABEL_16;
          v18 = FMOD::MemPool::alloc(
                  off_286F358->gSystemMemPool,
                  8 * v16,
                  "../../../core_api/src/fmod_memory.h",
                  232,
                  0,
                  0);
          if ( !v18 )
            goto LABEL_16;
          v19 = this->mObject3DHead.mSize;
          if ( (_DWORD)v19 )
            v18 = memcpy_0(v18, *(const void **)((char *)&stru_12618.r_offset + (_QWORD)this), 8 * v19);
          if ( this->mObject3DHead.mCapacity > 0 )
          {
            v20 = *(void **)((char *)&stru_12618.r_offset + (_QWORD)this);
            if ( v20 )
            {
              v22 = v18;
              FMOD::MemPool::free(off_286F358->gSystemMemPool, v20, "../../../core_api/src/fmod_memory.h", 244);
              v18 = v22;
            }
          }
          mSize = this->mObject3DHead.mSize;
          *(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) = (unsigned __int64)v18;
          v21 = v18;
          this->mObject3DHead.mCapacity = v16;
        }
        v21[mSize] = state;
        ++this->mObject3DHead.mSize;
LABEL_16:
        if ( v10 )
          FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_OBJECT3D_INFO);
        *handle = v4;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21c92e0 | Name: _ZN4FMOD7SystemI13setFileSystemEPF11FMOD_RESULTPKcPjPPvS5_EPFS1_S5_S5_EPFS1_S5_S5_jS4_S5_EPFS1_S5_jS5_EPFS1_P18FMOD_ASYNCREADINFOS5_ESI_i
FMOD_RESULT_0 __fastcall FMOD::SystemI::setFileSystem(
        FMOD::SystemI *const this,
        FMOD_FILE_OPEN_CALLBACK useropen,
        FMOD_FILE_CLOSE_CALLBACK userclose,
        FMOD_FILE_READ_CALLBACK userread,
        FMOD_FILE_SEEK_CALLBACK userseek,
        FMOD_FILE_ASYNCREAD_CALLBACK userasyncread,
        FMOD_FILE_ASYNCCANCEL_CALLBACK userasynccancel,
        int blockalign)
{
  FMOD_RESULT (*v8)(FMOD_ASYNCREADINFO *, void *); // rax

  v8 = userasynccancel;
  if ( !useropen || !userclose )
    goto LABEL_3;
  if ( userasyncread && userasynccancel )
  {
    this->mUsesUserCallbacks = 1;
  }
  else
  {
    if ( !userread || !userseek )
    {
LABEL_3:
      this->mUsesUserCallbacks = 0;
      v8 = 0;
      userasyncread = 0;
      userseek = 0;
      userread = 0;
      userclose = 0;
      useropen = 0;
      goto LABEL_4;
    }
    this->mUsesUserCallbacks = 1;
  }
LABEL_4:
  this->mOpenCallback = useropen;
  *(unsigned __int64 *)((char *)&stru_11700.r_offset + (_QWORD)this) = (unsigned __int64)userclose;
  this->mReadCallback = userread;
  this->mSeekCallback = userseek;
  *(unsigned __int64 *)((char *)&stru_11718.r_offset + (_QWORD)this) = (unsigned __int64)userasyncread;
  this->mAsyncCancelCallback = v8;
  if ( blockalign >= 0 )
    this->mBufferSize = blockalign;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c9370 | Name: _ZN4FMOD7SystemI16attachFileSystemEPF11FMOD_RESULTPKcPjPPvS5_EPFS1_S5_S5_EPFS1_S5_S5_jS4_S5_EPFS1_S5_jS5_E
FMOD_RESULT_0 __fastcall FMOD::SystemI::attachFileSystem(
        FMOD::SystemI *const this,
        FMOD_FILE_OPEN_CALLBACK useropen,
        FMOD_FILE_CLOSE_CALLBACK userclose,
        FMOD_FILE_READ_CALLBACK userread,
        FMOD_FILE_SEEK_CALLBACK userseek)
{
  this->mOpenRiderCallback = useropen;
  *(unsigned __int64 *)((char *)&stru_11730.r_offset + (_QWORD)this) = (unsigned __int64)userclose;
  this->mReadRiderCallback = userread;
  this->mSeekRiderCallback = userseek;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c9390 | Name: _ZN4FMOD7SystemI19setAdvancedSettingsEP21FMOD_ADVANCEDSETTINGS
FMOD_RESULT_0 __fastcall FMOD::SystemI::setAdvancedSettings(FMOD::SystemI *const this, FMOD_ADVANCEDSETTINGS *settings)
{
  int cbSize; // eax
  __m128i vol0virtualvol_low; // xmm0
  float distanceFilterCenterFreq; // xmm1_4
  unsigned int DSPBufferPoolSize; // ecx
  FMOD_DSP_RESAMPLER resamplerMethod; // edx

  if ( !settings )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  cbSize = settings->cbSize;
  if ( (unsigned int)(settings->cbSize - 97) > 0xF
    || (cbSize & 3) != 0
    || settings->maxADPCMCodecs > 0xFFFFu
    || settings->maxMPEGCodecs > 0xFFFFu
    || settings->maxXMACodecs > 0xFFFFu
    || settings->maxVorbisCodecs > 0xFFFFu
    || settings->maxAT9Codecs > 0xFFFFu
    || settings->maxFADPCMCodecs > 0xFFFFu )
  {
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  vol0virtualvol_low = (__m128i)LODWORD(settings->vol0virtualvol);
  if ( (_mm_cvtsi128_si32(vol0virtualvol_low) & 0x7F800000) == 0x7F800000 )
    return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  distanceFilterCenterFreq = settings->distanceFilterCenterFreq;
  if ( distanceFilterCenterFreq >= 0.000099999997 )
  {
    if ( distanceFilterCenterFreq < 10.0 || distanceFilterCenterFreq > 22050.0 )
      return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  else
  {
    settings->distanceFilterCenterFreq = this->mAdvancedSettings.distanceFilterCenterFreq;
  }
  if ( *(float *)vol0virtualvol_low.m128i_i32 != -1.0
    && (*(float *)vol0virtualvol_low.m128i_i32 < 0.0 || *(float *)vol0virtualvol_low.m128i_i32 > 1.0) )
  {
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  if ( settings->ASIONumChannels > 0x20u )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  DSPBufferPoolSize = settings->DSPBufferPoolSize;
  if ( DSPBufferPoolSize > 0xFFFF )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  resamplerMethod = settings->resamplerMethod;
  if ( (unsigned int)resamplerMethod > FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_SPLINE || settings->reverb3Dinstance > 3u )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( settings->defaultDecodeBufferSize - 1 > 0x752F )
    settings->defaultDecodeBufferSize = this->mAdvancedSettings.defaultDecodeBufferSize;
  if ( !settings->stackSizeStream )
    settings->stackSizeStream = this->mAdvancedSettings.stackSizeStream;
  if ( !settings->stackSizeNonBlocking )
    settings->stackSizeNonBlocking = *(_DWORD *)((char *)&stru_11580.r_offset + (_QWORD)this);
  if ( !settings->stackSizeMixer )
    settings->stackSizeMixer = this->mAdvancedSettings.stackSizeMixer;
  if ( !DSPBufferPoolSize )
    settings->DSPBufferPoolSize = this->mAdvancedSettings.DSPBufferPoolSize;
  if ( resamplerMethod == FMOD_DSP_RESAMPLER::FMOD_DSP_RESAMPLER_DEFAULT )
    settings->resamplerMethod = this->mAdvancedSettings.resamplerMethod;
  memcpy_0(&this->mAdvancedSettings, settings, cbSize);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c9510 | Name: _ZN4FMOD7SystemI19getAdvancedSettingsEP21FMOD_ADVANCEDSETTINGS
FMOD_RESULT_0 __fastcall FMOD::SystemI::getAdvancedSettings(FMOD::SystemI *const this, FMOD_ADVANCEDSETTINGS *settings)
{
  FMOD_RESULT_0 result; // eax
  int cbSize; // ebx
  FMOD_SPEAKER *ASIOSpeakerList; // rbp
  _QWORD *v5; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( settings )
  {
    cbSize = settings->cbSize;
    if ( (unsigned int)(settings->cbSize - 49) <= 0x3F && (cbSize & 3) == 0 && settings->ASIONumChannels <= 0x20u )
    {
      ASIOSpeakerList = settings->ASIOSpeakerList;
      v5 = memcpy_0(settings, &this->mAdvancedSettings, cbSize);
      *(_DWORD *)v5 = cbSize;
      v5[6] = ASIOSpeakerList;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21c9570 | Name: _ZN4FMOD7SystemI11setCallbackEPF11FMOD_RESULTP11FMOD_SYSTEMjPvS4_S4_Ej
FMOD_RESULT_0 __fastcall FMOD::SystemI::setCallback(
        FMOD::SystemI *const this,
        FMOD_SYSTEM_CALLBACK callback,
        FMOD_SYSTEM_CALLBACK_TYPE callbackmask)
{
  FMOD::Global *v3; // rax

  v3 = off_286F358;
  off_286F358->gSystemCallback = callback;
  v3->gSystemCallbackMask = callbackmask;
  *(unsigned __int64 *)((char *)&stru_11748.r_offset + (_QWORD)this) = (unsigned __int64)callback;
  this->mCallbackMask = callbackmask;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21c95a0 | Name: _ZN4FMOD7SystemI13setPluginPathEPKc
FMOD_RESULT_0 __fastcall FMOD::SystemI::setPluginPath(FMOD::SystemI *const this, const char *path)
{
  FMOD_RESULT_0 v3; // ebp
  FMOD::PluginFactory *mPluginFactory; // rdi

  v3 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( FMOD_strlen(path) > 255 )
    return v3;
  LOBYTE(v3) = 0;
  FMOD_strcpy_safe((char *)&stru_11370 + (_QWORD)this, path, 256);
  mPluginFactory = this->mPluginFactory;
  if ( !mPluginFactory )
    return v3;
  FMOD::PluginFactory::setPluginPath(mPluginFactory, (const char *)&stru_11370 + (_QWORD)this);
  return v3;
}


// Address: 0x21c9620 | Name: _ZN4FMOD7SystemI10loadPluginEPKcPjj
FMOD_RESULT_0 __fastcall FMOD::SystemI::loadPlugin(
        FMOD::SystemI *const this,
        const char *filename,
        unsigned int *handle,
        unsigned int priority)
{
  FMOD_RESULT_0 result; // eax
  unsigned int *handlea; // [rsp+8h] [rbp-20h]

  if ( this->mPluginsLoaded )
    return FMOD::PluginFactory::loadPlugin(this->mPluginFactory, filename, handle, 0, priority);
  handlea = handle;
  result = FMOD::SystemI::setUpPlugins(this);
  handle = handlea;
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::PluginFactory::loadPlugin(this->mPluginFactory, filename, handle, 0, priority);
  return result;
}


// Address: 0x21c9670 | Name: _ZN4FMOD7SystemI12unloadPluginEj
FMOD_RESULT_0 __fastcall FMOD::SystemI::unloadPlugin(FMOD::SystemI *const this, unsigned int handle)
{
  FMOD_RESULT_0 result; // eax

  if ( this->mPluginsLoaded )
    return FMOD::PluginFactory::unloadPlugin(this->mPluginFactory, handle, 0);
  result = FMOD::SystemI::setUpPlugins(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::PluginFactory::unloadPlugin(this->mPluginFactory, handle, 0);
  return result;
}


// Address: 0x21c96b0 | Name: _ZN4FMOD7SystemI13getNumPluginsE15FMOD_PLUGINTYPEPi
FMOD_RESULT_0 __fastcall FMOD::SystemI::getNumPlugins(
        FMOD::SystemI *const this,
        FMOD_PLUGINTYPE_0 type,
        int *numplugins)
{
  FMOD_RESULT_0 result; // eax
  int *numpluginsa; // [rsp+4h] [rbp-10h]

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numplugins )
  {
    if ( this->mPluginsLoaded )
    {
      if ( type != FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_CODEC_0 )
      {
LABEL_4:
        if ( type == FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_DSP_0 )
        {
          FMOD::PluginFactory::getNumDSPs(this->mPluginFactory, numplugins);
          return FMOD_RESULT::FMOD_OK_0;
        }
        else
        {
          result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
          if ( type == FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_OUTPUT_0 )
          {
            FMOD::PluginFactory::getNumOutputs(this->mPluginFactory, numplugins);
            return FMOD_RESULT::FMOD_OK_0;
          }
        }
        return result;
      }
    }
    else
    {
      numpluginsa = numplugins;
      result = FMOD::SystemI::setUpPlugins(this);
      numplugins = numpluginsa;
      if ( result )
        return result;
      if ( type != FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_CODEC_0 )
        goto LABEL_4;
    }
    FMOD::PluginFactory::getNumCodecs(this->mPluginFactory, numplugins);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21c9760 | Name: _ZN4FMOD7SystemI19getNumNestedPluginsEjPi
FMOD_RESULT_0 __fastcall FMOD::SystemI::getNumNestedPlugins(FMOD::SystemI *const this, unsigned int handle, int *count)
{
  FMOD_RESULT_0 result; // eax
  int *counta; // [rsp+8h] [rbp-10h]

  if ( this->mPluginsLoaded )
    return FMOD::PluginFactory::getNumNestedPlugins(this->mPluginFactory, handle, count);
  counta = count;
  result = FMOD::SystemI::setUpPlugins(this);
  count = counta;
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::PluginFactory::getNumNestedPlugins(this->mPluginFactory, handle, count);
  return result;
}


// Address: 0x21c97b0 | Name: _ZN4FMOD7SystemI15getNestedPluginEjiPj
FMOD_RESULT_0 __fastcall FMOD::SystemI::getNestedPlugin(
        FMOD::SystemI *const this,
        unsigned int handle,
        int index,
        unsigned int *itemhandle)
{
  FMOD_RESULT_0 result; // eax
  int indexa; // [rsp+4h] [rbp-14h]
  unsigned int *itemhandlea; // [rsp+8h] [rbp-10h]

  if ( this->mPluginsLoaded )
    return FMOD::PluginFactory::getNestedPlugin(this->mPluginFactory, handle, index, itemhandle);
  itemhandlea = itemhandle;
  indexa = index;
  result = FMOD::SystemI::setUpPlugins(this);
  index = indexa;
  itemhandle = itemhandlea;
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::PluginFactory::getNestedPlugin(this->mPluginFactory, handle, index, itemhandle);
  return result;
}


// Address: 0x21c9800 | Name: _ZN4FMOD7SystemI15getPluginHandleE15FMOD_PLUGINTYPEiPj
FMOD_RESULT_0 __fastcall FMOD::SystemI::getPluginHandle(
        FMOD::SystemI *const this,
        FMOD_PLUGINTYPE_0 plugintype,
        int index,
        unsigned int *handle)
{
  if ( plugintype == FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_CODEC_0 )
    return FMOD::PluginFactory::getCodecHandle(this->mPluginFactory, index, handle);
  if ( plugintype == FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_DSP_0 )
    return FMOD::PluginFactory::getDSPHandle(this->mPluginFactory, index, handle);
  if ( plugintype )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  return FMOD::PluginFactory::getOutputHandle(this->mPluginFactory, index, handle);
}


// Address: 0x21c9870 | Name: _ZN4FMOD7SystemI13getPluginInfoEjP15FMOD_PLUGINTYPEPciPj
FMOD_RESULT_0 __fastcall FMOD::SystemI::getPluginInfo(
        FMOD::SystemI *const this,
        unsigned int handle,
        FMOD_PLUGINTYPE_0 *plugintype,
        char *name,
        int namelen,
        unsigned int *version)
{
  FMOD_RESULT_0 result; // eax
  FMOD::FMOD_OUTPUT_DESCRIPTION_PLUGIN *outputdesc; // [rsp+8h] [rbp-50h] BYREF
  FMOD::FMOD_CODEC_DESCRIPTION_PLUGIN *codecdesc; // [rsp+10h] [rbp-48h] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *dspdesc; // [rsp+18h] [rbp-40h] BYREF

  if ( this->mPluginsLoaded || (result = FMOD::SystemI::setUpPlugins(this)) == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD::PluginFactory::getOutput(this->mPluginFactory, handle, &outputdesc);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( name )
        FMOD_strcpy_safe(name, outputdesc->mDescription.name, namelen);
      if ( version )
        *version = outputdesc->mDescription.version;
      if ( plugintype )
      {
        *plugintype = FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_OUTPUT_0;
        return FMOD_RESULT::FMOD_OK_0;
      }
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( result == FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0 )
    {
      result = FMOD::PluginFactory::getCodec(this->mPluginFactory, handle, &codecdesc);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( name )
          FMOD_strcpy_safe(name, codecdesc->mDescription.name, namelen);
        if ( version )
          *version = codecdesc->mDescription.version;
        if ( plugintype )
        {
          *plugintype = FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_CODEC_0;
          return FMOD_RESULT::FMOD_OK_0;
        }
        return FMOD_RESULT::FMOD_OK_0;
      }
      if ( result == FMOD_RESULT::FMOD_ERR_PLUGIN_MISSING_0 )
      {
        result = FMOD::PluginFactory::getDSP(this->mPluginFactory, handle, &dspdesc);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          if ( name )
            FMOD_strcpy_safe(name, dspdesc->mDescription.mDescription->name, namelen);
          if ( version )
            *version = dspdesc->mDescription.mDescription->version;
          if ( plugintype )
            *plugintype = FMOD_PLUGINTYPE::FMOD_PLUGINTYPE_DSP_0;
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x21c99d0 | Name: _ZN4FMOD7SystemI17setOutputByPluginEj
FMOD_RESULT_0 __fastcall FMOD::SystemI::setOutputByPlugin(FMOD::SystemI *const this, unsigned int handle)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INITIALIZED_0;
  if ( !this->mInitialized )
  {
    result = FMOD::SystemI::setOutputInternal(this, FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_AUTODETECT_0, handle);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      this->mDeviceListPreferredOutputType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_AUTODETECT_0;
      this->mDeviceListPreferredOutputHandle = handle;
    }
  }
  return result;
}


// Address: 0x21c9a20 | Name: _ZN4FMOD7SystemI17getOutputByPluginEPj
FMOD_RESULT_0 __fastcall FMOD::SystemI::getOutputByPlugin(FMOD::SystemI *const this, unsigned int *handle)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( handle )
  {
    *handle = this->mOutputHandle;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21c9a40 | Name: _ZN4FMOD7SystemI17createDSPByPluginEjPPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::createDSPByPlugin(
        FMOD::SystemI *const this,
        unsigned int handle,
        FMOD::DSPI **dsp)
{
  FMOD_RESULT_0 result; // eax
  bool v4; // zf
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *descriptionplugin; // [rsp+8h] [rbp-20h] BYREF

  result = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  v4 = this->mPluginFactory == 0;
  descriptionplugin = 0;
  if ( !v4 )
  {
    LOBYTE(result) = 31;
    if ( dsp )
    {
      *dsp = 0;
      result = FMOD::PluginFactory::getDSP(this->mPluginFactory, handle, &descriptionplugin);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        result = FMOD::PluginFactory::createDSP(this->mPluginFactory, &descriptionplugin->mDescription, 0, dsp);
        if ( result == FMOD_RESULT::FMOD_OK_0 )
        {
          (*dsp)->mJob.mFlags |= 4u;
          ++descriptionplugin->mRefCount;
        }
      }
    }
  }
  return result;
}


// Address: 0x21c9ac0 | Name: _ZN4FMOD7SystemI18getDSPInfoByPluginEjPPK20FMOD_DSP_DESCRIPTION
FMOD_RESULT_0 __fastcall FMOD::SystemI::getDSPInfoByPlugin(
        FMOD::SystemI *const this,
        unsigned int handle,
        const FMOD_DSP_DESCRIPTION_0 **description)
{
  FMOD_RESULT_0 result; // eax
  FMOD::FMOD_DSP_DESCRIPTION_PLUGIN *dspdesc; // [rsp+8h] [rbp-10h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( description )
  {
    result = FMOD::PluginFactory::getDSP(this->mPluginFactory, handle, &dspdesc);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      *description = dspdesc->mDescription.mDescription;
  }
  return result;
}


// Address: 0x21c9b00 | Name: _ZN4FMOD7SystemI13registerCodecEP22FMOD_CODEC_DESCRIPTIONPjj
FMOD_RESULT_0 __fastcall FMOD::SystemI::registerCodec(
        FMOD::SystemI *const this,
        FMOD_CODEC_DESCRIPTION *description,
        unsigned int *handle,
        unsigned int priority)
{
  FMOD_RESULT_0 result; // eax
  const char *name; // rax
  FMOD::PluginFactory *mPluginFactory; // rdi
  unsigned int pluginhandle; // [rsp+Ch] [rbp-10Ch] BYREF
  FMOD::FMOD_CODEC_DESCRIPTION_EX descriptionex; // [rsp+10h] [rbp-108h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( description )
  {
    if ( this->mPluginsLoaded || (result = FMOD::SystemI::setUpPlugins(this)) == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( handle )
        *handle = 0;
      memset(&descriptionex, 0, sizeof(descriptionex));
      name = description->name;
      mPluginFactory = this->mPluginFactory;
      descriptionex.mSize = 416;
      descriptionex.name = name;
      descriptionex.version = description->version;
      descriptionex.timeunits = description->timeunits;
      descriptionex.defaultasstream = description->defaultasstream;
      descriptionex.open = description->open;
      descriptionex.close = description->close;
      descriptionex.read = description->read;
      descriptionex.getlength = description->getlength;
      descriptionex.setposition = description->setposition;
      descriptionex.getposition = description->getposition;
      descriptionex.soundcreate = description->soundcreate;
      descriptionex.getwaveformat = description->getwaveformat;
      result = FMOD::PluginFactory::registerCodec(mPluginFactory, &descriptionex, &pluginhandle, priority, 0);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( handle )
          *handle = pluginhandle;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21c9c10 | Name: _ZN4FMOD7SystemI11registerDSPEPK20FMOD_DSP_DESCRIPTIONPj
// local variable allocation has failed, the output may be wrong!
FMOD_RESULT_0 __fastcall FMOD::SystemI::registerDSP(
        FMOD::SystemI *const this,
        const FMOD_DSP_DESCRIPTION_0 *description_in,
        unsigned int *handle)
{
  FMOD_RESULT_0 result; // eax
  int v4; // ebx
  FMOD::PluginFactory *mPluginFactory; // rdi
  int numdsps; // [rsp+18h] [rbp-80h] BYREF
  unsigned int pluginhandle; // [rsp+1Ch] [rbp-7Ch] BYREF
  FMOD::FMOD_DSP_DESCRIPTION_EX dspdesc; // [rsp+20h] [rbp-78h] OVERLAPPED BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( description_in )
  {
    if ( this->mPluginsLoaded || (result = FMOD::SystemI::setUpPlugins(this)) == FMOD_RESULT::FMOD_OK_0 )
    {
      if ( handle )
        *handle = 0;
      result = FMOD::PluginFactory::getNumDSPs(this->mPluginFactory, &numdsps);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        if ( numdsps <= 0 )
        {
LABEL_15:
          memset(&dspdesc, 0, sizeof(dspdesc));
          mPluginFactory = this->mPluginFactory;
          dspdesc.mSize = 528;
          result = FMOD::PluginFactory::registerDSP(mPluginFactory, &dspdesc, description_in, &pluginhandle, 0);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            if ( handle )
              *handle = pluginhandle;
          }
        }
        else
        {
          v4 = 0;
          while ( 1 )
          {
            result = FMOD::PluginFactory::getDSPHandle(this->mPluginFactory, v4, &pluginhandle);
            if ( result )
              break;
            result = FMOD::PluginFactory::getDSP(
                       this->mPluginFactory,
                       pluginhandle,
                       (FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **)&dspdesc);
            if ( result )
              break;
            if ( !FMOD_strcmp((const char *)(*(_QWORD *)dspdesc.mDescription + 4LL), description_in->name) )
              return FMOD_RESULT::FMOD_ERR_DSP_INUSE_0;
            if ( numdsps <= ++v4 )
              goto LABEL_15;
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21c9d80 | Name: _ZN4FMOD7SystemI14registerOutputEPK23FMOD_OUTPUT_DESCRIPTIONPj
FMOD_RESULT_0 __fastcall FMOD::SystemI::registerOutput(
        FMOD::SystemI *const this,
        const FMOD_OUTPUT_DESCRIPTION_4 *description_in,
        unsigned int *handle)
{
  FMOD_RESULT_0 result; // eax
  unsigned int *handlea; // [rsp+8h] [rbp-10h]

  if ( this->mPluginsLoaded )
    return FMOD::PluginFactory::registerOutput(
             this->mPluginFactory,
             description_in,
             handle,
             0,
             FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_UNKNOWN_0);
  handlea = handle;
  result = FMOD::SystemI::setUpPlugins(this);
  handle = handlea;
  if ( result == FMOD_RESULT::FMOD_OK_0 )
    return FMOD::PluginFactory::registerOutput(
             this->mPluginFactory,
             description_in,
             handle,
             0,
             FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_UNKNOWN_0);
  return result;
}


// Address: 0x21c9dd0 | Name: _ZN4FMOD7SystemI6updateEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::update(FMOD::SystemI *const this)
{
  return FMOD::SystemI::updateInternal(this, 1);
}


// Address: 0x21c9de0 | Name: _ZN4FMOD7SystemI18setSpeakerPositionE12FMOD_SPEAKERffb
FMOD_RESULT_0 __fastcall FMOD::SystemI::setSpeakerPosition(
        FMOD::SystemI *const this,
        FMOD_SPEAKER_0 speaker,
        float x,
        float y,
        char active)
{
  FMOD_SPEAKERMODE_0 mSpeakerMode; // eax
  FMOD_SPEAKER_0 v6; // r9d
  FMOD_RESULT_0 result; // eax
  float *v8; // r10
  float v9; // xmm3_4
  float v10; // xmm2_4
  float v11; // xmm2_4
  float v12; // xmm3_4

  if ( (LODWORD(x) & 0x7F800000) == 0x7F800000 || (LODWORD(y) & 0x7F800000) == 0x7F800000 )
    return FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  mSpeakerMode = this->mSpeakerMode;
  v6 = speaker;
  if ( mSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_QUAD_0 )
  {
    v6 = speaker - 2;
    if ( (unsigned int)(speaker - 2) > 1 )
    {
      if ( (unsigned int)(speaker - 4) > 1 )
        v6 = speaker;
      goto LABEL_5;
    }
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  if ( mSpeakerMode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_SURROUND_0 )
  {
    if ( speaker != FMOD_SPEAKER::FMOD_SPEAKER_LOW_FREQUENCY_0 )
    {
      v6 = speaker - 1;
      if ( (unsigned int)(speaker - 4) > 1 )
        v6 = speaker;
      goto LABEL_5;
    }
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
LABEL_5:
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( v6 < this->mDSPMaxOutputChannels )
  {
    v8 = (float *)((char *)this + 48 * v6);
    v8[17930] = x;
    *((_BYTE *)v8 + 71752) = active;
    *(_DWORD *)((char *)&stru_11820.r_offset + (_QWORD)v8) = speaker;
    *((_DWORD *)v8 + 17929) = v6;
    v8[17931] = 0.0;
    v8[17932] = y;
    if ( y != 0.0 || (v11 = 0.0, x != 0.0) )
    {
      if ( y < 0.0 )
        v9 = -y;
      else
        v9 = y;
      v10 = x;
      if ( x < 0.0 )
        v10 = -x;
      if ( v9 < v10 )
      {
        v12 = 3.0 - (float)(y / v10);
        v11 = v12;
        if ( x < 0.0 )
          v11 = 10.0 - v12;
      }
      else
      {
        v11 = (float)(x / v9) + 1.0;
        if ( y < 0.0 )
          v11 = 6.0 - (float)((float)(x / v9) + 1.0);
      }
    }
    this->mSpeaker[v6].mXZAngle = v11;
    return FMOD::SystemI::sortSpeakerList(this);
  }
  return result;
}


// Address: 0x21ca0c0 | Name: _ZN4FMOD7SystemI19setStreamBufferSizeEjj
FMOD_RESULT_0 __fastcall FMOD::SystemI::setStreamBufferSize(
        FMOD::SystemI *const this,
        unsigned int filebuffersize,
        FMOD_TIMEUNIT filebuffersizetype)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( filebuffersize && (filebuffersizetype - 1 <= 1 || filebuffersizetype == 4 || filebuffersizetype == 8) )
  {
    this->mStreamFileBufferSize = filebuffersize;
    this->mStreamFileBufferSizeType = filebuffersizetype;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21ca100 | Name: _ZN4FMOD7SystemI19getStreamBufferSizeEPjS1_
FMOD_RESULT_0 __fastcall FMOD::SystemI::getStreamBufferSize(
        FMOD::SystemI *const this,
        unsigned int *filebuffersize,
        FMOD_TIMEUNIT *filebuffersizetype)
{
  if ( filebuffersize )
    *filebuffersize = this->mStreamFileBufferSize;
  if ( filebuffersizetype )
    *filebuffersizetype = this->mStreamFileBufferSizeType;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ca120 | Name: _ZN4FMOD7SystemI13set3DSettingsEfff
__int64 __fastcall FMOD::SystemI::set3DSettings(
        FMOD::SystemI *const this,
        float a2,
        float dopplerscale,
        __m128i distancescale,
        float rolloffscale)
{
  __int64 result; // rax

  result = 29;
  if ( (LODWORD(a2) & 0x7F800000) != 0x7F800000
    && (LODWORD(dopplerscale) & 0x7F800000) != 0x7F800000
    && (_mm_cvtsi128_si32(distancescale) & 0x7F800000) != 0x7F800000 )
  {
    result = 31;
    if ( a2 >= 0.0 && dopplerscale > 0.0 && *(float *)distancescale.m128i_i32 >= 0.0 )
    {
      this->mDopplerScale = a2;
      this->mDistanceScale = dopplerscale;
      *(_DWORD *)((char *)&stru_11358.r_offset + (_QWORD)this) = distancescale.m128i_i32[0];
      return 0;
    }
  }
  return result;
}


// Address: 0x21ca1d0 | Name: _ZN4FMOD7SystemI17set3DNumListenersEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::set3DNumListeners(FMOD::SystemI *const this, int numlisteners)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (unsigned int)(numlisteners - 1) <= 7 )
  {
    this->mNumListeners = numlisteners;
    LOBYTE(result) = 0;
  }
  return result;
}


// Address: 0x21ca1f0 | Name: _ZN4FMOD7SystemI23set3DListenerAttributesEiPK11FMOD_VECTORS3_S3_S3_
FMOD_RESULT_0 __fastcall FMOD::SystemI::set3DListenerAttributes(
        FMOD::SystemI *const this,
        int listener,
        const FMOD_VECTOR *pos,
        const FMOD_VECTOR *vel,
        const FMOD_VECTOR *forward,
        const FMOD_VECTOR *up)
{
  FMOD_RESULT_0 result; // eax
  __m128i x_low; // xmm1
  FMOD_RESULT_0 v8; // ebx
  __m128i y_low; // xmm2
  __m128i z_low; // xmm3
  int v11; // r10d
  bool v12; // zf
  FMOD_RESULT_0 v13; // r10d
  int v14; // r10d
  float v15; // xmm0_4
  float *v16; // r10
  char *v17; // rax
  __m128i v18; // xmm1
  int v19; // eax
  int v20; // r11d
  __m128i v21; // xmm2
  __m128i v22; // xmm3
  int v23; // r8d
  int v24; // r8d
  int v25; // r8d
  float v26; // xmm0_4
  char *v27; // rax
  float y; // r11d
  int v29; // eax
  int v30; // ebx
  int v31; // r8d
  int v32; // r8d
  float z; // ebx
  __int64 v34; // r9
  FMOD::Listener *v35; // r8
  float v36; // eax
  __int64 v37; // rax
  float v38; // r10d
  int v39; // eax
  int v40; // r11d
  int v41; // edx
  int v42; // edx
  float v43; // r11d
  __int64 v44; // rsi
  char *v45; // rdx
  float x; // xmm6_4
  float v47; // xmm3_4
  float v48; // xmm2_4
  float *v49; // rcx
  float v50; // xmm4_4
  float v51; // xmm5_4
  float v52; // xmm1_4
  float v53; // xmm0_4
  float *v54; // rax
  int v55; // [rsp+0h] [rbp-14h]
  int v56; // [rsp+0h] [rbp-14h]

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (unsigned int)listener > 7 )
    return result;
  if ( forward )
  {
    x_low = (__m128i)LODWORD(forward->x);
    LOBYTE(result) = 29;
    v8 = result;
    y_low = (__m128i)LODWORD(forward->y);
    z_low = (__m128i)LODWORD(forward->z);
    v11 = _mm_cvtsi128_si32(y_low);
    v55 = _mm_cvtsi128_si32(z_low);
    if ( (_mm_cvtsi128_si32(x_low) & 0x7F800000) != 0x7F800000 )
      v8 = FMOD_RESULT::FMOD_OK_0;
    v12 = (v11 & 0x7F800000) == 2139095040;
    v13 = result;
    if ( !v12 )
      v13 = FMOD_RESULT::FMOD_OK_0;
    v14 = v8 | v13;
    if ( (v55 & 0x7F800000) != 0x7F800000 )
      result = FMOD_RESULT::FMOD_OK_0;
    result |= v14;
    if ( result )
      return result;
    v15 = (float)((float)(*(float *)x_low.m128i_i32 * *(float *)x_low.m128i_i32)
                + (float)(*(float *)y_low.m128i_i32 * *(float *)y_low.m128i_i32))
        + (float)(*(float *)z_low.m128i_i32 * *(float *)z_low.m128i_i32);
    if ( v15 > 1.1 || v15 < 0.89999998 )
      return FMOD_RESULT::FMOD_ERR_INVALID_VECTOR_0;
    v16 = (float *)((char *)off_11020 + (_QWORD)this + 112 * listener);
    if ( *(float *)x_low.m128i_i32 != v16[1]
      || *(float *)y_low.m128i_i32 != v16[2]
      || *(float *)z_low.m128i_i32 != v16[3] )
    {
      this->mListener[listener].mRotated = 1;
    }
    v17 = (char *)this + 112 * listener;
    *(_QWORD *)(v17 + 69668) = *(__int64 *)((char *)&qword_11018 + (_QWORD)v17);
    *((_DWORD *)v17 + 17419) = *(_DWORD *)((char *)off_11020 + (_QWORD)v17);
    *(__int64 *)((char *)&qword_11018 + (_QWORD)v17) = *(_QWORD *)&forward->x;
    *(float *)((char *)off_11020 + (_QWORD)v17) = forward->z;
  }
  if ( up )
  {
    v18 = (__m128i)LODWORD(up->x);
    v19 = 29;
    v20 = 29;
    v21 = (__m128i)LODWORD(up->y);
    v22 = (__m128i)LODWORD(up->z);
    v23 = _mm_cvtsi128_si32(v21);
    v56 = _mm_cvtsi128_si32(v22);
    if ( (_mm_cvtsi128_si32(v18) & 0x7F800000) != 0x7F800000 )
      v20 = 0;
    v12 = (v23 & 0x7F800000) == 2139095040;
    v24 = 29;
    if ( !v12 )
      v24 = 0;
    v25 = v20 | v24;
    if ( (v56 & 0x7F800000) != 0x7F800000 )
      v19 = 0;
    result = v25 | v19;
    if ( result )
      return result;
    v26 = (float)((float)(*(float *)v18.m128i_i32 * *(float *)v18.m128i_i32)
                + (float)(*(float *)v21.m128i_i32 * *(float *)v21.m128i_i32))
        + (float)(*(float *)v22.m128i_i32 * *(float *)v22.m128i_i32);
    if ( v26 <= 1.1 && v26 >= 0.89999998 )
    {
      if ( *(float *)v18.m128i_i32 != this->mListener[listener].mLastUp.x
        || *(float *)v21.m128i_i32 != this->mListener[listener].mLastUp.y
        || *(float *)v22.m128i_i32 != this->mListener[listener].mLastUp.z )
      {
        this->mListener[listener].mRotated = 1;
      }
      v27 = (char *)this + 112 * listener;
      *(_QWORD *)(v27 + 69644) = *((_QWORD *)v27 + 8704);
      *((_DWORD *)v27 + 17413) = *((_DWORD *)v27 + 17410);
      *(FMOD_VECTOR *)(v27 + 69632) = *up;
      goto LABEL_34;
    }
    return FMOD_RESULT::FMOD_ERR_INVALID_VECTOR_0;
  }
LABEL_34:
  if ( pos )
  {
    y = pos->y;
    v29 = 29;
    v30 = 29;
    if ( (LODWORD(pos->x) & 0x7F800000) != 0x7F800000 )
      v30 = 0;
    v31 = 29;
    if ( (LODWORD(y) & 0x7F800000) != 0x7F800000 )
      v31 = 0;
    v32 = v30 | v31;
    z = pos->z;
    if ( (LODWORD(z) & 0x7F800000) != 0x7F800000 )
      v29 = 0;
    result = v32 | v29;
    if ( result )
      return result;
    if ( pos->x != this->mListener[listener].mLastPosition.x
      || y != this->mListener[listener].mLastPosition.y
      || z != this->mListener[listener].mLastPosition.z )
    {
      this->mListener[listener].mMoved = 1;
    }
    v34 = *(_QWORD *)&pos->x;
    v35 = &this->mListener[listener];
    *(_QWORD *)&v35->mPosition.x = *(_QWORD *)&pos->x;
    v36 = pos->z;
    *(_QWORD *)&v35->mLastPosition.x = v34;
    v35->mPosition.z = v36;
    v35->mLastPosition.z = v36;
  }
  v37 = listener;
  if ( !vel )
    goto LABEL_60;
  v38 = vel->y;
  v39 = 29;
  v40 = 29;
  if ( (LODWORD(vel->x) & 0x7F800000) != 0x7F800000 )
    v40 = 0;
  v41 = 29;
  if ( (LODWORD(v38) & 0x7F800000) != 0x7F800000 )
    v41 = 0;
  v42 = v40 | v41;
  v43 = vel->z;
  if ( (LODWORD(v43) & 0x7F800000) != 0x7F800000 )
    v39 = 0;
  result = v42 | v39;
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    v37 = listener;
    v44 = 16LL * listener;
    if ( vel->x != *(float *)((char *)&this->mListener[0].mLastVelocity.x + (v37 << 7) - v44)
      || v38 != *(float *)((char *)&this->mListener[0].mLastVelocity.y + (v37 << 7) - v44)
      || v43 != *(float *)((char *)&this->mListener[0].mLastVelocity.z + (v37 << 7) - v44) )
    {
      this->mListener[v37].mMoved = 1;
    }
    v45 = (char *)this + 112 * v37;
    *(_QWORD *)(v45 + 69620) = *((_QWORD *)v45 + 8701);
    *((_DWORD *)v45 + 17407) = *((_DWORD *)v45 + 17404);
    *(FMOD_VECTOR *)(v45 + 69608) = *vel;
LABEL_60:
    x = this->mListener[v37].mUp.x;
    v47 = this->mListener[v37].mUp.y;
    v48 = this->mListener[v37].mUp.z;
    v49 = (float *)((char *)&off_11010 + (_QWORD)this + 112 * v37);
    v50 = v49[2];
    v51 = v49[3];
    v52 = v49[4];
    if ( (this->mFlags & 4) != 0 )
    {
      v48 = -v48;
      v52 = -v52;
    }
    v53 = (float)((float)(v50 * x) + (float)(v47 * v51)) + (float)(v48 * v52);
    if ( v53 <= 0.0099999998 && v53 >= -0.0099999998 )
    {
      v54 = (float *)((char *)this + 112 * v37);
      v54[17420] = (float)(v47 * v52) - (float)(v48 * v51);
      v54[17421] = (float)(v48 * v50) - (float)(v52 * x);
      v54[17422] = (float)(v51 * x) - (float)(v47 * v50);
      return FMOD_RESULT::FMOD_OK_0;
    }
    return FMOD_RESULT::FMOD_ERR_INVALID_VECTOR_0;
  }
  return result;
}


// Address: 0x21ca7e0 | Name: _ZN4FMOD7SystemI20set3DRolloffCallbackEPFfP19FMOD_CHANNELCONTROLfE
FMOD_RESULT_0 __fastcall FMOD::SystemI::set3DRolloffCallback(
        FMOD::SystemI *const this,
        FMOD_3D_ROLLOFF_CALLBACK callback)
{
  this->mRolloffCallback = callback;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ca7f0 | Name: _ZN4FMOD7SystemI17get3DNumListenersEPi
FMOD_RESULT_0 __fastcall FMOD::SystemI::get3DNumListeners(FMOD::SystemI *const this, int *numlisteners)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numlisteners )
  {
    *numlisteners = this->mNumListeners;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21ca810 | Name: _ZN4FMOD7SystemI23get3DListenerAttributesEiP11FMOD_VECTORS2_S2_S2_
FMOD_RESULT_0 __fastcall FMOD::SystemI::get3DListenerAttributes(
        FMOD::SystemI *const this,
        int listener,
        FMOD_VECTOR *pos,
        FMOD_VECTOR *vel,
        FMOD_VECTOR *forward,
        FMOD_VECTOR *up)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (unsigned int)listener <= 7 )
  {
    if ( pos )
      *pos = this->mListener[listener].mPosition;
    if ( vel )
      *vel = *(FMOD_VECTOR *)((char *)&stru_10FE0.r_info + (_QWORD)this + 112 * listener);
    if ( forward )
      *forward = *(FMOD_VECTOR *)((char *)&off_11010 + (_QWORD)this + 112 * listener + 8);
    if ( up )
      *up = this->mListener[listener].mUp;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21ca8e0 | Name: _ZN4FMOD7SystemI13get3DSettingsEPfS1_S1_
FMOD_RESULT_0 __fastcall FMOD::SystemI::get3DSettings(
        FMOD::SystemI *const this,
        float *dopplerscale,
        float *distancescale,
        float *rolloffscale)
{
  if ( dopplerscale )
    *dopplerscale = this->mDopplerScale;
  if ( distancescale )
    *distancescale = this->mDistanceScale;
  if ( rolloffscale )
    *rolloffscale = *(float *)((char *)&stru_11358.r_offset + (_QWORD)this);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21ca920 | Name: _ZN4FMOD7SystemI12mixerSuspendEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::mixerSuspend(FMOD::SystemI *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD::Output *mOutput; // rdi
  unsigned int (__fastcall *suspend)(FMOD_OUTPUT_STATE *, __int64); // rax

  result = FMOD_RESULT::FMOD_OK_0;
  if ( this->mInitialized && !*((_BYTE *)&stru_11688.r_offset + (_QWORD)this) )
  {
    mOutput = this->mOutput;
    suspend = (unsigned int (__fastcall *)(FMOD_OUTPUT_STATE *, __int64))mOutput->mDescription.suspend;
    if ( !suspend || (result = suspend(&mOutput->FMOD_OUTPUT_STATE, 1)) == FMOD_RESULT::FMOD_OK_0 )
    {
      *((_BYTE *)&stru_11688.r_offset + (_QWORD)this) = 1;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21ca970 | Name: _ZN4FMOD7SystemI11mixerResumeEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::mixerResume(FMOD::SystemI *const this)
{
  FMOD_RESULT_0 result; // eax
  FMOD::Output *mOutput; // rdi
  unsigned int (__fastcall *suspend)(_QWORD, _QWORD); // rax

  result = FMOD_RESULT::FMOD_OK_0;
  if ( this->mInitialized )
  {
    if ( *((_BYTE *)&stru_11688.r_offset + (_QWORD)this) )
    {
      mOutput = this->mOutput;
      suspend = (unsigned int (__fastcall *)(_QWORD, _QWORD))mOutput->mDescription.suspend;
      if ( !suspend || (result = suspend(&mOutput->FMOD_OUTPUT_STATE, 0)) == FMOD_RESULT::FMOD_OK_0 )
      {
        *((_BYTE *)&stru_11688.r_offset + (_QWORD)this) = 0;
        return FMOD_RESULT::FMOD_OK_0;
      }
    }
  }
  return result;
}


// Address: 0x21ca9b0 | Name: _ZN4FMOD7SystemI10getVersionEPj
FMOD_RESULT_0 __fastcall FMOD::SystemI::getVersion(FMOD::SystemI *const this, unsigned int *version)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( version )
  {
    *version = 131074;
    LOBYTE(result) = 0;
  }
  return result;
}


// Address: 0x21ca9d0 | Name: _ZN4FMOD7SystemI15getOutputHandleEPPv
FMOD_RESULT_0 __fastcall FMOD::SystemI::getOutputHandle(FMOD::SystemI *const this, void **handle)
{
  FMOD::Output *mOutput; // rdi
  FMOD_RESULT_0 (__fastcall *gethandle)(FMOD_OUTPUT_STATE *); // rax

  if ( !handle )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mOutput = this->mOutput;
  if ( !mOutput )
    return FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  gethandle = (FMOD_RESULT_0 (__fastcall *)(FMOD_OUTPUT_STATE *))mOutput->mDescription.gethandle;
  if ( gethandle )
    return gethandle(&mOutput->FMOD_OUTPUT_STATE);
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21caa10 | Name: _ZN4FMOD7SystemI18getChannelsPlayingEPiS1_
FMOD_RESULT_0 __fastcall FMOD::SystemI::getChannelsPlaying(FMOD::SystemI *const this, int *channels, int *realchannels)
{
  if ( channels )
    *channels = this->mNumChannelsPlaying;
  if ( realchannels )
    return FMOD::ChannelPool::getChannelsUsed(this->mSoftware->mChannelPool, realchannels);
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21caa40 | Name: _ZN4FMOD7SystemI11getCPUUsageEPfS1_S1_S1_S1_
FMOD_RESULT_0 __fastcall FMOD::SystemI::getCPUUsage(
        FMOD::SystemI *const this,
        float *dsp,
        float *stream,
        float *geometry,
        float *update,
        float *total)
{
  float totalcpu; // [rsp+4h] [rbp-54h]
  float usage[15]; // [rsp+1Ch] [rbp-3Ch] BYREF

  totalcpu = 0.0;
  if ( FMOD::TimeStamp::getCPUUsage(&this->mDSPTimeStamp, usage) == FMOD_RESULT::FMOD_OK_0 )
  {
    totalcpu = usage[0] + 0.0;
    if ( dsp )
      *dsp = usage[0];
  }
  if ( FMOD::TimeStamp::getCPUUsage(&this->mStreamTimeStamp, usage) == FMOD_RESULT::FMOD_OK_0 )
  {
    totalcpu = totalcpu + usage[0];
    if ( stream )
      *stream = usage[0];
  }
  if ( FMOD::TimeStamp::getCPUUsage(&this->mGeometryTimeStamp, usage) == FMOD_RESULT::FMOD_OK_0 )
  {
    totalcpu = totalcpu + usage[0];
    if ( geometry )
      *geometry = usage[0];
  }
  if ( FMOD::TimeStamp::getCPUUsage(&this->mUpdateTimeStamp, usage) == FMOD_RESULT::FMOD_OK_0 )
  {
    totalcpu = totalcpu + usage[0];
    if ( update )
      *update = usage[0];
  }
  if ( total )
    *total = totalcpu;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cab60 | Name: _ZN4FMOD7SystemI12getFileUsageEPxS1_S1_
FMOD_RESULT_0 __fastcall FMOD::SystemI::getFileUsage(
        FMOD::SystemI *const this,
        __int64 *sampleBytesRead,
        __int64 *streamBytesRead,
        __int64 *otherBytesRead)
{
  if ( sampleBytesRead )
    *sampleBytesRead = this->mFileBytesRead[0].m_value;
  if ( streamBytesRead )
    *streamBytesRead = this->mFileBytesRead[1].m_value;
  if ( otherBytesRead )
    *otherBytesRead = *(unsigned __int64 *)((char *)&stru_11520.r_offset + (_QWORD)this);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cab90 | Name: _ZN4FMOD7SystemI11createSoundEPKcjP22FMOD_CREATESOUNDEXINFOPPNS_6SoundIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::createSound(
        FMOD::SystemI *const this,
        const char *name_or_data,
        FMOD_MODE mode_in,
        FMOD_CREATESOUNDEXINFO *exinfo,
        FMOD::SoundI **sound)
{
  FMOD_RESULT_0 v5; // r14d
  FMOD_CREATESOUNDEXINFO *v11; // rbp
  size_t v12; // rdx
  FMOD_CREATESOUNDEXINFO *v13; // r8
  FMOD::Stream *v14; // rax
  FMOD::Stream *v15; // r14
  const char *dlsname; // rdi
  int inclusionlistnum; // eax
  int v18; // esi
  const char *encryptionkey; // rdi
  FMOD::AsyncData *mAsyncData; // rax
  FMOD::AsyncData *v21; // rdx
  FMOD_CREATESOUNDEXINFO *v22; // rsi
  FMOD_CREATESOUNDEXINFO *p_mExInfo; // rdi
  unsigned int v24; // eax
  __int64 v25; // rdx
  __int64 v26; // rcx
  int *v27; // rdi
  int *v28; // rsi
  FMOD_SOUNDGROUP *initialsoundgroup; // rsi
  FMOD::AsyncData *v30; // rax
  __int64 v31; // rdx
  int nonblockthreadid; // ebp
  char *v33; // r15
  const char *v34; // rsi
  const char *v35; // rsi
  FMOD_RESULT_0 AsyncThread; // ebx
  FMOD::AsyncData *v37; // rax
  FMOD::AsyncThread *mThread; // rdx
  FMOD_OS_CRITICALSECTION *mCrit; // rdi
  FMOD::AsyncData *v40; // rax
  FMOD_OS_SEMAPHORE *mSema; // rdi
  FMOD_RESULT_0 Sample; // eax
  FMOD::OutputSoftware *mSoftware; // rdi
  FMOD::Stream *v44; // r11
  FMOD::Stream *v45; // rdi
  int (**vptr_SoundI)(...); // rax
  __int64 v47; // rdx
  int *inclusionlist; // rax
  int v49; // edx
  __int16 cbsize; // dx
  int len; // [rsp+18h] [rbp-220h]
  int sizeof_dlsname; // [rsp+20h] [rbp-218h]
  int sizeof_asyncdataa; // [rsp+24h] [rbp-214h]
  int sizeof_asyncdata; // [rsp+24h] [rbp-214h]
  void **p_mName; // [rsp+28h] [rbp-210h]
  int inclusionListIndex; // [rsp+3Ch] [rbp-1FCh] BYREF
  FMOD_CREATESOUNDEXINFO localexinfo; // [rsp+40h] [rbp-1F8h] BYREF
  FMOD_CREATESOUNDEXINFO exinfo_copy; // [rsp+120h] [rbp-118h] BYREF

  v5 = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  if ( !this->mInitialized )
    return v5;
  LOBYTE(v5) = 31;
  if ( !sound )
    return v5;
  v11 = exinfo;
  if ( !name_or_data && (mode_in & 0x400) == 0 )
    return v5;
  if ( !exinfo )
  {
    *sound = 0;
    if ( (mode_in & 0x10000) == 0 )
      return FMOD::SystemI::createSoundInternal(
               this,
               name_or_data,
               mode_in,
               this->mStreamFileBufferSize,
               this->mStreamFileBufferSizeType,
               0,
               1,
               sound);
LABEL_11:
    if ( (mode_in & 0x80u) != 0 )
    {
      v14 = (FMOD::Stream *)FMOD::MemPool::calloc(
                              off_286F358->gSystemMemPool,
                              408,
                              "../../../core_api/src/fmod_systemi.cpp",
                              3920,
                              0);
      v15 = v14;
      if ( !v14 )
        return FMOD_RESULT::FMOD_ERR_MEMORY_0;
      FMOD::Stream::Stream(v14);
      *sound = v15;
LABEL_14:
      if ( v11 )
      {
        dlsname = v11->dlsname;
        inclusionlistnum = v11->inclusionlistnum;
        sizeof_dlsname = 0;
        v18 = 4 * inclusionlistnum + 296;
        if ( dlsname )
        {
          sizeof_asyncdataa = 4 * inclusionlistnum + 296;
          sizeof_dlsname = FMOD_strlen(dlsname) + 1;
          v18 = sizeof_dlsname + sizeof_asyncdataa;
        }
        encryptionkey = v11->encryptionkey;
        sizeof_asyncdata = 0;
        if ( encryptionkey )
        {
          sizeof_asyncdata = FMOD_strlen(encryptionkey) + 1;
          v18 += sizeof_asyncdata;
        }
      }
      else
      {
        sizeof_asyncdata = 0;
        sizeof_dlsname = 0;
        v18 = 296;
      }
      mAsyncData = (FMOD::AsyncData *)FMOD::MemPool::calloc(
                                        off_286F358->gSystemMemPool,
                                        v18,
                                        "../../../core_api/src/fmod_systemi.cpp",
                                        3968,
                                        0);
      v15->mAsyncData = mAsyncData;
      if ( mAsyncData )
      {
        if ( (mode_in & 0x10000800) != 0 )
        {
          mAsyncData->mNameData = (void *)name_or_data;
        }
        else if ( name_or_data )
        {
          len = FMOD_strlen(name_or_data) + 1;
          p_mName = (void **)&v15->mAsyncData->FMOD::SoundI::mName;
          *p_mName = FMOD::MemPool::alloc(
                       off_286F358->gSystemMemPool,
                       len,
                       "../../../core_api/src/fmod_systemi.cpp",
                       3982,
                       0,
                       0);
          memcpy_0(v15->mAsyncData->FMOD::SoundI::mName, name_or_data, len);
          mAsyncData = v15->mAsyncData;
        }
        mAsyncData->mBufferSize = this->mStreamFileBufferSize;
        mAsyncData->mBufferSizeType = this->mStreamFileBufferSizeType;
        v15->mMode = mode_in;
        v15->mSystem = this;
        v15->mOpenState.m_value = FMOD_OPENSTATE::FMOD_OPENSTATE_LOADING_0;
        _mm_mfence();
        if ( v11 )
        {
          v21 = v15->mAsyncData;
          v22 = v11;
          p_mExInfo = &v21->mExInfo;
          v15->mUserData = v11->userdata;
          v24 = 224;
          if ( (((_BYTE)v21 + 56) & 1) != 0 )
          {
            p_mExInfo = (FMOD_CREATESOUNDEXINFO *)((char *)&v21->mExInfo.cbsize + 1);
            v22 = (FMOD_CREATESOUNDEXINFO *)((char *)&v11->cbsize + 1);
            LOBYTE(v21->mExInfo.cbsize) = v11->cbsize;
            v24 = 223;
          }
          if ( ((unsigned __int8)p_mExInfo & 2) != 0 )
          {
            cbsize = v22->cbsize;
            p_mExInfo = (FMOD_CREATESOUNDEXINFO *)((char *)p_mExInfo + 2);
            v22 = (FMOD_CREATESOUNDEXINFO *)((char *)v22 + 2);
            v24 -= 2;
            HIWORD(p_mExInfo[-1].fsbguid) = cbsize;
          }
          if ( ((unsigned __int8)p_mExInfo & 4) != 0 )
          {
            v49 = v22->cbsize;
            p_mExInfo = (FMOD_CREATESOUNDEXINFO *)((char *)p_mExInfo + 4);
            v22 = (FMOD_CREATESOUNDEXINFO *)((char *)v22 + 4);
            v24 -= 4;
            HIDWORD(p_mExInfo[-1].fsbguid) = v49;
          }
          v25 = 0;
          v26 = v24 >> 3;
          qmemcpy(p_mExInfo, v22, 8 * v26);
          v28 = &v22->cbsize + 2 * v26;
          v27 = &p_mExInfo->cbsize + 2 * v26;
          if ( (v24 & 4) != 0 )
          {
            *v27 = *v28;
            v25 = 4;
          }
          if ( (v24 & 2) != 0 )
          {
            *(_WORD *)((char *)v27 + v25) = *(_WORD *)((char *)v28 + v25);
            v25 += 2;
          }
          if ( (v24 & 1) != 0 )
            *((_BYTE *)v27 + v25) = *((_BYTE *)v28 + v25);
          initialsoundgroup = v11->initialsoundgroup;
          v30 = v15->mAsyncData;
          v30->mExInfoExists = 1;
          if ( initialsoundgroup )
          {
            (*((void (__fastcall **)(FMOD::Stream *, FMOD_SOUNDGROUP *, __int64))v15->_vptr_SoundI + 27))(
              v15,
              initialsoundgroup,
              v25);
            v30 = v15->mAsyncData;
          }
          v31 = v30->mExInfo.inclusionlistnum;
          nonblockthreadid = v11->nonblockthreadid;
          v33 = (char *)&v30[1];
          if ( (_DWORD)v31 )
          {
            memcpy_0(&v30[1], v30->mExInfo.inclusionlist, 4 * v31);
            v30 = v15->mAsyncData;
            v47 = v30->mExInfo.inclusionlistnum;
            v30->mExInfo.inclusionlist = (int *)v33;
            v33 += 4 * v47;
          }
          v34 = v30->mExInfo.dlsname;
          if ( v34 )
          {
            FMOD_strcpy_safe(v33, v34, sizeof_dlsname);
            v30 = v15->mAsyncData;
            v30->mExInfo.dlsname = v33;
            v33 += sizeof_dlsname;
          }
          v35 = v30->mExInfo.encryptionkey;
          if ( v35 )
          {
            FMOD_strcpy_safe(v33, v35, sizeof_asyncdata);
            v30 = v15->mAsyncData;
            v30->mExInfo.encryptionkey = v33;
          }
        }
        else
        {
          v30 = v15->mAsyncData;
          v15->mUserData = 0;
          nonblockthreadid = 0;
          v30->mExInfoExists = 0;
        }
        AsyncThread = FMOD::AsyncThread::getAsyncThread(this, nonblockthreadid, &v30->mThread);
        if ( AsyncThread )
        {
          v15->mOpenState.m_value = FMOD_OPENSTATE::FMOD_OPENSTATE_ERROR_0;
          v45 = v15;
          _mm_mfence();
          vptr_SoundI = v15->_vptr_SoundI;
          v5 = AsyncThread;
          vptr_SoundI[3](v45, 1);
          *sound = 0;
        }
        else
        {
          FMOD_OS_CriticalSection_Enter(v15->mAsyncData->mThread->mCrit);
          v15->mAsyncData->mNode.mNodeData = v15;
          v37 = v15->mAsyncData;
          mThread = v37->mThread;
          mCrit = mThread->mCrit;
          v37->mNode.mNodePrev = mThread->mHead.mNodePrev;
          v37->mNode.mNodeNext = &mThread->mHead;
          mThread->mHead.mNodePrev = &v37->mNode;
          v37->mNode.mNodePrev->mNodeNext = &v37->mNode;
          FMOD_OS_CriticalSection_Leave(mCrit);
          v40 = v15->mAsyncData;
          v5 = FMOD_RESULT::FMOD_OK_0;
          mSema = v40->mThread->mThread.mSema;
          if ( mSema )
            FMOD_OS_Semaphore_Signal(mSema);
        }
        return v5;
      }
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    }
    mSoftware = this->mSoftware;
    *(_QWORD *)&exinfo_copy.cbsize = 0;
    Sample = FMOD::OutputSoftware::createSample(mSoftware, 0, 0, (FMOD::Sample **)&exinfo_copy);
    if ( Sample == FMOD_RESULT::FMOD_OK_0 )
    {
      v44 = *(FMOD::Stream **)&exinfo_copy.cbsize;
      *sound = *(FMOD::SoundI **)&exinfo_copy.cbsize;
      v15 = v44;
      goto LABEL_14;
    }
    return Sample;
  }
  v12 = exinfo->cbsize;
  v5 = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (unsigned int)(v12 - 4) > 0xDC || (v12 & 3) != 0 )
    return v5;
  memset(&localexinfo, 0, sizeof(localexinfo));
  v13 = (FMOD_CREATESOUNDEXINFO *)memcpy_0(&localexinfo, exinfo, v12);
  if ( !v11->inclusionlistnum )
  {
    inclusionlist = v11->inclusionlist;
    if ( ((unsigned __int8)inclusionlist & 1) != 0 )
    {
      localexinfo.inclusionlistnum = 1;
      inclusionListIndex = (unsigned __int64)inclusionlist >> 1;
      localexinfo.inclusionlist = &inclusionListIndex;
    }
  }
  *sound = 0;
  if ( (mode_in & 0x10000) != 0 )
  {
    v11 = v13;
    goto LABEL_11;
  }
  qmemcpy(&exinfo_copy, v13, sizeof(exinfo_copy));
  Sample = FMOD::SystemI::createSoundInternal(
             this,
             name_or_data,
             mode_in,
             this->mStreamFileBufferSize,
             this->mStreamFileBufferSizeType,
             &exinfo_copy,
             1,
             sound);
  if ( !*sound )
    return Sample;
  v5 = Sample;
  if ( localexinfo.initialsoundgroup )
    (*((void (__fastcall **)(FMOD::SoundI *))(*sound)->_vptr_SoundI + 27))(*sound);
  return v5;
}


// Address: 0x21cb1c0 | Name: _ZN4FMOD7SystemI12createStreamEPKcjP22FMOD_CREATESOUNDEXINFOPPNS_6SoundIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::createStream(
        FMOD::SystemI *const this,
        const char *name_or_data,
        FMOD_MODE mode_in,
        FMOD_CREATESOUNDEXINFO *exinfo,
        FMOD::SoundI **sound)
{
  LOBYTE(mode_in) = mode_in | 0x80;
  return FMOD::SystemI::createSound(this, name_or_data, mode_in, exinfo, sound);
}


// Address: 0x21cb1d0 | Name: _ZN4FMOD7SystemI9createDSPEPK20FMOD_DSP_DESCRIPTIONPPNS_4DSPIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::createDSP(
        FMOD::SystemI *const this,
        const FMOD_DSP_DESCRIPTION_0 *description_in,
        FMOD::DSPI **dsp)
{
  FMOD::PluginFactory *mPluginFactory; // rdi
  FMOD_RESULT_0 result; // eax

  if ( !dsp )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *dsp = 0;
  if ( !description_in )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  mPluginFactory = this->mPluginFactory;
  result = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  if ( mPluginFactory )
  {
    result = FMOD::PluginFactory::createDSP(mPluginFactory, 0, description_in, dsp);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      (*dsp)->mSystem = this;
  }
  return result;
}


// Address: 0x21cb230 | Name: _ZN4FMOD7SystemI15createDSPByTypeE13FMOD_DSP_TYPEPPNS_4DSPIE
__int64 __fastcall FMOD::SystemI::createDSPByType(FMOD::SystemI *this, FMOD_DSP_TYPE a2, FMOD::DSPI **a3)
{
  unsigned int DSPByType; // ebx
  FMOD::PluginFactory *mPluginFactory; // rdi
  FMOD_RESULT_0 DSP; // eax
  FMOD::FMOD_DSP_DESCRIPTION_EX desc; // [rsp+0h] [rbp-58h] BYREF

  DSPByType = 67;
  if ( this->mPluginFactory )
  {
    if ( a3 && (*a3 = 0, a2 <= FMOD_DSP_TYPE_MULTIBAND_EQ) && a2 )
    {
      if ( a2 == FMOD_DSP_TYPE_MIXER )
      {
        memset(&desc, 0, sizeof(desc));
        desc.mName = "FMOD Mixer unit";
        *(&desc.mHandle + 1) = 1;
        return (unsigned int)FMOD::SystemI::createDSP(this, &desc, 0, a3, 1);
      }
      else
      {
        mPluginFactory = this->mPluginFactory;
        desc.mDescription = 0;
        DSPByType = FMOD::PluginFactory::getDSPByType(mPluginFactory, a2, (FMOD::FMOD_DSP_DESCRIPTION_PLUGIN **)&desc);
        if ( !DSPByType )
        {
          DSP = FMOD::PluginFactory::createDSP(
                  this->mPluginFactory,
                  (FMOD::FMOD_DSP_DESCRIPTION_EX *)desc.mDescription,
                  0,
                  a3);
          if ( DSP )
            return (unsigned int)DSP;
        }
      }
    }
    else
    {
      return 31;
    }
  }
  return DSPByType;
}


// Address: 0x21cb300 | Name: _ZN4FMOD7SystemI18createChannelGroupEPKcPPNS_13ChannelGroupIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::createChannelGroup(
        FMOD::SystemI *const this,
        const char *name,
        FMOD::ChannelGroupI **channelgroup)
{
  if ( channelgroup )
    return FMOD::SystemI::createChannelGroupInternal(this, name, channelgroup, 1);
  else
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
}


// Address: 0x21cb320 | Name: _ZN4FMOD7SystemI16createSoundGroupEPKcPPNS_11SoundGroupIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::createSoundGroup(
        FMOD::SystemI *const this,
        const char *name,
        FMOD::SoundGroupI **soundgroup)
{
  FMOD_RESULT_0 result; // eax
  FMOD_OS_CRITICALSECTION *gSoundListCrit; // r12
  FMOD::SoundGroupI *v6; // rax
  FMOD::SoundGroupI *v7; // rbx
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::Global *v9; // rax
  char *v10; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  gSoundListCrit = off_286F358->gSoundListCrit;
  if ( soundgroup )
  {
    v6 = (FMOD::SoundGroupI *)FMOD::MemPool::calloc(
                                off_286F358->gSystemMemPool,
                                128,
                                "../../../core_api/src/fmod_systemi.cpp",
                                4253,
                                0);
    v7 = v6;
    if ( !v6 )
      return FMOD_RESULT::FMOD_ERR_MEMORY_0;
    FMOD::SoundGroupI::SoundGroupI(v6);
    FMOD_OS_CriticalSection_Enter(off_286F358->gSoundListCrit);
    mNodeNext = this->mSoundGroupFreeHead.mNodeNext;
    v7->mNodePrev = &this->mSoundGroupFreeHead;
    v7->mNodeNext = mNodeNext;
    mNodeNext->mNodePrev = v7;
    v7->mNodePrev->FMOD::LinkedListNode::mNodeNext = v7;
    v9 = off_286F358;
    v7->mSystem = this;
    FMOD_OS_CriticalSection_Leave(v9->gSoundListCrit);
    if ( !name )
    {
      v7->mName = 0;
      goto LABEL_5;
    }
    v10 = FMOD_strdup(name);
    v7->mName = v10;
    if ( v10 )
    {
LABEL_5:
      *soundgroup = v7;
      return FMOD_RESULT::FMOD_OK_0;
    }
    if ( gSoundListCrit )
    {
      FMOD_OS_CriticalSection_Enter(gSoundListCrit);
      FMOD::SoundGroupI::release(v7);
      FMOD_OS_CriticalSection_Leave(gSoundListCrit);
    }
    else
    {
      FMOD::SoundGroupI::release(v7);
    }
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
  return result;
}


// Address: 0x21cb470 | Name: _ZN4FMOD7SystemI9playSoundEPNS_6SoundIEPNS_13ChannelGroupIEbPPNS_8ChannelIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::playSound(
        FMOD::SystemI *const this,
        FMOD::SoundI *sound,
        FMOD::ChannelGroupI *channelgroup,
        bool paused,
        FMOD::ChannelI **channel)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SoundGroupI *mSoundGroup; // rdi
  FMOD::SoundGroupI *v11; // rax
  FMOD_SOUNDGROUP_BEHAVIOR mMaxAudibleBehavior; // edx
  int mIndex; // r8d
  char v14; // r15
  FMOD_RESULT_0 v15; // ebp
  FMOD::SystemI *mNodeNext; // r15
  FMOD::LinkedListNode *v17; // rcx
  float v18; // xmm0_4
  float *p_audibility; // r9
  FMOD::DSPI **p_mDSP; // rdx
  FMOD::DSPI *v21; // rax
  __int64 v22; // rax
  FMOD::ChannelI *v23; // [rsp+0h] [rbp-68h]
  float *v24; // [rsp+8h] [rbp-60h]
  int channelid; // [rsp+10h] [rbp-58h]
  FMOD::LinkedListNode *v26; // [rsp+18h] [rbp-50h]
  int numplaying; // [rsp+20h] [rbp-48h] BYREF
  float audibility; // [rsp+24h] [rbp-44h] BYREF
  FMOD::ChannelI *chan; // [rsp+28h] [rbp-40h] BYREF

  chan = 0;
  if ( channel )
    *channel = 0;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( !sound )
    return result;
  LOBYTE(result) = 46;
  if ( sound->mOpenState.m_value )
    return result;
  LOBYTE(result) = 19;
  if ( sound->mType == FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_PLAYLIST_0 )
    return result;
  mSoundGroup = sound->mSoundGroup;
  if ( mSoundGroup && mSoundGroup->mMaxAudible >= 0 )
  {
    result = FMOD::SoundGroupI::getNumPlaying(mSoundGroup, &numplaying);
    if ( result )
      return result;
    v11 = sound->mSoundGroup;
    if ( v11->mMaxAudible <= numplaying )
    {
      mMaxAudibleBehavior = v11->mMaxAudibleBehavior;
      if ( mMaxAudibleBehavior == FMOD_SOUNDGROUP_BEHAVIOR::FMOD_SOUNDGROUP_BEHAVIOR_MUTE )
      {
        mIndex = -1;
        v14 = 1;
        goto LABEL_16;
      }
      if ( mMaxAudibleBehavior == FMOD_SOUNDGROUP_BEHAVIOR::FMOD_SOUNDGROUP_BEHAVIOR_STEALLOWEST )
      {
        mNodeNext = (FMOD::SystemI *)this->mChannelUsedListHead.mNodeNext;
        v17 = &this->mChannelUsedListHead.FMOD::LinkedListNode;
        if ( mNodeNext != (FMOD::SystemI *)&this->mChannelUsedListHead.FMOD::LinkedListNode )
        {
          v18 = 9999.0;
          mIndex = -1;
          p_audibility = &audibility;
          do
          {
            p_mDSP = 0;
            if ( mNodeNext )
              p_mDSP = &mNodeNext[-1].mReverb[1].mDSP;
            v21 = p_mDSP[59];
            if ( v21 )
            {
              v22 = *(_QWORD *)&v21->mJob.mDelayClock.mPitch;
              if ( v22 )
              {
                if ( sound->mSoundGroup == *(FMOD::SoundGroupI **)(v22 + 280) )
                {
                  v26 = v17;
                  channelid = mIndex;
                  v24 = p_audibility;
                  v23 = (FMOD::ChannelI *)p_mDSP;
                  ((void (__fastcall *)(FMOD::DSPI **, float *))(*p_mDSP)->mJob.mDelayClock.mDelayStartShadow)(
                    p_mDSP,
                    p_audibility);
                  p_audibility = v24;
                  mIndex = channelid;
                  v17 = v26;
                  if ( v18 > audibility )
                  {
                    chan = v23;
                    mIndex = v23->mIndex;
                    v18 = audibility;
                  }
                }
              }
            }
            mNodeNext = (FMOD::SystemI *)mNodeNext->_vptr_SystemI;
          }
          while ( mNodeNext != (FMOD::SystemI *)v17 );
          goto LABEL_15;
        }
      }
      else
      {
        result = FMOD_RESULT::FMOD_ERR_MAXAUDIBLE_0;
        if ( mMaxAudibleBehavior == FMOD_SOUNDGROUP_BEHAVIOR::FMOD_SOUNDGROUP_BEHAVIOR_FAIL )
          return result;
      }
    }
  }
  mIndex = -1;
LABEL_15:
  v14 = 0;
LABEL_16:
  result = FMOD::SystemI::findChannel(this, mIndex, sound, &chan);
  if ( result )
  {
LABEL_17:
    if ( channel )
      *channel = 0;
    return result;
  }
  v15 = FMOD::ChannelI::play(chan, sound, channelgroup, paused, 1, v14 & 1);
  if ( v15 )
  {
    if ( channel )
      *channel = 0;
    FMOD::ChannelI::stopEx(chan, 0x52u);
    return v15;
  }
  else
  {
    result = FMOD::ChannelI::updatePosition(chan);
    if ( result )
      goto LABEL_17;
    result = FMOD::ChannelI::referenceStamp(chan, 1);
    if ( result )
      goto LABEL_17;
    if ( channel )
      *channel = (FMOD::ChannelI *)chan->mHandleCurrent;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21cb6e0 | Name: _ZN4FMOD7SystemI7playDSPEPNS_4DSPIEPNS_13ChannelGroupIEbPPNS_8ChannelIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::playDSP(
        FMOD::SystemI *const this,
        FMOD::DSPI *dsp,
        FMOD::ChannelGroupI *channelgroup,
        bool paused,
        FMOD::ChannelI **channel)
{
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 v9; // ebx
  FMOD::ChannelI *chan; // [rsp+8h] [rbp-30h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  chan = 0;
  if ( dsp )
  {
    if ( channel )
      *channel = 0;
    result = FMOD::SystemI::findChannel(this, -1, dsp, &chan);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      result = FMOD::SystemI::stopDSP(this, dsp);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v9 = FMOD::ChannelI::play(chan, dsp, channelgroup, paused, 1, 0);
        if ( v9 )
        {
          FMOD::ChannelI::stopEx(chan, 0x52u);
          return v9;
        }
        else
        {
          result = FMOD::ChannelI::updatePosition(chan);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = FMOD::ChannelI::referenceStamp(chan, 1);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              if ( channel )
                *channel = (FMOD::ChannelI *)chan->mHandleCurrent;
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21cb7d0 | Name: _ZN4FMOD7SystemI10getChannelEiPPNS_8ChannelIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::getChannel(FMOD::SystemI *const this, int id, FMOD::ChannelI **channel)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channel && id >= 0 && id < this->mNumChannels )
  {
    *channel = (FMOD::ChannelI *)(((id & 0xFFF) << 17)
                                | (*(_DWORD *)((char *)&stru_115E0.r_offset + (_QWORD)this) << 29)
                                | 0x1FFFFu);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21cb810 | Name: _ZN4FMOD7SystemI21getMasterChannelGroupEPPNS_13ChannelGroupIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::getMasterChannelGroup(
        FMOD::SystemI *const this,
        FMOD::ChannelGroupI **channelgroup)
{
  FMOD_RESULT_0 result; // eax
  FMOD::ChannelGroupI *mMasterChannelGroup; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroup )
  {
    mMasterChannelGroup = this->mMasterChannelGroup;
    if ( mMasterChannelGroup )
    {
      *channelgroup = mMasterChannelGroup;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      *channelgroup = 0;
      return FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
    }
  }
  return result;
}


// Address: 0x21cb840 | Name: _ZN4FMOD7SystemI19getMasterSoundGroupEPPNS_11SoundGroupIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::getMasterSoundGroup(FMOD::SystemI *const this, FMOD::SoundGroupI **soundgroup)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SoundGroupI *mMasterSoundGroup; // rax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( soundgroup )
  {
    mMasterSoundGroup = this->mMasterSoundGroup;
    if ( mMasterSoundGroup )
    {
      *soundgroup = mMasterSoundGroup;
      return FMOD_RESULT::FMOD_OK_0;
    }
    else
    {
      *soundgroup = 0;
      return FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
    }
  }
  return result;
}


// Address: 0x21cb870 | Name: _ZN4FMOD7SystemI24attachChannelGroupToPortEjyPNS_13ChannelGroupIEb
FMOD_RESULT_0 __fastcall FMOD::SystemI::attachChannelGroupToPort(
        FMOD::SystemI *const this,
        FMOD_PORT_TYPE portType,
        FMOD_PORT_INDEX portIndex,
        FMOD::ChannelGroupI *channelgroup,
        bool passThru)
{
  FMOD_RESULT_0 result; // eax
  FMOD::Output *mOutput; // rdi
  FMOD::ChannelGroupI *mChannelGroupParent; // rdi
  int (**vptr_ChannelControlI)(...); // rax
  __int16 v11; // ax
  int i; // r12d
  int portId; // [rsp+8h] [rbp-60h] BYREF
  int numoutputs; // [rsp+Ch] [rbp-5Ch] BYREF
  FMOD::DSPI *port; // [rsp+10h] [rbp-58h] BYREF
  FMOD::DSPI *parent; // [rsp+18h] [rbp-50h] BYREF
  FMOD::DSPI *head; // [rsp+20h] [rbp-48h] BYREF
  FMOD::DSPConnectionI *connection; // [rsp+28h] [rbp-40h] BYREF
  FMOD::DSPI *dsp; // [rsp+30h] [rbp-38h] BYREF
  FMOD::DSPConnectionI *connection_0; // [rsp+38h] [rbp-30h] BYREF

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroup )
  {
    if ( channelgroup->mPortId == -1 )
    {
      if ( channelgroup->mChannelGroupParent )
      {
        mOutput = this->mOutput;
        LOBYTE(result) = 68;
        if ( mOutput->mDescription.openport )
        {
          port = 0;
          result = FMOD::Output::openport(mOutput, portType, portIndex, &portId, &port);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            mChannelGroupParent = channelgroup->mChannelGroupParent;
            parent = 0;
            result = (*((unsigned int (__fastcall **)(FMOD::ChannelGroupI *, __int64, FMOD::DSPI **))mChannelGroupParent->_vptr_ChannelControlI
                      + 36))(
                       mChannelGroupParent,
                       4294967293LL,
                       &parent);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              vptr_ChannelControlI = channelgroup->_vptr_ChannelControlI;
              head = 0;
              result = vptr_ChannelControlI[36](channelgroup, 0xFFFFFFFFLL, &head);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                FMOD::DSPI::addInput(
                  port,
                  head,
                  &connection,
                  FMOD_DSPCONNECTION_TYPE::FMOD_DSPCONNECTION_TYPE_STANDARD_0,
                  1,
                  0);
                FMOD::DSPConnectionI::setUserData(connection, (void *)(portId | 0xFEED0000));
                if ( !passThru )
                {
                  FMOD::DSPI::getNumOutputsInternal(head, &numoutputs, 0, 1);
                  if ( numoutputs > 0 )
                  {
                    for ( i = 0; i < numoutputs; ++i )
                    {
                      FMOD::DSPI::getOutputInternal(head, i, &dsp, &connection_0, 0, 1);
                      if ( dsp == parent )
                        FMOD::DSPConnectionI::setMix(connection_0, 0.0, 0, 1, 0);
                    }
                  }
                }
                v11 = portId;
                channelgroup->mPortPassthru = passThru;
                channelgroup->mPortId = v11;
                return FMOD_RESULT::FMOD_OK_0;
              }
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21cba00 | Name: _ZN4FMOD7SystemI26detachChannelGroupFromPortEPNS_13ChannelGroupIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::detachChannelGroupFromPort(
        FMOD::SystemI *const this,
        FMOD::ChannelGroupI *channelgroup)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( channelgroup && channelgroup->mPortId != -1 )
  {
    LOBYTE(result) = 68;
    if ( this->mOutput->mDescription.closeport )
    {
      FMOD::ChannelGroupI::disconnectFromPort(channelgroup);
      channelgroup->mPortId = -1;
      channelgroup->mPortPassthru = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21cba60 | Name: _ZN4FMOD7SystemI14createReverb3DEPPNS_7ReverbIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::createReverb3D(FMOD::SystemI *const this, FMOD::ReverbI **reverb)
{
  FMOD::ReverbI *v2; // rax
  FMOD::ReverbI *v3; // rbx
  FMOD_RESULT_0 v4; // eax
  FMOD_RESULT_0 result; // [rsp+Ch] [rbp-2Ch]

  v2 = (FMOD::ReverbI *)FMOD::MemPool::alloc(
                          off_286F358->gSystemMemPool,
                          120,
                          "../../../core_api/src/fmod_systemi.cpp",
                          4710,
                          0,
                          0);
  v3 = v2;
  if ( !v2 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  FMOD::ReverbI::ReverbI(v2);
  v4 = FMOD::ReverbI::init(v3, this);
  if ( v4 )
  {
    result = v4;
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v3, "../../../core_api/src/fmod_systemi.cpp", 4722);
    return result;
  }
  else
  {
    v3->mNode.mNodePrev = this->mReverb3DHead.mNodePrev;
    v3->mNode.mNodeNext = (FMOD::LinkedListNode *)((char *)&stru_125B8 + (_QWORD)this);
    this->mReverb3DHead.mNodePrev = &v3->mNode;
    v3->mNode.mNodePrev->mNodeNext = &v3->mNode;
    v3->mNode.mNodeData = v3;
    if ( reverb )
      *reverb = v3;
    return FMOD_RESULT::FMOD_OK_0;
  }
}


// Address: 0x21cbb60 | Name: _ZN4FMOD7SystemI19setReverbPropertiesEiPK22FMOD_REVERB_PROPERTIES
FMOD_RESULT_0 __fastcall FMOD::SystemI::setReverbProperties(
        FMOD::SystemI *const this,
        int instance,
        const FMOD_REVERB_PROPERTIES *prop)
{
  __m128 v4; // xmm1
  int v5; // xmm0_4
  __m128 v6; // xmm0
  __m128 v7; // xmm3
  float v8; // xmm0_4
  float v9; // xmm1_4
  __m128 v10; // xmm1
  __m128 v11; // xmm3
  float v12; // xmm1_4
  __m128 v13; // xmm1
  __m128 v14; // xmm4
  float v15; // xmm3_4
  __m128 v16; // xmm3
  __m128 v17; // xmm4
  float v18; // xmm3_4
  __m128 v19; // xmm3
  __m128 v20; // xmm4
  float v21; // xmm3_4
  __m128 v22; // xmm3
  __m128 v23; // xmm4
  unsigned __int32 v24; // xmm3_4
  __m128 v25; // xmm3
  __m128 v26; // xmm4
  float v27; // xmm3_4
  __m128 v28; // xmm3
  __m128 v29; // xmm4
  float v30; // xmm3_4
  __m128 v31; // xmm3
  __m128 v32; // xmm4
  float v33; // xmm3_4
  __m128 v34; // xmm3
  __m128 v35; // xmm3
  __m128 v36; // xmm0
  __m128 v37; // xmm2
  float v38; // xmm0_4
  __m128 v39; // xmm0

  if ( (unsigned int)instance > 3 )
    return FMOD_RESULT::FMOD_ERR_REVERB_INSTANCE_0;
  if ( prop )
  {
    v4.m128_i32[0] = LODWORD(prop->DecayTime);
    v5 = 1120403456;
    if ( prop->DecayTime >= 100.0 )
    {
      v6 = _mm_cmpge_ss((__m128)0x469C4000u, v4);
      v5 = _mm_andnot_ps(v6, (__m128)0x469C4000u).m128_u32[0] | v4.m128_i32[0] & v6.m128_i32[0];
    }
    v7.m128_i32[0] = LODWORD(prop->EarlyDelay);
    *(_DWORD *)((char *)&stru_124F8.r_offset + (_QWORD)this + 48 * instance) = v5;
    v8 = 0.0;
    v9 = 0.0;
    if ( v7.m128_f32[0] >= 0.0 )
    {
      v10 = _mm_cmpge_ss((__m128)0x43960000u, v7);
      LODWORD(v9) = _mm_andnot_ps(v10, (__m128)0x43960000u).m128_u32[0] | v7.m128_i32[0] & v10.m128_i32[0];
    }
    v11.m128_i32[0] = LODWORD(prop->LateDelay);
    this->mReverbProperties[instance].EarlyDelay = v9;
    v12 = 0.0;
    if ( v11.m128_f32[0] >= 0.0 )
    {
      v13 = _mm_cmpge_ss((__m128)0x42C80000u, v11);
      LODWORD(v12) = _mm_andnot_ps(v13, (__m128)0x42C80000u).m128_u32[0] | v11.m128_i32[0] & v13.m128_i32[0];
    }
    v14.m128_i32[0] = LODWORD(prop->HFReference);
    this->mReverbProperties[instance].LateDelay = v12;
    v15 = 20.0;
    if ( v14.m128_f32[0] >= 20.0 )
    {
      v16 = _mm_cmpge_ss((__m128)0x469C4000u, v14);
      LODWORD(v15) = _mm_andnot_ps(v16, (__m128)0x469C4000u).m128_u32[0] | v14.m128_i32[0] & v16.m128_i32[0];
    }
    v17.m128_i32[0] = LODWORD(prop->HFDecayRatio);
    this->mReverbProperties[instance].HFReference = v15;
    v18 = 10.0;
    if ( v17.m128_f32[0] >= 10.0 )
    {
      v19 = _mm_cmpge_ss((__m128)0x42C80000u, v17);
      LODWORD(v18) = _mm_andnot_ps(v19, (__m128)0x42C80000u).m128_u32[0] | v17.m128_i32[0] & v19.m128_i32[0];
    }
    v20.m128_i32[0] = LODWORD(prop->Diffusion);
    this->mReverbProperties[instance].HFDecayRatio = v18;
    v21 = 0.0;
    if ( v20.m128_f32[0] >= 0.0 )
    {
      v22 = _mm_cmpge_ss((__m128)0x42C80000u, v20);
      LODWORD(v21) = _mm_andnot_ps(v22, (__m128)0x42C80000u).m128_u32[0] | v20.m128_i32[0] & v22.m128_i32[0];
    }
    v23.m128_i32[0] = LODWORD(prop->Density);
    this->mReverbProperties[instance].Diffusion = v21;
    v24 = 0;
    if ( v23.m128_f32[0] >= 0.0 )
    {
      v25 = _mm_cmpge_ss((__m128)0x42C80000u, v23);
      v24 = _mm_andnot_ps(v25, (__m128)0x42C80000u).m128_u32[0] | v23.m128_i32[0] & v25.m128_i32[0];
    }
    v26.m128_i32[0] = LODWORD(prop->LowShelfFrequency);
    *(_DWORD *)((char *)&stru_12510.r_offset + (_QWORD)this + 48 * instance) = v24;
    v27 = 20.0;
    if ( v26.m128_f32[0] >= 20.0 )
    {
      v28 = _mm_cmpge_ss((__m128)0x447A0000u, v26);
      LODWORD(v27) = _mm_andnot_ps(v28, (__m128)0x447A0000u).m128_u32[0] | v26.m128_i32[0] & v28.m128_i32[0];
    }
    v29.m128_i32[0] = LODWORD(prop->LowShelfGain);
    this->mReverbProperties[instance].LowShelfFrequency = v27;
    v30 = -36.0;
    if ( v29.m128_f32[0] >= -36.0 )
    {
      v31 = _mm_cmpge_ss((__m128)0x41400000u, v29);
      LODWORD(v30) = _mm_andnot_ps(v31, (__m128)0x41400000u).m128_u32[0] | v29.m128_i32[0] & v31.m128_i32[0];
    }
    v32.m128_i32[0] = LODWORD(prop->HighCut);
    this->mReverbProperties[instance].LowShelfGain = v30;
    v33 = 20.0;
    if ( v32.m128_f32[0] >= 20.0 )
    {
      v34 = _mm_cmpge_ss((__m128)0x469C4000u, v32);
      LODWORD(v33) = _mm_andnot_ps(v34, (__m128)0x469C4000u).m128_u32[0] | v32.m128_i32[0] & v34.m128_i32[0];
    }
    this->mReverbProperties[instance].HighCut = v33;
    v35.m128_i32[0] = LODWORD(prop->EarlyLateMix);
    if ( v35.m128_f32[0] >= 0.0 )
    {
      v36 = _mm_cmpge_ss((__m128)0x42C80000u, v35);
      LODWORD(v8) = _mm_andnot_ps(v36, (__m128)0x42C80000u).m128_u32[0] | v35.m128_i32[0] & v36.m128_i32[0];
    }
    v37.m128_i32[0] = LODWORD(prop->WetLevel);
    this->mReverbProperties[instance].EarlyLateMix = v8;
    v38 = -80.0;
    if ( v37.m128_f32[0] >= -80.0 )
    {
      v39 = _mm_cmpge_ss((__m128)0x41A00000u, v37);
      LODWORD(v38) = _mm_andnot_ps(v39, (__m128)0x41A00000u).m128_u32[0] | v37.m128_i32[0] & v39.m128_i32[0];
    }
    this->mReverbProperties[instance].WetLevel = v38;
  }
  return FMOD::SystemI::setReverbPropertiesInternal(this, instance, prop, 0);
}


// Address: 0x21cbe30 | Name: _ZN4FMOD7SystemI19getReverbPropertiesEiP22FMOD_REVERB_PROPERTIES
FMOD_RESULT_0 __fastcall FMOD::SystemI::getReverbProperties(
        FMOD::SystemI *const this,
        int instance,
        FMOD_REVERB_PROPERTIES *prop)
{
  FMOD_RESULT_0 result; // eax
  float v4; // xmm0_4
  __m128 v5; // xmm1
  __m128 v6; // xmm0
  float v7; // xmm0_4
  __m128 v8; // xmm3
  float v9; // xmm1_4
  __m128 v10; // xmm1
  float v11; // xmm1_4
  __m128 v12; // xmm3
  __m128 v13; // xmm1
  float v14; // xmm3_4
  __m128 v15; // xmm4
  __m128 v16; // xmm3
  float v17; // xmm3_4
  __m128 v18; // xmm4
  __m128 v19; // xmm3
  float v20; // xmm3_4
  __m128 v21; // xmm4
  __m128 v22; // xmm3
  float v23; // xmm3_4
  __m128 v24; // xmm4
  __m128 v25; // xmm3
  float v26; // xmm3_4
  __m128 v27; // xmm4
  __m128 v28; // xmm3
  float v29; // xmm3_4
  __m128 v30; // xmm4
  __m128 v31; // xmm3
  float v32; // xmm3_4
  __m128 v33; // xmm4
  __m128 v34; // xmm3
  __m128 v35; // xmm3
  __m128 v36; // xmm0
  float v37; // xmm0_4
  __m128 v38; // xmm2
  __m128 v39; // xmm0

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( prop )
  {
    LOBYTE(result) = 59;
    if ( (unsigned int)instance <= 3 )
    {
      v4 = 100.0;
      v5.m128_i32[0] = *(_DWORD *)((char *)&stru_124F8.r_offset + (_QWORD)this + 48 * instance);
      if ( v5.m128_f32[0] >= 100.0 )
      {
        v6 = _mm_cmpge_ss((__m128)0x469C4000u, v5);
        LODWORD(v4) = _mm_andnot_ps(v6, (__m128)0x469C4000u).m128_u32[0] | v5.m128_i32[0] & v6.m128_i32[0];
      }
      prop->DecayTime = v4;
      v7 = 0.0;
      v8.m128_i32[0] = LODWORD(this->mReverbProperties[instance].EarlyDelay);
      v9 = 0.0;
      if ( v8.m128_f32[0] >= 0.0 )
      {
        v10 = _mm_cmpge_ss((__m128)0x43960000u, v8);
        LODWORD(v9) = _mm_andnot_ps(v10, (__m128)0x43960000u).m128_u32[0] | v8.m128_i32[0] & v10.m128_i32[0];
      }
      prop->EarlyDelay = v9;
      v11 = 0.0;
      v12.m128_i32[0] = LODWORD(this->mReverbProperties[instance].LateDelay);
      if ( v12.m128_f32[0] >= 0.0 )
      {
        v13 = _mm_cmpge_ss((__m128)0x42C80000u, v12);
        LODWORD(v11) = _mm_andnot_ps(v13, (__m128)0x42C80000u).m128_u32[0] | v12.m128_i32[0] & v13.m128_i32[0];
      }
      prop->LateDelay = v11;
      v14 = 20.0;
      v15.m128_i32[0] = LODWORD(this->mReverbProperties[instance].HFReference);
      if ( v15.m128_f32[0] >= 20.0 )
      {
        v16 = _mm_cmpge_ss((__m128)0x469C4000u, v15);
        LODWORD(v14) = _mm_andnot_ps(v16, (__m128)0x469C4000u).m128_u32[0] | v15.m128_i32[0] & v16.m128_i32[0];
      }
      prop->HFReference = v14;
      v17 = 10.0;
      v18.m128_i32[0] = LODWORD(this->mReverbProperties[instance].HFDecayRatio);
      if ( v18.m128_f32[0] >= 10.0 )
      {
        v19 = _mm_cmpge_ss((__m128)0x42C80000u, v18);
        LODWORD(v17) = _mm_andnot_ps(v19, (__m128)0x42C80000u).m128_u32[0] | v18.m128_i32[0] & v19.m128_i32[0];
      }
      prop->HFDecayRatio = v17;
      v20 = 0.0;
      v21.m128_i32[0] = LODWORD(this->mReverbProperties[instance].Diffusion);
      if ( v21.m128_f32[0] >= 0.0 )
      {
        v22 = _mm_cmpge_ss((__m128)0x42C80000u, v21);
        LODWORD(v20) = _mm_andnot_ps(v22, (__m128)0x42C80000u).m128_u32[0] | v21.m128_i32[0] & v22.m128_i32[0];
      }
      prop->Diffusion = v20;
      v23 = 0.0;
      v24.m128_i32[0] = *(_DWORD *)((char *)&stru_12510.r_offset + (_QWORD)this + 48 * instance);
      if ( v24.m128_f32[0] >= 0.0 )
      {
        v25 = _mm_cmpge_ss((__m128)0x42C80000u, v24);
        LODWORD(v23) = _mm_andnot_ps(v25, (__m128)0x42C80000u).m128_u32[0] | v24.m128_i32[0] & v25.m128_i32[0];
      }
      prop->Density = v23;
      v26 = 20.0;
      v27.m128_i32[0] = LODWORD(this->mReverbProperties[instance].LowShelfFrequency);
      if ( v27.m128_f32[0] >= 20.0 )
      {
        v28 = _mm_cmpge_ss((__m128)0x447A0000u, v27);
        LODWORD(v26) = _mm_andnot_ps(v28, (__m128)0x447A0000u).m128_u32[0] | v27.m128_i32[0] & v28.m128_i32[0];
      }
      prop->LowShelfFrequency = v26;
      v29 = -36.0;
      v30.m128_i32[0] = LODWORD(this->mReverbProperties[instance].LowShelfGain);
      if ( v30.m128_f32[0] >= -36.0 )
      {
        v31 = _mm_cmpge_ss((__m128)0x41400000u, v30);
        LODWORD(v29) = _mm_andnot_ps(v31, (__m128)0x41400000u).m128_u32[0] | v30.m128_i32[0] & v31.m128_i32[0];
      }
      prop->LowShelfGain = v29;
      v32 = 20.0;
      v33.m128_i32[0] = LODWORD(this->mReverbProperties[instance].HighCut);
      if ( v33.m128_f32[0] >= 20.0 )
      {
        v34 = _mm_cmpge_ss((__m128)0x469C4000u, v33);
        LODWORD(v32) = _mm_andnot_ps(v34, (__m128)0x469C4000u).m128_u32[0] | v33.m128_i32[0] & v34.m128_i32[0];
      }
      prop->HighCut = v32;
      v35.m128_i32[0] = LODWORD(this->mReverbProperties[instance].EarlyLateMix);
      if ( v35.m128_f32[0] >= 0.0 )
      {
        v36 = _mm_cmpge_ss((__m128)0x42C80000u, v35);
        LODWORD(v7) = _mm_andnot_ps(v36, (__m128)0x42C80000u).m128_u32[0] | v35.m128_i32[0] & v36.m128_i32[0];
      }
      prop->EarlyLateMix = v7;
      v37 = -80.0;
      v38.m128_i32[0] = LODWORD(this->mReverbProperties[instance].WetLevel);
      if ( v38.m128_f32[0] >= -80.0 )
      {
        v39 = _mm_cmpge_ss((__m128)0x41A00000u, v38);
        LODWORD(v37) = _mm_andnot_ps(v39, (__m128)0x41A00000u).m128_u32[0] | v38.m128_i32[0] & v39.m128_i32[0];
      }
      prop->WetLevel = v37;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21cc0f0 | Name: _ZN4FMOD7SystemI7lockDSPEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::lockDSP(FMOD::SystemI *const this)
{
  FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_DSPFULL);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cc110 | Name: _ZN4FMOD7SystemI9unlockDSPEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::unlockDSP(FMOD::SystemI *const this)
{
  FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_DSPFULL);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cc130 | Name: _ZN4FMOD7SystemI19updateRecordBuffersEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::updateRecordBuffers(FMOD::SystemI *const this)
{
  char v1; // r13
  __int64 v2; // rbx
  int v3; // r12d
  FMOD::FMOD_RECORDING_INFO *info; // rsi
  FMOD_RESULT_0 v5; // eax
  FMOD_RESULT_0 v6; // ebx

  if ( this )
  {
    v1 = 1;
    FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_RECORD_INFO);
  }
  else
  {
    v1 = 0;
  }
  v2 = 0;
  v3 = 0;
  if ( this->mNumRecordDrivers <= 0 )
  {
LABEL_7:
    v6 = FMOD_RESULT::FMOD_OK_0;
  }
  else
  {
    while ( 1 )
    {
      info = this->mRecordCache[v2].info;
      if ( info )
      {
        v5 = FMOD::Output::recordUpdate(this->mOutput, info);
        if ( v5 )
          break;
      }
      ++v3;
      ++v2;
      if ( this->mNumRecordDrivers <= v3 )
        goto LABEL_7;
    }
    v6 = v5;
  }
  if ( v1 )
    FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_RECORD_INFO);
  return v6;
}


// Address: 0x21cc1d0 | Name: _ZN4FMOD7SystemI17updateRecordCacheEv_0
FMOD_RESULT_0 __fastcall FMOD::SystemI::updateRecordCache(FMOD::SystemI *const this)
{
  if ( this->mInitialized )
    return FMOD::SystemI::updateRecordCache(this);
  else
    return FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
}


// Address: 0x21cc1f0 | Name: _ZN4FMOD7SystemI19getRecordNumDriversEPiS1_
FMOD_RESULT_0 __fastcall FMOD::SystemI::getRecordNumDrivers(
        FMOD::SystemI *const this,
        int *numDrivers,
        int *numConnected)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD::SystemI::updateRecordCache(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( numDrivers )
      *numDrivers = this->mNumRecordDrivers;
    if ( numConnected )
      *numConnected = this->mNumRecordConnected;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21cc240 | Name: _ZN4FMOD7SystemI19getRecordDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_Pj
FMOD_RESULT_0 __fastcall FMOD::SystemI::getRecordDriverInfo(
        FMOD::SystemI *const this,
        int id,
        char *name,
        int nameLen,
        FMOD_GUID *guid,
        int *systemRate,
        FMOD_SPEAKERMODE_0 *speakerMode,
        int *speakerModeChannels,
        FMOD_DRIVER_STATE *state)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI::RecordCache *v14; // rax

  result = FMOD::SystemI::updateRecordCache(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( id >= 0 && id < this->mNumRecordDrivers )
    {
      if ( name )
        FMOD_strcpy_safe(name, this->mRecordCache[id].name, nameLen);
      if ( guid )
      {
        v14 = &this->mRecordCache[id];
        *(_QWORD *)&guid->Data1 = *(_QWORD *)&v14->guid.Data1;
        *(_QWORD *)guid->Data4 = *(_QWORD *)v14->guid.Data4;
      }
      if ( systemRate )
        *systemRate = this->mRecordCache[id].systemRate;
      if ( speakerMode )
        *speakerMode = this->mRecordCache[id].speakerMode;
      if ( speakerModeChannels )
        *speakerModeChannels = this->mRecordCache[id].speakerModeChannels;
      if ( state )
        *state = this->mRecordCache[id].state;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21cc3b0 | Name: _ZN4FMOD7SystemI10recordStopEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::recordStop(FMOD::SystemI *const this, int id)
{
  FMOD_RESULT_0 updated; // ebx
  __int64 v4; // r12
  FMOD_RESULT_0 v5; // eax

  updated = FMOD::SystemI::updateRecordCache(this);
  if ( updated == FMOD_RESULT::FMOD_OK_0 )
  {
    updated = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( id >= 0 && id < this->mNumRecordDrivers )
    {
      LOBYTE(updated) = 0;
      v4 = id;
      if ( this->mRecordCache[v4].info )
      {
        FMOD::SystemI::enterCrit(this, FMOD_SYSTEM_CRIT_RECORD_INFO);
        v5 = FMOD::Output::recordStop(this->mOutput, this->mRecordCache[v4].info);
        if ( v5 )
        {
          updated = v5;
        }
        else
        {
          FMOD::MemPool::free(
            off_286F358->gSystemMemPool,
            this->mRecordCache[v4].info,
            "../../../core_api/src/fmod_systemi.cpp",
            5211);
          this->mRecordCache[v4].info = 0;
        }
        FMOD::SystemI::leaveCrit(this, FMOD_SYSTEM_CRIT_RECORD_INFO);
      }
    }
  }
  return updated;
}


// Address: 0x21cc4a0 | Name: _ZN4FMOD7SystemI11recordStartEiPNS_6SoundIEb
FMOD_RESULT_0 __fastcall FMOD::SystemI::recordStart(FMOD::SystemI *const this, int id, FMOD::SoundI *sound, bool loop)
{
  FMOD_RESULT_0 result; // eax
  __int64 v7; // r14
  _QWORD *v8; // rbp
  FMOD::SystemI::RecordCache *v9; // rax
  int index; // edx
  FMOD_RESULT_0 v11; // r12d

  result = FMOD::SystemI::updateRecordCache(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( id >= 0 && id < this->mNumRecordDrivers )
    {
      if ( sound )
      {
        if ( SLOBYTE(sound->mMode) >= 0 )
        {
          if ( sound->mLength )
          {
            v7 = id;
            result = FMOD_RESULT::FMOD_ERR_RECORD_DISCONNECTED_0;
            if ( (this->mRecordCache[v7].state & 1) != 0 )
            {
              result = FMOD::SystemI::recordStop(this, id);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                v8 = FMOD::MemPool::calloc(
                       off_286F358->gSystemMemPool,
                       96,
                       "../../../core_api/src/fmod_systemi.cpp",
                       5149,
                       0);
                result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
                if ( v8 )
                {
                  v9 = &this->mRecordCache[v7];
                  index = v9->index;
                  v8[8] = sound;
                  *((_BYTE *)v8 + 48) = loop;
                  *(_DWORD *)v8 = index;
                  *((_DWORD *)v8 + 7) = (int)sound->mDefaultFrequency;
                  *((_DWORD *)v8 + 8) = sound->mChannels;
                  *((_DWORD *)v8 + 6) = sound->mFormat;
                  *((_DWORD *)v8 + 9) = sound->mLength;
                  *(_QWORD *)((char *)v8 + 4) = *(_QWORD *)&v9->guid.Data1;
                  *(_QWORD *)((char *)v8 + 12) = *(_QWORD *)v9->guid.Data4;
                  v11 = FMOD::Output::recordStart(this->mOutput, (FMOD::FMOD_RECORDING_INFO *)v8);
                  if ( v11 )
                  {
                    FMOD::Output::recordStop(this->mOutput, (FMOD::FMOD_RECORDING_INFO *)v8);
                    FMOD::MemPool::free(off_286F358->gSystemMemPool, v8, "../../../core_api/src/fmod_systemi.cpp", 5169);
                    return v11;
                  }
                  else
                  {
                    this->mRecordCache[v7].info = (FMOD::FMOD_RECORDING_INFO *)v8;
                    return FMOD_RESULT::FMOD_OK_0;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21cc610 | Name: _ZN4FMOD7SystemI13closeInternalEb
FMOD_RESULT_0 __fastcall FMOD::SystemI::closeInternal(FMOD::SystemI *const this, bool calledfrominit)
{
  __int64 v4; // rbp
  int v5; // r12d
  FMOD::SystemI::RecordCache *i; // r8
  void **p_name; // rax
  FMOD_RESULT_0 result; // eax
  __int64 v9; // r12
  int v10; // ebp
  FMOD::ChannelI *v11; // rdi
  FMOD::Output *mOutput; // rdi
  __int64 mSize; // rax
  bool v14; // zf
  bool v15; // cc
  FMOD::Profile *v16; // rdi
  FMOD::ChannelGroupI *mMasterChannelGroup; // rdi
  FMOD::SoundGroupI *mMasterSoundGroup; // rdi
  __int64 *j; // rax
  __int64 *v20; // rbp
  __int64 v21; // rbp
  FMOD_RESULT_0 v22; // r12d
  FMOD::Output *v23; // rdi
  void (__fastcall *close)(FMOD_OUTPUT_STATE *); // rax
  FMOD::DownMix *mDownMix; // rdi
  __int64 v26; // rdi
  FMOD::OutputRingBuffer *mDSPRingBuffer; // rdi
  FMOD::OutputSoftware *mSoftware; // rdi
  FMOD::OutputEmulated *mEmulated; // rdi
  FMOD::FMOD_DSP_CODECPOOL_TYPE v30; // ebp
  FMOD::ChannelI *mChannel; // rsi
  __int64 v32; // rax
  void *v33; // rsi
  __int64 k; // rbp
  FMOD_OS_CRITICALSECTION *v35; // rdi
  FMOD::FFT *mNodeNext; // rdi
  FMOD_OS_CRITICALSECTION *v37; // rdi
  FMOD_OS_CRITICALSECTION *v38; // rdi
  FMOD_OS_CRITICALSECTION *v39; // rdi
  void *v40; // rsi
  FMOD_RESULT_0 v41; // eax
  FMOD::PluginFactory *mPluginFactory; // rdi
  int connectionsRemaining[11]; // [rsp+Ch] [rbp-2Ch] BYREF

  if ( this )
  {
    if ( FMOD::SystemI::enterMainUpdateLock(this) )
    {
      FMOD::SystemI::updateInternal(this, 0);
    }
    else
    {
      FMOD::SystemI::updateInternal(this, 0);
      FMOD::SystemI::leaveMainUpdateLock(this);
    }
  }
  else
  {
    FMOD::SystemI::updateInternal(0, 0);
  }
  v4 = 0;
  v5 = 0;
  for ( i = this->mRecordCache; this->mNumRecordDrivers > v5; ++v4 )
  {
    p_name = (void **)&i[v4].name;
    if ( i[v4].info )
    {
      result = FMOD::SystemI::recordStop(this, v5);
      if ( result )
        return result;
      i = this->mRecordCache;
      p_name = (void **)&i[v4].name;
    }
    if ( *p_name )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, *p_name, "../../../core_api/src/fmod_systemi.cpp", 578);
      i = this->mRecordCache;
      i[v4].name = 0;
    }
    ++v5;
  }
  this->mNumRecordDrivers = 0;
  this->mNumRecordCapacity = 0;
  this->mNumRecordConnected = 0;
  this->mRecordListChanged = 0;
  this->mRecordListLastCheckedTime = 0;
  if ( i )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, i, "../../../core_api/src/fmod_systemi.cpp", 586);
    this->mRecordCache = 0;
  }
  v9 = 0;
  v10 = 0;
  FMOD::SystemI::enterMainUpdateLock(this);
  if ( this->mNumChannels > 0 )
  {
    do
    {
      v11 = &this->mChannel[v9];
      ++v10;
      ++v9;
      FMOD::ChannelI::close(v11);
    }
    while ( this->mNumChannels > v10 );
  }
  FMOD::SystemI::leaveMainUpdateLock(this);
  FMOD::SystemI::flushDSPQueue(this, 1);
  FMOD::SystemI::updateInternal(this, 0);
  if ( this->mStreamThreadActive )
  {
    FMOD::Thread::closeThread(&this->mStreamThread);
    v37 = this->mCrit[7];
    this->mStreamThreadActive = 0;
    FMOD_OS_CriticalSection_Free(v37, 0);
    v38 = *(FMOD_OS_CRITICALSECTION **)((char *)&stru_114C0.r_offset + (_QWORD)this);
    this->mCrit[7] = 0;
    FMOD_OS_CriticalSection_Free(v38, 0);
    v39 = this->mCrit[9];
    *(unsigned __int64 *)((char *)&stru_114C0.r_offset + (_QWORD)this) = 0;
    FMOD_OS_CriticalSection_Free(v39, 0);
    this->mCrit[9] = 0;
  }
  mOutput = this->mOutput;
  if ( mOutput )
    FMOD::Output::stop(mOutput);
  while ( 1 )
  {
    mSize = this->mObject3DHead.mSize;
    if ( !(_DWORD)mSize )
      break;
    result = FMOD::SystemI::cleanUpObject3DHandle(
               this,
               *(void **)(*(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) + 8 * mSize - 8));
    if ( result )
      return result;
  }
  v14 = this->mObject3DHead.mCapacity == 0;
  v15 = this->mObject3DHead.mCapacity <= 0;
  this->mObject3DHead.mSize = 0;
  if ( !v14 )
  {
    if ( !v15 )
    {
      v40 = *(void **)((char *)&stru_12618.r_offset + (_QWORD)this);
      if ( v40 )
        FMOD::MemPool::free(off_286F358->gSystemMemPool, v40, "../../../core_api/src/fmod_memory.h", 244);
    }
    *(unsigned __int64 *)((char *)&stru_12618.r_offset + (_QWORD)this) = 0;
    this->mObject3DHead.mCapacity = 0;
  }
  v16 = *(FMOD::Profile **)((char *)&stru_125D0.r_offset + (_QWORD)this);
  if ( v16 )
  {
    result = FMOD::Profile::release(v16);
    if ( result )
      return result;
    *(unsigned __int64 *)((char *)&stru_125D0.r_offset + (_QWORD)this) = 0;
  }
  mMasterChannelGroup = this->mMasterChannelGroup;
  this->mProfileDSP = 0;
  if ( mMasterChannelGroup )
  {
    result = FMOD::ChannelGroupI::releaseInternal(mMasterChannelGroup, 1);
    if ( result )
      return result;
    this->mMasterChannelGroup = 0;
  }
  mMasterSoundGroup = this->mMasterSoundGroup;
  if ( mMasterSoundGroup )
  {
    result = FMOD::SoundGroupI::releaseInternal(mMasterSoundGroup);
    if ( result )
      return result;
    this->mMasterSoundGroup = 0;
  }
  for ( j = *(__int64 **)((char *)&stru_125B8.r_offset + (_QWORD)this);
        (__int64 *)((char *)&stru_125B8 + (_QWORD)this) != j;
        j = v20 )
  {
    v20 = (__int64 *)*j;
    result = FMOD::ReverbI::release((FMOD::ReverbI *const)j[2], 1);
    if ( result )
      return result;
  }
  v21 = 0;
  while ( 1 )
  {
    result = FMOD::ReverbPhysical::release((FMOD::ReverbPhysical *const)((char *)&stru_12498 + (_QWORD)this + v21));
    v22 = result;
    if ( result )
      return result;
    v21 += 24;
    if ( v21 == 96 )
    {
      v23 = this->mOutput;
      if ( v23 )
      {
        if ( calledfrominit )
        {
          close = (void (__fastcall *)(FMOD_OUTPUT_STATE *))v23->mDescription.close;
          if ( close )
            close(&v23->FMOD_OUTPUT_STATE);
        }
        else
        {
          v41 = (*v23->_vptr_Output)(v23);
          this->mOutput = 0;
          v22 = v41;
        }
      }
      mDownMix = this->mDownMix;
      if ( mDownMix )
      {
        result = (*((unsigned int (__fastcall **)(FMOD::DownMix *))mDownMix->_vptr_DownMix + 1))(mDownMix);
        v22 = result;
        if ( result )
          return result;
        this->mDownMix = 0;
      }
      v26 = *(unsigned __int64 *)((char *)&stru_10F50.r_offset + (_QWORD)this);
      if ( v26 )
      {
        result = (*(unsigned int (__fastcall **)(__int64))(*(_QWORD *)v26 + 16LL))(v26);
        v22 = result;
        if ( result )
          return result;
        FMOD::MemPool::free(
          off_286F358->gSystemMemPool,
          *(void **)((char *)&stru_10F50.r_offset + (_QWORD)this),
          "../../../core_api/src/fmod_systemi.cpp",
          754);
        *(unsigned __int64 *)((char *)&stru_10F50.r_offset + (_QWORD)this) = 0;
      }
      mDSPRingBuffer = this->mDSPRingBuffer;
      if ( mDSPRingBuffer )
      {
        FMOD::OutputRingBuffer::release(mDSPRingBuffer);
        result = v22;
        if ( v22 )
          return result;
        FMOD::MemPool::free(
          off_286F358->gSystemMemPool,
          this->mDSPRingBuffer,
          "../../../core_api/src/fmod_systemi.cpp",
          763);
        this->mDSPRingBuffer = 0;
      }
      mSoftware = this->mSoftware;
      if ( mSoftware )
      {
        (*mSoftware->_vptr_Output)(mSoftware);
        this->mSoftware = 0;
      }
      mEmulated = this->mEmulated;
      if ( mEmulated )
      {
        (*mEmulated->_vptr_Output)(mEmulated);
        this->mEmulated = 0;
      }
      v30 = FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_PCM;
      while ( 1 )
      {
        result = FMOD::SystemI::DSPCodecPoolUnregister(this, v30);
        if ( result )
          return result;
        if ( ++v30 == FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_MAX )
        {
          mChannel = this->mChannel;
          if ( mChannel )
          {
            FMOD::MemPool::free(off_286F358->gSystemMemPool, mChannel, "../../../core_api/src/fmod_systemi.cpp", 801);
            this->mChannel = 0;
            this->mNumChannels = 0;
          }
          this->mChannelFreeListHead.mNodeData = 0;
          this->mChannelFreeListHead.mNodePrev = &this->mChannelFreeListHead.FMOD::LinkedListNode;
          this->mChannelFreeListHead.mNodeNext = &this->mChannelFreeListHead.FMOD::LinkedListNode;
          if ( !calledfrominit )
          {
            result = FMOD::SystemI::channelLayoutsClose(this);
            if ( result )
              return result;
            mPluginFactory = this->mPluginFactory;
            if ( mPluginFactory )
            {
              result = FMOD::PluginFactory::release(mPluginFactory, 1);
              if ( result )
                return result;
              this->mPluginFactory = 0;
              this->mPluginsLoaded = 0;
            }
            FMOD::SystemI::flushDSPQueue(this, 1);
            FMOD::SystemI::updateInternal(this, 0);
          }
          v32 = *(unsigned __int64 *)((char *)&stru_10788.r_offset + (_QWORD)this);
          if ( v32 )
          {
            v33 = *(void **)(v32 + 24);
            if ( v33 )
            {
              FMOD::MemPool::free(off_286F358->gSystemMemPool, v33, "../../../core_api/src/fmod_systemi.cpp", 835);
              *(_QWORD *)(*(unsigned __int64 *)((char *)&stru_10788.r_offset + (_QWORD)this) + 24) = 0;
            }
          }
          result = FMOD::SystemI::releaseDSPBufferPool(this);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            result = FMOD::SystemI::flushDSPQueue(this, 1);
            if ( result == FMOD_RESULT::FMOD_OK_0 )
            {
              result = FMOD::SystemI::flushDSPReleaseQueue(this);
              if ( result == FMOD_RESULT::FMOD_OK_0 )
              {
                FMOD::ExpandingPool<FMOD::DSPConnectionI>::getNumAlloced(
                  &this->mDSPConnectionPool,
                  connectionsRemaining);
                result = FMOD::ExpandingPool<FMOD::DSPConnectionI>::close(&this->mDSPConnectionPool);
                if ( result == FMOD_RESULT::FMOD_OK_0 )
                {
                  result = FMOD::MemPool::close((FMOD::MemPool *const)((char *)&stru_10818 + (_QWORD)this));
                  if ( result == FMOD_RESULT::FMOD_OK_0 )
                  {
                    result = FMOD::MemPool::close(&this->mDSPLevelsPool);
                    if ( result == FMOD_RESULT::FMOD_OK_0 )
                    {
                      result = FMOD::SystemI::releaseFadePointPool(this);
                      if ( result == FMOD_RESULT::FMOD_OK_0 )
                      {
                        result = FMOD::ReturnTable::close(&this->mReturnTable);
                        if ( result == FMOD_RESULT::FMOD_OK_0 )
                        {
                          for ( k = 0; k != 18; ++k )
                          {
                            v35 = this->mCrit[k];
                            if ( v35 )
                            {
                              result = FMOD_OS_CriticalSection_Free(v35, 0);
                              if ( result )
                                return result;
                              this->mCrit[k] = 0;
                            }
                          }
                          mNodeNext = (FMOD::FFT *)this->mFFTHead.mNodeNext;
                          if ( mNodeNext == &this->mFFTHead )
                          {
LABEL_81:
                            result = FMOD::GeometryMgr::close(&this->mGeometryMgr);
                            if ( result == FMOD_RESULT::FMOD_OK_0 )
                            {
                              result = FMOD::Global::decRef(off_286F358);
                              if ( result == FMOD_RESULT::FMOD_OK_0 )
                                this->mInitialized = 0;
                            }
                          }
                          else
                          {
                            while ( 1 )
                            {
                              result = FMOD::FFT::release(mNodeNext);
                              if ( result )
                                break;
                              mNodeNext = (FMOD::FFT *)this->mFFTHead.mNodeNext;
                              if ( mNodeNext == &this->mFFTHead )
                                goto LABEL_81;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          return result;
        }
      }
    }
  }
}


// Address: 0x21ccd50 | Name: _ZN4FMOD7SystemI4initEijPv
FMOD_RESULT_0 __fastcall FMOD::SystemI::init(
        FMOD::SystemI *const this,
        int maxchannels,
        FMOD_INITFLAGS flags,
        void *extradriverdata)
{
  FMOD_RESULT_1 ChannelGroup; // r15d
  __int64 i; // r14
  FMOD_RESULT_0 v11; // eax
  FMOD_SPEAKERMODE_0 mSpeakerMode; // r14d
  unsigned int v13; // eax
  unsigned int v14; // edx
  __int64 v15; // rax
  FMOD::OutputSoftware *v16; // rax
  FMOD::OutputSoftware *v17; // r15
  _QWORD *v18; // r15
  FMOD::Global *v19; // rax
  void *v20; // rax
  __int64 v21; // rdx
  __int64 v22; // rax
  FMOD::Output *mOutput; // rdx
  __int64 (__fastcall *init)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _DWORD, _DWORD, _QWORD); // r15
  FMOD_SPEAKERMODE_0 v25; // edi
  int mDSPSampleRate; // eax
  int mDSPMaxOutputChannels; // eax
  FMOD_RESULT_0 OutputResampler; // eax
  int v29; // esi
  FMOD_SPEAKERMODE_0 v30; // r15d
  FMOD_SOUND_FORMAT_0 v31; // ecx
  int v32; // edx
  int v33; // eax
  FMOD::Output *v34; // rax
  bool v35; // cc
  int v36; // eax
  FMOD::DownMix *mDownMix; // rdi
  FMOD::OutputEmulated *v38; // rax
  FMOD::OutputEmulated *v39; // r15
  FMOD::ChannelI *v40; // rax
  __int64 v41; // rbx
  __int64 v42; // r13
  FMOD::ChannelI *mChannel; // rax
  FMOD::ChannelI *v44; // rdi
  int v45; // esi
  FMOD::ChannelI *v46; // rdi
  FMOD::LinkedListNode *mNodeNext; // rdx
  int maxMPEGCodecs; // ebx
  FMOD::SystemI *v49; // rax
  int v50; // edx
  FMOD::Output *v51; // rdi
  FMOD::FMOD_CODEC_DESCRIPTION_EX *Description; // rax
  FMOD_SPEAKERMODE_0 v53; // edi
  int v54; // eax
  int ChannelsFromSpeakerMode; // eax
  unsigned int mDSPBlockSize; // ecx
  FMOD::Output *v57; // r11
  __int64 mSelectedDriver; // rsi
  FMOD::DownMix *v59; // rax
  FMOD::Output *v60; // rsi
  int v61; // r9d
  int autoClean_mSpeakerModeChannels; // [rsp+34h] [rbp-64h]
  FMOD::Output *v63; // [rsp+38h] [rbp-60h]
  int v64; // [rsp+38h] [rbp-60h]
  FMOD_SOUND_FORMAT_0 v65; // [rsp+40h] [rbp-58h]
  int v66; // [rsp+48h] [rbp-50h]
  int rate; // [rsp+50h] [rbp-48h] BYREF
  FMOD_SPEAKERMODE_0 speakermode; // [rsp+54h] [rbp-44h] BYREF
  FMOD_SOUND_FORMAT_0 format; // [rsp+58h] [rbp-40h] BYREF
  int speakermodechannels[15]; // [rsp+5Ch] [rbp-3Ch] BYREF

  ChannelGroup = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (unsigned int)maxchannels > 0xFFF )
    return ChannelGroup;
  LOBYTE(ChannelGroup) = 27;
  if ( this->mInitialized )
    return ChannelGroup;
  ChannelGroup = FMOD::Global::incRef(off_286F358);
  if ( ChannelGroup )
    return ChannelGroup;
  for ( i = 0; i != 18; ++i )
  {
    v11 = FMOD_OS_CriticalSection_Create(&this->mCrit[i], 0);
    if ( v11 )
      return v11;
  }
  mSpeakerMode = this->mSpeakerMode;
  autoClean_mSpeakerModeChannels = this->mDSPMaxOutputChannels;
  if ( (flags & 0x200000) != 0 )
    this->mFlags = flags | 0x10000;
  else
    this->mFlags = flags;
  v13 = this->mAdvancedSettings.randomSeed ^ 0xF30D5EED;
  *(_DWORD *)((char *)&stru_116E8.r_offset + (_QWORD)this) = v13;
  this->mRandom.mState.y = ~v13;
  v14 = -1474208055 * ~v13;
  this->mRandom.mState.z = 572572263 * v13;
  v15 = 0;
  this->mRandom.mState.w = v14;
  do
  {
    this->mFileBytesRead[v15++].m_value = 0;
    _mm_mfence();
  }
  while ( v15 != 3 );
  ChannelGroup = FMOD::SystemI::setOutputInternal(this, this->mOutputType, this->mOutputHandle);
  if ( ChannelGroup == FMOD_RESULT::FMOD_OK_0 )
  {
    v16 = (FMOD::OutputSoftware *)FMOD::MemPool::calloc(
                                    off_286F358->gSystemMemPool,
                                    1152,
                                    "../../../core_api/src/fmod_systemi.cpp",
                                    2709,
                                    0);
    v17 = v16;
    if ( !v16 )
    {
      this->mSoftware = 0;
      ChannelGroup = FMOD_RESULT::FMOD_ERR_MEMORY_0;
      goto LABEL_13;
    }
    FMOD::OutputSoftware::OutputSoftware(v16);
    this->mSoftware = v17;
    v17->mSystem = this;
    this->mDSPQueueCmdOffset = 0;
    v18 = (_QWORD *)((unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL);
    *(unsigned __int64 *)((char *)&stru_10788.r_offset + (_QWORD)this) = (unsigned __int64)v18;
    if ( v18 )
    {
      *(_UNKNOWN **)((char *)&off_18 + ((unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL)) = 0;
      *(HuffmanEncodingTreeNode **)((char *)&inputbuff.root
                                  + ((unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL)) = 0;
      *(_DWORD *)((char *)&inputbuff.encodingTable[0].bitLength
                + ((unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL)
                + 4) = 0;
      *(_DWORD *)((char *)&inputbuff.encodingTable[1].encoding
                + ((unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL)) = 0;
      *(_DWORD *)((char *)&inputbuff.encodingTable[1].encoding
                + ((unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL)
                + 4) = 0;
    }
    *v18 = this;
    *(_DWORD *)((char *)&inputbuff.encodingTable[0].bitLength
              + ((unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL)) = 1;
    *(_DWORD *)&byte_8[(unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL] = 1024;
    *(_DWORD *)&byte_9[((unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL) + 3] = 0;
    v19 = off_286F358;
    *(_DWORD *)((char *)word_10 + ((unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL)) = 1024;
    v20 = FMOD::MemPool::calloc(v19->gSystemMemPool, 8208, "../../../core_api/src/fmod_systemi.cpp", 2724, 0);
    v21 = *(unsigned __int64 *)((char *)&stru_10788.r_offset + (_QWORD)this);
    *(_UNKNOWN **)((char *)&off_18 + ((unsigned __int64)&this->mDSPJobListMemory[15] & 0xFFFFFFFFFFFFFFF0LL)) = v20;
    v22 = *(_QWORD *)(v21 + 24);
    if ( v22 )
    {
      *(_QWORD *)(v21 + 32) = (v22 + 15) & 0xFFFFFFFFFFFFFFF0LL;
      ChannelGroup = FMOD::ExpandingPool<FMOD::DSPConnectionI>::init(
                       &this->mDSPConnectionPool,
                       this,
                       1024,
                       512,
                       1,
                       16,
                       1);
      if ( ChannelGroup )
        goto LABEL_13;
      ChannelGroup = FMOD::MemPool::init(&this->mDSPLevelsPool, 0, 0x40000, 1, 0);
      if ( ChannelGroup )
        goto LABEL_13;
      ChannelGroup = FMOD::MemPool::init((FMOD::MemPool *const)((char *)&stru_10818 + (_QWORD)this), 0, 0x2000, 1, 0);
      if ( ChannelGroup )
        goto LABEL_13;
      ChannelGroup = FMOD::SystemI::channelLayoutsInit(this);
      if ( ChannelGroup )
        goto LABEL_13;
      *(_QWORD *)&this->mSelectedDriverGUID.Data1 = -1;
      *(_QWORD *)this->mSelectedDriverGUID.Data4 = -1;
      FMOD::SystemI::getDriverInfo(this, this->mSelectedDriver, 0, 0, &this->mSelectedDriverGUID, 0, 0, 0);
      mOutput = this->mOutput;
      init = (__int64 (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _DWORD, _DWORD, _QWORD))mOutput->mDescription.init;
      if ( init )
      {
        v25 = this->mSpeakerMode;
        mDSPSampleRate = this->mDSPSampleRate;
        format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
        rate = mDSPSampleRate;
        speakermode = v25;
        if ( v25 == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
        {
          mDSPMaxOutputChannels = this->mDSPMaxOutputChannels;
        }
        else
        {
          v63 = mOutput;
          mDSPMaxOutputChannels = FMOD::SystemI::getChannelsFromSpeakerMode(v25);
          mOutput = v63;
        }
        speakermodechannels[0] = mDSPMaxOutputChannels;
        OutputResampler = (unsigned int)init(
                                          &mOutput->FMOD_OUTPUT_STATE,
                                          (unsigned int)this->mSelectedDriver,
                                          flags,
                                          &rate,
                                          &speakermode,
                                          speakermodechannels,
                                          &format,
                                          this->mDSPBlockSize,
                                          this->mDSPBufferSize / this->mDSPBlockSize,
                                          extradriverdata);
        if ( OutputResampler == FMOD_RESULT::FMOD_ERR_OUTPUT_NODRIVERS_0 )
        {
          ChannelGroup = this->mOutput->mDescription.close(&this->mOutput->FMOD_OUTPUT_STATE);
          if ( ChannelGroup )
            goto LABEL_13;
          OutputResampler = FMOD::SystemI::setOutputInternal(this, FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_NOSOUND_0, 0);
          if ( OutputResampler )
            goto LABEL_54;
          v53 = this->mSpeakerMode;
          v54 = this->mDSPSampleRate;
          format = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
          rate = v54;
          speakermode = v53;
          if ( v53 == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0 )
            ChannelsFromSpeakerMode = this->mDSPMaxOutputChannels;
          else
            ChannelsFromSpeakerMode = FMOD::SystemI::getChannelsFromSpeakerMode(v53);
          mDSPBlockSize = this->mDSPBlockSize;
          v57 = this->mOutput;
          mSelectedDriver = (unsigned int)this->mSelectedDriver;
          speakermodechannels[0] = ChannelsFromSpeakerMode;
          OutputResampler = v57->mDescription.init(
                              &v57->FMOD_OUTPUT_STATE,
                              mSelectedDriver,
                              flags,
                              &rate,
                              &speakermode,
                              speakermodechannels,
                              &format,
                              mDSPBlockSize,
                              this->mDSPBufferSize / mDSPBlockSize,
                              0);
        }
        if ( OutputResampler )
          goto LABEL_54;
        v29 = rate;
        if ( (unsigned int)(rate - 8000) > 0x5BCC0 )
          goto LABEL_36;
        v30 = speakermode;
        if ( (unsigned int)(speakermode - 1) > 7 )
          goto LABEL_36;
        v31 = format;
        if ( (unsigned int)(format - 1) > 4 )
          goto LABEL_36;
        v32 = speakermodechannels[0];
        if ( (unsigned int)(speakermodechannels[0] - 1) > 0x1F
          || speakermode != FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0
          && (v66 = speakermodechannels[0],
              v65 = format,
              v64 = rate,
              v33 = FMOD::SystemI::getChannelsFromSpeakerMode(speakermode),
              v32 = v66,
              v29 = v64,
              v31 = v65,
              v66 != v33) )
        {
LABEL_36:
          ChannelGroup = FMOD_RESULT::FMOD_ERR_INTERNAL_0;
          goto LABEL_13;
        }
        v34 = this->mOutput;
        v34->mSampleRate = v29;
        v34->mSpeakerMode = v30;
        v34->mFormat = v31;
        v34->mSpeakerModeChannels = v32;
      }
      OutputResampler = FMOD::SystemI::setSpeakerMode(this, this->mSpeakerMode, this->mDSPMaxOutputChannels);
      if ( OutputResampler )
        goto LABEL_54;
      if ( this->mOutput->mSampleRate != this->mDSPSampleRate )
      {
        OutputResampler = FMOD::SystemI::createOutputResampler(this);
        if ( OutputResampler )
          goto LABEL_54;
      }
      if ( this->mOutputType == FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_WINSONIC_0 )
      {
        OutputResampler = FMOD::SystemI::createOutputRingBuffer(this);
        if ( OutputResampler )
          goto LABEL_54;
      }
      ChannelGroup = FMOD::SystemI::createChannelGroup(this, "FMOD master", &this->mMasterChannelGroup);
      if ( ChannelGroup )
        goto LABEL_13;
      ChannelGroup = FMOD::SystemI::createSoundGroup(this, "FMOD master", &this->mMasterSoundGroup);
      if ( ChannelGroup )
        goto LABEL_13;
      ChannelGroup = (*((unsigned int (__fastcall **)(FMOD::OutputSoftware *, _QWORD))this->mSoftware->_vptr_Output + 1))(
                       this->mSoftware,
                       (unsigned int)this->mNumSoftwareChannels);
      if ( ChannelGroup )
        goto LABEL_13;
      v35 = this->mDSPMaxOutputChannels < 2;
      v36 = 2;
      this->mDSPMemoryBlocks.mNodeData = 0;
      if ( !v35 )
        v36 = this->mDSPMaxOutputChannels;
      this->mDSPMemoryChannels = v36;
      this->mDSPMemoryBlocks.mNodePrev = (FMOD::LinkedListNode *)((char *)&stru_10758 + (_QWORD)this);
      *(unsigned __int64 *)((char *)&stru_10758.r_offset + (_QWORD)this) = (unsigned __int64)&stru_10758 + (_QWORD)this;
      OutputResampler = FMOD::SystemI::expandDSPBufferPool(this);
      if ( OutputResampler )
        goto LABEL_54;
      mDownMix = this->mDownMix;
      if ( mDownMix
        && (*mDownMix->_vptr_DownMix)(
             mDownMix,
             this,
             this->mDSPBlockSize,
             (unsigned int)this->mDSPSampleRate,
             (unsigned int)this->mSpeakerMode,
             (unsigned int)this->mDSPMaxOutputChannels,
             this->mOutput->mSpeakerMode,
             this->mOutput->mSpeakerModeChannels,
             0) )
      {
        ChannelGroup = (*((unsigned int (__fastcall **)(FMOD::DownMix *))this->mDownMix->_vptr_DownMix + 1))(this->mDownMix);
        if ( ChannelGroup )
          goto LABEL_13;
        v59 = (FMOD::DownMix *)FMOD::MemPool::calloc(
                                 off_286F358->gSystemMemPool,
                                 200,
                                 "../../../core_api/src/fmod_systemi.cpp",
                                 2874,
                                 0);
        if ( !v59 )
        {
          this->mDownMix = 0;
          ChannelGroup = FMOD_RESULT::FMOD_ERR_MEMORY_0;
          goto LABEL_13;
        }
        v60 = this->mOutput;
        v59->mConnection.mInputNode.mNodeData = 0;
        v59->mConnection.mOutputNode.mNodeData = 0;
        v59->mConnection.mMixMatrix.mData = 0;
        v59->mConnection.mMixMatrix.mInChannels = 0;
        v59->mConnection.mMixMatrix.mOutChannels = 0;
        v59->mConnection.mMixMatrixCurrent.mData = 0;
        v59->_vptr_DownMix = (int (**)(...))&off_29B2730;
        v59->mConnection.mMixMatrixCurrent.mInChannels = 0;
        v59->mConnection.mMixMatrixCurrent.mOutChannels = 0;
        v59->mConnection.mUserData.mMixMatrixUser.mData = 0;
        v59->mConnection.mInputNode.mNodePrev = &v59->mConnection.mInputNode;
        v59->mConnection.mInputNode.mNodeNext = &v59->mConnection.mInputNode;
        v59->mConnection.mUserData.mMixMatrixUser.mInChannels = 0;
        v59->mConnection.mUserData.mMixMatrixUser.mOutChannels = 0;
        v59->mConnection.mOutputNode.mNodePrev = &v59->mConnection.mOutputNode;
        v59->mConnection.mOutputNode.mNodeNext = &v59->mConnection.mOutputNode;
        v59->mConnection.mSystem = 0;
        v59->mConnection.mInputUnit = 0;
        v59->mConnection.mOutputUnit = 0;
        v61 = this->mDSPMaxOutputChannels;
        this->mDownMix = v59;
        OutputResampler = FMOD::DownMix::init(
                            v59,
                            this,
                            this->mDSPBlockSize,
                            this->mDSPSampleRate,
                            this->mSpeakerMode,
                            v61,
                            v60->mSpeakerMode,
                            v60->mSpeakerModeChannels,
                            0);
        if ( OutputResampler )
        {
LABEL_54:
          ChannelGroup = OutputResampler;
          goto LABEL_13;
        }
      }
      if ( !maxchannels )
      {
LABEL_62:
        if ( !this->mStreamThreadActive && (this->mFlags & 1) == 0 )
        {
          OutputResampler = FMOD::Thread::initThread(
                              &this->mStreamThread,
                              "FMOD stream thread",
                              FMOD::SystemI::updateStreams,
                              this,
                              FMOD::FMOD_THREAD_TYPE::FMOD_THREAD_TYPE_STREAM,
                              FMOD_THREAD_PRIORITY::FMOD_THREAD_PRIORITY_VERYHIGH,
                              this->mAdvancedSettings.stackSizeStream,
                              0,
                              10,
                              this,
                              1);
          if ( OutputResampler )
            goto LABEL_54;
          this->mStreamThreadActive = 1;
        }
        maxMPEGCodecs = this->mAdvancedSettings.maxMPEGCodecs;
        if ( !maxMPEGCodecs
          || (Description = FMOD::CodecMPEG::getDescriptionEx(),
              (OutputResampler = FMOD::SystemI::DSPCodecPoolRegister(
                                   this,
                                   FMOD::FMOD_DSP_CODECPOOL_TYPE::FMOD_DSP_CODECPOOL_TYPE_MPEG,
                                   Description,
                                   maxMPEGCodecs,
                                   2)) == FMOD_RESULT::FMOD_OK_0) )
        {
          v49 = this;
          v50 = 0;
          do
          {
            ++v50;
            *(_DWORD *)((char *)&stru_124F8.r_offset + (_QWORD)v49) = 1148846080;
            v49->mReverbProperties[0].EarlyDelay = 7.0;
            v49->mReverbProperties[0].LateDelay = 11.0;
            v49->mReverbProperties[0].HFReference = 5000.0;
            v49 = (FMOD::SystemI *)((char *)v49 + 48);
            v49->mReverb[2].mInstance = 1120403456;
            *(&v49->mReverb[2].mInstance + 1) = 1120403456;
            *(_DWORD *)((char *)&stru_124E0.r_offset + (_QWORD)v49) = 1120403456;
            HIDWORD(v49->mReverb[3].mSystem) = 1132068864;
            LODWORD(v49->mReverb[3].mDSP) = 0;
            HIDWORD(v49->mReverb[3].mDSP) = 1101004800;
            v49->mReverb[3].mInstance = 1119879168;
            *(&v49->mReverb[3].mInstance + 1) = -1029701632;
          }
          while ( v50 != 4 );
          if ( (this->mFlags & 0x10000) == 0 )
            goto LABEL_68;
          ChannelGroup = FMOD::Profile::createProfile(
                           (FMOD::Profile **)((char *)&stru_125D0 + (_QWORD)this),
                           1,
                           *(_WORD *)((char *)&stru_11568.r_offset + (_QWORD)this));
          if ( ChannelGroup )
            goto LABEL_13;
          ChannelGroup = FMOD::ProfileRemoteFile::create(*(FMOD::Profile **)((char *)&stru_125D0.r_offset + (_QWORD)this));
          if ( ChannelGroup )
            goto LABEL_13;
          ChannelGroup = FMOD::ProfileDsp::create(
                           *(FMOD::Profile **)((char *)&stru_125D0.r_offset + (_QWORD)this),
                           this,
                           &this->mProfileDSP);
          if ( ChannelGroup )
            goto LABEL_13;
          OutputResampler = FMOD::ProfileStats::create(
                              *(FMOD::Profile **)((char *)&stru_125D0.r_offset + (_QWORD)this),
                              this);
          if ( OutputResampler == FMOD_RESULT::FMOD_OK_0 )
          {
LABEL_68:
            ChannelGroup = FMOD::ReturnTable::init(&this->mReturnTable, this);
            if ( ChannelGroup )
              goto LABEL_13;
            v51 = this->mOutput;
            *(unsigned __int64 *)((char *)&stru_116A0.r_offset + (_QWORD)this) = 0;
            this->mFFTHead.mNodePrev = &this->mFFTHead;
            this->mFFTHead.mNodeNext = &this->mFFTHead;
            OutputResampler = FMOD::Output::start(v51);
            if ( OutputResampler == FMOD_RESULT::FMOD_OK_0 )
            {
              this->mInitialized = 1;
              return ChannelGroup;
            }
          }
        }
        goto LABEL_54;
      }
      v38 = (FMOD::OutputEmulated *)FMOD::MemPool::alloc(
                                      off_286F358->gSystemMemPool,
                                      1152,
                                      "../../../core_api/src/fmod_systemi.cpp",
                                      2892,
                                      0,
                                      0);
      v39 = v38;
      if ( !v38 )
      {
        this->mEmulated = 0;
        ChannelGroup = FMOD_RESULT::FMOD_ERR_MEMORY_0;
        goto LABEL_13;
      }
      FMOD::OutputEmulated::OutputEmulated(v38);
      this->mEmulated = v39;
      v39->mSystem = this;
      OutputResampler = FMOD::OutputEmulated::init(v39, maxchannels);
      if ( OutputResampler )
        goto LABEL_54;
      v40 = (FMOD::ChannelI *)FMOD::MemPool::calloc(
                                off_286F358->gSystemMemPool,
                                568 * maxchannels,
                                "../../../core_api/src/fmod_systemi.cpp",
                                2910,
                                0);
      this->mChannel = v40;
      if ( v40 )
      {
        this->mNumChannels = maxchannels;
        v41 = 0;
        while ( (int)v41 < this->mNumChannels )
        {
          v42 = v41;
          mChannel = this->mChannel;
          v44 = &mChannel[v41];
          if ( v44 )
          {
            FMOD::ChannelI::ChannelI(v44);
            mChannel = this->mChannel;
          }
          v45 = v41++;
          FMOD::ChannelI::init(&mChannel[v42], v45, this);
          v46 = &this->mChannel[v42];
          mNodeNext = this->mChannelFreeListHead.mNodeNext;
          v46->mNodeNext = mNodeNext;
          v46->mNodePrev = &this->mChannelFreeListHead.FMOD::LinkedListNode;
          mNodeNext->mNodePrev = &v46->FMOD::LinkedListNode;
          v46->mNodePrev->FMOD::LinkedListNode::mNodeNext = &v46->FMOD::LinkedListNode;
          FMOD::ChannelI::setChannelGroupInternal(v46, 0, 0, 0);
        }
        goto LABEL_62;
      }
    }
    ChannelGroup = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
LABEL_13:
  if ( !this->mInitialized )
  {
    this->mSpeakerMode = mSpeakerMode;
    this->mDSPMaxOutputChannels = autoClean_mSpeakerModeChannels;
    FMOD::SystemI::closeInternal(this, 1);
  }
  return ChannelGroup;
}


// Address: 0x21cd8c0 | Name: _ZN4FMOD7SystemI5closeEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::close(FMOD::SystemI *const this)
{
  if ( this->mInitialized )
    return FMOD::SystemI::closeInternal(this, 0);
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cd8e0 | Name: _ZN4FMOD7SystemI7releaseEv
FMOD_RESULT_0 __fastcall FMOD::SystemI::release(FMOD::SystemI *const this)
{
  FMOD::Output *mOutput; // rdi
  FMOD::PluginFactory *mPluginFactory; // rdi
  FMOD_RESULT_0 result; // eax
  FMOD::MemPool *gSystemMemPool; // rdi

  if ( !this->mInitialized || (result = FMOD::SystemI::close(this)) == FMOD_RESULT::FMOD_OK_0 )
  {
    mOutput = this->mOutput;
    if ( mOutput )
    {
      (*mOutput->_vptr_Output)(mOutput);
      this->mOutput = 0;
    }
    mPluginFactory = this->mPluginFactory;
    if ( mPluginFactory )
    {
      result = FMOD::PluginFactory::release(mPluginFactory, 1);
      if ( result )
        return result;
      this->mPluginFactory = 0;
      this->mPluginsLoaded = 0;
    }
    gSystemMemPool = off_286F358->gSystemMemPool;
    off_286F358->gSystem[*(unsigned int *)((char *)&stru_115E0.r_offset + (_QWORD)this)] = 0;
    FMOD::MemPool::free(gSystemMemPool, this, "../../../core_api/src/fmod_systemi.cpp", 1326);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21cd990 | Name: _ZN4FMOD7SystemI17getRecordPositionEiPj
FMOD_RESULT_0 __fastcall FMOD::SystemI::getRecordPosition(FMOD::SystemI *const this, int id, unsigned int *position)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI::RecordCache *v5; // rbp
  FMOD::FMOD_RECORDING_INFO *info; // rax

  result = FMOD::SystemI::updateRecordCache(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( id >= 0 && id < this->mNumRecordDrivers )
    {
      v5 = &this->mRecordCache[id];
      if ( position )
      {
        info = v5->info;
        if ( info )
          *position = info->mRecordOffset;
        else
          *position = 0;
      }
      return (v5->state & 1) == 0 ? 0x50 : 0;
    }
  }
  return result;
}


// Address: 0x21cda10 | Name: _ZN4FMOD7SystemI11isRecordingEiPb
FMOD_RESULT_0 __fastcall FMOD::SystemI::isRecording(FMOD::SystemI *const this, int id, bool *recording)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI::RecordCache *v5; // rbp

  result = FMOD::SystemI::updateRecordCache(this);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( id >= 0 && id < this->mNumRecordDrivers )
    {
      v5 = &this->mRecordCache[id];
      if ( recording )
        *recording = v5->info != 0;
      return (v5->state & 1) == 0 ? 0x50 : 0;
    }
  }
  return result;
}


// Address: 0x21cda80 | Name: _ZN4FMOD7SystemI14createGeometryEiiPPNS_9GeometryIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::createGeometry(
        FMOD::SystemI *const this,
        int maxNumPolygons,
        int maxNumVertices,
        FMOD::GeometryI **geometry)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryMgr *p_mGeometryMgr; // r14
  FMOD::GeometryI *v9; // rdi
  FMOD::GeometryI *mGeometryList; // rdx
  FMOD::GeometryI *v11; // rax
  FMOD::LinkedListNode *mNodePrev; // rcx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( geometry )
  {
    if ( maxNumPolygons > 0 && maxNumVertices > 0 )
    {
      p_mGeometryMgr = &this->mGeometryMgr;
      result = FMOD::GeometryMgr::init(&this->mGeometryMgr, this);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v9 = (FMOD::GeometryI *)FMOD::MemPool::alloc(
                                  off_286F358->gSystemMemPool,
                                  320,
                                  "../../../core_api/src/fmod_systemi.cpp",
                                  5347,
                                  0,
                                  0);
        *geometry = v9;
        result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
        if ( v9 )
        {
          FMOD::GeometryI::GeometryI(v9, p_mGeometryMgr);
          result = FMOD::GeometryI::alloc(*geometry, maxNumPolygons, maxNumVertices);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            mGeometryList = this->mGeometryList;
            if ( mGeometryList )
            {
              v11 = *geometry;
              mNodePrev = mGeometryList->mNodePrev;
              v11->mNodeNext = mGeometryList;
              v11->mNodePrev = mNodePrev;
              mGeometryList->mNodePrev = v11;
              v11->mNodePrev->FMOD::LinkedListNode::mNodeNext = v11;
            }
            this->mGeometryList = *geometry;
            return FMOD_RESULT::FMOD_OK_0;
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21cdb60 | Name: _ZN4FMOD7SystemI19setGeometrySettingsEf
FMOD_RESULT_0 __fastcall FMOD::SystemI::setGeometrySettings(FMOD::SystemI *const this, float a2, float maxWorldSize)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryI *mGeometryList; // rbp
  FMOD::GeometryI *mNodeNext; // rbx

  result = FMOD_RESULT::FMOD_ERR_INVALID_FLOAT_0;
  if ( (LODWORD(a2) & 0x7F800000) != 0x7F800000 )
  {
    result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    if ( a2 > 0.0 )
    {
      result = FMOD::GeometryMgr::setWorldSize(&this->mGeometryMgr, maxWorldSize);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        mGeometryList = this->mGeometryList;
        if ( mGeometryList )
        {
          do
          {
            FMOD::GeometryI::removeFromTree(mGeometryList);
            mGeometryList = (FMOD::GeometryI *)mGeometryList->mNodeNext;
            mNodeNext = this->mGeometryList;
          }
          while ( mGeometryList != mNodeNext );
          while ( 1 )
          {
            result = FMOD::GeometryI::setWorldSize(mNodeNext, maxWorldSize);
            if ( result )
              break;
            mNodeNext = (FMOD::GeometryI *)mNodeNext->mNodeNext;
            if ( mNodeNext == this->mGeometryList )
              return FMOD_RESULT::FMOD_OK_0;
          }
        }
        else
        {
          return FMOD_RESULT::FMOD_OK_0;
        }
      }
    }
  }
  return result;
}


// Address: 0x21cdc20 | Name: _ZN4FMOD7SystemI19getGeometrySettingsEPf
FMOD_RESULT_0 __fastcall FMOD::SystemI::getGeometrySettings(FMOD::SystemI *const this, float *maxWorldSize)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( maxWorldSize )
  {
    LOBYTE(result) = 0;
    *maxWorldSize = *(float *)((char *)&stru_12450.r_offset + (_QWORD)this);
  }
  return result;
}


// Address: 0x21cdc40 | Name: _ZN4FMOD7SystemI12loadGeometryEPKviPPNS_9GeometryIE
FMOD_RESULT_0 __fastcall FMOD::SystemI::loadGeometry(
        FMOD::SystemI *const this,
        const void *data,
        int dataSize,
        FMOD::GeometryI **geometry)
{
  FMOD_RESULT_0 result; // eax
  FMOD::GeometryMgr *p_mGeometryMgr; // r14
  FMOD::GeometryI *v9; // rdi
  FMOD::GeometryI *mGeometryList; // rdx
  FMOD::GeometryI *v11; // rax
  FMOD::LinkedListNode *mNodePrev; // rcx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( data )
  {
    if ( geometry )
    {
      p_mGeometryMgr = &this->mGeometryMgr;
      result = FMOD::GeometryMgr::init(&this->mGeometryMgr, this);
      if ( result == FMOD_RESULT::FMOD_OK_0 )
      {
        v9 = (FMOD::GeometryI *)FMOD::MemPool::alloc(
                                  off_286F358->gSystemMemPool,
                                  320,
                                  "../../../core_api/src/fmod_systemi.cpp",
                                  5483,
                                  0,
                                  0);
        *geometry = v9;
        result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
        if ( v9 )
        {
          FMOD::GeometryI::GeometryI(v9, p_mGeometryMgr);
          result = FMOD::GeometryI::load(*geometry, data, dataSize);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            mGeometryList = this->mGeometryList;
            if ( mGeometryList )
            {
              v11 = *geometry;
              mNodePrev = mGeometryList->mNodePrev;
              v11->mNodeNext = mGeometryList;
              v11->mNodePrev = mNodePrev;
              mGeometryList->mNodePrev = v11;
              v11->mNodePrev->FMOD::LinkedListNode::mNodeNext = v11;
            }
            this->mGeometryList = *geometry;
            return FMOD_RESULT::FMOD_OK_0;
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21cdd20 | Name: _ZN4FMOD7SystemI20getGeometryOcclusionEPK11FMOD_VECTORS3_PfS4_
FMOD_RESULT_0 __fastcall FMOD::SystemI::getGeometryOcclusion(
        FMOD::SystemI *const this,
        const FMOD_VECTOR *listener,
        const FMOD_VECTOR *source,
        float *direct,
        float *reverb)
{
  FMOD_RESULT_0 result; // eax
  float direct_occlusion; // [rsp+0h] [rbp-20h] BYREF
  float reverb_occlusion[7]; // [rsp+4h] [rbp-1Ch] BYREF

  if ( !source || !listener )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  direct_occlusion = 0.0;
  reverb_occlusion[0] = 0.0;
  result = FMOD::GeometryMgr::lineTestAll(&this->mGeometryMgr, listener, source, &direct_occlusion, reverb_occlusion);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    if ( direct )
      *direct = direct_occlusion;
    if ( reverb )
    {
      result = FMOD_RESULT::FMOD_OK_0;
      *reverb = reverb_occlusion[0];
    }
    else
    {
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21cdda0 | Name: _ZN4FMOD7SystemI15setNetworkProxyEPKc
FMOD_RESULT_0 __fastcall FMOD::SystemI::setNetworkProxy(FMOD::SystemI *const this, const char *proxy)
{
  return FMOD_Net_SetProxy(proxy);
}


// Address: 0x21cddb0 | Name: _ZN4FMOD7SystemI15getNetworkProxyEPci
FMOD_RESULT_0 __fastcall FMOD::SystemI::getNetworkProxy(FMOD::SystemI *const this, char *proxy, int proxylen)
{
  return FMOD_Net_GetProxy(proxy, proxylen);
}


// Address: 0x21cddc0 | Name: _ZN4FMOD7SystemI17setNetworkTimeoutEi
FMOD_RESULT_0 __fastcall FMOD::SystemI::setNetworkTimeout(FMOD::SystemI *const this, int timeout)
{
  return FMOD_Net_SetTimeout(timeout);
}


// Address: 0x21cddd0 | Name: _ZN4FMOD7SystemI17getNetworkTimeoutEPi
FMOD_RESULT_0 __fastcall FMOD::SystemI::getNetworkTimeout(FMOD::SystemI *const this, int *timeout)
{
  return FMOD_Net_GetTimeout(timeout);
}


// Address: 0x21cdde0 | Name: _ZN4FMOD7SystemI11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::SystemI::setUserData(FMOD::SystemI *const this, void *userdata)
{
  *(unsigned __int64 *)((char *)&stru_11598.r_offset + (_QWORD)this) = (unsigned __int64)userdata;
  off_286F358->gSystemUserData = userdata;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21cde00 | Name: _ZN4FMOD7SystemI11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::SystemI::getUserData(FMOD::SystemI *const this, void **userdata)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( userdata )
  {
    *userdata = *(void **)((char *)&stru_11598.r_offset + (_QWORD)this);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


