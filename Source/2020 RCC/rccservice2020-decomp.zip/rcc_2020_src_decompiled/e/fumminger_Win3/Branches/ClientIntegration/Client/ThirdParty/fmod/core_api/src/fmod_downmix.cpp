// Address: 0x222e020 | Name: _ZN4FMOD7DownMix4initEPNS_7SystemIEjj16FMOD_SPEAKERMODEiS3_iPv
FMOD_RESULT_0 __fastcall FMOD::DownMix::init(
        FMOD::DownMix *const this,
        FMOD::SystemI *system,
        unsigned int dspbuffersize,
        unsigned int rate,
        FMOD_SPEAKERMODE_0 inputspeakermode,
        int inputchannels,
        FMOD_SPEAKERMODE_0 outputspeakermode,
        int outputchannels,
        void *extradata)
{
  float v9; // xmm1_4
  float mixmatrix[32][32]; // [rsp+10h] [rbp-1018h] BYREF

  this->mNumInputChannels = inputchannels;
  this->mSystem = system;
  memset(mixmatrix, 0, sizeof(mixmatrix));
  this->mDirectMapping = outputspeakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0
                      || inputspeakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_RAW_0;
  this->mNumOutputChannels = outputchannels;
  FMOD::DSPConnectionI::init(&this->mConnection, system, 1.0, v9);
  FMOD::DSPConnectionI::getDefaultMatrix(
    mixmatrix,
    this->mDirectMapping,
    this->mNumOutputChannels,
    this->mNumInputChannels,
    1.0);
  FMOD::DSPConnectionI::setMixMatrix(
    &this->mConnection,
    mixmatrix[0],
    this->mNumOutputChannels,
    this->mNumInputChannels,
    32,
    0,
    0);
  FMOD::DSPConnectionI::setMixInternal(&this->mConnection, 1.0, 0, 0);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222e0e0 | Name: _ZN4FMOD7DownMix7releaseEv
FMOD_RESULT_0 __fastcall FMOD::DownMix::release(FMOD::DownMix *const this)
{
  FMOD::DSPConnectionI::freeFromPool(&this->mConnection);
  FMOD::MemPool::free(off_286F358->gSystemMemPool, this, "../../../core_api/src/fmod_downmix.cpp", 61);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x222e120 | Name: _ZN4FMOD7DownMix6encodeEPfS1_j
FMOD_RESULT_0 __fastcall FMOD::DownMix::encode(
        FMOD::DownMix *const this,
        float *inbuffer,
        float *outbuffer,
        unsigned int numsamples)
{
  return FMOD::DSPConnectionI::mix(
           &this->mConnection,
           outbuffer,
           inbuffer,
           this->mDirectMapping,
           this->mNumOutputChannels,
           this->mNumInputChannels,
           numsamples,
           1);
}


