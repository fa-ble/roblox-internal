// Address: 0x21dfaa0 | Name: _ZN4FMOD12DSPResampler16getRealFrequencyEv
float __fastcall FMOD::DSPResampler::getRealFrequency(FMOD::DSPResampler *const this)
{
  __m128 v1; // xmm1
  float result; // xmm0_4
  __m128 v3; // xmm0

  result = 0.0;
  v1.m128_f32[0] = (float)((float)(int)this->mJob.mDelayClock.mRealPitch * 0.00000095367432) * this->mNoDMA->mFrequency;
  if ( v1.m128_f32[0] >= 0.0 )
  {
    v3 = _mm_cmplt_ss((__m128)0x49742400u, v1);
    LODWORD(result) = _mm_andnot_ps(v3, v1).m128_u32[0] | v3.m128_i32[0] & 0x49742400;
  }
  return result;
}


