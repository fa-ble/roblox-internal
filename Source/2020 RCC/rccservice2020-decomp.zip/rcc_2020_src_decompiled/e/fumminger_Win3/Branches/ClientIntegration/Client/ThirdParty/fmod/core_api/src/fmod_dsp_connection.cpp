// Address: 0x222a010 | Name: _ZN4FMOD13DSPConnection8getInputEPPNS_3DSPE
FMOD_RESULT_0 __fastcall FMOD::DSPConnection::getInput(FMOD::DSPConnection *const this, FMOD::DSP **input)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPConnectionI *dspconnectioni; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::DSPConnectionI::validate(this, &dspconnectioni, &lockScope);
  if ( (v2 || (v2 = FMOD::DSPConnectionI::getInput(dspconnectioni, (FMOD::DSPI **)input)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, input);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSPCONNECTION,
      this,
      "DSPConnection::getInput",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x222a0c0 | Name: _ZN4FMOD13DSPConnection9getOutputEPPNS_3DSPE
FMOD_RESULT_0 __fastcall FMOD::DSPConnection::getOutput(FMOD::DSPConnection *const this, FMOD::DSP **output)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPConnectionI *dspconnectioni; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::DSPConnectionI::validate(this, &dspconnectioni, &lockScope);
  if ( (v2 || (v2 = FMOD::DSPConnectionI::getOutput(dspconnectioni, (FMOD::DSPI **)output)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, output);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSPCONNECTION,
      this,
      "DSPConnection::getOutput",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x222a170 | Name: _ZN4FMOD13DSPConnection6setMixEf
__int64 __fastcall FMOD::DSPConnection::setMix(FMOD::DSPConnection *const this, float a2, float volume)
{
  FMOD_RESULT_0 v3; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-128h] BYREF
  FMOD::DSPConnectionI *dspconnectioni; // [rsp+18h] [rbp-120h] BYREF
  char _buffer[280]; // [rsp+20h] [rbp-118h] BYREF

  lockScope.mSystem = 0;
  v3 = FMOD::DSPConnectionI::validate(this, &dspconnectioni, &lockScope);
  if ( (v3 || (v3 = FMOD::DSPConnectionI::setMix(dspconnectioni, a2, 0x40u, 1, 0)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, volume);
    FMOD_ReportError(
      v3,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSPCONNECTION,
      this,
      "DSPConnection::setMix",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return (unsigned int)v3;
}


// Address: 0x222a230 | Name: _ZN4FMOD13DSPConnection6getMixEPf
FMOD_RESULT_0 __fastcall FMOD::DSPConnection::getMix(FMOD::DSPConnection *const this, float *volume)
{
  FMOD_RESULT_0 Mix; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPConnectionI *dspconnectioni; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  Mix = FMOD::DSPConnectionI::validate(this, &dspconnectioni, &lockScope);
  if ( (Mix || (Mix = FMOD::DSPConnectionI::getMix(dspconnectioni, volume)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, volume);
    FMOD_ReportError(
      Mix,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSPCONNECTION,
      this,
      "DSPConnection::getMix",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return Mix;
}


// Address: 0x222a2e0 | Name: _ZN4FMOD13DSPConnection12setMixMatrixEPfiii
FMOD_RESULT_0 __fastcall FMOD::DSPConnection::setMixMatrix(
        FMOD::DSPConnection *const this,
        float *matrix,
        int outchannels,
        int inchannels,
        int inchannel_hop)
{
  FMOD_RESULT_0 v7; // r13d
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r14d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::DSPConnectionI *dspconnectioni; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  v7 = FMOD::DSPConnectionI::validate(this, &dspconnectioni, &lockScope);
  if ( (v7
     || (v7 = FMOD::DSPConnectionI::setMixMatrix(dspconnectioni, matrix, outchannels, inchannels, inchannel_hop, 64, 1)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, matrix);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), outchannels);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = v11 + FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, inchannels);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), inchannel_hop);
    FMOD_ReportError(
      v7,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSPCONNECTION,
      this,
      "DSPConnection::setMixMatrix",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v7;
}


// Address: 0x222a480 | Name: _ZN4FMOD13DSPConnection12getMixMatrixEPfPiS2_i
FMOD_RESULT_0 __fastcall FMOD::DSPConnection::getMixMatrix(
        FMOD::DSPConnection *const this,
        float *matrix,
        int *outchannels,
        int *inchannels,
        int inchannel_hop)
{
  FMOD_RESULT_0 MixMatrix; // r13d
  int v9; // eax
  int v10; // r15d
  int v11; // r15d
  int v12; // r14d
  int v13; // eax
  int v15; // [rsp+Ch] [rbp-14Ch]
  FMOD::SystemLockScope lockScope; // [rsp+10h] [rbp-148h] BYREF
  FMOD::DSPConnectionI *dspconnectioni; // [rsp+18h] [rbp-140h] BYREF
  char _buffer[312]; // [rsp+20h] [rbp-138h] BYREF

  lockScope.mSystem = 0;
  MixMatrix = FMOD::DSPConnectionI::validate(this, &dspconnectioni, &lockScope);
  if ( (MixMatrix
     || (MixMatrix = FMOD::DSPConnectionI::getMixMatrix(dspconnectioni, matrix, outchannels, inchannels, inchannel_hop)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    v15 = FMOD::FMOD_FormatArg(_buffer, 256, matrix);
    v9 = FMOD::FMOD_FormatArg(&_buffer[v15], 256 - v15, ", ");
    v10 = v9 + v15 + FMOD::FMOD_FormatArg(&_buffer[v9 + v15], 256 - (v9 + v15), outchannels);
    v11 = FMOD::FMOD_FormatArg(&_buffer[v10], 256 - v10, ", ") + v10;
    v12 = v11 + FMOD::FMOD_FormatArg(&_buffer[v11], 256 - v11, inchannels);
    v13 = FMOD::FMOD_FormatArg(&_buffer[v12], 256 - v12, ", ");
    FMOD::FMOD_FormatArg(&_buffer[v13 + v12], 256 - (v13 + v12), inchannel_hop);
    FMOD_ReportError(
      MixMatrix,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSPCONNECTION,
      this,
      "DSPConnection::getMixMatrix",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return MixMatrix;
}


// Address: 0x222a610 | Name: _ZN4FMOD13DSPConnection7getTypeEP23FMOD_DSPCONNECTION_TYPE
FMOD_RESULT_0 __fastcall FMOD::DSPConnection::getType(FMOD::DSPConnection *const this, FMOD_DSPCONNECTION_TYPE_1 *type)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPConnectionI *dspconnectioni; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::DSPConnectionI::validate(this, &dspconnectioni, &lockScope);
  if ( (v2 || (v2 = FMOD::DSPConnectionI::getType(dspconnectioni, type)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, type);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSPCONNECTION,
      this,
      "DSPConnection::getType",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x222a6c0 | Name: _ZN4FMOD13DSPConnection11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::DSPConnection::setUserData(FMOD::DSPConnection *const this, void *_userdata)
{
  FMOD_RESULT_0 v2; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPConnectionI *dspconnectioni; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  v2 = FMOD::DSPConnectionI::validate(this, &dspconnectioni, &lockScope);
  if ( (v2 || (v2 = FMOD::DSPConnectionI::setUserData(dspconnectioni, _userdata)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      v2,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSPCONNECTION,
      this,
      "DSPConnection::setUserData",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return v2;
}


// Address: 0x222a770 | Name: _ZN4FMOD13DSPConnection11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::DSPConnection::getUserData(FMOD::DSPConnection *const this, void **_userdata)
{
  FMOD_RESULT_0 UserData; // ebx
  FMOD::SystemLockScope lockScope; // [rsp+0h] [rbp-138h] BYREF
  FMOD::DSPConnectionI *dspconnectioni; // [rsp+8h] [rbp-130h] BYREF
  char _buffer[296]; // [rsp+10h] [rbp-128h] BYREF

  lockScope.mSystem = 0;
  UserData = FMOD::DSPConnectionI::validate(this, &dspconnectioni, &lockScope);
  if ( (UserData || (UserData = FMOD::DSPConnectionI::getUserData(dspconnectioni, _userdata)) != FMOD_RESULT::FMOD_OK_0)
    && SLOBYTE(off_286F358->gSystemCallbackMask) < 0 )
  {
    FMOD::FMOD_FormatArg(_buffer, 256, _userdata);
    FMOD_ReportError(
      UserData,
      FMOD_ERRORCALLBACK_INSTANCETYPE::FMOD_ERRORCALLBACK_INSTANCETYPE_DSPCONNECTION,
      this,
      "DSPConnection::getUserData",
      _buffer);
  }
  if ( lockScope.mSystem )
    FMOD::SystemI::leaveMainUpdateLock(lockScope.mSystem);
  return UserData;
}


