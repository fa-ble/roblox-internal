// Address: 0x2244660 | Name: _Z16FMOD_OS_Net_Initv
FMOD_RESULT_0 __cdecl FMOD_OS_Net_Init()
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2244670 | Name: _Z20FMOD_OS_Net_Shutdownv
FMOD_RESULT_0 __cdecl FMOD_OS_Net_Shutdown()
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2244680 | Name: _Z24FMOD_OS_Net_SetKeepAlivei
FMOD_RESULT_0 __fastcall FMOD_OS_Net_SetKeepAlive(int socket)
{
  int v2; // edx
  int keepalive; // [rsp+0h] [rbp-18h] BYREF
  int keepaliveCount; // [rsp+4h] [rbp-14h] BYREF
  int keepaliveTime; // [rsp+8h] [rbp-10h] BYREF
  int keepaliveInt[3]; // [rsp+Ch] [rbp-Ch] BYREF

  keepalive = 1;
  if ( setsockopt(socket, 1, 9, &keepalive, 4u) == -1 )
    return FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
  keepaliveCount = 10;
  if ( setsockopt(socket, 6, 6, &keepaliveCount, 4u) == -1 )
    return FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
  v2 = 1;
  if ( FMOD_Net_Timeout / keepaliveCount > 1999 )
    v2 = FMOD_Net_Timeout / keepaliveCount / 1000;
  keepaliveTime = v2;
  if ( setsockopt(socket, 6, 4, &keepaliveTime, 4u) == -1 )
    return FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
  keepaliveInt[0] = keepaliveTime;
  if ( setsockopt(socket, 6, 5, keepaliveInt, 4u) == -1 )
    return FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2244780 | Name: _Z26FMOD_OS_Net_SetNonBlockingib
FMOD_RESULT_0 __fastcall FMOD_OS_Net_SetNonBlocking(int socket, bool nonblocking)
{
  unsigned int v2; // eax
  __int64 v3; // rdx

  v2 = fcntl(socket, 3);
  if ( v2 == -1 )
    return FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
  v3 = v2;
  BYTE1(v2) &= ~8u;
  BYTE1(v3) |= 8u;
  if ( !nonblocking )
    v3 = v2;
  if ( fcntl(socket, 4, v3) == -1 )
    return FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
  else
    return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22447e0 | Name: _Z23FMOD_OS_Net_SetNoSignali
FMOD_RESULT_0 __fastcall FMOD_OS_Net_SetNoSignal(int socket)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22447f0 | Name: _Z19FMOD_OS_Net_ConnectPKctbPPv
FMOD_RESULT_0 __fastcall FMOD_OS_Net_Connect(
        const char *host,
        const unsigned __int16 port,
        bool nonblocking,
        void **handle)
{
  FMOD_RESULT_0 v6; // ebx
  int v8; // eax
  int mSocket; // eax
  int v10; // edi
  int v11; // eax
  int v12; // eax
  FMOD_RESULT_0 v13; // eax
  void *v14; // rax
  int connectErr; // [rsp+8h] [rbp-110h] BYREF
  socklen_t connectErrSize; // [rsp+Ch] [rbp-10Ch] BYREF
  char portString[16]; // [rsp+10h] [rbp-108h] BYREF
  FMOD_OS_Net_Connect::AutoClean autoClean; // [rsp+20h] [rbp-F8h] BYREF
  timeval timeValue; // [rsp+30h] [rbp-E8h] BYREF
  addrinfo hints; // [rsp+40h] [rbp-D8h] BYREF
  fd_set_0 writeDescriptor; // [rsp+70h] [rbp-A8h] BYREF

  autoClean.mSocket = -1;
  autoClean.mAddress = 0;
  *(_QWORD *)portString = 0;
  memset(&hints, 0, sizeof(hints));
  hints.ai_socktype = 1;
  hints.ai_flags = 1024;
  sprintf(portString, "%d", port);
  v6 = FMOD_RESULT::FMOD_ERR_NET_URL_0;
  if ( getaddrinfo(host, portString, &hints, &autoClean.mAddress) )
    goto LABEL_2;
  LOBYTE(v6) = 43;
  v8 = socket(autoClean.mAddress->ai_family, autoClean.mAddress->ai_socktype, autoClean.mAddress->ai_protocol);
  autoClean.mSocket = v8;
  if ( v8 == -1 )
    goto LABEL_4;
  v6 = FMOD_OS_Net_SetNonBlocking(v8, 1);
  if ( v6 )
    goto LABEL_2;
  v6 = FMOD_OS_Net_SetKeepAlive(autoClean.mSocket);
  if ( v6 )
    goto LABEL_2;
  v6 = FMOD_OS_Net_SetNoSignal(autoClean.mSocket);
  if ( v6 )
    goto LABEL_2;
  if ( connect(autoClean.mSocket, autoClean.mAddress->ai_addr, autoClean.mAddress->ai_addrlen) == -1 )
  {
    v12 = *__errno_location();
    if ( v12 != 115 && v12 != 11 )
      goto LABEL_15;
  }
  memset(&writeDescriptor, 0, sizeof(writeDescriptor));
  mSocket = autoClean.mSocket + 63;
  v10 = autoClean.mSocket + 1;
  if ( autoClean.mSocket >= 0 )
    mSocket = autoClean.mSocket;
  writeDescriptor.fds_bits[mSocket >> 6] |= 1LL << (autoClean.mSocket % 64);
  timeValue.tv_sec = FMOD_Net_Timeout / 1000;
  timeValue.tv_usec = 1000 * (FMOD_Net_Timeout % 1000);
  v11 = select(v10, 0, (fd_set *)&writeDescriptor, 0, &timeValue);
  if ( !v11 )
    goto LABEL_15;
  if ( v11 == -1
    || (connectErr = 0, connectErrSize = 4, getsockopt(autoClean.mSocket, 1, 4, &connectErr, &connectErrSize) == -1) )
  {
    v6 = FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
  }
  else
  {
    if ( connectErr )
    {
LABEL_15:
      v6 = FMOD_RESULT::FMOD_ERR_NET_CONNECT_0;
      goto LABEL_2;
    }
    v13 = FMOD_OS_Net_SetNonBlocking(autoClean.mSocket, nonblocking);
    if ( v13 == FMOD_RESULT::FMOD_OK_0 )
    {
      v14 = (void *)autoClean.mSocket;
      v6 = FMOD_RESULT::FMOD_OK_0;
      autoClean.mSocket = -1;
      *handle = v14;
      goto LABEL_4;
    }
    v6 = v13;
  }
LABEL_2:
  if ( autoClean.mSocket != -1 )
    close(autoClean.mSocket);
LABEL_4:
  if ( autoClean.mAddress )
    freeaddrinfo(autoClean.mAddress);
  return v6;
}


// Address: 0x2244a40 | Name: _Z18FMOD_OS_Net_ListentbPPv
FMOD_RESULT_0 __fastcall FMOD_OS_Net_Listen(const unsigned __int16 port, bool nonblocking, void **handle)
{
  int v4; // eax
  void *v5; // rbp
  FMOD_RESULT_0 v6; // ebx
  int optVal; // [rsp+Ch] [rbp-3Ch] BYREF
  sockaddr_in server; // [rsp+10h] [rbp-38h] BYREF

  v4 = socket(2, 1, 0);
  v5 = (void *)v4;
  if ( v4 == -1 )
    return FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
  v6 = FMOD_OS_Net_SetNonBlocking(v4, nonblocking);
  if ( v6 == FMOD_RESULT::FMOD_OK_0 )
  {
    v6 = FMOD_OS_Net_SetNoSignal((int)v5);
    if ( v6 == FMOD_RESULT::FMOD_OK_0 )
    {
      optVal = 1;
      if ( setsockopt((int)v5, 1, 2, &optVal, 4u) != -1 )
      {
        *(_QWORD *)server.sin_zero = 0;
        *(_QWORD *)&server.sin_family = 2;
        server.sin_port = __ROL2__(port, 8);
        if ( bind((int)v5, (const struct sockaddr *)&server, 0x10u) != -1 && listen((int)v5, 3) != -1 )
        {
          *handle = v5;
          return v6;
        }
      }
      return FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
    }
  }
  return v6;
}


// Address: 0x2244b30 | Name: _Z18FMOD_OS_Net_AcceptPKvbPPv
FMOD_RESULT_0 __fastcall FMOD_OS_Net_Accept(const void *listenHandle, bool nonblocking, void **clientHandle)
{
  int v4; // eax
  void *v5; // rbx
  FMOD_RESULT_0 result; // eax

  v4 = accept((int)listenHandle, 0, 0);
  v5 = (void *)v4;
  if ( v4 == -1 )
    return 2 * (*__errno_location() == 11) + 43;
  result = FMOD_OS_Net_SetNonBlocking(v4, nonblocking);
  if ( result == FMOD_RESULT::FMOD_OK_0 )
  {
    result = FMOD_OS_Net_SetNoSignal((int)v5);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
      *clientHandle = v5;
  }
  return result;
}


// Address: 0x2244ba0 | Name: _Z17FMOD_OS_Net_ClosePKv
FMOD_RESULT_0 __fastcall FMOD_OS_Net_Close(const void *handle)
{
  FMOD_RESULT_0 v1; // ebx

  v1 = FMOD_RESULT::FMOD_OK_0;
  if ( (_DWORD)handle != -1 )
  {
    shutdown((int)handle, 2);
    if ( close((int)handle) == -1 )
      return FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
  }
  return v1;
}


// Address: 0x2244be0 | Name: _Z17FMOD_OS_Net_WritePKvPKcjPj
FMOD_RESULT_0 __fastcall FMOD_OS_Net_Write(
        const void *handle,
        const char *buff,
        const unsigned int len,
        unsigned int *bytesWritten)
{
  unsigned int v6; // ebx
  ssize_t v7; // rax

  v6 = len;
  *bytesWritten = 0;
  if ( !len )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    v7 = send((int)handle, buff, v6, 0x4000);
    if ( v7 == -1 )
      break;
    *bytesWritten += v7;
    buff += v7;
    v6 -= v7;
    if ( !v6 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  return 2 * (*__errno_location() == 11) + 43;
}


// Address: 0x2244c60 | Name: _Z16FMOD_OS_Net_ReadPKvPcjPj
FMOD_RESULT_0 __fastcall FMOD_OS_Net_Read(
        const void *handle,
        char *buff,
        const unsigned int len,
        unsigned int *bytesRead)
{
  signed int v6; // ebx
  ssize_t v7; // rax
  int v8; // edx
  FMOD_RESULT_0 result; // eax

  v6 = len;
  *bytesRead = 0;
  if ( !len )
    return FMOD_RESULT::FMOD_OK_0;
  while ( 1 )
  {
    v7 = recv((int)handle, buff, v6, 0);
    if ( v7 == -1 )
      break;
    if ( !v7 )
      return FMOD_RESULT::FMOD_ERR_FILE_EOF_0;
    *bytesRead += v7;
    buff += v7;
    v6 -= v7;
    if ( !v6 )
      return FMOD_RESULT::FMOD_OK_0;
  }
  v8 = *__errno_location();
  result = FMOD_RESULT::FMOD_ERR_NET_WOULD_BLOCK_0;
  if ( v8 != 11 )
  {
    LOBYTE(result) = 16;
    if ( v8 != 104 )
      return FMOD_RESULT::FMOD_ERR_NET_SOCKET_ERROR_0;
  }
  return result;
}


