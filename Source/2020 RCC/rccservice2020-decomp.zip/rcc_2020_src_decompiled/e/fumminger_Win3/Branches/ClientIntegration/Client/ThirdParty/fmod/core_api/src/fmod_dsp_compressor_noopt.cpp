// Address: 0x21c6480 | Name: FMOD_DSP_Compressor_1channel_NoOpt
void __fastcall FMOD_DSP_Compressor_1channel_NoOpt(
        float *in,
        float *out,
        float *analysis,
        int length,
        float *envelopeStage1,
        float *envelope,
        float gainExponent,
        float gainMakeup,
        float attackTime,
        __m128 releaseTime,
        float envelopeThreshold,
        float inverseEnvelopeThreshold)
{
  float v12; // xmm8_4
  float *v13; // r15
  float *v18; // rbx
  float v19; // xmm0_4
  float v20; // xmm0_4
  __m128 v21; // xmm0
  float v22; // xmm6_4
  __m128 v23; // xmm5
  float v24; // xmm0_4
  float v25; // [rsp+14h] [rbp-44h]

  v12 = gainMakeup;
  v13 = &in[length - 1 + 1];
  v18 = in;
  if ( length > 0 )
  {
    do
    {
      v21.m128_f32[0] = *analysis * *analysis;
      v22 = *envelope;
      v23 = _mm_cmplt_ss((__m128)*(unsigned int *)envelope, v21);
      v23.m128_i32[0] = _mm_andnot_ps(v23, releaseTime).m128_u32[0] | LODWORD(attackTime) & v23.m128_i32[0];
      v21.m128_f32[0] = (float)((float)(v21.m128_f32[0] - *envelopeStage1) * v23.m128_f32[0]) + *envelopeStage1;
      *envelopeStage1 = v21.m128_f32[0];
      v24 = (float)((float)(v21.m128_f32[0] - v22) * v23.m128_f32[0]) + v22;
      *envelope = v24;
      if ( v24 <= envelopeThreshold )
      {
        v19 = v12;
      }
      else
      {
        v25 = envelopeThreshold;
        v12 = gainMakeup;
        v19 = powf(v24 * inverseEnvelopeThreshold, gainExponent) * gainMakeup;
        releaseTime = (__m128)releaseTime.m128_u32[0];
        envelopeThreshold = v25;
      }
      v20 = v19 * *v18++;
      ++out;
      ++analysis;
      *(out - 1) = v20;
    }
    while ( v18 != v13 );
  }
}


// Address: 0x21c6590 | Name: FMOD_DSP_Compressor_2channel_NoOpt
void __fastcall FMOD_DSP_Compressor_2channel_NoOpt(
        float *in,
        float *out,
        float *analysis,
        int length,
        float *envelopeStage1,
        float *envelope,
        float gainExponent,
        float gainMakeup,
        float attackTime,
        __m128 releaseTime,
        float envelopeThreshold,
        float inverseEnvelopeThreshold)
{
  float *v13; // r15
  float *v18; // rbx
  float v19; // xmm0_4
  float v20; // xmm1_4
  float v21; // xmm1_4
  float v22; // xmm0_4
  float v23; // xmm6_4
  __m128 v24; // xmm0
  __m128 v25; // xmm5
  float v26; // xmm0_4
  float v27; // [rsp+14h] [rbp-44h]

  v13 = &in[2 * (length - 1) + 2];
  v18 = in;
  if ( length > 0 )
  {
    do
    {
      v23 = *envelope;
      v24.m128_f32[0] = (float)(analysis[1] * analysis[1]) + (float)(*analysis * *analysis);
      v25 = _mm_cmplt_ss((__m128)*(unsigned int *)envelope, v24);
      v25.m128_i32[0] = _mm_andnot_ps(v25, releaseTime).m128_u32[0] | LODWORD(attackTime) & v25.m128_i32[0];
      v24.m128_f32[0] = (float)((float)(v24.m128_f32[0] - *envelopeStage1) * v25.m128_f32[0]) + *envelopeStage1;
      *envelopeStage1 = v24.m128_f32[0];
      v26 = (float)((float)(v24.m128_f32[0] - v23) * v25.m128_f32[0]) + v23;
      *envelope = v26;
      if ( v26 <= envelopeThreshold )
      {
        v19 = gainMakeup;
      }
      else
      {
        v27 = envelopeThreshold;
        v19 = powf(v26 * inverseEnvelopeThreshold, gainExponent) * gainMakeup;
        releaseTime = (__m128)releaseTime.m128_u32[0];
        envelopeThreshold = v27;
      }
      v20 = *v18;
      v18 += 2;
      out += 2;
      v21 = v20 * v19;
      analysis += 2;
      v22 = v19 * *(v18 - 1);
      *(out - 2) = v21;
      *(out - 1) = v22;
    }
    while ( v18 != v13 );
  }
}


// Address: 0x21c66d0 | Name: FMOD_DSP_Compressor_6channel_NoOpt
void __fastcall FMOD_DSP_Compressor_6channel_NoOpt(
        float *in,
        float *out,
        float *analysis,
        int length,
        float *envelopeStage1,
        float *envelope,
        float gainExponent,
        float gainMakeup,
        float attackTime,
        __m128 releaseTime,
        float envelopeThreshold,
        float inverseEnvelopeThreshold)
{
  float *v12; // rbx
  float *v18; // r15
  float v19; // xmm0_4
  float v20; // xmm1_4
  float v21; // xmm1_4
  float v22; // xmm0_4
  float v23; // xmm1_4
  __m128 v24; // xmm0
  __m128 v25; // xmm5
  float v26; // xmm0_4
  float v27; // [rsp+14h] [rbp-44h]

  if ( length > 0 )
  {
    v12 = in;
    v18 = &in[6 * (length - 1) + 6];
    do
    {
      v23 = *envelope;
      v24.m128_f32[0] = (float)(analysis[5] * analysis[5])
                      + (float)((float)(analysis[4] * analysis[4])
                              + (float)((float)(analysis[3] * analysis[3])
                                      + (float)((float)(analysis[2] * analysis[2])
                                              + (float)((float)(analysis[1] * analysis[1])
                                                      + (float)(*analysis * *analysis)))));
      v25 = _mm_cmplt_ss((__m128)*(unsigned int *)envelope, v24);
      v25.m128_i32[0] = _mm_andnot_ps(v25, releaseTime).m128_u32[0] | LODWORD(attackTime) & v25.m128_i32[0];
      v24.m128_f32[0] = (float)((float)(v24.m128_f32[0] - *envelopeStage1) * v25.m128_f32[0]) + *envelopeStage1;
      *envelopeStage1 = v24.m128_f32[0];
      v26 = (float)((float)(v24.m128_f32[0] - v23) * v25.m128_f32[0]) + v23;
      *envelope = v26;
      if ( v26 <= envelopeThreshold )
      {
        v19 = gainMakeup;
      }
      else
      {
        v27 = envelopeThreshold;
        v19 = powf(v26 * inverseEnvelopeThreshold, gainExponent) * gainMakeup;
        releaseTime = (__m128)releaseTime.m128_u32[0];
        envelopeThreshold = v27;
      }
      v20 = *v12;
      v12 += 6;
      out += 6;
      analysis += 6;
      *(out - 6) = v20 * v19;
      *(out - 5) = *(v12 - 5) * v19;
      *(out - 4) = *(v12 - 4) * v19;
      *(out - 3) = *(v12 - 3) * v19;
      v21 = *(v12 - 2) * v19;
      v22 = v19 * *(v12 - 1);
      *(out - 2) = v21;
      *(out - 1) = v22;
    }
    while ( v12 != v18 );
  }
}


// Address: 0x21c6880 | Name: FMOD_DSP_Compressor_8channel_NoOpt
void __fastcall FMOD_DSP_Compressor_8channel_NoOpt(
        float *in,
        float *out,
        float *analysis,
        int length,
        float *envelopeStage1,
        float *envelope,
        float gainExponent,
        float gainMakeup,
        float attackTime,
        __m128 releaseTime,
        float envelopeThreshold,
        float inverseEnvelopeThreshold)
{
  float *v16; // rbx
  float *v18; // r15
  float v19; // xmm0_4
  float v20; // xmm1_4
  float v21; // xmm1_4
  float v22; // xmm0_4
  __m128 v23; // xmm0
  float v24; // xmm5_4
  __m128 v25; // xmm1
  float v26; // xmm0_4
  float v27; // [rsp+14h] [rbp-44h]

  if ( length > 0 )
  {
    v16 = in;
    v18 = &in[8 * (length - 1) + 8];
    do
    {
      v23.m128_f32[0] = (float)(analysis[7] * analysis[7])
                      + (float)((float)(analysis[6] * analysis[6])
                              + (float)((float)(analysis[5] * analysis[5])
                                      + (float)((float)(analysis[4] * analysis[4])
                                              + (float)((float)(analysis[3] * analysis[3])
                                                      + (float)((float)(analysis[2] * analysis[2])
                                                              + (float)((float)(analysis[1] * analysis[1])
                                                                      + (float)(*analysis * *analysis)))))));
      v24 = *envelope;
      v25 = _mm_cmplt_ss((__m128)*(unsigned int *)envelope, v23);
      v25.m128_i32[0] = _mm_andnot_ps(v25, releaseTime).m128_u32[0] | LODWORD(attackTime) & v25.m128_i32[0];
      v23.m128_f32[0] = (float)((float)(v23.m128_f32[0] - *envelopeStage1) * v25.m128_f32[0]) + *envelopeStage1;
      *envelopeStage1 = v23.m128_f32[0];
      v26 = (float)((float)(v23.m128_f32[0] - v24) * v25.m128_f32[0]) + v24;
      *envelope = v26;
      if ( v26 <= envelopeThreshold )
      {
        v19 = gainMakeup;
      }
      else
      {
        v27 = envelopeThreshold;
        v19 = powf(v26 * inverseEnvelopeThreshold, gainExponent) * gainMakeup;
        releaseTime = (__m128)releaseTime.m128_u32[0];
        envelopeThreshold = v27;
      }
      v20 = *v16;
      v16 += 8;
      out += 8;
      analysis += 8;
      *(out - 8) = v20 * v19;
      *(out - 7) = *(v16 - 7) * v19;
      *(out - 6) = *(v16 - 6) * v19;
      *(out - 5) = *(v16 - 5) * v19;
      *(out - 4) = *(v16 - 4) * v19;
      *(out - 3) = *(v16 - 3) * v19;
      v21 = *(v16 - 2) * v19;
      v22 = v19 * *(v16 - 1);
      *(out - 2) = v21;
      *(out - 1) = v22;
    }
    while ( v16 != v18 );
  }
}


