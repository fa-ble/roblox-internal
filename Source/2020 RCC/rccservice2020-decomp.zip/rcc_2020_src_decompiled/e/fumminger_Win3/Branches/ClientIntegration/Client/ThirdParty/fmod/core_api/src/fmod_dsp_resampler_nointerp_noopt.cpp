// Address: 0x221fd40 | Name: FMOD_Resampler_NoInterp_PCM16_Mono_NoOpt
void __fastcall FMOD_Resampler_NoInterp_PCM16_Mono_NoOpt(
        float *out,
        int outlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  FMOD_UINT64 mValue; // r10
  int v6; // ebx
  float *v7; // rax
  FMOD_SINT64 v8; // r11
  FMOD_SINT64 v9; // r12
  FMOD_UINT64 v10; // r9
  FMOD_UINT64 v11; // r10
  int v12; // ebp
  float v13; // xmm4_4
  int v14; // ebp
  float v15; // xmm3_4
  FMOD_UINT64 v16; // rbp
  float v17; // xmm2_4
  FMOD_UINT64 v18; // rbp
  int v19; // esi
  FMOD_SINT64 v20; // r9
  FMOD_UINT64 v21; // rax

  if ( outlength >> 2 )
  {
    mValue = position->mValue;
    v6 = outlength >> 2;
    v7 = out;
    v8 = 2 * speed->mValue;
    v9 = 4 * speed->mValue;
    v10 = position->mValue + speed->mValue;
    do
    {
      v11 = v8 + mValue;
      v7 += 4;
      v12 = *((__int16 *)src + position->mHi);
      position->mValue = v10;
      v13 = (float)v12;
      v14 = *((__int16 *)src + HIDWORD(v10));
      position->mValue = v11;
      v15 = (float)v14;
      v16 = HIDWORD(v11);
      mValue = v8 + v11;
      v17 = (float)*((__int16 *)src + v16);
      v18 = v8 + v10;
      v10 += v9;
      position->mValue = v18;
      LODWORD(v18) = *((__int16 *)src + HIDWORD(v18));
      position->mValue = mValue;
      *(v7 - 4) = v13 * 0.000030517578;
      *(v7 - 3) = v15 * 0.000030517578;
      *(v7 - 2) = v17 * 0.000030517578;
      *(v7 - 1) = (float)(int)v18 * 0.000030517578;
      --v6;
    }
    while ( v6 );
    out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
  }
  v19 = outlength & 3;
  if ( v19 )
  {
    v20 = speed->mValue;
    v21 = position->mValue + speed->mValue;
    do
    {
      *out++ = (float)*((__int16 *)src + position->mHi) * 0.000030517578;
      position->mValue = v21;
      v21 += v20;
      --v19;
    }
    while ( v19 );
  }
}


// Address: 0x221fe50 | Name: FMOD_Resampler_NoInterp_PCM16_Stereo_NoOpt
void __fastcall FMOD_Resampler_NoInterp_PCM16_Stereo_NoOpt(
        float *out,
        int outlength,
        void *src,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed)
{
  FMOD_UINT64 mValue; // r10
  int v6; // ebx
  float *v7; // rax
  FMOD_SINT64 v8; // r11
  FMOD_SINT64 v9; // r12
  FMOD_UINT64 v10; // r9
  FMOD_UINT64 v11; // r10
  __int64 v12; // r14
  __int64 v13; // rbp
  float v14; // xmm8_4
  float v15; // xmm7_4
  __int64 v16; // r14
  __int64 v17; // rbp
  float v18; // xmm6_4
  float v19; // xmm5_4
  __int64 v20; // r14
  float v21; // xmm3_4
  FMOD_UINT64 v22; // rbp
  float v23; // xmm4_4
  __int64 v24; // r14
  __int64 v25; // rbp
  int v26; // esi
  FMOD_SINT64 v27; // r10
  FMOD_UINT64 v28; // rax
  __int64 v29; // r9
  int v30; // r8d

  if ( outlength >> 2 )
  {
    mValue = position->mValue;
    v6 = outlength >> 2;
    v7 = out;
    v8 = 2 * speed->mValue;
    v9 = 4 * speed->mValue;
    v10 = position->mValue + speed->mValue;
    do
    {
      v11 = v8 + mValue;
      v7 += 8;
      v12 = 2 * position->mHi;
      v13 = (unsigned int)(v12 + 1);
      LODWORD(v12) = *((__int16 *)src + v12);
      LODWORD(v13) = *((__int16 *)src + v13);
      position->mValue = v10;
      v14 = (float)(int)v12;
      v15 = (float)(int)v13;
      v16 = (unsigned int)(2 * HIDWORD(v10));
      v17 = (unsigned int)(v16 + 1);
      LODWORD(v16) = *((__int16 *)src + v16);
      LODWORD(v17) = *((__int16 *)src + v17);
      position->mValue = v11;
      v18 = (float)(int)v16;
      v19 = (float)(int)v17;
      LODWORD(v17) = HIDWORD(v11);
      mValue = v8 + v11;
      v20 = (unsigned int)(2 * v17);
      v21 = (float)*((__int16 *)src + (unsigned int)(v20 + 1));
      v22 = v8 + v10;
      v23 = (float)*((__int16 *)src + v20);
      v10 += v9;
      position->mValue = v22;
      v24 = (unsigned int)(2 * HIDWORD(v22));
      v25 = (unsigned int)(v24 + 1);
      LODWORD(v24) = *((__int16 *)src + v24);
      LODWORD(v25) = *((__int16 *)src + v25);
      position->mValue = mValue;
      *(v7 - 8) = v14 * 0.000030517578;
      *(v7 - 7) = v15 * 0.000030517578;
      *(v7 - 6) = v18 * 0.000030517578;
      *(v7 - 5) = v19 * 0.000030517578;
      *(v7 - 3) = v21 * 0.000030517578;
      *(v7 - 4) = v23 * 0.000030517578;
      *(v7 - 2) = (float)(int)v24 * 0.000030517578;
      *(v7 - 1) = (float)(int)v25 * 0.000030517578;
      --v6;
    }
    while ( v6 );
    out += 8 * (unsigned int)((outlength >> 2) - 1) + 8;
  }
  v26 = outlength & 3;
  if ( v26 )
  {
    v27 = speed->mValue;
    v28 = position->mValue + speed->mValue;
    do
    {
      out += 2;
      v29 = 2 * position->mHi;
      v30 = *((__int16 *)src + (unsigned int)(v29 + 1));
      *(out - 2) = (float)*((__int16 *)src + v29) * 0.000030517578;
      *(out - 1) = (float)v30 * 0.000030517578;
      position->mValue = v28;
      v28 += v27;
      --v26;
    }
    while ( v26 );
  }
}


