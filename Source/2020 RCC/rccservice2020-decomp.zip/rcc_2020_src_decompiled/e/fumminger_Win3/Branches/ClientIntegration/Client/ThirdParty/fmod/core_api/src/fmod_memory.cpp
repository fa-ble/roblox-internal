// Address: 0x22127a0 | Name: _ZN4FMOD20Memory_DefaultMallocEjjPKc
// attributes: thunk
void *__fastcall FMOD::Memory_DefaultMalloc(unsigned int size, FMOD_MEMORY_TYPE type, const char *sourcestr)
{
  return FMOD_OS_Memory_Alloc(size, type);
}


// Address: 0x22127b0 | Name: _ZN4FMOD21Memory_DefaultReallocEPvjjPKc
// attributes: thunk
void *__fastcall FMOD::Memory_DefaultRealloc(
        void *data,
        unsigned int size,
        FMOD_MEMORY_TYPE type,
        const char *sourcestr)
{
  return FMOD_OS_Memory_Realloc(data, size, type);
}


// Address: 0x22127c0 | Name: _ZN4FMOD18Memory_DefaultFreeEPvjPKc
// Alternative name is 'j_j_.free_3'
// attributes: thunk
void __fastcall FMOD::Memory_DefaultFree(void *ptr, FMOD_MEMORY_TYPE type, const char *sourcestr)
{
  FMOD_OS_Memory_Free(ptr, type);
}


// Address: 0x22127d0 | Name: _ZN4FMOD7MemPoolC2Ev
void __fastcall FMOD::MemPool::MemPool(FMOD::MemPool *const this)
{
  this->mCrit = 0;
  this->mCurrentAllocated = 0;
  this->mDLMallocSpace = 0;
  this->mUserPool = 0;
  this->mPoolMemoryType = 0;
  this->mAlloc = FMOD::Memory_DefaultMalloc;
  this->mRealloc = FMOD::Memory_DefaultRealloc;
  this->mFree = FMOD::Memory_DefaultFree;
}


// Address: 0x2212830 | Name: _ZN4FMOD7MemPool3setEiii
void __fastcall FMOD::MemPool::set(FMOD::MemPool *const this, int blockoffset, int value, int numblocks)
{
  int v5; // r15d
  int v9; // ecx
  int v10; // ebx
  int v11; // edx
  int v12; // eax
  int v13; // r8d
  unsigned __int8 *v14; // rdx
  int v15; // edi
  int v16; // eax
  unsigned __int8 *v17; // r8
  int v18; // esi
  int mFirstFreeBlock; // eax
  int v20; // edx
  unsigned __int8 *mBitmap; // r8
  unsigned int v22; // ecx
  int v23; // edx
  int mSizeBlocks; // r9d
  int v25; // esi
  int v26; // edi
  int v27; // ecx
  unsigned __int8 *v28; // rdx
  int v29; // eax
  int bitoffset; // [rsp+Ch] [rbp-3Ch]

  v5 = numblocks;
  v9 = blockoffset & 7;
  v10 = blockoffset / 8;
  v11 = blockoffset & 0x1F;
  if ( (blockoffset & 0x1F) != 0 )
  {
    v12 = 32 - v11;
    if ( 32 - v11 > numblocks )
      v12 = numblocks;
    v13 = v12;
    if ( v12 )
    {
      do
      {
        v14 = &this->mBitmap[v10];
        v15 = 1 << v9;
        if ( value )
          *v14 |= v15;
        else
          *v14 &= ~(_BYTE)v15;
        if ( ++v9 == 8 )
        {
          ++v10;
          LOBYTE(v9) = 0;
        }
        --v12;
      }
      while ( v12 );
      v5 = numblocks - v13;
    }
    else
    {
      v5 = numblocks;
    }
  }
  if ( v5 / 8 )
  {
    bitoffset = v9;
    memset(&this->mBitmap[v10], (unsigned __int8)-(value != 0), v5 / 8);
    v9 = bitoffset;
    v10 += v5 / 8;
    LOBYTE(v5) = v5 % 8;
  }
  v16 = v5 & 0x1F;
  if ( (v5 & 0x1F) != 0 )
  {
    do
    {
      v17 = &this->mBitmap[v10];
      v18 = 1 << v9;
      if ( value )
        *v17 |= v18;
      else
        *v17 &= ~(_BYTE)v18;
      if ( ++v9 == 8 )
      {
        ++v10;
        LOBYTE(v9) = 0;
      }
      --v16;
    }
    while ( v16 );
  }
  if ( value )
  {
    mFirstFreeBlock = this->mFirstFreeBlock;
    if ( mFirstFreeBlock == blockoffset )
    {
      mFirstFreeBlock = numblocks + blockoffset;
      this->mFirstFreeBlock = numblocks + blockoffset;
    }
    v20 = mFirstFreeBlock + 7;
    mBitmap = this->mBitmap;
    v22 = mFirstFreeBlock & 7;
    if ( mFirstFreeBlock >= 0 )
      v20 = mFirstFreeBlock;
    v23 = mBitmap[v20 >> 3];
    if ( _bittest(&v23, v22) )
    {
      mSizeBlocks = this->mSizeBlocks;
      v25 = 1 << v22;
      v26 = mFirstFreeBlock >> 3;
      v27 = 0;
LABEL_34:
      if ( mSizeBlocks > mFirstFreeBlock )
      {
        while ( !v27 )
        {
          v28 = &mBitmap[v26];
          if ( ((unsigned __int8)v25 & *v28) != 0 )
          {
            v27 = 0;
            if ( (mFirstFreeBlock & 0x1F) == 0 && *(_DWORD *)v28 == -1 )
            {
              v26 += 4;
              mFirstFreeBlock += 32;
              goto LABEL_34;
            }
          }
          else if ( (mFirstFreeBlock & 0x1F) != 0 )
          {
            v27 = 1;
          }
          else
          {
            if ( *(_DWORD *)v28 == -1 )
            {
              v27 = 0;
              v26 += 4;
              mFirstFreeBlock += 32;
              goto LABEL_34;
            }
            v27 = 1;
          }
          ++mFirstFreeBlock;
          LOBYTE(v25) = 2 * v25;
          if ( (mFirstFreeBlock & 7) != 0 )
            goto LABEL_34;
          ++v26;
          LOBYTE(v25) = 1;
          if ( mSizeBlocks <= mFirstFreeBlock )
            break;
        }
      }
      if ( v27 == 1 )
        v29 = mFirstFreeBlock - 1;
      else
        v29 = -1;
      this->mFirstFreeBlock = v29;
    }
  }
  else if ( blockoffset < this->mFirstFreeBlock )
  {
    this->mFirstFreeBlock = blockoffset;
  }
}


// Address: 0x2212a90 | Name: _ZN4FMOD7MemPool5allocEiPKcijb
void *__fastcall FMOD::MemPool::alloc(
        FMOD::MemPool *const this,
        int len_original,
        const char *file,
        const int line,
        FMOD_MEMORY_TYPE type,
        bool clear)
{
  FMOD_OS_CRITICALSECTION *mCrit; // rdi
  FMOD_MEMORY_ALLOC_CALLBACK mAlloc; // rax
  int v12; // r13d
  FMOD_MEMORY_TYPE v13; // r15d
  int *v14; // rax
  void *v15; // r15
  unsigned int v16; // eax
  bool v17; // cc
  int mFirstFreeBlock; // edi
  int mSizeBlocks; // r15d
  int v21; // r8d
  int v22; // r10d
  int v23; // eax
  int v24; // r9d
  unsigned __int8 *v25; // rsi
  int v26; // edi
  _DWORD *v27; // rax
  void *v28; // rax
  char fileLine[312]; // [rsp+10h] [rbp-138h] BYREF

  mCrit = this->mCrit;
  if ( !mCrit )
  {
    if ( FMOD_OS_CriticalSection_Create(&this->mCrit, 1) )
      return 0;
    mCrit = this->mCrit;
  }
  FMOD_OS_CriticalSection_Enter(mCrit);
  mAlloc = this->mAlloc;
  if ( mAlloc )
  {
    v12 = len_original + 8;
    v13 = off_286F358->gMemoryTypeFlags & type;
    v14 = (int *)mAlloc(len_original + 8, v13, 0);
    if ( v14 )
    {
      v14[1] = v13;
      *v14 = v12;
      v15 = v14 + 2;
      if ( v14 != (int *)-8LL )
        goto LABEL_5;
    }
    goto LABEL_33;
  }
  if ( !this->mCustomPool )
  {
    v28 = FMOD::mspace_malloc(this->mDLMallocSpace, len_original);
    v15 = v28;
    if ( v28 )
    {
      v12 = FMOD::mspace_chunksize(v28);
      goto LABEL_5;
    }
LABEL_32:
    v12 = len_original;
LABEL_33:
    FMOD_OS_CriticalSection_Leave(this->mCrit);
    if ( off_286F358->gSystemCallback && (off_286F358->gSystemCallbackMask & 4) != 0 )
    {
      sprintf(fileLine, "%s (%d)", file, line);
      off_286F358->gSystemCallback(0, 4, fileLine, (void *)v12, off_286F358->gSystemUserData);
      return 0;
    }
    return 0;
  }
  mFirstFreeBlock = this->mFirstFreeBlock;
  mSizeBlocks = this->mSizeBlocks;
  v21 = 0;
  v22 = mFirstFreeBlock >> 3;
  v23 = (this->mBlockSize + len_original - 1) / this->mBlockSize;
  v24 = 1 << (this->mFirstFreeBlock & 7);
LABEL_13:
  if ( mSizeBlocks > mFirstFreeBlock )
  {
    while ( 1 )
    {
      if ( v23 <= v21 )
        goto LABEL_19;
      v25 = &this->mBitmap[v22];
      if ( ((unsigned __int8)v24 & *v25) != 0 )
        break;
      if ( (mFirstFreeBlock & 0x1F) == 0 && *(_DWORD *)v25 == -1 )
      {
        v21 = 0;
LABEL_29:
        v22 += 4;
        mFirstFreeBlock += 32;
        goto LABEL_13;
      }
      ++v21;
      if ( (mFirstFreeBlock & 0x1F) == 0 )
        goto LABEL_28;
LABEL_17:
      ++mFirstFreeBlock;
      LOBYTE(v24) = 2 * v24;
      if ( (mFirstFreeBlock & 7) != 0 )
        goto LABEL_13;
      ++v22;
      LOBYTE(v24) = 1;
      if ( mSizeBlocks <= mFirstFreeBlock )
        goto LABEL_19;
    }
    v21 = 0;
    if ( (mFirstFreeBlock & 0x1F) != 0 )
      goto LABEL_17;
LABEL_28:
    if ( *(_DWORD *)v25 == -1 )
      goto LABEL_29;
    goto LABEL_17;
  }
LABEL_19:
  if ( v23 != v21 )
    goto LABEL_32;
  v26 = mFirstFreeBlock - v23;
  if ( v26 < 0 )
    goto LABEL_32;
  FMOD::MemPool::set(this, v26, 1, v23);
  v27 = FMOD::MemPool::alloc(off_286F358->gSystemMemPool, 8, "../../../core_api/src/fmod_memory.cpp", 682, 0, 0);
  v15 = v27;
  if ( !v27 )
    goto LABEL_32;
  v27[1] = v26;
  *v27 = len_original;
  v12 = len_original;
LABEL_5:
  v16 = v12 + this->mCurrentAllocated;
  v17 = v16 <= this->mMaxAllocated;
  this->mCurrentAllocated = v16;
  if ( !v17 )
    this->mMaxAllocated = v16;
  if ( !this->mCustomPool && clear )
    memset(v15, 0, len_original);
  FMOD_OS_CriticalSection_Leave(this->mCrit);
  return v15;
}


// Address: 0x2212d70 | Name: FMOD_Memory_allocC
void *__fastcall FMOD_Memory_allocC(int len, const char *file, const int line)
{
  return FMOD::MemPool::alloc(off_286F358->gSystemMemPool, len, file, line, 0, 0);
}


// Address: 0x2212da0 | Name: _ZN4FMOD7MemPool8morecoreEiPv
void *__fastcall FMOD::MemPool::morecore(const int size, void *userdata)
{
  void *result; // rax
  __int64 v3; // rax
  __int64 v4; // rbp
  void *v5; // rax

  if ( !size )
    return (void *)*((_QWORD *)userdata + 106);
  v3 = 0;
  if ( size < 0 )
    return (void *)-1LL;
  while ( 1 )
  {
    v4 = (int)v3;
    if ( !*((_QWORD *)userdata + v3 + 2) )
      break;
    if ( ++v3 == 100 )
      return (void *)-1LL;
  }
  v5 = FMOD::MemPool::alloc(
         off_286F358->gSystemMemPool,
         size + 16,
         "../../../core_api/src/fmod_memory.cpp",
         154,
         *((_DWORD *)userdata + 205),
         0);
  if ( !v5 )
    return (void *)-1LL;
  *((_QWORD *)userdata + v4 + 2) = v5;
  result = (void *)(((unsigned __int64)v5 + 15) & 0xFFFFFFFFFFFFFFF0LL);
  *((_QWORD *)userdata + 106) = (char *)result + size;
  return result;
}


// Address: 0x2212e40 | Name: _ZN4FMOD7MemPool4freeEPvPKci
void __fastcall FMOD::MemPool::free(FMOD::MemPool *const this, void *ptr, const char *file, const int line)
{
  char *v4; // r12
  FMOD_OS_CRITICALSECTION *mCrit; // rdi
  int v8; // esi
  int v9; // eax
  FMOD_MEMORY_FREE_CALLBACK mFree; // rax

  v4 = (char *)ptr - 8;
  while ( 1 )
  {
    mCrit = this->mCrit;
    if ( mCrit )
    {
      FMOD_OS_CriticalSection_Enter(mCrit);
      if ( this->mAlloc )
        goto LABEL_7;
    }
    else
    {
      if ( FMOD_OS_CriticalSection_Create(&this->mCrit, 1) )
        return;
      FMOD_OS_CriticalSection_Enter(this->mCrit);
      if ( this->mAlloc )
      {
LABEL_7:
        v8 = *((_DWORD *)ptr - 1);
        v9 = *((_DWORD *)ptr - 2);
        goto LABEL_8;
      }
    }
    v9 = this->mCustomPool ? *(_DWORD *)ptr : FMOD::mspace_chunksize(ptr);
    v8 = 0;
LABEL_8:
    this->mCurrentAllocated -= v9;
    mFree = this->mFree;
    if ( mFree )
    {
      mFree(v4, off_286F358->gMemoryTypeFlags & v8, 0);
    }
    else if ( this->mCustomPool )
    {
      FMOD::MemPool::set(this, *((_DWORD *)ptr + 1), 0, (this->mBlockSize + *(_DWORD *)ptr - 1) / this->mBlockSize);
    }
    else
    {
      FMOD::mspace_free(this->mDLMallocSpace, ptr);
    }
    FMOD_OS_CriticalSection_Leave(this->mCrit);
    if ( !this->mCustomPool )
      break;
    this = off_286F358->gSystemMemPool;
  }
}


// Address: 0x2212f70 | Name: FMOD_Memory_freeC
void __fastcall FMOD_Memory_freeC(void *ptr, const char *file, const int line)
{
  FMOD::MemPool::free(off_286F358->gSystemMemPool, ptr, file, line);
}


// Address: 0x2212fa0 | Name: _ZN4FMOD7MemPool5closeEv
FMOD_RESULT_0 __fastcall FMOD::MemPool::close(FMOD::MemPool *const this)
{
  __int64 i; // rbx
  void *v3; // rsi
  FMOD_OS_CRITICALSECTION *mCrit; // rdi

  if ( this->mCustomPool && this->mBitmap )
    FMOD::MemPool::free(off_286F358->gSystemMemPool, this->mBitmap, "../../../core_api/src/fmod_memory.cpp", 327);
  for ( i = 0; i != 100; ++i )
  {
    v3 = this->mDLMallocBlockMemory[i];
    if ( v3 )
    {
      FMOD::MemPool::free(off_286F358->gSystemMemPool, v3, "../../../core_api/src/fmod_memory.cpp", 334);
      this->mDLMallocBlockMemory[i] = 0;
    }
  }
  mCrit = this->mCrit;
  this->mBitmap = 0;
  this->mData = 0;
  this->mSizeBytes = 0;
  this->mSizeBlocks = 0;
  this->mAlloc = FMOD::Memory_DefaultMalloc;
  this->mCurrentAllocated = 0;
  this->mCustomPool = 0;
  this->mDLMallocSpace = 0;
  this->mRealloc = FMOD::Memory_DefaultRealloc;
  this->mFree = FMOD::Memory_DefaultFree;
  if ( mCrit )
  {
    FMOD_OS_CriticalSection_Free(mCrit, !this->mUserPool);
    this->mCrit = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x22130c0 | Name: j__ZN4FMOD7MemPool5closeEv
// attributes: thunk
void __fastcall FMOD::MemPool::close(FMOD::MemPool *const this)
{
  _ZN4FMOD7MemPool5closeEv(this);
}


// Address: 0x22130d0 | Name: _ZN4FMOD7MemPool4initEPvibj
FMOD_RESULT_0 __fastcall FMOD::MemPool::init(
        FMOD::MemPool *const this,
        void *poolmem,
        int poolsize,
        bool userpool,
        FMOD_MEMORY_TYPE memtype)
{
  char *v10; // rdi
  int v11; // r12d
  FMOD::mspace v12; // rax
  void *v13; // rax
  FMOD::mspace mspace_with_base; // rax

  FMOD::MemPool::close(this);
  this->mPoolMemoryType = memtype;
  if ( !poolmem )
  {
    v13 = FMOD::MemPool::morecore(poolsize, this);
    if ( v13 != (void *)-1LL )
    {
      mspace_with_base = FMOD::create_mspace_with_base(
                           v13,
                           poolsize,
                           0,
                           (void *(*)(int, void *))FMOD::MemPool::morecore,
                           this);
      this->mDLMallocSpace = mspace_with_base;
      if ( mspace_with_base )
        goto LABEL_5;
    }
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  }
  if ( !poolsize )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  v10 = (char *)poolmem + 255;
  LOBYTE(v10) = 0;
  v11 = poolsize - ((_DWORD)v10 - (_DWORD)poolmem);
  LOBYTE(v11) = 0;
  v12 = FMOD::create_mspace_with_base(v10, v11, 0, 0, 0);
  this->mDLMallocSpace = v12;
  if ( !v12 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
LABEL_5:
  this->mUserPool = userpool;
  this->mMaxAllocated = 0;
  this->mFirstFreeBlock = 0;
  this->mCurrentAllocated = 0;
  this->mAlloc = 0;
  this->mRealloc = 0;
  this->mFree = 0;
  return FMOD_OS_CriticalSection_Create(&this->mCrit, !userpool);
}


// Address: 0x22131f0 | Name: _ZN4FMOD7MemPool15initHardwareMemEPvii
FMOD_RESULT_0 __fastcall FMOD::MemPool::initHardwareMem(
        FMOD::MemPool *const this,
        void *poolmem,
        int poolsize,
        int blocksize)
{
  unsigned int v6; // eax
  int v7; // esi
  int v8; // ecx
  int v9; // eax
  unsigned __int8 *v10; // rax
  int mSizeBlocks; // ecx

  if ( !poolsize )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  FMOD::MemPool::close(this);
  this->mBlockSize = blocksize;
  v6 = ((poolsize + blocksize - 1) / blocksize) & 0xFFFFFFFC;
  v7 = v6 + 14;
  this->mSizeBlocks = v6;
  v8 = v6 * blocksize;
  v9 = v6 + 7;
  if ( v9 >= 0 )
    v7 = v9;
  this->mSizeBytes = v8;
  v10 = (unsigned __int8 *)FMOD::MemPool::alloc(
                             off_286F358->gSystemMemPool,
                             v7 >> 3,
                             "../../../core_api/src/fmod_memory.cpp",
                             284,
                             0,
                             0);
  this->mBitmap = v10;
  if ( !v10 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  mSizeBlocks = this->mSizeBlocks;
  this->mData = (unsigned __int8 *)poolmem;
  FMOD::MemPool::set(this, 0, 0, mSizeBlocks);
  this->mMaxAllocated = 0;
  this->mCustomPool = 1;
  this->mFirstFreeBlock = 0;
  this->mCurrentAllocated = 0;
  this->mAlloc = 0;
  this->mRealloc = 0;
  this->mFree = 0;
  return FMOD_OS_CriticalSection_Create(&this->mCrit, 0);
}


// Address: 0x2213300 | Name: _ZN4FMOD7MemPool6callocEiPKcij
void *__fastcall FMOD::MemPool::calloc(
        FMOD::MemPool *const this,
        int len,
        const char *file,
        const int line,
        FMOD_MEMORY_TYPE type)
{
  return FMOD::MemPool::alloc(this, len, file, line, type, 1);
}


// Address: 0x2213310 | Name: FMOD_Memory_callocC
void *__fastcall FMOD_Memory_callocC(int len, const char *file, const int line)
{
  return FMOD::MemPool::calloc(off_286F358->gSystemMemPool, len, file, line, 0);
}


// Address: 0x2213340 | Name: _ZN4FMOD7MemPool7reallocEPviPKcij
void *__fastcall FMOD::MemPool::realloc(
        FMOD::MemPool *const this,
        void *ptr,
        int len_original,
        const char *file,
        const int line,
        FMOD_MEMORY_TYPE type)
{
  signed int v7; // r12d
  _DWORD *v8; // rbp
  FMOD_OS_CRITICALSECTION *mCrit; // rdi
  int v11; // r15d
  int v12; // ecx
  FMOD_MEMORY_REALLOC_CALLBACK mRealloc; // r8
  FMOD_MEMORY_TYPE v14; // r15d
  signed int *v15; // rax
  unsigned int v16; // r12d
  bool v17; // cc
  int mBlockSize; // esi
  int v20; // r13d
  int v21; // r8d
  int v22; // esi
  int v23; // edx
  int v24; // r10d
  int v25; // edi
  unsigned __int8 *v26; // r9
  int v27; // r14d
  _DWORD *v28; // rax
  int mFirstFreeBlock; // esi
  int mSizeBlocks; // r9d
  int v31; // edx
  int v32; // r8d
  int v33; // edi
  unsigned __int8 *v34; // rax
  int v35; // esi
  unsigned __int8 *v36; // rax
  size_t v37; // rdx
  char fileLine[312]; // [rsp+10h] [rbp-138h] BYREF

  v7 = len_original;
  v8 = ptr;
  if ( !ptr )
    return FMOD::MemPool::alloc(this, len_original, file, line, 0, 0);
  mCrit = this->mCrit;
  if ( mCrit )
  {
    FMOD_OS_CriticalSection_Enter(mCrit);
    if ( this->mAlloc )
    {
LABEL_4:
      v11 = *((_DWORD *)ptr - 1);
      v12 = *((_DWORD *)ptr - 2);
      goto LABEL_5;
    }
  }
  else
  {
    if ( FMOD_OS_CriticalSection_Create(&this->mCrit, 1) )
      return 0;
    FMOD_OS_CriticalSection_Enter(this->mCrit);
    if ( this->mAlloc )
      goto LABEL_4;
  }
  if ( this->mCustomPool )
    goto LABEL_4;
  v11 = 0;
  v12 = FMOD::mspace_chunksize(ptr);
LABEL_5:
  mRealloc = this->mRealloc;
  this->mCurrentAllocated -= v12;
  if ( !mRealloc )
  {
    if ( !this->mCustomPool )
    {
      v28 = FMOD::mspace_realloc(this->mDLMallocSpace, ptr, v7);
      v8 = v28;
      if ( v28 )
      {
        v7 = FMOD::mspace_chunksize(v28);
        goto LABEL_8;
      }
      goto LABEL_35;
    }
    mBlockSize = this->mBlockSize;
    v20 = (v7 + mBlockSize - 1) / mBlockSize;
    FMOD::MemPool::set(this, *(v8 - 1), 0, (v12 + mBlockSize - 1) / mBlockSize);
    v21 = *(v8 - 1);
    v22 = 0;
    v23 = v21 + v20;
    v24 = v21 >> 3;
    v25 = 1 << (*(_BYTE *)(v8 - 1) & 7);
LABEL_13:
    if ( v23 > v21 )
    {
      while ( 1 )
      {
        if ( v20 <= v22 || v21 >= this->mSizeBlocks )
          goto LABEL_20;
        v26 = &this->mBitmap[v24];
        if ( ((unsigned __int8)v25 & *v26) != 0 )
          break;
        if ( (v21 & 0x1F) == 0 && *(_DWORD *)v26 == -1 )
        {
          v22 = 0;
LABEL_29:
          v24 += 4;
          v21 += 32;
          goto LABEL_13;
        }
        ++v22;
        if ( (v21 & 0x1F) == 0 )
          goto LABEL_28;
LABEL_18:
        ++v21;
        LOBYTE(v25) = 2 * v25;
        if ( (v21 & 7) != 0 )
          goto LABEL_13;
        ++v24;
        LOBYTE(v25) = 1;
        if ( v23 <= v21 )
          goto LABEL_20;
      }
      v22 = 0;
      if ( (v21 & 0x1F) != 0 )
        goto LABEL_18;
LABEL_28:
      if ( *(_DWORD *)v26 == -1 )
        goto LABEL_29;
      goto LABEL_18;
    }
LABEL_20:
    if ( v20 == v22 )
    {
      v27 = v21 - v20;
      if ( v21 - v20 >= 0 )
      {
        FMOD::MemPool::set(this, v27, 1, v20);
        *(_DWORD *)&this->mData[v27 * this->mBlockSize + 4] = v27;
        goto LABEL_8;
      }
    }
    mFirstFreeBlock = this->mFirstFreeBlock;
    mSizeBlocks = this->mSizeBlocks;
    v31 = 0;
    v32 = mFirstFreeBlock >> 3;
    v33 = 1 << (this->mFirstFreeBlock & 7);
LABEL_41:
    if ( mSizeBlocks <= mFirstFreeBlock )
    {
LABEL_47:
      if ( v20 == v31 )
      {
        v35 = mFirstFreeBlock - v20;
        if ( v35 >= 0 )
        {
          FMOD::MemPool::set(this, v35, 1, v20);
          if ( this->mCustomPool )
          {
            *(v8 - 1) = v35;
            *(v8 - 2) = v7;
          }
          else
          {
            v36 = &this->mData[v35 * this->mBlockSize];
            *(_DWORD *)v36 = v7;
            v37 = (int)*(v8 - 2);
            *((_DWORD *)v36 + 1) = v35;
            memmove(v36 + 8, v8, v37);
          }
        }
      }
      goto LABEL_8;
    }
    while ( 1 )
    {
      if ( v20 <= v31 )
        goto LABEL_47;
      v34 = &this->mBitmap[v32];
      if ( ((unsigned __int8)v33 & *v34) != 0 )
        break;
      if ( (mFirstFreeBlock & 0x1F) == 0 && *(_DWORD *)v34 == -1 )
      {
        v31 = 0;
LABEL_55:
        v32 += 4;
        mFirstFreeBlock += 32;
        goto LABEL_41;
      }
      ++v31;
      if ( (mFirstFreeBlock & 0x1F) == 0 )
        goto LABEL_54;
LABEL_45:
      ++mFirstFreeBlock;
      LOBYTE(v33) = 2 * v33;
      if ( (mFirstFreeBlock & 7) != 0 )
        goto LABEL_41;
      ++v32;
      LOBYTE(v33) = 1;
      if ( mSizeBlocks <= mFirstFreeBlock )
        goto LABEL_47;
    }
    v31 = 0;
    if ( (mFirstFreeBlock & 0x1F) != 0 )
      goto LABEL_45;
LABEL_54:
    if ( *(_DWORD *)v34 == -1 )
      goto LABEL_55;
    goto LABEL_45;
  }
  v7 += 8;
  v14 = off_286F358->gMemoryTypeFlags & v11;
  v15 = (signed int *)mRealloc((char *)ptr - 8, v7, v14, 0);
  if ( !v15 || (*v15 = v7, v15[1] = v14, v8 = v15 + 2, v15 == (signed int *)-8LL) )
  {
LABEL_35:
    FMOD_OS_CriticalSection_Leave(this->mCrit);
    if ( off_286F358->gSystemCallback && (off_286F358->gSystemCallbackMask & 4) != 0 )
    {
      sprintf(fileLine, "%s (%d)", file, line);
      off_286F358->gSystemCallback(0, 4, fileLine, (void *)v7, off_286F358->gSystemUserData);
    }
    return 0;
  }
LABEL_8:
  v16 = this->mCurrentAllocated + v7;
  v17 = v16 <= this->mMaxAllocated;
  this->mCurrentAllocated = v16;
  if ( !v17 )
    this->mMaxAllocated = v16;
  FMOD_OS_CriticalSection_Leave(this->mCrit);
  return v8;
}


// Address: 0x2213790 | Name: FMOD_Memory_reallocC
void *__fastcall FMOD_Memory_reallocC(void *ptr, int len, const char *file, const int line)
{
  return FMOD::MemPool::realloc(off_286F358->gSystemMemPool, ptr, len, file, line, 0);
}


// Address: 0x22137c0 | Name: _ZN4FMOD7MemPool12alignedAllocEiiPKcijb
void *__fastcall FMOD::MemPool::alignedAlloc(
        FMOD::MemPool *const this,
        int size,
        int align,
        const char *file,
        const int line,
        FMOD_MEMORY_TYPE type,
        bool clear)
{
  int v7; // ebx
  void *v8; // rax

  v7 = align;
  if ( align <= 0 )
    v7 = 8;
  v8 = FMOD::MemPool::alloc(this, size + v7 + 8, file, line, type, clear);
  if ( !v8 )
    return 0;
  *(_QWORD *)((((unsigned __int64)v8 + v7 + 7) & ~(__int64)(v7 - 1)) - 8) = v8;
  return (void *)(((unsigned __int64)v8 + v7 + 7) & ~(__int64)(v7 - 1));
}


// Address: 0x2213820 | Name: _ZN4FMOD7MemPool13alignedCallocEiiPKcij
void *__fastcall FMOD::MemPool::alignedCalloc(
        FMOD::MemPool *const this,
        int size,
        int align,
        const char *file,
        const int line,
        FMOD_MEMORY_TYPE type)
{
  return FMOD::MemPool::alignedAlloc(this, size, align, file, line, type, 1);
}


// Address: 0x2213840 | Name: _ZN4FMOD7MemPool11alignedFreeEPvPKci
void __fastcall FMOD::MemPool::alignedFree(FMOD::MemPool *const this, void *ptr, const char *file, const int line)
{
  FMOD::MemPool::free(this, *((void **)ptr - 1), file, line);
}


