// Address: 0x2201690 | Name: _ZN4FMOD13ExpandingPoolINS_14DSPConnectionIEE8addBlockEv
FMOD_RESULT_0 __fastcall FMOD::ExpandingPool<FMOD::DSPConnectionI>::addBlock(
        FMOD::ExpandingPool<FMOD::DSPConnectionI> *const this)
{
  float v1; // xmm1_4
  unsigned int mSecondaryBlockSize; // ebp
  unsigned int mMemoryAlignment; // eax
  __int64 v5; // r12
  int v6; // r15d
  unsigned int v7; // r13d
  __int64 v8; // r15
  unsigned int v9; // r13d
  void *v10; // rdx
  FMOD_RESULT_0 result; // eax
  FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *v12; // rbx
  FMOD::LinkedListNode *v13; // rax
  __int64 v14; // r12
  FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *mFirstBlock; // rax
  FMOD::LinkedListNode *mNodePrev; // rdx
  __int64 v17; // rax
  FMOD::LinkedListNode *p_mFreeListHead; // r13
  unsigned __int64 v19; // r15
  __int64 v20; // rax
  unsigned int v21; // r12d
  __int64 v22; // rax
  FMOD::DSPConnectionI *v23; // rdi
  FMOD::LinkedListNode *v24; // rdx
  unsigned int itemsize; // [rsp+Ch] [rbp-4Ch]
  __int64 v26; // [rsp+18h] [rbp-40h]

  mSecondaryBlockSize = this->mSecondaryBlockSize;
  if ( !this->mFirstBlock )
    mSecondaryBlockSize = this->mPrimaryBlockSize;
  mMemoryAlignment = this->mMemoryAlignment;
  v5 = -mMemoryAlignment & (mMemoryAlignment + 55);
  v6 = mMemoryAlignment + 24 * mSecondaryBlockSize - 1;
  v7 = v6 - 16 * mSecondaryBlockSize;
  v8 = -mMemoryAlignment & v6;
  v9 = -mMemoryAlignment & v7;
  itemsize = -mMemoryAlignment & (mMemoryAlignment + 167);
  v10 = FMOD::MemPool::calloc(
          off_286F358->gSystemMemPool,
          v9 + v8 + mSecondaryBlockSize * itemsize + v5 + mMemoryAlignment,
          "../../../core_api/src/fmod_expandingpool.cpp",
          36,
          0x200000u);
  result = FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( v10 )
  {
    v12 = (FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *)(~(unsigned __int64)(this->mMemoryAlignment - 1)
                                                           & ((unsigned __int64)v10 + this->mMemoryAlignment - 1));
    v13 = (FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *)((char *)v12 + v5);
    v14 = v8 + v5;
    v12->mBaseMemory = v10;
    v12->mNumItems = mSecondaryBlockSize;
    v12->mNodePrev = v12;
    v12->mListNode = v13;
    v12->mNodeNext = v12;
    v12->mNodeData = 0;
    v12->mItem = (FMOD::DSPConnectionI **)((char *)v12 + v14);
    mFirstBlock = this->mFirstBlock;
    if ( mFirstBlock )
    {
      mNodePrev = mFirstBlock->mNodePrev;
      v12->mNodeNext = mFirstBlock;
      v12->mNodePrev = mNodePrev;
      mFirstBlock->mNodePrev = v12;
      v12->mNodePrev->FMOD::LinkedListNode::mNodeNext = v12;
    }
    else
    {
      this->mFirstBlock = v12;
    }
    if ( mSecondaryBlockSize )
    {
      v17 = v9;
      p_mFreeListHead = &this->mFreeListHead;
      v19 = 0;
      v20 = v14 + v17;
      v21 = 0;
      v26 = v20;
      do
      {
        v22 = v26 + v21;
        v23 = (FMOD::DSPConnectionI *)((char *)v12 + v22);
        v12->mItem[v19 / 8] = (FMOD::DSPConnectionI *)((char *)v12 + v22);
        v24 = &v12->mListNode[v19 / 8];
        v24->mNodePrev = this->mFreeListHead.mNodePrev;
        v24->mNodeNext = p_mFreeListHead;
        this->mFreeListHead.mNodePrev = v24;
        v24->mNodePrev->mNodeNext = v24;
        v24->mNodeData = (char *)v12 + v22;
        if ( (FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *)((char *)v12 + v22) )
        {
          v23->mInputNode.mNodePrev = &v23->mInputNode;
          v23->mInputNode.mNodeNext = &v23->mInputNode;
          v23->mInputNode.mNodeData = 0;
          v23->mOutputNode.mNodeData = 0;
          v23->mOutputNode.mNodePrev = &v23->mOutputNode;
          v23->mOutputNode.mNodeNext = &v23->mOutputNode;
          v23->mMixMatrix.mData = 0;
          v23->mMixMatrix.mInChannels = 0;
          v23->mMixMatrix.mOutChannels = 0;
          v23->mMixMatrixCurrent.mData = 0;
          v23->mMixMatrixCurrent.mInChannels = 0;
          v23->mMixMatrixCurrent.mOutChannels = 0;
          v23->mUserData.mMixMatrixUser.mData = 0;
          v23->mUserData.mMixMatrixUser.mInChannels = 0;
          v23->mUserData.mMixMatrixUser.mOutChannels = 0;
          v23->mSystem = 0;
          v23->mInputUnit = 0;
          v23->mOutputUnit = 0;
        }
        v19 += 8LL;
        FMOD::DSPConnectionI::init(v23, this->mSystem, 1.0, v1);
        v21 += itemsize;
      }
      while ( v19 != 8LL * (mSecondaryBlockSize - 1) + 8 );
    }
    this->mNumItems += mSecondaryBlockSize;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x22018d0 | Name: _ZN4FMOD13ExpandingPoolINS_14DSPConnectionIEE11removeBlockEPNS_18ExpandingPoolBlockIS1_EE
FMOD_RESULT_0 __fastcall FMOD::ExpandingPool<FMOD::DSPConnectionI>::removeBlock(
        FMOD::ExpandingPool<FMOD::DSPConnectionI> *const this,
        FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *block)
{
  int mNumItems; // r10d
  FMOD::LinkedListNode *mListNode; // rax
  FMOD::LinkedListNode *v4; // rdx
  __int64 v5; // r9
  FMOD::LinkedListNode *mNodePrev; // rcx
  FMOD::LinkedListNode *v7; // rax
  FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *mNodeNext; // rax

  mNumItems = block->mNumItems;
  if ( mNumItems > 0 )
  {
    mListNode = block->mListNode;
    v4 = mListNode + 1;
    v5 = (__int64)&mListNode[(unsigned int)(mNumItems - 1) + 1];
    while ( 1 )
    {
      mNodePrev = mListNode->mNodePrev;
      mNodePrev->mNodeNext = mListNode->mNodeNext;
      mListNode->mNodeNext->mNodePrev = mNodePrev;
      mListNode->mNodePrev = mListNode;
      mListNode->mNodeNext = mListNode;
      mListNode = v4;
      if ( v4 == (FMOD::LinkedListNode *)v5 )
        break;
      ++v4;
    }
  }
  if ( this->mFirstBlock == block )
  {
    mNodeNext = 0;
    if ( block != block->mNodeNext )
      mNodeNext = (FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *)block->mNodeNext;
    this->mFirstBlock = mNodeNext;
  }
  v7 = block->mNodePrev;
  v7->mNodeNext = block->mNodeNext;
  block->mNodeNext->mNodePrev = v7;
  block->mNodePrev = block;
  block->mNodeNext = block;
  this->mNumItems -= mNumItems;
  FMOD::MemPool::free(
    off_286F358->gSystemMemPool,
    block->mBaseMemory,
    "../../../core_api/src/fmod_expandingpool.cpp",
    112);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2201990 | Name: _ZN4FMOD13ExpandingPoolINS_14DSPConnectionIEE4initEPNS_7SystemIEiiiib
FMOD_RESULT_0 __fastcall FMOD::ExpandingPool<FMOD::DSPConnectionI>::init(
        FMOD::ExpandingPool<FMOD::DSPConnectionI> *const this,
        FMOD::SystemI *system,
        int primaryblocksize,
        int secondaryblocksize,
        int crit_id,
        int memoryalignment,
        bool allowshrinkage)
{
  FMOD_RESULT_0 result; // eax

  if ( primaryblocksize < 0 || secondaryblocksize < 0 )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( memoryalignment > 0 )
  {
    this->mSystem = system;
    this->mMemoryAlignment = memoryalignment;
    this->mPrimaryBlockSize = primaryblocksize;
    this->mSecondaryBlockSize = secondaryblocksize;
    this->mUsedListHead.mNodePrev = &this->mUsedListHead;
    this->mUsedListHead.mNodeNext = &this->mUsedListHead;
    this->mCritId = crit_id;
    this->mAllowShrinkage = allowshrinkage;
    this->mFreeListHead.mNodePrev = &this->mFreeListHead;
    this->mFreeListHead.mNodeNext = &this->mFreeListHead;
    this->mNumItems = 0;
    this->mNumAlloced = 0;
    this->mUsedListHead.mNodeData = 0;
    this->mFreeListHead.mNodeData = 0;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2201a10 | Name: _ZN4FMOD13ExpandingPoolINS_14DSPConnectionIEE5closeEv
FMOD_RESULT_0 __fastcall FMOD::ExpandingPool<FMOD::DSPConnectionI>::close(
        FMOD::ExpandingPool<FMOD::DSPConnectionI> *const this)
{
  FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *i; // rsi

  for ( i = this->mFirstBlock; i; i = this->mFirstBlock )
    FMOD::ExpandingPool<FMOD::DSPConnectionI>::removeBlock(this, i);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2201a40 | Name: _ZN4FMOD13ExpandingPoolINS_14DSPConnectionIEE11getNumItemsEPi
FMOD_RESULT_0 __fastcall FMOD::ExpandingPool<FMOD::DSPConnectionI>::getNumItems(
        FMOD::ExpandingPool<FMOD::DSPConnectionI> *const this,
        int *numitems)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numitems )
  {
    *numitems = this->mNumItems;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2201a60 | Name: _ZN4FMOD13ExpandingPoolINS_14DSPConnectionIEE13getNumAllocedEPi
FMOD_RESULT_0 __fastcall FMOD::ExpandingPool<FMOD::DSPConnectionI>::getNumAlloced(
        FMOD::ExpandingPool<FMOD::DSPConnectionI> *const this,
        int *numalloced)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numalloced )
  {
    *numalloced = this->mNumAlloced;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2201a80 | Name: _ZN4FMOD13ExpandingPoolINS_14DSPConnectionIEE16getBlockAndIndexEPS1_PNS_14LinkedListNodeEPPNS_18ExpandingPoolBlockIS1_EEPi
FMOD_RESULT_0 __fastcall FMOD::ExpandingPool<FMOD::DSPConnectionI>::getBlockAndIndex(
        FMOD::ExpandingPool<FMOD::DSPConnectionI> *const this,
        FMOD::DSPConnectionI *item,
        FMOD::LinkedListNode *node,
        FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> **block_out,
        int *index_out)
{
  FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *mFirstBlock; // r10
  unsigned int mMemoryAlignment; // r11d
  FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *mNodeNext; // rdi
  unsigned int v8; // r11d
  unsigned __int64 v9; // rax
  unsigned __int64 mListNode; // rax

  mFirstBlock = this->mFirstBlock;
  mMemoryAlignment = this->mMemoryAlignment;
  mNodeNext = mFirstBlock;
  v8 = (mMemoryAlignment + 167) & -mMemoryAlignment;
  while ( 1 )
  {
    if ( item )
    {
      v9 = (unsigned __int64)*mNodeNext->mItem;
      if ( (unsigned __int64)item >= v9 && (unsigned __int64)item < v9 + mNodeNext->mNumItems * v8 )
      {
        mListNode = ((unsigned __int64)item - v9) / v8;
        goto LABEL_11;
      }
    }
    if ( node )
    {
      mListNode = (unsigned __int64)mNodeNext->mListNode;
      if ( (unsigned __int64)node >= mListNode && (unsigned __int64)node < mListNode + 24LL * mNodeNext->mNumItems )
        break;
    }
    mNodeNext = (FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *)mNodeNext->mNodeNext;
    if ( mFirstBlock == mNodeNext )
      return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  }
  LODWORD(mListNode) = -1431655765 * ((__int64)((__int64)node - mListNode) >> 3);
LABEL_11:
  if ( (_DWORD)mListNode == -1 )
    return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( block_out )
    *block_out = mNodeNext;
  if ( index_out )
    *index_out = mListNode;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x2201b30 | Name: _ZN4FMOD13ExpandingPoolINS_14DSPConnectionIEE5allocEPPS1_b
FMOD_RESULT_0 __fastcall FMOD::ExpandingPool<FMOD::DSPConnectionI>::alloc(
        FMOD::ExpandingPool<FMOD::DSPConnectionI> *const this,
        FMOD::DSPConnectionI **item,
        bool protect)
{
  float v3; // xmm1_4
  FMOD::FMOD_SYSTEM_CRIT v4; // r13d
  FMOD_RESULT_0 BlockAndIndex; // r12d
  int mCritId; // eax
  FMOD::SystemI *mSystem; // r15
  FMOD::LinkedListNode *mNodeNext; // rbp
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::DSPConnectionI *v11; // rax
  char v12; // [rsp+Fh] [rbp-49h]
  int index; // [rsp+14h] [rbp-44h] BYREF
  FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *block; // [rsp+18h] [rbp-40h] BYREF

  v4 = FMOD_SYSTEM_CRIT_MAX;
  BlockAndIndex = FMOD_RESULT::FMOD_ERR_UNINITIALIZED_0;
  mCritId = this->mCritId;
  mSystem = this->mSystem;
  if ( mCritId >= 0 )
    v4 = this->mCritId;
  if ( mSystem )
  {
    LOBYTE(BlockAndIndex) = 31;
    if ( item )
    {
      v12 = 0;
      if ( mCritId >= 0 && protect )
      {
        FMOD::SystemI::enterCrit(mSystem, v4);
        mNodeNext = this->mFreeListHead.mNodeNext;
        v12 = 1;
        if ( &this->mFreeListHead != mNodeNext )
          goto LABEL_8;
      }
      else
      {
        mNodeNext = this->mFreeListHead.mNodeNext;
        if ( &this->mFreeListHead != mNodeNext )
          goto LABEL_8;
      }
      if ( mNodeNext == this->mFreeListHead.mNodePrev )
      {
        BlockAndIndex = FMOD::ExpandingPool<FMOD::DSPConnectionI>::addBlock(this);
        if ( BlockAndIndex )
        {
LABEL_9:
          if ( v12 )
            FMOD::SystemI::leaveCrit(mSystem, v4);
          return BlockAndIndex;
        }
        mNodeNext = this->mFreeListHead.mNodeNext;
      }
LABEL_8:
      mNodePrev = mNodeNext->mNodePrev;
      mNodePrev->mNodeNext = mNodeNext->mNodeNext;
      mNodeNext->mNodeNext->mNodePrev = mNodePrev;
      mNodeNext->mNodePrev = mNodeNext;
      mNodeNext->mNodePrev = this->mUsedListHead.mNodePrev;
      mNodeNext->mNodeNext = &this->mUsedListHead;
      this->mUsedListHead.mNodePrev = mNodeNext;
      mNodeNext->mNodePrev->mNodeNext = mNodeNext;
      BlockAndIndex = FMOD::ExpandingPool<FMOD::DSPConnectionI>::getBlockAndIndex(this, 0, mNodeNext, &block, &index);
      if ( BlockAndIndex == FMOD_RESULT::FMOD_OK_0 )
      {
        BlockAndIndex = FMOD_RESULT::FMOD_ERR_MEMORY_0;
        v11 = block->mItem[index];
        *item = v11;
        if ( v11 )
        {
          mNodeNext->mNodeData = v11;
          LOBYTE(BlockAndIndex) = 0;
          FMOD::DSPConnectionI::init(*item, this->mSystem, 1.0, v3);
          ++block->mNumAlloced;
          ++this->mNumAlloced;
        }
      }
      goto LABEL_9;
    }
  }
  return BlockAndIndex;
}


// Address: 0x2201cb0 | Name: _ZN4FMOD13ExpandingPoolINS_14DSPConnectionIEE4freeEPS1_b
FMOD_RESULT_0 __fastcall FMOD::ExpandingPool<FMOD::DSPConnectionI>::free(
        FMOD::ExpandingPool<FMOD::DSPConnectionI> *const this,
        FMOD::DSPConnectionI *item,
        bool protect)
{
  FMOD::FMOD_SYSTEM_CRIT mCritId; // eax
  FMOD::FMOD_SYSTEM_CRIT v5; // r15d
  FMOD::SystemI *mSystem; // r13
  char v7; // r14
  FMOD_RESULT_0 BlockAndIndex; // ebx
  FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *v10; // rsi
  FMOD::LinkedListNode *mNodePrev; // rcx
  FMOD::LinkedListNode *mNodeNext; // rdi
  int v13; // eax
  FMOD::LinkedListNode *node; // [rsp+8h] [rbp-50h]
  int index; // [rsp+14h] [rbp-44h] BYREF
  FMOD::ExpandingPoolBlock<FMOD::DSPConnectionI> *block; // [rsp+18h] [rbp-40h] BYREF

  mCritId = this->mCritId;
  if ( mCritId >= FMOD_SYSTEM_CRIT_DSPFULL )
  {
    v5 = this->mCritId;
    mSystem = this->mSystem;
    block = 0;
    if ( item )
    {
      v7 = 0;
      if ( protect && mSystem )
      {
        v7 = 1;
        FMOD::SystemI::enterCrit(mSystem, mCritId);
      }
      goto LABEL_4;
    }
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  }
  mSystem = this->mSystem;
  block = 0;
  if ( !item )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v7 = 0;
  v5 = FMOD_SYSTEM_CRIT_MAX;
LABEL_4:
  BlockAndIndex = FMOD::ExpandingPool<FMOD::DSPConnectionI>::getBlockAndIndex(this, item, 0, &block, &index);
  if ( BlockAndIndex == FMOD_RESULT::FMOD_OK_0 )
  {
    BlockAndIndex = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
    node = &block->mListNode[index];
    if ( node->mNodeData )
    {
      BlockAndIndex = FMOD::DSPConnectionI::freeFromPool(item);
      if ( BlockAndIndex == FMOD_RESULT::FMOD_OK_0 )
      {
        v10 = block;
        mNodePrev = node->mNodePrev;
        mNodeNext = node->mNodeNext;
        --this->mNumAlloced;
        v13 = v10->mNumAlloced - 1;
        v10->mNumAlloced = v13;
        mNodePrev->mNodeNext = mNodeNext;
        node->mNodeNext->mNodePrev = mNodePrev;
        node->mNodePrev = node;
        node->mNodeData = 0;
        node->mNodePrev = this->mFreeListHead.mNodePrev;
        node->mNodeNext = &this->mFreeListHead;
        this->mFreeListHead.mNodePrev = node;
        node->mNodePrev->mNodeNext = node;
        if ( !v13 && this->mAllowShrinkage )
          FMOD::ExpandingPool<FMOD::DSPConnectionI>::removeBlock(this, v10);
      }
    }
  }
  if ( v7 && mSystem )
    FMOD::SystemI::leaveCrit(mSystem, v5);
  return BlockAndIndex;
}


