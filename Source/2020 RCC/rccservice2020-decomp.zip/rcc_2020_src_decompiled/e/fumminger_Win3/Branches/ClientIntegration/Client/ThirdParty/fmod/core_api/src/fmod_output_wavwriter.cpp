// Address: 0x21f9ea0 | Name: _ZN4FMOD15OutputWavWriter16getDescriptionExEv
FMOD::FMOD_OUTPUT_DESCRIPTION_EX *__cdecl FMOD::OutputWavWriter::getDescriptionEx()
{
  stru_2ADC300.mType = FMOD_OUTPUTTYPE::FMOD_OUTPUTTYPE_WAVWRITER_0;
  stru_2ADC300.mSize = 1432;
  memset(&stru_2ADC300, 0, 0xB0u);
  stru_2ADC300.apiversion = 4;
  stru_2ADC300.version = 65792;
  stru_2ADC300.polling = 1;
  stru_2ADC300.name = "FMOD WavWriter Output";
  stru_2ADC300.getnumdrivers = FMOD::OutputWavWriter::getNumDriversCallback;
  stru_2ADC300.getdriverinfo = FMOD::OutputWavWriter::getDriverInfoCallback;
  stru_2ADC300.init = FMOD::OutputWavWriter::initCallback;
  stru_2ADC300.close = FMOD::OutputWavWriter::closeCallback;
  stru_2ADC300.getposition = FMOD::OutputWavWriter::getPositionCallback;
  stru_2ADC300.lock = FMOD::OutputWavWriter::lockCallback;
  stru_2ADC300.unlock = FMOD::OutputWavWriter::unlockCallback;
  stru_2ADC300.gethandle = FMOD::OutputWavWriter::getHandleCallback;
  return &stru_2ADC300;
}


// Address: 0x21f9f50 | Name: _ZN4FMOD15OutputWavWriter13getNumDriversEPi
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::getNumDrivers(FMOD::OutputWavWriter *const this, int *numdrivers)
{
  *numdrivers = 5;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21f9f60 | Name: _ZN4FMOD15OutputWavWriter21getNumDriversCallbackEP17FMOD_OUTPUT_STATEPi
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::getNumDriversCallback(FMOD_OUTPUT_STATE *output, int *numdrivers)
{
  FMOD::OutputWavWriter *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter *)&output[-1].requestreset;
  return FMOD::OutputWavWriter::getNumDrivers(p_requestreset, numdrivers);
}


// Address: 0x21f9f80 | Name: _ZN4FMOD15OutputWavWriter13getDriverInfoEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES4_
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::getDriverInfo(
        FMOD::OutputWavWriter *const this,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels)
{
  if ( name )
  {
    switch ( id )
    {
      case 0:
        FMOD_strcpy_safe(name, "16 bit Integer PCM wave writer (default filename = fmodoutput.wav)", namelen);
        break;
      case 1:
        FMOD_strcpy_safe(name, "8  bit Integer PCM wave writer (default filename = fmodoutput.wav)", namelen);
        break;
      case 2:
        FMOD_strcpy_safe(name, "24 bit Integer PCM wave writer (default filename = fmodoutput.wav)", namelen);
        break;
      case 3:
        FMOD_strcpy_safe(name, "32 bit Integer PCM wave writer (default filename = fmodoutput.wav)", namelen);
        break;
      case 4:
        FMOD_strcpy_safe(name, "32 bit float   PCM wave writer (default filename = fmodoutput.wav)", namelen);
        break;
      default:
        break;
    }
  }
  if ( guid )
    guid->Data1 = id;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21fa020 | Name: _ZN4FMOD15OutputWavWriter21getDriverInfoCallbackEP17FMOD_OUTPUT_STATEiPciP9FMOD_GUIDPiP16FMOD_SPEAKERMODES6_
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::getDriverInfoCallback(
        FMOD_OUTPUT_STATE *output,
        int id,
        char *name,
        int namelen,
        FMOD_GUID *guid,
        int *systemrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels)
{
  FMOD::OutputWavWriter *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter *)&output[-1].requestreset;
  return FMOD::OutputWavWriter::getDriverInfo(
           p_requestreset,
           id,
           name,
           namelen,
           guid,
           systemrate,
           speakermode,
           speakermodechannels);
}


// Address: 0x21fa040 | Name: _ZN4FMOD15OutputWavWriter11getPositionEPj
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::getPosition(FMOD::OutputWavWriter *const this, unsigned int *pcm)
{
  __int64 v2; // rax
  int v3; // ebp
  unsigned int ms[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  v2 = *((_QWORD *)this + 9);
  ms[0] = 0;
  v3 = *(_DWORD *)(v2 + 1696);
  FMOD_OS_Time_GetMs(ms);
  *pcm = v3 * ms[0] / 0x3E8;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21fa090 | Name: _ZN4FMOD15OutputWavWriter19getPositionCallbackEP17FMOD_OUTPUT_STATEPj
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::getPositionCallback(FMOD_OUTPUT_STATE *output, unsigned int *pcm)
{
  FMOD::OutputWavWriter *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter *)&output[-1].requestreset;
  return FMOD::OutputWavWriter::getPosition(p_requestreset, pcm);
}


// Address: 0x21fa0b0 | Name: _ZN4FMOD15OutputWavWriter4lockEjjPPvS2_PjS3_
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::lock(
        FMOD::OutputWavWriter *const this,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  unsigned int v7; // r10d
  unsigned int v9; // edx

  v7 = *((_DWORD *)this + 352);
  v9 = offset % v7;
  *ptr1 = (void *)(*((_QWORD *)this + 175) + offset % v7);
  if ( v7 < offset % v7 + length )
  {
    *ptr2 = (void *)*((_QWORD *)this + 175);
    *len1 = v7 - v9;
    *len2 = length - *((_DWORD *)this + 352) + v9;
  }
  else
  {
    *ptr2 = 0;
    *len1 = length;
    *len2 = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21fa130 | Name: _ZN4FMOD15OutputWavWriter12lockCallbackEP17FMOD_OUTPUT_STATEjjPPvS4_PjS5_
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::lockCallback(
        FMOD_OUTPUT_STATE *output,
        unsigned int offset,
        unsigned int length,
        void **ptr1,
        void **ptr2,
        unsigned int *len1,
        unsigned int *len2)
{
  FMOD::OutputWavWriter *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter *)&output[-1].requestreset;
  return FMOD::OutputWavWriter::lock(p_requestreset, offset, length, ptr1, ptr2, len1, len2);
}


// Address: 0x21fa150 | Name: _ZN4FMOD15OutputWavWriter6unlockEPvS1_jj
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::unlock(
        FMOD::OutputWavWriter *const this,
        void *ptr1,
        void *ptr2,
        unsigned int len1,
        unsigned int len2)
{
  int v7; // eax
  __int64 v8; // rax
  __int64 v9; // rax
  unsigned int len2a; // [rsp+Ch] [rbp-1Ch]

  if ( ptr1 && len1 )
  {
    if ( *((_DWORD *)this + 20) == 1 )
    {
      v9 = 0;
      do
        *((_BYTE *)ptr1 + v9++) += 0x80;
      while ( len1 > (unsigned int)v9 );
    }
    len2a = len2;
    v7 = fwrite(ptr1, 1u, len1, *((FILE **)this + 178));
    len2 = len2a;
    *((_DWORD *)this + 354) += v7;
  }
  if ( ptr2 && len2 )
  {
    if ( *((_DWORD *)this + 20) == 1 )
    {
      v8 = 0;
      do
        *((_BYTE *)ptr2 + v8++) += 0x80;
      while ( len2 > (unsigned int)v8 );
    }
    *((_DWORD *)this + 354) += fwrite(ptr2, 1u, len2, *((FILE **)this + 178));
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21fa210 | Name: _ZN4FMOD15OutputWavWriter14unlockCallbackEP17FMOD_OUTPUT_STATEPvS3_jj
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::unlockCallback(
        FMOD_OUTPUT_STATE *output,
        void *ptr1,
        void *ptr2,
        unsigned int len1,
        unsigned int len2)
{
  FMOD::OutputWavWriter *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter *)&output[-1].requestreset;
  return FMOD::OutputWavWriter::unlock(p_requestreset, ptr1, ptr2, len1, len2);
}


// Address: 0x21fa230 | Name: _ZN4FMOD15OutputWavWriter9getHandleEPPv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::getHandle(FMOD::OutputWavWriter *const this, void **handle)
{
  *handle = (void *)*((_QWORD *)this + 178);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21fa240 | Name: _ZN4FMOD15OutputWavWriter17getHandleCallbackEP17FMOD_OUTPUT_STATEPPv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::getHandleCallback(FMOD_OUTPUT_STATE *output, void **handle)
{
  FMOD::OutputWavWriter *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter *)&output[-1].requestreset;
  return FMOD::OutputWavWriter::getHandle(p_requestreset, handle);
}


// Address: 0x21fa260 | Name: _ZN4FMOD15OutputWavWriter14writeWavHeaderEv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::writeWavHeader(FMOD::OutputWavWriter *const this)
{
  return FMOD::FMOD_WriteWavHeader(
           *((FILE **)this + 178),
           *((FMOD_SOUND_FORMAT_0 *)this + 20),
           *((_DWORD *)this + 22),
           *(_DWORD *)(*((_QWORD *)this + 9) + 1696LL),
           *((_DWORD *)this + 354));
}


// Address: 0x21fa290 | Name: _ZN4FMOD15OutputWavWriter4initEijPiP16FMOD_SPEAKERMODES1_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::init(
        FMOD::OutputWavWriter *const this,
        int selecteddriver,
        FMOD_INITFLAGS flags,
        int *outputrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels,
        FMOD_SOUND_FORMAT_0 *outputformat,
        int dspbufferlength,
        int dspnumbuffers,
        void *extradriverdata)
{
  unsigned __int64 v10; // rax
  FMOD_SOUND_FORMAT_0 v11; // edx
  int v12; // ecx
  __int64 v13; // rdx
  FMOD::Global *v14; // rdx
  void *v15; // rax
  FILE *v16; // rax

  LODWORD(v10) = dspbufferlength;
  *((_DWORD *)this + 23) = 1;
  switch ( selecteddriver )
  {
    case 0:
      *outputformat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
      v11 = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0;
      break;
    case 1:
      *outputformat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0;
      v11 = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0;
      break;
    case 2:
      *outputformat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0;
      v11 = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0;
      break;
    case 3:
      *outputformat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0;
      v11 = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0;
      break;
    case 4:
      *outputformat = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
      v11 = FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0;
      break;
    default:
      v11 = *outputformat;
      break;
  }
  if ( *speakermode == FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_DEFAULT_0 )
  {
    *speakermode = FMOD_SPEAKERMODE::FMOD_SPEAKERMODE_STEREO_0;
    *speakermodechannels = 2;
  }
  *((_DWORD *)this + 353) = 0;
  switch ( v11 )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      *((_DWORD *)this + 353) = 8;
      v13 = 8;
      v12 = *speakermodechannels;
      goto LABEL_8;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      *((_DWORD *)this + 353) = 16;
      v12 = *speakermodechannels;
LABEL_17:
      v13 = 16;
      goto LABEL_8;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      *((_DWORD *)this + 353) = 24;
      v12 = *speakermodechannels;
LABEL_15:
      v13 = 24;
      goto LABEL_8;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      *((_DWORD *)this + 353) = 32;
      v12 = *speakermodechannels;
LABEL_7:
      v13 = 32;
LABEL_8:
      v10 = (v13 * (unsigned __int64)(unsigned int)dspbufferlength) >> 3;
      break;
    default:
      v12 = *speakermodechannels;
      switch ( v11 )
      {
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
          v13 = 8;
          goto LABEL_8;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
          goto LABEL_17;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
          goto LABEL_15;
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
        case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
          goto LABEL_7;
        default:
          goto LABEL_9;
      }
  }
LABEL_9:
  v14 = off_286F358;
  *((_DWORD *)this + 352) = v10 * v12;
  v15 = FMOD::MemPool::calloc(
          v14->gSystemMemPool,
          (int)v10 * v12,
          "../../../core_api/src/fmod_output_wavwriter.cpp",
          147,
          0);
  *((_QWORD *)this + 175) = v15;
  if ( !v15 )
    return FMOD_RESULT::FMOD_ERR_MEMORY_0;
  if ( extradriverdata )
    FMOD_strcpy_safe((char *)this + 1144, (const char *)extradriverdata, 256);
  else
    FMOD_strcpy_safe((char *)this + 1144, "fmodoutput.wav", 256);
  v16 = fopen((const char *)this + 1144, "wb");
  *((_QWORD *)this + 178) = v16;
  if ( v16 )
    return FMOD::OutputWavWriter::writeWavHeader(this);
  else
    return FMOD_RESULT::FMOD_ERR_FILE_NOTFOUND_0;
}


// Address: 0x21fa4d0 | Name: _ZN4FMOD15OutputWavWriter12initCallbackEP17FMOD_OUTPUT_STATEijPiP16FMOD_SPEAKERMODES3_P17FMOD_SOUND_FORMATiiPv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::initCallback(
        FMOD_OUTPUT_STATE *output,
        int selecteddriver,
        FMOD_INITFLAGS flags,
        int *outputrate,
        FMOD_SPEAKERMODE_0 *speakermode,
        int *speakermodechannels,
        FMOD_SOUND_FORMAT_0 *outputformat,
        int dspbufferlength,
        int dspnumbuffers,
        void *extradriverdata)
{
  FMOD::OutputWavWriter *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter *)&output[-1].requestreset;
  return FMOD::OutputWavWriter::init(
           p_requestreset,
           selecteddriver,
           flags,
           outputrate,
           speakermode,
           speakermodechannels,
           outputformat,
           dspbufferlength,
           dspnumbuffers,
           extradriverdata);
}


// Address: 0x21fa4f0 | Name: _ZN4FMOD15OutputWavWriter5closeEv
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::close(FMOD::OutputWavWriter *const this)
{
  FILE *v2; // rdi
  void *v3; // rsi

  FMOD::OutputWavWriter::writeWavHeader(this);
  v2 = (FILE *)*((_QWORD *)this + 178);
  if ( v2 )
  {
    fclose(v2);
    *((_QWORD *)this + 178) = 0;
  }
  v3 = (void *)*((_QWORD *)this + 175);
  if ( v3 )
  {
    FMOD::MemPool::free(off_286F358->gSystemMemPool, v3, "../../../core_api/src/fmod_output_wavwriter.cpp", 198);
    *((_QWORD *)this + 175) = 0;
  }
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21fa560 | Name: _ZN4FMOD15OutputWavWriter13closeCallbackEP17FMOD_OUTPUT_STATE
FMOD_RESULT_0 __fastcall FMOD::OutputWavWriter::closeCallback(FMOD_OUTPUT_STATE *output)
{
  FMOD::OutputWavWriter *p_requestreset; // rax

  p_requestreset = 0;
  if ( output )
    p_requestreset = (FMOD::OutputWavWriter *)&output[-1].requestreset;
  return FMOD::OutputWavWriter::close(p_requestreset);
}


