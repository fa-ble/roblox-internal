// Address: 0x221d5f0 | Name: FMOD_DSP_Deinterleave71ToMono_Normalised_SSE
void __fastcall FMOD_DSP_Deinterleave71ToMono_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r8
  int v5; // eax
  int v6; // ecx
  __m128 v7; // xmm2
  __m128 v8; // xmm12
  __m128 v9; // xmm10
  __m128 v10; // xmm7
  __m128 v11; // xmm9
  __m128 v12; // xmm5
  __m128 v13; // xmm4
  __m128 v14; // xmm3
  __m128 v15; // xmm8
  __int64 v16; // rsi
  __m128 v17; // xmm0
  __int64 v18; // rsi
  __m128 v19; // xmm1
  __m128 v20; // xmm6
  __m128 v21; // xmm4

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = 4;
    v6 = 0;
    do
    {
      v7 = *(__m128 *)&inbuffer[32 * v6];
      v8 = *(__m128 *)&inbuffer[v5 + 4];
      v9 = *(__m128 *)&inbuffer[v5 + 8];
      v10 = _mm_unpacklo_ps(v7, v8);
      v11 = *(__m128 *)&inbuffer[v5 + 12];
      v12 = _mm_unpacklo_ps(*(__m128 *)&inbuffer[v5], v9);
      v13 = *(__m128 *)&inbuffer[v5 + 16];
      v14 = _mm_unpackhi_ps(*(__m128 *)&inbuffer[v5], v9);
      v15 = *(__m128 *)&inbuffer[v5 + 20];
      v16 = (unsigned int)(v5 + 24);
      v5 += 32;
      v17 = *(__m128 *)&inbuffer[v16];
      v18 = (unsigned int)(4 * v6);
      v19 = _mm_unpacklo_ps(v11, v15);
      ++v6;
      v20 = _mm_unpacklo_ps(v13, v17);
      v21 = _mm_unpackhi_ps(v13, v17);
      *(__m128 *)&v4[v18] = _mm_mul_ps(
                              _mm_add_ps(
                                _mm_add_ps(
                                  _mm_add_ps(_mm_movelh_ps(v10, v19), _mm_movelh_ps(v12, v20)),
                                  _mm_add_ps(
                                    _mm_movelh_ps(_mm_unpackhi_ps(v7, v8), _mm_unpackhi_ps(v11, v15)),
                                    _mm_movelh_ps(v14, v21))),
                                _mm_add_ps(
                                  _mm_add_ps(_mm_movehl_ps(v19, v10), _mm_movehl_ps(v20, v12)),
                                  _mm_movehl_ps(v21, v14))),
                              (__m128)xmmword_3E70C0);
    }
    while ( v6 != v3 );
  }
}


// Address: 0x221d6d0 | Name: FMOD_DSP_Deinterleave71ToStereo_Normalised_SSE
void __fastcall FMOD_DSP_Deinterleave71ToStereo_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r9
  float *v5; // r8
  int v6; // eax
  int v7; // ecx
  __m128 v8; // xmm4
  __m128 v9; // xmm13
  __m128 v10; // xmm12
  __m128 v11; // xmm3
  __m128 v12; // xmm11
  __m128 v13; // xmm6
  __m128 v14; // xmm5
  __m128 v15; // xmm7
  __m128 v16; // xmm10
  __int64 v17; // rsi
  __m128 v18; // xmm1
  __int64 v19; // rsi
  __m128 v20; // xmm0
  __m128 v21; // xmm2
  __m128 v22; // xmm5
  __m128 v23; // xmm4

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = outbuffer[1];
    v6 = 4;
    v7 = 0;
    do
    {
      v8 = *(__m128 *)&inbuffer[32 * v7];
      v9 = *(__m128 *)&inbuffer[v6 + 4];
      v10 = *(__m128 *)&inbuffer[v6 + 8];
      v11 = _mm_unpacklo_ps(v8, v9);
      v12 = *(__m128 *)&inbuffer[v6 + 12];
      v13 = _mm_unpacklo_ps(*(__m128 *)&inbuffer[v6], v10);
      v14 = *(__m128 *)&inbuffer[v6 + 16];
      v15 = _mm_unpackhi_ps(*(__m128 *)&inbuffer[v6], v10);
      v16 = *(__m128 *)&inbuffer[v6 + 20];
      v17 = (unsigned int)(v6 + 24);
      v6 += 32;
      v18 = *(__m128 *)&inbuffer[v17];
      v19 = (unsigned int)(4 * v7);
      v20 = _mm_unpacklo_ps(v12, v16);
      ++v7;
      v21 = _mm_unpacklo_ps(v14, v18);
      v22 = _mm_unpackhi_ps(v14, v18);
      v23 = _mm_movelh_ps(_mm_unpackhi_ps(v8, v9), _mm_unpackhi_ps(v12, v16));
      *(__m128 *)&v4[v19] = _mm_add_ps(
                              _mm_add_ps(
                                _mm_movelh_ps(v11, v20),
                                _mm_mul_ps(_mm_movelh_ps(v15, v22), (__m128)xmmword_3E9190)),
                              _mm_mul_ps(_mm_add_ps(_mm_movelh_ps(v13, v21), v23), (__m128)xmmword_3E5A90));
      *(__m128 *)&v5[v19] = _mm_add_ps(
                              _mm_add_ps(
                                _mm_movehl_ps(v20, v11),
                                _mm_mul_ps(_mm_movehl_ps(v22, v15), (__m128)xmmword_3E9190)),
                              _mm_mul_ps(_mm_add_ps(_mm_movehl_ps(v21, v13), v23), (__m128)xmmword_3E5A90));
    }
    while ( v7 != v3 );
  }
}


// Address: 0x221d7d0 | Name: FMOD_DSP_Deinterleave71ToQuad_Normalised_SSE
void __fastcall FMOD_DSP_Deinterleave71ToQuad_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r11
  float *v5; // r10
  int v6; // eax
  float *v7; // r9
  float *v8; // r8
  int v9; // ecx
  __m128 v10; // xmm2
  __m128 v11; // xmm14
  __m128 v12; // xmm13
  __m128 v13; // xmm5
  __m128 v14; // xmm12
  __m128 v15; // xmm10
  __m128 v16; // xmm9
  __m128 v17; // xmm1
  __m128 v18; // xmm11
  __int64 v19; // rsi
  __m128 v20; // xmm3
  __int64 v21; // rsi
  __m128 v22; // xmm0
  __m128 v23; // xmm4
  __m128 v24; // xmm9
  __m128 v25; // xmm3
  __m128 v26; // xmm0
  __m128 v27; // xmm5
  __m128 v28; // xmm4
  __m128 v29; // xmm10
  __m128 v30; // xmm9
  __m128 v31; // xmm2
  __m128 v32; // xmm5
  __m128 v33; // xmm4

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = outbuffer[1];
    v6 = 4;
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = 0;
    do
    {
      v10 = *(__m128 *)&inbuffer[32 * v9];
      v11 = *(__m128 *)&inbuffer[v6 + 4];
      v12 = *(__m128 *)&inbuffer[v6 + 8];
      v13 = _mm_unpacklo_ps(v10, v11);
      v14 = *(__m128 *)&inbuffer[v6 + 12];
      v15 = _mm_unpacklo_ps(*(__m128 *)&inbuffer[v6], v12);
      v16 = *(__m128 *)&inbuffer[v6 + 16];
      v17 = _mm_unpackhi_ps(*(__m128 *)&inbuffer[v6], v12);
      v18 = *(__m128 *)&inbuffer[v6 + 20];
      v19 = (unsigned int)(v6 + 24);
      v6 += 32;
      v20 = *(__m128 *)&inbuffer[v19];
      v21 = (unsigned int)(4 * v9);
      v22 = _mm_unpacklo_ps(v14, v18);
      ++v9;
      v23 = _mm_unpacklo_ps(v16, v20);
      v24 = _mm_unpackhi_ps(v16, v20);
      v25 = _mm_movelh_ps(v13, v22);
      v26 = _mm_movehl_ps(v22, v13);
      v27 = _mm_movelh_ps(v15, v23);
      v28 = _mm_movehl_ps(v23, v15);
      v29 = _mm_movelh_ps(v17, v24);
      v30 = _mm_movehl_ps(v24, v17);
      v31 = _mm_mul_ps(_mm_movelh_ps(_mm_unpackhi_ps(v10, v11), _mm_unpackhi_ps(v14, v18)), (__m128)xmmword_3E5A90);
      v32 = _mm_mul_ps(v27, (__m128)xmmword_3E5A90);
      v33 = _mm_mul_ps(v28, (__m128)xmmword_3E5A90);
      *(__m128 *)&v4[v21] = _mm_add_ps(
                              _mm_add_ps(
                                _mm_add_ps(
                                  _mm_mul_ps((__m128)xmmword_3E70D0, v25),
                                  _mm_mul_ps((__m128)xmmword_3E74E0, v26)),
                                v31),
                              v32);
      *(__m128 *)&v5[v21] = _mm_add_ps(
                              _mm_add_ps(
                                _mm_add_ps(
                                  _mm_mul_ps(v26, (__m128)xmmword_3E70D0),
                                  _mm_mul_ps(v25, (__m128)xmmword_3E74E0)),
                                v31),
                              v33);
      *(__m128 *)&v7[v21] = _mm_add_ps(
                              _mm_add_ps(
                                _mm_mul_ps((__m128)xmmword_3E70D0, v29),
                                _mm_mul_ps((__m128)xmmword_3E74E0, v30)),
                              v32);
      *(__m128 *)&v8[v21] = _mm_add_ps(
                              _mm_add_ps(
                                _mm_mul_ps(v30, (__m128)xmmword_3E70D0),
                                _mm_mul_ps(v29, (__m128)xmmword_3E74E0)),
                              v33);
    }
    while ( v9 != v3 );
  }
}


// Address: 0x221d930 | Name: FMOD_DSP_Deinterleave71To51_Normalised_SSE
void __fastcall FMOD_DSP_Deinterleave71To51_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // eax
  float *v5; // rbp
  float *v6; // rbx
  float *v7; // r11
  float *v8; // r10
  float *v9; // r9
  float *v10; // r8
  int v11; // esi
  __m128 v12; // xmm6
  __m128 v13; // xmm15
  __m128 v14; // xmm14
  __m128 v15; // xmm1
  __m128 v16; // xmm7
  __m128 v17; // xmm4
  __m128 v18; // xmm8
  __m128 v19; // xmm5
  __m128 v20; // xmm13
  __int64 v21; // rcx
  __m128 v22; // xmm3
  __int64 v23; // rcx
  __m128 v24; // xmm2
  __m128 v25; // xmm0
  __m128 v26; // xmm8
  __m128 v27; // xmm6
  __m128 v28; // xmm3
  __m128 v29; // xmm2
  __m128 v30; // xmm7
  __m128 v31; // xmm1
  __m128 v32; // xmm0
  __m128 v33; // xmm4
  __m128 v34; // xmm8

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 4;
    v5 = *outbuffer;
    v6 = outbuffer[1];
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = outbuffer[4];
    v10 = outbuffer[5];
    v11 = 0;
    do
    {
      v12 = *(__m128 *)&inbuffer[32 * v11];
      v13 = *(__m128 *)&inbuffer[v4 + 4];
      v14 = *(__m128 *)&inbuffer[v4 + 8];
      v15 = _mm_unpacklo_ps(v12, v13);
      v16 = *(__m128 *)&inbuffer[v4 + 12];
      v17 = _mm_unpacklo_ps(*(__m128 *)&inbuffer[v4], v14);
      v18 = *(__m128 *)&inbuffer[v4 + 16];
      v19 = _mm_unpackhi_ps(*(__m128 *)&inbuffer[v4], v14);
      v20 = *(__m128 *)&inbuffer[v4 + 20];
      v21 = (unsigned int)(v4 + 24);
      v4 += 32;
      v22 = *(__m128 *)&inbuffer[v21];
      v23 = (unsigned int)(4 * v11);
      v24 = _mm_unpacklo_ps(v16, v20);
      ++v11;
      v25 = _mm_unpacklo_ps(v18, v22);
      v26 = _mm_unpackhi_ps(v18, v22);
      v27 = _mm_unpackhi_ps(v12, v13);
      v28 = _mm_movelh_ps(v15, v24);
      v29 = _mm_movehl_ps(v24, v15);
      v30 = _mm_unpackhi_ps(v16, v20);
      v31 = _mm_movelh_ps(v17, v25);
      v32 = _mm_movehl_ps(v25, v17);
      v33 = _mm_movelh_ps(v19, v26);
      v34 = _mm_movehl_ps(v26, v19);
      *(__m128 *)&v5[v23] = _mm_add_ps(v28, _mm_mul_ps((__m128)xmmword_3E6960, v31));
      *(__m128 *)&v6[v23] = _mm_add_ps(v29, _mm_mul_ps((__m128)xmmword_3E6960, v32));
      *(__m128 *)&v7[v23] = _mm_movelh_ps(v27, v30);
      *(__m128 *)&v8[v23] = _mm_movehl_ps(v30, v27);
      *(__m128 *)&v9[v23] = _mm_add_ps(
                              _mm_mul_ps(v31, (__m128)xmmword_3E9860),
                              _mm_add_ps(
                                _mm_mul_ps((__m128)xmmword_3E9740, v33),
                                _mm_mul_ps((__m128)xmmword_3E7C10, v34)));
      *(__m128 *)&v10[v23] = _mm_add_ps(
                               _mm_mul_ps(v32, (__m128)xmmword_3E9860),
                               _mm_add_ps(
                                 _mm_mul_ps(v33, (__m128)xmmword_3E7C10),
                                 _mm_mul_ps(v34, (__m128)xmmword_3E9740)));
    }
    while ( v11 != v3 );
  }
}


// Address: 0x221da90 | Name: FMOD_DSP_Deinterleave71To71_Normalised_SSE
void __fastcall FMOD_DSP_Deinterleave71To71_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // eax
  float *v5; // r13
  float *v6; // r12
  float *v7; // rbp
  float *v8; // rbx
  float *v9; // r11
  float *v10; // r10
  float *v11; // r9
  float *v12; // r8
  int v13; // esi
  __m128 v14; // xmm6
  __m128 v15; // xmm11
  __m128 v16; // xmm10
  __m128 v17; // xmm4
  __m128 v18; // xmm5
  __m128 v19; // xmm2
  __m128 v20; // xmm1
  __m128 v21; // xmm0
  __m128 v22; // xmm9
  __int64 v23; // rcx
  __m128 v24; // xmm6
  __m128 v25; // xmm8
  __int64 v26; // rcx
  __m128 v27; // xmm7
  __m128 v28; // xmm3
  __m128 v29; // xmm5
  __m128 v30; // xmm1

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 4;
    v5 = *outbuffer;
    v6 = outbuffer[1];
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = outbuffer[4];
    v10 = outbuffer[5];
    v11 = outbuffer[6];
    v12 = outbuffer[7];
    v13 = 0;
    do
    {
      v14 = *(__m128 *)&inbuffer[32 * v13];
      v15 = *(__m128 *)&inbuffer[v4 + 4];
      v16 = *(__m128 *)&inbuffer[v4 + 8];
      v17 = _mm_unpackhi_ps(v14, v15);
      v18 = *(__m128 *)&inbuffer[v4 + 12];
      v19 = _mm_unpacklo_ps(*(__m128 *)&inbuffer[v4], v16);
      v20 = *(__m128 *)&inbuffer[v4 + 16];
      v21 = _mm_unpackhi_ps(*(__m128 *)&inbuffer[v4], v16);
      v22 = *(__m128 *)&inbuffer[v4 + 20];
      v23 = (unsigned int)(v4 + 24);
      v24 = _mm_unpacklo_ps(v14, v15);
      v4 += 32;
      v25 = *(__m128 *)&inbuffer[v23];
      v26 = (unsigned int)(4 * v13++);
      v27 = _mm_unpacklo_ps(v18, v22);
      v28 = _mm_unpacklo_ps(v20, v25);
      v29 = _mm_unpackhi_ps(v18, v22);
      v30 = _mm_unpackhi_ps(v20, v25);
      *(__m128 *)&v5[v26] = _mm_movelh_ps(v24, v27);
      *(__m128 *)&v6[v26] = _mm_movehl_ps(v27, v24);
      *(__m128 *)&v7[v26] = _mm_movelh_ps(v17, v29);
      *(__m128 *)&v8[v26] = _mm_movehl_ps(v29, v17);
      *(__m128 *)&v9[v26] = _mm_movelh_ps(v19, v28);
      *(__m128 *)&v10[v26] = _mm_movehl_ps(v28, v19);
      *(__m128 *)&v11[v26] = _mm_movelh_ps(v21, v30);
      *(__m128 *)&v12[v26] = _mm_movehl_ps(v30, v21);
    }
    while ( v13 != v3 );
  }
}


// Address: 0x221dbb0 | Name: FMOD_DSP_DeinterleaveMonoToStereo_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveMonoToStereo_Normalised_SSE(
        float *inbuffer,
        float **outbuffer,
        unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r8
  float *v5; // rsi
  int v6; // eax
  __int64 v7; // rcx
  __m128 v8; // xmm0

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = outbuffer[1];
    v6 = 0;
    do
    {
      v7 = (unsigned int)(4 * v6++);
      v8 = _mm_mul_ps(*(__m128 *)&inbuffer[v7], (__m128)xmmword_3E5A90);
      *(__m128 *)&v4[v7] = v8;
      *(__m128 *)&v5[v7] = v8;
    }
    while ( v6 != v3 );
  }
}


// Address: 0x221dbf0 | Name: FMOD_DSP_DeinterleaveMonoToQuad_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveMonoToQuad_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r10
  float *v5; // r9
  int v6; // ecx
  float *v7; // r8
  float *v8; // rsi
  __int64 v9; // rax
  __m128 v10; // xmm0

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = outbuffer[1];
    v6 = 0;
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    do
    {
      v9 = (unsigned int)(4 * v6++);
      v10 = _mm_mul_ps(*(__m128 *)&inbuffer[v9], (__m128)xmmword_3E5A90);
      *(__m128 *)&v4[v9] = v10;
      *(__m128 *)&v5[v9] = v10;
      *(_OWORD *)&v7[v9] = 0;
      *(_OWORD *)&v8[v9] = 0;
    }
    while ( v6 != v3 );
  }
}


// Address: 0x221dc50 | Name: FMOD_DSP_DeinterleaveMonoTo51_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveMonoTo51_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // rbx
  float *v5; // r11
  int v6; // ecx
  float *v7; // r10
  float *v8; // r9
  float *v9; // r8
  float *v10; // rsi
  __int64 v11; // rax
  __m128 v12; // xmm1

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = outbuffer[1];
    v6 = 0;
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = outbuffer[4];
    v10 = outbuffer[5];
    do
    {
      v11 = (unsigned int)(4 * v6++);
      v12 = _mm_mul_ps(*(__m128 *)&inbuffer[v11], (__m128)xmmword_3E5A90);
      *(__m128 *)&v4[v11] = v12;
      *(__m128 *)&v5[v11] = v12;
      *(_OWORD *)&v7[v11] = 0;
      *(_OWORD *)&v8[v11] = 0;
      *(_OWORD *)&v9[v11] = 0;
      *(_OWORD *)&v10[v11] = 0;
    }
    while ( v6 != v3 );
  }
}


// Address: 0x221dcc0 | Name: FMOD_DSP_DeinterleaveMonoTo71_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveMonoTo71_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // ecx
  float *v5; // r12
  float *v6; // rbp
  float *v7; // rbx
  float *v8; // r11
  float *v9; // r10
  float *v10; // r9
  float *v11; // r8
  float *v12; // rsi
  __int64 v13; // rax
  __m128 v14; // xmm1

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 0;
    v5 = *outbuffer;
    v6 = outbuffer[1];
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = outbuffer[4];
    v10 = outbuffer[5];
    v11 = outbuffer[6];
    v12 = outbuffer[7];
    do
    {
      v13 = (unsigned int)(4 * v4++);
      v14 = _mm_mul_ps(*(__m128 *)&inbuffer[v13], (__m128)xmmword_3E5A90);
      *(__m128 *)&v5[v13] = v14;
      *(__m128 *)&v6[v13] = v14;
      *(_OWORD *)&v7[v13] = 0;
      *(_OWORD *)&v8[v13] = 0;
      *(_OWORD *)&v9[v13] = 0;
      *(_OWORD *)&v10[v13] = 0;
      *(_OWORD *)&v11[v13] = 0;
      *(_OWORD *)&v12[v13] = 0;
    }
    while ( v4 != v3 );
  }
}


// Address: 0x221dd50 | Name: FMOD_DSP_DeinterleaveStereoToMono_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveStereoToMono_Normalised_SSE(
        float *inbuffer,
        float **outbuffer,
        unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r8
  unsigned int v5; // ecx
  int i; // eax
  __m128 v7; // xmm2
  __int64 v8; // rsi
  __m128 v9; // xmm1
  __int64 v10; // rsi

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = 4;
    for ( i = 0; i != v3; ++i )
    {
      v7 = *(__m128 *)&inbuffer[8 * i];
      v8 = v5;
      v5 += 8;
      v9 = *(__m128 *)&inbuffer[v8];
      v10 = (unsigned int)(4 * i);
      *(__m128 *)&v4[v10] = _mm_mul_ps(
                              _mm_add_ps(_mm_shuffle_ps(v7, v9, 136), _mm_shuffle_ps(v7, v9, 221)),
                              (__m128)xmmword_3EA320);
    }
  }
}


// Address: 0x221ddb0 | Name: FMOD_DSP_DeinterleaveStereoToStereo_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveStereoToStereo_Normalised_SSE(
        float *inbuffer,
        float **outbuffer,
        unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r9
  float *v5; // r8
  unsigned int v6; // ecx
  int i; // eax
  __m128 v8; // xmm1
  __int64 v9; // rsi
  __m128 v10; // xmm0
  __int64 v11; // rsi

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = outbuffer[1];
    v6 = 4;
    for ( i = 0; i != v3; ++i )
    {
      v8 = *(__m128 *)&inbuffer[8 * i];
      v9 = v6;
      v6 += 8;
      v10 = *(__m128 *)&inbuffer[v9];
      v11 = (unsigned int)(4 * i);
      *(__m128 *)&v4[v11] = _mm_shuffle_ps(v8, v10, 136);
      *(__m128 *)&v5[v11] = _mm_shuffle_ps(v8, v10, 221);
    }
  }
}


// Address: 0x221de10 | Name: FMOD_DSP_DeinterleaveStereoToQuad_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveStereoToQuad_Normalised_SSE(
        float *inbuffer,
        float **outbuffer,
        unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r11
  float *v5; // r10
  float *v6; // r9
  float *v7; // r8
  int v8; // eax
  unsigned int v9; // esi
  __m128 v10; // xmm1
  __int64 v11; // rcx
  __m128 v12; // xmm0
  __int64 v13; // rcx

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = outbuffer[1];
    v6 = outbuffer[2];
    v7 = outbuffer[3];
    v8 = 0;
    v9 = 4;
    do
    {
      v10 = *(__m128 *)&inbuffer[8 * v8];
      v11 = v9;
      v9 += 8;
      v12 = *(__m128 *)&inbuffer[v11];
      v13 = (unsigned int)(4 * v8++);
      *(__m128 *)&v4[v13] = _mm_shuffle_ps(v10, v12, 136);
      *(__m128 *)&v5[v13] = _mm_shuffle_ps(v10, v12, 221);
      *(_OWORD *)&v6[v13] = 0;
      *(_OWORD *)&v7[v13] = 0;
    }
    while ( v8 != v3 );
  }
}


// Address: 0x221de80 | Name: FMOD_DSP_DeinterleaveStereoTo51_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveStereoTo51_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // ecx
  float *v5; // rbp
  float *v6; // rbx
  float *v7; // r11
  float *v8; // r10
  float *v9; // r9
  float *v10; // r8
  unsigned int v11; // esi
  __m128 v12; // xmm2
  __int64 v13; // rax
  __m128 v14; // xmm1
  __int64 v15; // rax

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 0;
    v5 = *outbuffer;
    v6 = outbuffer[1];
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = outbuffer[4];
    v10 = outbuffer[5];
    v11 = 4;
    do
    {
      v12 = *(__m128 *)&inbuffer[8 * v4];
      v13 = v11;
      v11 += 8;
      v14 = *(__m128 *)&inbuffer[v13];
      v15 = (unsigned int)(4 * v4++);
      *(__m128 *)&v5[v15] = _mm_shuffle_ps(v12, v14, 136);
      *(__m128 *)&v6[v15] = _mm_shuffle_ps(v12, v14, 221);
      *(_OWORD *)&v7[v15] = 0;
      *(_OWORD *)&v8[v15] = 0;
      *(_OWORD *)&v9[v15] = 0;
      *(_OWORD *)&v10[v15] = 0;
    }
    while ( v4 != v3 );
  }
}


// Address: 0x221df00 | Name: FMOD_DSP_DeinterleaveStereoTo71_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveStereoTo71_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // ecx
  float *v5; // r13
  float *v6; // r12
  float *v7; // rbp
  float *v8; // rbx
  float *v9; // r11
  float *v10; // r10
  float *v11; // r9
  float *v12; // r8
  unsigned int v13; // esi
  __m128 v14; // xmm2
  __int64 v15; // rax
  __m128 v16; // xmm1
  __int64 v17; // rax

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 0;
    v5 = *outbuffer;
    v6 = outbuffer[1];
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = outbuffer[4];
    v10 = outbuffer[5];
    v11 = outbuffer[6];
    v12 = outbuffer[7];
    v13 = 4;
    do
    {
      v14 = *(__m128 *)&inbuffer[8 * v4];
      v15 = v13;
      v13 += 8;
      v16 = *(__m128 *)&inbuffer[v15];
      v17 = (unsigned int)(4 * v4++);
      *(__m128 *)&v5[v17] = _mm_shuffle_ps(v14, v16, 136);
      *(__m128 *)&v6[v17] = _mm_shuffle_ps(v14, v16, 221);
      *(_OWORD *)&v7[v17] = 0;
      *(_OWORD *)&v8[v17] = 0;
      *(_OWORD *)&v9[v17] = 0;
      *(_OWORD *)&v10[v17] = 0;
      *(_OWORD *)&v11[v17] = 0;
      *(_OWORD *)&v12[v17] = 0;
    }
    while ( v4 != v3 );
  }
}


// Address: 0x221dfa0 | Name: FMOD_DSP_DeinterleaveQuadToMono_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveQuadToMono_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r8
  int v5; // ecx
  int i; // eax
  __m128 v7; // xmm5
  __m128 v8; // xmm3
  __int64 v9; // rsi
  __m128 v10; // xmm1
  __m128 v11; // xmm0
  __m128 v12; // xmm2
  __int64 v13; // rsi
  __m128 v14; // xmm4
  __m128 v15; // xmm3

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = 4;
    for ( i = 0; i != v3; ++i )
    {
      v7 = *(__m128 *)&inbuffer[v5];
      v8 = *(__m128 *)&inbuffer[v5 + 4];
      v9 = (unsigned int)(v5 + 8);
      v5 += 16;
      v10 = _mm_unpacklo_ps(*(__m128 *)&inbuffer[16 * i], v7);
      v11 = *(__m128 *)&inbuffer[v9];
      v12 = _mm_unpackhi_ps(*(__m128 *)&inbuffer[16 * i], v7);
      v13 = (unsigned int)(4 * i);
      v14 = _mm_unpacklo_ps(v8, v11);
      v15 = _mm_unpackhi_ps(v8, v11);
      *(__m128 *)&v4[v13] = _mm_mul_ps(
                              _mm_add_ps(
                                _mm_add_ps(_mm_movelh_ps(v10, v14), _mm_movehl_ps(v14, v10)),
                                _mm_add_ps(_mm_movelh_ps(v12, v15), _mm_movehl_ps(v15, v12))),
                              (__m128)xmmword_3E72A0);
    }
  }
}


// Address: 0x221e030 | Name: FMOD_DSP_DeinterleaveQuadToStereo_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveQuadToStereo_Normalised_SSE(
        float *inbuffer,
        float **outbuffer,
        unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r9
  float *v5; // r8
  int v6; // ecx
  int v7; // eax
  __m128 v8; // xmm5
  __m128 v9; // xmm2
  __int64 v10; // rsi
  __m128 v11; // xmm3
  __m128 v12; // xmm1
  __m128 v13; // xmm4
  __int64 v14; // rsi
  __m128 v15; // xmm0
  __m128 v16; // xmm2

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = outbuffer[1];
    v6 = 4;
    v7 = 0;
    do
    {
      v8 = *(__m128 *)&inbuffer[v6];
      v9 = *(__m128 *)&inbuffer[v6 + 4];
      v10 = (unsigned int)(v6 + 8);
      v6 += 16;
      v11 = _mm_unpacklo_ps(*(__m128 *)&inbuffer[16 * v7], v8);
      v12 = *(__m128 *)&inbuffer[v10];
      v13 = _mm_unpackhi_ps(*(__m128 *)&inbuffer[16 * v7], v8);
      v14 = (unsigned int)(4 * v7);
      v15 = _mm_unpacklo_ps(v9, v12);
      ++v7;
      v16 = _mm_unpackhi_ps(v9, v12);
      *(__m128 *)&v4[v14] = _mm_add_ps(
                              _mm_movelh_ps(v11, v15),
                              _mm_mul_ps(_mm_movelh_ps(v13, v16), (__m128)xmmword_3E5A90));
      *(__m128 *)&v5[v14] = _mm_add_ps(
                              _mm_movehl_ps(v15, v11),
                              _mm_mul_ps(_mm_movehl_ps(v16, v13), (__m128)xmmword_3E5A90));
    }
    while ( v7 != v3 );
  }
}


// Address: 0x221e0c0 | Name: FMOD_DSP_DeinterleaveQuadToQuad_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveQuadToQuad_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r11
  float *v5; // r10
  int v6; // ecx
  float *v7; // r9
  float *v8; // r8
  int v9; // eax
  __m128 v10; // xmm5
  __m128 v11; // xmm2
  __m128 v12; // xmm1
  __int64 v13; // rsi
  __m128 v14; // xmm0
  __m128 v15; // xmm4
  __m128 v16; // xmm2
  __m128 v17; // xmm3
  __int64 v18; // rsi
  __m128 v19; // xmm1
  __m128 v20; // xmm3

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = outbuffer[1];
    v6 = 4;
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = 0;
    do
    {
      v10 = *(__m128 *)&inbuffer[v6];
      v11 = *(__m128 *)&inbuffer[16 * v9];
      v12 = *(__m128 *)&inbuffer[v6 + 4];
      v13 = (unsigned int)(v6 + 8);
      v6 += 16;
      v14 = _mm_unpackhi_ps(v11, v10);
      v15 = *(__m128 *)&inbuffer[v13];
      v16 = _mm_unpacklo_ps(v11, v10);
      v17 = v12;
      v18 = (unsigned int)(4 * v9);
      v19 = _mm_unpackhi_ps(v12, v15);
      ++v9;
      v20 = _mm_unpacklo_ps(v17, v15);
      *(__m128 *)&v4[v18] = _mm_movelh_ps(v16, v20);
      *(__m128 *)&v5[v18] = _mm_movehl_ps(v20, v16);
      *(__m128 *)&v7[v18] = _mm_movelh_ps(v14, v19);
      *(__m128 *)&v8[v18] = _mm_movehl_ps(v19, v14);
    }
    while ( v9 != v3 );
  }
}


// Address: 0x221e150 | Name: FMOD_DSP_DeinterleaveQuadTo51_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveQuadTo51_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // ecx
  float *v5; // rbp
  float *v6; // rbx
  float *v7; // r11
  float *v8; // r10
  float *v9; // r9
  float *v10; // r8
  int v11; // esi
  __m128 v12; // xmm10
  __m128 v13; // xmm3
  __int64 v14; // rax
  __m128 v15; // xmm2
  __m128 v16; // xmm1
  __m128 v17; // xmm4
  __int64 v18; // rax
  __m128 v19; // xmm0
  __m128 v20; // xmm3
  __m128 v21; // xmm1
  __m128 v22; // xmm0
  __m128 v23; // xmm2
  __m128 v24; // xmm3

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 0;
    v5 = *outbuffer;
    v6 = outbuffer[1];
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = outbuffer[4];
    v10 = outbuffer[5];
    v11 = 4;
    do
    {
      v12 = *(__m128 *)&inbuffer[v11];
      v13 = *(__m128 *)&inbuffer[v11 + 4];
      v14 = (unsigned int)(v11 + 8);
      v11 += 16;
      v15 = _mm_unpacklo_ps(*(__m128 *)&inbuffer[16 * v4], v12);
      v16 = *(__m128 *)&inbuffer[v14];
      v17 = _mm_unpackhi_ps(*(__m128 *)&inbuffer[16 * v4], v12);
      v18 = (unsigned int)(4 * v4);
      v19 = _mm_unpacklo_ps(v13, v16);
      ++v4;
      v20 = _mm_unpackhi_ps(v13, v16);
      v21 = _mm_movelh_ps(v15, v19);
      v22 = _mm_movehl_ps(v19, v15);
      v23 = _mm_movelh_ps(v17, v20);
      v24 = _mm_movehl_ps(v20, v17);
      *(__m128 *)&v5[v18] = _mm_mul_ps(v21, (__m128)xmmword_3EAD20);
      *(__m128 *)&v6[v18] = _mm_mul_ps(v22, (__m128)xmmword_3EAD20);
      *(_OWORD *)&v7[v18] = 0;
      *(_OWORD *)&v8[v18] = 0;
      *(__m128 *)&v9[v18] = _mm_add_ps(
                              _mm_add_ps(
                                _mm_mul_ps(v21, (__m128)xmmword_3E8E70),
                                _mm_mul_ps((__m128)xmmword_3E8430, v23)),
                              _mm_mul_ps((__m128)xmmword_3E6450, v24));
      *(__m128 *)&v10[v18] = _mm_add_ps(
                               _mm_add_ps(
                                 _mm_mul_ps(v22, (__m128)xmmword_3E8E70),
                                 _mm_mul_ps(v23, (__m128)xmmword_3E6450)),
                               _mm_mul_ps(v24, (__m128)xmmword_3E8430));
    }
    while ( v4 != v3 );
  }
}


// Address: 0x221e260 | Name: FMOD_DSP_DeinterleaveQuadTo71_Normalised_SSE
void __fastcall FMOD_DSP_DeinterleaveQuadTo71_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // ecx
  float *v5; // r13
  float *v6; // r12
  float *v7; // rbp
  float *v8; // rbx
  float *v9; // r11
  float *v10; // r10
  float *v11; // r9
  float *v12; // r8
  int v13; // esi
  __m128 v14; // xmm6
  __m128 v15; // xmm3
  __int64 v16; // rax
  __m128 v17; // xmm4
  __m128 v18; // xmm2
  __m128 v19; // xmm5
  __int64 v20; // rax
  __m128 v21; // xmm1
  __m128 v22; // xmm3
  __m128 v23; // xmm2
  __m128 v24; // xmm1
  __m128 v25; // xmm4
  __m128 v26; // xmm3

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 0;
    v5 = *outbuffer;
    v6 = outbuffer[1];
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = outbuffer[4];
    v10 = outbuffer[5];
    v11 = outbuffer[6];
    v12 = outbuffer[7];
    v13 = 4;
    do
    {
      v14 = *(__m128 *)&inbuffer[v13];
      v15 = *(__m128 *)&inbuffer[v13 + 4];
      v16 = (unsigned int)(v13 + 8);
      v13 += 16;
      v17 = _mm_unpacklo_ps(*(__m128 *)&inbuffer[16 * v4], v14);
      v18 = *(__m128 *)&inbuffer[v16];
      v19 = _mm_unpackhi_ps(*(__m128 *)&inbuffer[16 * v4], v14);
      v20 = (unsigned int)(4 * v4);
      v21 = _mm_unpacklo_ps(v15, v18);
      ++v4;
      v22 = _mm_unpackhi_ps(v15, v18);
      v23 = _mm_movelh_ps(v17, v21);
      v24 = _mm_movehl_ps(v21, v17);
      v25 = _mm_movelh_ps(v19, v22);
      v26 = _mm_movehl_ps(v22, v19);
      *(__m128 *)&v5[v20] = _mm_mul_ps(v23, (__m128)xmmword_3E70E0);
      *(__m128 *)&v6[v20] = _mm_mul_ps(v24, (__m128)xmmword_3E70E0);
      *(_OWORD *)&v7[v20] = 0;
      *(_OWORD *)&v8[v20] = 0;
      *(__m128 *)&v9[v20] = _mm_mul_ps(_mm_add_ps(v23, v25), (__m128)xmmword_3E52D0);
      *(__m128 *)&v10[v20] = _mm_mul_ps(_mm_add_ps(v24, v26), (__m128)xmmword_3E52D0);
      *(__m128 *)&v11[v20] = _mm_mul_ps(v25, (__m128)xmmword_3E70E0);
      *(__m128 *)&v12[v20] = _mm_mul_ps(v26, (__m128)xmmword_3E70E0);
    }
    while ( v4 != v3 );
  }
}


// Address: 0x221e360 | Name: FMOD_DSP_Deinterleave51ToMono_Normalised_SSE
void __fastcall FMOD_DSP_Deinterleave51ToMono_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r8
  int v5; // eax
  int v6; // ecx
  __m128 v7; // xmm1
  __m128 v8; // xmm4
  __m128 v9; // xmm6
  __m128 v10; // xmm7
  __m128 v11; // xmm3
  __int64 v12; // rsi
  __m128 v13; // xmm5
  __m128 v14; // xmm0
  __int64 v15; // rsi
  __m128 v16; // xmm2
  __m128 v17; // xmm4
  __m128 v18; // xmm3

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = 4;
    v6 = 0;
    do
    {
      v7 = *(__m128 *)&inbuffer[v5 - 4];
      v8 = *(__m128 *)&inbuffer[v5];
      v9 = *(__m128 *)&inbuffer[v5 + 4];
      v10 = *(__m128 *)&inbuffer[v5 + 8];
      v11 = *(__m128 *)&inbuffer[v5 + 12];
      v12 = (unsigned int)(v5 + 16);
      v13 = _mm_unpacklo_ps(v7, v10);
      v5 += 24;
      v14 = *(__m128 *)&inbuffer[v12];
      v15 = (unsigned int)(4 * v6);
      v16 = _mm_unpackhi_ps(v8, v11);
      ++v6;
      v17 = _mm_unpacklo_ps(v8, v11);
      v18 = _mm_unpackhi_ps(v9, v14);
      *(__m128 *)&v4[v15] = _mm_mul_ps(
                              _mm_add_ps(
                                _mm_add_ps(
                                  _mm_add_ps(_mm_unpacklo_ps(v13, v16), _mm_unpackhi_ps(v13, v16)),
                                  _mm_add_ps(_mm_unpacklo_ps(v17, v18), _mm_unpackhi_ps(v17, v18))),
                                _mm_unpacklo_ps(_mm_unpackhi_ps(v7, v10), _mm_unpacklo_ps(v9, v14))),
                              (__m128)xmmword_3EA330);
    }
    while ( v6 != v3 );
  }
}


// Address: 0x221e410 | Name: FMOD_DSP_Deinterleave51ToStereo_Normalised_SSE
void __fastcall FMOD_DSP_Deinterleave51ToStereo_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r9
  float *v5; // r8
  int v6; // eax
  int v7; // ecx
  __m128 v8; // xmm2
  __m128 v9; // xmm0
  __m128 v10; // xmm6
  __m128 v11; // xmm7
  __m128 v12; // xmm5
  __int64 v13; // rsi
  __m128 v14; // xmm3
  __m128 v15; // xmm4
  __int64 v16; // rsi
  __m128 v17; // xmm1
  __m128 v18; // xmm0
  __m128 v19; // xmm5
  __m128 v20; // xmm2

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *outbuffer;
    v5 = outbuffer[1];
    v6 = 4;
    v7 = 0;
    do
    {
      v8 = *(__m128 *)&inbuffer[v6 - 4];
      v9 = *(__m128 *)&inbuffer[v6];
      v10 = *(__m128 *)&inbuffer[v6 + 4];
      v11 = *(__m128 *)&inbuffer[v6 + 8];
      v12 = *(__m128 *)&inbuffer[v6 + 12];
      v13 = (unsigned int)(v6 + 16);
      v14 = _mm_unpacklo_ps(v8, v11);
      v6 += 24;
      v15 = *(__m128 *)&inbuffer[v13];
      v16 = (unsigned int)(4 * v7);
      v17 = _mm_unpackhi_ps(v9, v12);
      ++v7;
      v18 = _mm_unpacklo_ps(v9, v12);
      v19 = _mm_unpackhi_ps(v10, v15);
      v20 = _mm_unpacklo_ps(_mm_unpackhi_ps(v8, v11), _mm_unpacklo_ps(v10, v15));
      *(__m128 *)&v4[v16] = _mm_add_ps(
                              _mm_unpacklo_ps(v14, v17),
                              _mm_mul_ps(_mm_add_ps(_mm_unpacklo_ps(v18, v19), v20), (__m128)xmmword_3E5A90));
      *(__m128 *)&v5[v16] = _mm_add_ps(
                              _mm_unpackhi_ps(v14, v17),
                              _mm_mul_ps(_mm_add_ps(_mm_unpackhi_ps(v18, v19), v20), (__m128)xmmword_3E5A90));
    }
    while ( v7 != v3 );
  }
}


// Address: 0x221e4d0 | Name: FMOD_DSP_Deinterleave51ToQuad_Normalised_SSE
void __fastcall FMOD_DSP_Deinterleave51ToQuad_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // eax
  float *v5; // r11
  float *v6; // r10
  float *v7; // r9
  float *v8; // r8
  int v9; // esi
  __m128 v10; // xmm4
  __m128 v11; // xmm1
  __m128 v12; // xmm6
  __m128 v13; // xmm7
  __m128 v14; // xmm3
  __int64 v15; // rcx
  __m128 v16; // xmm2
  __int64 v17; // rcx
  __m128 v18; // xmm5
  __m128 v19; // xmm4
  __m128 v20; // xmm3
  __m128 v21; // xmm0
  __m128 v22; // xmm2
  __m128 v23; // xmm0

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 4;
    v5 = *outbuffer;
    v6 = outbuffer[1];
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = 0;
    do
    {
      v10 = *(__m128 *)&inbuffer[v4];
      v11 = *(__m128 *)&inbuffer[v4 - 4];
      v12 = *(__m128 *)&inbuffer[v4 + 4];
      v13 = *(__m128 *)&inbuffer[v4 + 8];
      v14 = *(__m128 *)&inbuffer[v4 + 12];
      v15 = (unsigned int)(v4 + 16);
      v4 += 24;
      v16 = *(__m128 *)&inbuffer[v15];
      v17 = (unsigned int)(4 * v9);
      v18 = _mm_unpackhi_ps(v10, v14);
      ++v9;
      v19 = _mm_unpacklo_ps(v10, v14);
      v20 = _mm_unpackhi_ps(v12, v16);
      v21 = _mm_unpacklo_ps(_mm_unpackhi_ps(v11, v13), _mm_unpacklo_ps(v12, v16));
      v22 = _mm_unpacklo_ps(v11, v13);
      v23 = _mm_mul_ps(v21, (__m128)xmmword_3E5A90);
      *(__m128 *)&v5[v17] = _mm_add_ps(_mm_unpacklo_ps(v22, v18), v23);
      *(__m128 *)&v6[v17] = _mm_add_ps(_mm_unpackhi_ps(v22, v18), v23);
      *(__m128 *)&v7[v17] = _mm_unpacklo_ps(v19, v20);
      *(__m128 *)&v8[v17] = _mm_unpackhi_ps(v19, v20);
    }
    while ( v9 != v3 );
  }
}


// Address: 0x221e590 | Name: FMOD_DSP_Deinterleave51To51_Normalised_SSE
void __fastcall FMOD_DSP_Deinterleave51To51_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // eax
  float *v5; // rbp
  float *v6; // rbx
  float *v7; // r11
  float *v8; // r10
  float *v9; // r9
  float *v10; // r8
  int v11; // esi
  __m128 v12; // xmm3
  __m128 v13; // xmm1
  __m128 v14; // xmm2
  __m128 v15; // xmm7
  __m128 v16; // xmm0
  __int64 v17; // rcx
  __m128 v18; // xmm6
  __int64 v19; // rcx
  __m128 v20; // xmm4
  __m128 v21; // xmm1
  __m128 v22; // xmm0
  __m128 v23; // xmm2
  __m128 v24; // xmm0
  __m128 v25; // xmm6
  __m128 v26; // xmm5
  __m128 v27; // xmm6
  __m128 v28; // xmm4

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 4;
    v5 = *outbuffer;
    v6 = outbuffer[1];
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = outbuffer[4];
    v10 = outbuffer[5];
    v11 = 0;
    do
    {
      v12 = *(__m128 *)&inbuffer[v4 - 4];
      v13 = *(__m128 *)&inbuffer[v4];
      v14 = *(__m128 *)&inbuffer[v4 + 4];
      v15 = *(__m128 *)&inbuffer[v4 + 8];
      v16 = *(__m128 *)&inbuffer[v4 + 12];
      v17 = (unsigned int)(v4 + 16);
      v4 += 24;
      v18 = *(__m128 *)&inbuffer[v17];
      v19 = (unsigned int)(4 * v11);
      v20 = _mm_unpackhi_ps(v13, v16);
      ++v11;
      v21 = _mm_unpacklo_ps(v13, v16);
      v22 = v14;
      v23 = _mm_unpacklo_ps(v14, v18);
      v24 = _mm_unpackhi_ps(v22, v18);
      v25 = _mm_unpacklo_ps(v12, v15);
      v26 = _mm_unpackhi_ps(v25, v20);
      v27 = _mm_unpacklo_ps(v25, v20);
      v28 = _mm_unpackhi_ps(v12, v15);
      *(__m128 *)&v5[v19] = v27;
      *(__m128 *)&v6[v19] = v26;
      *(__m128 *)&v7[v19] = _mm_unpacklo_ps(v28, v23);
      *(__m128 *)&v8[v19] = _mm_unpackhi_ps(v28, v23);
      *(__m128 *)&v9[v19] = _mm_unpacklo_ps(v21, v24);
      *(__m128 *)&v10[v19] = _mm_unpackhi_ps(v21, v24);
    }
    while ( v11 != v3 );
  }
}


// Address: 0x221e660 | Name: FMOD_DSP_Deinterleave51To71_Normalised_SSE
void __fastcall FMOD_DSP_Deinterleave51To71_Normalised_SSE(float *inbuffer, float **outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // ecx
  float *v5; // r13
  float *v6; // r12
  float *v7; // rbp
  float *v8; // rbx
  float *v9; // r11
  float *v10; // r10
  float *v11; // r9
  float *v12; // r8
  int v13; // esi
  __m128 v14; // xmm0
  __m128 v15; // xmm5
  __m128 v16; // xmm1
  __m128 v17; // xmm7
  __m128 v18; // xmm2
  __int64 v19; // rax
  __m128 v20; // xmm3
  __m128 v21; // xmm6
  __int64 v22; // rax
  __m128 v23; // xmm4
  __m128 v24; // xmm0
  __m128 v25; // xmm2
  __m128 v26; // xmm1
  __m128 v27; // xmm5
  __m128 v28; // xmm2
  __m128 v29; // xmm7
  __m128 v30; // xmm3
  __m128 v31; // xmm1
  __m128 v32; // xmm0

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 4;
    v5 = *outbuffer;
    v6 = outbuffer[1];
    v7 = outbuffer[2];
    v8 = outbuffer[3];
    v9 = outbuffer[4];
    v10 = outbuffer[5];
    v11 = outbuffer[6];
    v12 = outbuffer[7];
    v13 = 0;
    do
    {
      v14 = *(__m128 *)&inbuffer[v4];
      v15 = *(__m128 *)&inbuffer[v4 - 4];
      v16 = *(__m128 *)&inbuffer[v4 + 4];
      v17 = *(__m128 *)&inbuffer[v4 + 8];
      v18 = *(__m128 *)&inbuffer[v4 + 12];
      v19 = (unsigned int)(v4 + 16);
      v20 = _mm_unpackhi_ps(v15, v17);
      v4 += 24;
      v21 = *(__m128 *)&inbuffer[v19];
      v22 = (unsigned int)(4 * v13);
      v23 = _mm_unpackhi_ps(v14, v18);
      ++v13;
      v24 = _mm_unpacklo_ps(v14, v18);
      v25 = v16;
      v26 = _mm_unpacklo_ps(v16, v21);
      v27 = _mm_unpacklo_ps(v15, v17);
      v28 = _mm_unpackhi_ps(v25, v21);
      v29 = _mm_unpacklo_ps(v20, v26);
      v30 = _mm_unpackhi_ps(v20, v26);
      v31 = _mm_unpacklo_ps(v24, v28);
      v32 = _mm_unpackhi_ps(v24, v28);
      *(__m128 *)&v5[v22] = _mm_unpacklo_ps(v27, v23);
      *(__m128 *)&v6[v22] = _mm_unpackhi_ps(v27, v23);
      *(__m128 *)&v7[v22] = v29;
      *(__m128 *)&v8[v22] = v30;
      *(__m128 *)&v9[v22] = _mm_mul_ps((__m128)xmmword_3E9480, v31);
      *(__m128 *)&v10[v22] = _mm_mul_ps((__m128)xmmword_3E9480, v32);
      *(__m128 *)&v11[v22] = _mm_mul_ps(v31, (__m128)xmmword_3E9EC0);
      *(__m128 *)&v12[v22] = _mm_mul_ps(v32, (__m128)xmmword_3E9EC0);
    }
    while ( v13 != v3 );
  }
}


// Address: 0x221e770 | Name: FMOD_DSP_InterleaveStereo_SSE
void __fastcall FMOD_DSP_InterleaveStereo_SSE(float **inbuffer, float *outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r9
  float *v5; // r8
  unsigned int v6; // ecx
  int v7; // eax
  __int64 v8; // rdi
  __m128 v9; // xmm1
  __m128 v10; // xmm0
  __int64 v11; // rdi
  __int64 v12; // rdi

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *inbuffer;
    v5 = inbuffer[1];
    v6 = 4;
    v7 = 0;
    do
    {
      v8 = (unsigned int)(4 * v7);
      v9 = *(__m128 *)&v4[v8];
      v10 = *(__m128 *)&v5[v8];
      v11 = (unsigned int)(8 * v7++);
      *(__m128 *)&outbuffer[v11] = _mm_unpacklo_ps(v9, v10);
      v12 = v6;
      v6 += 8;
      *(__m128 *)&outbuffer[v12] = _mm_unpackhi_ps(v9, v10);
    }
    while ( v7 != v3 );
  }
}


// Address: 0x221e7c0 | Name: FMOD_DSP_InterleaveQuad_SSE
void __fastcall FMOD_DSP_InterleaveQuad_SSE(float **inbuffer, float *outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  float *v4; // r11
  float *v5; // r10
  int v6; // ecx
  float *v7; // r9
  float *v8; // r8
  int v9; // eax
  __int64 v10; // rdi
  __m128 v11; // xmm5
  __m128 v12; // xmm2
  __m128 v13; // xmm1
  __m128 v14; // xmm0
  __m128 v15; // xmm2
  __m128 v16; // xmm4
  __m128 v17; // xmm3
  __m128 v18; // xmm1
  __int64 v19; // rdi

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = *inbuffer;
    v5 = inbuffer[1];
    v6 = 4;
    v7 = inbuffer[2];
    v8 = inbuffer[3];
    v9 = 0;
    do
    {
      v10 = (unsigned int)(4 * v9);
      v11 = *(__m128 *)&v5[v10];
      v12 = *(__m128 *)&v4[v10];
      v13 = *(__m128 *)&v7[v10];
      v14 = _mm_unpackhi_ps(v12, v11);
      v15 = _mm_unpacklo_ps(v12, v11);
      v16 = *(__m128 *)&v8[v10];
      LODWORD(v10) = v9++;
      v17 = _mm_unpacklo_ps(v13, v16);
      v18 = _mm_unpackhi_ps(v13, v16);
      *(__m128 *)&outbuffer[(unsigned int)(16 * v10)] = _mm_movelh_ps(v15, v17);
      *(__m128 *)&outbuffer[v6] = _mm_movehl_ps(v17, v15);
      *(__m128 *)&outbuffer[v6 + 4] = _mm_movelh_ps(v14, v18);
      v19 = (unsigned int)(v6 + 8);
      v6 += 16;
      *(__m128 *)&outbuffer[v19] = _mm_movehl_ps(v18, v14);
    }
    while ( v9 != v3 );
  }
}


// Address: 0x221e850 | Name: FMOD_DSP_Interleave51_SSE
void __fastcall FMOD_DSP_Interleave51_SSE(float **inbuffer, float *outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // eax
  float *v5; // rbp
  float *v6; // rbx
  float *v7; // r11
  float *v8; // r10
  float *v9; // r9
  float *v10; // r8
  int v11; // edi
  __int64 v12; // rcx
  __m128 v13; // xmm8
  __m128 v14; // xmm5
  __m128 v15; // xmm6
  __m128 v16; // xmm4
  __m128 v17; // xmm7
  __m128 v18; // xmm1
  __m128 v19; // xmm2
  __m128 v20; // xmm0
  __m128 v21; // xmm6
  __int64 v22; // rcx

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 0;
    v5 = *inbuffer;
    v6 = inbuffer[1];
    v7 = inbuffer[2];
    v8 = inbuffer[3];
    v9 = inbuffer[4];
    v10 = inbuffer[5];
    v11 = 0;
    do
    {
      v12 = (unsigned int)(4 * v11++);
      v13 = *(__m128 *)&v6[v12];
      v14 = _mm_unpacklo_ps(*(__m128 *)&v5[v12], v13);
      v15 = *(__m128 *)&v10[v12];
      v16 = _mm_unpackhi_ps(*(__m128 *)&v5[v12], v13);
      v17 = *(__m128 *)&v8[v12];
      v18 = _mm_unpackhi_ps(*(__m128 *)&v9[v12], v15);
      v19 = _mm_unpacklo_ps(*(__m128 *)&v7[v12], v17);
      v20 = _mm_unpackhi_ps(*(__m128 *)&v7[v12], v17);
      v21 = _mm_unpacklo_ps(*(__m128 *)&v9[v12], v15);
      *(__m128 *)&outbuffer[v4] = _mm_movelh_ps(v14, v19);
      *(__m128 *)&outbuffer[v4 + 4] = _mm_shuffle_ps(v21, v14, 228);
      *(__m128 *)&outbuffer[v4 + 8] = _mm_movehl_ps(v21, v19);
      *(__m128 *)&outbuffer[v4 + 12] = _mm_movelh_ps(v16, v20);
      *(__m128 *)&outbuffer[v4 + 16] = _mm_shuffle_ps(v18, v16, 228);
      v22 = (unsigned int)(v4 + 20);
      v4 += 24;
      *(__m128 *)&outbuffer[v22] = _mm_movehl_ps(v18, v20);
    }
    while ( v11 != v3 );
  }
}


// Address: 0x221e920 | Name: FMOD_DSP_Interleave71_SSE
void __fastcall FMOD_DSP_Interleave71_SSE(float **inbuffer, float *outbuffer, unsigned int length)
{
  unsigned int v3; // edx
  int v4; // eax
  float *v5; // r13
  float *v6; // r12
  float *v7; // rbp
  float *v8; // rbx
  float *v9; // r11
  float *v10; // r10
  float *v11; // r9
  float *v12; // r8
  int v13; // edi
  __int64 v14; // rcx
  __m128 v15; // xmm11
  __m128 v16; // xmm6
  __m128 v17; // xmm9
  __m128 v18; // xmm2
  __m128 v19; // xmm1
  __m128 v20; // xmm4
  __m128 v21; // xmm10
  __m128 v22; // xmm0
  __m128 v23; // xmm8
  __m128 v24; // xmm7
  __m128 v25; // xmm3
  __m128 v26; // xmm5
  __int64 v27; // rcx
  __m128 v28; // xmm1
  __int64 v29; // rcx

  v3 = length >> 2;
  if ( v3 )
  {
    v4 = 4;
    v5 = *inbuffer;
    v6 = inbuffer[1];
    v7 = inbuffer[2];
    v8 = inbuffer[3];
    v9 = inbuffer[4];
    v10 = inbuffer[5];
    v11 = inbuffer[6];
    v12 = inbuffer[7];
    v13 = 0;
    do
    {
      v14 = (unsigned int)(4 * v13);
      v15 = *(__m128 *)&v6[v14];
      v16 = _mm_unpacklo_ps(*(__m128 *)&v5[v14], v15);
      v17 = *(__m128 *)&v10[v14];
      v18 = _mm_unpackhi_ps(*(__m128 *)&v5[v14], v15);
      v19 = *(__m128 *)&v11[v14];
      v20 = _mm_unpacklo_ps(*(__m128 *)&v9[v14], v17);
      v21 = *(__m128 *)&v8[v14];
      v22 = _mm_unpackhi_ps(*(__m128 *)&v9[v14], v17);
      v23 = *(__m128 *)&v12[v14];
      v24 = _mm_unpacklo_ps(*(__m128 *)&v7[v14], v21);
      v25 = _mm_unpackhi_ps(*(__m128 *)&v7[v14], v21);
      v26 = _mm_unpacklo_ps(v19, v23);
      v27 = (unsigned int)(32 * v13++);
      *(__m128 *)&outbuffer[v27] = _mm_movelh_ps(v16, v24);
      *(__m128 *)&outbuffer[v4] = _mm_movelh_ps(v20, v26);
      v28 = _mm_unpackhi_ps(v19, v23);
      *(__m128 *)&outbuffer[v4 + 4] = _mm_movehl_ps(v24, v16);
      *(__m128 *)&outbuffer[v4 + 8] = _mm_movehl_ps(v26, v20);
      *(__m128 *)&outbuffer[v4 + 12] = _mm_movelh_ps(v18, v25);
      *(__m128 *)&outbuffer[v4 + 16] = _mm_movelh_ps(v22, v28);
      *(__m128 *)&outbuffer[v4 + 20] = _mm_movehl_ps(v25, v18);
      v29 = (unsigned int)(v4 + 24);
      v4 += 32;
      *(__m128 *)&outbuffer[v29] = _mm_movehl_ps(v28, v22);
    }
    while ( v13 != v3 );
  }
}


// Address: 0x221ea40 | Name: FMOD_DSP_Deinterleave_SSE
void __fastcall FMOD_DSP_Deinterleave_SSE(
        float *inbuffer,
        float **outbuffer,
        int inchannels,
        int outchannels,
        unsigned int length)
{
  switch ( inchannels )
  {
    case 1:
      switch ( outchannels )
      {
        case 1:
          memcpy_0(*outbuffer, inbuffer, 4LL * length);
          break;
        case 2:
          FMOD_DSP_DeinterleaveMonoToStereo_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 4:
          FMOD_DSP_DeinterleaveMonoToQuad_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 6:
          FMOD_DSP_DeinterleaveMonoTo51_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 8:
          FMOD_DSP_DeinterleaveMonoTo71_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        default:
          goto LABEL_2;
      }
      break;
    case 2:
      switch ( outchannels )
      {
        case 1:
          FMOD_DSP_DeinterleaveStereoToMono_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 2:
          FMOD_DSP_DeinterleaveStereoToStereo_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 4:
          FMOD_DSP_DeinterleaveStereoToQuad_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 6:
          FMOD_DSP_DeinterleaveStereoTo51_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 8:
          FMOD_DSP_DeinterleaveStereoTo71_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        default:
          goto LABEL_2;
      }
      break;
    case 4:
      switch ( outchannels )
      {
        case 1:
          FMOD_DSP_DeinterleaveQuadToMono_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 2:
          FMOD_DSP_DeinterleaveQuadToStereo_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 4:
          FMOD_DSP_DeinterleaveQuadToQuad_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 6:
          FMOD_DSP_DeinterleaveQuadTo51_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 8:
          FMOD_DSP_DeinterleaveQuadTo71_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        default:
          goto LABEL_2;
      }
      break;
    case 6:
      switch ( outchannels )
      {
        case 1:
          FMOD_DSP_Deinterleave51ToMono_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 2:
          FMOD_DSP_Deinterleave51ToStereo_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 4:
          FMOD_DSP_Deinterleave51ToQuad_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 6:
          FMOD_DSP_Deinterleave51To51_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 8:
          FMOD_DSP_Deinterleave51To71_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        default:
          goto LABEL_2;
      }
      break;
    case 8:
      switch ( outchannels )
      {
        case 1:
          FMOD_DSP_Deinterleave71ToMono_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 2:
          FMOD_DSP_Deinterleave71ToStereo_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 4:
          FMOD_DSP_Deinterleave71ToQuad_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 6:
          FMOD_DSP_Deinterleave71To51_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        case 8:
          FMOD_DSP_Deinterleave71To71_Normalised_SSE(inbuffer, outbuffer, length);
          break;
        default:
          goto LABEL_2;
      }
      break;
    default:
LABEL_2:
      FMOD_DSP_Deinterleave_NoOpt(inbuffer, outbuffer, inchannels, outchannels, length);
      break;
  }
}


// Address: 0x221eca0 | Name: FMOD_DSP_Interleave_SSE
void __fastcall FMOD_DSP_Interleave_SSE(float **inbuffer, float *outbuffer, int channels, unsigned int length)
{
  switch ( channels )
  {
    case 1:
      memcpy_0(outbuffer, *inbuffer, 4LL * length);
      break;
    case 2:
      FMOD_DSP_InterleaveStereo_SSE(inbuffer, outbuffer, length);
      break;
    case 4:
      FMOD_DSP_InterleaveQuad_SSE(inbuffer, outbuffer, length);
      break;
    case 6:
      FMOD_DSP_Interleave51_SSE(inbuffer, outbuffer, length);
      break;
    case 8:
      FMOD_DSP_Interleave71_SSE(inbuffer, outbuffer, length);
      break;
    default:
      FMOD_DSP_Interleave_NoOpt(inbuffer, outbuffer, channels, length);
      break;
  }
}


