// Address: 0x21d2300 | Name: _ZN4FMOD9CodecUser16getDescriptionExEv
FMOD::FMOD_CODEC_DESCRIPTION_EX *__cdecl FMOD::CodecUser::getDescriptionEx()
{
  stru_2AD84E0.version = 65792;
  stru_2AD84E0.timeunits = 2;
  stru_2AD84E0.mType = FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_USER_0;
  stru_2AD84E0.mSize = 472;
  stru_2AD84E0.name = "FMOD User Reader Codec";
  stru_2AD84E0.open = FMOD::CodecUser::openInternal;
  stru_2AD84E0.close = FMOD::CodecUser::closeInternal;
  stru_2AD84E0.read = FMOD::CodecUser::readInternal;
  stru_2AD84E0.setposition = FMOD::CodecUser::setPositionInternal;
  return &stru_2AD84E0;
}


// Address: 0x21d2380 | Name: _ZN4FMOD9CodecUser12openInternalEjP22FMOD_CREATESOUNDEXINFO
FMOD_RESULT_0 __fastcall FMOD::CodecUser::openInternal(
        FMOD::CodecUser *const this,
        FMOD_MODE usermode,
        FMOD_CREATESOUNDEXINFO *userexinfo)
{
  FMOD_RESULT_0 result; // eax
  FMOD_SOUND_FORMAT format; // eax
  unsigned int numchannels; // esi
  FMOD_CODEC_WAVEFORMAT *waveformat; // rcx
  int defaultfrequency; // edi
  unsigned int length; // edx
  unsigned __int64 v10; // rdi

  this->mType = FMOD_SOUND_TYPE::FMOD_SOUND_TYPE_USER_0;
  this->mDecoder = 0;
  this->mDecoderContext = 0;
  this->mDecoderContextMemory = 0;
  this->mPCMBufferMemory = 0;
  this->fileread = (FMOD_FILE_READ_CALLBACK)FMOD::Codec::defaultFileRead;
  this->mWaveFormatMemory = 0;
  this->mMetadata = 0;
  this->numsubsounds = 0;
  this->waveformatversion = 3;
  this->fileseek = (FMOD_FILE_SEEK_CALLBACK)FMOD::Codec::defaultFileSeek;
  this->metadata = FMOD::Codec::defaultMetaData;
  this->waveformat = &this->mWaveFormat;
  result = FMOD_RESULT::FMOD_ERR_FORMAT_0;
  if ( (unsigned int)(userexinfo->format - 1) <= 4 )
  {
    result = (*((unsigned int (__fastcall **)(FMOD::File *, unsigned int *))this->mFile->_vptr_File + 3))(
               this->mFile,
               &this->mWaveFormat.lengthbytes);
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      format = userexinfo->format;
      numchannels = userexinfo->numchannels;
      waveformat = this->waveformat;
      defaultfrequency = userexinfo->defaultfrequency;
      this->mSrcDataOffset = 0;
      length = userexinfo->length;
      waveformat->format = format;
      waveformat->channels = numchannels;
      waveformat->frequency = defaultfrequency;
      if ( numchannels )
      {
        switch ( format )
        {
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8:
            v10 = 8;
            goto LABEL_8;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16:
            v10 = 16;
            goto LABEL_8;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24:
            v10 = 24;
            goto LABEL_8;
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32:
          case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT:
            v10 = 32;
LABEL_8:
            waveformat->lengthpcm = (unsigned int)(8 * (unsigned __int64)length / v10) / numchannels;
            break;
          default:
            waveformat->lengthpcm = length;
            break;
        }
      }
      this->numsubsounds = 0;
      return FMOD_RESULT::FMOD_OK_0;
    }
  }
  return result;
}


// Address: 0x21d24c0 | Name: j__ZN4FMOD9CodecUser12openInternalEjP22FMOD_CREATESOUNDEXINFO
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecUser::openInternal(
        FMOD_CODEC_STATE *codec,
        FMOD_MODE usermode,
        FMOD_CREATESOUNDEXINFO *userexinfo)
{
  return _ZN4FMOD9CodecUser12openInternalEjP22FMOD_CREATESOUNDEXINFO(
           (FMOD::CodecUser *const)codec,
           usermode,
           userexinfo);
}


// Address: 0x21d24d0 | Name: _ZN4FMOD9CodecUser13closeInternalEv
FMOD_RESULT_0 __fastcall FMOD::CodecUser::closeInternal(FMOD::CodecUser *const this)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d24e0 | Name: j__ZN4FMOD9CodecUser13closeInternalEv
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecUser::closeInternal(FMOD_CODEC_STATE *codec)
{
  return _ZN4FMOD9CodecUser13closeInternalEv((FMOD::CodecUser *const)codec);
}


// Address: 0x21d24f0 | Name: _ZN4FMOD9CodecUser12readInternalEPvjPj
FMOD_RESULT_0 __fastcall FMOD::CodecUser::readInternal(
        FMOD::CodecUser *const this,
        void *buffer,
        unsigned int samples_in,
        unsigned int *samples_out)
{
  *samples_out = samples_in;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d2500 | Name: j__ZN4FMOD9CodecUser12readInternalEPvjPj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecUser::readInternal(
        FMOD_CODEC_STATE *codec,
        void *buffer,
        unsigned int samples_in,
        unsigned int *samples_out)
{
  return _ZN4FMOD9CodecUser12readInternalEPvjPj((FMOD::CodecUser *const)codec, buffer, samples_in, samples_out);
}


// Address: 0x21d2510 | Name: _ZN4FMOD9CodecUser19setPositionInternalEijj
FMOD_RESULT_0 __fastcall FMOD::CodecUser::setPositionInternal(
        FMOD::CodecUser *const this,
        int subsound,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21d2520 | Name: j__ZN4FMOD9CodecUser19setPositionInternalEijj
// attributes: thunk
FMOD_RESULT_0 __fastcall FMOD::CodecUser::setPositionInternal(
        FMOD_CODEC_STATE *codec,
        int subsound,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  return _ZN4FMOD9CodecUser19setPositionInternalEijj((FMOD::CodecUser *const)codec, subsound, position, postype);
}


