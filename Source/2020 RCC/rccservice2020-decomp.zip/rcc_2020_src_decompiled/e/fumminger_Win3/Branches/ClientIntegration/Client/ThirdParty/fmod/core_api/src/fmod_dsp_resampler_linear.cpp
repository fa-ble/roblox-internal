// Address: 0x21e0ab0 | Name: FMOD_Resampler_Linear
void __fastcall FMOD_Resampler_Linear(
        float *out,
        int outlength,
        void *src,
        FMOD_SOUND_FORMAT_0 srcformat,
        FMOD_UINT64P *position,
        FMOD_SINT64P *speed,
        int channels)
{
  FMOD_UINT64 v8; // r10
  int v9; // ebp
  float *v10; // rax
  FMOD_SINT64 v11; // r8
  FMOD_SINT64 v12; // r12
  FMOD_UINT64 v13; // rcx
  FMOD_UINT64 v14; // r10
  __int64 v15; // r14
  float v16; // xmm4_4
  float v17; // xmm6_4
  float v18; // xmm2_4
  float v19; // xmm6_4
  float v20; // xmm4_4
  float v21; // xmm5_4
  float v22; // xmm7_4
  float v23; // xmm2_4
  int v24; // r11d
  __int64 v25; // r14
  float v26; // xmm5_4
  float v27; // xmm7_4
  float v28; // xmm4_4
  float v29; // xmm2_4
  FMOD_UINT64 v30; // r11
  float v31; // xmm4_4
  float v32; // xmm8_4
  float v33; // xmm2_4
  float v34; // xmm7_4
  int v35; // esi
  FMOD_SINT64 v36; // r9
  FMOD_UINT64 v37; // rax
  FMOD_SINT64 v38; // rbp
  FMOD_UINT64 v39; // r11
  float v40; // xmm2_4
  float *v41; // rcx
  unsigned int v42; // eax
  unsigned int v43; // r9d
  float v44; // xmm0_4
  __int64 v45; // r8
  FMOD_SINT64 mValue; // rbp
  FMOD_UINT64 v47; // r11
  float v48; // xmm4_4
  float *v49; // rcx
  unsigned int v50; // eax
  unsigned int v51; // r9d
  float v52; // xmm0_4
  __int64 v53; // r8
  FMOD_SINT64 v54; // rbp
  FMOD_UINT64 v55; // r11
  float v56; // xmm4_4
  float *v57; // rcx
  unsigned int v58; // eax
  unsigned int v59; // r9d
  float v60; // xmm0_4
  __int64 v61; // r8
  FMOD_SINT64 v62; // r13
  FMOD_UINT64 v63; // r12
  float v64; // xmm4_4
  float *v65; // r8
  unsigned int v66; // r9d
  unsigned int v67; // ebp
  __int64 v68; // r11
  __int64 v69; // rax
  FMOD_SINT64 v70; // rbp
  FMOD_UINT64 v71; // r11
  float v72; // xmm4_4
  float *v73; // rcx
  unsigned int v74; // eax
  unsigned int v75; // r9d
  __int64 v76; // r8
  float v77; // xmm0_4
  void (*FMOD_Resampler_Linear_PCM8_Mono)(float *, int, void *, FMOD_UINT64P *, FMOD_SINT64P *); // rax
  FMOD_SINT64 v79; // r11
  FMOD_UINT64 v80; // r10
  __int64 mHi; // rcx

  switch ( srcformat )
  {
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
      if ( channels == 1 )
      {
        FMOD_Resampler_Linear_PCM8_Mono = FMOD_Optimised_Routines.FMOD_Resampler_Linear_PCM8_Mono;
        goto LABEL_59;
      }
      if ( channels == 2 )
      {
        FMOD_Resampler_Linear_PCM8_Mono = FMOD_Optimised_Routines.FMOD_Resampler_Linear_PCM8_Stereo;
        goto LABEL_59;
      }
      if ( outlength )
      {
        mValue = speed->mValue;
        v47 = position->mValue + speed->mValue;
        do
        {
          v48 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v49 = out;
            v50 = channels * position->mHi;
            v51 = channels + v50;
            do
            {
              ++v49;
              v52 = (float)*((char *)src + v50);
              v53 = channels + v50++;
              *(v49 - 1) = (float)((float)(v52 * 0.0078125) * (float)(1.0 - v48))
                         + (float)((float)((float)*((char *)src + v53) * 0.0078125) * v48);
            }
            while ( v50 != v51 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v47;
          v47 += mValue;
          --outlength;
        }
        while ( outlength );
      }
      return;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
      if ( channels == 1 )
      {
        FMOD_Resampler_Linear_PCM8_Mono = FMOD_Optimised_Routines.FMOD_Resampler_Linear_PCM16_Mono;
        goto LABEL_59;
      }
      if ( channels == 2 )
      {
        FMOD_Resampler_Linear_PCM8_Mono = FMOD_Optimised_Routines.FMOD_Resampler_Linear_PCM16_Stereo;
        goto LABEL_59;
      }
      if ( outlength )
      {
        v54 = speed->mValue;
        v55 = position->mValue + speed->mValue;
        do
        {
          v56 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v57 = out;
            v58 = channels * position->mHi;
            v59 = channels + v58;
            do
            {
              ++v57;
              v60 = (float)*((__int16 *)src + v58);
              v61 = channels + v58++;
              *(v57 - 1) = (float)((float)(v60 * 0.000030517578) * (float)(1.0 - v56))
                         + (float)((float)((float)*((__int16 *)src + v61) * 0.000030517578) * v56);
            }
            while ( v58 != v59 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v55;
          v55 += v54;
          --outlength;
        }
        while ( outlength );
      }
      return;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
      if ( channels == 1 )
      {
        if ( outlength )
        {
          v79 = speed->mValue;
          v80 = position->mValue + speed->mValue;
          do
          {
            ++out;
            mHi = position->mHi;
            *(out - 1) = (float)((float)(1.0 - (float)((float)(int)position->mLo * 2.3283064e-10))
                               * (float)((float)(((*((unsigned __int8 *)src + 3 * mHi + 2) << 24)
                                                | (*((unsigned __int8 *)src + 3 * mHi) << 8)
                                                | (*((unsigned __int8 *)src + 3 * mHi + 1) << 16)) >> 8)
                                       * 0.00000011920929))
                       + (float)((float)((float)(((*((unsigned __int8 *)src + 3 * (unsigned int)(mHi + 1) + 2) << 24)
                                                | (*((unsigned __int8 *)src + 3 * (unsigned int)(mHi + 1)) << 8)
                                                | (*((unsigned __int8 *)src + 3 * (unsigned int)(mHi + 1) + 1) << 16)) >> 8)
                                       * 0.00000011920929)
                               * (float)((float)(int)position->mLo * 2.3283064e-10));
            position->mValue = v80;
            v80 += v79;
            --outlength;
          }
          while ( outlength );
        }
      }
      else if ( outlength )
      {
        v62 = speed->mValue;
        v63 = position->mValue + speed->mValue;
        do
        {
          v64 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v65 = out;
            v66 = channels * position->mHi;
            v67 = channels + v66;
            do
            {
              ++v65;
              v68 = 3LL * v66;
              v69 = channels + v66++;
              *(v65 - 1) = (float)((float)((float)(((*((unsigned __int8 *)src + v68 + 2) << 24)
                                                  | (*((unsigned __int8 *)src + v68) << 8)
                                                  | (*((unsigned __int8 *)src + v68 + 1) << 16)) >> 8)
                                         * 0.00000011920929)
                                 * (float)(1.0 - v64))
                         + (float)((float)((float)(((*((unsigned __int8 *)src + 3 * v69 + 2) << 24)
                                                  | (*((unsigned __int8 *)src + 3 * v69) << 8)
                                                  | (*((unsigned __int8 *)src + 3 * v69 + 1) << 16)) >> 8)
                                         * 0.00000011920929)
                                 * v64);
            }
            while ( v66 != v67 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v63;
          v63 += v62;
          --outlength;
        }
        while ( outlength );
      }
      return;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      if ( channels == 1 )
      {
        if ( outlength >> 2 )
        {
          v8 = position->mValue;
          v9 = outlength >> 2;
          v10 = out;
          v11 = 2 * speed->mValue;
          v12 = 4 * speed->mValue;
          v13 = v8 + speed->mValue;
          do
          {
            v14 = v11 + v8;
            v10 += 4;
            v15 = position->mHi;
            v16 = (float)(int)position->mLo * 2.3283064e-10;
            v17 = (float)(1.0 - v16) * (float)((float)*((int *)src + v15) * 4.6566129e-10);
            v18 = (float)*((int *)src + (unsigned int)(v15 + 1));
            position->mValue = v13;
            v19 = v17 + (float)((float)(v18 * 4.6566129e-10) * v16);
            v20 = (float)(int)v13 * 2.3283064e-10;
            v21 = (float)(1.0 - v20) * (float)((float)*((int *)src + HIDWORD(v13)) * 4.6566129e-10);
            v22 = (float)(int)v14;
            v23 = (float)*((int *)src + (unsigned int)(HIDWORD(v13) + 1)) * 4.6566129e-10;
            position->mValue = v14;
            v24 = HIDWORD(v14);
            v25 = HIDWORD(v14);
            v8 = v11 + v14;
            v26 = v21 + (float)(v23 * v20);
            v27 = v22 * 2.3283064e-10;
            v28 = (float)(1.0 - v27) * (float)((float)*((int *)src + v25) * 4.6566129e-10);
            v29 = (float)*((int *)src + (unsigned int)(v24 + 1));
            v30 = v11 + v13;
            v13 += v12;
            position->mValue = v30;
            v31 = v28 + (float)((float)(v29 * 4.6566129e-10) * v27);
            v32 = (float)(int)v30 * 2.3283064e-10;
            v33 = (float)(1.0 - v32) * (float)((float)*((int *)src + HIDWORD(v30)) * 4.6566129e-10);
            v34 = (float)*((int *)src + (unsigned int)(HIDWORD(v30) + 1));
            position->mValue = v8;
            *(v10 - 4) = v19;
            *(v10 - 3) = v26;
            *(v10 - 2) = v31;
            *(v10 - 1) = v33 + (float)((float)(v34 * 4.6566129e-10) * v32);
            --v9;
          }
          while ( v9 );
          out += 4 * (unsigned int)((outlength >> 2) - 1) + 4;
        }
        v35 = outlength & 3;
        if ( v35 )
        {
          v36 = speed->mValue;
          v37 = position->mValue + v36;
          do
          {
            *out++ = (float)((float)(1.0 - (float)((float)(int)position->mLo * 2.3283064e-10))
                           * (float)((float)*((int *)src + position->mHi) * 4.6566129e-10))
                   + (float)((float)((float)*((int *)src + position->mHi + 1) * 4.6566129e-10)
                           * (float)((float)(int)position->mLo * 2.3283064e-10));
            position->mValue = v37;
            v37 += v36;
            --v35;
          }
          while ( v35 );
        }
      }
      else if ( outlength )
      {
        v70 = speed->mValue;
        v71 = position->mValue + speed->mValue;
        do
        {
          v72 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v73 = out;
            v74 = channels * position->mHi;
            v75 = channels + v74;
            do
            {
              ++v73;
              v76 = channels + v74;
              v77 = (float)*((int *)src + v74++) * 4.6566129e-10;
              *(v73 - 1) = (float)(v77 * (float)(1.0 - v72))
                         + (float)((float)((float)*((int *)src + v76) * 4.6566129e-10) * v72);
            }
            while ( v74 != v75 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v71;
          v71 += v70;
          --outlength;
        }
        while ( outlength );
      }
      return;
    case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
      if ( channels == 1 )
      {
        FMOD_Resampler_Linear_PCM8_Mono = FMOD_Optimised_Routines.FMOD_Resampler_Linear_Float_Mono;
LABEL_59:
        FMOD_Resampler_Linear_PCM8_Mono(out, outlength, src, position, speed);
        return;
      }
      if ( channels == 2 )
      {
        FMOD_Resampler_Linear_PCM8_Mono = FMOD_Optimised_Routines.FMOD_Resampler_Linear_Float_Stereo;
        goto LABEL_59;
      }
      if ( outlength )
      {
        v38 = speed->mValue;
        v39 = position->mValue + speed->mValue;
        do
        {
          v40 = (float)(int)position->mLo * 2.3283064e-10;
          if ( channels > 0 )
          {
            v41 = out;
            v42 = channels * position->mHi;
            v43 = channels + v42;
            do
            {
              ++v41;
              v44 = *((float *)src + v42);
              v45 = channels + v42++;
              *(v41 - 1) = (float)(v44 * (float)(1.0 - v40)) + (float)(*((float *)src + v45) * v40);
            }
            while ( v42 != v43 );
            out += (unsigned int)(channels - 1) + 1;
          }
          position->mValue = v39;
          v39 += v38;
          --outlength;
        }
        while ( outlength );
      }
      return;
    default:
      return;
  }
}


