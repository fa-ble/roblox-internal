// Address: 0x2238000 | Name: _ZN4FMOD6StreamC2Ev
void __fastcall FMOD::Stream::Stream(FMOD::Stream *const this)
{
  FMOD::SoundI::SoundI(this);
  this->mStreamNode.mNodeData = 0;
  this->mLastPos = 0;
  this->mSubSound = 0;
  this->mLoopCountCurrent = -1;
  this->mBlockSize = 1;
  this->mChannel = 0;
  this->mInitialPosition = 0;
  this->_vptr_SoundI = (int (**)(...))&off_29B27B0;
  this->mStreamNode.mNodePrev = &this->mStreamNode;
  this->mStreamNode.mNodeNext = &this->mStreamNode;
}


// Address: 0x2238080 | Name: _ZN4FMOD6Stream4fillEjjPj
FMOD_RESULT_0 __fastcall FMOD::Stream::fill(
        FMOD::Stream *const this,
        unsigned int offset,
        unsigned int length,
        unsigned int *read_out)
{
  FMOD::Sample *mSample; // r13
  FMOD::SoundI *mSubSoundParent; // rax
  unsigned int v8; // r15d
  unsigned int v9; // r14d
  FMOD_RESULT_0 v10; // eax
  FMOD::SoundI **mSubSound; // rdx
  FMOD::Stream *v12; // r12
  __int64 mSubSoundIndex; // rsi
  unsigned int lengthpcm; // r11d
  unsigned int v15; // r8d
  unsigned int mLength; // edi
  unsigned int mPosition; // esi
  unsigned int v18; // r9d
  int mChannels; // eax
  __int64 v20; // rdx
  unsigned int v21; // edx
  unsigned int v22; // esi
  FMOD_RESULT_0 v23; // ecx
  unsigned int v24; // esi
  unsigned int v25; // eax
  FMOD_RESULT_0 v26; // ebp
  unsigned int i; // edx
  unsigned int v28; // ebx
  unsigned int v29; // r12d
  int mLoopCountCurrent; // ecx
  bool v32; // zf
  unsigned int mLoopStart; // edx
  FMOD::Codec *mCodec; // rax
  FMOD::File *mFile; // rax
  volatile unsigned int mFlags; // ecx
  unsigned int v37; // eax
  FMOD::SoundI *v38; // rax
  unsigned int v40; // [rsp+10h] [rbp-A8h]
  unsigned int endpoint; // [rsp+14h] [rbp-A4h]
  unsigned int streamlength; // [rsp+18h] [rbp-A0h]
  FMOD::Atomic<unsigned int> *p_mFlags; // [rsp+28h] [rbp-90h]
  unsigned int r; // [rsp+3Ch] [rbp-7Ch] BYREF
  FMOD_CODEC_WAVEFORMAT waveformat; // [rsp+40h] [rbp-78h] BYREF

  mSample = this->mSample;
  if ( read_out )
    *read_out = 0;
  mSubSoundParent = this->mSubSoundParent;
  if ( mSubSoundParent )
    mSample = *(FMOD::Sample **)&mSubSoundParent[1].mMagic;
  p_mFlags = &this->mFlags;
  if ( (this->mFlags.m_value & 8) != 0 )
  {
    v9 = 0;
    v23 = FMOD_RESULT::FMOD_OK_0;
    goto LABEL_70;
  }
  v8 = length;
  v9 = 0;
  v10 = FMOD_RESULT::FMOD_OK_0;
  while ( 2 )
  {
    mSubSound = this->mSubSound;
    if ( mSubSound )
    {
      v12 = (FMOD::Stream *)mSubSound[this->mSubSoundIndex];
      if ( !v12 )
        goto LABEL_31;
    }
    else
    {
      v12 = this;
    }
    if ( this->mSubSoundShared )
    {
      mSubSoundIndex = (unsigned int)this->mSubSoundIndex;
      memset(&waveformat, 0, sizeof(waveformat));
      v12->mCodec->mDescription.getwaveformat(v12->mCodec, mSubSoundIndex, &waveformat);
      lengthpcm = waveformat.lengthpcm;
    }
    else
    {
      lengthpcm = v12->mLength;
    }
    if ( (this->mMode & 2) != 0 && this->mLoopCountCurrent )
    {
      v15 = v12->mLoopLength + v12->mLoopStart - 1;
    }
    else
    {
      v15 = lengthpcm - 1;
      if ( (mSample->mCodec->FMOD::SoundI::mFlags & 1) == 0 )
        v15 = -1;
    }
    mLength = mSample->mLength;
    mPosition = v12->mPosition;
    v18 = mLength - offset;
    if ( v8 + offset <= mLength )
      v18 = v8;
    if ( v15 < mPosition )
    {
      v18 = 0;
    }
    else if ( v15 < v18 + mPosition )
    {
      v18 = v15 - mPosition + 1;
    }
    mChannels = this->mChannels;
    switch ( this->mFormat )
    {
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM8_0:
        v20 = 8;
        goto LABEL_21;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM16_0:
        v20 = 16;
        goto LABEL_21;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM24_0:
        v20 = 24;
        goto LABEL_21;
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCM32_0:
      case FMOD_SOUND_FORMAT::FMOD_SOUND_FORMAT_PCMFLOAT_0:
        v20 = 32;
LABEL_21:
        v10 = (((unsigned __int64)v18 * v20) >> 3) * mChannels;
        if ( v10 == FMOD_RESULT::FMOD_OK_0 )
          goto LABEL_22;
        goto LABEL_45;
      default:
        v10 = v18 * mChannels;
        if ( v10 == FMOD_RESULT::FMOD_OK_0 )
        {
LABEL_22:
          r = 0;
          v21 = 0;
          LOBYTE(v10) = 16;
          goto LABEL_23;
        }
LABEL_45:
        streamlength = lengthpcm;
        endpoint = v15;
        v40 = v18;
        v10 = FMOD::SoundI::read(mSample, offset, v18, &r);
        v15 = endpoint;
        lengthpcm = streamlength;
        if ( (v10 & 0xFFFFFFEF) != 0 )
        {
          if ( v10 != FMOD_RESULT::FMOD_ERR_FILE_DISKEJECTED_0 )
            return v10;
          v21 = r;
LABEL_48:
          mLength = mSample->mLength;
          mPosition = v12->mPosition;
          goto LABEL_23;
        }
        v21 = r;
        if ( v10 || r )
          goto LABEL_48;
        if ( v40 )
        {
LABEL_31:
          v23 = v10;
          if ( v9 < length )
            goto LABEL_32;
          return v23;
        }
        mLength = mSample->mLength;
        mPosition = v12->mPosition;
        v21 = 0;
LABEL_23:
        offset += v21;
        v9 += v21;
        v8 -= v21;
        if ( offset >= mLength )
          offset = 0;
        v12->mLastPos = mPosition;
        v22 = v21 + mPosition;
        v12->mPosition = v22;
        if ( read_out )
        {
          *read_out = v9;
          v22 = v12->mPosition;
        }
        if ( v15 >= v22 && v10 != FMOD_RESULT::FMOD_ERR_FILE_EOF_0 )
        {
          if ( !v21 )
            goto LABEL_31;
          goto LABEL_30;
        }
        if ( (this->mMode & 2) != 0 )
        {
          mLoopCountCurrent = this->mLoopCountCurrent;
          if ( mLoopCountCurrent )
          {
            v32 = this->mLength == -1;
            mLoopStart = this->mLoopStart;
            v12->mPosition = mLoopStart;
            if ( !v32 )
            {
              mCodec = this->mCodec;
              if ( mCodec )
              {
                mFile = mCodec->mFile;
                if ( mFile )
                {
                  mFlags = mFile->mFlags;
                  BYTE1(mFlags) |= 0x10u;
                  mFile->mFlags = mFlags;
                }
              }
              v10 = FMOD::SoundI::seek(mSample, this->mSubSoundIndex, mLoopStart);
              if ( v10 )
                return v10;
              mLoopCountCurrent = this->mLoopCountCurrent;
              v12->mPosition = mSample->mPosition;
            }
            if ( mLoopCountCurrent > 0 )
              this->mLoopCountCurrent = mLoopCountCurrent - 1;
LABEL_30:
            if ( !v8 )
              goto LABEL_31;
            continue;
          }
        }
        v23 = v10;
        if ( v12 != this )
        {
          v37 = this->mLength;
          if ( v37 == -1 )
            this->mLength = this->mPosition;
          else
            this->mPosition = v37;
          _InterlockedOr((volatile signed __int32 *)p_mFlags, 8u);
        }
        if ( lengthpcm == -1 )
          v12->mLength = v12->mPosition;
        else
          v12->mPosition = lengthpcm;
        _InterlockedOr((volatile signed __int32 *)&v12->mFlags, 8u);
        v38 = v12->mSubSoundParent;
        if ( v38 )
          _InterlockedOr((volatile signed __int32 *)&v38->mFlags, 8u);
LABEL_70:
        if ( v9 < length )
        {
LABEL_32:
          v24 = offset;
          v25 = mSample->mLength;
          v26 = v23;
          for ( i = length - v9; ; i = v29 )
          {
            v28 = i + v24;
            v29 = 0;
            if ( i + v24 > v25 )
            {
              v28 = v25;
              v29 = i - (v25 - v24);
              i = v25 - v24;
            }
            FMOD::SoundI::clear(mSample, v24, i);
            v25 = mSample->mLength;
            v24 = 0;
            if ( v28 < v25 )
              v24 = v28;
            if ( !v29 )
              break;
          }
          return v26;
        }
        return v23;
    }
  }
}


// Address: 0x22384e0 | Name: _ZN4FMOD6Stream5flushEv
FMOD_RESULT_0 __fastcall FMOD::Stream::flush(FMOD::Stream *const this)
{
  FMOD::Sample *mSample; // rax
  unsigned int mLength; // ebp
  FMOD_RESULT_0 result; // eax
  FMOD::Sample *v5; // rdi
  unsigned int v6; // edx
  unsigned int v7; // eax

  mSample = this->mSample;
  if ( !mSample )
    goto LABEL_7;
  if ( (this->mMode & 0x400) != 0 )
  {
    mLength = mSample->mLength;
  }
  else
  {
    mLength = this->mLength;
    v7 = mSample->mLength;
    if ( mLength > v7 )
      mLength = v7;
  }
  result = FMOD::Stream::fill(this, 0, mLength, 0);
  if ( (result & 0xFFFFFFEF) == 0 )
  {
    v5 = this->mSample;
    v6 = v5->mLength;
    if ( mLength < v6 )
      FMOD::SoundI::clear(v5, mLength, v6 - mLength);
LABEL_7:
    _InterlockedAnd((volatile signed __int32 *)&this->mFlags, 0xFFFFFFEF);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x2238550 | Name: _ZN4FMOD6Stream11setPositionEjj
FMOD_RESULT_0 __fastcall FMOD::Stream::setPosition(
        FMOD::Stream *const this,
        unsigned int position,
        FMOD_TIMEUNIT postype)
{
  FMOD::Codec *mCodec; // rax
  FMOD::File *mFile; // rsi
  int v7; // edx
  FMOD::SoundI *mSubSoundParent; // rax
  FMOD::SoundI **mSubSound; // rax
  FMOD::Codec *v10; // r12
  unsigned __int8 *mPCMBuffer; // rdi
  void (__fastcall *reset)(FMOD::Codec *); // rax
  FMOD::SoundI *v13; // rax
  int mSubSoundIndex; // esi
  FMOD_RESULT_0 result; // eax
  FMOD_RESULT_0 v16; // r12d
  FMOD::SoundI *v17; // rax
  FMOD::Sample *mSample; // rax
  void (__fastcall *mPostSetPositionCallback)(_QWORD, _QWORD, _QWORD, _QWORD); // rax
  unsigned int v20; // eax
  unsigned int v21; // edx
  FMOD::Stream *v22; // rdi
  unsigned int positiona[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  mCodec = this->mCodec;
  positiona[0] = position;
  mFile = mCodec->mFile;
  if ( mFile && (mFile->mFlags & 0x2000) != 0 && positiona[0] )
  {
    mFile->mFlags |= 1u;
    if ( postype != 2 )
      goto LABEL_4;
  }
  else if ( postype != 2 )
  {
    goto LABEL_4;
  }
  if ( (this->mMode & 1) != 0 )
    v21 = this->mLength - 1;
  else
    v21 = this->mLoopLength + this->mLoopStart - 1;
  result = FMOD_RESULT::FMOD_ERR_INVALID_POSITION_0;
  if ( v21 < positiona[0] )
    return result;
LABEL_4:
  if ( mFile )
    v7 = mFile->mFlags & 1;
  else
    LOBYTE(v7) = 1;
  _InterlockedAnd((volatile signed __int32 *)&this->mFlags, 0xFFFFFFB7);
  mSubSoundParent = this->mSubSoundParent;
  if ( mSubSoundParent )
    _InterlockedAnd((volatile signed __int32 *)&mSubSoundParent->mFlags, 0xFFFFFFB7);
  if ( (_BYTE)v7 )
  {
    mSubSound = this->mSubSound;
    if ( mSubSound && postype == 2 )
    {
      v22 = (FMOD::Stream *)mSubSound[this->mSubSoundIndex];
      if ( v22 )
      {
        v16 = FMOD::Stream::setPosition(v22, positiona[0], 2u);
        goto LABEL_21;
      }
LABEL_46:
      v16 = FMOD_RESULT::FMOD_OK_0;
LABEL_21:
      mSample = this->mSample;
      if ( mSample )
      {
        mPostSetPositionCallback = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))mSample->mPostSetPositionCallback;
        if ( mPostSetPositionCallback )
          mPostSetPositionCallback(this->mPostCallbackSound, (unsigned int)this->mSubSoundIndex, positiona[0], postype);
      }
      if ( postype - 1 <= 1 || postype == 4 )
      {
        v20 = positiona[0];
      }
      else
      {
        v16 = FMOD::Codec::getPosition(this->mCodec, positiona, 2u);
        v20 = 0;
        if ( v16 == FMOD_RESULT::FMOD_OK_0 )
          v20 = positiona[0];
      }
      this->mPosition = v20;
      this->mLastPos = v20;
      return v16;
    }
    v10 = this->mCodec;
    mPCMBuffer = v10->mPCMBuffer;
    v10->mPCMBufferOffset = 0;
    if ( mPCMBuffer )
      memset(mPCMBuffer, 0, v10->mPCMBufferLengthBytes);
    reset = (void (__fastcall *)(FMOD::Codec *))v10->mDescription.reset;
    if ( reset )
      reset(v10);
    v13 = this->mSubSoundParent;
    if ( v13 && v13->mNumSubSounds || (mSubSoundIndex = 0, this->mNumSubSounds) )
      mSubSoundIndex = this->mSubSoundIndex;
    result = FMOD::Codec::setPosition(this->mCodec, mSubSoundIndex, positiona[0], postype);
    v16 = result;
    if ( result == FMOD_RESULT::FMOD_OK_0 )
    {
      v17 = this->mSubSoundParent;
      if ( v17 )
      {
        v17->mSubSoundIndex = this->mSubSoundIndex;
        goto LABEL_21;
      }
      goto LABEL_46;
    }
  }
  else
  {
    result = FMOD_RESULT::FMOD_ERR_FILE_COULDNOTSEEK_0;
    if ( !this->mLastPos )
      return positiona[0] != 0 ? 0xE : 0;
  }
  return result;
}


