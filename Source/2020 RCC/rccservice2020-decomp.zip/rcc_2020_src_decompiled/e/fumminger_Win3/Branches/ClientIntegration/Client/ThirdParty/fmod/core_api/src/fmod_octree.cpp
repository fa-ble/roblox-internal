// Address: 0x22345c0 | Name: _ZN4FMOD7aabbAddERNS_9FMOD_AABBES1_S1_
void __fastcall FMOD::aabbAdd(FMOD::FMOD_AABB *const a, FMOD::FMOD_AABB *const b, FMOD::FMOD_AABB *const dst)
{
  dst->xMin = fminf(a->xMin, b->xMin);
  dst->xMax = fmaxf(a->xMax, b->xMax);
  dst->yMin = fminf(a->yMin, b->yMin);
  dst->yMax = fmaxf(a->yMax, b->yMax);
  dst->zMin = fminf(a->zMin, b->zMin);
  dst->zMax = fmaxf(a->zMax, b->zMax);
}


// Address: 0x2234620 | Name: _ZN4FMOD6OctreeC2Ef
void __fastcall FMOD::Octree::Octree(FMOD::Octree *const this, float a2, float worldSize)
{
  this->mRoot = 0;
  this->mFreeList = 0;
  this->mScale = 1.0 / a2;
  this->mCenter.x = 0.0;
  this->mCenter.y = 0.0;
  this->mCenter.z = 0.0;
}


// Address: 0x2234660 | Name: _ZN4FMOD6OctreeD2Ev
void __fastcall FMOD::Octree::~Octree(FMOD::Octree *const this)
{
  ;
}


// Address: 0x2234670 | Name: _ZN4FMOD6Octree7getAABBEPNS_9FMOD_AABBE
void __fastcall FMOD::Octree::getAABB(FMOD::Octree *const this, FMOD::FMOD_AABB *aabb)
{
  FMOD::OctreeNode *mRoot; // rax
  FMOD::OctreeNode *nextItem; // rbx

  mRoot = this->mRoot;
  if ( this->mRoot )
  {
    nextItem = mRoot->nextItem;
    for ( *aabb = mRoot->aabb; nextItem; nextItem = nextItem->nextItem )
      FMOD::aabbAdd(&nextItem->aabb, aabb, aabb);
  }
  else
  {
    aabb->xMin = 0.0;
    aabb->xMax = 0.0;
    aabb->yMin = 0.0;
    aabb->yMax = 0.0;
    aabb->zMin = 0.0;
    aabb->zMax = 0.0;
  }
}


// Address: 0x22346f0 | Name: _ZN4FMOD6Octree10setMaxSizeEf
void __fastcall FMOD::Octree::setMaxSize(FMOD::Octree *const this, float a2, float maxSize)
{
  this->mScale = 1.0 / a2;
}


// Address: 0x2234710 | Name: _ZN4FMOD6Octree13addToFreeListEPNS_10OctreeNodeE
void __fastcall FMOD::Octree::addToFreeList(FMOD::Octree *const this, FMOD::OctreeNode *item)
{
  FMOD::OctreeNode *mFreeList; // rax

  mFreeList = this->mFreeList;
  item->nextItem = mFreeList;
  this->mFreeList = item;
  if ( mFreeList )
    mFreeList->parent = item;
  item->parent = 0;
  item->flags |= 0x20u;
}


// Address: 0x2234740 | Name: _ZN4FMOD6Octree15addInternalNodeEPNS_10OctreeNodeE
void __fastcall FMOD::Octree::addInternalNode(FMOD::Octree *const this, FMOD::OctreeNode *item)
{
  int flags; // eax

  flags = item->flags;
  if ( (flags & 0x400) == 0 )
  {
    BYTE1(flags) |= 4u;
    item->flags = flags;
    FMOD::Octree::addToFreeList(this, item);
  }
}


// Address: 0x2234760 | Name: _ZN4FMOD6Octree11getFreeNodeEv
FMOD::OctreeNode *__fastcall FMOD::Octree::getFreeNode(FMOD::Octree *const this)
{
  FMOD::OctreeNode *result; // rax
  FMOD::OctreeNode *nextItem; // rdx

  result = this->mFreeList;
  nextItem = result->nextItem;
  this->mFreeList = nextItem;
  if ( nextItem )
    nextItem->parent = 0;
  result->nextItem = 0;
  result->flags &= ~0x20u;
  return result;
}


// Address: 0x2234790 | Name: _ZN4FMOD6Octree18removeInternalNodeEPNS_10OctreeNodeE
void __fastcall FMOD::Octree::removeInternalNode(FMOD::Octree *const this, FMOD::OctreeNode *item)
{
  int flags; // eax
  int v3; // edx
  FMOD::OctreeNode *parent; // rax
  FMOD::OctreeNode *nextItem; // rdx
  FMOD::OctreeNode *v6; // rdx
  FMOD::OctreeNode *v7; // rcx
  FMOD::OctreeNode *v8; // rdx
  FMOD::OctreeNode *hi; // rdx
  FMOD::OctreeNode *v10; // rax

  flags = item->flags;
  if ( (flags & 0x400) != 0 )
  {
    v3 = item->flags;
    BYTE1(v3) = BYTE1(flags) & 0xFB;
    item->flags = v3;
    if ( (flags & 0x20) != 0 )
    {
      parent = item->parent;
      if ( parent )
      {
        parent->nextItem = item->nextItem;
        nextItem = item->nextItem;
        if ( !nextItem )
          return;
        goto LABEL_5;
      }
      v10 = item->nextItem;
      this->mFreeList = v10;
      if ( v10 )
        v10->parent = 0;
    }
    else
    {
      parent = FMOD::Octree::getFreeNode(this);
      *(_QWORD *)&parent->aabb.xMin = *(_QWORD *)&item->aabb.xMin;
      *(_QWORD *)&parent->aabb.yMin = *(_QWORD *)&item->aabb.yMin;
      *(_QWORD *)&parent->aabb.zMin = *(_QWORD *)&item->aabb.zMin;
      *(_QWORD *)&parent->flags = *(_QWORD *)&item->flags;
      *(_QWORD *)parent->pos = *(_QWORD *)item->pos;
      *(_QWORD *)&parent->pos[2] = *(_QWORD *)&item->pos[2];
      v6 = item->parent;
      parent->parent = v6;
      parent->hi = item->hi;
      parent->lo = item->lo;
      v7 = item->nextItem;
      parent->flags |= 0x400u;
      parent->nextItem = v7;
      if ( v6 )
      {
        if ( v6->nextItem == item )
        {
          v6->nextItem = parent;
        }
        else if ( v6->hi == item )
        {
          v6->hi = parent;
        }
        else
        {
          v6->lo = parent;
        }
      }
      else
      {
        this->mRoot = parent;
      }
      v8 = parent->nextItem;
      if ( v8 )
        v8->parent = parent;
      hi = parent->hi;
      if ( hi )
        hi->parent = parent;
      nextItem = parent->lo;
      if ( nextItem )
LABEL_5:
        nextItem->parent = parent;
    }
  }
}


// Address: 0x22348c0 | Name: _ZN4FMOD6Octree11adjustAABBsEPNS_10OctreeNodeE
void __fastcall FMOD::Octree::adjustAABBs(FMOD::Octree *const this, FMOD::OctreeNode *node)
{
  FMOD::OctreeNode *i; // rbx
  FMOD::OctreeNode *j; // rbp
  FMOD::OctreeNode *hi; // rax
  FMOD::OctreeNode *k; // rbp
  FMOD::OctreeNode *lo; // rax
  FMOD::OctreeNode *nextItem; // rbp

  for ( i = node; i; i = i->parent )
  {
    while ( 1 )
    {
      if ( (i->flags & 4) == 0 )
      {
        FMOD::aabbAdd(&i->hi->aabb, &i->lo->aabb, &i->aabb);
        for ( j = i->nextItem; j; j = j->nextItem )
          FMOD::aabbAdd(&j->aabb, &i->aabb, &i->aabb);
        hi = i->hi;
        i->flags |= 8u;
        if ( (hi->flags & 4) != 0 )
        {
          for ( k = hi->nextItem; k; k = k->nextItem )
            FMOD::aabbAdd(&k->aabb, &i->aabb, &i->aabb);
        }
        lo = i->lo;
        if ( (lo->flags & 4) != 0 )
        {
          nextItem = lo->nextItem;
          if ( nextItem )
            break;
        }
      }
      i = i->parent;
      if ( !i )
        return;
    }
    do
    {
      FMOD::aabbAdd(&nextItem->aabb, &i->aabb, &i->aabb);
      nextItem = nextItem->nextItem;
    }
    while ( nextItem );
  }
}


// Address: 0x22349b0 | Name: _ZN4FMOD6Octree14removeListItemEPNS_10OctreeNodeE
void __fastcall FMOD::Octree::removeListItem(FMOD::Octree *const this, FMOD::OctreeNode *node)
{
  FMOD::OctreeNode *parent; // rdx
  FMOD::OctreeNode *nextItem; // rax

  parent = node->parent;
  if ( parent->nextItem == node )
  {
    parent->nextItem = node->nextItem;
    nextItem = node->nextItem;
LABEL_8:
    if ( !nextItem )
      goto LABEL_6;
    goto LABEL_5;
  }
  nextItem = node->nextItem;
  if ( parent->hi == node )
  {
    parent->hi = nextItem;
    if ( !nextItem )
      goto LABEL_6;
    nextItem->flags &= ~0x10u;
    goto LABEL_8;
  }
  parent->lo = nextItem;
  if ( nextItem )
  {
    nextItem->flags &= ~0x10u;
LABEL_5:
    nextItem->parent = parent;
  }
LABEL_6:
  node->parent = 0;
  node->nextItem = 0;
  node->flags &= ~0x10u;
}


// Address: 0x2234a20 | Name: _ZN4FMOD6Octree11addListItemEPNS_10OctreeNodeES2_
void __fastcall FMOD::Octree::addListItem(FMOD::Octree *const this, FMOD::OctreeNode *list, FMOD::OctreeNode *node)
{
  FMOD::OctreeNode *parent; // rax
  int v4; // ecx

  if ( (list->flags & 4) != 0 )
  {
LABEL_7:
    while ( list->splitLevel < node->splitLevel )
    {
      if ( !list->nextItem )
        goto LABEL_13;
      list = list->nextItem;
    }
    parent = list->parent;
    if ( parent )
    {
      if ( list == parent->nextItem )
      {
        v4 = list->flags & parent->flags;
        parent->nextItem = node;
        if ( (v4 & 4) != 0 )
          node->flags |= 0x10u;
      }
      else if ( list == parent->hi )
      {
        parent->hi = node;
      }
      else
      {
        parent->lo = node;
      }
    }
    else
    {
      this->mRoot = node;
    }
    node->parent = parent;
    node->nextItem = list;
    list->parent = node;
    list->flags |= 0x10u;
  }
  else
  {
    if ( list->nextItem )
    {
      list = list->nextItem;
      goto LABEL_7;
    }
LABEL_13:
    list->nextItem = node;
    node->parent = list;
    node->flags |= 0x10u;
  }
}


// Address: 0x2234ac0 | Name: _ZN4FMOD6Octree14insertInternalEPNS_10OctreeNodeES2_
void __fastcall FMOD::Octree::insertInternal(FMOD::Octree *const this, FMOD::OctreeNode *node, FMOD::OctreeNode *item)
{
  FMOD::OctreeNode *v4; // rbx
  int flags; // r8d
  int v6; // r10d
  __int64 v7; // rsi
  unsigned int v8; // r12d
  int v9; // r13d
  unsigned int v10; // ecx
  unsigned int v11; // edi
  unsigned int v12; // eax
  FMOD::OctreeNode *hi; // rax
  unsigned int splitLevel; // r14d
  __int64 v15; // rsi
  int v16; // r9d
  unsigned int v17; // ecx
  unsigned int v18; // edi
  unsigned int v19; // eax
  FMOD::OctreeNode *FreeNode; // rax
  FMOD::OctreeNode *v21; // r14
  FMOD::OctreeNode *v22; // rcx
  FMOD::OctreeNode *v23; // rsi
  FMOD::OctreeNode *parent; // rax
  int v25; // eax
  FMOD::OctreeNode *nextItem; // rdx
  FMOD::OctreeNode *v27; // rdx
  FMOD::OctreeNode *v28; // rsi
  FMOD::OctreeNode *v29; // rbx
  FMOD::OctreeNode *v30; // rsi
  FMOD::OctreeNode *v31; // r12
  unsigned int v32; // ecx
  int v33; // eax
  FMOD::OctreeNode *nexta; // [rsp+8h] [rbp-40h]

  v4 = node;
  flags = node->flags;
  v6 = flags & 4;
  if ( (flags & 4) == 0 )
    goto LABEL_14;
LABEL_2:
  v7 = 0;
  v8 = 0;
  v9 = 0;
  do
  {
    v10 = v4->pos[v7] ^ item->pos[v7];
    v11 = (v10 >> 1)
        | (v10 >> 2)
        | (((v10 >> 1) | (v10 >> 2)) >> 2)
        | (((v10 >> 1) | (v10 >> 2) | (((v10 >> 1) | (v10 >> 2)) >> 2)) >> 4)
        | (((v10 >> 1)
          | (v10 >> 2)
          | (((v10 >> 1) | (v10 >> 2)) >> 2)
          | (((v10 >> 1) | (v10 >> 2) | (((v10 >> 1) | (v10 >> 2)) >> 2)) >> 4)) >> 8);
    v12 = v10 & ~(v11 | HIWORD(v11));
    if ( v12 > v8 && item->splitLevel < v12 && v4->splitLevel < v12 )
    {
      v8 = v10
         & ~(v11
           | (((v10 >> 1)
             | ((v4->pos[v7] ^ item->pos[v7]) >> 2)
             | (((v10 >> 1) | ((v4->pos[v7] ^ item->pos[v7]) >> 2)) >> 2)
             | (((v10 >> 1)
               | ((v4->pos[v7] ^ item->pos[v7]) >> 2)
               | (((v10 >> 1) | ((v4->pos[v7] ^ item->pos[v7]) >> 2)) >> 2)) >> 4)
             | (((v10 >> 1)
               | ((v4->pos[v7] ^ item->pos[v7]) >> 2)
               | (((v10 >> 1) | ((v4->pos[v7] ^ item->pos[v7]) >> 2)) >> 2)
               | (((v10 >> 1)
                 | ((v4->pos[v7] ^ item->pos[v7]) >> 2)
                 | (((v10 >> 1) | ((v4->pos[v7] ^ item->pos[v7]) >> 2)) >> 2)) >> 4)) >> 8)) >> 16));
      v9 = v7;
    }
    ++v7;
  }
  while ( v7 != 3 );
  if ( v8 )
  {
LABEL_21:
    FreeNode = FMOD::Octree::getFreeNode(this);
    FreeNode->flags |= v9;
    v21 = FreeNode;
    FreeNode->splitLevel = v8;
    if ( (v8 & item->pos[v9]) != 0 )
    {
      FreeNode->lo = v4;
      FreeNode->hi = item;
      v22 = v4;
      v23 = item;
    }
    else
    {
      FreeNode->hi = v4;
      FreeNode->lo = item;
      v22 = item;
      v23 = v4;
    }
    FreeNode->parent = v4->parent;
    v23->parent = FreeNode;
    v22->parent = FreeNode;
    parent = FreeNode->parent;
    if ( parent )
    {
      if ( v4 == parent->lo )
        parent->lo = v21;
      else
        parent->hi = v21;
    }
    else
    {
      this->mRoot = v21;
    }
    if ( v9 )
    {
      v32 = v8 >> 1;
      v33 = -(v8 >> 1);
      if ( v9 != 1 )
      {
        v21->pos[0] = v32 | v33 & item->pos[0];
        v21->pos[1] = v32 | item->pos[1] & v33;
        v21->pos[2] = v8 | item->pos[2] & -v8;
LABEL_29:
        nextItem = v4->nextItem;
        v4->nextItem = 0;
        nexta = nextItem;
        FMOD::Octree::adjustAABBs(this, v21);
        v27 = nexta;
        if ( nexta )
        {
          while ( 1 )
          {
            v27->parent = 0;
            v28 = v21->parent;
            v27->flags &= ~0x10u;
            v29 = v27->nextItem;
            v27->nextItem = 0;
            if ( v28 )
            {
              FMOD::Octree::insertInternal(this, v28, v27);
              if ( !v29 )
                return;
            }
            else
            {
              FMOD::Octree::insertInternal(this, this->mRoot, v27);
              if ( !v29 )
                return;
            }
            v27 = v29;
          }
        }
        return;
      }
      v21->pos[0] = v32 | item->pos[0] & v33;
      v25 = -v8;
    }
    else
    {
      v25 = -v8;
      v21->pos[0] = v8 | -v8 & item->pos[0];
    }
    v21->pos[1] = v8 | v25 & item->pos[1];
    v21->pos[2] = v8 | item->pos[2] & v25;
    goto LABEL_29;
  }
  while ( 1 )
  {
    if ( item->splitLevel >= v4->splitLevel )
    {
      FMOD::Octree::addListItem(this, v4, item);
      v30 = v4;
      goto LABEL_41;
    }
    if ( v6 )
      break;
    hi = v4->hi;
    if ( item->pos[flags & 3] < v4->pos[flags & 3] )
      hi = v4->lo;
    v4 = hi;
    flags = hi->flags;
    v6 = flags & 4;
    if ( (flags & 4) != 0 )
      goto LABEL_2;
LABEL_14:
    splitLevel = v4->splitLevel;
    v15 = 0;
    v8 = 0;
    v9 = 0;
    v16 = -splitLevel;
    do
    {
      v17 = v16 & (v4->pos[v15] ^ item->pos[v15]);
      v18 = (v17 >> 1)
          | (v17 >> 2)
          | (((v17 >> 1) | (v17 >> 2)) >> 2)
          | (((v17 >> 1) | (v17 >> 2) | (((v17 >> 1) | (v17 >> 2)) >> 2)) >> 4)
          | (((v17 >> 1)
            | (v17 >> 2)
            | (((v17 >> 1) | (v17 >> 2)) >> 2)
            | (((v17 >> 1) | (v17 >> 2) | (((v17 >> 1) | (v17 >> 2)) >> 2)) >> 4)) >> 8);
      v19 = v17 & ~(v18 | HIWORD(v18));
      if ( v19 > v8 && item->splitLevel < v19 )
      {
        if ( v19 > splitLevel )
        {
          v8 = v17
             & ~(v18
               | (((v17 >> 1)
                 | ((v16 & (v4->pos[v15] ^ item->pos[v15])) >> 2)
                 | (((v17 >> 1) | ((v16 & (v4->pos[v15] ^ item->pos[v15])) >> 2)) >> 2)
                 | (((v17 >> 1)
                   | ((v16 & (v4->pos[v15] ^ item->pos[v15])) >> 2)
                   | (((v17 >> 1) | ((v16 & (v4->pos[v15] ^ item->pos[v15])) >> 2)) >> 2)) >> 4)
                 | (((v17 >> 1)
                   | ((v16 & (v4->pos[v15] ^ item->pos[v15])) >> 2)
                   | (((v17 >> 1) | ((v16 & (v4->pos[v15] ^ item->pos[v15])) >> 2)) >> 2)
                   | (((v17 >> 1)
                     | ((v16 & (v4->pos[v15] ^ item->pos[v15])) >> 2)
                     | (((v17 >> 1) | ((v16 & (v4->pos[v15] ^ item->pos[v15])) >> 2)) >> 2)) >> 4)) >> 8)) >> 16));
          v9 = v15;
        }
        else if ( v19 == splitLevel && (flags & 3) > (int)v15 )
        {
          v8 = v4->splitLevel;
          v9 = v15;
        }
      }
      ++v15;
    }
    while ( v15 != 3 );
    if ( v8 )
      goto LABEL_21;
  }
  v31 = v4->parent;
  FMOD::Octree::addListItem(this, v4, item);
  v30 = v31;
LABEL_41:
  FMOD::Octree::adjustAABBs(this, v30);
}


// Address: 0x2234e00 | Name: _ZN4FMOD6Octree10insertItemEPNS_10OctreeNodeE
void __fastcall FMOD::Octree::insertItem(FMOD::Octree *const this, FMOD::OctreeNode *item)
{
  int flags; // eax
  float xMax; // xmm9_4
  float yMax; // xmm8_4
  float yMin; // xmm1_4
  float zMin; // xmm0_4
  float mScale; // xmm5_4
  unsigned int v8; // ecx
  float v9; // xmm2_4
  float v10; // xmm1_4
  float v11; // xmm0_4

  flags = item->flags;
  if ( (flags & 0x40) == 0 )
  {
    xMax = item->aabb.xMax;
    yMax = item->aabb.yMax;
    item->flags = flags | 0x44;
    yMin = item->aabb.yMin;
    zMin = item->aabb.zMin;
    mScale = this->mScale;
    v8 = (int)(float)((float)(mScale * 1073741800.0)
                    * fmaxf(fmaxf(xMax - item->aabb.xMin, yMax - yMin), item->aabb.zMax - zMin));
    v9 = (float)((float)((float)((float)((float)(item->aabb.xMin + xMax) * 0.5) - this->mCenter.x) * mScale)
               * 1073741800.0)
       + 1073741800.0;
    v10 = (float)((float)((float)((float)((float)(yMin + yMax) * 0.5) - this->mCenter.y) * mScale) * 1073741800.0)
        + 1073741800.0;
    v11 = (float)((float)((float)((float)((float)(zMin + item->aabb.zMax) * 0.5) - this->mCenter.z) * mScale)
                * 1073741800.0)
        + 1073741800.0;
    item->splitLevel = v8
                     & ~((v8 >> 1)
                       | (v8 >> 2)
                       | (((v8 >> 1) | (v8 >> 2)) >> 2)
                       | (((v8 >> 1) | (v8 >> 2) | (((v8 >> 1) | (v8 >> 2)) >> 2)) >> 4)
                       | (((v8 >> 1)
                         | (v8 >> 2)
                         | (((v8 >> 1) | (v8 >> 2)) >> 2)
                         | (((v8 >> 1) | (v8 >> 2) | (((v8 >> 1) | (v8 >> 2)) >> 2)) >> 4)) >> 8)
                       | (((v8 >> 1)
                         | (v8 >> 2)
                         | (((v8 >> 1) | (v8 >> 2)) >> 2)
                         | (((v8 >> 1) | (v8 >> 2) | (((v8 >> 1) | (v8 >> 2)) >> 2)) >> 4)
                         | (((v8 >> 1)
                           | (v8 >> 2)
                           | (((v8 >> 1) | (v8 >> 2)) >> 2)
                           | (((v8 >> 1) | (v8 >> 2) | (((v8 >> 1) | (v8 >> 2)) >> 2)) >> 4)) >> 8)) >> 16));
    item->pos[0] = (int)v9;
    item->pos[1] = (int)v10;
    item->pos[2] = (int)v11;
    if ( this->mRoot )
      FMOD::Octree::insertInternal(this, this->mRoot, item);
    else
      this->mRoot = item;
  }
}


// Address: 0x2234f30 | Name: _ZN4FMOD6Octree10deleteItemEPNS_10OctreeNodeE
void __fastcall FMOD::Octree::deleteItem(FMOD::Octree *const this, FMOD::OctreeNode *item)
{
  int flags; // eax
  FMOD::OctreeNode *parent; // rbp
  FMOD::OctreeNode *nextItem; // rdx
  FMOD::OctreeNode *hi; // r13
  FMOD::OctreeNode *v7; // rax
  FMOD::OctreeNode *v8; // rdx
  FMOD::OctreeNode *v9; // rax
  FMOD::OctreeNode *v10; // rbx
  FMOD::OctreeNode *v11; // rsi

  flags = item->flags;
  if ( (flags & 0x40) != 0 )
  {
    parent = item->parent;
    if ( parent )
    {
      nextItem = parent->nextItem;
      if ( nextItem == item )
      {
        parent->nextItem = item->nextItem;
        v7 = item->nextItem;
        if ( v7 )
          goto LABEL_7;
      }
      else
      {
        hi = parent->hi;
        v7 = item->nextItem;
        if ( hi == item )
        {
          parent->hi = v7;
          if ( v7 )
            goto LABEL_6;
          hi = parent->lo;
        }
        else
        {
          parent->lo = v7;
          if ( v7 )
          {
LABEL_6:
            v7->flags &= ~0x10u;
LABEL_7:
            v7->parent = parent;
            parent = item->parent;
            goto LABEL_8;
          }
        }
        if ( hi )
        {
          v9 = parent->parent;
          if ( v9 )
          {
            if ( parent == v9->hi )
              v9->hi = hi;
            else
              v9->lo = hi;
            hi->parent = v9;
            hi = parent->parent;
          }
          else
          {
            this->mRoot = hi;
            hi->parent = 0;
          }
          if ( nextItem )
          {
            while ( 1 )
            {
              nextItem->flags &= ~0x10u;
              v10 = nextItem->nextItem;
              nextItem->nextItem = 0;
              nextItem->parent = 0;
              FMOD::Octree::insertInternal(this, hi, nextItem);
              if ( !v10 )
                break;
              nextItem = v10;
            }
          }
          v11 = parent->parent;
          if ( v11 )
            FMOD::Octree::adjustAABBs(this, v11);
          parent->flags &= 0xFFFFFFF4;
          parent->parent = 0;
          parent->hi = 0;
          parent->lo = 0;
          parent->nextItem = 0;
          FMOD::Octree::addToFreeList(this, parent);
          goto LABEL_10;
        }
      }
LABEL_8:
      if ( (parent->flags & 4) == 0 )
        FMOD::Octree::adjustAABBs(this, parent);
LABEL_10:
      item->flags &= 0xFFFFFFA0;
      item->parent = 0;
      item->nextItem = 0;
      return;
    }
    v8 = item->nextItem;
    this->mRoot = v8;
    if ( v8 )
    {
      v8->flags &= ~0x10u;
      v8->parent = 0;
      flags = item->flags;
    }
    item->nextItem = 0;
    item->flags = flags & 0xFFFFFFA0;
  }
}


// Address: 0x22350f0 | Name: _ZN4FMOD6Octree10updateItemEPNS_10OctreeNodeE
void __fastcall FMOD::Octree::updateItem(FMOD::Octree *const this, FMOD::OctreeNode *item)
{
  float xMax; // xmm5_4
  float yMax; // xmm7_4
  float xMin; // xmm4_4
  float yMin; // xmm6_4
  float zMax; // xmm9_4
  float zMin; // xmm8_4
  unsigned int splitLevel; // esi
  float mScale; // xmm3_4
  unsigned int v11; // ecx
  int v12; // esi

  if ( (item->flags & 0x40) == 0 )
    goto LABEL_4;
  xMax = item->aabb.xMax;
  yMax = item->aabb.yMax;
  xMin = item->aabb.xMin;
  yMin = item->aabb.yMin;
  zMax = item->aabb.zMax;
  zMin = item->aabb.zMin;
  splitLevel = item->splitLevel;
  mScale = this->mScale;
  v11 = (int)(float)((float)(mScale * 1073741800.0) * fmaxf(fmaxf(xMax - xMin, yMax - yMin), zMax - zMin));
  if ( splitLevel != (v11
                    & ~((v11 >> 1)
                      | (v11 >> 2)
                      | (((v11 >> 1) | (v11 >> 2)) >> 2)
                      | (((v11 >> 1) | (v11 >> 2) | (((v11 >> 1) | (v11 >> 2)) >> 2)) >> 4)
                      | (((v11 >> 1)
                        | (v11 >> 2)
                        | (((v11 >> 1) | (v11 >> 2)) >> 2)
                        | (((v11 >> 1) | (v11 >> 2) | (((v11 >> 1) | (v11 >> 2)) >> 2)) >> 4)) >> 8)
                      | (((v11 >> 1)
                        | (v11 >> 2)
                        | (((v11 >> 1) | (v11 >> 2)) >> 2)
                        | (((v11 >> 1) | (v11 >> 2) | (((v11 >> 1) | (v11 >> 2)) >> 2)) >> 4)
                        | (((v11 >> 1)
                          | (v11 >> 2)
                          | (((v11 >> 1) | (v11 >> 2)) >> 2)
                          | (((v11 >> 1) | (v11 >> 2) | (((v11 >> 1) | (v11 >> 2)) >> 2)) >> 4)) >> 8)) >> 16)))
    || (v12 = -splitLevel,
        (v12
       & (item->pos[0]
        ^ (int)(float)((float)((float)((float)((float)((float)(xMax + xMin) * 0.5) - this->mCenter.x) * mScale)
                             * 1073741800.0)
                     + 1073741800.0))) != 0)
    || (v12
      & (item->pos[1]
       ^ (int)(float)((float)((float)((float)((float)((float)(yMax + yMin) * 0.5) - this->mCenter.y) * mScale)
                            * 1073741800.0)
                    + 1073741800.0))) != 0
    || (v12
      & (item->pos[2]
       ^ (int)(float)((float)((float)((float)((float)((float)(zMin + zMax) * 0.5) - this->mCenter.z) * mScale)
                            * 1073741800.0)
                    + 1073741800.0))) != 0 )
  {
    FMOD::Octree::deleteItem(this, item);
LABEL_4:
    FMOD::Octree::insertItem(this, item);
    return;
  }
  FMOD::Octree::adjustAABBs(this, item);
}


// Address: 0x2235260 | Name: _ZN4FMOD6Octree8testLineEPNS_10OctreeNodeE11FMOD_VECTORS3_PNS0_13RecursionDataE
void __fastcall FMOD::Octree::testLine(
        FMOD::OctreeNode *node,
        FMOD_VECTOR a,
        FMOD_VECTOR b,
        FMOD::Octree::RecursionData *recursionData)
{
  FMOD::OctreeNode *nextItem; // rbx
  float v6; // xmm1_4
  float v7; // xmm4_4
  float v8; // xmm1_4
  float xMax; // xmm1_4
  float v10; // xmm0_4
  float v11; // xmm1_4
  float v12; // xmm1_4
  float yMin; // xmm0_4
  float v14; // xmm1_4
  float v15; // xmm5_4
  float v16; // xmm1_4
  float yMax; // xmm1_4
  float v18; // xmm0_4
  float v19; // xmm1_4
  float v20; // xmm1_4
  float zMin; // xmm0_4
  float v22; // xmm1_4
  float v23; // xmm6_4
  float v24; // xmm1_4
  float zMax; // xmm1_4
  float v26; // xmm0_4
  float v27; // xmm1_4
  float v28; // xmm1_4
  FMOD::OctreeNode *hi; // rdi
  float v30; // xmm0_4
  float v31; // xmm0_4
  float v32; // xmm0_4
  float v33; // xmm0_4
  float v34; // xmm0_4
  float v35; // xmm0_4

  while ( 1 )
  {
    nextItem = node->nextItem;
    if ( nextItem )
    {
      while ( recursionData->octreeLineTestCallback(nextItem, recursionData->data) )
      {
        nextItem = nextItem->nextItem;
        if ( !nextItem )
          goto LABEL_7;
      }
      goto LABEL_5;
    }
LABEL_7:
    v6 = a.x - node->aabb.xMin;
    v7 = b.x - node->aabb.xMin;
    if ( v7 <= 0.0 || v6 >= 0.0 )
    {
      if ( v7 < 0.0 )
      {
        if ( v6 <= 0.0 )
        {
          if ( v6 < 0.0 )
            return;
        }
        else
        {
          v30 = v7 / (float)(v7 - v6);
          b.x = (float)((float)(a.x - b.x) * v30) + b.x;
          b.y = (float)((float)(a.y - b.y) * v30) + b.y;
          b.z = (float)((float)(a.z - b.z) * v30) + b.z;
        }
      }
    }
    else
    {
      v8 = v6 / (float)(v6 - v7);
      a.x = (float)((float)(b.x - a.x) * v8) + a.x;
      a.y = (float)((float)(b.y - a.y) * v8) + a.y;
      a.z = (float)((float)(b.z - a.z) * v8) + a.z;
    }
    xMax = node->aabb.xMax;
    v10 = xMax - b.x;
    v11 = xMax - a.x;
    if ( v10 <= 0.0 || v11 >= 0.0 )
    {
      if ( v10 < 0.0 )
      {
        if ( v11 <= 0.0 )
        {
          if ( v11 < 0.0 )
            return;
        }
        else
        {
          v31 = v10 / (float)(v10 - v11);
          b.x = (float)((float)(a.x - b.x) * v31) + b.x;
          b.y = (float)((float)(a.y - b.y) * v31) + b.y;
          b.z = (float)((float)(a.z - b.z) * v31) + b.z;
        }
      }
    }
    else
    {
      v12 = v11 / (float)(v11 - v10);
      a.x = (float)((float)(b.x - a.x) * v12) + a.x;
      a.y = (float)((float)(b.y - a.y) * v12) + a.y;
      a.z = (float)((float)(b.z - a.z) * v12) + a.z;
    }
    yMin = node->aabb.yMin;
    v14 = a.y - yMin;
    v15 = b.y - yMin;
    if ( (float)(b.y - yMin) <= 0.0 || (float)(a.y - yMin) >= 0.0 )
    {
      if ( v15 < 0.0 )
      {
        if ( v14 <= 0.0 )
        {
          if ( (float)(a.y - yMin) < 0.0 )
            return;
        }
        else
        {
          v32 = v15 / (float)(v15 - v14);
          b.x = (float)((float)(a.x - b.x) * v32) + b.x;
          b.y = (float)((float)(a.y - b.y) * v32) + b.y;
          b.z = (float)((float)(a.z - b.z) * v32) + b.z;
        }
      }
    }
    else
    {
      v16 = v14 / (float)(v14 - v15);
      a.x = (float)((float)(b.x - a.x) * v16) + a.x;
      a.y = (float)((float)(b.y - a.y) * v16) + a.y;
      a.z = (float)((float)(b.z - a.z) * v16) + a.z;
    }
    yMax = node->aabb.yMax;
    v18 = yMax - b.y;
    v19 = yMax - a.y;
    if ( v18 <= 0.0 || v19 >= 0.0 )
    {
      if ( v18 < 0.0 )
      {
        if ( v19 <= 0.0 )
        {
          if ( v19 < 0.0 )
            return;
        }
        else
        {
          v33 = v18 / (float)(v18 - v19);
          b.x = (float)((float)(a.x - b.x) * v33) + b.x;
          b.y = (float)((float)(a.y - b.y) * v33) + b.y;
          b.z = (float)((float)(a.z - b.z) * v33) + b.z;
        }
      }
    }
    else
    {
      v20 = v19 / (float)(v19 - v18);
      a.x = (float)((float)(b.x - a.x) * v20) + a.x;
      a.y = (float)((float)(b.y - a.y) * v20) + a.y;
      a.z = (float)((float)(b.z - a.z) * v20) + a.z;
    }
    zMin = node->aabb.zMin;
    v22 = a.z - zMin;
    v23 = b.z - zMin;
    if ( (float)(b.z - zMin) <= 0.0 || (float)(a.z - zMin) >= 0.0 )
    {
      if ( v23 < 0.0 )
      {
        if ( v22 <= 0.0 )
        {
          if ( (float)(a.z - zMin) < 0.0 )
            return;
        }
        else
        {
          v34 = v23 / (float)(v23 - v22);
          b.x = (float)((float)(a.x - b.x) * v34) + b.x;
          b.y = (float)((float)(a.y - b.y) * v34) + b.y;
          b.z = (float)((float)(a.z - b.z) * v34) + b.z;
        }
      }
    }
    else
    {
      v24 = v22 / (float)(v22 - v23);
      a.x = (float)((float)(b.x - a.x) * v24) + a.x;
      a.y = (float)((float)(b.y - a.y) * v24) + a.y;
      a.z = (float)((float)(b.z - a.z) * v24) + a.z;
    }
    zMax = node->aabb.zMax;
    v26 = zMax - b.z;
    v27 = zMax - a.z;
    if ( v26 <= 0.0 || v27 >= 0.0 )
    {
      if ( v26 < 0.0 )
      {
        if ( v27 <= 0.0 )
        {
          if ( v27 < 0.0 )
            return;
        }
        else
        {
          v35 = v26 / (float)(v26 - v27);
          b.x = (float)((float)(a.x - b.x) * v35) + b.x;
          b.y = (float)((float)(a.y - b.y) * v35) + b.y;
          b.z = (float)((float)(a.z - b.z) * v35) + b.z;
        }
      }
    }
    else
    {
      v28 = v27 / (float)(v27 - v26);
      a.x = (float)((float)(b.x - a.x) * v28) + a.x;
      a.y = (float)((float)(b.y - a.y) * v28) + a.y;
      a.z = (float)((float)(b.z - a.z) * v28) + a.z;
    }
    if ( (node->flags & 4) != 0 )
      break;
    hi = node->hi;
    if ( !hi || (FMOD::Octree::testLine(hi, a, b, recursionData), !recursionData->exit) )
    {
      node = node->lo;
      if ( node )
        continue;
    }
    return;
  }
  if ( !recursionData->octreeLineTestCallback(node, recursionData->data) )
LABEL_5:
    recursionData->exit = 1;
}


// Address: 0x2235aa0 | Name: _ZN4FMOD6Octree8testLineEPFbPNS_10OctreeNodeEPvES3_RK11FMOD_VECTORS8_
bool __fastcall FMOD::Octree::testLine(
        FMOD::Octree *const this,
        bool (*octreeLineTestCallback)(FMOD::OctreeNode *, void *),
        void *data,
        const FMOD_VECTOR *const a,
        const FMOD_VECTOR *const b)
{
  FMOD::OctreeNode *mRoot; // rdi
  bool result; // al
  FMOD::Octree::RecursionData recursionData; // [rsp+0h] [rbp-28h] BYREF
  FMOD_VECTOR v8; // 0:xmm0_8.8,8:xmm1_4.4
  FMOD_VECTOR v9; // 0:xmm2_8.8,8:xmm3_4.4

  mRoot = this->mRoot;
  result = 1;
  if ( mRoot )
  {
    recursionData.octreeLineTestCallback = octreeLineTestCallback;
    *(_QWORD *)&v8.x = *(_QWORD *)&a->x;
    v9 = *b;
    recursionData.data = data;
    v8.z = a->z;
    recursionData.exit = 0;
    FMOD::Octree::testLine(mRoot, v8, v9, &recursionData);
    return !recursionData.exit;
  }
  return result;
}


