// Address: 0x21e3850 | Name: _ZN4FMOD11SoundGroupI8validateEPNS_10SoundGroupEPPS0_PNS_15SystemLockScopeE
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::validate(
        FMOD::SoundGroup *soundgroup,
        FMOD::SoundGroupI **soundgroupi,
        FMOD::SystemLockScope *lockScope)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SystemI *v4; // rbp

  result = FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
  if ( soundgroup )
  {
    LOBYTE(result) = 31;
    if ( soundgroupi )
    {
      if ( !lockScope )
      {
LABEL_9:
        *soundgroupi = (FMOD::SoundGroupI *)soundgroup;
        return FMOD_RESULT::FMOD_OK_0;
      }
      v4 = *(FMOD::SystemI **)&soundgroup[24].gap0;
      LOBYTE(result) = 28;
      if ( !lockScope->mSystem )
      {
        if ( v4 )
        {
          result = FMOD::SystemI::enterMainUpdateLock(v4);
          if ( result == FMOD_RESULT::FMOD_OK_0 )
          {
            lockScope->mSystem = v4;
            goto LABEL_9;
          }
        }
      }
    }
  }
  return result;
}


// Address: 0x21e38c0 | Name: _ZN4FMOD11SoundGroupIC2Ev
void __fastcall FMOD::SoundGroupI::SoundGroupI(FMOD::SoundGroupI *const this)
{
  this->mNodePrev = this;
  this->mNodeNext = this;
  this->mNodeData = 0;
  this->mSoundHead.mNodeData = 0;
  this->mSoundHead.mNodePrev = &this->mSoundHead;
  this->mSoundHead.mNodeNext = &this->mSoundHead;
  this->mChannelListHead.mNodeData = 0;
  this->mChannelListHead.mNodePriority = -1;
  this->mChannelListHead.mNodePrev = &this->mChannelListHead;
  this->mChannelListHead.mNodeNext = &this->mChannelListHead;
  this->mMaxAudible = -1;
  this->mName = 0;
  this->mFadeSpeed = 0.0;
  this->mVolume = 1.0;
}


// Address: 0x21e3920 | Name: _ZN4FMOD11SoundGroupI15releaseInternalEv
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::releaseInternal(FMOD::SoundGroupI *const this)
{
  char *mName; // rsi
  FMOD::LinkedListNode *mNodePrev; // rax
  FMOD::Global *v3; // rax

  mName = this->mName;
  if ( mName )
    FMOD::MemPool::free(off_286F358->gSystemMemPool, mName, "../../../core_api/src/fmod_soundgroupi.cpp", 181);
  mNodePrev = this->mNodePrev;
  mNodePrev->mNodeNext = this->mNodeNext;
  this->mNodeNext->mNodePrev = mNodePrev;
  v3 = off_286F358;
  this->mNodePrev = this;
  this->mNodeNext = this;
  FMOD::MemPool::free(v3->gSystemMemPool, this, "../../../core_api/src/fmod_soundgroupi.cpp", 186);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e39a0 | Name: _ZN4FMOD11SoundGroupI7releaseEv
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::release(FMOD::SoundGroupI *const this)
{
  FMOD::SystemI *mSystem; // r8
  FMOD::SoundGroupI *mMasterSoundGroup; // rax
  FMOD::SoundGroupI *mNodeNext; // rdx
  FMOD::SystemI *v5; // rcx
  FMOD::LinkedListNode *v6; // rax
  FMOD::LinkedListNode *p_mSoundHead; // rbx
  FMOD::SortedLinkedListNode *i; // rbx
  _QWORD *mNodeData; // rax
  FMOD::SoundGroupI *v11; // rsi
  _QWORD *v12; // rcx
  bool v13; // zf
  FMOD::LinkedListNode *mNodePrev; // rax
  float *v15; // rdi

  mSystem = this->mSystem;
  mMasterSoundGroup = mSystem->mMasterSoundGroup;
  if ( mMasterSoundGroup != this )
  {
    if ( !mMasterSoundGroup )
      return FMOD::SoundGroupI::releaseInternal(this);
    mNodeNext = (FMOD::SoundGroupI *)this->mChannelListHead.mNodeNext;
    v5 = this->mSystem;
    if ( mNodeNext == (FMOD::SoundGroupI *)&this->mChannelListHead )
    {
      v6 = this->mSoundHead.mNodeNext;
      p_mSoundHead = &this->mSoundHead;
      if ( v6 == &this->mSoundHead )
        goto LABEL_5;
    }
    else
    {
      while ( 1 )
      {
        mNodeData = mNodeNext->mNodeData;
        v11 = (FMOD::SoundGroupI *)mNodeNext->mNodeNext;
        v12 = (_QWORD *)mNodeData[55];
        v13 = mNodeNext->mNodeNext == &this->mChannelListHead;
        *v12 = mNodeData[54];
        *(_QWORD *)(mNodeData[54] + 8LL) = v12;
        *((_DWORD *)mNodeData + 114) = -1;
        mNodeData[56] = 0;
        *((_DWORD *)mNodeData + 134) = 1065353216;
        mNodeData[54] = mNodeData + 54;
        mNodeData[55] = mNodeData + 54;
        *((_DWORD *)mNodeData + 135) = 1065353216;
        *((_DWORD *)mNodeData + 122) = 0;
        mNodePrev = mNodeNext->mNodePrev;
        mNodePrev->mNodeNext = mNodeNext->mNodeNext;
        mNodeNext->mNodeNext->mNodePrev = mNodePrev;
        mNodeNext->mNodePrev = mNodeNext;
        mNodeNext->mNodeNext = mNodeNext;
        if ( v13 )
          break;
        mNodeNext = v11;
      }
      v6 = this->mSoundHead.mNodeNext;
      p_mSoundHead = &this->mSoundHead;
      v5 = mSystem;
      if ( v6 == &this->mSoundHead )
      {
LABEL_5:
        for ( i = (FMOD::SortedLinkedListNode *)mSystem->mChannelSortedListHead.mNodeNext;
              i != &mSystem->mChannelSortedListHead;
              i = (FMOD::SortedLinkedListNode *)i->mNodeNext )
        {
          v15 = (float *)i->mNodeData;
          if ( !*((_DWORD *)v15 + 122) )
          {
            (*(void (__fastcall **)(float *, __int64, float))(*(_QWORD *)v15 + 32LL))(v15, 1, v15[12]);
            mSystem = this->mSystem;
          }
        }
        return FMOD::SoundGroupI::releaseInternal(this);
      }
    }
    while ( 1 )
    {
      (*(void (__fastcall **)(void *, FMOD::SoundGroupI *))(*(_QWORD *)v6->mNodeData + 216LL))(
        v6->mNodeData,
        v5->mMasterSoundGroup);
      v6 = this->mSoundHead.mNodeNext;
      if ( v6 == p_mSoundHead )
        break;
      v5 = this->mSystem;
    }
    mSystem = this->mSystem;
    goto LABEL_5;
  }
  return FMOD_RESULT::FMOD_ERR_INVALID_HANDLE_0;
}


// Address: 0x21e3b30 | Name: _ZN4FMOD11SoundGroupI15getSystemObjectEPPNS_6SystemE
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::getSystemObject(FMOD::SoundGroupI *const this, FMOD::System **system)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( system )
  {
    *system = (FMOD::System *)this->mSystem;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e3b50 | Name: _ZN4FMOD11SoundGroupI13setMaxAudibleEi
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::setMaxAudible(FMOD::SoundGroupI *const this, int maxaudible)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( maxaudible >= -1 )
  {
    this->mMaxAudible = maxaudible;
    LOBYTE(result) = 0;
  }
  return result;
}


// Address: 0x21e3b70 | Name: _ZN4FMOD11SoundGroupI13getMaxAudibleEPi
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::getMaxAudible(FMOD::SoundGroupI *const this, int *maxaudible)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( maxaudible )
  {
    *maxaudible = this->mMaxAudible;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e3b90 | Name: _ZN4FMOD11SoundGroupI21setMaxAudibleBehaviorE24FMOD_SOUNDGROUP_BEHAVIOR
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::setMaxAudibleBehavior(
        FMOD::SoundGroupI *const this,
        FMOD_SOUNDGROUP_BEHAVIOR behavior)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::SortedLinkedListNode *p_mChannelListHead; // r13
  int v6; // ebp
  bool v7; // cc
  _DWORD *mNodeData; // rdi
  FMOD::LinkedListNode *v9; // r12

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( (unsigned int)behavior <= FMOD_SOUNDGROUP_BEHAVIOR::FMOD_SOUNDGROUP_BEHAVIOR_STEALLOWEST )
  {
    if ( this->mMaxAudibleBehavior == FMOD_SOUNDGROUP_BEHAVIOR::FMOD_SOUNDGROUP_BEHAVIOR_MUTE
      && behavior != FMOD_SOUNDGROUP_BEHAVIOR::FMOD_SOUNDGROUP_BEHAVIOR_MUTE )
    {
      mNodeNext = this->mChannelListHead.mNodeNext;
      p_mChannelListHead = &this->mChannelListHead;
      v6 = 0;
      while ( mNodeNext != p_mChannelListHead )
      {
        v7 = ++v6 <= this->mMaxAudible;
        mNodeData = mNodeNext->mNodeData;
        v9 = mNodeNext->mNodeNext;
        mNodeData[134] = 1065353216;
        mNodeData[135] = 1065353216;
        if ( !v7 )
          (*(void (__fastcall **)(_DWORD *))(*(_QWORD *)mNodeData + 8LL))(mNodeData);
        mNodeNext = v9;
      }
    }
    this->mMaxAudibleBehavior = behavior;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e3c20 | Name: _ZN4FMOD11SoundGroupI21getMaxAudibleBehaviorEP24FMOD_SOUNDGROUP_BEHAVIOR
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::getMaxAudibleBehavior(
        FMOD::SoundGroupI *const this,
        FMOD_SOUNDGROUP_BEHAVIOR *behavior)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( behavior )
  {
    *behavior = this->mMaxAudibleBehavior;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e3c40 | Name: _ZN4FMOD11SoundGroupI16setMuteFadeSpeedEf
char __fastcall FMOD::SoundGroupI::setMuteFadeSpeed(FMOD::SoundGroupI *const this, float a2, float speed)
{
  char result; // al

  result = 31;
  if ( a2 >= 0.0 )
  {
    this->mFadeSpeed = a2;
    return 0;
  }
  return result;
}


// Address: 0x21e3c60 | Name: _ZN4FMOD11SoundGroupI16getMuteFadeSpeedEPf
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::getMuteFadeSpeed(FMOD::SoundGroupI *const this, float *speed)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( speed )
  {
    LOBYTE(result) = 0;
    *speed = this->mFadeSpeed;
  }
  return result;
}


// Address: 0x21e3c80 | Name: _ZN4FMOD11SoundGroupI9setVolumeEf
__int64 __fastcall FMOD::SoundGroupI::setVolume(FMOD::SoundGroupI *const this, float a2, float volume)
{
  float v3; // xmm1_4
  FMOD::SoundGroupI *mNodeNext; // r14
  FMOD::SystemI *mSystem; // rsi
  FMOD::ChannelI *p_mChannelUsedListHead; // rcx
  FMOD::LinkedListNode *v7; // rax
  FMOD::ChannelI *p_mNodePrev; // rbx
  FMOD::SoundI *mNodeData; // rbp
  FMOD::LinkedListNode *v10; // rax
  FMOD::SoundI *channelsound; // [rsp+0h] [rbp-40h] BYREF

  v3 = 0.0;
  if ( a2 >= 0.0 )
    v3 = fminf(1.0, a2);
  mNodeNext = (FMOD::SoundGroupI *)this->mSoundHead.mNodeNext;
  this->mVolume = v3;
  if ( mNodeNext != &this->mSoundHead )
  {
    mSystem = this->mSystem;
    p_mChannelUsedListHead = &mSystem->mChannelUsedListHead;
    do
    {
      v7 = mSystem->mChannelUsedListHead.mNodeNext;
      p_mNodePrev = 0;
      mNodeData = (FMOD::SoundI *)mNodeNext->mNodeData;
      if ( v7 )
        p_mNodePrev = (FMOD::ChannelI *)&v7[-16].mNodePrev;
      while ( p_mNodePrev != p_mChannelUsedListHead )
      {
        if ( p_mNodePrev->mRealChannel )
        {
          channelsound = 0;
          FMOD::ChannelI::getCurrentSound(p_mNodePrev, &channelsound);
          if ( mNodeData == channelsound )
            (*((void (__fastcall **)(FMOD::ChannelI *, _QWORD, float))p_mNodePrev->_vptr_ChannelControlI + 4))(
              p_mNodePrev,
              0,
              p_mNodePrev->mVolume);
          mSystem = this->mSystem;
          p_mChannelUsedListHead = &mSystem->mChannelUsedListHead;
        }
        v10 = p_mNodePrev->mNodeNext;
        p_mNodePrev = 0;
        if ( v10 )
          p_mNodePrev = (FMOD::ChannelI *)&v10[-16].mNodePrev;
      }
      mNodeNext = (FMOD::SoundGroupI *)mNodeNext->mNodeNext;
    }
    while ( mNodeNext != &this->mSoundHead );
  }
  return 0;
}


// Address: 0x21e3d90 | Name: _ZN4FMOD11SoundGroupI9getVolumeEPf
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::getVolume(FMOD::SoundGroupI *const this, float *volume)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( volume )
  {
    LOBYTE(result) = 0;
    *volume = this->mVolume;
  }
  return result;
}


// Address: 0x21e3db0 | Name: _ZN4FMOD11SoundGroupI4stopEv
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::stop(FMOD::SoundGroupI *const this)
{
  FMOD::LinkedListNode *i; // rbx

  for ( i = this->mSoundHead.mNodeNext; i != &this->mSoundHead; i = i->mNodeNext )
    FMOD::SystemI::stopSound(this->mSystem, (FMOD::SoundI *)i->mNodeData);
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e3df0 | Name: _ZN4FMOD11SoundGroupI7getNameEPci
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::getName(FMOD::SoundGroupI *const this, char *name, int namelen)
{
  FMOD_RESULT_0 result; // eax
  char *mName; // rsi

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( name )
  {
    mName = this->mName;
    LOWORD(result) = 256;
    if ( namelen <= 256 )
      result = namelen;
    if ( !mName )
      mName = "(null)";
    FMOD_strcpy_safe(name, mName, result);
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e3e40 | Name: _ZN4FMOD11SoundGroupI12getNumSoundsEPi
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::getNumSounds(FMOD::SoundGroupI *const this, int *numsounds)
{
  FMOD_RESULT_0 result; // eax
  FMOD::SoundGroupI *mNodeNext; // rax
  int i; // edx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numsounds )
  {
    mNodeNext = (FMOD::SoundGroupI *)this->mSoundHead.mNodeNext;
    for ( i = 0; &this->mSoundHead != mNodeNext; ++i )
      mNodeNext = (FMOD::SoundGroupI *)mNodeNext->mNodeNext;
    *numsounds = i;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e3e80 | Name: _ZN4FMOD11SoundGroupI8getSoundEiPPNS_5SoundE
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::getSound(FMOD::SoundGroupI *const this, int index, FMOD::Sound **sound)
{
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *p_mSoundHead; // rdi
  int v5; // ecx

  if ( !sound )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  *sound = 0;
  mNodeNext = this->mSoundHead.mNodeNext;
  p_mSoundHead = &this->mSoundHead;
  if ( mNodeNext == p_mSoundHead )
    return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  v5 = 0;
  if ( index )
  {
    do
    {
      mNodeNext = mNodeNext->mNodeNext;
      ++v5;
      if ( mNodeNext == p_mSoundHead )
        return FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
    }
    while ( index != v5 );
  }
  *sound = (FMOD::Sound *)mNodeNext->mNodeData;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e3ed0 | Name: _ZN4FMOD11SoundGroupI13getNumPlayingEPi
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::getNumPlaying(FMOD::SoundGroupI *const this, int *numplaying)
{
  FMOD_RESULT_0 result; // eax
  FMOD::LinkedListNode *mNodeNext; // rax
  FMOD::LinkedListNode *p_mSoundHead; // rdi
  int v5; // edx
  _DWORD *mNodeData; // rcx

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( numplaying )
  {
    mNodeNext = this->mSoundHead.mNodeNext;
    p_mSoundHead = &this->mSoundHead;
    v5 = 0;
    for ( *numplaying = 0; mNodeNext != p_mSoundHead; *numplaying = v5 )
    {
      mNodeData = mNodeNext->mNodeData;
      mNodeNext = mNodeNext->mNodeNext;
      v5 += mNodeData[78];
    }
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


// Address: 0x21e3f20 | Name: _ZN4FMOD11SoundGroupI11setUserDataEPv
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::setUserData(FMOD::SoundGroupI *const this, void *userdata)
{
  this->mUserData = userdata;
  return FMOD_RESULT::FMOD_OK_0;
}


// Address: 0x21e3f30 | Name: _ZN4FMOD11SoundGroupI11getUserDataEPPv
FMOD_RESULT_0 __fastcall FMOD::SoundGroupI::getUserData(FMOD::SoundGroupI *const this, void **userdata)
{
  FMOD_RESULT_0 result; // eax

  result = FMOD_RESULT::FMOD_ERR_INVALID_PARAM_0;
  if ( userdata )
  {
    *userdata = this->mUserData;
    return FMOD_RESULT::FMOD_OK_0;
  }
  return result;
}


