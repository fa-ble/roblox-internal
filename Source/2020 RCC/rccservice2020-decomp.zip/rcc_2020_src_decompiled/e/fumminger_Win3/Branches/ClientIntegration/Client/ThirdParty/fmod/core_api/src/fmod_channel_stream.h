// Address: 0x222cd00 | Name: _ZN4FMOD13ChannelStream8isStreamEv
bool __fastcall FMOD::ChannelStream::isStream(FMOD::ChannelStream *const this)
{
  return 1;
}


// Address: 0x222cd10 | Name: _ZN4FMOD13ChannelStream11getPositionEP14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::getPosition(FMOD::ChannelStream *const this, FMOD_UINT32_32 *pcm)
{
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelStream *const, unsigned int *, __int64))this->_vptr_ChannelReal
          + 28))(
           this,
           &pcm->mHi,
           2);
}


// Address: 0x222ce30 | Name: _ZN4FMOD13ChannelStream11setPositionE14FMOD_UINT32_32
FMOD_RESULT_0 __fastcall FMOD::ChannelStream::setPosition(FMOD::ChannelStream *const this, FMOD_UINT32_32 pcm)
{
  FMOD::ChannelReal::setPosition(this, pcm);
  return (*((FMOD_RESULT_0 (__fastcall **)(FMOD::ChannelStream *const, _QWORD, __int64, _QWORD))this->_vptr_ChannelReal
          + 27))(
           this,
           pcm.mHi,
           2,
           0);
}


