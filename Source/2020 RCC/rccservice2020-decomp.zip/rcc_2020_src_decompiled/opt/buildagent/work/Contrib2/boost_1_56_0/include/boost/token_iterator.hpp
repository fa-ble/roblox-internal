// Address: 0xe605d0 | Name: _ZN5boost14token_iteratorINS_14char_separatorIcNSt3__111char_traitsIcEEEENS2_11__wrap_iterIPKcEENS2_12basic_stringIcS4_NS2_9allocatorIcEEEEEC2ES5_S9_S9_
bool __fastcall boost::token_iterator<boost::char_separator<char,std::char_traits<char>>,std::__wrap_iter<char const*>,std::string>::token_iterator(
        boost::char_separator<char,std::char_traits<char> > *this,
        __int64 a2,
        const char *a3,
        std::__wrap_iter<const char *> a4)
{
  bool result; // al

  std::string::basic_string(this, a2);
  std::string::basic_string((char *)this + 24, a2 + 24);
  *((_BYTE *)this + 56) = *(_BYTE *)(a2 + 56);
  *((_QWORD *)this + 6) = *(_QWORD *)(a2 + 48);
  *((_QWORD *)this + 8) = a3;
  *((std::__wrap_iter<const char *> *)this + 9) = a4;
  *((_BYTE *)this + 80) = 0;
  *(_OWORD *)((char *)this + 88) = 0;
  *((_QWORD *)this + 13) = 0;
  result = a3 != a4.__i
        && boost::char_separator<char,std::char_traits<char>>::operator()<std::__wrap_iter<char const*>,std::string>(
             this,
             (std::__wrap_iter<const char *> *)this + 8,
             a4,
             (boost::char_separator<char,std::char_traits<char> > *)((char *)this + 88));
  *((_BYTE *)this + 80) = result;
  return result;
}


