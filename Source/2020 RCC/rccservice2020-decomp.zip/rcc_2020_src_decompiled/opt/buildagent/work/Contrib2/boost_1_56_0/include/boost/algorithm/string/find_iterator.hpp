// Address: 0xfebd20 | Name: _ZN5boost9algorithm14split_iteratorINSt3__111__wrap_iterIPKcEEEC2INS0_6detail13token_finderFINS9_10is_any_ofFIcEEEEEES6_S6_T_
void __fastcall boost::algorithm::split_iterator<std::__wrap_iter<char const*>>::split_iterator<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
        boost::algorithm::split_iterator<std::__wrap_iter<const char *> >_0 *this,
        std::__wrap_iter<const char *> Begin,
        std::__wrap_iter<const char *> End,
        _DWORD *a4)
{
  size_t v8; // rbx
  boost::algorithm::detail::is_any_ofF<char>::set_value_type *v9; // rdi
  const void *v10; // rsi
  const char *v11; // rax
  const char *i; // rdx
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > v13; // [rsp+0h] [rbp-58h] BYREF
  int v14; // [rsp+20h] [rbp-38h]
  unsigned __int64 v15; // [rsp+28h] [rbp-30h]

  v15 = __readfsqword(0x28u);
  v8 = *((_QWORD *)a4 + 2);
  *(_QWORD *)&v13.m_eCompress = v8;
  *(_QWORD *)&v13.m_Pred.m_Storage.m_fixSet[8] = 0;
  if ( v8 > 0x10 )
  {
    v9 = (boost::algorithm::detail::is_any_ofF<char>::set_value_type *)operator new[](v8);
    *(_QWORD *)&v13.m_Pred.m_Storage.m_fixSet[8] = v9;
    v10 = *(const void **)a4;
  }
  else
  {
    v9 = &v13.m_Pred.m_Storage.m_fixSet[8];
    v10 = a4;
  }
  memcpy(v9, v10, v8);
  v14 = a4[6];
  boost::algorithm::detail::find_iterator_base<std::__wrap_iter<char const*>>::find_iterator_base<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
    this,
    v13,
    (int)&v13.m_Pred.m_Storage.m_fixSet[8]);
  if ( *(_QWORD *)&v13.m_eCompress >= 0x11u && *(_QWORD *)&v13.m_Pred.m_Storage.m_fixSet[8] )
    operator delete[](*(void **)&v13.m_Pred.m_Storage.m_fixSet[8]);
  this->m_Match.m_Begin = Begin;
  this->m_Match.m_End = Begin;
  this->m_Next = Begin;
  this->m_End = End;
  this->m_bEof = 0;
  if ( Begin.__i != End.__i )
  {
    if ( this->m_Finder.vtable )
    {
      v11 = (const char *)(*(__int64 (__fastcall **)(boost::detail::function::function_buffer *, std::__wrap_iter<const char *>::iterator_type, std::__wrap_iter<const char *>::iterator_type))(((unsigned __int64)this->m_Finder.vtable & 0xFFFFFFFFFFFFFFFELL) + 8))(
                            &this->m_Finder.functor,
                            Begin.__i,
                            End.__i);
      End.__i = this->m_End.__i;
      if ( i != End.__i )
      {
LABEL_14:
        this->m_Match.m_Begin.__i = this->m_Next.__i;
        this->m_Match.m_End.__i = v11;
        this->m_Next.__i = i;
        return;
      }
    }
    else
    {
      i = End.__i;
      v11 = End.__i;
    }
    if ( v11 == End.__i && this->m_Match.m_End.__i == End.__i )
      this->m_bEof = 1;
    goto LABEL_14;
  }
}


// Address: 0x1018ff0 | Name: _ZN5boost9algorithm14split_iteratorINSt3__111__wrap_iterIPcEEEC2INS0_6detail13token_finderFINS8_10is_any_ofFIcEEEEEES5_S5_T_
void __fastcall boost::algorithm::split_iterator<std::__wrap_iter<char *>>::split_iterator<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
        boost::algorithm::split_iterator<std::__wrap_iter<char *> > *this,
        std::__wrap_iter<char *> Begin,
        std::__wrap_iter<char *> End,
        _DWORD *a4)
{
  size_t v8; // rbx
  boost::algorithm::detail::is_any_ofF<char>::set_value_type *v9; // rdi
  const void *v10; // rsi
  char *v11; // rax
  char *i; // rdx
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > v13; // [rsp+0h] [rbp-58h] BYREF
  int v14; // [rsp+20h] [rbp-38h]
  unsigned __int64 v15; // [rsp+28h] [rbp-30h]

  v15 = __readfsqword(0x28u);
  v8 = *((_QWORD *)a4 + 2);
  *(_QWORD *)&v13.m_eCompress = v8;
  *(_QWORD *)&v13.m_Pred.m_Storage.m_fixSet[8] = 0;
  if ( v8 > 0x10 )
  {
    v9 = (boost::algorithm::detail::is_any_ofF<char>::set_value_type *)operator new[](v8);
    *(_QWORD *)&v13.m_Pred.m_Storage.m_fixSet[8] = v9;
    v10 = *(const void **)a4;
  }
  else
  {
    v9 = &v13.m_Pred.m_Storage.m_fixSet[8];
    v10 = a4;
  }
  memcpy(v9, v10, v8);
  v14 = a4[6];
  boost::algorithm::detail::find_iterator_base<std::__wrap_iter<char *>>::find_iterator_base<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
    this,
    v13,
    (int)&v13.m_Pred.m_Storage.m_fixSet[8]);
  if ( *(_QWORD *)&v13.m_eCompress >= 0x11u && *(_QWORD *)&v13.m_Pred.m_Storage.m_fixSet[8] )
    operator delete[](*(void **)&v13.m_Pred.m_Storage.m_fixSet[8]);
  this->m_Match.m_Begin = Begin;
  this->m_Match.m_End = Begin;
  this->m_Next = Begin;
  this->m_End = End;
  this->m_bEof = 0;
  if ( Begin.__i != End.__i )
  {
    if ( this->m_Finder.vtable )
    {
      v11 = (char *)(*(__int64 (__fastcall **)(boost::detail::function::function_buffer *, std::__wrap_iter<char *>::iterator_type, std::__wrap_iter<char *>::iterator_type))(((unsigned __int64)this->m_Finder.vtable & 0xFFFFFFFFFFFFFFFELL) + 8))(
                      &this->m_Finder.functor,
                      Begin.__i,
                      End.__i);
      End.__i = this->m_End.__i;
      if ( i != End.__i )
      {
LABEL_14:
        this->m_Match.m_Begin.__i = this->m_Next.__i;
        this->m_Match.m_End.__i = v11;
        this->m_Next.__i = i;
        return;
      }
    }
    else
    {
      i = End.__i;
      v11 = End.__i;
    }
    if ( v11 == End.__i && this->m_Match.m_End.__i == End.__i )
      this->m_bEof = 1;
    goto LABEL_14;
  }
}


// Address: 0x110fff0 | Name: _ZN5boost9algorithm14split_iteratorIPKcEC2INS0_6detail13token_finderFINS6_10is_any_ofFIcEEEEEES3_S3_T_
void __fastcall boost::algorithm::split_iterator<char const*>::split_iterator<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
        boost::algorithm::split_iterator<const char *> *this,
        const char *Begin,
        boost::algorithm::split_iterator<const char *>::input_iterator_type End,
        _DWORD *a4)
{
  size_t v8; // rbx
  boost::algorithm::detail::is_any_ofF<char>::set_value_type *v9; // rdi
  const void *v10; // rsi
  const char *v11; // rax
  const char *v12; // rdx
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > v13; // [rsp+0h] [rbp-58h] BYREF
  int v14; // [rsp+20h] [rbp-38h]
  unsigned __int64 v15; // [rsp+28h] [rbp-30h]

  v15 = __readfsqword(0x28u);
  v8 = *((_QWORD *)a4 + 2);
  *(_QWORD *)&v13.m_eCompress = v8;
  *(_QWORD *)&v13.m_Pred.m_Storage.m_fixSet[8] = 0;
  if ( v8 > 0x10 )
  {
    v9 = (boost::algorithm::detail::is_any_ofF<char>::set_value_type *)operator new[](v8);
    *(_QWORD *)&v13.m_Pred.m_Storage.m_fixSet[8] = v9;
    v10 = *(const void **)a4;
  }
  else
  {
    v9 = &v13.m_Pred.m_Storage.m_fixSet[8];
    v10 = a4;
  }
  memcpy(v9, v10, v8);
  v14 = a4[6];
  boost::algorithm::detail::find_iterator_base<char const*>::find_iterator_base<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
    this,
    v13,
    (int)&v13.m_Pred.m_Storage.m_fixSet[8]);
  if ( *(_QWORD *)&v13.m_eCompress >= 0x11u && *(_QWORD *)&v13.m_Pred.m_Storage.m_fixSet[8] )
    operator delete[](*(void **)&v13.m_Pred.m_Storage.m_fixSet[8]);
  this->m_Match.m_Begin = Begin;
  this->m_Match.m_End = Begin;
  this->m_Next = Begin;
  this->m_End = End;
  this->m_bEof = 0;
  if ( Begin != End )
  {
    if ( this->m_Finder.vtable )
    {
      v11 = (const char *)(*(__int64 (__fastcall **)(boost::detail::function::function_buffer *, const char *, boost::algorithm::split_iterator<const char *>::input_iterator_type))(((unsigned __int64)this->m_Finder.vtable & 0xFFFFFFFFFFFFFFFELL) + 8))(
                            &this->m_Finder.functor,
                            Begin,
                            End);
      End = this->m_End;
      if ( v12 != End )
      {
LABEL_14:
        this->m_Match.m_Begin = this->m_Next;
        this->m_Match.m_End = v11;
        this->m_Next = v12;
        return;
      }
    }
    else
    {
      v12 = End;
      v11 = End;
    }
    if ( v11 == End && this->m_Match.m_End == End )
      this->m_bEof = 1;
    goto LABEL_14;
  }
}


// Address: 0x275b070 | Name: _ZN5boost9algorithm14split_iteratorINSt3__111__wrap_iterIPKcEEEC2INS0_6detail13token_finderFINS9_14is_from_rangeFIcEEEEEES6_S6_T_
// local variable allocation has failed, the output may be wrong!
void __fastcall boost::algorithm::split_iterator<std::__wrap_iter<char const*>>::split_iterator<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_from_rangeF<char>>>(
        boost::algorithm::split_iterator<std::__wrap_iter<const char *> > *this,
        std::__wrap_iter<const char *> Begin,
        std::__wrap_iter<const char *> End,
        boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_from_rangeF<char> > Finder)
{
  const char *v4; // rax
  const char *v5; // rdx
  const char *i; // rcx

  this->m_Finder.functor.obj_ptr = (void *)Finder;
  this->m_Finder.vtable = (boost::detail::function::vtable_base *)((char *)off_29C9EE8 + 1);
  this->m_Match.m_Begin = Begin;
  this->m_Match.m_End = Begin;
  this->m_Next = Begin;
  this->m_End = End;
  this->m_bEof = 0;
  if ( Begin.__i != End.__i )
  {
    v4 = (const char *)(*(__int64 (__fastcall **)(boost::detail::function::function_buffer *))(((unsigned __int64)off_29C9EE8
                                                                                              & 0xFFFFFFFFFFFFFFFELL)
                                                                                             + 8))(&this->m_Finder.functor);
    i = this->m_End.__i;
    if ( v5 == i && v4 == i && this->m_Match.m_End.__i == i )
      this->m_bEof = 1;
    this->m_Match.m_Begin.__i = this->m_Next.__i;
    this->m_Match.m_End.__i = v4;
    this->m_Next.__i = v5;
  }
}


