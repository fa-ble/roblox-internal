// Address: 0x15b30a0 | Name: _ZNK3RBX12LocalStorage9directoryEv
boost::optional<boost::filesystem::path> *__fastcall RBX::LocalStorage::directory(
        boost::optional<boost::filesystem::path> *__return_ptr retstr,
        const RBX::LocalStorage *this)
{
  retstr->m_initialized = 0;
  return retstr;
}


