// Address: 0x25f50c0 | Name: _ZN5boost4asio3ssl6detail15verify_callbackIZZN3web10websockets6client7details20wspp_callback_client7connectEvENKUlNSt3__18weak_ptrIvEEE_clESB_EUlbRNS1_14verify_contextEE_ED0Ev
// Alternative name is 'j__ZdlPv_1974'
// attributes: thunk
void __fastcall boost::asio::ssl::detail::verify_callback<web::websockets::client::details::wspp_callback_client::connect(void)::{lambda(std::weak_ptr<void>)#1}::operator() const(std::weak_ptr<void>)::{lambda(bool,boost::asio::ssl::verify_context &)#1}>::~verify_callback(
        boost::asio::ssl::detail::verify_callback<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_ThirdParty_cpprestsdk_Release_src_websockets_client_ws_client_wspp_cpp:167:49)> *this)
{
  operator delete(this);
}


// Address: 0x25f50d0 | Name: _ZN5boost4asio3ssl6detail15verify_callbackIZZN3web10websockets6client7details20wspp_callback_client7connectEvENKUlNSt3__18weak_ptrIvEEE_clESB_EUlbRNS1_14verify_contextEE_E4callEbSE_
bool __fastcall boost::asio::ssl::detail::verify_callback<web::websockets::client::details::wspp_callback_client::connect(void)::{lambda(std::weak_ptr<void>)#1}::operator() const(std::weak_ptr<void>)::{lambda(bool,boost::asio::ssl::verify_context &)#1}>::call(
        boost::asio::ssl::detail::verify_callback<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_ThirdParty_cpprestsdk_Release_src_websockets_client_ws_client_wspp_cpp:167:49)> *this,
        bool preverified,
        boost::asio::ssl::verify_context *ctx)
{
  return web::websockets::client::details::wspp_callback_client::connect(void)::{lambda(std::weak_ptr<void>)#1}::operator() const(std::weak_ptr<void>)::{lambda(bool,boost::asio::ssl::verify_context &)#1}::operator()(
           (const const struct __cppobj {web::websockets::client::details::wspp_callback_client *this;} *)&this->callback_,
           preverified,
           ctx);
}


// Address: 0x25f50e0 | Name: _ZN5boost4asio3ssl6detail20verify_callback_baseD2Ev
void __fastcall boost::asio::ssl::detail::verify_callback_base::~verify_callback_base(
        boost::asio::ssl::detail::verify_callback_base *this)
{
  ;
}


// Address: 0x26a8680 | Name: _ZN5boost4asio3ssl6detail15verify_callbackIZN3web4http6client7details12asio_context13write_requestEvEUlbRNS1_14verify_contextEE_ED2Ev
void __fastcall boost::asio::ssl::detail::verify_callback<web::http::client::details::asio_context::write_request(void)::{lambda(bool,boost::asio::ssl::verify_context &)#1}>::~verify_callback(
        boost::asio::ssl::detail::verify_callback<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_ThirdParty_cpprestsdk_Release_src_http_client_http_client_asio_cpp:856:43)> *this)
{
  std::__shared_weak_count *cntrl; // rdi

  this->_vptr$verify_callback_base = (int (**)(void))&off_29C7478;
  cntrl = this->callback_.weakCtx.__cntrl_;
  if ( cntrl )
    std::__shared_weak_count::__release_weak(cntrl);
}


// Address: 0x26a86a0 | Name: _ZN5boost4asio3ssl6detail15verify_callbackIZN3web4http6client7details12asio_context13write_requestEvEUlbRNS1_14verify_contextEE_ED0Ev
void __fastcall boost::asio::ssl::detail::verify_callback<web::http::client::details::asio_context::write_request(void)::{lambda(bool,boost::asio::ssl::verify_context &)#1}>::~verify_callback(
        boost::asio::ssl::detail::verify_callback<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_ThirdParty_cpprestsdk_Release_src_http_client_http_client_asio_cpp:856:43)> *this)
{
  std::__shared_weak_count *cntrl; // rdi

  this->_vptr$verify_callback_base = (int (**)(void))&off_29C7478;
  cntrl = this->callback_.weakCtx.__cntrl_;
  if ( cntrl )
    std::__shared_weak_count::__release_weak(cntrl);
  operator delete(this);
}


// Address: 0x26a86d0 | Name: _ZN5boost4asio3ssl6detail15verify_callbackIZN3web4http6client7details12asio_context13write_requestEvEUlbRNS1_14verify_contextEE_E4callEbSA_
bool __fastcall boost::asio::ssl::detail::verify_callback<web::http::client::details::asio_context::write_request(void)::{lambda(bool,boost::asio::ssl::verify_context &)#1}>::call(
        boost::asio::ssl::detail::verify_callback<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_ThirdParty_cpprestsdk_Release_src_http_client_http_client_asio_cpp:856:43)> *this,
        bool preverified,
        boost::asio::ssl::verify_context *ctx)
{
  return web::http::client::details::asio_context::write_request(void)::{lambda(bool,boost::asio::ssl::verify_context &)#1}::operator()(
           (const const struct __cppobj {const std::weak_ptr<web::http::client::details::asio_context> weakCtx;} *)&this->callback_,
           preverified,
           ctx);
}


