// Address: 0x159bdc0 | Name: _ZN5boost6detail22lexical_converter_implINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEN3RBX9HeapValueIlLi0EEEE11try_convertERKSB_RS8_
bool __fastcall boost::detail::lexical_converter_impl<std::string,RBX::HeapValue<long,0>>::try_convert(
        const RBX::HeapValue<long,0> *arg,
        std::string *result)
{
  unsigned __int64 v3; // rbx
  unsigned __int64 v4; // r12
  unsigned __int64 v5; // r15
  unsigned __int8 v6; // al
  unsigned __int64 v7; // rsi
  __int64 v8; // rcx
  bool v9; // bl
  unsigned __int64 v10; // rcx
  _BYTE *v11; // r8
  _BYTE *v12; // rdx
  __int64 v13; // r12
  __int64 v14; // rcx
  unsigned __int64 v16; // rcx
  __int64 v17; // rdx
  __int64 v18; // rsi
  __int64 v19; // rdi
  __int128 v20; // xmm1
  __int128 v21; // xmm1
  __int128 v22; // xmm1
  __int128 v23; // xmm1
  __int64 v24; // rsi
  __int64 v25; // rdx
  __int128 v26; // xmm1
  _QWORD v27[9]; // [rsp+8h] [rbp-140h] BYREF
  char v28; // [rsp+50h] [rbp-F8h]
  void *ptr; // [rsp+60h] [rbp-E8h]
  __int64 (__fastcall **v30)(); // [rsp+78h] [rbp-D0h]
  unsigned __int64 v31; // [rsp+118h] [rbp-30h]
  unsigned __int64 v32; // [rsp+120h] [rbp-28h]

  boost::detail::lexical_istream_limited_src<char,std::char_traits<char>,true,2ul>::lexical_istream_limited_src((boost::detail::lexical_istream_limited_src<char,std::char_traits<char>,true,2> *)v27);
  if ( boost::detail::lexical_istream_limited_src<char,std::char_traits<char>,true,2ul>::shl_input_streamable<RBX::HeapValue<long,0> const>(
         (boost::detail::lexical_istream_limited_src<char,std::char_traits<char>,true,2> *)v27,
         arg) )
  {
    v3 = v31;
    v4 = v32;
    v5 = v32 - v31;
    v6 = *(_BYTE *)result;
    if ( (*(_BYTE *)result & 1) != 0 )
    {
      v8 = *(_QWORD *)result;
      v7 = (*(_QWORD *)result & 0xFFFFFFFFFFFFFFFELL) - 1;
    }
    else
    {
      v7 = 22;
      LOBYTE(v8) = v6;
    }
    if ( v5 > v7 )
    {
      if ( (v6 & 1) != 0 )
        v10 = *((_QWORD *)result + 1);
      else
        v10 = (unsigned __int64)v6 >> 1;
      std::string::__grow_by(result, v7, v5 - v7, v10, 0, v10, 0);
      LOBYTE(v8) = *(_BYTE *)result;
    }
    if ( (v8 & 1) != 0 )
    {
      v11 = (_BYTE *)*((_QWORD *)result + 2);
      if ( v3 == v4 )
      {
LABEL_21:
        *v11 = 0;
        if ( (*(_BYTE *)result & 1) != 0 )
          *((_QWORD *)result + 1) = v5;
        else
          *(_BYTE *)result = 2 * v5;
        v9 = 1;
        goto LABEL_25;
      }
    }
    else
    {
      v11 = (char *)result + 1;
      if ( v3 == v4 )
        goto LABEL_21;
    }
    if ( v5 < 0x20 || (unsigned __int64)v11 < v4 && v3 < (unsigned __int64)&v11[v5] )
    {
      v12 = v11;
      goto LABEL_17;
    }
    v16 = v5 & 0xFFFFFFFFFFFFFFE0LL;
    v17 = ((unsigned __int8)(((v5 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3;
    if ( (v5 & 0xFFFFFFFFFFFFFFE0LL) - 32 >= 0x60 )
    {
      v19 = v17 - ((((v5 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1);
      v18 = 0;
      do
      {
        v20 = *(_OWORD *)(v3 + v18 + 16);
        *(_OWORD *)&v11[v18] = *(_OWORD *)(v3 + v18);
        *(_OWORD *)&v11[v18 + 16] = v20;
        v21 = *(_OWORD *)(v3 + v18 + 48);
        *(_OWORD *)&v11[v18 + 32] = *(_OWORD *)(v3 + v18 + 32);
        *(_OWORD *)&v11[v18 + 48] = v21;
        v22 = *(_OWORD *)(v3 + v18 + 80);
        *(_OWORD *)&v11[v18 + 64] = *(_OWORD *)(v3 + v18 + 64);
        *(_OWORD *)&v11[v18 + 80] = v22;
        v23 = *(_OWORD *)(v3 + v18 + 112);
        *(_OWORD *)&v11[v18 + 96] = *(_OWORD *)(v3 + v18 + 96);
        *(_OWORD *)&v11[v18 + 112] = v23;
        v18 += 128;
        v19 += 4;
      }
      while ( v19 );
      if ( (((unsigned __int8)(((v5 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
        goto LABEL_36;
    }
    else
    {
      v18 = 0;
      if ( (((unsigned __int8)(((v5 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
      {
LABEL_36:
        if ( v5 == v16 )
        {
LABEL_19:
          v11 += v5;
          goto LABEL_21;
        }
        v12 = &v11[v16];
        v3 += v16;
LABEL_17:
        v13 = v4 - v3;
        v14 = 0;
        do
        {
          v12[v14] = *(_BYTE *)(v3 + v14);
          ++v14;
        }
        while ( v13 != v14 );
        goto LABEL_19;
      }
    }
    v24 = v18 + 16;
    v25 = -v17;
    do
    {
      v26 = *(_OWORD *)(v3 + v24);
      *(_OWORD *)&v11[v24 - 16] = *(_OWORD *)(v3 + v24 - 16);
      *(_OWORD *)&v11[v24] = v26;
      v24 += 32;
      ++v25;
    }
    while ( v25 );
    goto LABEL_36;
  }
  v9 = 0;
LABEL_25:
  v27[0] = &off_2876AC8;
  v30 = off_2876AF0;
  v27[1] = &off_28753A8;
  if ( (v28 & 1) != 0 )
    operator delete(ptr);
  std::streambuf::~streambuf();
  std::ostream::~ostream(v27, data);
  std::ios::~ios();
  return v9;
}


