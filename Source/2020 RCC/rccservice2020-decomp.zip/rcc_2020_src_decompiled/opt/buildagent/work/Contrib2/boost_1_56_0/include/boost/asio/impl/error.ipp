// Address: 0x25ed220 | Name: _ZN5boost4asio5error6detail14netdb_categoryD0Ev
// Alternative name is 'j__ZdlPv_1965'
// attributes: thunk
void __fastcall boost::asio::error::detail::netdb_category::~netdb_category(
        boost::asio::error::detail::netdb_category *this)
{
  operator delete(this);
}


// Address: 0x25ed230 | Name: _ZNK5boost4asio5error6detail14netdb_category4nameEv
const char *__fastcall boost::asio::error::detail::netdb_category::name(
        const boost::asio::error::detail::netdb_category *this)
{
  return "asio.netdb";
}


// Address: 0x25ed240 | Name: _ZNK5boost4asio5error6detail14netdb_category7messageEi
boost::asio::error::detail::netdb_category *__fastcall boost::asio::error::detail::netdb_category::message(
        boost::asio::error::detail::netdb_category *this,
        int a2,
        int a3)
{
  char *v3; // rax
  _BYTE *v4; // rax
  char *v5; // rax
  char *v6; // rax
  char *v7; // rax

  switch ( a3 )
  {
    case 1:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      v3 = (char *)operator new(0x20u);
      *((_QWORD *)this + 2) = v3;
      *(_OWORD *)&this->_vptr$error_category = *(_OWORD *)&stru_3E8880.vtable;
      qmemcpy(v3, "Host not found (authoritative)", 30);
      v4 = v3 + 30;
      break;
    case 2:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      v5 = (char *)operator new(0x40u);
      *((_QWORD *)this + 2) = v5;
      *(_OWORD *)&this->_vptr$error_category = xmmword_3E7A10;
      qmemcpy(v5, "Host not found (non-authoritative), try again later", 51);
      v4 = v5 + 51;
      break;
    case 3:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      v6 = (char *)operator new(0x40u);
      *((_QWORD *)this + 2) = v6;
      *(_OWORD *)&this->_vptr$error_category = xmmword_3E8C50;
      qmemcpy(v6, "A non-recoverable error occurred during database lookup", 55);
      v4 = v6 + 55;
      break;
    case 4:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      v7 = (char *)operator new(0x40u);
      *((_QWORD *)this + 2) = v7;
      *(_OWORD *)&this->_vptr$error_category = xmmword_3E71F0;
      qmemcpy(v7, "The query is valid, but it does not have associated data", 56);
      v4 = v7 + 56;
      break;
    default:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_BYTE *)this + 17) = 0;
      *((_WORD *)this + 9) = 0;
      *((_DWORD *)this + 5) = 0;
      strcpy((char *)this, " asio.netdb erro");
      v4 = (char *)this + 17;
      break;
  }
  *v4 = 0;
  return this;
}


// Address: 0x25ed430 | Name: _ZN5boost4asio5error6detail17addrinfo_categoryD0Ev
// Alternative name is 'j__ZdlPv_1966'
// attributes: thunk
void __fastcall boost::asio::error::detail::addrinfo_category::~addrinfo_category(
        boost::asio::error::detail::addrinfo_category *this)
{
  operator delete(this);
}


// Address: 0x25ed440 | Name: _ZNK5boost4asio5error6detail17addrinfo_category4nameEv
const char *__fastcall boost::asio::error::detail::addrinfo_category::name(
        const boost::asio::error::detail::addrinfo_category *this)
{
  return "asio.addrinfo";
}


// Address: 0x25ed450 | Name: _ZNK5boost4asio5error6detail17addrinfo_category7messageEi
boost::asio::error::detail::addrinfo_category *__fastcall boost::asio::error::detail::addrinfo_category::message(
        boost::asio::error::detail::addrinfo_category *this,
        int a2,
        int a3)
{
  _BYTE *v3; // rax
  char *v4; // rax

  if ( a3 == -7 )
  {
    *(_OWORD *)&this->_vptr$error_category = 0;
    *((_QWORD *)this + 2) = 0;
    v4 = (char *)operator new(0x20u);
    *((_QWORD *)this + 2) = v4;
    *(_OWORD *)&this->_vptr$error_category = xmmword_3E5070;
    qmemcpy(v4, "Socket type not supported", 25);
    v3 = v4 + 25;
  }
  else
  {
    *(_OWORD *)&this->_vptr$error_category = 0;
    *((_BYTE *)this + 17) = 0;
    *((_WORD *)this + 9) = 0;
    *((_DWORD *)this + 5) = 0;
    if ( a3 == -8 )
    {
      strcpy((char *)this, "\"Service not fou");
      v3 = (char *)this + 18;
    }
    else
    {
      strcpy((char *)this, "&asio.addrinfo e");
      v3 = (char *)this + 20;
    }
  }
  *v3 = 0;
  return this;
}


// Address: 0x25ed500 | Name: _ZN5boost4asio5error6detail13misc_categoryD0Ev
// Alternative name is 'j__ZdlPv_1967'
// attributes: thunk
void __fastcall boost::asio::error::detail::misc_category::~misc_category(
        boost::asio::error::detail::misc_category *this)
{
  operator delete(this);
}


// Address: 0x25ed510 | Name: _ZNK5boost4asio5error6detail13misc_category4nameEv
const char *__fastcall boost::asio::error::detail::misc_category::name(
        const boost::asio::error::detail::misc_category *this)
{
  return "asio.misc";
}


// Address: 0x25ed520 | Name: _ZNK5boost4asio5error6detail13misc_category7messageEi
boost::asio::error::detail::misc_category *__fastcall boost::asio::error::detail::misc_category::message(
        boost::asio::error::detail::misc_category *this,
        int a2,
        int a3)
{
  char *v3; // rax

  switch ( a3 )
  {
    case 1:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      LOBYTE(this->_vptr$error_category) = 24;
      strcpy((char *)&this->_vptr$error_category + 1, "Already open");
      break;
    case 2:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      LOBYTE(this->_vptr$error_category) = 22;
      *(int (***)(void))((char *)&this->_vptr$error_category + 1) = (int (**)(void))0x6620666F20646E45LL;
      *(_DWORD *)((char *)this + 9) = (_DWORD)&unk_656C69;
      break;
    case 3:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      strcpy((char *)this, "\"Element not found");
      break;
    case 4:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      v3 = (char *)operator new(0x40u);
      *((_QWORD *)this + 2) = v3;
      *(_OWORD *)&this->_vptr$error_category = xmmword_3E6250;
      strcpy(v3, "The descriptor does not fit into the select call's fd_set");
      break;
    default:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      LOBYTE(this->_vptr$error_category) = 30;
      strcpy((char *)&this->_vptr$error_category + 1, "asio.misc error");
      break;
  }
  return this;
}


