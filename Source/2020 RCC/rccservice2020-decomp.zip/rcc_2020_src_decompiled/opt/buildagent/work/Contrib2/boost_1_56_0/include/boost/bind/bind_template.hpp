// Address: 0x10b7850 | Name: _ZN5boost3_bi6bind_tINS0_11unspecifiedENS_8functionIFvN3RBX10Reflection7VariantEEEENS0_5list1INS0_5valueIS6_EEEEEclEv
boost::_bi::bind_t<boost::_bi::unspecified,boost::function<void (RBX::Reflection::Variant)>,boost::_bi::list1<boost::_bi::value<RBX::Reflection::Variant> > >::result_type __fastcall boost::_bi::bind_t<boost::_bi::unspecified,boost::function<void ()(RBX::Reflection::Variant)>,boost::_bi::list1<boost::_bi::value<RBX::Reflection::Variant>>>::operator()(
        boost::_bi::bind_t<boost::_bi::unspecified,boost::function<void (RBX::Reflection::Variant)>,boost::_bi::list1<boost::_bi::value<RBX::Reflection::Variant> > >_0 *this)
{
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v2; // rax
  const RBX::Reflection::Type *type; // [rsp+8h] [rbp-80h] BYREF
  const rbx::implementation::type_holder *v4; // [rsp+10h] [rbp-78h]
  _BYTE v5[96]; // [rsp+18h] [rbp-70h] BYREF
  unsigned __int64 v6; // [rsp+78h] [rbp-10h]

  v6 = __readfsqword(0x28u);
  type = this->l_.a1_.t_._type;
  v4 = 0;
  holder = this->l_.a1_.t_.value.holder;
  if ( holder )
  {
    holder->construct(this->l_.a1_.t_.value.data, v5);
    v2 = this->l_.a1_.t_.value.holder;
  }
  else
  {
    v2 = 0;
  }
  v4 = v2;
  boost::function1<void,RBX::Reflection::Variant>::operator()(&this->f_, &type);
  if ( v4 )
    v4->destruct(v5);
}


// Address: 0x119a7a0 | Name: _ZN5boost3_bi6bind_tIvNS_4_mfi3mf1Iv24YieldFunctionStateObjectNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEEENS0_5list2INS0_5valueINS_10shared_ptrIS4_EEEENS_3argILi1EEEEEEclISB_EEvRKT_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,YieldFunctionStateObject,std::string >,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<YieldFunctionStateObject> >,boost::arg<1> > >::result_type __fastcall boost::_bi::bind_t<void,boost::_mfi::mf1<void,YieldFunctionStateObject,std::string>,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<YieldFunctionStateObject>>,boost::arg<1>>>::operator()<std::string>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,YieldFunctionStateObject,std::string >,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<YieldFunctionStateObject> >,boost::arg<1> > > *this,
        const std::string *a1)
{
  boost::_mfi::mf1<void,YieldFunctionStateObject,std::string >::F f; // r15
  _QWORD *v3; // r14
  _BYTE v4[16]; // [rsp+0h] [rbp-48h] BYREF
  void *v5; // [rsp+10h] [rbp-38h]
  _BYTE v6[16]; // [rsp+18h] [rbp-30h] BYREF
  void *ptr; // [rsp+28h] [rbp-20h]

  std::string::basic_string(v4, a1);
  f = this->f_.f_;
  v3 = (boost::weak_ptr<YieldFunctionStateObject>::element_type **)((char *)&this->l_.a1_.t_.px->weak_this_.px
                                                                  + *((_QWORD *)&this->f_.f_ + 1));
  if ( ((__int64)this->f_.f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,YieldFunctionStateObject,std::string >::F *)((char *)f + *v3 - 1);
  std::string::basic_string(v6, v4);
  ((void (__fastcall *)(_QWORD *, _BYTE *))f)(v3, v6);
  if ( (v6[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v4[0] & 1) != 0 )
    operator delete(v5);
}


// Address: 0x17e0570 | Name: _ZN5boost3_bi6bind_tIvNS_4_mfi3mf1IvN3RBX10GuiServiceENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEEENS0_5list2INS0_5valueINS_10shared_ptrIS5_EEEENS_3argILi1EEEEEEclISC_EEvRKT_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GuiService,std::string >,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::arg<1> > >::result_type __fastcall boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GuiService,std::string>,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService>>,boost::arg<1>>>::operator()<std::string>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GuiService,std::string >,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::arg<1> > > *this,
        const std::string *a1)
{
  boost::_mfi::mf1<void,RBX::GuiService,std::string >::F f; // r15
  _QWORD *v3; // r14
  _BYTE v4[16]; // [rsp+0h] [rbp-48h] BYREF
  void *v5; // [rsp+10h] [rbp-38h]
  _BYTE v6[16]; // [rsp+18h] [rbp-30h] BYREF
  void *ptr; // [rsp+28h] [rbp-20h]

  std::string::basic_string(v4, a1);
  f = this->f_.f_;
  v3 = (char *)this->l_.a1_.t_.px + *((_QWORD *)&this->f_.f_ + 1);
  if ( ((__int64)this->f_.f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::GuiService,std::string >::F *)((char *)f + *v3 - 1);
  std::string::basic_string(v6, v4);
  ((void (__fastcall *)(_QWORD *, _BYTE *))f)(v3, v6);
  if ( (v6[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v4[0] & 1) != 0 )
    operator delete(v5);
}


// Address: 0x187df40 | Name: _ZN5boost3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX10LogServiceEEEbENS0_5list2INS0_5valueIS5_EENS_3argILi1EEEEEEclIbEEvRT_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LogService>,bool),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::arg<1> > >::result_type __fastcall boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LogService>,bool),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService>>,boost::arg<1>>>::operator()<bool>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LogService>,bool),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::arg<1> > > *this,
        bool *a1)
{
  void (*f)(boost::weak_ptr<RBX::LogService>, bool); // rax
  boost::detail::sp_counted_base *pi; // rcx
  boost::detail::sp_counted_base *v4; // rdi
  boost::weak_ptr<RBX::LogService>::element_type *px; // [rsp+0h] [rbp-18h] BYREF
  boost::detail::sp_counted_base *v6; // [rsp+8h] [rbp-10h]

  f = this->f_;
  px = this->l_.a1_.t_.px;
  pi = this->l_.a1_.t_.pn.pi_;
  v6 = pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  ((void (__fastcall *)(boost::weak_ptr<RBX::LogService>::element_type **, bool))f)(&px, *a1);
  v4 = v6;
  if ( v6 )
  {
    if ( !_InterlockedSub(&v6->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
  }
}


