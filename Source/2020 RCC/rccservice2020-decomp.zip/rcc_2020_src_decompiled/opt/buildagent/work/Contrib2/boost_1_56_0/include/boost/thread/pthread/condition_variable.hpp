// Address: 0xdcbbf0 | Name: _ZN5boost18condition_variable4waitERNS_11unique_lockINS_5mutexEEE
void __fastcall boost::condition_variable::wait(boost::condition_variable *this, boost::unique_lock<boost::mutex> *m)
{
  int v2; // ebp
  bool set; // bl
  boost::mutex *v4; // rbx
  const boost::system::error_category *v5; // rbx
  boost::detail::interruption_checker v6; // [rsp+0h] [rbp-58h] BYREF
  const boost::system::error_category *v7; // [rsp+18h] [rbp-40h]
  __int128 v8; // [rsp+20h] [rbp-38h]
  void *ptr; // [rsp+30h] [rbp-28h]

  boost::detail::interruption_checker::interruption_checker(&v6, &this->internal_mutex, &this->cond);
  boost::unique_lock<boost::mutex>::unlock(m);
  do
    v2 = pthread_cond_wait(&this->cond, &this->internal_mutex);
  while ( v2 == 4 );
  set = v6.set;
  pthread_mutex_unlock(v6.m);
  if ( set )
  {
    v4 = (boost::mutex *)((char *)v6.thread_info + 48);
    boost::mutex::lock((boost::mutex *)((char *)v6.thread_info + 48));
    *(_OWORD *)((char *)v6.thread_info + 344) = 0;
    boost::mutex::unlock(v4);
  }
  boost::unique_lock<boost::mutex>::lock(m);
  boost::this_thread::interruption_point();
  if ( v2 )
  {
    v5 = boost::system::system_category();
    std::runtime_error::runtime_error(
      (std::runtime_error *)&v6,
      "boost::condition_variable::wait failed in pthread_cond_wait");
    *(_DWORD *)&v6.set = v2;
    v7 = v5;
    v8 = 0;
    ptr = 0;
    v6.thread_info = (boost::detail::thread_data_base *const)off_2878558;
    boost::throw_exception<boost::condition_error>((const boost::condition_error *)&v6);
  }
}


// Address: 0x11d8360 | Name: _ZN5boost18condition_variable13do_wait_untilERNS_11unique_lockINS_5mutexEEERK8timespec
bool __fastcall boost::condition_variable::do_wait_until(
        boost::condition_variable *this,
        boost::unique_lock<boost::mutex> *m,
        const timespec *timeout)
{
  int v4; // ebp
  bool set; // bl
  boost::mutex *v6; // rbx
  bool v7; // bl
  const boost::system::error_category *v9; // rbx
  boost::detail::interruption_checker v10; // [rsp+8h] [rbp-60h] BYREF
  const boost::system::error_category *v11; // [rsp+20h] [rbp-48h]
  __int128 v12; // [rsp+28h] [rbp-40h]
  void *ptr; // [rsp+38h] [rbp-30h]

  boost::detail::interruption_checker::interruption_checker(&v10, &this->internal_mutex, &this->cond);
  boost::unique_lock<boost::mutex>::unlock(m);
  v4 = pthread_cond_timedwait(&this->cond, &this->internal_mutex, timeout);
  set = v10.set;
  pthread_mutex_unlock(v10.m);
  if ( set )
  {
    v6 = (boost::mutex *)((char *)v10.thread_info + 48);
    boost::mutex::lock((boost::mutex *)((char *)v10.thread_info + 48));
    *(_OWORD *)((char *)v10.thread_info + 344) = 0;
    boost::mutex::unlock(v6);
  }
  boost::this_thread::interruption_point();
  if ( v4 )
  {
    if ( v4 != 110 )
    {
      v9 = boost::system::system_category();
      std::runtime_error::runtime_error(
        (std::runtime_error *)&v10,
        "boost::condition_variable::do_wait_until failed in pthread_cond_timedwait");
      *(_DWORD *)&v10.set = v4;
      v11 = v9;
      v12 = 0;
      ptr = 0;
      v10.thread_info = (boost::detail::thread_data_base *const)off_2878558;
      boost::throw_exception<boost::condition_error>((const boost::condition_error *)&v10);
    }
    v7 = 0;
  }
  else
  {
    v7 = 1;
  }
  boost::unique_lock<boost::mutex>::lock(m);
  return v7;
}


// Address: 0x27c93e0 | Name: _ZN5boost22condition_variable_anyC2Ev
void __fastcall boost::condition_variable_any::condition_variable_any(boost::condition_variable_any *this)
{
  int v1; // eax
  int v2; // ebp
  const boost::system::error_category *v3; // rbx
  const boost::system::error_category *v4; // rbx
  _QWORD v5[2]; // [rsp+8h] [rbp-50h] BYREF
  int v6; // [rsp+18h] [rbp-40h]
  const boost::system::error_category *v7; // [rsp+20h] [rbp-38h]
  __int128 v8; // [rsp+28h] [rbp-30h]
  void *ptr; // [rsp+38h] [rbp-20h]

  v1 = pthread_mutex_init(&this->internal_mutex, 0);
  if ( v1 )
  {
    v2 = v1;
    v3 = boost::system::system_category();
    std::runtime_error::runtime_error(
      (std::runtime_error *)v5,
      "boost::condition_variable_any::condition_variable_any() failed in pthread_mutex_init");
    v6 = v2;
    v7 = v3;
    v8 = 0;
    ptr = 0;
    v5[0] = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)v5);
  }
  if ( pthread_cond_init(&this->cond, 0) )
  {
    pthread_mutex_destroy(&this->internal_mutex);
    v4 = boost::system::system_category();
    std::runtime_error::runtime_error(
      (std::runtime_error *)v5,
      "boost::condition_variable_any::condition_variable_any() failed in pthread_cond_init");
    v6 = 0;
    v7 = v4;
    v8 = 0;
    ptr = 0;
    v5[0] = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)v5);
  }
}


// Address: 0x27c9650 | Name: _ZN5boost22condition_variable_any4waitINS_11unique_lockINS_5mutexEEEEEvRT_
void __fastcall boost::condition_variable_any::wait<boost::unique_lock<boost::mutex>>(
        boost::condition_variable_any *this,
        boost::unique_lock<boost::mutex> *m)
{
  int v2; // r14d
  bool set; // bl
  boost::mutex *v4; // rbx
  const boost::system::error_category *v5; // rbx
  boost::detail::interruption_checker v6; // [rsp+8h] [rbp-60h] BYREF
  const boost::system::error_category *v7; // [rsp+20h] [rbp-48h]
  __int128 v8; // [rsp+28h] [rbp-40h]
  void *ptr; // [rsp+38h] [rbp-30h]

  boost::detail::interruption_checker::interruption_checker(&v6, &this->internal_mutex, &this->cond);
  boost::unique_lock<boost::mutex>::unlock(m);
  v2 = pthread_cond_wait(&this->cond, &this->internal_mutex);
  set = v6.set;
  pthread_mutex_unlock(v6.m);
  if ( set )
  {
    v4 = (boost::mutex *)((char *)v6.thread_info + 48);
    boost::mutex::lock((boost::mutex *)((char *)v6.thread_info + 48));
    *(_OWORD *)((char *)v6.thread_info + 344) = 0;
    boost::mutex::unlock(v4);
  }
  boost::unique_lock<boost::mutex>::lock(m);
  boost::this_thread::interruption_point();
  if ( v2 )
  {
    v5 = boost::system::system_category();
    std::runtime_error::runtime_error(
      (std::runtime_error *)&v6,
      "boost::condition_variable_any::wait() failed in pthread_cond_wait");
    *(_DWORD *)&v6.set = v2;
    v7 = v5;
    v8 = 0;
    ptr = 0;
    v6.thread_info = (boost::detail::thread_data_base *const)off_2878558;
    boost::throw_exception<boost::condition_error>((const boost::condition_error *)&v6);
  }
}


