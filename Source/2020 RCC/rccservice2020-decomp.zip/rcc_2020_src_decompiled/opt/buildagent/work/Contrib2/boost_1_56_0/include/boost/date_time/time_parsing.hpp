// Address: 0x186af00 | Name: _ZN5boost9date_time32str_from_delimited_time_durationINS_10posix_time13time_durationEcEET_RKNSt3__112basic_stringIT0_NS5_11char_traitsIS7_EENS5_9allocatorIS7_EEEE
boost::posix_time::time_duration __fastcall boost::date_time::str_from_delimited_time_duration<boost::posix_time::time_duration,char>(
        __int64 *a1,
        const std::string *s,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  char v6; // r15
  char v7; // al
  char *v8; // rcx
  unsigned __int64 v9; // rdx
  __int64 v10; // r14
  int v11; // r13d
  bool v12; // bl
  bool v13; // zf
  unsigned __int64 *v14; // rcx
  unsigned __int64 v15; // rax
  unsigned __int64 *v16; // rcx
  unsigned __int64 v17; // rax
  unsigned __int64 v18; // r15
  unsigned __int64 *v19; // rcx
  unsigned __int64 v20; // rax
  const char *v21; // rax
  char v22; // bl
  bool v23; // al
  const char *v24; // rax
  const char *v25; // rcx
  char v26; // r12
  bool v27; // al
  bool v28; // dl
  __m128i si128; // xmm4
  unsigned __int64 v30; // r14
  unsigned int v31; // ecx
  int v32; // edx
  unsigned int v33; // eax
  const char *v34; // rcx
  unsigned __int64 v35; // rax
  const char *v36; // rax
  char v37; // bl
  bool v38; // al
  bool v39; // dl
  __int64 v40; // rax
  const char *v41; // rax
  char v42; // bl
  bool v43; // al
  const char *v44; // rax
  char v45; // bl
  bool v46; // al
  bool v47; // dl
  int v48; // edx
  __m128i v49; // xmm0
  __m128i v50; // xmm1
  __m128i v51; // xmm3
  unsigned int v52; // esi
  int v53; // edx
  __m128i v54; // xmm1
  __m128i v55; // xmm0
  __m128i v56; // xmm1
  int v57; // ecx
  bool v58; // cl
  __int64 v59; // rcx
  __int64 v60; // rax
  __int64 v61; // rax
  __int64 v62; // rax
  __int64 v63; // rcx
  __int64 v64; // rcx
  __int64 *v65; // rbx
  char v67; // [rsp+7h] [rbp-1F1h]
  unsigned __int64 v68; // [rsp+8h] [rbp-1F0h] BYREF
  unsigned __int64 v69; // [rsp+10h] [rbp-1E8h]
  void *v70; // [rsp+18h] [rbp-1E0h]
  __int64 v71; // [rsp+20h] [rbp-1D8h]
  __int64 v72; // [rsp+28h] [rbp-1D0h]
  char dropped_delims[8]; // [rsp+30h] [rbp-1C8h] BYREF
  boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned long,char> v74; // [rsp+38h] [rbp-1C0h] BYREF
  void *v75; // [rsp+60h] [rbp-198h]
  const char *v76; // [rsp+78h] [rbp-180h]
  const char *v77; // [rsp+80h] [rbp-178h]
  char v78; // [rsp+88h] [rbp-170h]
  char v79; // [rsp+90h] [rbp-168h]
  void *ptr; // [rsp+A0h] [rbp-158h]
  __int64 *v81; // [rsp+A8h] [rbp-150h]
  _BYTE *v82; // [rsp+B0h] [rbp-148h]
  __int64 v83; // [rsp+B8h] [rbp-140h]
  _BYTE v84[16]; // [rsp+C0h] [rbp-138h] BYREF
  void *v85; // [rsp+D0h] [rbp-128h]
  char v86; // [rsp+D8h] [rbp-120h]
  void *v87; // [rsp+E8h] [rbp-110h]
  std::__wrap_iter<const char *> next; // [rsp+100h] [rbp-F8h] BYREF
  std::__wrap_iter<const char *> end; // [rsp+108h] [rbp-F0h]
  char v90; // [rsp+110h] [rbp-E8h]
  unsigned __int8 v91; // [rsp+118h] [rbp-E0h] BYREF
  _BYTE v92[7]; // [rsp+119h] [rbp-DFh] BYREF
  unsigned __int64 v93; // [rsp+120h] [rbp-D8h]
  void *v94; // [rsp+128h] [rbp-D0h]
  unsigned __int64 v95; // [rsp+130h] [rbp-C8h] BYREF
  _QWORD v96[2]; // [rsp+138h] [rbp-C0h] BYREF
  char v97[16]; // [rsp+148h] [rbp-B0h] BYREF
  void *v98; // [rsp+158h] [rbp-A0h]
  char v99[16]; // [rsp+160h] [rbp-98h] BYREF
  void *v100; // [rsp+170h] [rbp-88h]
  __int64 v101; // [rsp+178h] [rbp-80h]
  char v102; // [rsp+180h] [rbp-78h]
  _BYTE v103[16]; // [rsp+188h] [rbp-70h] BYREF
  void *v104; // [rsp+198h] [rbp-60h]
  _BYTE v105[16]; // [rsp+1A0h] [rbp-58h] BYREF
  void *v106; // [rsp+1B0h] [rbp-48h]
  __int64 v107; // [rsp+1B8h] [rbp-40h]
  char v108; // [rsp+1C0h] [rbp-38h]

  v6 = *(_BYTE *)std::string::at(s, 0, a3, a4, a5, a6);
  strcpy(dropped_delims, "-:,.");
  boost::char_separator<char,std::char_traits<char>>::char_separator(
    (boost::char_separator<char,std::char_traits<char> > *)v103,
    dropped_delims,
    0,
    boost::empty_token_policy::drop_empty_tokens);
  v7 = *(_BYTE *)s;
  v8 = (char *)s + 1;
  v9 = (unsigned __int64)*(unsigned __int8 *)s >> 1;
  if ( (*(_BYTE *)s & 1) != 0 )
    v8 = (char *)*((_QWORD *)s + 2);
  v96[0] = v8;
  if ( (v7 & 1) != 0 )
    v9 = *((_QWORD *)s + 1);
  v96[1] = &v8[v9];
  std::string::basic_string(v97, v103);
  v82 = v105;
  std::string::basic_string(v99, v105);
  v67 = v6;
  v81 = a1;
  v102 = v108;
  v101 = v107;
  boost::tokenizer<boost::char_separator<char,std::char_traits<char>>,std::__wrap_iter<char const*>,std::string>::begin(
    (boost::char_separator<char,std::char_traits<char> > *)v84,
    (const boost::tokenizer<boost::char_separator<char,std::char_traits<char> >,std::__wrap_iter<const char *>,std::string > *)v96);
  v83 = 0;
  v10 = 0;
  v11 = 0;
  v72 = 0;
  v71 = 0;
  while ( 1 )
  {
    boost::tokenizer<boost::char_separator<char,std::char_traits<char>>,std::__wrap_iter<char const*>,std::string>::end(
      (__int64)&v74,
      (const boost::tokenizer<boost::char_separator<char,std::char_traits<char> >,std::__wrap_iter<const char *>,std::string > *)v96);
    if ( !v78 || !v90 )
    {
      v13 = v78 == v90;
      goto LABEL_13;
    }
    if ( v76 == next.__i )
    {
      v13 = v77 == end.__i;
LABEL_13:
      v12 = v13;
      if ( (v79 & 1) == 0 )
        goto LABEL_15;
LABEL_14:
      operator delete(ptr);
      goto LABEL_15;
    }
    v12 = 0;
    if ( (v79 & 1) != 0 )
      goto LABEL_14;
LABEL_15:
    if ( ((__int64)v74.m_begin & 1) != 0 )
      break;
    if ( v74.m_multiplier_overflowed )
      goto LABEL_20;
LABEL_17:
    if ( v12 )
      goto LABEL_104;
LABEL_21:
    if ( (v11 & 0x7FFFFFFFu) <= 3 )
    {
      switch ( v11 & 0x7FFFFFFF )
      {
        case 0:
          if ( (v91 & 1) != 0 )
          {
            v14 = (unsigned __int64 *)v94;
            v15 = v93;
            if ( !v93 )
              goto LABEL_143;
          }
          else
          {
            v15 = (unsigned __int64)v91 >> 1;
            v14 = (unsigned __int64 *)v92;
            if ( !v15 )
              goto LABEL_143;
          }
          v36 = (char *)v14 + v15;
          LODWORD(v68) = 0;
          v37 = *(_BYTE *)v14;
          if ( *(_BYTE *)v14 == 45 || v37 == 43 )
            v14 = (unsigned __int64 *)((char *)v14 + 1);
          v74.m_multiplier_overflowed = 0;
          *((_DWORD *)&v74.m_multiplier_overflowed + 1) = 1;
          v74.m_multiplier = (unsigned __int64)&v68;
          v74.m_value = v14;
          v74.m_begin = v36;
          v38 = boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned int,char>::convert((boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned int,char> *)&v74);
          v39 = (unsigned int)v68 < 0x80000001;
          if ( v37 != 45 )
            v39 = (v68 & 0x80000000) == 0LL;
          if ( !v39 || !v38 )
          {
LABEL_143:
            std::bad_cast::bad_cast((std::bad_cast *)&v74);
            *(_QWORD *)&v74.m_multiplier_overflowed = off_287BC88;
            *(__m128i *)&v74.m_multiplier = _mm_unpacklo_epi64(
                                              (__m128i)(unsigned __int64)&`typeinfo for'std::string,
                                              _mm_loadl_epi64((const __m128i *)&`typeinfo for'int));
            boost::throw_exception<boost::bad_lexical_cast>((const boost::bad_lexical_cast *)&v74);
          }
          v40 = (unsigned int)-(int)v68;
          if ( v37 != 45 )
            v40 = (unsigned int)v68;
          v83 = v40;
          break;
        case 1:
          if ( (v91 & 1) != 0 )
          {
            v19 = (unsigned __int64 *)v94;
            v20 = v93;
            if ( !v93 )
              goto LABEL_145;
          }
          else
          {
            v20 = (unsigned __int64)v91 >> 1;
            v19 = (unsigned __int64 *)v92;
            if ( !v20 )
              goto LABEL_145;
          }
          v41 = (char *)v19 + v20;
          v42 = *(_BYTE *)v19;
          if ( *(_BYTE *)v19 == 45 || v42 == 43 )
            v19 = (unsigned __int64 *)((char *)v19 + 1);
          v74.m_multiplier_overflowed = 0;
          *((_WORD *)&v74.m_multiplier_overflowed + 1) = 1;
          v74.m_multiplier = (unsigned __int64)&v68;
          v74.m_value = v19;
          v74.m_begin = v41;
          v43 = boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned short,char>::convert((boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned short,char> *)&v74);
          if ( v42 == 45 )
          {
            v71 = (unsigned __int16)-(__int16)v68;
            LOWORD(v68) = -(__int16)v68;
            if ( !v43 )
              goto LABEL_145;
          }
          else
          {
            if ( !v43 )
            {
LABEL_145:
              std::bad_cast::bad_cast((std::bad_cast *)&v74);
              *(_QWORD *)&v74.m_multiplier_overflowed = off_287BC88;
              *(__m128i *)&v74.m_multiplier = _mm_unpacklo_epi64(
                                                (__m128i)(unsigned __int64)&`typeinfo for'std::string,
                                                _mm_loadl_epi64((const __m128i *)&`typeinfo for'unsigned short));
              boost::throw_exception<boost::bad_lexical_cast>((const boost::bad_lexical_cast *)&v74);
            }
            v71 = (unsigned __int16)v68;
          }
          break;
        case 2:
          if ( (v91 & 1) != 0 )
          {
            v16 = (unsigned __int64 *)v94;
            v17 = v93;
            if ( !v93 )
              goto LABEL_144;
          }
          else
          {
            v17 = (unsigned __int64)v91 >> 1;
            v16 = (unsigned __int64 *)v92;
            if ( !v17 )
              goto LABEL_144;
          }
          v21 = (char *)v16 + v17;
          v22 = *(_BYTE *)v16;
          if ( *(_BYTE *)v16 == 45 || v22 == 43 )
            v16 = (unsigned __int64 *)((char *)v16 + 1);
          v74.m_multiplier_overflowed = 0;
          *((_WORD *)&v74.m_multiplier_overflowed + 1) = 1;
          v74.m_multiplier = (unsigned __int64)&v68;
          v74.m_value = v16;
          v74.m_begin = v21;
          v23 = boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned short,char>::convert((boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned short,char> *)&v74);
          if ( v22 == 45 )
          {
            v72 = (unsigned __int16)-(__int16)v68;
            LOWORD(v68) = -(__int16)v68;
            if ( !v23 )
              goto LABEL_144;
          }
          else
          {
            if ( !v23 )
            {
LABEL_144:
              std::bad_cast::bad_cast((std::bad_cast *)&v74);
              *(_QWORD *)&v74.m_multiplier_overflowed = off_287BC88;
              *(__m128i *)&v74.m_multiplier = _mm_unpacklo_epi64(
                                                (__m128i)(unsigned __int64)&`typeinfo for'std::string,
                                                _mm_loadl_epi64((const __m128i *)&`typeinfo for'unsigned short));
              boost::throw_exception<boost::bad_lexical_cast>((const boost::bad_lexical_cast *)&v74);
            }
            v72 = (unsigned __int16)v68;
          }
          break;
        case 3:
          if ( (v91 & 1) != 0 )
            v18 = v93;
          else
            v18 = (unsigned __int64)v91 >> 1;
          if ( (int)v18 < 6 )
          {
            v24 = v92;
            if ( (v91 & 1) != 0 )
              v24 = (const char *)v94;
            if ( !v18 )
              goto LABEL_147;
            v25 = &v24[v18];
            v68 = 0;
            v26 = *v24;
            if ( *v24 == 45 || v26 == 43 )
              ++v24;
            v74.m_multiplier_overflowed = 0;
            v74.m_multiplier = 1;
            v74.m_value = &v68;
            v74.m_begin = v24;
            v74.m_end = v25;
            v27 = boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned long,char>::convert(&v74);
            v28 = v68 < 0x8000000000000001LL;
            si128 = _mm_load_si128((const __m128i *)&xmmword_3EA550);
            if ( v26 != 45 )
              v28 = (v68 & 0x8000000000000000LL) == 0LL;
            if ( !v28 || !v27 )
            {
LABEL_147:
              std::bad_cast::bad_cast((std::bad_cast *)&v74);
              *(_QWORD *)&v74.m_multiplier_overflowed = off_287BC88;
              *(__m128i *)&v74.m_multiplier = _mm_unpacklo_epi64(
                                                (__m128i)(unsigned __int64)&`typeinfo for'std::string,
                                                _mm_loadl_epi64((const __m128i *)&`typeinfo for'long));
              boost::throw_exception<boost::bad_lexical_cast>((const boost::bad_lexical_cast *)&v74);
            }
            v30 = -(__int64)v68;
            if ( v26 != 45 )
              v30 = v68;
            v31 = 6 - v18;
            if ( (int)v18 >= 6 )
            {
              v32 = 1;
            }
            else
            {
              if ( v31 < 8 )
              {
                v32 = 1;
                v33 = 0;
                goto LABEL_100;
              }
              v33 = v31 & 0xFFFFFFF8;
              v48 = ((unsigned __int8)(((v31 & 0xFFFFFFF8) - 8) >> 3) + 1) & 7;
              v49 = _mm_load_si128((const __m128i *)&xmmword_3EA800);
              v50 = v49;
              v51 = _mm_load_si128((const __m128i *)&xmmword_3EA0E0);
              if ( (v31 & 0xFFFFFFF8) - 8 >= 0x38 )
              {
                v52 = v48 - ((((v31 & 0xFFFFFFF8) - 8) >> 3) + 1);
                v49 = _mm_load_si128((const __m128i *)&xmmword_3EA800);
                v50 = v49;
                do
                {
                  v49 = _mm_unpacklo_epi32(
                          _mm_shuffle_epi32(_mm_mul_epu32(v49, si128), 232),
                          _mm_shuffle_epi32(_mm_mul_epu32(_mm_shuffle_epi32(v49, 245), si128), 232));
                  v50 = _mm_unpacklo_epi32(
                          _mm_shuffle_epi32(_mm_mul_epu32(v50, si128), 232),
                          _mm_shuffle_epi32(_mm_mul_epu32(_mm_shuffle_epi32(v50, 245), si128), 232));
                  v52 += 8;
                }
                while ( v52 );
              }
              if ( (((unsigned __int8)(((v31 & 0xFFFFFFF8) - 8) >> 3) + 1) & 7) != 0 )
              {
                v53 = -v48;
                do
                {
                  v49 = _mm_unpacklo_epi32(
                          _mm_shuffle_epi32(_mm_mul_epu32(v49, v51), 232),
                          _mm_shuffle_epi32(_mm_mul_epu32(_mm_shuffle_epi32(v49, 245), v51), 232));
                  v50 = _mm_unpacklo_epi32(
                          _mm_shuffle_epi32(_mm_mul_epu32(v50, v51), 232),
                          _mm_shuffle_epi32(_mm_mul_epu32(_mm_shuffle_epi32(v50, 245), v51), 232));
                  ++v53;
                }
                while ( v53 );
              }
              v54 = _mm_unpacklo_epi32(
                      _mm_shuffle_epi32(_mm_mul_epu32(v50, v49), 232),
                      _mm_shuffle_epi32(_mm_mul_epu32(_mm_shuffle_epi32(v49, 245), _mm_shuffle_epi32(v50, 245)), 232));
              v55 = _mm_shuffle_epi32(v54, 78);
              v56 = _mm_unpacklo_epi32(
                      _mm_shuffle_epi32(_mm_mul_epu32(v54, v55), 232),
                      _mm_shuffle_epi32(_mm_mul_epu32(_mm_shuffle_epi32(v55, 245), _mm_shuffle_epi32(v54, 245)), 232));
              v32 = _mm_cvtsi128_si32(_mm_mul_epu32(_mm_shuffle_epi32(v56, 229), v56));
              if ( v31 != v33 )
              {
LABEL_100:
                v57 = 6 - v33 - v18;
                do
                {
                  v32 *= 10;
                  --v57;
                }
                while ( v57 );
              }
            }
            v10 = v32 * v30;
            break;
          }
          std::string::basic_string(&v68, &v91, 0, 6, &v91);
          if ( (v68 & 1) != 0 )
          {
            v34 = (const char *)v70;
            v35 = v69;
            if ( !v69 )
              goto LABEL_146;
          }
          else
          {
            v35 = (unsigned __int64)(unsigned __int8)v68 >> 1;
            v34 = (char *)&v68 + 1;
            if ( !v35 )
              goto LABEL_146;
          }
          v44 = &v34[v35];
          v95 = 0;
          v45 = *v34;
          if ( *v34 == 45 || v45 == 43 )
            ++v34;
          v74.m_multiplier_overflowed = 0;
          v74.m_multiplier = 1;
          v74.m_value = &v95;
          v74.m_begin = v34;
          v74.m_end = v44;
          v46 = boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned long,char>::convert(&v74);
          v47 = v95 < 0x8000000000000001LL;
          if ( v45 != 45 )
            v47 = (v95 & 0x8000000000000000LL) == 0LL;
          if ( !v47 || !v46 )
          {
LABEL_146:
            std::bad_cast::bad_cast((std::bad_cast *)&v74);
            *(_QWORD *)&v74.m_multiplier_overflowed = off_287BC88;
            *(__m128i *)&v74.m_multiplier = _mm_unpacklo_epi64(
                                              (__m128i)(unsigned __int64)&`typeinfo for'std::string,
                                              _mm_loadl_epi64((const __m128i *)&`typeinfo for'long));
            boost::throw_exception<boost::bad_lexical_cast>((const boost::bad_lexical_cast *)&v74);
          }
          v10 = -(__int64)v95;
          if ( v45 != 45 )
            v10 = v95;
          if ( (v68 & 1) != 0 )
            operator delete(v70);
          break;
      }
    }
    ++v11;
    v90 = boost::char_separator<char,std::char_traits<char>>::operator()<std::__wrap_iter<char const*>,std::string>(
            (boost::char_separator<char,std::char_traits<char> > *)v84,
            &next,
            end,
            (std::string *)&v91);
  }
  operator delete(v75);
  if ( !v74.m_multiplier_overflowed )
    goto LABEL_17;
LABEL_20:
  operator delete(v74.m_value);
  if ( !v12 )
    goto LABEL_21;
LABEL_104:
  if ( (v91 & 1) != 0 )
    operator delete(v94);
  if ( (v86 & 1) != 0 )
    operator delete(v87);
  if ( (v84[0] & 1) != 0 )
    operator delete(v85);
  v58 = (int)v83 < 0 || v10 < 0;
  if ( v67 == 45 )
  {
    if ( v58 )
    {
      v59 = -v10;
      if ( -v10 < 1 )
        v59 = v10;
      v60 = (unsigned int)-(int)v83;
      if ( -(int)v83 < 1 )
        v60 = (unsigned int)v83;
      v61 = -(v59 + 1000000 * (60LL * (unsigned __int16)v71 + 3600 * v60 + (unsigned __int16)v72));
    }
    else
    {
      v61 = v10 + 1000000 * (60LL * (unsigned __int16)v71 + 3600LL * (int)v83 + (unsigned __int16)v72);
    }
    v65 = v81;
    if ( (unsigned __int64)(v61 - 0x7FFFFFFFFFFFFFFELL) > 2 )
    {
      v64 = -v61;
    }
    else
    {
      v64 = 0x7FFFFFFFFFFFFFFELL;
      if ( v61 == 0x7FFFFFFFFFFFFFFFLL )
        v64 = 0x8000000000000000LL;
      if ( v61 == 0x8000000000000000LL )
        v64 = 0x7FFFFFFFFFFFFFFFLL;
    }
  }
  else
  {
    if ( v58 )
    {
      v62 = -v10;
      if ( -v10 < 1 )
        v62 = v10;
      v63 = (unsigned int)-(int)v83;
      if ( -(int)v83 < 1 )
        v63 = (unsigned int)v83;
      v64 = -(v62 + 1000000 * (60LL * (unsigned __int16)v71 + 3600 * v63 + (unsigned __int16)v72));
    }
    else
    {
      v64 = v10 + 1000000 * (60LL * (unsigned __int16)v71 + 3600LL * (int)v83 + (unsigned __int16)v72);
    }
    v65 = v81;
  }
  *v65 = v64;
  if ( (v99[0] & 1) != 0 )
  {
    operator delete(v100);
    if ( (v97[0] & 1) != 0 )
      goto LABEL_140;
LABEL_135:
    if ( (v105[0] & 1) == 0 )
      goto LABEL_136;
LABEL_141:
    operator delete(v106);
    if ( (v103[0] & 1) != 0 )
LABEL_137:
      operator delete(v104);
  }
  else
  {
    if ( (v97[0] & 1) == 0 )
      goto LABEL_135;
LABEL_140:
    operator delete(v98);
    if ( (v105[0] & 1) != 0 )
      goto LABEL_141;
LABEL_136:
    if ( (v103[0] & 1) != 0 )
      goto LABEL_137;
  }
  return (boost::posix_time::time_duration)v65;
}


