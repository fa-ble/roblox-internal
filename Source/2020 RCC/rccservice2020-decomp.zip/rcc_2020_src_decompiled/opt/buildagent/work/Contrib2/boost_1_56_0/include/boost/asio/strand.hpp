// Address: 0x26076d0 | Name: _ZN5boost4asio10io_service6strand8dispatchINS0_6detail7binder1INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config15asio_tls_client16transport_configEEEFvNS6_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISJ_EENS0_22deadline_timer_serviceISJ_SL_EEEEEENS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNSG_ISF_EERSP_RSV_RKNS6_12placeholders4__phILi1EEEEEESX_EEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS1E_
boost::asio::async_result<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::type __fastcall boost::asio::io_service::strand::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
        boost::asio::io_service::strand *this,
        boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v9; // rbx
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> v10; // [rsp+0h] [rbp-A8h] BYREF
  unsigned __int64 v11; // [rsp+88h] [rbp-20h]

  v11 = __readfsqword(0x28u);
  *(_OWORD *)&v10.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v10.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  v10.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      v10.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *))f->handler_.__f_
       + 3))(
        f,
        &v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        v2,
        v3,
        v4,
        v5,
        v10.handler_.__f_,
        *((_QWORD *)&v10.handler_.__f_ + 1),
        v10.handler_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v10.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v10.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v10.arg1_ = handler->arg1_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
    this->service_,
    &this->impl_,
    &v10);
  if ( &v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v10.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v10.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v10.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v10.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v10.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v10.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v10.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v9 = v10.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
      std::__shared_weak_count::__release_weak(v9);
    }
  }
}


// Address: 0x260fda0 | Name: _ZN5boost4asio10io_service6strand8dispatchINS0_6detail17rewrapped_handlerINS4_15wrapped_handlerIS2_NSt3__18functionIFvvEEENS4_26is_continuation_if_runningEEESA_EEEENS0_12async_resultINS0_12handler_typeIT_S9_E4typeEE4typeEOSG_
boost::asio::async_result<boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > >::type __fastcall boost::asio::io_service::strand::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>,std::function<void ()(void)>>>(
        boost::asio::io_service::strand *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *handler)
{
  boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *f; // rdi
  boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *v4; // rdi
  boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > v5; // [rsp+0h] [rbp-A8h] BYREF
  unsigned __int64 v6; // [rsp+80h] [rbp-28h]

  v6 = __readfsqword(0x28u);
  f = (boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *)handler->context_.__f_;
  if ( f )
  {
    if ( handler == f )
    {
      v5.context_.__f_ = (std::function<void ()>::__base *)&v5;
      (*(void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *))(*(_QWORD *)f->context_.__buf_.__lx + 24LL))(f);
    }
    else
    {
      v5.context_.__f_ = handler->context_.__f_;
      handler->context_.__f_ = 0;
    }
  }
  else
  {
    v5.context_.__f_ = 0;
  }
  v5.handler_.dispatcher_ = handler->handler_.dispatcher_;
  v4 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *)handler->handler_.handler_.__f_;
  if ( v4 )
  {
    if ( &handler->handler_.handler_ == (std::function<void ()> *)v4 )
    {
      v5.handler_.handler_.__f_ = (std::function<void ()>::__base *)&v5.handler_.handler_;
      (*(void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *, std::function<void ()> *))(*(_QWORD *)v4->context_.__buf_.__lx + 24LL))(
        v4,
        &v5.handler_.handler_);
    }
    else
    {
      v5.handler_.handler_.__f_ = handler->handler_.handler_.__f_;
      handler->handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    v5.handler_.handler_.__f_ = 0;
  }
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>,std::function<void ()(void)>>>(
    this->service_,
    &this->impl_,
    &v5);
  if ( &v5.handler_.handler_ == (std::function<void ()> *)v5.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void ()>::__base *))v5.handler_.handler_.__f_->_vptr$__base + 4))(v5.handler_.handler_.__f_);
  }
  else if ( v5.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v5.handler_.handler_.__f_->_vptr$__base + 5))();
  }
  if ( &v5 == (boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *)v5.context_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void ()>::__base *))v5.context_.__f_->_vptr$__base + 4))(v5.context_.__f_);
  }
  else if ( v5.context_.__f_ )
  {
    (*((void (**)(void))v5.context_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x26104a0 | Name: _ZN5boost4asio10io_service6strand8dispatchINSt3__18functionIFvvEEEEENS0_12async_resultINS0_12handler_typeIT_S6_E4typeEE4typeEOSA_
boost::asio::async_result<std::function<void ()> >::type __fastcall boost::asio::io_service::strand::dispatch<std::function<void ()(void)>>(
        boost::asio::io_service::strand *this,
        std::function<void ()> *handler)
{
  std::function<void ()> *f; // rdi
  std::function<void ()> v4; // [rsp+0h] [rbp-58h] BYREF
  unsigned __int64 v5; // [rsp+40h] [rbp-18h]

  v5 = __readfsqword(0x28u);
  f = (std::function<void ()> *)handler->__f_;
  if ( f )
  {
    if ( handler == f )
    {
      v4.__f_ = (std::function<void ()>::__base *)&v4;
      (*(void (__fastcall **)(std::function<void ()> *))(*(_QWORD *)f->__buf_.__lx + 24LL))(f);
    }
    else
    {
      v4.__f_ = handler->__f_;
      handler->__f_ = 0;
    }
  }
  else
  {
    v4.__f_ = 0;
  }
  boost::asio::detail::strand_service::dispatch<std::function<void ()(void)>>(this->service_, &this->impl_, &v4);
  if ( &v4 == (std::function<void ()> *)v4.__f_ )
  {
    (*((void (__fastcall **)(std::function<void ()>::__base *))v4.__f_->_vptr$__base + 4))(v4.__f_);
  }
  else if ( v4.__f_ )
  {
    (*((void (**)(void))v4.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x2619ab0 | Name: _ZN5boost4asio10io_service6strand8dispatchINS0_6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config15asio_tls_client16transport_configEEEFvRKNS_6system10error_codeEmEJNS6_10shared_ptrISF_EERKNS6_12placeholders4__phILi1EEERKNSP_ILi2EEEEEESH_mEEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS10_
boost::asio::async_result<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> >::type __fastcall boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::io_service::strand *this,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> v3; // [rsp+0h] [rbp-58h] BYREF

  *(_OWORD *)&v3.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v3.handler_.__bound_args_ = handler->handler_.__bound_args_;
  handler->handler_.__bound_args_ = 0;
  v3.arg2_ = handler->arg2_;
  v3.arg1_ = handler->arg1_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
    this->service_,
    &this->impl_,
    &v3);
  cntrl = v3.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v3.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v3.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x262b6d0 | Name: _ZN5boost4asio10io_service6strand8dispatchINS0_6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config15asio_tls_client16transport_configEEEFvNS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNS6_10shared_ptrISF_EERSL_RKNS6_12placeholders4__phILi1EEEEEESN_mEEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS14_
boost::asio::async_result<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> >::type __fastcall boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::io_service::strand *this,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> v9; // [rsp+0h] [rbp-A8h] BYREF
  unsigned __int64 v10; // [rsp+88h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  *(_OWORD *)&v9.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v9.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *))f->handler_.__f_
       + 3))(
        f,
        &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v2,
        v3,
        v4,
        v5,
        v9.handler_.__f_,
        *((_QWORD *)&v9.handler_.__f_ + 1),
        v9.handler_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v9.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v9.arg2_ = handler->arg2_;
  v9.arg1_ = handler->arg1_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>(
    this->service_,
    &this->impl_,
    &v9);
  if ( &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v9.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v9.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v9.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x262e640 | Name: _ZN5boost4asio10io_service6strand8dispatchINS0_6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config15asio_tls_client16transport_configEEEFvNS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEmEJNS6_10shared_ptrISF_EERSL_RKNS6_12placeholders4__phILi1EEERKNSW_ILi2EEEEEESN_mEEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS17_
boost::asio::async_result<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> >::type __fastcall boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::io_service::strand *this,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> v9; // [rsp+0h] [rbp-A8h] BYREF
  unsigned __int64 v10; // [rsp+88h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  *(_OWORD *)&v9.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v9.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *))f->handler_.__f_
       + 3))(
        f,
        &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v2,
        v3,
        v4,
        v5,
        v9.handler_.__f_,
        *((_QWORD *)&v9.handler_.__f_ + 1),
        v9.handler_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v9.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v9.arg2_ = handler->arg2_;
  v9.arg1_ = handler->arg1_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
    this->service_,
    &this->impl_,
    &v9);
  if ( &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v9.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v9.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v9.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26360a0 | Name: _ZN5boost4asio10io_service6strand8dispatchINS0_6detail7binder1INSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNS6_10shared_ptrISC_EERSI_RKNS6_12placeholders4__phILi1EEEEEESK_EEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS11_
boost::asio::async_result<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::type __fastcall boost::asio::io_service::strand::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
        boost::asio::io_service::strand *this,
        boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> v9; // [rsp+0h] [rbp-98h] BYREF
  unsigned __int64 v10; // [rsp+78h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  *(_OWORD *)&v9.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v9.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>::element_type *))f->handler_.__f_
       + 3))(
        f,
        &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v2,
        v3,
        v4,
        v5,
        v9.handler_.__f_,
        *((_QWORD *)&v9.handler_.__f_ + 1),
        v9.handler_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v9.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v9.arg1_ = handler->arg1_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
    this->service_,
    &this->impl_,
    &v9);
  if ( &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v9.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v9.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v9.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x2657930 | Name: _ZN5boost4asio10io_service6strand8dispatchINS0_6detail7binder1INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config11asio_client16transport_configEEEFvNS6_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISJ_EENS0_22deadline_timer_serviceISJ_SL_EEEEEENS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNSG_ISF_EERSP_RSV_RKNS6_12placeholders4__phILi1EEEEEESX_EEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS1E_
boost::asio::async_result<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::type __fastcall boost::asio::io_service::strand::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
        boost::asio::io_service::strand *this,
        boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v9; // rbx
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> v10; // [rsp+0h] [rbp-A8h] BYREF
  unsigned __int64 v11; // [rsp+88h] [rbp-20h]

  v11 = __readfsqword(0x28u);
  *(_OWORD *)&v10.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v10.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  v10.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      v10.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *))f->handler_.__f_
       + 3))(
        f,
        &v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        v2,
        v3,
        v4,
        v5,
        v10.handler_.__f_,
        *((_QWORD *)&v10.handler_.__f_ + 1),
        v10.handler_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v10.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v10.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v10.arg1_ = handler->arg1_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
    this->service_,
    &this->impl_,
    &v10);
  if ( &v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v10.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v10.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v10.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v10.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v10.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v10.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v10.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v9 = v10.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
      std::__shared_weak_count::__release_weak(v9);
    }
  }
}


// Address: 0x265f870 | Name: _ZN5boost4asio10io_service6strand8dispatchINS0_6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config11asio_client16transport_configEEEFvRKNS_6system10error_codeEmEJNS6_10shared_ptrISF_EERKNS6_12placeholders4__phILi1EEERKNSP_ILi2EEEEEESH_mEEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS10_
boost::asio::async_result<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> >::type __fastcall boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::io_service::strand *this,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> v3; // [rsp+0h] [rbp-58h] BYREF

  *(_OWORD *)&v3.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v3.handler_.__bound_args_ = handler->handler_.__bound_args_;
  handler->handler_.__bound_args_ = 0;
  v3.arg2_ = handler->arg2_;
  v3.arg1_ = handler->arg1_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
    this->service_,
    &this->impl_,
    &v3);
  cntrl = v3.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v3.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v3.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x266ca00 | Name: _ZN5boost4asio10io_service6strand8dispatchINS0_6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config11asio_client16transport_configEEEFvNS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNS6_10shared_ptrISF_EERSL_RKNS6_12placeholders4__phILi1EEEEEESN_mEEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS14_
boost::asio::async_result<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> >::type __fastcall boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::io_service::strand *this,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> v9; // [rsp+0h] [rbp-A8h] BYREF
  unsigned __int64 v10; // [rsp+88h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  *(_OWORD *)&v9.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v9.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *))f->handler_.__f_
       + 3))(
        f,
        &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v2,
        v3,
        v4,
        v5,
        v9.handler_.__f_,
        *((_QWORD *)&v9.handler_.__f_ + 1),
        v9.handler_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v9.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v9.arg2_ = handler->arg2_;
  v9.arg1_ = handler->arg1_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>(
    this->service_,
    &this->impl_,
    &v9);
  if ( &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v9.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v9.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v9.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x266f970 | Name: _ZN5boost4asio10io_service6strand8dispatchINS0_6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config11asio_client16transport_configEEEFvNS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEmEJNS6_10shared_ptrISF_EERSL_RKNS6_12placeholders4__phILi1EEERKNSW_ILi2EEEEEESN_mEEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS17_
boost::asio::async_result<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> >::type __fastcall boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::io_service::strand *this,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> v9; // [rsp+0h] [rbp-A8h] BYREF
  unsigned __int64 v10; // [rsp+88h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  *(_OWORD *)&v9.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v9.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *))f->handler_.__f_
       + 3))(
        f,
        &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v2,
        v3,
        v4,
        v5,
        v9.handler_.__f_,
        *((_QWORD *)&v9.handler_.__f_ + 1),
        v9.handler_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v9.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v9.arg2_ = handler->arg2_;
  v9.arg1_ = handler->arg1_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
    this->service_,
    &this->impl_,
    &v9);
  if ( &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v9.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v9.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v9.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


