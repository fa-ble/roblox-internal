// Address: 0x2029be0 | Name: _ZN5boost9iostreams6detail11execute_allINS1_22member_close_operationINS1_16linked_streambufIcNSt3__111char_traitsIcEEEEEES9_EENS1_14execute_traitsIT_NS_9result_ofIFSB_vEE4typeEE11result_typeESB_T0_
__int64 __fastcall boost::iostreams::detail::execute_all<boost::iostreams::detail::member_close_operation<boost::iostreams::detail::linked_streambuf<char,std::char_traits<char>>>,boost::iostreams::detail::member_close_operation<boost::iostreams::detail::linked_streambuf<char,std::char_traits<char>>>>(
        __int128 op,
        __int128 c0)
{
  int v2; // ebp
  __int64 *v3; // rbx
  int v4; // eax
  int v5; // eax
  int v6; // eax
  __int64 v7; // rax
  __int64 v8; // rsi
  int v9; // eax

  v2 = DWORD2(c0);
  v3 = (__int64 *)c0;
  if ( DWORD2(op) == 16 )
  {
    v5 = *(_DWORD *)(op + 64);
    if ( (v5 & 4) == 0 )
    {
      *(_DWORD *)(op + 64) = v5 | 4;
      (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)op + 120LL))(op, 16);
    }
  }
  else if ( DWORD2(op) == 8 )
  {
    v4 = *(_DWORD *)(op + 64);
    if ( (v4 & 2) == 0 )
    {
      *(_DWORD *)(op + 64) = v4 | 2;
      (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)op + 120LL))(op, 8);
    }
  }
  if ( v2 == 16 )
  {
    v9 = *((_DWORD *)v3 + 16);
    if ( (v9 & 4) == 0 )
    {
      *((_DWORD *)v3 + 16) = v9 | 4;
      v7 = *v3;
      v8 = 16;
      goto LABEL_13;
    }
  }
  else if ( v2 == 8 )
  {
    v6 = *((_DWORD *)v3 + 16);
    if ( (v6 & 2) == 0 )
    {
      *((_DWORD *)v3 + 16) = v6 | 2;
      v7 = *v3;
      v8 = 8;
LABEL_13:
      (*(void (__fastcall **)(__int64 *, __int64))(v7 + 120))(v3, v8);
    }
  }
  return 0;
}


