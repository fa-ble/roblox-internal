// Address: 0xefd380 | Name: _ZN5boost9algorithm6detail21find_format_all_impl2INSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS1_13first_finderFIPKcNS0_8is_equalEEENS1_13const_formatFINS_14iterator_rangeINS3_11__wrap_iterISC_EEEEEENSG_INSH_IPcEEEESJ_EEvRT_T0_T1_T2_T3_
// local variable allocation has failed, the output may be wrong!
void __fastcall boost::algorithm::detail::find_format_all_impl2<std::string,boost::algorithm::detail::first_finderF<char const*,boost::algorithm::is_equal>,boost::algorithm::detail::const_formatF<boost::iterator_range<std::__wrap_iter<char const*>>>,boost::iterator_range<std::__wrap_iter<char *>>,boost::iterator_range<std::__wrap_iter<char const*>>>(
        std::string *Input,
        boost::algorithm::detail::const_formatF<boost::iterator_range<std::__wrap_iter<const char *> > > Formatter,
        boost::iterator_range<std::__wrap_iter<char *> > FindResult,
        __int64 a4,
        boost::algorithm::detail::first_finderF<const char *,boost::algorithm::is_equal> Finder,
        boost::iterator_range<std::__wrap_iter<const char *> > FormatResult)
{
  char *i; // rbx
  std::__wrap_iter<const char *>::iterator_type v7; // r12
  std::__wrap_iter<const char *>::iterator_type v8; // rbp
  unsigned __int64 v9; // r9
  std::__wrap_iter<char *>::iterator_type v10; // r13
  std::__wrap_iter<char *>::iterator_type v11; // r15
  std::__wrap_iter<char *> v12; // rax
  char **v13; // rsi
  char *v14; // rdx
  unsigned __int64 v15; // rax
  char *v16; // r9
  unsigned __int64 v17; // rax
  char *v18; // r9
  const char *m_Begin; // rdx
  unsigned __int64 v20; // r9
  std::__wrap_iter<char *> v21; // rax
  unsigned __int64 v22; // rbp
  char *v23; // rcx
  unsigned __int64 v24; // rbp
  std::string::const_iterator v25; // rbp
  char **v26; // rdx OVERLAPPED
  char *v27; // rcx OVERLAPPED
  char **v28; // r8 OVERLAPPED
  char *v29; // r9 OVERLAPPED
  boost::algorithm::detail::process_segment_helper<false> v30; // [rsp+0h] [rbp-88h] BYREF
  char *v31; // [rsp+8h] [rbp-80h]
  std::deque<char> Storage; // [rsp+10h] [rbp-78h] BYREF
  std::__wrap_iter<const char *>::iterator_type v33; // [rsp+48h] [rbp-40h]
  std::__wrap_iter<const char *>::iterator_type v34; // [rsp+50h] [rbp-38h]

  i = FindResult.m_Begin.__i;
  v34 = Formatter.m_Format.m_End.__i;
  v33 = Formatter.m_Format.m_Begin.__i;
  v7 = FormatResult.m_Begin.__i;
  v8 = FormatResult.m_End.__i;
  memset(&Storage, 0, sizeof(Storage));
  v9 = *(unsigned __int8 *)Input;
  v10 = (char *)Input + 1;
  if ( (v9 & 1) != 0 )
    v10 = (std::__wrap_iter<char *>::iterator_type)*((_QWORD *)Input + 2);
  v31 = (char *)Input + 1;
  if ( FindResult.m_End.__i == FindResult.m_Begin.__i )
  {
    if ( (v9 & 1) != 0 )
      v20 = *((_QWORD *)Input + 1);
    else
      v20 = v9 >> 1;
    v18 = &v10[v20];
    v11 = v10;
  }
  else
  {
    v11 = v10;
    v12.__i = v10;
    while ( 2 )
    {
      v10 = FindResult.m_End.__i;
      v11 = boost::algorithm::detail::process_segment_helper<false>::operator()<std::deque<char>,std::string,std::__wrap_iter<char *>>(
              &v30,
              &Storage,
              Input,
              (std::__wrap_iter<char *>)v11,
              v12,
              (std::__wrap_iter<char *>)i).__i;
      v13 = &Storage.__map_.__begin_[(Storage.__size_.__value_ + Storage.__start_) >> 12];
      if ( Storage.__map_.__end_ == Storage.__map_.__begin_ )
        v14 = 0;
      else
        v14 = &(*v13)[(LOWORD(Storage.__size_.__value_) + LOWORD(Storage.__start_)) & 0xFFF];
      std::deque<char>::insert<std::__wrap_iter<char const*>>(
        &Storage,
        (std::deque<char>::const_iterator)__PAIR128__((unsigned __int64)v14, (unsigned __int64)v13),
        (std::__wrap_iter<const char *>)v7,
        (std::__wrap_iter<const char *>)v8,
        0);
      v15 = *(unsigned __int8 *)Input;
      if ( (v15 & 1) != 0 )
      {
        v16 = (char *)*((_QWORD *)Input + 2);
        v17 = *((_QWORD *)Input + 1);
      }
      else
      {
        v17 = v15 >> 1;
        v16 = v31;
      }
      v18 = &v16[v17];
      if ( v18 != v10 && Finder.m_Search.m_Begin != Finder.m_Search.m_End )
      {
        i = v10;
LABEL_14:
        m_Begin = Finder.m_Search.m_Begin;
        FindResult.m_End.__i = i;
        while ( Finder.m_Search.m_End != m_Begin )
        {
          if ( *FindResult.m_End.__i != *m_Begin )
            goto LABEL_19;
          ++FindResult.m_End.__i;
          ++m_Begin;
          if ( v18 == FindResult.m_End.__i )
          {
            FindResult.m_End.__i = v18;
LABEL_19:
            if ( m_Begin != Finder.m_Search.m_End )
            {
              if ( ++i != v18 )
                goto LABEL_14;
              goto LABEL_30;
            }
            break;
          }
        }
        if ( i != FindResult.m_End.__i )
        {
          v8 = v34;
          v7 = v33;
        }
        v12.__i = v10;
        if ( FindResult.m_End.__i != i )
          continue;
      }
      break;
    }
  }
LABEL_30:
  v21.__i = boost::algorithm::detail::process_segment_helper<false>::operator()<std::deque<char>,std::string,std::__wrap_iter<char *>>(
              &v30,
              &Storage,
              Input,
              (std::__wrap_iter<char *>)v11,
              (std::__wrap_iter<char *>)v10,
              (std::__wrap_iter<char *>)v18).__i;
  v22 = *(unsigned __int8 *)Input;
  v23 = v31;
  if ( (v22 & 1) != 0 )
  {
    v23 = (char *)*((_QWORD *)Input + 2);
    v24 = *((_QWORD *)Input + 1);
  }
  else
  {
    v24 = v22 >> 1;
  }
  v25.__i = &v23[v24];
  if ( Storage.__size_.__value_ )
  {
    v26 = &Storage.__map_.__begin_[Storage.__start_ >> 12];
    if ( Storage.__map_.__end_ == Storage.__map_.__begin_ )
    {
      v28 = &Storage.__map_.__begin_[(Storage.__size_.__value_ + Storage.__start_) >> 12];
      v27 = 0;
      v29 = 0;
    }
    else
    {
      v27 = &(*v26)[Storage.__start_ & 0xFFF];
      v28 = &Storage.__map_.__begin_[(Storage.__start_ + Storage.__size_.__value_) >> 12];
      v29 = &(*v28)[(LODWORD(Storage.__start_) + LODWORD(Storage.__size_.__value_)) & 0xFFF];
    }
    std::string::insert<std::__deque_iterator<char,char *,char &,char **,long,4096l>>(
      Input,
      v25,
      *(std::__deque_iterator<char,char *,char &,char **,long,4096> *)&v26,
      *(std::__deque_iterator<char,char *,char &,char **,long,4096> *)&v28);
  }
  else
  {
    std::string::erase(Input, v21.__i - v23, v25.__i - v21.__i);
  }
  std::__deque_base<char>::~__deque_base(&Storage);
}


// Address: 0x1431e60 | Name: _ZN5boost9algorithm6detail21find_format_all_impl2INSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS1_13first_finderFIPKcNS0_8is_equalEEENS1_13const_formatFINS_14iterator_rangeISC_EEEENSG_INS3_11__wrap_iterIPcEEEESH_EEvRT_T0_T1_T2_T3_
// local variable allocation has failed, the output may be wrong!
void __fastcall boost::algorithm::detail::find_format_all_impl2<std::string,boost::algorithm::detail::first_finderF<char const*,boost::algorithm::is_equal>,boost::algorithm::detail::const_formatF<boost::iterator_range<char const*>>,boost::iterator_range<std::__wrap_iter<char *>>,boost::iterator_range<char const*>>(
        std::string *Input,
        boost::algorithm::detail::const_formatF<boost::iterator_range<const char *> > Formatter,
        boost::iterator_range<std::__wrap_iter<char *> > FindResult,
        __int64 a4,
        boost::algorithm::detail::first_finderF<const char *,boost::algorithm::is_equal> Finder,
        boost::iterator_range<const char *> FormatResult)
{
  char *i; // rbx
  const char *v7; // r12
  const char *v8; // rbp
  unsigned __int64 v9; // r9
  std::__wrap_iter<char *>::iterator_type v10; // r13
  std::__wrap_iter<char *>::iterator_type v11; // r15
  std::__wrap_iter<char *> v12; // rax
  char **v13; // rsi
  char *v14; // rdx
  unsigned __int64 v15; // rax
  char *v16; // r9
  unsigned __int64 v17; // rax
  char *v18; // r9
  const char *v19; // rdx
  unsigned __int64 v20; // r9
  std::__wrap_iter<char *> v21; // rax
  unsigned __int64 v22; // rbp
  char *v23; // rcx
  unsigned __int64 v24; // rbp
  std::string::const_iterator v25; // rbp
  char **v26; // rdx OVERLAPPED
  char *v27; // rcx OVERLAPPED
  char **v28; // r8 OVERLAPPED
  char *v29; // r9 OVERLAPPED
  boost::algorithm::detail::process_segment_helper<false> v30; // [rsp+0h] [rbp-88h] BYREF
  char *v31; // [rsp+8h] [rbp-80h]
  std::deque<char> Storage; // [rsp+10h] [rbp-78h] BYREF
  const char *m_Begin; // [rsp+48h] [rbp-40h]
  const char *m_End; // [rsp+50h] [rbp-38h]

  i = FindResult.m_Begin.__i;
  m_End = Formatter.m_Format.m_End;
  m_Begin = Formatter.m_Format.m_Begin;
  v7 = FormatResult.m_Begin;
  v8 = FormatResult.m_End;
  memset(&Storage, 0, sizeof(Storage));
  v9 = *(unsigned __int8 *)Input;
  v10 = (char *)Input + 1;
  if ( (v9 & 1) != 0 )
    v10 = (std::__wrap_iter<char *>::iterator_type)*((_QWORD *)Input + 2);
  v31 = (char *)Input + 1;
  if ( FindResult.m_End.__i == FindResult.m_Begin.__i )
  {
    if ( (v9 & 1) != 0 )
      v20 = *((_QWORD *)Input + 1);
    else
      v20 = v9 >> 1;
    v18 = &v10[v20];
    v11 = v10;
  }
  else
  {
    v11 = v10;
    v12.__i = v10;
    while ( 2 )
    {
      v10 = FindResult.m_End.__i;
      v11 = boost::algorithm::detail::process_segment_helper<false>::operator()<std::deque<char>,std::string,std::__wrap_iter<char *>>(
              &v30,
              &Storage,
              Input,
              (std::__wrap_iter<char *>)v11,
              v12,
              (std::__wrap_iter<char *>)i).__i;
      v13 = &Storage.__map_.__begin_[(Storage.__size_.__value_ + Storage.__start_) >> 12];
      if ( Storage.__map_.__end_ == Storage.__map_.__begin_ )
        v14 = 0;
      else
        v14 = &(*v13)[(LOWORD(Storage.__size_.__value_) + LOWORD(Storage.__start_)) & 0xFFF];
      std::deque<char>::insert<char const*>(
        &Storage,
        (std::deque<char>::const_iterator)__PAIR128__((unsigned __int64)v14, (unsigned __int64)v13),
        v7,
        v8,
        0);
      v15 = *(unsigned __int8 *)Input;
      if ( (v15 & 1) != 0 )
      {
        v16 = (char *)*((_QWORD *)Input + 2);
        v17 = *((_QWORD *)Input + 1);
      }
      else
      {
        v17 = v15 >> 1;
        v16 = v31;
      }
      v18 = &v16[v17];
      if ( v18 != v10 && Finder.m_Search.m_Begin != Finder.m_Search.m_End )
      {
        i = v10;
LABEL_14:
        v19 = Finder.m_Search.m_Begin;
        FindResult.m_End.__i = i;
        while ( Finder.m_Search.m_End != v19 )
        {
          if ( *FindResult.m_End.__i != *v19 )
            goto LABEL_19;
          ++FindResult.m_End.__i;
          ++v19;
          if ( v18 == FindResult.m_End.__i )
          {
            FindResult.m_End.__i = v18;
LABEL_19:
            if ( v19 != Finder.m_Search.m_End )
            {
              if ( ++i != v18 )
                goto LABEL_14;
              goto LABEL_30;
            }
            break;
          }
        }
        if ( i != FindResult.m_End.__i )
        {
          v8 = m_End;
          v7 = m_Begin;
        }
        v12.__i = v10;
        if ( FindResult.m_End.__i != i )
          continue;
      }
      break;
    }
  }
LABEL_30:
  v21.__i = boost::algorithm::detail::process_segment_helper<false>::operator()<std::deque<char>,std::string,std::__wrap_iter<char *>>(
              &v30,
              &Storage,
              Input,
              (std::__wrap_iter<char *>)v11,
              (std::__wrap_iter<char *>)v10,
              (std::__wrap_iter<char *>)v18).__i;
  v22 = *(unsigned __int8 *)Input;
  v23 = v31;
  if ( (v22 & 1) != 0 )
  {
    v23 = (char *)*((_QWORD *)Input + 2);
    v24 = *((_QWORD *)Input + 1);
  }
  else
  {
    v24 = v22 >> 1;
  }
  v25.__i = &v23[v24];
  if ( Storage.__size_.__value_ )
  {
    v26 = &Storage.__map_.__begin_[Storage.__start_ >> 12];
    if ( Storage.__map_.__end_ == Storage.__map_.__begin_ )
    {
      v28 = &Storage.__map_.__begin_[(Storage.__size_.__value_ + Storage.__start_) >> 12];
      v27 = 0;
      v29 = 0;
    }
    else
    {
      v27 = &(*v26)[Storage.__start_ & 0xFFF];
      v28 = &Storage.__map_.__begin_[(Storage.__start_ + Storage.__size_.__value_) >> 12];
      v29 = &(*v28)[(LODWORD(Storage.__start_) + LODWORD(Storage.__size_.__value_)) & 0xFFF];
    }
    std::string::insert<std::__deque_iterator<char,char *,char &,char **,long,4096l>>(
      Input,
      v25,
      *(std::__deque_iterator<char,char *,char &,char **,long,4096> *)&v26,
      *(std::__deque_iterator<char,char *,char &,char **,long,4096> *)&v28);
  }
  else
  {
    std::string::erase(Input, v21.__i - v23, v25.__i - v21.__i);
  }
  std::__deque_base<char>::~__deque_base(&Storage);
}


