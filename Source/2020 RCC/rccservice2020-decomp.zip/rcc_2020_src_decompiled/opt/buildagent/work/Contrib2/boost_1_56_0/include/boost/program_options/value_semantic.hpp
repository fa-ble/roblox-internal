// Address: 0xe3f550 | Name: _ZN5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE13default_valueERKS8_
boost::program_options::typed_value<std::string,char> *__fastcall boost::program_options::typed_value<std::string,char>::default_value(
        boost::program_options::typed_value<std::string,char> *this,
        const std::string *v)
{
  _QWORD *v3; // rbx
  int v4; // edx
  void *v5; // rcx
  size_t v6; // r8
  const void *v7; // r9
  __int64 v8; // rdi
  _WORD *v9; // rbx
  __int128 v11; // [rsp+0h] [rbp-38h] BYREF
  __int64 v12; // [rsp+10h] [rbp-28h]

  v3 = operator new(0x20u);
  *v3 = &off_287BA98;
  std::string::basic_string(v3 + 1, v);
  v8 = *((_QWORD *)this + 6);
  *((_QWORD *)this + 6) = v3;
  if ( v8 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 8LL))(v8);
  v11 = 0;
  v12 = 0;
  std::string::operator=((soap *)&v11, (int)v, v4, v5, v6, v7);
  v9 = (_WORD *)((char *)this + 56);
  if ( (*((_BYTE *)this + 56) & 1) != 0 )
  {
    **((_BYTE **)this + 9) = 0;
    *((_QWORD *)this + 8) = 0;
  }
  else
  {
    *v9 = 0;
  }
  std::string::reserve((char *)this + 56, 0);
  *((_QWORD *)this + 9) = v12;
  *(_OWORD *)v9 = v11;
  return this;
}


// Address: 0xe3f630 | Name: _ZN5boost15program_options11typed_valueIicE13default_valueERKi
boost::program_options::typed_value<int,char> *__fastcall boost::program_options::typed_value<int,char>::default_value(
        boost::program_options::typed_value<int,char> *this,
        const int *v)
{
  _DWORD *v3; // rax
  int v4; // ebp
  __int64 v5; // rdi
  boost::mpl::if_c<false,int,unsigned int>::type v6; // eax
  char *v7; // rax
  unsigned __int64 v8; // rbx
  unsigned __int8 v9; // al
  unsigned __int64 v10; // r15
  unsigned __int64 v11; // rsi
  unsigned __int8 v12; // cl
  __int64 v13; // rcx
  unsigned __int64 v14; // r8
  unsigned __int64 v15; // rcx
  unsigned __int64 v16; // rcx
  _BYTE *v17; // rsi
  _WORD *v18; // rbx
  unsigned __int64 v20; // rdx
  __int64 v21; // rsi
  __int64 v22; // rdi
  __int64 v23; // rbp
  __int128 v24; // xmm1
  __int128 v25; // xmm1
  __int128 v26; // xmm1
  __int128 v27; // xmm1
  __int64 v28; // rdi
  __int64 v29; // rsi
  __int128 v30; // xmm1
  __int128 v31; // [rsp+10h] [rbp-88h] BYREF
  void *ptr; // [rsp+20h] [rbp-78h]
  boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned int,char> v33; // [rsp+28h] [rbp-70h] BYREF
  _BYTE v35[21]; // [rsp+41h] [rbp-57h] BYREF
  _BYTE v36[2]; // [rsp+56h] [rbp-42h] BYREF
  _BYTE *v37; // [rsp+58h] [rbp-40h]
  _BYTE *v38; // [rsp+60h] [rbp-38h]
  unsigned __int64 v39; // [rsp+68h] [rbp-30h]

  v39 = __readfsqword(0x28u);
  v3 = operator new(0x10u);
  *(_QWORD *)v3 = &off_287BF70;
  v4 = *v;
  v3[2] = *v;
  v5 = *((_QWORD *)this + 6);
  *((_QWORD *)this + 6) = v3;
  if ( v5 )
  {
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(v5);
    v4 = *v;
  }
  v31 = 0;
  ptr = 0;
  v37 = v35;
  v38 = v36;
  v6 = -v4;
  if ( -v4 < 1 )
    v6 = v4;
  v33.m_value = v6;
  v33.m_finish = v36;
  v33.m_czero = 48;
  v33.m_zero = 48;
  v7 = boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned int,char>::convert(&v33);
  v8 = (unsigned __int64)v7;
  if ( v4 < 0 )
  {
    *(v7 - 1) = 45;
    v8 = (unsigned __int64)(v7 - 1);
    v9 = v31;
  }
  else
  {
    v9 = 0;
  }
  v37 = (_BYTE *)v8;
  v38 = v36;
  v10 = (unsigned __int64)&v36[-v8];
  if ( (v9 & 1) != 0 )
  {
    v12 = v31;
    v11 = (v31 & 0xFFFFFFFFFFFFFFFELL) - 1;
  }
  else
  {
    v11 = 22;
    v12 = v9;
  }
  if ( v10 > v11 )
  {
    if ( (v9 & 1) != 0 )
      v13 = *((_QWORD *)&v31 + 1);
    else
      v13 = v9 >> 1;
    std::string::__grow_by(&v31, v11, v10 - v11, v13, 0, v13, 0);
    v12 = v31;
  }
  if ( (v12 & 1) == 0 )
  {
    v14 = (unsigned __int64)&v31 + 1;
    if ( (_BYTE *)v8 == v36 )
      goto LABEL_27;
LABEL_20:
    v15 = (unsigned __int64)&v35[21 - v8];
    if ( v15 < 0x20 || v14 < (unsigned __int64)v36 && v8 < (unsigned __int64)&v35[21 - v8 + v14] )
    {
      v16 = v14;
      goto LABEL_24;
    }
    v20 = v15 & 0xFFFFFFFFFFFFFFE0LL;
    v21 = ((unsigned __int8)(((v15 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3;
    if ( (v15 & 0xFFFFFFFFFFFFFFE0LL) - 32 >= 0x60 )
    {
      v23 = v21 - ((((v15 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1);
      v22 = 0;
      do
      {
        v24 = *(_OWORD *)(v8 + v22 + 16);
        *(_OWORD *)(v14 + v22) = *(_OWORD *)(v8 + v22);
        *(_OWORD *)(v14 + v22 + 16) = v24;
        v25 = *(_OWORD *)(v8 + v22 + 48);
        *(_OWORD *)(v14 + v22 + 32) = *(_OWORD *)(v8 + v22 + 32);
        *(_OWORD *)(v14 + v22 + 48) = v25;
        v26 = *(_OWORD *)(v8 + v22 + 80);
        *(_OWORD *)(v14 + v22 + 64) = *(_OWORD *)(v8 + v22 + 64);
        *(_OWORD *)(v14 + v22 + 80) = v26;
        v27 = *(_OWORD *)(v8 + v22 + 112);
        *(_OWORD *)(v14 + v22 + 96) = *(_OWORD *)(v8 + v22 + 96);
        *(_OWORD *)(v14 + v22 + 112) = v27;
        v22 += 128;
        v23 += 4;
      }
      while ( v23 );
      if ( (((unsigned __int8)(((v15 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
        goto LABEL_42;
    }
    else
    {
      v22 = 0;
      if ( (((unsigned __int8)(((v15 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
      {
LABEL_42:
        if ( v20 == v15 )
        {
LABEL_26:
          v14 += v10;
          goto LABEL_27;
        }
        v16 = v14 + v20;
        v8 += v20;
LABEL_24:
        v17 = 0;
        do
        {
          v17[v16] = v17[v8];
          ++v17;
        }
        while ( &v35[21 - v8] != v17 );
        goto LABEL_26;
      }
    }
    v28 = v22 + 16;
    v29 = -v21;
    do
    {
      v30 = *(_OWORD *)(v8 + v28);
      *(_OWORD *)(v14 + v28 - 16) = *(_OWORD *)(v8 + v28 - 16);
      *(_OWORD *)(v14 + v28) = v30;
      v28 += 32;
      ++v29;
    }
    while ( v29 );
    goto LABEL_42;
  }
  v14 = (unsigned __int64)ptr;
  if ( (_BYTE *)v8 != v36 )
    goto LABEL_20;
LABEL_27:
  *(_BYTE *)v14 = 0;
  if ( (v31 & 1) != 0 )
    *((_QWORD *)&v31 + 1) = v10;
  else
    LOBYTE(v31) = 2 * v10;
  v18 = (_WORD *)((char *)this + 56);
  if ( (*((_BYTE *)this + 56) & 1) != 0 )
  {
    **((_BYTE **)this + 9) = 0;
    *((_QWORD *)this + 8) = 0;
  }
  else
  {
    *v18 = 0;
  }
  std::string::reserve((char *)this + 56, 0);
  *((_QWORD *)this + 9) = ptr;
  *(_OWORD *)v18 = v31;
  return this;
}


// Address: 0xe40980 | Name: _ZNK5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE10min_tokensEv
unsigned int __fastcall boost::program_options::typed_value<std::string,char>::min_tokens(
        const boost::program_options::typed_value<std::string,char> *this)
{
  return !*((_BYTE *)this + 115) && *((_QWORD *)this + 10) == 0;
}


// Address: 0xe409a0 | Name: _ZNK5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE10max_tokensEv
unsigned int __fastcall boost::program_options::typed_value<std::string,char>::max_tokens(
        const boost::program_options::typed_value<std::string,char> *this)
{
  unsigned int result; // eax

  result = 32000;
  if ( !*((_BYTE *)this + 114) )
    return *((unsigned __int8 *)this + 115) ^ 1;
  return result;
}


// Address: 0xe409c0 | Name: _ZNK5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE12is_composingEv
bool __fastcall boost::program_options::typed_value<std::string,char>::is_composing(
        const boost::program_options::typed_value<std::string,char> *this)
{
  return *((_BYTE *)this + 112);
}


// Address: 0xe409d0 | Name: _ZNK5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE11is_requiredEv
bool __fastcall boost::program_options::typed_value<std::string,char>::is_required(
        const boost::program_options::typed_value<std::string,char> *this)
{
  return *((_BYTE *)this + 116);
}


// Address: 0xe409e0 | Name: _ZNK5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE13apply_defaultERNS_3anyE
bool __fastcall boost::program_options::typed_value<std::string,char>::apply_default(
        const boost::program_options::typed_value<std::string,char> *this,
        boost::any_0 *value_store)
{
  __int64 v2; // rdi
  boost::any::placeholder *v3; // rax
  boost::any::placeholder *content; // rdi
  bool v5; // bl

  v2 = *((_QWORD *)this + 6);
  if ( !v2 )
    return 0;
  v3 = (boost::any::placeholder *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v2 + 24LL))(v2);
  content = value_store->content;
  value_store->content = v3;
  v5 = 1;
  if ( content )
    (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
  return v5;
}


// Address: 0xe40af0 | Name: _ZN5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcED2Ev
void __fastcall boost::program_options::typed_value<std::string,char>::~typed_value(
        boost::program_options::typed_value<std::string,char> *this)
{
  __int64 v2; // rax
  void (__fastcall *v3)(char *, char *, __int64); // rax
  __int64 v4; // rdi
  __int64 v5; // rdi

  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)&off_287B9B8, (__m128i)(unsigned __int64)off_287BA28);
  v2 = *((_QWORD *)this + 15);
  if ( v2 )
  {
    if ( (v2 & 1) == 0 )
    {
      v3 = *(void (__fastcall **)(char *, char *, __int64))(v2 & 0xFFFFFFFFFFFFFFFELL);
      if ( v3 )
        v3((char *)this + 128, (char *)this + 128, 2);
    }
    *((_QWORD *)this + 15) = 0;
  }
  if ( (*((_BYTE *)this + 88) & 1) != 0 )
    operator delete(*((void **)this + 13));
  v4 = *((_QWORD *)this + 10);
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 8LL))(v4);
  if ( (*((_BYTE *)this + 56) & 1) != 0 )
    operator delete(*((void **)this + 9));
  v5 = *((_QWORD *)this + 6);
  if ( v5 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(v5);
  if ( (*((_BYTE *)this + 24) & 1) != 0 )
    operator delete(*((void **)this + 5));
}


// Address: 0xe40ba0 | Name: _ZN5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcED0Ev
void __fastcall boost::program_options::typed_value<std::string,char>::~typed_value(
        boost::program_options::typed_value<std::string,char> *this)
{
  boost::program_options::typed_value<std::string,char>::~typed_value(this);
  operator delete(this);
}


// Address: 0xe40c10 | Name: _ZNK5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE10value_typeEv
const std::type_info *__fastcall boost::program_options::typed_value<std::string,char>::value_type(
        const boost::program_options::typed_value<std::string,char> *this)
{
  return (const std::type_info *)&`typeinfo for'std::string;
}


// Address: 0xe40c20 | Name: _ZThn8_NK5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE10value_typeEv
void __fastcall `non-virtual thunk to'boost::program_options::typed_value<std::string,char>::value_type(
        const boost::program_options::typed_value<std::string,char> *this)
{
  ;
}


// Address: 0xe40c30 | Name: _ZThn8_N5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcED1Ev
void __fastcall `non-virtual thunk to'boost::program_options::typed_value<std::string,char>::~typed_value(
        boost::program_options::typed_value<std::string,char> *this)
{
  boost::program_options::typed_value<std::string,char>::~typed_value((boost::program_options::typed_value<std::string,char> *)((char *)this - 8));
}


// Address: 0xe40c40 | Name: _ZThn8_N5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcED0Ev
void __fastcall `non-virtual thunk to'boost::program_options::typed_value<std::string,char>::~typed_value(
        boost::program_options::typed_value<std::string,char> *this)
{
  boost::program_options::typed_value<std::string,char>::~typed_value((boost::program_options::typed_value<std::string,char> *)((char *)this - 8));
  operator delete((char *)this - 8);
}


// Address: 0xe41870 | Name: _ZNK5boost15program_options11typed_valueIicE10min_tokensEv
unsigned int __fastcall boost::program_options::typed_value<int,char>::min_tokens(
        const boost::program_options::typed_value<int,char> *this)
{
  return !*((_BYTE *)this + 115) && *((_QWORD *)this + 10) == 0;
}


// Address: 0xe41890 | Name: _ZNK5boost15program_options11typed_valueIicE10max_tokensEv
unsigned int __fastcall boost::program_options::typed_value<int,char>::max_tokens(
        const boost::program_options::typed_value<int,char> *this)
{
  unsigned int result; // eax

  result = 32000;
  if ( !*((_BYTE *)this + 114) )
    return *((unsigned __int8 *)this + 115) ^ 1;
  return result;
}


// Address: 0xe418b0 | Name: _ZNK5boost15program_options11typed_valueIicE12is_composingEv
bool __fastcall boost::program_options::typed_value<int,char>::is_composing(
        const boost::program_options::typed_value<int,char> *this)
{
  return *((_BYTE *)this + 112);
}


// Address: 0xe418c0 | Name: _ZNK5boost15program_options11typed_valueIicE11is_requiredEv
bool __fastcall boost::program_options::typed_value<int,char>::is_required(
        const boost::program_options::typed_value<int,char> *this)
{
  return *((_BYTE *)this + 116);
}


// Address: 0xe418d0 | Name: _ZNK5boost15program_options11typed_valueIicE13apply_defaultERNS_3anyE
bool __fastcall boost::program_options::typed_value<int,char>::apply_default(
        const boost::program_options::typed_value<int,char> *this,
        boost::any_0 *value_store)
{
  __int64 v2; // rdi
  boost::any::placeholder *v3; // rax
  boost::any::placeholder *content; // rdi
  bool v5; // bl

  v2 = *((_QWORD *)this + 6);
  if ( !v2 )
    return 0;
  v3 = (boost::any::placeholder *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v2 + 24LL))(v2);
  content = value_store->content;
  value_store->content = v3;
  v5 = 1;
  if ( content )
    (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
  return v5;
}


// Address: 0xe419e0 | Name: _ZN5boost15program_options11typed_valueIicED2Ev
void __fastcall boost::program_options::typed_value<int,char>::~typed_value(
        boost::program_options::typed_value<int,char> *this)
{
  __int64 v2; // rax
  void (__fastcall *v3)(char *, char *, __int64); // rax
  __int64 v4; // rdi
  __int64 v5; // rdi

  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)&off_287BCB0, (__m128i)(unsigned __int64)off_287BD20);
  v2 = *((_QWORD *)this + 15);
  if ( v2 )
  {
    if ( (v2 & 1) == 0 )
    {
      v3 = *(void (__fastcall **)(char *, char *, __int64))(v2 & 0xFFFFFFFFFFFFFFFELL);
      if ( v3 )
        v3((char *)this + 128, (char *)this + 128, 2);
    }
    *((_QWORD *)this + 15) = 0;
  }
  if ( (*((_BYTE *)this + 88) & 1) != 0 )
    operator delete(*((void **)this + 13));
  v4 = *((_QWORD *)this + 10);
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 8LL))(v4);
  if ( (*((_BYTE *)this + 56) & 1) != 0 )
    operator delete(*((void **)this + 9));
  v5 = *((_QWORD *)this + 6);
  if ( v5 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(v5);
  if ( (*((_BYTE *)this + 24) & 1) != 0 )
    operator delete(*((void **)this + 5));
}


// Address: 0xe41a90 | Name: _ZN5boost15program_options11typed_valueIicED0Ev
void __fastcall boost::program_options::typed_value<int,char>::~typed_value(
        boost::program_options::typed_value<int,char> *this)
{
  boost::program_options::typed_value<int,char>::~typed_value(this);
  operator delete(this);
}


// Address: 0xe41b00 | Name: _ZNK5boost15program_options11typed_valueIicE10value_typeEv
const std::type_info *__fastcall boost::program_options::typed_value<int,char>::value_type(
        const boost::program_options::typed_value<int,char> *this)
{
  return (const std::type_info *)`typeinfo for'int;
}


// Address: 0xe41b10 | Name: _ZThn8_NK5boost15program_options11typed_valueIicE10value_typeEv
void __fastcall `non-virtual thunk to'boost::program_options::typed_value<int,char>::value_type(
        const boost::program_options::typed_value<int,char> *this)
{
  ;
}


// Address: 0xe41b20 | Name: _ZThn8_N5boost15program_options11typed_valueIicED1Ev
void __fastcall `non-virtual thunk to'boost::program_options::typed_value<int,char>::~typed_value(
        boost::program_options::typed_value<int,char> *this)
{
  boost::program_options::typed_value<int,char>::~typed_value((boost::program_options::typed_value<int,char> *)((char *)this - 8));
}


// Address: 0xe41b30 | Name: _ZThn8_N5boost15program_options11typed_valueIicED0Ev
void __fastcall `non-virtual thunk to'boost::program_options::typed_value<int,char>::~typed_value(
        boost::program_options::typed_value<int,char> *this)
{
  boost::program_options::typed_value<int,char>::~typed_value((boost::program_options::typed_value<int,char> *)((char *)this - 8));
  operator delete((char *)this - 8);
}


// Address: 0xe67220 | Name: _ZN5boost15program_options14value_semanticD2Ev
void __fastcall boost::program_options::value_semantic::~value_semantic(boost::program_options::value_semantic *this)
{
  ;
}


// Address: 0xe67230 | Name: _ZN5boost15program_options29value_semantic_codecvt_helperIcED0Ev
void __fastcall __noreturn boost::program_options::value_semantic_codecvt_helper<char>::~value_semantic_codecvt_helper(
        boost::program_options::value_semantic_codecvt_helper<char> *this)
{
  BUG();
}


// Address: 0xe67240 | Name: _ZNK5boost15program_options13untyped_value12is_composingEv
bool __fastcall boost::program_options::untyped_value::is_composing(const boost::program_options::untyped_value *this)
{
  return 0;
}


// Address: 0xe67250 | Name: _ZNK5boost15program_options13untyped_value11is_requiredEv
bool __fastcall boost::program_options::untyped_value::is_required(const boost::program_options::untyped_value *this)
{
  return 0;
}


// Address: 0xe67260 | Name: _ZNK5boost15program_options13untyped_value13apply_defaultERNS_3anyE
bool __fastcall boost::program_options::untyped_value::apply_default(
        const boost::program_options::untyped_value *this,
        boost::any_0 *a2)
{
  return 0;
}


// Address: 0xe67270 | Name: _ZNK5boost15program_options13untyped_value6notifyERKNS_3anyE
void __fastcall boost::program_options::untyped_value::notify(
        const boost::program_options::untyped_value *this,
        const boost::any_0 *a2)
{
  ;
}


// Address: 0xe67280 | Name: j__ZdlPv_79
// attributes: thunk
void __fastcall operator delete(boost::program_options::untyped_value *this)
{
  _ZdlPv(this);
}


// Address: 0xe67290 | Name: _ZN5boost15program_options29value_semantic_codecvt_helperIwED0Ev
void __fastcall __noreturn boost::program_options::value_semantic_codecvt_helper<wchar_t>::~value_semantic_codecvt_helper(
        boost::program_options::value_semantic_codecvt_helper<wchar_t> *this)
{
  BUG();
}


// Address: 0xe68420 | Name: _ZNK5boost15program_options11typed_valueIbcE10min_tokensEv
unsigned int __fastcall boost::program_options::typed_value<bool,char>::min_tokens(
        const boost::program_options::typed_value<bool,char> *this)
{
  return !*((_BYTE *)this + 115) && *((_QWORD *)this + 10) == 0;
}


// Address: 0xe68440 | Name: _ZNK5boost15program_options11typed_valueIbcE10max_tokensEv
unsigned int __fastcall boost::program_options::typed_value<bool,char>::max_tokens(
        const boost::program_options::typed_value<bool,char> *this)
{
  unsigned int result; // eax

  result = 32000;
  if ( !*((_BYTE *)this + 114) )
    return *((unsigned __int8 *)this + 115) ^ 1;
  return result;
}


// Address: 0xe68460 | Name: _ZNK5boost15program_options11typed_valueIbcE12is_composingEv
bool __fastcall boost::program_options::typed_value<bool,char>::is_composing(
        const boost::program_options::typed_value<bool,char> *this)
{
  return *((_BYTE *)this + 112);
}


// Address: 0xe68470 | Name: _ZNK5boost15program_options11typed_valueIbcE11is_requiredEv
bool __fastcall boost::program_options::typed_value<bool,char>::is_required(
        const boost::program_options::typed_value<bool,char> *this)
{
  return *((_BYTE *)this + 116);
}


// Address: 0xe68480 | Name: _ZNK5boost15program_options11typed_valueIbcE13apply_defaultERNS_3anyE
bool __fastcall boost::program_options::typed_value<bool,char>::apply_default(
        const boost::program_options::typed_value<bool,char> *this,
        boost::any_0 *value_store)
{
  __int64 v2; // rdi
  boost::any::placeholder *v3; // rax
  boost::any::placeholder *content; // rdi
  bool v5; // bl

  v2 = *((_QWORD *)this + 6);
  if ( !v2 )
    return 0;
  v3 = (boost::any::placeholder *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v2 + 24LL))(v2);
  content = value_store->content;
  value_store->content = v3;
  v5 = 1;
  if ( content )
    (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
  return v5;
}


// Address: 0xe68590 | Name: _ZN5boost15program_options11typed_valueIbcED2Ev
void __fastcall boost::program_options::typed_value<bool,char>::~typed_value(
        boost::program_options::typed_value<bool,char> *this)
{
  __int64 v2; // rax
  void (__fastcall *v3)(char *, char *, __int64); // rax
  __int64 v4; // rdi
  __int64 v5; // rdi

  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)&off_287E408, (__m128i)(unsigned __int64)off_287E478);
  v2 = *((_QWORD *)this + 15);
  if ( v2 )
  {
    if ( (v2 & 1) == 0 )
    {
      v3 = *(void (__fastcall **)(char *, char *, __int64))(v2 & 0xFFFFFFFFFFFFFFFELL);
      if ( v3 )
        v3((char *)this + 128, (char *)this + 128, 2);
    }
    *((_QWORD *)this + 15) = 0;
  }
  if ( (*((_BYTE *)this + 88) & 1) != 0 )
    operator delete(*((void **)this + 13));
  v4 = *((_QWORD *)this + 10);
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 8LL))(v4);
  if ( (*((_BYTE *)this + 56) & 1) != 0 )
    operator delete(*((void **)this + 9));
  v5 = *((_QWORD *)this + 6);
  if ( v5 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(v5);
  if ( (*((_BYTE *)this + 24) & 1) != 0 )
    operator delete(*((void **)this + 5));
}


// Address: 0xe68640 | Name: _ZN5boost15program_options11typed_valueIbcED0Ev
void __fastcall boost::program_options::typed_value<bool,char>::~typed_value(
        boost::program_options::typed_value<bool,char> *this)
{
  boost::program_options::typed_value<bool,char>::~typed_value(this);
  operator delete(this);
}


// Address: 0xe686a0 | Name: _ZNK5boost15program_options11typed_valueIbcE10value_typeEv
const std::type_info *__fastcall boost::program_options::typed_value<bool,char>::value_type(
        const boost::program_options::typed_value<bool,char> *this)
{
  return (const std::type_info *)`typeinfo for'bool;
}


// Address: 0xe686b0 | Name: _ZThn8_NK5boost15program_options11typed_valueIbcE10value_typeEv
void __fastcall `non-virtual thunk to'boost::program_options::typed_value<bool,char>::value_type(
        const boost::program_options::typed_value<bool,char> *this)
{
  ;
}


// Address: 0xe686c0 | Name: _ZThn8_N5boost15program_options11typed_valueIbcED1Ev
void __fastcall `non-virtual thunk to'boost::program_options::typed_value<bool,char>::~typed_value(
        boost::program_options::typed_value<bool,char> *this)
{
  boost::program_options::typed_value<bool,char>::~typed_value((boost::program_options::typed_value<bool,char> *)((char *)this - 8));
}


// Address: 0xe686d0 | Name: _ZThn8_N5boost15program_options11typed_valueIbcED0Ev
void __fastcall `non-virtual thunk to'boost::program_options::typed_value<bool,char>::~typed_value(
        boost::program_options::typed_value<bool,char> *this)
{
  boost::program_options::typed_value<bool,char>::~typed_value((boost::program_options::typed_value<bool,char> *)((char *)this - 8));
  operator delete((char *)this - 8);
}


