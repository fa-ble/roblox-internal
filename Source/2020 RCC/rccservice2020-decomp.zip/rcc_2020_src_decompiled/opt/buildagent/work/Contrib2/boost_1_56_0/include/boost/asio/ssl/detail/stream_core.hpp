// Address: 0x261a320 | Name: _ZN5boost4asio3ssl6detail11stream_coreC2EP10ssl_ctx_stRNS0_10io_serviceE
void __fastcall boost::asio::ssl::detail::stream_core::stream_core(
        boost::asio::ssl::detail::stream_core *this,
        SSL_CTX *context,
        boost::asio::io_service *io_service)
{
  boost::asio::detail::service_registry *service_registry; // rdi
  boost::asio::detail::service_registry *v6; // rdi
  _BYTE *v7; // rax
  __int64 v8; // rcx
  _BYTE *v9; // rdx
  _BYTE *v10; // rdx
  _BYTE *v11; // rdx
  __int64 v12; // rdx
  _BYTE *v13; // rax
  _BYTE *v14; // rax
  __int64 v15; // rcx
  _BYTE *v16; // rdx
  _BYTE *v17; // rdx
  _BYTE *v18; // rdx
  __int64 v19; // rdx
  _BYTE *v20; // rax
  boost::asio::io_service::service::key_0 key; // [rsp+8h] [rbp-40h] BYREF

  boost::asio::ssl::detail::engine::engine((boost::asio::ssl::detail::engine *)this, context);
  service_registry = io_service->service_registry_;
  key.type_info_ = (const std::type_info *)&`typeinfo for'boost::asio::detail::typeid_wrapper<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>;
  key.id_ = 0;
  *((_QWORD *)this + 2) = boost::asio::detail::service_registry::do_use_service(
                            service_registry,
                            &key,
                            boost::asio::detail::service_registry::create<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>);
  *(_OWORD *)((char *)this + 40) = 0;
  *((_OWORD *)this + 4) = 0;
  *((_QWORD *)this + 3) = 0x7FFFFFFFFFFFFFFELL;
  *((_BYTE *)this + 32) = 0;
  v6 = io_service->service_registry_;
  key.type_info_ = (const std::type_info *)&`typeinfo for'boost::asio::detail::typeid_wrapper<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>;
  key.id_ = 0;
  *((_QWORD *)this + 10) = boost::asio::detail::service_registry::do_use_service(
                             v6,
                             &key,
                             boost::asio::detail::service_registry::create<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>);
  *(_OWORD *)((char *)this + 104) = 0;
  *((_OWORD *)this + 8) = 0;
  *((_QWORD *)this + 11) = 0x7FFFFFFFFFFFFFFELL;
  *((_BYTE *)this + 96) = 0;
  *((_OWORD *)this + 9) = 0;
  *((_QWORD *)this + 20) = 0;
  v7 = operator new(0x4400u);
  *((_QWORD *)this + 19) = v7;
  *((_QWORD *)this + 18) = v7;
  *((_QWORD *)this + 20) = v7 + 17408;
  v8 = -17408;
  do
  {
    *v7 = 0;
    v9 = (_BYTE *)(*((_QWORD *)this + 19) + 1LL);
    *((_QWORD *)this + 19) = v9;
    *v9 = 0;
    v10 = (_BYTE *)(*((_QWORD *)this + 19) + 1LL);
    *((_QWORD *)this + 19) = v10;
    *v10 = 0;
    v11 = (_BYTE *)(*((_QWORD *)this + 19) + 1LL);
    *((_QWORD *)this + 19) = v11;
    *v11 = 0;
    v7 = (_BYTE *)(*((_QWORD *)this + 19) + 1LL);
    *((_QWORD *)this + 19) = v7;
    v8 += 4;
  }
  while ( v8 );
  v12 = 0;
  v13 = &v7[-*((_QWORD *)this + 18)];
  if ( v13 )
    v12 = *((_QWORD *)this + 18);
  *((_QWORD *)this + 21) = v12;
  *((_QWORD *)this + 22) = v13;
  *(_OWORD *)((char *)this + 184) = 0;
  *((_QWORD *)this + 25) = 0;
  v14 = operator new(0x4400u);
  *((_QWORD *)this + 24) = v14;
  *((_QWORD *)this + 23) = v14;
  *((_QWORD *)this + 25) = v14 + 17408;
  v15 = -17408;
  do
  {
    *v14 = 0;
    v16 = (_BYTE *)(*((_QWORD *)this + 24) + 1LL);
    *((_QWORD *)this + 24) = v16;
    *v16 = 0;
    v17 = (_BYTE *)(*((_QWORD *)this + 24) + 1LL);
    *((_QWORD *)this + 24) = v17;
    *v17 = 0;
    v18 = (_BYTE *)(*((_QWORD *)this + 24) + 1LL);
    *((_QWORD *)this + 24) = v18;
    *v18 = 0;
    v14 = (_BYTE *)(*((_QWORD *)this + 24) + 1LL);
    *((_QWORD *)this + 24) = v14;
    v15 += 4;
  }
  while ( v15 );
  v19 = 0;
  v20 = &v14[-*((_QWORD *)this + 23)];
  if ( v20 )
    v19 = *((_QWORD *)this + 23);
  *((_QWORD *)this + 26) = v19;
  *((_QWORD *)this + 27) = v20;
  *((_OWORD *)this + 14) = 0;
  boost::system::system_category();
  if ( *((_BYTE *)this + 32) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)this + 2) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)this + 2)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)this + 1,
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)this + 32) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)this + 3) = 0x8000000000000000LL;
  boost::system::system_category();
  boost::system::system_category();
  if ( *((_BYTE *)this + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)this + 10) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)this + 10)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)this + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)this + 96) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)this + 11) = 0x8000000000000000LL;
  boost::system::system_category();
}


