// Address: 0x11846c0 | Name: _ZN5boost9call_onceIRZN3RBX3Lua20NamecallAtomicBridgeIN3G3D6Color3EE31registerClassAndExportFunctionsEP9lua_StateRKNS2_6BridgeIS5_E11MetaMethodsEPK8luaL_RegEUlvE_JEEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<RBX::Lua::NamecallAtomicBridge<G3D::Color3>::registerClassAndExportFunctions(lua_State *,RBX::Lua::Bridge<G3D::Color3>::MetaMethods const&,luaL_Reg const*)::{lambda(void)#1} &>(
        boost::once_flag *flag,
        struct __cppobj {const luaL_Reg *exportedFunctions;} *f)
{
  const luaL_Reg *exportedFunctions; // r12
  const char *i; // rdi
  lua_CFunction func; // r13
  const RBX::Name *v6; // r14
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  const RBX::Name *v12; // rbp
  __int64 v13; // rbx

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    exportedFunctions = f->exportedFunctions;
    if ( f->exportedFunctions )
    {
      for ( i = exportedFunctions->name; i; ++exportedFunctions )
      {
        func = exportedFunctions->func;
        v6 = RBX::Name::declare(i);
        v7 = xmmword_2A0D6D8;
        v8 = (__int64)(*(&xmmword_2A0D6D8 + 1) - xmmword_2A0D6D8) >> 4;
        if ( qword_2A0D6F0 >= (unsigned __int64)(3 * v8) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Name const*,std::pair<RBX::Name const*,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<RBX::Name const*,int (*)(lua_State *)>,boost::hash<RBX::Name const*>,std::equal_to<RBX::Name const*>>::rehash((RBX::detail::DenseHashTable<const RBX::Name *,std::pair<const RBX::Name *,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<const RBX::Name *,int (*)(lua_State *)>,boost::hash<const RBX::Name *>,std::equal_to<const RBX::Name *> > *)&xmmword_2A0D6D8);
          v7 = xmmword_2A0D6D8;
          v8 = (__int64)(*(&xmmword_2A0D6D8 + 1) - xmmword_2A0D6D8) >> 4;
        }
        v9 = v8 - 1;
        v10 = v9 & ((unsigned __int64)v6 + ((unsigned __int64)v6 >> 3));
        v11 = 16 * v10;
        v12 = *(const RBX::Name **)(v7 + 16 * v10);
        if ( v12 == (const RBX::Name *)qword_2A0D6F8 )
        {
LABEL_12:
          *(_QWORD *)(v7 + v11) = v6;
          ++qword_2A0D6F0;
        }
        else
        {
          v13 = 1;
          while ( v12 != v6 )
          {
            v10 = v9 & (v13 + v10);
            v11 = 16 * v10;
            v12 = *(const RBX::Name **)(v7 + 16 * v10);
            ++v13;
            if ( v12 == (const RBX::Name *)qword_2A0D6F8 )
              goto LABEL_12;
          }
        }
        *(_QWORD *)(v7 + 16 * v10 + 8) = func;
        i = exportedFunctions[1].name;
      }
    }
    boost::thread_detail::commit_once_region(flag);
  }
}


// Address: 0x1185130 | Name: _ZN5boost9call_onceIRZN3RBX3Lua20NamecallAtomicBridgeINS1_6RbxRayEE31registerClassAndExportFunctionsEP9lua_StateRKNS2_6BridgeIS4_E11MetaMethodsEPK8luaL_RegEUlvE_JEEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<RBX::Lua::NamecallAtomicBridge<RBX::RbxRay>::registerClassAndExportFunctions(lua_State *,RBX::Lua::Bridge<RBX::RbxRay>::MetaMethods const&,luaL_Reg const*)::{lambda(void)#1} &>(
        boost::once_flag *flag,
        struct __cppobj {const luaL_Reg *exportedFunctions;} *f)
{
  const luaL_Reg *exportedFunctions; // r12
  const char *i; // rdi
  lua_CFunction func; // r13
  const RBX::Name *v6; // r14
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  const RBX::Name *v12; // rbp
  __int64 v13; // rbx

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    exportedFunctions = f->exportedFunctions;
    if ( f->exportedFunctions )
    {
      for ( i = exportedFunctions->name; i; ++exportedFunctions )
      {
        func = exportedFunctions->func;
        v6 = RBX::Name::declare(i);
        v7 = xmmword_2A0D710;
        v8 = (__int64)(*(&xmmword_2A0D710 + 1) - xmmword_2A0D710) >> 4;
        if ( qword_2A0D728 >= (unsigned __int64)(3 * v8) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Name const*,std::pair<RBX::Name const*,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<RBX::Name const*,int (*)(lua_State *)>,boost::hash<RBX::Name const*>,std::equal_to<RBX::Name const*>>::rehash((RBX::detail::DenseHashTable<const RBX::Name *,std::pair<const RBX::Name *,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<const RBX::Name *,int (*)(lua_State *)>,boost::hash<const RBX::Name *>,std::equal_to<const RBX::Name *> > *)&xmmword_2A0D710);
          v7 = xmmword_2A0D710;
          v8 = (__int64)(*(&xmmword_2A0D710 + 1) - xmmword_2A0D710) >> 4;
        }
        v9 = v8 - 1;
        v10 = v9 & ((unsigned __int64)v6 + ((unsigned __int64)v6 >> 3));
        v11 = 16 * v10;
        v12 = *(const RBX::Name **)(v7 + 16 * v10);
        if ( v12 == (const RBX::Name *)qword_2A0D730 )
        {
LABEL_12:
          *(_QWORD *)(v7 + v11) = v6;
          ++qword_2A0D728;
        }
        else
        {
          v13 = 1;
          while ( v12 != v6 )
          {
            v10 = v9 & (v13 + v10);
            v11 = 16 * v10;
            v12 = *(const RBX::Name **)(v7 + 16 * v10);
            ++v13;
            if ( v12 == (const RBX::Name *)qword_2A0D730 )
              goto LABEL_12;
          }
        }
        *(_QWORD *)(v7 + 16 * v10 + 8) = func;
        i = exportedFunctions[1].name;
      }
    }
    boost::thread_detail::commit_once_region(flag);
  }
}


// Address: 0x11858e0 | Name: _ZN5boost9call_onceIRZN3RBX3Lua20NamecallAtomicBridgeINS1_7Region3EE31registerClassAndExportFunctionsEP9lua_StateRKNS2_6BridgeIS4_E11MetaMethodsEPK8luaL_RegEUlvE_JEEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<RBX::Lua::NamecallAtomicBridge<RBX::Region3>::registerClassAndExportFunctions(lua_State *,RBX::Lua::Bridge<RBX::Region3>::MetaMethods const&,luaL_Reg const*)::{lambda(void)#1} &>(
        boost::once_flag *flag,
        struct __cppobj {const luaL_Reg *exportedFunctions;} *f)
{
  const luaL_Reg *exportedFunctions; // r12
  const char *i; // rdi
  lua_CFunction func; // r13
  const RBX::Name *v6; // r14
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  const RBX::Name *v12; // rbp
  __int64 v13; // rbx

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    exportedFunctions = f->exportedFunctions;
    if ( f->exportedFunctions )
    {
      for ( i = exportedFunctions->name; i; ++exportedFunctions )
      {
        func = exportedFunctions->func;
        v6 = RBX::Name::declare(i);
        v7 = xmmword_2A0D748;
        v8 = (__int64)(*(&xmmword_2A0D748 + 1) - xmmword_2A0D748) >> 4;
        if ( qword_2A0D760 >= (unsigned __int64)(3 * v8) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Name const*,std::pair<RBX::Name const*,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<RBX::Name const*,int (*)(lua_State *)>,boost::hash<RBX::Name const*>,std::equal_to<RBX::Name const*>>::rehash((RBX::detail::DenseHashTable<const RBX::Name *,std::pair<const RBX::Name *,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<const RBX::Name *,int (*)(lua_State *)>,boost::hash<const RBX::Name *>,std::equal_to<const RBX::Name *> > *)&xmmword_2A0D748);
          v7 = xmmword_2A0D748;
          v8 = (__int64)(*(&xmmword_2A0D748 + 1) - xmmword_2A0D748) >> 4;
        }
        v9 = v8 - 1;
        v10 = v9 & ((unsigned __int64)v6 + ((unsigned __int64)v6 >> 3));
        v11 = 16 * v10;
        v12 = *(const RBX::Name **)(v7 + 16 * v10);
        if ( v12 == (const RBX::Name *)qword_2A0D768 )
        {
LABEL_12:
          *(_QWORD *)(v7 + v11) = v6;
          ++qword_2A0D760;
        }
        else
        {
          v13 = 1;
          while ( v12 != v6 )
          {
            v10 = v9 & (v13 + v10);
            v11 = 16 * v10;
            v12 = *(const RBX::Name **)(v7 + 16 * v10);
            ++v13;
            if ( v12 == (const RBX::Name *)qword_2A0D768 )
              goto LABEL_12;
          }
        }
        *(_QWORD *)(v7 + 16 * v10 + 8) = func;
        i = exportedFunctions[1].name;
      }
    }
    boost::thread_detail::commit_once_region(flag);
  }
}


// Address: 0x1186830 | Name: _ZN5boost9call_onceIRZN3RBX3Lua20NamecallAtomicBridgeIN3G3D7Vector3EE31registerClassAndExportFunctionsEP9lua_StateRKNS2_6BridgeIS5_E11MetaMethodsEPK8luaL_RegEUlvE_JEEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<RBX::Lua::NamecallAtomicBridge<G3D::Vector3>::registerClassAndExportFunctions(lua_State *,RBX::Lua::Bridge<G3D::Vector3>::MetaMethods const&,luaL_Reg const*)::{lambda(void)#1} &>(
        boost::once_flag *flag,
        struct __cppobj {const luaL_Reg *exportedFunctions;} *f)
{
  const luaL_Reg *exportedFunctions; // r12
  const char *i; // rdi
  lua_CFunction func; // r13
  const RBX::Name *v6; // r14
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  const RBX::Name *v12; // rbp
  __int64 v13; // rbx

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    exportedFunctions = f->exportedFunctions;
    if ( f->exportedFunctions )
    {
      for ( i = exportedFunctions->name; i; ++exportedFunctions )
      {
        func = exportedFunctions->func;
        v6 = RBX::Name::declare(i);
        v7 = xmmword_2A0D780;
        v8 = (__int64)(*(&xmmword_2A0D780 + 1) - xmmword_2A0D780) >> 4;
        if ( qword_2A0D798 >= (unsigned __int64)(3 * v8) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Name const*,std::pair<RBX::Name const*,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<RBX::Name const*,int (*)(lua_State *)>,boost::hash<RBX::Name const*>,std::equal_to<RBX::Name const*>>::rehash((RBX::detail::DenseHashTable<const RBX::Name *,std::pair<const RBX::Name *,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<const RBX::Name *,int (*)(lua_State *)>,boost::hash<const RBX::Name *>,std::equal_to<const RBX::Name *> > *)&xmmword_2A0D780);
          v7 = xmmword_2A0D780;
          v8 = (__int64)(*(&xmmword_2A0D780 + 1) - xmmword_2A0D780) >> 4;
        }
        v9 = v8 - 1;
        v10 = v9 & ((unsigned __int64)v6 + ((unsigned __int64)v6 >> 3));
        v11 = 16 * v10;
        v12 = *(const RBX::Name **)(v7 + 16 * v10);
        if ( v12 == (const RBX::Name *)qword_2A0D7A0 )
        {
LABEL_12:
          *(_QWORD *)(v7 + v11) = v6;
          ++qword_2A0D798;
        }
        else
        {
          v13 = 1;
          while ( v12 != v6 )
          {
            v10 = v9 & (v13 + v10);
            v11 = 16 * v10;
            v12 = *(const RBX::Name **)(v7 + 16 * v10);
            ++v13;
            if ( v12 == (const RBX::Name *)qword_2A0D7A0 )
              goto LABEL_12;
          }
        }
        *(_QWORD *)(v7 + 16 * v10 + 8) = func;
        i = exportedFunctions[1].name;
      }
    }
    boost::thread_detail::commit_once_region(flag);
  }
}


// Address: 0x1187190 | Name: _ZN5boost9call_onceIRZN3RBX3Lua20NamecallAtomicBridgeIN3G3D7Vector2EE31registerClassAndExportFunctionsEP9lua_StateRKNS2_6BridgeIS5_E11MetaMethodsEPK8luaL_RegEUlvE_JEEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<RBX::Lua::NamecallAtomicBridge<G3D::Vector2>::registerClassAndExportFunctions(lua_State *,RBX::Lua::Bridge<G3D::Vector2>::MetaMethods const&,luaL_Reg const*)::{lambda(void)#1} &>(
        boost::once_flag *flag,
        struct __cppobj {const luaL_Reg *exportedFunctions;} *f)
{
  const luaL_Reg *exportedFunctions; // r12
  const char *i; // rdi
  lua_CFunction func; // r13
  const RBX::Name *v6; // r14
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  const RBX::Name *v12; // rbp
  __int64 v13; // rbx

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    exportedFunctions = f->exportedFunctions;
    if ( f->exportedFunctions )
    {
      for ( i = exportedFunctions->name; i; ++exportedFunctions )
      {
        func = exportedFunctions->func;
        v6 = RBX::Name::declare(i);
        v7 = xmmword_2A0D7B8;
        v8 = (__int64)(*(&xmmword_2A0D7B8 + 1) - xmmword_2A0D7B8) >> 4;
        if ( qword_2A0D7D0 >= (unsigned __int64)(3 * v8) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Name const*,std::pair<RBX::Name const*,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<RBX::Name const*,int (*)(lua_State *)>,boost::hash<RBX::Name const*>,std::equal_to<RBX::Name const*>>::rehash((RBX::detail::DenseHashTable<const RBX::Name *,std::pair<const RBX::Name *,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<const RBX::Name *,int (*)(lua_State *)>,boost::hash<const RBX::Name *>,std::equal_to<const RBX::Name *> > *)&xmmword_2A0D7B8);
          v7 = xmmword_2A0D7B8;
          v8 = (__int64)(*(&xmmword_2A0D7B8 + 1) - xmmword_2A0D7B8) >> 4;
        }
        v9 = v8 - 1;
        v10 = v9 & ((unsigned __int64)v6 + ((unsigned __int64)v6 >> 3));
        v11 = 16 * v10;
        v12 = *(const RBX::Name **)(v7 + 16 * v10);
        if ( v12 == (const RBX::Name *)qword_2A0D7D8 )
        {
LABEL_12:
          *(_QWORD *)(v7 + v11) = v6;
          ++qword_2A0D7D0;
        }
        else
        {
          v13 = 1;
          while ( v12 != v6 )
          {
            v10 = v9 & (v13 + v10);
            v11 = 16 * v10;
            v12 = *(const RBX::Name **)(v7 + 16 * v10);
            ++v13;
            if ( v12 == (const RBX::Name *)qword_2A0D7D8 )
              goto LABEL_12;
          }
        }
        *(_QWORD *)(v7 + 16 * v10 + 8) = func;
        i = exportedFunctions[1].name;
      }
    }
    boost::thread_detail::commit_once_region(flag);
  }
}


// Address: 0x1187f30 | Name: _ZN5boost9call_onceIRZN3RBX3Lua20NamecallAtomicBridgeIN3G3D15CoordinateFrameEE31registerClassAndExportFunctionsEP9lua_StateRKNS2_6BridgeIS5_E11MetaMethodsEPK8luaL_RegEUlvE_JEEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<RBX::Lua::NamecallAtomicBridge<G3D::CoordinateFrame>::registerClassAndExportFunctions(lua_State *,RBX::Lua::Bridge<G3D::CoordinateFrame>::MetaMethods const&,luaL_Reg const*)::{lambda(void)#1} &>(
        boost::once_flag *flag,
        struct __cppobj {const luaL_Reg *exportedFunctions;} *f)
{
  const luaL_Reg *exportedFunctions; // r12
  const char *i; // rdi
  lua_CFunction func; // r13
  const RBX::Name *v6; // r14
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  const RBX::Name *v12; // rbp
  __int64 v13; // rbx

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    exportedFunctions = f->exportedFunctions;
    if ( f->exportedFunctions )
    {
      for ( i = exportedFunctions->name; i; ++exportedFunctions )
      {
        func = exportedFunctions->func;
        v6 = RBX::Name::declare(i);
        v7 = xmmword_2A0D7F0;
        v8 = (__int64)(*(&xmmword_2A0D7F0 + 1) - xmmword_2A0D7F0) >> 4;
        if ( qword_2A0D808 >= (unsigned __int64)(3 * v8) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Name const*,std::pair<RBX::Name const*,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<RBX::Name const*,int (*)(lua_State *)>,boost::hash<RBX::Name const*>,std::equal_to<RBX::Name const*>>::rehash((RBX::detail::DenseHashTable<const RBX::Name *,std::pair<const RBX::Name *,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<const RBX::Name *,int (*)(lua_State *)>,boost::hash<const RBX::Name *>,std::equal_to<const RBX::Name *> > *)&xmmword_2A0D7F0);
          v7 = xmmword_2A0D7F0;
          v8 = (__int64)(*(&xmmword_2A0D7F0 + 1) - xmmword_2A0D7F0) >> 4;
        }
        v9 = v8 - 1;
        v10 = v9 & ((unsigned __int64)v6 + ((unsigned __int64)v6 >> 3));
        v11 = 16 * v10;
        v12 = *(const RBX::Name **)(v7 + 16 * v10);
        if ( v12 == (const RBX::Name *)qword_2A0D810 )
        {
LABEL_12:
          *(_QWORD *)(v7 + v11) = v6;
          ++qword_2A0D808;
        }
        else
        {
          v13 = 1;
          while ( v12 != v6 )
          {
            v10 = v9 & (v13 + v10);
            v11 = 16 * v10;
            v12 = *(const RBX::Name **)(v7 + 16 * v10);
            ++v13;
            if ( v12 == (const RBX::Name *)qword_2A0D810 )
              goto LABEL_12;
          }
        }
        *(_QWORD *)(v7 + 16 * v10 + 8) = func;
        i = exportedFunctions[1].name;
      }
    }
    boost::thread_detail::commit_once_region(flag);
  }
}


// Address: 0x11886f0 | Name: _ZN5boost9call_onceIRZN3RBX3Lua20NamecallAtomicBridgeINS1_8DateTimeEE31registerClassAndExportFunctionsEP9lua_StateRKNS2_6BridgeIS4_E11MetaMethodsEPK8luaL_RegEUlvE_JEEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<RBX::Lua::NamecallAtomicBridge<RBX::DateTime>::registerClassAndExportFunctions(lua_State *,RBX::Lua::Bridge<RBX::DateTime>::MetaMethods const&,luaL_Reg const*)::{lambda(void)#1} &>(
        boost::once_flag *flag,
        struct __cppobj {const luaL_Reg *exportedFunctions;} *f)
{
  const luaL_Reg *exportedFunctions; // r12
  const char *i; // rdi
  lua_CFunction func; // r13
  const RBX::Name *v6; // r14
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  const RBX::Name *v12; // rbp
  __int64 v13; // rbx

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    exportedFunctions = f->exportedFunctions;
    if ( f->exportedFunctions )
    {
      for ( i = exportedFunctions->name; i; ++exportedFunctions )
      {
        func = exportedFunctions->func;
        v6 = RBX::Name::declare(i);
        v7 = xmmword_2A0D828;
        v8 = (__int64)(*(&xmmword_2A0D828 + 1) - xmmword_2A0D828) >> 4;
        if ( qword_2A0D840 >= (unsigned __int64)(3 * v8) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Name const*,std::pair<RBX::Name const*,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<RBX::Name const*,int (*)(lua_State *)>,boost::hash<RBX::Name const*>,std::equal_to<RBX::Name const*>>::rehash((RBX::detail::DenseHashTable<const RBX::Name *,std::pair<const RBX::Name *,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<const RBX::Name *,int (*)(lua_State *)>,boost::hash<const RBX::Name *>,std::equal_to<const RBX::Name *> > *)&xmmword_2A0D828);
          v7 = xmmword_2A0D828;
          v8 = (__int64)(*(&xmmword_2A0D828 + 1) - xmmword_2A0D828) >> 4;
        }
        v9 = v8 - 1;
        v10 = v9 & ((unsigned __int64)v6 + ((unsigned __int64)v6 >> 3));
        v11 = 16 * v10;
        v12 = *(const RBX::Name **)(v7 + 16 * v10);
        if ( v12 == (const RBX::Name *)qword_2A0D848 )
        {
LABEL_12:
          *(_QWORD *)(v7 + v11) = v6;
          ++qword_2A0D840;
        }
        else
        {
          v13 = 1;
          while ( v12 != v6 )
          {
            v10 = v9 & (v13 + v10);
            v11 = 16 * v10;
            v12 = *(const RBX::Name **)(v7 + 16 * v10);
            ++v13;
            if ( v12 == (const RBX::Name *)qword_2A0D848 )
              goto LABEL_12;
          }
        }
        *(_QWORD *)(v7 + 16 * v10 + 8) = func;
        i = exportedFunctions[1].name;
      }
    }
    boost::thread_detail::commit_once_region(flag);
  }
}


// Address: 0x1189030 | Name: _ZN5boost9call_onceIRZN3RBX3Lua20NamecallAtomicBridgeINS1_5UDim2EE31registerClassAndExportFunctionsEP9lua_StateRKNS2_6BridgeIS4_E11MetaMethodsEPK8luaL_RegEUlvE_JEEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<RBX::Lua::NamecallAtomicBridge<RBX::UDim2>::registerClassAndExportFunctions(lua_State *,RBX::Lua::Bridge<RBX::UDim2>::MetaMethods const&,luaL_Reg const*)::{lambda(void)#1} &>(
        boost::once_flag *flag,
        struct __cppobj {const luaL_Reg *exportedFunctions;} *f)
{
  const luaL_Reg *exportedFunctions; // r12
  const char *i; // rdi
  lua_CFunction func; // r13
  const RBX::Name *v6; // r14
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  const RBX::Name *v12; // rbp
  __int64 v13; // rbx

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    exportedFunctions = f->exportedFunctions;
    if ( f->exportedFunctions )
    {
      for ( i = exportedFunctions->name; i; ++exportedFunctions )
      {
        func = exportedFunctions->func;
        v6 = RBX::Name::declare(i);
        v7 = xmmword_2A0D860;
        v8 = (__int64)(*(&xmmword_2A0D860 + 1) - xmmword_2A0D860) >> 4;
        if ( qword_2A0D878 >= (unsigned __int64)(3 * v8) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Name const*,std::pair<RBX::Name const*,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<RBX::Name const*,int (*)(lua_State *)>,boost::hash<RBX::Name const*>,std::equal_to<RBX::Name const*>>::rehash((RBX::detail::DenseHashTable<const RBX::Name *,std::pair<const RBX::Name *,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<const RBX::Name *,int (*)(lua_State *)>,boost::hash<const RBX::Name *>,std::equal_to<const RBX::Name *> > *)&xmmword_2A0D860);
          v7 = xmmword_2A0D860;
          v8 = (__int64)(*(&xmmword_2A0D860 + 1) - xmmword_2A0D860) >> 4;
        }
        v9 = v8 - 1;
        v10 = v9 & ((unsigned __int64)v6 + ((unsigned __int64)v6 >> 3));
        v11 = 16 * v10;
        v12 = *(const RBX::Name **)(v7 + 16 * v10);
        if ( v12 == (const RBX::Name *)qword_2A0D880 )
        {
LABEL_12:
          *(_QWORD *)(v7 + v11) = v6;
          ++qword_2A0D878;
        }
        else
        {
          v13 = 1;
          while ( v12 != v6 )
          {
            v10 = v9 & (v13 + v10);
            v11 = 16 * v10;
            v12 = *(const RBX::Name **)(v7 + 16 * v10);
            ++v13;
            if ( v12 == (const RBX::Name *)qword_2A0D880 )
              goto LABEL_12;
          }
        }
        *(_QWORD *)(v7 + 16 * v10 + 8) = func;
        i = exportedFunctions[1].name;
      }
    }
    boost::thread_detail::commit_once_region(flag);
  }
}


// Address: 0x1189880 | Name: _ZN5boost9call_onceIRZN3RBX3Lua20NamecallAtomicBridgeINS1_6RandomEE31registerClassAndExportFunctionsEP9lua_StateRKNS2_6BridgeIS4_E11MetaMethodsEPK8luaL_RegEUlvE_JEEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<RBX::Lua::NamecallAtomicBridge<RBX::Random>::registerClassAndExportFunctions(lua_State *,RBX::Lua::Bridge<RBX::Random>::MetaMethods const&,luaL_Reg const*)::{lambda(void)#1} &>(
        boost::once_flag *flag,
        struct __cppobj {const luaL_Reg *exportedFunctions;} *f)
{
  const luaL_Reg *exportedFunctions; // r12
  const char *i; // rdi
  lua_CFunction func; // r13
  const RBX::Name *v6; // r14
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  const RBX::Name *v12; // rbp
  __int64 v13; // rbx

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    exportedFunctions = f->exportedFunctions;
    if ( f->exportedFunctions )
    {
      for ( i = exportedFunctions->name; i; ++exportedFunctions )
      {
        func = exportedFunctions->func;
        v6 = RBX::Name::declare(i);
        v7 = xmmword_2A0D898;
        v8 = (__int64)(*(&xmmword_2A0D898 + 1) - xmmword_2A0D898) >> 4;
        if ( qword_2A0D8B0 >= (unsigned __int64)(3 * v8) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Name const*,std::pair<RBX::Name const*,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<RBX::Name const*,int (*)(lua_State *)>,boost::hash<RBX::Name const*>,std::equal_to<RBX::Name const*>>::rehash((RBX::detail::DenseHashTable<const RBX::Name *,std::pair<const RBX::Name *,int (*)(lua_State *)>,RBX::detail::ItemInterfaceMap<const RBX::Name *,int (*)(lua_State *)>,boost::hash<const RBX::Name *>,std::equal_to<const RBX::Name *> > *)&xmmword_2A0D898);
          v7 = xmmword_2A0D898;
          v8 = (__int64)(*(&xmmword_2A0D898 + 1) - xmmword_2A0D898) >> 4;
        }
        v9 = v8 - 1;
        v10 = v9 & ((unsigned __int64)v6 + ((unsigned __int64)v6 >> 3));
        v11 = 16 * v10;
        v12 = *(const RBX::Name **)(v7 + 16 * v10);
        if ( v12 == (const RBX::Name *)qword_2A0D8B8 )
        {
LABEL_12:
          *(_QWORD *)(v7 + v11) = v6;
          ++qword_2A0D8B0;
        }
        else
        {
          v13 = 1;
          while ( v12 != v6 )
          {
            v10 = v9 & (v13 + v10);
            v11 = 16 * v10;
            v12 = *(const RBX::Name **)(v7 + 16 * v10);
            ++v13;
            if ( v12 == (const RBX::Name *)qword_2A0D8B8 )
              goto LABEL_12;
          }
        }
        *(_QWORD *)(v7 + 16 * v10 + 8) = func;
        i = exportedFunctions[1].name;
      }
    }
    boost::thread_detail::commit_once_region(flag);
  }
}


// Address: 0x1a62570 | Name: _ZN5boost9call_onceINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX9DataModelEEEENS1_5list1INS1_5valueIS6_EEEEEEJEEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>>>>(
        boost::once_flag *flag,
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::DataModel> > > > *f)
{
  void (*v3)(boost::weak_ptr<RBX::DataModel>); // rax
  boost::weak_ptr<RBX::DataModel>::element_type *px; // rcx
  boost::detail::sp_counted_base *pi; // r12
  boost::detail::sp_counted_base *v6; // rdi
  boost::weak_ptr<RBX::DataModel>::element_type *v7; // [rsp+8h] [rbp-30h] BYREF
  boost::detail::sp_counted_base *v8; // [rsp+10h] [rbp-28h]

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    v3 = f->f_;
    px = f->l_.a1_.t_.px;
    pi = f->l_.a1_.t_.pn.pi_;
    f->l_ = 0;
    v7 = px;
    v8 = pi;
    if ( pi )
      _InterlockedAdd(&pi->weak_count_, 1u);
    ((void (__fastcall *)(boost::weak_ptr<RBX::DataModel>::element_type **))v3)(&v7);
    v6 = v8;
    if ( v8 && !_InterlockedSub(&v8->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    if ( pi )
    {
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
    boost::thread_detail::commit_once_region(flag);
  }
}


// Address: 0x1abc110 | Name: _ZN5boost9call_onceIPFvRKN3RBX9TextureIdEEJS4_EEEvRNS_9once_flagEOT_DpOT0_
void __fastcall boost::call_once<void (*)(RBX::TextureId const&),RBX::TextureId const&>(
        boost::once_flag *flag,
        void (**f)(const RBX::TextureId *),
        const RBX::TextureId *args)
{
  void (*v4)(const RBX::TextureId *); // rbx
  _BYTE v5[16]; // [rsp+8h] [rbp-30h] BYREF
  void *ptr; // [rsp+18h] [rbp-20h]

  if ( boost::thread_detail::enter_once_region(flag) )
  {
    v4 = *f;
    std::string::basic_string(v5, args);
    v4((const RBX::TextureId *)v5);
    if ( (v5[0] & 1) != 0 )
      operator delete(ptr);
    boost::thread_detail::commit_once_region(flag);
  }
}


