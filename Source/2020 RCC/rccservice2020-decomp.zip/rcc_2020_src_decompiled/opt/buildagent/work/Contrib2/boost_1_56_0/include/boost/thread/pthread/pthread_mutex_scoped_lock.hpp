// Address: 0x2842960 | Name: _ZN5boost7pthread25pthread_mutex_scoped_lockD2Ev
void __fastcall boost::pthread::pthread_mutex_scoped_lock::~pthread_mutex_scoped_lock(
        boost::pthread::pthread_mutex_scoped_lock *this)
{
  if ( this->locked )
  {
    pthread_mutex_unlock(this->m);
    this->locked = 0;
  }
}


