// Address: 0xe603e0 | Name: _ZNK5boost9tokenizerINS_14char_separatorIcNSt3__111char_traitsIcEEEENS2_11__wrap_iterIPKcEENS2_12basic_stringIcS4_NS2_9allocatorIcEEEEE5beginEv
void __fastcall boost::tokenizer<boost::char_separator<char,std::char_traits<char>>,std::__wrap_iter<char const*>,std::string>::begin(
        boost::char_separator<char,std::char_traits<char> > *a1,
        const boost::tokenizer<boost::char_separator<char,std::char_traits<char> >,std::__wrap_iter<const char *>,std::string > *this)
{
  _BYTE v2[16]; // [rsp+8h] [rbp-50h] BYREF
  void *v3; // [rsp+18h] [rbp-40h]
  _BYTE v4[16]; // [rsp+20h] [rbp-38h] BYREF
  void *ptr; // [rsp+30h] [rbp-28h]
  __int64 v6; // [rsp+38h] [rbp-20h]
  char v7; // [rsp+40h] [rbp-18h]

  std::string::basic_string(v2, (char *)this + 16);
  std::string::basic_string(v4, (char *)this + 40);
  v7 = *((_BYTE *)this + 72);
  v6 = *((_QWORD *)this + 8);
  boost::token_iterator<boost::char_separator<char,std::char_traits<char>>,std::__wrap_iter<char const*>,std::string>::token_iterator(a1);
  if ( (v4[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v2[0] & 1) != 0 )
    operator delete(v3);
}


// Address: 0xe604b0 | Name: _ZNK5boost9tokenizerINS_14char_separatorIcNSt3__111char_traitsIcEEEENS2_11__wrap_iterIPKcEENS2_12basic_stringIcS4_NS2_9allocatorIcEEEEE3endEv
void __fastcall boost::tokenizer<boost::char_separator<char,std::char_traits<char>>,std::__wrap_iter<char const*>,std::string>::end(
        __int64 a1,
        const boost::tokenizer<boost::char_separator<char,std::char_traits<char> >,std::__wrap_iter<const char *>,std::string > *this)
{
  __int64 v2; // rbx
  _BYTE v3[16]; // [rsp+0h] [rbp-58h] BYREF
  void *v4; // [rsp+10h] [rbp-48h]
  _BYTE v5[16]; // [rsp+18h] [rbp-40h] BYREF
  void *ptr; // [rsp+28h] [rbp-30h]
  __int64 v7; // [rsp+30h] [rbp-28h]
  char v8; // [rsp+38h] [rbp-20h]

  std::string::basic_string(v3, (char *)this + 16);
  std::string::basic_string(v5, (char *)this + 40);
  v8 = *((_BYTE *)this + 72);
  v7 = *((_QWORD *)this + 8);
  v2 = *((_QWORD *)this + 1);
  std::string::basic_string(a1, v3);
  std::string::basic_string(a1 + 24, v5);
  *(_BYTE *)(a1 + 56) = v8;
  *(_QWORD *)(a1 + 48) = v7;
  *(_QWORD *)(a1 + 64) = v2;
  *(_QWORD *)(a1 + 72) = v2;
  *(_OWORD *)(a1 + 88) = 0;
  *(_QWORD *)(a1 + 104) = 0;
  *(_BYTE *)(a1 + 80) = 0;
  if ( (v5[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v3[0] & 1) != 0 )
    operator delete(v4);
}


