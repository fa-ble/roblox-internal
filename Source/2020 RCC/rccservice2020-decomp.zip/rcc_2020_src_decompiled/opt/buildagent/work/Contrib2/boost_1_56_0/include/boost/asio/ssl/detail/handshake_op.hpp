// Address: 0x26371e0 | Name: _ZNK5boost4asio3ssl6detail12handshake_op12call_handlerINSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNS5_10shared_ptrISB_EERSH_RKNS5_12placeholders4__phILi1EEEEEEEEvRT_SL_RKm
void __fastcall boost::asio::ssl::detail::handshake_op::call_handler<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>(
        const boost::asio::ssl::detail::handshake_op *this,
        std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *handler,
        const boost::system::error_code *ec,
        const size_t *a4)
{
  std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd f; // r12
  _QWORD *v6; // rbx
  std::function<void (const std::error_code &)>::__base *v7; // rdi
  std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *v8; // rsi
  _BYTE v9[32]; // [rsp+0h] [rbp-58h] BYREF
  _BYTE *v10; // [rsp+20h] [rbp-38h]
  unsigned __int64 v11; // [rsp+30h] [rbp-28h]

  v11 = __readfsqword(0x28u);
  f = handler->__f_;
  v6 = (std::weak_ptr<websocketpp::transport::asio::tls_socket::connection>::element_type **)((char *)&handler->__bound_args_.__base_.__value_.__ptr_->__weak_this_.__ptr_
                                                                                            + *((_QWORD *)&handler->__f_
                                                                                              + 1));
  if ( ((__int64)handler->__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd *)((char *)f + *v6 - 1);
  v7 = handler->__bound_args_.__base_.__value_.__f_;
  if ( v7 )
  {
    v8 = &handler->__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
    if ( v8 == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v7 )
    {
      v10 = v9;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *, const boost::system::error_code *, const size_t *))v7->_vptr$__base
       + 3))(
        v7,
        v9,
        ec,
        a4);
    }
    else
    {
      v10 = (_BYTE *)(*((__int64 (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, const size_t *))v7->_vptr$__base
                      + 2))(
                       v7,
                       v8,
                       ec,
                       a4);
    }
  }
  else
  {
    v10 = 0;
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, const boost::system::error_code *))f)(v6, v9, ec);
  if ( v9 == v10 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v10 + 32LL))(v10);
  }
  else if ( v10 )
  {
    (*(void (**)(void))(*(_QWORD *)v10 + 40LL))();
  }
}


