// Address: 0xf12600 | Name: _ZN3RBX7Network9ItemQueueD2Ev
void __fastcall RBX::Network::ItemQueue::~ItemQueue(RBX::Network::ItemQueue *this)
{
  RBX::Network::ItemQueue *next; // rcx
  RBX::Network::ItemQueue *size; // rdx

  next = (RBX::Network::ItemQueue *)this->itemList.data_.root_plus_size_.m_header.next_;
  if ( &this->itemList.data_.root_plus_size_.m_header != (boost::intrusive::list_impl<boost::intrusive::bhtraits<RBX::Network::Item,boost::intrusive::list_node_traits<void *>,boost::intrusive::safe_link,RBX::Network::ItemTag,1>,unsigned long,true,void>::header_holder_type *)next )
  {
    do
    {
      size = (RBX::Network::ItemQueue *)next->itemList.data_.root_plus_size_.size_;
      next->itemList.data_.root_plus_size_.size_ = 0;
      next->itemList.data_.root_plus_size_.m_header.next_ = 0;
      next = size;
    }
    while ( &this->itemList.data_.root_plus_size_.m_header != (boost::intrusive::list_impl<boost::intrusive::bhtraits<RBX::Network::Item,boost::intrusive::list_node_traits<void *>,boost::intrusive::safe_link,RBX::Network::ItemTag,1>,unsigned long,true,void>::header_holder_type *)size );
  }
  *(_OWORD *)&this->itemList.data_.root_plus_size_.size_ = 0;
  this->itemList.data_.root_plus_size_.m_header.prev_ = 0;
}


// Address: 0xf126b0 | Name: _ZNK3RBX7Network9ItemQueue5emptyEv
bool __fastcall RBX::Network::ItemQueue::empty(const RBX::Network::ItemQueue *this)
{
  return this->itemList.data_.root_plus_size_.m_header.next_ == 0
      || this->itemList.data_.root_plus_size_.m_header.next_ == &this->itemList.data_.root_plus_size_.m_header;
}


// Address: 0xf12710 | Name: _ZNK3RBX7Network9ItemQueue9head_timeEv
RBX::Time __fastcall RBX::Network::ItemQueue::head_time(const RBX::Network::ItemQueue *this)
{
  boost::intrusive::list_node<void *>::node_ptr next; // rax
  RBX::Time result; // xmm0_8

  next = this->itemList.data_.root_plus_size_.m_header.next_;
  *(RBX::Time *)&result.sec = 0;
  if ( next )
  {
    if ( next != &this->itemList.data_.root_plus_size_.m_header )
      return (RBX::Time)next[2].next_;
  }
  return result;
}


// Address: 0xf12790 | Name: _ZN3RBX7Network9ItemQueue14pop_if_presentERPNS0_4ItemE
bool __fastcall RBX::Network::ItemQueue::pop_if_present(RBX::Network::ItemQueue *this, RBX::Network::Item **item)
{
  RBX::Network::ItemQueue *next; // rcx
  bool result; // al
  boost::intrusive::list_node<void *>::node_ptr v4; // rax
  boost::intrusive::list_node<void *>::node_ptr v5; // rcx
  boost::intrusive::list_node<void *> *prev; // rdx

  next = (RBX::Network::ItemQueue *)this->itemList.data_.root_plus_size_.m_header.next_;
  result = 0;
  if ( next )
  {
    if ( next != (RBX::Network::ItemQueue *)&this->itemList.data_.root_plus_size_.m_header )
    {
      *item = (RBX::Network::Item *)&next[-1].itemList.data_.root_plus_size_.m_header.prev_;
      v4 = this->itemList.data_.root_plus_size_.m_header.next_;
      v5 = v4->next_;
      prev = v4->prev_;
      prev->next_ = v4->next_;
      v5->prev_ = prev;
      --this->itemList.data_.root_plus_size_.size_;
      *v4 = 0;
      return 1;
    }
  }
  return result;
}


// Address: 0xf12850 | Name: _ZN3RBX7Network9ItemQueue29push_front_preserve_timestampEPNS0_4ItemE
void __fastcall RBX::Network::ItemQueue::push_front_preserve_timestamp(
        RBX::Network::ItemQueue *this,
        RBX::Network::Item *item)
{
  boost::intrusive::list_node<void *>::node_ptr next; // rax
  boost::intrusive::list_node<void *> *prev; // rcx

  next = this->itemList.data_.root_plus_size_.m_header.next_;
  prev = next->prev_;
  item->prev_ = prev;
  item->next_ = next;
  next->prev_ = &item->RBX::Network::ItemHook;
  prev->next_ = &item->RBX::Network::ItemHook;
  ++this->itemList.data_.root_plus_size_.size_;
}


// Address: 0xf8dfd0 | Name: _ZN3RBX7Network10Replicator18ChangePropertyItemC2EPS1_RKNS_10Reflection18PropertyDescriptorERKNS0_13NetworkSchema13ClassPropertyERKN5boost10shared_ptrIKNS_8InstanceEEE
void __fastcall RBX::Network::Replicator::ChangePropertyItem::ChangePropertyItem(
        RBX::Network::Replicator::ChangePropertyItem *this,
        RBX::Network::Replicator *replicator,
        const RBX::Reflection::PropertyDescriptor *desc,
        const RBX::Network::NetworkSchema::ClassProperty *classProperty,
        const boost::shared_ptr<const RBX::Instance> *instance)
{
  boost::detail::sp_counted_base *pi; // rax

  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))off_2885C28;
  this->desc = desc;
  this->classProperty = classProperty;
  this->instance.px = instance->px;
  pi = instance->pn.pi_;
  this->instance.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
}


// Address: 0xf92c60 | Name: _ZN3RBX7Network10Replicator19EventInvocationItemC2EPS1_RKN5boost10shared_ptrINS_8InstanceEEERKNS_10Reflection15EventDescriptorERKNS0_13NetworkSchema10ClassEventERKNS5_IKNSt3__16vectorINSA_7VariantENSI_9allocatorISK_EEEEEE
void __fastcall RBX::Network::Replicator::EventInvocationItem::EventInvocationItem(
        RBX::Network::Replicator::EventInvocationItem *this,
        RBX::Network::Replicator *replicator,
        const boost::shared_ptr<RBX::Instance> *instance,
        const RBX::Reflection::EventDescriptor *desc,
        const RBX::Network::NetworkSchema::ClassEvent *classEvent,
        const boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > *sharedArguments)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v7; // rax

  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))off_2886358;
  this->instance.px = instance->px;
  pi = instance->pn.pi_;
  this->instance.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  this->desc = desc;
  this->classEvent = classEvent;
  this->sharedArguments.px = sharedArguments->px;
  v7 = sharedArguments->pn.pi_;
  this->sharedArguments.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
}


// Address: 0xf9d4e0 | Name: _ZN3RBX7Network10Replicator10MarkerItemC2EPS1_i
void __fastcall RBX::Network::Replicator::MarkerItem::MarkerItem(
        RBX::Network::Replicator::MarkerItem *this,
        RBX::Network::Replicator *replicator,
        int id)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_2886610;
  this->id = id;
}


// Address: 0xf9d9b0 | Name: _ZN3RBX7Network10Replicator12PingBackItemC2EPS1_mj
void __fastcall RBX::Network::Replicator::PingBackItem::PingBackItem(
        RBX::Network::Replicator::PingBackItem *this,
        RBX::Network::Replicator *replicator,
        RakNet::Time time,
        unsigned int extraStats)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_2886710;
  this->time = time;
  this->extraStats = extraStats;
}


// Address: 0xf9ec00 | Name: _ZN3RBX7Network10Replicator9RockyItemC2EPS1_RNS0_9MccReportE
void __fastcall RBX::Network::Replicator::RockyItem::RockyItem(
        RBX::Network::Replicator::RockyItem *this,
        RBX::Network::Replicator *replicator,
        RBX::Network::MccReport *report)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_28868E0;
  this->report = *report;
}


// Address: 0xf9ed50 | Name: _ZN3RBX7Network10Replicator18NetPmcResponseItemC2EPS1_jmh
void __fastcall RBX::Network::Replicator::NetPmcResponseItem::NetPmcResponseItem(
        RBX::Network::Replicator::NetPmcResponseItem *this,
        RBX::Network::Replicator *replicator,
        uint32_t response,
        uint64_t correct,
        uint8_t idx)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_2886920;
  this->response = response;
  this->correct = correct;
  this->idx = idx;
}


// Address: 0xf9ee60 | Name: _ZN3RBX7Network10Replicator7CsrItemC2EPS1_NSt3__110shared_ptrINS_8Security3CsrEEE
void __fastcall RBX::Network::Replicator::CsrItem::CsrItem(
        RBX::Network::Replicator::CsrItem *this,
        RBX::Network::Replicator *replicator,
        std::shared_ptr<RBX::Security::Csr>_0 p)
{
  volatile signed __int64 *v3; // rax

  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))off_2886960;
  this->version = 1;
  this->report.__ptr_ = (std::shared_ptr<RBX::Security::Csr>::element_type *)p.__ptr_->_vptr$Csr;
  v3 = *(volatile signed __int64 **)&p.__ptr_->type;
  this->report.__cntrl_ = (std::__shared_weak_count *)v3;
  if ( v3 )
    _InterlockedAdd64(v3 + 1, 1u);
}


// Address: 0xf9f670 | Name: _ZN3RBX7Network10Replicator14IdResponseItemC2EPS1_jj
void __fastcall RBX::Network::Replicator::IdResponseItem::IdResponseItem(
        RBX::Network::Replicator::IdResponseItem *this,
        RBX::Network::Replicator *replicator,
        uint32_t challenge,
        uint32_t response)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_28869A0;
  this->challenge = challenge;
  this->response = response;
}


// Address: 0xf9f740 | Name: _ZN3RBX7Network10Replicator15AacResponseItemC2EPS1_RKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEE
void __fastcall RBX::Network::Replicator::AacResponseItem::AacResponseItem(
        RBX::Network::Replicator::AacResponseItem *this,
        RBX::Network::Replicator *replicator,
        const std::string *title)
{
  *(_OWORD *)((char *)this + 8) = 0;
  *((_QWORD *)this + 3) = replicator;
  *((_BYTE *)this + 32) = 0;
  *((_QWORD *)this + 5) = 0;
  *(_QWORD *)this = off_28869E0;
  std::string::basic_string((char *)this + 48, title);
}


// Address: 0xf9f7c0 | Name: _ZN3RBX7Network10Replicator19NetPmcChallengeItemC2EPS1_h
void __fastcall RBX::Network::Replicator::NetPmcChallengeItem::NetPmcChallengeItem(
        RBX::Network::Replicator::NetPmcChallengeItem *this,
        RBX::Network::Replicator *replicator,
        uint8_t idx)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_2886A20;
  this->idx = idx;
}


// Address: 0xf9f930 | Name: _ZN3RBX7Network10Replicator15IdChallengeItemC2EPS1_j
void __fastcall RBX::Network::Replicator::IdChallengeItem::IdChallengeItem(
        RBX::Network::Replicator::IdChallengeItem *this,
        RBX::Network::Replicator *replicator,
        uint32_t challenge)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_2886A60;
  this->challenge = challenge;
}


// Address: 0xf9f9d0 | Name: _ZN3RBX7Network10Replicator16AacChallengeItemC2EPS1_
void __fastcall RBX::Network::Replicator::AacChallengeItem::AacChallengeItem(
        RBX::Network::Replicator::AacChallengeItem *this,
        RBX::Network::Replicator *replicator)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_2886AA0;
}


// Address: 0xf9fa40 | Name: _ZN3RBX7Network10Replicator22TimeoutInfoRequestItemC2EPS1_
void __fastcall RBX::Network::Replicator::TimeoutInfoRequestItem::TimeoutInfoRequestItem(
        RBX::Network::Replicator::TimeoutInfoRequestItem *this,
        RBX::Network::Replicator *replicator)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_2886AE0;
}


// Address: 0xf9fab0 | Name: _ZN3RBX7Network10Replicator22ClientCrashRequestItemC2EPS1_
void __fastcall RBX::Network::Replicator::ClientCrashRequestItem::ClientCrashRequestItem(
        RBX::Network::Replicator::ClientCrashRequestItem *this,
        RBX::Network::Replicator *replicator)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_2886B20;
}


// Address: 0xf9fb20 | Name: _ZN3RBX7Network10Replicator13PmcConfigItemC2EPS1_hj
void __fastcall RBX::Network::Replicator::PmcConfigItem::PmcConfigItem(
        RBX::Network::Replicator::PmcConfigItem *this,
        RBX::Network::Replicator *replicator,
        uint8_t idx,
        uint32_t value)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_2886B60;
  this->idx = idx;
  this->value = value;
}


// Address: 0xfa0b60 | Name: _ZN3RBX7Network10Replicator7TagItemC2EPS1_NS0_11TagItemTypeEN5boost8functionIFbvEEE
void __fastcall RBX::Network::Replicator::TagItem::TagItem(
        RBX::Network::Replicator::TagItem *this,
        RBX::Network::Replicator *replicator,
        RBX::Network::TagItemType id,
        __int64 a4)
{
  boost::detail::function::vtable_base *v4; // rdx

  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))off_28870F8;
  this->id = id;
  this->readyCallback.vtable = 0;
  v4 = *(boost::detail::function::vtable_base **)a4;
  if ( *(_QWORD *)a4 )
  {
    this->readyCallback.vtable = v4;
    if ( ((unsigned __int8)v4 & 1) != 0 )
      this->readyCallback.functor = *(boost::detail::function::function_buffer *)(a4 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v4
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a4 + 8,
        &this->readyCallback.functor,
        0);
  }
}


// Address: 0xfa3310 | Name: _ZN3RBX7Network10Replicator14JoinDataItemV2C2EPS1_
void __fastcall RBX::Network::Replicator::JoinDataItemV2::JoinDataItemV2(
        RBX::Network::Replicator::JoinDataItemV2 *this,
        RBX::Network::Replicator *replicator)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))off_28872F0;
  *(_OWORD *)&this->totalNumberOfSentBlobs = 0;
  this->sharedStringsInstanceCounters = 0;
  this->partsInstanceCounters = 0;
  this->notCacheableInstanceCounters = 0;
  this->cacheableInstanceCounters = 0;
  *(_QWORD *)&this->totalUncompressedBytes = 0;
  this->readyBitstreamList.__end_.__prev_ = &this->readyBitstreamList.__end_;
  this->readyBitstreamList.__end_.__next_ = &this->readyBitstreamList.__end_;
  *(_OWORD *)&this->readyBitstreamList.__size_alloc_.__value_ = 0;
  this->instanceTypeCountMap.table_.current_ = 0;
  *(_OWORD *)&this->instanceTypeCountMap.table_.bucket_count_ = 0x10u;
  this->instanceTypeCountMap.table_.mlf_ = 1.0;
  *(_OWORD *)&this->instanceTypeCountMap.table_.max_load_ = 0;
}


// Address: 0xfa5910 | Name: _ZN3RBX7Network10Replicator32ResolveNewInstanceAtomicTreeItemC2EPS1_N5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::Network::Replicator::ResolveNewInstanceAtomicTreeItem::ResolveNewInstanceAtomicTreeItem(
        RBX::Network::Replicator::ResolveNewInstanceAtomicTreeItem *this,
        RBX::Network::Replicator *replicator,
        boost::shared_ptr<RBX::Instance> instance)
{
  boost::detail::sp_counted_base *px; // rax

  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))off_28873B0;
  this->instance.px = (boost::shared_ptr<RBX::Instance>::element_type *)instance.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)instance.px->weak_this_.px;
  this->instance.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->use_count_, 1u);
  this->parentGuidOnCreate = (RBX::Guid)0xFFFFFFFFLL;
  this->parentGuidOnCreate = *(RBX::Guid *)(*((_QWORD *)instance.px->_vptr$EventSource + 11) + 48LL);
}


// Address: 0xfbe6f0 | Name: _ZN3RBX7Network10Replicator9StreamJob17StreamTerrainItemC2EPS1_PS2_RKNS_12StreamRegion2IdE
void __fastcall RBX::Network::Replicator::StreamJob::StreamTerrainItem::StreamTerrainItem(
        RBX::Network::Replicator::StreamJob::StreamTerrainItem *this,
        RBX::Network::Replicator *replicator,
        RBX::Network::Replicator::StreamJob *streamJob,
        const RBX::StreamRegion::Id *regionId)
{
  this->RBX::Network::ItemHook = 0;
  this->replicator = replicator;
  this->needReceipt = 0;
  this->timestamp.sec = 0.0;
  this->_vptr$Item = (int (**)(void))&off_28885B0;
  this->streamJob = streamJob;
  this->regionId = *regionId;
}


