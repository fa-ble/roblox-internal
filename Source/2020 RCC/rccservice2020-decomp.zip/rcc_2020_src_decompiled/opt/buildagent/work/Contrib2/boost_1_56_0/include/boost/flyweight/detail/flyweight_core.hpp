// Address: 0xd9d410 | Name: __cxx_global_var_init.92
void __cdecl _cxx_global_var_init_92()
{
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::allocator_type v0; // [rsp+0h] [rbp-28h] BYREF
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::ctor_args_list args_list; // [rsp+8h] [rbp-20h] BYREF

  if ( !(_BYTE)qword_29D5548 )
  {
    if ( !byte_29D5540 )
    {
      if ( !(_BYTE)byte_29D5608 )
      {
        if ( __cxa_guard_acquire(&byte_29D5608) )
        {
          args_list.head.head = 0;
          ptr = operator new(0x48u);
          boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::hashed_index(
            &stru_29D55A0,
            &args_list,
            &v0);
          qword_29D55D8 = 0;
          pthread_mutexattr_init((pthread_mutexattr_t *)&args_list);
          pthread_mutexattr_settype((pthread_mutexattr_t *)&args_list, 1);
          pthread_mutex_init(&mutex, (const pthread_mutexattr_t *)&args_list);
          pthread_mutexattr_destroy((pthread_mutexattr_t *)&args_list);
          __cxa_atexit(
            (void (*)(void *))boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg::~holder_arg,
            &unk_29D5590,
            &dso_handle);
          __cxa_guard_release(&byte_29D5608);
        }
      }
      qword_29D5580 = (__int64)&unk_29D5590;
      qword_29D5588 = &mutex;
      byte_29D5540 = 1;
    }
    byte_29D5540 = 1;
    qword_29D5548 = 1;
  }
}


// Address: 0xd9ed80 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX12SharedString4DataEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS9_S9_S9_Li0EEENS0_14simple_lockingENS0_13static_holderEE10holder_argD2Ev
void __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg::~holder_arg(
        boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg *this)
{
  boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::multi_index::detail::hashed_unique_tag> *member; // r15
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > > *prior; // r12
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > > *v3; // r15
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *p_next; // rbx

  pthread_mutex_destroy(&this->mutex.m_);
  member = this->factory.cont.member;
  prior = (boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > > *)member->prior_;
  v3 = &member->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > >;
  while ( prior != v3 )
  {
    p_next = &prior[-4].next_;
    if ( !prior )
      p_next = 0;
    prior = (boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > > *)prior->prior_;
    if ( ((_BYTE)p_next[2] & 1) != 0 )
      operator delete(p_next[4]);
    operator delete(p_next);
  }
  if ( this->factory.cont.buckets.spc.n_ )
    operator delete(this->factory.cont.buckets.spc.data_);
  operator delete(this->factory.cont.member);
}


// Address: 0xdaf4a0 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX12SharedString4DataEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS9_S9_S9_Li0EEENS0_14simple_lockingENS0_13static_holderEE4initEv
bool __cdecl boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init()
{
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::allocator_type v1; // [rsp+0h] [rbp-28h] BYREF
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::ctor_args_list args_list; // [rsp+8h] [rbp-20h] BYREF

  if ( !byte_29D5540 )
  {
    if ( !(_BYTE)byte_29D5608 && __cxa_guard_acquire(&byte_29D5608) )
    {
      args_list.head.head = 0;
      ptr = operator new(0x48u);
      boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::hashed_index(
        &stru_29D55A0,
        &args_list,
        &v1);
      qword_29D55D8 = 0;
      pthread_mutexattr_init((pthread_mutexattr_t *)&args_list);
      pthread_mutexattr_settype((pthread_mutexattr_t *)&args_list, 1);
      pthread_mutex_init(&mutex, (const pthread_mutexattr_t *)&args_list);
      pthread_mutexattr_destroy((pthread_mutexattr_t *)&args_list);
      __cxa_atexit(
        (void (*)(void *))boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg::~holder_arg,
        &unk_29D5590,
        &dso_handle);
      __cxa_guard_release(&byte_29D5608);
    }
    qword_29D5580 = (__int64)&unk_29D5590;
    qword_29D5588 = &mutex;
    byte_29D5540 = 1;
  }
  return 1;
}


// Address: 0xeb5d30 | Name: __cxx_global_var_init.101
void __cdecl _cxx_global_var_init_101()
{
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::allocator_type v0; // [rsp+0h] [rbp-28h] BYREF
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::ctor_args_list args_list; // [rsp+8h] [rbp-20h] BYREF

  if ( !(_BYTE)qword_29FA8C8 )
  {
    if ( !byte_29FA8C5 )
    {
      if ( !(_BYTE)byte_29FA958 )
      {
        if ( __cxa_guard_acquire(&byte_29FA958) )
        {
          args_list.head.head = 0;
          qword_29FA8E8 = operator new(0x60u);
          boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::hashed_index(
            &stru_29FA8F0,
            &args_list,
            &v0);
          qword_29FA928 = 0;
          pthread_mutexattr_init((pthread_mutexattr_t *)&args_list);
          pthread_mutexattr_settype((pthread_mutexattr_t *)&args_list, 1);
          pthread_mutex_init(&stru_29FA930, (const pthread_mutexattr_t *)&args_list);
          pthread_mutexattr_destroy((pthread_mutexattr_t *)&args_list);
          __cxa_atexit(
            (void (*)(void *))boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg::~holder_arg,
            &unk_29FA8E0,
            &dso_handle);
          __cxa_guard_release(&byte_29FA958);
        }
      }
      qword_29FA8D0 = (boost::multi_index::multi_index_container<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > > *)&unk_29FA8E0;
      qword_29FA8D8 = &stru_29FA930;
      byte_29FA8C5 = 1;
    }
    byte_29FA8C5 = 1;
    qword_29FA8C8 = 1;
  }
}


// Address: 0xeb6820 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX15ProtectedStringEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS8_S8_S8_Li0EEENS0_14simple_lockingENS0_13static_holderEE10holder_argD2Ev
void __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg::~holder_arg(
        boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg *this)
{
  boost::multi_index::detail::hashed_unique_tag v1; // si

  pthread_mutex_destroy(&this->mutex.m_);
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::delete_all_nodes_(
    &this->factory.cont.boost::multi_index::detail::nth_layer<0,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >::type,
    v1);
  if ( this->factory.cont.buckets.spc.n_ )
    operator delete(this->factory.cont.buckets.spc.data_);
  operator delete(this->factory.cont.member);
}


// Address: 0x1114c30 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX15ProtectedStringEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS8_S8_S8_Li0EEENS0_14simple_lockingENS0_13static_holderEE4initEv
bool __cdecl boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init()
{
  __int64 v1; // rax
  float v2; // xmm0_4
  __int64 v3; // rax
  unsigned __int64 v4; // rax
  size_type v5; // rcx
  std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > al_0; // [rsp+8h] [rbp-20h] BYREF
  pthread_mutexattr_t attr; // [rsp+10h] [rbp-18h] BYREF

  if ( !byte_29FA8C5 )
  {
    if ( !(_BYTE)byte_29FA958 && __cxa_guard_acquire(&byte_29FA958) )
    {
      qword_29FA8E8 = operator new(0x60u);
      boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>::bucket_array(
        &stru_29FA8F0.buckets,
        &al_0,
        (boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >::pointer)qword_29FA8E8
      + 5,
        0);
      stru_29FA8F0.mlf = 1.0;
      v1 = *(_QWORD *)&a5[8 * stru_29FA8F0.buckets.size_index_];
      if ( v1 < 0 )
      {
        v3 = (*(_QWORD *)&a5[8 * stru_29FA8F0.buckets.size_index_] >> 1)
           | *(_QWORD *)&a5[8 * stru_29FA8F0.buckets.size_index_] & 1LL;
        v2 = (float)(int)v3 + (float)(int)v3;
      }
      else
      {
        v2 = (float)(int)v1;
      }
      v4 = (unsigned int)(int)v2;
      if ( v2 >= 9.223372e18 )
        v4 = (unsigned int)(int)(float)(v2 - 9.223372e18) ^ 0x8000000000000000LL;
      v5 = -1;
      if ( v2 < 1.8446744e19 )
        v5 = v4;
      stru_29FA8F0.max_load = v5;
      qword_29FA928 = 0;
      pthread_mutexattr_init(&attr);
      pthread_mutexattr_settype(&attr, 1);
      pthread_mutex_init(&stru_29FA930, &attr);
      pthread_mutexattr_destroy(&attr);
      __cxa_atexit(
        (void (*)(void *))boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg::~holder_arg,
        &unk_29FA8E0,
        &dso_handle);
      __cxa_guard_release(&byte_29FA958);
    }
    qword_29FA8D0 = (boost::multi_index::multi_index_container<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > > *)&unk_29FA8E0;
    qword_29FA8D8 = &stru_29FA930;
    byte_29FA8C5 = 1;
  }
  return 1;
}


// Address: 0x1115050 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX15ProtectedStringEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS8_S8_S8_Li0EEENS0_14simple_lockingENS0_13static_holderEE12insert_valueERKS5_
boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert_value(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **a1,
        const RBX::ProtectedString *x)
{
  pthread_mutex_t *v2; // r15
  boost::multi_index::multi_index_container<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > > *v3; // rbx
  boost::multi_index::detail::rvalue_tag v4; // cl
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v5; // rax
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v7[3]; // [rsp+0h] [rbp-A8h] BYREF
  char v8; // [rsp+18h] [rbp-90h]
  void *ptr; // [rsp+28h] [rbp-80h]
  boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > v10; // [rsp+30h] [rbp-78h] BYREF
  boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > v11; // [rsp+38h] [rbp-70h] BYREF
  _BYTE v12[16]; // [rsp+40h] [rbp-68h] BYREF
  void *v13; // [rsp+50h] [rbp-58h]
  char v14; // [rsp+58h] [rbp-50h]
  void *v15; // [rsp+68h] [rbp-40h]
  boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > v16; // [rsp+70h] [rbp-38h] BYREF
  boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > v17; // [rsp+78h] [rbp-30h] BYREF
  int v18; // [rsp+80h] [rbp-28h]
  __int64 v19; // [rsp+88h] [rbp-20h]

  boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
  RBX::ProtectedString::ProtectedString((RBX::ProtectedString *)v7, x);
  RBX::ProtectedString::ProtectedString((RBX::ProtectedString *)v12, (RBX::ProtectedString *)v7);
  v18 = 0;
  v19 = 0;
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(&v11);
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(&v10);
  if ( (v8 & 1) != 0 )
    operator delete(ptr);
  if ( ((__int64)v7[0] & 1) != 0 )
    operator delete(v7[2]);
  v2 = qword_29FA8D8;
  pthread_mutex_lock(qword_29FA8D8);
  v3 = qword_29FA8D0;
  v7[0] = 0;
  v5 = boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
         &qword_29FA8D0->boost::multi_index::detail::nth_layer<0,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >::type,
         (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::value_param_type)v12,
         v7,
         v4);
  if ( v5 == v7[0] )
    ++v3->node_count;
  *a1 = v5;
  if ( !_InterlockedExchangeAdd((volatile signed __int32 *)&v5->space.data_.align_ + 16, 1u) )
    ++*((_QWORD *)&v5->space.data_.align_ + 9);
  pthread_mutex_unlock(v2);
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(&v17);
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(&v16);
  if ( (v14 & 1) != 0 )
    operator delete(v15);
  if ( (v12[0] & 1) != 0 )
    operator delete(v13);
  return (boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type)a1;
}


// Address: 0x11afed0 | Name: _ZNK3RBX6Script19getEmbeddedCodeSafeEv
const RBX::ProtectedString *__fastcall RBX::Script::getEmbeddedCodeSafe(const RBX::Script *this)
{
  return (const RBX::ProtectedString *)*((_QWORD *)this + 50);
}


// Address: 0x11b16a0 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX15ProtectedStringEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS8_S8_S8_Li0EEENS0_14simple_lockingENS0_13static_holderEE10insert_repEONS6_8rep_typeE
boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert_rep(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **a1,
        RBX::ProtectedString *x)
{
  pthread_mutex_t *v2; // r12
  boost::multi_index::multi_index_container<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > > *v3; // rbx
  boost::multi_index::detail::rvalue_tag v4; // cl
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v5; // rax
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v7; // [rsp+0h] [rbp-78h] BYREF
  _BYTE v8[16]; // [rsp+8h] [rbp-70h] BYREF
  void *v9; // [rsp+18h] [rbp-60h]
  char v10; // [rsp+20h] [rbp-58h]
  void *ptr; // [rsp+30h] [rbp-48h]
  boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > v12; // [rsp+38h] [rbp-40h] BYREF
  boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > v13; // [rsp+40h] [rbp-38h] BYREF
  int v14; // [rsp+48h] [rbp-30h]
  __int64 v15; // [rsp+50h] [rbp-28h]

  boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
  RBX::ProtectedString::ProtectedString((RBX::ProtectedString *)v8, x);
  v14 = 0;
  v15 = 0;
  v2 = qword_29FA8D8;
  pthread_mutex_lock(qword_29FA8D8);
  v3 = qword_29FA8D0;
  v7 = 0;
  v5 = boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
         &qword_29FA8D0->boost::multi_index::detail::nth_layer<0,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >::type,
         (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::value_param_type)v8,
         &v7,
         v4);
  if ( v5 == v7 )
    ++v3->node_count;
  *a1 = v5;
  if ( !_InterlockedExchangeAdd((volatile signed __int32 *)&v5->space.data_.align_ + 16, 1u) )
    ++*((_QWORD *)&v5->space.data_.align_ + 9);
  pthread_mutex_unlock(v2);
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(&v13);
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(&v12);
  if ( (v10 & 1) != 0 )
    operator delete(ptr);
  if ( (v8[0] & 1) != 0 )
    operator delete(v9);
  return (boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type)a1;
}


// Address: 0x1311a00 | Name: _ZNK3RBX12SharedString11getContentsEv
const std::string *__fastcall RBX::SharedString::getContents(const RBX::SharedString *this)
{
  return (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *)((char *)this->flyweight.h.h + 16);
}


// Address: 0x1311a10 | Name: _ZNK3RBX12SharedString10getMd5HashEPc
void __fastcall RBX::SharedString::getMd5Hash(const RBX::SharedString *this, char *out)
{
  *(_OWORD *)out = *(_OWORD *)this->flyweight.h.h;
}


// Address: 0x1311a40 | Name: _ZNK3RBX12SharedStringltERKS0_
bool __fastcall RBX::SharedString::operator<(const RBX::SharedString *this, const RBX::SharedString *other)
{
  unsigned __int64 *h; // rsi
  unsigned __int64 v3; // rcx
  unsigned __int64 v4; // rdx
  unsigned int v5; // eax

  h = (unsigned __int64 *)other->flyweight.h.h;
  v3 = _byteswap_uint64(*(_QWORD *)this->flyweight.h.h);
  v4 = _byteswap_uint64(*h);
  if ( v3 != v4
    || (v3 = _byteswap_uint64(*((_QWORD *)this->flyweight.h.h + 1)), v4 = _byteswap_uint64(h[1]), v5 = 0, v3 != v4) )
  {
    v5 = 2 * (v3 >= v4) - 1;
  }
  return v5 >> 31;
}


// Address: 0x1311a80 | Name: _ZNK3RBX12SharedStringeqERKS0_
bool __fastcall RBX::SharedString::operator==(const RBX::SharedString *this, const RBX::SharedString *other)
{
  return this->flyweight.h.h == other->flyweight.h.h;
}


// Address: 0x1311a90 | Name: _ZNK3RBX12SharedStringneERKS0_
bool __fastcall RBX::SharedString::operator!=(const RBX::SharedString *this, const RBX::SharedString *other)
{
  return this->flyweight.h.h != other->flyweight.h.h;
}


// Address: 0x1311ad0 | Name: _ZN3RBX10hash_valueERKNS_12SharedStringE
size_t __fastcall RBX::hash_value(const RBX::SharedString *sharedString)
{
  return (size_t)sharedString->flyweight.h.h + ((unsigned __int64)sharedString->flyweight.h.h >> 3);
}


// Address: 0x1311d20 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX12SharedString4DataEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS9_S9_S9_Li0EEENS0_14simple_lockingENS0_13static_holderEE12insert_valueEOS6_
boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert_value(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **a1,
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **x)
{
  char v2; // al
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v3; // rcx
  pthread_mutex_t *v4; // r15
  __int64 v5; // rbx
  boost::multi_index::detail::rvalue_tag v6; // cl
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v7; // rax
  __int128 v9; // [rsp+0h] [rbp-68h] BYREF
  char v10; // [rsp+10h] [rbp-58h]
  _BYTE v11[15]; // [rsp+11h] [rbp-57h]
  void *ptr; // [rsp+20h] [rbp-48h]
  int v13; // [rsp+28h] [rbp-40h]
  __int64 v14; // [rsp+30h] [rbp-38h]
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v15[6]; // [rsp+38h] [rbp-30h] BYREF

  v15[2] = (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *)__readfsqword(0x28u);
  boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
  v2 = *((_BYTE *)x + 16);
  *(boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **)((char *)v15 + 7) = x[3];
  v15[0] = *(boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **)((char *)x + 17);
  v3 = x[4];
  *((_OWORD *)x + 1) = 0;
  x[4] = 0;
  v9 = *(_OWORD *)x;
  v10 = v2;
  *(boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **)&v11[7] = *(boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **)((char *)v15 + 7);
  *(boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **)v11 = v15[0];
  ptr = v3;
  v13 = 0;
  v14 = 0;
  v4 = qword_29D5588;
  pthread_mutex_lock(qword_29D5588);
  v5 = qword_29D5580;
  v15[0] = 0;
  v7 = boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
         (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *)(qword_29D5580 + 16),
         (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::value_param_type)&v9,
         v15,
         v6);
  if ( v7 == v15[0] )
    ++*(_QWORD *)(v5 + 72);
  *a1 = v7;
  if ( !_InterlockedExchangeAdd((volatile signed __int32 *)&v7->space.data_.align_ + 10, 1u) )
    ++*((_QWORD *)&v7->space.data_.align_ + 6);
  pthread_mutex_unlock(v4);
  if ( (v10 & 1) != 0 )
    operator delete(ptr);
  return (boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type)a1;
}


// Address: 0x1541f90 | Name: __cxx_global_var_init.47_0
void __cdecl _cxx_global_var_init_47_0()
{
  if ( !(_BYTE)qword_2A2A788 )
  {
    byte_2A2A781 = boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
    qword_2A2A788 = 1;
  }
}


// Address: 0x1541fc0 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryISD_SD_SD_Li0EEENS0_14simple_lockingENS0_13static_holderEE4initEv
bool __cdecl boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init()
{
  __int64 v1; // rax
  float v2; // xmm0_4
  __int64 v3; // rax
  unsigned __int64 v4; // rax
  __int64 v5; // rcx
  std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > al_0; // [rsp+8h] [rbp-20h] BYREF
  pthread_mutexattr_t attr; // [rsp+10h] [rbp-18h] BYREF

  if ( !byte_2A2A781 )
  {
    if ( !(_BYTE)byte_2A2A818 && __cxa_guard_acquire(&byte_2A2A818) )
    {
      qword_2A2A7A8 = operator new(0x38u);
      boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>::bucket_array(
        &stru_2A2A7B8,
        &al_0,
        (boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >::pointer)((char *)qword_2A2A7A8 + 40),
        0);
      dword_2A2A7D8 = 1065353216;
      v1 = *(_QWORD *)&a5[8 * stru_2A2A7B8.size_index_];
      if ( v1 < 0 )
      {
        v3 = (*(_QWORD *)&a5[8 * stru_2A2A7B8.size_index_] >> 1) | *(_QWORD *)&a5[8 * stru_2A2A7B8.size_index_] & 1LL;
        v2 = (float)(int)v3 + (float)(int)v3;
      }
      else
      {
        v2 = (float)(int)v1;
      }
      v4 = (unsigned int)(int)v2;
      if ( v2 >= 9.223372e18 )
        v4 = (unsigned int)(int)(float)(v2 - 9.223372e18) ^ 0x8000000000000000LL;
      v5 = -1;
      if ( v2 < 1.8446744e19 )
        v5 = v4;
      qword_2A2A7E0 = v5;
      qword_2A2A7E8 = 0;
      pthread_mutexattr_init(&attr);
      pthread_mutexattr_settype(&attr, 1);
      pthread_mutex_init(&stru_2A2A7F0, &attr);
      pthread_mutexattr_destroy(&attr);
      __cxa_atexit(
        (void (*)(void *))boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg::~holder_arg,
        &unk_2A2A7A0,
        &dso_handle);
      __cxa_guard_release(&byte_2A2A818);
    }
    qword_2A2A790 = (__int64)&unk_2A2A7A0;
    qword_2A2A798 = &stru_2A2A7F0;
    byte_2A2A781 = 1;
  }
  return 1;
}


// Address: 0x1544600 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryISD_SD_SD_Li0EEENS0_14simple_lockingENS0_13static_holderEE12insert_valueERKSA_
boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert_value(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **a1,
        const boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::value_type *x)
{
  pthread_mutex_t *v2; // r15
  __int64 v3; // rbx
  boost::multi_index::detail::rvalue_tag v4; // cl
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v5; // rax
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v7[2]; // [rsp+8h] [rbp-60h] BYREF
  void *v8; // [rsp+18h] [rbp-50h]
  __int128 v9; // [rsp+20h] [rbp-48h] BYREF
  void *ptr; // [rsp+30h] [rbp-38h]
  int v11; // [rsp+38h] [rbp-30h]
  __int64 v12; // [rsp+40h] [rbp-28h]

  boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
  std::string::basic_string(v7, x);
  ptr = v8;
  v9 = *(_OWORD *)v7;
  v11 = 0;
  v12 = 0;
  v2 = qword_2A2A798;
  pthread_mutex_lock(qword_2A2A798);
  v3 = qword_2A2A790;
  v7[0] = 0;
  v5 = boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>,boost::hash<std::string>,std::equal_to<std::string>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
         (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *)(qword_2A2A790 + 16),
         (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::value_param_type)&v9,
         v7,
         v4);
  if ( v5 == v7[0] )
    ++*(_QWORD *)(v3 + 72);
  *a1 = v5;
  if ( !_InterlockedExchangeAdd((volatile signed __int32 *)&v5->space.data_.align_ + 6, 1u) )
    ++*((_QWORD *)&v5->space.data_.align_ + 4);
  pthread_mutex_unlock(v2);
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
  return (boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type)a1;
}


// Address: 0x1544e90 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryISD_SD_SD_Li0EEENS0_14simple_lockingENS0_13static_holderEE10holder_argD2Ev
void __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg::~holder_arg(
        boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg *this)
{
  boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::multi_index::detail::hashed_unique_tag> *member; // r15
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > > *prior; // r12
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > > *v3; // r15
  void **p_next; // rbx

  pthread_mutex_destroy(&this->mutex.m_);
  member = this->factory.cont.member;
  prior = (boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > > *)member->prior_;
  v3 = &member->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > >;
  while ( prior != v3 )
  {
    p_next = (void **)&prior[-3].next_;
    if ( !prior )
      p_next = 0;
    prior = (boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > > *)prior->prior_;
    if ( (*(_BYTE *)p_next & 1) != 0 )
      operator delete(p_next[2]);
    operator delete(p_next);
  }
  if ( this->factory.cont.buckets.spc.n_ )
    operator delete(this->factory.cont.buckets.spc.data_);
  operator delete(this->factory.cont.member);
}


// Address: 0x1d45c00 | Name: _ZNK3RBX8Instance7getNameEv
const std::string *__fastcall RBX::Instance::getName(const RBX::Instance *this)
{
  return this->name.h.h;
}


// Address: 0x1d4cbe0 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryISD_SD_SD_Li0EEENS0_14simple_lockingENS0_13static_holderEE10insert_repEONSB_8rep_typeE
boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert_rep(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **a1,
        __int128 *x)
{
  pthread_mutex_t *v2; // r15
  __int64 v3; // rbx
  boost::multi_index::detail::rvalue_tag v4; // cl
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v5; // rax
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v7; // [rsp+8h] [rbp-50h] BYREF
  __int128 v8; // [rsp+10h] [rbp-48h] BYREF
  void *ptr; // [rsp+20h] [rbp-38h]
  int v10; // [rsp+28h] [rbp-30h]
  __int64 v11; // [rsp+30h] [rbp-28h]

  boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
  ptr = (void *)*((_QWORD *)x + 2);
  v8 = *x;
  *x = 0;
  *((_QWORD *)x + 2) = 0;
  v10 = 0;
  v11 = 0;
  v2 = qword_2A2A798;
  pthread_mutex_lock(qword_2A2A798);
  v3 = qword_2A2A790;
  v7 = 0;
  v5 = boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>,boost::hash<std::string>,std::equal_to<std::string>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
         (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *)(qword_2A2A790 + 16),
         (char *)&v8,
         &v7,
         v4);
  if ( v5 == v7 )
    ++*(_QWORD *)(v3 + 72);
  *a1 = v5;
  if ( !_InterlockedExchangeAdd((volatile signed __int32 *)&v5->space.data_.align_ + 6, 1u) )
    ++*((_QWORD *)&v5->space.data_.align_ + 4);
  pthread_mutex_unlock(v2);
  if ( (v8 & 1) != 0 )
    operator delete(ptr);
  return (boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type)a1;
}


// Address: 0x1d4cec0 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryISD_SD_SD_Li0EEENS0_14simple_lockingENS0_13static_holderEE6insertIJRA9_KcEEENS1_17refcounted_handleIPKNS1_16refcounted_valueINSB_8rep_typeESA_EENS1_30flyweight_core_tracking_helperISB_SD_SE_SG_SH_SI_EEEEDpOT_
boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert<char const(&)[9]>(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **a1,
        const char (*args)[9])
{
  size_t v2; // rax
  size_t v3; // r13
  char *v4; // r12
  size_t v5; // rbx
  struct _Unwind_Exception *v7; // rax
  struct _Unwind_Exception *v8; // rbx
  __int128 dest; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]

  dest = 0;
  ptr = 0;
  v2 = strlen((const char *)args);
  if ( v2 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
    v8 = v7;
    if ( (dest & 1) != 0 )
      operator delete(ptr);
    _Unwind_Resume(v8);
  }
  v3 = v2;
  if ( v2 >= 0x17 )
  {
    v5 = (v2 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v4 = (char *)operator new(v5);
    ptr = v4;
    *(_QWORD *)&dest = v5 | 1;
    *((_QWORD *)&dest + 1) = v3;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v2;
  v4 = (char *)&dest + 1;
  if ( v2 )
LABEL_6:
    memcpy(v4, args, v3);
  v4[v3] = 0;
  boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert_rep(
    a1,
    &dest);
  if ( (dest & 1) != 0 )
    operator delete(ptr);
  return (boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type)a1;
}


// Address: 0x1d4cfd0 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryISD_SD_SD_Li0EEENS0_14simple_lockingENS0_13static_holderEE6insertIJRPKcEEENS1_17refcounted_handleIPKNS1_16refcounted_valueINSB_8rep_typeESA_EENS1_30flyweight_core_tracking_helperISB_SD_SE_SG_SH_SI_EEEEDpOT_
boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert<char const*&>(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **a1,
        const char **args)
{
  const char *v2; // r15
  size_t v3; // rax
  size_t v4; // r13
  char *v5; // r12
  size_t v6; // rbx
  struct _Unwind_Exception *v8; // rax
  struct _Unwind_Exception *v9; // rbx
  __int128 dest; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]

  v2 = *args;
  dest = 0;
  ptr = 0;
  v3 = strlen(v2);
  if ( v3 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
    v9 = v8;
    if ( (dest & 1) != 0 )
      operator delete(ptr);
    _Unwind_Resume(v9);
  }
  v4 = v3;
  if ( v3 >= 0x17 )
  {
    v6 = (v3 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v5 = (char *)operator new(v6);
    ptr = v5;
    *(_QWORD *)&dest = v6 | 1;
    *((_QWORD *)&dest + 1) = v4;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v3;
  v5 = (char *)&dest + 1;
  if ( v3 )
LABEL_6:
    memcpy(v5, v2, v4);
  v5[v4] = 0;
  boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert_rep(
    a1,
    &dest);
  if ( (dest & 1) != 0 )
    operator delete(ptr);
  return (boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type)a1;
}


// Address: 0x1d4d0b0 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryISD_SD_SD_Li0EEENS0_14simple_lockingENS0_13static_holderEE12insert_valueEOSA_
boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert_value(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **a1,
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **x)
{
  char v2; // al
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v3; // rcx
  pthread_mutex_t *v4; // r15
  __int64 v5; // rbx
  boost::multi_index::detail::rvalue_tag v6; // cl
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v7; // rax
  char v9; // [rsp+0h] [rbp-58h] BYREF
  _BYTE v10[15]; // [rsp+1h] [rbp-57h]
  void *ptr; // [rsp+10h] [rbp-48h]
  int v12; // [rsp+18h] [rbp-40h]
  __int64 v13; // [rsp+20h] [rbp-38h]
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v14[6]; // [rsp+28h] [rbp-30h] BYREF

  v14[2] = (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *)__readfsqword(0x28u);
  boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
  v2 = *(_BYTE *)x;
  *(boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **)((char *)v14 + 7) = x[1];
  v14[0] = *(boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **)((char *)x + 1);
  v3 = x[2];
  *(_OWORD *)x = 0;
  x[2] = 0;
  v9 = v2;
  *(boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **)v10 = v14[0];
  *(boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **)&v10[7] = *(boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **)((char *)v14 + 7);
  ptr = v3;
  v12 = 0;
  v13 = 0;
  v4 = qword_2A2A798;
  pthread_mutex_lock(qword_2A2A798);
  v5 = qword_2A2A790;
  v14[0] = 0;
  v7 = boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>,boost::hash<std::string>,std::equal_to<std::string>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
         (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *)(qword_2A2A790 + 16),
         &v9,
         v14,
         v6);
  if ( v7 == v14[0] )
    ++*(_QWORD *)(v5 + 72);
  *a1 = v7;
  if ( !_InterlockedExchangeAdd((volatile signed __int32 *)&v7->space.data_.align_ + 6, 1u) )
    ++*((_QWORD *)&v7->space.data_.align_ + 4);
  pthread_mutex_unlock(v4);
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
  return (boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type)a1;
}


// Address: 0x1e10770 | Name: _ZN3RBX18MaterialProperties10getDensityEPKNS_9PrimitiveE
float __fastcall RBX::MaterialProperties::getDensity(const RBX::Primitive *prim)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)prim + 73);
  if ( *(_BYTE *)v1 )
    return *(float *)(v1 + 4);
  else
    return RBX::MaterialProperties::getDefaultMaterialDensity((RBX::PartMaterial)*((unsigned __int16 *)prim + 296));
}


// Address: 0x1e2d7e0 | Name: __cxx_global_var_init.34
void __cdecl _cxx_global_var_init_34()
{
  if ( !(_BYTE)qword_2AAFBE0 )
  {
    byte_2AAFBD8 = boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
    qword_2AAFBE0 = 1;
  }
}


// Address: 0x1e2d810 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX18PhysicalPropertiesEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS8_S8_S8_Li0EEENS0_14simple_lockingENS0_13static_holderEE4initEv
bool __cdecl boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init()
{
  __int64 v1; // rax
  float v2; // xmm0_4
  __int64 v3; // rax
  unsigned __int64 v4; // rax
  __int64 v5; // rcx
  std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > al_0; // [rsp+8h] [rbp-20h] BYREF
  pthread_mutexattr_t attr; // [rsp+10h] [rbp-18h] BYREF

  if ( !byte_2AAFBD8 )
  {
    if ( !(_BYTE)byte_2AAFC70 && __cxa_guard_acquire(&byte_2AAFC70) )
    {
      qword_2AAFC00 = operator new(0x38u);
      boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>>::bucket_array(
        &stru_2AAFC10,
        &al_0,
        (boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >::pointer)((char *)qword_2AAFC00 + 40),
        0);
      dword_2AAFC30 = 1065353216;
      v1 = *(_QWORD *)&a5[8 * stru_2AAFC10.size_index_];
      if ( v1 < 0 )
      {
        v3 = (*(_QWORD *)&a5[8 * stru_2AAFC10.size_index_] >> 1) | *(_QWORD *)&a5[8 * stru_2AAFC10.size_index_] & 1LL;
        v2 = (float)(int)v3 + (float)(int)v3;
      }
      else
      {
        v2 = (float)(int)v1;
      }
      v4 = (unsigned int)(int)v2;
      if ( v2 >= 9.223372e18 )
        v4 = (unsigned int)(int)(float)(v2 - 9.223372e18) ^ 0x8000000000000000LL;
      v5 = -1;
      if ( v2 < 1.8446744e19 )
        v5 = v4;
      qword_2AAFC38 = v5;
      qword_2AAFC40 = 0;
      pthread_mutexattr_init(&attr);
      pthread_mutexattr_settype(&attr, 1);
      pthread_mutex_init(&stru_2AAFC48, &attr);
      pthread_mutexattr_destroy(&attr);
      __cxa_atexit(
        (void (*)(void *))boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg::~holder_arg,
        &unk_2AAFBF8,
        &dso_handle);
      __cxa_guard_release(&byte_2AAFC70);
    }
    qword_2AAFBE8 = (__int64)&unk_2AAFBF8;
    qword_2AAFBF0 = &stru_2AAFC48;
    byte_2AAFBD8 = 1;
  }
  return 1;
}


// Address: 0x1e2da90 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX18PhysicalPropertiesEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS8_S8_S8_Li0EEENS0_14simple_lockingENS0_13static_holderEE12insert_valueEOS5_
boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert_value(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **a1,
        boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type *x)
{
  pthread_mutex_t *v2; // r15
  __int64 v3; // rbx
  boost::multi_index::detail::rvalue_tag v4; // cl
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v5; // rax
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v7; // [rsp+8h] [rbp-50h] BYREF
  boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> v; // [rsp+10h] [rbp-48h] BYREF

  boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
  v.x = *x;
  v.ref.value_ = 0;
  v.del_ref = 0;
  v2 = qword_2AAFBF0;
  pthread_mutex_lock(qword_2AAFBF0);
  v3 = qword_2AAFBE8;
  v7 = 0;
  v5 = boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
         (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *)(qword_2AAFBE8 + 16),
         &v,
         &v7,
         v4);
  if ( v5 == v7 )
    ++*(_QWORD *)(v3 + 72);
  *a1 = v5;
  if ( !_InterlockedExchangeAdd((volatile signed __int32 *)&v5->space.data_.align_ + 6, 1u) )
    ++*((_QWORD *)&v5->space.data_.align_ + 4);
  pthread_mutex_unlock(v2);
  return (boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type)a1;
}


// Address: 0x1e2e230 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX18PhysicalPropertiesEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS8_S8_S8_Li0EEENS0_14simple_lockingENS0_13static_holderEE10holder_argD2Ev
void __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg::~holder_arg(
        boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::holder_arg *this)
{
  boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::multi_index::detail::hashed_unique_tag> *member; // r15
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > > *prior; // rax
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > > *v4; // r15
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > > *v5; // rbx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *p_next; // rdi

  pthread_mutex_destroy(&this->mutex.m_);
  member = this->factory.cont.member;
  prior = (boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > > *)member->prior_;
  v4 = &member->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > >;
  if ( prior != v4 )
  {
    do
    {
      v5 = (boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > > *)prior->prior_;
      p_next = &prior[-3].next_;
      if ( !prior )
        p_next = 0;
      operator delete(p_next);
      prior = v5;
    }
    while ( v5 != v4 );
  }
  if ( this->factory.cont.buckets.spc.n_ )
    operator delete(this->factory.cont.buckets.spc.data_);
  operator delete(this->factory.cont.member);
}


// Address: 0x1e2e6b0 | Name: _ZN5boost10flyweights6detail14flyweight_coreINS1_20default_value_policyIN3RBX18PhysicalPropertiesEEEN4mpl_2naENS0_10refcountedENS0_14hashed_factoryIS8_S8_S8_Li0EEENS0_14simple_lockingENS0_13static_holderEE12insert_valueERKS5_
boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type __fastcall boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::insert_value(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **a1,
        boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type *x)
{
  pthread_mutex_t *v2; // r15
  __int64 v3; // rbx
  boost::multi_index::detail::rvalue_tag v4; // cl
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v5; // rax
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v7; // [rsp+8h] [rbp-50h] BYREF
  boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> v; // [rsp+10h] [rbp-48h] BYREF

  boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
  v.x = *x;
  v.ref.value_ = 0;
  v.del_ref = 0;
  v2 = qword_2AAFBF0;
  pthread_mutex_lock(qword_2AAFBF0);
  v3 = qword_2AAFBE8;
  v7 = 0;
  v5 = boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
         (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *)(qword_2AAFBE8 + 16),
         &v,
         &v7,
         v4);
  if ( v5 == v7 )
    ++*(_QWORD *)(v3 + 72);
  *a1 = v5;
  if ( !_InterlockedExchangeAdd((volatile signed __int32 *)&v5->space.data_.align_ + 6, 1u) )
    ++*((_QWORD *)&v5->space.data_.align_ + 4);
  pthread_mutex_unlock(v2);
  return (boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::handle_type)a1;
}


