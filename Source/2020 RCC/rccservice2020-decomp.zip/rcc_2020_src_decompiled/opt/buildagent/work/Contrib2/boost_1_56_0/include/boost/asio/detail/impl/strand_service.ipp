// Address: 0x26071f0 | Name: _ZN5boost4asio6detail14strand_service11do_dispatchERPNS2_11strand_implEPNS1_25task_io_service_operationE
bool __fastcall boost::asio::detail::strand_service::do_dispatch(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::operation *op)
{
  unsigned __int64 v5; // rax
  boost::asio::detail::strand_service::implementation_type v6; // rdi
  boost::asio::detail::task_io_service_operation *back; // rax
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *p_back; // rdi
  boost::asio::detail::strand_service::implementation_type v9; // rax
  boost::asio::detail::task_io_service_operation *v10; // rcx
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *p_ready_queue; // rax
  __int64 v12; // r12
  boost::asio::detail::strand_service::implementation_type v13; // rdi
  bool v14; // bl

  v5 = __readfsqword(0xFFFFFFD8);
  if ( v5 )
  {
    while ( *(boost::asio::detail::io_service_impl **)v5 != this->io_service_ )
    {
      v5 = *(_QWORD *)(v5 + 16);
      if ( !v5 )
        goto LABEL_4;
    }
    v12 = *(_QWORD *)(v5 + 8);
    pthread_mutex_lock(&(*impl)->mutex_.mutex_);
    if ( v12 )
    {
      v13 = *impl;
      if ( !(*impl)->locked_ )
      {
        v13->locked_ = 1;
        pthread_mutex_unlock(&v13->mutex_.mutex_);
        return 1;
      }
    }
  }
  else
  {
LABEL_4:
    pthread_mutex_lock(&(*impl)->mutex_.mutex_);
  }
  v6 = *impl;
  if ( (*impl)->locked_ )
  {
    op->next_ = 0;
    back = v6->waiting_queue_.back_;
    if ( back )
    {
      p_back = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)&v6->waiting_queue_.back_;
      back->next_ = op;
    }
    else
    {
      v6->waiting_queue_.back_ = op;
      p_back = &v6->waiting_queue_;
    }
    p_back->front_ = op;
    pthread_mutex_unlock(&(*impl)->mutex_.mutex_);
    return 0;
  }
  else
  {
    v6->locked_ = 1;
    pthread_mutex_unlock(&v6->mutex_.mutex_);
    v9 = *impl;
    op->next_ = 0;
    v10 = v9->ready_queue_.back_;
    if ( v10 )
    {
      p_ready_queue = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)&v9->ready_queue_.back_;
      v10->next_ = op;
    }
    else
    {
      v9->ready_queue_.back_ = op;
      p_ready_queue = &v9->ready_queue_;
    }
    p_ready_queue->front_ = op;
    v14 = 0;
    boost::asio::detail::task_io_service::post_immediate_completion(this->io_service_, *impl, 0);
  }
  return v14;
}


// Address: 0x2619050 | Name: _ZN5boost4asio6detail14strand_service9constructERPNS2_11strand_implE
void __fastcall boost::asio::detail::strand_service::construct(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl)
{
  size_t salt; // rax
  unsigned __int64 v3; // rbx
  char *p; // r12
  int v5; // ebp
  const boost::system::error_category *v6; // rax
  boost::asio::detail::strand_service::strand_impl *v7; // rbp
  const boost::system::error_category *v8; // rbx
  _QWORD v9[2]; // [rsp+0h] [rbp-68h] BYREF
  int v10; // [rsp+10h] [rbp-58h]
  const boost::system::error_category *v11; // [rsp+18h] [rbp-50h]
  __int128 v12; // [rsp+20h] [rbp-48h]
  void *ptr; // [rsp+30h] [rbp-38h]

  pthread_mutex_lock(&this->mutex_.mutex_);
  salt = this->salt_;
  this->salt_ = salt + 1;
  v3 = (((unsigned __int64)impl + ((unsigned __int64)impl >> 3))
      ^ (salt
       + (((_QWORD)impl + ((unsigned __int64)impl >> 3)) << 6)
       + (((unsigned __int64)impl + ((unsigned __int64)impl >> 3)) >> 2)
       + 2654435769u))
     % 0xC1;
  p = (char *)this->implementations_[v3].p_;
  if ( !p )
  {
    p = (char *)operator new(0x68u);
    *(_QWORD *)p = 0;
    *((_QWORD *)p + 1) = boost::asio::detail::strand_service::do_complete;
    *((_DWORD *)p + 4) = 0;
    v5 = pthread_mutex_init((pthread_mutex_t *)(p + 24), 0);
    v6 = boost::system::system_category();
    if ( v5 )
    {
      v8 = v6;
      std::runtime_error::runtime_error((std::runtime_error *)v9, "mutex");
      v9[0] = off_2875F00;
      v10 = v5;
      v11 = v8;
      v12 = 0;
      ptr = 0;
      boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v9);
    }
    p[64] = 0;
    *(_OWORD *)(p + 88) = 0;
    *(_OWORD *)(p + 72) = 0;
    v7 = this->implementations_[v3].p_;
    if ( v7 )
    {
      boost::asio::detail::strand_service::strand_impl::~strand_impl(this->implementations_[v3].p_);
      operator delete(v7);
    }
    this->implementations_[v3].p_ = (boost::asio::detail::strand_service::strand_impl *)p;
  }
  *impl = (boost::asio::detail::strand_service::implementation_type)p;
  pthread_mutex_unlock(&this->mutex_.mutex_);
}


// Address: 0x26193a0 | Name: _ZN5boost4asio6detail14strand_service16shutdown_serviceEv
void __fastcall boost::asio::detail::strand_service::shutdown_service(boost::asio::detail::strand_service *this)
{
  boost::asio::detail::mutex *p_mutex; // r14
  _QWORD *v3; // rcx
  __int64 v4; // rax
  _QWORD *v5; // r15
  _QWORD *v6; // rdx
  __int64 v7; // rdi
  __int64 v8; // rdi
  _QWORD *v9; // rbx
  void (__fastcall *v10)(_QWORD, _QWORD *, int *, _QWORD, double); // r12
  int v11; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v12; // [rsp+10h] [rbp-28h]

  p_mutex = &this->mutex_;
  pthread_mutex_lock(&this->mutex_.mutex_);
  v3 = 0;
  v4 = 11;
  v5 = 0;
  do
  {
    v6 = (_QWORD *)*((_QWORD *)&this->_vptr$service + v4);
    if ( v6 )
    {
      v7 = v6[9];
      if ( v7 )
      {
        if ( v3 )
          *v3 = v7;
        else
          v5 = (_QWORD *)v6[9];
        v3 = (_QWORD *)v6[10];
        *(_OWORD *)(v6 + 9) = 0;
      }
      v8 = v6[11];
      if ( v8 )
      {
        if ( v3 )
          *v3 = v8;
        else
          v5 = (_QWORD *)v6[11];
        v3 = (_QWORD *)v6[12];
        *(_OWORD *)(v6 + 11) = 0;
      }
    }
    ++v4;
  }
  while ( v4 != 204 );
  pthread_mutex_unlock(&p_mutex->mutex_);
  while ( v5 )
  {
    v9 = v5;
    v5 = (_QWORD *)*v5;
    v10 = (void (__fastcall *)(_QWORD, _QWORD *, int *, _QWORD, double))v9[1];
    *v9 = 0;
    v11 = 0;
    v12 = boost::system::system_category();
    v10(0, v9, &v11, 0, 0.0);
  }
}


// Address: 0x2619580 | Name: _ZN5boost4asio6detail14strand_service11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationERKNS_6system10error_codeEm
void __fastcall boost::asio::detail::strand_service::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *ec,
        size_t a4)
{
  boost::asio::detail::task_io_service_operation *v6; // rbx
  boost::asio::detail::task_io_service_operation *next; // rsi
  boost::asio::detail::task_io_service_operation *v8; // rax
  boost::asio::detail::task_io_service_operation *v9; // rax
  __int64 v10; // rbx
  _QWORD v11[2]; // [rsp+8h] [rbp-40h] BYREF
  unsigned __int64 v12; // [rsp+18h] [rbp-30h]

  if ( owner )
  {
    v11[0] = base;
    v12 = __readfsqword(0xFFFFFFE0);
    v11[1] = v11;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v11);
    v6 = (boost::asio::detail::operation *)((char *)base + 88);
    while ( 1 )
    {
      next = v6->next_;
      if ( !v6->next_ )
        break;
      v8 = next->next_;
      v6->next_ = next->next_;
      if ( !v8 )
        v6->func_ = 0;
      next->next_ = 0;
      next->func_(owner, next, ec, 0);
    }
    pthread_mutex_lock((pthread_mutex_t *)&base[1]);
    v9 = base[3].next_;
    if ( v9 )
    {
      if ( base[4].next_ )
        v6 = base[4].next_;
      v6->next_ = v9;
      base[4].next_ = (boost::asio::detail::task_io_service_operation *)base[3].func_;
      *(_OWORD *)&base[3].next_ = 0;
    }
    v10 = *(_QWORD *)&base[3].task_result_;
    LOBYTE(base[2].task_result_) = v10 != 0;
    pthread_mutex_unlock((pthread_mutex_t *)&base[1]);
    if ( v10 )
      boost::asio::detail::task_io_service::post_immediate_completion(owner, base, 1);
    __writefsqword(0xFFFFFFE0, v12);
  }
}


