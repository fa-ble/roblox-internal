// Address: 0x28424c0 | Name: _GLOBAL__sub_I_error_code.cpp
void __cdecl GLOBAL__sub_I_error_code_cpp()
{
  if ( !(_BYTE)byte_2CE5630 && __cxa_guard_acquire(&byte_2CE5630) )
  {
    stru_2CE5628._vptr$error_category = (int (**)(void))&off_29CFD68;
    __cxa_guard_release(&byte_2CE5630);
  }
  if ( !(_BYTE)byte_2CE5630 && __cxa_guard_acquire(&byte_2CE5630) )
  {
    stru_2CE5628._vptr$error_category = (int (**)(void))&off_29CFD68;
    __cxa_guard_release(&byte_2CE5630);
  }
  if ( !(_BYTE)byte_2CE5620 && __cxa_guard_acquire(&byte_2CE5620) )
  {
    stru_2CE5618._vptr$error_category = (int (**)(void))&off_29CFD00;
    __cxa_guard_release(&byte_2CE5620);
  }
  dword_2CE5608 = 0;
  if ( !(_BYTE)byte_2CE5620 && __cxa_guard_acquire(&byte_2CE5620) )
  {
    stru_2CE5618._vptr$error_category = (int (**)(void))&off_29CFD00;
    __cxa_guard_release(&byte_2CE5620);
  }
  qword_2CE5610 = (__int64)&stru_2CE5618;
}


