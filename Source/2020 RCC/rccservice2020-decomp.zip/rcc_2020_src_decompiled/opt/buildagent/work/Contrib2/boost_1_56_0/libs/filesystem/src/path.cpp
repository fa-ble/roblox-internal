// Address: 0x283eef0 | Name: _ZN5boost10filesystem4pathdVERKS1_
boost::filesystem::path *__fastcall boost::filesystem::path::operator/=(
        boost::filesystem::path *this,
        const boost::filesystem::path *p)
{
  unsigned __int64 v4; // rdx
  char v5; // al
  unsigned __int64 v6; // rcx
  unsigned __int64 v7; // rsi
  char *v8; // rsi
  _BYTE *v9; // rdi
  unsigned __int64 v10; // r9
  unsigned __int8 v11; // al
  char v12; // dl
  _BYTE *v13; // rcx
  _BYTE *v14; // r15
  _BYTE *v15; // rsi
  unsigned __int64 v16; // rsi
  __int64 v17; // rdx
  unsigned __int8 v19; // [rsp+8h] [rbp-30h] BYREF
  _BYTE v20[7]; // [rsp+9h] [rbp-2Fh] BYREF
  __int64 v21; // [rsp+10h] [rbp-28h]
  void *ptr; // [rsp+18h] [rbp-20h]

  v4 = (unsigned __int64)*(unsigned __int8 *)p >> 1;
  v5 = *(_BYTE *)p & 1;
  v6 = *((_QWORD *)p + 1);
  v7 = v6;
  if ( !v5 )
    v7 = v4;
  if ( v7 )
  {
    if ( this != p )
    {
      v8 = (char *)*((_QWORD *)p + 2);
      v9 = v8;
      if ( !v5 )
        v9 = (char *)p + 1;
      if ( *v9 == 47 )
        goto LABEL_25;
      v10 = *(unsigned __int8 *)this;
      if ( (v10 & 1) != 0 )
      {
        if ( !*((_QWORD *)this + 1) )
          goto LABEL_25;
      }
      else if ( !(v10 >> 1) )
      {
        goto LABEL_25;
      }
      if ( (v10 & 1) == 0 )
      {
        if ( *((_BYTE *)this + ((unsigned __int8)v10 >> 1)) == 47 )
          goto LABEL_25;
        goto LABEL_24;
      }
      if ( *(_BYTE *)(*((_QWORD *)this + 2) + *((_QWORD *)this + 1) - 1LL) != 47 )
      {
LABEL_24:
        std::string::push_back(this, 47);
        v6 = *((_QWORD *)p + 1);
        v8 = (char *)*((_QWORD *)p + 2);
        v5 = *(_BYTE *)p & 1;
        v4 = (unsigned __int64)*(unsigned __int8 *)p >> 1;
      }
LABEL_25:
      if ( v5 )
        v4 = v6;
      else
        v8 = (char *)p + 1;
      std::string::append(this, v8, v4);
      return this;
    }
    std::string::basic_string(&v19, p);
    v11 = v19;
    v12 = v19 & 1;
    v13 = ptr;
    v14 = v20;
    v15 = ptr;
    if ( (v19 & 1) == 0 )
      v15 = v20;
    if ( *v15 == 47 )
      goto LABEL_33;
    v16 = *(unsigned __int8 *)p;
    if ( (v16 & 1) != 0 )
    {
      if ( !*((_QWORD *)p + 1) )
        goto LABEL_33;
    }
    else if ( !(v16 >> 1) )
    {
LABEL_33:
      if ( v12 )
      {
        v17 = v21;
        v14 = v13;
      }
      else
      {
        v17 = v11 >> 1;
      }
      std::string::append(p, v14, v17);
      if ( (v19 & 1) != 0 )
        operator delete(ptr);
      return this;
    }
    if ( (v16 & 1) != 0 )
    {
      if ( *(_BYTE *)(*((_QWORD *)p + 2) + *((_QWORD *)p + 1) - 1LL) == 47 )
        goto LABEL_33;
    }
    else if ( *((_BYTE *)p + (v16 >> 1)) == 47 )
    {
      goto LABEL_33;
    }
    std::string::push_back(p, 47);
    v11 = v19;
    v13 = ptr;
    v12 = v19 & 1;
    goto LABEL_33;
  }
  return this;
}


// Address: 0x283f0c0 | Name: _ZN5boost10filesystem4path28m_append_separator_if_neededEv
std::string::size_type __fastcall boost::filesystem::path::m_append_separator_if_needed(boost::filesystem::path *this)
{
  unsigned __int64 v1; // rbx
  std::string::size_type v2; // rbx

  v1 = *(unsigned __int8 *)this;
  if ( (v1 & 1) != 0 )
  {
    if ( !*((_QWORD *)this + 1) )
      return 0;
  }
  else if ( !(v1 >> 1) )
  {
    return 0;
  }
  if ( (v1 & 1) != 0 )
  {
    if ( *(_BYTE *)(*((_QWORD *)this + 2) + *((_QWORD *)this + 1) - 1LL) != 47 )
      goto LABEL_5;
    return 0;
  }
  if ( *((_BYTE *)this + ((unsigned __int8)v1 >> 1)) == 47 )
    return 0;
LABEL_5:
  if ( (v1 & 1) != 0 )
    v2 = *((_QWORD *)this + 1);
  else
    v2 = v1 >> 1;
  std::string::push_back(this, 47);
  return v2;
}


// Address: 0x283f130 | Name: _ZN5boost10filesystem4pathdVEPKc
boost::filesystem::path *__fastcall boost::filesystem::path::operator/=(
        boost::filesystem::path *this,
        const boost::filesystem::path::value_type *ptr)
{
  unsigned __int64 v2; // rbp
  char *v3; // rcx
  unsigned __int64 v4; // rdx
  size_t v5; // rax
  size_t v6; // r12
  char *v7; // r15
  char *v8; // r13
  size_t v9; // r15
  unsigned __int8 v10; // bl
  char v11; // cl
  char *v12; // rsi
  _BYTE *v13; // rax
  __int64 v15; // rdx
  struct _Unwind_Exception *v16; // rax
  struct _Unwind_Exception *v17; // rbx
  __int128 dest; // [rsp+0h] [rbp-48h] BYREF
  void *v19; // [rsp+10h] [rbp-38h]

  if ( !*ptr )
    return this;
  v2 = *(unsigned __int8 *)this;
  if ( (v2 & 1) != 0 )
  {
    if ( *((_QWORD *)this + 2) > (unsigned __int64)ptr )
      goto LABEL_14;
  }
  else if ( (char *)this + 1 > ptr )
  {
    goto LABEL_14;
  }
  if ( (v2 & 1) != 0 )
  {
    v4 = *((_QWORD *)this + 1);
    v3 = (char *)*((_QWORD *)this + 2);
  }
  else
  {
    v3 = (char *)this + 1;
    v4 = v2 >> 1;
  }
  if ( &v3[v4] <= ptr )
  {
LABEL_14:
    if ( *ptr != 47 )
    {
      if ( (v2 & 1) != 0 )
      {
        if ( !*((_QWORD *)this + 1) )
          goto LABEL_34;
      }
      else if ( !((unsigned __int8)v2 >> 1) )
      {
        goto LABEL_34;
      }
      if ( (v2 & 1) == 0 )
      {
        if ( *((_BYTE *)this + ((unsigned __int8)v2 >> 1)) == 47 )
          goto LABEL_34;
        goto LABEL_33;
      }
      if ( *(_BYTE *)(*((_QWORD *)this + 2) + *((_QWORD *)this + 1) - 1LL) != 47 )
LABEL_33:
        std::string::push_back(this, 47);
    }
LABEL_34:
    std::string::append(this, ptr);
    return this;
  }
  dest = 0;
  v19 = 0;
  v5 = strlen(ptr);
  if ( v5 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
    v17 = v16;
    if ( (dest & 1) != 0 )
      operator delete(v19);
    _Unwind_Resume(v17);
  }
  v6 = v5;
  if ( v5 >= 0x17 )
  {
    v9 = (v5 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v19 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v6;
    v7 = (char *)&dest + 1;
    goto LABEL_23;
  }
  LOBYTE(dest) = 2 * v5;
  v7 = (char *)&dest + 1;
  v8 = (char *)&dest + 1;
  if ( v5 )
LABEL_23:
    memcpy(v8, ptr, v6);
  v8[v6] = 0;
  v10 = dest;
  v11 = dest & 1;
  v12 = (char *)v19;
  v13 = v19;
  if ( (dest & 1) == 0 )
    v13 = (char *)&dest + 1;
  if ( *v13 == 47 )
    goto LABEL_40;
  if ( (v2 & 1) != 0 )
  {
    if ( !*((_QWORD *)this + 1) )
      goto LABEL_40;
  }
  else if ( !(v2 >> 1) )
  {
    goto LABEL_40;
  }
  if ( (v2 & 1) == 0 )
  {
    if ( *((_BYTE *)this + (v2 >> 1)) == 47 )
      goto LABEL_40;
    goto LABEL_39;
  }
  if ( *(_BYTE *)(*((_QWORD *)this + 2) + *((_QWORD *)this + 1) - 1LL) != 47 )
  {
LABEL_39:
    std::string::push_back(this, 47);
    v10 = dest;
    v12 = (char *)v19;
    v11 = dest & 1;
  }
LABEL_40:
  if ( v11 )
  {
    v15 = *((_QWORD *)&dest + 1);
    v7 = v12;
  }
  else
  {
    v15 = v10 >> 1;
  }
  std::string::append(this, v7, v15);
  if ( (dest & 1) != 0 )
    operator delete(v19);
  return this;
}


// Address: 0x283f380 | Name: _ZNK5boost10filesystem4path7compareERKS1_
int __fastcall boost::filesystem::path::compare(const boost::filesystem::path *this, const boost::filesystem::path *p)
{
  unsigned __int64 v2; // rax
  unsigned __int64 v3; // rax
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // rax
  int v6; // ebx
  _BYTE v8[16]; // [rsp+8h] [rbp-C0h] BYREF
  void *ptr; // [rsp+18h] [rbp-B0h]
  __int128 v10; // [rsp+30h] [rbp-98h] BYREF
  __int64 v11; // [rsp+40h] [rbp-88h]
  const boost::filesystem::path *v12; // [rsp+48h] [rbp-80h]
  unsigned __int64 v13; // [rsp+50h] [rbp-78h]
  __int128 v14; // [rsp+60h] [rbp-68h] BYREF
  __int64 v15; // [rsp+70h] [rbp-58h]
  const boost::filesystem::path *v16; // [rsp+78h] [rbp-50h]
  unsigned __int64 v17; // [rsp+80h] [rbp-48h]
  _BYTE v18[16]; // [rsp+90h] [rbp-38h] BYREF
  void *v19; // [rsp+A0h] [rbp-28h]

  boost::filesystem::path::begin((boost::filesystem::path *)v18);
  v14 = 0;
  v15 = 0;
  v16 = this;
  v2 = *(unsigned __int8 *)this;
  if ( (v2 & 1) != 0 )
    v3 = *((_QWORD *)this + 1);
  else
    v3 = v2 >> 1;
  v17 = v3;
  boost::filesystem::path::begin((boost::filesystem::path *)v8);
  v10 = 0;
  v11 = 0;
  v12 = p;
  v4 = *(unsigned __int8 *)p;
  if ( (v4 & 1) != 0 )
    v5 = *((_QWORD *)p + 1);
  else
    v5 = v4 >> 1;
  v13 = v5;
  v6 = boost::filesystem::detail::lex_compare(v18, &v14, v8, &v10);
  if ( (v8[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v18[0] & 1) != 0 )
    operator delete(v19);
  return v6;
}


// Address: 0x283f490 | Name: _ZN5boost10filesystem6detail11lex_compareENS0_4path8iteratorES3_S3_S3_
__int64 __fastcall boost::filesystem::detail::lex_compare(_QWORD *a1, __int64 a2, _QWORD *a3, __int64 a4)
{
  _QWORD *v4; // rbx
  _QWORD *v5; // rbp
  __int64 v6; // rax
  __int64 v7; // rdx
  unsigned __int64 v8; // rcx
  size_t v9; // r15
  unsigned __int64 v10; // r13
  size_t v11; // r12
  size_t v12; // rbx
  const void *v13; // rbp
  const void *v14; // r14
  int v15; // eax
  int v16; // eax
  unsigned int v17; // esi
  __int64 result; // rax
  void *s2; // [rsp+20h] [rbp-48h]
  __int64 i; // [rsp+28h] [rbp-40h]
  char v23; // [rsp+30h] [rbp-38h]

  v4 = a3;
  v5 = a1;
  s2 = (char *)a3 + 1;
  for ( i = a4; ; a4 = i )
  {
    v6 = v5[3];
    v7 = *(_QWORD *)(a2 + 24);
    if ( v6 == v7 && v5[4] == *(_QWORD *)(a2 + 32) )
      goto LABEL_39;
    if ( v4[3] == *(_QWORD *)(a4 + 24) && v4[4] == *(_QWORD *)(a4 + 32) )
      break;
    v8 = *(unsigned __int8 *)v4;
    if ( (v8 & 1) != 0 )
      v9 = v4[1];
    else
      v9 = v8 >> 1;
    v10 = *(unsigned __int8 *)v5;
    if ( (v10 & 1) != 0 )
      v11 = v5[1];
    else
      v11 = v10 >> 1;
    v12 = v11;
    if ( v11 > v9 )
      v12 = v9;
    if ( !v12 )
      goto LABEL_23;
    v13 = (char *)a1 + 1;
    if ( (v10 & 1) != 0 )
      v13 = (const void *)a1[2];
    v14 = s2;
    v23 = v8;
    if ( (v8 & 1) != 0 )
      v14 = (const void *)a3[2];
    v15 = memcmp(v13, v14, v12);
    LOBYTE(v8) = v23;
    if ( v15 )
    {
      if ( v15 < 0 )
        return (unsigned int)-1;
    }
    else
    {
LABEL_23:
      if ( v11 < v9 )
        return (unsigned int)-1;
      if ( !v12 )
        goto LABEL_32;
      v14 = s2;
      if ( (v8 & 1) != 0 )
        v14 = (const void *)a3[2];
      v13 = (char *)a1 + 1;
      if ( (v10 & 1) != 0 )
        v13 = (const void *)a1[2];
    }
    v16 = memcmp(v14, v13, v12);
    if ( v16 )
    {
      if ( v16 < 0 )
        return 1;
      goto LABEL_2;
    }
LABEL_32:
    if ( v11 > v9 )
      return 1;
LABEL_2:
    v5 = a1;
    boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)a1);
    v4 = a3;
    boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)a3);
  }
  v17 = 1;
  if ( v6 != v7 )
    return v17;
  result = 1;
  if ( v5[4] == *(_QWORD *)(a2 + 32) )
  {
LABEL_39:
    result = 0xFFFFFFFFLL;
    if ( v4[3] == *(_QWORD *)(a4 + 24) )
    {
      v17 = 0;
      if ( v4[4] == *(_QWORD *)(a4 + 32) )
        return v17;
    }
  }
  return result;
}


// Address: 0x283f670 | Name: _ZNK5boost10filesystem4path5beginEv
soap *__fastcall boost::filesystem::path::begin(soap *this, unsigned __int8 *a2)
{
  unsigned __int64 v3; // rcx
  unsigned __int64 v4; // rax
  char *v5; // rdi
  unsigned __int64 j; // rdx
  unsigned __int64 v7; // rcx
  char v8; // cl
  unsigned __int64 i; // rdx
  int v10; // edx
  void *v11; // rcx
  size_t v12; // r8
  const void *v13; // r9
  unsigned __int64 v14; // rax
  _BYTE v16[16]; // [rsp+0h] [rbp-28h] BYREF
  void *ptr; // [rsp+10h] [rbp-18h]

  *(_OWORD *)&this->_vptr$soap = 0;
  *(_QWORD *)&this->imode = 0;
  this->float_format = (const char *)a2;
  v3 = *a2;
  if ( (v3 & 1) != 0 )
    v4 = *((_QWORD *)a2 + 1);
  else
    v4 = v3 >> 1;
  this->double_format = 0;
  if ( !v4 )
  {
    j = 0;
    v7 = 0;
    goto LABEL_25;
  }
  if ( (v3 & 1) != 0 )
    v5 = (char *)*((_QWORD *)a2 + 2);
  else
    v5 = (char *)(a2 + 1);
  v8 = *v5;
  if ( v4 == 1 )
  {
    j = 0;
    if ( v8 != 47 )
      goto LABEL_21;
LABEL_20:
    v7 = 1;
    goto LABEL_25;
  }
  if ( v8 != 47 )
  {
LABEL_21:
    v7 = 0;
    goto LABEL_22;
  }
  if ( v5[1] != 47 || v4 != 2 && v5[2] == 47 )
  {
    for ( i = 1; i < v4; ++i )
    {
      if ( v5[i] != 47 )
        break;
      this->double_format = (const char *)i;
    }
    j = i - 1;
    goto LABEL_20;
  }
  v7 = 2;
LABEL_22:
  for ( j = 0; v7 < v4; ++v7 )
  {
    if ( v5[v7] == 47 )
      break;
  }
LABEL_25:
  std::string::basic_string(v16, a2, j, v7, a2);
  std::string::operator=(this, (int)v16, v10, v11, v12, v13);
  if ( (v16[0] & 1) != 0 )
    operator delete(ptr);
  v14 = LOBYTE(this->_vptr$soap);
  if ( (v14 & 1) != 0 )
  {
    if ( *(_QWORD *)&this->state != 1 )
      return this;
  }
  else if ( v14 >> 1 != 1 )
  {
    return this;
  }
  if ( !(unsigned int)std::string::compare(this, 0, -1, "/", 1) )
    std::string::assign(this, "/");
  return this;
}


// Address: 0x283f850 | Name: _ZN5boost10filesystem4path27m_erase_redundant_separatorEm
void __fastcall boost::filesystem::path::m_erase_redundant_separator(
        boost::filesystem::path *this,
        std::string::size_type sep_pos)
{
  unsigned __int64 v2; // rax

  if ( sep_pos )
  {
    v2 = *(unsigned __int8 *)this;
    if ( (v2 & 1) == 0 )
    {
      if ( v2 >> 1 <= sep_pos )
        return;
LABEL_4:
      if ( (v2 & 1) != 0 )
      {
        if ( *(_BYTE *)(*((_QWORD *)this + 2) + sep_pos + 1) != 47 )
          return;
      }
      else if ( *((_BYTE *)this + sep_pos + 2) != 47 )
      {
        return;
      }
      std::string::erase(this, sep_pos, 1);
      return;
    }
    if ( *((_QWORD *)this + 1) > sep_pos )
      goto LABEL_4;
  }
}


// Address: 0x283f8a0 | Name: _ZN5boost10filesystem4path15remove_filenameEv
boost::filesystem::path *__fastcall boost::filesystem::path::remove_filename(boost::filesystem::path *this)
{
  std::string::size_type v1; // rax

  v1 = boost::filesystem::path::m_parent_path_end(this);
  std::string::erase(this, v1, -1);
  return this;
}


// Address: 0x283f8c0 | Name: _ZNK5boost10filesystem4path17m_parent_path_endEv
std::string::size_type __fastcall boost::filesystem::path::m_parent_path_end(const boost::filesystem::path *this)
{
  unsigned __int64 v1; // r15
  unsigned __int64 v2; // rax
  char *v3; // rcx
  char *v4; // r12
  `anonymous namespace'::size_type v5; // rbx
  `anonymous namespace'::size_type v6; // rdx
  bool v7; // zf
  char *v8; // rax
  bool v9; // bp
  `anonymous namespace'::size_type v10; // rax
  std::string::size_type v11; // rcx
  std::string::size_type result; // rax

  v1 = *(unsigned __int8 *)this;
  if ( (v1 & 1) != 0 )
    v2 = *((_QWORD *)this + 1);
  else
    v2 = v1 >> 1;
  v3 = (char *)this + 1;
  if ( v2 != 2 )
  {
    if ( !v2 )
    {
      v4 = (char *)*((_QWORD *)this + 2);
      if ( (v1 & 1) != 0 )
        v3 = (char *)*((_QWORD *)this + 2);
      v5 = -1;
      if ( (v1 & 1) == 0 )
      {
LABEL_9:
        v6 = (unsigned __int8)v1 >> 1;
        goto LABEL_20;
      }
LABEL_19:
      v6 = *((_QWORD *)this + 1);
LABEL_20:
      if ( v6 <= v5 )
        v2 = v6;
      v5 = 0;
      while ( v2 )
      {
        v7 = v3[--v2] == 47;
        if ( v7 )
        {
          if ( v2 == -1 )
            goto LABEL_34;
          if ( v2 == 1 && *v3 == 47 )
          {
            v5 = 0;
            break;
          }
          v5 = v2 + 1;
          if ( (v1 & 1) == 0 )
            goto LABEL_30;
          goto LABEL_35;
        }
      }
LABEL_29:
      if ( (v1 & 1) == 0 )
        goto LABEL_30;
LABEL_35:
      if ( *((_QWORD *)this + 1) )
        goto LABEL_31;
LABEL_36:
      v9 = 1;
      goto LABEL_37;
    }
    v4 = (char *)*((_QWORD *)this + 2);
    if ( (v1 & 1) != 0 )
      v3 = (char *)*((_QWORD *)this + 2);
LABEL_17:
    v5 = v2 - 1;
    if ( v3[v2 - 1] == 47 )
      goto LABEL_29;
    if ( (v1 & 1) == 0 )
      goto LABEL_9;
    goto LABEL_19;
  }
  v4 = (char *)*((_QWORD *)this + 2);
  if ( (v1 & 1) != 0 )
    v3 = (char *)*((_QWORD *)this + 2);
  if ( *v3 != 47 || v3[1] != 47 )
    goto LABEL_17;
LABEL_34:
  v5 = 0;
  if ( (v1 & 1) != 0 )
    goto LABEL_35;
LABEL_30:
  if ( !(v1 >> 1) )
    goto LABEL_36;
LABEL_31:
  v8 = (char *)this + 1;
  if ( (v1 & 1) != 0 )
    v8 = v4;
  v9 = v8[v5] != 47;
LABEL_37:
  v10 = `anonymous namespace'::root_directory_start(this, v5);
  if ( (v1 & 1) == 0 )
    v4 = (char *)this + 1;
  do
  {
    v11 = v5;
    if ( !v5 )
      break;
    if ( v10 + 1 == v5 )
      break;
    --v5;
  }
  while ( v4[v11 - 1] == 47 );
  v7 = (v11 ^ 1 | v10) == 0;
  result = -1;
  if ( !v7 )
    result = v11;
  if ( v9 )
    return v11;
  return result;
}


// Address: 0x283fa50 | Name: _ZN5boost10filesystem4path25remove_trailing_separatorEv
boost::filesystem::path *__fastcall boost::filesystem::path::remove_trailing_separator(boost::filesystem::path *this)
{
  unsigned __int64 v1; // rax
  __int64 v2; // rsi

  v1 = *(unsigned __int8 *)this;
  if ( (v1 & 1) != 0 )
  {
    if ( !*((_QWORD *)this + 1) )
      return this;
  }
  else if ( !(v1 >> 1) )
  {
    return this;
  }
  if ( (v1 & 1) != 0 )
  {
    if ( *(_BYTE *)(*((_QWORD *)this + 2) + *((_QWORD *)this + 1) - 1LL) != 47 )
      return this;
  }
  else if ( *((_BYTE *)this + (v1 >> 1)) != 47 )
  {
    return this;
  }
  if ( (v1 & 1) != 0 )
    v2 = *((_QWORD *)this + 1);
  else
    v2 = (unsigned __int8)v1 >> 1;
  std::string::erase(this, v2 - 1, -1);
  return this;
}


// Address: 0x283fac0 | Name: _ZN5boost10filesystem4path17replace_extensionERKS1_
boost::filesystem::path *__fastcall boost::filesystem::path::replace_extension(
        boost::filesystem::path *this,
        const boost::filesystem::path *new_extension)
{
  unsigned __int64 v4; // rbx
  unsigned __int64 v5; // rbx
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rcx
  char v8; // di
  unsigned __int64 v9; // rbx
  unsigned __int64 v10; // rax
  char *v11; // rsi
  _BYTE *v12; // rax
  _BYTE v14[8]; // [rsp+0h] [rbp-38h] BYREF
  unsigned __int64 v15; // [rsp+8h] [rbp-30h]
  void *ptr; // [rsp+10h] [rbp-28h]

  v4 = *(unsigned __int8 *)this;
  if ( (v4 & 1) != 0 )
    v5 = *((_QWORD *)this + 1);
  else
    v5 = v4 >> 1;
  boost::filesystem::path::extension((boost::filesystem::path *)v14);
  if ( (v14[0] & 1) != 0 )
    v6 = v15;
  else
    v6 = (unsigned __int64)v14[0] >> 1;
  std::string::erase(this, v5 - v6, -1);
  if ( (v14[0] & 1) != 0 )
    operator delete(ptr);
  v7 = (unsigned __int64)*(unsigned __int8 *)new_extension >> 1;
  v8 = *(_BYTE *)new_extension & 1;
  v9 = *((_QWORD *)new_extension + 1);
  v10 = v9;
  if ( !v8 )
    v10 = (unsigned __int64)*(unsigned __int8 *)new_extension >> 1;
  if ( v10 )
  {
    v11 = (char *)*((_QWORD *)new_extension + 2);
    v12 = (_BYTE *)*((_QWORD *)new_extension + 2);
    if ( !v8 )
      v12 = (char *)new_extension + 1;
    if ( *v12 != 46 )
    {
      std::string::push_back(this, 46);
      v9 = *((_QWORD *)new_extension + 1);
      v11 = (char *)*((_QWORD *)new_extension + 2);
      v8 = *(_BYTE *)new_extension & 1;
      v7 = (unsigned __int64)*(unsigned __int8 *)new_extension >> 1;
    }
    if ( v8 )
      v7 = v9;
    else
      v11 = (char *)new_extension + 1;
    std::string::append(this, v11, v7);
  }
  return this;
}


// Address: 0x283fbc0 | Name: _ZNK5boost10filesystem4path9extensionEv
boost::filesystem::path *__fastcall boost::filesystem::path::extension(boost::filesystem::path *this)
{
  __int64 v1; // rax
  char *v2; // r14
  const char *v4; // r14
  size_t v5; // rax
  size_t v6; // r13
  char *v7; // r12
  size_t v8; // rbx
  struct _Unwind_Exception *v9; // rax
  struct _Unwind_Exception *v10; // rbx
  char v11; // [rsp+8h] [rbp-40h] BYREF
  char v12; // [rsp+9h] [rbp-3Fh] BYREF
  void *ptr; // [rsp+18h] [rbp-30h]

  boost::filesystem::path::filename((boost::filesystem::path *)&v11);
  if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
  {
    p = 0;
    qword_2CE55C8 = 0;
    p = 11778;
    *(&p + 2) = 0;
    __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
    __cxa_guard_release(&byte_2CE55D0);
  }
  if ( boost::filesystem::path::compare((const boost::filesystem::path *)&v11, (const boost::filesystem::path *)&p) )
  {
    if ( !(_BYTE)byte_2CE55F0 && __cxa_guard_acquire(&byte_2CE55F0) )
    {
      xmmword_2CE55D8 = 0;
      qword_2CE55E8 = 0;
      xmmword_2CE55D8 = 4;
      strcpy((char *)&xmmword_2CE55D8 + 1, "..");
      __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &xmmword_2CE55D8, &dso_handle);
      __cxa_guard_release(&byte_2CE55F0);
    }
    if ( boost::filesystem::path::compare(
           (const boost::filesystem::path *)&v11,
           (const boost::filesystem::path *)&xmmword_2CE55D8) )
    {
      v1 = std::string::rfind(&v11, 46, -1);
      if ( v1 != -1 )
      {
        if ( (v11 & 1) != 0 )
          v2 = (char *)ptr;
        else
          v2 = &v12;
        v4 = &v2[v1];
        *(_OWORD *)this = 0;
        *((_QWORD *)this + 2) = 0;
        v5 = strlen(v4);
        if ( v5 >= 0xFFFFFFFFFFFFFFF0LL )
        {
          std::__basic_string_common<true>::__throw_length_error(this);
          v10 = v9;
          if ( (v11 & 1) != 0 )
            operator delete(ptr);
          _Unwind_Resume(v10);
        }
        v6 = v5;
        if ( v5 >= 0x17 )
        {
          v8 = (v5 + 16) & 0xFFFFFFFFFFFFFFF0LL;
          v7 = (char *)operator new(v8);
          *((_QWORD *)this + 2) = v7;
          *(_QWORD *)this = v8 | 1;
          *((_QWORD *)this + 1) = v6;
        }
        else
        {
          *(_BYTE *)this = 2 * v5;
          v7 = (char *)this + 1;
          if ( !v5 )
          {
LABEL_18:
            v7[v6] = 0;
            if ( (v11 & 1) == 0 )
              return this;
            goto LABEL_9;
          }
        }
        memcpy(v7, v4, v6);
        goto LABEL_18;
      }
    }
  }
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  if ( (v11 & 1) != 0 )
LABEL_9:
    operator delete(ptr);
  return this;
}


// Address: 0x283fe00 | Name: _ZNK5boost10filesystem4path9root_pathEv
boost::filesystem::path *__fastcall boost::filesystem::path::root_path(boost::filesystem::path *this, char *a2)
{
  unsigned __int64 v3; // rbx
  `anonymous namespace'::size_type v4; // rsi
  `anonymous namespace'::size_type v5; // rax
  char *v6; // rcx
  __int64 v7; // rbx
  unsigned __int64 v8; // rbx
  `anonymous namespace'::size_type v9; // rsi
  `anonymous namespace'::size_type v10; // rax
  char *v11; // r15
  __int128 v13; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  boost::filesystem::path::root_name(this);
  v3 = (unsigned __int8)*a2;
  if ( (v3 & 1) != 0 )
    v4 = *((_QWORD *)a2 + 1);
  else
    v4 = v3 >> 1;
  v5 = `anonymous namespace'::root_directory_start(a2, v4);
  if ( v5 == -1 )
    return this;
  if ( (v3 & 1) != 0 )
    v6 = (char *)*((_QWORD *)a2 + 2);
  else
    v6 = a2 + 1;
  boost::filesystem::path::path<char const*>((boost::filesystem::path *)&v13, &v6[v5], &v6[v5 + 1]);
  if ( (v13 & 1) != 0 )
  {
    v7 = *((_QWORD *)&v13 + 1);
    operator delete(ptr);
    if ( !v7 )
      return this;
  }
  else if ( (unsigned __int8)v13 < 2u )
  {
    return this;
  }
  v8 = (unsigned __int8)*a2;
  if ( (v8 & 1) != 0 )
    v9 = *((_QWORD *)a2 + 1);
  else
    v9 = v8 >> 1;
  v10 = `anonymous namespace'::root_directory_start(a2, v9);
  if ( v10 == -1 )
  {
    v13 = 0;
    ptr = 0;
LABEL_21:
    std::string::append(this, (const char *)&v13 + 1);
    goto LABEL_23;
  }
  if ( (v8 & 1) != 0 )
    v11 = (char *)*((_QWORD *)a2 + 2);
  else
    v11 = a2 + 1;
  boost::filesystem::path::path<char const*>((boost::filesystem::path *)&v13, &v11[v10], &v11[v10 + 1]);
  if ( (v13 & 1) == 0 )
    goto LABEL_21;
  std::string::append(this, (const char *)ptr);
LABEL_23:
  if ( (v13 & 1) != 0 )
    operator delete(ptr);
  return this;
}


// Address: 0x283ff60 | Name: _ZNK5boost10filesystem4path9root_nameEv
boost::filesystem::path *__fastcall boost::filesystem::path::root_name(
        boost::filesystem::path *this,
        unsigned __int8 *a2)
{
  unsigned __int64 v2; // rcx
  char *v3; // rax
  unsigned __int8 v5; // [rsp+0h] [rbp-38h] BYREF
  char v6; // [rsp+1h] [rbp-37h] BYREF
  unsigned __int64 v7; // [rsp+8h] [rbp-30h]
  void *ptr; // [rsp+10h] [rbp-28h]
  __int64 v9; // [rsp+20h] [rbp-18h]

  boost::filesystem::path::begin((soap *)&v5, a2);
  v2 = *a2;
  if ( (v2 & 1) != 0 )
  {
    if ( v9 == *((_QWORD *)a2 + 1) )
      goto LABEL_16;
  }
  else if ( v9 == v2 >> 1 )
  {
    goto LABEL_16;
  }
  if ( (v5 & 1) != 0 )
  {
    if ( v7 < 2 )
      goto LABEL_16;
  }
  else if ( (unsigned __int64)v5 >> 1 < 2 )
  {
LABEL_16:
    *(_OWORD *)this = 0;
    *((_QWORD *)this + 2) = 0;
    if ( (v5 & 1) == 0 )
      return this;
    goto LABEL_11;
  }
  if ( (v5 & 1) != 0 )
  {
    v3 = (char *)ptr;
    if ( *(_BYTE *)ptr != 47 )
      goto LABEL_16;
  }
  else
  {
    v3 = &v6;
    if ( v6 != 47 )
      goto LABEL_16;
  }
  if ( v3[1] != 47 )
    goto LABEL_16;
  std::string::basic_string(this, &v5);
  if ( (v5 & 1) != 0 )
LABEL_11:
    operator delete(ptr);
  return this;
}


// Address: 0x2840030 | Name: _ZNK5boost10filesystem4path14root_directoryEv
boost::filesystem::path *__fastcall boost::filesystem::path::root_directory(boost::filesystem::path *this, char *a2)
{
  unsigned __int64 v3; // r15
  `anonymous namespace'::size_type v4; // rsi
  `anonymous namespace'::size_type v5; // rax
  char *v6; // rbx

  v3 = (unsigned __int8)*a2;
  if ( (v3 & 1) != 0 )
    v4 = *((_QWORD *)a2 + 1);
  else
    v4 = v3 >> 1;
  v5 = `anonymous namespace'::root_directory_start(a2, v4);
  if ( v5 == -1 )
  {
    *(_OWORD *)this = 0;
    *((_QWORD *)this + 2) = 0;
  }
  else
  {
    if ( (v3 & 1) != 0 )
      v6 = (char *)*((_QWORD *)a2 + 2);
    else
      v6 = a2 + 1;
    boost::filesystem::path::path<char const*>(this, &v6[v5], &v6[v5 + 1]);
  }
  return this;
}


// Address: 0x28400a0 | Name: _ZN12_GLOBAL__N_120root_directory_startERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEEm
`anonymous namespace'::size_type __fastcall `anonymous namespace'::root_directory_start(
        const `anonymous namespace'::string_type *path,
        `anonymous namespace'::size_type size)
{
  char *v2; // rdx
  char v3; // cl
  char *v4; // r10
  char *v5; // rsi
  `anonymous namespace'::size_type result; // rax
  char *v7; // r8
  unsigned __int64 v8; // r9
  `anonymous namespace'::size_type v9; // rcx
  char *v10; // rdx
  char *v11; // rcx
  unsigned __int64 v12; // r9
  bool v13; // zf

  if ( size == 2 )
  {
    v2 = (char *)path + 1;
    v3 = *(_BYTE *)path & 1;
    v4 = (char *)*((_QWORD *)path + 2);
    v5 = v4;
    if ( !v3 )
      v5 = (char *)path + 1;
    if ( *v5 == 47 )
    {
      result = -1;
      if ( v5[1] == 47 )
        return result;
    }
    goto LABEL_17;
  }
  if ( size < 4 )
  {
    if ( !size )
      return -1;
    v4 = (char *)*((_QWORD *)path + 2);
    v3 = *(_BYTE *)path & 1;
    v2 = (char *)path + 1;
LABEL_17:
    if ( v3 )
      v2 = v4;
    if ( *v2 == 47 )
      return 0;
    return -1;
  }
  v2 = (char *)path + 1;
  v3 = *(_BYTE *)path & 1;
  v4 = (char *)*((_QWORD *)path + 2);
  v7 = v4;
  if ( !v3 )
    v7 = (char *)path + 1;
  if ( *v7 != 47 || v7[1] != 47 || v7[2] == 47 )
    goto LABEL_17;
  if ( v3 )
    v8 = *((_QWORD *)path + 1);
  else
    v8 = (unsigned __int64)*(unsigned __int8 *)path >> 1;
  result = -1;
  v9 = -1;
  if ( v8 >= 3 )
  {
    v10 = v7 + 2;
    v11 = &v7[v8];
    v12 = v8 - 3;
    while ( v12 )
    {
      --v12;
      v13 = *++v10 == 47;
      if ( v13 )
        goto LABEL_30;
    }
    v10 = v11;
LABEL_30:
    v13 = v10 == v11;
    v9 = -1;
    if ( !v13 )
      v9 = v10 - v7;
  }
  if ( v9 < size )
    return v9;
  return result;
}


// Address: 0x28401a0 | Name: _ZNK5boost10filesystem4path13relative_pathEv
boost::filesystem::path *__fastcall boost::filesystem::path::relative_path(
        boost::filesystem::path *this,
        unsigned __int8 *a2)
{
  unsigned __int64 v2; // rcx
  char *v3; // rdx
  unsigned __int8 *v4; // rbx
  const char *v5; // rbx
  size_t v6; // rax
  size_t v7; // r15
  char *v8; // r12
  size_t v9; // r13
  struct _Unwind_Exception *v11; // rax
  struct _Unwind_Exception *v12; // rbx
  char v13; // [rsp+8h] [rbp-50h] BYREF
  char v14; // [rsp+9h] [rbp-4Fh] BYREF
  void *ptr; // [rsp+18h] [rbp-40h]
  __int64 v16; // [rsp+28h] [rbp-30h]

  boost::filesystem::path::begin((soap *)&v13, a2);
  while ( 1 )
  {
    v2 = *a2;
    if ( (v2 & 1) != 0 )
    {
      if ( v16 == *((_QWORD *)a2 + 1) )
        break;
    }
    else if ( v16 == v2 >> 1 )
    {
      break;
    }
    v3 = &v14;
    if ( (v13 & 1) != 0 )
      v3 = (char *)ptr;
    if ( *v3 != 47 )
      break;
    boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)&v13);
  }
  if ( (v2 & 1) != 0 )
    v4 = (unsigned __int8 *)*((_QWORD *)a2 + 2);
  else
    v4 = a2 + 1;
  v5 = (const char *)&v4[v16];
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v6 = strlen(v5);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(this);
    v12 = v11;
    if ( (v13 & 1) != 0 )
      operator delete(ptr);
    _Unwind_Resume(v12);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)this + 2) = v8;
    *(_QWORD *)this = v9 | 1;
    *((_QWORD *)this + 1) = v7;
    goto LABEL_18;
  }
  *(_BYTE *)this = 2 * v6;
  v8 = (char *)this + 1;
  if ( v6 )
LABEL_18:
    memcpy(v8, v5, v7);
  v8[v7] = 0;
  if ( (v13 & 1) != 0 )
    operator delete(ptr);
  return this;
}


// Address: 0x28402f0 | Name: _ZNK5boost10filesystem4path11parent_pathEv
boost::filesystem::path *__fastcall boost::filesystem::path::parent_path(boost::filesystem::path *this, const char *a2)
{
  std::string::size_type v2; // rax
  const char *v3; // rbx

  v2 = boost::filesystem::path::m_parent_path_end((const boost::filesystem::path *)a2);
  if ( v2 == -1 )
  {
    *(_OWORD *)this = 0;
    *((_QWORD *)this + 2) = 0;
  }
  else
  {
    if ( (*a2 & 1) != 0 )
      v3 = (const char *)*((_QWORD *)a2 + 2);
    else
      v3 = a2 + 1;
    boost::filesystem::path::path<char const*>(this, v3, &v3[v2]);
  }
  return this;
}


// Address: 0x2840350 | Name: _ZNK5boost10filesystem4path8filenameEv
boost::filesystem::path *__fastcall boost::filesystem::path::filename(
        boost::filesystem::path *this,
        unsigned __int8 *a2)
{
  unsigned __int64 v3; // rax
  unsigned __int64 v4; // rdx
  _BYTE *v5; // rdi
  unsigned __int8 *v6; // r15
  unsigned __int64 v7; // rcx
  unsigned __int64 v8; // rbx
  bool v9; // zf
  unsigned __int64 v10; // rdx
  unsigned __int8 *v11; // rdx
  unsigned __int8 *v12; // rdi
  unsigned __int64 v13; // rdi
  unsigned __int64 v14; // r9
  unsigned __int8 *v15; // rsi
  const char *v16; // r15
  size_t v17; // rax
  size_t v18; // r13
  char *v19; // r12
  size_t v20; // rbx
  __int64 v22; // rbx
  unsigned __int8 *v23; // r8
  __int64 v24; // rbx
  unsigned __int8 *v25; // rbx
  __int64 v26; // r9

  v3 = *a2;
  if ( (v3 & 1) != 0 )
    v4 = *((_QWORD *)a2 + 1);
  else
    v4 = v3 >> 1;
  v5 = a2 + 1;
  if ( v4 != 2 )
  {
    if ( !v4 )
    {
      v6 = (unsigned __int8 *)*((_QWORD *)a2 + 2);
      if ( (v3 & 1) != 0 )
        v5 = (_BYTE *)*((_QWORD *)a2 + 2);
      v7 = -1;
      if ( (v3 & 1) == 0 )
      {
LABEL_9:
        v8 = (unsigned __int8)v3 >> 1;
        goto LABEL_20;
      }
LABEL_19:
      v8 = *((_QWORD *)a2 + 1);
LABEL_20:
      if ( v8 <= v7 )
        v4 = v8;
      v7 = 0;
      while ( v4 )
      {
        v9 = v5[--v4] == 47;
        if ( v9 )
        {
          if ( v4 == -1 )
            goto LABEL_45;
          if ( v4 == 1 && *v5 == 47 )
          {
            v7 = 0;
            break;
          }
          v7 = v4 + 1;
          if ( (v3 & 1) == 0 )
            goto LABEL_30;
          goto LABEL_46;
        }
      }
LABEL_29:
      if ( (v3 & 1) == 0 )
        goto LABEL_30;
LABEL_46:
      v10 = *((_QWORD *)a2 + 1);
      if ( !v7 )
        goto LABEL_47;
      goto LABEL_31;
    }
    v6 = (unsigned __int8 *)*((_QWORD *)a2 + 2);
    if ( (v3 & 1) != 0 )
      v5 = (_BYTE *)*((_QWORD *)a2 + 2);
LABEL_17:
    v7 = v4 - 1;
    if ( v5[v4 - 1] == 47 )
      goto LABEL_29;
    if ( (v3 & 1) == 0 )
      goto LABEL_9;
    goto LABEL_19;
  }
  v6 = (unsigned __int8 *)*((_QWORD *)a2 + 2);
  if ( (v3 & 1) != 0 )
    v5 = (_BYTE *)*((_QWORD *)a2 + 2);
  if ( *v5 != 47 || v5[1] != 47 )
    goto LABEL_17;
LABEL_45:
  v7 = 0;
  if ( (v3 & 1) != 0 )
    goto LABEL_46;
LABEL_30:
  v10 = v3 >> 1;
  if ( !v7 )
    goto LABEL_47;
LABEL_31:
  if ( v10 )
  {
    v11 = a2 + 1;
    v12 = v6;
    if ( (v3 & 1) == 0 )
      v12 = a2 + 1;
    if ( v12[v7] == 47 )
    {
      if ( (v3 & 1) != 0 )
        v11 = v6;
      v13 = v7 + 1;
      while ( v13 != 1 )
      {
        v9 = v11[v13-- - 2] == 47;
        if ( !v9 )
        {
          if ( v13 < 3 || *v11 != 47 || v11[1] != 47 )
            goto LABEL_77;
          if ( (v3 & 1) != 0 )
            v14 = *((_QWORD *)a2 + 1);
          else
            v14 = (unsigned __int8)v3 >> 1;
          v22 = -1;
          if ( v14 >= 3 )
          {
            v23 = &v11[v14];
            v24 = 2;
            while ( v11[v24] != 47 )
            {
              if ( v14 == ++v24 )
              {
                v25 = &v11[v14];
                goto LABEL_66;
              }
            }
            v25 = &v11[v24];
LABEL_66:
            v26 = v25 - v11;
            v9 = v25 == v23;
            v22 = -1;
            if ( !v9 )
              v22 = v26;
          }
          if ( v22 != v13 )
          {
LABEL_77:
            if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
            {
              p = 0;
              qword_2CE55C8 = 0;
              p = 11778;
              *(&p + 2) = 0;
              __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
              __cxa_guard_release(&byte_2CE55D0);
            }
            std::string::basic_string(this, &p);
            return this;
          }
          break;
        }
      }
    }
  }
LABEL_47:
  v15 = a2 + 1;
  if ( (v3 & 1) == 0 )
    v6 = v15;
  v16 = (const char *)&v6[v7];
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v17 = strlen(v16);
  if ( v17 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(this);
    JUMPOUT(0x284060A);
  }
  v18 = v17;
  if ( v17 >= 0x17 )
  {
    v20 = (v17 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v19 = (char *)operator new(v20);
    *((_QWORD *)this + 2) = v19;
    *(_QWORD *)this = v20 | 1;
    *((_QWORD *)this + 1) = v18;
  }
  else
  {
    *(_BYTE *)this = 2 * v17;
    v19 = (char *)this + 1;
    if ( !v17 )
      goto LABEL_55;
  }
  memcpy(v19, v16, v18);
LABEL_55:
  v19[v18] = 0;
  return this;
}


// Address: 0x2840610 | Name: _ZN5boost10filesystem6detail8dot_pathEv
const boost::filesystem::path *__cdecl boost::filesystem::detail::dot_path()
{
  if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
  {
    p = 0;
    qword_2CE55C8 = 0;
    p = 11778;
    *(&p + 2) = 0;
    __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
    __cxa_guard_release(&byte_2CE55D0);
  }
  return (const boost::filesystem::path *)&p;
}


// Address: 0x2840690 | Name: _ZNK5boost10filesystem4path4stemEv
boost::filesystem::path *__fastcall boost::filesystem::path::stem(boost::filesystem::path *this, unsigned __int8 *a2)
{
  __int64 v2; // rax
  const char *p_begin; // rsi
  char v5; // [rsp+8h] [rbp-20h] BYREF
  char begin; // [rsp+9h] [rbp-1Fh] BYREF
  void *ptr; // [rsp+18h] [rbp-10h]

  boost::filesystem::path::filename((boost::filesystem::path *)&v5, a2);
  if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
  {
    p = 0;
    qword_2CE55C8 = 0;
    p = 11778;
    *(&p + 2) = 0;
    __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
    __cxa_guard_release(&byte_2CE55D0);
  }
  if ( !boost::filesystem::path::compare((const boost::filesystem::path *)&v5, (const boost::filesystem::path *)&p) )
    goto LABEL_8;
  if ( !(_BYTE)byte_2CE55F0 && __cxa_guard_acquire(&byte_2CE55F0) )
  {
    xmmword_2CE55D8 = 0;
    qword_2CE55E8 = 0;
    xmmword_2CE55D8 = 4;
    strcpy((char *)&xmmword_2CE55D8 + 1, "..");
    __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &xmmword_2CE55D8, &dso_handle);
    __cxa_guard_release(&byte_2CE55F0);
  }
  if ( boost::filesystem::path::compare(
         (const boost::filesystem::path *)&v5,
         (const boost::filesystem::path *)&xmmword_2CE55D8)
    && (v2 = std::string::rfind(&v5, 46, -1), v2 != -1) )
  {
    if ( (v5 & 1) != 0 )
      p_begin = (const char *)ptr;
    else
      p_begin = &begin;
    boost::filesystem::path::path<char const*>(this, p_begin, &p_begin[v2]);
  }
  else
  {
LABEL_8:
    std::string::basic_string(this, &v5);
  }
  if ( (v5 & 1) != 0 )
    operator delete(ptr);
  return this;
}


// Address: 0x2840850 | Name: _ZN5boost10filesystem6detail12dot_dot_pathEv
const boost::filesystem::path *__cdecl boost::filesystem::detail::dot_dot_path()
{
  if ( !(_BYTE)byte_2CE55F0 && __cxa_guard_acquire(&byte_2CE55F0) )
  {
    xmmword_2CE55D8 = 0;
    qword_2CE55E8 = 0;
    xmmword_2CE55D8 = 4;
    strcpy((char *)&xmmword_2CE55D8 + 1, "..");
    __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &xmmword_2CE55D8, &dso_handle);
    __cxa_guard_release(&byte_2CE55F0);
  }
  return (const boost::filesystem::path *)&xmmword_2CE55D8;
}


// Address: 0x28408d0 | Name: _ZN5boost10filesystem4path11m_normalizeEv
boost::filesystem::path *__fastcall boost::filesystem::path::m_normalize(boost::filesystem::path *this)
{
  unsigned __int64 v1; // rax
  unsigned __int64 v2; // rax
  unsigned __int64 v3; // rax
  void *v4; // rcx
  size_t v5; // r8
  const void *v6; // r9
  int v7; // edx
  unsigned __int64 v8; // rcx
  _BYTE *v9; // rsi
  _BYTE *v10; // rcx
  unsigned __int64 v11; // rcx
  _BYTE *v12; // rcx
  _BYTE *v13; // rcx
  std::string::size_type v14; // rax
  `anonymous namespace'::size_type v15; // rsi
  char *v16; // rcx
  `anonymous namespace'::size_type v17; // rax
  __int128 v19; // [rsp+0h] [rbp-128h] BYREF
  void *v20; // [rsp+10h] [rbp-118h]
  unsigned __int8 v21; // [rsp+18h] [rbp-110h] BYREF
  _BYTE v22[7]; // [rsp+19h] [rbp-10Fh] BYREF
  unsigned __int64 v23; // [rsp+20h] [rbp-108h]
  void *v24; // [rsp+28h] [rbp-100h]
  __int128 v25; // [rsp+30h] [rbp-F8h] BYREF
  void *v26; // [rsp+40h] [rbp-E8h]
  __int128 v27; // [rsp+48h] [rbp-E0h]
  unsigned __int8 v28; // [rsp+58h] [rbp-D0h] BYREF
  _BYTE v29[7]; // [rsp+59h] [rbp-CFh] BYREF
  unsigned __int64 v30; // [rsp+60h] [rbp-C8h]
  void *v31; // [rsp+68h] [rbp-C0h]
  __int128 v32; // [rsp+70h] [rbp-B8h]
  _BYTE v33[16]; // [rsp+80h] [rbp-A8h] BYREF
  void *ptr; // [rsp+90h] [rbp-98h]
  __int128 v35; // [rsp+98h] [rbp-90h]
  _BYTE v36[16]; // [rsp+A8h] [rbp-80h] BYREF
  void *v37; // [rsp+B8h] [rbp-70h]
  __int128 v38; // [rsp+C0h] [rbp-68h]
  _BYTE v39[16]; // [rsp+D0h] [rbp-58h] BYREF
  void *v40; // [rsp+E0h] [rbp-48h]
  __int128 v41; // [rsp+E8h] [rbp-40h]

  v1 = *(unsigned __int8 *)this;
  if ( (v1 & 1) != 0 )
  {
    if ( !*((_QWORD *)this + 1) )
      return this;
  }
  else if ( !(v1 >> 1) )
  {
    return this;
  }
  v19 = 0;
  v20 = 0;
  boost::filesystem::path::begin((soap *)v39, (unsigned __int8 *)this);
  v25 = 0;
  v26 = 0;
  *(_QWORD *)&v27 = this;
  v2 = *(unsigned __int8 *)this;
  if ( (v2 & 1) != 0 )
    v3 = *((_QWORD *)this + 1);
  else
    v3 = v2 >> 1;
  *((_QWORD *)&v27 + 1) = v3;
  std::string::basic_string(v36, &v25);
  v38 = v27;
  boost::filesystem::path::m_path_iterator_decrement((boost::filesystem::path::iterator *)&v25);
  std::string::basic_string(&v28, v39);
  v32 = v41;
  while ( 1 )
  {
    v7 = v32;
    if ( v32 == v38 )
      break;
    if ( (v28 & 1) != 0 )
    {
      v8 = v30;
      if ( v30 != 1 )
        goto LABEL_19;
    }
    else
    {
      v8 = (unsigned __int64)v28 >> 1;
      if ( v8 != 1 )
        goto LABEL_19;
    }
    v9 = v29;
    if ( (v28 & 1) != 0 )
      v9 = v31;
    if ( *v9 != 46 || v32 == v41 || v32 == v27 )
    {
LABEL_19:
      if ( (v19 & 1) != 0 )
      {
        if ( !*((_QWORD *)&v19 + 1) )
          goto LABEL_46;
      }
      else if ( !((unsigned __int64)(unsigned __int8)v19 >> 1) )
      {
        goto LABEL_46;
      }
      if ( v8 != 2 )
        goto LABEL_46;
      v10 = v29;
      if ( (v28 & 1) != 0 )
        v10 = v31;
      if ( *v10 != 46 || v10[1] != 46 )
        goto LABEL_46;
      boost::filesystem::path::filename((boost::filesystem::path *)v33, (unsigned __int8 *)&v19);
      std::string::basic_string(&v21, v33);
      if ( (v33[0] & 1) != 0 )
        operator delete(ptr);
      if ( (v21 & 1) != 0 )
      {
        v11 = v23;
        if ( !v23 )
          goto LABEL_44;
      }
      else
      {
        v11 = (unsigned __int64)v21 >> 1;
        if ( !v11 )
          goto LABEL_44;
      }
      if ( v11 == 2 )
      {
        v13 = v22;
        if ( (v21 & 1) != 0 )
          v13 = v24;
        if ( *v13 == 46 || v13[1] == 46 )
        {
LABEL_44:
          if ( (v21 & 1) != 0 )
            operator delete(v24);
LABEL_46:
          boost::filesystem::path::operator/=((boost::filesystem::path *)&v19, (const boost::filesystem::path *)&v28);
          goto LABEL_47;
        }
      }
      else if ( v11 == 1 )
      {
        v12 = v22;
        if ( (v21 & 1) != 0 )
          v12 = v24;
        if ( (*v12 & 0xFE) == 0x2E )
          goto LABEL_44;
      }
      v14 = boost::filesystem::path::m_parent_path_end((const boost::filesystem::path *)&v19);
      std::string::erase(&v19, v14, -1);
      if ( (v19 & 1) != 0 )
      {
        v15 = *((_QWORD *)&v19 + 1);
        if ( !*((_QWORD *)&v19 + 1) )
          goto LABEL_58;
      }
      else
      {
        v15 = (unsigned __int64)(unsigned __int8)v19 >> 1;
        if ( !v15 )
          goto LABEL_58;
      }
      v16 = (char *)&v19 + 1;
      if ( (v19 & 1) != 0 )
        v16 = (char *)v20;
      if ( v16[v15 - 1] == 47 )
      {
        v17 = `anonymous namespace'::root_directory_start(&v19, v15);
        if ( v17 == -1 || v17 != v15 - 1 )
          std::string::erase(&v19, v15 - 1, -1);
      }
LABEL_58:
      std::string::basic_string(v33, &v28);
      v35 = v32;
      if ( (v19 & 1) != 0 )
      {
        if ( !*((_QWORD *)&v19 + 1) )
        {
LABEL_62:
          boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)v33);
          if ( (_QWORD)v35 == (_QWORD)v38 )
          {
            if ( *((_QWORD *)&v35 + 1) != *((_QWORD *)&v38 + 1) && v35 == v27 )
            {
LABEL_67:
              if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
              {
                p = 0;
                qword_2CE55C8 = 0;
                p = 11778;
                *(&p + 2) = 0;
                __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
                __cxa_guard_release(&byte_2CE55D0);
              }
              if ( !boost::filesystem::path::compare(
                      (const boost::filesystem::path *)&v25,
                      (const boost::filesystem::path *)&p) )
              {
                if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
                {
                  p = 0;
                  qword_2CE55C8 = 0;
                  p = 11778;
                  *(&p + 2) = 0;
                  __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
                  __cxa_guard_release(&byte_2CE55D0);
                }
                boost::filesystem::path::operator/=(
                  (boost::filesystem::path *)&v19,
                  (const boost::filesystem::path *)&p);
              }
            }
          }
          else if ( v35 == v27 )
          {
            goto LABEL_67;
          }
        }
      }
      else if ( !((unsigned __int64)(unsigned __int8)v19 >> 1) )
      {
        goto LABEL_62;
      }
      if ( (v33[0] & 1) != 0 )
        operator delete(ptr);
      if ( (v21 & 1) != 0 )
        operator delete(v24);
    }
LABEL_47:
    boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)&v28);
  }
  if ( (v28 & 1) != 0 )
    operator delete(v31);
  if ( (v19 & 1) != 0 )
  {
    if ( !*((_QWORD *)&v19 + 1) )
      goto LABEL_85;
  }
  else if ( !((unsigned __int64)(unsigned __int8)v19 >> 1) )
  {
LABEL_85:
    if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
    {
      p = 0;
      qword_2CE55C8 = 0;
      p = 11778;
      *(&p + 2) = 0;
      __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
      __cxa_guard_release(&byte_2CE55D0);
    }
    boost::filesystem::path::operator/=((boost::filesystem::path *)&v19, (const boost::filesystem::path *)&p);
  }
  std::string::operator=((soap *)this, (int)&v19, v7, v4, v5, v6);
  if ( (v36[0] & 1) != 0 )
  {
    operator delete(v37);
    if ( (v25 & 1) != 0 )
      goto LABEL_94;
LABEL_89:
    if ( (v39[0] & 1) == 0 )
      goto LABEL_90;
LABEL_95:
    operator delete(v40);
    if ( (v19 & 1) != 0 )
LABEL_91:
      operator delete(v20);
  }
  else
  {
    if ( (v25 & 1) == 0 )
      goto LABEL_89;
LABEL_94:
    operator delete(v26);
    if ( (v39[0] & 1) != 0 )
      goto LABEL_95;
LABEL_90:
    if ( (v19 & 1) != 0 )
      goto LABEL_91;
  }
  return this;
}


// Address: 0x2841020 | Name: _ZNK5boost10filesystem4path16lexically_normalEv
boost::filesystem::path *__fastcall boost::filesystem::path::lexically_normal(
        boost::filesystem::path *this,
        unsigned __int8 *a2)
{
  unsigned __int64 v2; // rax
  unsigned __int64 v3; // rax
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // rcx
  _BYTE *v6; // rsi
  _BYTE *v7; // rcx
  unsigned __int64 v8; // rcx
  _BYTE *v9; // rcx
  _BYTE *v10; // rcx
  std::string::size_type v11; // rax
  __int128 v13; // [rsp+0h] [rbp-128h] BYREF
  void *v14; // [rsp+10h] [rbp-118h]
  unsigned __int8 v15; // [rsp+18h] [rbp-110h] BYREF
  _BYTE v16[7]; // [rsp+19h] [rbp-10Fh] BYREF
  unsigned __int64 v17; // [rsp+20h] [rbp-108h]
  void *v18; // [rsp+28h] [rbp-100h]
  __int128 v19; // [rsp+30h] [rbp-F8h] BYREF
  void *v20; // [rsp+40h] [rbp-E8h]
  __int128 v21; // [rsp+48h] [rbp-E0h]
  unsigned __int8 v22; // [rsp+58h] [rbp-D0h] BYREF
  _BYTE v23[7]; // [rsp+59h] [rbp-CFh] BYREF
  unsigned __int64 v24; // [rsp+60h] [rbp-C8h]
  void *v25; // [rsp+68h] [rbp-C0h]
  __int128 v26; // [rsp+70h] [rbp-B8h]
  _BYTE v27[16]; // [rsp+80h] [rbp-A8h] BYREF
  void *ptr; // [rsp+90h] [rbp-98h]
  __int128 v29; // [rsp+98h] [rbp-90h]
  _BYTE v30[16]; // [rsp+A8h] [rbp-80h] BYREF
  void *v31; // [rsp+B8h] [rbp-70h]
  __int128 v32; // [rsp+C0h] [rbp-68h]
  _BYTE v33[16]; // [rsp+D0h] [rbp-58h] BYREF
  void *v34; // [rsp+E0h] [rbp-48h]
  __int128 v35; // [rsp+E8h] [rbp-40h]

  v2 = *a2;
  if ( (v2 & 1) != 0 )
  {
    if ( *((_QWORD *)a2 + 1) )
      goto LABEL_3;
LABEL_6:
    std::string::basic_string(this, a2);
    return this;
  }
  if ( !(v2 >> 1) )
    goto LABEL_6;
LABEL_3:
  v13 = 0;
  v14 = 0;
  boost::filesystem::path::begin((soap *)v33, a2);
  v19 = 0;
  v20 = 0;
  *(_QWORD *)&v21 = a2;
  v3 = *a2;
  if ( (v3 & 1) != 0 )
    v4 = *((_QWORD *)a2 + 1);
  else
    v4 = v3 >> 1;
  *((_QWORD *)&v21 + 1) = v4;
  std::string::basic_string(v30, &v19);
  v32 = v21;
  boost::filesystem::path::m_path_iterator_decrement((boost::filesystem::path::iterator *)&v19);
  std::string::basic_string(&v22, v33);
  v26 = v35;
  while ( v26 != v32 )
  {
    if ( (v22 & 1) != 0 )
    {
      v5 = v24;
      if ( v24 != 1 )
        goto LABEL_19;
    }
    else
    {
      v5 = (unsigned __int64)v22 >> 1;
      if ( v5 != 1 )
        goto LABEL_19;
    }
    v6 = v23;
    if ( (v22 & 1) != 0 )
      v6 = v25;
    if ( *v6 != 46 || v26 == v35 || v26 == v21 )
    {
LABEL_19:
      if ( (v13 & 1) != 0 )
      {
        if ( !*((_QWORD *)&v13 + 1) )
          goto LABEL_46;
      }
      else if ( !((unsigned __int64)(unsigned __int8)v13 >> 1) )
      {
        goto LABEL_46;
      }
      if ( v5 != 2 )
        goto LABEL_46;
      v7 = v23;
      if ( (v22 & 1) != 0 )
        v7 = v25;
      if ( *v7 != 46 || v7[1] != 46 )
        goto LABEL_46;
      boost::filesystem::path::filename((boost::filesystem::path *)v27, (unsigned __int8 *)&v13);
      std::string::basic_string(&v15, v27);
      if ( (v27[0] & 1) != 0 )
        operator delete(ptr);
      if ( (v15 & 1) != 0 )
      {
        v8 = v17;
        if ( !v17 )
          goto LABEL_44;
      }
      else
      {
        v8 = (unsigned __int64)v15 >> 1;
        if ( !v8 )
          goto LABEL_44;
      }
      if ( v8 == 2 )
      {
        v10 = v16;
        if ( (v15 & 1) != 0 )
          v10 = v18;
        if ( *v10 == 46 || v10[1] == 46 )
        {
LABEL_44:
          if ( (v15 & 1) != 0 )
            operator delete(v18);
LABEL_46:
          boost::filesystem::path::operator/=((boost::filesystem::path *)&v13, (const boost::filesystem::path *)&v22);
          goto LABEL_47;
        }
      }
      else if ( v8 == 1 )
      {
        v9 = v16;
        if ( (v15 & 1) != 0 )
          v9 = v18;
        if ( (*v9 & 0xFE) == 0x2E )
          goto LABEL_44;
      }
      v11 = boost::filesystem::path::m_parent_path_end((const boost::filesystem::path *)&v13);
      std::string::erase(&v13, v11, -1);
      std::string::basic_string(v27, &v22);
      v29 = v26;
      if ( (v13 & 1) != 0 )
      {
        if ( !*((_QWORD *)&v13 + 1) )
        {
LABEL_52:
          boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)v27);
          if ( (_QWORD)v29 == (_QWORD)v32 )
          {
            if ( *((_QWORD *)&v29 + 1) != *((_QWORD *)&v32 + 1) && v29 == v21 )
            {
LABEL_57:
              if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
              {
                p = 0;
                qword_2CE55C8 = 0;
                p = 11778;
                *(&p + 2) = 0;
                __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
                __cxa_guard_release(&byte_2CE55D0);
              }
              if ( !boost::filesystem::path::compare(
                      (const boost::filesystem::path *)&v19,
                      (const boost::filesystem::path *)&p) )
              {
                if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
                {
                  p = 0;
                  qword_2CE55C8 = 0;
                  p = 11778;
                  *(&p + 2) = 0;
                  __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
                  __cxa_guard_release(&byte_2CE55D0);
                }
                boost::filesystem::path::operator/=(
                  (boost::filesystem::path *)&v13,
                  (const boost::filesystem::path *)&p);
              }
            }
          }
          else if ( v29 == v21 )
          {
            goto LABEL_57;
          }
        }
      }
      else if ( !((unsigned __int64)(unsigned __int8)v13 >> 1) )
      {
        goto LABEL_52;
      }
      if ( (v27[0] & 1) != 0 )
        operator delete(ptr);
      if ( (v15 & 1) != 0 )
        operator delete(v18);
    }
LABEL_47:
    boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)&v22);
  }
  if ( (v22 & 1) != 0 )
    operator delete(v25);
  if ( (v13 & 1) != 0 )
  {
    if ( !*((_QWORD *)&v13 + 1) )
      goto LABEL_75;
  }
  else if ( !((unsigned __int64)(unsigned __int8)v13 >> 1) )
  {
LABEL_75:
    if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
    {
      p = 0;
      qword_2CE55C8 = 0;
      p = 11778;
      *(&p + 2) = 0;
      __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
      __cxa_guard_release(&byte_2CE55D0);
    }
    boost::filesystem::path::operator/=((boost::filesystem::path *)&v13, (const boost::filesystem::path *)&p);
  }
  std::string::basic_string(this, &v13);
  if ( (v30[0] & 1) != 0 )
  {
    operator delete(v31);
    if ( (v19 & 1) != 0 )
      goto LABEL_84;
LABEL_79:
    if ( (v33[0] & 1) == 0 )
      goto LABEL_80;
LABEL_85:
    operator delete(v34);
    if ( (v13 & 1) != 0 )
LABEL_81:
      operator delete(v14);
  }
  else
  {
    if ( (v19 & 1) == 0 )
      goto LABEL_79;
LABEL_84:
    operator delete(v20);
    if ( (v33[0] & 1) != 0 )
      goto LABEL_85;
LABEL_80:
    if ( (v13 & 1) != 0 )
      goto LABEL_81;
  }
  return this;
}


// Address: 0x2841710 | Name: _ZN5boost10filesystem4path25m_path_iterator_incrementERNS1_8iteratorE
void __fastcall boost::filesystem::path::m_path_iterator_increment(boost::filesystem::path::iterator *it)
{
  _BYTE *v1; // r9
  unsigned __int64 v3; // rcx
  unsigned __int64 v4; // rdi
  unsigned __int64 v5; // rdx
  char *v6; // rsi
  unsigned __int8 v7; // r11
  char *v8; // rcx
  bool v9; // cl
  _BYTE *v10; // rcx
  char *v11; // rdi
  size_t v12; // r8
  unsigned __int64 v13; // rdi
  bool v14; // zf
  unsigned __int64 v15; // r10
  __int64 v16; // rbx
  __int64 v17; // rbx
  _BYTE *v18; // rbx
  __int64 v19; // rax
  char *v20; // rdi
  unsigned __int64 v21; // rbx
  __int64 v22; // rcx
  int v23; // edx
  void *v24; // rcx
  size_t v25; // r8
  const void *v26; // r9
  _BYTE v27[16]; // [rsp+8h] [rbp-30h] BYREF
  void *ptr; // [rsp+18h] [rbp-20h]

  v3 = *(unsigned __int8 *)it;
  if ( (v3 & 1) != 0 )
    v4 = *((_QWORD *)it + 1);
  else
    v4 = v3 >> 1;
  v5 = v4 + *((_QWORD *)it + 4);
  *((_QWORD *)it + 4) = v5;
  v6 = (char *)*((_QWORD *)it + 3);
  v7 = *v6;
  if ( (*v6 & 1) != 0 )
  {
    if ( v5 != *((_QWORD *)v6 + 1) )
    {
LABEL_6:
      if ( v4 < 3 )
        goto LABEL_19;
      if ( (v3 & 1) != 0 )
      {
        v8 = (char *)*((_QWORD *)it + 2);
        if ( *v8 != 47 )
          goto LABEL_19;
      }
      else
      {
        v8 = (char *)it + 1;
        if ( *((_BYTE *)it + 1) != 47 )
          goto LABEL_19;
      }
      if ( v8[1] == 47 )
      {
        v9 = v8[2] != 47;
        if ( (v7 & 1) != 0 )
          goto LABEL_11;
        goto LABEL_20;
      }
LABEL_19:
      v9 = 0;
      if ( (v7 & 1) != 0 )
      {
LABEL_11:
        if ( *(_BYTE *)(*((_QWORD *)v6 + 2) + v5) != 47 )
          goto LABEL_54;
        goto LABEL_12;
      }
LABEL_20:
      if ( v6[v5 + 1] != 47 )
        goto LABEL_54;
LABEL_12:
      if ( v9 )
      {
        std::string::operator=(it, 47);
        return;
      }
      v10 = v6 + 1;
      if ( (v7 & 1) == 0 )
        goto LABEL_26;
LABEL_23:
      if ( v5 != *((_QWORD *)v6 + 1) )
      {
        do
        {
          v11 = v6 + 1;
          if ( (v7 & 1) != 0 )
            v11 = (char *)*((_QWORD *)v6 + 2);
          if ( v11[v5] != 47 )
            break;
          *((_QWORD *)it + 4) = ++v5;
          v7 = *v6;
          if ( (*v6 & 1) != 0 )
            goto LABEL_23;
LABEL_26:
          ;
        }
        while ( v5 != v7 >> 1 );
      }
      if ( (v7 & 1) != 0 )
      {
        if ( *((_QWORD *)v6 + 1) != v5 )
          goto LABEL_54;
      }
      else if ( v7 >> 1 != v5 )
      {
        goto LABEL_54;
      }
      if ( (v7 & 1) != 0 )
        v10 = (_BYTE *)*((_QWORD *)v6 + 2);
      v12 = v5 - 1;
      v13 = v5;
      while ( v13 != 1 )
      {
        v14 = v10[v13-- - 2] == 47;
        if ( !v14 )
        {
          if ( v13 < 3 || *v10 != 47 || v10[1] != 47 )
            goto LABEL_70;
          if ( (v7 & 1) != 0 )
            v15 = *((_QWORD *)v6 + 1);
          else
            v15 = v7 >> 1;
          v16 = -1;
          if ( v15 >= 3 )
          {
            v1 = &v10[v15];
            v17 = 2;
            while ( v10[v17] != 47 )
            {
              if ( v15 == ++v17 )
              {
                v18 = &v10[v15];
                goto LABEL_51;
              }
            }
            v18 = &v10[v17];
LABEL_51:
            v19 = v18 - v10;
            v14 = v18 == v1;
            v16 = -1;
            if ( !v14 )
              v16 = v19;
          }
          if ( v16 != v13 )
          {
LABEL_70:
            *((_QWORD *)it + 4) = v12;
            if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
            {
              p = 0;
              qword_2CE55C8 = 0;
              p = 11778;
              *(&p + 2) = 0;
              __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
              __cxa_guard_release(&byte_2CE55D0);
            }
            std::string::operator=((soap *)it, (int)&p, v5, v10, v12, v1);
            return;
          }
          break;
        }
      }
LABEL_54:
      if ( (v7 & 1) != 0 )
      {
        v21 = *((_QWORD *)v6 + 1);
        v20 = (char *)*((_QWORD *)v6 + 2);
        if ( v21 <= v5 )
          goto LABEL_64;
      }
      else
      {
        v20 = v6 + 1;
        v21 = v7 >> 1;
        if ( v21 <= v5 )
        {
LABEL_64:
          if ( (v7 & 1) != 0 )
            v22 = *((_QWORD *)v6 + 1);
          else
            v22 = v7 >> 1;
LABEL_67:
          std::string::basic_string(v27, v6, v5, v22 - v5, v6);
          std::string::operator=((soap *)it, (int)v27, v23, v24, v25, v26);
          if ( (v27[0] & 1) != 0 )
            operator delete(ptr);
          return;
        }
      }
      v22 = v5;
      while ( v20[v22] != 47 )
      {
        if ( v21 == ++v22 )
          goto LABEL_64;
      }
      if ( v21 != v22 && v22 != -1 )
        goto LABEL_67;
      goto LABEL_64;
    }
  }
  else if ( v5 != (unsigned __int64)v7 >> 1 )
  {
    goto LABEL_6;
  }
  if ( (v3 & 1) != 0 )
  {
    **((_BYTE **)it + 2) = 0;
    *((_QWORD *)it + 1) = 0;
  }
  else
  {
    *(_WORD *)it = 0;
  }
}


// Address: 0x2841a40 | Name: _ZN5boost10filesystem4path25m_path_iterator_decrementERNS1_8iteratorE
void __fastcall boost::filesystem::path::m_path_iterator_decrement(boost::filesystem::path::iterator *it)
{
  size_t v1; // r8
  const void *v2; // r9
  _QWORD *v4; // r15
  `anonymous namespace'::size_type v5; // rbx
  unsigned __int64 v6; // r12
  `anonymous namespace'::size_type v7; // rsi
  _BYTE *v8; // rdx
  _BYTE *v9; // rcx
  bool v10; // zf
  unsigned __int64 v11; // rax
  __int64 v12; // rdi
  __int64 v13; // rdi
  _BYTE *v14; // rdi
  __int64 v15; // rax
  _BYTE *v16; // rsi
  `anonymous namespace'::size_type v17; // rax
  `anonymous namespace'::size_type v18; // rcx
  char *v19; // rdx
  unsigned __int64 v20; // rdx
  unsigned __int64 v21; // rax
  int v22; // edx
  void *v23; // rcx
  size_t v24; // r8
  const void *v25; // r9
  unsigned __int64 v26; // rax
  _BYTE v27[16]; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  v4 = (_QWORD *)*((_QWORD *)it + 3);
  v5 = *((_QWORD *)it + 4);
  v6 = *(unsigned __int8 *)v4;
  if ( (v6 & 1) != 0 )
  {
    if ( v5 != v4[1] )
      goto LABEL_34;
  }
  else if ( v5 != v6 >> 1 )
  {
    goto LABEL_34;
  }
  if ( (v6 & 1) != 0 )
  {
    if ( v4[1] < 2u )
      goto LABEL_34;
  }
  else if ( v6 >> 1 < 2 )
  {
    goto LABEL_34;
  }
  v7 = v5 - 1;
  if ( (v6 & 1) != 0 )
  {
    if ( *(_BYTE *)(v4[2] + v7) != 47 )
      goto LABEL_34;
  }
  else if ( *((_BYTE *)v4 + v5) != 47 )
  {
    goto LABEL_34;
  }
  if ( (v6 & 1) != 0 )
    v8 = (_BYTE *)v4[2];
  else
    v8 = (char *)v4 + 1;
  v9 = (_BYTE *)*((_QWORD *)it + 4);
  while ( v9 != (_BYTE *)&dword_0 + 1 )
  {
    v10 = (v9--)[(_QWORD)v8 - 2] == 47;
    if ( !v10 )
    {
      if ( (unsigned __int64)v9 < 3 || *v8 != 47 || v8[1] != 47 )
        goto LABEL_70;
      if ( (v6 & 1) != 0 )
        v11 = v4[1];
      else
        v11 = (unsigned __int8)v6 >> 1;
      v12 = -1;
      if ( v11 >= 3 )
      {
        v1 = (size_t)&v8[v11];
        v13 = 2;
        while ( v8[v13] != 47 )
        {
          if ( v11 == ++v13 )
          {
            v14 = &v8[v11];
            goto LABEL_31;
          }
        }
        v14 = &v8[v13];
LABEL_31:
        v15 = v14 - v8;
        v10 = v14 == (_BYTE *)v1;
        v12 = -1;
        if ( !v10 )
          v12 = v15;
      }
      if ( (_BYTE *)v12 != v9 )
      {
LABEL_70:
        *((_QWORD *)it + 4) = v7;
        if ( !(_BYTE)byte_2CE55D0 && __cxa_guard_acquire(&byte_2CE55D0) )
        {
          p = 0;
          qword_2CE55C8 = 0;
          p = 11778;
          *(&p + 2) = 0;
          __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &p, &dso_handle);
          __cxa_guard_release(&byte_2CE55D0);
        }
        std::string::operator=((soap *)it, (int)&p, (int)v8, v9, v1, v2);
        return;
      }
      break;
    }
  }
LABEL_34:
  v16 = (char *)v4 + 1;
  v17 = `anonymous namespace'::root_directory_start(v4, v5) + 1;
  while ( 1 )
  {
    v18 = v5;
    if ( !v5 )
      break;
    if ( v17 != v5 )
    {
      v19 = (char *)v4 + 1;
      if ( (v6 & 1) != 0 )
        v19 = (char *)v4[2];
      --v5;
      if ( v19[v18 - 1] == 47 )
        continue;
    }
    if ( (v6 & 1) != 0 )
      v16 = (_BYTE *)v4[2];
    if ( v18 == 2 && *v16 == 47 && v16[1] == 47 )
    {
LABEL_60:
      v20 = 0;
      goto LABEL_62;
    }
    v20 = v18 - 1;
    if ( v16[v18 - 1] == 47 )
      goto LABEL_62;
    if ( (v6 & 1) != 0 )
      goto LABEL_47;
    goto LABEL_51;
  }
  if ( (v6 & 1) != 0 )
    v16 = (_BYTE *)v4[2];
  v20 = -1;
  if ( (v6 & 1) != 0 )
  {
LABEL_47:
    v21 = v4[1];
    goto LABEL_52;
  }
LABEL_51:
  v21 = (unsigned __int8)v6 >> 1;
LABEL_52:
  if ( v21 > v20 )
    v21 = v18;
  v20 = 0;
  while ( v21 )
  {
    v10 = v16[--v21] == 47;
    if ( v10 )
    {
      if ( v21 != -1 && (v21 != 1 || *v16 != 47) )
      {
        v20 = v21 + 1;
        break;
      }
      goto LABEL_60;
    }
  }
LABEL_62:
  *((_QWORD *)it + 4) = v20;
  std::string::basic_string(v27, v4, v20, v18 - v20, v4);
  std::string::operator=((soap *)it, (int)v27, v22, v23, v24, v25);
  if ( (v27[0] & 1) != 0 )
    operator delete(ptr);
  v26 = *(unsigned __int8 *)it;
  if ( (v26 & 1) != 0 )
  {
    if ( *((_QWORD *)it + 1) != 1 )
      return;
  }
  else if ( v26 >> 1 != 1 )
  {
    return;
  }
  if ( !(unsigned int)std::string::compare(it, 0, -1, "/", 1) )
    std::string::assign(it, "/");
}


// Address: 0x2841d70 | Name: _ZN5boost10filesystem4path7codecvtEv
const boost::filesystem::path::codecvt_type *__cdecl boost::filesystem::path::codecvt()
{
  if ( !(_BYTE)byte_2CE5600 && __cxa_guard_acquire(&byte_2CE5600) )
  {
    std::locale::locale(&stru_2CE55F8, (const char *)&uri_string);
    __cxa_atexit((void (*)(void *))&std::locale::~locale, &stru_2CE55F8, &dso_handle);
    __cxa_guard_release(&byte_2CE5600);
  }
  return (const boost::filesystem::path::codecvt_type *)std::locale::use_facet(
                                                          &stru_2CE55F8,
                                                          &std::codecvt<wchar_t,char,__mbstate_t>::id);
}


// Address: 0x2841e00 | Name: _ZN5boost10filesystem4path5imbueERKNSt3__16localeE
std::locale __fastcall boost::filesystem::path::imbue(std::locale *a1, const std::locale *loc)
{
  if ( !(_BYTE)byte_2CE5600 && __cxa_guard_acquire(&byte_2CE5600) )
  {
    std::locale::locale(&stru_2CE55F8, (const char *)&uri_string);
    __cxa_atexit((void (*)(void *))&std::locale::~locale, &stru_2CE55F8, &dso_handle);
    __cxa_guard_release(&byte_2CE5600);
  }
  std::locale::locale(a1, &stru_2CE55F8);
  if ( !(_BYTE)byte_2CE5600 && __cxa_guard_acquire(&byte_2CE5600) )
  {
    std::locale::locale(&stru_2CE55F8, (const char *)&uri_string);
    __cxa_atexit((void (*)(void *))&std::locale::~locale, &stru_2CE55F8, &dso_handle);
    __cxa_guard_release(&byte_2CE5600);
  }
  std::locale::operator=(&stru_2CE55F8, loc);
  return (std::locale)a1;
}


