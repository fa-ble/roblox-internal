// Address: 0x2602d90 | Name: _ZN5boost4asio6detail13epoll_reactor12cancel_timerINS0_11time_traitsINS_10posix_time5ptimeEEEEEmRNS1_11timer_queueIT_EERNSA_14per_timer_dataEm
size_t __fastcall boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
        boost::asio::detail::epoll_reactor *this,
        boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *queue,
        boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *timer,
        size_t max_cancelled)
{
  boost::asio::detail::epoll_reactor *v6; // rbp
  boost::asio::detail::mutex *p_mutex; // r15
  boost::asio::detail::wait_op *front; // r14
  _QWORD *p_next; // r15
  size_t v10; // r12
  const boost::system::error_category *v11; // rax
  boost::asio::detail::wait_op **v12; // rcx
  boost::asio::detail::wait_op *v13; // rax
  boost::asio::detail::task_io_service_operation **p_back; // rcx
  boost::asio::detail::task_io_service_operation *i; // rbx
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // rbp
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> v18; // [rsp+0h] [rbp-68h] BYREF
  boost::asio::detail::epoll_reactor *v19; // [rsp+18h] [rbp-50h]
  int v20; // [rsp+20h] [rbp-48h] BYREF
  const boost::system::error_category *v21; // [rsp+28h] [rbp-40h]
  boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *v22; // [rsp+30h] [rbp-38h]

  v6 = this;
  p_mutex = &this->mutex_;
  pthread_mutex_lock(&this->mutex_.mutex_);
  v18 = 0;
  if ( !timer->prev_
    && *((boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data **)queue
       + 4) != timer )
  {
    max_cancelled = 0;
    goto LABEL_21;
  }
  v22 = queue;
  v19 = this;
  if ( max_cancelled )
  {
    front = timer->op_queue_.front_;
    p_next = 0;
    v10 = 0;
    while ( front )
    {
      v11 = boost::system::system_category();
      front->ec_.m_val = 125;
      front->ec_.m_cat = v11;
      v12 = (boost::asio::detail::wait_op **)timer->op_queue_.front_;
      if ( timer->op_queue_.front_ )
      {
        v13 = *v12;
        timer->op_queue_.front_ = *v12;
        if ( !v13 )
          timer->op_queue_.back_ = 0;
        *v12 = 0;
      }
      else
      {
        v13 = 0;
      }
      front->next_ = 0;
      if ( p_next )
      {
        *p_next = front;
        p_back = &v18.back_;
      }
      else
      {
        v18.back_ = front;
        p_back = (boost::asio::detail::task_io_service_operation **)&v18;
      }
      *p_back = front;
      ++v10;
      p_next = &front->next_;
      front = v13;
      if ( max_cancelled == v10 )
        goto LABEL_19;
    }
    max_cancelled = v10;
    p_mutex = &this->mutex_;
    v6 = v19;
LABEL_20:
    boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::remove_timer(
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)v22 + 16),
      timer);
    goto LABEL_21;
  }
  v13 = timer->op_queue_.front_;
LABEL_19:
  p_mutex = &this->mutex_;
  v6 = v19;
  if ( !v13 )
    goto LABEL_20;
LABEL_21:
  pthread_mutex_unlock(&p_mutex->mutex_);
  boost::asio::detail::task_io_service::post_deferred_completions(v6->io_service_, &v18);
  for ( i = v18.front_; v18.front_; i = v18.front_ )
  {
    v18.front_ = i->next_;
    if ( !v18.front_ )
      v18 = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation>)0LL;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v20 = 0;
    v21 = boost::system::system_category();
    func(0, i, &v20, 0);
  }
  return max_cancelled;
}


// Address: 0x2606710 | Name: _ZN5boost4asio6detail13epoll_reactor14schedule_timerINS0_11time_traitsINS_10posix_time5ptimeEEEEEvRNS1_11timer_queueIT_EERKNS9_9time_typeERNSA_14per_timer_dataEPNS1_7wait_opE
void __fastcall boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
        boost::asio::detail::epoll_reactor *this,
        boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *queue,
        const boost::asio::time_traits<boost::posix_time::ptime>::time_type *time,
        boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *timer,
        boost::asio::detail::wait_op *op)
{
  bool v8; // al
  boost::asio::detail::timer_queue_base *first; // rbx
  __int64 v10; // rcx
  int v11; // esi
  __syscall_slong_t v12; // rax
  struct itimerspec v13; // [rsp+0h] [rbp-78h] BYREF
  struct itimerspec otmr; // [rsp+28h] [rbp-50h] BYREF

  pthread_mutex_lock(&this->mutex_.mutex_);
  if ( !this->shutdown_ )
  {
    v8 = boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::enqueue_timer(
           (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)queue + 16),
           time,
           timer,
           op);
    _InterlockedAdd64(&this->io_service_->outstanding_work_.__a_, 1u);
    if ( !v8 )
      goto LABEL_14;
    if ( this->timer_fd_ == -1 )
    {
      LODWORD(v13.it_interval.tv_sec) = -2147483639;
      *(__time_t *)((char *)&v13.it_interval.tv_sec + 4) = (__time_t)&this->interrupter_;
      epoll_ctl(this->epoll_fd_, 3, this->interrupter_.read_descriptor_, (struct epoll_event *)&v13);
      goto LABEL_14;
    }
    v13.it_interval = 0;
    first = this->timer_queues_.first_;
    if ( first )
    {
      v10 = 300000000;
      do
      {
        v10 = (*((__int64 (__fastcall **)(boost::asio::detail::timer_queue_base *, __int64))first->_vptr$timer_queue_base
               + 4))(
                first,
                v10);
        first = first->next_;
      }
      while ( first );
      v13.it_value.tv_sec = v10 / 1000000;
      if ( !v10 )
      {
        v11 = 1;
        v12 = 1;
LABEL_13:
        v13.it_value.tv_nsec = v12;
        timerfd_settime(this->timer_fd_, v11, &v13, &otmr);
        goto LABEL_14;
      }
    }
    else
    {
      v13.it_value.tv_sec = 300;
      v10 = 300000000;
    }
    v12 = 1000 * (v10 % 1000000);
    v11 = 0;
    goto LABEL_13;
  }
  boost::asio::detail::task_io_service::post_immediate_completion(this->io_service_, op, 0);
LABEL_14:
  pthread_mutex_unlock(&this->mutex_.mutex_);
}


// Address: 0x26978f0 | Name: _ZN5boost4asio6detail13epoll_reactor12cancel_timerINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS7_EEEEEEmRNS1_11timer_queueIT_EERNSD_14per_timer_dataEm
size_t __fastcall boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>(
        boost::asio::detail::epoll_reactor *this,
        boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *queue,
        boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::per_timer_data *timer,
        size_t max_cancelled)
{
  boost::asio::detail::mutex *p_mutex; // rbp
  boost::asio::detail::wait_op *front; // r14
  _QWORD *p_next; // rbp
  size_t v9; // r12
  const boost::system::error_category *v10; // rax
  boost::asio::detail::wait_op **v11; // rcx
  boost::asio::detail::wait_op *v12; // rax
  boost::asio::detail::task_io_service_operation **p_back; // rcx
  boost::asio::detail::task_io_service_operation *i; // rbx
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // rbp
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> v17; // [rsp+0h] [rbp-68h] BYREF
  boost::asio::detail::mutex *v18; // [rsp+18h] [rbp-50h]
  int v19; // [rsp+20h] [rbp-48h] BYREF
  const boost::system::error_category *v20; // [rsp+28h] [rbp-40h]
  boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *v21; // [rsp+30h] [rbp-38h]

  p_mutex = &this->mutex_;
  pthread_mutex_lock(&this->mutex_.mutex_);
  v17 = 0;
  if ( !timer->prev_
    && *((boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::per_timer_data **)queue
       + 2) != timer )
  {
    max_cancelled = 0;
    goto LABEL_21;
  }
  v21 = queue;
  v18 = &this->mutex_;
  if ( max_cancelled )
  {
    front = timer->op_queue_.front_;
    p_next = 0;
    v9 = 0;
    while ( front )
    {
      v10 = boost::system::system_category();
      front->ec_.m_val = 125;
      front->ec_.m_cat = v10;
      v11 = (boost::asio::detail::wait_op **)timer->op_queue_.front_;
      if ( timer->op_queue_.front_ )
      {
        v12 = *v11;
        timer->op_queue_.front_ = *v11;
        if ( !v12 )
          timer->op_queue_.back_ = 0;
        *v11 = 0;
      }
      else
      {
        v12 = 0;
      }
      front->next_ = 0;
      if ( p_next )
      {
        *p_next = front;
        p_back = &v17.back_;
      }
      else
      {
        v17.back_ = front;
        p_back = (boost::asio::detail::task_io_service_operation **)&v17;
      }
      *p_back = front;
      ++v9;
      p_next = &front->next_;
      front = v12;
      if ( max_cancelled == v9 )
        goto LABEL_19;
    }
    max_cancelled = v9;
    p_mutex = v18;
LABEL_20:
    boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::remove_timer(
      v21,
      timer);
    goto LABEL_21;
  }
  v12 = timer->op_queue_.front_;
LABEL_19:
  p_mutex = v18;
  if ( !v12 )
    goto LABEL_20;
LABEL_21:
  pthread_mutex_unlock(&p_mutex->mutex_);
  boost::asio::detail::task_io_service::post_deferred_completions(this->io_service_, &v17);
  for ( i = v17.front_; v17.front_; i = v17.front_ )
  {
    v17.front_ = i->next_;
    if ( !v17.front_ )
      v17 = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation>)0LL;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v19 = 0;
    v20 = boost::system::system_category();
    func(0, i, &v19, 0);
  }
  return max_cancelled;
}


// Address: 0x269f350 | Name: _ZN5boost4asio6detail13epoll_reactor14schedule_timerINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS7_EEEEEEvRNS1_11timer_queueIT_EERKNSC_9time_typeERNSD_14per_timer_dataEPNS1_7wait_opE
void __fastcall boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>(
        boost::asio::detail::epoll_reactor *this,
        boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *queue,
        const boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> >::time_type *time,
        boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::per_timer_data *timer,
        boost::asio::detail::wait_op *op)
{
  bool v8; // al
  boost::asio::detail::timer_queue_base *first; // rbx
  __int64 v10; // rcx
  int v11; // esi
  __syscall_slong_t v12; // rax
  struct itimerspec v13; // [rsp+0h] [rbp-78h] BYREF
  struct itimerspec otmr; // [rsp+28h] [rbp-50h] BYREF

  pthread_mutex_lock(&this->mutex_.mutex_);
  if ( !this->shutdown_ )
  {
    v8 = boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::enqueue_timer(
           queue,
           time,
           timer,
           op);
    _InterlockedAdd64(&this->io_service_->outstanding_work_.__a_, 1u);
    if ( !v8 )
      goto LABEL_14;
    if ( this->timer_fd_ == -1 )
    {
      LODWORD(v13.it_interval.tv_sec) = -2147483639;
      *(__time_t *)((char *)&v13.it_interval.tv_sec + 4) = (__time_t)&this->interrupter_;
      epoll_ctl(this->epoll_fd_, 3, this->interrupter_.read_descriptor_, (struct epoll_event *)&v13);
      goto LABEL_14;
    }
    v13.it_interval = 0;
    first = this->timer_queues_.first_;
    if ( first )
    {
      v10 = 300000000;
      do
      {
        v10 = (*((__int64 (__fastcall **)(boost::asio::detail::timer_queue_base *, __int64))first->_vptr$timer_queue_base
               + 4))(
                first,
                v10);
        first = first->next_;
      }
      while ( first );
      v13.it_value.tv_sec = v10 / 1000000;
      if ( !v10 )
      {
        v11 = 1;
        v12 = 1;
LABEL_13:
        v13.it_value.tv_nsec = v12;
        timerfd_settime(this->timer_fd_, v11, &v13, &otmr);
        goto LABEL_14;
      }
    }
    else
    {
      v13.it_value.tv_sec = 300;
      v10 = 300000000;
    }
    v12 = 1000 * (v10 % 1000000);
    v11 = 0;
    goto LABEL_13;
  }
  boost::asio::detail::task_io_service::post_immediate_completion(this->io_service_, op, 0);
LABEL_14:
  pthread_mutex_unlock(&this->mutex_.mutex_);
}


