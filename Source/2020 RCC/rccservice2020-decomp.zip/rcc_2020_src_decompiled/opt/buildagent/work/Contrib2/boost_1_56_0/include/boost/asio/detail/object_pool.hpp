// Address: 0x25f8070 | Name: _ZN5boost4asio6detail11object_poolINS1_13epoll_reactor16descriptor_stateEED2Ev
void __fastcall boost::asio::detail::object_pool<boost::asio::detail::epoll_reactor::descriptor_state>::~object_pool(
        boost::asio::detail::object_pool<boost::asio::detail::epoll_reactor::descriptor_state> *this)
{
  boost::asio::detail::epoll_reactor::descriptor_state *live_list; // rbx
  boost::asio::detail::epoll_reactor::descriptor_state *next; // r15
  boost::asio::detail::epoll_reactor::descriptor_state *free_list; // rbx
  boost::asio::detail::epoll_reactor::descriptor_state *v4; // r14

  live_list = this->live_list_;
  if ( this->live_list_ )
  {
    do
    {
      next = live_list->next_;
      boost::asio::detail::epoll_reactor::descriptor_state::~descriptor_state(live_list);
      operator delete(live_list);
      live_list = next;
    }
    while ( next );
  }
  free_list = this->free_list_;
  if ( free_list )
  {
    do
    {
      v4 = free_list->next_;
      boost::asio::detail::epoll_reactor::descriptor_state::~descriptor_state(free_list);
      operator delete(free_list);
      free_list = v4;
    }
    while ( v4 );
  }
}


