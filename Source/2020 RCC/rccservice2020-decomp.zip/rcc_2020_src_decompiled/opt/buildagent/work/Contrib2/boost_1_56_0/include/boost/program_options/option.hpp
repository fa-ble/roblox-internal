// Address: 0xe44d80 | Name: _ZN5boost15program_options12basic_optionIcEC2ERKS2_
void __fastcall boost::program_options::basic_option<char>::basic_option(
        boost::program_options::basic_option<char> *this,
        const boost::program_options::basic_option<char> *a2)
{
  std::string::basic_string(this, a2);
  *((_DWORD *)this + 6) = *((_DWORD *)a2 + 6);
  std::vector<std::string>::vector(
    (boost::program_options::basic_option<char> *)((char *)this + 32),
    (const boost::program_options::basic_option<char> *)((char *)a2 + 32));
  std::vector<std::string>::vector(
    (boost::program_options::basic_option<char> *)((char *)this + 56),
    (const boost::program_options::basic_option<char> *)((char *)a2 + 56));
  *((_WORD *)this + 40) = *((_WORD *)a2 + 40);
}


