// Address: 0xfe9820 | Name: _ZN5boost9date_time6c_time6gmtimeEPKlP2tm
tm *__fastcall boost::date_time::c_time::gmtime(const time_t *t, tm *result)
{
  tm *v2; // rax
  _BYTE v3[24]; // [rsp+0h] [rbp-18h] BYREF

  v2 = gmtime_r(t, result);
  if ( !v2 )
  {
    std::runtime_error::runtime_error((std::runtime_error *)v3, "could not convert calendar time to UTC time");
    boost::throw_exception<std::runtime_error>((const std::runtime_error *)v3);
  }
  return v2;
}


// Address: 0x15dd5c0 | Name: _ZN5boost9date_time6c_time9localtimeEPKlP2tm
tm *__fastcall boost::date_time::c_time::localtime(const time_t *t, tm *result)
{
  tm *v2; // rax
  _BYTE v3[24]; // [rsp+0h] [rbp-18h] BYREF

  v2 = localtime_r(t, result);
  if ( !v2 )
  {
    std::runtime_error::runtime_error((std::runtime_error *)v3, "could not convert calendar time to local time");
    boost::throw_exception<std::runtime_error>((const std::runtime_error *)v3);
  }
  return v2;
}


