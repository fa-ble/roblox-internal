// Address: 0x25f8ad0 | Name: _ZN5boost4asio6detail8op_queueINS1_25task_io_service_operationEED2Ev
void __fastcall boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation>::~op_queue(
        boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *this)
{
  boost::asio::detail::task_io_service_operation *i; // rbx
  boost::asio::detail::task_io_service_operation *next; // rax
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  int v4; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v5; // [rsp+10h] [rbp-28h]

  for ( i = this->front_; this->front_; i = this->front_ )
  {
    next = i->next_;
    this->front_ = i->next_;
    if ( !next )
      this->back_ = 0;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v4 = 0;
    v5 = boost::system::system_category();
    func(0, i, &v4, 0);
  }
}


