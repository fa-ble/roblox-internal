// Address: 0x1735ad0 | Name: _ZN5boost9algorithm7iequalsINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEA5_cEEbRKT_RKT0_RKNS2_6localeE
bool __fastcall boost::algorithm::iequals<std::string,char [5]>(
        const std::string *Input,
        const char (*Test)[5],
        const std::locale *Loc)
{
  unsigned __int64 v3; // rbx
  unsigned __int64 v4; // rbx
  char *v5; // r15
  size_t v6; // rbp
  bool v7; // al
  char *v8; // rcx
  size_t v9; // rbp
  __int64 v10; // r14
  char v11; // bl
  __int64 v12; // rax
  char v13; // bl
  char v14; // r12
  __int64 v15; // rax
  __int64 v16; // rcx
  bool v18; // bl
  std::locale v20; // [rsp+8h] [rbp-50h] BYREF
  char *s; // [rsp+10h] [rbp-48h]
  unsigned __int64 v22; // [rsp+18h] [rbp-40h]
  unsigned __int64 v23; // [rsp+20h] [rbp-38h]

  s = (char *)Test;
  std::locale::locale(&v20, Loc);
  v3 = *(unsigned __int8 *)Input;
  if ( (v3 & 1) != 0 )
  {
    v4 = *((_QWORD *)Input + 1);
    v5 = (char *)*((_QWORD *)Input + 2);
  }
  else
  {
    v5 = (char *)Input + 1;
    v4 = v3 >> 1;
  }
  v6 = strlen(s);
  v7 = v6 == 0;
  v8 = v5;
  if ( v4 && v6 )
  {
    v9 = v6 - 1;
    v22 = v4;
    v23 = v4 - 1;
    v10 = 0;
    while ( 1 )
    {
      v11 = v5[v10];
      v12 = std::locale::use_facet(&v20, &std::ctype<char>::id);
      v13 = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v12 + 24LL))(v12, (unsigned int)v11);
      v14 = s[v10];
      v15 = std::locale::use_facet(&v20, &std::ctype<char>::id);
      if ( v13 != (*(unsigned __int8 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v15 + 24LL))(v15, (unsigned int)v14) )
        break;
      v16 = v10 + 1;
      v7 = v9 == v10;
      if ( v9 != v10 && v23 != v10++ )
        continue;
      v8 = &v5[v16];
      v4 = v22;
      goto LABEL_11;
    }
    v18 = 0;
  }
  else
  {
LABEL_11:
    v18 = v7 && v8 == &v5[v4];
  }
  std::locale::~locale(&v20);
  return v18;
}


// Address: 0x19646e0 | Name: _ZN5boost9algorithm7iequalsIA10_cNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEEbRKT_RKT0_RKNS3_6localeE
bool __fastcall boost::algorithm::iequals<char [10],std::string>(
        const char (*Input)[10],
        const std::string *Test,
        const std::locale *Loc)
{
  size_t v3; // rax
  size_t v4; // rbp
  unsigned __int64 v5; // rdx
  unsigned __int64 v6; // rdx
  char *v7; // r15
  bool v8; // al
  char *v9; // rcx
  size_t v10; // rbp
  __int64 v11; // r14
  char v12; // bl
  __int64 v13; // rax
  char v14; // bl
  char v15; // r12
  __int64 v16; // rax
  __int64 v17; // rcx
  bool v19; // bl
  std::locale v21; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v22; // [rsp+10h] [rbp-48h]
  unsigned __int64 v23; // [rsp+18h] [rbp-40h]
  const char *v24; // [rsp+20h] [rbp-38h]

  std::locale::locale(&v21, Loc);
  v24 = (const char *)Input;
  v3 = strlen((const char *)Input);
  v4 = v3;
  v5 = *(unsigned __int8 *)Test;
  if ( (v5 & 1) != 0 )
  {
    v6 = *((_QWORD *)Test + 1);
    v7 = (char *)*((_QWORD *)Test + 2);
  }
  else
  {
    v7 = (char *)Test + 1;
    v6 = v5 >> 1;
  }
  v8 = v3 == 0;
  v9 = v7;
  if ( v6 && v4 )
  {
    v10 = v4 - 1;
    v22 = v6;
    v23 = v6 - 1;
    v11 = 0;
    while ( 1 )
    {
      v12 = v24[v11];
      v13 = std::locale::use_facet(&v21, &std::ctype<char>::id);
      v14 = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v13 + 24LL))(v13, (unsigned int)v12);
      v15 = v7[v11];
      v16 = std::locale::use_facet(&v21, &std::ctype<char>::id);
      if ( v14 != (*(unsigned __int8 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v16 + 24LL))(v16, (unsigned int)v15) )
        break;
      v8 = v10 == v11;
      v17 = v11 + 1;
      if ( v23 != v11 && v10 != v11++ )
        continue;
      v9 = &v7[v17];
      v6 = v22;
      goto LABEL_11;
    }
    v19 = 0;
  }
  else
  {
LABEL_11:
    v19 = v8 && v9 == &v7[v6];
  }
  std::locale::~locale(&v21);
  return v19;
}


// Address: 0x27cf7f0 | Name: _ZN5boost9algorithm7iequalsINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEPKcEEbRKT_RKT0_RKNS2_6localeE
bool __fastcall boost::algorithm::iequals<std::string,char const*>(
        const std::string *Input,
        const char *const *Test,
        const std::locale *Loc)
{
  unsigned __int64 v3; // rbx
  unsigned __int64 v4; // rbx
  char *v5; // r15
  size_t v6; // rbp
  bool v7; // al
  char *v8; // rcx
  size_t v9; // rbp
  __int64 v10; // r14
  char v11; // bl
  __int64 v12; // rax
  char v13; // bl
  char v14; // r12
  __int64 v15; // rax
  __int64 v16; // rcx
  bool v18; // bl
  std::locale v20; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v21; // [rsp+10h] [rbp-48h]
  unsigned __int64 v22; // [rsp+18h] [rbp-40h]
  const char *v23; // [rsp+20h] [rbp-38h]

  std::locale::locale(&v20, Loc);
  v3 = *(unsigned __int8 *)Input;
  if ( (v3 & 1) != 0 )
  {
    v4 = *((_QWORD *)Input + 1);
    v5 = (char *)*((_QWORD *)Input + 2);
  }
  else
  {
    v5 = (char *)Input + 1;
    v4 = v3 >> 1;
  }
  v23 = *Test;
  v6 = strlen(v23);
  v7 = v6 == 0;
  v8 = v5;
  if ( v4 && v6 )
  {
    v9 = v6 - 1;
    v21 = v4;
    v22 = v4 - 1;
    v10 = 0;
    while ( 1 )
    {
      v11 = v5[v10];
      v12 = std::locale::use_facet(&v20, &std::ctype<char>::id);
      v13 = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v12 + 24LL))(v12, (unsigned int)v11);
      v14 = v23[v10];
      v15 = std::locale::use_facet(&v20, &std::ctype<char>::id);
      if ( v13 != (*(unsigned __int8 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v15 + 24LL))(v15, (unsigned int)v14) )
        break;
      v16 = v10 + 1;
      v7 = v9 == v10;
      if ( v9 != v10 && v22 != v10++ )
        continue;
      v8 = &v5[v16];
      v4 = v21;
      goto LABEL_11;
    }
    v18 = 0;
  }
  else
  {
LABEL_11:
    v18 = v7 && v8 == &v5[v4];
  }
  std::locale::~locale(&v20);
  return v18;
}


