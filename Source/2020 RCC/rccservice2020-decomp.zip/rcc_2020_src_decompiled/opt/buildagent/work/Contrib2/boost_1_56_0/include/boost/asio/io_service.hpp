// Address: 0x2546d00 | Name: __cxx_global_var_init.42_0
void __cdecl _cxx_global_var_init_42_0()
{
  if ( !(_BYTE)qword_2B11490 )
    qword_2B11490 = 1;
}


// Address: 0x2546d20 | Name: __cxx_global_var_init.43_0
void __cdecl _cxx_global_var_init_43_0()
{
  if ( !(_BYTE)qword_2B114A0 )
    qword_2B114A0 = 1;
}


// Address: 0x2546db0 | Name: __cxx_global_var_init.45_0
void __cdecl _cxx_global_var_init_45_0()
{
  if ( !(_BYTE)qword_2B114C8 )
    qword_2B114C8 = 1;
}


// Address: 0x25b05a0 | Name: __cxx_global_var_init.31_0
void __cdecl _cxx_global_var_init_31_0()
{
  if ( !(_BYTE)qword_2B11708 )
    qword_2B11708 = 1;
}


// Address: 0x25ed1c0 | Name: __cxx_global_var_init.32_0
void __cdecl _cxx_global_var_init_32_0()
{
  if ( !(_BYTE)qword_2B12870 )
    qword_2B12870 = 1;
}


// Address: 0x25ed1e0 | Name: __cxx_global_var_init.33_0
void __cdecl _cxx_global_var_init_33_0()
{
  if ( !(_BYTE)qword_2B12880 )
    qword_2B12880 = 1;
}


// Address: 0x25ed200 | Name: __cxx_global_var_init.34_1
void __cdecl _cxx_global_var_init_34_1()
{
  if ( !(_BYTE)qword_2B12890 )
    qword_2B12890 = 1;
}


// Address: 0x2694990 | Name: __cxx_global_var_init.31_1
void __cdecl _cxx_global_var_init_31_1()
{
  if ( !(_BYTE)qword_2B12950 )
    qword_2B12950 = 1;
}


