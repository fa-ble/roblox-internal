// Address: 0x2698010 | Name: _ZN5boost4asio12placeholders5errorEv
boost::arg<1> __cdecl boost::asio::placeholders::error()
{
  boost::arg<1> result; // al

  return result;
}


// Address: 0x269f180 | Name: _ZN5boost4asio12placeholders8iteratorEv
boost::arg<2> __cdecl boost::asio::placeholders::iterator()
{
  boost::arg<2> result; // al

  return result;
}


