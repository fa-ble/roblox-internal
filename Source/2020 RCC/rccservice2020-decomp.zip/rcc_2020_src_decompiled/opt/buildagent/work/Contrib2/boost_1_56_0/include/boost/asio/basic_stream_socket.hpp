// Address: 0x26126d0 | Name: _ZN5boost4asio19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS3_EEE15async_read_someINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS6_NSA_8write_opINS0_6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorISF_NSG_9allocatorISF_EEEEEEEENSD_8write_opINS9_6streamIS6_EESK_NSD_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSG_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSX_mEE4typeEE4typeERKT_OS17_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > >::type __fastcall boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *this,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *handler)
{
  boost::asio::stream_socket_service<boost::asio::ip::tcp> *service; // rbx
  _BYTE v4[16]; // [rsp+0h] [rbp-148h] BYREF
  void *v5; // [rsp+10h] [rbp-138h]
  void *v6; // [rsp+18h] [rbp-130h]
  void *ptr; // [rsp+78h] [rbp-D0h]
  void *v8; // [rsp+80h] [rbp-C8h]
  char v9; // [rsp+E0h] [rbp-68h] BYREF
  char *v10; // [rsp+100h] [rbp-48h]
  unsigned __int64 v11; // [rsp+120h] [rbp-28h]

  v11 = __readfsqword(0x28u);
  service = this->service_;
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v4,
    handler);
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
    &service->service_impl_,
    &this->implementation,
    buffers,
    0,
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v4);
  if ( &v9 == v10 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v10 + 32LL))(v10);
  }
  else if ( v10 )
  {
    (*(void (**)(void))(*(_QWORD *)v10 + 40LL))();
  }
  if ( ptr )
  {
    v8 = ptr;
    operator delete(ptr);
  }
  if ( v5 )
  {
    v6 = v5;
    operator delete(v5);
  }
}


// Address: 0x26160c0 | Name: _ZN5boost4asio19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS3_EEE15async_read_someINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS6_NSA_7read_opIS8_EENS0_6detail7read_opINS9_6streamIS6_EES8_NSE_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSQ_mEE4typeEE4typeERKT_OS10_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > >::type __fastcall boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *this,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *handler)
{
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::stream_socket_service<boost::asio::ip::tcp> *service; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *f; // rdi
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > v9; // [rsp+0h] [rbp-E8h] BYREF
  unsigned __int64 v10; // [rsp+C0h] [rbp-28h]

  v10 = __readfsqword(0x28u);
  service = this->service_;
  *(_OWORD *)&v9.next_layer_ = *(_OWORD *)&handler->next_layer_;
  v9.op_ = handler->op_;
  v9.start_ = handler->start_;
  v9.want_ = handler->want_;
  v9.ec_ = handler->ec_;
  *(_OWORD *)&v9.bytes_transferred_ = *(_OWORD *)&handler->bytes_transferred_;
  v9.handler_.stream_ = handler->handler_.stream_;
  v9.handler_.buffer_ = handler->handler_.buffer_;
  v9.handler_.start_ = handler->handler_.start_;
  *(_OWORD *)&v9.handler_.total_transferred_ = *(_OWORD *)&handler->handler_.total_transferred_;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)handler->handler_.handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      v9.handler_.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&v9.handler_.handler_.handler_;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *, std::function<void (const boost::system::error_code &,unsigned long)> *, boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *, __int64, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *, void *, size_t, int, size_t, websocketpp::transport::asio::handler_allocator *))f->next_layer_->service_)(
        f,
        &v9.handler_.handler_.handler_,
        handler,
        v3,
        v4,
        v5,
        v9.next_layer_,
        v9.core_,
        v9.op_.buffers_.data_,
        v9.op_.buffers_.size_,
        *(_QWORD *)&v9.start_,
        *(_QWORD *)&v9.ec_.m_val,
        v9.ec_.m_cat,
        v9.bytes_transferred_,
        v9.handler_.completion_condition_.minimum_,
        v9.handler_.stream_,
        v9.handler_.buffer_.data_,
        v9.handler_.buffer_.size_,
        v9.handler_.start_,
        v9.handler_.total_transferred_,
        v9.handler_.handler_.allocator_);
    }
    else
    {
      v9.handler_.handler_.handler_.__f_ = handler->handler_.handler_.handler_.__f_;
      handler->handler_.handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    v9.handler_.handler_.handler_.__f_ = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
    &service->service_impl_,
    &this->implementation,
    buffers,
    0,
    &v9);
  if ( &v9.handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v9.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v9.handler_.handler_.handler_.__f_->_vptr$__base
     + 4))(v9.handler_.handler_.handler_.__f_);
  }
  else if ( v9.handler_.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v9.handler_.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x2629d90 | Name: _ZN5boost4asio19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS3_EEE16async_write_someINS0_6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorISA_NSB_9allocatorISA_EEEEEENS8_8write_opIS6_SF_NS8_14transfer_all_tENS8_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSN_6config15asio_tls_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEEJNSB_10shared_ptrISU_EERS10_RKNSB_12placeholders4__phILi1EEEEEENS8_26is_continuation_if_runningEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvS12_mEE4typeEE4typeERKT_OS1L_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >::type __fastcall boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_write_some<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *this,
        const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *buffers,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  boost::asio::stream_socket_service<boost::asio::ip::tcp> *service; // r13
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *v6; // rdi
  std::__shared_weak_count *v7; // rbx
  __int64 v8; // [rsp+0h] [rbp-108h] BYREF
  void *ptr[8]; // [rsp+8h] [rbp-100h] BYREF
  int v10; // [rsp+48h] [rbp-C0h]
  __int64 v11; // [rsp+50h] [rbp-B8h]
  __int128 v12; // [rsp+60h] [rbp-A8h]
  __int128 v13; // [rsp+70h] [rbp-98h]
  std::__shared_weak_count *v14[2]; // [rsp+80h] [rbp-88h]
  _BYTE v15[32]; // [rsp+90h] [rbp-78h] BYREF
  _BYTE *v16; // [rsp+B0h] [rbp-58h]
  unsigned __int64 v17; // [rsp+D8h] [rbp-30h]

  v17 = __readfsqword(0x28u);
  service = this->service_;
  v8 = *(_QWORD *)handler;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 8));
  v10 = *((_DWORD *)handler + 18);
  v11 = *((_QWORD *)handler + 10);
  v12 = *((_OWORD *)handler + 6);
  v13 = *((_OWORD *)handler + 7);
  *(_OWORD *)v14 = *((_OWORD *)handler + 8);
  *((_OWORD *)handler + 8) = 0;
  v6 = (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)*((_QWORD *)handler + 22);
  if ( v6 )
  {
    if ( (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 144) == v6 )
    {
      v16 = v15;
      (*(void (__fastcall **)(boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, _BYTE *))(*(_QWORD *)v6 + 24LL))(
        v6,
        v15);
    }
    else
    {
      v16 = (_BYTE *)*((_QWORD *)handler + 22);
      *((_QWORD *)handler + 22) = 0;
    }
  }
  else
  {
    v16 = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
    &service->service_impl_,
    &this->implementation,
    buffers,
    0,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&v8);
  if ( v15 == v16 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v16 + 32LL))(v16);
  }
  else if ( v16 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v16 + 40LL))(v16);
  }
  v7 = v14[1];
  if ( v14[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
}


// Address: 0x262d490 | Name: _ZN5boost4asio19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS3_EEE15async_read_someINS0_17mutable_buffers_1ENS0_6detail26read_until_delim_string_opIS6_NSt3__19allocatorIcEENS9_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config15asio_tls_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS9_26is_continuation_if_runningEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSX_mEE4typeEE4typeERKT_OS1J_
boost::asio::async_result<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > >::type __fastcall boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *this,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  boost::asio::stream_socket_service<boost::asio::ip::tcp> *service; // rbx
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v5; // rdi
  std::__shared_weak_count *v6; // rbx
  __int128 v7; // [rsp+0h] [rbp-D8h] BYREF
  __int128 v8; // [rsp+10h] [rbp-C8h]
  void *ptr; // [rsp+20h] [rbp-B8h]
  int v10; // [rsp+28h] [rbp-B0h]
  __int64 v11; // [rsp+30h] [rbp-A8h]
  __int128 v12; // [rsp+40h] [rbp-98h]
  __int128 v13; // [rsp+50h] [rbp-88h]
  std::__shared_weak_count *v14[2]; // [rsp+60h] [rbp-78h]
  _BYTE v15[32]; // [rsp+70h] [rbp-68h] BYREF
  _BYTE *v16; // [rsp+90h] [rbp-48h]
  unsigned __int64 v17; // [rsp+B0h] [rbp-28h]

  v17 = __readfsqword(0x28u);
  service = this->service_;
  v7 = *(_OWORD *)handler;
  ptr = (void *)*((_QWORD *)handler + 4);
  v8 = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  v10 = *((_DWORD *)handler + 10);
  v11 = *((_QWORD *)handler + 6);
  v12 = *((_OWORD *)handler + 4);
  v13 = *((_OWORD *)handler + 5);
  *(_OWORD *)v14 = *((_OWORD *)handler + 6);
  *((_OWORD *)handler + 6) = 0;
  v5 = (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)*((_QWORD *)handler + 18);
  if ( v5 )
  {
    if ( (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 112) == v5 )
    {
      v16 = v15;
      (*(void (__fastcall **)(boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *, _BYTE *))(*(_QWORD *)v5 + 24LL))(
        v5,
        v15);
    }
    else
    {
      v16 = (_BYTE *)*((_QWORD *)handler + 18);
      *((_QWORD *)handler + 18) = 0;
    }
  }
  else
  {
    v16 = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>(
    &service->service_impl_,
    &this->implementation,
    buffers,
    0,
    (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)&v7);
  if ( v15 == v16 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v16 + 32LL))(v16);
  }
  else if ( v16 )
  {
    (*(void (__fastcall **)(_BYTE *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *))(*(_QWORD *)v16 + 40LL))(
      v16,
      this);
  }
  v6 = v14[1];
  if ( v14[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
    if ( (v8 & 1) == 0 )
      return;
  }
  else if ( (v8 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x266b1b0 | Name: _ZN5boost4asio19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS3_EEE16async_write_someINS0_6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorISA_NSB_9allocatorISA_EEEEEENS8_8write_opIS6_SF_NS8_14transfer_all_tENS8_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSN_6config11asio_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEEJNSB_10shared_ptrISU_EERS10_RKNSB_12placeholders4__phILi1EEEEEENS8_26is_continuation_if_runningEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvS12_mEE4typeEE4typeERKT_OS1L_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >::type __fastcall boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_write_some<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *this,
        const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *buffers,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  boost::asio::stream_socket_service<boost::asio::ip::tcp> *service; // r13
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *v6; // rdi
  std::__shared_weak_count *v7; // rbx
  __int64 v8; // [rsp+0h] [rbp-108h] BYREF
  void *ptr[8]; // [rsp+8h] [rbp-100h] BYREF
  int v10; // [rsp+48h] [rbp-C0h]
  __int64 v11; // [rsp+50h] [rbp-B8h]
  __int128 v12; // [rsp+60h] [rbp-A8h]
  __int128 v13; // [rsp+70h] [rbp-98h]
  std::__shared_weak_count *v14[2]; // [rsp+80h] [rbp-88h]
  _BYTE v15[32]; // [rsp+90h] [rbp-78h] BYREF
  _BYTE *v16; // [rsp+B0h] [rbp-58h]
  unsigned __int64 v17; // [rsp+D8h] [rbp-30h]

  v17 = __readfsqword(0x28u);
  service = this->service_;
  v8 = *(_QWORD *)handler;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 8));
  v10 = *((_DWORD *)handler + 18);
  v11 = *((_QWORD *)handler + 10);
  v12 = *((_OWORD *)handler + 6);
  v13 = *((_OWORD *)handler + 7);
  *(_OWORD *)v14 = *((_OWORD *)handler + 8);
  *((_OWORD *)handler + 8) = 0;
  v6 = (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)*((_QWORD *)handler + 22);
  if ( v6 )
  {
    if ( (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 144) == v6 )
    {
      v16 = v15;
      (*(void (__fastcall **)(boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, _BYTE *))(*(_QWORD *)v6 + 24LL))(
        v6,
        v15);
    }
    else
    {
      v16 = (_BYTE *)*((_QWORD *)handler + 22);
      *((_QWORD *)handler + 22) = 0;
    }
  }
  else
  {
    v16 = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
    &service->service_impl_,
    &this->implementation,
    buffers,
    0,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&v8);
  if ( v15 == v16 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v16 + 32LL))(v16);
  }
  else if ( v16 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v16 + 40LL))(v16);
  }
  v7 = v14[1];
  if ( v14[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
}


// Address: 0x266e7c0 | Name: _ZN5boost4asio19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS3_EEE15async_read_someINS0_17mutable_buffers_1ENS0_6detail26read_until_delim_string_opIS6_NSt3__19allocatorIcEENS9_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config11asio_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS9_26is_continuation_if_runningEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSX_mEE4typeEE4typeERKT_OS1J_
boost::asio::async_result<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > >::type __fastcall boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *this,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  boost::asio::stream_socket_service<boost::asio::ip::tcp> *service; // rbx
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v5; // rdi
  std::__shared_weak_count *v6; // rbx
  __int128 v7; // [rsp+0h] [rbp-D8h] BYREF
  __int128 v8; // [rsp+10h] [rbp-C8h]
  void *ptr; // [rsp+20h] [rbp-B8h]
  int v10; // [rsp+28h] [rbp-B0h]
  __int64 v11; // [rsp+30h] [rbp-A8h]
  __int128 v12; // [rsp+40h] [rbp-98h]
  __int128 v13; // [rsp+50h] [rbp-88h]
  std::__shared_weak_count *v14[2]; // [rsp+60h] [rbp-78h]
  _BYTE v15[32]; // [rsp+70h] [rbp-68h] BYREF
  _BYTE *v16; // [rsp+90h] [rbp-48h]
  unsigned __int64 v17; // [rsp+B0h] [rbp-28h]

  v17 = __readfsqword(0x28u);
  service = this->service_;
  v7 = *(_OWORD *)handler;
  ptr = (void *)*((_QWORD *)handler + 4);
  v8 = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  v10 = *((_DWORD *)handler + 10);
  v11 = *((_QWORD *)handler + 6);
  v12 = *((_OWORD *)handler + 4);
  v13 = *((_OWORD *)handler + 5);
  *(_OWORD *)v14 = *((_OWORD *)handler + 6);
  *((_OWORD *)handler + 6) = 0;
  v5 = (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)*((_QWORD *)handler + 18);
  if ( v5 )
  {
    if ( (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 112) == v5 )
    {
      v16 = v15;
      (*(void (__fastcall **)(boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *, _BYTE *))(*(_QWORD *)v5 + 24LL))(
        v5,
        v15);
    }
    else
    {
      v16 = (_BYTE *)*((_QWORD *)handler + 18);
      *((_QWORD *)handler + 18) = 0;
    }
  }
  else
  {
    v16 = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>(
    &service->service_impl_,
    &this->implementation,
    buffers,
    0,
    (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)&v7);
  if ( v15 == v16 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v16 + 32LL))(v16);
  }
  else if ( v16 )
  {
    (*(void (__fastcall **)(_BYTE *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *))(*(_QWORD *)v16 + 40LL))(
      v16,
      this);
  }
  v6 = v14[1];
  if ( v14[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
    if ( (v8 & 1) == 0 )
      return;
  }
  else if ( (v8 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


