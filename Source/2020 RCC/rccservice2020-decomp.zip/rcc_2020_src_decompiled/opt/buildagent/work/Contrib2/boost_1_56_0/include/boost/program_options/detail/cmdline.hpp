// Address: 0xe446c0 | Name: _ZN5boost15program_options6detail7cmdlineD2Ev
void __fastcall boost::program_options::detail::cmdline::~cmdline(boost::program_options::detail::cmdline *this)
{
  __int64 v2; // rax
  void (__fastcall *v3)(char *, char *, __int64); // rax
  __int64 v4; // rax
  void (__fastcall *v5)(char *, char *, __int64); // rax
  void **v6; // r15
  void **v7; // rax
  void **v8; // rbx
  void **v9; // rdi

  v2 = *((_QWORD *)this + 10);
  if ( v2 )
  {
    if ( (v2 & 1) == 0 )
    {
      v3 = *(void (__fastcall **)(char *, char *, __int64))(v2 & 0xFFFFFFFFFFFFFFFELL);
      if ( v3 )
        v3((char *)this + 88, (char *)this + 88, 2);
    }
    *((_QWORD *)this + 10) = 0;
  }
  v4 = *((_QWORD *)this + 6);
  if ( v4 )
  {
    if ( (v4 & 1) == 0 )
    {
      v5 = *(void (__fastcall **)(char *, char *, __int64))(v4 & 0xFFFFFFFFFFFFFFFELL);
      if ( v5 )
        v5((char *)this + 56, (char *)this + 56, 2);
    }
    *((_QWORD *)this + 6) = 0;
  }
  v6 = *(void ***)this;
  if ( *(_QWORD *)this )
  {
    v7 = (void **)*((_QWORD *)this + 1);
    if ( v7 == v6 )
    {
      v9 = *(void ***)this;
    }
    else
    {
      do
      {
        v8 = v7 - 3;
        if ( (*(_BYTE *)(v7 - 3) & 1) != 0 )
          operator delete(*(v7 - 1));
        v7 = v8;
      }
      while ( v6 != v8 );
      v9 = *(void ***)this;
    }
    *((_QWORD *)this + 1) = v6;
    operator delete(v9);
  }
}


