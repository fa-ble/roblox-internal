// Address: 0x2842160 | Name: _ZN5boost6system16generic_categoryEv
const boost::system::error_category *__cdecl boost::system::generic_category()
{
  if ( !(_BYTE)byte_2CE5630 && __cxa_guard_acquire(&byte_2CE5630) )
  {
    stru_2CE5628._vptr$error_category = (int (**)(void))&off_29CFD68;
    __cxa_guard_release(&byte_2CE5630);
  }
  return &stru_2CE5628;
}


// Address: 0x28421a0 | Name: _ZN5boost6system15system_categoryEv
const boost::system::error_category *__cdecl boost::system::system_category()
{
  if ( !(_BYTE)byte_2CE5620 && __cxa_guard_acquire(&byte_2CE5620) )
  {
    stru_2CE5618._vptr$error_category = (int (**)(void))&off_29CFD00;
    __cxa_guard_release(&byte_2CE5620);
  }
  return &stru_2CE5618;
}


// Address: 0x28421e0 | Name: _ZN5boost6system12_GLOBAL__N_121system_error_categoryD0Ev
// Alternative name is 'j__ZdlPv_2070'
// attributes: thunk
void __fastcall boost::system::`anonymous namespace'::system_error_category::~system_error_category(
        boost::system::`anonymous namespace'::system_error_category *this)
{
  operator delete(this);
}


// Address: 0x28421f0 | Name: _ZNK5boost6system12_GLOBAL__N_121system_error_category4nameEv
const char *__fastcall boost::system::`anonymous namespace'::system_error_category::name(
        const boost::system::`anonymous namespace'::system_error_category *this)
{
  return "system";
}


// Address: 0x2842200 | Name: _ZNK5boost6system12_GLOBAL__N_121system_error_category7messageEi
boost::system::_anonymous_namespace_::system_error_category *__fastcall boost::system::`anonymous namespace'::system_error_category::message(
        boost::system::_anonymous_namespace_::system_error_category *this,
        int a2,
        unsigned int a3)
{
  if ( !(_BYTE)byte_2CE5630 && __cxa_guard_acquire(&byte_2CE5630) )
  {
    stru_2CE5628._vptr$error_category = (int (**)(void))&off_29CFD68;
    __cxa_guard_release(&byte_2CE5630);
  }
  (*((void (__fastcall **)(boost::system::_anonymous_namespace_::system_error_category *, const boost::system::`anonymous namespace'::generic_error_category *, _QWORD))stru_2CE5628._vptr$error_category
   + 3))(
    this,
    &stru_2CE5628,
    a3);
  return this;
}


// Address: 0x2842260 | Name: _ZNK5boost6system12_GLOBAL__N_121system_error_category23default_error_conditionEi
boost::system::error_condition_0 __fastcall boost::system::`anonymous namespace'::system_error_category::default_error_condition(
        const boost::system::`anonymous namespace'::system_error_category *this,
        int ev)
{
  const boost::system::`anonymous namespace'::system_error_category *v2; // r14
  __guard *v4; // rdi
  boost::system::error_condition_0 result; // 0:eax.4,8:rdx.8

  switch ( ev )
  {
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
    case 16:
    case 17:
    case 18:
    case 19:
    case 20:
    case 21:
    case 22:
    case 23:
    case 24:
    case 25:
    case 26:
    case 27:
    case 28:
    case 29:
    case 30:
    case 31:
    case 32:
    case 33:
    case 34:
    case 35:
    case 36:
    case 37:
    case 38:
    case 39:
    case 40:
    case 42:
    case 43:
    case 60:
    case 61:
    case 62:
    case 63:
    case 67:
    case 71:
    case 74:
    case 75:
    case 84:
    case 88:
    case 89:
    case 90:
    case 91:
    case 92:
    case 93:
    case 95:
    case 97:
    case 98:
    case 99:
    case 100:
    case 101:
    case 102:
    case 103:
    case 104:
    case 105:
    case 106:
    case 107:
    case 110:
    case 111:
    case 113:
    case 114:
    case 115:
    case 125:
    case 130:
    case 131:
      v2 = (const boost::system::`anonymous namespace'::system_error_category *)&stru_2CE5628;
      if ( !(_BYTE)byte_2CE5630 && __cxa_guard_acquire(&byte_2CE5630) )
      {
        stru_2CE5628._vptr$error_category = (int (**)(void))&off_29CFD68;
        v4 = &byte_2CE5630;
        goto LABEL_9;
      }
      break;
    default:
      v2 = &stru_2CE5618;
      if ( !(_BYTE)byte_2CE5620 && __cxa_guard_acquire(&byte_2CE5620) )
      {
        stru_2CE5618._vptr$error_category = (int (**)(void))&off_29CFD00;
        v4 = &byte_2CE5620;
LABEL_9:
        __cxa_guard_release(v4);
      }
      break;
  }
  result.m_val = ev;
  result.m_cat = v2;
  return result;
}


// Address: 0x2842310 | Name: _ZN5boost6system12_GLOBAL__N_122generic_error_categoryD0Ev
// Alternative name is 'j__ZdlPv_2071'
// attributes: thunk
void __fastcall boost::system::`anonymous namespace'::generic_error_category::~generic_error_category(
        boost::system::`anonymous namespace'::generic_error_category *this)
{
  operator delete(this);
}


// Address: 0x2842320 | Name: _ZNK5boost6system12_GLOBAL__N_122generic_error_category4nameEv
const char *__fastcall boost::system::`anonymous namespace'::generic_error_category::name(
        const boost::system::`anonymous namespace'::generic_error_category *this)
{
  return "generic";
}


// Address: 0x2842330 | Name: _ZNK5boost6system12_GLOBAL__N_122generic_error_category7messageEi
boost::system::_anonymous_namespace_::generic_error_category *__fastcall boost::system::`anonymous namespace'::generic_error_category::message(
        boost::system::_anonymous_namespace_::generic_error_category *this,
        int a2,
        int a3)
{
  char *v4; // rax
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // r13
  char *v8; // r12
  size_t v9; // rbx
  char v11[72]; // [rsp+0h] [rbp-78h] BYREF
  unsigned __int64 v12; // [rsp+48h] [rbp-30h]

  v12 = __readfsqword(0x28u);
  if ( !(_BYTE)byte_2CE5650 && __cxa_guard_acquire(&byte_2CE5650) )
  {
    xmmword_2CE5638 = 0;
    qword_2CE5648 = 0;
    xmmword_2CE5638 = 26;
    strcpy((char *)&xmmword_2CE5638 + 1, "Unknown error");
    __cxa_atexit((void (*)(void *))&std::string::~string, &xmmword_2CE5638, &dso_handle);
    __cxa_guard_release(&byte_2CE5650);
  }
  v4 = strerror_r(a3, v11, 0x40u);
  if ( v4 )
  {
    v5 = v4;
    *(_OWORD *)this = 0;
    *((_QWORD *)this + 2) = 0;
    v6 = strlen(v4);
    if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
    {
      std::__basic_string_common<true>::__throw_length_error(this);
      JUMPOUT(0x28424B2);
    }
    v7 = v6;
    if ( v6 >= 0x17 )
    {
      v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
      v8 = (char *)operator new(v9);
      *((_QWORD *)this + 2) = v8;
      *(_QWORD *)this = v9 | 1;
      *((_QWORD *)this + 1) = v7;
    }
    else
    {
      *(_BYTE *)this = 2 * v6;
      v8 = (char *)this + 1;
      if ( !v6 )
        goto LABEL_10;
    }
    memcpy(v8, v5, v7);
LABEL_10:
    v8[v7] = 0;
    return this;
  }
  std::string::basic_string(this, &xmmword_2CE5638);
  return this;
}


