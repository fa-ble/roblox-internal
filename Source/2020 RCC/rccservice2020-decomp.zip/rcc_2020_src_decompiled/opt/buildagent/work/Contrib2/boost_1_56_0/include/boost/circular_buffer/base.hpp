// Address: 0xea4e00 | Name: _ZN6RakNet22CCRakNetSlidingWindow29findRangeERN5boost15circular_bufferINS0_12RttRangeInfoENSt3__19allocatorIS3_EEEEj
RakNet::CCRakNetSlidingWindow2::RttRangeInfo *__fastcall RakNet::CCRakNetSlidingWindow2::findRange(
        RakNet::CCRakNetSlidingWindow2 *this,
        RakNet::CCRakNetSlidingWindow2::RttRangeQueue *rttRangeQueue,
        uint32_t id)
{
  signed __int64 m_size; // rax
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer m_first; // r10
  signed __int64 v5; // rcx
  signed __int64 v6; // rdi
  signed __int64 v7; // rdi
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *result; // rax

  m_size = rttRangeQueue->m_size;
  if ( (int)m_size <= 0 )
    return 0;
  m_first = rttRangeQueue->m_first;
  m_size = (int)m_size;
  while ( 1 )
  {
    v5 = m_size - 1;
    v6 = m_size - 1;
    if ( rttRangeQueue->m_end - m_first < m_size )
      v6 = m_size - (rttRangeQueue->m_end - rttRangeQueue->m_buff) - 1;
    v7 = v6 << 7;
    if ( *(int *)((char *)&m_first->packetsSent + v7) )
    {
      result = (boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer)((char *)m_first + v7);
      if ( *(int *)((char *)&m_first->countStart + v7) <= (signed int)id )
        break;
    }
    m_size = v5;
    if ( v5 + 1 <= 1 )
      return 0;
  }
  if ( *(int *)((char *)&m_first->countEnd + v7) < (signed int)id )
    return 0;
  return result;
}


// Address: 0xea4ea0 | Name: _ZN6RakNet22CCRakNetSlidingWindow211updateRangeERN5boost15circular_bufferINS0_12RttRangeInfoENSt3__19allocatorIS3_EEEEjim
void __fastcall RakNet::CCRakNetSlidingWindow2::updateRange(
        RakNet::CCRakNetSlidingWindow2 *this,
        RakNet::CCRakNetSlidingWindow2::RttRangeQueue *rttRangeQueue,
        uint32_t id,
        int size,
        RakNet::CCTimeType time)
{
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_last; // rax

  m_last = rttRangeQueue->m_last;
  if ( m_last == rttRangeQueue->m_buff )
    m_last = rttRangeQueue->m_end;
  ++m_last[-1].packetsSentAll;
  m_last[-1].bytesSentAll += size;
  if ( id != -1 )
  {
    ++m_last[-1].packetsSent;
    m_last[-1].bytesSent += size;
    m_last[-1].timeSentLast = time;
    m_last[-1].countEnd = id;
    if ( !m_last[-1].timeSentFirst )
    {
      m_last[-1].timeSentFirst = time;
      m_last[-1].countStart = id;
    }
  }
}


// Address: 0xea7940 | Name: _ZN5boost15circular_bufferIN6RakNet22CCRakNetSlidingWindow212RttRangeInfoENSt3__19allocatorIS3_EEE12set_capacityEm
void __fastcall boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::set_capacity(
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> > *this,
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::capacity_type new_capacity)
{
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer m_buff; // rbp
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer m_end; // r12
  __int64 v4; // rbx
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::capacity_type v5; // r14
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v7; // r15
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::capacity_type m_size; // rcx
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer m_first; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v10; // rsi
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v11; // rdx
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer m_last; // rdi
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer v13; // r8
  __int64 v14; // rdx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v15; // rbx
  __int128 v16; // xmm0
  __int128 v17; // xmm1
  __int128 v18; // xmm2
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v19; // rax
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::capacity_type v20; // rsi
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v21; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v22; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v23; // r14
  _QWORD v24[8]; // [rsp+8h] [rbp-40h] BYREF

  m_buff = this->m_buff;
  m_end = this->m_end;
  v4 = m_end - this->m_buff;
  if ( v4 == new_capacity )
    return;
  v5 = new_capacity;
  if ( new_capacity >> 57 )
  {
    std::logic_error::logic_error((std::logic_error *)v24, "circular_buffer");
    v24[0] = (char *)&`vtable for'std::length_error + 16;
    boost::throw_exception<std::length_error>((const std::length_error *)v24);
  }
  if ( new_capacity )
    v7 = (RakNet::CCRakNetSlidingWindow2::RttRangeInfo *)operator new(new_capacity << 7);
  else
    v7 = 0;
  m_size = this->m_size;
  if ( m_size )
    m_first = this->m_first;
  else
    m_first = 0;
  if ( m_size < new_capacity )
    new_capacity = this->m_size;
  if ( (__int64)new_capacity <= 0 )
  {
    v11 = m_first;
    if ( (new_capacity & 0x8000000000000000LL) != 0LL )
    {
      m_last = m_first;
      v13 = m_first;
      if ( !m_first )
      {
        m_last = this->m_last;
        v13 = m_last;
      }
      v14 = 0;
      if ( m_last - m_buff < -(__int64)new_capacity )
        v14 = v4;
      v11 = &v13[new_capacity + v14];
    }
  }
  else
  {
    if ( m_end - m_first > (__int64)new_capacity )
      v4 = 0;
    v10 = &m_first[new_capacity - v4];
    if ( v10 == this->m_last )
      v10 = 0;
    v11 = v10;
  }
  v15 = v7;
  if ( m_first == v11 )
  {
    if ( m_size )
      goto LABEL_33;
    goto LABEL_44;
  }
  do
  {
    *(_OWORD *)&v15->nakPercentage = *(_OWORD *)&m_first->nakPercentage;
    *(_OWORD *)&v15->rttMicroMinPktSize = *(_OWORD *)&m_first->rttMicroMinPktSize;
    *(_OWORD *)&v15->timeAckFirst = *(_OWORD *)&m_first->timeAckFirst;
    *(_OWORD *)&v15->timeSentFirst = *(_OWORD *)&m_first->timeSentFirst;
    v16 = *(_OWORD *)&m_first->countStart;
    v17 = *(_OWORD *)&m_first->bytesSentAll;
    v18 = *(_OWORD *)&m_first->bytesAck;
    *(_OWORD *)&v15->rttMicroMin = *(_OWORD *)&m_first->rttMicroMin;
    *(_OWORD *)&v15->bytesAck = v18;
    *(_OWORD *)&v15->bytesSentAll = v17;
    *(_OWORD *)&v15->countStart = v16;
    ++m_first;
    m_end = this->m_end;
    if ( m_first != m_end )
    {
      if ( m_first != this->m_last )
        goto LABEL_31;
LABEL_30:
      m_first = 0;
      goto LABEL_31;
    }
    m_first = this->m_buff;
    if ( this->m_buff == this->m_last )
      goto LABEL_30;
LABEL_31:
    ++v15;
  }
  while ( m_first != v11 );
  m_size = this->m_size;
  if ( m_size )
  {
LABEL_33:
    v19 = this->m_first;
    if ( m_size != 1 )
    {
      v20 = (m_size & 1) - m_size;
      do
      {
        while ( 1 )
        {
          v21 = v19 + 1;
          this->m_first = v21;
          if ( v21 == m_end )
          {
            v21 = this->m_buff;
            this->m_first = this->m_buff;
          }
          v19 = v21 + 1;
          this->m_first = v19;
          if ( v19 == m_end )
            break;
          v20 += 2LL;
          if ( !v20 )
            goto LABEL_41;
        }
        v19 = this->m_buff;
        this->m_first = this->m_buff;
        v20 += 2LL;
      }
      while ( v20 );
    }
LABEL_41:
    if ( (m_size & 1) != 0 )
    {
      v22 = v19 + 1;
      this->m_first = v22;
      if ( v22 == m_end )
        this->m_first = this->m_buff;
    }
  }
LABEL_44:
  if ( this->m_buff )
    operator delete(this->m_buff);
  this->m_size = v15 - v7;
  this->m_buff = v7;
  this->m_first = v7;
  v23 = &v7[v5];
  this->m_end = v23;
  if ( v23 == v15 )
    v15 = v7;
  this->m_last = v15;
}


// Address: 0xea7bb0 | Name: _ZN5boost15circular_bufferIN6RakNet22CCRakNetSlidingWindow212RttRangeInfoENSt3__19allocatorIS3_EEE6resizeEmRKS3_
void __fastcall boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::resize(
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> > *this,
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type new_size,
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::param_value_type item)
{
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type m_size; // rax
  __int64 v4; // rcx
  signed __int64 v6; // rdx
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type v7; // rdx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_last; // rdx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v9; // rcx
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer m_buff; // rsi
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type v11; // rcx
  boost::cb_details::item_wrapper<const RakNet::CCRakNetSlidingWindow2::RttRangeInfo *,const RakNet::CCRakNetSlidingWindow2::RttRangeInfo &> wrapper; // [rsp+8h] [rbp-30h] BYREF
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::iterator pos; // [rsp+10h] [rbp-28h] BYREF

  m_size = this->m_size;
  v4 = m_size - new_size;
  if ( m_size < new_size )
  {
    if ( this->m_end - this->m_buff < new_size )
    {
      boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::set_capacity(
        this,
        new_size);
      m_size = this->m_size;
    }
    pos.m_buff = this;
    pos.m_it = 0;
    if ( new_size != m_size )
    {
      v6 = (char *)this->m_end - (char *)this->m_buff;
      if ( v6 )
      {
        v7 = v6 >> 7;
        if ( v7 >= new_size - m_size )
          v7 = new_size - m_size;
        wrapper.m_item = item;
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::insert_n<boost::cb_details::item_wrapper<RakNet::CCRakNetSlidingWindow2::RttRangeInfo const*,RakNet::CCRakNetSlidingWindow2::RttRangeInfo const&>>(
          this,
          &pos,
          v7,
          &wrapper);
      }
    }
    return;
  }
  if ( v4 > 0 )
  {
    m_last = this->m_last;
    if ( m_last - this->m_buff < v4 )
      v4 -= this->m_end - this->m_buff;
    v9 = &m_last[-v4];
LABEL_13:
    if ( v9 )
    {
      m_buff = this->m_buff;
      do
      {
        if ( m_last == m_buff )
        {
          m_last = this->m_end;
          this->m_last = m_last;
        }
        this->m_last = --m_last;
        --m_size;
      }
      while ( m_last != v9 );
      this->m_size = m_size;
    }
    return;
  }
  if ( v4 < 0 )
  {
    v11 = new_size - m_size;
    if ( (__int64)this->m_end >> 7 <= (__int64)(new_size - m_size) )
      v11 -= this->m_end - this->m_buff;
    v9 = (RakNet::CCRakNetSlidingWindow2::RttRangeInfo *)(v11 << 7);
    m_last = this->m_last;
    if ( v9 != m_last )
      goto LABEL_13;
  }
}


// Address: 0xea8490 | Name: _ZN5boost15circular_bufferIN6RakNet22CCRakNetSlidingWindow212RttRangeInfoENSt3__19allocatorIS3_EEE8insert_nINS_10cb_details12item_wrapperIPKS3_RSB_EEEEvRKNS9_8iteratorIS7_NS9_15nonconst_traitsINS_9container16allocator_traitsIS6_EEEEEEmRKT_
void __fastcall boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::insert_n<boost::cb_details::item_wrapper<RakNet::CCRakNetSlidingWindow2::RttRangeInfo const*,RakNet::CCRakNetSlidingWindow2::RttRangeInfo const&>>(
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> > *this,
        const boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::iterator *pos,
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type n,
        const boost::cb_details::item_wrapper<const RakNet::CCRakNetSlidingWindow2::RttRangeInfo *,const RakNet::CCRakNetSlidingWindow2::RttRangeInfo &> *wrapper)
{
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer m_buff; // r15
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer m_end; // r11
  __int64 v6; // r9
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type m_size; // r14
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type v8; // r8
  boost::cb_details::iterator<boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >,boost::cb_details::nonconst_traits<boost::container::allocator_traits<std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> > > >::pointer m_it; // r10
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer m_last; // rax
  __int64 v11; // r11
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer v12; // rbx
  __int128 v13; // xmm0
  __int128 v14; // xmm1
  __int128 v15; // xmm2
  __int128 v16; // xmm3
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type v17; // rbx
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type v18; // rsi
  const RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v19; // rbx
  __int128 v20; // xmm0
  __int128 v21; // xmm1
  __int128 v22; // xmm2
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer v23; // r10
  const RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v24; // rbx
  __int128 v25; // xmm0
  __int128 v26; // xmm1
  __int128 v27; // xmm2
  const RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v28; // rax
  __int128 v29; // xmm0
  __int128 v30; // xmm1
  __int128 v31; // xmm2
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type v32; // rbx
  __int64 v33; // rsi
  const RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v34; // rbx
  __int128 v35; // xmm0
  __int128 v36; // xmm1
  __int128 v37; // xmm2
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer v38; // rax
  const RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v39; // rbx
  __int128 v40; // xmm0
  __int128 v41; // xmm1
  __int128 v42; // xmm2
  const RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v43; // rsi
  __int128 v44; // xmm0
  __int128 v45; // xmm1
  __int128 v46; // xmm2
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type v47; // r14
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type v48; // rsi
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type v49; // rsi
  const RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_item; // rbx
  __int128 v51; // xmm0
  __int128 v52; // xmm1
  __int128 v53; // xmm2
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer v54; // rax
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::size_type v55; // rcx
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >::pointer m_first; // rax
  __int64 v57; // rdx

  m_buff = this->m_buff;
  m_end = this->m_end;
  v6 = m_end - this->m_buff;
  m_size = this->m_size;
  v8 = v6 - m_size;
  if ( v6 - m_size > n )
    v8 = n;
  m_it = pos->m_it;
  m_last = this->m_last;
  if ( !m_it )
  {
    if ( !v8 )
      goto LABEL_42;
    v17 = m_size + ~v6;
    if ( v17 <= ~n )
      v17 = ~n;
    if ( v17 == -2 )
    {
      if ( (v8 & 1) == 0 )
      {
LABEL_42:
        if ( v6 - m_size < n )
        {
          v47 = m_size - 1 - v6;
          v48 = ~n;
          if ( v47 > ~n )
            v48 = v47;
          v49 = n + v48 + 1;
          do
          {
            m_item = wrapper->m_item;
            *(_OWORD *)&m_last->nakPercentage = *(_OWORD *)&wrapper->m_item->nakPercentage;
            *(_OWORD *)&m_last->rttMicroMinPktSize = *(_OWORD *)&m_item->rttMicroMinPktSize;
            *(_OWORD *)&m_last->timeAckFirst = *(_OWORD *)&m_item->timeAckFirst;
            *(_OWORD *)&m_last->timeSentFirst = *(_OWORD *)&m_item->timeSentFirst;
            v51 = *(_OWORD *)&m_item->countStart;
            v52 = *(_OWORD *)&m_item->bytesSentAll;
            v53 = *(_OWORD *)&m_item->bytesAck;
            *(_OWORD *)&m_last->rttMicroMin = *(_OWORD *)&m_item->rttMicroMin;
            *(_OWORD *)&m_last->bytesAck = v53;
            *(_OWORD *)&m_last->bytesSentAll = v52;
            *(_OWORD *)&m_last->countStart = v51;
            ++m_last;
            m_end = this->m_end;
            if ( m_last == m_end )
              m_last = this->m_buff;
            --v49;
          }
          while ( v49 );
        }
        goto LABEL_49;
      }
    }
    else
    {
      v32 = m_size - 1 - v6;
      if ( v32 <= ~n )
        v32 = ~n;
      v33 = v32 + (v8 & 1) + 1;
      do
      {
        v34 = wrapper->m_item;
        *(_OWORD *)&m_last->nakPercentage = *(_OWORD *)&wrapper->m_item->nakPercentage;
        *(_OWORD *)&m_last->rttMicroMinPktSize = *(_OWORD *)&v34->rttMicroMinPktSize;
        *(_OWORD *)&m_last->timeAckFirst = *(_OWORD *)&v34->timeAckFirst;
        *(_OWORD *)&m_last->timeSentFirst = *(_OWORD *)&v34->timeSentFirst;
        v35 = *(_OWORD *)&v34->countStart;
        v36 = *(_OWORD *)&v34->bytesSentAll;
        v37 = *(_OWORD *)&v34->bytesAck;
        *(_OWORD *)&m_last->rttMicroMin = *(_OWORD *)&v34->rttMicroMin;
        *(_OWORD *)&m_last->bytesAck = v37;
        *(_OWORD *)&m_last->bytesSentAll = v36;
        *(_OWORD *)&m_last->countStart = v35;
        v38 = m_last + 1;
        if ( v38 == this->m_end )
          v38 = this->m_buff;
        v39 = wrapper->m_item;
        *(_OWORD *)&v38->nakPercentage = *(_OWORD *)&wrapper->m_item->nakPercentage;
        *(_OWORD *)&v38->rttMicroMinPktSize = *(_OWORD *)&v39->rttMicroMinPktSize;
        *(_OWORD *)&v38->timeAckFirst = *(_OWORD *)&v39->timeAckFirst;
        *(_OWORD *)&v38->timeSentFirst = *(_OWORD *)&v39->timeSentFirst;
        v40 = *(_OWORD *)&v39->countStart;
        v41 = *(_OWORD *)&v39->bytesSentAll;
        v42 = *(_OWORD *)&v39->bytesAck;
        *(_OWORD *)&v38->rttMicroMin = *(_OWORD *)&v39->rttMicroMin;
        *(_OWORD *)&v38->bytesAck = v42;
        *(_OWORD *)&v38->bytesSentAll = v41;
        *(_OWORD *)&v38->countStart = v40;
        m_last = v38 + 1;
        m_end = this->m_end;
        if ( m_last == m_end )
          m_last = this->m_buff;
        v33 += 2;
      }
      while ( v33 );
      if ( (v8 & 1) == 0 )
        goto LABEL_42;
    }
    v43 = wrapper->m_item;
    *(_OWORD *)&m_last->nakPercentage = *(_OWORD *)&wrapper->m_item->nakPercentage;
    *(_OWORD *)&m_last->rttMicroMinPktSize = *(_OWORD *)&v43->rttMicroMinPktSize;
    *(_OWORD *)&m_last->timeAckFirst = *(_OWORD *)&v43->timeAckFirst;
    *(_OWORD *)&m_last->timeSentFirst = *(_OWORD *)&v43->timeSentFirst;
    v44 = *(_OWORD *)&v43->countStart;
    v45 = *(_OWORD *)&v43->bytesSentAll;
    v46 = *(_OWORD *)&v43->bytesAck;
    *(_OWORD *)&m_last->rttMicroMin = *(_OWORD *)&v43->rttMicroMin;
    *(_OWORD *)&m_last->bytesAck = v46;
    *(_OWORD *)&m_last->bytesSentAll = v45;
    *(_OWORD *)&m_last->countStart = v44;
    ++m_last;
    m_end = this->m_end;
    if ( m_last == m_end )
      m_last = this->m_buff;
    goto LABEL_42;
  }
  if ( m_it != m_last )
  {
    v11 = m_end - m_last;
    if ( v11 > (__int64)(n - 1) )
      v6 = 0;
    v12 = &m_last[n - 1 - v6];
    do
    {
      if ( m_buff == m_last )
        m_last = this->m_end;
      *(_OWORD *)&v12->nakPercentage = *(_OWORD *)&m_last[-1].nakPercentage;
      *(_OWORD *)&v12->rttMicroMinPktSize = *(_OWORD *)&m_last[-1].rttMicroMinPktSize;
      *(_OWORD *)&v12->timeAckFirst = *(_OWORD *)&m_last[-1].timeAckFirst;
      *(_OWORD *)&v12->timeSentFirst = *(_OWORD *)&m_last[-1].timeSentFirst;
      v13 = *(_OWORD *)&m_last[-1].countStart;
      v14 = *(_OWORD *)&m_last[-1].bytesSentAll;
      v15 = *(_OWORD *)&m_last[-1].bytesAck;
      v16 = *(_OWORD *)&m_last[-1].rttMicroMin;
      --m_last;
      *(_OWORD *)&v12->rttMicroMin = v16;
      *(_OWORD *)&v12->bytesAck = v15;
      *(_OWORD *)&v12->bytesSentAll = v14;
      *(_OWORD *)&v12->countStart = v13;
      m_buff = this->m_buff;
      if ( v12 == this->m_buff )
        v12 = this->m_end;
      --v12;
    }
    while ( pos->m_it != m_last );
  }
  if ( !n )
    goto LABEL_30;
  if ( n == 1 )
    goto LABEL_29;
  v18 = (n & 1) - n;
  do
  {
    v19 = wrapper->m_item;
    *(_OWORD *)&m_it->nakPercentage = *(_OWORD *)&wrapper->m_item->nakPercentage;
    *(_OWORD *)&m_it->rttMicroMinPktSize = *(_OWORD *)&v19->rttMicroMinPktSize;
    *(_OWORD *)&m_it->timeAckFirst = *(_OWORD *)&v19->timeAckFirst;
    *(_OWORD *)&m_it->timeSentFirst = *(_OWORD *)&v19->timeSentFirst;
    v20 = *(_OWORD *)&v19->countStart;
    v21 = *(_OWORD *)&v19->bytesSentAll;
    v22 = *(_OWORD *)&v19->bytesAck;
    *(_OWORD *)&m_it->rttMicroMin = *(_OWORD *)&v19->rttMicroMin;
    *(_OWORD *)&m_it->bytesAck = v22;
    *(_OWORD *)&m_it->bytesSentAll = v21;
    *(_OWORD *)&m_it->countStart = v20;
    v23 = m_it + 1;
    if ( v23 == this->m_end )
      v23 = this->m_buff;
    v24 = wrapper->m_item;
    *(_OWORD *)&v23->nakPercentage = *(_OWORD *)&wrapper->m_item->nakPercentage;
    *(_OWORD *)&v23->rttMicroMinPktSize = *(_OWORD *)&v24->rttMicroMinPktSize;
    *(_OWORD *)&v23->timeAckFirst = *(_OWORD *)&v24->timeAckFirst;
    *(_OWORD *)&v23->timeSentFirst = *(_OWORD *)&v24->timeSentFirst;
    v25 = *(_OWORD *)&v24->countStart;
    v26 = *(_OWORD *)&v24->bytesSentAll;
    v27 = *(_OWORD *)&v24->bytesAck;
    *(_OWORD *)&v23->rttMicroMin = *(_OWORD *)&v24->rttMicroMin;
    *(_OWORD *)&v23->bytesAck = v27;
    *(_OWORD *)&v23->bytesSentAll = v26;
    *(_OWORD *)&v23->countStart = v25;
    m_it = v23 + 1;
    m_end = this->m_end;
    if ( m_it == m_end )
      m_it = this->m_buff;
    v18 += 2LL;
  }
  while ( v18 );
  if ( (n & 1) != 0 )
  {
LABEL_29:
    v28 = wrapper->m_item;
    *(_OWORD *)&m_it->nakPercentage = *(_OWORD *)&wrapper->m_item->nakPercentage;
    *(_OWORD *)&m_it->rttMicroMinPktSize = *(_OWORD *)&v28->rttMicroMinPktSize;
    *(_OWORD *)&m_it->timeAckFirst = *(_OWORD *)&v28->timeAckFirst;
    *(_OWORD *)&m_it->timeSentFirst = *(_OWORD *)&v28->timeSentFirst;
    v29 = *(_OWORD *)&v28->countStart;
    v30 = *(_OWORD *)&v28->bytesSentAll;
    v31 = *(_OWORD *)&v28->bytesAck;
    *(_OWORD *)&m_it->rttMicroMin = *(_OWORD *)&v28->rttMicroMin;
    *(_OWORD *)&m_it->bytesAck = v31;
    *(_OWORD *)&m_it->bytesSentAll = v30;
    *(_OWORD *)&m_it->countStart = v29;
LABEL_30:
    m_end = this->m_end;
  }
LABEL_49:
  v54 = this->m_last;
  v55 = n;
  if ( m_end - v54 <= (__int64)n )
    v55 = n - (m_end - this->m_buff);
  this->m_last = &v54[v55];
  m_first = this->m_first;
  v57 = n - v8;
  if ( m_end - m_first <= v57 )
    v57 -= m_end - this->m_buff;
  this->m_first = &m_first[v57];
  this->m_size += v8;
}


// Address: 0x130dd40 | Name: _ZN5boost15circular_bufferIN3RBX10PhysicsJob10StepRecordENSt3__19allocatorIS3_EEE12set_capacityEm
void __fastcall boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord>>::set_capacity(
        boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord> > *this,
        boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord> >::capacity_type new_capacity)
{
  boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord> >::pointer m_buff; // r12
  boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord> >::pointer m_end; // r13
  unsigned __int64 v4; // rbp
  boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord> >::capacity_type v5; // r14
  RBX::PhysicsJob::StepRecord *v7; // r15
  boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord> >::capacity_type m_size; // rcx
  boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord> >::pointer m_first; // rax
  RBX::PhysicsJob::StepRecord *v10; // rdx
  boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord> >::pointer m_last; // rdi
  boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord> >::pointer v12; // r8
  unsigned __int64 v13; // rdx
  RBX::PhysicsJob::StepRecord *v14; // rbp
  RBX::PhysicsJob::StepRecord *v15; // rax
  boost::circular_buffer<RBX::PhysicsJob::StepRecord,std::allocator<RBX::PhysicsJob::StepRecord> >::capacity_type v16; // rsi
  RBX::PhysicsJob::StepRecord *v17; // rax
  RBX::PhysicsJob::StepRecord *v18; // rax
  RBX::PhysicsJob::StepRecord *v19; // rax
  _QWORD v20[8]; // [rsp+8h] [rbp-40h] BYREF

  m_buff = this->m_buff;
  m_end = this->m_end;
  v4 = 0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)this->m_buff) >> 3);
  if ( v4 == new_capacity )
    return;
  v5 = new_capacity;
  if ( new_capacity >= 0xAAAAAAAAAAAAAABLL )
  {
    std::logic_error::logic_error((std::logic_error *)v20, "circular_buffer");
    v20[0] = (char *)&`vtable for'std::length_error + 16;
    boost::throw_exception<std::length_error>((const std::length_error *)v20);
  }
  if ( new_capacity )
    v7 = (RBX::PhysicsJob::StepRecord *)operator new(24 * new_capacity);
  else
    v7 = 0;
  m_size = this->m_size;
  if ( m_size )
    m_first = this->m_first;
  else
    m_first = 0;
  if ( m_size < new_capacity )
    new_capacity = this->m_size;
  if ( (__int64)new_capacity <= 0 )
  {
    v10 = m_first;
    if ( (new_capacity & 0x8000000000000000LL) != 0LL )
    {
      m_last = m_first;
      v12 = m_first;
      if ( !m_first )
      {
        m_last = this->m_last;
        v12 = m_last;
      }
      v13 = 0;
      if ( (__int64)(0xAAAAAAAAAAAAAAABLL * (((char *)m_last - (char *)m_buff) >> 3)) < -(__int64)new_capacity )
        v13 = v4;
      v10 = &v12[new_capacity + v13];
    }
  }
  else
  {
    if ( (__int64)(0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)m_first) >> 3)) > (__int64)new_capacity )
      v4 = 0;
    v10 = &m_first[new_capacity - v4];
    if ( v10 == this->m_last )
      v10 = 0;
  }
  v14 = v7;
  if ( m_first == v10 )
  {
    if ( m_size )
      goto LABEL_33;
    goto LABEL_44;
  }
  do
  {
    *(_QWORD *)&v14->timeInterval = *(_QWORD *)&m_first->timeInterval;
    *(_OWORD *)&v14->beginTime.sec = *(_OWORD *)&m_first->beginTime.sec;
    ++m_first;
    m_end = this->m_end;
    if ( m_first != m_end )
    {
      if ( m_first != this->m_last )
        goto LABEL_31;
LABEL_30:
      m_first = 0;
      goto LABEL_31;
    }
    m_first = this->m_buff;
    if ( this->m_buff == this->m_last )
      goto LABEL_30;
LABEL_31:
    ++v14;
  }
  while ( m_first != v10 );
  m_size = this->m_size;
  if ( m_size )
  {
LABEL_33:
    v15 = this->m_first;
    if ( m_size != 1 )
    {
      v16 = (m_size & 1) - m_size;
      do
      {
        while ( 1 )
        {
          v17 = v15 + 1;
          this->m_first = v17;
          if ( v17 == m_end )
          {
            v17 = this->m_buff;
            this->m_first = this->m_buff;
          }
          v15 = v17 + 1;
          this->m_first = v15;
          if ( v15 == m_end )
            break;
          v16 += 2LL;
          if ( !v16 )
            goto LABEL_41;
        }
        v15 = this->m_buff;
        this->m_first = this->m_buff;
        v16 += 2LL;
      }
      while ( v16 );
    }
LABEL_41:
    if ( (m_size & 1) != 0 )
    {
      v18 = v15 + 1;
      this->m_first = v18;
      if ( v18 == m_end )
        this->m_first = this->m_buff;
    }
  }
LABEL_44:
  if ( this->m_buff )
    operator delete(this->m_buff);
  this->m_size = 0xAAAAAAAAAAAAAAABLL * (((char *)v14 - (char *)v7) >> 3);
  this->m_buff = v7;
  this->m_first = v7;
  v19 = &v7[v5];
  this->m_end = v19;
  if ( v19 == v14 )
    v14 = v7;
  this->m_last = v14;
}


// Address: 0x130e750 | Name: _ZNK3RBX10PhysicsJob21averageStepsPerSecondEv
double __fastcall RBX::PhysicsJob::averageStepsPerSecond(const RBX::PhysicsJob *this)
{
  float v1; // xmm0_4
  __int64 v2; // rcx
  __int64 v3; // rsi
  unsigned __int64 v4; // rdx
  double v5; // xmm2_8
  float v6; // xmm1_4
  double *v7; // rax

  v1 = 1.0;
  if ( *((_QWORD *)this + 62) )
  {
    v2 = *((_QWORD *)this + 60);
    if ( v2 )
    {
      v3 = *((_QWORD *)this + 58);
      v4 = -1;
      if ( *((_QWORD *)this + 61) - v3 <= 23 )
        v4 = 0xAAAAAAAAAAAAAAABLL * ((*((_QWORD *)this + 59) - v3) >> 3) - 1;
      v5 = *(double *)(*((_QWORD *)this + 61) + 24 * v4 + 8);
      v6 = 0.0;
      do
      {
        v6 = v6 + *(float *)(v2 + 16);
        v2 += 24;
        if ( v2 == *((_QWORD *)this + 59) )
          v2 = *((_QWORD *)this + 58);
        if ( v2 == *((_QWORD *)this + 61) )
          v2 = 0;
      }
      while ( v2 );
    }
    else
    {
      v5 = 0.0;
      v6 = 0.0;
    }
    v7 = (double *)*((_QWORD *)this + 60);
    if ( v7 )
      v1 = v5 - *v7;
  }
  else
  {
    v6 = 0.0;
  }
  return (float)((float)(v6 / v1) * 60.0);
}


// Address: 0x1595f90 | Name: _ZNK3RBX25WindowAverageTimeIntervalILNS_4Time12SampleMethodE1EE8getStatsEm
RBX::WindowAverageTimeInterval<RBX::Time::Benchmark>::Stats *__fastcall RBX::WindowAverageTimeInterval<(RBX::Time::SampleMethod)1>::getStats(
        RBX::WindowAverageTimeInterval<RBX::Time::Benchmark>::Stats *__return_ptr retstr,
        const RBX::WindowAverageTimeInterval<RBX::Time::Benchmark> *this,
        size_t samples)
{
  boost::circular_buffer<double,std::allocator<double> >::size_type m_size; // r8
  size_t v4; // r9
  double v5; // xmm0_8
  double v6; // xmm1_8
  double v7; // xmm2_8
  boost::circular_buffer<double,std::allocator<double> >::pointer m_buff; // r10
  double v9; // xmm1_8
  __int64 v10; // r11
  boost::circular_buffer<double,std::allocator<double> >::pointer m_end; // rcx
  boost::circular_buffer<double,std::allocator<double> >::pointer v12; // rax
  __m128i v13; // xmm2
  __int64 v14; // r11
  boost::circular_buffer<double,std::allocator<double> >::pointer v15; // rcx
  boost::circular_buffer<double,std::allocator<double> >::pointer m_last; // rax
  __m128i v17; // xmm3
  boost::circular_buffer<double,std::allocator<double> >::pointer m_first; // rax
  __m128i v19; // xmm3

  m_size = this->average.buffer.m_size;
  v4 = m_size;
  if ( m_size > samples )
    v4 = samples;
  v5 = 0.0;
  v6 = 0.0;
  v7 = 0.0;
  if ( v4 )
  {
    m_buff = this->average.buffer.m_buff;
    v9 = 0.0;
    v10 = 0;
    m_end = 0;
    while ( 1 )
    {
      v12 = m_end;
      if ( !m_end )
        break;
      if ( m_end == m_buff )
        goto LABEL_6;
LABEL_11:
      v9 = v9 + *(v12 - 1);
      if ( m_end )
      {
        if ( m_end != m_buff )
          goto LABEL_13;
LABEL_8:
        m_end = this->average.buffer.m_end;
        goto LABEL_13;
      }
      m_end = this->average.buffer.m_last;
      if ( m_end == m_buff )
        goto LABEL_8;
LABEL_13:
      --m_end;
      if ( ++v10 >= v4 )
      {
        v13 = (__m128i)_mm_sub_pd(
                         (__m128d)_mm_unpacklo_epi32((__m128i)v4, (__m128i)xmmword_3E4930),
                         *(__m128d *)(&errorFunction.functor.data + 8));
        v6 = v9 / (*(double *)_mm_shuffle_epi32(v13, 78).m128i_i64 + *(double *)v13.m128i_i64);
        v7 = 0.0;
        v14 = 0;
        v15 = 0;
        while ( 1 )
        {
          m_last = v15;
          if ( v15 )
            break;
          m_last = this->average.buffer.m_last;
          if ( m_last == m_buff )
            goto LABEL_16;
LABEL_19:
          if ( !v15 )
            v15 = this->average.buffer.m_last;
          if ( v15 == m_buff )
            v15 = this->average.buffer.m_end;
          v7 = v7 + (v6 - *(m_last - 1)) * (v6 - *(m_last - 1));
          --v15;
          if ( ++v14 >= v4 )
          {
            if ( v4 >= 2 )
            {
              v17 = (__m128i)_mm_sub_pd(
                               (__m128d)_mm_unpacklo_epi32((__m128i)(v4 - 1), (__m128i)xmmword_3E4930),
                               *(__m128d *)(&errorFunction.functor.data + 8));
              v7 = v7 / (*(double *)_mm_shuffle_epi32(v17, 78).m128i_i64 + *(double *)v17.m128i_i64);
            }
            goto LABEL_26;
          }
        }
        if ( v15 != m_buff )
          goto LABEL_19;
LABEL_16:
        m_last = this->average.buffer.m_end;
        goto LABEL_19;
      }
    }
    v12 = this->average.buffer.m_last;
    if ( v12 != m_buff )
      goto LABEL_11;
LABEL_6:
    v12 = this->average.buffer.m_end;
    goto LABEL_11;
  }
LABEL_26:
  if ( m_size )
  {
    m_first = this->average.buffer.m_first;
    if ( m_first )
    {
      v5 = 0.0;
      do
      {
        v5 = v5 + *m_first++;
        if ( m_first == this->average.buffer.m_end )
          m_first = this->average.buffer.m_buff;
        if ( m_first == this->average.buffer.m_last )
          m_first = 0;
      }
      while ( m_first );
    }
  }
  v19 = (__m128i)_mm_sub_pd(
                   (__m128d)_mm_unpacklo_epi32((__m128i)samples, (__m128i)xmmword_3E4930),
                   *(__m128d *)(&errorFunction.functor.data + 8));
  retstr->samples = v4;
  retstr->average.sec = v6;
  retstr->variance.sec = v7;
  retstr->sum.sec = v5;
  retstr->samplespersecond = (*(double *)_mm_shuffle_epi32(v19, 78).m128i_i64 + *(double *)v19.m128i_i64) / v5;
  return retstr;
}


// Address: 0x1880620 | Name: _ZN5boost15circular_bufferIN3RBX18StandardOutMessageENSt3__19allocatorIS2_EEE6reraseENS_10cb_details8iteratorIS6_NS7_15nonconst_traitsINS_9container16allocator_traitsIS5_EEEEEESE_
boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> > *__fastcall boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage>>::rerase(
        boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> > *this,
        boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::iterator first,
        boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::iterator last,
        const void *a4)
{
  boost::cb_details::iterator<boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >,boost::cb_details::nonconst_traits<boost::container::allocator_traits<std::allocator<RBX::StandardOutMessage> > > >::pointer m_it; // r12
  RBX::StandardOutMessage *v5; // rax
  RBX::StandardOutMessage *m_end; // rbx
  const boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> > *m_buff; // r15
  int v8; // edx
  void *v9; // rcx
  size_t v10; // r8
  const void *v11; // r9
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer v12; // rbp
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer v13; // rax
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::size_type v14; // rcx
  RBX::StandardOutMessage *v15; // rdx
  RBX::StandardOutMessage *v16; // rdx

  m_it = first.m_it;
  v5 = (RBX::StandardOutMessage *)*((_QWORD *)first.m_it + 1);
  m_end = last.m_buff->m_end;
  if ( v5 == m_end )
  {
    this->m_buff = *(boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer *)first.m_it;
    this->m_end = v5;
  }
  else
  {
    m_buff = last.m_buff;
    if ( !m_end )
      m_end = first.m_buff->m_last;
    last.m_buff->m_end = m_end;
    while ( 1 )
    {
      v12 = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)*((_QWORD *)m_it + 1);
      if ( v12 == first.m_buff->m_first )
        break;
      if ( v12 == first.m_buff->m_buff )
      {
        v12 = first.m_buff->m_end;
        *((_QWORD *)m_it + 1) = v12;
      }
      *((_QWORD *)m_it + 1) = (char *)v12 - 64;
      if ( m_end == first.m_buff->m_buff )
        m_end = first.m_buff->m_end;
      *((_QWORD *)m_end - 8) = *((_QWORD *)v12 - 8);
      std::string::operator=(
        (soap *)((char *)m_end - 56),
        (_DWORD)v12 - 56,
        (int)first.m_it,
        (void *)last.m_buff,
        (size_t)last.m_it,
        a4);
      std::string::operator=((soap *)((char *)m_end - 32), (_DWORD)v12 - 32, v8, v9, v10, v11);
      *((_QWORD *)m_end - 1) = *((_QWORD *)v12 - 1);
      m_end = (RBX::StandardOutMessage *)((char *)m_end - 64);
    }
    do
    {
      if ( (*((_BYTE *)v12 + 32) & 1) != 0 )
        operator delete(*((void **)v12 + 6));
      if ( (*((_BYTE *)v12 + 8) & 1) != 0 )
        operator delete(*((void **)v12 + 3));
      v13 = first.m_buff->m_end;
      v12 = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)((char *)first.m_buff->m_first + 64);
      first.m_buff->m_first = v12;
      if ( v12 == v13 )
      {
        v12 = first.m_buff->m_buff;
        first.m_buff->m_first = first.m_buff->m_buff;
      }
      v14 = first.m_buff->m_size - 1;
      first.m_buff->m_size = v14;
    }
    while ( v12 != m_end );
    v15 = m_buff->m_end;
    if ( m_end == v15 )
    {
      if ( !v14 )
        m_end = 0;
      this->m_buff = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)first.m_buff;
      this->m_end = m_end;
    }
    else
    {
      if ( v15 == first.m_buff->m_buff )
      {
        m_buff->m_end = v13;
        v15 = v13;
      }
      v16 = (RBX::StandardOutMessage *)((char *)v15 - 64);
      m_buff->m_end = v16;
      this->m_buff = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)first.m_buff;
      this->m_end = v16;
    }
  }
  return this;
}


// Address: 0x1880760 | Name: _ZN5boost15circular_bufferIN3RBX18StandardOutMessageENSt3__19allocatorIS2_EEE12set_capacityEm
void __fastcall boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage>>::set_capacity(
        boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> > *this,
        boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::capacity_type new_capacity)
{
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer m_buff; // r13
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer m_end; // rbp
  __int64 v4; // rbx
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::capacity_type v5; // r14
  RBX::StandardOutMessage *v7; // r15
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::capacity_type m_size; // rcx
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer m_first; // rax
  RBX::StandardOutMessage *v10; // rsi
  RBX::StandardOutMessage *v11; // rdx
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer m_last; // rdi
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer v13; // r8
  __int64 v14; // rdx
  RBX::StandardOutMessage *v15; // rbx
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer v16; // rbp
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::size_type v17; // r13
  RBX::StandardOutMessage *v18; // r14
  _QWORD v19[8]; // [rsp+8h] [rbp-40h] BYREF

  m_buff = this->m_buff;
  m_end = this->m_end;
  v4 = (m_end - this->m_buff) >> 6;
  if ( v4 != new_capacity )
  {
    v5 = new_capacity;
    if ( new_capacity >> 58 )
    {
      std::logic_error::logic_error((std::logic_error *)v19, "circular_buffer");
      v19[0] = (char *)&`vtable for'std::length_error + 16;
      boost::throw_exception<std::length_error>((const std::length_error *)v19);
    }
    if ( new_capacity )
      v7 = (RBX::StandardOutMessage *)operator new(new_capacity << 6);
    else
      v7 = 0;
    m_size = this->m_size;
    if ( m_size )
      m_first = this->m_first;
    else
      m_first = 0;
    if ( m_size < new_capacity )
      new_capacity = this->m_size;
    if ( (__int64)new_capacity <= 0 )
    {
      v11 = m_first;
      if ( (new_capacity & 0x8000000000000000LL) != 0LL )
      {
        m_last = m_first;
        v13 = m_first;
        if ( !m_first )
        {
          m_last = this->m_last;
          v13 = m_last;
        }
        v14 = 0;
        if ( (m_last - m_buff) >> 6 < -(__int64)new_capacity )
          v14 = v4;
        v11 = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)((char *)v13 + 64 * (new_capacity + v14));
      }
    }
    else
    {
      if ( (m_end - m_first) >> 6 > (__int64)new_capacity )
        v4 = 0;
      v10 = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)((char *)m_first + 64 * (new_capacity - v4));
      if ( v10 == this->m_last )
        v10 = 0;
      v11 = v10;
    }
    v15 = v7;
    if ( m_first != v11 )
    {
      v15 = v7;
      while ( 1 )
      {
        *(_QWORD *)v15 = *(_QWORD *)m_first;
        *((_QWORD *)v15 + 3) = *((_QWORD *)m_first + 3);
        *(_OWORD *)((char *)v15 + 8) = *(_OWORD *)((char *)m_first + 8);
        *(_OWORD *)((char *)m_first + 8) = 0;
        *((_QWORD *)m_first + 3) = 0;
        *((_QWORD *)v15 + 6) = *((_QWORD *)m_first + 6);
        *((_OWORD *)v15 + 2) = *((_OWORD *)m_first + 2);
        *((_OWORD *)m_first + 2) = 0;
        *((_QWORD *)m_first + 6) = 0;
        *((_QWORD *)v15 + 7) = *((_QWORD *)m_first + 7);
        m_first = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)((char *)m_first + 64);
        if ( m_first == this->m_end )
          break;
        if ( m_first == this->m_last )
          goto LABEL_29;
LABEL_30:
        v15 = (RBX::StandardOutMessage *)((char *)v15 + 64);
        if ( m_first == v11 )
        {
          m_size = this->m_size;
          goto LABEL_32;
        }
      }
      m_first = this->m_buff;
      if ( this->m_buff != this->m_last )
        goto LABEL_30;
LABEL_29:
      m_first = 0;
      goto LABEL_30;
    }
LABEL_32:
    if ( m_size )
    {
      v16 = this->m_first;
      v17 = 0;
      do
      {
        while ( 1 )
        {
          if ( (*((_BYTE *)v16 + 32) & 1) != 0 )
            operator delete(*((void **)v16 + 6));
          if ( (*((_BYTE *)v16 + 8) & 1) != 0 )
            operator delete(*((void **)v16 + 3));
          ++v17;
          v16 = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)((char *)this->m_first + 64);
          this->m_first = v16;
          if ( v16 == this->m_end )
            break;
          if ( v17 >= this->m_size )
            goto LABEL_42;
        }
        v16 = this->m_buff;
        this->m_first = this->m_buff;
      }
      while ( v17 < this->m_size );
    }
LABEL_42:
    if ( this->m_buff )
      operator delete(this->m_buff);
    this->m_size = (v15 - v7) >> 6;
    this->m_buff = v7;
    this->m_first = v7;
    v18 = (RBX::StandardOutMessage *)((char *)v7 + 64 * v5);
    this->m_end = v18;
    if ( v18 == v15 )
      v15 = v7;
    this->m_last = v15;
  }
}


// Address: 0x18809c0 | Name: _ZN5boost15circular_bufferIN3RBX18StandardOutMessageENSt3__19allocatorIS2_EEE14push_back_implIRKS2_EEvT_
void __fastcall boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage>>::push_back_impl<RBX::StandardOutMessage const&>(
        boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> > *this,
        const RBX::StandardOutMessage *item)
{
  int v2; // edx
  size_t v3; // r8
  const void *v4; // r9
  signed __int64 v5; // rcx
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer m_last; // r15
  int v7; // edx
  void *v8; // rcx
  size_t v9; // r8
  const void *v10; // r9
  RBX::StandardOutMessage *m_buff; // rax
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer v12; // r12
  RBX::StandardOutMessage *v13; // rax

  v5 = (this->m_end - this->m_buff) >> 6;
  if ( v5 == this->m_size )
  {
    if ( this->m_end != this->m_buff )
    {
      m_last = this->m_last;
      *(_QWORD *)m_last = *(_QWORD *)item;
      std::string::operator=((soap *)((char *)m_last + 8), (_DWORD)item + 8, v2, (void *)v5, v3, v4);
      std::string::operator=((soap *)((char *)m_last + 32), (_DWORD)item + 32, v7, v8, v9, v10);
      *((_QWORD *)m_last + 7) = *((_QWORD *)item + 7);
      m_buff = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)((char *)this->m_last + 64);
      this->m_last = m_buff;
      if ( m_buff == this->m_end )
      {
        m_buff = this->m_buff;
        this->m_last = this->m_buff;
      }
      this->m_first = m_buff;
    }
  }
  else
  {
    v12 = this->m_last;
    *(_QWORD *)v12 = *(_QWORD *)item;
    std::string::basic_string((char *)v12 + 8, (char *)item + 8);
    std::string::basic_string((char *)v12 + 32, (char *)item + 32);
    *((_QWORD *)v12 + 7) = *((_QWORD *)item + 7);
    v13 = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)((char *)this->m_last + 64);
    this->m_last = v13;
    if ( v13 == this->m_end )
      this->m_last = this->m_buff;
    ++this->m_size;
  }
}


// Address: 0x1880ac0 | Name: _ZN5boost15circular_bufferINS_10shared_ptrINS_9unordered13unordered_mapINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairIKSA_SD_EEEEEEEENS8_ISN_EEE6reraseENS_10cb_details8iteratorISP_NSQ_15nonconst_traitsINS_9container16allocator_traitsISO_EEEEEESX_
boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *__fastcall boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>>::rerase(
        boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *this,
        boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::iterator first,
        boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::iterator last)
{
  boost::cb_details::iterator<boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >,boost::cb_details::nonconst_traits<boost::container::allocator_traits<std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > > >::pointer m_it; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *m_end; // rbp
  const boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *m_buff; // r15
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer v7; // rax
  boost::detail::sp_counted_base *v8; // rax
  volatile signed __int32 *v9; // rbx
  volatile signed __int32 *v10; // rbx
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *v11; // rax

  m_it = first.m_it;
  pi = first.m_it->pn.pi_;
  m_end = last.m_buff->m_end;
  if ( pi == (boost::detail::sp_counted_base *)m_end )
  {
    this->m_buff = (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer)first.m_it->px;
LABEL_29:
    this->m_end = (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer)pi;
    return this;
  }
  m_buff = last.m_buff;
  if ( !m_end )
    m_end = first.m_buff->m_last;
  last.m_buff->m_end = m_end;
  while ( 1 )
  {
    v7 = (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer)m_it->pn.pi_;
    if ( v7 == first.m_buff->m_first )
      break;
    if ( v7 == first.m_buff->m_buff )
    {
      v7 = first.m_buff->m_end;
      m_it->pn.pi_ = (boost::detail::sp_counted_base *)v7;
    }
    m_it->pn.pi_ = (boost::detail::sp_counted_base *)&v7[-1];
    if ( m_end == first.m_buff->m_buff )
      m_end = first.m_buff->m_end;
    last.m_buff = (const boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *)v7[-1].px;
    v8 = v7[-1].pn.pi_;
    if ( v8 )
      _InterlockedAdd(&v8->use_count_, 1u);
    m_end[-1].px = (boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >::element_type *)last.m_buff;
    v9 = (volatile signed __int32 *)m_end[-1].pn.pi_;
    m_end[-1].pn.pi_ = v8;
    if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, const boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *, boost::cb_details::iterator<boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >,boost::cb_details::nonconst_traits<boost::container::allocator_traits<std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > > >::pointer, const boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *, boost::cb_details::iterator<boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >,boost::cb_details::nonconst_traits<boost::container::allocator_traits<std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > > >::pointer))(*(_QWORD *)v9 + 16LL))(
        v9,
        first.m_buff,
        first.m_it,
        last.m_buff,
        last.m_it);
      if ( !_InterlockedSub(v9 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
    }
    --m_end;
  }
  do
  {
    v10 = (volatile signed __int32 *)v7->pn.pi_;
    if ( v10 )
    {
      if ( !_InterlockedSub(v10 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *, const boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *, boost::cb_details::iterator<boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >,boost::cb_details::nonconst_traits<boost::container::allocator_traits<std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > > >::pointer, const boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *, boost::cb_details::iterator<boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >,boost::cb_details::nonconst_traits<boost::container::allocator_traits<std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > > >::pointer))(*(_QWORD *)v10 + 16LL))(
          v10,
          first.m_buff,
          first.m_it,
          last.m_buff,
          last.m_it);
        if ( !_InterlockedSub(v10 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
      }
    }
    last.m_buff = (const boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *)first.m_buff->m_end;
    v7 = first.m_buff->m_first + 1;
    first.m_buff->m_first = v7;
    if ( v7 == (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer)last.m_buff )
    {
      v7 = first.m_buff->m_buff;
      first.m_buff->m_first = first.m_buff->m_buff;
    }
    first.m_it = (boost::cb_details::iterator<boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >,boost::cb_details::nonconst_traits<boost::container::allocator_traits<std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > > >::pointer)(first.m_buff->m_size - 1);
    first.m_buff->m_size = (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::size_type)first.m_it;
  }
  while ( v7 != m_end );
  v11 = m_buff->m_end;
  if ( m_end != v11 )
  {
    if ( v11 == first.m_buff->m_buff )
    {
      m_buff->m_end = (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer)last.m_buff;
      v11 = (boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *)last.m_buff;
    }
    pi = (boost::detail::sp_counted_base *)&v11[-1];
    m_buff->m_end = (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer)pi;
    this->m_buff = (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer)first.m_buff;
    goto LABEL_29;
  }
  if ( !first.m_it )
    m_end = 0;
  this->m_buff = (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer)first.m_buff;
  this->m_end = m_end;
  return this;
}


// Address: 0x1880c40 | Name: _ZN5boost15circular_bufferINS_10shared_ptrINS_9unordered13unordered_mapINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairIKSA_SD_EEEEEEEENS8_ISN_EEE12set_capacityEm
void __fastcall boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>>::set_capacity(
        boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *this,
        boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::capacity_type new_capacity)
{
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer m_buff; // r12
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer m_end; // rbx
  __int64 v4; // rbp
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::capacity_type v5; // r14
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *v7; // r15
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::capacity_type m_size; // rax
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer m_first; // rcx
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *v10; // rsi
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *v11; // rdx
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer m_last; // rdi
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer v13; // r8
  __int64 v14; // rdx
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *v15; // rbp
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer v16; // rsi
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > v17; // xmm0
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer v18; // rax
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::size_type v19; // r12
  volatile signed __int32 *pi; // rbx
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *v21; // r14
  _QWORD v22[8]; // [rsp+8h] [rbp-40h] BYREF

  m_buff = this->m_buff;
  m_end = this->m_end;
  v4 = m_end - this->m_buff;
  if ( v4 != new_capacity )
  {
    v5 = new_capacity;
    if ( new_capacity >> 60 )
    {
      std::logic_error::logic_error((std::logic_error *)v22, "circular_buffer");
      v22[0] = (char *)&`vtable for'std::length_error + 16;
      boost::throw_exception<std::length_error>((const std::length_error *)v22);
    }
    if ( new_capacity )
      v7 = (boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *)operator new(16 * new_capacity);
    else
      v7 = 0;
    m_size = this->m_size;
    if ( m_size )
      m_first = this->m_first;
    else
      m_first = 0;
    if ( m_size < new_capacity )
      new_capacity = this->m_size;
    if ( (__int64)new_capacity <= 0 )
    {
      v11 = m_first;
      if ( (new_capacity & 0x8000000000000000LL) != 0LL )
      {
        m_last = m_first;
        v13 = m_first;
        if ( !m_first )
        {
          m_last = this->m_last;
          v13 = m_last;
        }
        v14 = 0;
        if ( m_last - m_buff < -(__int64)new_capacity )
          v14 = v4;
        v11 = &v13[new_capacity + v14];
      }
    }
    else
    {
      if ( m_end - m_first > (__int64)new_capacity )
        v4 = 0;
      v10 = &m_first[new_capacity - v4];
      if ( v10 == this->m_last )
        v10 = 0;
      v11 = v10;
    }
    v15 = v7;
    if ( m_first != v11 )
    {
      v16 = this->m_last;
      v15 = v7;
      do
      {
        v15->pn.pi_ = 0;
        v17 = *m_first;
        m_first->pn.pi_ = 0;
        *v15 = v17;
        m_first->px = 0;
        if ( ++m_first == m_end )
          m_first = m_buff;
        if ( m_first == v16 )
          m_first = 0;
        ++v15;
      }
      while ( m_first != v11 );
    }
    if ( m_size )
    {
      v18 = this->m_first;
      v19 = 0;
      do
      {
        while ( 1 )
        {
          pi = (volatile signed __int32 *)v18->pn.pi_;
          if ( pi )
          {
            if ( !_InterlockedSub(pi + 2, 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
              if ( !_InterlockedSub(pi + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
            }
          }
          ++v19;
          v18 = this->m_first + 1;
          this->m_first = v18;
          if ( v18 == this->m_end )
            break;
          if ( v19 >= this->m_size )
            goto LABEL_40;
        }
        v18 = this->m_buff;
        this->m_first = this->m_buff;
      }
      while ( v19 < this->m_size );
LABEL_40:
      m_buff = this->m_buff;
    }
    if ( m_buff )
      operator delete(m_buff);
    this->m_size = v15 - v7;
    this->m_buff = v7;
    this->m_first = v7;
    v21 = &v7[v5];
    this->m_end = v21;
    if ( v21 == v15 )
      v15 = v7;
    this->m_last = v15;
  }
}


// Address: 0x1880e80 | Name: _ZN5boost15circular_bufferINS_10shared_ptrINS_9unordered13unordered_mapINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairIKSA_SD_EEEEEEEENS8_ISN_EEE14push_back_implIRKSN_EEvT_
void __fastcall boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>>::push_back_impl<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>> const&>(
        boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *this,
        const boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *item)
{
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer m_end; // rax
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer m_last; // rax
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >::element_type *px; // rdx
  boost::detail::sp_counted_base *pi; // rcx
  volatile signed __int32 *v6; // r14
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *m_buff; // rax
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer v8; // rdx
  boost::detail::sp_counted_base *v9; // rcx
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *v10; // rcx

  m_end = this->m_end;
  if ( m_end - this->m_buff == this->m_size )
  {
    if ( this->m_end != this->m_buff )
    {
      m_last = this->m_last;
      px = item->px;
      pi = item->pn.pi_;
      if ( pi )
        _InterlockedAdd(&pi->use_count_, 1u);
      m_last->px = px;
      v6 = (volatile signed __int32 *)m_last->pn.pi_;
      m_last->pn.pi_ = pi;
      if ( v6 )
      {
        if ( !_InterlockedSub(v6 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
          if ( !_InterlockedSub(v6 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
        }
      }
      m_buff = this->m_last + 1;
      this->m_last = m_buff;
      if ( m_buff == this->m_end )
      {
        m_buff = this->m_buff;
        this->m_last = this->m_buff;
      }
      this->m_first = m_buff;
    }
  }
  else
  {
    v8 = this->m_last;
    v8->px = item->px;
    v9 = item->pn.pi_;
    v8->pn.pi_ = v9;
    if ( v9 )
    {
      _InterlockedAdd(&v9->use_count_, 1u);
      m_end = this->m_end;
    }
    v10 = this->m_last + 1;
    this->m_last = v10;
    if ( v10 == m_end )
      this->m_last = this->m_buff;
    ++this->m_size;
  }
}


// Address: 0x1e171e0 | Name: _ZN3RBX18NetworkPhysicsData25frameBufferPopFrontIfFullEv
void __fastcall RBX::NetworkPhysicsData::frameBufferPopFrontIfFull(RBX::NetworkPhysicsData_0 *this)
{
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type m_size; // r9
  RBX::NetworkPhysicsData::NetworkFrame *v2; // rdx
  RBX::NetworkPhysicsData::NetworkFrame *m_buff; // rax
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_end; // rcx
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type v5; // r9
  unsigned __int64 v6; // rcx
  unsigned __int64 m_min_capacity; // rsi
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::capacity_type m_capacity; // rsi

  m_size = this->frameBuffer.m_size;
  if ( m_size == dword_2868C60 )
  {
    v2 = this->frameBuffer.m_first + 1;
    this->frameBuffer.m_first = v2;
    m_buff = this->frameBuffer.m_buff;
    m_end = this->frameBuffer.m_end;
    if ( v2 == m_end )
      this->frameBuffer.m_first = m_buff;
    v5 = m_size - 1;
    this->frameBuffer.m_size = v5;
    v6 = 0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)m_buff) >> 5);
    while ( v6 / 3 >= v5 )
    {
      v6 >>= 1;
      m_min_capacity = this->frameBuffer.m_capacity_ctrl.m_min_capacity;
      if ( v6 <= m_min_capacity )
        goto LABEL_10;
    }
    m_min_capacity = v6;
LABEL_10:
    m_capacity = m_min_capacity << (v5 + m_min_capacity / 5 >= m_min_capacity);
    if ( m_capacity > this->frameBuffer.m_capacity_ctrl.m_capacity )
      m_capacity = this->frameBuffer.m_capacity_ctrl.m_capacity;
    boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>::set_capacity(
      &this->frameBuffer,
      m_capacity);
  }
}


// Address: 0x1e1e790 | Name: _ZNK3RBX18NetworkPhysicsData22getLastFramesDeltaTimeEv
float __fastcall RBX::NetworkPhysicsData::getLastFramesDeltaTime(const RBX::NetworkPhysicsData_0 *this)
{
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type m_size; // rcx
  float result; // xmm0_4
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_buff; // r8
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_last; // r9
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_end; // rax
  __int64 v6; // rsi
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_first; // rdi

  m_size = this->frameBuffer.m_size;
  result = 0.0;
  if ( (int)m_size >= 2 )
  {
    m_buff = this->frameBuffer.m_buff;
    m_last = this->frameBuffer.m_last;
    m_end = this->frameBuffer.m_end;
    if ( m_last == m_buff )
      m_last = this->frameBuffer.m_end;
    v6 = (__int64)((m_size << 32) - 0x200000000LL) >> 32;
    m_first = this->frameBuffer.m_first;
    if ( (__int64)(0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)m_first) >> 5)) <= v6 )
      v6 -= 0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)m_buff) >> 5);
    return m_last[-1].remoteTime.sec - m_first[v6].remoteTime.sec;
  }
  return result;
}


// Address: 0x1e222b0 | Name: _ZN5boost15circular_bufferIN3RBX4TimeENSt3__19allocatorIS2_EEEaSERKS6_
boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> > *__fastcall boost::circular_buffer<RBX::Time,std::allocator<RBX::Time>>::operator=(
        boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> > *this,
        const boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> > *cb)
{
  boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> >::pointer m_buff; // rbp
  boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> >::pointer m_end; // r12
  signed __int64 v5; // rdi
  RBX::Time *v6; // r14
  RBX::Time *v7; // rbx
  boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> >::pointer m_first; // rax
  boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> >::pointer m_last; // rcx
  boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> >::size_type m_size; // rdi
  boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> >::pointer v11; // rax
  RBX::Time *v12; // rcx
  boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> >::size_type v13; // rsi
  RBX::Time *v14; // rcx
  RBX::Time *v15; // rcx
  RBX::Time *v16; // rax
  signed __int64 v18; // [rsp+0h] [rbp-48h]
  _QWORD v19[8]; // [rsp+8h] [rbp-40h] BYREF

  if ( this != cb )
  {
    m_buff = cb->m_buff;
    m_end = cb->m_end;
    v5 = (char *)m_end - (char *)cb->m_buff;
    if ( (unsigned __int64)(v5 >> 3) >> 61 )
    {
      std::logic_error::logic_error((std::logic_error *)v19, "circular_buffer");
      v19[0] = (char *)&`vtable for'std::length_error + 16;
      boost::throw_exception<std::length_error>((const std::length_error *)v19);
    }
    v18 = cb->m_end - cb->m_buff;
    if ( v5 )
      v6 = (RBX::Time *)operator new(v5);
    else
      v6 = 0;
    v7 = v6;
    if ( cb->m_size )
    {
      m_first = cb->m_first;
      v7 = v6;
      if ( m_first )
      {
        m_last = cb->m_last;
        v7 = v6;
        do
        {
          v7->sec = m_first->sec;
          if ( ++m_first == m_end )
            m_first = m_buff;
          if ( m_first == m_last )
            m_first = 0;
          ++v7;
        }
        while ( m_first );
      }
    }
    m_size = this->m_size;
    if ( m_size )
    {
      v11 = this->m_end;
      v12 = this->m_first;
      if ( m_size != 1 )
      {
        v13 = (this->m_size & 1) - m_size;
        do
        {
          while ( 1 )
          {
            v14 = v12 + 1;
            this->m_first = v14;
            if ( v14 == v11 )
            {
              v14 = this->m_buff;
              this->m_first = this->m_buff;
            }
            v12 = v14 + 1;
            this->m_first = v12;
            if ( v12 == v11 )
              break;
            v13 += 2LL;
            if ( !v13 )
              goto LABEL_23;
          }
          v12 = this->m_buff;
          this->m_first = this->m_buff;
          v13 += 2LL;
        }
        while ( v13 );
      }
LABEL_23:
      if ( (m_size & 1) != 0 )
      {
        v15 = v12 + 1;
        this->m_first = v15;
        if ( v15 == v11 )
          this->m_first = this->m_buff;
      }
    }
    if ( this->m_buff )
      operator delete(this->m_buff);
    this->m_size = v7 - v6;
    this->m_buff = v6;
    this->m_first = v6;
    v16 = &v6[v18];
    this->m_end = v16;
    if ( v16 == v7 )
      v7 = v6;
    this->m_last = v7;
  }
  return this;
}


// Address: 0x1e23040 | Name: _ZN5boost15circular_bufferIN3RBX18NetworkPhysicsData12NetworkFrameENSt3__19allocatorIS3_EEE12set_capacityEm
void __fastcall boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>::set_capacity(
        boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *this,
        boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::capacity_type new_capacity)
{
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_buff; // r12
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_end; // r13
  unsigned __int64 v4; // rbp
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::capacity_type v5; // r14
  RBX::NetworkPhysicsData::NetworkFrame *v7; // r15
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::capacity_type m_size; // rcx
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_first; // rax
  RBX::NetworkPhysicsData::NetworkFrame *v10; // rdx
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_last; // rdi
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer v12; // r8
  unsigned __int64 v13; // rdx
  RBX::NetworkPhysicsData::NetworkFrame *v14; // rbp
  __int128 v15; // xmm0
  __int128 v16; // xmm1
  RBX::NetworkPhysicsData::NetworkFrame *v17; // rax
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::capacity_type v18; // rsi
  RBX::NetworkPhysicsData::NetworkFrame *v19; // rax
  RBX::NetworkPhysicsData::NetworkFrame *v20; // rax
  RBX::NetworkPhysicsData::NetworkFrame *v21; // rax
  _QWORD v22[8]; // [rsp+8h] [rbp-40h] BYREF

  m_buff = this->m_buff;
  m_end = this->m_end;
  v4 = 0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)this->m_buff) >> 5);
  if ( v4 == new_capacity )
    return;
  v5 = new_capacity;
  if ( new_capacity >= 0x2AAAAAAAAAAAAABLL )
  {
    std::logic_error::logic_error((std::logic_error *)v22, "circular_buffer");
    v22[0] = (char *)&`vtable for'std::length_error + 16;
    boost::throw_exception<std::length_error>((const std::length_error *)v22);
  }
  if ( new_capacity )
    v7 = (RBX::NetworkPhysicsData::NetworkFrame *)operator new(96 * new_capacity);
  else
    v7 = 0;
  m_size = this->m_size;
  if ( m_size )
    m_first = this->m_first;
  else
    m_first = 0;
  if ( m_size < new_capacity )
    new_capacity = this->m_size;
  if ( (__int64)new_capacity <= 0 )
  {
    v10 = m_first;
    if ( (new_capacity & 0x8000000000000000LL) != 0LL )
    {
      m_last = m_first;
      v12 = m_first;
      if ( !m_first )
      {
        m_last = this->m_last;
        v12 = m_last;
      }
      v13 = 0;
      if ( (__int64)(0xAAAAAAAAAAAAAAABLL * (((char *)m_last - (char *)m_buff) >> 5)) < -(__int64)new_capacity )
        v13 = v4;
      v10 = &v12[new_capacity + v13];
    }
  }
  else
  {
    if ( (__int64)(0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)m_first) >> 5)) > (__int64)new_capacity )
      v4 = 0;
    v10 = &m_first[new_capacity - v4];
    if ( v10 == this->m_last )
      v10 = 0;
  }
  v14 = v7;
  if ( m_first == v10 )
  {
    if ( m_size )
      goto LABEL_33;
    goto LABEL_44;
  }
  do
  {
    v14->replicationRootGuid.index = m_first->replicationRootGuid.index;
    *(_QWORD *)&v14->pendingSend = *(_QWORD *)&m_first->pendingSend;
    v15 = *(_OWORD *)&m_first->pv.position.rotation.elt[0][0];
    v16 = *(_OWORD *)&m_first->pv.position.rotation.elt[1][1];
    *(_OWORD *)&v14->pv.position.rotation.elt[2][2] = *(_OWORD *)&m_first->pv.position.rotation.elt[2][2];
    *(_OWORD *)&v14->pv.position.rotation.elt[1][1] = v16;
    *(_OWORD *)&v14->pv.position.rotation.elt[0][0] = v15;
    v14->pv.velocity.linear.z = m_first->pv.velocity.linear.z;
    *(_QWORD *)&v14->pv.velocity.linear.x = *(_QWORD *)&m_first->pv.velocity.linear.x;
    v14->pv.velocity.rotational.z = m_first->pv.velocity.rotational.z;
    *(_QWORD *)&v14->pv.velocity.rotational.x = *(_QWORD *)&m_first->pv.velocity.rotational.x;
    v14->remoteTime.sec = m_first->remoteTime.sec;
    ++m_first;
    m_end = this->m_end;
    if ( m_first != m_end )
    {
      if ( m_first != this->m_last )
        goto LABEL_31;
LABEL_30:
      m_first = 0;
      goto LABEL_31;
    }
    m_first = this->m_buff;
    if ( this->m_buff == this->m_last )
      goto LABEL_30;
LABEL_31:
    ++v14;
  }
  while ( m_first != v10 );
  m_size = this->m_size;
  if ( m_size )
  {
LABEL_33:
    v17 = this->m_first;
    if ( m_size != 1 )
    {
      v18 = (m_size & 1) - m_size;
      do
      {
        while ( 1 )
        {
          v19 = v17 + 1;
          this->m_first = v19;
          if ( v19 == m_end )
          {
            v19 = this->m_buff;
            this->m_first = this->m_buff;
          }
          v17 = v19 + 1;
          this->m_first = v17;
          if ( v17 == m_end )
            break;
          v18 += 2LL;
          if ( !v18 )
            goto LABEL_41;
        }
        v17 = this->m_buff;
        this->m_first = this->m_buff;
        v18 += 2LL;
      }
      while ( v18 );
    }
LABEL_41:
    if ( (m_size & 1) != 0 )
    {
      v20 = v17 + 1;
      this->m_first = v20;
      if ( v20 == m_end )
        this->m_first = this->m_buff;
    }
  }
LABEL_44:
  if ( this->m_buff )
    operator delete(this->m_buff);
  this->m_size = 0xAAAAAAAAAAAAAAABLL * (((char *)v14 - (char *)v7) >> 5);
  this->m_buff = v7;
  this->m_first = v7;
  v21 = &v7[v5];
  this->m_end = v21;
  if ( v21 == v14 )
    v14 = v7;
  this->m_last = v14;
}


// Address: 0x1e235c0 | Name: _ZN5boost15circular_bufferINSt3__13mapImN3RBX19NetworkDebugTracker20NetworkFramePrimDataENS1_4lessImEENS1_9allocatorINS1_4pairIKmS5_EEEEEENS8_ISD_EEE12set_capacityEm
void __fastcall boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>>>::set_capacity(
        boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > > *this,
        boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::capacity_type new_capacity)
{
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::pointer m_buff; // rbp
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::pointer m_end; // r12
  unsigned __int64 v4; // rbx
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::capacity_type v5; // r14
  std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *v7; // r15
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::capacity_type m_size; // rcx
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::pointer m_first; // rax
  std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *v10; // rdx
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::pointer m_last; // rdi
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::pointer v12; // r8
  signed __int64 v13; // rdi
  unsigned __int64 v14; // rbp
  std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *v15; // rbx
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer left; // rsi
  std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *p_pair1; // rcx
  unsigned __int64 value; // rdi
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::pointer v19; // rdi
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::size_type v20; // rbp
  std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *v21; // rax
  _QWORD v22[8]; // [rsp+8h] [rbp-40h] BYREF

  m_buff = this->m_buff;
  m_end = this->m_end;
  v4 = 0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)this->m_buff) >> 3);
  if ( v4 != new_capacity )
  {
    v5 = new_capacity;
    if ( new_capacity >= 0xAAAAAAAAAAAAAABLL )
    {
      std::logic_error::logic_error((std::logic_error *)v22, "circular_buffer");
      v22[0] = (char *)&`vtable for'std::length_error + 16;
      boost::throw_exception<std::length_error>((const std::length_error *)v22);
    }
    if ( new_capacity )
      v7 = (std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *)operator new(24 * new_capacity);
    else
      v7 = 0;
    m_size = this->m_size;
    if ( m_size )
      m_first = this->m_first;
    else
      m_first = 0;
    if ( m_size < new_capacity )
      new_capacity = this->m_size;
    if ( (__int64)new_capacity <= 0 )
    {
      v10 = m_first;
      if ( (new_capacity & 0x8000000000000000LL) != 0LL )
      {
        m_last = m_first;
        v12 = m_first;
        if ( !m_first )
        {
          m_last = this->m_last;
          v12 = m_last;
        }
        v13 = 0xAAAAAAAAAAAAAAABLL * (((char *)m_last - (char *)m_buff) >> 3);
        v14 = 0;
        if ( v13 < -(__int64)new_capacity )
          v14 = v4;
        v10 = &v12[new_capacity + v14];
      }
    }
    else
    {
      if ( (__int64)(0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)m_first) >> 3)) > (__int64)new_capacity )
        v4 = 0;
      v10 = &m_first[new_capacity - v4];
      if ( v10 == this->m_last )
        v10 = 0;
    }
    v15 = v7;
    if ( m_first != v10 )
    {
      v15 = v7;
      while ( 1 )
      {
        v15->__tree_.__begin_node_ = m_first->__tree_.__begin_node_;
        left = m_first->__tree_.__pair1_.__value_.__left_;
        p_pair1 = &v15->__tree_.__pair1_;
        v15->__tree_.__pair1_.__value_.__left_ = left;
        value = m_first->__tree_.__pair3_.__value_;
        v15->__tree_.__pair3_.__value_ = value;
        if ( value )
        {
          left->__parent_ = &p_pair1->__value_;
          m_first->__tree_.__begin_node_ = &m_first->__tree_.__pair1_.__value_;
          *(_OWORD *)&m_first->__tree_.__pair1_.__value_.__left_ = 0;
        }
        else
        {
          v15->__tree_.__begin_node_ = &p_pair1->__value_;
        }
        if ( ++m_first == this->m_end )
          break;
        if ( m_first == this->m_last )
          goto LABEL_32;
LABEL_33:
        ++v15;
        if ( m_first == v10 )
        {
          m_size = this->m_size;
          goto LABEL_35;
        }
      }
      m_first = this->m_buff;
      if ( this->m_buff != this->m_last )
        goto LABEL_33;
LABEL_32:
      m_first = 0;
      goto LABEL_33;
    }
LABEL_35:
    if ( m_size )
    {
      v19 = this->m_first;
      v20 = 0;
      do
      {
        while ( 1 )
        {
          std::__tree<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__map_value_compare<unsigned long,std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::less<unsigned long>,true>,std::allocator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>>>::destroy(
            &v19->__tree_,
            (std::__tree<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__map_value_compare<unsigned long,std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::less<unsigned long>,true>,std::allocator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::__node_pointer)v19->__tree_.__pair1_.__value_.__left_);
          ++v20;
          v19 = this->m_first + 1;
          this->m_first = v19;
          if ( v19 == this->m_end )
            break;
          if ( v20 >= this->m_size )
            goto LABEL_41;
        }
        v19 = this->m_buff;
        this->m_first = this->m_buff;
      }
      while ( v20 < this->m_size );
    }
LABEL_41:
    if ( this->m_buff )
      operator delete(this->m_buff);
    this->m_size = 0xAAAAAAAAAAAAAAABLL * (((char *)v15 - (char *)v7) >> 3);
    this->m_buff = v7;
    this->m_first = v7;
    v21 = &v7[v5];
    this->m_end = v21;
    if ( v21 == v15 )
      v15 = v7;
    this->m_last = v15;
  }
}


// Address: 0x1e23810 | Name: _ZN5boost15circular_bufferINSt3__13mapImN3RBX19NetworkDebugTracker20NetworkFramePrimDataENS1_4lessImEENS1_9allocatorINS1_4pairIKmS5_EEEEEENS8_ISD_EEE14push_back_implIRKSD_EEvT_
void __fastcall boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>>>::push_back_impl<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> const&>(
        boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > > *this,
        const std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *item)
{
  const std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *v2; // r15
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::pointer m_end; // rax
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::pointer m_last; // rdi
  std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *v6; // r15
  boost::circular_buffer<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::allocator<std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::pointer v7; // r13
  std::__tree<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__map_value_compare<unsigned long,std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::less<unsigned long>,true>,std::allocator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::__iter_pointer begin_node; // rbx
  _QWORD *p_left; // rcx
  const std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *left; // rax
  __int64 v11; // rbx
  bool v12; // zf
  std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *v13; // rax
  std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *m_buff; // rax

  v2 = item;
  m_end = this->m_end;
  if ( 0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)this->m_buff) >> 3) == this->m_size )
  {
    if ( this->m_end != this->m_buff )
    {
      m_last = this->m_last;
      if ( m_last != item )
      {
        std::__tree<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__map_value_compare<unsigned long,std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::less<unsigned long>,true>,std::allocator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>>>::__assign_multi<std::__tree_const_iterator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__tree_node<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,void *> *,long>>(
          &m_last->__tree_,
          (std::__tree_const_iterator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__tree_node<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,void *> *,long>)item->__tree_.__begin_node_,
          (std::__tree_const_iterator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__tree_node<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,void *> *,long>)&item->__tree_.__pair1_);
        m_end = this->m_end;
        v2 = this->m_last;
      }
      v6 = (std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *)&v2[1];
      this->m_last = v6;
      if ( v6 == m_end )
      {
        m_buff = this->m_buff;
        this->m_last = this->m_buff;
        this->m_first = m_buff;
      }
      else
      {
        this->m_first = v6;
      }
    }
  }
  else
  {
    v7 = this->m_last;
    *(_OWORD *)&v7->__tree_.__pair1_.__value_.__left_ = 0;
    v7->__tree_.__begin_node_ = &v7->__tree_.__pair1_.__value_;
    begin_node = item->__tree_.__begin_node_;
    if ( (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)item->__tree_.__begin_node_ != &item->__tree_.__pair1_ )
    {
      do
      {
        std::__tree<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__map_value_compare<unsigned long,std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::less<unsigned long>,true>,std::allocator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>>>::__emplace_hint_unique_key_args<unsigned long,std::pair<unsigned long const,RBX::NetworkDebugTracker::NetworkFramePrimData> const&>(
          &v7->__tree_,
          (std::__tree<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__map_value_compare<unsigned long,std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::less<unsigned long>,true>,std::allocator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::const_iterator_0)&v7->__tree_.__pair1_,
          (const unsigned __int64 *)&begin_node[4],
          (const std::pair<const unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *)&begin_node[4]);
        p_left = &begin_node[1].__left_->__left_;
        if ( p_left )
        {
          do
          {
            left = (const std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *)p_left;
            p_left = (_QWORD *)*p_left;
          }
          while ( p_left );
        }
        else
        {
          left = (const std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *)begin_node[2].__left_;
          if ( left->__tree_.__begin_node_ != begin_node )
          {
            v11 = (__int64)&begin_node[2];
            do
            {
              left = *(const std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> **)(*(_QWORD *)v11 + 16LL);
              v12 = left->__tree_.__begin_node_ == *(std::__tree<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__map_value_compare<unsigned long,std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::less<unsigned long>,true>,std::allocator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::__iter_pointer *)v11;
              v11 = *(_QWORD *)v11 + 16LL;
            }
            while ( !v12 );
          }
        }
        begin_node = (std::__tree<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::__map_value_compare<unsigned long,std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData>,std::less<unsigned long>,true>,std::allocator<std::__value_type<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> > >::__iter_pointer)left;
      }
      while ( left != (const std::map<unsigned long,RBX::NetworkDebugTracker::NetworkFramePrimData> *)&item->__tree_.__pair1_ );
    }
    v13 = this->m_last + 1;
    this->m_last = v13;
    if ( v13 == this->m_end )
      this->m_last = this->m_buff;
    ++this->m_size;
  }
}


// Address: 0x1e242d0 | Name: _ZN5boost15circular_bufferIN3RBX4TimeENSt3__19allocatorIS2_EEEC2ERKS6_
void __fastcall boost::circular_buffer<RBX::Time,std::allocator<RBX::Time>>::circular_buffer(
        boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> > *this,
        const boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> > *cb)
{
  signed __int64 v3; // rdi
  RBX::Time *v5; // rax
  RBX::Time *v6; // r8
  RBX::Time *v7; // rsi
  boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> >::pointer m_first; // rdx
  boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> >::pointer m_end; // rdi
  boost::circular_buffer<RBX::Time,std::allocator<RBX::Time> >::pointer m_last; // rcx
  _QWORD v11[5]; // [rsp+0h] [rbp-28h] BYREF

  this->m_size = cb->m_size;
  v3 = (char *)cb->m_end - (char *)cb->m_buff;
  if ( (unsigned __int64)(v3 >> 3) >> 61 )
  {
    std::logic_error::logic_error((std::logic_error *)v11, "circular_buffer");
    v11[0] = (char *)&`vtable for'std::length_error + 16;
    boost::throw_exception<std::length_error>((const std::length_error *)v11);
  }
  if ( v3 )
    v5 = (RBX::Time *)operator new(v3);
  else
    v5 = 0;
  this->m_buff = v5;
  v6 = &v5[v3 >> 3];
  this->m_end = v6;
  this->m_first = v5;
  v7 = v5;
  if ( cb->m_size )
  {
    m_first = cb->m_first;
    v7 = v5;
    if ( m_first )
    {
      m_end = cb->m_end;
      m_last = cb->m_last;
      v7 = v5;
      do
      {
        v7->sec = m_first->sec;
        if ( ++m_first == m_end )
          m_first = cb->m_buff;
        if ( m_first == m_last )
          m_first = 0;
        ++v7;
      }
      while ( m_first );
    }
  }
  this->m_last = v7;
  if ( v7 == v6 )
    this->m_last = v5;
}


// Address: 0x1e243c0 | Name: _ZN5boost15circular_bufferIN3RBX18NetworkPhysicsData12NetworkFrameENSt3__19allocatorIS3_EEE10initializeINS_10cb_details8iteratorIS7_NS9_12const_traitsINS_9container16allocator_traitsIS6_EEEEEEEEvmT_SH_m
void __fastcall boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>::initialize<boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>>>>(
        boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *this,
        boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::capacity_type buffer_capacity,
        boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > > > first,
        boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > > > last,
        boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type distance)
{
  boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > > >::pointer m_it; // r15
  boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > > >::pointer m_last; // rbx
  const boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *m_buff; // r12
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type v8; // r13
  RBX::NetworkPhysicsData::NetworkFrame *v9; // rax
  RBX::NetworkPhysicsData::NetworkFrame *m_end; // rcx
  __int64 v11; // rdx
  __int128 v12; // xmm0
  __int128 v13; // xmm1
  signed __int64 v14; // rdx
  _QWORD v15[8]; // [rsp+8h] [rbp-40h] BYREF

  if ( buffer_capacity >= 0x2AAAAAAAAAAAAABLL )
  {
    std::logic_error::logic_error((std::logic_error *)v15, "circular_buffer");
    v15[0] = (char *)&`vtable for'std::length_error + 16;
    boost::throw_exception<std::length_error>((const std::length_error *)v15);
  }
  m_it = last.m_it;
  m_last = first.m_it;
  m_buff = first.m_buff;
  v8 = buffer_capacity;
  if ( buffer_capacity )
    v9 = (RBX::NetworkPhysicsData::NetworkFrame *)operator new(96 * buffer_capacity);
  else
    v9 = 0;
  this->m_buff = v9;
  m_end = &v9[buffer_capacity];
  this->m_end = m_end;
  this->m_first = v9;
  v11 = distance - buffer_capacity;
  if ( distance <= buffer_capacity )
  {
    v8 = distance;
  }
  else if ( v11 <= 0 )
  {
    if ( v11 < 0 )
    {
      v14 = buffer_capacity - distance;
      if ( !m_last )
        m_last = m_buff->m_last;
      if ( (__int64)(0xAAAAAAAAAAAAAAABLL * (((char *)m_last - (char *)m_buff->m_buff) >> 5)) < v14 )
        v14 -= 0xAAAAAAAAAAAAAAABLL * (((char *)m_buff->m_end - (char *)m_buff->m_buff) >> 5);
      m_last -= v14;
    }
  }
  else
  {
    if ( (__int64)(0xAAAAAAAAAAAAAAABLL * (((char *)m_buff->m_end - (char *)m_last) >> 5)) <= v11 )
      v11 -= 0xAAAAAAAAAAAAAAABLL * (((char *)m_buff->m_end - (char *)m_buff->m_buff) >> 5);
    m_last += v11;
    if ( m_last == m_buff->m_last )
      m_last = 0;
  }
  this->m_size = v8;
  if ( m_last != m_it )
  {
    while ( 1 )
    {
      v9->replicationRootGuid.index = m_last->replicationRootGuid.index;
      *(_QWORD *)&v9->pendingSend = *(_QWORD *)&m_last->pendingSend;
      v12 = *(_OWORD *)&m_last->pv.position.rotation.elt[0][0];
      v13 = *(_OWORD *)&m_last->pv.position.rotation.elt[1][1];
      *(_OWORD *)&v9->pv.position.rotation.elt[2][2] = *(_OWORD *)&m_last->pv.position.rotation.elt[2][2];
      *(_OWORD *)&v9->pv.position.rotation.elt[1][1] = v13;
      *(_OWORD *)&v9->pv.position.rotation.elt[0][0] = v12;
      v9->pv.velocity.linear.z = m_last->pv.velocity.linear.z;
      *(_QWORD *)&v9->pv.velocity.linear.x = *(_QWORD *)&m_last->pv.velocity.linear.x;
      v9->pv.velocity.rotational.z = m_last->pv.velocity.rotational.z;
      *(_QWORD *)&v9->pv.velocity.rotational.x = *(_QWORD *)&m_last->pv.velocity.rotational.x;
      v9->remoteTime.sec = m_last->remoteTime.sec;
      if ( ++m_last == m_buff->m_end )
        break;
      if ( m_last == m_buff->m_last )
        goto LABEL_19;
LABEL_20:
      ++v9;
      if ( m_last == m_it )
      {
        m_end = this->m_end;
        goto LABEL_22;
      }
    }
    m_last = m_buff->m_buff;
    if ( m_buff->m_buff != m_buff->m_last )
      goto LABEL_20;
LABEL_19:
    m_last = 0;
    goto LABEL_20;
  }
LABEL_22:
  this->m_last = v9;
  if ( v9 == m_end )
    this->m_last = this->m_buff;
}


// Address: 0x1e24ba0 | Name: _ZN5boost15circular_bufferIN3RBX18NetworkPhysicsData12NetworkFrameENSt3__19allocatorIS3_EEE8assign_nINS_10cb_details12assign_rangeINS9_8iteratorIS7_NS9_12const_traitsINS_9container16allocator_traitsIS6_EEEEEES6_EEEEvmmRKT_
void __fastcall boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>::assign_n<boost::cb_details::assign_range<boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>>>,std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>>(
        boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *this,
        boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::capacity_type new_capacity,
        boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type n,
        const boost::cb_details::assign_range<boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > > >,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *fnc)
{
  char *p_pendingSend; // rbx
  RBX::NetworkPhysicsData::NetworkFrame *m_end; // rax
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type m_size; // rdi
  RBX::NetworkPhysicsData::NetworkFrame *m_first; // rdx
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type v11; // rcx
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type v12; // rsi
  RBX::NetworkPhysicsData::NetworkFrame *v13; // rdx
  RBX::NetworkPhysicsData::NetworkFrame *v14; // rdx
  RBX::NetworkPhysicsData::NetworkFrame *v15; // rdx
  __int64 v16; // rcx
  boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > > >::pointer m_it; // rdx
  boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > > >::pointer v18; // rcx
  const boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *m_buff; // rax
  __int128 v20; // xmm0
  __int128 v21; // xmm1
  boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > > >::pointer v23; // rcx
  boost::cb_details::iterator<boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >,boost::cb_details::const_traits<boost::container::allocator_traits<std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > > >::pointer v24; // rax
  const boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *v25; // rdx
  char *v26; // rsi
  __int128 v27; // xmm0
  __int128 v28; // xmm1
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type v29; // rdi
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer v30; // rax
  RBX::NetworkPhysicsData::NetworkFrame *v31; // rcx
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::size_type v32; // rsi
  RBX::NetworkPhysicsData::NetworkFrame *v33; // rcx
  RBX::NetworkPhysicsData::NetworkFrame *v34; // rcx
  signed __int64 v35; // rax
  signed __int64 v36; // rcx
  _QWORD v37[8]; // [rsp+8h] [rbp-40h] BYREF

  p_pendingSend = (char *)&this->m_buff->pendingSend;
  m_end = this->m_end;
  if ( 0xAAAAAAAAAAAAAAABLL * (((char *)m_end - (char *)this->m_buff) >> 5) == new_capacity )
  {
    m_size = this->m_size;
    if ( m_size )
    {
      m_first = this->m_first;
      v11 = this->m_size & 3;
      if ( m_size - 1 >= 3 )
      {
        v12 = v11 - m_size;
        do
        {
          while ( 1 )
          {
            v13 = m_first + 1;
            this->m_first = v13;
            if ( v13 == m_end )
            {
              this->m_first = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer)p_pendingSend;
              v13 = (RBX::NetworkPhysicsData::NetworkFrame *)p_pendingSend;
            }
            v14 = v13 + 1;
            this->m_first = v14;
            if ( v14 == m_end )
            {
              this->m_first = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer)p_pendingSend;
              v14 = (RBX::NetworkPhysicsData::NetworkFrame *)p_pendingSend;
            }
            v15 = v14 + 1;
            this->m_first = v15;
            if ( v15 == m_end )
            {
              this->m_first = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer)p_pendingSend;
              v15 = (RBX::NetworkPhysicsData::NetworkFrame *)p_pendingSend;
            }
            m_first = v15 + 1;
            this->m_first = m_first;
            if ( m_first == m_end )
              break;
            v12 += 4LL;
            if ( !v12 )
              goto LABEL_15;
          }
          this->m_first = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer)p_pendingSend;
          m_first = (RBX::NetworkPhysicsData::NetworkFrame *)p_pendingSend;
          v12 += 4LL;
        }
        while ( v12 );
      }
LABEL_15:
      if ( (m_size & 3) != 0 )
      {
        v16 = -(__int64)v11;
        do
        {
          while ( 1 )
          {
            this->m_first = ++m_first;
            if ( m_first == m_end )
              break;
            if ( !++v16 )
              goto LABEL_21;
          }
          this->m_first = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer)p_pendingSend;
          m_first = (RBX::NetworkPhysicsData::NetworkFrame *)p_pendingSend;
          ++v16;
        }
        while ( v16 );
      }
    }
LABEL_21:
    m_it = fnc->m_first.m_it;
    v18 = fnc->m_last.m_it;
    if ( m_it == v18 )
      goto LABEL_57;
    m_buff = fnc->m_first.m_buff;
    while ( 1 )
    {
      *((_DWORD *)p_pendingSend + 2) = m_it->replicationRootGuid.index;
      *(_QWORD *)p_pendingSend = *(_QWORD *)&m_it->pendingSend;
      v20 = *(_OWORD *)&m_it->pv.position.rotation.elt[0][0];
      v21 = *(_OWORD *)&m_it->pv.position.rotation.elt[1][1];
      *(_OWORD *)(p_pendingSend + 44) = *(_OWORD *)&m_it->pv.position.rotation.elt[2][2];
      *(_OWORD *)(p_pendingSend + 28) = v21;
      *(_OWORD *)(p_pendingSend + 12) = v20;
      *((_DWORD *)p_pendingSend + 17) = LODWORD(m_it->pv.velocity.linear.z);
      *(_QWORD *)(p_pendingSend + 60) = *(_QWORD *)&m_it->pv.velocity.linear.x;
      *((_DWORD *)p_pendingSend + 20) = LODWORD(m_it->pv.velocity.rotational.z);
      *((_QWORD *)p_pendingSend + 9) = *(_QWORD *)&m_it->pv.velocity.rotational.x;
      *((_QWORD *)p_pendingSend + 11) = *(_QWORD *)&m_it->remoteTime.sec;
      if ( ++m_it == m_buff->m_end )
        break;
      if ( m_it == m_buff->m_last )
        goto LABEL_27;
LABEL_28:
      p_pendingSend += 96;
      if ( m_it == v18 )
      {
        p_pendingSend = (char *)&this->m_buff->pendingSend;
        m_end = this->m_end;
        goto LABEL_57;
      }
    }
    m_it = m_buff->m_buff;
    if ( m_buff->m_buff != m_buff->m_last )
      goto LABEL_28;
LABEL_27:
    m_it = 0;
    goto LABEL_28;
  }
  if ( new_capacity >= 0x2AAAAAAAAAAAAABLL )
  {
    std::logic_error::logic_error((std::logic_error *)v37, "circular_buffer");
    v37[0] = (char *)&`vtable for'std::length_error + 16;
    boost::throw_exception<std::length_error>((const std::length_error *)v37);
  }
  if ( new_capacity )
    p_pendingSend = (char *)operator new(96 * new_capacity);
  else
    p_pendingSend = 0;
  v23 = fnc->m_first.m_it;
  v24 = fnc->m_last.m_it;
  if ( v23 != v24 )
  {
    v25 = fnc->m_first.m_buff;
    v26 = p_pendingSend;
    while ( 1 )
    {
      *((_DWORD *)v26 + 2) = v23->replicationRootGuid.index;
      *(_QWORD *)v26 = *(_QWORD *)&v23->pendingSend;
      v27 = *(_OWORD *)&v23->pv.position.rotation.elt[0][0];
      v28 = *(_OWORD *)&v23->pv.position.rotation.elt[1][1];
      *(_OWORD *)(v26 + 44) = *(_OWORD *)&v23->pv.position.rotation.elt[2][2];
      *(_OWORD *)(v26 + 28) = v28;
      *(_OWORD *)(v26 + 12) = v27;
      *((_DWORD *)v26 + 17) = LODWORD(v23->pv.velocity.linear.z);
      *(_QWORD *)(v26 + 60) = *(_QWORD *)&v23->pv.velocity.linear.x;
      *((_DWORD *)v26 + 20) = LODWORD(v23->pv.velocity.rotational.z);
      *((_QWORD *)v26 + 9) = *(_QWORD *)&v23->pv.velocity.rotational.x;
      *((_QWORD *)v26 + 11) = *(_QWORD *)&v23->remoteTime.sec;
      if ( ++v23 == v25->m_end )
        break;
      if ( v23 == v25->m_last )
        goto LABEL_40;
LABEL_41:
      v26 += 96;
      if ( v23 == v24 )
        goto LABEL_42;
    }
    v23 = v25->m_buff;
    if ( v25->m_buff != v25->m_last )
      goto LABEL_41;
LABEL_40:
    v23 = 0;
    goto LABEL_41;
  }
LABEL_42:
  v29 = this->m_size;
  if ( v29 )
  {
    v30 = this->m_end;
    v31 = this->m_first;
    if ( v29 != 1 )
    {
      v32 = (this->m_size & 1) - v29;
      do
      {
        while ( 1 )
        {
          v33 = v31 + 1;
          this->m_first = v33;
          if ( v33 == v30 )
          {
            v33 = this->m_buff;
            this->m_first = this->m_buff;
          }
          v31 = v33 + 1;
          this->m_first = v31;
          if ( v31 == v30 )
            break;
          v32 += 2LL;
          if ( !v32 )
            goto LABEL_51;
        }
        v31 = this->m_buff;
        this->m_first = this->m_buff;
        v32 += 2LL;
      }
      while ( v32 );
    }
LABEL_51:
    if ( (v29 & 1) != 0 )
    {
      v34 = v31 + 1;
      this->m_first = v34;
      if ( v34 == v30 )
        this->m_first = this->m_buff;
    }
  }
  if ( this->m_buff )
    operator delete(this->m_buff);
  this->m_buff = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer)p_pendingSend;
  m_end = (RBX::NetworkPhysicsData::NetworkFrame *)&p_pendingSend[96 * new_capacity];
  this->m_end = m_end;
LABEL_57:
  this->m_size = n;
  this->m_first = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer)p_pendingSend;
  v35 = 0xAAAAAAAAAAAAAAABLL * (((char *)m_end - p_pendingSend) >> 5);
  v36 = 0;
  if ( v35 <= (__int64)n )
    v36 = v35;
  this->m_last = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer)&p_pendingSend[96 * (n - v36)];
}


// Address: 0x1f8a6e0 | Name: _ZN3RBX13WindowAverageIddED2Ev
void __fastcall RBX::WindowAverage<double,double>::~WindowAverage(RBX::WindowAverage<double,double> *this)
{
  boost::circular_buffer<double,std::allocator<double> >::pointer m_first; // rcx
  signed __int64 m_size; // rdx
  boost::circular_buffer<double,std::allocator<double> >::pointer m_buff; // rax

  m_first = this->buffer.m_first;
  m_size = this->buffer.m_size;
  m_buff = this->buffer.m_buff;
  if ( this->buffer.m_end - m_first <= m_size )
    m_size -= this->buffer.m_end - this->buffer.m_buff;
  this->buffer.m_first = &m_first[m_size];
  if ( m_buff )
    operator delete(m_buff);
}


// Address: 0x1f902d0 | Name: _ZN3RBX16FrameRateManager19GetFrameTimeAverageEv
double __fastcall RBX::FrameRateManager::GetFrameTimeAverage(RBX::FrameRateManager_0 *this)
{
  boost::circular_buffer<double,std::allocator<double> >::size_type m_size; // r8
  boost::circular_buffer<double,std::allocator<double> >::pointer m_buff; // rcx
  double v3; // xmm0_8
  boost::circular_buffer<double,std::allocator<double> >::pointer m_end; // rsi
  boost::circular_buffer<double,std::allocator<double> >::size_type v5; // rdx
  boost::circular_buffer<double,std::allocator<double> >::pointer m_last; // rax
  __m128i v7; // xmm1

  m_size = this->frameTimeAverage.buffer.m_size;
  if ( m_size )
  {
    m_buff = this->frameTimeAverage.buffer.m_buff;
    v3 = 0.0;
    m_end = 0;
    v5 = this->frameTimeAverage.buffer.m_size;
    while ( 1 )
    {
      m_last = m_end;
      if ( !m_end )
        break;
      if ( m_end == m_buff )
        goto LABEL_4;
LABEL_9:
      v3 = v3 + *(m_last - 1);
      if ( m_end )
      {
        if ( m_end != m_buff )
          goto LABEL_11;
LABEL_6:
        m_end = this->frameTimeAverage.buffer.m_end;
        goto LABEL_11;
      }
      m_end = this->frameTimeAverage.buffer.m_last;
      if ( m_end == m_buff )
        goto LABEL_6;
LABEL_11:
      --m_end;
      if ( !--v5 )
      {
        v7 = (__m128i)_mm_sub_pd(
                        (__m128d)_mm_unpacklo_epi32((__m128i)m_size, (__m128i)xmmword_3E4930),
                        *(__m128d *)(&errorFunction.functor.data + 8));
        return v3 / (*(double *)_mm_shuffle_epi32(v7, 78).m128i_i64 + *(double *)v7.m128i_i64);
      }
    }
    m_last = this->frameTimeAverage.buffer.m_last;
    if ( m_last != m_buff )
      goto LABEL_9;
LABEL_4:
    m_last = this->frameTimeAverage.buffer.m_end;
    goto LABEL_9;
  }
  return 0.0;
}


// Address: 0x1f90390 | Name: _ZN3RBX16FrameRateManager21GetPrepareTimeAverageEv
double __fastcall RBX::FrameRateManager::GetPrepareTimeAverage(RBX::FrameRateManager_0 *this)
{
  boost::circular_buffer<double,std::allocator<double> >::size_type m_size; // r8
  boost::circular_buffer<double,std::allocator<double> >::pointer m_buff; // rcx
  double v3; // xmm0_8
  boost::circular_buffer<double,std::allocator<double> >::pointer m_end; // rsi
  boost::circular_buffer<double,std::allocator<double> >::size_type v5; // rdx
  boost::circular_buffer<double,std::allocator<double> >::pointer m_last; // rax
  __m128i v7; // xmm1

  m_size = this->prepareTimeAverage.buffer.m_size;
  if ( m_size )
  {
    m_buff = this->prepareTimeAverage.buffer.m_buff;
    v3 = 0.0;
    m_end = 0;
    v5 = this->prepareTimeAverage.buffer.m_size;
    while ( 1 )
    {
      m_last = m_end;
      if ( !m_end )
        break;
      if ( m_end == m_buff )
        goto LABEL_4;
LABEL_9:
      v3 = v3 + *(m_last - 1);
      if ( m_end )
      {
        if ( m_end != m_buff )
          goto LABEL_11;
LABEL_6:
        m_end = this->prepareTimeAverage.buffer.m_end;
        goto LABEL_11;
      }
      m_end = this->prepareTimeAverage.buffer.m_last;
      if ( m_end == m_buff )
        goto LABEL_6;
LABEL_11:
      --m_end;
      if ( !--v5 )
      {
        v7 = (__m128i)_mm_sub_pd(
                        (__m128d)_mm_unpacklo_epi32((__m128i)m_size, (__m128i)xmmword_3E4930),
                        *(__m128d *)(&errorFunction.functor.data + 8));
        return v3 / (*(double *)_mm_shuffle_epi32(v7, 78).m128i_i64 + *(double *)v7.m128i_i64);
      }
    }
    m_last = this->prepareTimeAverage.buffer.m_last;
    if ( m_last != m_buff )
      goto LABEL_9;
LABEL_4:
    m_last = this->prepareTimeAverage.buffer.m_end;
    goto LABEL_9;
  }
  return 0.0;
}


// Address: 0x1f90450 | Name: _ZN3RBX16FrameRateManager20GetRenderTimeAverageEv
double __fastcall RBX::FrameRateManager::GetRenderTimeAverage(RBX::FrameRateManager_0 *this)
{
  boost::circular_buffer<double,std::allocator<double> >::size_type m_size; // r8
  boost::circular_buffer<double,std::allocator<double> >::pointer m_buff; // rcx
  double v3; // xmm0_8
  boost::circular_buffer<double,std::allocator<double> >::pointer m_end; // rsi
  boost::circular_buffer<double,std::allocator<double> >::size_type v5; // rdx
  boost::circular_buffer<double,std::allocator<double> >::pointer m_last; // rax
  __m128i v7; // xmm1

  m_size = this->renderTimeAverage.buffer.m_size;
  if ( m_size )
  {
    m_buff = this->renderTimeAverage.buffer.m_buff;
    v3 = 0.0;
    m_end = 0;
    v5 = this->renderTimeAverage.buffer.m_size;
    while ( 1 )
    {
      m_last = m_end;
      if ( !m_end )
        break;
      if ( m_end == m_buff )
        goto LABEL_4;
LABEL_9:
      v3 = v3 + *(m_last - 1);
      if ( m_end )
      {
        if ( m_end != m_buff )
          goto LABEL_11;
LABEL_6:
        m_end = this->renderTimeAverage.buffer.m_end;
        goto LABEL_11;
      }
      m_end = this->renderTimeAverage.buffer.m_last;
      if ( m_end == m_buff )
        goto LABEL_6;
LABEL_11:
      --m_end;
      if ( !--v5 )
      {
        v7 = (__m128i)_mm_sub_pd(
                        (__m128d)_mm_unpacklo_epi32((__m128i)m_size, (__m128i)xmmword_3E4930),
                        *(__m128d *)(&errorFunction.functor.data + 8));
        return v3 / (*(double *)_mm_shuffle_epi32(v7, 78).m128i_i64 + *(double *)v7.m128i_i64);
      }
    }
    m_last = this->renderTimeAverage.buffer.m_last;
    if ( m_last != m_buff )
      goto LABEL_9;
LABEL_4:
    m_last = this->renderTimeAverage.buffer.m_end;
    goto LABEL_9;
  }
  return 0.0;
}


// Address: 0x1fe1b40 | Name: _ZNK3RBX13WindowAverageIddE8getStatsEm
RBX::WindowAverage<double,double>::Stats *__fastcall RBX::WindowAverage<double,double>::getStats(
        RBX::WindowAverage<double,double>::Stats *__return_ptr retstr,
        const RBX::WindowAverage<double,double> *this,
        size_t samples)
{
  boost::circular_buffer<double,std::allocator<double> >::size_type m_size; // r9
  double *p_average; // r8
  boost::circular_buffer<double,std::allocator<double> >::pointer m_buff; // r10
  double v6; // xmm0_8
  __int64 v7; // rcx
  boost::circular_buffer<double,std::allocator<double> >::pointer m_end; // rax
  boost::circular_buffer<double,std::allocator<double> >::pointer v9; // rdx
  __m128i v10; // xmm1
  double v11; // xmm0_8
  boost::circular_buffer<double,std::allocator<double> >::pointer v12; // r8
  double v13; // xmm1_8
  __int64 v14; // rdx
  boost::circular_buffer<double,std::allocator<double> >::pointer i; // rax
  boost::circular_buffer<double,std::allocator<double> >::pointer m_last; // rcx
  __m128i v17; // xmm0

  m_size = this->buffer.m_size;
  if ( m_size > samples )
    m_size = samples;
  retstr->samples = m_size;
  *(_OWORD *)&retstr->average = 0;
  if ( m_size )
  {
    p_average = &retstr->average;
    m_buff = this->buffer.m_buff;
    v6 = 0.0;
    v7 = 0;
    m_end = 0;
    while ( 1 )
    {
      v9 = m_end;
      if ( !m_end )
        break;
      if ( m_end == m_buff )
        goto LABEL_6;
LABEL_11:
      v6 = v6 + *(v9 - 1);
      *p_average = v6;
      if ( m_end )
      {
        if ( m_end != m_buff )
          goto LABEL_13;
LABEL_8:
        m_end = this->buffer.m_end;
        goto LABEL_13;
      }
      m_end = this->buffer.m_last;
      if ( m_end == m_buff )
        goto LABEL_8;
LABEL_13:
      --m_end;
      if ( ++v7 >= m_size )
      {
        v10 = (__m128i)_mm_sub_pd(
                         (__m128d)_mm_unpacklo_epi32((__m128i)m_size, (__m128i)xmmword_3E4930),
                         *(__m128d *)(&errorFunction.functor.data + 8));
        v11 = v6 / (*(double *)_mm_shuffle_epi32(v10, 78).m128i_i64 + *(double *)v10.m128i_i64);
        *p_average = v11;
        v12 = this->buffer.m_buff;
        v13 = 0.0;
        v14 = 0;
        for ( i = 0; ; --i )
        {
          m_last = i;
          if ( !i )
            break;
          if ( i == v12 )
            goto LABEL_16;
LABEL_21:
          v13 = v13 + (v11 - *(m_last - 1)) * (v11 - *(m_last - 1));
          retstr->variance = v13;
          if ( i )
          {
            if ( i != v12 )
              goto LABEL_23;
LABEL_18:
            i = this->buffer.m_end;
            goto LABEL_23;
          }
          i = this->buffer.m_last;
          if ( i == v12 )
            goto LABEL_18;
LABEL_23:
          if ( ++v14 >= m_size )
          {
            if ( m_size >= 2 )
            {
              v17 = (__m128i)_mm_sub_pd(
                               (__m128d)_mm_unpacklo_epi32((__m128i)(m_size - 1), (__m128i)xmmword_3E4930),
                               *(__m128d *)(&errorFunction.functor.data + 8));
              retstr->variance = v13 / (*(double *)_mm_shuffle_epi32(v17, 78).m128i_i64 + *(double *)v17.m128i_i64);
            }
            return retstr;
          }
        }
        m_last = this->buffer.m_last;
        if ( m_last != v12 )
          goto LABEL_21;
LABEL_16:
        m_last = this->buffer.m_end;
        goto LABEL_21;
      }
    }
    v9 = this->buffer.m_last;
    if ( v9 != m_buff )
      goto LABEL_11;
LABEL_6:
    v9 = this->buffer.m_end;
    goto LABEL_11;
  }
  return retstr;
}


// Address: 0x27c03a0 | Name: _ZN5boost15circular_bufferIdNSt3__19allocatorIdEEE12set_capacityEm
void __fastcall boost::circular_buffer<double,std::allocator<double>>::set_capacity(
        boost::circular_buffer<double,std::allocator<double> > *this,
        boost::circular_buffer<double,std::allocator<double> >::capacity_type new_capacity)
{
  boost::circular_buffer<double,std::allocator<double> >::pointer m_buff; // r14
  boost::circular_buffer<double,std::allocator<double> >::pointer m_end; // rbp
  __int64 v4; // r13
  double *v7; // rax
  boost::circular_buffer<double,std::allocator<double> >::capacity_type m_size; // r10
  boost::circular_buffer<double,std::allocator<double> >::pointer m_first; // rcx
  signed __int64 v10; // rdx
  __int64 v11; // rsi
  double *v12; // rsi
  boost::circular_buffer<double,std::allocator<double> >::pointer m_last; // rdi
  boost::circular_buffer<double,std::allocator<double> >::pointer v14; // r8
  __int64 v15; // rsi
  double *v16; // r12
  boost::circular_buffer<double,std::allocator<double> >::pointer v17; // rdx
  boost::circular_buffer<double,std::allocator<double> >::pointer v18; // rdx
  double *v19; // rbx
  double *v20; // rcx
  boost::circular_buffer<double,std::allocator<double> >::capacity_type v21; // [rsp+0h] [rbp-48h]
  _QWORD v22[8]; // [rsp+8h] [rbp-40h] BYREF

  m_buff = this->m_buff;
  m_end = this->m_end;
  v4 = m_end - this->m_buff;
  if ( v4 != new_capacity )
  {
    if ( new_capacity >> 61 )
    {
      std::logic_error::logic_error((std::logic_error *)v22, "circular_buffer");
      v22[0] = (char *)&`vtable for'std::length_error + 16;
      boost::throw_exception<std::length_error>((const std::length_error *)v22);
    }
    if ( new_capacity )
      v7 = (double *)operator new(8 * new_capacity);
    else
      v7 = 0;
    m_size = this->m_size;
    if ( m_size )
      m_first = this->m_first;
    else
      m_first = 0;
    v10 = new_capacity;
    if ( m_size < new_capacity )
      v10 = this->m_size;
    if ( v10 <= 0 )
    {
      v12 = m_first;
      if ( v10 < 0 )
      {
        m_last = m_first;
        v14 = m_first;
        if ( !m_first )
        {
          m_last = this->m_last;
          v14 = m_last;
        }
        v15 = 0;
        if ( m_last - m_buff < -v10 )
          v15 = v4;
        v12 = &v14[v10 + v15];
      }
    }
    else
    {
      v11 = v4;
      if ( m_end - m_first > v10 )
        v11 = 0;
      v12 = &m_first[v10 - v11];
      if ( v12 == this->m_last )
        v12 = 0;
    }
    v21 = new_capacity;
    v16 = v7;
    if ( m_first != v12 )
    {
      v17 = this->m_last;
      v16 = v7;
      do
      {
        *v16 = *m_first++;
        if ( m_first == m_end )
          m_first = m_buff;
        if ( m_first == v17 )
          m_first = 0;
        ++v16;
      }
      while ( m_first != v12 );
    }
    v18 = this->m_first;
    if ( m_end - v18 > (__int64)m_size )
      v4 = 0;
    this->m_first = &v18[m_size - v4];
    if ( m_buff )
    {
      v19 = v7;
      operator delete(m_buff);
      v7 = v19;
    }
    this->m_size = v16 - v7;
    this->m_buff = v7;
    this->m_first = v7;
    v20 = &v7[v21];
    this->m_end = v20;
    if ( v20 == v16 )
      v16 = v7;
    this->m_last = v16;
  }
}


