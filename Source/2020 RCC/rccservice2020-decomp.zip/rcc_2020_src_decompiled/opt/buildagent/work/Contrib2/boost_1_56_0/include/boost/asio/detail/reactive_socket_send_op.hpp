// Address: 0x260b030 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESL_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v4; // rbx
  boost::asio::detail::operation *next; // rdi
  boost::asio::detail::operation *v7; // rdi
  size_t v8; // rcx
  size_t size; // rax
  char *v10; // rdi
  unsigned __int64 v11; // rax
  size_t v12; // rcx
  boost::asio::mutable_buffers_1 v13; // [rsp+0h] [rbp-F8h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > handler; // [rsp+10h] [rbp-E8h] BYREF
  __int128 ec; // [rsp+B0h] [rbp-48h]
  __int64 v16; // [rsp+C0h] [rbp-38h]
  unsigned __int64 v17; // [rsp+D8h] [rbp-20h]
  boost::system::error_code v18; // 0:esi.4,8:rdx.8

  v4 = base;
  v17 = __readfsqword(0x28u);
  *(boost::asio::detail::operation *)&handler.stream_ = base[4];
  handler.start_ = (int)base[5].next_;
  handler.total_transferred_ = (size_t)base[5].func_;
  *(_OWORD *)&handler.handler_.next_layer_ = *(_OWORD *)&base[6].next_;
  handler.handler_.start_ = *(&base[6].task_result_ + 1);
  handler.handler_.want_ = (boost::asio::ssl::detail::engine::want)base[7].next_;
  handler.handler_.ec_ = *(boost::system::error_code *)&base[7].func_;
  handler.handler_.bytes_transferred_ = (size_t)base[8].next_;
  next = base[10].next_;
  if ( next )
  {
    if ( &base[8].task_result_ == (unsigned int *)next )
    {
      handler.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)&handler.handler_.handler_;
      base = (boost::asio::detail::operation *)&handler.handler_.handler_;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::function<void (const boost::system::error_code &)> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
        next,
        &handler.handler_.handler_,
        a3,
        a4);
    }
    else
    {
      handler.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)base[10].next_;
      base[10].next_ = 0;
    }
  }
  else
  {
    handler.handler_.handler_.__f_ = 0;
  }
  ec = *(_OWORD *)&v4[1].next_;
  v16 = *(_QWORD *)&v4[1].task_result_;
  v7 = v4[10].next_;
  if ( &v4[8].task_result_ == (unsigned int *)v7 )
  {
    v7->next_[1].func_((boost::asio::detail::task_io_service *)v7, base, a3, a4);
  }
  else if ( v7 )
  {
    (*(void (__fastcall **)(boost::asio::detail::operation *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&v7->next_[1].task_result_)(
      v7,
      base,
      a3,
      a4);
  }
  operator delete(v4);
  if ( owner )
  {
    handler.start_ = 0;
    v8 = v16 + handler.total_transferred_;
    handler.total_transferred_ += v16;
    v18.m_val = ec;
    if ( !v16 || (_DWORD)ec || (size = handler.buffer_.size_, v8 == handler.buffer_.size_) )
    {
      v18.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
      boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>::operator()(
        &handler.handler_,
        v18,
        v8,
        0);
    }
    else
    {
      v10 = 0;
      if ( handler.buffer_.size_ >= v8 )
        v10 = (char *)handler.buffer_.data_ + v8;
      else
        size = v8;
      v11 = size - v8;
      v12 = 0x10000;
      if ( v11 < 0x10000 )
        v12 = v11;
      v13.data_ = v10;
      v13.size_ = v12;
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>>(
        handler.stream_->service_,
        &handler.stream_->implementation,
        &v13,
        0,
        &handler);
    }
    _mm_sfence();
  }
  if ( &handler.handler_.handler_ == (std::function<void (const boost::system::error_code &)> *)handler.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *))handler.handler_.handler_.__f_->_vptr$__base
     + 4))(handler.handler_.handler_.__f_);
  }
  else if ( handler.handler_.handler_.__f_ )
  {
    (*((void (**)(void))handler.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x260b270 | Name: _ZN5boost4asio6detail28reactive_socket_send_op_baseINS0_17mutable_buffers_1EE10do_performEPNS1_10reactor_opE
bool __fastcall boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform(
        boost::asio::detail::reactor_op *base)
{
  __m128i v2; // [rsp+0h] [rbp-18h] BYREF
  unsigned __int64 v3; // [rsp+10h] [rbp-8h]

  v2 = _mm_loadu_si128((const __m128i *)&base[1].func_);
  v3 = _mm_shuffle_epi32(v2, 78).m128i_u64[0];
  return boost::asio::detail::socket_ops::non_blocking_send(
           (boost::asio::detail::socket_type)base[1].next_,
           (const boost::asio::detail::socket_ops::buf *)&v2,
           1u,
           base[1].ec_.m_val,
           &base->ec_,
           &base->bytes_transferred_);
}


// Address: 0x26138a0 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_8write_opINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorISH_NSI_9allocatorISH_EEEEEEEENS4_INSC_6streamISA_EESM_SB_N11websocketpp9transport4asio20custom_alloc_handlerINSI_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  void (*v6)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t); // rdi
  boost::asio::detail::task_io_service_operation *v7; // rdi
  size_t v8; // rcx
  size_t v9; // rax
  char *v10; // rdi
  unsigned __int64 v11; // rax
  size_t v12; // rcx
  boost::asio::mutable_buffers_1 v13; // [rsp+0h] [rbp-198h] BYREF
  boost::asio::detail::operation impl; // [rsp+10h] [rbp-188h] BYREF
  int next; // [rsp+28h] [rbp-170h]
  boost::asio::detail::task_io_service_operation::func_type func; // [rsp+30h] [rbp-168h]
  _BYTE v17[16]; // [rsp+40h] [rbp-158h] BYREF
  void *v18; // [rsp+50h] [rbp-148h]
  void *v19; // [rsp+58h] [rbp-140h]
  void *ptr; // [rsp+B8h] [rbp-E0h]
  void *v21; // [rsp+C0h] [rbp-D8h]
  __int64 v22; // [rsp+110h] [rbp-88h]
  char v23; // [rsp+120h] [rbp-78h] BYREF
  char *v24; // [rsp+140h] [rbp-58h]
  boost::asio::detail::operation ec; // [rsp+150h] [rbp-48h]
  unsigned __int64 v26; // [rsp+178h] [rbp-20h]
  boost::system::error_code v27; // 0:esi.4,8:rdx.8

  v26 = __readfsqword(0x28u);
  impl = base[4];
  next = (int)base[5].next_;
  func = base[5].func_;
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v17,
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)&base[6]);
  ec = base[1];
  v5 = *(boost::asio::detail::operation **)&base[16].task_result_;
  if ( &base[15].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v5 )
  {
    ((void (__fastcall *)(boost::asio::detail::operation *))v5->next_[1].func_)(v5);
  }
  else if ( v5 )
  {
    (*(void (__fastcall **)(boost::asio::detail::operation *))&v5->next_[1].task_result_)(v5);
  }
  v6 = (void (*)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t))base[11].next_;
  if ( v6 )
  {
    base[11].func_ = v6;
    operator delete(v6);
  }
  v7 = *(boost::asio::detail::task_io_service_operation **)&base[6].task_result_;
  if ( v7 )
  {
    base[7].next_ = v7;
    operator delete(v7);
  }
  if ( (boost::asio::detail::operation *)v22 == base )
  {
    *(_BYTE *)(v22 + 1024) = 0;
    if ( !owner )
      goto LABEL_24;
  }
  else
  {
    operator delete(base);
    if ( !owner )
      goto LABEL_24;
  }
  next = 0;
  v8 = (size_t)func + *(_QWORD *)&ec.task_result_;
  func = (boost::asio::detail::task_io_service_operation::func_type)((char *)func + *(_QWORD *)&ec.task_result_);
  v27.m_val = (int)ec.next_;
  if ( !*(_QWORD *)&ec.task_result_
    || LODWORD(ec.next_)
    || (v9 = *(_QWORD *)&impl.task_result_, v8 == *(_QWORD *)&impl.task_result_) )
  {
    v27.m_cat = (const boost::system::error_category *)ec.func_;
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::operator()(
      (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v17,
      v27,
      v8,
      0);
  }
  else
  {
    v10 = 0;
    if ( *(_QWORD *)&impl.task_result_ >= v8 )
      v10 = (char *)impl.func_ + v8;
    else
      v9 = v8;
    v11 = v9 - v8;
    v12 = 0x10000;
    if ( v11 < 0x10000 )
      v12 = v11;
    v13.data_ = v10;
    v13.size_ = v12;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>(
      (boost::asio::stream_socket_service<boost::asio::ip::tcp> *)impl.next_[1].next_,
      (boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *)impl.next_,
      &v13,
      0,
      (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *)&impl);
  }
  _mm_sfence();
LABEL_24:
  if ( &v23 == v24 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v24 + 32LL))(v24);
  }
  else if ( v24 )
  {
    (*(void (**)(void))(*(_QWORD *)v24 + 40LL))();
  }
  if ( ptr )
  {
    v21 = ptr;
    operator delete(ptr);
  }
  if ( v18 )
  {
    v19 = v18;
    operator delete(v18);
  }
}


// Address: 0x2617420 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_7read_opIS3_EENS1_7read_opINSC_6streamISA_EES3_NS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESU_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > v6; // [rsp+0h] [rbp-118h] BYREF
  boost::system::error_code ec; // [rsp+E0h] [rbp-38h] BYREF
  size_t bytes_transferred; // [rsp+F0h] [rbp-28h]
  unsigned __int64 v9; // [rsp+100h] [rbp-18h]

  v9 = __readfsqword(0x28u);
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::write_op(
    &v6,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *)&base[4]);
  ec = *(boost::system::error_code *)&base[1].next_;
  bytes_transferred = *(_QWORD *)&base[1].task_result_;
  if ( base )
  {
    v5 = *(boost::asio::detail::operation **)&base[12].task_result_;
    if ( &base[11].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v5 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v5->next_[1].func_)(v5);
    }
    else if ( v5 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v5->next_[1].task_result_)(v5);
    }
  }
  if ( (boost::asio::detail::operation *)v6.handler_.handler_.handler_.allocator_ == base )
  {
    v6.handler_.handler_.handler_.allocator_->in_use_ = 0;
    if ( !owner )
      goto LABEL_11;
    goto LABEL_10;
  }
  operator delete(base);
  if ( owner )
  {
LABEL_10:
    boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::operator()(
      &v6,
      &ec,
      bytes_transferred,
      0);
    _mm_sfence();
  }
LABEL_11:
  if ( &v6.handler_.handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v6.handler_.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v6.handler_.handler_.handler_.handler_.__f_->_vptr$__base
     + 4))(v6.handler_.handler_.handler_.handler_.__f_);
  }
  else if ( v6.handler_.handler_.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v6.handler_.handler_.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x262a570 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEES9_NS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENS5_6__bindIMN11websocketpp9transport4asio10connectionINSN_6config15asio_tls_client16transport_configEEEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNS5_10shared_ptrISU_EERS10_RKNS5_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES14_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  void **p_func; // r14
  boost::asio::detail::operation *v6; // rdi
  boost::asio::detail::operation *v7; // rbx
  boost::asio::detail::task_io_service_operation::func_type v8; // rdi
  volatile signed __int64 *v9; // rbx
  void *v10; // rdi
  boost::asio::detail::task_io_service_operation *v11; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::task_io_service_operation *next; // [rsp+0h] [rbp-118h] BYREF
  void *ptr[8]; // [rsp+8h] [rbp-110h] BYREF
  int v15; // [rsp+48h] [rbp-D0h]
  boost::asio::detail::task_io_service_operation::func_type func; // [rsp+50h] [rbp-C8h]
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> this_handler; // [rsp+60h] [rbp-B8h] BYREF
  boost::asio::detail::operation v18; // [rsp+C0h] [rbp-58h]
  unsigned __int64 v19; // [rsp+E8h] [rbp-30h]

  v19 = __readfsqword(0x28u);
  next = base[6].next_;
  p_func = (void **)&base[6].func_;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    (const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)&base[6].func_);
  v15 = (int)base[9].next_;
  func = base[9].func_;
  this_handler.dispatcher_ = *(boost::asio::io_service::strand *)&base[10].next_;
  *(_OWORD *)&this_handler.handler_.__f_ = *(_OWORD *)&base[10].task_result_;
  this_handler.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)&base[11].func_;
  *(_OWORD *)&base[11].func_ = 0;
  v6 = (boost::asio::detail::operation *)base[13].func_;
  if ( !v6 )
  {
    this_handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    v7 = base + 12;
    goto LABEL_5;
  }
  v7 = base + 12;
  if ( &base[12] != v6 )
  {
    this_handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[13].func_;
    base[13].func_ = 0;
LABEL_5:
    v8 = 0;
    goto LABEL_7;
  }
  this_handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this_handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
  ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))v6->next_[1].next_)(
    v6,
    &this_handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
  v8 = base[13].func_;
LABEL_7:
  v18 = base[1];
  if ( v7 == (boost::asio::detail::operation *)v8 )
  {
    (*(void (__fastcall **)(boost::asio::detail::task_io_service_operation::func_type))(*(_QWORD *)v8 + 32LL))(v8);
  }
  else if ( v8 )
  {
    (*(void (__fastcall **)(boost::asio::detail::task_io_service_operation::func_type))(*(_QWORD *)v8 + 40LL))(v8);
  }
  v9 = *(volatile signed __int64 **)&base[11].task_result_;
  if ( v9 && !_InterlockedExchangeAdd64(v9 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v9 + 16))(v9);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v9);
  }
  v10 = *p_func;
  if ( *p_func )
  {
    *(_QWORD *)&base[6].task_result_ = v10;
    operator delete(v10);
  }
  v11 = *(boost::asio::detail::task_io_service_operation **)&base[2].task_result_;
  if ( v11 )
  {
    base[3].next_ = v11;
    operator delete(v11);
  }
  operator delete(base);
  if ( owner )
  {
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
      (boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)&next,
      &this_handler);
    _mm_sfence();
  }
  if ( &this_handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)this_handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))this_handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(this_handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( this_handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))this_handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))(this_handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  cntrl = this_handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( this_handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)this_handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
}


// Address: 0x262b5e0 | Name: _ZN5boost4asio6detail28reactive_socket_send_op_baseINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE10do_performEPNS1_10reactor_opE
bool __fastcall boost::asio::detail::reactive_socket_send_op_base<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>::do_perform(
        boost::asio::detail::reactor_op *base)
{
  boost::asio::detail::task_io_service_operation::func_type func; // r9
  size_t v3; // rdx
  boost::asio::detail::task_io_service_operation *v4; // r8
  size_t perform_func; // rdi
  size_t bytes_transferred; // r14
  boost::asio::detail::task_io_service_operation *next; // rsi
  size_t *p_iov_len; // rcx
  unsigned __int64 v9; // rax
  __int64 v10; // r11
  bool (*v11)(boost::asio::detail::reactor_op *); // rbx
  boost::asio::detail::socket_ops::buf bufs; // [rsp+8h] [rbp-420h] BYREF
  __int128 v15; // [rsp+408h] [rbp-20h]

  v15 = 0;
  func = base[2].func_;
  if ( LOBYTE(base[1].ec_.m_cat) | (func == 0) )
  {
    v3 = 0;
  }
  else
  {
    v4 = *(boost::asio::detail::task_io_service_operation **)&base[1].task_result_;
    perform_func = (size_t)base[1].perform_func_;
    if ( perform_func >= (unsigned __int64)func )
      perform_func = (size_t)func;
    bytes_transferred = base[1].bytes_transferred_;
    next = base[2].next_;
    p_iov_len = &bufs.iov_len;
    v9 = 0;
    v3 = 1;
    v10 = 0;
    while ( 1 )
    {
      *(p_iov_len - 1) = bytes_transferred;
      *p_iov_len = perform_func;
      v10 += perform_func;
      if ( v4 == next )
        break;
      v9 += perform_func;
      perform_func = (size_t)func - v9;
      if ( (unsigned __int64)func <= v9 )
        break;
      bytes_transferred = (size_t)next->next_;
      v11 = (bool (*)(boost::asio::detail::reactor_op *))next->func_;
      next = (boost::asio::detail::task_io_service_operation *)((char *)next + 16);
      if ( (unsigned __int64)v11 < perform_func )
        perform_func = (size_t)v11;
      *(_QWORD *)&v15 = v3;
      p_iov_len += 2;
      if ( v3++ >= 0x40 )
      {
        *((_QWORD *)&v15 + 1) = v10;
        return boost::asio::detail::socket_ops::non_blocking_send(
                 (boost::asio::detail::socket_type)base[1].next_,
                 &bufs,
                 --v3,
                 base[2].task_result_,
                 &base->ec_,
                 &base->bytes_transferred_);
      }
    }
    *((_QWORD *)&v15 + 1) = v10;
    *(_QWORD *)&v15 = v3;
  }
  return boost::asio::detail::socket_ops::non_blocking_send(
           (boost::asio::detail::socket_type)base[1].next_,
           &bufs,
           v3,
           base[2].task_result_,
           &base->ec_,
           &base->bytes_transferred_);
}


// Address: 0x2634f80 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSJ_8functionIFvRKNSJ_10error_codeEEEERKNS_6system10error_codeEEJNSJ_10shared_ptrISP_EERSV_RKNSJ_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  volatile signed __int64 *func; // r15
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9; // rbx
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long> v12; // [rsp+0h] [rbp-3A8h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > other; // [rsp+F0h] [rbp-2B8h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > handler; // [rsp+230h] [rbp-178h] BYREF
  unsigned __int64 v15; // [rsp+388h] [rbp-20h]

  v15 = __readfsqword(0x28u);
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::write_op(
    &v12.handler_,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *)&base[4]);
  *(boost::asio::detail::operation *)&v12.arg1_.m_val = base[1];
  if ( base )
  {
    next = base[12].next_;
    if ( &base[10].task_result_ == (unsigned int *)next )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))next->next_[1].func_)(next);
    }
    else if ( next )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&next->next_[1].task_result_)(next);
    }
    func = (volatile signed __int64 *)base[10].func_;
    if ( func && !_InterlockedExchangeAdd64(func + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*func + 16))(func);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)func);
    }
  }
  operator delete(base);
  if ( owner )
  {
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      &other,
      &v12,
      &v12.handler_.handler_.handler_.handler_);
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      &handler,
      &other);
    boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
      v12.handler_.handler_.handler_.dispatcher_.service_,
      &v12.handler_.handler_.handler_.dispatcher_.impl_,
      &handler);
    if ( &handler.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 4))(handler.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    else if ( handler.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (**)(void))handler.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 5))();
    }
    cntrl = handler.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( handler.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
      && !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)handler.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
          + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
    if ( &handler.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.context_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 4))(handler.context_.__bound_args_.__base_.__value_.__f_);
    }
    else if ( handler.context_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (**)(void))handler.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
    }
    v8 = handler.context_.__bound_args_.__base_.__value_.__cntrl_;
    if ( handler.context_.__bound_args_.__base_.__value_.__cntrl_
      && !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)handler.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
    if ( &other.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)other.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 4))(other.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    else if ( other.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (**)(void))other.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 5))();
    }
    v9 = other.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( other.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
      && !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)other.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
          + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
      std::__shared_weak_count::__release_weak(v9);
    }
    if ( &other.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)other.context_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 4))(other.context_.__bound_args_.__base_.__value_.__f_);
    }
    else if ( other.context_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (**)(void))other.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
    }
    v10 = other.context_.__bound_args_.__base_.__value_.__cntrl_;
    if ( other.context_.__bound_args_.__base_.__value_.__cntrl_
      && !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)other.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
      std::__shared_weak_count::__release_weak(v10);
    }
    _mm_sfence();
  }
  if ( &v12.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v12.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v12.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v12.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v12.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v12.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v11 = v12.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v12.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v12.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
          + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
      std::__shared_weak_count::__release_weak(v11);
    }
  }
}


// Address: 0x26383f0 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSG_8functionIFvRKNSG_10error_codeEEEERKNS_6system10error_codeEEJNSG_10shared_ptrISM_EERSS_RKNSG_12placeholders4__phILi1EEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESW_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *func; // rdi
  volatile signed __int64 *v6; // r15
  size_t v7; // rcx
  size_t size; // rax
  char *v9; // rdi
  unsigned __int64 v10; // rax
  size_t v11; // rcx
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::mutable_buffers_1 v13; // [rsp+0h] [rbp-118h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > handler; // [rsp+10h] [rbp-108h] BYREF
  boost::asio::detail::operation ec; // [rsp+D0h] [rbp-48h]
  unsigned __int64 v16; // [rsp+F8h] [rbp-20h]
  boost::system::error_code v17; // 0:esi.4,8:rdx.8

  v16 = __readfsqword(0x28u);
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::write_op(
    &handler,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *)&base[4]);
  ec = base[1];
  if ( base )
  {
    func = (boost::asio::detail::operation *)base[11].func_;
    if ( &base[10] == func )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))func->next_[1].func_)(func);
    }
    else if ( func )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&func->next_[1].task_result_)(func);
    }
    v6 = *(volatile signed __int64 **)&base[9].task_result_;
    if ( v6 && !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(v6);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
  }
  operator delete(base);
  if ( owner )
  {
    handler.start_ = 0;
    v7 = *(_QWORD *)&ec.task_result_ + handler.total_transferred_;
    handler.total_transferred_ += *(_QWORD *)&ec.task_result_;
    v17.m_val = (int)ec.next_;
    if ( !*(_QWORD *)&ec.task_result_
      || LODWORD(ec.next_)
      || (size = handler.buffer_.size_, v7 == handler.buffer_.size_) )
    {
      v17.m_cat = (const boost::system::error_category *)ec.func_;
      boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::operator()(
        &handler.handler_,
        v17,
        v7,
        0);
    }
    else
    {
      v9 = 0;
      if ( handler.buffer_.size_ >= v7 )
        v9 = (char *)handler.buffer_.data_ + v7;
      else
        size = v7;
      v10 = size - v7;
      v11 = 0x10000;
      if ( v10 < 0x10000 )
        v11 = v10;
      v13.data_ = v9;
      v13.size_ = v11;
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>>(
        handler.stream_->service_,
        &handler.stream_->implementation,
        &v13,
        0,
        &handler);
    }
    _mm_sfence();
  }
  if ( &handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x265c820 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEES9_NS1_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINS5_8functionIFvRKNS_6system10error_codeEmEEEEEEEEC2EiRKSA_iRSV_
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::reactive_socket_send_op(
        boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> >,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *this,
        boost::asio::detail::socket_type socket,
        const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *handler)
{
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *v8; // rax

  *(_QWORD *)this = 0;
  *((_QWORD *)this + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::do_complete;
  *((_DWORD *)this + 4) = 0;
  *((_DWORD *)this + 6) = 0;
  *((_QWORD *)this + 4) = boost::system::system_category();
  *((_QWORD *)this + 5) = 0;
  *((_QWORD *)this + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>::do_perform;
  *((_DWORD *)this + 14) = socket;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> >,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)((char *)this + 64),
    buffers);
  *((_DWORD *)this + 32) = flags;
  *((_QWORD *)this + 18) = *(_QWORD *)handler;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> >,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)((char *)this + 152),
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)((char *)handler + 8));
  *((_DWORD *)this + 54) = *((_DWORD *)handler + 18);
  *((_QWORD *)this + 28) = *((_QWORD *)handler + 10);
  *((_QWORD *)this + 30) = *((_QWORD *)handler + 12);
  v8 = (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)*((_QWORD *)handler + 18);
  if ( v8 )
  {
    if ( (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)((char *)handler + 112) == v8 )
    {
      *((_QWORD *)this + 36) = (char *)this + 256;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)handler + 18) + 24LL))(*((_QWORD *)handler + 18));
    }
    else
    {
      *((_QWORD *)this + 36) = v8;
      *((_QWORD *)handler + 18) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 36) = 0;
  }
}


// Address: 0x265c950 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEES9_NS1_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINS5_8functionIFvRKNS_6system10error_codeEmEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESR_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  void **p_func; // r12
  boost::asio::detail::operation *v6; // rdi
  unsigned int *p_task_result; // r13
  boost::asio::detail::task_io_service_operation *v8; // rdi
  void *v9; // rdi
  boost::asio::detail::task_io_service_operation *v10; // rdi
  boost::asio::detail::task_io_service_operation *next; // [rsp+0h] [rbp-F8h] BYREF
  void *ptr[8]; // [rsp+8h] [rbp-F0h] BYREF
  int v13; // [rsp+48h] [rbp-B0h]
  boost::asio::detail::task_io_service_operation::func_type func; // [rsp+50h] [rbp-A8h]
  boost::asio::detail::task_io_service_operation *v15; // [rsp+60h] [rbp-98h]
  _BYTE v16[32]; // [rsp+70h] [rbp-88h] BYREF
  boost::asio::detail::task_io_service_operation *v17; // [rsp+90h] [rbp-68h]
  boost::system::error_code ec; // [rsp+A0h] [rbp-58h] BYREF
  size_t bytes_transferred; // [rsp+B0h] [rbp-48h]
  unsigned __int64 v20; // [rsp+C8h] [rbp-30h]

  v20 = __readfsqword(0x28u);
  next = base[6].next_;
  p_func = (void **)&base[6].func_;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    (const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)&base[6].func_);
  v13 = (int)base[9].next_;
  func = base[9].func_;
  v15 = base[10].next_;
  v6 = base[12].next_;
  if ( !v6 )
  {
    v17 = 0;
    p_task_result = &base[10].task_result_;
    goto LABEL_5;
  }
  p_task_result = &base[10].task_result_;
  if ( &base[10].task_result_ != (unsigned int *)v6 )
  {
    v17 = base[12].next_;
    base[12].next_ = 0;
LABEL_5:
    v8 = 0;
    goto LABEL_7;
  }
  v17 = (boost::asio::detail::task_io_service_operation *)v16;
  ((void (__fastcall *)(boost::asio::detail::operation *, _BYTE *))v6->next_[1].next_)(v6, v16);
  v8 = base[12].next_;
LABEL_7:
  ec = *(boost::system::error_code *)&base[1].next_;
  bytes_transferred = *(_QWORD *)&base[1].task_result_;
  if ( p_task_result == (unsigned int *)v8 )
  {
    ((void (__fastcall *)(boost::asio::detail::task_io_service_operation *))v8->next_[1].func_)(v8);
  }
  else if ( v8 )
  {
    (*(void (__fastcall **)(boost::asio::detail::task_io_service_operation *))&v8->next_[1].task_result_)(v8);
  }
  v9 = *p_func;
  if ( *p_func )
  {
    *(_QWORD *)&base[6].task_result_ = v9;
    operator delete(v9);
  }
  v10 = *(boost::asio::detail::task_io_service_operation **)&base[2].task_result_;
  if ( v10 )
  {
    base[3].next_ = v10;
    operator delete(v10);
  }
  if ( v15 == base )
  {
    LOBYTE(v15[42].task_result_) = 0;
    if ( !owner )
      goto LABEL_20;
    goto LABEL_19;
  }
  operator delete(base);
  if ( owner )
  {
LABEL_19:
    boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>::operator()(
      (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)&next,
      &ec,
      bytes_transferred,
      0);
    _mm_sfence();
  }
LABEL_20:
  if ( v16 == (_BYTE *)v17 )
  {
    ((void (__fastcall *)(boost::asio::detail::task_io_service_operation *))v17->next_[1].func_)(v17);
  }
  else if ( v17 )
  {
    (*(void (__fastcall **)(boost::asio::detail::task_io_service_operation *))&v17->next_[1].task_result_)(v17);
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
}


// Address: 0x266b990 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEES9_NS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENS5_6__bindIMN11websocketpp9transport4asio10connectionINSN_6config11asio_client16transport_configEEEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNS5_10shared_ptrISU_EERS10_RKNS5_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES14_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  void **p_func; // r14
  boost::asio::detail::operation *v6; // rdi
  boost::asio::detail::operation *v7; // rbx
  boost::asio::detail::task_io_service_operation::func_type v8; // rdi
  volatile signed __int64 *v9; // rbx
  void *v10; // rdi
  boost::asio::detail::task_io_service_operation *v11; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::task_io_service_operation *next; // [rsp+0h] [rbp-118h] BYREF
  void *ptr[8]; // [rsp+8h] [rbp-110h] BYREF
  int v15; // [rsp+48h] [rbp-D0h]
  boost::asio::detail::task_io_service_operation::func_type func; // [rsp+50h] [rbp-C8h]
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> this_handler; // [rsp+60h] [rbp-B8h] BYREF
  boost::asio::detail::operation v18; // [rsp+C0h] [rbp-58h]
  unsigned __int64 v19; // [rsp+E8h] [rbp-30h]

  v19 = __readfsqword(0x28u);
  next = base[6].next_;
  p_func = (void **)&base[6].func_;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    (const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)&base[6].func_);
  v15 = (int)base[9].next_;
  func = base[9].func_;
  this_handler.dispatcher_ = *(boost::asio::io_service::strand *)&base[10].next_;
  *(_OWORD *)&this_handler.handler_.__f_ = *(_OWORD *)&base[10].task_result_;
  this_handler.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)&base[11].func_;
  *(_OWORD *)&base[11].func_ = 0;
  v6 = (boost::asio::detail::operation *)base[13].func_;
  if ( !v6 )
  {
    this_handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    v7 = base + 12;
    goto LABEL_5;
  }
  v7 = base + 12;
  if ( &base[12] != v6 )
  {
    this_handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[13].func_;
    base[13].func_ = 0;
LABEL_5:
    v8 = 0;
    goto LABEL_7;
  }
  this_handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this_handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
  ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))v6->next_[1].next_)(
    v6,
    &this_handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
  v8 = base[13].func_;
LABEL_7:
  v18 = base[1];
  if ( v7 == (boost::asio::detail::operation *)v8 )
  {
    (*(void (__fastcall **)(boost::asio::detail::task_io_service_operation::func_type))(*(_QWORD *)v8 + 32LL))(v8);
  }
  else if ( v8 )
  {
    (*(void (__fastcall **)(boost::asio::detail::task_io_service_operation::func_type))(*(_QWORD *)v8 + 40LL))(v8);
  }
  v9 = *(volatile signed __int64 **)&base[11].task_result_;
  if ( v9 && !_InterlockedExchangeAdd64(v9 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v9 + 16))(v9);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v9);
  }
  v10 = *p_func;
  if ( *p_func )
  {
    *(_QWORD *)&base[6].task_result_ = v10;
    operator delete(v10);
  }
  v11 = *(boost::asio::detail::task_io_service_operation **)&base[2].task_result_;
  if ( v11 )
  {
    base[3].next_ = v11;
    operator delete(v11);
  }
  operator delete(base);
  if ( owner )
  {
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
      (boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)&next,
      &this_handler);
    _mm_sfence();
  }
  if ( &this_handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)this_handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))this_handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(this_handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( this_handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))this_handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))(this_handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  cntrl = this_handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( this_handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)this_handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
}


// Address: 0x26a3730 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_8write_opINS0_15const_buffers_1EEENS4_INSC_6streamIRSA_EESG_SB_NS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISY_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES12_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __m128i v4; // xmm1
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> si128; // xmm2
  __m128i v6; // xmm0
  __int64 v7; // rbx
  size_t v8; // rcx
  size_t size; // rax
  volatile signed __int64 *cntrl; // rbx
  char *v11; // rdi
  unsigned __int64 v12; // rax
  size_t v13; // rcx
  boost::asio::mutable_buffers_1 v14; // [rsp+0h] [rbp-118h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > > handler; // [rsp+10h] [rbp-108h] BYREF
  __m128i ec; // [rsp+C8h] [rbp-50h]
  __int64 v17; // [rsp+D8h] [rbp-40h]
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> v18; // [rsp+E0h] [rbp-38h] BYREF
  __m128i v19[2]; // [rsp+F0h] [rbp-28h] BYREF
  boost::system::error_code v20; // 0:kr00_16.16

  handler.stream_ = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)&base[3].task_result_;
  *(boost::asio::detail::operation *)&handler.buffer_.data_ = base[4];
  v4 = _mm_loadu_si128((const __m128i *)&base[5]);
  *(__m128i *)&handler.total_transferred_ = v4;
  handler.handler_.core_ = *(boost::asio::ssl::detail::stream_core **)&base[5].task_result_;
  *(boost::asio::detail::operation *)&handler.handler_.op_.buffers_.data_ = base[6];
  handler.handler_.ec_ = *(boost::system::error_code *)&base[7].next_;
  *(_OWORD *)&handler.handler_.bytes_transferred_ = *(_OWORD *)&base[7].task_result_;
  handler.handler_.handler_.buffer_ = *(boost::asio::const_buffer *)&base[8].func_;
  handler.handler_.handler_.start_ = (int)base[9].next_;
  *(_OWORD *)&handler.handler_.handler_.total_transferred_ = *(_OWORD *)&base[9].func_;
  handler.handler_.handler_.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> *)&base[10].next_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[10].task_result_);
  handler.handler_.handler_.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[10].task_result_ = 0;
  v6 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v6;
  v7 = *(_QWORD *)&base[1].task_result_;
  v17 = v7;
  if ( base )
  {
    v19[0] = v4;
    v18 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v18);
    v4.m128i_i64[0] = _mm_load_si128(v19).m128i_u64[0];
  }
  if ( !owner )
  {
    v6.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
    cntrl = (volatile signed __int64 *)v6.m128i_i64[0];
    if ( !v6.m128i_i64[0] )
      return;
    goto LABEL_17;
  }
  handler.start_ = 0;
  v8 = v7 + v4.m128i_i64[0];
  handler.total_transferred_ = v7 + v4.m128i_i64[0];
  base = (boost::asio::detail::operation *)ec.m128i_u32[0];
  if ( !v7 || ec.m128i_i32[0] || (size = handler.buffer_.size_, v8 == handler.buffer_.size_) )
  {
    v20.m_val = ec.m128i_i32[0];
    v20.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::operator()(
      &handler.handler_,
      v20,
      v8,
      0);
  }
  else
  {
    v11 = 0;
    if ( handler.buffer_.size_ >= v8 )
      v11 = (char *)handler.buffer_.data_ + v8;
    else
      size = v7 + v4.m128i_i64[0];
    v12 = size - v8;
    v13 = 0x10000;
    if ( v12 < 0x10000 )
      v13 = v12;
    base = (boost::asio::detail::operation *)handler.stream_;
    v14.data_ = v11;
    v14.size_ = v13;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>>(
      handler.stream_->service_,
      &handler.stream_->implementation,
      &v14,
      0,
      &handler);
  }
  _mm_sfence();
  cntrl = (volatile signed __int64 *)handler.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( handler.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
LABEL_17:
    if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, double, double))(*cntrl + 16))(
        cntrl,
        base,
        a3,
        a4,
        *(double *)v6.m128i_i64,
        *(double *)v4.m128i_i64);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
  }
}


// Address: 0x26a3ce0 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_15const_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSG_5list2INSG_5valueINSD_10shared_ptrISP_EEEEPFNS_3argILi1EEEvEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationEST_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> si128; // xmm1
  boost::system::error_code v7; // xmm0
  size_t v8; // rbx
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> v12; // [rsp+0h] [rbp-88h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > v13; // [rsp+10h] [rbp-78h] BYREF
  boost::system::error_code ec; // [rsp+60h] [rbp-28h] BYREF
  size_t v15; // [rsp+70h] [rbp-18h]

  v13.stream_ = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)&base[3].task_result_;
  *(boost::asio::detail::operation *)&v13.buffer_.data_ = base[4];
  *(_OWORD *)&v13.total_transferred_ = *(_OWORD *)&base[5].next_;
  v13.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> *)&base[5].task_result_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[6].func_);
  v13.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[6].func_ = 0;
  v7 = (boost::system::error_code)_mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  v8 = *(_QWORD *)&base[1].task_result_;
  v15 = v8;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 || (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) == 0 || *v10 )
  {
    v12 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v12);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[7].next_;
  LOBYTE(base->next_) = a4;
  *v10 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)&ec;
    boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::operator()(
      &v13,
      &ec,
      v8,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v13.handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( !v13.handler_.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  *(_QWORD *)&v7.m_val = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = *(volatile signed __int64 **)&v7.m_val;
  if ( !*(_QWORD *)&v7.m_val )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, const void *, size_t, int, size_t, boost::asio::basic_streambuf<std::allocator<char> > *, boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)&v7.m_val,
      *(double *)&si128.a1_.t_.__ptr_,
      v12.a1_.t_.__ptr_,
      v12.a1_.t_.__cntrl_,
      v13.stream_,
      v13.buffer_.data_,
      v13.buffer_.size_,
      v13.start_,
      v13.total_transferred_,
      v13.handler_.streambuf_,
      v13.handler_.handler_.f_.f_,
      *((_QWORD *)&v13.handler_.handler_.f_.f_ + 1),
      v13.handler_.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26a3e30 | Name: _ZN5boost4asio6detail28reactive_socket_send_op_baseINS0_15const_buffers_1EE10do_performEPNS1_10reactor_opE
bool __fastcall boost::asio::detail::reactive_socket_send_op_base<boost::asio::const_buffers_1>::do_perform(
        boost::asio::detail::reactor_op *base)
{
  __m128i v2; // [rsp+0h] [rbp-18h] BYREF
  unsigned __int64 v3; // [rsp+10h] [rbp-8h]

  v2 = _mm_loadu_si128((const __m128i *)&base[1].func_);
  v3 = _mm_shuffle_epi32(v2, 78).m128i_u64[0];
  return boost::asio::detail::socket_ops::non_blocking_send(
           (boost::asio::detail::socket_type)base[1].next_,
           (const boost::asio::detail::socket_ops::buf *)&v2,
           1u,
           base[1].ec_.m_val,
           &base->ec_,
           &base->bytes_transferred_);
}


// Address: 0x26a6730 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_7read_opIS3_EENS1_26read_until_delim_string_opINSC_6streamIRSA_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSO_5list2INSO_5valueINSL_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES11_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __m128i v4; // xmm2
  __m128i v5; // xmm1
  __m128i v6; // xmm0
  __int64 v7; // rbx
  void (*v8)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t); // rcx
  boost::asio::detail::task_io_service_operation::func_type v9; // rax
  volatile signed __int64 *v10; // rbx
  char *v11; // rdi
  unsigned __int64 v12; // rax
  size_t v13; // rcx
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-120h] BYREF
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl; // [rsp+18h] [rbp-110h] BYREF
  boost::asio::detail::operation v16; // [rsp+20h] [rbp-108h]
  __m128i v17; // [rsp+38h] [rbp-F0h] BYREF
  __int64 v18; // [rsp+48h] [rbp-E0h]
  boost::asio::detail::operation v19; // [rsp+50h] [rbp-D8h]
  __int128 v20; // [rsp+68h] [rbp-C0h]
  __int128 v21; // [rsp+78h] [rbp-B0h]
  boost::asio::detail::task_io_service_operation::func_type func; // [rsp+88h] [rbp-A0h]
  __int128 v23; // [rsp+90h] [rbp-98h]
  void *ptr; // [rsp+A0h] [rbp-88h]
  unsigned int task_result; // [rsp+A8h] [rbp-80h]
  boost::asio::detail::operation v26; // [rsp+B0h] [rbp-78h]
  __m128i v27; // [rsp+C8h] [rbp-60h]
  __m128i ec; // [rsp+D8h] [rbp-50h]
  __int64 v29; // [rsp+E8h] [rbp-40h]
  __m128i v30; // [rsp+F0h] [rbp-38h] BYREF
  __m128i v31[2]; // [rsp+100h] [rbp-28h] BYREF
  boost::system::error_code v32; // 0:kr00_16.16

  impl = *(boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type **)&base[3].task_result_;
  v16 = base[4];
  v4 = _mm_loadu_si128((const __m128i *)&base[5]);
  v17 = v4;
  v18 = *(_QWORD *)&base[5].task_result_;
  v19 = base[6];
  v20 = *(_OWORD *)&base[7].next_;
  v21 = *(_OWORD *)&base[7].task_result_;
  func = base[8].func_;
  ptr = base[9].func_;
  v23 = *(_OWORD *)&base[8].task_result_;
  *(_OWORD *)&base[8].task_result_ = 0;
  base[9].func_ = 0;
  task_result = base[9].task_result_;
  v26 = base[10];
  v5 = _mm_loadu_si128((const __m128i *)&base[11]);
  v27 = v5;
  *(_OWORD *)&base[11].next_ = 0;
  v6 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v6;
  v7 = *(_QWORD *)&base[1].task_result_;
  v29 = v7;
  if ( base )
  {
    v31[0] = v4;
    v30 = v5;
    operator delete(base);
    v5 = _mm_load_si128(&v30);
    v4.m128i_i64[0] = _mm_load_si128(v31).m128i_u64[0];
  }
  if ( !owner )
  {
    v6.m128i_i64[0] = _mm_shuffle_epi32(v5, 78).m128i_u64[0];
    v10 = (volatile signed __int64 *)v6.m128i_i64[0];
    if ( v6.m128i_i64[0] )
      goto LABEL_17;
LABEL_18:
    if ( (v23 & 1) == 0 )
      return;
    goto LABEL_19;
  }
  v16.task_result_ = 0;
  v8 = (void (*)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t))(v7 + v4.m128i_i64[0]);
  v17.m128i_i64[0] = v7 + v4.m128i_i64[0];
  base = (boost::asio::detail::operation *)ec.m128i_u32[0];
  if ( !v7 || ec.m128i_i32[0] || (v9 = v16.func_, v8 == v16.func_) )
  {
    v32.m_val = ec.m128i_i32[0];
    v32.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::operator()(
      (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)&v17.m128i_u64[1],
      v32,
      (size_t)v8,
      0);
  }
  else
  {
    v11 = 0;
    if ( (char *)v16.func_ >= (char *)v8 )
      v11 = (char *)v8 + (unsigned __int64)v16.next_;
    else
      v9 = (boost::asio::detail::task_io_service_operation::func_type)(v7 + v4.m128i_i64[0]);
    v12 = (char *)v9 - (char *)v8;
    v13 = 0x10000;
    if ( v12 < 0x10000 )
      v13 = v12;
    base = (boost::asio::detail::operation *)impl;
    buffers.data_ = v11;
    buffers.size_ = v13;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
      *(boost::asio::stream_socket_service<boost::asio::ip::tcp> **)&impl[1].socket_,
      impl,
      &buffers,
      0,
      (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *)&impl);
  }
  _mm_sfence();
  v10 = (volatile signed __int64 *)v27.m128i_i64[1];
  if ( !v27.m128i_i64[1] )
    goto LABEL_18;
LABEL_17:
  if ( _InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    goto LABEL_18;
  (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, double, double, double))(*v10 + 16))(
    v10,
    base,
    a3,
    a4,
    *(double *)v6.m128i_i64,
    *(double *)v5.m128i_i64,
    *(double *)v4.m128i_i64);
  std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v10);
  if ( (v23 & 1) == 0 )
    return;
LABEL_19:
  operator delete(ptr);
}


// Address: 0x26a9820 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSG_5list2INSG_5valueINSt3__110shared_ptrISO_EEEEPFNS_3argILi1EEEvEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESS_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v4; // r14
  __m128i v5; // xmm1
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm2
  __m128i v7; // xmm0
  __int64 v8; // rbx
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  size_t v11; // rcx
  size_t size; // rax
  char *v13; // rsi
  unsigned __int64 v14; // rax
  size_t v15; // rcx
  volatile signed __int64 *cntrl; // rbx
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-E0h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > handler; // [rsp+18h] [rbp-D0h] BYREF
  __m128i ec; // [rsp+98h] [rbp-50h]
  __int64 v20; // [rsp+A8h] [rbp-40h]
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v21; // [rsp+B0h] [rbp-38h] BYREF
  __m128i v22[2]; // [rsp+C0h] [rbp-28h] BYREF
  boost::system::error_code v23; // 0:esi.4,8:rdx.8

  v4 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)&base[3].task_result_;
  handler.stream_ = v4;
  *(boost::asio::detail::operation *)&handler.buffer_.data_ = base[4];
  v5 = _mm_loadu_si128((const __m128i *)&base[5]);
  *(__m128i *)&handler.total_transferred_ = v5;
  handler.handler_.core_ = *(boost::asio::ssl::detail::stream_core **)&base[5].task_result_;
  handler.handler_.op_.type_ = (boost::asio::ssl::stream_base::handshake_type)base[6].next_;
  handler.handler_.start_ = HIDWORD(base[6].next_);
  handler.handler_.want_ = (boost::asio::ssl::detail::engine::want)base[6].func_;
  handler.handler_.ec_ = *(boost::system::error_code *)&base[6].task_result_;
  handler.handler_.bytes_transferred_ = (size_t)base[7].func_;
  handler.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)&base[7].task_result_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[8].func_);
  handler.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[8].func_ = 0;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  v8 = *(_QWORD *)&base[1].task_result_;
  v20 = v8;
  if ( base )
  {
    v9 = __readfsqword(0xFFFFFFD8);
    if ( v9 )
    {
      v10 = *(boost::asio::detail::operation ***)(v9 + 8);
      if ( v10 )
      {
        if ( !*v10 )
        {
          LOBYTE(base->next_) = base[9].next_;
          *v10 = base;
          if ( owner )
            goto LABEL_7;
LABEL_20:
          v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
          cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
          if ( !v7.m128i_i64[0] )
            return;
          goto LABEL_21;
        }
      }
    }
    v22[0] = v5;
    v21 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v21);
    v5.m128i_i64[0] = _mm_load_si128(v22).m128i_u64[0];
  }
  if ( !owner )
    goto LABEL_20;
LABEL_7:
  handler.start_ = 0;
  v11 = v8 + v5.m128i_i64[0];
  handler.total_transferred_ = v8 + v5.m128i_i64[0];
  v23.m_val = ec.m128i_i32[0];
  if ( !v8 || ec.m128i_i32[0] || (size = handler.buffer_.size_, v11 == handler.buffer_.size_) )
  {
    v23.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
      &handler.handler_,
      v23,
      v11,
      0);
  }
  else
  {
    v13 = 0;
    if ( handler.buffer_.size_ >= v11 )
      v13 = (char *)handler.buffer_.data_ + v11;
    else
      size = v8 + v5.m128i_i64[0];
    v14 = size - v11;
    v15 = 0x10000;
    if ( v14 < 0x10000 )
      v15 = v14;
    buffers.data_ = v13;
    buffers.size_ = v15;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
      v4->service_,
      &v4->implementation,
      &buffers,
      0,
      &handler);
  }
  _mm_sfence();
  cntrl = (volatile signed __int64 *)handler.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( handler.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
LABEL_21:
    if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, double, double, double))(*cntrl + 16))(
        cntrl,
        *(double *)v7.m128i_i64,
        *(double *)v5.m128i_i64,
        *(double *)&si128.a1_.t_.__ptr_);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
  }
}


// Address: 0x26ab180 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_8write_opINS0_15const_buffers_1EEENS4_INSC_6streamIRSA_EESG_SB_NS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES11_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __m128i v4; // xmm1
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm2
  __m128i v6; // xmm0
  __int64 v7; // rbx
  size_t v8; // rcx
  size_t size; // rax
  volatile signed __int64 *cntrl; // rbx
  char *v11; // rdi
  unsigned __int64 v12; // rax
  size_t v13; // rcx
  boost::asio::mutable_buffers_1 v14; // [rsp+0h] [rbp-118h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > > handler; // [rsp+10h] [rbp-108h] BYREF
  __m128i ec; // [rsp+C8h] [rbp-50h]
  __int64 v17; // [rsp+D8h] [rbp-40h]
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v18; // [rsp+E0h] [rbp-38h] BYREF
  __m128i v19[2]; // [rsp+F0h] [rbp-28h] BYREF
  boost::system::error_code v20; // 0:kr00_16.16

  handler.stream_ = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)&base[3].task_result_;
  *(boost::asio::detail::operation *)&handler.buffer_.data_ = base[4];
  v4 = _mm_loadu_si128((const __m128i *)&base[5]);
  *(__m128i *)&handler.total_transferred_ = v4;
  handler.handler_.core_ = *(boost::asio::ssl::detail::stream_core **)&base[5].task_result_;
  *(boost::asio::detail::operation *)&handler.handler_.op_.buffers_.data_ = base[6];
  handler.handler_.ec_ = *(boost::system::error_code *)&base[7].next_;
  *(_OWORD *)&handler.handler_.bytes_transferred_ = *(_OWORD *)&base[7].task_result_;
  handler.handler_.handler_.buffer_ = *(boost::asio::const_buffer *)&base[8].func_;
  handler.handler_.handler_.start_ = (int)base[9].next_;
  *(_OWORD *)&handler.handler_.handler_.total_transferred_ = *(_OWORD *)&base[9].func_;
  handler.handler_.handler_.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)&base[10].next_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[10].task_result_);
  handler.handler_.handler_.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[10].task_result_ = 0;
  v6 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v6;
  v7 = *(_QWORD *)&base[1].task_result_;
  v17 = v7;
  if ( base )
  {
    v19[0] = v4;
    v18 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v18);
    v4.m128i_i64[0] = _mm_load_si128(v19).m128i_u64[0];
  }
  if ( !owner )
  {
    v6.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
    cntrl = (volatile signed __int64 *)v6.m128i_i64[0];
    if ( !v6.m128i_i64[0] )
      return;
    goto LABEL_17;
  }
  handler.start_ = 0;
  v8 = v7 + v4.m128i_i64[0];
  handler.total_transferred_ = v7 + v4.m128i_i64[0];
  base = (boost::asio::detail::operation *)ec.m128i_u32[0];
  if ( !v7 || ec.m128i_i32[0] || (size = handler.buffer_.size_, v8 == handler.buffer_.size_) )
  {
    v20.m_val = ec.m128i_i32[0];
    v20.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::operator()(
      &handler.handler_,
      v20,
      v8,
      0);
  }
  else
  {
    v11 = 0;
    if ( handler.buffer_.size_ >= v8 )
      v11 = (char *)handler.buffer_.data_ + v8;
    else
      size = v7 + v4.m128i_i64[0];
    v12 = size - v8;
    v13 = 0x10000;
    if ( v12 < 0x10000 )
      v13 = v12;
    base = (boost::asio::detail::operation *)handler.stream_;
    v14.data_ = v11;
    v14.size_ = v13;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>>(
      handler.stream_->service_,
      &handler.stream_->implementation,
      &v14,
      0,
      &handler);
  }
  _mm_sfence();
  cntrl = (volatile signed __int64 *)handler.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( handler.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
LABEL_17:
    if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, double, double))(*cntrl + 16))(
        cntrl,
        base,
        a3,
        a4,
        *(double *)v6.m128i_i64,
        *(double *)v4.m128i_i64);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
  }
}


// Address: 0x26ab730 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_15const_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSG_5list2INSG_5valueINSD_10shared_ptrISO_EEEEPFNS_3argILi1EEEvEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESS_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  boost::system::error_code v7; // xmm0
  size_t v8; // rbx
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v12; // [rsp+0h] [rbp-88h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v13; // [rsp+10h] [rbp-78h] BYREF
  boost::system::error_code ec; // [rsp+60h] [rbp-28h] BYREF
  size_t v15; // [rsp+70h] [rbp-18h]

  v13.stream_ = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)&base[3].task_result_;
  *(boost::asio::detail::operation *)&v13.buffer_.data_ = base[4];
  *(_OWORD *)&v13.total_transferred_ = *(_OWORD *)&base[5].next_;
  v13.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)&base[5].task_result_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[6].func_);
  v13.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[6].func_ = 0;
  v7 = (boost::system::error_code)_mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  v8 = *(_QWORD *)&base[1].task_result_;
  v15 = v8;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 || (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) == 0 || *v10 )
  {
    v12 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v12);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[7].next_;
  LOBYTE(base->next_) = a4;
  *v10 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)&ec;
    boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
      &v13,
      &ec,
      v8,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v13.handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( !v13.handler_.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  *(_QWORD *)&v7.m_val = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = *(volatile signed __int64 **)&v7.m_val;
  if ( !*(_QWORD *)&v7.m_val )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, const void *, size_t, int, size_t, boost::asio::basic_streambuf<std::allocator<char> > *, boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)&v7.m_val,
      *(double *)&si128.a1_.t_.__ptr_,
      v12.a1_.t_.__ptr_,
      v12.a1_.t_.__cntrl_,
      v13.stream_,
      v13.buffer_.data_,
      v13.buffer_.size_,
      v13.start_,
      v13.total_transferred_,
      v13.handler_.streambuf_,
      v13.handler_.handler_.f_.f_,
      *((_QWORD *)&v13.handler_.handler_.f_.f_ + 1),
      v13.handler_.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26aebb0 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_7read_opIS3_EENS1_26read_until_delim_string_opINSC_6streamIRSA_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSO_5list2INSO_5valueINSL_10shared_ptrISW_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES10_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __m128i v4; // xmm2
  __m128i v5; // xmm1
  __m128i v6; // xmm0
  __int64 v7; // rbx
  void (*v8)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t); // rcx
  boost::asio::detail::task_io_service_operation::func_type v9; // rax
  volatile signed __int64 *v10; // rbx
  char *v11; // rdi
  unsigned __int64 v12; // rax
  size_t v13; // rcx
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-120h] BYREF
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl; // [rsp+18h] [rbp-110h] BYREF
  boost::asio::detail::operation v16; // [rsp+20h] [rbp-108h]
  __m128i v17; // [rsp+38h] [rbp-F0h] BYREF
  __int64 v18; // [rsp+48h] [rbp-E0h]
  boost::asio::detail::operation v19; // [rsp+50h] [rbp-D8h]
  __int128 v20; // [rsp+68h] [rbp-C0h]
  __int128 v21; // [rsp+78h] [rbp-B0h]
  boost::asio::detail::task_io_service_operation::func_type func; // [rsp+88h] [rbp-A0h]
  __int128 v23; // [rsp+90h] [rbp-98h]
  void *ptr; // [rsp+A0h] [rbp-88h]
  unsigned int task_result; // [rsp+A8h] [rbp-80h]
  boost::asio::detail::operation v26; // [rsp+B0h] [rbp-78h]
  __m128i v27; // [rsp+C8h] [rbp-60h]
  __m128i ec; // [rsp+D8h] [rbp-50h]
  __int64 v29; // [rsp+E8h] [rbp-40h]
  __m128i v30; // [rsp+F0h] [rbp-38h] BYREF
  __m128i v31[2]; // [rsp+100h] [rbp-28h] BYREF
  boost::system::error_code v32; // 0:kr00_16.16

  impl = *(boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type **)&base[3].task_result_;
  v16 = base[4];
  v4 = _mm_loadu_si128((const __m128i *)&base[5]);
  v17 = v4;
  v18 = *(_QWORD *)&base[5].task_result_;
  v19 = base[6];
  v20 = *(_OWORD *)&base[7].next_;
  v21 = *(_OWORD *)&base[7].task_result_;
  func = base[8].func_;
  ptr = base[9].func_;
  v23 = *(_OWORD *)&base[8].task_result_;
  *(_OWORD *)&base[8].task_result_ = 0;
  base[9].func_ = 0;
  task_result = base[9].task_result_;
  v26 = base[10];
  v5 = _mm_loadu_si128((const __m128i *)&base[11]);
  v27 = v5;
  *(_OWORD *)&base[11].next_ = 0;
  v6 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v6;
  v7 = *(_QWORD *)&base[1].task_result_;
  v29 = v7;
  if ( base )
  {
    v31[0] = v4;
    v30 = v5;
    operator delete(base);
    v5 = _mm_load_si128(&v30);
    v4.m128i_i64[0] = _mm_load_si128(v31).m128i_u64[0];
  }
  if ( !owner )
  {
    v6.m128i_i64[0] = _mm_shuffle_epi32(v5, 78).m128i_u64[0];
    v10 = (volatile signed __int64 *)v6.m128i_i64[0];
    if ( v6.m128i_i64[0] )
      goto LABEL_17;
LABEL_18:
    if ( (v23 & 1) == 0 )
      return;
    goto LABEL_19;
  }
  v16.task_result_ = 0;
  v8 = (void (*)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t))(v7 + v4.m128i_i64[0]);
  v17.m128i_i64[0] = v7 + v4.m128i_i64[0];
  base = (boost::asio::detail::operation *)ec.m128i_u32[0];
  if ( !v7 || ec.m128i_i32[0] || (v9 = v16.func_, v8 == v16.func_) )
  {
    v32.m_val = ec.m128i_i32[0];
    v32.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
      (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)&v17.m128i_u64[1],
      v32,
      (size_t)v8,
      0);
  }
  else
  {
    v11 = 0;
    if ( (char *)v16.func_ >= (char *)v8 )
      v11 = (char *)v8 + (unsigned __int64)v16.next_;
    else
      v9 = (boost::asio::detail::task_io_service_operation::func_type)(v7 + v4.m128i_i64[0]);
    v12 = (char *)v9 - (char *)v8;
    v13 = 0x10000;
    if ( v12 < 0x10000 )
      v13 = v12;
    base = (boost::asio::detail::operation *)impl;
    buffers.data_ = v11;
    buffers.size_ = v13;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
      *(boost::asio::stream_socket_service<boost::asio::ip::tcp> **)&impl[1].socket_,
      impl,
      &buffers,
      0,
      (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *)&impl);
  }
  _mm_sfence();
  v10 = (volatile signed __int64 *)v27.m128i_i64[1];
  if ( !v27.m128i_i64[1] )
    goto LABEL_18;
LABEL_17:
  if ( _InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    goto LABEL_18;
  (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, double, double, double))(*v10 + 16))(
    v10,
    base,
    a3,
    a4,
    *(double *)v6.m128i_i64,
    *(double *)v5.m128i_i64,
    *(double *)v4.m128i_i64);
  std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v10);
  if ( (v23 & 1) == 0 )
    return;
LABEL_19:
  operator delete(ptr);
}


// Address: 0x26b31e0 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_7read_opIS3_EENS1_17read_streambuf_opINSC_6streamIRSA_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSL_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES11_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __m128i v4; // xmm1
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm2
  __m128i v6; // xmm0
  __int64 v7; // rbx
  size_t v8; // rcx
  size_t size; // rax
  volatile signed __int64 *cntrl; // rbx
  char *v11; // rdi
  unsigned __int64 v12; // rax
  size_t v13; // rcx
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-110h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > handler; // [rsp+18h] [rbp-100h] BYREF
  __m128i ec; // [rsp+C8h] [rbp-50h]
  __int64 v17; // [rsp+D8h] [rbp-40h]
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v18; // [rsp+E0h] [rbp-38h] BYREF
  __m128i v19[2]; // [rsp+F0h] [rbp-28h] BYREF
  boost::system::error_code v20; // 0:kr00_16.16

  handler.stream_ = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)&base[3].task_result_;
  *(boost::asio::detail::operation *)&handler.buffer_.data_ = base[4];
  v4 = _mm_loadu_si128((const __m128i *)&base[5]);
  *(__m128i *)&handler.total_transferred_ = v4;
  handler.handler_.core_ = *(boost::asio::ssl::detail::stream_core **)&base[5].task_result_;
  *(boost::asio::detail::operation *)&handler.handler_.op_.buffers_.data_ = base[6];
  handler.handler_.ec_ = *(boost::system::error_code *)&base[7].next_;
  *(_OWORD *)&handler.handler_.bytes_transferred_ = *(_OWORD *)&base[7].task_result_;
  *(_OWORD *)&handler.handler_.handler_.stream_ = *(_OWORD *)&base[8].func_;
  handler.handler_.handler_.start_ = (int)base[9].next_;
  handler.handler_.handler_.total_transferred_ = (size_t)base[9].func_;
  handler.handler_.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)&base[9].task_result_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[10].func_);
  handler.handler_.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[10].func_ = 0;
  v6 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v6;
  v7 = *(_QWORD *)&base[1].task_result_;
  v17 = v7;
  if ( base )
  {
    v19[0] = v4;
    v18 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v18);
    v4.m128i_i64[0] = _mm_load_si128(v19).m128i_u64[0];
  }
  if ( !owner )
  {
    v6.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
    cntrl = (volatile signed __int64 *)v6.m128i_i64[0];
    if ( !v6.m128i_i64[0] )
      return;
    goto LABEL_17;
  }
  handler.start_ = 0;
  v8 = v7 + v4.m128i_i64[0];
  handler.total_transferred_ = v7 + v4.m128i_i64[0];
  base = (boost::asio::detail::operation *)ec.m128i_u32[0];
  if ( !v7 || ec.m128i_i32[0] || (size = handler.buffer_.size_, v8 == handler.buffer_.size_) )
  {
    v20.m_val = ec.m128i_i32[0];
    v20.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
      &handler.handler_,
      v20,
      v8,
      0);
  }
  else
  {
    v11 = 0;
    if ( handler.buffer_.size_ >= v8 )
      v11 = (char *)handler.buffer_.data_ + v8;
    else
      size = v7 + v4.m128i_i64[0];
    v12 = size - v8;
    v13 = 0x10000;
    if ( v12 < 0x10000 )
      v13 = v12;
    base = (boost::asio::detail::operation *)handler.stream_;
    buffers.data_ = v11;
    buffers.size_ = v13;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
      handler.stream_->service_,
      &handler.stream_->implementation,
      &buffers,
      0,
      &handler);
  }
  _mm_sfence();
  cntrl = (volatile signed __int64 *)handler.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( handler.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
LABEL_17:
    if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, double, double))(*cntrl + 16))(
        cntrl,
        base,
        a3,
        a4,
        *(double *)v6.m128i_i64,
        *(double *)v4.m128i_i64);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
  }
}


// Address: 0x26b6cb0 | Name: _ZN5boost4asio6detail23reactive_socket_send_opINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_7read_opIS3_EENS1_17read_streambuf_opINSC_6streamIRSA_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSP_5list3INSP_5valueINSL_10shared_ptrISX_EEEEPFNS_3argILi1EEEvENS14_IiEEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES11_m
void __fastcall boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __m128i v4; // xmm1
  boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm2
  __m128i v6; // xmm0
  __int64 v7; // rbx
  size_t v8; // rcx
  size_t size; // rax
  volatile signed __int64 *cntrl; // rbx
  char *v11; // rdi
  unsigned __int64 v12; // rax
  size_t v13; // rcx
  boost::asio::mutable_buffers_1 v14; // [rsp+0h] [rbp-118h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > > handler; // [rsp+10h] [rbp-108h] BYREF
  __m128i ec; // [rsp+C8h] [rbp-50h]
  __int64 v17; // [rsp+D8h] [rbp-40h]
  boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v18; // [rsp+E0h] [rbp-38h] BYREF
  __m128i v19[2]; // [rsp+F0h] [rbp-28h] BYREF
  boost::system::error_code v20; // 0:kr00_16.16

  handler.stream_ = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)&base[3].task_result_;
  *(boost::asio::detail::operation *)&handler.buffer_.data_ = base[4];
  v4 = _mm_loadu_si128((const __m128i *)&base[5]);
  *(__m128i *)&handler.total_transferred_ = v4;
  handler.handler_.core_ = *(boost::asio::ssl::detail::stream_core **)&base[5].task_result_;
  *(boost::asio::detail::operation *)&handler.handler_.op_.buffers_.data_ = base[6];
  handler.handler_.ec_ = *(boost::system::error_code *)&base[7].next_;
  *(_OWORD *)&handler.handler_.bytes_transferred_ = *(_OWORD *)&base[7].task_result_;
  *(_OWORD *)&handler.handler_.handler_.stream_ = *(_OWORD *)&base[8].func_;
  handler.handler_.handler_.start_ = (int)base[9].next_;
  handler.handler_.handler_.total_transferred_ = (size_t)base[9].func_;
  handler.handler_.handler_.handler_.f_ = *(boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int> *)&base[9].task_result_;
  si128 = (boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[10].func_);
  handler.handler_.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = si128;
  *(_OWORD *)&base[10].func_ = 0;
  handler.handler_.handler_.handler_.l_.a3_.t_ = (int)base[11].next_;
  v6 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v6;
  v7 = *(_QWORD *)&base[1].task_result_;
  v17 = v7;
  if ( base )
  {
    v19[0] = v4;
    v18 = si128;
    operator delete(base);
    si128 = (boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v18);
    v4.m128i_i64[0] = _mm_load_si128(v19).m128i_u64[0];
  }
  if ( !owner )
  {
    v6.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
    cntrl = (volatile signed __int64 *)v6.m128i_i64[0];
    if ( !v6.m128i_i64[0] )
      return;
    goto LABEL_17;
  }
  handler.start_ = 0;
  v8 = v7 + v4.m128i_i64[0];
  handler.total_transferred_ = v7 + v4.m128i_i64[0];
  base = (boost::asio::detail::operation *)ec.m128i_u32[0];
  if ( !v7 || ec.m128i_i32[0] || (size = handler.buffer_.size_, v8 == handler.buffer_.size_) )
  {
    v20.m_val = ec.m128i_i32[0];
    v20.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>::operator()(
      &handler.handler_,
      v20,
      v8,
      0);
  }
  else
  {
    v11 = 0;
    if ( handler.buffer_.size_ >= v8 )
      v11 = (char *)handler.buffer_.data_ + v8;
    else
      size = v7 + v4.m128i_i64[0];
    v12 = size - v8;
    v13 = 0x10000;
    if ( v12 < 0x10000 )
      v13 = v12;
    base = (boost::asio::detail::operation *)handler.stream_;
    v14.data_ = v11;
    v14.size_ = v13;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>>(
      handler.stream_->service_,
      &handler.stream_->implementation,
      &v14,
      0,
      &handler);
  }
  _mm_sfence();
  cntrl = (volatile signed __int64 *)handler.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( handler.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
LABEL_17:
    if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, double, double))(*cntrl + 16))(
        cntrl,
        base,
        a3,
        a4,
        *(double *)v6.m128i_i64,
        *(double *)v4.m128i_i64);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
  }
}


