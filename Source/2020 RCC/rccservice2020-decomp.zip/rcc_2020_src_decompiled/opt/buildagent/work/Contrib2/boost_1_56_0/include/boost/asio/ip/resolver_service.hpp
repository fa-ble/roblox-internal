// Address: 0x261e2c0 | Name: _ZN5boost4asio2ip16resolver_serviceINS1_3tcpEE9constructERNSt3__110shared_ptrIvEE
void __fastcall boost::asio::ip::resolver_service<boost::asio::ip::tcp>::construct(
        boost::asio::ip::resolver_service<boost::asio::ip::tcp> *this,
        boost::asio::ip::resolver_service<boost::asio::ip::tcp>::implementation_type *impl)
{
  char *v2; // rax
  volatile signed __int64 *cntrl; // r14

  v2 = (char *)operator new(0x20u);
  *(_OWORD *)(v2 + 8) = 0;
  *(_QWORD *)v2 = &off_29C3D98;
  *((_QWORD *)v2 + 3) = 0;
  impl->__ptr_ = 0;
  cntrl = (volatile signed __int64 *)impl->__cntrl_;
  impl->__cntrl_ = (std::__shared_weak_count *)v2;
  if ( cntrl )
  {
    if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
  }
}


// Address: 0x261e3c0 | Name: _ZN5boost4asio2ip16resolver_serviceINS1_3tcpEED2Ev
void __fastcall boost::asio::ip::resolver_service<boost::asio::ip::tcp>::~resolver_service(
        boost::asio::ip::resolver_service<boost::asio::ip::tcp> *this)
{
  this->_vptr$service = (int (**)(void))&off_29C3CD8;
  boost::asio::detail::resolver_service_base::~resolver_service_base(&this->service_impl_);
}


// Address: 0x261e3e0 | Name: _ZN5boost4asio2ip16resolver_serviceINS1_3tcpEED0Ev
void __fastcall boost::asio::ip::resolver_service<boost::asio::ip::tcp>::~resolver_service(
        boost::asio::ip::resolver_service<boost::asio::ip::tcp> *this)
{
  this->_vptr$service = (int (**)(void))&off_29C3CD8;
  boost::asio::detail::resolver_service_base::~resolver_service_base(&this->service_impl_);
  operator delete(this);
}


// Address: 0x261e400 | Name: _ZN5boost4asio2ip16resolver_serviceINS1_3tcpEE16shutdown_serviceEv
void __fastcall boost::asio::ip::resolver_service<boost::asio::ip::tcp>::shutdown_service(
        boost::asio::ip::resolver_service<boost::asio::ip::tcp> *this)
{
  boost::asio::detail::resolver_service_base::shutdown_service(&this->service_impl_);
}


// Address: 0x261e410 | Name: _ZN5boost4asio2ip16resolver_serviceINS1_3tcpEE12fork_serviceENS0_10io_service10fork_eventE
void __fastcall boost::asio::ip::resolver_service<boost::asio::ip::tcp>::fork_service(
        boost::asio::ip::resolver_service<boost::asio::ip::tcp> *this,
        boost::asio::io_service::fork_event event)
{
  boost::asio::detail::resolver_service_base::fork_service(&this->service_impl_, event);
}


// Address: 0x261fbe0 | Name: _ZN5boost4asio2ip16resolver_serviceINS1_3tcpEE6cancelERNSt3__110shared_ptrIvEE
void __fastcall boost::asio::ip::resolver_service<boost::asio::ip::tcp>::cancel(
        boost::asio::ip::resolver_service<boost::asio::ip::tcp> *this,
        boost::asio::ip::resolver_service<boost::asio::ip::tcp>::implementation_type *impl)
{
  char *v2; // rax
  volatile signed __int64 *cntrl; // r14

  v2 = (char *)operator new(0x20u);
  *(_OWORD *)(v2 + 8) = 0;
  *(_QWORD *)v2 = &off_29C3D98;
  *((_QWORD *)v2 + 3) = 0;
  impl->__ptr_ = 0;
  cntrl = (volatile signed __int64 *)impl->__cntrl_;
  impl->__cntrl_ = (std::__shared_weak_count *)v2;
  if ( cntrl )
  {
    if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
  }
}


