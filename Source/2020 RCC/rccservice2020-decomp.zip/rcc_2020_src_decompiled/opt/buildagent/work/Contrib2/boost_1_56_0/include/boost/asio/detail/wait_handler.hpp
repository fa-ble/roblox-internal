// Address: 0x26068a0 | Name: _ZN5boost4asio6detail12wait_handlerINS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config15asio_tls_client16transport_configEEEFvNS6_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISJ_EENS0_22deadline_timer_serviceISJ_SL_EEEEEENS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNSG_ISF_EERSP_RSV_RKNS6_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v7; // rbx
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::ptr v8; // [rsp+8h] [rbp-C0h] BYREF
  boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code> this_handler; // [rsp+20h] [rbp-A8h] BYREF
  unsigned __int64 v10; // [rsp+A8h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  v8.h = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)&base[2];
  v8.v = base;
  v8.p = (boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)base;
  this_handler.handler_.dispatcher_ = *(boost::asio::io_service::strand *)&base[2].next_;
  *(_OWORD *)&this_handler.handler_.handler_.__f_ = *(_OWORD *)&base[2].task_result_;
  this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)&base[3].func_;
  *(_OWORD *)&base[3].func_ = 0;
  this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)&base[4].next_;
  *(_OWORD *)&base[4].next_ = 0;
  next = base[6].next_;
  if ( next )
  {
    if ( &base[4].task_result_ == (unsigned int *)next )
    {
      this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
        next,
        &this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[6].next_;
      base[6].next_ = 0;
    }
  }
  else
  {
    this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this_handler.arg1_ = *(boost::system::error_code *)&base[1].next_;
  v8.h = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)&this_handler;
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::ptr::reset(&v8);
  if ( owner )
  {
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
      &this_handler,
      &this_handler.handler_);
    _mm_sfence();
  }
  if ( &this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v7 = this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::ptr::reset(&v8);
}


// Address: 0x2606af0 | Name: _ZN5boost4asio6detail12wait_handlerINS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config15asio_tls_client16transport_configEEEFvNS6_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISJ_EENS0_22deadline_timer_serviceISJ_SL_EEEEEENS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNSG_ISF_EERSP_RSV_RKNS6_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEE3ptr5resetEv
void __fastcall boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::ptr::reset(
        boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::ptr *this)
{
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *p; // rbx
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *f; // rdi
  volatile signed __int64 *cntrl; // r15
  volatile signed __int64 *v5; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v7; // rax
  _QWORD *v8; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    v5 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v7 = __readfsqword(0xFFFFFFD8);
    if ( v7 && (v8 = *(_QWORD **)(v7 + 8)) != 0 && !*v8 )
    {
      *v = v[160];
      *v8 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x260ab10 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESI_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v4; // rbx
  boost::asio::detail::operation *v6; // r12
  boost::asio::detail::operation *next; // rdi
  boost::asio::detail::operation *v8; // rdi
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > v11; // [rsp+0h] [rbp-A8h] BYREF
  __int128 ec; // [rsp+70h] [rbp-38h]
  unsigned __int64 v13; // [rsp+80h] [rbp-28h]
  boost::system::error_code v14; // 0:kr00_16.16

  v4 = base;
  v13 = __readfsqword(0x28u);
  v6 = base + 1;
  *(_OWORD *)&v11.next_layer_ = *(_OWORD *)&base[2].next_;
  v11.start_ = *(&base[2].task_result_ + 1);
  v11.want_ = (boost::asio::ssl::detail::engine::want)base[3].next_;
  v11.ec_ = *(boost::system::error_code *)&base[3].func_;
  v11.bytes_transferred_ = (size_t)base[4].next_;
  next = base[6].next_;
  if ( next )
  {
    if ( &base[4].task_result_ != (unsigned int *)next )
    {
      v11.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)base[6].next_;
      base[6].next_ = 0;
      ec = *(_OWORD *)&v6->next_;
      goto LABEL_10;
    }
    v11.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)&v11.handler_;
    base = (boost::asio::detail::operation *)&v11.handler_;
    ((void (__fastcall *)(boost::asio::detail::operation *, std::function<void (const boost::system::error_code &)> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
      next,
      &v11.handler_,
      a3,
      a4);
  }
  else
  {
    v11.handler_.__f_ = 0;
  }
  ec = *(_OWORD *)&v6->next_;
  v8 = v4[6].next_;
  if ( &v4[4].task_result_ == (unsigned int *)v8 )
  {
    v8->next_[1].func_((boost::asio::detail::task_io_service *)v8, base, a3, a4);
  }
  else if ( v8 )
  {
    (*(void (__fastcall **)(boost::asio::detail::operation *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&v8->next_[1].task_result_)(
      v8,
      base,
      a3,
      a4);
  }
LABEL_10:
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 || (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) == 0 || *v10 )
  {
    operator delete(v4);
    if ( !owner )
      goto LABEL_15;
    goto LABEL_14;
  }
  LOBYTE(v4->next_) = v4[6].task_result_;
  *v10 = v4;
  if ( owner )
  {
LABEL_14:
    base = (boost::asio::detail::operation *)(unsigned int)ec;
    v14.m_val = ec;
    v14.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>::operator()(
      &v11,
      v14,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
  }
LABEL_15:
  if ( &v11.handler_ == (std::function<void (const boost::system::error_code &)> *)v11.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *))v11.handler_.__f_->_vptr$__base
     + 4))(v11.handler_.__f_);
  }
  else if ( v11.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *, boost::asio::detail::operation *))v11.handler_.__f_->_vptr$__base
     + 5))(
      v11.handler_.__f_,
      base);
  }
}


// Address: 0x2613350 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_8write_opINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorISE_NSF_9allocatorISE_EEEEEEEENS1_8write_opINS3_6streamISB_EESJ_NS1_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSF_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESY_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  void (*next)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t); // rdi
  boost::asio::detail::task_io_service_operation *v7; // rdi
  _BYTE v8[16]; // [rsp+0h] [rbp-138h] BYREF
  void *v9; // [rsp+10h] [rbp-128h]
  void *v10; // [rsp+18h] [rbp-120h]
  void *ptr; // [rsp+78h] [rbp-C0h]
  void *v12; // [rsp+80h] [rbp-B8h]
  __int64 v13; // [rsp+D0h] [rbp-68h]
  char v14; // [rsp+E0h] [rbp-58h] BYREF
  char *v15; // [rsp+100h] [rbp-38h]
  __int128 ec; // [rsp+110h] [rbp-28h]
  unsigned __int64 v17; // [rsp+120h] [rbp-18h]
  boost::system::error_code v18; // 0:esi.4,8:rdx.8

  v17 = __readfsqword(0x28u);
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v8,
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)&base[2]);
  ec = *(_OWORD *)&base[1].next_;
  if ( base )
  {
    v5 = *(boost::asio::detail::operation **)&base[12].task_result_;
    if ( &base[11].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v5 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v5->next_[1].func_)(v5);
    }
    else if ( v5 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v5->next_[1].task_result_)(v5);
    }
    next = (void (*)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t))base[7].next_;
    if ( next )
    {
      base[7].func_ = next;
      operator delete(next);
    }
    v7 = *(boost::asio::detail::task_io_service_operation **)&base[2].task_result_;
    if ( v7 )
    {
      base[3].next_ = v7;
      operator delete(v7);
    }
  }
  if ( (boost::asio::detail::operation *)v13 == base )
  {
    *(_BYTE *)(v13 + 1024) = 0;
    if ( !owner )
      goto LABEL_15;
    goto LABEL_14;
  }
  operator delete(base);
  if ( owner )
  {
LABEL_14:
    v18.m_val = ec;
    v18.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::operator()(
      (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v8,
      v18,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
  }
LABEL_15:
  if ( &v14 == v15 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v15 + 32LL))(v15);
  }
  else if ( v15 )
  {
    (*(void (**)(void))(*(_QWORD *)v15 + 40LL))();
  }
  if ( ptr )
  {
    v12 = ptr;
    operator delete(ptr);
  }
  if ( v9 )
  {
    v10 = v9;
    operator delete(v9);
  }
}


// Address: 0x2616e70 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_7read_opINS0_17mutable_buffers_1EEENS1_7read_opINS3_6streamISB_EESD_NS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESS_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::operation *v6; // rbx
  boost::asio::detail::operation *v8; // r12
  boost::asio::detail::operation *v9; // rdi
  boost::asio::detail::operation *v10; // rdi
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > v11; // [rsp+0h] [rbp-E8h] BYREF
  __int128 ec; // [rsp+B0h] [rbp-38h]
  unsigned __int64 v13; // [rsp+C0h] [rbp-28h]
  boost::system::error_code v14; // 0:esi.4,8:rdx.8

  v6 = base;
  v13 = __readfsqword(0x28u);
  v8 = base + 1;
  *(_OWORD *)&v11.next_layer_ = *(_OWORD *)&base[2].next_;
  v11.op_ = *(boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)&base[2].task_result_;
  *(_QWORD *)&v11.start_ = base[3].func_;
  v11.ec_ = *(boost::system::error_code *)&base[3].task_result_;
  *(_OWORD *)&v11.bytes_transferred_ = *(_OWORD *)&base[4].func_;
  *(boost::asio::detail::operation *)&v11.handler_.stream_ = base[5];
  v11.handler_.start_ = (int)base[6].next_;
  *(_OWORD *)&v11.handler_.total_transferred_ = *(_OWORD *)&base[6].func_;
  v9 = *(boost::asio::detail::operation **)&base[8].task_result_;
  if ( v9 )
  {
    if ( &base[7].func_ != (boost::asio::detail::task_io_service_operation::func_type *)v9 )
    {
      v11.handler_.handler_.handler_.__f_ = *(std::function<void (const boost::system::error_code &,unsigned long)>::__base **)&base[8].task_result_;
      *(_QWORD *)&base[8].task_result_ = 0;
      ec = *(_OWORD *)&v8->next_;
      goto LABEL_10;
    }
    v11.handler_.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&v11.handler_.handler_.handler_;
    base = (boost::asio::detail::operation *)&v11.handler_.handler_.handler_;
    ((void (__fastcall *)(boost::asio::detail::operation *, std::function<void (const boost::system::error_code &,unsigned long)> *, const boost::system::error_code *, size_t, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *, void *, size_t, int, size_t))v9->next_[1].next_)(
      v9,
      &v11.handler_.handler_.handler_,
      a3,
      a4,
      v4,
      v5,
      v11.next_layer_,
      v11.core_,
      v11.op_.buffers_.data_,
      v11.op_.buffers_.size_,
      *(_QWORD *)&v11.start_,
      *(_QWORD *)&v11.ec_.m_val,
      v11.ec_.m_cat,
      v11.bytes_transferred_,
      v11.handler_.completion_condition_.minimum_,
      v11.handler_.stream_,
      v11.handler_.buffer_.data_,
      v11.handler_.buffer_.size_,
      v11.handler_.start_,
      v11.handler_.total_transferred_);
  }
  else
  {
    v11.handler_.handler_.handler_.__f_ = 0;
  }
  ec = *(_OWORD *)&v8->next_;
  v10 = *(boost::asio::detail::operation **)&v6[8].task_result_;
  if ( &v6[7].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v10 )
  {
    v10->next_[1].func_((boost::asio::detail::task_io_service *)v10, base, a3, a4);
  }
  else if ( v10 )
  {
    (*(void (__fastcall **)(boost::asio::detail::operation *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&v10->next_[1].task_result_)(
      v10,
      base,
      a3,
      a4);
  }
LABEL_10:
  if ( (boost::asio::detail::operation *)v11.handler_.handler_.allocator_ == v6 )
  {
    v11.handler_.handler_.allocator_->in_use_ = 0;
    if ( !owner )
      goto LABEL_15;
    goto LABEL_14;
  }
  operator delete(v6);
  if ( owner )
  {
LABEL_14:
    v14.m_val = ec;
    v14.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::operator()(
      &v11,
      v14,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
  }
LABEL_15:
  if ( &v11.handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v11.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v11.handler_.handler_.handler_.__f_->_vptr$__base
     + 4))(v11.handler_.handler_.handler_.__f_);
  }
  else if ( v11.handler_.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v11.handler_.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x2633c80 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSG_8functionIFvRKNSG_10error_codeEEEERKNS_6system10error_codeEEJNSG_10shared_ptrISM_EERSS_RKNSG_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESW_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >::ptr v7; // [rsp+8h] [rbp-F0h] BYREF
  boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> function; // [rsp+20h] [rbp-D8h] BYREF
  unsigned __int64 v9; // [rsp+D8h] [rbp-20h]

  v9 = __readfsqword(0x28u);
  v7.h = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[2];
  v7.v = base;
  v7.p = (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *)base;
  *(boost::asio::detail::operation *)&function.handler_.next_layer_ = base[2];
  function.handler_.want_ = (boost::asio::ssl::detail::engine::want)base[3].next_;
  function.handler_.ec_ = *(boost::system::error_code *)&base[3].func_;
  function.handler_.bytes_transferred_ = (size_t)base[4].next_;
  function.handler_.handler_.dispatcher_ = *(boost::asio::io_service::strand *)&base[4].task_result_;
  *(_OWORD *)&function.handler_.handler_.handler_.__f_ = *(_OWORD *)&base[5].func_;
  function.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> *)&base[6].next_;
  *(_OWORD *)&base[6].next_ = 0;
  next = base[8].next_;
  if ( next )
  {
    if ( &base[6].task_result_ == (unsigned int *)next )
    {
      function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&function.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
        next,
        &function.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[8].next_;
      base[8].next_ = 0;
    }
  }
  else
  {
    function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  function.arg1_ = *(boost::system::error_code *)&base[1].next_;
  v7.h = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&function;
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(&v7);
  if ( owner )
  {
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
      &function,
      &function.handler_.handler_);
    _mm_sfence();
  }
  if ( &function.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)function.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(&v7);
}


// Address: 0x2633eb0 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSG_8functionIFvRKNSG_10error_codeEEEERKNS_6system10error_codeEEJNSG_10shared_ptrISM_EERSS_RKNSG_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(
        boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >::ptr *this)
{
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *p; // rbx
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *f; // rdi
  volatile signed __int64 *cntrl; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *)p->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[208];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x2637c70 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSD_8functionIFvRKNSD_10error_codeEEEERKNS_6system10error_codeEEJNSD_10shared_ptrISJ_EERSP_RKNSD_12placeholders4__phILi1EEEEEEEEEC2ERS15_
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::wait_handler(
        boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *this,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *h)
{
  std::function<void (const std::error_code &)>::__base *f; // rax

  this->next_ = 0;
  this->func_ = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
  this->task_result_ = 0;
  this->ec_.m_val = 0;
  this->ec_.m_cat = boost::system::system_category();
  this->handler_.next_layer_ = h->next_layer_;
  this->handler_.core_ = h->core_;
  this->handler_.op_.type_ = h->op_.type_;
  this->handler_.start_ = h->start_;
  this->handler_.want_ = h->want_;
  this->handler_.ec_ = h->ec_;
  this->handler_.bytes_transferred_ = h->bytes_transferred_;
  *(_OWORD *)&this->handler_.handler_.__f_ = *(_OWORD *)&h->handler_.__f_;
  this->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = h->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  h->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = h->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &h->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))h->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(h->handler_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->handler_.handler_.__bound_args_.__base_.__value_.__f_ = f;
      h->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
}


// Address: 0x2637d60 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSD_8functionIFvRKNSD_10error_codeEEEERKNS_6system10error_codeEEJNSD_10shared_ptrISJ_EERSP_RKNSD_12placeholders4__phILi1EEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationEST_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *func; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > >::ptr v7; // [rsp+8h] [rbp-E0h] BYREF
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v8; // [rsp+20h] [rbp-C8h] BYREF
  __int128 ec; // [rsp+B0h] [rbp-38h]
  unsigned __int64 v10; // [rsp+C8h] [rbp-20h]
  boost::system::error_code v11; // 0:esi.4,8:rdx.8

  v10 = __readfsqword(0x28u);
  v7.h = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[2];
  v7.v = base;
  v7.p = (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *)base;
  *(boost::asio::detail::operation *)&v8.next_layer_ = base[2];
  v8.want_ = (boost::asio::ssl::detail::engine::want)base[3].next_;
  v8.ec_ = *(boost::system::error_code *)&base[3].func_;
  v8.bytes_transferred_ = (size_t)base[4].next_;
  *(_OWORD *)&v8.handler_.__f_ = *(_OWORD *)&base[4].task_result_;
  v8.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> *)&base[5].func_;
  *(_OWORD *)&base[5].func_ = 0;
  func = (boost::asio::detail::operation *)base[7].func_;
  if ( func )
  {
    if ( &base[6] == func )
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))func->next_[1].next_)(
        func,
        &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[7].func_;
      base[7].func_ = 0;
    }
  }
  else
  {
    v8.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  ec = *(_OWORD *)&base[1].next_;
  v7.h = &v8;
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::ptr::reset(&v7);
  if ( owner )
  {
    v11.m_val = ec;
    v11.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::operator()(
      &v8,
      v11,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
  }
  if ( &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v8.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v8.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::ptr::reset(&v7);
}


// Address: 0x2637f90 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSD_8functionIFvRKNSD_10error_codeEEEERKNS_6system10error_codeEEJNSD_10shared_ptrISJ_EERSP_RKNSD_12placeholders4__phILi1EEEEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::ptr::reset(
        boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > >::ptr *this)
{
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *p; // rbx
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *f; // rdi
  volatile signed __int64 *cntrl; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[192];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x2656c10 | Name: _ZN5boost4asio6detail12wait_handlerINS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config11asio_client16transport_configEEEFvNS6_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISJ_EENS0_22deadline_timer_serviceISJ_SL_EEEEEENS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNSG_ISF_EERSP_RSV_RKNS6_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v7; // rbx
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::ptr v8; // [rsp+8h] [rbp-C0h] BYREF
  boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code> this_handler; // [rsp+20h] [rbp-A8h] BYREF
  unsigned __int64 v10; // [rsp+A8h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  v8.h = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)&base[2];
  v8.v = base;
  v8.p = (boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)base;
  this_handler.handler_.dispatcher_ = *(boost::asio::io_service::strand *)&base[2].next_;
  *(_OWORD *)&this_handler.handler_.handler_.__f_ = *(_OWORD *)&base[2].task_result_;
  this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)&base[3].func_;
  *(_OWORD *)&base[3].func_ = 0;
  this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)&base[4].next_;
  *(_OWORD *)&base[4].next_ = 0;
  next = base[6].next_;
  if ( next )
  {
    if ( &base[4].task_result_ == (unsigned int *)next )
    {
      this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
        next,
        &this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[6].next_;
      base[6].next_ = 0;
    }
  }
  else
  {
    this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this_handler.arg1_ = *(boost::system::error_code *)&base[1].next_;
  v8.h = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)&this_handler;
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::ptr::reset(&v8);
  if ( owner )
  {
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
      &this_handler,
      &this_handler.handler_);
    _mm_sfence();
  }
  if ( &this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v7 = this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::ptr::reset(&v8);
}


// Address: 0x2656e60 | Name: _ZN5boost4asio6detail12wait_handlerINS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS8_6config11asio_client16transport_configEEEFvNS6_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISJ_EENS0_22deadline_timer_serviceISJ_SL_EEEEEENS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNSG_ISF_EERSP_RSV_RKNS6_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEE3ptr5resetEv
void __fastcall boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::ptr::reset(
        boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::ptr *this)
{
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *p; // rbx
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *f; // rdi
  volatile signed __int64 *cntrl; // r15
  volatile signed __int64 *v5; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v7; // rax
  _QWORD *v8; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    v5 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v7 = __readfsqword(0xFFFFFFD8);
    if ( v7 && (v8 = *(_QWORD **)(v7 + 8)) != 0 && !*v8 )
    {
      *v = v[160];
      *v8 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x2698220 | Name: _ZN5boost4asio6detail12wait_handlerINS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details20asio_connection_poolERKNS_6system10error_codeERKNSt3__18weak_ptrINSA_15asio_connectionEEEEENS3_5list3INS3_5valueIPSB_EEPFNS_3argILi1EEEvENSO_INSG_10shared_ptrISI_EEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESF_m
void __fastcall boost::asio::detail::wait_handler<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_connection_pool,boost::system::error_code const&,std::weak_ptr<web::http::client::details::asio_connection> const&>,boost::_bi::list3<boost::_bi::value<web::http::client::details::asio_connection_pool*>,boost::arg<1> (*)(void),boost::_bi::value<std::shared_ptr<web::http::client::details::asio_connection>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __m128i si128; // xmm1
  volatile signed __int64 *next; // rbx
  __m128i v6; // xmm0
  unsigned __int64 v7; // rax
  boost::asio::detail::operation **v8; // rax
  void (__fastcall *v9)(size_t *, __m128i *, __int64 *, size_t); // rax
  size_t *v10; // rdi
  __int64 v11; // [rsp+0h] [rbp-78h] BYREF
  std::__shared_weak_count *v12; // [rsp+8h] [rbp-70h]
  __int128 v13; // [rsp+10h] [rbp-68h]
  __m128i v14; // [rsp+20h] [rbp-58h]
  volatile signed __int64 *v15; // [rsp+30h] [rbp-48h]
  __m128i v16; // [rsp+38h] [rbp-40h] BYREF
  __m128i v17[2]; // [rsp+50h] [rbp-28h] BYREF

  v13 = *(_OWORD *)&base[1].task_result_;
  si128 = _mm_loadu_si128((const __m128i *)&base[2].func_);
  v14 = si128;
  next = (volatile signed __int64 *)base[3].next_;
  v15 = next;
  *(_OWORD *)&base[2].task_result_ = 0;
  v6 = _mm_loadu_si128((const __m128i *)&base[1]);
  v16 = v6;
  if ( base )
  {
    v7 = __readfsqword(0xFFFFFFD8);
    if ( v7 )
    {
      v8 = *(boost::asio::detail::operation ***)(v7 + 8);
      if ( v8 )
      {
        if ( !*v8 )
        {
          LOBYTE(a4) = base[3].func_;
          LOBYTE(base->next_) = a4;
          *v8 = base;
          if ( !owner )
            goto LABEL_14;
          goto LABEL_7;
        }
      }
    }
    v17[0] = si128;
    operator delete(base);
    si128 = _mm_load_si128(v17);
  }
  if ( !owner )
    goto LABEL_14;
LABEL_7:
  v6.m128i_i64[0] = _mm_shuffle_epi32(si128, 78).m128i_u64[0];
  v11 = v6.m128i_i64[0];
  v12 = (std::__shared_weak_count *)next;
  if ( next )
    _InterlockedAdd64(next + 2, 1u);
  base = (boost::asio::detail::operation *)&v16;
  v9 = (void (__fastcall *)(size_t *, __m128i *, __int64 *, size_t))v13;
  v10 = (size_t *)(*((_QWORD *)&v13 + 1) + v14.m128i_i64[0]);
  if ( (v13 & 1) != 0 )
  {
    a4 = *v10;
    v9 = *(void (__fastcall **)(size_t *, __m128i *, __int64 *, size_t))(*v10 + v13 - 1);
  }
  v9(v10, &v16, &v11, a4);
  if ( v12 )
    std::__shared_weak_count::__release_weak(v12);
  _mm_sfence();
  next = v15;
LABEL_14:
  if ( next )
  {
    if ( !_InterlockedExchangeAdd64(next + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, double, double))(*next + 16))(
        next,
        base,
        a3,
        a4,
        *(double *)v6.m128i_i64,
        *(double *)si128.m128i_i64);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)next);
    }
  }
}


// Address: 0x269f4e0 | Name: _ZN5boost4asio6detail12wait_handlerIZN3web4http6client7details12asio_context13timeout_timer5startEvEUlRKNS_6system10error_codeEE_E11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESC_m
void __fastcall boost::asio::detail::wait_handler<web::http::client::details::asio_context::timeout_timer::start(void)::{lambda(boost::system::error_code const&)#1}>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __m128i v4; // xmm1
  unsigned __int64 v5; // rax
  boost::asio::detail::operation **v6; // rax
  std::__shared_weak_count *v7; // rdi
  std::__shared_weak_count *v8[2]; // [rsp+0h] [rbp-38h] BYREF
  boost::system::error_code ec; // [rsp+10h] [rbp-28h] BYREF
  __m128i v10; // [rsp+20h] [rbp-18h] BYREF

  v4 = _mm_loadu_si128((const __m128i *)&base[1].task_result_);
  *(__m128i *)v8 = v4;
  *(_OWORD *)&base[1].task_result_ = 0;
  ec = (boost::system::error_code)_mm_loadu_si128((const __m128i *)&base[1]);
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_11;
  }
  v5 = __readfsqword(0xFFFFFFD8);
  if ( !v5 || (v6 = *(boost::asio::detail::operation ***)(v5 + 8)) == 0 || *v6 )
  {
    v10 = v4;
    operator delete(base);
    v4 = _mm_load_si128(&v10);
    goto LABEL_6;
  }
  LOBYTE(base->next_) = base[2].func_;
  *v6 = base;
  if ( owner )
  {
LABEL_7:
    web::http::client::details::asio_context::timeout_timer::handle_timeout(
      &ec,
      (const std::weak_ptr<web::http::client::details::asio_context> *)v8);
    _mm_sfence();
    v7 = v8[1];
    if ( !v8[1] )
      return;
    goto LABEL_8;
  }
LABEL_11:
  v7 = (std::__shared_weak_count *)_mm_shuffle_epi32(v4, 78).m128i_u64[0];
  if ( !v7 )
    return;
LABEL_8:
  std::__shared_weak_count::__release_weak(v7);
}


// Address: 0x26a0e50 | Name: _ZN5boost4asio6detail12wait_handlerIZN3web4http6client7details12asio_context13timeout_timer5resetEvEUlRKNS_6system10error_codeEE_E11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESC_m
void __fastcall boost::asio::detail::wait_handler<web::http::client::details::asio_context::timeout_timer::reset(void)::{lambda(boost::system::error_code const&)#1}>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __m128i v4; // xmm1
  unsigned __int64 v5; // rax
  boost::asio::detail::operation **v6; // rax
  std::__shared_weak_count *v7; // rdi
  std::__shared_weak_count *v8[2]; // [rsp+0h] [rbp-38h] BYREF
  boost::system::error_code ec; // [rsp+10h] [rbp-28h] BYREF
  __m128i v10; // [rsp+20h] [rbp-18h] BYREF

  v4 = _mm_loadu_si128((const __m128i *)&base[1].task_result_);
  *(__m128i *)v8 = v4;
  *(_OWORD *)&base[1].task_result_ = 0;
  ec = (boost::system::error_code)_mm_loadu_si128((const __m128i *)&base[1]);
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_11;
  }
  v5 = __readfsqword(0xFFFFFFD8);
  if ( !v5 || (v6 = *(boost::asio::detail::operation ***)(v5 + 8)) == 0 || *v6 )
  {
    v10 = v4;
    operator delete(base);
    v4 = _mm_load_si128(&v10);
    goto LABEL_6;
  }
  LOBYTE(base->next_) = base[2].func_;
  *v6 = base;
  if ( owner )
  {
LABEL_7:
    web::http::client::details::asio_context::timeout_timer::handle_timeout(
      &ec,
      (const std::weak_ptr<web::http::client::details::asio_context> *)v8);
    _mm_sfence();
    v7 = v8[1];
    if ( !v8[1] )
      return;
    goto LABEL_8;
  }
LABEL_11:
  v7 = (std::__shared_weak_count *)_mm_shuffle_epi32(v4, 78).m128i_u64[0];
  if ( !v7 )
    return;
LABEL_8:
  std::__shared_weak_count::__release_weak(v7);
}


// Address: 0x26a3240 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_8write_opINS0_15const_buffers_1EEENS1_8write_opINS3_6streamIRSB_EESD_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSO_5list2INSO_5valueINSL_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES11_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> si128; // xmm1
  __m128i v7; // xmm0
  unsigned __int64 v8; // rax
  boost::asio::detail::operation **v9; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> v11; // [rsp+0h] [rbp-C8h] BYREF
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > v12; // [rsp+10h] [rbp-B8h] BYREF
  __m128i ec; // [rsp+A0h] [rbp-28h]
  boost::system::error_code v14; // 0:kr00_16.16

  *(_OWORD *)&v12.next_layer_ = *(_OWORD *)&base[1].task_result_;
  v12.op_ = *(boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *)&base[2].func_;
  *(boost::asio::detail::operation *)&v12.start_ = base[3];
  *(_OWORD *)&v12.bytes_transferred_ = *(_OWORD *)&base[4].next_;
  v12.handler_.buffer_ = *(boost::asio::const_buffer *)&base[4].task_result_;
  v12.handler_.start_ = (int)base[5].func_;
  *(_OWORD *)&v12.handler_.total_transferred_ = *(_OWORD *)&base[5].task_result_;
  v12.handler_.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> *)&base[6].func_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[7]);
  v12.handler_.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[7].next_ = 0;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 || (v9 = *(boost::asio::detail::operation ***)(v8 + 8)) == 0 || *v9 )
  {
    v11 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v11);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[7].task_result_;
  LOBYTE(base->next_) = a4;
  *v9 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)ec.m128i_u32[0];
    v14.m_val = ec.m128i_i32[0];
    v14.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::operator()(
      &v12,
      v14,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v12.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( !v12.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
  if ( !v7.m128i_i64[0] )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, const void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *, const void *, size_t, int, size_t, boost::asio::basic_streambuf<std::allocator<char> > *, boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)v7.m128i_i64,
      *(double *)&si128.a1_.t_.__ptr_,
      v11.a1_.t_.__ptr_,
      v11.a1_.t_.__cntrl_,
      v12.next_layer_,
      v12.core_,
      v12.op_.buffers_.data_,
      v12.op_.buffers_.size_,
      *(_QWORD *)&v12.start_,
      *(_QWORD *)&v12.ec_.m_val,
      v12.ec_.m_cat,
      v12.bytes_transferred_,
      v12.handler_.stream_,
      v12.handler_.buffer_.data_,
      v12.handler_.buffer_.size_,
      v12.handler_.start_,
      v12.handler_.total_transferred_,
      v12.handler_.handler_.streambuf_,
      v12.handler_.handler_.handler_.f_.f_,
      *((_QWORD *)&v12.handler_.handler_.handler_.f_.f_ + 1),
      v12.handler_.handler_.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26a60a0 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_7read_opINS0_17mutable_buffers_1EEENS1_26read_until_delim_string_opINS3_6streamIRSB_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  std::__shared_weak_count *v4; // rbx
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::ptr v5; // [rsp+8h] [rbp-D0h] BYREF
  _OWORD v6[2]; // [rsp+20h] [rbp-B8h] BYREF
  boost::asio::detail::operation v7; // [rsp+40h] [rbp-98h]
  boost::asio::detail::operation v8; // [rsp+58h] [rbp-80h]
  __int128 v9; // [rsp+70h] [rbp-68h]
  void *ptr; // [rsp+80h] [rbp-58h]
  int next; // [rsp+88h] [rbp-50h]
  boost::asio::detail::task_io_service_operation::func_type func; // [rsp+90h] [rbp-48h]
  __int128 v13; // [rsp+98h] [rbp-40h]
  std::__shared_weak_count *v14[2]; // [rsp+A8h] [rbp-30h]
  __int128 ec; // [rsp+B8h] [rbp-20h]
  boost::system::error_code v16; // 0:esi.4,8:rdx.8

  v5.v = base;
  v5.p = (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *)base;
  v6[0] = *(_OWORD *)&base[1].task_result_;
  v6[1] = *(_OWORD *)&base[2].func_;
  v7 = base[3];
  v8 = base[4];
  ptr = *(void **)&base[5].task_result_;
  v9 = *(_OWORD *)&base[5].next_;
  *(_OWORD *)&base[5].next_ = 0;
  *(_QWORD *)&base[5].task_result_ = 0;
  next = (int)base[6].next_;
  func = base[6].func_;
  v13 = *(_OWORD *)&base[6].task_result_;
  *(_OWORD *)v14 = *(_OWORD *)&base[7].func_;
  *(_OWORD *)&base[7].func_ = 0;
  ec = *(_OWORD *)&base[1].next_;
  v5.h = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)v6;
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v5);
  if ( owner )
  {
    v16.m_val = ec;
    v16.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::operator()(
      (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)v6,
      v16,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
  }
  v4 = v14[1];
  if ( v14[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(v4);
    std::__shared_weak_count::__release_weak(v4);
    if ( (v9 & 1) == 0 )
      goto LABEL_7;
    goto LABEL_6;
  }
  if ( (v9 & 1) != 0 )
LABEL_6:
    operator delete(ptr);
LABEL_7:
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v5);
}


// Address: 0x26a6280 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_7read_opINS0_17mutable_buffers_1EEENS1_26read_until_delim_string_opINS3_6streamIRSB_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(
        boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::ptr *this)
{
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *p; // rbx
  volatile signed __int64 *v3; // r15
  _BYTE *v; // rdi
  unsigned __int64 v5; // rax
  _QWORD *v6; // rax

  p = this->p;
  if ( p )
  {
    v3 = (volatile signed __int64 *)*((_QWORD *)p + 23);
    if ( v3 && !_InterlockedExchangeAdd64(v3 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v3 + 16))(v3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v3);
      if ( (*((_BYTE *)p + 120) & 1) == 0 )
        goto LABEL_6;
    }
    else if ( (*((_BYTE *)p + 120) & 1) == 0 )
    {
LABEL_6:
      this->p = 0;
      goto LABEL_7;
    }
    operator delete(*((void **)p + 17));
    goto LABEL_6;
  }
LABEL_7:
  v = this->v;
  if ( v )
  {
    v5 = __readfsqword(0xFFFFFFD8);
    if ( v5 && (v6 = *(_QWORD **)(v5 + 8)) != 0 && !*v6 )
    {
      *v = v[192];
      *v6 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26a93c0 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSD_5list2INSD_5valueINSt3__110shared_ptrISL_EEEEPFNS_3argILi1EEEvEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESP_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  __m128i v7; // xmm0
  unsigned __int64 v8; // rax
  boost::asio::detail::operation **v9; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > v11; // [rsp+0h] [rbp-98h] BYREF
  __m128i ec; // [rsp+58h] [rbp-40h]
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v13; // [rsp+70h] [rbp-28h] BYREF
  boost::system::error_code v14; // 0:kr00_16.16

  *(_OWORD *)&v11.next_layer_ = *(_OWORD *)&base[1].task_result_;
  *(_QWORD *)&v11.op_.type_ = base[2].func_;
  v11.want_ = base[2].task_result_;
  *(boost::asio::detail::operation *)&v11.ec_.m_val = base[3];
  v11.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)&base[4].next_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[4].task_result_);
  v11.handler_.l_ = si128;
  *(_OWORD *)&base[4].task_result_ = 0;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 || (v9 = *(boost::asio::detail::operation ***)(v8 + 8)) == 0 || *v9 )
  {
    v13 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v13);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[5].func_;
  LOBYTE(base->next_) = a4;
  *v9 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)ec.m128i_u32[0];
    v14.m_val = ec.m128i_i32[0];
    v14.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
      &v11,
      v14,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v11.handler_.l_.a1_.t_.__cntrl_;
    if ( !v11.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
  if ( !v7.m128i_i64[0] )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, _QWORD, boost::asio::ssl::detail::engine::want, _QWORD, const boost::system::error_category *, size_t, boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)v7.m128i_i64,
      *(double *)&si128.a1_.t_.__ptr_,
      v11.next_layer_,
      v11.core_,
      *(_QWORD *)&v11.op_.type_,
      v11.want_,
      *(_QWORD *)&v11.ec_.m_val,
      v11.ec_.m_cat,
      v11.bytes_transferred_,
      v11.handler_.f_.f_,
      *((_QWORD *)&v11.handler_.f_.f_ + 1),
      v11.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26aac90 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_8write_opINS0_15const_buffers_1EEENS1_8write_opINS3_6streamIRSB_EESD_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSO_5list2INSO_5valueINSL_10shared_ptrISW_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES10_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  __m128i v7; // xmm0
  unsigned __int64 v8; // rax
  boost::asio::detail::operation **v9; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v11; // [rsp+0h] [rbp-C8h] BYREF
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > v12; // [rsp+10h] [rbp-B8h] BYREF
  __m128i ec; // [rsp+A0h] [rbp-28h]
  boost::system::error_code v14; // 0:kr00_16.16

  *(_OWORD *)&v12.next_layer_ = *(_OWORD *)&base[1].task_result_;
  v12.op_ = *(boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *)&base[2].func_;
  *(boost::asio::detail::operation *)&v12.start_ = base[3];
  *(_OWORD *)&v12.bytes_transferred_ = *(_OWORD *)&base[4].next_;
  v12.handler_.buffer_ = *(boost::asio::const_buffer *)&base[4].task_result_;
  v12.handler_.start_ = (int)base[5].func_;
  *(_OWORD *)&v12.handler_.total_transferred_ = *(_OWORD *)&base[5].task_result_;
  v12.handler_.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)&base[6].func_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[7]);
  v12.handler_.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[7].next_ = 0;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 || (v9 = *(boost::asio::detail::operation ***)(v8 + 8)) == 0 || *v9 )
  {
    v11 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v11);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[7].task_result_;
  LOBYTE(base->next_) = a4;
  *v9 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)ec.m128i_u32[0];
    v14.m_val = ec.m128i_i32[0];
    v14.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::operator()(
      &v12,
      v14,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v12.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( !v12.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
  if ( !v7.m128i_i64[0] )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, const void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *, const void *, size_t, int, size_t, boost::asio::basic_streambuf<std::allocator<char> > *, boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)v7.m128i_i64,
      *(double *)&si128.a1_.t_.__ptr_,
      v11.a1_.t_.__ptr_,
      v11.a1_.t_.__cntrl_,
      v12.next_layer_,
      v12.core_,
      v12.op_.buffers_.data_,
      v12.op_.buffers_.size_,
      *(_QWORD *)&v12.start_,
      *(_QWORD *)&v12.ec_.m_val,
      v12.ec_.m_cat,
      v12.bytes_transferred_,
      v12.handler_.stream_,
      v12.handler_.buffer_.data_,
      v12.handler_.buffer_.size_,
      v12.handler_.start_,
      v12.handler_.total_transferred_,
      v12.handler_.handler_.streambuf_,
      v12.handler_.handler_.handler_.f_.f_,
      *((_QWORD *)&v12.handler_.handler_.handler_.f_.f_ + 1),
      v12.handler_.handler_.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26ae520 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_7read_opINS0_17mutable_buffers_1EEENS1_26read_until_delim_string_opINS3_6streamIRSB_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISU_EEEEPFNS_3argILi1EEEvEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESY_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  std::__shared_weak_count *v4; // rbx
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::ptr v5; // [rsp+8h] [rbp-D0h] BYREF
  _OWORD v6[2]; // [rsp+20h] [rbp-B8h] BYREF
  boost::asio::detail::operation v7; // [rsp+40h] [rbp-98h]
  boost::asio::detail::operation v8; // [rsp+58h] [rbp-80h]
  __int128 v9; // [rsp+70h] [rbp-68h]
  void *ptr; // [rsp+80h] [rbp-58h]
  int next; // [rsp+88h] [rbp-50h]
  boost::asio::detail::task_io_service_operation::func_type func; // [rsp+90h] [rbp-48h]
  __int128 v13; // [rsp+98h] [rbp-40h]
  std::__shared_weak_count *v14[2]; // [rsp+A8h] [rbp-30h]
  __int128 ec; // [rsp+B8h] [rbp-20h]
  boost::system::error_code v16; // 0:esi.4,8:rdx.8

  v5.v = base;
  v5.p = (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *)base;
  v6[0] = *(_OWORD *)&base[1].task_result_;
  v6[1] = *(_OWORD *)&base[2].func_;
  v7 = base[3];
  v8 = base[4];
  ptr = *(void **)&base[5].task_result_;
  v9 = *(_OWORD *)&base[5].next_;
  *(_OWORD *)&base[5].next_ = 0;
  *(_QWORD *)&base[5].task_result_ = 0;
  next = (int)base[6].next_;
  func = base[6].func_;
  v13 = *(_OWORD *)&base[6].task_result_;
  *(_OWORD *)v14 = *(_OWORD *)&base[7].func_;
  *(_OWORD *)&base[7].func_ = 0;
  ec = *(_OWORD *)&base[1].next_;
  v5.h = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)v6;
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v5);
  if ( owner )
  {
    v16.m_val = ec;
    v16.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
      (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)v6,
      v16,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
  }
  v4 = v14[1];
  if ( v14[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(v4);
    std::__shared_weak_count::__release_weak(v4);
    if ( (v9 & 1) == 0 )
      goto LABEL_7;
    goto LABEL_6;
  }
  if ( (v9 & 1) != 0 )
LABEL_6:
    operator delete(ptr);
LABEL_7:
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v5);
}


// Address: 0x26ae700 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_7read_opINS0_17mutable_buffers_1EEENS1_26read_until_delim_string_opINS3_6streamIRSB_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISU_EEEEPFNS_3argILi1EEEvEEEEEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(
        boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::ptr *this)
{
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *p; // rbx
  volatile signed __int64 *v3; // r15
  _BYTE *v; // rdi
  unsigned __int64 v5; // rax
  _QWORD *v6; // rax

  p = this->p;
  if ( p )
  {
    v3 = (volatile signed __int64 *)*((_QWORD *)p + 23);
    if ( v3 && !_InterlockedExchangeAdd64(v3 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v3 + 16))(v3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v3);
      if ( (*((_BYTE *)p + 120) & 1) == 0 )
        goto LABEL_6;
    }
    else if ( (*((_BYTE *)p + 120) & 1) == 0 )
    {
LABEL_6:
      this->p = 0;
      goto LABEL_7;
    }
    operator delete(*((void **)p + 17));
    goto LABEL_6;
  }
LABEL_7:
  v = this->v;
  if ( v )
  {
    v5 = __readfsqword(0xFFFFFFD8);
    if ( v5 && (v6 = *(_QWORD **)(v5 + 8)) != 0 && !*v6 )
    {
      *v = v[192];
      *v6 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26b2cf0 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_7read_opINS0_17mutable_buffers_1EEENS1_17read_streambuf_opINS3_6streamIRSB_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSN_5list2INSN_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  __m128i v7; // xmm0
  unsigned __int64 v8; // rax
  boost::asio::detail::operation **v9; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v11; // [rsp+0h] [rbp-B8h] BYREF
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v12; // [rsp+10h] [rbp-A8h] BYREF
  __m128i ec; // [rsp+98h] [rbp-20h]
  boost::system::error_code v14; // 0:kr00_16.16

  *(_OWORD *)&v12.next_layer_ = *(_OWORD *)&base[1].task_result_;
  v12.op_ = *(boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)&base[2].func_;
  *(boost::asio::detail::operation *)&v12.start_ = base[3];
  *(_OWORD *)&v12.bytes_transferred_ = *(_OWORD *)&base[4].next_;
  *(_OWORD *)&v12.handler_.stream_ = *(_OWORD *)&base[4].task_result_;
  v12.handler_.start_ = (int)base[5].func_;
  v12.handler_.total_transferred_ = *(_QWORD *)&base[5].task_result_;
  v12.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)&base[6].next_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[6].task_result_);
  v12.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[6].task_result_ = 0;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 || (v9 = *(boost::asio::detail::operation ***)(v8 + 8)) == 0 || *v9 )
  {
    v11 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v11);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[7].func_;
  LOBYTE(base->next_) = a4;
  *v9 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)ec.m128i_u32[0];
    v14.m_val = ec.m128i_i32[0];
    v14.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
      &v12,
      v14,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v12.handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( !v12.handler_.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
  if ( !v7.m128i_i64[0] )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *, boost::asio::basic_streambuf<std::allocator<char> > *, int, size_t, boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)v7.m128i_i64,
      *(double *)&si128.a1_.t_.__ptr_,
      v11.a1_.t_.__ptr_,
      v11.a1_.t_.__cntrl_,
      v12.next_layer_,
      v12.core_,
      v12.op_.buffers_.data_,
      v12.op_.buffers_.size_,
      *(_QWORD *)&v12.start_,
      *(_QWORD *)&v12.ec_.m_val,
      v12.ec_.m_cat,
      v12.bytes_transferred_,
      v12.handler_.completion_condition_.size_,
      v12.handler_.stream_,
      v12.handler_.streambuf_,
      v12.handler_.start_,
      v12.handler_.total_transferred_,
      v12.handler_.handler_.f_.f_,
      *((_QWORD *)&v12.handler_.handler_.f_.f_ + 1),
      v12.handler_.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26b67a0 | Name: _ZN5boost4asio6detail12wait_handlerINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS4_7read_opINS0_17mutable_buffers_1EEENS1_17read_streambuf_opINS3_6streamIRSB_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSN_5list3INSN_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvENS12_IiEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  __m128i v7; // xmm0
  unsigned __int64 v8; // rax
  boost::asio::detail::operation **v9; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v11; // [rsp+0h] [rbp-C8h] BYREF
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > v12; // [rsp+10h] [rbp-B8h] BYREF
  __m128i ec; // [rsp+A0h] [rbp-28h]
  boost::system::error_code v14; // 0:kr00_16.16

  *(_OWORD *)&v12.next_layer_ = *(_OWORD *)&base[1].task_result_;
  v12.op_ = *(boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)&base[2].func_;
  *(boost::asio::detail::operation *)&v12.start_ = base[3];
  *(_OWORD *)&v12.bytes_transferred_ = *(_OWORD *)&base[4].next_;
  *(_OWORD *)&v12.handler_.stream_ = *(_OWORD *)&base[4].task_result_;
  v12.handler_.start_ = (int)base[5].func_;
  v12.handler_.total_transferred_ = *(_QWORD *)&base[5].task_result_;
  v12.handler_.handler_.f_ = *(boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int> *)&base[6].next_;
  si128 = (boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[6].task_result_);
  v12.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = si128;
  *(_OWORD *)&base[6].task_result_ = 0;
  v12.handler_.handler_.l_.a3_.t_ = (int)base[7].func_;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 || (v9 = *(boost::asio::detail::operation ***)(v8 + 8)) == 0 || *v9 )
  {
    v11 = si128;
    operator delete(base);
    si128 = (boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v11);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[7].task_result_;
  LOBYTE(base->next_) = a4;
  *v9 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)ec.m128i_u32[0];
    v14.m_val = ec.m128i_i32[0];
    v14.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>::operator()(
      &v12,
      v14,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v12.handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( !v12.handler_.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
  if ( !v7.m128i_i64[0] )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *, boost::asio::basic_streambuf<std::allocator<char> > *, int, size_t, boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)v7.m128i_i64,
      *(double *)&si128.a1_.t_.__ptr_,
      v11.a1_.t_.__ptr_,
      v11.a1_.t_.__cntrl_,
      v12.next_layer_,
      v12.core_,
      v12.op_.buffers_.data_,
      v12.op_.buffers_.size_,
      *(_QWORD *)&v12.start_,
      *(_QWORD *)&v12.ec_.m_val,
      v12.ec_.m_cat,
      v12.bytes_transferred_,
      v12.handler_.completion_condition_.size_,
      v12.handler_.stream_,
      v12.handler_.streambuf_,
      v12.handler_.start_,
      v12.handler_.total_transferred_,
      v12.handler_.handler_.f_.f_,
      *((_QWORD *)&v12.handler_.handler_.f_.f_ + 1),
      v12.handler_.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


