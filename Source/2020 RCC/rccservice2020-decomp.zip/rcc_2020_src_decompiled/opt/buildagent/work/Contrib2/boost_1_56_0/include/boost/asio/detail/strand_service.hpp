// Address: 0x26192e0 | Name: _ZN5boost4asio6detail14strand_serviceD2Ev
void __fastcall boost::asio::detail::strand_service::~strand_service(boost::asio::detail::strand_service *this)
{
  __int64 v1; // rbx
  void *v2; // r15

  this->_vptr$service = (int (**)(void))off_29C38E8;
  v1 = 1544;
  do
  {
    v2 = *(__pthread_internal_list **)((char *)&this->mutex_.mutex_.__data.__list.__next + v1);
    if ( v2 )
    {
      boost::asio::detail::strand_service::strand_impl::~strand_impl(*(boost::asio::detail::strand_service::strand_impl **)((char *)&this->mutex_.mutex_.__data.__list.__next + v1));
      operator delete(v2);
    }
    v1 -= 8;
  }
  while ( v1 );
  pthread_mutex_destroy(&this->mutex_.mutex_);
}


// Address: 0x2619340 | Name: _ZN5boost4asio6detail14strand_serviceD0Ev
void __fastcall boost::asio::detail::strand_service::~strand_service(boost::asio::detail::strand_service *this)
{
  __int64 i; // rbx
  void *v2; // r15

  this->_vptr$service = (int (**)(void))off_29C38E8;
  for ( i = 1624; i != 80; i -= 8 )
  {
    v2 = *(int (***)(void))((char *)&this->_vptr$service + i);
    if ( v2 )
    {
      boost::asio::detail::strand_service::strand_impl::~strand_impl(*(boost::asio::detail::strand_service::strand_impl **)((char *)&this->_vptr$service + i));
      operator delete(v2);
    }
  }
  pthread_mutex_destroy(&this->mutex_.mutex_);
  operator delete(this);
}


// Address: 0x2619490 | Name: _ZN5boost4asio6detail14strand_service11strand_implD2Ev
void __fastcall boost::asio::detail::strand_service::strand_impl::~strand_impl(
        boost::asio::detail::strand_service::strand_impl *this)
{
  boost::asio::detail::task_io_service_operation *i; // rbx
  boost::asio::detail::task_io_service_operation *next; // rax
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  boost::asio::detail::task_io_service_operation *j; // rbx
  boost::asio::detail::task_io_service_operation *v5; // rax
  void (__fastcall *v6)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  int v7; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v8; // [rsp+10h] [rbp-28h]

  for ( i = this->ready_queue_.front_; i; i = this->ready_queue_.front_ )
  {
    next = i->next_;
    this->ready_queue_.front_ = i->next_;
    if ( !next )
      this->ready_queue_.back_ = 0;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v7 = 0;
    v8 = boost::system::system_category();
    func(0, i, &v7, 0);
  }
  for ( j = this->waiting_queue_.front_; j; j = this->waiting_queue_.front_ )
  {
    v5 = j->next_;
    this->waiting_queue_.front_ = j->next_;
    if ( !v5 )
      this->waiting_queue_.back_ = 0;
    j->next_ = 0;
    v6 = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))j->func_;
    v7 = 0;
    v8 = boost::system::system_category();
    v6(0, j, &v7, 0);
  }
  pthread_mutex_destroy(&this->mutex_.mutex_);
}


