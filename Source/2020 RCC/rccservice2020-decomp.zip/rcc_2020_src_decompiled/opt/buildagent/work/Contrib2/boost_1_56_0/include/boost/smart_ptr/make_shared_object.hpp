// Address: 0xd9c7b0 | Name: _ZN5boost11make_sharedINSt3__118basic_stringstreamIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<std::basic_stringstream<char,std::char_traits<char>,std::allocator<char> > >::type __cdecl boost::make_shared<std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>>()
{
  _QWORD *v0; // rdi
  _QWORD *v1; // rbx
  boost::detail::sp_if_not_array<std::basic_stringstream<char,std::char_traits<char>,std::allocator<char> > >::type result; // rax

  v1 = operator new(0x138u);
  v1[1] = 0x100000001LL;
  *v1 = &off_2875878;
  v1[2] = 0;
  *((_BYTE *)v1 + 24) = 0;
  v1[6] = &off_28751D8;
  v1[20] = &off_2875320;
  *((_OWORD *)v1 + 2) = (unsigned __int64)&off_28752F8;
  std::ios_base::init((std::ios_base *)(v1 + 20), v1 + 7);
  v1[37] = 0;
  *((_DWORD *)v1 + 76) = -1;
  v1[4] = &off_28751B0;
  v1[20] = off_2875200;
  v1[6] = &off_28751D8;
  std::streambuf::basic_streambuf(v1 + 7);
  v1[7] = &off_28753A8;
  *(_OWORD *)(v1 + 17) = 0;
  *(_OWORD *)(v1 + 15) = 0;
  *((_DWORD *)v1 + 38) = 24;
  *((_BYTE *)v1 + 24) = 1;
  *v0 = v1 + 4;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(_QWORD *))(*v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(_QWORD *))(*v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0xdb1fd0 | Name: _ZN5boost11make_sharedIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SC_EEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >::type __cdecl boost::make_shared<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>()
{
  boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x50u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2876490;
  *((_QWORD *)v2 + 2) = 0;
  v2[32] = 0;
  *(_OWORD *)(v2 + 40) = 0x10u;
  *((_DWORD *)v2 + 14) = 1065353216;
  *((_OWORD *)v2 + 4) = 0;
  v2[24] = 1;
  *(_QWORD *)&v0->table_.current_ = v2 + 32;
  v0->table_.bucket_count_ = (size_t)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0xdbd4a0 | Name: _ZN5boost11make_sharedINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<std::string >::type __cdecl boost::make_shared<std::string>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<std::string >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2876688;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0xdbd560 | Name: _ZN5boost11make_sharedINS_7promiseINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<boost::promise<std::string > >::type __cdecl boost::make_shared<boost::promise<std::string>>()
{
  boost::shared_ptr<boost::promise<std::string > >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<boost::promise<std::string > >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28766E8;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  v2[48] = 0;
  v2[24] = 1;
  v0->future_.px = (boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *)(v2 + 32);
  v0->future_.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0xdbd7c0 | Name: _ZN5boost11make_sharedIN3RBX18RCCMonitorSettingsEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::RCCMonitorSettings>::type __cdecl boost::make_shared<RBX::RCCMonitorSettings>()
{
  _QWORD *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::RCCMonitorSettings>::type result; // rax

  v1 = (char *)operator new(0xE8u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_2878F28;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  RBX::RCCMonitorSettings::RCCMonitorSettings((RBX::RCCMonitorSettings *)(v1 + 32));
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0xdcf240 | Name: _ZN5boost11make_sharedIN3RBX13RCCMonitoringEJRNS_10shared_ptrINS1_9DataModelEEERKNS3_INS1_18RCCMonitorSettingsEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::RCCMonitoring,boost::shared_ptr<RBX::DataModel> &,boost::shared_ptr<RBX::RCCMonitorSettings> const&>(
        _QWORD *a1,
        boost::shared_ptr<RBX::DataModel> *args,
        const boost::shared_ptr<RBX::RCCMonitorSettings> *a3)
{
  boost::detail::sp_counted_base *v4; // r13
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v6; // rbx
  boost::shared_ptr<RBX::RCCMonitoring> v8; // [rsp+0h] [rbp-38h] BYREF

  v8.px = 0;
  v4 = (boost::detail::sp_counted_base *)operator new(0x280u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2878F88;
  v4[1]._vptr$sp_counted_base = 0;
  LOBYTE(v4[1].use_count_) = 0;
  v8.pn.pi_ = v4;
  RBX::RCCMonitoring::RCCMonitoring((RBX::RCCMonitoring *)&v4[2], args, a3);
  LOBYTE(v4[1].use_count_) = 1;
  boost::enable_shared_from_this<RBX::RCCMonitoring>::_internal_accept_owner<RBX::RCCMonitoring,RBX::RCCMonitoring>(
    (const boost::enable_shared_from_this<RBX::RCCMonitoring> *)&v4[2],
    &v8,
    (RBX::RCCMonitoring *)&v4[2]);
  *a1 = v4 + 2;
  pi = v8.pn.pi_;
  a1[1] = v8.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v6 = v8.pn.pi_;
    if ( v8.pn.pi_ )
    {
      if ( !_InterlockedSub(&v8.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 2))(v6);
        if ( !_InterlockedSub(&v6->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      }
    }
  }
  return a1;
}


// Address: 0xefa270 | Name: _ZN5boost11make_sharedIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SC_EEEEEEJRSL_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const,boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>&>(
        _QWORD *a1,
        boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > *args)
{
  char *v2; // rbx
  __m128i v3; // xmm1
  double v4; // xmm0_8
  unsigned __int64 v5; // rdx
  unsigned __int64 v6; // rax
  __int64 v7; // rax
  unsigned __int64 v8; // rax
  unsigned __int64 v9; // rax
  float mlf; // [rsp+0h] [rbp-24h]

  v2 = (char *)operator new(0x50u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2876490;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v2[32] = 0;
  v3 = (__m128i)_mm_sub_pd(
                  (__m128d)_mm_unpacklo_ps((__m128)args->table_.size_, (__m128)xmmword_3E4930),
                  *(__m128d *)(&errorFunction.functor.data + 8));
  mlf = args->table_.mlf_;
  v4 = floor((*(double *)_mm_shuffle_epi32(v3, 78).m128i_i64 + *(double *)v3.m128i_i64) / mlf) + 1.0;
  v5 = (unsigned int)(int)v4;
  if ( v4 >= 9.223372036854776e18 )
    v5 = (unsigned int)(int)(v4 - 9.223372036854776e18) ^ 0x8000000000000000LL;
  v6 = -1;
  if ( v4 < 1.844674407370955e19 )
    v6 = v5;
  if ( v6 >= 5 )
  {
    v8 = (v6 - 1) | ((v6 - 1) >> 1) | (((v6 - 1) | ((v6 - 1) >> 1)) >> 2);
    v9 = v8 | (v8 >> 4) | ((v8 | (v8 >> 4)) >> 8);
    v7 = (v9 | (v9 >> 16) | ((v9 | (v9 >> 16)) >> 32)) + 1;
  }
  else
  {
    v7 = 4;
  }
  *((_QWORD *)v2 + 5) = v7;
  *((_QWORD *)v2 + 6) = 0;
  *((float *)v2 + 14) = mlf;
  *((_OWORD *)v2 + 4) = 0;
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>>>::init(
    (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > *)(v2 + 32),
    &args->table_);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0xf1cad0 | Name: _ZN5boost11make_sharedIN3RBX7Network15CachedBitstreamEJNS2_27ReplicationDataCreationModeEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Network::CachedBitstream,RBX::Network::ReplicationDataCreationMode>(
        _QWORD *a1,
        RBX::Network::ReplicationDataCreationMode *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0xB0u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2882788;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::Network::CachedBitstream::CachedBitstream((RBX::Network::CachedBitstream *)(v2 + 32), *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0xf43f80 | Name: _ZN5boost11make_sharedIN3RBX7Network13NetworkStreamEJjEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Network::NetworkStream,unsigned int>(_QWORD *a1, unsigned int *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x60u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2884498;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::Network::NetworkStream::NetworkStream((RBX::Network::NetworkStream *)(v2 + 32), *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0xf8f5b0 | Name: _ZN5boost11make_sharedIN3RBX7Network31DeserializedChangeAttributeItemEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Network::DeserializedChangeAttributeItem>::type __cdecl boost::make_shared<RBX::Network::DeserializedChangeAttributeItem>()
{
  _QWORD *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::Network::DeserializedChangeAttributeItem>::type result; // rax

  v1 = (char *)operator new(0xD8u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_2885DB8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  RBX::Network::DeserializedChangeAttributeItem::DeserializedChangeAttributeItem((RBX::Network::DeserializedChangeAttributeItem *)(v1 + 32));
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0xfd25d0 | Name: _ZN5boost11make_sharedIN3RBX7Network16ServerSchemaInfoEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Network::ServerSchemaInfo>::type __cdecl boost::make_shared<RBX::Network::ServerSchemaInfo>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::Network::ServerSchemaInfo>::type result; // rax

  v1 = (char *)operator new(0xD0u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_2889228;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  RBX::Network::NetworkStream::NetworkStream((RBX::Network::NetworkStream *)(v1 + 32));
  RBX::Network::NetworkStream::NetworkStream((RBX::Network::NetworkStream *)(v1 + 96));
  *((_OWORD *)v1 + 11) = 0;
  *((_OWORD *)v1 + 10) = 0;
  *((_QWORD *)v1 + 24) = 0;
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0xfe7990 | Name: _ZN5boost11make_sharedIN3RBX7Network13NetworkStreamEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Network::NetworkStream>::type __cdecl boost::make_shared<RBX::Network::NetworkStream>()
{
  _QWORD *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::Network::NetworkStream>::type result; // rax

  v1 = (char *)operator new(0x60u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_2884498;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  RBX::Network::NetworkStream::NetworkStream((RBX::Network::NetworkStream *)(v1 + 32));
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0xff8bc0 | Name: _ZN5boost11make_sharedIN3RBX7Network17StreamingObserver9ResizeJobEJPS3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Network::StreamingObserver::ResizeJob,RBX::Network::StreamingObserver*>(
        _QWORD *a1,
        RBX::Network::StreamingObserver **args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::Network::StreamingObserver::ResizeJob> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0x1F8u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_288B448;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::Network::StreamingObserver::ResizeJob::ResizeJob((RBX::Network::StreamingObserver::ResizeJob *)(v2 + 32), *args);
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::StreamingObserver::ResizeJob,RBX::Network::StreamingObserver::ResizeJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v2 + 40),
    &v6,
    (RBX::Network::StreamingObserver::ResizeJob *)(v2 + 32));
  *a1 = v2 + 32;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x103d090 | Name: _ZN5boost11make_sharedINSt3__16vectorIN3RBX10Reflection7VariantENS1_9allocatorIS5_EEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<std::vector<RBX::Reflection::Variant> >::type __cdecl boost::make_shared<std::vector<RBX::Reflection::Variant>>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<std::vector<RBX::Reflection::Variant> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_288D878;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x10454d0 | Name: _ZN5boost11make_sharedIN3rbx6signalIFvNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<rbx::signal<void (std::string)> >::type __cdecl boost::make_shared<rbx::signal<void ()(std::string)>>()
{
  boost::shared_ptr<rbx::signal<void (std::string)> >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<rbx::signal<void (std::string)> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x28u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_288E568;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 4) = 0;
  v2[24] = 1;
  v0->head.px = (rbx::signals::slot_base *)(v2 + 32);
  v0[1].head.px = (rbx::signals::slot_base *)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1045580 | Name: _ZN5boost11make_sharedIN3RBX3Lua18EventSignalWrapperIFvNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEEN3rbx6signalISB_EEEEJRNS_10shared_ptrISE_EEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Lua::EventSignalWrapper<void ()(std::string),rbx::signal<void ()(std::string)>>,boost::shared_ptr<rbx::signal<void ()(std::string)>> &>(
        _QWORD *a1,
        boost::shared_ptr<rbx::signal<void (std::string)> > *args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rcx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_288E5C8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  *((_QWORD *)v2 + 4) = off_288E628;
  *((_QWORD *)v2 + 5) = args->px;
  pi = args->pn.pi_;
  *((_QWORD *)v2 + 6) = pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x104d460 | Name: _ZN5boost11make_sharedINSt3__16vectorINS_10shared_ptrIN3RBX8InstanceEEENS1_9allocatorIS6_EEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<std::vector<boost::shared_ptr<RBX::Instance>> >::type __cdecl boost::make_shared<std::vector<boost::shared_ptr<RBX::Instance>>>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<std::vector<boost::shared_ptr<RBX::Instance>> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_288F588;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1060b80 | Name: _ZN5boost11make_sharedINS_9unordered13unordered_mapINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SC_EEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >::type __cdecl boost::make_shared<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>()
{
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x50u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2890748;
  *((_QWORD *)v2 + 2) = 0;
  v2[32] = 0;
  *(_OWORD *)(v2 + 40) = 0x10u;
  *((_DWORD *)v2 + 14) = 1065353216;
  *((_OWORD *)v2 + 4) = 0;
  v2[24] = 1;
  *(_QWORD *)&v0->table_.current_ = v2 + 32;
  v0->table_.bucket_count_ = (size_t)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x10af320 | Name: _ZN5boost11make_sharedINSt3__16vectorINS_10shared_ptrIN3RBX24HumanoidAssetRequirementEEENS1_9allocatorIS6_EEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> >::type __cdecl boost::make_shared<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>>>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2894E88;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x10c9f00 | Name: _ZN5boost11make_sharedIN3RBX10Reflection5TupleEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Reflection::Tuple>::type __cdecl boost::make_shared<RBX::Reflection::Tuple>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<RBX::Reflection::Tuple>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2894E28;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1121f00 | Name: _ZN5boost11make_sharedINSt3__16vectorINS_10shared_ptrIN3RBX8InstanceEEENS1_9allocatorIS6_EEEEJmEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
void ***__fastcall boost::make_shared<std::vector<boost::shared_ptr<RBX::Instance>>,unsigned long>(
        void ***a1,
        unsigned __int64 *args)
{
  char *v2; // r13
  void **v3; // r14
  unsigned __int64 v4; // rbx
  _OWORD *v5; // rcx
  unsigned __int64 v6; // rax
  __int64 v7; // rdx
  _OWORD *v8; // rcx
  _OWORD *v9; // rcx
  __int64 v10; // rax
  struct _Unwind_Exception *v12; // r15
  char *v13; // rbx
  char *v14; // rbp
  volatile signed __int32 *v15; // r12
  void *v16; // rdi

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_288F588;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v3 = (void **)(v2 + 32);
  v4 = *args;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  if ( v4 )
  {
    if ( v4 >> 60 )
    {
      v12 = (struct _Unwind_Exception *)std::__vector_base_common<true>::__throw_length_error(v2 + 32);
      v13 = (char *)*v3;
      if ( *v3 )
      {
        v14 = (char *)*((_QWORD *)v2 + 5);
        if ( v14 == v13 )
        {
          v16 = *v3;
        }
        else
        {
          do
          {
            v15 = (volatile signed __int32 *)*((_QWORD *)v14 - 1);
            if ( v15 )
            {
              if ( !_InterlockedSub(v15 + 2, 1u) )
              {
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
                if ( !_InterlockedSub(v15 + 3, 1u) )
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
              }
            }
            v14 -= 16;
          }
          while ( v13 != v14 );
          v16 = *v3;
        }
        *((_QWORD *)v2 + 5) = v13;
        operator delete(v16);
      }
      if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
      {
        (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
        if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
          (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
      }
      _Unwind_Resume(v12);
    }
    v5 = operator new(16 * v4);
    *((_QWORD *)v2 + 5) = v5;
    *((_QWORD *)v2 + 4) = v5;
    *((_QWORD *)v2 + 6) = &v5[v4];
    v6 = v4 - 1;
    if ( (v4 & 3) != 0 )
    {
      v7 = 0;
      do
      {
        *v5 = 0;
        v5 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v5;
        ++v7;
      }
      while ( (v4 & 3) != v7 );
      v4 -= v7;
    }
    if ( v6 >= 3 )
    {
      do
      {
        *v5 = 0;
        v8 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v8;
        *v8 = 0;
        v9 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v9;
        *v9 = 0;
        v10 = *((_QWORD *)v2 + 5);
        *((_QWORD *)v2 + 5) = v10 + 16;
        *(_OWORD *)(v10 + 16) = 0;
        v5 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v5;
        v4 -= 4LL;
      }
      while ( v4 );
    }
  }
  v2[24] = 1;
  *a1 = v3;
  a1[1] = (void **)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1122c90 | Name: _ZN5boost11make_sharedINSt3__13mapINS1_12basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEN3RBX10Reflection7VariantENS1_4lessIS8_EENS6_INS1_4pairIKS8_SB_EEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<std::map<std::string,RBX::Reflection::Variant> >::type __cdecl boost::make_shared<std::map<std::string,RBX::Reflection::Variant>>()
{
  boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<std::map<std::string,RBX::Reflection::Variant> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_289A8E8;
  *((_QWORD *)v2 + 2) = 0;
  *(_OWORD *)(v2 + 40) = 0;
  *((_QWORD *)v2 + 4) = v2 + 40;
  v2[24] = 1;
  v0->__tree_.__begin_node_ = (std::__tree<std::__value_type<std::string,RBX::Reflection::Variant>,std::__map_value_compare<std::string,std::__value_type<std::string,RBX::Reflection::Variant>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,RBX::Reflection::Variant> > >::__iter_pointer)(v2 + 32);
  v0->__tree_.__pair1_.__value_.__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1128d70 | Name: _ZN5boost11make_sharedINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJPKcEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::string,char const*>(_QWORD *a1, const char **args)
{
  char *v2; // rbx
  char *v3; // r15
  const char *v4; // r12
  size_t v5; // rax
  size_t v6; // r13
  void *v7; // rbp
  size_t v8; // r15
  struct _Unwind_Exception *v10; // r14

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2876688;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v3 = v2 + 32;
  v4 = *args;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v5 = strlen(v4);
  if ( v5 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    v10 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(v2 + 32);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
    {
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
      if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
        (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
    }
    _Unwind_Resume(v10);
  }
  v6 = v5;
  if ( v5 >= 0x17 )
  {
    v8 = (v5 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v7 = operator new(v8);
    *((_QWORD *)v2 + 6) = v7;
    *((_QWORD *)v2 + 4) = v8 | 1;
    *((_QWORD *)v2 + 5) = v6;
    v3 = v2 + 32;
  }
  else
  {
    v2[32] = 2 * v5;
    v7 = v2 + 33;
    if ( !v5 )
      goto LABEL_7;
  }
  memcpy(v7, v4, v6);
LABEL_7:
  *((_BYTE *)v7 + v6) = 0;
  v2[24] = 1;
  *a1 = v3;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1171950 | Name: _ZN5boost11make_sharedIN3RBX10Reflection5TupleEJRiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Reflection::Tuple,int &>(_QWORD *a1, int *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2894E28;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)(v2 + 32), *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1171a50 | Name: _ZN5boost11make_sharedINSt3__16vectorIN3RBX10Reflection7VariantENS1_9allocatorIS5_EEEEJRKiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::vector<RBX::Reflection::Variant>,int const&>(_QWORD *a1, const int *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_288D878;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)(v2 + 32), *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1171b50 | Name: _ZN5boost11make_sharedIKNSt3__16vectorIN3RBX10Reflection7VariantENS1_9allocatorIS5_EEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<const std::vector<RBX::Reflection::Variant> >::type __cdecl boost::make_shared<std::vector<RBX::Reflection::Variant> const>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<const std::vector<RBX::Reflection::Variant> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_289CC38;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x11738a0 | Name: _ZN5boost11make_sharedINSt3__16vectorINS_10shared_ptrIN3RBX8InstanceEEENS1_9allocatorIS6_EEEEJRiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
void ***__fastcall boost::make_shared<std::vector<boost::shared_ptr<RBX::Instance>>,int &>(void ***a1, int *args)
{
  char *v2; // r13
  void **v3; // r14
  __int64 v4; // rbx
  _OWORD *v5; // rcx
  unsigned __int64 v6; // rax
  __int64 v7; // rdx
  _OWORD *v8; // rcx
  _OWORD *v9; // rcx
  __int64 v10; // rax
  struct _Unwind_Exception *v12; // r15
  char *v13; // rbx
  char *v14; // rbp
  volatile signed __int32 *v15; // r12
  void *v16; // rdi

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_288F588;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v3 = (void **)(v2 + 32);
  v4 = *args;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  if ( v4 )
  {
    if ( (int)v4 < 0 )
    {
      v12 = (struct _Unwind_Exception *)std::__vector_base_common<true>::__throw_length_error(v2 + 32);
      v13 = (char *)*v3;
      if ( *v3 )
      {
        v14 = (char *)*((_QWORD *)v2 + 5);
        if ( v14 == v13 )
        {
          v16 = *v3;
        }
        else
        {
          do
          {
            v15 = (volatile signed __int32 *)*((_QWORD *)v14 - 1);
            if ( v15 )
            {
              if ( !_InterlockedSub(v15 + 2, 1u) )
              {
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
                if ( !_InterlockedSub(v15 + 3, 1u) )
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
              }
            }
            v14 -= 16;
          }
          while ( v13 != v14 );
          v16 = *v3;
        }
        *((_QWORD *)v2 + 5) = v13;
        operator delete(v16);
      }
      if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
      {
        (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
        if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
          (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
      }
      _Unwind_Resume(v12);
    }
    v5 = operator new(16 * v4);
    *((_QWORD *)v2 + 5) = v5;
    *((_QWORD *)v2 + 4) = v5;
    *((_QWORD *)v2 + 6) = &v5[v4];
    v6 = v4 - 1;
    if ( (v4 & 3) != 0 )
    {
      v7 = 0;
      do
      {
        *v5 = 0;
        v5 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v5;
        ++v7;
      }
      while ( (v4 & 3) != v7 );
      v4 -= v7;
    }
    if ( v6 >= 3 )
    {
      do
      {
        *v5 = 0;
        v8 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v8;
        *v8 = 0;
        v9 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v9;
        *v9 = 0;
        v10 = *((_QWORD *)v2 + 5);
        *((_QWORD *)v2 + 5) = v10 + 16;
        *(_OWORD *)(v10 + 16) = 0;
        v5 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v5;
        v4 -= 4;
      }
      while ( v4 );
    }
  }
  v2[24] = 1;
  *a1 = v3;
  a1[1] = (void **)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1174060 | Name: _ZN5boost11make_sharedIN3RBX10Reflection5TupleEJiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Reflection::Tuple,int>(_QWORD *a1, int *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2894E28;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)(v2 + 32), *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1198470 | Name: _ZN5boost11make_sharedI24YieldFunctionStateObjectJRPKN3RBX10Reflection23YieldFunctionDescriptorERNS_10shared_ptrINS2_8InstanceEEERP9lua_StateEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
YieldFunctionStateObject **__fastcall boost::make_shared<YieldFunctionStateObject,RBX::Reflection::YieldFunctionDescriptor const*&,boost::shared_ptr<RBX::Instance> &,lua_State *&>(
        YieldFunctionStateObject **a1,
        const RBX::Reflection::YieldFunctionDescriptor **args,
        boost::shared_ptr<RBX::Instance> *a3,
        boost::detail::sp_counted_base **a4)
{
  char *v6; // rbx
  lua_State *v7; // r8
  YieldFunctionStateObject *v8; // r15
  const RBX::Reflection::YieldFunctionDescriptor *v9; // rsi
  boost::detail::sp_counted_base *pi; // rax
  boost::shared_ptr<RBX::Instance> v11; // rdx
  boost::detail::sp_counted_base *v12; // r12
  boost::detail::sp_counted_base *v13; // rax
  boost::detail::sp_counted_base *v14; // rbx
  boost::shared_ptr<YieldFunctionStateObject> v16; // [rsp+0h] [rbp-58h] BYREF
  boost::shared_ptr<RBX::Instance> instance; // [rsp+18h] [rbp-40h] BYREF

  v16.px = 0;
  v6 = (char *)operator new(0x80u);
  *((_QWORD *)v6 + 1) = 0x100000001LL;
  *(_QWORD *)v6 = &off_289D980;
  *((_QWORD *)v6 + 2) = 0;
  v6[24] = 0;
  v16.pn.pi_ = (boost::detail::sp_counted_base *)v6;
  v8 = (YieldFunctionStateObject *)(v6 + 32);
  v9 = *args;
  instance.px = a3->px;
  pi = a3->pn.pi_;
  instance.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v11.pn.pi_ = *a4;
  v11.px = (boost::shared_ptr<RBX::Instance>::element_type *)&instance;
  YieldFunctionStateObject::YieldFunctionStateObject(v8, v9, v11, v7);
  v12 = instance.pn.pi_;
  if ( instance.pn.pi_ )
  {
    if ( !_InterlockedSub(&instance.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
      if ( !_InterlockedSub(&v12->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
    }
  }
  v6[24] = 1;
  boost::enable_shared_from_this<YieldFunctionStateObject>::_internal_accept_owner<YieldFunctionStateObject,YieldFunctionStateObject>(
    v8,
    &v16,
    v8);
  *a1 = v8;
  v13 = v16.pn.pi_;
  a1[1] = (YieldFunctionStateObject *)v16.pn.pi_;
  if ( v13 )
  {
    _InterlockedAdd(&v13->use_count_, 1u);
    v14 = v16.pn.pi_;
    if ( v16.pn.pi_ )
    {
      if ( !_InterlockedSub(&v16.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
        if ( !_InterlockedSub(&v14->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
      }
    }
  }
  return a1;
}


// Address: 0x119a920 | Name: _ZN5boost11make_sharedI24YieldFunctionStateObjectJRPN3RBX10Reflection23YieldFunctionDescriptorERKNS_10shared_ptrINS2_8InstanceEEERP9lua_StateEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
YieldFunctionStateObject **__fastcall boost::make_shared<YieldFunctionStateObject,RBX::Reflection::YieldFunctionDescriptor *&,boost::shared_ptr<RBX::Instance> const&,lua_State *&>(
        YieldFunctionStateObject **a1,
        RBX::Reflection::YieldFunctionDescriptor **args,
        const boost::shared_ptr<RBX::Instance> *a3,
        boost::detail::sp_counted_base **a4)
{
  char *v6; // rbx
  lua_State *v7; // r8
  YieldFunctionStateObject *v8; // r15
  const RBX::Reflection::YieldFunctionDescriptor *v9; // rsi
  boost::detail::sp_counted_base *pi; // rax
  boost::shared_ptr<RBX::Instance> v11; // rdx
  boost::detail::sp_counted_base *v12; // r12
  boost::detail::sp_counted_base *v13; // rax
  boost::detail::sp_counted_base *v14; // rbx
  boost::shared_ptr<YieldFunctionStateObject> v16; // [rsp+0h] [rbp-58h] BYREF
  boost::shared_ptr<RBX::Instance> instance; // [rsp+18h] [rbp-40h] BYREF

  v16.px = 0;
  v6 = (char *)operator new(0x80u);
  *((_QWORD *)v6 + 1) = 0x100000001LL;
  *(_QWORD *)v6 = &off_289D980;
  *((_QWORD *)v6 + 2) = 0;
  v6[24] = 0;
  v16.pn.pi_ = (boost::detail::sp_counted_base *)v6;
  v8 = (YieldFunctionStateObject *)(v6 + 32);
  v9 = *args;
  instance.px = a3->px;
  pi = a3->pn.pi_;
  instance.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v11.pn.pi_ = *a4;
  v11.px = (boost::shared_ptr<RBX::Instance>::element_type *)&instance;
  YieldFunctionStateObject::YieldFunctionStateObject(v8, v9, v11, v7);
  v12 = instance.pn.pi_;
  if ( instance.pn.pi_ )
  {
    if ( !_InterlockedSub(&instance.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
      if ( !_InterlockedSub(&v12->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
    }
  }
  v6[24] = 1;
  boost::enable_shared_from_this<YieldFunctionStateObject>::_internal_accept_owner<YieldFunctionStateObject,YieldFunctionStateObject>(
    v8,
    &v16,
    v8);
  *a1 = v8;
  v13 = v16.pn.pi_;
  a1[1] = (YieldFunctionStateObject *)v16.pn.pi_;
  if ( v13 )
  {
    _InterlockedAdd(&v13->use_count_, 1u);
    v14 = v16.pn.pi_;
    if ( v16.pn.pi_ )
    {
      if ( !_InterlockedSub(&v16.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
        if ( !_InterlockedSub(&v14->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
      }
    }
  }
  return a1;
}


// Address: 0x119cb40 | Name: _ZN5boost11make_sharedINS_8functionIFNS_10shared_ptrIN3RBX10Reflection5TupleEEENS2_IKS5_EEEEEJRKSA_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<boost::function<boost::shared_ptr<RBX::Reflection::Tuple> ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<boost::shared_ptr<RBX::Reflection::Tuple> ()(boost::shared_ptr<RBX::Reflection::Tuple const>)> const&>(
        _QWORD *a1,
        const boost::function<boost::shared_ptr<RBX::Reflection::Tuple> (boost::shared_ptr<const RBX::Reflection::Tuple>)> *args)
{
  char *v2; // rbx
  _QWORD *v3; // r12
  boost::detail::function::vtable_base *vtable; // rax

  v2 = (char *)operator new(0x40u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_289DAF8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v3 = v2 + 32;
  *((_QWORD *)v2 + 4) = 0;
  vtable = args->vtable;
  if ( args->vtable )
  {
    *v3 = vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      *(boost::detail::function::function_buffer *)(v2 + 40) = args->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, char *, _QWORD))((unsigned __int64)vtable
                                                                                         & 0xFFFFFFFFFFFFFFFELL))(
        &args->functor,
        v2 + 40,
        0);
  }
  v2[24] = 1;
  *a1 = v3;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x119cc60 | Name: _ZN5boost11make_sharedINS_8functionIFvNS_10shared_ptrIKN3RBX10Reflection5TupleEEENS1_IFvS7_EEENS1_IFvNSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEEEEEEEEJRKSK_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)> const&>(
        _QWORD *a1,
        const boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)>_0 *args)
{
  char *v2; // rbx
  _QWORD *v3; // r12
  boost::detail::function::vtable_base *vtable; // rax

  v2 = (char *)operator new(0x40u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_289DB58;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v3 = v2 + 32;
  *((_QWORD *)v2 + 4) = 0;
  vtable = args->vtable;
  if ( args->vtable )
  {
    *v3 = vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      *(boost::detail::function::function_buffer *)(v2 + 40) = args->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, char *, _QWORD))((unsigned __int64)vtable
                                                                                         & 0xFFFFFFFFFFFFFFFELL))(
        &args->functor,
        v2 + 40,
        0);
  }
  v2[24] = 1;
  *a1 = v3;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x119fb20 | Name: _ZN5boost11make_sharedIN3RBX10Reflection19TGenericSlotWrapperINS1_3Lua18FunctionScriptSlotEEEJS5_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Reflection::TGenericSlotWrapper<RBX::Lua::FunctionScriptSlot>,RBX::Lua::FunctionScriptSlot>(
        _QWORD *a1,
        RBX::Lua::FunctionScriptSlot *args)
{
  char *v2; // r15
  char *v3; // rbx
  rbx::signals::slot_base *p; // rax
  __int128 v5; // xmm0
  boost::detail::sp_counted_base *pi; // rax
  char *v7; // r15
  boost::detail::sp_counted_base *v8; // rax

  v2 = (char *)operator new(0xE0u);
  v3 = v2;
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_289DBB8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  _InterlockedAdd(&dword_29D54D4, 1u);
  *((_QWORD *)v2 + 4) = &off_289DCD8;
  _InterlockedAdd(&dword_2A0E0E4, 1u);
  *((_QWORD *)v2 + 4) = &off_289DC18;
  *((_QWORD *)v2 + 5) = 0;
  p = args->connection.weak_slot.p_;
  if ( args->connection.weak_slot.p_ && p->strong.v )
  {
    *((_QWORD *)v2 + 5) = p;
    _InterlockedAdd(&p->weak.v, 1u);
  }
  v5 = *(_OWORD *)&args->eventInfo.eventName;
  *((_OWORD *)v2 + 4) = *(_OWORD *)&args->eventInfo.isScriptable;
  *((_OWORD *)v2 + 3) = v5;
  RBX::Lua::WeakFunctionRef::WeakFunctionRef((RBX::Lua::WeakFunctionRef *)(v2 + 80), &args->function);
  RBX::Lua::WeakThreadRef::WeakThreadRef((RBX::Lua::WeakThreadRef *)(v2 + 136), &args->cachedSlotThread);
  v2[188] = args->useSubmitTask;
  *((_DWORD *)v2 + 46) = args->executionDepth;
  *((_QWORD *)v2 + 24) = args->weakSelf.px;
  pi = args->weakSelf.pn.pi_;
  *((_QWORD *)v2 + 25) = pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  v7 = v2 + 32;
  *((_QWORD *)v3 + 26) = args->weakDm.px;
  v8 = args->weakDm.pn.pi_;
  *((_QWORD *)v3 + 27) = v8;
  if ( v8 )
    _InterlockedAdd(&v8->weak_count_, 1u);
  v3[24] = 1;
  *a1 = v7;
  a1[1] = v3;
  _InterlockedAdd((volatile signed __int32 *)v3 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v3 + 16LL))(v3);
    if ( !_InterlockedSub((volatile signed __int32 *)v3 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v3 + 24LL))(v3);
  }
  return a1;
}


// Address: 0x11a0070 | Name: _ZN5boost11make_sharedIN3RBX10Reflection19TGenericSlotWrapperINS1_3Lua14WaitScriptSlotEEEJS5_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::intrusive_ptr<RBX::Lua::detail::LiveThreadRef> **__fastcall boost::make_shared<RBX::Reflection::TGenericSlotWrapper<RBX::Lua::WaitScriptSlot>,RBX::Lua::WaitScriptSlot>(
        boost::intrusive_ptr<RBX::Lua::detail::LiveThreadRef> **a1,
        RBX::Lua::WaitScriptSlot *args)
{
  RBX::Lua::WeakThreadRef *v2; // r15
  RBX::Lua::WeakThreadRef *v3; // rbx
  rbx::signals::slot_base *p; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::intrusive_ptr<RBX::Lua::detail::LiveThreadRef> *p_liveThreadRef; // r15
  boost::detail::sp_counted_base *v7; // rax

  v2 = (RBX::Lua::WeakThreadRef *)operator new(0x88u);
  v3 = v2;
  *(_QWORD *)&v2->refs.v = 0x100000001LL;
  v2->_vptr$WeakThreadRef = (int (**)(void))&off_289DD20;
  v2->previous = 0;
  LOBYTE(v2->next) = 0;
  _InterlockedAdd(&dword_29D54D4, 1u);
  v2->liveThreadRef.px = (RBX::Lua::detail::LiveThreadRef *)&off_289DCD8;
  _InterlockedAdd(&dword_2A0E0F0, 1u);
  v2->liveThreadRef.px = (RBX::Lua::detail::LiveThreadRef *)&off_289DD78;
  v2->node = 0;
  p = args->connection.weak_slot.p_;
  if ( args->connection.weak_slot.p_ && p->strong.v )
  {
    v2->node = (RBX::Lua::WeakThreadRef::Node *)p;
    _InterlockedAdd(&p->weak.v, 1u);
  }
  RBX::Lua::WeakThreadRef::WeakThreadRef(v2 + 1, &args->waitThread);
  LOBYTE(v2[2]._vptr$WeakThreadRef) = args->useSubmitTask;
  *(_QWORD *)&v2[2].refs.v = args->weakDm.px;
  pi = args->weakDm.pn.pi_;
  v2[2].previous = (RBX::Lua::WeakThreadRef *)pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  p_liveThreadRef = &v2->liveThreadRef;
  v3[2].next = (RBX::Lua::WeakThreadRef *)args->weakSelf.px;
  v7 = args->weakSelf.pn.pi_;
  v3[2].liveThreadRef.px = (RBX::Lua::detail::LiveThreadRef *)v7;
  if ( v7 )
    _InterlockedAdd(&v7->weak_count_, 1u);
  LOBYTE(v3->next) = 1;
  *a1 = p_liveThreadRef;
  a1[1] = (boost::intrusive_ptr<RBX::Lua::detail::LiveThreadRef> *)v3;
  _InterlockedAdd(&v3->refs.v, 1u);
  if ( !_InterlockedSub(&v3->refs.v, 1u) )
  {
    (*((void (__fastcall **)(RBX::Lua::WeakThreadRef *))v3->_vptr$WeakThreadRef + 2))(v3);
    if ( !_InterlockedSub(
            (volatile signed __int32 *)&v3->rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef> + 1,
            1u) )
      (*((void (__fastcall **)(RBX::Lua::WeakThreadRef *))v3->_vptr$WeakThreadRef + 3))(v3);
  }
  return a1;
}


// Address: 0x11a7190 | Name: _ZN5boost11make_sharedIN3RBX18LuaSourceContainer20LinkedScriptLoadDataEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::LuaSourceContainer::LinkedScriptLoadData>::type __cdecl boost::make_shared<RBX::LuaSourceContainer::LinkedScriptLoadData>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::LuaSourceContainer::LinkedScriptLoadData>::type result; // rax

  v1 = (char *)operator new(0xA0u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_289E9A8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  *((_OWORD *)v1 + 9) = 0;
  *((_OWORD *)v1 + 8) = 0;
  *((_OWORD *)v1 + 7) = 0;
  *((_OWORD *)v1 + 6) = 0;
  *((_OWORD *)v1 + 5) = 0;
  *((_OWORD *)v1 + 4) = 0;
  *((_OWORD *)v1 + 3) = 0;
  *((_OWORD *)v1 + 2) = 0;
  boost::mutex::mutex((boost::mutex *)(v1 + 96));
  *(_OWORD *)(v1 + 136) = 0;
  *((_QWORD *)v1 + 19) = 0;
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x11ca050 | Name: _ZN5boost11make_sharedIN3RBX5GcJobEJNS_10shared_ptrINS1_13ScriptContextEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::GcJob **__fastcall boost::make_shared<RBX::GcJob,boost::shared_ptr<RBX::ScriptContext>>(
        RBX::GcJob **a1,
        boost::shared_ptr<RBX::ScriptContext> *args)
{
  char *v2; // rbx
  RBX::GcJob *v3; // r15
  boost::shared_ptr<RBX::ScriptContext> v4; // xmm0
  unsigned __int64 v5; // rdx
  boost::detail::sp_counted_base *pi; // r12
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *v8; // rbx
  boost::shared_ptr<RBX::GcJob> v10; // [rsp+0h] [rbp-48h] BYREF
  boost::shared_ptr<RBX::ScriptContext> scriptContext; // [rsp+10h] [rbp-38h] BYREF

  v10.px = 0;
  v2 = (char *)operator new(0x200u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A0A48;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v10.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  v3 = (RBX::GcJob *)(v2 + 32);
  v4 = *args;
  args->pn.pi_ = 0;
  scriptContext = v4;
  args->px = 0;
  RBX::GcJob::GcJob((RBX::GcJob *)(v2 + 32), (boost::shared_ptr<RBX::ScriptContext>)__PAIR128__(v5, &scriptContext));
  pi = scriptContext.pn.pi_;
  if ( scriptContext.pn.pi_ )
  {
    if ( !_InterlockedSub(&scriptContext.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::GcJob,RBX::GcJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v2 + 40),
    &v10,
    v3);
  *a1 = v3;
  v7 = v10.pn.pi_;
  a1[1] = (RBX::GcJob *)v10.pn.pi_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    v8 = v10.pn.pi_;
    if ( v10.pn.pi_ )
    {
      if ( !_InterlockedSub(&v10.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
        if ( !_InterlockedSub(&v8->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
      }
    }
  }
  return a1;
}


// Address: 0x11ca2a0 | Name: _ZN5boost11make_sharedIN3RBX17WaitingScriptsJobEJNS_10shared_ptrINS1_13ScriptContextEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::WaitingScriptsJob **__fastcall boost::make_shared<RBX::WaitingScriptsJob,boost::shared_ptr<RBX::ScriptContext>>(
        RBX::WaitingScriptsJob **a1,
        boost::shared_ptr<RBX::ScriptContext> *args)
{
  char *v2; // rbx
  RBX::WaitingScriptsJob *v3; // r15
  boost::shared_ptr<RBX::ScriptContext> v4; // xmm0
  unsigned __int64 v5; // rdx
  boost::detail::sp_counted_base *pi; // r12
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *v8; // rbx
  boost::shared_ptr<RBX::WaitingScriptsJob> v10; // [rsp+0h] [rbp-48h] BYREF
  boost::shared_ptr<RBX::ScriptContext> scriptContext; // [rsp+10h] [rbp-38h] BYREF

  v10.px = 0;
  v2 = (char *)operator new(0x208u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A0B08;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v10.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  v3 = (RBX::WaitingScriptsJob *)(v2 + 32);
  v4 = *args;
  args->pn.pi_ = 0;
  scriptContext = v4;
  args->px = 0;
  RBX::WaitingScriptsJob::WaitingScriptsJob(
    (RBX::WaitingScriptsJob *)(v2 + 32),
    (boost::shared_ptr<RBX::ScriptContext>)__PAIR128__(v5, &scriptContext));
  pi = scriptContext.pn.pi_;
  if ( scriptContext.pn.pi_ )
  {
    if ( !_InterlockedSub(&scriptContext.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::WaitingScriptsJob,RBX::WaitingScriptsJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v2 + 40),
    &v10,
    v3);
  *a1 = v3;
  v7 = v10.pn.pi_;
  a1[1] = (RBX::WaitingScriptsJob *)v10.pn.pi_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    v8 = v10.pn.pi_;
    if ( v10.pn.pi_ )
    {
      if ( !_InterlockedSub(&v10.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
        if ( !_InterlockedSub(&v8->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
      }
    }
  }
  return a1;
}


// Address: 0x11ca450 | Name: _ZN5boost11make_sharedIN3RBX21ClearUnusedLuaRefsJobEJNS_10shared_ptrINS1_13ScriptContextEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::ClearUnusedLuaRefsJob **__fastcall boost::make_shared<RBX::ClearUnusedLuaRefsJob,boost::shared_ptr<RBX::ScriptContext>>(
        RBX::ClearUnusedLuaRefsJob **a1,
        boost::shared_ptr<RBX::ScriptContext> *args)
{
  char *v2; // rbx
  RBX::ClearUnusedLuaRefsJob *v3; // r15
  boost::shared_ptr<RBX::ScriptContext> v4; // xmm0
  unsigned __int64 v5; // rdx
  boost::detail::sp_counted_base *pi; // r12
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *v8; // rbx
  boost::shared_ptr<RBX::ClearUnusedLuaRefsJob> v10; // [rsp+0h] [rbp-48h] BYREF
  boost::shared_ptr<RBX::ScriptContext> scriptContext; // [rsp+10h] [rbp-38h] BYREF

  v10.px = 0;
  v2 = (char *)operator new(0x200u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A0BC8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v10.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  v3 = (RBX::ClearUnusedLuaRefsJob *)(v2 + 32);
  v4 = *args;
  args->pn.pi_ = 0;
  scriptContext = v4;
  args->px = 0;
  RBX::ClearUnusedLuaRefsJob::ClearUnusedLuaRefsJob(
    (RBX::ClearUnusedLuaRefsJob *)(v2 + 32),
    (boost::shared_ptr<RBX::ScriptContext>)__PAIR128__(v5, &scriptContext));
  pi = scriptContext.pn.pi_;
  if ( scriptContext.pn.pi_ )
  {
    if ( !_InterlockedSub(&scriptContext.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::ClearUnusedLuaRefsJob,RBX::ClearUnusedLuaRefsJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v2 + 40),
    &v10,
    v3);
  *a1 = v3;
  v7 = v10.pn.pi_;
  a1[1] = (RBX::ClearUnusedLuaRefsJob *)v10.pn.pi_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    v8 = v10.pn.pi_;
    if ( v10.pn.pi_ )
    {
      if ( !_InterlockedSub(&v10.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
        if ( !_InterlockedSub(&v8->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
      }
    }
  }
  return a1;
}


// Address: 0x11ca600 | Name: _ZN5boost11make_sharedIN3RBX10Reflection5TupleEJRmEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Reflection::Tuple,unsigned long &>(_QWORD *a1, unsigned __int64 *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2894E28;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)(v2 + 32), *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x11cbe60 | Name: _ZN5boost11make_sharedIN3RBX11ScriptStatsEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::ScriptStats>::type __cdecl boost::make_shared<RBX::ScriptStats>()
{
  boost::shared_ptr<RBX::ScriptStats>::element_type *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::ScriptStats>::type result; // rax

  v1 = (char *)operator new(0x68u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28A0FA8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  RBX::ScriptStats::ScriptStats((RBX::ScriptStats *)(v1 + 32));
  v1[24] = 1;
  v0->scriptActivityMap.__tree_.__begin_node_ = (std::__tree<std::__value_type<std::string,RBX::ScriptStats::StatCollection>,std::__map_value_compare<std::string,std::__value_type<std::string,RBX::ScriptStats::StatCollection>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,RBX::ScriptStats::StatCollection> > >::__iter_pointer)(v1 + 32);
  v0->scriptActivityMap.__tree_.__pair1_.__value_.__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x11d8980 | Name: _ZN5boost6detail13sp_ms_deleterIN3RBX11ScriptStatsEE7destroyEv
void __fastcall boost::detail::sp_ms_deleter<RBX::ScriptStats>::destroy(
        boost::detail::sp_ms_deleter<RBX::ScriptStats> *this)
{
  boost::type_with_alignment<8>::type *v1; // r14
  void **v2; // rbx
  void **v3; // r15
  __int64 v4; // rcx
  __int64 v5; // rax

  if ( this->initialized_ )
  {
    v1 = &this->storage_.align_ + 3;
    std::__deque_base<std::string>::clear((std::__deque_base<std::string> *)(&this->storage_.align_ + 3));
    v2 = (void **)*((_QWORD *)&this->storage_.align_ + 4);
    v3 = (void **)*((_QWORD *)&this->storage_.align_ + 5);
    if ( v2 != v3 )
    {
      do
        operator delete(*v2++);
      while ( v3 != v2 );
      v4 = *((_QWORD *)&this->storage_.align_ + 4);
      v5 = *((_QWORD *)&this->storage_.align_ + 5);
      if ( v5 != v4 )
        *((_QWORD *)&this->storage_.align_ + 5) = v5 + (~(v5 - 8 - v4) & 0xFFFFFFFFFFFFFFF8LL);
    }
    if ( *v1 )
      operator delete(*(void **)v1);
    std::__tree<std::__value_type<std::string,RBX::ScriptStats::StatCollection>,std::__map_value_compare<std::string,std::__value_type<std::string,RBX::ScriptStats::StatCollection>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,RBX::ScriptStats::StatCollection>>>::destroy(
      (std::__tree<std::__value_type<std::string,RBX::ScriptStats::StatCollection>,std::__map_value_compare<std::string,std::__value_type<std::string,RBX::ScriptStats::StatCollection>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,RBX::ScriptStats::StatCollection> > > *)&this->storage_,
      *((std::__tree<std::__value_type<std::string,RBX::ScriptStats::StatCollection>,std::__map_value_compare<std::string,std::__value_type<std::string,RBX::ScriptStats::StatCollection>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,RBX::ScriptStats::StatCollection> > >::__node_pointer *)&this->storage_.align_
      + 1));
    this->initialized_ = 0;
  }
}


// Address: 0x11e1b50 | Name: _ZN5boost11make_sharedIN3RBX13ActivityMeterILi2EEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::ActivityMeter<2> >::type __cdecl boost::make_shared<RBX::ActivityMeter<2>>()
{
  __int64 v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::ActivityMeter<2> >::type result; // rax

  v1 = (char *)operator new(0x840u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = off_28A19C8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  *((_QWORD *)v1 + 260) = 0xFFFFFFFFLL;
  *((_DWORD *)v1 + 522) = 0;
  *((RBX::Time *)v1 + 262) = RBX::Time::now<(RBX::Time::SampleMethod)2>();
  *((_QWORD *)v1 + 263) = 0;
  memset(v1 + 32, 0, 0x800u);
  v1[24] = 1;
  *(_QWORD *)v0 = v1 + 32;
  *(_QWORD *)(v0 + 8) = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = (boost::shared_ptr<RBX::ActivityMeter<2> >::element_type *)v0;
  return result;
}


// Address: 0x11e1c60 | Name: _ZN5boost11make_sharedIN3RBX15InvocationMeterILi2EEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::InvocationMeter<2> >::type __cdecl boost::make_shared<RBX::InvocationMeter<2>>()
{
  __int64 v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::InvocationMeter<2> >::type result; // rax

  v1 = (char *)operator new(0x838u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = off_28A1A28;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  *((_QWORD *)v1 + 260) = 0xFFFFFFFFLL;
  *((RBX::Time *)v1 + 261) = RBX::Time::now<(RBX::Time::SampleMethod)2>();
  *((_QWORD *)v1 + 262) = 0;
  memset(v1 + 32, 0, 0x800u);
  v1[24] = 1;
  *(_QWORD *)v0 = v1 + 32;
  *(_QWORD *)(v0 + 8) = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = (boost::shared_ptr<RBX::InvocationMeter<2> >::element_type *)v0;
  return result;
}


// Address: 0x11e2230 | Name: _ZN5boost6detail18sp_counted_impl_pdIPN3RBX13ActivityMeterILi2EEENS0_13sp_ms_deleterIS4_EEE7disposeEv
void __fastcall boost::detail::sp_counted_impl_pd<RBX::ActivityMeter<2> *,boost::detail::sp_ms_deleter<RBX::ActivityMeter<2>>>::dispose(
        boost::detail::sp_counted_impl_pd<RBX::ActivityMeter<2> *,boost::detail::sp_ms_deleter<RBX::ActivityMeter<2> > > *this)
{
  if ( this->del.initialized_ )
    this->del.initialized_ = 0;
}


// Address: 0x11e22a0 | Name: _ZN5boost6detail18sp_counted_impl_pdIPN3RBX15InvocationMeterILi2EEENS0_13sp_ms_deleterIS4_EEE7disposeEv
void __fastcall boost::detail::sp_counted_impl_pd<RBX::InvocationMeter<2> *,boost::detail::sp_ms_deleter<RBX::InvocationMeter<2>>>::dispose(
        boost::detail::sp_counted_impl_pd<RBX::InvocationMeter<2> *,boost::detail::sp_ms_deleter<RBX::InvocationMeter<2> > > *this)
{
  if ( this->del.initialized_ )
    this->del.initialized_ = 0;
}


// Address: 0x11ebe90 | Name: _ZN5boost11make_sharedIN3rbx7signals17scoped_connectionEJNS2_10connectionEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
rbx::signals::slot_base ***__fastcall boost::make_shared<rbx::signals::scoped_connection,rbx::signals::connection>(
        rbx::signals::slot_base ***a1,
        rbx::signals::connection *args)
{
  char *v2; // rbx
  rbx::signals::slot_base **v3; // rax
  rbx::signals::slot_base *p; // rcx

  v2 = (char *)operator new(0x28u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A1F18;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v3 = (rbx::signals::slot_base **)(v2 + 32);
  *((_QWORD *)v2 + 4) = 0;
  p = args->weak_slot.p_;
  if ( args->weak_slot.p_ && p->strong.v )
  {
    *v3 = p;
    _InterlockedAdd(&p->weak.v, 1u);
  }
  v2[24] = 1;
  *a1 = v3;
  a1[1] = (rbx::signals::slot_base **)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x11f8120 | Name: _ZN5boost11make_sharedIN12_GLOBAL__N_111SharedStateEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<(anonymous namespace)::SharedState>::type __cdecl boost::make_shared<`anonymous namespace'::SharedState>()
{
  __int64 v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<(anonymous namespace)::SharedState>::type result; // rax

  v1 = (char *)operator new(0x50u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28A2598;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  *((_OWORD *)v1 + 4) = 0;
  *((_OWORD *)v1 + 3) = 0;
  *((_OWORD *)v1 + 2) = 0;
  boost::mutex::mutex((boost::mutex *)(v1 + 32));
  v1[72] = 0;
  v1[24] = 1;
  *(_QWORD *)v0 = v1 + 32;
  *(_QWORD *)(v0 + 8) = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = (boost::shared_ptr<(anonymous namespace)::SharedState>::element_type *)v0;
  return result;
}


// Address: 0x11ff5e0 | Name: _ZN5boost6detail18sp_counted_impl_pdIPN12_GLOBAL__N_111SharedStateENS0_13sp_ms_deleterIS3_EEE7disposeEv
void __fastcall boost::detail::sp_counted_impl_pd<`anonymous namespace'::SharedState *,boost::detail::sp_ms_deleter<`anonymous namespace'::SharedState>>::dispose(
        boost::detail::sp_counted_impl_pd<(anonymous namespace)::SharedState *,boost::detail::sp_ms_deleter<(anonymous namespace)::SharedState> > *this)
{
  if ( this->del.initialized_ )
  {
    while ( pthread_mutex_destroy((pthread_mutex_t *)&this->del.storage_) == 4 )
      ;
    this->del.initialized_ = 0;
  }
}


// Address: 0x11fff10 | Name: _ZN5boost6detail13sp_ms_deleterIN3RBX9Analytics3NS112_GLOBAL__N_110ProbeStateEE7destroyEv
void __fastcall boost::detail::sp_ms_deleter<RBX::Analytics::NS1::`anonymous namespace'::ProbeState>::destroy(
        boost::detail::sp_ms_deleter<RBX::Analytics::NS1::(anonymous namespace)::ProbeState> *this)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  void *v4; // rdi
  __int64 v5; // r12

  if ( this->initialized_ )
  {
    boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::vector<std::pair<int,int>>>>,std::string,std::vector<std::pair<int,int>>,boost::hash<std::string>,std::equal_to<std::string>>>::~table((boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::vector<std::pair<int,int>> > >,std::string,std::vector<std::pair<int,int>>,boost::hash<std::string>,std::equal_to<std::string > > > *)(&this->storage_.align_ + 4));
    v2 = *(_QWORD *)this->storage_.data_;
    if ( v2 )
    {
      v3 = *((_QWORD *)&this->storage_.align_ + 1);
      v4 = *(void **)this->storage_.data_;
      if ( v3 != v2 )
      {
        do
        {
          if ( (*(_BYTE *)(v3 - 24) & 1) != 0 )
            operator delete(*(void **)(v3 - 8));
          v5 = v3 - 56;
          if ( (*(_BYTE *)(v3 - 48) & 1) != 0 )
            operator delete(*(void **)(v3 - 32));
          v3 -= 56;
        }
        while ( v2 != v5 );
        v4 = *(void **)this->storage_.data_;
      }
      *((_QWORD *)&this->storage_.align_ + 1) = v2;
      operator delete(v4);
    }
    this->initialized_ = 0;
  }
}


// Address: 0x12001e0 | Name: _ZN5boost11make_sharedINS_7promiseIvEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<boost::promise<void> >::type __cdecl boost::make_shared<boost::promise<void>>()
{
  boost::shared_ptr<boost::promise<void> >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<boost::promise<void> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A29D8;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  v2[48] = 0;
  v2[24] = 1;
  v0->future_.px = (boost::shared_ptr<boost::detail::shared_state<void> >::element_type *)(v2 + 32);
  v0->future_.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1207720 | Name: _ZN5boost11make_sharedIN3RBX9Analytics16EphemeralCounter21EphemeralCounterStateEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Analytics::EphemeralCounter::EphemeralCounterState>::type __cdecl boost::make_shared<RBX::Analytics::EphemeralCounter::EphemeralCounterState>()
{
  _QWORD *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::Analytics::EphemeralCounter::EphemeralCounterState>::type result; // rax

  v1 = (char *)operator new(0x200u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28A2838;
  *((_QWORD *)v1 + 2) = 0;
  v1[32] = 0;
  RBX::Analytics::EphemeralCounter::EphemeralCounterState::EphemeralCounterState((RBX::Analytics::EphemeralCounter::EphemeralCounterState *)(v1 + 48));
  v1[32] = 1;
  *v0 = v1 + 48;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x1207810 | Name: _ZN5boost11make_sharedIN3RBX9Analytics11EventIngest16EventIngestStateEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Analytics::EventIngest::EventIngestState>::type __cdecl boost::make_shared<RBX::Analytics::EventIngest::EventIngestState>()
{
  _QWORD *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::Analytics::EventIngest::EventIngestState>::type result; // rax

  v1 = (char *)operator new(0x158u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28A2898;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  RBX::Analytics::EventIngest::EventIngestState::EventIngestState((RBX::Analytics::EventIngest::EventIngestState *)(v1 + 32));
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x1207900 | Name: _ZN5boost11make_sharedIN3RBX9Analytics5Event15GAReporterStateEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Analytics::Event::GAReporterState>::type __cdecl boost::make_shared<RBX::Analytics::Event::GAReporterState>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::Analytics::Event::GAReporterState>::type result; // rax

  v1 = (char *)operator new(0x40u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28A28F8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  *((_DWORD *)v1 + 8) = 0;
  *(_OWORD *)(v1 + 40) = 0;
  *((_QWORD *)v1 + 7) = 0;
  result.px = operator new(0x10u);
  *((_QWORD *)v1 + 5) = result.px;
  result.pn.pi_ = (boost::detail::sp_counted_base *)((char *)result.px + 16);
  *((_QWORD *)v1 + 7) = (char *)result.px + 16;
  *(_OWORD *)result.px = 0;
  *((_QWORD *)v1 + 6) = (char *)result.px + 16;
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x1213d70 | Name: _ZN5boost11make_sharedISt13runtime_errorJRA12_KcEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::runtime_error,char const(&)[12]>(_QWORD *a1, const char (*args)[12])
{
  char *v2; // r12

  v2 = (char *)operator new(0x30u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A2C48;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::runtime_error::runtime_error((std::runtime_error *)(v2 + 32), (const char *)args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1213e70 | Name: _ZN5boost11make_sharedIN3RBX14AsyncHttpQueue7RequestEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::AsyncHttpQueue::Request>::type __cdecl boost::make_shared<RBX::AsyncHttpQueue::Request>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<RBX::AsyncHttpQueue::Request>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0xD8u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A2CA8;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 12) = 0;
  *((_OWORD *)v2 + 11) = 0;
  *((_OWORD *)v2 + 10) = 0;
  *((_OWORD *)v2 + 9) = 0;
  *((_OWORD *)v2 + 8) = 0;
  *((_OWORD *)v2 + 7) = 0;
  *((_OWORD *)v2 + 6) = 0;
  *((_OWORD *)v2 + 5) = 0;
  *((_OWORD *)v2 + 4) = 0;
  *((_OWORD *)v2 + 3) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 26) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1214160 | Name: _ZN5boost11make_sharedISt13runtime_errorJPKcEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::runtime_error,char const*>(_QWORD *a1, const char **args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x30u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A2C48;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::runtime_error::runtime_error((std::runtime_error *)(v2 + 32), *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1253fb0 | Name: _ZN5boost11make_sharedIN3RBX13BatchAssetApiEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::BatchAssetApi>::type __cdecl boost::make_shared<RBX::BatchAssetApi>()
{
  boost::shared_ptr<RBX::BatchAssetApi>::element_type *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::BatchAssetApi>::type result; // rax

  v1 = (char *)operator new(0x30u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28A41C8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  RBX::BatchAssetApi::BatchAssetApi((RBX::BatchAssetApi *)v1 + 2);
  v1[24] = 1;
  v0->ba.px = (boost::shared_ptr<RBX::BatchAssetApiState>::element_type *)(v1 + 32);
  v0->ba.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x12540e0 | Name: _ZN5boost11make_sharedIN3RBX21BatchThumbnailFetcherEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::BatchThumbnailFetcher>::type __cdecl boost::make_shared<RBX::BatchThumbnailFetcher>()
{
  boost::shared_ptr<RBX::BatchThumbnailFetcher>::element_type *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::BatchThumbnailFetcher>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::BatchThumbnailFetcher> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0x158u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28A4228;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::BatchThumbnailFetcher::BatchThumbnailFetcher((RBX::BatchThumbnailFetcher *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::BatchThumbnailFetcher>::_internal_accept_owner<RBX::BatchThumbnailFetcher,RBX::BatchThumbnailFetcher>(
    (const boost::enable_shared_from_this<RBX::BatchThumbnailFetcher> *)v1 + 2,
    &v4,
    (RBX::BatchThumbnailFetcher *)(v1 + 32));
  v0->weak_this_.px = (boost::weak_ptr<RBX::BatchThumbnailFetcher>::element_type *)(v1 + 32);
  result.px = (boost::shared_ptr<RBX::BatchThumbnailFetcher>::element_type *)v4.pn.pi_;
  v0->weak_this_.pn.pi_ = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)&result.px->weak_this_.pn, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x12544f0 | Name: _ZN5boost11make_sharedIN3RBX3Lua15WeakFunctionRefEJRS3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Lua::WeakFunctionRef,RBX::Lua::WeakFunctionRef&>(
        _QWORD *a1,
        RBX::Lua::WeakFunctionRef *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x58u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A44F8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::Lua::WeakFunctionRef::WeakFunctionRef((RBX::Lua::WeakFunctionRef *)(v2 + 32), args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1254850 | Name: _ZN5boost11make_sharedINSt3__16vectorINS1_4pairIN3RBX9ContentIdEPFRKNS1_12basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEvEEENS9_ISG_EEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<std::vector<std::pair<RBX::ContentId,const std::string &(*)()>> >::type __cdecl boost::make_shared<std::vector<std::pair<RBX::ContentId,std::string const& (*)(void)>>>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<std::vector<std::pair<RBX::ContentId,const std::string &(*)()>> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A4558;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1254910 | Name: _ZN5boost11make_sharedIN3RBX19PreloadAsyncRequestEJmEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::PreloadAsyncRequest,unsigned long>(_QWORD *a1, unsigned __int64 *args)
{
  char *v2; // rbx

  v2 = (char *)operator new(0x28u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = off_28A45B8;
  *((_QWORD *)v2 + 2) = 0;
  *(_QWORD *)(v2 + 28) = *(unsigned int *)args;
  v2[24] = 1;
  *a1 = v2 + 28;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x12555f0 | Name: _ZN5boost11make_sharedINSt3__16vectorINS_10shared_ptrINS2_INS3_IN3RBX8InstanceEEENS1_9allocatorIS6_EEEEEENS7_ISA_EEEEJmEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
void ***__fastcall boost::make_shared<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>,unsigned long>(
        void ***a1,
        unsigned __int64 *args)
{
  volatile signed __int32 *v2; // r13
  void **v3; // r14
  unsigned __int64 v4; // rbx
  _OWORD *v5; // rcx
  unsigned __int64 v6; // rax
  __int64 v7; // rdx
  _OWORD *v8; // rcx
  _OWORD *v9; // rcx
  __int64 v10; // rax
  double v12; // xmm0_8
  struct _Unwind_Exception *v13; // rax
  struct _Unwind_Exception *v14; // r15
  char *v15; // rbx
  char *v16; // rbp
  volatile signed __int32 *v17; // r12
  void *v18; // rdi

  v2 = (volatile signed __int32 *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A4618;
  *((_QWORD *)v2 + 2) = 0;
  *((_BYTE *)v2 + 24) = 0;
  v3 = (void **)(v2 + 8);
  v4 = *args;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  if ( v4 )
  {
    if ( v4 >> 60 )
    {
      v12 = std::__vector_base_common<true>::__throw_length_error(v2 + 8);
      v14 = v13;
      v15 = (char *)*v3;
      if ( *v3 )
      {
        v16 = (char *)*((_QWORD *)v2 + 5);
        if ( v16 == v15 )
        {
          v18 = *v3;
        }
        else
        {
          do
          {
            v17 = (volatile signed __int32 *)*((_QWORD *)v16 - 1);
            if ( v17 )
            {
              if ( !_InterlockedSub(v17 + 2, 1u) )
              {
                (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v17 + 16LL))(v17, v12);
                if ( !_InterlockedSub(v17 + 3, 1u) )
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
              }
            }
            v16 -= 16;
          }
          while ( v15 != v16 );
          v18 = *v3;
        }
        *((_QWORD *)v2 + 5) = v15;
        operator delete(v18);
      }
      if ( !_InterlockedSub(v2 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v2 + 16LL))(v2, v12);
        if ( !_InterlockedSub(v2 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
      }
      _Unwind_Resume(v14);
    }
    v5 = operator new(16 * v4);
    *((_QWORD *)v2 + 5) = v5;
    *((_QWORD *)v2 + 4) = v5;
    *((_QWORD *)v2 + 6) = &v5[v4];
    v6 = v4 - 1;
    if ( (v4 & 3) != 0 )
    {
      v7 = 0;
      do
      {
        *v5 = 0;
        v5 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v5;
        ++v7;
      }
      while ( (v4 & 3) != v7 );
      v4 -= v7;
    }
    if ( v6 >= 3 )
    {
      do
      {
        *v5 = 0;
        v8 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v8;
        *v8 = 0;
        v9 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v9;
        *v9 = 0;
        v10 = *((_QWORD *)v2 + 5);
        *((_QWORD *)v2 + 5) = v10 + 16;
        *(_OWORD *)(v10 + 16) = 0;
        v5 = (_OWORD *)(*((_QWORD *)v2 + 5) + 16LL);
        *((_QWORD *)v2 + 5) = v5;
        v4 -= 4LL;
      }
      while ( v4 );
    }
  }
  *((_BYTE *)v2 + 24) = 1;
  *a1 = v3;
  a1[1] = (void **)v2;
  _InterlockedAdd(v2 + 2, 1u);
  if ( !_InterlockedSub(v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub(v2 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1255920 | Name: _ZN5boost11make_sharedImJmEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<unsigned long,unsigned long>(_QWORD *a1, unsigned __int64 *args)
{
  char *v2; // rbx

  v2 = (char *)operator new(0x28u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = off_28A4678;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 4) = *args;
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x12559d0 | Name: _ZN5boost11make_sharedIKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJRA1_KcEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::string const,char const(&)[1]>(_QWORD *a1, const char (*args)[1])
{
  char *v2; // rbx
  char *v3; // r12
  size_t v4; // rax
  size_t v5; // r13
  void *v6; // rbp
  size_t v7; // r12
  struct _Unwind_Exception *v9; // r14

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A4438;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v3 = v2 + 32;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v4 = strlen((const char *)args);
  if ( v4 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    v9 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(v2 + 32);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
    {
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
      if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
        (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
    }
    _Unwind_Resume(v9);
  }
  v5 = v4;
  if ( v4 >= 0x17 )
  {
    v7 = (v4 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v6 = operator new(v7);
    *((_QWORD *)v2 + 6) = v6;
    *((_QWORD *)v2 + 4) = v7 | 1;
    *((_QWORD *)v2 + 5) = v5;
    v3 = v2 + 32;
  }
  else
  {
    v2[32] = 2 * v4;
    v6 = v2 + 33;
    if ( !v4 )
      goto LABEL_7;
  }
  memcpy(v6, args, v5);
LABEL_7:
  *((_BYTE *)v6 + v5) = 0;
  v2[24] = 1;
  *a1 = v3;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1255b40 | Name: _ZN5boost11make_sharedISt13runtime_errorJRA18_KcEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::runtime_error,char const(&)[18]>(_QWORD *a1, const char (*args)[18])
{
  char *v2; // r12

  v2 = (char *)operator new(0x30u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A2C48;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::runtime_error::runtime_error((std::runtime_error *)(v2 + 32), (const char *)args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1255e20 | Name: _ZN5boost11make_sharedINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJRS7_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::string,std::string&>(_QWORD *a1, std::string *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2876688;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::string::basic_string(v2 + 32, args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1256090 | Name: _ZN5boost11make_sharedINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJS7_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::string,std::string>(_QWORD *a1, std::string *args)
{
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2876688;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = *((_QWORD *)args + 2);
  *((_OWORD *)v2 + 2) = *(_OWORD *)args;
  *(_OWORD *)args = 0;
  *((_QWORD *)args + 2) = 0;
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1256160 | Name: _ZN5boost11make_sharedINSt3__119basic_istringstreamIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJRKNS1_12basic_stringIcS4_S6_EEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::istringstream,std::string const&>(_QWORD *a1, const std::string *args)
{
  _QWORD *v2; // rbx

  v2 = operator new(0x130u);
  v2[1] = 0x100000001LL;
  *v2 = &off_28A4728;
  v2[2] = 0;
  *((_BYTE *)v2 + 24) = 0;
  v2[19] = &off_2878EF0;
  *((_OWORD *)v2 + 2) = (unsigned __int64)&off_2878EC8;
  std::ios_base::init((std::ios_base *)(v2 + 19), v2 + 6);
  v2[36] = 0;
  *((_DWORD *)v2 + 74) = -1;
  v2[4] = &off_2878E58;
  v2[19] = off_2878E80;
  std::streambuf::basic_streambuf(v2 + 6);
  v2[6] = &off_28753A8;
  *((_OWORD *)v2 + 8) = 0;
  *((_OWORD *)v2 + 7) = 0;
  *((_DWORD *)v2 + 36) = 8;
  std::stringbuf::str((std::stringbuf *)(v2 + 6), args);
  *((_BYTE *)v2 + 24) = 1;
  *a1 = v2 + 4;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(_QWORD *))(*v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(_QWORD *))(*v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x125c420 | Name: _ZN5boost11make_sharedIKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJRS8_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::string const,std::string const&>(_QWORD *a1, const std::string *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A4438;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::string::basic_string(v2 + 32, args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x125da70 | Name: _ZN5boost6detail18sp_counted_impl_pdIPN3RBX19PreloadAsyncRequestENS0_13sp_ms_deleterIS3_EEE7disposeEv
void __fastcall boost::detail::sp_counted_impl_pd<RBX::PreloadAsyncRequest *,boost::detail::sp_ms_deleter<RBX::PreloadAsyncRequest>>::dispose(
        boost::detail::sp_counted_impl_pd<RBX::PreloadAsyncRequest *,boost::detail::sp_ms_deleter<RBX::PreloadAsyncRequest> > *this)
{
  if ( this->del.initialized_ )
    this->del.initialized_ = 0;
}


// Address: 0x125ecc0 | Name: _ZN5boost6detail18sp_counted_impl_pdIPmNS0_13sp_ms_deleterImEEE7disposeEv
void __fastcall boost::detail::sp_counted_impl_pd<unsigned long *,boost::detail::sp_ms_deleter<unsigned long>>::dispose(
        boost::detail::sp_counted_impl_pd<unsigned long *,boost::detail::sp_ms_deleter<unsigned long> > *this)
{
  if ( this->del.initialized_ )
    this->del.initialized_ = 0;
}


// Address: 0x125efd0 | Name: _ZN5boost11make_sharedISt13runtime_errorJS1_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::runtime_error,std::runtime_error>(_QWORD *a1, std::runtime_error *args)
{
  char *v2; // rbx

  v2 = (char *)operator new(0x30u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A2C48;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::runtime_error::runtime_error((std::runtime_error *)(v2 + 32), args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1263e70 | Name: _ZN5boost11make_sharedIN3RBX21BatchThumbnailFetcher17ThumbnailFetchJobEJNS_10shared_ptrIS2_EEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::BatchThumbnailFetcher::ThumbnailFetchJob **__fastcall boost::make_shared<RBX::BatchThumbnailFetcher::ThumbnailFetchJob,boost::shared_ptr<RBX::BatchThumbnailFetcher>>(
        RBX::BatchThumbnailFetcher::ThumbnailFetchJob **a1,
        boost::shared_ptr<RBX::BatchThumbnailFetcher> *args)
{
  char *v3; // rbx
  RBX::BatchThumbnailFetcher::ThumbnailFetchJob *v4; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v6; // rdi
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *v8; // rbx
  boost::shared_ptr<RBX::BatchThumbnailFetcher::ThumbnailFetchJob> v10; // [rsp+0h] [rbp-48h] BYREF
  boost::weak_ptr<RBX::BatchThumbnailFetcher> owner; // [rsp+18h] [rbp-30h] BYREF

  v10.px = 0;
  v3 = (char *)operator new(0x1F0u);
  *((_QWORD *)v3 + 1) = 0x100000001LL;
  *(_QWORD *)v3 = &off_28A48B8;
  *((_QWORD *)v3 + 2) = 0;
  v3[24] = 0;
  v10.pn.pi_ = (boost::detail::sp_counted_base *)v3;
  v4 = (RBX::BatchThumbnailFetcher::ThumbnailFetchJob *)(v3 + 32);
  owner.px = args->px;
  pi = args->pn.pi_;
  owner.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  RBX::BatchThumbnailFetcher::ThumbnailFetchJob::ThumbnailFetchJob(v4, &owner);
  v6 = owner.pn.pi_;
  if ( owner.pn.pi_ && !_InterlockedSub(&owner.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
  v3[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::BatchThumbnailFetcher::ThumbnailFetchJob,RBX::BatchThumbnailFetcher::ThumbnailFetchJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v3 + 40),
    &v10,
    v4);
  *a1 = v4;
  v7 = v10.pn.pi_;
  a1[1] = (RBX::BatchThumbnailFetcher::ThumbnailFetchJob *)v10.pn.pi_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    v8 = v10.pn.pi_;
    if ( v10.pn.pi_ )
    {
      if ( !_InterlockedSub(&v10.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
        if ( !_InterlockedSub(&v8->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
      }
    }
  }
  return a1;
}


// Address: 0x128fd10 | Name: _ZN5boost11make_sharedIN3RBX9HttpCache20HttpCacheAsyncWriterEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::HttpCache::HttpCacheAsyncWriter>::type __cdecl boost::make_shared<RBX::HttpCache::HttpCacheAsyncWriter>()
{
  __int64 v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::HttpCache::HttpCacheAsyncWriter>::type result; // rax

  v1 = (char *)operator new(0x68u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28A5B78;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  RBX::HttpCache::HttpCacheAsyncWriter::HttpCacheAsyncWriter((RBX::HttpCache::HttpCacheAsyncWriter *)(v1 + 32));
  v1[24] = 1;
  *(_QWORD *)v0 = v1 + 32;
  *(_QWORD *)(v0 + 8) = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = (boost::shared_ptr<RBX::HttpCache::HttpCacheAsyncWriter>::element_type *)v0;
  return result;
}


// Address: 0x128ff70 | Name: _ZN5boost11make_sharedIN3RBX16HttpResponseImplEJRNS1_11HttpRequestEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::HttpResponseImpl,RBX::HttpRequest &>(_QWORD *a1, RBX::HttpRequest *args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::HttpResponseImpl> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0x180u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A5BD8;
  *((_QWORD *)v2 + 2) = 0;
  v2[32] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::HttpResponseImpl::HttpResponseImpl((RBX::HttpResponseImpl *)(v2 + 48), args);
  v2[32] = 1;
  boost::enable_shared_from_this<RBX::HttpResponse>::_internal_accept_owner<RBX::HttpResponseImpl,RBX::HttpResponseImpl>(
    (const boost::enable_shared_from_this<RBX::HttpResponse> *)(v2 + 56),
    &v6,
    (RBX::HttpResponseImpl *)(v2 + 48));
  *a1 = v2 + 48;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x1290230 | Name: _ZN5boost11make_sharedIN3RBX17HttpClientHandlerEJRiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::HttpClientHandler,int &>(_QWORD *a1, unsigned int *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x168u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A5CE8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::HttpClientHandler::HttpClientHandler((RBX::HttpClientHandler *)(v2 + 32), *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x129ead0 | Name: _ZN5boost11make_sharedIN3RBX16HttpRequestMsxmlEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::HttpRequestMsxml>::type __cdecl __noreturn boost::make_shared<RBX::HttpRequestMsxml>()
{
  _QWORD *v0; // rax

  v0 = operator new(0x198u);
  v0[1] = 0x100000001LL;
  *v0 = &off_28A6028;
  v0[2] = 0;
  *((_BYTE *)v0 + 24) = 0;
  RBX::HttpRequestMsxml::HttpRequestMsxml((RBX::HttpRequestMsxml *)(v0 + 4));
}


// Address: 0x129ebf0 | Name: _ZN5boost11make_sharedIN3RBX15HttpRequestCurlEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::HttpRequestCurl>::type __cdecl boost::make_shared<RBX::HttpRequestCurl>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::HttpRequestCurl>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::HttpRequestCurl> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0x1C0u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28A6088;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::HttpRequestCurl::HttpRequestCurl((RBX::HttpRequestCurl *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::HttpRequest>::_internal_accept_owner<RBX::HttpRequestCurl,RBX::HttpRequestCurl>(
    (const boost::enable_shared_from_this<RBX::HttpRequest> *)(v1 + 40),
    &v4,
    (RBX::HttpRequestCurl *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x129ed10 | Name: _ZN5boost11make_sharedINS_7promiseINS_10shared_ptrIN3RBX12HttpResponseEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<boost::promise<boost::shared_ptr<RBX::HttpResponse> > >::type __cdecl boost::make_shared<boost::promise<boost::shared_ptr<RBX::HttpResponse>>>()
{
  boost::shared_ptr<boost::promise<boost::shared_ptr<RBX::HttpResponse> > >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<boost::promise<boost::shared_ptr<RBX::HttpResponse> > >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A60E8;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  v2[48] = 0;
  v2[24] = 1;
  v0->future_.px = (boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type *)(v2 + 32);
  v0->future_.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1313910 | Name: _ZN5boost11make_sharedIN3RBX14TimerTickerJobEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::TimerTickerJob>::type __cdecl boost::make_shared<RBX::TimerTickerJob>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::TimerTickerJob>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::TimerTickerJob> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0x1D0u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28A8398;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::TimerTickerJob::TimerTickerJob((RBX::TimerTickerJob *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TimerTickerJob,RBX::TimerTickerJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v1 + 40),
    &v4,
    (RBX::TimerTickerJob *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1313a80 | Name: _ZN5boost11make_sharedIN3RBX9TimerDataEJRKNS_8functionIFvRNS1_11SimpleTimerEEEERdEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::TimerData,boost::function<void ()(RBX::SimpleTimer &)> const&,double &>(
        _QWORD *a1,
        const boost::function<void (RBX::SimpleTimer &)> *args,
        double *a3)
{
  char *v4; // rbx
  __int64 v5; // r12
  boost::detail::function::vtable_base *vtable; // rax

  v4 = (char *)operator new(0x58u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_28A83F8;
  *((_QWORD *)v4 + 2) = 0;
  v4[24] = 0;
  v5 = *(_QWORD *)a3;
  *((_WORD *)v4 + 16) = 0;
  *((_QWORD *)v4 + 5) = 0;
  vtable = args->vtable;
  if ( args->vtable )
  {
    *((_QWORD *)v4 + 5) = vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      *((boost::detail::function::function_buffer *)v4 + 2) = args->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, char *, _QWORD))((unsigned __int64)vtable
                                                                                         & 0xFFFFFFFFFFFFFFFELL))(
        &args->functor,
        v4 + 48,
        0);
  }
  *((_QWORD *)v4 + 9) = v5;
  *((_QWORD *)v4 + 10) = 0;
  v4[24] = 1;
  *a1 = v4 + 32;
  a1[1] = v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return a1;
}


// Address: 0x13419d0 | Name: _ZN5boost11make_sharedIN3RBX10Soundscape24FMODPlaybackChannelGroupEJRPN4FMOD12ChannelGroupEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Soundscape::FMODPlaybackChannelGroup,FMOD::ChannelGroup *&>(
        _QWORD *a1,
        FMOD::ChannelGroup **args)
{
  boost::detail::sp_counted_base *v2; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::Soundscape::FMODPlaybackChannelGroup> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x50u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28AE618;
  v2[1]._vptr$sp_counted_base = 0;
  LOBYTE(v2[1].use_count_) = 0;
  v6.pn.pi_ = v2;
  RBX::Soundscape::FMODPlaybackChannelGroup::FMODPlaybackChannelGroup(
    (RBX::Soundscape::FMODPlaybackChannelGroup *)&v2[2],
    *args);
  LOBYTE(v2[1].use_count_) = 1;
  boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannelGroup>::_internal_accept_owner<RBX::Soundscape::FMODPlaybackChannelGroup,RBX::Soundscape::FMODPlaybackChannelGroup>(
    (const boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannelGroup> *)&v2[2],
    &v6,
    (RBX::Soundscape::FMODPlaybackChannelGroup *)&v2[2]);
  *a1 = v2 + 2;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x1342160 | Name: _ZN5boost11make_sharedIN3RBX10Soundscape19FMODPlaybackChannelEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Soundscape::FMODPlaybackChannel>::type __cdecl boost::make_shared<RBX::Soundscape::FMODPlaybackChannel>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_counted_base *v1; // r15
  boost::detail::sp_if_not_array<RBX::Soundscape::FMODPlaybackChannel>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::Soundscape::FMODPlaybackChannel> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (boost::detail::sp_counted_base *)operator new(0xF0u);
  *(_QWORD *)&v1->use_count_ = 0x100000001LL;
  v1->_vptr$sp_counted_base = (int (**)(void))&off_28AE6D8;
  v1[1]._vptr$sp_counted_base = 0;
  LOBYTE(v1[1].use_count_) = 0;
  v4.pn.pi_ = v1;
  RBX::Soundscape::FMODPlaybackChannel::FMODPlaybackChannel((RBX::Soundscape::FMODPlaybackChannel *)&v1[2]);
  LOBYTE(v1[1].use_count_) = 1;
  boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannel>::_internal_accept_owner<RBX::Soundscape::FMODPlaybackChannel,RBX::Soundscape::FMODPlaybackChannel>(
    (const boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannel> *)&v1[2],
    &v4,
    (RBX::Soundscape::FMODPlaybackChannel *)&v1[2]);
  *v0 = v1 + 2;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1342280 | Name: _ZN5boost11make_sharedIN3RBX10Soundscape21DetachedSoundPlaybackEJRNS_10shared_ptrINS2_19FMODPlaybackChannelEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Soundscape::DetachedSoundPlayback,boost::shared_ptr<RBX::Soundscape::FMODPlaybackChannel> &>(
        _QWORD *a1,
        boost::shared_ptr<RBX::Soundscape::FMODPlaybackChannel> *args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rcx

  v2 = (char *)operator new(0x40u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28AE738;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  *((_QWORD *)v2 + 4) = off_28AD550;
  *((_QWORD *)v2 + 5) = args->px;
  pi = args->pn.pi_;
  *((_QWORD *)v2 + 6) = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  *((_WORD *)v2 + 28) = 0;
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1342360 | Name: _ZN5boost11make_sharedIN3RBX10Soundscape15FMODPlaybackDSPEJRPN4FMOD3DSPEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Soundscape::FMODPlaybackDSP,FMOD::DSP *&>(_QWORD *a1, FMOD::DSP **args)
{
  char *v2; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::Soundscape::FMODPlaybackDSP> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0x48u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28AE798;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::Soundscape::FMODPlaybackDSP::FMODPlaybackDSP((RBX::Soundscape::FMODPlaybackDSP *)(v2 + 32), *args);
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackDSP>::_internal_accept_owner<RBX::Soundscape::FMODPlaybackDSP,RBX::Soundscape::FMODPlaybackDSP>(
    (const boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackDSP> *)v2 + 2,
    &v6,
    (RBX::Soundscape::FMODPlaybackDSP *)(v2 + 32));
  *a1 = v2 + 32;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x1342860 | Name: _ZN5boost11make_sharedIKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJS7_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::string const,std::string>(_QWORD *a1, std::string *args)
{
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A4438;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = *((_QWORD *)args + 2);
  *((_OWORD *)v2 + 2) = *(_OWORD *)args;
  *(_OWORD *)args = 0;
  *((_QWORD *)args + 2) = 0;
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1342df0 | Name: _ZN5boost11make_sharedIN3RBX10Soundscape5SoundEJRNS2_7SoundIdERPN4FMOD5SoundEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Soundscape::Sound,RBX::Soundscape::SoundId &,FMOD::Sound *&>(
        _QWORD *a1,
        RBX::Soundscape::SoundId *args,
        FMOD::Sound **a3)
{
  char *v4; // rbx
  __int64 v5; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v7; // rbx
  boost::shared_ptr<RBX::Soundscape::Sound> v9; // [rsp+0h] [rbp-38h] BYREF

  v9.px = 0;
  v4 = (char *)operator new(0x58u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_28AE7F8;
  *((_QWORD *)v4 + 2) = 0;
  v4[24] = 0;
  v9.pn.pi_ = (boost::detail::sp_counted_base *)v4;
  v5 = (__int64)*a3;
  *((_OWORD *)v4 + 2) = 0;
  *((_QWORD *)v4 + 6) = v5;
  *((_DWORD *)v4 + 14) = 0;
  std::string::basic_string(v4 + 64, args);
  v4[24] = 1;
  boost::enable_shared_from_this<RBX::Soundscape::Sound>::_internal_accept_owner<RBX::Soundscape::Sound,RBX::Soundscape::Sound>(
    (const boost::enable_shared_from_this<RBX::Soundscape::Sound> *)v4 + 2,
    &v9,
    (RBX::Soundscape::Sound *)(v4 + 32));
  *a1 = v4 + 32;
  pi = v9.pn.pi_;
  a1[1] = v9.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v7 = v9.pn.pi_;
    if ( v9.pn.pi_ )
    {
      if ( !_InterlockedSub(&v9.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
  }
  return a1;
}


// Address: 0x135c6c0 | Name: _ZN5boost11make_sharedIKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJRPKcRmEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
volatile signed __int32 **__fastcall boost::make_shared<std::string const,char const*&,unsigned long &>(
        volatile signed __int32 **a1,
        const char **args,
        unsigned __int64 *a3)
{
  volatile signed __int32 *v4; // rbx
  volatile signed __int32 *v5; // r15
  const void *v6; // r13
  size_t v7; // r12
  void *v8; // rbp
  double v10; // xmm0_8
  struct _Unwind_Exception *v11; // rax
  struct _Unwind_Exception *v12; // r14

  v4 = (volatile signed __int32 *)operator new(0x38u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_28A4438;
  *((_QWORD *)v4 + 2) = 0;
  *((_BYTE *)v4 + 24) = 0;
  v5 = v4 + 8;
  v6 = *args;
  v7 = *a3;
  *((_OWORD *)v4 + 2) = 0;
  *((_QWORD *)v4 + 6) = 0;
  if ( v7 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    v10 = std::__basic_string_common<true>::__throw_length_error(v4 + 8);
    v12 = v11;
    if ( !_InterlockedSub(v4 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v4 + 16LL))(v4, v10);
      if ( !_InterlockedSub(v4 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
    }
    _Unwind_Resume(v12);
  }
  if ( v7 >= 0x17 )
  {
    v8 = operator new((v7 + 16) & 0xFFFFFFFFFFFFFFF0LL);
    *((_QWORD *)v4 + 6) = v8;
    *((_QWORD *)v4 + 4) = (v7 + 16) & 0xFFFFFFFFFFFFFFF0LL | 1;
    *((_QWORD *)v4 + 5) = v7;
    v5 = v4 + 8;
  }
  else
  {
    *((_BYTE *)v4 + 32) = 2 * v7;
    v8 = (char *)v4 + 33;
    if ( !v7 )
      goto LABEL_7;
  }
  memcpy(v8, v6, v7);
LABEL_7:
  *((_BYTE *)v8 + v7) = 0;
  *((_BYTE *)v4 + 24) = 1;
  *a1 = v5;
  a1[1] = v4;
  _InterlockedAdd(v4 + 2, 1u);
  if ( !_InterlockedSub(v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub(v4 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return a1;
}


// Address: 0x135d0d0 | Name: _ZN5boost11make_sharedIN3RBX13WebSocketNullEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::WebSocketNull>::type __cdecl boost::make_shared<RBX::WebSocketNull>()
{
  boost::shared_ptr<RBX::WebSocketNull>::element_type *v0; // rdi
  char *v1; // rax
  int (**v2)(void); // rbx
  boost::detail::sp_if_not_array<RBX::WebSocketNull>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::WebSocketNull> v5; // [rsp+0h] [rbp-28h] BYREF

  v5.px = 0;
  v1 = (char *)operator new(0x40u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28AED38;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v5.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  v2 = (int (**)(void))(v1 + 32);
  *(_OWORD *)(v1 + 40) = 0;
  *((_QWORD *)v1 + 7) = 0;
  *((_QWORD *)v1 + 4) = off_28AECB0;
  *((_DWORD *)v1 + 14) = _InterlockedExchangeAdd(&dword_2A1BAD4, 1u);
  *((_DWORD *)v1 + 15) = -1;
  *((_QWORD *)v1 + 4) = off_28AED98;
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::WebSocket>::_internal_accept_owner<RBX::WebSocketNull,RBX::WebSocketNull>(
    (const boost::enable_shared_from_this<RBX::WebSocket> *)(v1 + 40),
    &v5,
    (RBX::WebSocketNull *)v1 + 1);
  v0->_vptr$WebSocket = v2;
  result.px = (boost::shared_ptr<RBX::WebSocketNull>::element_type *)v5.pn.pi_;
  v0->weak_this_.px = (boost::weak_ptr<RBX::WebSocket>::element_type *)v5.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)&result.px->boost::enable_shared_from_this<RBX::WebSocket>, 1u);
    pi = v5.pn.pi_;
    if ( v5.pn.pi_ )
    {
      if ( !_InterlockedSub(&v5.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1369a80 | Name: _ZN5boost11make_sharedIN3RBX4HttpEJRS2_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Http,RBX::Http&>(_QWORD *a1, RBX::Http *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0xA8u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28AF148;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::Http::Http((RBX::Http *)(v2 + 32), args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1370d80 | Name: _ZN5boost11make_sharedIN3RBX18BatchAssetApiStateEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::BatchAssetApiState>::type __cdecl boost::make_shared<RBX::BatchAssetApiState>()
{
  boost::shared_ptr<RBX::BatchAssetApiState>::element_type *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::BatchAssetApiState>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::BatchAssetApiState> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0x1C0u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28AF3A8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::BatchAssetApiState::BatchAssetApiState((RBX::BatchAssetApiState *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::BatchAssetApiState>::_internal_accept_owner<RBX::BatchAssetApiState,RBX::BatchAssetApiState>(
    (const boost::enable_shared_from_this<RBX::BatchAssetApiState> *)v1 + 2,
    &v4,
    (RBX::BatchAssetApiState *)(v1 + 32));
  v0->weak_this_.px = (boost::weak_ptr<RBX::BatchAssetApiState>::element_type *)(v1 + 32);
  result.px = (boost::shared_ptr<RBX::BatchAssetApiState>::element_type *)v4.pn.pi_;
  v0->weak_this_.pn.pi_ = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)&result.px->weak_this_.pn, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1415950 | Name: _ZN5boost11make_sharedIN3RBX19AnalyticsServiceJobEJPNS1_16AnalyticsServiceEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::AnalyticsServiceJob,RBX::AnalyticsService *>(
        _QWORD *a1,
        RBX::AnalyticsService **args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::AnalyticsServiceJob> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0x208u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28B5698;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::AnalyticsServiceJob::AnalyticsServiceJob((RBX::AnalyticsServiceJob *)(v2 + 32), *args);
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::AnalyticsServiceJob,RBX::AnalyticsServiceJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v2 + 40),
    &v6,
    (RBX::AnalyticsServiceJob *)(v2 + 32));
  *a1 = v2 + 32;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x1416e20 | Name: _ZN5boost11make_sharedIN3RBX24AnalyticsProviderPlayFabEJRNS_10shared_ptrINS1_16AnalyticsServiceEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::AnalyticsProviderPlayFab **__fastcall boost::make_shared<RBX::AnalyticsProviderPlayFab,boost::shared_ptr<RBX::AnalyticsService> &>(
        RBX::AnalyticsProviderPlayFab **a1,
        boost::shared_ptr<RBX::AnalyticsService> *args)
{
  unsigned __int64 v2; // rdx
  char *v3; // rbx
  RBX::AnalyticsProviderPlayFab *v4; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v6; // r12
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *v8; // rbx
  boost::shared_ptr<RBX::AnalyticsProviderPlayFab> v10; // [rsp+0h] [rbp-48h] BYREF
  boost::shared_ptr<RBX::AnalyticsService> analyticsService; // [rsp+18h] [rbp-30h] BYREF

  v10.px = 0;
  v3 = (char *)operator new(0x200u);
  *((_QWORD *)v3 + 1) = 0x100000001LL;
  *(_QWORD *)v3 = &off_28B57E8;
  *((_QWORD *)v3 + 2) = 0;
  v3[32] = 0;
  v10.pn.pi_ = (boost::detail::sp_counted_base *)v3;
  v4 = (RBX::AnalyticsProviderPlayFab *)(v3 + 48);
  analyticsService.px = args->px;
  pi = args->pn.pi_;
  analyticsService.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  RBX::AnalyticsProviderPlayFab::AnalyticsProviderPlayFab(
    v4,
    (boost::shared_ptr<RBX::AnalyticsService>)__PAIR128__(v2, &analyticsService));
  v6 = analyticsService.pn.pi_;
  if ( analyticsService.pn.pi_ )
  {
    if ( !_InterlockedSub(&analyticsService.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 2))(v6);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
  }
  v3[32] = 1;
  boost::enable_shared_from_this<RBX::AnalyticsProviderBase>::_internal_accept_owner<RBX::AnalyticsProviderPlayFab,RBX::AnalyticsProviderPlayFab>(
    (const boost::enable_shared_from_this<RBX::AnalyticsProviderBase> *)(v3 + 56),
    &v10,
    v4);
  *a1 = v4;
  v7 = v10.pn.pi_;
  a1[1] = (RBX::AnalyticsProviderPlayFab *)v10.pn.pi_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    v8 = v10.pn.pi_;
    if ( v10.pn.pi_ )
    {
      if ( !_InterlockedSub(&v10.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
        if ( !_InterlockedSub(&v8->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
      }
    }
  }
  return a1;
}


// Address: 0x14307e0 | Name: _ZN5boost11make_sharedIN3RBX24AnalyticsProviderPlayFab17BulkIngestionInfoEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::AnalyticsProviderPlayFab::BulkIngestionInfo>::type __cdecl boost::make_shared<RBX::AnalyticsProviderPlayFab::BulkIngestionInfo>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<RBX::AnalyticsProviderPlayFab::BulkIngestionInfo>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x78u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28B5BD8;
  *((_QWORD *)v2 + 2) = 0;
  *(_OWORD *)(v2 + 41) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 4) = 0x10u;
  *((_DWORD *)v2 + 20) = 1065353216;
  *(_OWORD *)(v2 + 100) = 0;
  *(_OWORD *)(v2 + 88) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x14308b0 | Name: _ZN5boost11make_sharedIN3RBX24AnalyticsProviderPlayFab13PlayFabEntityEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::AnalyticsProviderPlayFab::PlayFabEntity>::type __cdecl boost::make_shared<RBX::AnalyticsProviderPlayFab::PlayFabEntity>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<RBX::AnalyticsProviderPlayFab::PlayFabEntity>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x80u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28B5C38;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 7) = 0;
  *((_OWORD *)v2 + 6) = 0;
  *((_OWORD *)v2 + 5) = 0;
  *((_OWORD *)v2 + 4) = 0;
  *((_OWORD *)v2 + 3) = 0;
  *((_OWORD *)v2 + 2) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1430970 | Name: _ZN5boost11make_sharedIN3RBX24AnalyticsProviderPlayFab9EventInfoEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::AnalyticsProviderPlayFab::EventInfo>::type __cdecl boost::make_shared<RBX::AnalyticsProviderPlayFab::EventInfo>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<RBX::AnalyticsProviderPlayFab::EventInfo>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0xB0u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28B5C98;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 10) = 0;
  *((_OWORD *)v2 + 9) = 0;
  *((_OWORD *)v2 + 8) = 0;
  *((_OWORD *)v2 + 7) = 0;
  *((_OWORD *)v2 + 6) = 0;
  *((_OWORD *)v2 + 5) = 0;
  *((_OWORD *)v2 + 4) = 0;
  *((_OWORD *)v2 + 3) = 0;
  *((_OWORD *)v2 + 2) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1431290 | Name: _ZN5boost11make_sharedIN3RBX24AnalyticsProviderPlayFab17BulkIngestionInfoEJRS3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::AnalyticsProviderPlayFab::BulkIngestionInfo,RBX::AnalyticsProviderPlayFab::BulkIngestionInfo&>(
        _QWORD *a1,
        RBX::AnalyticsProviderPlayFab::BulkIngestionInfo *args)
{
  char *v2; // rbx
  __m128i v3; // xmm1
  double v4; // xmm0_8
  unsigned __int64 v5; // rdx
  unsigned __int64 v6; // rax
  __int64 v7; // rax
  unsigned __int64 v8; // rax
  unsigned __int64 v9; // rax
  float v11; // [rsp+0h] [rbp-34h]

  v2 = (char *)operator new(0x78u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28B5BD8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::string::basic_string(v2 + 32, args);
  v2[56] = 0;
  v3 = (__m128i)_mm_sub_pd(
                  (__m128d)_mm_unpacklo_ps((__m128)*((unsigned __int64 *)args + 5), (__m128)xmmword_3E4930),
                  *(__m128d *)(&errorFunction.functor.data + 8));
  v11 = *((float *)args + 12);
  v4 = floor((*(double *)_mm_shuffle_epi32(v3, 78).m128i_i64 + *(double *)v3.m128i_i64) / v11) + 1.0;
  v5 = (unsigned int)(int)v4;
  if ( v4 >= 9.223372036854776e18 )
    v5 = (unsigned int)(int)(v4 - 9.223372036854776e18) ^ 0x8000000000000000LL;
  v6 = -1;
  if ( v4 < 1.844674407370955e19 )
    v6 = v5;
  if ( v6 >= 5 )
  {
    v8 = (v6 - 1) | ((v6 - 1) >> 1) | (((v6 - 1) | ((v6 - 1) >> 1)) >> 2);
    v9 = v8 | (v8 >> 4) | ((v8 | (v8 >> 4)) >> 8);
    v7 = (v9 | (v9 >> 16) | ((v9 | (v9 >> 16)) >> 32)) + 1;
  }
  else
  {
    v7 = 4;
  }
  *((_QWORD *)v2 + 8) = v7;
  *((_QWORD *)v2 + 9) = 0;
  *((float *)v2 + 20) = v11;
  *(_OWORD *)(v2 + 88) = 0;
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::string>>,std::string,std::string,boost::hash<std::string>,std::equal_to<std::string>>>::init(
    (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::string > >,std::string,std::string,boost::hash<std::string>,std::equal_to<std::string > > > *)(v2 + 56),
    (const boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::string > >,std::string,std::string,boost::hash<std::string>,std::equal_to<std::string > > > *)((char *)args + 24));
  *((_DWORD *)v2 + 28) = *((_DWORD *)args + 20);
  *((_QWORD *)v2 + 13) = *((_QWORD *)args + 9);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1431790 | Name: _ZN5boost6detail13sp_ms_deleterIN3RBX24AnalyticsProviderPlayFab13PlayFabEntityEE7destroyEv
void __fastcall boost::detail::sp_ms_deleter<RBX::AnalyticsProviderPlayFab::PlayFabEntity>::destroy(
        boost::detail::sp_ms_deleter<RBX::AnalyticsProviderPlayFab::PlayFabEntity> *this)
{
  if ( this->initialized_ )
  {
    if ( (this->storage_.data_[72] & 1) != 0 )
    {
      operator delete(*((void **)&this->storage_.align_ + 11));
      if ( (this->storage_.data_[48] & 1) == 0 )
      {
LABEL_4:
        if ( (this->storage_.data_[24] & 1) == 0 )
          goto LABEL_5;
        goto LABEL_11;
      }
    }
    else if ( (this->storage_.data_[48] & 1) == 0 )
    {
      goto LABEL_4;
    }
    operator delete(*((void **)&this->storage_.align_ + 8));
    if ( (this->storage_.data_[24] & 1) == 0 )
    {
LABEL_5:
      if ( (this->storage_.data_[0] & 1) == 0 )
      {
LABEL_7:
        this->initialized_ = 0;
        return;
      }
LABEL_6:
      operator delete(*((void **)&this->storage_.align_ + 2));
      goto LABEL_7;
    }
LABEL_11:
    operator delete(*((void **)&this->storage_.align_ + 5));
    if ( (this->storage_.data_[0] & 1) == 0 )
      goto LABEL_7;
    goto LABEL_6;
  }
}


// Address: 0x1498fe0 | Name: _ZN5boost11make_sharedIN3RBX10Reflection5TupleEJmEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Reflection::Tuple,unsigned long>(_QWORD *a1, unsigned __int64 *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2894E28;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)(v2 + 32), *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x14d72c0 | Name: _ZN5boost11make_sharedIKN3RBX10Reflection5TupleEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<const RBX::Reflection::Tuple>::type __cdecl boost::make_shared<RBX::Reflection::Tuple const>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<const RBX::Reflection::Tuple>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28BE4E8;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1509ba0 | Name: _ZN5boost11make_sharedIN3RBX11TextScraperEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::TextScraper>::type __cdecl boost::make_shared<RBX::TextScraper>()
{
  boost::shared_ptr<RBX::TextScraper>::element_type *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::TextScraper>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::TextScraper> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0x1A8u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28BF8E8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::TextScraper::TextScraper((RBX::TextScraper *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::TextScraper>::_internal_accept_owner<RBX::TextScraper,RBX::TextScraper>(
    (const boost::enable_shared_from_this<RBX::TextScraper> *)v1 + 2,
    &v4,
    (RBX::TextScraper *)(v1 + 32));
  v0->weak_this_.px = (boost::weak_ptr<RBX::TextScraper>::element_type *)(v1 + 32);
  result.px = (boost::shared_ptr<RBX::TextScraper>::element_type *)v4.pn.pi_;
  v0->weak_this_.pn.pi_ = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)&result.px->weak_this_.pn, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1526300 | Name: _ZN5boost11make_sharedIN3RBX35SingleLocaleTableTranslatorInstanceEJNS_10shared_ptrINS1_17LocalizationTableEEENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::SingleLocaleTableTranslatorInstance **__fastcall boost::make_shared<RBX::SingleLocaleTableTranslatorInstance,boost::shared_ptr<RBX::LocalizationTable>,std::string>(
        RBX::SingleLocaleTableTranslatorInstance **a1,
        const __m128i *args,
        std::string *a3)
{
  char *v4; // rbx
  RBX::SingleLocaleTableTranslatorInstance *v5; // r12
  boost::shared_ptr<const RBX::LocalizationTable> v6; // xmm0
  volatile signed __int32 *v7; // xmm0_8
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v9; // rbx
  boost::shared_ptr<RBX::SingleLocaleTableTranslatorInstance> v11; // [rsp+0h] [rbp-48h] BYREF
  boost::shared_ptr<const RBX::LocalizationTable> table; // [rsp+10h] [rbp-38h] BYREF

  v11.px = 0;
  v4 = (char *)operator new(0xD8u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_28C07C8;
  *((_QWORD *)v4 + 2) = 0;
  v4[24] = 0;
  v11.pn.pi_ = (boost::detail::sp_counted_base *)v4;
  v5 = (RBX::SingleLocaleTableTranslatorInstance *)(v4 + 32);
  v6 = (boost::shared_ptr<const RBX::LocalizationTable>)_mm_loadu_si128(args);
  args->m128i_i64[1] = 0;
  table = v6;
  args->m128i_i64[0] = 0;
  v7 = (volatile signed __int32 *)_mm_shuffle_epi32((__m128i)v6, 78).m128i_u64[0];
  RBX::SingleLocaleTableTranslatorInstance::SingleLocaleTableTranslatorInstance(
    (RBX::SingleLocaleTableTranslatorInstance *)(v4 + 32),
    &table,
    a3);
  if ( v7 )
  {
    if ( !_InterlockedSub(v7 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v7 + 16LL))(v7, *(double *)&v7);
      if ( !_InterlockedSub(v7 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
    }
  }
  v4[24] = 1;
  boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SingleLocaleTableTranslatorInstance,RBX::SingleLocaleTableTranslatorInstance>(
    (const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *)(v4 + 40),
    &v11,
    v5);
  *a1 = v5;
  pi = v11.pn.pi_;
  a1[1] = (RBX::SingleLocaleTableTranslatorInstance *)v11.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v9 = v11.pn.pi_;
    if ( v11.pn.pi_ )
    {
      if ( !_InterlockedSub(&v11.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
        if ( !_InterlockedSub(&v9->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
      }
    }
  }
  return a1;
}


// Address: 0x1526800 | Name: _ZN5boost11make_sharedIN3RBX17LocalizationTable5EntryEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::LocalizationTable::Entry>::type __cdecl boost::make_shared<RBX::LocalizationTable::Entry>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::LocalizationTable::Entry>::type result; // rax

  v1 = (char *)operator new(0xE8u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28C0828;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  *((_OWORD *)v1 + 13) = 0;
  *((_OWORD *)v1 + 12) = 0;
  *((_OWORD *)v1 + 11) = 0;
  *((_OWORD *)v1 + 10) = 0;
  *((_OWORD *)v1 + 9) = 0;
  *((_OWORD *)v1 + 8) = 0;
  *((_OWORD *)v1 + 7) = 0;
  *((_OWORD *)v1 + 6) = 0;
  *((_OWORD *)v1 + 5) = 0;
  *((_OWORD *)v1 + 4) = 0;
  *((_OWORD *)v1 + 3) = 0;
  *((_OWORD *)v1 + 2) = 0;
  *((_QWORD *)v1 + 28) = 0;
  RBX::Localization::Expression::Expression((RBX::Localization::Expression *)(v1 + 128));
  v1[184] = 0;
  *((_OWORD *)v1 + 12) = 0x10u;
  *((_DWORD *)v1 + 52) = 1065353216;
  *(_OWORD *)(v1 + 216) = 0;
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x1541550 | Name: _ZN5boost11make_sharedIKNSt3__16vectorINS_10shared_ptrIN3RBX8InstanceEEENS1_9allocatorIS6_EEEEJRS9_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::vector<boost::shared_ptr<RBX::Instance>> const,std::vector<boost::shared_ptr<RBX::Instance>>&>(
        _QWORD *a1,
        std::vector<boost::shared_ptr<RBX::Instance>> *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28C1518;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::vector<boost::shared_ptr<RBX::Instance>>::vector(
    (std::vector<boost::shared_ptr<RBX::Instance>> *)(v2 + 32),
    args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1541bf0 | Name: _ZN5boost11make_sharedIKNSt3__16vectorIN3RBX10Reflection7VariantENS1_9allocatorIS5_EEEEJRS8_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::vector<RBX::Reflection::Variant> const,std::vector<RBX::Reflection::Variant>&>(
        _QWORD *a1,
        std::vector<RBX::Reflection::Variant> *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_289CC38;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)(v2 + 32), args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1541cf0 | Name: _ZN5boost11make_sharedIN3RBX3Lua18EventSignalWrapperIFvNS_10shared_ptrINS1_8InstanceEEEEN3rbx6signalIS7_EEEEJRNS4_ISA_EEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Lua::EventSignalWrapper<void ()(boost::shared_ptr<RBX::Instance>),rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::shared_ptr<rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>> &>(
        _QWORD *a1,
        boost::shared_ptr<rbx::signal<void (boost::shared_ptr<RBX::Instance>)> > *args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rcx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28C1578;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  *((_QWORD *)v2 + 4) = off_28C15D8;
  *((_QWORD *)v2 + 5) = args->px;
  pi = args->pn.pi_;
  *((_QWORD *)v2 + 6) = pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1541e90 | Name: _ZN5boost11make_sharedIN3rbx6signalIFvNS_10shared_ptrIN3RBX8InstanceEEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<rbx::signal<void (boost::shared_ptr<RBX::Instance>)> >::type __cdecl boost::make_shared<rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>>()
{
  boost::shared_ptr<rbx::signal<void (boost::shared_ptr<RBX::Instance>)> >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<rbx::signal<void (boost::shared_ptr<RBX::Instance>)> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x28u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28C1618;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 4) = 0;
  v2[24] = 1;
  v0->head.px = (rbx::signals::slot_base *)(v2 + 32);
  v0[1].head.px = (rbx::signals::slot_base *)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x15440e0 | Name: _ZN5boost11make_sharedINSt3__16vectorINS_10shared_ptrIN3RBX8InstanceEEENS1_9allocatorIS6_EEEEJRS9_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::vector<boost::shared_ptr<RBX::Instance>>,std::vector<boost::shared_ptr<RBX::Instance>>&>(
        _QWORD *a1,
        std::vector<boost::shared_ptr<RBX::Instance>> *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_288F588;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::vector<boost::shared_ptr<RBX::Instance>>::vector(
    (std::vector<boost::shared_ptr<RBX::Instance>> *)(v2 + 32),
    args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x15837f0 | Name: _ZN5boost11make_sharedIN3RBX9DataModel10GenericJobEJRNS_10shared_ptrIS2_EERA17_KcNS1_12DataModelJob8TaskTypeEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::DataModel::GenericJob **__fastcall boost::make_shared<RBX::DataModel::GenericJob,boost::shared_ptr<RBX::DataModel> &,char const(&)[17],RBX::DataModelJob::TaskType>(
        RBX::DataModel::GenericJob **a1,
        boost::shared_ptr<RBX::DataModel> *args,
        const char (*a3)[17],
        enum : __int32 {Read = 0x0,
        Write = 0x1,Render = 0x2,Simulation = 0x3,DataOut = 0x4,PhysicsOut = 0x5,PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        Render = 0x2,Simulation = 0x3,DataOut = 0x4,PhysicsOut = 0x5,PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        Simulation = 0x3,DataOut = 0x4,PhysicsOut = 0x5,PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        DataOut = 0x4,PhysicsOut = 0x5,PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        PhysicsOut = 0x5,PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        None = 0xA,TaskTypeMax = 0xB,} *a4)
        TaskTypeMax = 0xB,} *a4)
        } *a4)
{
  char *v6; // rbx
  RBX::DataModelJob::TaskType v7; // r8d
  RBX::DataModel::GenericJob *v8; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v10; // rbp
  boost::detail::sp_counted_base *v11; // rax
  boost::detail::sp_counted_base *v12; // rbx
  boost::shared_ptr<RBX::DataModel::GenericJob> v14; // [rsp+0h] [rbp-58h] BYREF
  boost::shared_ptr<RBX::DataModel> dataModel; // [rsp+18h] [rbp-40h] BYREF

  v14.px = 0;
  v6 = (char *)operator new(0x240u);
  *((_QWORD *)v6 + 1) = 0x100000001LL;
  *(_QWORD *)v6 = &off_28C6188;
  *((_QWORD *)v6 + 2) = 0;
  v6[24] = 0;
  v14.pn.pi_ = (boost::detail::sp_counted_base *)v6;
  v8 = (RBX::DataModel::GenericJob *)(v6 + 32);
  dataModel.px = args->px;
  pi = args->pn.pi_;
  dataModel.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  RBX::DataModel::GenericJob::GenericJob(
    v8,
    (boost::shared_ptr<RBX::DataModel>)__PAIR128__((unsigned __int64)a3, &dataModel),
    (const char *)(unsigned int)*a4,
    v7);
  v10 = dataModel.pn.pi_;
  if ( dataModel.pn.pi_ )
  {
    if ( !_InterlockedSub(&dataModel.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
      if ( !_InterlockedSub(&v10->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  v6[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::DataModel::GenericJob,RBX::DataModel::GenericJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v6 + 40),
    &v14,
    v8);
  *a1 = v8;
  v11 = v14.pn.pi_;
  a1[1] = (RBX::DataModel::GenericJob *)v14.pn.pi_;
  if ( v11 )
  {
    _InterlockedAdd(&v11->use_count_, 1u);
    v12 = v14.pn.pi_;
    if ( v14.pn.pi_ )
    {
      if ( !_InterlockedSub(&v14.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
        if ( !_InterlockedSub(&v12->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
      }
    }
  }
  return a1;
}


// Address: 0x15839c0 | Name: _ZN5boost11make_sharedIN3RBX9DataModel10GenericJobEJRNS_10shared_ptrIS2_EERA16_KcNS1_12DataModelJob8TaskTypeEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::DataModel::GenericJob **__fastcall boost::make_shared<RBX::DataModel::GenericJob,boost::shared_ptr<RBX::DataModel> &,char const(&)[16],RBX::DataModelJob::TaskType>(
        RBX::DataModel::GenericJob **a1,
        boost::shared_ptr<RBX::DataModel> *args,
        const char (*a3)[16],
        enum : __int32 {Read = 0x0,
        Write = 0x1,Render = 0x2,Simulation = 0x3,DataOut = 0x4,PhysicsOut = 0x5,PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        Render = 0x2,Simulation = 0x3,DataOut = 0x4,PhysicsOut = 0x5,PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        Simulation = 0x3,DataOut = 0x4,PhysicsOut = 0x5,PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        DataOut = 0x4,PhysicsOut = 0x5,PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        PhysicsOut = 0x5,PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        PhysicsOutSort = 0x6,DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        DataIn = 0x7,PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        PhysicsIn = 0x8,RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        RaknetPeer = 0x9,None = 0xA,TaskTypeMax = 0xB,} *a4)
        None = 0xA,TaskTypeMax = 0xB,} *a4)
        TaskTypeMax = 0xB,} *a4)
        } *a4)
{
  char *v6; // rbx
  RBX::DataModelJob::TaskType v7; // r8d
  RBX::DataModel::GenericJob *v8; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v10; // rbp
  boost::detail::sp_counted_base *v11; // rax
  boost::detail::sp_counted_base *v12; // rbx
  boost::shared_ptr<RBX::DataModel::GenericJob> v14; // [rsp+0h] [rbp-58h] BYREF
  boost::shared_ptr<RBX::DataModel> dataModel; // [rsp+18h] [rbp-40h] BYREF

  v14.px = 0;
  v6 = (char *)operator new(0x240u);
  *((_QWORD *)v6 + 1) = 0x100000001LL;
  *(_QWORD *)v6 = &off_28C6188;
  *((_QWORD *)v6 + 2) = 0;
  v6[24] = 0;
  v14.pn.pi_ = (boost::detail::sp_counted_base *)v6;
  v8 = (RBX::DataModel::GenericJob *)(v6 + 32);
  dataModel.px = args->px;
  pi = args->pn.pi_;
  dataModel.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  RBX::DataModel::GenericJob::GenericJob(
    v8,
    (boost::shared_ptr<RBX::DataModel>)__PAIR128__((unsigned __int64)a3, &dataModel),
    (const char *)(unsigned int)*a4,
    v7);
  v10 = dataModel.pn.pi_;
  if ( dataModel.pn.pi_ )
  {
    if ( !_InterlockedSub(&dataModel.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
      if ( !_InterlockedSub(&v10->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  v6[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::DataModel::GenericJob,RBX::DataModel::GenericJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v6 + 40),
    &v14,
    v8);
  *a1 = v8;
  v11 = v14.pn.pi_;
  a1[1] = (RBX::DataModel::GenericJob *)v14.pn.pi_;
  if ( v11 )
  {
    _InterlockedAdd(&v11->use_count_, 1u);
    v12 = v14.pn.pi_;
    if ( v14.pn.pi_ )
    {
      if ( !_InterlockedSub(&v14.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
        if ( !_InterlockedSub(&v12->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
      }
    }
  }
  return a1;
}


// Address: 0x15841c0 | Name: _ZN5boost11make_sharedIN3RBX6CEventEJbEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::CEvent,bool>(_QWORD *a1, bool *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0xA8u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28C62F8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::CEvent::CEvent((RBX::CEvent *)(v2 + 32), *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1584520 | Name: _ZN5boost11make_sharedIN3RBX7GuiRootEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::GuiRoot>::type __cdecl boost::make_shared<RBX::GuiRoot>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::GuiRoot>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::GuiRoot> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0x98u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28C64F8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::GuiRoot::GuiRoot((RBX::GuiRoot *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::GuiRoot,RBX::GuiRoot>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v1 + 40),
    &v4,
    (RBX::GuiRoot *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1585ba0 | Name: _ZN5boost11make_sharedIN3RBX20CorescriptConfigurerEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::CorescriptConfigurer>::type __cdecl boost::make_shared<RBX::CorescriptConfigurer>()
{
  _QWORD *v0; // rdi
  char *v1; // rax
  char *v2; // rbx
  boost::detail::sp_if_not_array<RBX::CorescriptConfigurer>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::CorescriptConfigurer> v5; // [rsp+0h] [rbp-28h] BYREF

  v5.px = 0;
  v1 = (char *)operator new(0x70u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28C6F18;
  *((_QWORD *)v1 + 2) = 0;
  v5.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  v2 = v1 + 32;
  *(_OWORD *)(v1 + 40) = 0;
  *((_OWORD *)v1 + 4) = 0;
  *((_QWORD *)v1 + 4) = off_28792D8;
  *(_OWORD *)(v1 + 88) = 0;
  *((_QWORD *)v1 + 13) = 0;
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::GameConfigurer>::_internal_accept_owner<RBX::CorescriptConfigurer,RBX::CorescriptConfigurer>(
    (const boost::enable_shared_from_this<RBX::GameConfigurer> *)(v1 + 40),
    &v5,
    (RBX::CorescriptConfigurer *)(v1 + 32));
  *v0 = v2;
  result.px = v5.pn.pi_;
  v0[1] = v5.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v5.pn.pi_;
    if ( v5.pn.pi_ )
    {
      if ( !_InterlockedSub(&v5.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x15869a0 | Name: _ZN5boost11make_sharedINS_7promiseINS_10shared_ptrINSt3__16vectorINS2_INS4_INS2_IN3RBX8InstanceEEENS3_9allocatorIS7_EEEEEENS8_ISB_EEEEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::type __cdecl boost::make_shared<boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>>()
{
  boost::shared_ptr<boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28C6F78;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  v2[48] = 0;
  v2[24] = 1;
  v0->future_.px = (boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type *)(v2 + 32);
  v0->future_.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1588380 | Name: _ZN5boost11make_sharedIN3RBX17http_status_errorEJRS2_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::http_status_error,RBX::http_status_error&>(
        _QWORD *a1,
        RBX::http_status_error *args)
{
  char *v2; // rbx

  v2 = (char *)operator new(0x50u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28C7138;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::runtime_error::runtime_error((std::runtime_error *)(v2 + 32), args);
  *((_QWORD *)v2 + 4) = off_2878910;
  std::string::basic_string(v2 + 48, (char *)args + 16);
  *((_DWORD *)v2 + 18) = *((_DWORD *)args + 10);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x15884a0 | Name: _ZN5boost11make_sharedIN3RBX17http_status_errorEJiPKcEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::http_status_error **__fastcall boost::make_shared<RBX::http_status_error,int,char const*>(
        RBX::http_status_error **a1,
        int *args,
        const char **a3)
{
  RBX::http_status_error **v4; // r14
  char *v5; // r15
  volatile signed __int32 *v6; // rbx
  const char *v7; // r13
  size_t v8; // rax
  size_t v9; // rbp
  char *v10; // r12
  size_t v11; // r14
  RBX::http_status_error *v12; // r15
  __int64 v14; // rdx
  __int64 v15; // rcx
  __int64 v16; // r8
  __int64 v17; // r9
  double v18; // xmm0_8
  struct _Unwind_Exception *v19; // rax
  struct _Unwind_Exception *v20; // rbp
  __int128 dest; // [rsp+0h] [rbp-58h] BYREF
  void *ptr; // [rsp+10h] [rbp-48h]
  int statusCode; // [rsp+1Ch] [rbp-3Ch]
  RBX::http_status_error **v24; // [rsp+20h] [rbp-38h]

  v4 = a1;
  v5 = (char *)operator new(0x50u);
  v6 = (volatile signed __int32 *)v5;
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28C7138;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  statusCode = *args;
  v7 = *a3;
  dest = 0;
  ptr = 0;
  v8 = strlen(v7);
  if ( v8 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    v18 = std::__basic_string_common<true>::__throw_length_error(&dest);
    v20 = v19;
    if ( !_InterlockedSub((volatile signed __int32 *)v5 + 2, 1u) )
    {
      (*(void (__fastcall **)(char *, int *, __int64, __int64, __int64, __int64, double, _QWORD, _QWORD, void *))(*(_QWORD *)v5 + 16LL))(
        v5,
        args,
        v14,
        v15,
        v16,
        v17,
        v18,
        dest,
        *((_QWORD *)&dest + 1),
        ptr);
      if ( !_InterlockedSub((volatile signed __int32 *)v5 + 3, 1u) )
        (*(void (__fastcall **)(char *))(*(_QWORD *)v5 + 24LL))(v5);
    }
    _Unwind_Resume(v20);
  }
  v9 = v8;
  if ( v8 >= 0x17 )
  {
    v24 = a1;
    v11 = (v8 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v10 = (char *)operator new(v11);
    ptr = v10;
    *(_QWORD *)&dest = v11 | 1;
    *((_QWORD *)&dest + 1) = v9;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v8;
  v10 = (char *)&dest + 1;
  if ( v8 )
LABEL_6:
    memcpy(v10, v7, v9);
  v12 = (RBX::http_status_error *)(v5 + 32);
  v10[v9] = 0;
  RBX::http_status_error::http_status_error(v12, statusCode, (const std::string *)&dest);
  if ( (dest & 1) != 0 )
    operator delete(ptr);
  *((_BYTE *)v6 + 24) = 1;
  *v4 = v12;
  v4[1] = (RBX::http_status_error *)v6;
  _InterlockedAdd(v6 + 2, 1u);
  if ( !_InterlockedSub(v6 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
  return v4;
}


// Address: 0x15c2340 | Name: _ZN5boost11make_sharedINSt3__16vectorIN3RBX10Reflection7VariantENS1_9allocatorIS5_EEEEJRKS8_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::vector<RBX::Reflection::Variant>,std::vector<RBX::Reflection::Variant> const&>(
        _QWORD *a1,
        const std::vector<RBX::Reflection::Variant> *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_288D878;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)(v2 + 32), args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x15cf260 | Name: _ZN5boost11make_sharedIN3RBX10AppStorageEJNS2_11SecretParamEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::AppStorage,RBX::AppStorage::SecretParam>(
        _QWORD *a1,
        RBX::AppStorage::SecretParam *args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::AppStorage> v6; // [rsp+0h] [rbp-28h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0xB8u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28C9388;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::LocalStorage::LocalStorage((RBX::LocalStorage *)(v2 + 32));
  *((_QWORD *)v2 + 4) = off_28C9330;
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::LocalStorage>::_internal_accept_owner<RBX::AppStorage,RBX::AppStorage>(
    (const boost::enable_shared_from_this<RBX::LocalStorage> *)(v2 + 40),
    &v6,
    (RBX::AppStorage *)(v2 + 32));
  *a1 = v2 + 32;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x160b860 | Name: _ZN5boost11make_sharedIN3RBX9DataStore12CachedRecordEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::DataStore::CachedRecord>::type __cdecl boost::make_shared<RBX::DataStore::CachedRecord>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::DataStore::CachedRecord>::type result; // rax

  v1 = (char *)operator new(0xB0u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_28CB128;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  *((_QWORD *)v1 + 4) = RBX::Reflection::Type::getSingleton<void>();
  *((_QWORD *)v1 + 5) = 0;
  *((_OWORD *)v1 + 10) = 0;
  *((_OWORD *)v1 + 9) = 0;
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x160bba0 | Name: _ZN5boost11make_sharedIN3rbx6signalIFvN3RBX10Reflection7VariantEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<rbx::signal<void (RBX::Reflection::Variant)> >::type __cdecl boost::make_shared<rbx::signal<void ()(RBX::Reflection::Variant)>>()
{
  boost::shared_ptr<rbx::signal<void (RBX::Reflection::Variant)> >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<rbx::signal<void (RBX::Reflection::Variant)> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x28u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28CB188;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 4) = 0;
  v2[24] = 1;
  v0->head.px = (rbx::signals::slot_base *)(v2 + 32);
  v0[1].head.px = (rbx::signals::slot_base *)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x160bc50 | Name: _ZN5boost11make_sharedIN3RBX9DataStore9EventSlotEJRNS1_3Lua15WeakFunctionRefEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::DataStore::EventSlot,RBX::Lua::WeakFunctionRef &>(
        _QWORD *a1,
        RBX::Lua::WeakFunctionRef *args)
{
  char *v2; // r12
  RBX::Lua::WeakFunctionRef v4; // [rsp+0h] [rbp-58h] BYREF

  v2 = (char *)operator new(0x58u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28CB1E8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::Lua::WeakFunctionRef::WeakFunctionRef(&v4, args);
  RBX::Lua::WeakFunctionRef::WeakFunctionRef((RBX::Lua::WeakFunctionRef *)(v2 + 32), &v4);
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef(&v4);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1641a50 | Name: _ZN5boost11make_sharedINS_9unordered13unordered_mapIlN3RBX26FriendService_FriendStatusENS_4hashIlEENSt3__18equal_toIlEENS7_9allocatorINS7_4pairIKlS4_EEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >::type __cdecl boost::make_shared<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>()
{
  boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >::element_type *v0; // rdi
  boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >::element_type *v1; // r14
  char *v2; // rbx
  const boost::unordered::detail::false_type *v3; // rcx
  __int64 v4; // rdx
  const boost::unordered::detail::false_type *v5; // rsi
  __int64 v6; // rdi
  boost::detail::sp_if_not_array<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >::type result; // rax
  const boost::unordered::detail::false_type *v8; // rsi

  v1 = v0;
  v2 = (char *)operator new(0x50u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28D0878;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v2[32] = 0;
  v3 = &stru_495510;
  v4 = 38;
  do
  {
    v5 = v3;
    v6 = v4 + ~(v4 / 2);
    if ( *(_QWORD *)&v3[8 * (v4 / 2)].gap0 >= 0xBu )
      v6 = v4 / 2;
    v3 += 8 * (v4 / 2) + 8;
    if ( *(_QWORD *)&v5[8 * (v4 / 2)].gap0 >= 0xBu )
      v3 = v5;
    v4 = v6;
  }
  while ( v6 );
  result.pn.pi_ = (boost::detail::sp_counted_base *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_5list1I"
                                                    "NS0_5valueIPS5_EEEEEE";
  v8 = v3 - 8;
  if ( v3 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v8 = v3;
  *((_QWORD *)v2 + 5) = *(_QWORD *)&v8->gap0;
  *((_QWORD *)v2 + 6) = 0;
  *((_DWORD *)v2 + 14) = 1065353216;
  *((_OWORD *)v2 + 4) = 0;
  v2[24] = 1;
  *(_QWORD *)&v1->table_.current_ = v2 + 32;
  v1->table_.bucket_count_ = (size_t)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v1;
  return result;
}


// Address: 0x174a2f0 | Name: _ZN5boost11make_sharedIN3RBX12GroupService16GroupRolesResultEJRKS3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::GroupService::GroupRolesResult,RBX::GroupService::GroupRolesResult const&>(
        _QWORD *a1,
        const RBX::GroupService::GroupRolesResult *args)
{
  char *v2; // rbx

  v2 = (char *)operator new(0x70u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28DDC18;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v2[32] = *(_BYTE *)args;
  std::string::basic_string(v2 + 40, (char *)args + 8);
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<long const,RBX::GroupService::GroupRole>>,long,RBX::GroupService::GroupRole,boost::hash<long>,std::equal_to<long>>>::table_impl(
    (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const long,RBX::GroupService::GroupRole> >,long,RBX::GroupService::GroupRole,boost::hash<long>,std::equal_to<long> > > *)(v2 + 64),
    (const boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const long,RBX::GroupService::GroupRole> >,long,RBX::GroupService::GroupRole,boost::hash<long>,std::equal_to<long> > > *)((char *)args + 32));
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x176dda0 | Name: _ZN5boost11make_sharedIN3RBX13RelativePanelEJRNS1_6LayoutEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::RelativePanel,RBX::Layout &>(_QWORD *a1, RBX::Layout *args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::RelativePanel> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0xB8u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28DF1B8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::GuiItem::GuiItem((RBX::GuiItem *)(v2 + 32));
  *((_QWORD *)v2 + 4) = off_28C9510;
  *((_OWORD *)v2 + 9) = xmmword_3EA480;
  RBX::TopMenuBar::init((RBX::TopMenuBar *)(v2 + 32));
  *((_QWORD *)v2 + 4) = off_28C9678;
  *((_DWORD *)v2 + 44) = 0;
  RBX::RelativePanel::init((RBX::RelativePanel *)(v2 + 32), args);
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::RelativePanel,RBX::RelativePanel>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v2 + 40),
    &v6,
    (RBX::RelativePanel *)(v2 + 32));
  *a1 = v2 + 32;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x176e1f0 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA18_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[18]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[18])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176e4a0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA13_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[13]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[13])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176e750 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA14_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[14]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[14])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176ea00 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA20_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[20]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[20])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176ecb0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA10_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[10]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[10])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176ef60 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA12_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[12]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[12])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176f210 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA19_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[19]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[19])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176f4c0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA8_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[8]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[8])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176f770 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA7_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[7]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[7])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176fa20 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA21_KcRA22_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[21],char const(&)[22]>(
        RBX::EquationDisplay **a1,
        const char (*args)[21],
        const char (*a3)[22])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176fcd0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA18_KcRA13_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[18],char const(&)[13]>(
        RBX::EquationDisplay **a1,
        const char (*args)[18],
        const char (*a3)[13])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x176ff80 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA18_KcRA19_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[18],char const(&)[19]>(
        RBX::EquationDisplay **a1,
        const char (*args)[18],
        const char (*a3)[19])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1770230 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA21_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[21]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[21])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17704e0 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA22_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[22]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[22])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1770790 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcS5_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[17]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[17])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1770a40 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA4_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[4]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[4])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1770cf0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA11_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[11]>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[11])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1770fa0 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA20_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[20]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[20])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1771320 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA19_KcRA16_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[19],char const(&)[16]>(
        RBX::EquationDisplay **a1,
        const char (*args)[19],
        const char (*a3)[16])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17715d0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA13_KcRA22_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[13],char const(&)[22]>(
        RBX::EquationDisplay **a1,
        const char (*args)[13],
        const char (*a3)[22])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1771880 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA24_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[24]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[24])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1771b30 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA13_KcRA21_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[13],char const(&)[21]>(
        RBX::EquationDisplay **a1,
        const char (*args)[13],
        const char (*a3)[21])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1771de0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA18_KcRA25_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[18],char const(&)[25]>(
        RBX::EquationDisplay **a1,
        const char (*args)[18],
        const char (*a3)[25])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1772090 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA23_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[23]>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[23])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1772340 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA21_KcRA13_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[21],char const(&)[13]>(
        RBX::EquationDisplay **a1,
        const char (*args)[21],
        const char (*a3)[13])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17725f0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA27_KcRA7_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[27],char const(&)[7]>(
        RBX::EquationDisplay **a1,
        const char (*args)[27],
        const char (*a3)[7])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17728a0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA6_KcRA21_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[6],char const(&)[21]>(
        RBX::EquationDisplay **a1,
        const char (*args)[6],
        const char (*a3)[21])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1772b50 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA6_KcRA15_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[6],char const(&)[15]>(
        RBX::EquationDisplay **a1,
        const char (*args)[6],
        const char (*a3)[15])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1772e00 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA8_KcRA17_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[8],char const(&)[17]>(
        RBX::EquationDisplay **a1,
        const char (*args)[8],
        const char (*a3)[17])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17730b0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA21_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[21]>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[21])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1773360 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA16_KcRA22_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[16],char const(&)[22]>(
        RBX::EquationDisplay **a1,
        const char (*args)[16],
        const char (*a3)[22])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1773610 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA12_KcRA18_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[12],char const(&)[18]>(
        RBX::EquationDisplay **a1,
        const char (*args)[12],
        const char (*a3)[18])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17738c0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA19_KcRA24_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[19],char const(&)[24]>(
        RBX::EquationDisplay **a1,
        const char (*args)[19],
        const char (*a3)[24])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1773b70 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA11_KcRA20_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[11],char const(&)[20]>(
        RBX::EquationDisplay **a1,
        const char (*args)[11],
        const char (*a3)[20])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1773e20 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA11_KcRA14_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[11],char const(&)[14]>(
        RBX::EquationDisplay **a1,
        const char (*args)[11],
        const char (*a3)[14])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17740d0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA5_KcRA14_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[5],char const(&)[14]>(
        RBX::EquationDisplay **a1,
        const char (*args)[5],
        const char (*a3)[14])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1774380 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA7_KcRA19_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[7],char const(&)[19]>(
        RBX::EquationDisplay **a1,
        const char (*args)[7],
        const char (*a3)[19])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1774630 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA17_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[17]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[17])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17748e0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA21_KcRA17_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[21],char const(&)[17]>(
        RBX::EquationDisplay **a1,
        const char (*args)[21],
        const char (*a3)[17])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1774b90 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA23_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[23]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[23])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1774e40 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA28_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[28]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[28])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17750f0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA13_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[13]>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[13])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17753a0 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA31_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[31]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[31])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1775650 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA14_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[14],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[14],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1775910 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA34_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[34]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[34])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1775bc0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA7_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[7],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[7],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1775e80 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA46_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[46]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[46])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1776130 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA10_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[10],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[10],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x17763f0 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA37_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[37]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[37])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17766a0 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA38_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[38]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[38])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1776950 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA11_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[11],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[11],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1776c10 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA14_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[14],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[14],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1776ed0 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA45_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[45]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[45])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1777180 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA8_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[8],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[8],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1777440 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA48_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[48]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[48])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17776f0 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA39_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[39]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[39])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17779a0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA12_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[12],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[12],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1777c60 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA43_KcRA20_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[43],char const(&)[20]>(
        RBX::EquationDisplay **a1,
        const char (*args)[43],
        const char (*a3)[20])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1777f10 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA51_KcRA19_S3_iEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[51],char const(&)[19],int>(
        RBX::EquationDisplay **a1,
        const char (*args)[51],
        const char (*a3)[19],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x17781d0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA34_KcRA10_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[34],char const(&)[10]>(
        RBX::EquationDisplay **a1,
        const char (*args)[34],
        const char (*a3)[10])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1778480 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA34_KcRA23_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[34],char const(&)[23]>(
        RBX::EquationDisplay **a1,
        const char (*args)[34],
        const char (*a3)[23])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1778730 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA34_KcRA33_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[34],char const(&)[33]>(
        RBX::EquationDisplay **a1,
        const char (*args)[34],
        const char (*a3)[33])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17789e0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA33_KcRA13_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[33],char const(&)[13]>(
        RBX::EquationDisplay **a1,
        const char (*args)[33],
        const char (*a3)[13])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1778c90 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA27_KcRA17_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[27],char const(&)[17]>(
        RBX::EquationDisplay **a1,
        const char (*args)[27],
        const char (*a3)[17])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1778f40 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA35_KcRA15_S3_iEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[35],char const(&)[15],int>(
        RBX::EquationDisplay **a1,
        const char (*args)[35],
        const char (*a3)[15],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1779200 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA36_KcRA16_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[36],char const(&)[16],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[36],
        const char (*a3)[16],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x17794c0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA63_KcRA18_S3_iEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[63],char const(&)[18],int>(
        RBX::EquationDisplay **a1,
        const char (*args)[63],
        const char (*a3)[18],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1779780 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA49_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[49]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[49])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1779a30 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA35_KcRA14_S3_iEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[35],char const(&)[14],int>(
        RBX::EquationDisplay **a1,
        const char (*args)[35],
        const char (*a3)[14],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1779cf0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA37_KcRA7_S3_iEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[37],char const(&)[7],int>(
        RBX::EquationDisplay **a1,
        const char (*args)[37],
        const char (*a3)[7],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1779fb0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA47_KcRA10_S3_iEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[47],char const(&)[10],int>(
        RBX::EquationDisplay **a1,
        const char (*args)[47],
        const char (*a3)[10],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177a270 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA20_KcRA7_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[20],char const(&)[7]>(
        RBX::EquationDisplay **a1,
        const char (*args)[20],
        const char (*a3)[7])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x177a520 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA8_KcRA11_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[8],char const(&)[11]>(
        RBX::EquationDisplay **a1,
        const char (*args)[8],
        const char (*a3)[11])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x177a7d0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA25_KcRA27_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[25],char const(&)[27],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[25],
        const char (*a3)[27],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177aa90 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA23_KcRA28_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[23],char const(&)[28],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[23],
        const char (*a3)[28],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177ad50 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA24_KcRA29_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[24],char const(&)[29],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[24],
        const char (*a3)[29],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177b010 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA18_KcRA28_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[18],char const(&)[28],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[18],
        const char (*a3)[28],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177b2d0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA28_KcRA38_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[28],char const(&)[38],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[28],
        const char (*a3)[38],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177b590 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA16_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[16],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[16],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177b850 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA19_KcRA20_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[19],char const(&)[20],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[19],
        const char (*a3)[20],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177bb10 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA28_KcRA37_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[28],char const(&)[37],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[28],
        const char (*a3)[37],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177bdd0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA30_KcRA34_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[30],char const(&)[34]>(
        RBX::EquationDisplay **a1,
        const char (*args)[30],
        const char (*a3)[34])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x177c080 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA30_KcRA37_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[30],char const(&)[37],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[30],
        const char (*a3)[37],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177c340 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA30_KcRA29_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[30],char const(&)[29]>(
        RBX::EquationDisplay **a1,
        const char (*args)[30],
        const char (*a3)[29])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x177c5f0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA25_KcRA22_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[25],char const(&)[22]>(
        RBX::EquationDisplay **a1,
        const char (*args)[25],
        const char (*a3)[22])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x177c8a0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA22_KcRA19_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[22],char const(&)[19]>(
        RBX::EquationDisplay **a1,
        const char (*args)[22],
        const char (*a3)[19])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x177cb50 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA23_KcRA16_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[23],char const(&)[16],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[23],
        const char (*a3)[16],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177ce10 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcS5_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[1]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[1])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x177d0c0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA14_KcRA19_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[14],char const(&)[19],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[14],
        const char (*a3)[19],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177d380 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA20_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[20],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[20],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177d640 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA16_KcRA21_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[16],char const(&)[21],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[16],
        const char (*a3)[21],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177d900 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA13_KcRA18_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[13],char const(&)[18],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[13],
        const char (*a3)[18],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177dbc0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA14_KcRA20_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[14],char const(&)[20],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[14],
        const char (*a3)[20],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177de80 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA21_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[21],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[21],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177e140 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA16_KcRA22_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[16],char const(&)[22],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[16],
        const char (*a3)[22],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177e400 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA13_KcRA19_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[13],char const(&)[19],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[13],
        const char (*a3)[19],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177e6c0 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA14_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[14]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[14])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x177e970 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA14_KcRA18_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[14],char const(&)[18],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[14],
        const char (*a3)[18],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177ec30 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA21_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[21],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[21],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177eef0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA6_KcRA11_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[6],char const(&)[11],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[6],
        const char (*a3)[11],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177f1b0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA10_KcRA15_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[10],char const(&)[15],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[10],
        const char (*a3)[15],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177f470 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA7_KcRA12_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[7],char const(&)[12],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[7],
        const char (*a3)[12],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177f730 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA12_KcRA17_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[12],char const(&)[17],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[12],
        const char (*a3)[17],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177f9f0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA9_KcRA14_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[9],char const(&)[14],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[9],
        const char (*a3)[14],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177fcb0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA8_KcRA13_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[8],char const(&)[13],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[8],
        const char (*a3)[13],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x177ff70 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA22_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[22],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[22],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1780230 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA6_KcRA12_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[6],char const(&)[12],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[6],
        const char (*a3)[12],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x17804f0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA10_KcRA16_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[10],char const(&)[16],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[10],
        const char (*a3)[16],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x17807b0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA7_KcRA13_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[7],char const(&)[13],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[7],
        const char (*a3)[13],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1780a70 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA12_KcRA18_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[12],char const(&)[18],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[12],
        const char (*a3)[18],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1780d30 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA9_KcRA15_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[9],char const(&)[15],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[9],
        const char (*a3)[15],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1780ff0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA8_KcRA14_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[8],char const(&)[14],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[8],
        const char (*a3)[14],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x17812b0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA13_KcRA11_S3_RiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[13],char const(&)[11],int &>(
        RBX::EquationDisplay **a1,
        const char (*args)[13],
        const char (*a3)[11],
        int *a4)
{
  char *v5; // r15
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r14
  RBX::EquationDisplay **v13; // rbp
  size_t v14; // rbp
  RBX::EquationDisplay *v15; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v17; // rbx
  void *v19; // rax
  __int128 v20; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int128 dest; // [rsp+20h] [rbp-78h] BYREF
  void *v23; // [rsp+30h] [rbp-68h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-58h] BYREF
  RBX::EquationDisplay **v25; // [rsp+58h] [rbp-40h]
  const int *v26; // [rsp+60h] [rbp-38h]

  v26 = a4;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v23 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v20);
    sub_D9C950(v19);
  }
  v7 = v6;
  v25 = a1;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v23 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v20 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v14 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v14);
    ptr = v12;
    *(_QWORD *)&v20 = v14 | 1;
    *((_QWORD *)&v20 + 1) = v11;
    v13 = v25;
    goto LABEL_12;
  }
  LOBYTE(v20) = 2 * v10;
  v12 = (char *)&v20 + 1;
  v13 = v25;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v15 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v20,
    *v26);
  if ( (v20 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v23);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v15);
  *v13 = v15;
  pi = ppx.pn.pi_;
  v13[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v17 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
      }
    }
  }
  return v13;
}


// Address: 0x1781570 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA14_KcRA12_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[14],char const(&)[12]>(
        RBX::EquationDisplay **a1,
        const char (*args)[14],
        const char (*a3)[12])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1781820 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA24_KcRA28_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[24],char const(&)[28]>(
        RBX::EquationDisplay **a1,
        const char (*args)[24],
        const char (*a3)[28])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1781ad0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA24_KcRA29_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[24],char const(&)[29]>(
        RBX::EquationDisplay **a1,
        const char (*args)[24],
        const char (*a3)[29])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1781d80 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA24_KcRA30_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[24],char const(&)[30]>(
        RBX::EquationDisplay **a1,
        const char (*args)[24],
        const char (*a3)[30])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1782030 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA23_KcRA29_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[23],char const(&)[29]>(
        RBX::EquationDisplay **a1,
        const char (*args)[23],
        const char (*a3)[29])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17822e0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA13_KcRA20_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[13],char const(&)[20]>(
        RBX::EquationDisplay **a1,
        const char (*args)[13],
        const char (*a3)[20])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1782590 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA28_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[28]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[28])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1782840 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA23_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[23]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[23])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1782af0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA15_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[15]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[15])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1782da0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA24_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[24]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[24])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1783050 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA11_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[11]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[11])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1783300 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA16_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[16]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[16])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17835b0 | Name: _ZN5boost11make_sharedIN3RBX11TextDisplayEJRA1_KcRA16_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextDisplay **__fastcall boost::make_shared<RBX::TextDisplay,char const(&)[1],char const(&)[16]>(
        RBX::TextDisplay **a1,
        const char (*args)[1],
        const char (*a3)[16])
{
  RBX::TextDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::TextDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::TextDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0xD8u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF218;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::TextDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::TextDisplay::TextDisplay((RBX::TextDisplay *)(v5 + 32), (const std::string *)&dest, (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::TextDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1783860 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA22_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[22]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[22])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1783b10 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA17_KcRA25_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[17],char const(&)[25]>(
        RBX::EquationDisplay **a1,
        const char (*args)[17],
        const char (*a3)[25])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1783dc0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA12_KcRA14_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[12],char const(&)[14]>(
        RBX::EquationDisplay **a1,
        const char (*args)[12],
        const char (*a3)[14])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1784070 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA15_KcRA14_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[15],char const(&)[14]>(
        RBX::EquationDisplay **a1,
        const char (*args)[15],
        const char (*a3)[14])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1784320 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA19_KcRA8_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[19],char const(&)[8]>(
        RBX::EquationDisplay **a1,
        const char (*args)[19],
        const char (*a3)[8])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17845d0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA19_KcRA7_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[19],char const(&)[7]>(
        RBX::EquationDisplay **a1,
        const char (*args)[19],
        const char (*a3)[7])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1784880 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA19_KcRA13_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[19],char const(&)[13]>(
        RBX::EquationDisplay **a1,
        const char (*args)[19],
        const char (*a3)[13])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1784b30 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA19_KcRA12_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[19],char const(&)[12]>(
        RBX::EquationDisplay **a1,
        const char (*args)[19],
        const char (*a3)[12])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1784de0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA27_KcRA13_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[27],char const(&)[13]>(
        RBX::EquationDisplay **a1,
        const char (*args)[27],
        const char (*a3)[13])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1785090 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA19_KcRA10_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[19],char const(&)[10]>(
        RBX::EquationDisplay **a1,
        const char (*args)[19],
        const char (*a3)[10])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1785340 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA27_KcRA10_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[27],char const(&)[10]>(
        RBX::EquationDisplay **a1,
        const char (*args)[27],
        const char (*a3)[10])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17855f0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA30_KcRA13_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[30],char const(&)[13]>(
        RBX::EquationDisplay **a1,
        const char (*args)[30],
        const char (*a3)[13])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17858a0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA31_KcRA13_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[31],char const(&)[13]>(
        RBX::EquationDisplay **a1,
        const char (*args)[31],
        const char (*a3)[13])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1785b50 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA30_KcRA22_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[30],char const(&)[22]>(
        RBX::EquationDisplay **a1,
        const char (*args)[30],
        const char (*a3)[22])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1785e00 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA34_KcRA25_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[34],char const(&)[25]>(
        RBX::EquationDisplay **a1,
        const char (*args)[34],
        const char (*a3)[25])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17860b0 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA33_KcRA25_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[33],char const(&)[25]>(
        RBX::EquationDisplay **a1,
        const char (*args)[33],
        const char (*a3)[25])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1786360 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA27_KcRA18_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[27],char const(&)[18]>(
        RBX::EquationDisplay **a1,
        const char (*args)[27],
        const char (*a3)[18])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x1786610 | Name: _ZN5boost11make_sharedIN3RBX15EquationDisplayEJRA30_KcRA21_S3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::EquationDisplay **__fastcall boost::make_shared<RBX::EquationDisplay,char const(&)[30],char const(&)[21]>(
        RBX::EquationDisplay **a1,
        const char (*args)[30],
        const char (*a3)[21])
{
  RBX::EquationDisplay **v4; // r14
  char *v5; // r13
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // rbp
  size_t v9; // r14
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // r12
  size_t v13; // rbp
  RBX::EquationDisplay *v14; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v16; // rbx
  void *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]
  __int128 dest; // [rsp+20h] [rbp-68h] BYREF
  void *v22; // [rsp+30h] [rbp-58h]
  boost::shared_ptr<RBX::EquationDisplay> ppx; // [rsp+40h] [rbp-48h] BYREF
  const char *v24; // [rsp+50h] [rbp-38h]

  v4 = a1;
  ppx.px = 0;
  v5 = (char *)operator new(0x118u);
  *((_QWORD *)v5 + 1) = 0x100000001LL;
  *(_QWORD *)v5 = &off_28DF278;
  *((_QWORD *)v5 + 2) = 0;
  v5[24] = 0;
  ppx.pn.pi_ = (boost::detail::sp_counted_base *)v5;
  dest = 0;
  v22 = 0;
  v6 = strlen((const char *)args);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
LABEL_24:
    std::__basic_string_common<true>::__throw_length_error(&v19);
    sub_D9C950(v18);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v24 = (const char *)a3;
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    v22 = v8;
    *(_QWORD *)&dest = v9 | 1;
    *((_QWORD *)&dest + 1) = v7;
    v4 = a1;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v6;
  v8 = (char *)&dest + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, args, v7);
  v8[v7] = 0;
  v19 = 0;
  ptr = 0;
  v10 = strlen((const char *)a3);
  if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    goto LABEL_24;
  v11 = v10;
  if ( v10 >= 0x17 )
  {
    v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v12 = (char *)operator new(v13);
    ptr = v12;
    *(_QWORD *)&v19 = v13 | 1;
    *((_QWORD *)&v19 + 1) = v11;
    goto LABEL_12;
  }
  LOBYTE(v19) = 2 * v10;
  v12 = (char *)&v19 + 1;
  if ( v10 )
LABEL_12:
    memcpy(v12, a3, v11);
  v14 = (RBX::EquationDisplay *)(v5 + 32);
  v12[v11] = 0;
  RBX::EquationDisplay::EquationDisplay(
    (RBX::EquationDisplay *)(v5 + 32),
    (const std::string *)&dest,
    (const std::string *)&v19);
  if ( (v19 & 1) != 0 )
    operator delete(ptr);
  if ( (dest & 1) != 0 )
    operator delete(v22);
  v5[24] = 1;
  boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
    (const boost::enable_shared_from_this<RBX::GuiItem> *)(v5 + 40),
    &ppx,
    v14);
  *v4 = v14;
  pi = ppx.pn.pi_;
  v4[1] = (RBX::EquationDisplay *)ppx.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v16 = ppx.pn.pi_;
    if ( ppx.pn.pi_ )
    {
      if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
        if ( !_InterlockedSub(&v16->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
      }
    }
  }
  return v4;
}


// Address: 0x17f3770 | Name: _ZN5boost11make_sharedIN3rbx6signalIFvRKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_10shared_ptrIN10MemStorage7ContextEEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<rbx::signal<void (const std::string &,boost::shared_ptr<MemStorage::Context>)> >::type __cdecl boost::make_shared<rbx::signal<void ()(std::string const&,boost::shared_ptr<MemStorage::Context>)>>()
{
  boost::shared_ptr<rbx::signal<void (const std::string &,boost::shared_ptr<MemStorage::Context>)> >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<rbx::signal<void (const std::string &,boost::shared_ptr<MemStorage::Context>)> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x28u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28E94B8;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 4) = 0;
  v2[24] = 1;
  v0->head.px = (rbx::signals::slot_base *)(v2 + 32);
  v0[1].head.px = (rbx::signals::slot_base *)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1824940 | Name: _ZN5boost11make_sharedIN3RBX18HttpRequestWrapperEJRNS_10shared_ptrINS1_11HttpRequestEEENS_8weak_ptrINS1_9DataModelEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::HttpRequestWrapper **__fastcall boost::make_shared<RBX::HttpRequestWrapper,boost::shared_ptr<RBX::HttpRequest> &,boost::weak_ptr<RBX::DataModel>>(
        RBX::HttpRequestWrapper **a1,
        boost::shared_ptr<RBX::HttpRequest> *args,
        boost::weak_ptr<RBX::DataModel> *a3)
{
  unsigned __int64 v5; // rcx
  char *v6; // rbx
  unsigned __int64 v7; // r8
  RBX::HttpRequestWrapper *v8; // r15
  boost::detail::sp_counted_base *pi; // rax
  __int64 v10; // rdi
  boost::detail::sp_counted_base *v11; // r12
  boost::detail::sp_counted_base *v12; // rax
  boost::detail::sp_counted_base *v13; // rbx
  boost::shared_ptr<RBX::HttpRequestWrapper> v15; // [rsp+0h] [rbp-58h] BYREF
  boost::shared_ptr<RBX::HttpRequest> v16; // [rsp+10h] [rbp-48h] BYREF
  __int128 httpRequest; // [rsp+20h] [rbp-38h] BYREF

  v15.px = 0;
  v6 = (char *)operator new(0xC0u);
  *((_QWORD *)v6 + 1) = 0x100000001LL;
  *(_QWORD *)v6 = &off_28F3708;
  *((_QWORD *)v6 + 2) = 0;
  v6[24] = 0;
  v15.pn.pi_ = (boost::detail::sp_counted_base *)v6;
  v8 = (RBX::HttpRequestWrapper *)(v6 + 32);
  v16.px = args->px;
  pi = args->pn.pi_;
  v16.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  httpRequest = (__int128)*a3;
  *a3 = 0;
  RBX::HttpRequestWrapper::HttpRequestWrapper(
    v8,
    (boost::shared_ptr<RBX::HttpRequest>)__PAIR128__(&httpRequest, &v16),
    (boost::weak_ptr<RBX::DataModel>)__PAIR128__(v7, v5));
  v10 = *((_QWORD *)&httpRequest + 1);
  if ( *((_QWORD *)&httpRequest + 1)
    && !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&httpRequest + 1) + 12LL), 1u) )
  {
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v10 + 24LL))(v10);
  }
  v11 = v16.pn.pi_;
  if ( v16.pn.pi_ )
  {
    if ( !_InterlockedSub(&v16.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 2))(v11);
      if ( !_InterlockedSub(&v11->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
    }
  }
  v6[24] = 1;
  boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::HttpRequestWrapper,RBX::HttpRequestWrapper>(
    (const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *)(v6 + 40),
    &v15,
    v8);
  *a1 = v8;
  v12 = v15.pn.pi_;
  a1[1] = (RBX::HttpRequestWrapper *)v15.pn.pi_;
  if ( v12 )
  {
    _InterlockedAdd(&v12->use_count_, 1u);
    v13 = v15.pn.pi_;
    if ( v15.pn.pi_ )
    {
      if ( !_InterlockedSub(&v15.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
        if ( !_InterlockedSub(&v13->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
      }
    }
  }
  return a1;
}


// Address: 0x1839b90 | Name: _ZN5boost11make_sharedIN3RBX17HttpRbxApiService33DefaultHttpRequestExecutionPolicyEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::HttpRbxApiService::DefaultHttpRequestExecutionPolicy>::type __cdecl boost::make_shared<RBX::HttpRbxApiService::DefaultHttpRequestExecutionPolicy>()
{
  boost::shared_ptr<RBX::HttpRbxApiService::DefaultHttpRequestExecutionPolicy>::element_type *v0; // rdi
  boost::detail::sp_if_not_array<RBX::HttpRbxApiService::DefaultHttpRequestExecutionPolicy>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x28u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28F3BD8;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 4) = &off_28F3920;
  v2[24] = 1;
  v0->_vptr$HttpRequestExecutionPolicy = (int (**)(void))(v2 + 32);
  v0[1]._vptr$HttpRequestExecutionPolicy = (int (**)(void))v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x19236f0 | Name: _ZN5boost11make_sharedIN3RBX14CSGOperations2EJRPNS1_9DataModelERA7_KcbEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::CSGOperations2,RBX::DataModel *&,char const(&)[7],bool>(
        _QWORD *a1,
        RBX::DataModel **args,
        const char (*a3)[7],
        bool *a4)
{
  char *v6; // rbx

  v6 = (char *)operator new(0x330u);
  *((_QWORD *)v6 + 1) = 0x100000001LL;
  *(_QWORD *)v6 = &off_290C108;
  *((_QWORD *)v6 + 2) = 0;
  v6[24] = 0;
  RBX::CSGOperations2::CSGOperations2((RBX::CSGOperations2 *)(v6 + 32), *args, (const char *)a3, *a4);
  v6[24] = 1;
  *a1 = v6 + 32;
  a1[1] = v6;
  _InterlockedAdd((volatile signed __int32 *)v6 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v6 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub((volatile signed __int32 *)v6 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v6 + 24LL))(v6);
  }
  return a1;
}


// Address: 0x19a3150 | Name: _ZN5boost11make_sharedIN3RBX21PlayerCharacterLoader28CharacterAppearanceAssetInfoEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::PlayerCharacterLoader::CharacterAppearanceAssetInfo>::type __cdecl boost::make_shared<RBX::PlayerCharacterLoader::CharacterAppearanceAssetInfo>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<RBX::PlayerCharacterLoader::CharacterAppearanceAssetInfo>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x50u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2928148;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 4) = 0;
  *((_OWORD *)v2 + 3) = 0;
  *((_OWORD *)v2 + 2) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x19a3210 | Name: _ZN5boost11make_sharedINSt3__16vectorIlNS1_9allocatorIlEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<std::vector<long> >::type __cdecl boost::make_shared<std::vector<long>>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<std::vector<long> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_29281A8;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 6) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x19a32d0 | Name: _ZN5boost11make_sharedIiJiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<int,int>(_QWORD *a1, int *args)
{
  char *v2; // rbx

  v2 = (char *)operator new(0x20u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = off_2928288;
  *((_QWORD *)v2 + 2) = 0;
  *((_DWORD *)v2 + 7) = *args;
  v2[24] = 1;
  *a1 = v2 + 28;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x19a5e40 | Name: _ZN5boost6detail18sp_counted_impl_pdIPiNS0_13sp_ms_deleterIiEEE7disposeEv
void __fastcall boost::detail::sp_counted_impl_pd<int *,boost::detail::sp_ms_deleter<int>>::dispose(
        boost::detail::sp_counted_impl_pd<int *,boost::detail::sp_ms_deleter<int> > *this)
{
  if ( this->del.initialized_ )
    this->del.initialized_ = 0;
}


// Address: 0x19fbb90 | Name: _ZN5boost11make_sharedIiJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<int>::type __cdecl boost::make_shared<int>()
{
  __int64 v0; // rdi
  boost::detail::sp_if_not_array<int>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x20u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = off_2928288;
  *((_QWORD *)v2 + 2) = 0;
  *((_DWORD *)v2 + 7) = 0;
  v2[24] = 1;
  *(_QWORD *)v0 = v2 + 28;
  *(_QWORD *)(v0 + 8) = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = (boost::shared_ptr<int>::element_type *)v0;
  return result;
}


// Address: 0x1a42760 | Name: _ZN5boost11make_sharedIN3RBX3Lua15WeakFunctionRefEJRKS3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Lua::WeakFunctionRef,RBX::Lua::WeakFunctionRef const&>(
        _QWORD *a1,
        const RBX::Lua::WeakFunctionRef *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x58u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_28A44F8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::Lua::WeakFunctionRef::WeakFunctionRef((RBX::Lua::WeakFunctionRef *)(v2 + 32), args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1a49440 | Name: _ZN5boost11make_sharedIN10MemStorage7ContextEJPN3RBX9DataModelEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<MemStorage::Context,RBX::DataModel *>(_QWORD *a1, RBX::DataModel **args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x30u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2931E58;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  MemStorage::Context::Context((MemStorage::Context *)v2 + 2, *args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1a49540 | Name: _ZN5boost11make_sharedIN3RBX20MemStorageConnectionEJRN3rbx7signals10connectionEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::MemStorageConnection,rbx::signals::connection &>(
        _QWORD *a1,
        rbx::signals::connection *args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::MemStorageConnection> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0xA8u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2931EB8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::MemStorageConnection::MemStorageConnection((RBX::MemStorageConnection *)(v2 + 32), args);
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MemStorageConnection,RBX::MemStorageConnection>(
    (const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *)(v2 + 40),
    &v6,
    (RBX::MemStorageConnection *)(v2 + 32));
  *a1 = v2 + 32;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x1b30260 | Name: _ZN5boost11make_sharedIN3RBX14PackageService16PackageAssetDataEJS3_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::PackageService::PackageAssetData,RBX::PackageService::PackageAssetData>(
        _QWORD *a1,
        RBX::PackageService::PackageAssetData *args)
{
  char *v2; // rbx

  v2 = (char *)operator new(0x48u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2955408;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 4) = *(_QWORD *)args;
  *((_QWORD *)v2 + 7) = *((_QWORD *)args + 3);
  *(_OWORD *)(v2 + 40) = *(_OWORD *)((char *)args + 8);
  *(_OWORD *)((char *)args + 8) = 0;
  *((_QWORD *)args + 3) = 0;
  *((_QWORD *)v2 + 8) = *((_QWORD *)args + 4);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1b6c750 | Name: _ZN5boost11make_sharedINS_9unordered13unordered_mapINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SC_EEEEEEJRSL_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>,boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>&>(
        _QWORD *a1,
        boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x50u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2890748;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>>>::table_impl(
    (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > *)(v2 + 32),
    &args->table_);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1b6dfc0 | Name: _ZN5boost11make_sharedIN3RBX5TimerILNS1_4Time12SampleMethodE0EEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Timer<RBX::Time::Fast> >::type __cdecl boost::make_shared<RBX::Timer<(RBX::Time::SampleMethod)0>>()
{
  __int64 v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::Timer<RBX::Time::Fast> >::type result; // rax

  v1 = (char *)operator new(0x28u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = off_2956E28;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  *((RBX::Time *)v1 + 4) = RBX::Time::now<(RBX::Time::SampleMethod)2>();
  v1[24] = 1;
  *(_QWORD *)v0 = v1 + 32;
  *(_QWORD *)(v0 + 8) = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = (boost::shared_ptr<RBX::Timer<RBX::Time::Fast> >::element_type *)v0;
  return result;
}


// Address: 0x1b6e0a0 | Name: _ZN5boost11make_sharedIN3RBX15TeleportService9PartyInfoEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::TeleportService::PartyInfo>::type __cdecl boost::make_shared<RBX::TeleportService::PartyInfo>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<RBX::TeleportService::PartyInfo>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x60u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2956F18;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 5) = 0;
  *((_OWORD *)v2 + 4) = 0;
  *((_OWORD *)v2 + 3) = 0;
  *((_OWORD *)v2 + 2) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1b79d20 | Name: _ZN5boost6detail18sp_counted_impl_pdIPN3RBX5TimerILNS2_4Time12SampleMethodE0EEENS0_13sp_ms_deleterIS6_EEE7disposeEv
void __fastcall boost::detail::sp_counted_impl_pd<RBX::Timer<(RBX::Time::SampleMethod)0> *,boost::detail::sp_ms_deleter<RBX::Timer<(RBX::Time::SampleMethod)0>>>::dispose(
        boost::detail::sp_counted_impl_pd<RBX::Timer<RBX::Time::Fast> *,boost::detail::sp_ms_deleter<RBX::Timer<RBX::Time::Fast> > > *this)
{
  if ( this->del.initialized_ )
    this->del.initialized_ = 0;
}


// Address: 0x1bbc700 | Name: _ZN5boost11make_sharedINS_9unordered13unordered_mapINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEN3RBX26UntranslatedSourceContextsENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SB_EEEEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<boost::unordered::unordered_map<std::string,RBX::UntranslatedSourceContexts,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::UntranslatedSourceContexts> > > >::type __cdecl boost::make_shared<boost::unordered::unordered_map<std::string,RBX::UntranslatedSourceContexts,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::UntranslatedSourceContexts>>>>()
{
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::UntranslatedSourceContexts,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::UntranslatedSourceContexts> > > >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<boost::unordered::unordered_map<std::string,RBX::UntranslatedSourceContexts,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::UntranslatedSourceContexts> > > >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x50u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_295DFC8;
  *((_QWORD *)v2 + 2) = 0;
  v2[32] = 0;
  *(_OWORD *)(v2 + 40) = 0x10u;
  *((_DWORD *)v2 + 14) = 1065353216;
  *((_OWORD *)v2 + 4) = 0;
  v2[24] = 1;
  *(_QWORD *)&v0->table_.current_ = v2 + 32;
  v0->table_.bucket_count_ = (size_t)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1bbc7d0 | Name: _ZN5boost11make_sharedIN3RBX15UsernameHandlerEJRNS_9unordered13unordered_setINSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_4hashISB_EENS5_8equal_toISB_EENS9_ISB_EEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::UsernameHandler,boost::unordered::unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::string>> &>(
        _QWORD *a1,
        boost::unordered::unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::string > > *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x40u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_295E028;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::UsernameHandler::UsernameHandler((RBX::UsernameHandler *)v2 + 1, args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1bbcbd0 | Name: _ZN5boost11make_sharedIN3RBX11TextScraper16ClientScraperJobEJPS2_RPNS1_19LocalizationServiceEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::TextScraper::ClientScraperJob,RBX::TextScraper*,RBX::LocalizationService *&>(
        _QWORD *a1,
        RBX::TextScraper **args,
        RBX::LocalizationService **a3)
{
  char *v4; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v6; // rbx
  boost::shared_ptr<RBX::TextScraper::ClientScraperJob> v8; // [rsp+0h] [rbp-38h] BYREF

  v8.px = 0;
  v4 = (char *)operator new(0x210u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_295E088;
  *((_QWORD *)v4 + 2) = 0;
  v4[24] = 0;
  v8.pn.pi_ = (boost::detail::sp_counted_base *)v4;
  RBX::TextScraper::ServiceScraperJob::ServiceScraperJob((RBX::TextScraper::ServiceScraperJob *)(v4 + 32), *args, *a3);
  *((_QWORD *)v4 + 4) = off_295DE28;
  v4[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TextScraper::ClientScraperJob,RBX::TextScraper::ClientScraperJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v4 + 40),
    &v8,
    (RBX::TextScraper::ClientScraperJob *)(v4 + 32));
  *a1 = v4 + 32;
  pi = v8.pn.pi_;
  a1[1] = v8.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v6 = v8.pn.pi_;
    if ( v8.pn.pi_ )
    {
      if ( !_InterlockedSub(&v8.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 2))(v6);
        if ( !_InterlockedSub(&v6->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      }
    }
  }
  return a1;
}


// Address: 0x1bbcd10 | Name: _ZN5boost11make_sharedIN3RBX11TextScraper16ServerScraperJobEJPS2_RPNS1_19LocalizationServiceEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::TextScraper::ServerScraperJob,RBX::TextScraper*,RBX::LocalizationService *&>(
        _QWORD *a1,
        RBX::TextScraper **args,
        RBX::LocalizationService **a3)
{
  char *v4; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v6; // rbx
  boost::shared_ptr<RBX::TextScraper::ServerScraperJob> v8; // [rsp+0h] [rbp-38h] BYREF

  v8.px = 0;
  v4 = (char *)operator new(0x210u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_295E0E8;
  *((_QWORD *)v4 + 2) = 0;
  v4[24] = 0;
  v8.pn.pi_ = (boost::detail::sp_counted_base *)v4;
  RBX::TextScraper::ServiceScraperJob::ServiceScraperJob((RBX::TextScraper::ServiceScraperJob *)(v4 + 32), *args, *a3);
  *((_QWORD *)v4 + 4) = off_295DE88;
  v4[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TextScraper::ServerScraperJob,RBX::TextScraper::ServerScraperJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v4 + 40),
    &v8,
    (RBX::TextScraper::ServerScraperJob *)(v4 + 32));
  *a1 = v4 + 32;
  pi = v8.pn.pi_;
  a1[1] = v8.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v6 = v8.pn.pi_;
    if ( v8.pn.pi_ )
    {
      if ( !_InterlockedSub(&v8.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 2))(v6);
        if ( !_InterlockedSub(&v6->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      }
    }
  }
  return a1;
}


// Address: 0x1bbce50 | Name: _ZN5boost11make_sharedIN3RBX11TextScraper10ScraperJobEJPS2_RPNS1_19LocalizationServiceEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::TextScraper::ScraperJob,RBX::TextScraper*,RBX::LocalizationService *&>(
        _QWORD *a1,
        RBX::TextScraper **args,
        RBX::LocalizationService **a3)
{
  char *v3; // rbx
  RBX::Instance *v4; // rdx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v6; // rbx
  boost::shared_ptr<RBX::TextScraper::ScraperJob> v8; // [rsp+0h] [rbp-38h] BYREF

  v8.px = 0;
  v3 = (char *)operator new(0x1D8u);
  *((_QWORD *)v3 + 1) = 0x100000001LL;
  *(_QWORD *)v3 = &off_295E148;
  *((_QWORD *)v3 + 2) = 0;
  v3[24] = 0;
  v8.pn.pi_ = (boost::detail::sp_counted_base *)v3;
  RBX::TextScraper::ScraperJob::ScraperJob((RBX::TextScraper::ScraperJob *)(v3 + 32), *args, v4);
  v3[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TextScraper::ScraperJob,RBX::TextScraper::ScraperJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v3 + 40),
    &v8,
    (RBX::TextScraper::ScraperJob *)(v3 + 32));
  *a1 = v3 + 32;
  pi = v8.pn.pi_;
  a1[1] = v8.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v6 = v8.pn.pi_;
    if ( v8.pn.pi_ )
    {
      if ( !_InterlockedSub(&v8.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 2))(v6);
        if ( !_InterlockedSub(&v6->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      }
    }
  }
  return a1;
}


// Address: 0x1bbcf70 | Name: _ZN5boost11make_sharedIN3RBX20GenericNumberHandlerEJRKNS1_12Localization10FormatInfoEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::GenericNumberHandler,RBX::Localization::FormatInfo const&>(
        _QWORD *a1,
        const RBX::Localization::FormatInfo *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x88u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_295E1A8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::GenericNumberHandler::GenericNumberHandler((RBX::GenericNumberHandler *)(v2 + 32), args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1bbd070 | Name: _ZN5boost11make_sharedIN3RBX15DatetimeHandlerEJRKNS1_12Localization10FormatInfoEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::DatetimeHandler,RBX::Localization::FormatInfo const&>(
        _QWORD *a1,
        const RBX::Localization::FormatInfo *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x88u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_295E208;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::DatetimeHandler::DatetimeHandler((RBX::DatetimeHandler *)(v2 + 32), args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1bbd170 | Name: _ZN5boost11make_sharedIN3RBX11DateHandlerEJRKNS1_12Localization10FormatInfoEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::DateHandler,RBX::Localization::FormatInfo const&>(
        _QWORD *a1,
        const RBX::Localization::FormatInfo *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x88u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_295E268;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::DateHandler::DateHandler((RBX::DateHandler *)(v2 + 32), args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1bbd270 | Name: _ZN5boost11make_sharedIN3RBX11TimeHandlerEJRKNS1_12Localization10FormatInfoEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::TimeHandler,RBX::Localization::FormatInfo const&>(
        _QWORD *a1,
        const RBX::Localization::FormatInfo *args)
{
  char *v2; // r12

  v2 = (char *)operator new(0x88u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_295E2C8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::TimeHandler::TimeHandler((RBX::TimeHandler *)(v2 + 32), args);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1bbd370 | Name: _ZN5boost11make_sharedIN3RBX11TextScraper20RawUntranslatedEntryEJRKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEESC_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::TextScraper::RawUntranslatedEntry,std::string const&,std::string const&>(
        _QWORD *a1,
        const std::string *args,
        const std::string *a3)
{
  char *v4; // rbx

  v4 = (char *)operator new(0x50u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_295E328;
  *((_QWORD *)v4 + 2) = 0;
  v4[24] = 0;
  std::string::basic_string(v4 + 32, args);
  std::string::basic_string(v4 + 56, a3);
  v4[24] = 1;
  *a1 = v4 + 32;
  a1[1] = v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return a1;
}


// Address: 0x1bc7900 | Name: _ZN5boost11make_sharedINSt3__111basic_regexIcNS1_12regex_traitsIcEEEEJRNS1_12basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::basic_regex<char,std::regex_traits<char>>,std::string &>(
        _QWORD *a1,
        std::string *args)
{
  char *v2; // rbx
  unsigned __int64 v3; // rdx
  unsigned __int64 v4; // rdx
  char *v5; // r12

  v2 = (char *)operator new(0x60u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_295E6D0;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::locale::locale((std::locale *)v2 + 4);
  *((_QWORD *)v2 + 5) = std::locale::use_facet((std::locale *)v2 + 4, &std::ctype<char>::id);
  *((_QWORD *)v2 + 6) = std::locale::use_facet((std::locale *)v2 + 4, &std::collate<char>::id);
  *(_OWORD *)(v2 + 72) = 0;
  *(_OWORD *)(v2 + 56) = 0;
  *((_QWORD *)v2 + 11) = 0;
  v3 = *(unsigned __int8 *)args;
  if ( (v3 & 1) != 0 )
  {
    v4 = *((_QWORD *)args + 1);
    v5 = (char *)*((_QWORD *)args + 2);
  }
  else
  {
    v5 = (char *)args + 1;
    v4 = v3 >> 1;
  }
  std::basic_regex<char,std::regex_traits<char>>::__parse<std::__wrap_iter<char const*>>(
    (std::basic_regex<char,std::regex_traits<char> > *)(v2 + 32),
    (std::__wrap_iter<const char *>)v5,
    (std::__wrap_iter<const char *>)&v5[v4]);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1bc7a90 | Name: _ZN5boost11make_sharedINSt3__111basic_regexIcNS1_12regex_traitsIcEEEEJRKNS1_12basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::basic_regex<char,std::regex_traits<char>>,std::string const&>(
        _QWORD *a1,
        const std::string *args)
{
  char *v2; // rbx
  unsigned __int64 v3; // rdx
  unsigned __int64 v4; // rdx
  char *v5; // r12

  v2 = (char *)operator new(0x60u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_295E6D0;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  std::locale::locale((std::locale *)v2 + 4);
  *((_QWORD *)v2 + 5) = std::locale::use_facet((std::locale *)v2 + 4, &std::ctype<char>::id);
  *((_QWORD *)v2 + 6) = std::locale::use_facet((std::locale *)v2 + 4, &std::collate<char>::id);
  *(_OWORD *)(v2 + 72) = 0;
  *(_OWORD *)(v2 + 56) = 0;
  *((_QWORD *)v2 + 11) = 0;
  v3 = *(unsigned __int8 *)args;
  if ( (v3 & 1) != 0 )
  {
    v4 = *((_QWORD *)args + 1);
    v5 = (char *)*((_QWORD *)args + 2);
  }
  else
  {
    v5 = (char *)args + 1;
    v4 = v3 >> 1;
  }
  std::basic_regex<char,std::regex_traits<char>>::__parse<std::__wrap_iter<char const*>>(
    (std::basic_regex<char,std::regex_traits<char> > *)(v2 + 32),
    (std::__wrap_iter<const char *>)v5,
    (std::__wrap_iter<const char *>)&v5[v4]);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1bd47b0 | Name: _ZN5boost11make_sharedIN3RBX10TypesetterEJRNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEfmRfRNS3_6vectorINS_10shared_ptrIS2_EENS7_ISE_EEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Typesetter,std::string &,float,unsigned long,float &,std::vector<boost::shared_ptr<RBX::Typesetter>> &>(
        _QWORD *a1,
        std::string *args,
        float *a3,
        unsigned __int64 *a4,
        float *a5,
        std::vector<boost::shared_ptr<RBX::Typesetter>> *a6)
{
  boost::detail::sp_counted_base *v9; // rbx
  _QWORD *v10; // rbp
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v12; // rbx
  boost::shared_ptr<RBX::Typesetter> v14; // [rsp+0h] [rbp-58h] BYREF
  _QWORD *v15; // [rsp+18h] [rbp-40h]
  std::vector<boost::shared_ptr<RBX::Typesetter>> *typesetterList; // [rsp+20h] [rbp-38h]

  typesetterList = a6;
  v15 = a1;
  v14.px = 0;
  v9 = (boost::detail::sp_counted_base *)operator new(0x78u);
  *(_QWORD *)&v9->use_count_ = 0x100000001LL;
  v9->_vptr$sp_counted_base = (int (**)(void))&off_295EFC8;
  v9[1]._vptr$sp_counted_base = 0;
  LOBYTE(v9[1].use_count_) = 0;
  v14.pn.pi_ = v9;
  RBX::Typesetter::Typesetter((RBX::Typesetter *)&v9[2], args, *a3, *(_DWORD *)a4, *a5, typesetterList);
  LOBYTE(v9[1].use_count_) = 1;
  boost::enable_shared_from_this<RBX::Typesetter>::_internal_accept_owner<RBX::Typesetter,RBX::Typesetter>(
    (const boost::enable_shared_from_this<RBX::Typesetter> *)&v9[2],
    &v14,
    (RBX::Typesetter *)&v9[2]);
  v10 = v15;
  *v15 = v9 + 2;
  pi = v14.pn.pi_;
  v10[1] = v14.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v12 = v14.pn.pi_;
    if ( v14.pn.pi_ )
    {
      if ( !_InterlockedSub(&v14.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
        if ( !_InterlockedSub(&v12->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
      }
    }
  }
  return v10;
}


// Address: 0x1bd4900 | Name: _ZN5boost11make_sharedIN3RBX24TextFilterResultInstanceEJRNS_8weak_ptrINS1_11ChatServiceEEERlRNS1_16TextFilterResultEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::TextFilterResultInstance **__fastcall boost::make_shared<RBX::TextFilterResultInstance,boost::weak_ptr<RBX::ChatService> &,long &,RBX::TextFilterResult &>(
        RBX::TextFilterResultInstance **a1,
        boost::weak_ptr<RBX::ChatService> *args,
        __int64 *a3,
        RBX::TextFilterResult *a4)
{
  char *v7; // rbx
  const RBX::TextFilterResult *v8; // r8
  RBX::TextFilterResultInstance *v9; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v11; // rdi
  boost::detail::sp_counted_base *v12; // rax
  boost::detail::sp_counted_base *v13; // rbx
  boost::shared_ptr<RBX::TextFilterResultInstance> v15; // [rsp+0h] [rbp-58h] BYREF
  boost::weak_ptr<RBX::ChatService> weakChatService; // [rsp+18h] [rbp-40h] BYREF

  v15.px = 0;
  v7 = (char *)operator new(0x110u);
  *((_QWORD *)v7 + 1) = 0x100000001LL;
  *(_QWORD *)v7 = &off_295F028;
  *((_QWORD *)v7 + 2) = 0;
  v7[24] = 0;
  v15.pn.pi_ = (boost::detail::sp_counted_base *)v7;
  v9 = (RBX::TextFilterResultInstance *)(v7 + 32);
  weakChatService.px = args->px;
  pi = args->pn.pi_;
  weakChatService.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  RBX::TextFilterResultInstance::TextFilterResultInstance(
    v9,
    (boost::weak_ptr<RBX::ChatService>)__PAIR128__(*a3, &weakChatService),
    (int64_t)a4,
    v8);
  v11 = weakChatService.pn.pi_;
  if ( weakChatService.pn.pi_ && !_InterlockedSub(&weakChatService.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
  v7[24] = 1;
  boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TextFilterResultInstance,RBX::TextFilterResultInstance>(
    (const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *)(v7 + 40),
    &v15,
    v9);
  *a1 = v9;
  v12 = v15.pn.pi_;
  a1[1] = (RBX::TextFilterResultInstance *)v15.pn.pi_;
  if ( v12 )
  {
    _InterlockedAdd(&v12->use_count_, 1u);
    v13 = v15.pn.pi_;
    if ( v15.pn.pi_ )
    {
      if ( !_InterlockedSub(&v15.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
        if ( !_InterlockedSub(&v13->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
      }
    }
  }
  return a1;
}


// Address: 0x1bd74d0 | Name: _ZN5boost11make_sharedIN3RBX24TextFilterResultInstanceEJRKNS_8weak_ptrINS1_11ChatServiceEEERKlRKNS1_16TextFilterResultEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::Instance **__fastcall boost::make_shared<RBX::TextFilterResultInstance,boost::weak_ptr<RBX::ChatService> const&,long const&,RBX::TextFilterResult const&>(
        RBX::Instance **a1,
        const boost::weak_ptr<RBX::ChatService> *args,
        const __int64 *a3,
        const RBX::TextFilterResult *a4)
{
  char *v7; // rbx
  const RBX::TextFilterResult *v8; // r8
  RBX::Instance *v9; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v11; // rdi
  boost::detail::sp_counted_base *v12; // rax
  boost::detail::sp_counted_base *v13; // rbx
  boost::shared_ptr<RBX::TextFilterResultInstance> v15; // [rsp+0h] [rbp-58h] BYREF
  boost::weak_ptr<RBX::ChatService> weakChatService; // [rsp+18h] [rbp-40h] BYREF

  v15.px = 0;
  v7 = (char *)operator new(0x110u);
  *((_QWORD *)v7 + 1) = 0x100000001LL;
  *(_QWORD *)v7 = &off_295F028;
  *((_QWORD *)v7 + 2) = 0;
  v7[24] = 0;
  v15.pn.pi_ = (boost::detail::sp_counted_base *)v7;
  v9 = (RBX::Instance *)(v7 + 32);
  weakChatService.px = args->px;
  pi = args->pn.pi_;
  weakChatService.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  RBX::TextFilterResultInstance::TextFilterResultInstance(
    v9,
    (boost::weak_ptr<RBX::ChatService>)__PAIR128__(*a3, &weakChatService),
    (int64_t)a4,
    v8);
  v11 = weakChatService.pn.pi_;
  if ( weakChatService.pn.pi_ && !_InterlockedSub(&weakChatService.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
  v7[24] = 1;
  boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TextFilterResultInstance,RBX::TextFilterResultInstance>(
    (const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *)(v7 + 40),
    &v15,
    (RBX::TextFilterResultInstance *)v9);
  *a1 = v9;
  v12 = v15.pn.pi_;
  a1[1] = (RBX::Instance *)v15.pn.pi_;
  if ( v12 )
  {
    _InterlockedAdd(&v12->use_count_, 1u);
    v13 = v15.pn.pi_;
    if ( v15.pn.pi_ )
    {
      if ( !_InterlockedSub(&v15.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
        if ( !_InterlockedSub(&v13->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
      }
    }
  }
  return a1;
}


// Address: 0x1c30990 | Name: _ZN5boost11make_sharedINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEJNS1_19istreambuf_iteratorIcS4_EERS9_EEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<std::string,std::istreambuf_iterator<char>,std::istreambuf_iterator<char>&>(
        _QWORD *a1,
        std::istreambuf_iterator<char> *args,
        std::istreambuf_iterator<char> *a3)
{
  char *v4; // rbx
  std::istreambuf_iterator<char>::streambuf_type *sbuf; // rsi
  std::istreambuf_iterator<char>::streambuf_type *v6; // rdx

  v4 = (char *)operator new(0x38u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876688;
  *((_QWORD *)v4 + 2) = 0;
  v4[24] = 0;
  sbuf = args->__sbuf_;
  v6 = a3->__sbuf_;
  *((_OWORD *)v4 + 2) = 0;
  *((_QWORD *)v4 + 6) = 0;
  std::string::__init<std::istreambuf_iterator<char>>(
    (std::string *)(v4 + 32),
    (std::istreambuf_iterator<char>)sbuf,
    (std::istreambuf_iterator<char>)v6);
  v4[24] = 1;
  *a1 = v4 + 32;
  a1[1] = v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return a1;
}


// Address: 0x1c30b10 | Name: _ZN5boost11make_sharedIN3RBX11VideoStreamEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::VideoStream>::type __cdecl boost::make_shared<RBX::VideoStream>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::VideoStream>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::VideoStream> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0x270u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_296EF38;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::VideoStream::VideoStream((RBX::VideoStream *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::VideoStream>::_internal_accept_owner<RBX::VideoStream,RBX::VideoStream>(
    (const boost::enable_shared_from_this<RBX::VideoStream> *)v1 + 3,
    &v4,
    (RBX::VideoStream *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1c30c70 | Name: _ZN5boost11make_sharedIN3RBX10VideoFrame7LoadJobEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::VideoFrame::LoadJob>::type __cdecl boost::make_shared<RBX::VideoFrame::LoadJob>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<RBX::VideoFrame::LoadJob>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x48u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_296F278;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 3) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 8) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1c992e0 | Name: _ZN5boost11make_sharedIN3RBX31AsyncPlayerCallbackQueueHandlerINS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEENS1_10Reflection7VariantENS_4hashISC_EENS6_8equal_toISC_EENSA_INS6_4pairIKSC_SE_EEEEEEEEEEJRiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::AsyncPlayerCallbackQueueHandler<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,int &>(
        _QWORD *a1,
        int *args)
{
  char *v2; // rbx
  __int64 v3; // rcx

  v2 = (char *)operator new(0x58u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2980558;
  *((_QWORD *)v2 + 2) = 0;
  v3 = *args;
  *((_QWORD *)v2 + 4) = &off_29805B8;
  *(_OWORD *)(v2 + 56) = 0;
  *(_OWORD *)(v2 + 40) = 0;
  *((_DWORD *)v2 + 18) = 1065353216;
  *((_QWORD *)v2 + 10) = v3;
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1cb65f0 | Name: _ZN5boost11make_sharedIN3RBX27MessagingServiceAnalysisJobEJPNS1_16MessagingServiceEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::MessagingServiceAnalysisJob,RBX::MessagingService *>(
        _QWORD *a1,
        RBX::MessagingService **args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::MessagingServiceAnalysisJob> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0x208u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2986C38;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::MessagingServiceAnalysisJob::MessagingServiceAnalysisJob((RBX::MessagingServiceAnalysisJob *)(v2 + 32), *args);
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::MessagingServiceAnalysisJob,RBX::MessagingServiceAnalysisJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v2 + 40),
    &v6,
    (RBX::MessagingServiceAnalysisJob *)(v2 + 32));
  *a1 = v2 + 32;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x1cb6710 | Name: _ZN5boost11make_sharedIN3RBX17SignalRConnectionEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::SignalRConnection>::type __cdecl boost::make_shared<RBX::SignalRConnection>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_counted_base *v1; // r15
  boost::detail::sp_if_not_array<RBX::SignalRConnection>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::SignalRConnection> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (boost::detail::sp_counted_base *)operator new(0x120u);
  *(_QWORD *)&v1->use_count_ = 0x100000001LL;
  v1->_vptr$sp_counted_base = (int (**)(void))&off_2986CF8;
  v1[1]._vptr$sp_counted_base = 0;
  LOBYTE(v1[1].use_count_) = 0;
  v4.pn.pi_ = v1;
  RBX::SignalRConnection::SignalRConnection((RBX::SignalRConnection *)&v1[2]);
  LOBYTE(v1[1].use_count_) = 1;
  boost::enable_shared_from_this<RBX::SignalRConnection>::_internal_accept_owner<RBX::SignalRConnection,RBX::SignalRConnection>(
    (const boost::enable_shared_from_this<RBX::SignalRConnection>_0 *)&v1[2],
    &v4,
    (RBX::SignalRConnection *)&v1[2]);
  *v0 = v1 + 2;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1cb6830 | Name: _ZN5boost11make_sharedIN3RBX16MessagingService9EventSlotEJRNS1_3Lua15WeakFunctionRefEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::MessagingService::EventSlot,RBX::Lua::WeakFunctionRef &>(
        _QWORD *a1,
        RBX::Lua::WeakFunctionRef *args)
{
  char *v2; // r12
  RBX::Lua::WeakFunctionRef v4; // [rsp+0h] [rbp-58h] BYREF

  v2 = (char *)operator new(0x80u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2986D68;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  RBX::Lua::WeakFunctionRef::WeakFunctionRef(&v4, args);
  RBX::Lua::WeakFunctionRef::WeakFunctionRef((RBX::Lua::WeakFunctionRef *)(v2 + 32), &v4);
  *(_OWORD *)(v2 + 88) = 0;
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef(&v4);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1cb6a30 | Name: _ZN5boost11make_sharedIN3RBX16MessagingService12LuaCallbacksEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::MessagingService::LuaCallbacks>::type __cdecl boost::make_shared<RBX::MessagingService::LuaCallbacks>()
{
  __int64 v0; // rdi
  boost::detail::sp_if_not_array<RBX::MessagingService::LuaCallbacks>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x98u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2986DC8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  *((_OWORD *)v2 + 8) = 0;
  *((_OWORD *)v2 + 7) = 0;
  *((_OWORD *)v2 + 6) = 0;
  *((_OWORD *)v2 + 5) = 0;
  *((_OWORD *)v2 + 4) = 0;
  *((_OWORD *)v2 + 3) = 0;
  *((_OWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 18) = 0;
  _InterlockedAdd(&dword_29D5500, 1u);
  *((_OWORD *)v2 + 4) = 0;
  *((_OWORD *)v2 + 3) = 0;
  *((_QWORD *)v2 + 4) = &off_28A1B38;
  *((_DWORD *)v2 + 20) = 0;
  *((_QWORD *)v2 + 11) = 0;
  *((_QWORD *)v2 + 15) = 0;
  v2[24] = 1;
  *(_QWORD *)v0 = v2 + 32;
  *(_QWORD *)(v0 + 8) = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = (boost::shared_ptr<RBX::MessagingService::LuaCallbacks>::element_type *)v0;
  return result;
}


// Address: 0x1cc1150 | Name: _ZN5boost11make_sharedIN3RBX17NavigationServiceEJRPNS1_9DataModelEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::NavigationService,RBX::DataModel *&>(_QWORD *a1, RBX::DataModel **args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::NavigationService> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0x1C0u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2987EF8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::NavigationService::NavigationService((RBX::NavigationService *)(v2 + 32), *args);
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::NavigationService>::_internal_accept_owner<RBX::NavigationService,RBX::NavigationService>(
    (const boost::enable_shared_from_this<RBX::NavigationService> *)v2 + 3,
    &v6,
    (RBX::NavigationService *)(v2 + 32));
  *a1 = v2 + 32;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x1ce49a0 | Name: _ZN5boost11make_sharedIN3G3D6GImageEJPKhmEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<G3D::GImage,unsigned char const*,unsigned long>(
        _QWORD *a1,
        const unsigned __int8 **args,
        unsigned __int64 *a3)
{
  char *v4; // rbx

  v4 = (char *)operator new(0x40u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_298FA38;
  *((_QWORD *)v4 + 2) = 0;
  v4[24] = 0;
  G3D::GImage::GImage((G3D::GImage *)v4 + 1, *args, *(_DWORD *)a3, G3D::GImage::Format::AUTODETECT);
  v4[24] = 1;
  *a1 = v4 + 32;
  a1[1] = v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return a1;
}


// Address: 0x1d46f90 | Name: _ZN5boost11make_sharedIN3RBX3Lua18EventSignalWrapperIFvvEN3rbx6signalIS4_EEEEJRNS_10shared_ptrIS7_EEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Lua::EventSignalWrapper<void ()(void),rbx::signal<void ()(void)>>,boost::shared_ptr<rbx::signal<void ()(void)>> &>(
        _QWORD *a1,
        boost::shared_ptr<rbx::signal<void ()> > *args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rcx

  v2 = (char *)operator new(0x38u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2999C60;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  *((_QWORD *)v2 + 4) = off_2999CB8;
  *((_QWORD *)v2 + 5) = args->px;
  pi = args->pn.pi_;
  *((_QWORD *)v2 + 6) = pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  v2[24] = 1;
  *a1 = v2 + 32;
  a1[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  return a1;
}


// Address: 0x1d47060 | Name: _ZN5boost11make_sharedIN3rbx6signalIFvvEEEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<rbx::signal<void ()> >::type __cdecl boost::make_shared<rbx::signal<void ()(void)>>()
{
  boost::shared_ptr<rbx::signal<void ()> >::element_type *v0; // rdi
  boost::detail::sp_if_not_array<rbx::signal<void ()> >::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x28u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_2999CF8;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 4) = 0;
  v2[24] = 1;
  v0->head.px = (rbx::signals::slot_base *)(v2 + 32);
  v0[1].head.px = (rbx::signals::slot_base *)v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1eb5dc0 | Name: _ZN5boost11make_sharedIN3RBX12PathWaypointEJRKN3G3D7Vector3ERNS2_6ActionEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::PathWaypoint,G3D::Vector3 const&,RBX::PathWaypoint::Action &>(
        _QWORD *a1,
        const G3D::Vector3 *args,
        RBX::PathWaypoint::Action *a3)
{
  char *v4; // rbx
  int v5; // eax

  v4 = (char *)operator new(0x40u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = off_29A2D18;
  *((_QWORD *)v4 + 2) = 0;
  v4[24] = 0;
  v5 = *a3;
  *(G3D::Vector3 *)(v4 + 32) = *args;
  *((_DWORD *)v4 + 11) = v5;
  dtTilePolyRef::dtTilePolyRef((dtTilePolyRef *)v4 + 3);
  v4[24] = 1;
  *a1 = v4 + 32;
  a1[1] = v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return a1;
}


// Address: 0x1eb6370 | Name: _ZN5boost11make_sharedIN3RBX8PathDataEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::PathData>::type __cdecl boost::make_shared<RBX::PathData>()
{
  _QWORD *v0; // rdi
  char *v1; // r12
  boost::detail::sp_if_not_array<RBX::PathData>::type result; // rax

  v1 = (char *)operator new(0x180u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A2D98;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  memset(v1 + 32, 0, 0x160u);
  *((_QWORD *)v1 + 10) = 0x7F7FFFFF7F7FFFFFLL;
  *((_DWORD *)v1 + 22) = 2139095039;
  *(_QWORD *)(v1 + 92) = 0xFF7FFFFFFF7FFFFFLL;
  *((_DWORD *)v1 + 25) = -8388609;
  dtQueryFilter::dtQueryFilter((dtQueryFilter *)(v1 + 104));
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x1eb6530 | Name: _ZN5boost11make_sharedI14dtNavMeshQueryJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<dtNavMeshQuery>::type __cdecl boost::make_shared<dtNavMeshQuery>()
{
  _QWORD *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<dtNavMeshQuery>::type result; // rax

  v1 = (char *)operator new(0x170u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A2DF8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  dtNavMeshQuery::dtNavMeshQuery((dtNavMeshQuery *)(v1 + 32));
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x1eb7210 | Name: _ZN5boost6detail18sp_counted_impl_pdIPN3RBX12PathWaypointENS0_13sp_ms_deleterIS3_EEE7disposeEv
void __fastcall boost::detail::sp_counted_impl_pd<RBX::PathWaypoint *,boost::detail::sp_ms_deleter<RBX::PathWaypoint>>::dispose(
        boost::detail::sp_counted_impl_pd<RBX::PathWaypoint *,boost::detail::sp_ms_deleter<RBX::PathWaypoint> > *this)
{
  if ( this->del.initialized_ )
    this->del.initialized_ = 0;
}


// Address: 0x1ebe730 | Name: _ZN5boost11make_sharedIN3RBX14NavigationPathEJNS_10shared_ptrINS1_17NavigationServiceEEEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::NavigationPath,boost::shared_ptr<RBX::NavigationService>>(
        _QWORD *a1,
        boost::shared_ptr<RBX::NavigationService> *args)
{
  char *v2; // r12
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::NavigationPath> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0x88u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_29A3178;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::NavigationPath::NavigationPath((RBX::NavigationPath *)(v2 + 32), args);
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::NavigationPath>::_internal_accept_owner<RBX::NavigationPath,RBX::NavigationPath>(
    (const boost::enable_shared_from_this<RBX::NavigationPath> *)v2 + 2,
    &v6,
    (RBX::NavigationPath *)(v2 + 32));
  *a1 = v2 + 32;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x1ebe860 | Name: _ZN5boost11make_sharedIN3RBX17NavigationService13PathUpdateJobEJRPNS1_9DataModelEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::NavigationService::PathUpdateJob,RBX::DataModel *&>(
        _QWORD *a1,
        RBX::DataModel **args)
{
  char *v2; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::NavigationService::PathUpdateJob> v6; // [rsp+0h] [rbp-38h] BYREF

  v6.px = 0;
  v2 = (char *)operator new(0x218u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_29A31D8;
  *((_QWORD *)v2 + 2) = 0;
  v2[24] = 0;
  v6.pn.pi_ = (boost::detail::sp_counted_base *)v2;
  RBX::NavigationService::PathUpdateJob::PathUpdateJob((RBX::NavigationService::PathUpdateJob *)(v2 + 32), *args);
  v2[24] = 1;
  boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::NavigationService::PathUpdateJob,RBX::NavigationService::PathUpdateJob>(
    (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)(v2 + 40),
    &v6,
    (RBX::NavigationService::PathUpdateJob *)(v2 + 32));
  *a1 = v2 + 32;
  pi = v6.pn.pi_;
  a1[1] = v6.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = v6.pn.pi_;
    if ( v6.pn.pi_ )
    {
      if ( !_InterlockedSub(&v6.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  return a1;
}


// Address: 0x1ebf0f0 | Name: _ZN5boost11make_sharedIN3RBX17NavigationService17NavigationRequestEJRKNS1_7ExtentsERiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::NavigationService::NavigationRequest,RBX::Extents const&,int &>(
        _QWORD *a1,
        const RBX::Extents *args,
        int *a3)
{
  char *v4; // rbx
  int v5; // ecx

  v4 = (char *)operator new(0x98u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_29A32B8;
  *((_QWORD *)v4 + 2) = 0;
  v5 = *a3;
  *((_QWORD *)v4 + 4) = off_29A3318;
  *(_OWORD *)(v4 + 72) = 0;
  *(_OWORD *)(v4 + 56) = 0;
  *(_OWORD *)(v4 + 40) = 0;
  *(RBX::Extents *)(v4 + 88) = *args;
  *((_DWORD *)v4 + 28) = v5;
  *((_QWORD *)v4 + 15) = 0;
  v4[24] = 1;
  *a1 = v4 + 32;
  a1[1] = v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return a1;
}


// Address: 0x1ebf2c0 | Name: _ZN5boost11make_sharedIN3RBX17NavigationService17NavigationRequestEJRKNSt3__16vectorIN3G3D12Vector2int16ENS4_9allocatorIS7_EEEERiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::NavigationService::NavigationRequest,std::vector<G3D::Vector2int16> const&,int &>(
        _QWORD *a1,
        const std::vector<G3D::Vector2int16> *args,
        int *a3)
{
  char *v4; // r13

  v4 = (char *)operator new(0x98u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_29A32B8;
  *((_QWORD *)v4 + 2) = 0;
  v4[24] = 0;
  RBX::NavigationService::NavigationRequest::NavigationRequest(
    (RBX::NavigationService::NavigationRequest *)(v4 + 32),
    args,
    *a3);
  v4[24] = 1;
  *a1 = v4 + 32;
  a1[1] = v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return a1;
}


// Address: 0x1ecf9c0 | Name: _ZN5boost11make_sharedIN3RBX8TileDataEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::TileData>::type __cdecl boost::make_shared<RBX::TileData>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<RBX::TileData>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x140u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_29A3768;
  *((_QWORD *)v2 + 2) = 0;
  *((_QWORD *)v2 + 4) = 0x7F7FFFFF7F7FFFFFLL;
  *((_DWORD *)v2 + 10) = 2139095039;
  *(_QWORD *)(v2 + 44) = 0xFF7FFFFFFF7FFFFFLL;
  *((_DWORD *)v2 + 13) = -8388609;
  *(_OWORD *)(v2 + 232) = 0;
  *(_OWORD *)(v2 + 216) = 0;
  *(_OWORD *)(v2 + 200) = 0;
  *(_OWORD *)(v2 + 184) = 0;
  *(_OWORD *)(v2 + 168) = 0;
  *(_OWORD *)(v2 + 152) = 0;
  *(_OWORD *)(v2 + 136) = 0;
  *(_OWORD *)(v2 + 120) = 0;
  *(_OWORD *)(v2 + 104) = 0;
  *(_OWORD *)(v2 + 88) = 0;
  *(_OWORD *)(v2 + 72) = 0;
  *(_OWORD *)(v2 + 56) = 0;
  *((_DWORD *)v2 + 62) = -1;
  *((_OWORD *)v2 + 19) = 0;
  *((_OWORD *)v2 + 18) = 0;
  *((_OWORD *)v2 + 17) = 0;
  *((_OWORD *)v2 + 16) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x1f15aa0 | Name: _ZN5boost11make_sharedIN3RBX13LayoutDefaultEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::LayoutDefault>::type __cdecl boost::make_shared<RBX::LayoutDefault>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::LayoutDefault>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::LayoutDefault> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0xD8u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A3998;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::LayoutDefault::LayoutDefault((RBX::LayoutDefault *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutDefault,RBX::LayoutDefault>(
    (const boost::enable_shared_from_this<RBX::LayoutNode> *)(v1 + 40),
    &v4,
    (RBX::LayoutDefault *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1f15bc0 | Name: _ZN5boost11make_sharedIN3RBX10LayoutListEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::LayoutList>::type __cdecl boost::make_shared<RBX::LayoutList>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::LayoutList>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::LayoutList> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0xD8u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A39F8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::LayoutList::LayoutList((RBX::LayoutList *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutList,RBX::LayoutList>(
    (const boost::enable_shared_from_this<RBX::LayoutNode> *)(v1 + 40),
    &v4,
    (RBX::LayoutList *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1f15ce0 | Name: _ZN5boost11make_sharedIN3RBX10LayoutGridEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::LayoutGrid>::type __cdecl boost::make_shared<RBX::LayoutGrid>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::LayoutGrid>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::LayoutGrid> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0xE8u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A3A58;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::LayoutGrid::LayoutGrid((RBX::LayoutGrid *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutGrid,RBX::LayoutGrid>(
    (const boost::enable_shared_from_this<RBX::LayoutNode> *)(v1 + 40),
    &v4,
    (RBX::LayoutGrid *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1f15e00 | Name: _ZN5boost11make_sharedIN3RBX10LayoutPageEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::LayoutPage>::type __cdecl boost::make_shared<RBX::LayoutPage>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::LayoutPage>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::LayoutPage> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0xE8u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A3AB8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::LayoutPage::LayoutPage((RBX::LayoutPage *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutPage,RBX::LayoutPage>(
    (const boost::enable_shared_from_this<RBX::LayoutNode> *)(v1 + 40),
    &v4,
    (RBX::LayoutPage *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1f15f20 | Name: _ZN5boost11make_sharedIN3RBX11LayoutTableEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::LayoutTable>::type __cdecl boost::make_shared<RBX::LayoutTable>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::LayoutTable>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::LayoutTable> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0x108u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A3B18;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::LayoutTable::LayoutTable((RBX::LayoutTable *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutTable,RBX::LayoutTable>(
    (const boost::enable_shared_from_this<RBX::LayoutNode> *)(v1 + 40),
    &v4,
    (RBX::LayoutTable *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1f16040 | Name: _ZN5boost11make_sharedIN3RBX16LayoutTableMajorEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::LayoutTableMajor>::type __cdecl boost::make_shared<RBX::LayoutTableMajor>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::LayoutTableMajor>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::LayoutTableMajor> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0xD8u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A3B78;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::LayoutTableMajor::LayoutTableMajor((RBX::LayoutTableMajor *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutTableMajor,RBX::LayoutTableMajor>(
    (const boost::enable_shared_from_this<RBX::LayoutNode> *)(v1 + 40),
    &v4,
    (RBX::LayoutTableMajor *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1f16160 | Name: _ZN5boost11make_sharedIN3RBX12LayoutInlineEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::LayoutInline>::type __cdecl boost::make_shared<RBX::LayoutInline>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  boost::detail::sp_if_not_array<RBX::LayoutInline>::type result; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::LayoutInline> v4; // [rsp+0h] [rbp-28h] BYREF

  v4.px = 0;
  v1 = (char *)operator new(0x108u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A3BD8;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  v4.pn.pi_ = (boost::detail::sp_counted_base *)v1;
  RBX::LayoutInline::LayoutInline((RBX::LayoutInline *)(v1 + 32));
  v1[24] = 1;
  boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutInline,RBX::LayoutInline>(
    (const boost::enable_shared_from_this<RBX::LayoutNode> *)(v1 + 40),
    &v4,
    (RBX::LayoutInline *)(v1 + 32));
  *v0 = v1 + 32;
  result.px = v4.pn.pi_;
  v0[1] = v4.pn.pi_;
  if ( result.px )
  {
    _InterlockedAdd((volatile signed __int32 *)result.px + 2, 1u);
    pi = v4.pn.pi_;
    if ( v4.pn.pi_ )
    {
      if ( !_InterlockedSub(&v4.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  result.px = v0;
  return result;
}


// Address: 0x1f24ba0 | Name: _ZN5boost11make_sharedIN3RBX10ThreadPoolEJRA9_KciNS1_14BaseThreadPool14ShutdownPolicyEiEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::ThreadPool,char const(&)[9],int,RBX::BaseThreadPool::ShutdownPolicy,int>(
        _QWORD *a1,
        const char (*args)[9],
        int *a3,
        RBX::BaseThreadPool::ShutdownPolicy *a4,
        int *a5)
{
  char *v8; // rbx

  v8 = (char *)operator new(0x68u);
  *((_QWORD *)v8 + 1) = 0x100000001LL;
  *(_QWORD *)v8 = &off_29A4138;
  *((_QWORD *)v8 + 2) = 0;
  v8[24] = 0;
  RBX::ThreadPool::ThreadPool((RBX::ThreadPool *)(v8 + 32), (const char *)args, *a3, *a4, *a5);
  v8[24] = 1;
  *a1 = v8 + 32;
  a1[1] = v8;
  _InterlockedAdd((volatile signed __int32 *)v8 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v8 + 16LL))(v8);
    if ( !_InterlockedSub((volatile signed __int32 *)v8 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v8 + 24LL))(v8);
  }
  return a1;
}


// Address: 0x1f7d5f0 | Name: _ZN5boost11make_sharedIN3RBX12FileMeshDataEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::FileMeshData>::type __cdecl boost::make_shared<RBX::FileMeshData>()
{
  _QWORD *v0; // rdi
  char *v1; // rbx
  _QWORD *v2; // r12
  _QWORD *v3; // rax
  boost::detail::sp_if_not_array<RBX::FileMeshData>::type result; // rax

  v1 = (char *)operator new(0x248u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A4B90;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  memset(v1 + 32, 0, 0x228u);
  v2 = operator new(8u);
  *((_QWORD *)v1 + 13) = v2;
  *((_QWORD *)v1 + 15) = v2 + 1;
  *v2 = 0;
  *((_QWORD *)v1 + 14) = v2 + 1;
  *((_OWORD *)v1 + 8) = 0;
  *((_QWORD *)v1 + 18) = 0;
  v3 = operator new(8u);
  *((_QWORD *)v1 + 16) = v3;
  *((_QWORD *)v1 + 18) = v3 + 1;
  *v3 = 0;
  *((_QWORD *)v1 + 17) = v3 + 1;
  memset(v1 + 152, 0, 0x1B0u);
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x20682f0 | Name: _ZN5boost11make_sharedIN3RBX8Graphics12MeshResourceEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Graphics::MeshResource>::type __cdecl boost::make_shared<RBX::Graphics::MeshResource>()
{
  _QWORD *v0; // rdi
  char *v1; // r15
  boost::detail::sp_if_not_array<RBX::Graphics::MeshResource>::type result; // rax

  v1 = (char *)operator new(0x1B0u);
  *((_QWORD *)v1 + 1) = 0x100000001LL;
  *(_QWORD *)v1 = &off_29A7C18;
  *((_QWORD *)v1 + 2) = 0;
  v1[24] = 0;
  memset(v1 + 32, 0, 0x190u);
  RBX::Graphics::MeshResource::MeshResource((RBX::Graphics::MeshResource *)(v1 + 32));
  v1[24] = 1;
  *v0 = v1 + 32;
  v0[1] = v1;
  _InterlockedAdd((volatile signed __int32 *)v1 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub((volatile signed __int32 *)v1 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  result.px = v0;
  return result;
}


// Address: 0x20683f0 | Name: _ZN5boost11make_sharedIN3RBX8Graphics11MeshManager8GeomDataEJEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
boost::detail::sp_if_not_array<RBX::Graphics::MeshManager::GeomData>::type __cdecl boost::make_shared<RBX::Graphics::MeshManager::GeomData>()
{
  _QWORD *v0; // rdi
  boost::detail::sp_if_not_array<RBX::Graphics::MeshManager::GeomData>::type result; // rax
  char *v2; // rbx

  v2 = (char *)operator new(0x70u);
  *((_QWORD *)v2 + 1) = 0x100000001LL;
  *(_QWORD *)v2 = &off_29A7C78;
  *((_QWORD *)v2 + 2) = 0;
  *((_OWORD *)v2 + 6) = 0;
  *((_OWORD *)v2 + 5) = 0;
  *((_OWORD *)v2 + 4) = 0;
  *((_OWORD *)v2 + 3) = 0;
  *((_OWORD *)v2 + 2) = 0;
  v2[24] = 1;
  *v0 = v2 + 32;
  v0[1] = v2;
  _InterlockedAdd((volatile signed __int32 *)v2 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub((volatile signed __int32 *)v2 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  result.px = v0;
  return result;
}


// Address: 0x275e160 | Name: _ZN5boost11make_sharedIN3RBX8Graphics8BufferGLEJPNS2_8DeviceGLERNS2_6Buffer4TypeERjS9_RNS6_5UsageEEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
_QWORD *__fastcall boost::make_shared<RBX::Graphics::BufferGL,RBX::Graphics::DeviceGL *,RBX::Graphics::Buffer::Type &,unsigned int &,unsigned int &,RBX::Graphics::Buffer::Usage &>(
        _QWORD *a1,
        RBX::Graphics::DeviceGL **args,
        RBX::Graphics::Buffer::Type *a3,
        unsigned int *a4,
        unsigned int *a5,
        RBX::Graphics::Buffer::Usage *a6)
{
  char *v8; // rbx

  v8 = (char *)operator new(0x80u);
  *((_QWORD *)v8 + 1) = 0x100000001LL;
  *(_QWORD *)v8 = &off_29CA228;
  *((_QWORD *)v8 + 2) = 0;
  v8[24] = 0;
  RBX::Graphics::BufferGL::BufferGL((RBX::Graphics::BufferGL *)(v8 + 32), *args, *a3, *a4, *a5, *a6);
  v8[24] = 1;
  *a1 = v8 + 32;
  a1[1] = v8;
  _InterlockedAdd((volatile signed __int32 *)v8 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v8 + 16LL))(v8);
    if ( !_InterlockedSub((volatile signed __int32 *)v8 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v8 + 24LL))(v8);
  }
  return a1;
}


// Address: 0x275e280 | Name: _ZN5boost11make_sharedIN3RBX8Graphics10GeometryGLEJPNS2_8DeviceGLERKNS_10shared_ptrINS2_12VertexLayoutEEERPKNS6_INS2_6BufferEEERmRSD_RjEEENS_6detail15sp_if_not_arrayIT_E4typeEDpOT0_
RBX::Graphics::DeviceGL **__fastcall boost::make_shared<RBX::Graphics::GeometryGL,RBX::Graphics::DeviceGL *,boost::shared_ptr<RBX::Graphics::VertexLayout> const&,boost::shared_ptr<RBX::Graphics::Buffer> const*&,unsigned long &,boost::shared_ptr<RBX::Graphics::Buffer> const&,unsigned int &>(
        RBX::Graphics::DeviceGL **args,
        const boost::shared_ptr<RBX::Graphics::VertexLayout>_0 *a2,
        const boost::shared_ptr<RBX::Graphics::Buffer>_0 **a3,
        const boost::shared_ptr<RBX::Graphics::Buffer> **a4,
        const boost::shared_ptr<RBX::Graphics::Buffer>_0 *a5,
        const boost::shared_ptr<RBX::Graphics::Buffer> *a6,
        unsigned int *a7)
{
  char *v9; // rbx

  v9 = (char *)operator new(0xA8u);
  *((_QWORD *)v9 + 1) = 0x100000001LL;
  *(_QWORD *)v9 = &off_29CA348;
  *((_QWORD *)v9 + 2) = 0;
  v9[24] = 0;
  RBX::Graphics::GeometryGL::GeometryGL(
    (RBX::Graphics::GeometryGL *)(v9 + 32),
    (RBX::Graphics::Device *)a2->px,
    (const boost::shared_ptr<RBX::Graphics::VertexLayout> *)a3,
    *a4,
    (size_t)a5->px,
    a6,
    *a7);
  v9[24] = 1;
  *args = (RBX::Graphics::DeviceGL *)(v9 + 32);
  args[1] = (RBX::Graphics::DeviceGL *)v9;
  _InterlockedAdd((volatile signed __int32 *)v9 + 2, 1u);
  if ( !_InterlockedSub((volatile signed __int32 *)v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v9 + 16LL))(v9);
    if ( !_InterlockedSub((volatile signed __int32 *)v9 + 3, 1u) )
      (*(void (__fastcall **)(char *))(*(_QWORD *)v9 + 24LL))(v9);
  }
  return args;
}


