// Address: 0xe5b2f0 | Name: _ZN5boost15program_options11to_internalERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall boost::program_options::to_internal(__int64 a1, __int64 a2)
{
  std::string::basic_string(a1, a2);
  return a1;
}


// Address: 0xe5b350 | Name: _ZN5boost6detail7convertIwcNS_3_bi6bind_tINSt3__112codecvt_base6resultENS_4_mfi4cmf7IS6_NS4_7codecvtIwc11__mbstate_tEERSA_PKcSE_RSE_PwSG_RSG_EENS2_5list8INS2_5valueIPKSB_EENS_3argILi1EEENSO_ILi2EEENSO_ILi3EEENSO_ILi4EEENSO_ILi5EEENSO_ILi6EEENSO_ILi7EEEEEEEEENS4_12basic_stringIT_NS4_11char_traitsISZ_EENS4_9allocatorISZ_EEEERKNSY_IT0_NS10_IS15_EENS12_IS15_EEEET1_
std::wstring *__fastcall boost::detail::convert<wchar_t,char,boost::_bi::bind_t<std::codecvt_base::result,boost::_mfi::cmf7<std::codecvt_base::result,std::codecvt<wchar_t,char,__mbstate_t>,__mbstate_t&,char const*,char const*,char const*&,wchar_t *,wchar_t *,wchar_t *&>,boost::_bi::list8<boost::_bi::value<std::codecvt<wchar_t,char,__mbstate_t> const*>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>,boost::arg<5>,boost::arg<6>,boost::arg<7>>>>(
        std::wstring *a1,
        unsigned __int8 *a2,
        int a3,
        int a4,
        int a5,
        int a6,
        char *a7,
        __int64 a8,
        __int64 a9)
{
  unsigned __int64 v9; // r12
  unsigned __int64 v10; // r12
  unsigned __int8 *v11; // rdx
  unsigned __int8 *v12; // r12
  _QWORD *v13; // r15
  unsigned int (__fastcall *v14)(_QWORD *, __int64 *, unsigned __int8 *, unsigned __int8 *, unsigned __int8 **, wchar_t *, char *, wchar_t **); // rax
  unsigned __int8 *v16; // [rsp+8h] [rbp-E0h] BYREF
  _BYTE v17[16]; // [rsp+10h] [rbp-D8h] BYREF
  wchar_t *__last; // [rsp+20h] [rbp-C8h] BYREF
  __int64 v19; // [rsp+28h] [rbp-C0h] BYREF
  wchar_t __first[32]; // [rsp+30h] [rbp-B8h] BYREF
  char v21[56]; // [rsp+B0h] [rbp-38h] BYREF

  *(_OWORD *)a1 = 0;
  *((_QWORD *)a1 + 2) = 0;
  v19 = 0;
  v9 = *a2;
  if ( (v9 & 1) != 0 )
  {
    v11 = (unsigned __int8 *)*((_QWORD *)a2 + 2);
    v16 = v11;
    v10 = *((_QWORD *)a2 + 1);
    if ( !v10 )
      return a1;
  }
  else
  {
    v16 = a2 + 1;
    v10 = v9 >> 1;
    v11 = a2 + 1;
    if ( !v10 )
      return a1;
  }
  v12 = &v11[v10];
  v13 = (_QWORD *)(a8 + a9);
  do
  {
    __last = __first;
    v14 = (unsigned int (__fastcall *)(_QWORD *, __int64 *, unsigned __int8 *, unsigned __int8 *, unsigned __int8 **, wchar_t *, char *, wchar_t **))a7;
    if ( ((unsigned __int8)a7 & 1) != 0 )
      v14 = *(unsigned int (__fastcall **)(_QWORD *, __int64 *, unsigned __int8 *, unsigned __int8 *, unsigned __int8 **, wchar_t *, char *, wchar_t **))&a7[*v13 - 1];
    if ( v14(v13, &v19, v11, v12, &v16, __first, v21, &__last) == 2 )
    {
      std::logic_error::logic_error((std::logic_error *)v17, "character conversion failed");
      boost::throw_exception<std::logic_error>((const std::logic_error *)v17);
    }
    if ( __last == __first )
    {
      std::logic_error::logic_error((std::logic_error *)v17, "character conversion failed");
      boost::throw_exception<std::logic_error>((const std::logic_error *)v17);
    }
    std::wstring::__append_forward_unsafe<wchar_t *>(a1, __first, __last);
    v11 = v16;
  }
  while ( v16 != v12 );
  return a1;
}


// Address: 0xe5b4e0 | Name: _ZN5boost6detail7convertIcwNS_3_bi6bind_tINSt3__112codecvt_base6resultENS_4_mfi4cmf7IS6_NS4_7codecvtIwc11__mbstate_tEERSA_PKwSE_RSE_PcSG_RSG_EENS2_5list8INS2_5valueIPKSB_EENS_3argILi1EEENSO_ILi2EEENSO_ILi3EEENSO_ILi4EEENSO_ILi5EEENSO_ILi6EEENSO_ILi7EEEEEEEEENS4_12basic_stringIT_NS4_11char_traitsISZ_EENS4_9allocatorISZ_EEEERKNSY_IT0_NS10_IS15_EENS12_IS15_EEEET1_
std::string *__fastcall boost::detail::convert<char,wchar_t,boost::_bi::bind_t<std::codecvt_base::result,boost::_mfi::cmf7<std::codecvt_base::result,std::codecvt<wchar_t,char,__mbstate_t>,__mbstate_t&,wchar_t const*,wchar_t const*,wchar_t const*&,char *,char *,char *&>,boost::_bi::list8<boost::_bi::value<std::codecvt<wchar_t,char,__mbstate_t> const*>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>,boost::arg<5>,boost::arg<6>,boost::arg<7>>>>(
        std::string *a1,
        unsigned __int8 *a2,
        int a3,
        int a4,
        int a5,
        int a6,
        char *a7,
        __int64 a8,
        __int64 a9)
{
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rax
  unsigned __int8 *v11; // rdx
  unsigned __int8 *v12; // r12
  _QWORD *v13; // r15
  unsigned int (__fastcall *v14)(_QWORD *, __int64 *, unsigned __int8 *, unsigned __int8 *, unsigned __int8 **, char *, unsigned __int64 *, char **); // rax
  unsigned __int8 *v16; // [rsp+8h] [rbp-80h] BYREF
  _BYTE v17[16]; // [rsp+10h] [rbp-78h] BYREF
  char *__last; // [rsp+20h] [rbp-68h] BYREF
  __int64 v19; // [rsp+28h] [rbp-60h] BYREF
  char __first[32]; // [rsp+30h] [rbp-58h] BYREF
  unsigned __int64 v21[7]; // [rsp+50h] [rbp-38h] BYREF

  v21[0] = __readfsqword(0x28u);
  *(_OWORD *)a1 = 0;
  *((_QWORD *)a1 + 2) = 0;
  v19 = 0;
  v9 = *a2;
  if ( (v9 & 1) != 0 )
  {
    v11 = (unsigned __int8 *)*((_QWORD *)a2 + 2);
    v16 = v11;
    v10 = *((_QWORD *)a2 + 1);
    if ( !v10 )
      return a1;
  }
  else
  {
    v16 = a2 + 4;
    v10 = v9 >> 1;
    v11 = a2 + 4;
    if ( !v10 )
      return a1;
  }
  v12 = &v11[4 * v10];
  v13 = (_QWORD *)(a8 + a9);
  do
  {
    __last = __first;
    v14 = (unsigned int (__fastcall *)(_QWORD *, __int64 *, unsigned __int8 *, unsigned __int8 *, unsigned __int8 **, char *, unsigned __int64 *, char **))a7;
    if ( ((unsigned __int8)a7 & 1) != 0 )
      v14 = *(unsigned int (__fastcall **)(_QWORD *, __int64 *, unsigned __int8 *, unsigned __int8 *, unsigned __int8 **, char *, unsigned __int64 *, char **))&a7[*v13 - 1];
    if ( v14(v13, &v19, v11, v12, &v16, __first, v21, &__last) == 2 )
    {
      std::logic_error::logic_error((std::logic_error *)v17, "character conversion failed");
      boost::throw_exception<std::logic_error>((const std::logic_error *)v17);
    }
    if ( __last == __first )
    {
      std::logic_error::logic_error((std::logic_error *)v17, "character conversion failed");
      boost::throw_exception<std::logic_error>((const std::logic_error *)v17);
    }
    std::string::__append_forward_unsafe<char *>(a1, __first, __last);
    v11 = v16;
  }
  while ( v16 != v12 );
  return a1;
}


// Address: 0xe5c7f0 | Name: _GLOBAL__sub_I_convert.cpp
void __cdecl GLOBAL__sub_I_convert_cpp()
{
  std::codecvt<wchar_t,char,__mbstate_t>::codecvt(qword_29F20B8, 0);
  *(_QWORD *)qword_29F20B8 = &off_287DD00;
  __cxa_atexit((void (*)(void *))&std::codecvt<wchar_t,char,__mbstate_t>::~codecvt, qword_29F20B8, &dso_handle);
}


