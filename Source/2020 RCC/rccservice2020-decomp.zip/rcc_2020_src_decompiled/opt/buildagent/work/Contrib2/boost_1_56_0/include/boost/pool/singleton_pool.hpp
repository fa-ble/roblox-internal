// Address: 0xf77140 | Name: __cxx_global_var_init.546
void __cdecl _cxx_global_var_init_546()
{
  if ( !(_BYTE)qword_29FDFD8 )
    qword_29FDFD8 = 1;
}


// Address: 0xf77160 | Name: __cxx_global_var_init.547
void __cdecl _cxx_global_var_init_547()
{
  if ( !(_BYTE)qword_29FDFE8 )
  {
    if ( !byte_29FE160 )
    {
      byte_29FE160 = 1;
      boost::mutex::mutex(&stru_29FDF78);
      *(_OWORD *)&stru_29FDFA0.first = 0;
      stru_29FDFA0.list.sz = 0;
      *(_OWORD *)&stru_29FDFA0.requested_size = xmmword_3EADD0;
      *(_OWORD *)&stru_29FDFA0.start_size = 0x20u;
    }
    qword_29FDFE8 = 1;
  }
}


// Address: 0xf771d0 | Name: __cxx_global_var_init.548
void __cdecl _cxx_global_var_init_548()
{
  if ( !(_BYTE)qword_29FE050 )
    qword_29FE050 = 1;
}


// Address: 0xf771f0 | Name: __cxx_global_var_init.549
void __cdecl _cxx_global_var_init_549()
{
  if ( !(_BYTE)qword_29FE060 )
  {
    if ( !byte_29FE161 )
    {
      byte_29FE161 = 1;
      boost::mutex::mutex(&stru_29FDFF0);
      *(_OWORD *)&stru_29FE018.first = 0;
      stru_29FE018.list.sz = 0;
      *(_OWORD *)&stru_29FE018.requested_size = xmmword_3EA050;
      *(_OWORD *)&stru_29FE018.start_size = 0x20u;
    }
    qword_29FE060 = 1;
  }
}


// Address: 0xf77260 | Name: __cxx_global_var_init.550
void __cdecl _cxx_global_var_init_550()
{
  if ( !(_BYTE)qword_29FE0C8 )
    qword_29FE0C8 = 1;
}


// Address: 0xf77280 | Name: __cxx_global_var_init.551
void __cdecl _cxx_global_var_init_551()
{
  if ( !(_BYTE)qword_29FE0D8 )
  {
    if ( !byte_29FE162 )
    {
      byte_29FE162 = 1;
      boost::mutex::mutex(&stru_29FE068);
      *(_OWORD *)&stru_29FE090.first = 0;
      stru_29FE090.list.sz = 0;
      *(_OWORD *)&stru_29FE090.requested_size = xmmword_3EA460;
      *(_OWORD *)&stru_29FE090.start_size = 0x20u;
    }
    qword_29FE0D8 = 1;
  }
}


// Address: 0xf7aa30 | Name: _ZN5boost14singleton_poolINS_23fast_pool_allocator_tagELj32ENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EE7is_fromEPv
bool __fastcall boost::singleton_pool<boost::fast_pool_allocator_tag,32u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::is_from(
        void *const ptr)
{
  char *v1; // rbx
  boost::details::PODptr<unsigned long>::size_type *p_sz; // rax
  boost::details::PODptr<unsigned long>::size_type v3; // rcx

  if ( !byte_29FE160 )
  {
    byte_29FE160 = 1;
    boost::mutex::mutex(&stru_29FDF78);
    *(_OWORD *)&stru_29FDFA0.first = 0;
    stru_29FDFA0.list.sz = 0;
    *(_OWORD *)&stru_29FDFA0.requested_size = xmmword_3EADD0;
    *(_OWORD *)&stru_29FDFA0.start_size = 0x20u;
  }
  boost::mutex::lock(&stru_29FDF78);
  v1 = stru_29FDFA0.list.ptr;
  if ( stru_29FDFA0.list.ptr )
  {
    p_sz = &stru_29FDFA0.list.sz;
    while ( 1 )
    {
      v3 = *p_sz;
      if ( v1 <= ptr && &v1[v3 - 16] > ptr )
        break;
      p_sz = (boost::details::PODptr<unsigned long>::size_type *)&v1[v3 - 8];
      v1 = *(char **)&v1[v3 - 16];
      if ( !v1 )
        goto LABEL_8;
    }
  }
  else
  {
LABEL_8:
    v1 = 0;
  }
  boost::mutex::unlock(&stru_29FDF78);
  return v1 != 0;
}


// Address: 0xf7ab00 | Name: _ZN5boost14singleton_poolINS_23fast_pool_allocator_tagELj48ENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EE7is_fromEPv
bool __fastcall boost::singleton_pool<boost::fast_pool_allocator_tag,48u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::is_from(
        void *const ptr)
{
  char *v1; // rbx
  boost::details::PODptr<unsigned long>::size_type *p_sz; // rax
  boost::details::PODptr<unsigned long>::size_type v3; // rcx

  if ( !byte_29FE161 )
  {
    byte_29FE161 = 1;
    boost::mutex::mutex(&stru_29FDFF0);
    *(_OWORD *)&stru_29FE018.first = 0;
    stru_29FE018.list.sz = 0;
    *(_OWORD *)&stru_29FE018.requested_size = xmmword_3EA050;
    *(_OWORD *)&stru_29FE018.start_size = 0x20u;
  }
  boost::mutex::lock(&stru_29FDFF0);
  v1 = stru_29FE018.list.ptr;
  if ( stru_29FE018.list.ptr )
  {
    p_sz = &stru_29FE018.list.sz;
    while ( 1 )
    {
      v3 = *p_sz;
      if ( v1 <= ptr && &v1[v3 - 16] > ptr )
        break;
      p_sz = (boost::details::PODptr<unsigned long>::size_type *)&v1[v3 - 8];
      v1 = *(char **)&v1[v3 - 16];
      if ( !v1 )
        goto LABEL_8;
    }
  }
  else
  {
LABEL_8:
    v1 = 0;
  }
  boost::mutex::unlock(&stru_29FDFF0);
  return v1 != 0;
}


// Address: 0xf7abd0 | Name: _ZN5boost14singleton_poolINS_23fast_pool_allocator_tagELj8ENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EE7is_fromEPv
bool __fastcall boost::singleton_pool<boost::fast_pool_allocator_tag,8u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::is_from(
        void *const ptr)
{
  char *v1; // rbx
  boost::details::PODptr<unsigned long>::size_type *p_sz; // rax
  boost::details::PODptr<unsigned long>::size_type v3; // rcx

  if ( !byte_29FE162 )
  {
    byte_29FE162 = 1;
    boost::mutex::mutex(&stru_29FE068);
    *(_OWORD *)&stru_29FE090.first = 0;
    stru_29FE090.list.sz = 0;
    *(_OWORD *)&stru_29FE090.requested_size = xmmword_3EA460;
    *(_OWORD *)&stru_29FE090.start_size = 0x20u;
  }
  boost::mutex::lock(&stru_29FE068);
  v1 = stru_29FE090.list.ptr;
  if ( stru_29FE090.list.ptr )
  {
    p_sz = &stru_29FE090.list.sz;
    while ( 1 )
    {
      v3 = *p_sz;
      if ( v1 <= ptr && &v1[v3 - 16] > ptr )
        break;
      p_sz = (boost::details::PODptr<unsigned long>::size_type *)&v1[v3 - 8];
      v1 = *(char **)&v1[v3 - 16];
      if ( !v1 )
        goto LABEL_8;
    }
  }
  else
  {
LABEL_8:
    v1 = 0;
  }
  boost::mutex::unlock(&stru_29FE068);
  return v1 != 0;
}


// Address: 0xf7ae40 | Name: _ZN5boost14singleton_poolINS_23fast_pool_allocator_tagELj8ENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EE4freeEPvm
void __fastcall boost::singleton_pool<boost::fast_pool_allocator_tag,8u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::free(
        void *const ptr,
        const boost::singleton_pool<boost::fast_pool_allocator_tag,8,boost::default_user_allocator_new_delete,boost::mutex,32,0>::size_type n)
{
  boost::pool<boost::default_user_allocator_new_delete>::size_type requested_size; // rcx
  __int64 v4; // rsi
  boost::pool<boost::default_user_allocator_new_delete>::size_type v5; // rsi
  boost::pool<boost::default_user_allocator_new_delete>::size_type v6; // rcx
  boost::pool<boost::default_user_allocator_new_delete>::size_type v7; // rcx
  char *v8; // rcx
  char *v9; // rax
  __int64 v10; // rsi
  char *v11; // rdx

  if ( !byte_29FE162 )
  {
    byte_29FE162 = 1;
    boost::mutex::mutex(&stru_29FE068);
    *(_OWORD *)&stru_29FE090.first = 0;
    stru_29FE090.list.sz = 0;
    *(_OWORD *)&stru_29FE090.requested_size = xmmword_3EA460;
    *(_OWORD *)&stru_29FE090.start_size = 0x20u;
  }
  boost::mutex::lock(&stru_29FE068);
  requested_size = 8;
  if ( stru_29FE090.requested_size > 8 )
    requested_size = stru_29FE090.requested_size;
  v4 = 8 - (requested_size & 7);
  if ( (requested_size & 7) == 0 )
    v4 = requested_size & 7;
  v5 = requested_size + v4;
  v6 = stru_29FE090.requested_size * n / v5 + (stru_29FE090.requested_size * n % v5 != 0);
  if ( v6 )
  {
    v7 = v5 * v6 - v5 - (v5 * v6 - v5) % v5;
    *(_QWORD *)((char *)ptr + v7) = stru_29FE090.first;
    if ( v7 )
    {
      v8 = (char *)ptr + v7;
      v9 = &v8[-v5];
      if ( &v8[-v5] == ptr )
      {
        v11 = v8;
      }
      else
      {
        v10 = -(__int64)v5;
        do
        {
          v11 = v9;
          *(_QWORD *)v9 = v8;
          v9 += v10;
          v8 = v11;
        }
        while ( v9 != ptr );
      }
      *(_QWORD *)ptr = v11;
    }
    stru_29FE090.first = ptr;
  }
  boost::mutex::unlock(&stru_29FE068);
}


// Address: 0xf800a0 | Name: _ZN5boost14singleton_poolINS_23fast_pool_allocator_tagELj48ENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EE6mallocEv
void *__cdecl boost::singleton_pool<boost::fast_pool_allocator_tag,48u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::malloc()
{
  void *first; // rbx

  if ( !byte_29FE161 )
  {
    byte_29FE161 = 1;
    boost::mutex::mutex(&stru_29FDFF0);
    *(_OWORD *)&stru_29FE018.first = 0;
    stru_29FE018.list.sz = 0;
    *(_OWORD *)&stru_29FE018.requested_size = xmmword_3EA050;
    *(_OWORD *)&stru_29FE018.start_size = 0x20u;
  }
  boost::mutex::lock(&stru_29FDFF0);
  first = stru_29FE018.first;
  if ( stru_29FE018.first )
    stru_29FE018.first = *(void **)stru_29FE018.first;
  else
    first = boost::pool<boost::default_user_allocator_new_delete>::malloc_need_resize(&stru_29FE018);
  boost::mutex::unlock(&stru_29FDFF0);
  return first;
}


// Address: 0xf80ff0 | Name: _ZN5boost14singleton_poolINS_23fast_pool_allocator_tagELj8ENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EE6mallocEv
void *__cdecl boost::singleton_pool<boost::fast_pool_allocator_tag,8u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::malloc()
{
  void *first; // rbx

  if ( !byte_29FE162 )
  {
    byte_29FE162 = 1;
    boost::mutex::mutex(&stru_29FE068);
    *(_OWORD *)&stru_29FE090.first = 0;
    stru_29FE090.list.sz = 0;
    *(_OWORD *)&stru_29FE090.requested_size = xmmword_3EA460;
    *(_OWORD *)&stru_29FE090.start_size = 0x20u;
  }
  boost::mutex::lock(&stru_29FE068);
  first = stru_29FE090.first;
  if ( stru_29FE090.first )
    stru_29FE090.first = *(void **)stru_29FE090.first;
  else
    first = boost::pool<boost::default_user_allocator_new_delete>::malloc_need_resize(&stru_29FE090);
  boost::mutex::unlock(&stru_29FE068);
  return first;
}


// Address: 0xf810b0 | Name: _ZN5boost14singleton_poolINS_23fast_pool_allocator_tagELj8ENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EE14ordered_mallocEm
void *__fastcall boost::singleton_pool<boost::fast_pool_allocator_tag,8u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::ordered_malloc(
        const boost::singleton_pool<boost::fast_pool_allocator_tag,8,boost::default_user_allocator_new_delete,boost::mutex,32,0>::size_type n)
{
  void *v1; // rbx

  if ( !byte_29FE162 )
  {
    byte_29FE162 = 1;
    boost::mutex::mutex(&stru_29FE068);
    *(_OWORD *)&stru_29FE090.first = 0;
    stru_29FE090.list.sz = 0;
    *(_OWORD *)&stru_29FE090.requested_size = xmmword_3EA460;
    *(_OWORD *)&stru_29FE090.start_size = 0x20u;
  }
  boost::mutex::lock(&stru_29FE068);
  v1 = boost::pool<boost::default_user_allocator_new_delete>::ordered_malloc(&stru_29FE090, n);
  boost::mutex::unlock(&stru_29FE068);
  return v1;
}


// Address: 0x1fe1ca0 | Name: __cxx_global_var_init.85
void __cdecl _cxx_global_var_init_85()
{
  if ( !(_BYTE)qword_2AB9058 )
    qword_2AB9058 = 1;
}


// Address: 0x1fe1cc0 | Name: __cxx_global_var_init.86_1
void __cdecl _cxx_global_var_init_86_1()
{
  if ( !(_BYTE)qword_2AB9068 )
  {
    if ( !byte_2AB9070 )
    {
      byte_2AB9070 = 1;
      boost::mutex::mutex(&stru_2AB8FF8);
      *(_OWORD *)&stru_2AB9020.first = 0;
      stru_2AB9020.list.sz = 0;
      *(_OWORD *)&stru_2AB9020.requested_size = xmmword_3E9DD0;
      *(_OWORD *)&stru_2AB9020.start_size = 0x20u;
    }
    qword_2AB9068 = 1;
  }
}


// Address: 0x1fe1f20 | Name: _ZN5boost14singleton_poolINS_23fast_pool_allocator_tagELj24ENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EE7is_fromEPv
bool __fastcall boost::singleton_pool<boost::fast_pool_allocator_tag,24u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::is_from(
        void *const ptr)
{
  char *v1; // rbx
  boost::details::PODptr<unsigned long>::size_type *p_sz; // rax
  boost::details::PODptr<unsigned long>::size_type v3; // rcx

  if ( !byte_2AB9070 )
  {
    byte_2AB9070 = 1;
    boost::mutex::mutex(&stru_2AB8FF8);
    *(_OWORD *)&stru_2AB9020.first = 0;
    stru_2AB9020.list.sz = 0;
    *(_OWORD *)&stru_2AB9020.requested_size = xmmword_3E9DD0;
    *(_OWORD *)&stru_2AB9020.start_size = 0x20u;
  }
  boost::mutex::lock(&stru_2AB8FF8);
  v1 = stru_2AB9020.list.ptr;
  if ( stru_2AB9020.list.ptr )
  {
    p_sz = &stru_2AB9020.list.sz;
    while ( 1 )
    {
      v3 = *p_sz;
      if ( v1 <= ptr && &v1[v3 - 16] > ptr )
        break;
      p_sz = (boost::details::PODptr<unsigned long>::size_type *)&v1[v3 - 8];
      v1 = *(char **)&v1[v3 - 16];
      if ( !v1 )
        goto LABEL_8;
    }
  }
  else
  {
LABEL_8:
    v1 = 0;
  }
  boost::mutex::unlock(&stru_2AB8FF8);
  return v1 != 0;
}


// Address: 0x1fe2b70 | Name: _ZN5boost14singleton_poolINS_23fast_pool_allocator_tagELj24ENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EE6mallocEv
void *__cdecl boost::singleton_pool<boost::fast_pool_allocator_tag,24u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::malloc()
{
  void *first; // rbx

  if ( !byte_2AB9070 )
  {
    byte_2AB9070 = 1;
    boost::mutex::mutex(&stru_2AB8FF8);
    *(_OWORD *)&stru_2AB9020.first = 0;
    stru_2AB9020.list.sz = 0;
    *(_OWORD *)&stru_2AB9020.requested_size = xmmword_3E9DD0;
    *(_OWORD *)&stru_2AB9020.start_size = 0x20u;
  }
  boost::mutex::lock(&stru_2AB8FF8);
  first = stru_2AB9020.first;
  if ( stru_2AB9020.first )
    stru_2AB9020.first = *(void **)stru_2AB9020.first;
  else
    first = boost::pool<boost::default_user_allocator_new_delete>::malloc_need_resize(&stru_2AB9020);
  boost::mutex::unlock(&stru_2AB8FF8);
  return first;
}


// Address: 0x1fe83e0 | Name: _ZN5boost14singleton_poolINS_23fast_pool_allocator_tagELj32ENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EE6mallocEv
void *__cdecl boost::singleton_pool<boost::fast_pool_allocator_tag,32u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::malloc()
{
  void *first; // rbx

  if ( !byte_29FE160 )
  {
    byte_29FE160 = 1;
    boost::mutex::mutex(&stru_29FDF78);
    *(_OWORD *)&stru_29FDFA0.first = 0;
    stru_29FDFA0.list.sz = 0;
    *(_OWORD *)&stru_29FDFA0.requested_size = xmmword_3EADD0;
    *(_OWORD *)&stru_29FDFA0.start_size = 0x20u;
  }
  boost::mutex::lock(&stru_29FDF78);
  first = stru_29FDFA0.first;
  if ( stru_29FDFA0.first )
    stru_29FDFA0.first = *(void **)stru_29FDFA0.first;
  else
    first = boost::pool<boost::default_user_allocator_new_delete>::malloc_need_resize(&stru_29FDFA0);
  boost::mutex::unlock(&stru_29FDF78);
  return first;
}


