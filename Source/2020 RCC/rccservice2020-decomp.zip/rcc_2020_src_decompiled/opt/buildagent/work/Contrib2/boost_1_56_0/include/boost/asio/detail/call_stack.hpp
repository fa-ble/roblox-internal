// Address: 0x2546ce0 | Name: __cxx_global_var_init.41_1
void __cdecl _cxx_global_var_init_41_1()
{
  if ( !(_BYTE)qword_2B11480 )
    qword_2B11480 = 1;
}


// Address: 0x25b0580 | Name: __cxx_global_var_init.30_0
void __cdecl _cxx_global_var_init_30_0()
{
  if ( !(_BYTE)qword_2B116F8 )
    qword_2B116F8 = 1;
}


