// Address: 0xdbdf20 | Name: _ZN5boost10shared_ptrINS_6detail12shared_stateINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEEED2Ev
void __fastcall boost::shared_ptr<boost::detail::shared_state<std::string>>::~shared_ptr(
        boost::shared_ptr<boost::detail::shared_state<std::string > > *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf2a450 | Name: _ZN5boost8weak_ptrIKN3RBX8InstanceEEaSIKNS1_4WeldEEERS4_ONS0_IT_EE
boost::weak_ptr<const RBX::Instance> *__fastcall boost::weak_ptr<RBX::Instance const>::operator=<RBX::Weld const>(
        boost::weak_ptr<const RBX::Instance> *this,
        boost::weak_ptr<const RBX::Weld> *r)
{
  boost::detail::sp_counted_base *pi; // rbx
  signed __int32 use_count; // eax
  boost::weak_ptr<const RBX::Instance>::element_type *px; // r12
  signed __int32 v6; // ett
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *v8; // rdi

  pi = r->pn.pi_;
  if ( pi )
  {
    use_count = pi->use_count_;
    px = 0;
    while ( use_count )
    {
      v6 = use_count;
      use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
      if ( v6 == use_count )
      {
        px = r->px;
        if ( !_InterlockedSub(&pi->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
        break;
      }
    }
  }
  else
  {
    px = 0;
  }
  v7 = r->pn.pi_;
  *r = 0;
  this->px = px;
  v8 = this->pn.pi_;
  this->pn.pi_ = v7;
  if ( v8 && !_InterlockedSub(&v8->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
  return this;
}


// Address: 0xfaba30 | Name: _ZN5boost8weak_ptrIN3RBX8Security29ReplicatorCryptoSystemOpenSSLEED2Ev
void __fastcall boost::weak_ptr<RBX::Security::ReplicatorCryptoSystemOpenSSL>::~weak_ptr(
        boost::weak_ptr<RBX::Security::ReplicatorCryptoSystemOpenSSL> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x103cb90 | Name: _ZN5boost8weak_ptrIN3RBX8InstanceEED2Ev
void __fastcall boost::weak_ptr<RBX::Instance>::~weak_ptr(boost::weak_ptr<RBX::Instance> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10acea0 | Name: _ZN5boost10shared_ptrIN3G3D5PlaneEED2Ev
void __fastcall boost::shared_ptr<G3D::Plane>::~shared_ptr(boost::shared_ptr<G3D::Plane> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10c5dc0 | Name: _ZN5boost10shared_ptrIN3RBX9SelectionEED2Ev
void __fastcall boost::shared_ptr<RBX::Selection>::~shared_ptr(boost::shared_ptr<RBX::Selection> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10c7cc0 | Name: _ZN5boost8weak_ptrIN3RBX12PartInstanceEED2Ev
void __fastcall boost::weak_ptr<RBX::PartInstance>::~weak_ptr(boost::weak_ptr<RBX::PartInstance> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10edeb0 | Name: _ZN5boost8weak_ptrIN3RBX14PhysicsServiceEED2Ev
void __fastcall boost::weak_ptr<RBX::PhysicsService>::~weak_ptr(boost::weak_ptr<RBX::PhysicsService> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1204bb0 | Name: _ZN5boost10shared_ptrINS_6detail12shared_stateIvEEED2Ev
void __fastcall boost::shared_ptr<boost::detail::shared_state<void>>::~shared_ptr(
        boost::shared_ptr<boost::detail::shared_state<void> > *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1213820 | Name: _ZN5boost8weak_ptrIN3RBX9DataModelEED2Ev
void __fastcall boost::weak_ptr<RBX::DataModel>::~weak_ptr(boost::weak_ptr<RBX::DataModel> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1280240 | Name: _ZN5boost10shared_ptrIN3RBX9Analytics8SettingsEED2Ev
void __fastcall boost::shared_ptr<RBX::Analytics::Settings>::~shared_ptr(
        boost::shared_ptr<RBX::Analytics::Settings> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x128fe00 | Name: _ZN5boost10shared_ptrIN3RBX7RbxCurlEED2Ev
void __fastcall boost::shared_ptr<RBX::RbxCurl>::~shared_ptr(boost::shared_ptr<RBX::RbxCurl> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x129f670 | Name: _ZN5boost10shared_ptrINS_6detail12shared_stateINS0_IN3RBX12HttpResponseEEEEEED2Ev
void __fastcall boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>>::~shared_ptr(
        boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > > *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1321b40 | Name: _ZN5boost10shared_ptrIN3RBX10Soundscape5SoundEED2Ev
void __fastcall boost::shared_ptr<RBX::Soundscape::Sound>::~shared_ptr(boost::shared_ptr<RBX::Soundscape::Sound> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1321c40 | Name: _ZN5boost10shared_ptrIN3RBX10Soundscape24FMODPlaybackChannelGroupEED2Ev
void __fastcall boost::shared_ptr<RBX::Soundscape::FMODPlaybackChannelGroup>::~shared_ptr(
        boost::shared_ptr<RBX::Soundscape::FMODPlaybackChannelGroup> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1342930 | Name: _ZN5boost10shared_ptrIKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEED2Ev
void __fastcall boost::shared_ptr<std::string const>::~shared_ptr(boost::shared_ptr<const std::string > *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1370b60 | Name: _ZN5boost10shared_ptrIN3RBX18BatchAssetApiStateEED2Ev
void __fastcall boost::shared_ptr<RBX::BatchAssetApiState>::~shared_ptr(
        boost::shared_ptr<RBX::BatchAssetApiState> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x13d20a0 | Name: _ZN5boost8weak_ptrIN3RBX10AttachmentEED2Ev
void __fastcall boost::weak_ptr<RBX::Attachment>::~weak_ptr(boost::weak_ptr<RBX::Attachment> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1413280 | Name: _ZN5boost10shared_ptrIN3RBX11Constraints10ConstraintEED2Ev
void __fastcall boost::shared_ptr<RBX::Constraints::Constraint>::~shared_ptr(
        boost::shared_ptr<RBX::Constraints::Constraint> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x14304a0 | Name: _ZN5boost10shared_ptrIN3RBX24AnalyticsProviderPlayFab17BulkIngestionInfoEED2Ev
void __fastcall boost::shared_ptr<RBX::AnalyticsProviderPlayFab::BulkIngestionInfo>::~shared_ptr(
        boost::shared_ptr<RBX::AnalyticsProviderPlayFab::BulkIngestionInfo> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1526140 | Name: _ZN5boost10shared_ptrIN3RBX17LocalizationTable5EntryEED2Ev
void __fastcall boost::shared_ptr<RBX::LocalizationTable::Entry>::~shared_ptr(
        boost::shared_ptr<RBX::LocalizationTable::Entry> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1586f50 | Name: _ZN5boost8weak_ptrIN3RBX9GuiObjectEEaSINS1_9GuiButtonEEERS3_ONS0_IT_EE
boost::weak_ptr<RBX::GuiObject> *__fastcall boost::weak_ptr<RBX::GuiObject>::operator=<RBX::GuiButton>(
        boost::weak_ptr<RBX::GuiObject> *this,
        boost::weak_ptr<RBX::GuiButton> *r)
{
  boost::detail::sp_counted_base *pi; // rbx
  signed __int32 use_count; // eax
  boost::weak_ptr<RBX::GuiButton>::element_type *px; // r12
  signed __int32 v6; // ett
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *v8; // rdi

  pi = r->pn.pi_;
  if ( pi )
  {
    use_count = pi->use_count_;
    px = 0;
    while ( use_count )
    {
      v6 = use_count;
      use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
      if ( v6 == use_count )
      {
        px = r->px;
        if ( !_InterlockedSub(&pi->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
        break;
      }
    }
  }
  else
  {
    px = 0;
  }
  v7 = r->pn.pi_;
  *r = 0;
  this->px = px;
  v8 = this->pn.pi_;
  this->pn.pi_ = v7;
  if ( v8 && !_InterlockedSub(&v8->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
  return this;
}


// Address: 0x15870c0 | Name: _ZN5boost8weak_ptrIN3RBX9GuiObjectEEaSINS1_7TextBoxEEERS3_ONS0_IT_EE
boost::weak_ptr<RBX::GuiObject> *__fastcall boost::weak_ptr<RBX::GuiObject>::operator=<RBX::TextBox>(
        boost::weak_ptr<RBX::GuiObject> *this,
        boost::weak_ptr<RBX::TextBox> *r)
{
  boost::detail::sp_counted_base *pi; // rbx
  signed __int32 use_count; // eax
  boost::weak_ptr<RBX::GuiObject>::element_type *px; // r12
  signed __int32 v6; // ett
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *v8; // rdi

  pi = r->pn.pi_;
  if ( pi )
  {
    use_count = pi->use_count_;
    px = 0;
    while ( use_count )
    {
      v6 = use_count;
      use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
      if ( v6 == use_count )
      {
        px = (boost::weak_ptr<RBX::GuiObject>::element_type *)r->px;
        if ( !_InterlockedSub(&pi->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
        break;
      }
    }
  }
  else
  {
    px = 0;
  }
  v7 = r->pn.pi_;
  *r = 0;
  this->px = px;
  v8 = this->pn.pi_;
  this->pn.pi_ = v7;
  if ( v8 && !_InterlockedSub(&v8->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
  return this;
}


// Address: 0x15a4490 | Name: _ZN5boost10shared_ptrINS_6detail12shared_stateINS0_INSt3__16vectorINS0_INS4_INS0_IN3RBX8InstanceEEENS3_9allocatorIS7_EEEEEENS8_ISB_EEEEEEEEED2Ev
void __fastcall boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>>::~shared_ptr(
        boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > > *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x15cf220 | Name: _ZN5boost10shared_ptrIN3RBX10AppStorageEED2Ev
void __fastcall boost::shared_ptr<RBX::AppStorage>::~shared_ptr(boost::shared_ptr<RBX::AppStorage> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x15d21c0 | Name: _ZN5boost8weak_ptrIN3RBX7GuiItemEED2Ev
void __fastcall boost::weak_ptr<RBX::GuiItem>::~weak_ptr(boost::weak_ptr<RBX::GuiItem> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1651b60 | Name: _ZN5boost10shared_ptrIN3RBX16PlayerConfigurerEED2Ev
void __fastcall boost::shared_ptr<RBX::PlayerConfigurer>::~shared_ptr(boost::shared_ptr<RBX::PlayerConfigurer> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x170fe30 | Name: _ZN5boost8weak_ptrIN3RBX10PVInstanceEED2Ev
void __fastcall boost::weak_ptr<RBX::PVInstance>::~weak_ptr(boost::weak_ptr<RBX::PVInstance> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x17165b0 | Name: _ZN5boost10shared_ptrIN3RBX10LuaDraggerEED2Ev
void __fastcall boost::shared_ptr<RBX::LuaDragger>::~shared_ptr(boost::shared_ptr<RBX::LuaDragger> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1790b20 | Name: _ZN5boost8weak_ptrIN3RBX10RunServiceEED2Ev
void __fastcall boost::weak_ptr<RBX::RunService>::~weak_ptr(boost::weak_ptr<RBX::RunService> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1790c90 | Name: _ZN5boost10shared_ptrIN3RBX6GfxGuiEED2Ev
void __fastcall boost::shared_ptr<RBX::GfxGui>::~shared_ptr(boost::shared_ptr<RBX::GfxGui> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x18e3cb0 | Name: _ZN5boost10shared_ptrIN3RBX6Voxel24GridEED2Ev
void __fastcall boost::shared_ptr<RBX::Voxel2::Grid>::~shared_ptr(boost::shared_ptr<RBX::Voxel2::Grid> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1962f30 | Name: _ZN5boost10shared_ptrIN3RBX5MouseEED2Ev
void __fastcall boost::shared_ptr<RBX::Mouse>::~shared_ptr(boost::shared_ptr<RBX::Mouse> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x19630d0 | Name: _ZN5boost10shared_ptrIN3RBX13ModelInstanceEED2Ev
void __fastcall boost::shared_ptr<RBX::ModelInstance>::~shared_ptr(boost::shared_ptr<RBX::ModelInstance> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x19631b0 | Name: _ZN5boost10shared_ptrIN3RBX19PersistentDataStoreEED2Ev
void __fastcall boost::shared_ptr<RBX::PersistentDataStore>::~shared_ptr(
        boost::shared_ptr<RBX::PersistentDataStore> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x19633c0 | Name: _ZN5boost10shared_ptrIN6RakNet13SystemAddressEED2Ev
void __fastcall boost::shared_ptr<RakNet::SystemAddress>::~shared_ptr(boost::shared_ptr<RakNet::SystemAddress> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1963440 | Name: _ZN5boost8weak_ptrIN3RBX13SpawnLocationEED2Ev
void __fastcall boost::weak_ptr<RBX::SpawnLocation>::~weak_ptr(boost::weak_ptr<RBX::SpawnLocation> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1963470 | Name: _ZN5boost8weak_ptrIN3RBX4TeamEED2Ev
void __fastcall boost::weak_ptr<RBX::Team>::~weak_ptr(boost::weak_ptr<RBX::Team> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x19634e0 | Name: _ZN5boost8weak_ptrIN3RBX12IHasLocationEED2Ev
void __fastcall boost::weak_ptr<RBX::IHasLocation>::~weak_ptr(boost::weak_ptr<RBX::IHasLocation> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x19b2440 | Name: _ZN5boost10shared_ptrIN3RBX9GuiObjectEED2Ev
void __fastcall boost::shared_ptr<RBX::GuiObject>::~shared_ptr(boost::shared_ptr<RBX::GuiObject> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x19b2480 | Name: _ZN5boost10shared_ptrIN3RBX19IAdornableCollectorEED2Ev
void __fastcall boost::shared_ptr<RBX::IAdornableCollector>::~shared_ptr(
        boost::shared_ptr<RBX::IAdornableCollector> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x19b2550 | Name: _ZN5boost8weak_ptrIN3RBX9GuiObjectEED2Ev
void __fastcall boost::weak_ptr<RBX::GuiObject>::~weak_ptr(boost::weak_ptr<RBX::GuiObject> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1a2d500 | Name: _ZN5boost10shared_ptrIN3RBX13PluginManagerEED2Ev
void __fastcall boost::shared_ptr<RBX::PluginManager>::~shared_ptr(boost::shared_ptr<RBX::PluginManager> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1a9b930 | Name: _ZN3RBX14ScrollingFrame19getParentScrollableEv
_QWORD *__fastcall RBX::ScrollingFrame::getParentScrollable(_QWORD *a1, RBX::ScrollingFrame *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 292);
  v2 = *((_QWORD *)this + 293);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 12), 1u);
  return a1;
}


// Address: 0x1a9b960 | Name: _ZThn1368_N3RBX14ScrollingFrame19getParentScrollableEv
void __fastcall `non-virtual thunk to'RBX::ScrollingFrame::getParentScrollable(_QWORD *a1, RBX::ScrollingFrame *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 121);
  v2 = *((_QWORD *)this + 122);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 12), 1u);
}


// Address: 0x1bbc940 | Name: _ZN5boost10shared_ptrIN3RBX19ParameterizeHandlerEED2Ev
void __fastcall boost::shared_ptr<RBX::ParameterizeHandler>::~shared_ptr(
        boost::shared_ptr<RBX::ParameterizeHandler> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1bbc980 | Name: _ZN5boost10shared_ptrIN3RBX15UsernameHandlerEED2Ev
void __fastcall boost::shared_ptr<RBX::UsernameHandler>::~shared_ptr(boost::shared_ptr<RBX::UsernameHandler> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1c30a90 | Name: _ZN5boost10shared_ptrIN3RBX10VideoFrame7LoadJobEED2Ev
void __fastcall boost::shared_ptr<RBX::VideoFrame::LoadJob>::~shared_ptr(
        boost::shared_ptr<RBX::VideoFrame::LoadJob> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1c30ad0 | Name: _ZN5boost10shared_ptrIN3RBX8VideoJobEED2Ev
void __fastcall boost::shared_ptr<RBX::VideoJob>::~shared_ptr(boost::shared_ptr<RBX::VideoJob> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1c30c30 | Name: _ZN5boost10shared_ptrIN3RBX11VideoStreamEED2Ev
void __fastcall boost::shared_ptr<RBX::VideoStream>::~shared_ptr(boost::shared_ptr<RBX::VideoStream> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1c4e070 | Name: _ZN5boost8weak_ptrIN3RBX10SurfaceGuiEED2Ev
void __fastcall boost::weak_ptr<RBX::SurfaceGui>::~weak_ptr(boost::weak_ptr<RBX::SurfaceGui> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1c4e0b0 | Name: _ZN5boost10shared_ptrIN3RBX6CameraEED2Ev
void __fastcall boost::shared_ptr<RBX::Camera>::~shared_ptr(boost::shared_ptr<RBX::Camera> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1c4e0f0 | Name: _ZN5boost10shared_ptrIN3RBX11InputObjectEED2Ev
void __fastcall boost::shared_ptr<RBX::InputObject>::~shared_ptr(boost::shared_ptr<RBX::InputObject> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1c4e130 | Name: _ZN5boost10shared_ptrIN3RBX12MouseCommandEED2Ev
void __fastcall boost::shared_ptr<RBX::MouseCommand>::~shared_ptr(boost::shared_ptr<RBX::MouseCommand> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1c58c30 | Name: _ZN5boost8weak_ptrIN3RBX8InstanceEEaSINS1_12PartInstanceEEERS3_ONS0_IT_EE
boost::weak_ptr<RBX::Instance> *__fastcall boost::weak_ptr<RBX::Instance>::operator=<RBX::PartInstance>(
        boost::weak_ptr<RBX::Instance> *this,
        boost::weak_ptr<RBX::PartInstance> *r)
{
  boost::detail::sp_counted_base *pi; // rbx
  signed __int32 use_count; // eax
  boost::weak_ptr<RBX::PartInstance>::element_type *px; // r12
  signed __int32 v6; // ett
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *v8; // rdi

  pi = r->pn.pi_;
  if ( pi )
  {
    use_count = pi->use_count_;
    px = 0;
    while ( use_count )
    {
      v6 = use_count;
      use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
      if ( v6 == use_count )
      {
        px = r->px;
        if ( !_InterlockedSub(&pi->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
        break;
      }
    }
  }
  else
  {
    px = 0;
  }
  v7 = r->pn.pi_;
  *r = 0;
  this->px = px;
  v8 = this->pn.pi_;
  this->pn.pi_ = v7;
  if ( v8 && !_InterlockedSub(&v8->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
  return this;
}


// Address: 0x1cb6170 | Name: _ZN5boost10shared_ptrIN3RBX27MessagingServiceAnalysisJobEED2Ev
void __fastcall boost::shared_ptr<RBX::MessagingServiceAnalysisJob>::~shared_ptr(
        boost::shared_ptr<RBX::MessagingServiceAnalysisJob> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1ceec70 | Name: _ZN3RBX12UIPageLayout19getParentScrollableEv
_QWORD *__fastcall RBX::UIPageLayout::getParentScrollable(_QWORD *a1, RBX::UIPageLayout *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 75);
  v2 = *((_QWORD *)this + 76);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 12), 1u);
  return a1;
}


// Address: 0x1ceeca0 | Name: _ZThn280_N3RBX12UIPageLayout19getParentScrollableEv
void __fastcall `non-virtual thunk to'RBX::UIPageLayout::getParentScrollable(_QWORD *a1, RBX::UIPageLayout *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 40);
  v2 = *((_QWORD *)this + 41);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 12), 1u);
}


// Address: 0x1cf60b0 | Name: _ZN5boost8weak_ptrIN3RBX9GuiBase2dEEaSINS1_9GuiObjectEEERS3_ONS0_IT_EE
boost::weak_ptr<RBX::GuiBase2d> *__fastcall boost::weak_ptr<RBX::GuiBase2d>::operator=<RBX::GuiObject>(
        boost::weak_ptr<RBX::GuiBase2d> *this,
        boost::weak_ptr<RBX::GuiObject> *r)
{
  boost::detail::sp_counted_base *pi; // rbx
  signed __int32 use_count; // eax
  boost::weak_ptr<RBX::GuiObject>::element_type *px; // r12
  signed __int32 v6; // ett
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *v8; // rdi

  pi = r->pn.pi_;
  if ( pi )
  {
    use_count = pi->use_count_;
    px = 0;
    while ( use_count )
    {
      v6 = use_count;
      use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
      if ( v6 == use_count )
      {
        px = r->px;
        if ( !_InterlockedSub(&pi->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
        break;
      }
    }
  }
  else
  {
    px = 0;
  }
  v7 = r->pn.pi_;
  *r = 0;
  this->px = px;
  v8 = this->pn.pi_;
  this->pn.pi_ = v7;
  if ( v8 && !_InterlockedSub(&v8->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
  return this;
}


// Address: 0x1df13d0 | Name: _ZN5boost10shared_ptrI16btCollisionShapeED2Ev
void __fastcall boost::shared_ptr<btCollisionShape>::~shared_ptr(boost::shared_ptr<btCollisionShape> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1e39640 | Name: _ZN5boost10shared_ptrIN3RBX14ChunkMeshShapeEED2Ev
void __fastcall boost::shared_ptr<RBX::ChunkMeshShape>::~shared_ptr(boost::shared_ptr<RBX::ChunkMeshShape> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f154e0 | Name: _ZN5boost8weak_ptrIN3RBX10LayoutNodeEED2Ev
void __fastcall boost::weak_ptr<RBX::LayoutNode>::~weak_ptr(boost::weak_ptr<RBX::LayoutNode> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f155d0 | Name: _ZN5boost10shared_ptrIN3RBX10LayoutNodeEED2Ev
void __fastcall boost::shared_ptr<RBX::LayoutNode>::~shared_ptr(boost::shared_ptr<RBX::LayoutNode> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


