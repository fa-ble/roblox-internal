// Address: 0xe42140 | Name: _ZN5boost15program_options22error_with_option_nameD2Ev
void __fastcall boost::program_options::error_with_option_name::~error_with_option_name(
        boost::program_options::error_with_option_name *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
}


// Address: 0xe42460 | Name: _ZN5boost15program_options22error_with_option_name15set_option_nameERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall boost::program_options::error_with_option_name::set_option_name(
        boost::program_options::error_with_option_name *this,
        const std::string *option_name)
{
  std::pair<std::__tree_iterator<std::__value_type<std::string,std::string >,std::__tree_node<std::__value_type<std::string,std::string >,void *> *,long>,bool> v2; // rax
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9
  std::tuple<> __args; // [rsp+8h] [rbp-30h] BYREF
  char v7; // [rsp+10h] [rbp-28h] BYREF
  char v8[7]; // [rsp+11h] [rbp-27h] BYREF
  void *ptr[2]; // [rsp+18h] [rbp-20h]
  std::tuple<const std::string &> v10; // [rsp+28h] [rbp-10h] BYREF

  *(_OWORD *)ptr = 0;
  v7 = 12;
  strcpy(v8, "option");
  v10.__base_.__value_ = (const std::string *)&v7;
  v2 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
         (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
       + 1,
         (const std::string *)&v7,
         &stru_4974E0,
         &v10,
         &__args);
  std::string::operator=((soap *)&v2.first.__ptr_[7], (int)option_name, *(int *)&v2.second, v3, v4, v5);
  if ( (v7 & 1) != 0 )
    operator delete(ptr[1]);
}


// Address: 0xe42730 | Name: _ZN5boost15program_options22error_with_option_nameC2ERKS1_
void __fastcall boost::program_options::error_with_option_name::error_with_option_name(
        boost::program_options::error_with_option_name *this,
        const boost::program_options::error_with_option_name *a2)
{
  const boost::program_options::error_with_option_name *v2; // rbp
  const boost::program_options::error_with_option_name *v3; // rcx
  const boost::program_options::error_with_option_name *v4; // rax
  __int64 v5; // rbp
  bool v6; // zf
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *v7; // rbx
  char *v8; // rbp
  char *v9; // r13
  char *v10; // r14
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_base_pointer *v11; // r15
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__parent_pointer v12; // rax
  std::__tree_node_base<void *> *value; // rsi
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer left; // rax
  char *v15; // rcx
  char *v16; // rax
  __int64 v17; // r13
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__parent_pointer __parent; // [rsp+30h] [rbp-58h] BYREF
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_base_pointer __dummy; // [rsp+38h] [rbp-50h] BYREF
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_holder v21; // [rsp+40h] [rbp-48h] BYREF

  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_287DDC0;
  *((_DWORD *)this + 4) = *((_DWORD *)a2 + 4);
  *((_OWORD *)this + 2) = 0;
  *((_QWORD *)this + 3) = (char *)this + 32;
  v2 = (const boost::program_options::error_with_option_name *)*((_QWORD *)a2 + 3);
  if ( v2 != (const boost::program_options::error_with_option_name *)((char *)a2 + 32) )
  {
    do
    {
      std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_hint_unique_key_args<std::string,std::pair<std::string const,std::string> const&>(
        (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
      + 1,
        (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::const_iterator)((char *)this + 32),
        (const boost::program_options::error_with_option_name *)((char *)v2 + 32),
        (const boost::program_options::error_with_option_name *)((char *)v2 + 32));
      v3 = (const boost::program_options::error_with_option_name *)*((_QWORD *)v2 + 1);
      if ( v3 )
      {
        do
        {
          v4 = v3;
          v3 = *(const boost::program_options::error_with_option_name **)v3;
        }
        while ( v3 );
      }
      else
      {
        v4 = (const boost::program_options::error_with_option_name *)*((_QWORD *)v2 + 2);
        if ( *(const boost::program_options::error_with_option_name **)v4 != v2 )
        {
          v5 = (__int64)v2 + 16;
          do
          {
            v4 = *(const boost::program_options::error_with_option_name **)(*(_QWORD *)v5 + 16LL);
            v6 = *(_QWORD *)v4 == *(_QWORD *)v5;
            v5 = *(_QWORD *)v5 + 16LL;
          }
          while ( !v6 );
        }
      }
      v2 = v4;
    }
    while ( v4 != (const boost::program_options::error_with_option_name *)((char *)a2 + 32) );
  }
  v7 = (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)((char *)this + 48);
  v8 = (char *)this + 56;
  *(_OWORD *)((char *)this + 56) = 0;
  *((_QWORD *)this + 6) = (char *)this + 56;
  v9 = (char *)*((_QWORD *)a2 + 6);
  v10 = (char *)a2 + 56;
  if ( v9 != (char *)a2 + 56 )
  {
    do
    {
      v11 = std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::__find_equal<std::string>(
              v7,
              (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::const_iterator)v8,
              &__parent,
              &__dummy,
              (const std::string *)(v9 + 32));
      if ( !*v11 )
      {
        std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::__construct_node<std::pair<std::string const,std::pair<std::string,std::string>> const&>(
          &v21,
          v7,
          (const std::pair<const std::string,std::pair<std::string,std::string > > *)(v9 + 32));
        v12 = __parent;
        value = (std::__tree_node_base<void *> *)v21.__ptr_.__value_;
        *(_OWORD *)v21.__ptr_.__value_ = 0;
        value->__parent_ = v12;
        *v11 = value;
        left = v7->__begin_node_->__left_;
        if ( left )
        {
          v7->__begin_node_ = left;
          value = *v11;
        }
        std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(
          *((std::__tree_node_base<void *> **)this + 7),
          value);
        ++*((_QWORD *)this + 8);
        v8 = (char *)this + 56;
      }
      v15 = (char *)*((_QWORD *)v9 + 1);
      if ( v15 )
      {
        do
        {
          v16 = v15;
          v15 = *(char **)v15;
        }
        while ( v15 );
      }
      else
      {
        v16 = (char *)*((_QWORD *)v9 + 2);
        if ( *(char **)v16 != v9 )
        {
          v17 = (__int64)(v9 + 16);
          do
          {
            v16 = *(char **)(*(_QWORD *)v17 + 16LL);
            v6 = *(_QWORD *)v16 == *(_QWORD *)v17;
            v17 = *(_QWORD *)v17 + 16LL;
          }
          while ( !v6 );
        }
      }
      v9 = v16;
    }
    while ( v16 != v10 );
  }
  std::string::basic_string((char *)this + 72, (char *)a2 + 72);
  std::string::basic_string((char *)this + 96, (char *)a2 + 96);
}


// Address: 0xe42990 | Name: _ZN5boost15program_options16validation_errorD0Ev
void __fastcall boost::program_options::validation_error::~validation_error(
        boost::program_options::validation_error *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe43f90 | Name: _ZN5boost15program_options20invalid_option_valueD0Ev
void __fastcall boost::program_options::invalid_option_value::~invalid_option_value(
        boost::program_options::invalid_option_value *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe58740 | Name: _ZN5boost15program_options14unknown_optionC2ERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall boost::program_options::unknown_option::unknown_option(
        boost::program_options::unknown_option *this,
        const std::string *original_token)
{
  __int128 v2; // [rsp+0h] [rbp-48h] BYREF
  void *v3; // [rsp+10h] [rbp-38h]
  __int128 v4; // [rsp+20h] [rbp-28h] BYREF
  void *ptr; // [rsp+30h] [rbp-18h]

  v3 = operator new(0x30u);
  v2 = *(_OWORD *)&xmmword_3E5060;
  strcpy((char *)v3, "unrecognised option '%canonical_option%'");
  v4 = 0;
  ptr = 0;
  boost::program_options::error_with_option_name::error_with_option_name(
    this,
    (const std::string *)&v2,
    (const std::string *)&v4,
    original_token,
    0);
  if ( (v4 & 1) != 0 )
    operator delete(ptr);
  *(_QWORD *)this = off_287CFD8;
  if ( (v2 & 1) != 0 )
    operator delete(v3);
  *(_QWORD *)this = off_287CF68;
}


// Address: 0xe58950 | Name: _ZN5boost15program_options27invalid_command_line_syntaxC2ENS0_14invalid_syntax6kind_tERKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEESC_i
void __fastcall boost::program_options::invalid_command_line_syntax::invalid_command_line_syntax(
        boost::program_options::invalid_command_line_syntax *this,
        boost::program_options::invalid_syntax::kind_t kind,
        const std::string *option_name,
        const std::string *original_token,
        int option_style)
{
  boost::program_options::invalid_syntax::kind_t v7; // ebp
  const char *v8; // r14
  size_t v9; // rax
  size_t v10; // r15
  char *v11; // r12
  int v12; // ebp
  size_t v13; // r13
  struct _Unwind_Exception *v14; // rbx
  __int128 dest; // [rsp+0h] [rbp-68h] BYREF
  void *ptr; // [rsp+10h] [rbp-58h]
  __int64 v17; // [rsp+20h] [rbp-48h]
  std::string *v18; // [rsp+28h] [rbp-40h]
  std::string *v19; // [rsp+30h] [rbp-38h]

  v18 = option_name;
  v7 = kind;
  *(_QWORD *)this = off_287D088;
  if ( (unsigned int)(kind - 30) > 6 )
    v8 = "unknown command line syntax error for '%s'";
  else
    v8 = (&off_287D6F0)[kind - 30];
  dest = 0;
  ptr = 0;
  v9 = strlen(v8);
  if ( v9 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    v14 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(&dest);
    if ( (dest & 1) != 0 )
      operator delete(ptr);
    _Unwind_Resume(v14);
  }
  v10 = v9;
  v19 = original_token;
  if ( v9 >= 0x17 )
  {
    v17 = (unsigned int)kind;
    v12 = option_style;
    v13 = (v9 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v11 = (char *)operator new(v13);
    ptr = v11;
    *(_QWORD *)&dest = v13 | 1;
    option_style = v12;
    v7 = kind;
    *((_QWORD *)&dest + 1) = v10;
    goto LABEL_9;
  }
  LOBYTE(dest) = 2 * v9;
  v11 = (char *)&dest + 1;
  if ( v9 )
LABEL_9:
    memcpy(v11, v8, v10);
  v11[v10] = 0;
  boost::program_options::error_with_option_name::error_with_option_name(
    this,
    (const std::string *)&dest,
    v18,
    v19,
    option_style);
  if ( (dest & 1) != 0 )
    operator delete(ptr);
  *((_DWORD *)this + 30) = v7;
  *(_QWORD *)this = off_287D010;
}


// Address: 0xe58bf0 | Name: _ZN5boost15program_options26invalid_command_line_styleD0Ev
void __fastcall boost::program_options::invalid_command_line_style::~invalid_command_line_style(
        boost::program_options::invalid_command_line_style *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe58c10 | Name: _ZN5boost15program_options5errorD0Ev
void __fastcall boost::program_options::error::~error(boost::program_options::error *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe58c30 | Name: _ZN5boost15program_options22error_with_option_name18set_original_tokenERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall boost::program_options::error_with_option_name::set_original_token(
        boost::program_options::error_with_option_name *this,
        const std::string *original_token)
{
  std::pair<std::__tree_iterator<std::__value_type<std::string,std::string >,std::__tree_node<std::__value_type<std::string,std::string >,void *> *,long>,bool> v2; // rax
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9
  std::tuple<> __args; // [rsp+8h] [rbp-30h] BYREF
  char v7; // [rsp+10h] [rbp-28h] BYREF
  char v8[15]; // [rsp+11h] [rbp-27h] BYREF
  void *ptr; // [rsp+20h] [rbp-18h]
  std::tuple<const std::string &> v10; // [rsp+28h] [rbp-10h] BYREF

  ptr = 0;
  v7 = 28;
  strcpy(v8, "original_token");
  v10.__base_.__value_ = (const std::string *)&v7;
  v2 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
         (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
       + 1,
         (const std::string *)&v7,
         &stru_498610,
         &v10,
         &__args);
  std::string::operator=((soap *)&v2.first.__ptr_[7], (int)original_token, *(int *)&v2.second, v3, v4, v5);
  if ( (v7 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0xe58cd0 | Name: _ZN5boost15program_options33too_many_positional_options_errorD0Ev
void __fastcall boost::program_options::too_many_positional_options_error::~too_many_positional_options_error(
        boost::program_options::too_many_positional_options_error *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe58cf0 | Name: _ZN5boost15program_options14unknown_optionD0Ev
void __fastcall boost::program_options::unknown_option::~unknown_option(boost::program_options::unknown_option *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe58d50 | Name: _ZN5boost15program_options25error_with_no_option_name15set_option_nameERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall boost::program_options::error_with_no_option_name::set_option_name(
        boost::program_options::error_with_no_option_name *this,
        const std::string *a2)
{
  ;
}


// Address: 0xe58d60 | Name: _ZN5boost15program_options25error_with_no_option_nameD0Ev
void __fastcall boost::program_options::error_with_no_option_name::~error_with_no_option_name(
        boost::program_options::error_with_no_option_name *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe58dc0 | Name: _ZN5boost15program_options27invalid_command_line_syntaxD0Ev
void __fastcall boost::program_options::invalid_command_line_syntax::~invalid_command_line_syntax(
        boost::program_options::invalid_command_line_syntax *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe58e20 | Name: _ZNK5boost15program_options14invalid_syntax6tokensEv
boost::program_options::invalid_syntax *__fastcall boost::program_options::invalid_syntax::tokens(
        boost::program_options::invalid_syntax *this)
{
  boost::program_options::error_with_option_name::get_canonical_option_name(this);
  return this;
}


// Address: 0xe58e2e | Name: sub_E58E2E
void __fastcall __noreturn sub_E58E2E()
{
  void *v0; // rax

  __cxa_call_unexpected(v0);
}


// Address: 0xe58e40 | Name: _ZN5boost15program_options14invalid_syntaxD0Ev
void __fastcall boost::program_options::invalid_syntax::~invalid_syntax(boost::program_options::invalid_syntax *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe5fd50 | Name: _ZN5boost15program_options16ambiguous_optionC2ERKNSt3__16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEE
void __fastcall boost::program_options::ambiguous_option::ambiguous_option(
        boost::program_options::ambiguous_option *this,
        const std::vector<std::string> *xalternatives)
{
  __int128 v2; // [rsp+0h] [rbp-68h] BYREF
  void *v3; // [rsp+10h] [rbp-58h]
  __int128 v4; // [rsp+20h] [rbp-48h] BYREF
  void *v5; // [rsp+30h] [rbp-38h]
  __int128 v6; // [rsp+40h] [rbp-28h] BYREF
  void *ptr; // [rsp+50h] [rbp-18h]

  v5 = operator new(0x30u);
  v4 = *(_OWORD *)&xmmword_3E5060;
  strcpy((char *)v5, "option '%canonical_option%' is ambiguous");
  v2 = 0;
  v3 = 0;
  v6 = 0;
  ptr = 0;
  boost::program_options::error_with_option_name::error_with_option_name(
    this,
    (const std::string *)&v4,
    (const std::string *)&v6,
    (const std::string *)&v2,
    0);
  if ( (v6 & 1) != 0 )
    operator delete(ptr);
  *(_QWORD *)this = off_287CFD8;
  if ( (v2 & 1) != 0 )
    operator delete(v3);
  if ( (v4 & 1) != 0 )
    operator delete(v5);
  *(_QWORD *)this = off_287DE18;
  std::vector<std::string>::vector((boost::program_options::ambiguous_option *)((char *)this + 120), xalternatives);
}


// Address: 0xe5fee0 | Name: _ZN5boost15program_options16ambiguous_optionD2Ev
void __fastcall boost::program_options::ambiguous_option::~ambiguous_option(
        boost::program_options::ambiguous_option *this)
{
  __int64 v2; // r15
  __int64 v3; // rax
  __int64 v4; // rbx
  void *v5; // rdi

  *(_QWORD *)this = off_287DE18;
  v2 = *((_QWORD *)this + 15);
  if ( v2 )
  {
    v3 = *((_QWORD *)this + 16);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)this + 15);
    }
    else
    {
      do
      {
        v4 = v3 - 24;
        if ( (*(_BYTE *)(v3 - 24) & 1) != 0 )
          operator delete(*(void **)(v3 - 8));
        v3 = v4;
      }
      while ( v2 != v4 );
      v5 = (void *)*((_QWORD *)this + 15);
    }
    *((_QWORD *)this + 16) = v2;
    operator delete(v5);
  }
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
}


// Address: 0xe666d0 | Name: _ZN5boost15program_options20multiple_occurrencesC2Ev
void __fastcall boost::program_options::multiple_occurrences::multiple_occurrences(
        boost::program_options::multiple_occurrences *this)
{
  __int128 v1; // [rsp+0h] [rbp-68h] BYREF
  void *v2; // [rsp+10h] [rbp-58h]
  __int128 v3; // [rsp+20h] [rbp-48h] BYREF
  void *v4; // [rsp+30h] [rbp-38h]
  __int128 v5; // [rsp+40h] [rbp-28h] BYREF
  void *ptr; // [rsp+50h] [rbp-18h]

  ptr = operator new(0x40u);
  v5 = xmmword_3E7F50;
  strcpy((char *)ptr, "option '%canonical_option%' cannot be specified more than once");
  v3 = 0;
  v4 = 0;
  v1 = 0;
  v2 = 0;
  boost::program_options::error_with_option_name::error_with_option_name(
    this,
    (const std::string *)&v5,
    (const std::string *)&v3,
    (const std::string *)&v1,
    0);
  if ( (v1 & 1) == 0 )
  {
    if ( (v3 & 1) == 0 )
      goto LABEL_3;
LABEL_7:
    operator delete(v4);
    if ( (v5 & 1) == 0 )
      goto LABEL_5;
    goto LABEL_4;
  }
  operator delete(v2);
  if ( (v3 & 1) != 0 )
    goto LABEL_7;
LABEL_3:
  if ( (v5 & 1) != 0 )
LABEL_4:
    operator delete(ptr);
LABEL_5:
  *(_QWORD *)this = off_287E048;
}


// Address: 0xe66900 | Name: _ZN5boost15program_options15multiple_valuesC2Ev
void __fastcall boost::program_options::multiple_values::multiple_values(boost::program_options::multiple_values *this)
{
  __int128 v1; // [rsp+0h] [rbp-68h] BYREF
  void *v2; // [rsp+10h] [rbp-58h]
  __int128 v3; // [rsp+20h] [rbp-48h] BYREF
  void *v4; // [rsp+30h] [rbp-38h]
  __int128 v5; // [rsp+40h] [rbp-28h] BYREF
  void *ptr; // [rsp+50h] [rbp-18h]

  ptr = operator new(0x40u);
  v5 = xmmword_3E71F0;
  strcpy((char *)ptr, "option '%canonical_option%' only takes a single argument");
  v3 = 0;
  v4 = 0;
  v1 = 0;
  v2 = 0;
  boost::program_options::error_with_option_name::error_with_option_name(
    this,
    (const std::string *)&v5,
    (const std::string *)&v3,
    (const std::string *)&v1,
    0);
  if ( (v1 & 1) == 0 )
  {
    if ( (v3 & 1) == 0 )
      goto LABEL_3;
LABEL_7:
    operator delete(v4);
    if ( (v5 & 1) == 0 )
      goto LABEL_5;
    goto LABEL_4;
  }
  operator delete(v2);
  if ( (v3 & 1) != 0 )
    goto LABEL_7;
LABEL_3:
  if ( (v5 & 1) != 0 )
LABEL_4:
    operator delete(ptr);
LABEL_5:
  *(_QWORD *)this = off_287E098;
}


// Address: 0xe66d30 | Name: _ZN5boost15program_options22error_with_option_name22set_substitute_defaultERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEESA_SA_
void __fastcall boost::program_options::error_with_option_name::set_substitute_default(
        boost::program_options::error_with_option_name *this,
        const std::string *parameter_name,
        const std::string *from,
        const std::string *to)
{
  std::__tree_iterator<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__tree_node<std::__value_type<std::string,std::pair<std::string,std::string > >,void *> *,long>::__iter_pointer v5; // rax
  std::__tree_iterator<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__tree_node<std::__value_type<std::string,std::pair<std::string,std::string > >,void *> *,long>::__iter_pointer v6; // r15
  std::__tree_iterator<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__tree_node<std::__value_type<std::string,std::pair<std::string,std::string > >,void *> *,long>::__iter_pointer v7; // rbx
  std::__tree_end_node<std::__tree_node_base<void *> *> *v8; // rbx
  std::tuple<> __args; // [rsp+8h] [rbp-60h] BYREF
  __int128 v10; // [rsp+10h] [rbp-58h] BYREF
  void *ptr; // [rsp+20h] [rbp-48h]
  __int128 v12; // [rsp+28h] [rbp-40h] BYREF
  void *v13; // [rsp+38h] [rbp-30h]
  std::tuple<const std::string &> v14; // [rsp+40h] [rbp-28h] BYREF

  std::string::basic_string(&v10, from);
  std::string::basic_string(&v12, to);
  v14.__base_.__value_ = parameter_name;
  v5 = std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
         (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
       + 2,
         parameter_name,
         &stru_49910C,
         &v14,
         &__args).first.__ptr_;
  v6 = v5;
  v7 = v5 + 7;
  if ( ((__int64)v5[7].__left_ & 1) != 0 )
  {
    LOBYTE(v5[9].__left_->__left_) = 0;
    v5[8].__left_ = 0;
  }
  else
  {
    LOWORD(v7->__left_) = 0;
  }
  std::string::reserve(v7, 0);
  v7[2].__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)ptr;
  *(_OWORD *)&v7->__left_ = v10;
  v10 = 0;
  ptr = 0;
  v8 = v6 + 10;
  if ( ((__int64)v6[10].__left_ & 1) != 0 )
  {
    LOBYTE(v6[12].__left_->__left_) = 0;
    v6[11].__left_ = 0;
  }
  else
  {
    LOWORD(v8->__left_) = 0;
  }
  std::string::reserve(&v6[10], 0);
  v6[12].__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v13;
  *(_OWORD *)&v8->__left_ = v12;
  v12 = 0;
  v13 = 0;
  if ( (v10 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0xe67100 | Name: _ZN5boost15program_options22error_with_option_nameD0Ev
void __fastcall boost::program_options::error_with_option_name::~error_with_option_name(
        boost::program_options::error_with_option_name *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe67160 | Name: _ZN5boost15program_options16ambiguous_optionD0Ev
void __fastcall boost::program_options::ambiguous_option::~ambiguous_option(
        boost::program_options::ambiguous_option *this)
{
  __int64 v2; // r15
  __int64 v3; // rax
  __int64 v4; // rbx
  void *v5; // rdi

  *(_QWORD *)this = off_287DE18;
  v2 = *((_QWORD *)this + 15);
  if ( v2 )
  {
    v3 = *((_QWORD *)this + 16);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)this + 15);
    }
    else
    {
      do
      {
        v4 = v3 - 24;
        if ( (*(_BYTE *)(v3 - 24) & 1) != 0 )
          operator delete(*(void **)(v3 - 8));
        v3 = v4;
      }
      while ( v2 != v4 );
      v5 = (void *)*((_QWORD *)this + 15);
    }
    *((_QWORD *)this + 16) = v2;
    operator delete(v5);
  }
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe672a0 | Name: _ZN5boost15program_options18invalid_bool_valueD0Ev
void __fastcall boost::program_options::invalid_bool_value::~invalid_bool_value(
        boost::program_options::invalid_bool_value *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe67300 | Name: _ZN5boost15program_options20multiple_occurrencesD0Ev
void __fastcall boost::program_options::multiple_occurrences::~multiple_occurrences(
        boost::program_options::multiple_occurrences *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe67360 | Name: _ZN5boost15program_options15multiple_valuesD0Ev
void __fastcall boost::program_options::multiple_values::~multiple_values(
        boost::program_options::multiple_values *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe68740 | Name: _ZN5boost15program_options16validation_errorC2ENS1_6kind_tERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEESB_i
void __fastcall boost::program_options::validation_error::validation_error(
        boost::program_options::validation_error *this,
        boost::program_options::validation_error::kind_t kind,
        const std::string *option_name,
        const std::string *original_token,
        int option_style)
{
  __int32 v7; // esi
  const char *v8; // r12
  size_t v9; // rax
  size_t v10; // rbx
  char *v11; // r14
  int v12; // ebp
  size_t v13; // r15
  struct _Unwind_Exception *v14; // rbx
  __int128 dest; // [rsp+0h] [rbp-58h] BYREF
  void *ptr; // [rsp+10h] [rbp-48h]
  std::string *v17; // [rsp+18h] [rbp-40h]
  std::string *v18; // [rsp+20h] [rbp-38h]

  v17 = option_name;
  *(_QWORD *)this = off_287BF38;
  v7 = kind - 30;
  if ( (unsigned int)v7 > 4 )
    v8 = "unknown error";
  else
    v8 = (const char *)*((_QWORD *)&off_287DFE0 + v7);
  dest = 0;
  ptr = 0;
  v9 = strlen(v8);
  if ( v9 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    v14 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(&dest);
    if ( (dest & 1) != 0 )
      operator delete(ptr);
    _Unwind_Resume(v14);
  }
  v10 = v9;
  v18 = original_token;
  if ( v9 >= 0x17 )
  {
    v12 = option_style;
    v13 = (v9 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v11 = (char *)operator new(v13);
    ptr = v11;
    *(_QWORD *)&dest = v13 | 1;
    option_style = v12;
    *((_QWORD *)&dest + 1) = v10;
    goto LABEL_9;
  }
  LOBYTE(dest) = 2 * v9;
  v11 = (char *)&dest + 1;
  if ( v9 )
LABEL_9:
    memcpy(v11, v8, v10);
  v11[v10] = 0;
  boost::program_options::error_with_option_name::error_with_option_name(
    this,
    (const std::string *)&dest,
    v17,
    v18,
    option_style);
  if ( (dest & 1) != 0 )
    operator delete(ptr);
  *(_QWORD *)this = off_287BF38;
}


// Address: 0xe6a380 | Name: _ZN5boost15program_options15required_optionC2ERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall boost::program_options::required_option::required_option(
        boost::program_options::required_option *this,
        const std::string *option_name)
{
  __int128 v2; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  __int128 v4; // [rsp+20h] [rbp-28h] BYREF
  void *v5; // [rsp+30h] [rbp-18h]

  v5 = operator new(0x40u);
  v4 = xmmword_3E8C50;
  strcpy((char *)v5, "the option '%canonical_option%' is required but missing");
  v2 = 0;
  ptr = 0;
  boost::program_options::error_with_option_name::error_with_option_name(
    this,
    (const std::string *)&v4,
    (const std::string *)&v2,
    option_name,
    0);
  if ( (v2 & 1) != 0 )
    operator delete(ptr);
  if ( (v4 & 1) != 0 )
    operator delete(v5);
  *(_QWORD *)this = off_287E7E8;
}


// Address: 0xe6a510 | Name: _ZN5boost15program_options15required_optionD0Ev
void __fastcall boost::program_options::required_option::~required_option(
        boost::program_options::required_option *this)
{
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
  operator delete(this);
}


