// Address: 0x2604230 | Name: _ZNK5boost4asio2ip6detail8endpoint9to_stringERNS_6system10error_codeE
boost::asio::ip::detail::endpoint *__fastcall boost::asio::ip::detail::endpoint::to_string(
        boost::asio::ip::detail::endpoint *this,
        boost::system::error_code *a2,
        boost::system::error_code *a3)
{
  boost::asio::ip::detail::endpoint *v5; // r14
  int v6; // eax
  unsigned __int64 m_cat_low; // r8
  const char *v8; // rax
  const char *v9; // r15
  size_t v10; // rax
  size_t v11; // rbx
  char *v12; // rbp
  size_t v13; // r14
  __int64 v15; // rbp
  __int64 v16; // rbx
  const std::locale *v17; // rbp
  const std::locale *locale; // rbp
  const std::locale *v19; // rbp
  const char *v20; // rsi
  size_t v21; // rdx
  std::ostream *v22; // rax
  const char *v23; // rsi
  size_t v24; // rdx
  std::ostream *v25; // rax
  std::ostream *v26; // rax
  struct _Unwind_Exception *v27; // rax
  struct _Unwind_Exception *v28; // rbx
  char v29[16]; // [rsp+0h] [rbp-198h] BYREF
  void *ptr; // [rsp+10h] [rbp-188h]
  char __str[8]; // [rsp+18h] [rbp-180h] BYREF
  __int128 src; // [rsp+20h] [rbp-178h] BYREF
  unsigned __int64 v33; // [rsp+30h] [rbp-168h]
  std::locale v34; // [rsp+38h] [rbp-160h] BYREF
  boost::asio::ip::detail::endpoint *v35; // [rsp+40h] [rbp-158h]
  std::locale v36; // [rsp+48h] [rbp-150h] BYREF
  char dest[8]; // [rsp+50h] [rbp-148h] BYREF
  std::locale v38; // [rsp+58h] [rbp-140h] BYREF
  __int128 v39; // [rsp+98h] [rbp-100h]
  void *v40[2]; // [rsp+A8h] [rbp-F0h]
  int v41; // [rsp+B8h] [rbp-E0h]
  _QWORD v42[18]; // [rsp+C0h] [rbp-D8h] BYREF
  int v43; // [rsp+150h] [rbp-48h]
  unsigned __int64 v44; // [rsp+160h] [rbp-38h]

  v5 = this;
  v44 = __readfsqword(0x28u);
  if ( LOWORD(a2->m_val) != 2 )
  {
    m_cat_low = LODWORD(a2[1].m_cat);
    src = *(_OWORD *)&a2->m_cat;
    v33 = m_cat_low;
    *(_QWORD *)__str = 1;
    v8 = boost::asio::detail::socket_ops::inet_ntop(10, &src, dest, 0x3Fu, m_cat_low, a3);
    *(_OWORD *)v29 = 0;
    ptr = 0;
    if ( !v8 )
      goto LABEL_12;
    v9 = v8;
    v10 = strlen(v8);
    if ( v10 >= 0xFFFFFFFFFFFFFFF0LL )
    {
      std::__basic_string_common<true>::__throw_length_error(v29);
      v28 = v27;
      std::ostream::~ostream(dest, data);
      std::ios::~ios();
      if ( (v29[0] & 1) != 0 )
        operator delete(ptr);
      _Unwind_Resume(v28);
    }
    v11 = v10;
    if ( v10 >= 0x17 )
    {
      v35 = this;
      v13 = (v10 + 16) & 0xFFFFFFFFFFFFFFF0LL;
      v12 = (char *)operator new(v13);
      ptr = v12;
      *(_QWORD *)v29 = v13 | 1;
      v5 = v35;
      *(_QWORD *)&v29[8] = v11;
    }
    else
    {
      v29[0] = 2 * v10;
      v12 = &v29[1];
      if ( !v10 )
        goto LABEL_11;
    }
    memcpy(v12, v9, v11);
LABEL_11:
    v12[v11] = 0;
LABEL_12:
    if ( !a3->m_val )
      goto LABEL_16;
LABEL_13:
    v5->data_.base = 0;
    *(_QWORD *)&v5->data_.v6.sin6_addr.__u6_addr32[2] = 0;
    if ( (v29[0] & 1) == 0 )
      return v5;
LABEL_14:
    operator delete(ptr);
    return v5;
  }
  v6 = *(&a2->m_val + 1);
  src = 0;
  v33 = 0;
  *(_DWORD *)__str = 0;
  *(_DWORD *)&__str[4] = v6;
  boost::asio::ip::address_v4::to_string((boost::asio::ip::address_v4 *)v29, (boost::system::error_code *)&__str[4]);
  if ( a3->m_val )
    goto LABEL_13;
LABEL_16:
  *(_QWORD *)dest = &off_2876B38;
  v42[0] = &off_2876B60;
  std::ios_base::init((std::ios_base *)v42, &v38);
  v42[17] = 0;
  v43 = -1;
  *(_QWORD *)dest = &off_2876AC8;
  v42[0] = off_2876AF0;
  std::streambuf::basic_streambuf(&v38);
  v38.__locale_ = (std::locale::__imp *)&off_28753A8;
  *(_OWORD *)v40 = 0;
  v39 = 0;
  v41 = 16;
  v15 = *(_QWORD *)(*(_QWORD *)dest - 24LL);
  v16 = std::locale::classic(&v38);
  v17 = (const std::locale *)&dest[v15];
  std::ios_base::getloc((std::ios_base *)&v34);
  std::ios_base::imbue((std::ios_base *)__str, v17);
  std::locale::~locale((std::locale *)__str);
  locale = (const std::locale *)v17[5].__locale_;
  if ( locale )
  {
    (*((void (__fastcall **)(const std::locale *, __int64))locale->__locale_ + 2))(locale, v16);
    v19 = locale + 1;
    std::locale::locale(&v36, v19);
    std::locale::operator=(v19, v16);
    std::locale::~locale(&v36);
  }
  std::locale::~locale(&v34);
  if ( LOWORD(a2->m_val) == 2 )
  {
    if ( (v29[0] & 1) != 0 )
    {
      v20 = (const char *)ptr;
      v21 = *(_QWORD *)&v29[8];
    }
    else
    {
      v21 = (unsigned __int64)(unsigned __int8)v29[0] >> 1;
      v20 = &v29[1];
    }
    std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)dest, v20, v21);
  }
  else
  {
    __str[0] = 91;
    v22 = std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)dest, __str, 1u);
    if ( (v29[0] & 1) != 0 )
    {
      v23 = (const char *)ptr;
      v24 = *(_QWORD *)&v29[8];
    }
    else
    {
      v24 = (unsigned __int64)(unsigned __int8)v29[0] >> 1;
      v23 = &v29[1];
    }
    v25 = std::__put_character_sequence<char,std::char_traits<char>>(v22, v23, v24);
    __str[0] = 93;
    std::__put_character_sequence<char,std::char_traits<char>>(v25, __str, 1u);
  }
  __str[0] = 58;
  v26 = std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)dest, __str, 1u);
  std::ostream::operator<<(v26, (unsigned __int16)__ROL2__(HIWORD(a2->m_val), 8));
  std::stringbuf::str((__int64)v5, (__int64)&v38);
  *(_QWORD *)dest = &off_2876AC8;
  v42[0] = off_2876AF0;
  v38.__locale_ = (std::locale::__imp *)&off_28753A8;
  if ( (v39 & 1) != 0 )
    operator delete(v40[0]);
  std::streambuf::~streambuf();
  std::ostream::~ostream(dest, data);
  std::ios::~ios();
  if ( (v29[0] & 1) != 0 )
    goto LABEL_14;
  return v5;
}


