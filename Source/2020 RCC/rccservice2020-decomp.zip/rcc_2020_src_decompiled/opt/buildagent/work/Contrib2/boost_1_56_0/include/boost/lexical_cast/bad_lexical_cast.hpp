// Address: 0xe40f90 | Name: _ZNK5boost16bad_lexical_cast4whatEv
const char *__fastcall boost::bad_lexical_cast::what(const boost::bad_lexical_cast *this)
{
  return "bad lexical cast: source type value could not be interpreted as target";
}


// Address: 0xe412f0 | Name: _ZN5boost16bad_lexical_castD0Ev
void __fastcall boost::bad_lexical_cast::~bad_lexical_cast(boost::bad_lexical_cast *this)
{
  std::bad_cast::~bad_cast(this);
  operator delete(this);
}


