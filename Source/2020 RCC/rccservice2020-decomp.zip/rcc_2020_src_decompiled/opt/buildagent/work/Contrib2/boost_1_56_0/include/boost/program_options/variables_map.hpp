// Address: 0xe6a220 | Name: _ZN5boost15program_options14variable_valueD2Ev
void __fastcall boost::program_options::variable_value::~variable_value(boost::program_options::variable_value *this)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::any::placeholder *content; // rdi

  pi = this->m_value_semantic.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  content = this->v.content;
  if ( this->v.content )
    (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
}


// Address: 0xe6a470 | Name: _ZN5boost15program_options13variables_mapD2Ev
void __fastcall boost::program_options::variables_map::~variables_map(boost::program_options::variables_map *this)
{
  this->_vptr$abstract_variables_map = (int (**)(void))off_287E760;
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    &this->m_required.__tree_,
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer)this->m_required.__tree_.__pair1_.__value_.__left_);
  std::__tree<std::string>::destroy(
    &this->m_final.__tree_,
    (std::__tree<std::string>::__node_pointer)this->m_final.__tree_.__pair1_.__value_.__left_);
  std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value>>>::destroy(
    &this->__tree_,
    (std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > >::__node_pointer)this->__tree_.__pair1_.__value_.__left_);
}


// Address: 0xe6a4b0 | Name: _ZN5boost15program_options13variables_mapD0Ev
void __fastcall boost::program_options::variables_map::~variables_map(boost::program_options::variables_map *this)
{
  this->_vptr$abstract_variables_map = (int (**)(void))off_287E760;
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    &this->m_required.__tree_,
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer)this->m_required.__tree_.__pair1_.__value_.__left_);
  std::__tree<std::string>::destroy(
    &this->m_final.__tree_,
    (std::__tree<std::string>::__node_pointer)this->m_final.__tree_.__pair1_.__value_.__left_);
  std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value>>>::destroy(
    &this->__tree_,
    (std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > >::__node_pointer)this->__tree_.__pair1_.__value_.__left_);
  operator delete(this);
}


// Address: 0xe6a4f0 | Name: _ZN5boost15program_options22abstract_variables_mapD2Ev
void __fastcall boost::program_options::abstract_variables_map::~abstract_variables_map(
        boost::program_options::abstract_variables_map *this)
{
  ;
}


// Address: 0xe6a500 | Name: _ZN5boost15program_options22abstract_variables_mapD0Ev
void __fastcall __noreturn boost::program_options::abstract_variables_map::~abstract_variables_map(
        boost::program_options::abstract_variables_map *this)
{
  BUG();
}


