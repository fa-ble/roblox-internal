// Address: 0x261e5d0 | Name: _ZN5boost4asio6detail10scoped_ptrINS0_10io_service4workEED2Ev
void __fastcall boost::asio::detail::scoped_ptr<boost::asio::io_service::work>::~scoped_ptr(
        boost::asio::detail::scoped_ptr<boost::asio::io_service::work> *this)
{
  boost::asio::io_service::work *p; // rbx

  p = this->p_;
  if ( this->p_ )
  {
    boost::asio::io_service::work::~work(this->p_);
    operator delete(p);
  }
}


// Address: 0x261e5f0 | Name: _ZN5boost4asio6detail10scoped_ptrINS0_10io_serviceEED2Ev
void __fastcall boost::asio::detail::scoped_ptr<boost::asio::io_service>::~scoped_ptr(
        boost::asio::detail::scoped_ptr<boost::asio::io_service> *this)
{
  boost::asio::io_service *p; // rbx

  p = this->p_;
  if ( this->p_ )
  {
    boost::asio::io_service::~io_service(this->p_);
    operator delete(p);
  }
}


// Address: 0x261e9c0 | Name: _ZN5boost4asio6detail10scoped_ptrINS1_12posix_threadEED2Ev
void __fastcall boost::asio::detail::scoped_ptr<boost::asio::detail::posix_thread>::~scoped_ptr(
        boost::asio::detail::scoped_ptr<boost::asio::detail::posix_thread> *this)
{
  boost::asio::detail::posix_thread *p; // rbx

  p = this->p_;
  if ( this->p_ )
  {
    if ( !p->joined_ )
      pthread_detach(p->thread_);
    operator delete(p);
  }
}


