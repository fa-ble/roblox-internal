// Address: 0x283edb0 | Name: _ZN5boost10filesystem22codecvt_error_categoryEv
const boost::system::error_category *__cdecl boost::filesystem::codecvt_error_category()
{
  `anonymous namespace'::codecvt_error_cat *v1; // rax

  if ( !(_BYTE)byte_2CE55B0 && __cxa_guard_acquire(&byte_2CE55B0) )
  {
    v1 = (`anonymous namespace'::codecvt_error_cat *)operator new(8u);
    v1->_vptr$error_category = (int (**)(void))&off_29CFC90;
    qword_2CE55A8 = v1;
    __cxa_guard_release(&byte_2CE55B0);
  }
  return qword_2CE55A8;
}


// Address: 0x283ee20 | Name: _ZN12_GLOBAL__N_117codecvt_error_catD0Ev
// Alternative name is 'j__ZdlPv_2069'
// attributes: thunk
void __fastcall `anonymous namespace'::codecvt_error_cat::~codecvt_error_cat(
        `anonymous namespace'::codecvt_error_cat *this)
{
  operator delete(this);
}


// Address: 0x283ee30 | Name: _ZNK12_GLOBAL__N_117codecvt_error_cat4nameEv
const char *__fastcall `anonymous namespace'::codecvt_error_cat::name(
        const `anonymous namespace'::codecvt_error_cat *this)
{
  return "codecvt";
}


// Address: 0x283ee40 | Name: _ZNK12_GLOBAL__N_117codecvt_error_cat7messageEi
_anonymous_namespace_::codecvt_error_cat *__fastcall `anonymous namespace'::codecvt_error_cat::message(
        _anonymous_namespace_::codecvt_error_cat *this,
        int a2,
        int a3)
{
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  switch ( a3 )
  {
    case 0:
      std::string::assign(this, "ok");
      break;
    case 1:
      std::string::assign(this, "partial");
      break;
    case 2:
      std::string::assign(this, "error");
      break;
    case 3:
      std::string::assign(this, "noconv");
      break;
    default:
      std::string::assign(this, "unknown error");
      break;
  }
  return this;
}


