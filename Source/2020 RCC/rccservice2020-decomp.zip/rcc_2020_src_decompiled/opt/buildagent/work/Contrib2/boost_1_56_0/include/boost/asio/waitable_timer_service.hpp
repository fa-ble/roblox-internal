// Address: 0x26971c0 | Name: _ZN5boost4asio22waitable_timer_serviceINSt3__16chrono12steady_clockENS0_11wait_traitsIS4_EEED2Ev
void __fastcall boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>::~waitable_timer_service(
        boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > *this)
{
  __int64 v2; // r15
  _QWORD *v3; // rax
  _QWORD *v4; // rdx
  void *v5; // rdi

  *(_QWORD *)this = &off_29C70A8;
  v2 = *((_QWORD *)this + 11);
  pthread_mutex_lock((pthread_mutex_t *)(v2 + 48));
  v3 = *(_QWORD **)(v2 + 104);
  if ( v3 )
  {
    if ( v3 == (_QWORD *)((char *)this + 40) )
    {
      *(_QWORD *)(v2 + 104) = *((_QWORD *)this + 6);
LABEL_7:
      *((_QWORD *)this + 6) = 0;
    }
    else
    {
      while ( 1 )
      {
        v4 = v3;
        v3 = (_QWORD *)v3[1];
        if ( !v3 )
          break;
        if ( v3 == (_QWORD *)((char *)this + 40) )
        {
          v4[1] = *((_QWORD *)this + 6);
          goto LABEL_7;
        }
      }
    }
  }
  pthread_mutex_unlock((pthread_mutex_t *)(v2 + 48));
  *((_QWORD *)this + 5) = &off_29C7118;
  v5 = (void *)*((_QWORD *)this + 8);
  if ( v5 )
  {
    *((_QWORD *)this + 9) = v5;
    operator delete(v5);
  }
}


// Address: 0x2697260 | Name: _ZN5boost4asio22waitable_timer_serviceINSt3__16chrono12steady_clockENS0_11wait_traitsIS4_EEED0Ev
void __fastcall boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>::~waitable_timer_service(
        boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > *this)
{
  __int64 v2; // r15
  _QWORD *v3; // rax
  _QWORD *v4; // rdx
  void *v5; // rdi

  *(_QWORD *)this = &off_29C70A8;
  v2 = *((_QWORD *)this + 11);
  pthread_mutex_lock((pthread_mutex_t *)(v2 + 48));
  v3 = *(_QWORD **)(v2 + 104);
  if ( v3 )
  {
    if ( v3 == (_QWORD *)((char *)this + 40) )
    {
      *(_QWORD *)(v2 + 104) = *((_QWORD *)this + 6);
LABEL_7:
      *((_QWORD *)this + 6) = 0;
    }
    else
    {
      while ( 1 )
      {
        v4 = v3;
        v3 = (_QWORD *)v3[1];
        if ( !v3 )
          break;
        if ( v3 == (_QWORD *)((char *)this + 40) )
        {
          v4[1] = *((_QWORD *)this + 6);
          goto LABEL_7;
        }
      }
    }
  }
  pthread_mutex_unlock((pthread_mutex_t *)(v2 + 48));
  *((_QWORD *)this + 5) = &off_29C7118;
  v5 = (void *)*((_QWORD *)this + 8);
  if ( v5 )
  {
    *((_QWORD *)this + 9) = v5;
    operator delete(v5);
  }
  operator delete(this);
}


// Address: 0x2697300 | Name: _ZN5boost4asio22waitable_timer_serviceINSt3__16chrono12steady_clockENS0_11wait_traitsIS4_EEE16shutdown_serviceEv
void __fastcall boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>::shutdown_service(
        boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > *this)
{
  ;
}


