// Address: 0xfe7c20 | Name: _ZN5boost2CV17constrained_valueINS0_23simple_exception_policyItLt1400ELt10000ENS_9gregorian8bad_yearEEEE6assignEt
void __fastcall boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1400,(unsigned short)10000,boost::gregorian::bad_year>>::assign(
        boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1400,10000,boost::gregorian::bad_year> > *this,
        boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1400,10000,boost::gregorian::bad_year> >::value_type value)
{
  _QWORD v2[2]; // [rsp+0h] [rbp-38h] BYREF
  __int128 v3; // [rsp+10h] [rbp-28h] BYREF
  void *ptr; // [rsp+20h] [rbp-18h]

  if ( value <= 0x577u )
  {
    ptr = operator new(0x30u);
    v3 = xmmword_3E8C90;
    strcpy((char *)ptr, "Year is out of valid range: 1400..10000");
    std::logic_error::logic_error(v2, &v3);
    v2[0] = (char *)&`vtable for'std::out_of_range + 16;
    if ( (v3 & 1) != 0 )
      operator delete(ptr);
    v2[0] = off_2889BE8;
    boost::throw_exception<boost::gregorian::bad_year>((const boost::gregorian::bad_year *)v2);
  }
  if ( value >= 0x2711u )
  {
    ptr = operator new(0x30u);
    v3 = xmmword_3E8C90;
    strcpy((char *)ptr, "Year is out of valid range: 1400..10000");
    std::logic_error::logic_error(v2, &v3);
    v2[0] = (char *)&`vtable for'std::out_of_range + 16;
    if ( (v3 & 1) != 0 )
      operator delete(ptr);
    v2[0] = off_2889BE8;
    boost::throw_exception<boost::gregorian::bad_year>((const boost::gregorian::bad_year *)v2);
  }
  this->value_ = value;
}


// Address: 0xfe84e0 | Name: _ZN5boost2CV17constrained_valueINS0_23simple_exception_policyItLt1ELt12ENS_9gregorian9bad_monthEEEE6assignEt
void __fastcall boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1,(unsigned short)12,boost::gregorian::bad_month>>::assign(
        boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,12,boost::gregorian::bad_month> > *this,
        boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,12,boost::gregorian::bad_month> >::value_type value)
{
  _QWORD v2[2]; // [rsp+0h] [rbp-38h] BYREF
  __int128 v3; // [rsp+10h] [rbp-28h] BYREF
  void *ptr; // [rsp+20h] [rbp-18h]

  if ( !value )
  {
    ptr = operator new(0x30u);
    v3 = xmmword_3EB1A0;
    strcpy((char *)ptr, "Month number is out of range 1..12");
    std::logic_error::logic_error(v2, &v3);
    v2[0] = (char *)&`vtable for'std::out_of_range + 16;
    if ( (v3 & 1) != 0 )
      operator delete(ptr);
    v2[0] = off_2889D98;
    boost::throw_exception<boost::gregorian::bad_month>((const boost::gregorian::bad_month *)v2);
  }
  if ( value >= 0xDu )
  {
    ptr = operator new(0x30u);
    v3 = xmmword_3EB1A0;
    strcpy((char *)ptr, "Month number is out of range 1..12");
    std::logic_error::logic_error(v2, &v3);
    v2[0] = (char *)&`vtable for'std::out_of_range + 16;
    if ( (v3 & 1) != 0 )
      operator delete(ptr);
    v2[0] = off_2889D98;
    boost::throw_exception<boost::gregorian::bad_month>((const boost::gregorian::bad_month *)v2);
  }
  this->value_ = value;
}


// Address: 0xfe8d80 | Name: _ZN5boost2CV17constrained_valueINS0_23simple_exception_policyItLt1ELt31ENS_9gregorian16bad_day_of_monthEEEE6assignEt
void __fastcall boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1,(unsigned short)31,boost::gregorian::bad_day_of_month>>::assign(
        boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,31,boost::gregorian::bad_day_of_month> > *this,
        boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,31,boost::gregorian::bad_day_of_month> >::value_type value)
{
  _QWORD v2[2]; // [rsp+0h] [rbp-38h] BYREF
  __int128 v3; // [rsp+10h] [rbp-28h] BYREF
  void *ptr; // [rsp+20h] [rbp-18h]

  if ( !value )
  {
    ptr = operator new(0x30u);
    v3 = *(_OWORD *)&xmmword_3E5060;
    strcpy((char *)ptr, "Day of month value is out of range 1..31");
    std::logic_error::logic_error(v2, &v3);
    v2[0] = (char *)&`vtable for'std::out_of_range + 16;
    if ( (v3 & 1) != 0 )
      operator delete(ptr);
    v2[0] = off_2889F48;
    boost::throw_exception<boost::gregorian::bad_day_of_month>((const boost::gregorian::bad_day_of_month *)v2);
  }
  if ( value >= 0x20u )
  {
    ptr = operator new(0x30u);
    v3 = *(_OWORD *)&xmmword_3E5060;
    strcpy((char *)ptr, "Day of month value is out of range 1..31");
    std::logic_error::logic_error(v2, &v3);
    v2[0] = (char *)&`vtable for'std::out_of_range + 16;
    if ( (v3 & 1) != 0 )
      operator delete(ptr);
    v2[0] = off_2889F48;
    boost::throw_exception<boost::gregorian::bad_day_of_month>((const boost::gregorian::bad_day_of_month *)v2);
  }
  this->value_ = value;
}


