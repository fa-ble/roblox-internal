// Address: 0xefa8e0 | Name: _ZN5boost10filesystem18directory_iteratorC2ERKNS0_4pathE
void __fastcall boost::filesystem::directory_iterator::directory_iterator(
        boost::filesystem::directory_iterator *this,
        const boost::filesystem::path *p)
{
  char *v2; // rax

  v2 = (char *)operator new(0x38u);
  *(_OWORD *)(v2 + 12) = 0;
  *(_OWORD *)v2 = 0;
  *(_QWORD *)(v2 + 28) = 0xFFFF;
  *((_DWORD *)v2 + 9) = 0xFFFF;
  *(_OWORD *)(v2 + 40) = 0;
  boost::shared_ptr<boost::filesystem::detail::dir_itr_imp>::shared_ptr<boost::filesystem::detail::dir_itr_imp>(
    &this->m_imp,
    (boost::filesystem::detail::dir_itr_imp *)v2);
  boost::filesystem::detail::directory_iterator_construct(this, p, 0);
}


// Address: 0x12766d0 | Name: _ZN5boost10filesystem18directory_iteratorC2ERKNS0_4pathERNS_6system10error_codeE
void __fastcall boost::filesystem::directory_iterator::directory_iterator(
        boost::filesystem::directory_iterator *this,
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  char *v4; // rax

  v4 = (char *)operator new(0x38u);
  *(_OWORD *)(v4 + 12) = 0;
  *(_OWORD *)v4 = 0;
  *(_QWORD *)(v4 + 28) = 0xFFFF;
  *((_DWORD *)v4 + 9) = 0xFFFF;
  *(_OWORD *)(v4 + 40) = 0;
  boost::shared_ptr<boost::filesystem::detail::dir_itr_imp>::shared_ptr<boost::filesystem::detail::dir_itr_imp>(
    &this->m_imp,
    (boost::filesystem::detail::dir_itr_imp *)v4);
  boost::filesystem::detail::directory_iterator_construct(this, p, ec);
}


// Address: 0x27caa80 | Name: _ZN3RBX10FileSystem26removeAllowImmediateReopenERKN5boost10filesystem4pathERNS1_6system10error_codeE
// attributes: thunk
void __fastcall RBX::FileSystem::removeAllowImmediateReopen(
        const boost::filesystem::path *path,
        boost::system::error_code *ec)
{
  boost::filesystem::detail::remove(path, ec);
}


// Address: 0x283dae0 | Name: _ZN5boost10filesystem18directory_iteratorD2Ev
void __fastcall boost::filesystem::directory_iterator::~directory_iterator(boost::filesystem::directory_iterator *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->m_imp.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x283db20 | Name: _ZN5boost10filesystem16filesystem_errorC2ERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEERKNS0_4pathENS_6system10error_codeE
void __fastcall boost::filesystem::filesystem_error::filesystem_error(
        boost::filesystem::filesystem_error *this,
        const std::string *what_arg,
        const boost::filesystem::path *path1_arg,
        boost::system::error_code ec)
{
  const boost::system::error_category *m_cat; // rbx
  int m_val; // ebp
  int v6; // r15d
  _OWORD *v7; // rax
  int v8; // edx
  void *v9; // rcx
  size_t v10; // r8
  const void *v11; // r9
  __m128i v12; // xmm0
  volatile signed __int32 *v13; // xmm0_8
  __m128i v14; // [rsp+0h] [rbp-38h] BYREF

  m_cat = ec.m_cat;
  m_val = ec.m_val;
  v6 = (int)path1_arg;
  std::runtime_error::runtime_error(this, what_arg);
  *((_DWORD *)this + 4) = m_val;
  *((_QWORD *)this + 3) = m_cat;
  *((_OWORD *)this + 2) = 0;
  *((_QWORD *)this + 6) = 0;
  *(_QWORD *)this = off_29CFC08;
  *(_OWORD *)((char *)this + 56) = 0;
  v7 = operator new(0x48u);
  v7[3] = 0;
  v7[2] = 0;
  v7[1] = 0;
  *v7 = 0;
  *((_QWORD *)v7 + 8) = 0;
  boost::shared_ptr<boost::filesystem::filesystem_error::m_imp>::shared_ptr<boost::filesystem::filesystem_error::m_imp>(
    (boost::shared_ptr<boost::filesystem::filesystem_error::m_imp> *)&v14,
    (boost::filesystem::filesystem_error::m_imp *)v7);
  v12 = _mm_loadu_si128((const __m128i *)((char *)this + 56));
  *(__m128i *)((char *)this + 56) = v14;
  v14 = v12;
  v13 = (volatile signed __int32 *)_mm_shuffle_epi32(v12, 78).m128i_u64[0];
  if ( v13 )
  {
    if ( !_InterlockedSub(v13 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v13 + 16LL))(v13, *(double *)&v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  std::string::operator=(*((soap **)this + 7), v6, v8, v9, v10, v11);
}


// Address: 0x283dc80 | Name: _ZN5boost10filesystem16filesystem_errorD2Ev
void __fastcall boost::filesystem::filesystem_error::~filesystem_error(boost::filesystem::filesystem_error *this)
{
  volatile signed __int32 *v1; // r14

  *(_QWORD *)this = off_29CFC08;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 8);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
}


// Address: 0x283dcf0 | Name: _ZN5boost10filesystem16filesystem_errorC2ERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEERKNS0_4pathESD_NS_6system10error_codeE
void __fastcall boost::filesystem::filesystem_error::filesystem_error(
        boost::filesystem::filesystem_error *this,
        const std::string *what_arg,
        const boost::filesystem::path *path1_arg,
        const boost::filesystem::path *path2_arg,
        boost::system::error_code ec)
{
  const boost::system::error_category *m_cat; // rbx
  int m_val; // ebp
  int v7; // r15d
  int v8; // r12d
  soap **v9; // r14
  _OWORD *v10; // rax
  int v11; // edx
  void *v12; // rcx
  size_t v13; // r8
  const void *v14; // r9
  __m128i v15; // xmm0
  volatile signed __int32 *v16; // xmm0_8
  int v17; // edx
  void *v18; // rcx
  size_t v19; // r8
  const void *v20; // r9
  __m128i v21; // [rsp+0h] [rbp-48h] BYREF

  m_cat = ec.m_cat;
  m_val = ec.m_val;
  v7 = (int)path2_arg;
  v8 = (int)path1_arg;
  std::runtime_error::runtime_error(this, what_arg);
  *((_DWORD *)this + 4) = m_val;
  *((_QWORD *)this + 3) = m_cat;
  *((_OWORD *)this + 2) = 0;
  *((_QWORD *)this + 6) = 0;
  *(_QWORD *)this = off_29CFC08;
  v9 = (soap **)((char *)this + 56);
  *(_OWORD *)((char *)this + 56) = 0;
  v10 = operator new(0x48u);
  v10[3] = 0;
  v10[2] = 0;
  v10[1] = 0;
  *v10 = 0;
  *((_QWORD *)v10 + 8) = 0;
  boost::shared_ptr<boost::filesystem::filesystem_error::m_imp>::shared_ptr<boost::filesystem::filesystem_error::m_imp>(
    (boost::shared_ptr<boost::filesystem::filesystem_error::m_imp> *)&v21,
    (boost::filesystem::filesystem_error::m_imp *)v10);
  v15 = _mm_loadu_si128((const __m128i *)((char *)this + 56));
  *(__m128i *)((char *)this + 56) = v21;
  v21 = v15;
  v16 = (volatile signed __int32 *)_mm_shuffle_epi32(v15, 78).m128i_u64[0];
  if ( v16 )
  {
    if ( !_InterlockedSub(v16 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v16 + 16LL))(v16, *(double *)&v16);
      if ( !_InterlockedSub(v16 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
    }
  }
  std::string::operator=(*v9, v8, v11, v12, v13, v14);
  std::string::operator=((soap *)&(*v9)->float_format, v7, v17, v18, v19, v20);
}


// Address: 0x283e0c0 | Name: _ZN5boost10filesystem16filesystem_errorD0Ev
void __fastcall boost::filesystem::filesystem_error::~filesystem_error(boost::filesystem::filesystem_error *this)
{
  volatile signed __int32 *v1; // r14

  *(_QWORD *)this = off_29CFC08;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 8);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0x283e140 | Name: _ZNK5boost10filesystem16filesystem_error4whatEv
const char *__fastcall boost::filesystem::filesystem_error::what(const boost::filesystem::filesystem_error *this)
{
  unsigned __int8 *v2; // rbx
  unsigned __int64 v3; // rax
  const char *v5; // rax
  unsigned __int64 v6; // rax
  unsigned __int8 *v7; // rsi
  unsigned __int8 *v8; // rdi
  unsigned __int64 v9; // rdx
  unsigned __int64 v10; // rdx
  unsigned __int8 *v11; // rsi
  unsigned __int64 v12; // rax
  __int64 v14; // rsi
  __int64 v15; // rdi
  unsigned __int64 v16; // rdx
  unsigned __int64 v17; // rdx
  __int64 v18; // rsi

  v2 = (unsigned __int8 *)*((_QWORD *)this + 7);
  if ( !v2 )
    return boost::system::system_error::what(this);
  v3 = v2[48];
  if ( (v3 & 1) != 0 )
  {
    if ( *((_QWORD *)v2 + 7) )
      goto LABEL_17;
  }
  else if ( v3 >> 1 )
  {
    goto LABEL_17;
  }
  v5 = boost::system::system_error::what(this);
  std::string::assign(*((_QWORD *)this + 7) + 48LL, v5);
  v2 = (unsigned __int8 *)*((_QWORD *)this + 7);
  v6 = *v2;
  if ( (v6 & 1) != 0 )
  {
    if ( !*((_QWORD *)v2 + 1) )
      goto LABEL_15;
  }
  else if ( !(v6 >> 1) )
  {
    goto LABEL_15;
  }
  std::string::append(v2 + 48, ": \"");
  v7 = (unsigned __int8 *)*((_QWORD *)this + 7);
  v8 = v7 + 48;
  v9 = *v7;
  if ( (v9 & 1) != 0 )
  {
    v10 = *((_QWORD *)v7 + 1);
    v11 = (unsigned __int8 *)*((_QWORD *)v7 + 2);
  }
  else
  {
    v11 = v7 + 1;
    v10 = v9 >> 1;
  }
  std::string::append(v8, v11, v10);
  std::string::append(*((_QWORD *)this + 7) + 48LL, "\"");
  v2 = (unsigned __int8 *)*((_QWORD *)this + 7);
LABEL_15:
  v12 = v2[24];
  if ( (v12 & 1) == 0 )
  {
    if ( !(v12 >> 1) )
      goto LABEL_17;
LABEL_20:
    std::string::append(v2 + 48, ", \"");
    v14 = *((_QWORD *)this + 7);
    v15 = v14 + 48;
    v16 = *(unsigned __int8 *)(v14 + 24);
    if ( (v16 & 1) != 0 )
    {
      v17 = *(_QWORD *)(v14 + 32);
      v18 = *(_QWORD *)(v14 + 40);
    }
    else
    {
      v18 = v14 + 25;
      v17 = v16 >> 1;
    }
    std::string::append(v15, v18, v17);
    std::string::append(*((_QWORD *)this + 7) + 48LL, "\"");
    v2 = (unsigned __int8 *)*((_QWORD *)this + 7);
    if ( (v2[48] & 1) == 0 )
      return (const char *)(v2 + 49);
    return (const char *)*((_QWORD *)v2 + 8);
  }
  if ( *((_QWORD *)v2 + 4) )
    goto LABEL_20;
LABEL_17:
  if ( (v2[48] & 1) != 0 )
    return (const char *)*((_QWORD *)v2 + 8);
  return (const char *)(v2 + 49);
}


// Address: 0x283e4a0 | Name: _ZN5boost10filesystem16filesystem_errorC2ERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_6system10error_codeE
void __fastcall boost::filesystem::filesystem_error::filesystem_error(
        boost::filesystem::filesystem_error *this,
        const std::string *what_arg,
        boost::system::error_code ec)
{
  const boost::system::error_category *m_cat; // r14
  int m_val; // ebp
  _OWORD *v5; // rax
  __m128i v6; // xmm0
  volatile signed __int32 *v7; // xmm0_8
  __m128i v8; // [rsp+0h] [rbp-38h] BYREF

  m_cat = ec.m_cat;
  m_val = ec.m_val;
  std::runtime_error::runtime_error(this, what_arg);
  *((_DWORD *)this + 4) = m_val;
  *((_QWORD *)this + 3) = m_cat;
  *((_OWORD *)this + 2) = 0;
  *((_QWORD *)this + 6) = 0;
  *(_QWORD *)this = off_29CFC08;
  *(_OWORD *)((char *)this + 56) = 0;
  v5 = operator new(0x48u);
  v5[3] = 0;
  v5[2] = 0;
  v5[1] = 0;
  *v5 = 0;
  *((_QWORD *)v5 + 8) = 0;
  boost::shared_ptr<boost::filesystem::filesystem_error::m_imp>::shared_ptr<boost::filesystem::filesystem_error::m_imp>(
    (boost::shared_ptr<boost::filesystem::filesystem_error::m_imp> *)&v8,
    (boost::filesystem::filesystem_error::m_imp *)v5);
  v6 = _mm_loadu_si128((const __m128i *)((char *)this + 56));
  *(__m128i *)((char *)this + 56) = v8;
  v8 = v6;
  v7 = (volatile signed __int32 *)_mm_shuffle_epi32(v6, 78).m128i_u64[0];
  if ( v7 && !_InterlockedSub(v7 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v7 + 16LL))(v7, *(double *)&v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


