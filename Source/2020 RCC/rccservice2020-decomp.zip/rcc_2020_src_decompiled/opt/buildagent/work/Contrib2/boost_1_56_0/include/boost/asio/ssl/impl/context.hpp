// Address: 0x25f43a0 | Name: _ZN5boost4asio3ssl7context19set_verify_callbackIZZN3web10websockets6client7details20wspp_callback_client7connectEvENKUlNSt3__18weak_ptrIvEEE_clESB_EUlbRNS1_14verify_contextEE_EEvT_
__int64 __fastcall boost::asio::ssl::context::set_verify_callback<web::websockets::client::details::wspp_callback_client::connect(void)::{lambda(std::weak_ptr<void>)#1}::operator() const(std::weak_ptr<void>)::{lambda(bool,boost::asio::ssl::verify_context &)#1}>(
        __int64 a1,
        __int64 a2)
{
  __int64 result; // rax
  int v3; // ebp
  const boost::system::error_category *v4; // rbx
  int v5; // [rsp+0h] [rbp-68h] BYREF
  const boost::system::error_category *v6; // [rsp+8h] [rbp-60h]
  _QWORD v7[2]; // [rsp+10h] [rbp-58h] BYREF
  int v8; // [rsp+20h] [rbp-48h]
  const boost::system::error_category *v9; // [rsp+28h] [rbp-40h]
  __int128 v10; // [rsp+30h] [rbp-38h]
  void *ptr; // [rsp+40h] [rbp-28h]

  v5 = 0;
  v6 = boost::system::system_category();
  result = boost::asio::ssl::context::set_verify_callback<web::websockets::client::details::wspp_callback_client::connect(void)::{lambda(std::weak_ptr<void>)#1}::operator() const(std::weak_ptr<void>)::{lambda(bool,boost::asio::ssl::verify_context &)#1}>(
             a1,
             a2,
             &v5);
  v3 = v5;
  if ( v5 )
  {
    v4 = v6;
    std::runtime_error::runtime_error((std::runtime_error *)v7, "set_verify_callback");
    v7[0] = off_2875F00;
    v8 = v3;
    v9 = v4;
    v10 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v7);
  }
  return result;
}


// Address: 0x25f4f90 | Name: _ZN5boost4asio3ssl7context19set_verify_callbackIZZN3web10websockets6client7details20wspp_callback_client7connectEvENKUlNSt3__18weak_ptrIvEEE_clESB_EUlbRNS1_14verify_contextEE_EENS_6system10error_codeET_RSH_
__int64 __fastcall boost::asio::ssl::context::set_verify_callback<web::websockets::client::details::wspp_callback_client::connect(void)::{lambda(std::weak_ptr<void>)#1}::operator() const(std::weak_ptr<void>)::{lambda(bool,boost::asio::ssl::verify_context &)#1}>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3)
{
  _QWORD *v4; // rbx
  __int64 v5; // rax
  __int64 v6; // rbx
  unsigned int verify_mode; // eax
  const boost::system::error_category *v8; // rax

  v4 = operator new(0x10u);
  *v4 = &off_29C2838;
  v4[1] = a2;
  if ( SSL_CTX_get_ex_data(*a1, 0) )
  {
    v5 = SSL_CTX_get_ex_data(*a1, 0);
    if ( v5 )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(v5);
  }
  SSL_CTX_set_ex_data(*a1, 0, v4);
  v6 = *a1;
  verify_mode = SSL_CTX_get_verify_mode(*a1);
  SSL_CTX_set_verify(v6, verify_mode, boost::asio::ssl::context::verify_callback_function);
  v8 = boost::system::system_category();
  *(_DWORD *)a3 = 0;
  *(_QWORD *)(a3 + 8) = v8;
  return 0;
}


