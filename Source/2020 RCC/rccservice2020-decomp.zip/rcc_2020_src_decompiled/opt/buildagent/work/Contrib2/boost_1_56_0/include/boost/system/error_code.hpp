// Address: 0x25ed3e0 | Name: _ZNK5boost6system14error_category23default_error_conditionEi
boost::system::error_condition __fastcall boost::system::error_category::default_error_condition(
        const boost::system::error_category *this,
        int ev)
{
  boost::system::error_condition result; // 0:eax.4,8:rdx.8

  result.m_val = ev;
  result.m_cat = this;
  return result;
}


// Address: 0x25ed3f0 | Name: _ZNK5boost6system14error_category10equivalentEiRKNS0_15error_conditionE
bool __fastcall boost::system::error_category::equivalent(
        const boost::system::error_category *this,
        int code,
        const boost::system::error_condition *condition)
{
  int v4; // eax
  const boost::system::error_category *v5; // rdx

  v4 = (*((__int64 (__fastcall **)(const boost::system::error_category *, int))this->_vptr$error_category + 4))(
         this,
         code);
  return v5 == condition->m_cat && v4 == condition->m_val;
}


// Address: 0x25ed410 | Name: _ZNK5boost6system14error_category10equivalentERKNS0_10error_codeEi
bool __fastcall boost::system::error_category::equivalent(
        const boost::system::error_category *this,
        const boost::system::error_code *code,
        int condition)
{
  return code->m_cat == this && code->m_val == condition;
}


// Address: 0x25ed420 | Name: _ZN5boost6system14error_categoryD2Ev
void __fastcall boost::system::error_category::~error_category(boost::system::error_category *this)
{
  ;
}


