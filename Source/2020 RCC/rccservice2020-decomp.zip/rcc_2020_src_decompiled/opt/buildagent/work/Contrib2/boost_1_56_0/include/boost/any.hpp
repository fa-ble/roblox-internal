// Address: 0xe40c70 | Name: _ZN5boost3any6holderINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEED2Ev
void __fastcall boost::any::holder<std::string>::~holder(boost::any::holder<std::string > *this)
{
  *(_QWORD *)this = &off_287BA98;
  if ( (*((_BYTE *)this + 8) & 1) != 0 )
    operator delete(*((void **)this + 3));
}


// Address: 0xe40c90 | Name: _ZN5boost3any6holderINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEED0Ev
void __fastcall boost::any::holder<std::string>::~holder(boost::any::holder<std::string > *this)
{
  *(_QWORD *)this = &off_287BA98;
  if ( (*((_BYTE *)this + 8) & 1) != 0 )
    operator delete(*((void **)this + 3));
  operator delete(this);
}


// Address: 0xe40cc0 | Name: _ZNK5boost3any6holderINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEE4typeEv
const boost::typeindex::type_info *__fastcall boost::any::holder<std::string>::type(
        const boost::any::holder<std::string > *this)
{
  return &`typeinfo for'std::string;
}


// Address: 0xe40cd0 | Name: _ZNK5boost3any6holderINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEE5cloneEv
boost::any::placeholder *__fastcall boost::any::holder<std::string>::clone(
        const boost::any::holder<std::string > *this)
{
  boost::any::placeholder *v1; // rbx

  v1 = (boost::any::placeholder *)operator new(0x20u);
  v1->_vptr$placeholder = (int (**)(void))&off_287BA98;
  std::string::basic_string(&v1[1], (char *)this + 8);
  return v1;
}


// Address: 0xe43b60 | Name: _ZN5boost3any11placeholderD2Ev
void __fastcall boost::any::placeholder::~placeholder(boost::any::placeholder *this)
{
  ;
}


// Address: 0xe43b70 | Name: j__ZdlPv_63
// attributes: thunk
void __fastcall operator delete(boost::any::holder<int> *this)
{
  _ZdlPv(this);
}


// Address: 0xe43b80 | Name: _ZNK5boost3any6holderIiE4typeEv
const boost::typeindex::type_info *__fastcall boost::any::holder<int>::type(const boost::any::holder<int> *this)
{
  return `typeinfo for'int;
}


// Address: 0xe43b90 | Name: _ZNK5boost3any6holderIiE5cloneEv
boost::any::placeholder *__fastcall boost::any::holder<int>::clone(const boost::any::holder<int> *this)
{
  boost::any::placeholder *result; // rax

  result = (boost::any::placeholder *)operator new(0x10u);
  result->_vptr$placeholder = (int (**)(void))&off_287BF70;
  LODWORD(result[1]._vptr$placeholder) = this->held;
  return result;
}


// Address: 0xe45300 | Name: _ZNK5boost12bad_any_cast4whatEv
const char *__fastcall boost::bad_any_cast::what(const boost::bad_any_cast *this)
{
  return "boost::bad_any_cast: failed conversion using boost::any_cast";
}


// Address: 0xe45660 | Name: _ZN5boost12bad_any_castD0Ev
void __fastcall boost::bad_any_cast::~bad_any_cast(boost::bad_any_cast *this)
{
  std::bad_cast::~bad_cast(this);
  operator delete(this);
}


// Address: 0xe68700 | Name: j__ZdlPv_80
// attributes: thunk
void __fastcall operator delete(boost::any::holder<bool> *this)
{
  _ZdlPv(this);
}


// Address: 0xe68710 | Name: _ZNK5boost3any6holderIbE4typeEv
const boost::typeindex::type_info *__fastcall boost::any::holder<bool>::type(const boost::any::holder<bool> *this)
{
  return `typeinfo for'bool;
}


// Address: 0xe68720 | Name: _ZNK5boost3any6holderIbE5cloneEv
boost::any::placeholder *__fastcall boost::any::holder<bool>::clone(const boost::any::holder<bool> *this)
{
  boost::any::placeholder *result; // rax

  result = (boost::any::placeholder *)operator new(0x10u);
  result->_vptr$placeholder = (int (**)(void))&off_287E4D8;
  LOBYTE(result[1]._vptr$placeholder) = this->held;
  return result;
}


// Address: 0xe68d10 | Name: _ZN5boost3any6holderINSt3__112basic_stringIwNS2_11char_traitsIwEENS2_9allocatorIwEEEEED2Ev
void __fastcall boost::any::holder<std::wstring>::~holder(boost::any::holder<std::wstring > *this)
{
  *(_QWORD *)this = &off_287E6B8;
  if ( (*((_BYTE *)this + 8) & 1) != 0 )
    operator delete(*((void **)this + 3));
}


// Address: 0xe68d30 | Name: _ZN5boost3any6holderINSt3__112basic_stringIwNS2_11char_traitsIwEENS2_9allocatorIwEEEEED0Ev
void __fastcall boost::any::holder<std::wstring>::~holder(boost::any::holder<std::wstring > *this)
{
  *(_QWORD *)this = &off_287E6B8;
  if ( (*((_BYTE *)this + 8) & 1) != 0 )
    operator delete(*((void **)this + 3));
  operator delete(this);
}


// Address: 0xe68d60 | Name: _ZNK5boost3any6holderINSt3__112basic_stringIwNS2_11char_traitsIwEENS2_9allocatorIwEEEEE4typeEv
const boost::typeindex::type_info *__fastcall boost::any::holder<std::wstring>::type(
        const boost::any::holder<std::wstring > *this)
{
  return &`typeinfo for'std::wstring;
}


// Address: 0xe68d70 | Name: _ZNK5boost3any6holderINSt3__112basic_stringIwNS2_11char_traitsIwEENS2_9allocatorIwEEEEE5cloneEv
boost::any::placeholder *__fastcall boost::any::holder<std::wstring>::clone(
        const boost::any::holder<std::wstring > *this)
{
  boost::any::placeholder *v1; // rbx

  v1 = (boost::any::placeholder *)operator new(0x20u);
  v1->_vptr$placeholder = (int (**)(void))&off_287E6B8;
  std::wstring::basic_string(&v1[1], (char *)this + 8);
  return v1;
}


