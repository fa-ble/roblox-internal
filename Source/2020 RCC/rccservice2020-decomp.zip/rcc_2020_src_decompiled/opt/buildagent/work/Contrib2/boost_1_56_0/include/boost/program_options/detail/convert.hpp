// Address: 0xe44790 | Name: _ZN5boost15program_options11to_internalINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEENS2_6vectorIS8_NS6_IS8_EEEERKNS9_IT_NS6_ISC_EEEE
std::vector<std::string> *__fastcall boost::program_options::to_internal<std::string>(
        std::vector<std::string> *this,
        __int64 *a2)
{
  __int64 v2; // rax
  unsigned int v3; // ebp
  unsigned __int64 v4; // rcx
  unsigned __int64 v5; // rax
  __int128 v7; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]

  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v2 = *a2;
  if ( a2[1] != *a2 )
  {
    v3 = 1;
    v4 = 0;
    do
    {
      boost::program_options::to_internal(&v7, v2 + 24 * v4);
      v5 = *((_QWORD *)this + 1);
      if ( v5 >= *((_QWORD *)this + 2) )
      {
        std::vector<std::string>::__push_back_slow_path<std::string>(this, (std::string *)&v7);
        if ( (v7 & 1) != 0 )
          operator delete(ptr);
      }
      else
      {
        *(_QWORD *)(v5 + 16) = ptr;
        *(_OWORD *)v5 = v7;
        v7 = 0;
        ptr = 0;
        *((_QWORD *)this + 1) += 24LL;
      }
      v4 = v3;
      v2 = *a2;
      ++v3;
    }
    while ( 0xAAAAAAAAAAAAAAABLL * ((a2[1] - *a2) >> 3) > v4 );
  }
  return this;
}


