// Address: 0xfe8360 | Name: _ZN5boost9gregorian8bad_yearD0Ev
void __fastcall boost::gregorian::bad_year::~bad_year(boost::gregorian::bad_year *this)
{
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


