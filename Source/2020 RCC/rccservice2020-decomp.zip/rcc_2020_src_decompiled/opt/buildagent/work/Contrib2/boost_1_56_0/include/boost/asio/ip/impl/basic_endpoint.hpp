// Address: 0x2603c50 | Name: _ZN5boost4asio2iplsIcNSt3__111char_traitsIcEENS1_3tcpEEERNS3_13basic_ostreamIT_T0_EESB_RKNS1_14basic_endpointIT1_EE
std::ostream *__fastcall boost::asio::ip::operator<<<char,std::char_traits<char>,boost::asio::ip::tcp>(
        std::ostream *os,
        const boost::asio::ip::basic_endpoint<boost::asio::ip::tcp> *endpoint)
{
  in_addr_t s_addr; // eax
  in6_addr_0 sin6_addr; // xmm0
  char v5; // di
  uint32_t sin6_scope_id; // ecx
  __int16 v7; // dx
  __int16 v8; // dx
  int v9; // ebx
  __int64 v10; // rdi
  char v11; // cl
  char *v12; // rbp
  char v13; // bl
  __int64 v14; // rax
  char v15; // bl
  in6_addr_0 v16; // rax
  const boost::system::error_category *v18; // rbp
  boost::asio::ip::detail::endpoint v19[2]; // [rsp+8h] [rbp-B0h] BYREF
  int v20; // [rsp+40h] [rbp-78h]
  const boost::system::error_category *v21; // [rsp+48h] [rbp-70h]
  char __str[8]; // [rsp+50h] [rbp-68h] BYREF
  int v23; // [rsp+60h] [rbp-58h]
  const boost::system::error_category *v24; // [rsp+68h] [rbp-50h]
  __int128 v25; // [rsp+70h] [rbp-48h]
  void *v26; // [rsp+80h] [rbp-38h]

  if ( endpoint->impl_.data_.base.sa_family == 2 )
  {
    s_addr = endpoint->impl_.data_.v4.sin_addr.s_addr;
    sin6_addr = 0;
    v5 = 1;
    sin6_scope_id = 0;
  }
  else
  {
    sin6_scope_id = endpoint->impl_.data_.v6.sin6_scope_id;
    sin6_addr = endpoint->impl_.data_.v6.sin6_addr;
    v5 = 0;
    s_addr = 0;
  }
  v7 = __ROL2__(endpoint->impl_.data_.v4.sin_port, 8);
  v19[1].data_.v6.sin6_addr = 0;
  *(_OWORD *)&v19[0].data_.v6.sin6_scope_id = 0;
  if ( v5 )
  {
    LOWORD(v19[0].data_.v6.sin6_scope_id) = 2;
    v8 = __ROL2__(v7, 8);
  }
  else
  {
    v8 = __ROL2__(v7, 8);
    strcpy((char *)&v19[0].data_.v6.sin6_scope_id, "\n");
    *(in6_addr_0 *)&v19[1].data_.v6.sin6_flowinfo = sin6_addr;
    v19[1].data_.v6.sin6_addr.__u6_addr32[3] = sin6_scope_id;
    s_addr = 0;
  }
  HIWORD(v19[0].data_.v6.sin6_scope_id) = v8;
  *(_DWORD *)&v19[1].data_.base.sa_family = s_addr;
  v20 = 0;
  v21 = boost::system::system_category();
  boost::asio::ip::detail::endpoint::to_string(v19, (boost::system::error_code *)&v19[0].data_.v6.sin6_scope_id);
  v9 = v20;
  if ( !v20 )
  {
    v11 = v19[0].data_.base.sa_family & 1;
    if ( (v19[0].data_.base.sa_family & 1) != 0 )
    {
      if ( !*(_QWORD *)v19[0].data_.v6.sin6_addr.__u6_addr8 )
        goto LABEL_21;
    }
    else if ( !((unsigned __int64)LOBYTE(v19[0].data_.base.sa_family) >> 1) )
    {
      goto LABEL_21;
    }
    v12 = (char *)&v19[0].data_.base.sa_family + 1;
    if ( v11 )
      v12 = *(char **)&v19[0].data_.v6.sin6_addr.__u6_addr32[2];
    do
    {
      v13 = *v12;
      std::ios_base::getloc((std::ios_base *)__str);
      v14 = std::locale::use_facet((std::locale *)__str, &std::ctype<char>::id);
      v15 = (*(__int64 (__fastcall **)(__int64, _QWORD, double))(*(_QWORD *)v14 + 56LL))(
              v14,
              (unsigned int)v13,
              *(double *)sin6_addr.__u6_addr8);
      std::locale::~locale((std::locale *)__str);
      __str[0] = v15;
      std::__put_character_sequence<char,std::char_traits<char>>(os, __str, 1u);
      ++v12;
      v11 = v19[0].data_.base.sa_family & 1;
      if ( (v19[0].data_.base.sa_family & 1) != 0 )
      {
        v16 = v19[0].data_.v6.sin6_addr;
      }
      else
      {
        *(_QWORD *)v16.__u6_addr8 = (unsigned __int64)LOBYTE(v19[0].data_.base.sa_family) >> 1;
        *(_QWORD *)&v16.__u6_addr32[2] = (char *)&v19[0].data_.base.sa_family + 1;
      }
    }
    while ( v12 != (char *)(*(_QWORD *)v16.__u6_addr8 + *(_QWORD *)&v16.__u6_addr32[2]) );
LABEL_21:
    if ( !v11 )
      return os;
LABEL_22:
    operator delete(*(void **)&v19[0].data_.v6.sin6_addr.__u6_addr32[2]);
    return os;
  }
  v10 = *(_QWORD *)(*(_QWORD *)os - 24LL);
  if ( (*((_BYTE *)os + v10 + 36) & 4) != 0 )
  {
    v18 = v21;
    std::runtime_error::runtime_error((std::runtime_error *)__str, (const char *)&uri_string);
    *(_QWORD *)__str = off_2875F00;
    v23 = v9;
    v24 = v18;
    v25 = 0;
    v26 = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)__str);
  }
  std::ios_base::clear((std::ostream *)((char *)os + v10), *(_DWORD *)((char *)os + v10 + 32) | 4);
  if ( (v19[0].data_.base.sa_family & 1) != 0 )
    goto LABEL_22;
  return os;
}


