// Address: 0xd9ee10 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyIN3RBX12SharedString4DataEE8rep_typeESA_EEEENS_4hashISA_EENSt3__18equal_toISA_EENS1_9nth_layerILi1ESD_NS4_20hashed_factory_classISD_SA_N4mpl_2naESN_SN_E10index_listENSH_9allocatorISD_EEEENS_3mpl7vector0ISN_EENS1_17hashed_unique_tagEEC2ERKNS_6tuples4consINSY_5tupleImSE_SG_SJ_NSY_9null_typeES11_S11_S11_S11_S11_EES11_EERKSR_
void __fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::hashed_index(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        const boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::ctor_args_list *args_list,
        const boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::allocator_type *al_0)
{
  __int64 v4; // r15
  boost::tuples::cons<unsigned long,boost::tuples::cons<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::tuples::cons<boost::hash<RBX::SharedString::Data>,boost::tuples::cons<std::equal_to<RBX::SharedString::Data>,boost::tuples::null_type> > > >::stored_head_type head; // rax
  char *v6; // rcx
  __int64 v7; // rdx
  char *v8; // rsi
  __int64 v9; // rdi
  char *v10; // rsi
  __int64 v11; // r12
  unsigned __int64 v12; // rdi
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v13; // rdi
  float v14; // xmm0_4
  unsigned __int64 v15; // rax
  size_type v16; // rcx
  std::logic_error *exception; // rbx

  v4 = *((_QWORD *)this - 1);
  head = args_list->head.head;
  v6 = "5";
  v7 = 60;
  do
  {
    v8 = v6;
    v9 = v7 + ~(v7 / 2);
    if ( *(_QWORD *)&v6[8 * (v7 / 2)] >= head )
      v9 = v7 / 2;
    v6 += 8 * (v7 / 2) + 8;
    if ( *(_QWORD *)&v8[8 * (v7 / 2)] >= head )
      v6 = v8;
    v7 = v9;
  }
  while ( v9 );
  v10 = v6 - 8;
  if ( v6 != "N5boost6detail18sp_counted_impl_pdIPNSt3__118basic_stringstreamIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEN"
             "S0_13sp_ms_deleterIS8_EEEE" )
    v10 = v6;
  v11 = *(_QWORD *)v10;
  this->buckets.size_index_ = (v10 - "5") >> 3;
  v12 = v11 + 1;
  this->buckets.spc.n_ = v11 + 1;
  if ( v11 == -1 )
  {
    v13 = 0;
  }
  else
  {
    if ( v12 >> 61 )
    {
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(exception, "allocator<T>::allocate(size_t n) 'n' exceeds maximum supported size");
      *(_QWORD *)exception = (char *)&`vtable for'std::length_error + 16;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::length_error,
        (void (*)(void *))&std::length_error::~length_error);
    }
    v13 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *)operator new(8 * v12);
  }
  this->buckets.spc.data_ = v13;
  memset(v13, 0, 8 * v11);
  *(_QWORD *)(v4 + 56) = v4 + 56;
  this->buckets.spc.data_[v11].prior_ = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)(v4 + 56);
  *(_QWORD *)(v4 + 64) = &this->buckets.spc.data_[v11];
  this->mlf = 1.0;
  if ( v11 < 0 )
    v14 = (float)(int)(((unsigned __int64)v11 >> 1) | v11 & 1) + (float)(int)(((unsigned __int64)v11 >> 1) | v11 & 1);
  else
    v14 = (float)(int)v11;
  v15 = (unsigned int)(int)v14;
  if ( v14 >= 9.223372e18 )
    v15 = (unsigned int)(int)(float)(v14 - 9.223372e18) ^ 0x8000000000000000LL;
  v16 = -1;
  if ( v14 < 1.8446744e19 )
    v16 = v15;
  this->max_load = v16;
}


// Address: 0xdd1b40 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyIN3RBX12SharedString4DataEE8rep_typeESA_EEEENS_4hashISA_EENSt3__18equal_toISA_EENS1_9nth_layerILi1ESD_NS4_20hashed_factory_classISD_SA_N4mpl_2naESN_SN_E10index_listENSH_9allocatorISD_EEEENS_3mpl7vector0ISN_EENS1_17hashed_unique_tagEE5eraseENS1_21hashed_index_iteratorINS1_17hashed_index_nodeINS1_15index_node_baseISD_SR_EESW_EENS1_12bucket_arrayISR_EENS1_32hashed_index_global_iterator_tagEEE
boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::iterator __fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::erase(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::iterator position)
{
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > > *v3; // rax
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer next; // rcx
  boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::multi_index::detail::hashed_unique_tag> *prior; // rdx
  bool v6; // zf
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v7; // rsi
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *p_next; // r14
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v9; // rdi
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > > *v10; // rsi
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v11; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v12; // rcx

  v3 = &position.node->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > >;
  next = position.node->next_;
  prior = (boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::multi_index::detail::hashed_unique_tag> *)next->prior_;
  v6 = next->prior_ == &position.node->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > >;
  v7 = next->prior_;
  if ( v6 )
    v7 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)next;
  p_next = &v7[-4].next_;
  if ( !v7 )
    p_next = 0;
  --*((_QWORD *)this + 7);
  v9 = position.node->prior_;
  v10 = (boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > > *)v9->next_;
  if ( v10 == v3 )
  {
    v9->next_ = next;
    v12 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)position.node->next_;
    if ( prior != (boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::multi_index::detail::hashed_unique_tag> *)v3 )
      v12 = v12->prior_;
    v11 = v3->prior_;
  }
  else if ( prior == (boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::multi_index::detail::hashed_unique_tag> *)v3 )
  {
    v10->prior_ = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)next;
    v11 = position.node->prior_;
    v12 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)position.node->next_;
  }
  else
  {
    v10->prior_ = 0;
    position.node->prior_->next_ = position.node->next_;
    v11 = position.node->prior_;
    v12 = position.node->next_->prior_;
  }
  v12->prior_ = v11;
  if ( (position.node->space.data_.buf[16] & 1) != 0 )
    operator delete(*((void **)&position.node->space.data_.align_ + 4));
  operator delete(position.node);
  return (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::iterator)p_next;
}


// Address: 0xeb6880 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyIN3RBX15ProtectedStringEE8rep_typeES9_EEEENS_4hashIS9_EENSt3__18equal_toIS9_EENS1_9nth_layerILi1ESC_NS4_20hashed_factory_classISC_S9_N4mpl_2naESM_SM_E10index_listENSG_9allocatorISC_EEEENS_3mpl7vector0ISM_EENS1_17hashed_unique_tagEEC2ERKNS_6tuples4consINSX_5tupleImSD_SF_SI_NSX_9null_typeES10_S10_S10_S10_S10_EES10_EERKSQ_
void __fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::hashed_index(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        const boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::ctor_args_list *args_list,
        const boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::allocator_type *al_0)
{
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v4; // r15
  boost::tuples::cons<unsigned long,boost::tuples::cons<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::tuples::cons<boost::hash<RBX::ProtectedString>,boost::tuples::cons<std::equal_to<RBX::ProtectedString>,boost::tuples::null_type> > > >::stored_head_type head; // rax
  char *v6; // rcx
  __int64 v7; // rdx
  char *v8; // rsi
  __int64 v9; // rdi
  char *v10; // rsi
  __int64 v11; // r12
  unsigned __int64 v12; // rdi
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v13; // rdi
  float v14; // xmm0_4
  unsigned __int64 v15; // rax
  size_type v16; // rcx
  std::logic_error *exception; // rbx

  v4 = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)*((_QWORD *)this - 1);
  head = args_list->head.head;
  v6 = "5";
  v7 = 60;
  do
  {
    v8 = v6;
    v9 = v7 + ~(v7 / 2);
    if ( *(_QWORD *)&v6[8 * (v7 / 2)] >= head )
      v9 = v7 / 2;
    v6 += 8 * (v7 / 2) + 8;
    if ( *(_QWORD *)&v8[8 * (v7 / 2)] >= head )
      v6 = v8;
    v7 = v9;
  }
  while ( v9 );
  v10 = v6 - 8;
  if ( v6 != "N5boost6detail18sp_counted_impl_pdIPNSt3__118basic_stringstreamIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEN"
             "S0_13sp_ms_deleterIS8_EEEE" )
    v10 = v6;
  v11 = *(_QWORD *)v10;
  this->buckets.size_index_ = (v10 - "5") >> 3;
  v12 = v11 + 1;
  this->buckets.spc.n_ = v11 + 1;
  if ( v11 == -1 )
  {
    v13 = 0;
  }
  else
  {
    if ( v12 >> 61 )
    {
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(exception, "allocator<T>::allocate(size_t n) 'n' exceeds maximum supported size");
      *(_QWORD *)exception = (char *)&`vtable for'std::length_error + 16;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::length_error,
        (void (*)(void *))&std::length_error::~length_error);
    }
    v13 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *)operator new(8 * v12);
  }
  this->buckets.spc.data_ = v13;
  memset(v13, 0, 8 * v11);
  v4[5].prior_ = v4 + 5;
  this->buckets.spc.data_[v11].prior_ = v4 + 5;
  v4[5].next_ = &this->buckets.spc.data_[v11];
  this->mlf = 1.0;
  if ( v11 < 0 )
    v14 = (float)(int)(((unsigned __int64)v11 >> 1) | v11 & 1) + (float)(int)(((unsigned __int64)v11 >> 1) | v11 & 1);
  else
    v14 = (float)(int)v11;
  v15 = (unsigned int)(int)v14;
  if ( v14 >= 9.223372e18 )
    v15 = (unsigned int)(int)(float)(v14 - 9.223372e18) ^ 0x8000000000000000LL;
  v16 = -1;
  if ( v14 < 1.8446744e19 )
    v16 = v15;
  this->max_load = v16;
}


// Address: 0xeb6a50 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyIN3RBX15ProtectedStringEE8rep_typeES9_EEEENS_4hashIS9_EENSt3__18equal_toIS9_EENS1_9nth_layerILi1ESC_NS4_20hashed_factory_classISC_S9_N4mpl_2naESM_SM_E10index_listENSG_9allocatorISC_EEEENS_3mpl7vector0ISM_EENS1_17hashed_unique_tagEE17delete_all_nodes_ESV_
void __fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::delete_all_nodes_(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        boost::multi_index::detail::hashed_unique_tag a2)
{
  __int64 v2; // r14
  _QWORD *v3; // r15
  _QWORD *v4; // r14
  boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *v5; // rbx

  v2 = *((_QWORD *)this - 1);
  v3 = *(_QWORD **)(v2 + 80);
  v4 = (_QWORD *)(v2 + 80);
  while ( v3 != v4 )
  {
    v5 = (boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)(v3 - 10);
    if ( !v3 )
      v5 = 0;
    v3 = (_QWORD *)*v3;
    boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(v5 + 7);
    boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(v5 + 6);
    if ( ((__int64)v5[3].h & 1) != 0 )
      operator delete(v5[5].h);
    if ( ((__int64)v5->h & 1) != 0 )
      operator delete(v5[2].h);
    operator delete(v5);
  }
}


// Address: 0x11151f0 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyIN3RBX15ProtectedStringEE8rep_typeES9_EEEENS_4hashIS9_EENSt3__18equal_toIS9_EENS1_9nth_layerILi1ESC_NS4_20hashed_factory_classISC_S9_N4mpl_2naESM_SM_E10index_listENSG_9allocatorISC_EEEENS_3mpl7vector0ISM_EENS1_17hashed_unique_tagEE7insert_INS1_10rvalue_tagEEEPNS1_17hashed_index_nodeINS1_15index_node_baseISC_SQ_EESV_EERKSC_RS13_T_
boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *__fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::value_param_type v,
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **x,
        boost::multi_index::detail::rvalue_tag variant)
{
  size_type v5; // rax
  __m128i v6; // xmm0
  float v7; // xmm0_4
  unsigned __int64 v8; // rax
  size_type v9; // rsi
  size_t v10; // rax
  boost::multi_index::detail::rvalue_tag v11; // cl
  size_t v12; // rbp
  boost::multi_index::detail::auto_space<boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >::pointer data; // r13
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer prior; // r14
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v15; // rbx
  _QWORD *p_prior; // rax
  bool v17; // zf
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v18; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v19; // rcx
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > > > *v20; // rax
  __int64 v21; // rdx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v22; // rsi

  v5 = *((_QWORD *)this + 7) + 1LL;
  if ( this->max_load < v5 )
  {
    v6 = (__m128i)_mm_sub_pd(
                    (__m128d)_mm_unpacklo_epi32((__m128i)v5, (__m128i)xmmword_3E4930),
                    *(__m128d *)(&errorFunction.functor.data + 8));
    v7 = (*(double *)_mm_shuffle_epi32(v6, 78).m128i_i64 + *(double *)v6.m128i_i64) / this->mlf + 1.0;
    v8 = (unsigned int)(int)v7;
    if ( v7 >= 9.223372e18 )
      v8 = (unsigned int)(int)(float)(v7 - 9.223372e18) ^ 0x8000000000000000LL;
    v9 = -1;
    if ( v7 < 1.8446744e19 )
      v9 = v8;
    boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::unchecked_rehash(
      this,
      v9,
      (boost::multi_index::detail::hashed_unique_tag)x);
  }
  v10 = RBX::hash_value(v);
  v12 = boost::multi_index::detail::bucket_array_base<true>::position(v10, this->buckets.size_index_);
  data = this->buckets.spc.data_;
  prior = data[v12].prior_;
  if ( prior )
  {
    while ( 1 )
    {
      v15 = (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *)&prior[-5];
      if ( RBX::ProtectedString::operator==(v, (const RBX::ProtectedString *)&prior[-5]) )
        break;
      p_prior = &prior->next_->prior_;
      if ( p_prior )
      {
        v17 = *p_prior == (_QWORD)prior;
        prior = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)prior->next_;
        if ( v17 )
          continue;
      }
      goto LABEL_11;
    }
    if ( !prior )
      return 0;
  }
  else
  {
LABEL_11:
    v18 = boost::multi_index::detail::index_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>::insert_(
            (boost::multi_index::detail::index_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > > *)this,
            v,
            x,
            v11);
    v15 = v18;
    if ( v18 == *x )
    {
      v19 = &data[v12];
      v20 = &v18->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > > >;
      if ( v19->prior_ )
      {
        v15->prior_ = v19->prior_->prior_;
        v15->next_ = v19->prior_;
        v19->prior_ = v20;
        v15->next_->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,std::__1::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > > >::boost::multi_index::detail::hashed_index_node_impl<std::__1::allocator<char> >::prior_ = v20;
      }
      else
      {
        v21 = *((_QWORD *)this - 1);
        v22 = *(boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > **)(v21 + 80);
        v15->prior_ = v22;
        v15->next_ = *(boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *)(*(_QWORD *)(v21 + 80) + 8LL);
        v22->next_ = v19;
        v19->prior_ = v20;
        *(_QWORD *)(v21 + 80) = v20;
      }
    }
  }
  return v15;
}


// Address: 0x1115400 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyIN3RBX15ProtectedStringEE8rep_typeES9_EEEENS_4hashIS9_EENSt3__18equal_toIS9_EENS1_9nth_layerILi1ESC_NS4_20hashed_factory_classISC_S9_N4mpl_2naESM_SM_E10index_listENSG_9allocatorISC_EEEENS_3mpl7vector0ISM_EENS1_17hashed_unique_tagEE16unchecked_rehashEmSV_
void __fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::unchecked_rehash(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> >,boost::hash<RBX::ProtectedString>,std::equal_to<RBX::ProtectedString>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        size_type n,
        boost::multi_index::detail::hashed_unique_tag a3)
{
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v4; // rbx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v5; // r12
  unsigned __int64 v6; // rbp
  _QWORD *v7; // r14
  _QWORD *v8; // r15
  __int64 v9; // rbp
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *prior; // rbx
  const RBX::ProtectedString *v11; // rdi
  size_t v12; // rax
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v13; // rcx
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v14; // rdx
  _QWORD *p_prior; // rsi
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *p_next; // rdx
  size_t v17; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v18; // rcx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *next; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v20; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v21; // rax
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer v22; // rax
  size_t size_index; // rax
  size_t v24; // rcx
  size_t v25; // rax
  __int128 v26; // xmm0
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *data; // rdi
  __int64 v28; // rcx
  float v29; // xmm0_4
  float v30; // xmm0_4
  unsigned __int64 v31; // rcx
  size_type v32; // rdx
  std::logic_error *exception; // r14
  std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > al_0; // [rsp+8h] [rbp-80h] BYREF
  __int64 v35; // [rsp+10h] [rbp-78h]
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > v36; // [rsp+18h] [rbp-70h] BYREF
  boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > > v37; // [rsp+28h] [rbp-60h] BYREF
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v38; // [rsp+48h] [rbp-40h]
  unsigned __int64 v39; // [rsp+50h] [rbp-38h]

  v4 = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)*((_QWORD *)this - 1);
  v5 = v4 + 5;
  boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>::bucket_array(
    &v37,
    &al_0,
    &v36,
    n);
  v6 = *((_QWORD *)this + 7);
  if ( v6 )
  {
    if ( v6 >> 61 )
    {
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(exception, "allocator<T>::allocate(size_t n) 'n' exceeds maximum supported size");
      *(_QWORD *)exception = (char *)&`vtable for'std::length_error + 16;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::length_error,
        (void (*)(void *))&std::length_error::~length_error);
    }
    v7 = operator new(8 * v6);
    v39 = v6;
    v38 = v4;
    v8 = operator new(8 * v6);
    v35 = -1;
    v9 = 0;
    do
    {
      prior = v5->prior_;
      v11 = (const RBX::ProtectedString *)&v5->prior_[-5];
      if ( !v5->prior_ )
        v11 = 0;
      v12 = RBX::hash_value(v11);
      v7[v9] = v12;
      v8[v9] = prior;
      v13 = v5->prior_;
      v14 = v5->prior_->prior_;
      p_prior = &v14->next_->prior_;
      if ( p_prior == (_QWORD *)v5->prior_ )
      {
        p_next = &v14->next_;
        v35 = 0;
      }
      else
      {
        *p_prior = 0;
        p_next = &v13->prior_->next_;
        v35 = -1;
      }
      *p_next = v13->next_;
      v5->prior_ = v13->prior_;
      v17 = boost::multi_index::detail::bucket_array_base<true>::position(v12, v37.size_index_);
      v18 = &v37.spc.data_[v17];
      if ( v18->prior_ )
      {
        prior->prior_ = v18->prior_->prior_;
        prior->next_ = v18->prior_;
        v18->prior_ = prior;
        next = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)prior->next_;
      }
      else
      {
        v20 = v36.prior_;
        prior->prior_ = v36.prior_;
        prior->next_ = v36.prior_->next_;
        v20->next_ = v18;
        v18->prior_ = prior;
        next = &v36;
      }
      next->prior_ = prior;
      ++v9;
    }
    while ( v39 != v9 );
    operator delete(v8);
    operator delete(v7);
    v4 = v38;
  }
  v21 = v36.prior_;
  if ( v36.prior_ == &v36 )
    v21 = v5;
  v4[5].prior_ = v21;
  v22 = v36.next_;
  v4[5].next_ = v36.next_;
  v22->prior_->prior_ = v5;
  v4[5].prior_->next_->prior_ = v5;
  size_index = this->buckets.size_index_;
  v24 = v37.size_index_;
  this->buckets.size_index_ = v37.size_index_;
  v37.size_index_ = size_index;
  v25 = this->buckets.spc.n_;
  v26 = *(_OWORD *)&v37.spc.n_;
  v37.spc.n_ = v25;
  data = this->buckets.spc.data_;
  *(_OWORD *)&this->buckets.spc.n_ = v26;
  v37.spc.data_ = data;
  v28 = *(_QWORD *)&a5[8 * v24];
  if ( v28 < 0 )
    v29 = (float)(int)(((unsigned __int64)v28 >> 1) | v28 & 1) + (float)(int)(((unsigned __int64)v28 >> 1) | v28 & 1);
  else
    v29 = (float)(int)v28;
  v30 = v29 * this->mlf;
  v31 = (unsigned int)(int)v30;
  if ( v30 >= 9.223372e18 )
    v31 = (unsigned int)(int)(float)(v30 - 9.223372e18) ^ 0x8000000000000000LL;
  v32 = -1;
  if ( v30 < 1.8446744e19 )
    v32 = v31;
  this->max_load = v32;
  if ( v25 )
    operator delete(data);
}


// Address: 0x1311e50 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyIN3RBX12SharedString4DataEE8rep_typeESA_EEEENS_4hashISA_EENSt3__18equal_toISA_EENS1_9nth_layerILi1ESD_NS4_20hashed_factory_classISD_SA_N4mpl_2naESN_SN_E10index_listENSH_9allocatorISD_EEEENS_3mpl7vector0ISN_EENS1_17hashed_unique_tagEE7insert_INS1_10rvalue_tagEEEPNS1_17hashed_index_nodeINS1_15index_node_baseISD_SR_EESW_EERKSD_RS14_T_
boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *__fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        const __m128i *v,
        boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer **x,
        boost::multi_index::detail::rvalue_tag variant)
{
  size_type v6; // rax
  __m128i v7; // xmm0
  float v8; // xmm0_4
  unsigned __int64 v9; // rax
  size_type v10; // rsi
  size_t v11; // rax
  boost::multi_index::detail::auto_space<boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >::pointer data; // rdx
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer prior; // rcx
  _QWORD *p_prior; // rsi
  bool v15; // zf
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer **v16; // r12
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v17; // rax
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *result; // rax
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > > *v19; // rcx
  __int64 v20; // rdx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v21; // rsi

  v6 = *((_QWORD *)this + 7) + 1LL;
  if ( this->max_load < v6 )
  {
    v7 = (__m128i)_mm_sub_pd(
                    (__m128d)_mm_unpacklo_epi32((__m128i)v6, (__m128i)xmmword_3E4930),
                    *(__m128d *)(&errorFunction.functor.data + 8));
    v8 = (*(double *)_mm_shuffle_epi32(v7, 78).m128i_i64 + *(double *)v7.m128i_i64) / this->mlf + 1.0;
    v9 = (unsigned int)(int)v8;
    if ( v8 >= 9.223372e18 )
      v9 = (unsigned int)(int)(float)(v8 - 9.223372e18) ^ 0x8000000000000000LL;
    v10 = -1;
    if ( v8 < 1.8446744e19 )
      v10 = v9;
    boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::unchecked_rehash(
      this,
      v10,
      (boost::multi_index::detail::hashed_unique_tag)x);
  }
  v11 = boost::multi_index::detail::bucket_array_base<true>::position(
          (v->m128i_i64[0] + 2654435769LL)
        ^ (((unsigned __int64)(v->m128i_i64[0] + 2654435769LL) >> 2)
         + v->m128i_i64[1]
         + ((v->m128i_i64[0] + 2654435769LL) << 6)
         + 2654435769u),
          this->buckets.size_index_);
  data = this->buckets.spc.data_;
  prior = data[v11].prior_;
  if ( prior )
  {
    while ( _mm_movemask_epi8(_mm_cmpeq_epi8(_mm_loadu_si128((const __m128i *)&prior[-4].next_), _mm_loadu_si128(v))) != 0xFFFF )
    {
      p_prior = &prior->next_->prior_;
      if ( p_prior )
      {
        v15 = *p_prior == (_QWORD)prior;
        prior = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)prior->next_;
        if ( v15 )
          continue;
      }
      goto LABEL_11;
    }
    result = &prior[-4].next_;
    if ( !prior )
      return 0;
  }
  else
  {
LABEL_11:
    v16 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer **)&data[v11];
    v17 = (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *)operator new(0x48u);
    *x = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *)v17;
    *((_QWORD *)&v17->space.data_.align_ + 4) = v[2].m128i_i64[0];
    *((__m128i *)&v17->space.data_.align_ + 1) = v[1];
    v[1] = 0;
    v[2].m128i_i64[0] = 0;
    *(__m128i *)v17->space.data_.buf = _mm_loadu_si128(v);
    *((_DWORD *)&v17->space.data_.align_ + 10) = 0;
    *((_QWORD *)&v17->space.data_.align_ + 6) = 0;
    result = *x;
    v19 = (boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > > *)(*x + 7);
    if ( *v16 )
    {
      result[7] = **v16;
      result[8] = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer)*v16;
      *v16 = &v19->prior_;
      result[8]->prior_ = v19;
    }
    else
    {
      v20 = *((_QWORD *)this - 1);
      v21 = *(boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > **)(v20 + 56);
      result[7] = v21;
      result[8] = *(boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *)(*(_QWORD *)(v20 + 56) + 8LL);
      v21->next_ = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer)v16;
      *v16 = &v19->prior_;
      *(_QWORD *)(v20 + 56) = v19;
    }
  }
  return result;
}


// Address: 0x1312020 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyIN3RBX12SharedString4DataEE8rep_typeESA_EEEENS_4hashISA_EENSt3__18equal_toISA_EENS1_9nth_layerILi1ESD_NS4_20hashed_factory_classISD_SA_N4mpl_2naESN_SN_E10index_listENSH_9allocatorISD_EEEENS_3mpl7vector0ISN_EENS1_17hashed_unique_tagEE16unchecked_rehashEmSW_
void __fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::unchecked_rehash(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        size_type n,
        boost::multi_index::detail::hashed_unique_tag a3)
{
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v4; // r13
  unsigned __int64 v5; // rbx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *prior; // r12
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *p_next; // rax
  size_t v8; // rdi
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v9; // rax
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *next; // rcx
  size_t v11; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v12; // rcx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v13; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v14; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v15; // rax
  __int64 v16; // rcx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer v17; // rax
  size_t size_index; // rax
  size_t v19; // rcx
  size_t v20; // rax
  __int128 v21; // xmm0
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *data; // rdi
  __int64 v23; // rcx
  float v24; // xmm0_4
  float v25; // xmm0_4
  unsigned __int64 v26; // rcx
  size_type v27; // rdx
  std::logic_error *exception; // rbx
  std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > al_0; // [rsp+8h] [rbp-70h] BYREF
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > v30; // [rsp+10h] [rbp-68h] BYREF
  boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > v31; // [rsp+20h] [rbp-58h] BYREF
  __int64 v32; // [rsp+40h] [rbp-38h]

  v32 = *((_QWORD *)this - 1);
  v4 = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)(v32 + 56);
  boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>::bucket_array(
    &v31,
    &al_0,
    &v30,
    n);
  v5 = *((_QWORD *)this + 7);
  if ( v5 )
  {
    if ( v5 >> 61 )
    {
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(exception, "allocator<T>::allocate(size_t n) 'n' exceeds maximum supported size");
      *(_QWORD *)exception = (char *)&`vtable for'std::length_error + 16;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::length_error,
        (void (*)(void *))&std::length_error::~length_error);
    }
    do
    {
      prior = v4->prior_;
      p_next = &v4->prior_[-4].next_;
      if ( !v4->prior_ )
        p_next = 0;
      v8 = ((unsigned __int64)&(*p_next)[331804471].prior_ + 1)
         ^ ((unsigned __int64)&p_next[1][8 * ((_QWORD)*p_next + 2654435769LL) + 331804471].prior_
          + (((unsigned __int64)&(*p_next)[331804471].prior_ + 1) >> 2)
          + 1);
      v9 = prior->prior_;
      next = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)prior->prior_->next_;
      if ( next != prior )
      {
        next->prior_ = 0;
        v9 = prior->prior_;
      }
      v9->next_ = prior->next_;
      v4->prior_ = prior->prior_;
      v11 = boost::multi_index::detail::bucket_array_base<true>::position(v8, v31.size_index_);
      v12 = &v31.spc.data_[v11];
      if ( v12->prior_ )
      {
        prior->prior_ = v12->prior_->prior_;
        prior->next_ = v12->prior_;
        v12->prior_ = prior;
        v13 = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)prior->next_;
      }
      else
      {
        v14 = v30.prior_;
        prior->prior_ = v30.prior_;
        prior->next_ = v30.prior_->next_;
        v14->next_ = v12;
        v12->prior_ = prior;
        v13 = &v30;
      }
      v13->prior_ = prior;
      --v5;
    }
    while ( v5 );
  }
  v15 = v30.prior_;
  if ( v30.prior_ == &v30 )
    v15 = v4;
  v16 = v32;
  *(_QWORD *)(v32 + 56) = v15;
  v17 = v30.next_;
  *(_QWORD *)(v16 + 64) = v30.next_;
  v17->prior_->prior_ = v4;
  **(_QWORD **)(*(_QWORD *)(v16 + 56) + 8LL) = v4;
  size_index = this->buckets.size_index_;
  v19 = v31.size_index_;
  this->buckets.size_index_ = v31.size_index_;
  v31.size_index_ = size_index;
  v20 = this->buckets.spc.n_;
  v21 = *(_OWORD *)&v31.spc.n_;
  v31.spc.n_ = v20;
  data = this->buckets.spc.data_;
  *(_OWORD *)&this->buckets.spc.n_ = v21;
  v31.spc.data_ = data;
  v23 = *(_QWORD *)&a5[8 * v19];
  if ( v23 < 0 )
    v24 = (float)(int)(((unsigned __int64)v23 >> 1) | v23 & 1) + (float)(int)(((unsigned __int64)v23 >> 1) | v23 & 1);
  else
    v24 = (float)(int)v23;
  v25 = v24 * this->mlf;
  v26 = (unsigned int)(int)v25;
  if ( v25 >= 9.223372e18 )
    v26 = (unsigned int)(int)(float)(v25 - 9.223372e18) ^ 0x8000000000000000LL;
  v27 = -1;
  if ( v25 < 1.8446744e19 )
    v27 = v26;
  this->max_load = v27;
  if ( v20 )
    operator delete(data);
}


// Address: 0x1542fa0 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyINSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEEE8rep_typeESE_EEEENS_4hashISE_EENS8_8equal_toISE_EENS1_9nth_layerILi1ESH_NS4_20hashed_factory_classISH_SE_N4mpl_2naESQ_SQ_E10index_listENSC_ISH_EEEENS_3mpl7vector0ISQ_EENS1_17hashed_unique_tagEE5eraseENS1_21hashed_index_iteratorINS1_17hashed_index_nodeINS1_15index_node_baseISH_ST_EESY_EENS1_12bucket_arrayIST_EENS1_32hashed_index_global_iterator_tagEEE
boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::iterator __fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>,boost::hash<std::string>,std::equal_to<std::string>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::erase(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::iterator position)
{
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > > *v3; // rax
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer next; // rcx
  boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::multi_index::detail::hashed_unique_tag> *prior; // rdx
  bool v6; // zf
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v7; // rsi
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *p_next; // r14
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v9; // rdi
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > > *v10; // rsi
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v11; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v12; // rcx

  v3 = &position.node->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > >;
  next = position.node->next_;
  prior = (boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::multi_index::detail::hashed_unique_tag> *)next->prior_;
  v6 = next->prior_ == &position.node->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > >;
  v7 = next->prior_;
  if ( v6 )
    v7 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)next;
  p_next = &v7[-3].next_;
  if ( !v7 )
    p_next = 0;
  --*((_QWORD *)this + 7);
  v9 = position.node->prior_;
  v10 = (boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > > *)v9->next_;
  if ( v10 == v3 )
  {
    v9->next_ = next;
    v12 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)position.node->next_;
    if ( prior != (boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::multi_index::detail::hashed_unique_tag> *)v3 )
      v12 = v12->prior_;
    v11 = v3->prior_;
  }
  else if ( prior == (boost::multi_index::detail::hashed_index_node<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::multi_index::detail::hashed_unique_tag> *)v3 )
  {
    v10->prior_ = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)next;
    v11 = position.node->prior_;
    v12 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)position.node->next_;
  }
  else
  {
    v10->prior_ = 0;
    position.node->prior_->next_ = position.node->next_;
    v11 = position.node->prior_;
    v12 = position.node->next_->prior_;
  }
  v12->prior_ = v11;
  if ( (position.node->space.data_.buf[0] & 1) != 0 )
    operator delete(*((void **)&position.node->space.data_.align_ + 2));
  operator delete(position.node);
  return (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::iterator)p_next;
}


// Address: 0x15446f0 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyINSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEEE8rep_typeESE_EEEENS_4hashISE_EENS8_8equal_toISE_EENS1_9nth_layerILi1ESH_NS4_20hashed_factory_classISH_SE_N4mpl_2naESQ_SQ_E10index_listENSC_ISH_EEEENS_3mpl7vector0ISQ_EENS1_17hashed_unique_tagEE7insert_INS1_10rvalue_tagEEEPNS1_17hashed_index_nodeINS1_15index_node_baseISH_ST_EESY_EERKSH_RS16_T_
boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *__fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>,boost::hash<std::string>,std::equal_to<std::string>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        char *v,
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **x,
        boost::multi_index::detail::rvalue_tag variant)
{
  size_type v7; // rax
  __m128i v8; // xmm0
  float v9; // xmm0_4
  unsigned __int64 v10; // rax
  size_type v11; // rsi
  unsigned __int64 v12; // rdi
  char *v13; // rax
  unsigned __int64 v14; // rdi
  __int64 v15; // r8
  size_t v16; // rdi
  unsigned __int64 v17; // rsi
  unsigned __int64 v18; // rdx
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer prior; // r12
  char v20; // bl
  unsigned __int64 v21; // r13
  size_t v22; // rbp
  unsigned __int64 next_low; // rax
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *p_next; // r14
  char *v25; // rsi
  __int64 v26; // rax
  _QWORD *p_prior; // rax
  bool v28; // zf
  __int64 *v29; // rbp
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *v30; // rax
  __int64 v31; // rax
  size_type max_load; // rcx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v33; // rdx
  char *s1; // [rsp+0h] [rbp-58h]
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *v36; // [rsp+8h] [rbp-50h]
  boost::multi_index::detail::auto_space<boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >::pointer data; // [rsp+10h] [rbp-48h]
  size_t v38; // [rsp+18h] [rbp-40h]
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **v39; // [rsp+20h] [rbp-38h]

  v7 = *((_QWORD *)this + 7) + 1LL;
  if ( this->max_load < v7 )
  {
    v8 = (__m128i)_mm_sub_pd(
                    (__m128d)_mm_unpacklo_epi32((__m128i)v7, (__m128i)xmmword_3E4930),
                    *(__m128d *)(&errorFunction.functor.data + 8));
    v9 = (*(double *)_mm_shuffle_epi32(v8, 78).m128i_i64 + *(double *)v8.m128i_i64) / this->mlf + 1.0;
    v10 = (unsigned int)(int)v9;
    if ( v9 >= 9.223372e18 )
      v10 = (unsigned int)(int)(float)(v9 - 9.223372e18) ^ 0x8000000000000000LL;
    v11 = -1;
    if ( v9 < 1.8446744e19 )
      v11 = v10;
    boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>,boost::hash<std::string>,std::equal_to<std::string>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::unchecked_rehash(
      this,
      v11,
      (boost::multi_index::detail::hashed_unique_tag)x);
  }
  v12 = (unsigned __int8)*v;
  v13 = v + 1;
  s1 = v + 1;
  if ( (v12 & 1) != 0 )
  {
    v13 = (char *)*((_QWORD *)v + 2);
    v14 = *((_QWORD *)v + 1);
  }
  else
  {
    v14 = v12 >> 1;
  }
  v39 = x;
  if ( v14 )
  {
    v15 = v14 & 1;
    if ( v14 == 1 )
    {
      v16 = 0;
      if ( !v15 )
        goto LABEL_19;
    }
    else
    {
      v17 = v15 - v14;
      v16 = 0;
      do
      {
        v18 = v16 ^ (*v13 + (v16 >> 2) + (v16 << 6) + 2654435769u);
        v16 = v18 ^ (v13[1] + (v18 >> 2) + (v18 << 6) + 2654435769u);
        v13 += 2;
        v17 += 2LL;
      }
      while ( v17 );
      if ( !v15 )
        goto LABEL_19;
    }
    v16 ^= (v16 << 6) + 2654435769u + (v16 >> 2) + *v13;
  }
  else
  {
    v16 = 0;
  }
LABEL_19:
  v36 = this;
  v38 = boost::multi_index::detail::bucket_array_base<true>::position(v16, this->buckets.size_index_);
  data = this->buckets.spc.data_;
  prior = data[v38].prior_;
  if ( !prior )
  {
LABEL_39:
    v29 = (__int64 *)&data[v38];
    v30 = (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *)operator new(0x38u);
    *v39 = v30;
    *((_QWORD *)&v30->space.data_.align_ + 2) = *((_QWORD *)v + 2);
    *(_OWORD *)v30->space.data_.buf = *(_OWORD *)v;
    *(_OWORD *)v = 0;
    *((_QWORD *)v + 2) = 0;
    *((_DWORD *)&v30->space.data_.align_ + 6) = 0;
    *((_QWORD *)&v30->space.data_.align_ + 4) = 0;
    p_next = *v39;
    v31 = (__int64)&(*v39)->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > >;
    if ( *v29 )
    {
      p_next->prior_ = *(boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer *)*v29;
      p_next->next_ = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer)*v29;
      *v29 = v31;
      p_next->next_->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::__1::basic_string<char> >::rep_type,std::__1::basic_string<char> >,std::__1::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::__1::basic_string<char> >::rep_type,std::__1::basic_string<char> > > > >::boost::multi_index::detail::hashed_index_node_impl<std::__1::allocator<char> >::prior_ = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)v31;
    }
    else
    {
      max_load = v36[-1].max_load;
      v33 = *(boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > **)(max_load + 40);
      p_next->prior_ = v33;
      p_next->next_ = *(boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *)(*(_QWORD *)(max_load + 40) + 8LL);
      v33->next_ = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer)v29;
      *v29 = v31;
      *(_QWORD *)(max_load + 40) = v31;
    }
    return p_next;
  }
  v20 = *v;
  v21 = (unsigned __int64)(unsigned __int8)*v >> 1;
  v22 = v21;
  if ( (*v & 1) != 0 )
  {
    v22 = *((_QWORD *)v + 1);
    s1 = (char *)*((_QWORD *)v + 2);
  }
  while ( 1 )
  {
    next_low = LOBYTE(prior[-3].next_);
    if ( (next_low & 1) != 0 )
    {
      if ( (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)v22 != prior[-2].prior_ )
        goto LABEL_37;
    }
    else if ( v22 != next_low >> 1 )
    {
      goto LABEL_37;
    }
    p_next = (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *)&prior[-3].next_;
    if ( (next_low & 1) != 0 )
    {
      v25 = (char *)*((_QWORD *)&p_next->space.data_.align_ + 2);
      if ( (v20 & 1) != 0 )
        break;
      goto LABEL_32;
    }
    v25 = &p_next->space.data_.buf[1];
    if ( (v20 & 1) != 0 )
      break;
LABEL_32:
    if ( !v22 )
      goto LABEL_41;
    v26 = 0;
    while ( v[v26 + 1] == v25[v26] )
    {
      if ( v21 == ++v26 )
        goto LABEL_41;
    }
LABEL_37:
    p_prior = &prior->next_->prior_;
    if ( p_prior )
    {
      v28 = *p_prior == (_QWORD)prior;
      prior = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)prior->next_;
      if ( v28 )
        continue;
    }
    goto LABEL_39;
  }
  if ( v22 && memcmp(s1, v25, v22) )
    goto LABEL_37;
LABEL_41:
  if ( !prior )
    return 0;
  return p_next;
}


// Address: 0x1544a30 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyINSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEEE8rep_typeESE_EEEENS_4hashISE_EENS8_8equal_toISE_EENS1_9nth_layerILi1ESH_NS4_20hashed_factory_classISH_SE_N4mpl_2naESQ_SQ_E10index_listENSC_ISH_EEEENS_3mpl7vector0ISQ_EENS1_17hashed_unique_tagEE16unchecked_rehashEmSY_
void __fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>,boost::hash<std::string>,std::equal_to<std::string>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::unchecked_rehash(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        size_type n,
        boost::multi_index::detail::hashed_unique_tag a3)
{
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v3; // r15
  unsigned __int64 v4; // r13
  __int64 i; // rbp
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *prior; // r14
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *p_next; // rax
  unsigned __int64 v8; // rsi
  unsigned __int64 v9; // rsi
  char *v10; // rax
  size_t v11; // rdi
  unsigned __int64 v12; // rdx
  unsigned __int64 v13; // rbx
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v14; // rax
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *next; // rcx
  size_t v16; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v17; // rcx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v18; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v19; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v20; // rax
  __int64 v21; // rcx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer v22; // rax
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *v23; // rsi
  size_t size_index; // rax
  size_t v25; // rcx
  size_t v26; // rax
  __int128 v27; // xmm0
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *data; // rdi
  __int64 v29; // rcx
  float v30; // xmm0_4
  float v31; // xmm0_4
  unsigned __int64 v32; // rcx
  __int64 v33; // rdx
  std::logic_error *exception; // rbx
  std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > v35; // [rsp+0h] [rbp-78h] BYREF
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > v36; // [rsp+8h] [rbp-70h] BYREF
  boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > v37; // [rsp+18h] [rbp-60h] BYREF
  __int64 v38; // [rsp+38h] [rbp-40h]
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *v39; // [rsp+40h] [rbp-38h]

  v38 = *((_QWORD *)this - 1);
  v3 = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)(v38 + 40);
  boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>::bucket_array(
    &v37,
    &v35,
    &v36,
    n);
  v39 = this;
  v4 = *((_QWORD *)this + 7);
  if ( v4 )
  {
    if ( v4 >> 61 )
    {
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(exception, "allocator<T>::allocate(size_t n) 'n' exceeds maximum supported size");
      *(_QWORD *)exception = (char *)&`vtable for'std::length_error + 16;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::length_error,
        (void (*)(void *))&std::length_error::~length_error);
    }
    for ( i = 0; i != v4; ++i )
    {
      prior = v3->prior_;
      p_next = &v3->prior_[-3].next_;
      if ( !v3->prior_ )
        p_next = 0;
      v8 = *(unsigned __int8 *)p_next;
      if ( (v8 & 1) != 0 )
      {
        v9 = (unsigned __int64)p_next[1];
        v10 = (char *)p_next[2];
        if ( !v9 )
          goto LABEL_11;
      }
      else
      {
        v10 = (char *)p_next + 1;
        v9 = v8 >> 1;
        if ( !v9 )
        {
LABEL_11:
          v11 = 0;
          goto LABEL_16;
        }
      }
      if ( v9 == 1 )
      {
        v11 = 0;
      }
      else
      {
        v12 = (v9 & 1) - v9;
        v11 = 0;
        do
        {
          v13 = v11 ^ (*v10 + (v11 >> 2) + (v11 << 6) + 2654435769u);
          v11 = v13 ^ (v10[1] + (v13 >> 2) + (v13 << 6) + 2654435769u);
          v10 += 2;
          v12 += 2LL;
        }
        while ( v12 );
        if ( (v9 & 1) == 0 )
          goto LABEL_16;
      }
      v11 ^= (v11 << 6) + 2654435769u + (v11 >> 2) + *v10;
LABEL_16:
      v14 = prior->prior_;
      next = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)prior->prior_->next_;
      if ( next != prior )
      {
        next->prior_ = 0;
        v14 = prior->prior_;
      }
      v14->next_ = prior->next_;
      v3->prior_ = prior->prior_;
      v16 = boost::multi_index::detail::bucket_array_base<true>::position(v11, v37.size_index_);
      v17 = &v37.spc.data_[v16];
      if ( v17->prior_ )
      {
        prior->prior_ = v17->prior_->prior_;
        prior->next_ = v17->prior_;
        v17->prior_ = prior;
        v18 = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)prior->next_;
      }
      else
      {
        v19 = v36.prior_;
        prior->prior_ = v36.prior_;
        prior->next_ = v36.prior_->next_;
        v19->next_ = v17;
        v17->prior_ = prior;
        v18 = &v36;
      }
      v18->prior_ = prior;
    }
  }
  v20 = v36.prior_;
  if ( v36.prior_ == &v36 )
    v20 = v3;
  v21 = v38;
  *(_QWORD *)(v38 + 40) = v20;
  v22 = v36.next_;
  *(_QWORD *)(v21 + 48) = v36.next_;
  v22->prior_->prior_ = v3;
  **(_QWORD **)(*(_QWORD *)(v21 + 40) + 8LL) = v3;
  v23 = v39;
  size_index = v39->buckets.size_index_;
  v25 = v37.size_index_;
  v39->buckets.size_index_ = v37.size_index_;
  v37.size_index_ = size_index;
  v26 = v23->buckets.spc.n_;
  v27 = *(_OWORD *)&v37.spc.n_;
  v37.spc.n_ = v26;
  data = v23->buckets.spc.data_;
  *(_OWORD *)&v23->buckets.spc.n_ = v27;
  v37.spc.data_ = data;
  v29 = *(_QWORD *)&a5[8 * v25];
  if ( v29 < 0 )
    v30 = (float)(int)(((unsigned __int64)v29 >> 1) | v29 & 1) + (float)(int)(((unsigned __int64)v29 >> 1) | v29 & 1);
  else
    v30 = (float)(int)v29;
  v31 = v30 * v23->mlf;
  v32 = (unsigned int)(int)v31;
  if ( v31 >= 9.223372e18 )
    v32 = (unsigned int)(int)(float)(v31 - 9.223372e18) ^ 0x8000000000000000LL;
  v33 = -1;
  if ( v31 < 1.8446744e19 )
    v33 = v32;
  v23->max_load = v33;
  if ( v26 )
    operator delete(data);
}


// Address: 0x1e2db50 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyIN3RBX18PhysicalPropertiesEE8rep_typeES9_EEEENS_4hashIS9_EENSt3__18equal_toIS9_EENS1_9nth_layerILi1ESC_NS4_20hashed_factory_classISC_S9_N4mpl_2naESM_SM_E10index_listENSG_9allocatorISC_EEEENS_3mpl7vector0ISM_EENS1_17hashed_unique_tagEE7insert_INS1_10rvalue_tagEEEPNS1_17hashed_index_nodeINS1_15index_node_baseISC_SQ_EESV_EERKSC_RS13_T_
boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *__fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::insert_<boost::multi_index::detail::rvalue_tag>(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::value_param_type v,
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type **x,
        boost::multi_index::detail::rvalue_tag variant)
{
  size_type v7; // rax
  __m128i v8; // xmm0
  float v9; // xmm0_4
  unsigned __int64 v10; // rax
  size_type v11; // rsi
  size_t v12; // rax
  size_t v13; // rdi
  boost::multi_index::detail::auto_space<boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >::pointer data; // rdx
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer prior; // rsi
  boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *result; // rax
  _QWORD *p_prior; // rax
  bool v18; // zf
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer **v19; // rbx
  boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > > *v20; // rcx
  __int64 v21; // rdx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v22; // rsi

  v7 = *((_QWORD *)this + 7) + 1LL;
  if ( this->max_load < v7 )
  {
    v8 = (__m128i)_mm_sub_pd(
                    (__m128d)_mm_unpacklo_epi32((__m128i)v7, (__m128i)xmmword_3E4930),
                    *(__m128d *)(&errorFunction.functor.data + 8));
    v9 = (*(double *)_mm_shuffle_epi32(v8, 78).m128i_i64 + *(double *)v8.m128i_i64) / this->mlf + 1.0;
    v10 = (unsigned int)(int)v9;
    if ( v9 >= 9.223372e18 )
      v10 = (unsigned int)(int)(float)(v9 - 9.223372e18) ^ 0x8000000000000000LL;
    v11 = -1;
    if ( v9 < 1.8446744e19 )
      v11 = v10;
    boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::unchecked_rehash(
      this,
      v11,
      (boost::multi_index::detail::hashed_unique_tag)x);
  }
  v12 = RBX::hash_value(&v->x.x);
  v13 = boost::multi_index::detail::bucket_array_base<true>::position(v12, this->buckets.size_index_);
  data = this->buckets.spc.data_;
  prior = data[v13].prior_;
  if ( prior )
  {
    while ( 1 )
    {
      if ( v->x.x.customEnabled == LOBYTE(prior[-3].next_) )
      {
        result = (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *)&prior[-3].next_;
        if ( v->x.x.density == *((float *)&prior[-3].next_ + 1)
          && v->x.x.friction == *((float *)&result->space.data_.align_ + 3)
          && v->x.x.elasticity == *((float *)&result->space.data_.align_ + 2)
          && v->x.x.frictionWeight == *((float *)&result->space.data_.align_ + 4)
          && v->x.x.elasticityWeight == *((float *)&result->space.data_.align_ + 5) )
        {
          break;
        }
      }
      p_prior = &prior->next_->prior_;
      if ( p_prior )
      {
        v18 = *p_prior == (_QWORD)prior;
        prior = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer)prior->next_;
        if ( v18 )
          continue;
      }
      goto LABEL_16;
    }
  }
  else
  {
LABEL_16:
    v19 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer **)&data[v13];
    result = (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::final_node_type *)operator new(0x38u);
    *x = result;
    *((_QWORD *)&result->space.data_.align_ + 2) = *(_QWORD *)&v->x.x.frictionWeight;
    *(_OWORD *)result->space.data_.buf = *(_OWORD *)&v->x.x.customEnabled;
    *((_DWORD *)&result->space.data_.align_ + 6) = 0;
    *((_QWORD *)&result->space.data_.align_ + 4) = 0;
    v20 = &result->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > >;
    if ( *v19 )
    {
      result->prior_ = **v19;
      result->next_ = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer)*v19;
      *v19 = &v20->prior_;
      result->next_->boost::multi_index::detail::hashed_index_node_trampoline<boost::multi_index::detail::index_node_base<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,std::__1::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > >::boost::multi_index::detail::hashed_index_node_impl<std::__1::allocator<char> >::prior_ = v20;
    }
    else
    {
      v21 = *((_QWORD *)this - 1);
      v22 = *(boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > **)(v21 + 40);
      result->prior_ = v22;
      result->next_ = *(boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *)(*(_QWORD *)(v21 + 40) + 8LL);
      v22->next_ = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer)v19;
      *v19 = &v20->prior_;
      *(_QWORD *)(v21 + 40) = v20;
    }
  }
  return result;
}


// Address: 0x1e2dd30 | Name: _ZN5boost11multi_index6detail12hashed_indexINS0_8identityINS_10flyweights6detail16refcounted_valueINS5_20default_value_policyIN3RBX18PhysicalPropertiesEE8rep_typeES9_EEEENS_4hashIS9_EENSt3__18equal_toIS9_EENS1_9nth_layerILi1ESC_NS4_20hashed_factory_classISC_S9_N4mpl_2naESM_SM_E10index_listENSG_9allocatorISC_EEEENS_3mpl7vector0ISM_EENS1_17hashed_unique_tagEE16unchecked_rehashEmSV_
void __fastcall boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::unchecked_rehash(
        boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> >,boost::hash<RBX::PhysicalProperties>,std::equal_to<RBX::PhysicalProperties>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>,RBX::PhysicalProperties,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *this,
        size_type n,
        boost::multi_index::detail::hashed_unique_tag a3)
{
  __int64 v4; // rbx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v5; // r12
  unsigned __int64 v6; // rbp
  _QWORD *v7; // r14
  _QWORD *v8; // r15
  __int64 v9; // rbp
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *prior; // rbx
  const RBX::PhysicalProperties *p_next; // rdi
  size_t v12; // rax
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *v13; // rcx
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v14; // rdx
  _QWORD *p_prior; // rsi
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer *v16; // rdx
  size_t v17; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v18; // rcx
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *next; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v20; // rax
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> >::pointer v21; // rax
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> >::base_pointer v22; // rax
  size_t size_index; // rax
  size_t v24; // rcx
  size_t v25; // rax
  __int128 v26; // xmm0
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *data; // rdi
  __int64 v28; // rcx
  float v29; // xmm0_4
  float v30; // xmm0_4
  unsigned __int64 v31; // rcx
  size_type v32; // rdx
  std::logic_error *exception; // r14
  std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > al_0; // [rsp+8h] [rbp-80h] BYREF
  __int64 v35; // [rsp+10h] [rbp-78h]
  boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > v36; // [rsp+18h] [rbp-70h] BYREF
  boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > v37; // [rsp+28h] [rbp-60h] BYREF
  __int64 v38; // [rsp+48h] [rbp-40h]
  unsigned __int64 v39; // [rsp+50h] [rbp-38h]

  v4 = *((_QWORD *)this - 1);
  v5 = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)(v4 + 40);
  boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>>::bucket_array(
    &v37,
    &al_0,
    &v36,
    n);
  v6 = *((_QWORD *)this + 7);
  if ( v6 )
  {
    if ( v6 >> 61 )
    {
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(exception, "allocator<T>::allocate(size_t n) 'n' exceeds maximum supported size");
      *(_QWORD *)exception = (char *)&`vtable for'std::length_error + 16;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::length_error,
        (void (*)(void *))&std::length_error::~length_error);
    }
    v7 = operator new(8 * v6);
    v39 = v6;
    v38 = v4;
    v8 = operator new(8 * v6);
    v35 = -1;
    v9 = 0;
    do
    {
      prior = v5->prior_;
      p_next = (const RBX::PhysicalProperties *)&v5->prior_[-3].next_;
      if ( !v5->prior_ )
        p_next = 0;
      v12 = RBX::hash_value(p_next);
      v7[v9] = v12;
      v8[v9] = prior;
      v13 = v5->prior_;
      v14 = v5->prior_->prior_;
      p_prior = &v14->next_->prior_;
      if ( p_prior == (_QWORD *)v5->prior_ )
      {
        v16 = &v14->next_;
        v35 = 0;
      }
      else
      {
        *p_prior = 0;
        v16 = &v13->prior_->next_;
        v35 = -1;
      }
      *v16 = v13->next_;
      v5->prior_ = v13->prior_;
      v17 = boost::multi_index::detail::bucket_array_base<true>::position(v12, v37.size_index_);
      v18 = &v37.spc.data_[v17];
      if ( v18->prior_ )
      {
        prior->prior_ = v18->prior_->prior_;
        prior->next_ = v18->prior_;
        v18->prior_ = prior;
        next = (boost::multi_index::detail::hashed_index_node_impl<std::allocator<char> > *)prior->next_;
      }
      else
      {
        v20 = v36.prior_;
        prior->prior_ = v36.prior_;
        prior->next_ = v36.prior_->next_;
        v20->next_ = v18;
        v18->prior_ = prior;
        next = &v36;
      }
      next->prior_ = prior;
      ++v9;
    }
    while ( v39 != v9 );
    operator delete(v8);
    operator delete(v7);
    v4 = v38;
  }
  v21 = v36.prior_;
  if ( v36.prior_ == &v36 )
    v21 = v5;
  *(_QWORD *)(v4 + 40) = v21;
  v22 = v36.next_;
  *(_QWORD *)(v4 + 48) = v36.next_;
  v22->prior_->prior_ = v5;
  **(_QWORD **)(*(_QWORD *)(v4 + 40) + 8LL) = v5;
  size_index = this->buckets.size_index_;
  v24 = v37.size_index_;
  this->buckets.size_index_ = v37.size_index_;
  v37.size_index_ = size_index;
  v25 = this->buckets.spc.n_;
  v26 = *(_OWORD *)&v37.spc.n_;
  v37.spc.n_ = v25;
  data = this->buckets.spc.data_;
  *(_OWORD *)&this->buckets.spc.n_ = v26;
  v37.spc.data_ = data;
  v28 = *(_QWORD *)&a5[8 * v24];
  if ( v28 < 0 )
    v29 = (float)(int)(((unsigned __int64)v28 >> 1) | v28 & 1) + (float)(int)(((unsigned __int64)v28 >> 1) | v28 & 1);
  else
    v29 = (float)(int)v28;
  v30 = v29 * this->mlf;
  v31 = (unsigned int)(int)v30;
  if ( v30 >= 9.223372e18 )
    v31 = (unsigned int)(int)(float)(v30 - 9.223372e18) ^ 0x8000000000000000LL;
  v32 = -1;
  if ( v30 < 1.8446744e19 )
    v32 = v31;
  this->max_load = v32;
  if ( v25 )
    operator delete(data);
}


