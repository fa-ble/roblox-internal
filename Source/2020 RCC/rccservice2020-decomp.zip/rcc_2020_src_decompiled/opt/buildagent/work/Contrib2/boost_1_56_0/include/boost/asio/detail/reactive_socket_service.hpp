// Address: 0x2603ed0 | Name: _ZNK5boost4asio6detail23reactive_socket_serviceINS0_2ip3tcpEE15remote_endpointERKNS5_19implementation_typeERNS_6system10error_codeE
boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::endpoint_type *__fastcall boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::remote_endpoint(
        boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::endpoint_type *__return_ptr retstr,
        const boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp> *this,
        const boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        boost::system::error_code *ec)
{
  boost::asio::detail::socket_type socket; // ebp
  int *v6; // r15
  int v7; // r13d
  unsigned int v8; // r12d
  int v9; // ebp
  const boost::system::error_category *v10; // rax
  const boost::system::error_category *v11; // rax
  boost::asio::detail::socket_addr_type v12; // xmm0
  const boost::system::error_category *v13; // rax
  const boost::system::error_category *v15; // rbx
  socklen_t v16[4]; // [rsp+0h] [rbp-88h] BYREF
  int v17; // [rsp+10h] [rbp-78h]
  const boost::system::error_category *v18; // [rsp+18h] [rbp-70h]
  __int128 v19; // [rsp+20h] [rbp-68h]
  void *ptr; // [rsp+30h] [rbp-58h]
  _OWORD addr[5]; // [rsp+38h] [rbp-50h] BYREF

  memset((char *)addr + 8, 0, 20);
  *(_QWORD *)&addr[0] = 2;
  socket = impl->socket_;
  if ( impl->socket_ == -1 )
  {
    v13 = boost::system::system_category();
    ec->m_val = 9;
    ec->m_cat = v13;
    goto LABEL_6;
  }
  v6 = __errno_location();
  *v6 = 0;
  v16[0] = 28;
  v7 = getpeername(socket, (struct sockaddr *)addr, v16);
  v8 = v16[0];
  v9 = *v6;
  v10 = boost::system::system_category();
  ec->m_val = v9;
  ec->m_cat = v10;
  if ( v7 )
  {
LABEL_6:
    retstr->impl_.data_.v6.sin6_addr = 0;
    retstr->impl_.data_.v6.sin6_scope_id = 0;
    *(_QWORD *)&retstr->impl_.data_.base.sa_family = 2;
    return retstr;
  }
  v11 = boost::system::system_category();
  ec->m_val = 0;
  ec->m_cat = v11;
  if ( v8 >= 0x81 )
  {
    v15 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v16, (const char *)&uri_string);
    *(_QWORD *)v16 = off_2875F00;
    v17 = 22;
    v18 = v15;
    v19 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v16);
  }
  v12 = (boost::asio::detail::socket_addr_type)addr[0];
  *(in6_addr_0 *)((char *)&retstr->impl_.data_.v6.sin6_addr + 4) = *(in6_addr_0 *)((char *)addr + 12);
  retstr->impl_.data_.base = v12;
  return retstr;
}


// Address: 0x2625510 | Name: _ZN5boost4asio6detail23reactive_socket_serviceINS0_2ip3tcpEE13async_connectINS1_10connect_opIS4_NS0_21stream_socket_serviceIS4_EENS3_23basic_resolver_iteratorIS4_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSI_6config15asio_tls_client16transport_configEEEFvNSG_10shared_ptrINSK_10connectionISO_EEEENSQ_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISW_EENS0_22deadline_timer_serviceISW_SY_EEEEEENSG_8functionIFvRKNSG_10error_codeEEEERKNS_6system10error_codeEEJPSP_RST_RS12_RS18_RKNSG_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEEvRNS5_19implementation_typeERKNS3_14basic_endpointIS4_EERT_
void __fastcall boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::async_connect<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::endpoint_type *peer_endpoint,
        boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  boost::asio::detail::strand_service::implementation_type *v6; // rax
  boost::asio::detail::strand_service::implementation_type v7; // rcx
  bool v8; // r15
  unsigned __int64 v9; // rax
  void **v10; // rax
  void *v11; // rdi
  char *v12; // rbx
  boost::asio::detail::socket_type socket; // ebp
  size_t v14; // r9

  v6 = (boost::asio::detail::strand_service::implementation_type *)__readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    v7 = handler->handler_.dispatcher_.impl_;
    while ( *v6 != v7 )
    {
      v6 = (boost::asio::detail::strand_service::implementation_type *)v6[2];
      if ( !v6 )
        goto LABEL_5;
    }
    v8 = v6[1] != 0;
  }
  else
  {
LABEL_5:
    v8 = 0;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( v9 )
  {
    v10 = *(void ***)(v9 + 8);
    if ( v10 )
    {
      v11 = *v10;
      if ( *v10 )
      {
        *v10 = 0;
        operator delete(v11);
      }
    }
  }
  v12 = (char *)operator new(0x101u);
  v12[256] = 0;
  socket = impl->socket_;
  *(_QWORD *)v12 = 0;
  *((_QWORD *)v12 + 1) = boost::asio::detail::reactive_socket_connect_op<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete;
  *((_DWORD *)v12 + 4) = 0;
  *((_DWORD *)v12 + 6) = 0;
  *((_QWORD *)v12 + 4) = boost::system::system_category();
  *((_QWORD *)v12 + 5) = 0;
  *((_QWORD *)v12 + 6) = boost::asio::detail::reactive_socket_connect_op_base::do_perform;
  *((_DWORD *)v12 + 14) = socket;
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    (boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)(v12 + 64),
    handler);
  v14 = 28;
  if ( peer_endpoint->impl_.data_.base.sa_family == 2 )
    v14 = 16;
  boost::asio::detail::reactive_socket_service_base::start_connect_op(
    this,
    impl,
    (boost::asio::detail::reactor_op *)v12,
    v8,
    &peer_endpoint->impl_.data_.base,
    v14);
}


// Address: 0x26671a0 | Name: _ZN5boost4asio6detail23reactive_socket_serviceINS0_2ip3tcpEE13async_connectINS1_10connect_opIS4_NS0_21stream_socket_serviceIS4_EENS3_23basic_resolver_iteratorIS4_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSI_6config11asio_client16transport_configEEEFvNSG_10shared_ptrINSK_10connectionISO_EEEENSQ_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISW_EENS0_22deadline_timer_serviceISW_SY_EEEEEENSG_8functionIFvRKNSG_10error_codeEEEERKNS_6system10error_codeEEJPSP_RST_RS12_RS18_RKNSG_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEEvRNS5_19implementation_typeERKNS3_14basic_endpointIS4_EERT_
void __fastcall boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::async_connect<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::endpoint_type *peer_endpoint,
        boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  boost::asio::detail::strand_service::implementation_type *v6; // rax
  boost::asio::detail::strand_service::implementation_type v7; // rcx
  bool v8; // r15
  unsigned __int64 v9; // rax
  void **v10; // rax
  void *v11; // rdi
  char *v12; // rbx
  boost::asio::detail::socket_type socket; // ebp
  size_t v14; // r9

  v6 = (boost::asio::detail::strand_service::implementation_type *)__readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    v7 = handler->handler_.dispatcher_.impl_;
    while ( *v6 != v7 )
    {
      v6 = (boost::asio::detail::strand_service::implementation_type *)v6[2];
      if ( !v6 )
        goto LABEL_5;
    }
    v8 = v6[1] != 0;
  }
  else
  {
LABEL_5:
    v8 = 0;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( v9 )
  {
    v10 = *(void ***)(v9 + 8);
    if ( v10 )
    {
      v11 = *v10;
      if ( *v10 )
      {
        *v10 = 0;
        operator delete(v11);
      }
    }
  }
  v12 = (char *)operator new(0x101u);
  v12[256] = 0;
  socket = impl->socket_;
  *(_QWORD *)v12 = 0;
  *((_QWORD *)v12 + 1) = boost::asio::detail::reactive_socket_connect_op<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete;
  *((_DWORD *)v12 + 4) = 0;
  *((_DWORD *)v12 + 6) = 0;
  *((_QWORD *)v12 + 4) = boost::system::system_category();
  *((_QWORD *)v12 + 5) = 0;
  *((_QWORD *)v12 + 6) = boost::asio::detail::reactive_socket_connect_op_base::do_perform;
  *((_DWORD *)v12 + 14) = socket;
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    (boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)(v12 + 64),
    handler);
  v14 = 28;
  if ( peer_endpoint->impl_.data_.base.sa_family == 2 )
    v14 = 16;
  boost::asio::detail::reactive_socket_service_base::start_connect_op(
    this,
    impl,
    (boost::asio::detail::reactor_op *)v12,
    v8,
    &peer_endpoint->impl_.data_.base,
    v14);
}


// Address: 0x26a1720 | Name: _ZN5boost4asio6detail23reactive_socket_serviceINS0_2ip3tcpEE13async_connectINS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEENS7_5list3INS7_5valueINSt3__110shared_ptrISG_EEEEPFNS_3argILi1EEEvENSP_ISM_EEEEEEEEvRNS5_19implementation_typeERKNS3_14basic_endpointIS4_EERT_
void __fastcall boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::async_connect<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>(
        boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::endpoint_type *peer_endpoint,
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > *handler)
{
  unsigned __int64 v6; // rax
  char **v7; // rax
  char *v8; // rbx
  char v9; // al
  boost::asio::detail::socket_type socket; // ebp
  size_t v11; // r9
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > >::ptr v12; // [rsp+0h] [rbp-48h] BYREF

  v12.h = handler;
  v6 = __readfsqword(0xFFFFFFD8);
  if ( v6 )
  {
    v7 = *(char ***)(v6 + 8);
    if ( v7 )
    {
      v8 = *v7;
      if ( *v7 )
      {
        *v7 = 0;
        v9 = *v8;
        if ( (unsigned __int8)*v8 > 0x77u )
          goto LABEL_7;
        operator delete(v8);
      }
    }
  }
  v8 = (char *)operator new(0x79u);
  v9 = 120;
LABEL_7:
  v8[120] = v9;
  v12.v = v8;
  socket = impl->socket_;
  *(_QWORD *)v8 = 0;
  *((_QWORD *)v8 + 1) = boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::do_complete;
  *((_DWORD *)v8 + 4) = 0;
  *((_DWORD *)v8 + 6) = 0;
  *((_QWORD *)v8 + 4) = boost::system::system_category();
  *((_QWORD *)v8 + 5) = 0;
  *((_QWORD *)v8 + 6) = boost::asio::detail::reactive_socket_connect_op_base::do_perform;
  *((_DWORD *)v8 + 14) = socket;
  *((_OWORD *)v8 + 4) = handler->f_;
  *((_OWORD *)v8 + 5) = handler->l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>;
  handler->l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> = 0;
  *((_OWORD *)v8 + 6) = handler->l_.a3_.t_.values_;
  handler->l_.a3_.t_.values_ = 0;
  *((_QWORD *)v8 + 14) = handler->l_.a3_.t_.index_;
  v12.p = (boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > > *)v8;
  v11 = 28;
  if ( peer_endpoint->impl_.data_.base.sa_family == 2 )
    v11 = 16;
  boost::asio::detail::reactive_socket_service_base::start_connect_op(
    this,
    impl,
    (boost::asio::detail::reactor_op *)v8,
    0,
    &peer_endpoint->impl_.data_.base,
    v11);
  *(_OWORD *)&v12.v = 0;
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::ptr::reset(&v12);
}


// Address: 0x26bc630 | Name: _ZN5boost4asio6detail23reactive_socket_serviceINS0_2ip3tcpEE13async_connectINS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEENS7_5list3INS7_5valueINSt3__110shared_ptrISF_EEEEPFNS_3argILi1EEEvENSO_ISL_EEEEEEEEvRNS5_19implementation_typeERKNS3_14basic_endpointIS4_EERT_
void __fastcall boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::async_connect<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>(
        boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::endpoint_type *peer_endpoint,
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > *handler)
{
  unsigned __int64 v6; // rax
  char **v7; // rax
  char *v8; // rbx
  char v9; // al
  boost::asio::detail::socket_type socket; // ebp
  size_t v11; // r9
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > >::ptr v12; // [rsp+0h] [rbp-48h] BYREF

  v12.h = handler;
  v6 = __readfsqword(0xFFFFFFD8);
  if ( v6 )
  {
    v7 = *(char ***)(v6 + 8);
    if ( v7 )
    {
      v8 = *v7;
      if ( *v7 )
      {
        *v7 = 0;
        v9 = *v8;
        if ( (unsigned __int8)*v8 > 0x77u )
          goto LABEL_7;
        operator delete(v8);
      }
    }
  }
  v8 = (char *)operator new(0x79u);
  v9 = 120;
LABEL_7:
  v8[120] = v9;
  v12.v = v8;
  socket = impl->socket_;
  *(_QWORD *)v8 = 0;
  *((_QWORD *)v8 + 1) = boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::do_complete;
  *((_DWORD *)v8 + 4) = 0;
  *((_DWORD *)v8 + 6) = 0;
  *((_QWORD *)v8 + 4) = boost::system::system_category();
  *((_QWORD *)v8 + 5) = 0;
  *((_QWORD *)v8 + 6) = boost::asio::detail::reactive_socket_connect_op_base::do_perform;
  *((_DWORD *)v8 + 14) = socket;
  *((_OWORD *)v8 + 4) = handler->f_;
  *((_OWORD *)v8 + 5) = handler->l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  *((_OWORD *)v8 + 6) = handler->l_.a3_.t_.values_;
  handler->l_.a3_.t_.values_ = 0;
  *((_QWORD *)v8 + 14) = handler->l_.a3_.t_.index_;
  v12.p = (boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > > *)v8;
  v11 = 28;
  if ( peer_endpoint->impl_.data_.base.sa_family == 2 )
    v11 = 16;
  boost::asio::detail::reactive_socket_service_base::start_connect_op(
    this,
    impl,
    (boost::asio::detail::reactor_op *)v8,
    0,
    &peer_endpoint->impl_.data_.base,
    v11);
  *(_OWORD *)&v12.v = 0;
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::ptr::reset(&v12);
}


