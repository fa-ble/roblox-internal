// Address: 0x2029000 | Name: _ZN5boost9iostreams6streamINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS4_9allocatorIcEEEC1IPKcmEERKT_RKT0_PNS_10disable_ifINS_7is_sameISD_S3_EEvE4typeE
void __fastcall boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>>::stream<char const*,unsigned long>(
        boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *this,
        const char *const *u0,
        const unsigned __int64 *u1,
        boost::disable_if_c<false,void>::type *a4)
{
  boost::iostreams::detail::array_adapter<boost::iostreams::input_seekable,char>::char_type *v5; // r13
  unsigned __int64 v6; // r12
  boost::iostreams::basic_array_source<char> v7; // [rsp+0h] [rbp-38h] BYREF

  *((_QWORD *)this + 19) = (char *)&`vtable for'std::ios + 16;
  std::streambuf::basic_streambuf((char *)this + 16);
  *((_BYTE *)this + 104) = 0;
  *((_OWORD *)this + 8) = 0;
  *((_OWORD *)this + 7) = 0;
  *((_BYTE *)this + 144) = 1;
  *((_DWORD *)this + 20) = 1;
  *((_QWORD *)this + 2) = &off_29A6AD8;
  *((_QWORD *)this + 19) = &off_29A6AA0;
  *(_OWORD *)this = (unsigned __int64)&off_29A6A78;
  std::ios_base::init(
    (boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *)((char *)this + 152),
    (char *)this + 16);
  *((_QWORD *)this + 36) = 0;
  *((_DWORD *)this + 74) = -1;
  *(_QWORD *)this = &off_29A6950;
  *((_QWORD *)this + 19) = off_29A6978;
  v5 = (boost::iostreams::detail::array_adapter<boost::iostreams::input_seekable,char>::char_type *)*u0;
  v6 = *u1;
  std::ios_base::clear(
    (boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *)((char *)this + 152),
    0);
  v7.begin_ = v5;
  v7.end_ = &v5[v6];
  boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::open_impl(
    (boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *)((char *)this + 16),
    &v7,
    -1,
    -1);
}


// Address: 0x2029140 | Name: _ZN5boost9iostreams6streamINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS4_9allocatorIcEEED1Ev
void __fastcall boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>>::~stream(
        boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *this)
{
  std::istream::~istream(this, off_29A69A0);
  boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer((boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *)((char *)this + 16));
  std::ios::~ios();
}


// Address: 0x20295d0 | Name: _ZTv0_n24_N5boost9iostreams6streamINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS4_9allocatorIcEEED1Ev
void __fastcall `virtual thunk to'boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>>::~stream(
        boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *this)
{
  __int64 v1; // r14

  v1 = *(_QWORD *)(*(_QWORD *)this - 24LL);
  std::istream::~istream((char *)this + v1, off_29A69A0);
  boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer((boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *)((char *)this + v1 + 16));
  std::ios::~ios();
}


// Address: 0x2029620 | Name: _ZN5boost9iostreams6detail11stream_baseINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS5_9allocatorIcEENS5_13basic_istreamIcS7_EEED1Ev
void __fastcall boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream>::~stream_base(
        boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream > *this)
{
  std::istream::~istream(this, off_29A6E88);
  boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer((boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream > *)((char *)this + 16));
  std::ios::~ios();
}


// Address: 0x2029650 | Name: _ZN5boost9iostreams6detail11stream_baseINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS5_9allocatorIcEENS5_13basic_istreamIcS7_EEED0Ev
void __fastcall boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream>::~stream_base(
        boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream > *this)
{
  std::istream::~istream(this, off_29A6E88);
  boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer((boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream > *)((char *)this + 16));
  std::ios::~ios();
  operator delete(this);
}


// Address: 0x2029680 | Name: _ZTv0_n24_N5boost9iostreams6detail11stream_baseINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS5_9allocatorIcEENS5_13basic_istreamIcS7_EEED1Ev
void __fastcall `virtual thunk to'boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream>::~stream_base(
        boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream > *this)
{
  __int64 v1; // r14

  v1 = *(_QWORD *)(*(_QWORD *)this - 24LL);
  std::istream::~istream((char *)this + v1, off_29A6E88);
  boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer((boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream > *)((char *)this + v1 + 16));
  std::ios::~ios();
}


// Address: 0x20296d0 | Name: _ZTv0_n24_N5boost9iostreams6detail11stream_baseINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS5_9allocatorIcEENS5_13basic_istreamIcS7_EEED0Ev
void __fastcall `virtual thunk to'boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream>::~stream_base(
        boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream > *this)
{
  __int64 v1; // r15

  v1 = *(_QWORD *)(*(_QWORD *)this - 24LL);
  std::istream::~istream((char *)this + v1, off_29A6E88);
  boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer((boost::iostreams::detail::stream_base<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,std::istream > *)((char *)this + v1 + 16));
  std::ios::~ios();
  operator delete((char *)this + v1);
}


// Address: 0x2029720 | Name: _ZN5boost9iostreams6streamINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS4_9allocatorIcEEED0Ev
void __fastcall boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>>::~stream(
        boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *this)
{
  std::istream::~istream(this, off_29A69A0);
  boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer((boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *)((char *)this + 16));
  std::ios::~ios();
  operator delete(this);
}


// Address: 0x2029750 | Name: _ZTv0_n24_N5boost9iostreams6streamINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS4_9allocatorIcEEED0Ev
void __fastcall `virtual thunk to'boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>>::~stream(
        boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *this)
{
  __int64 v1; // r15

  v1 = *(_QWORD *)(*(_QWORD *)this - 24LL);
  std::istream::~istream((char *)this + v1, off_29A69A0);
  boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer((boost::iostreams::stream<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char> > *)((char *)this + v1 + 16));
  std::ios::~ios();
  operator delete((char *)this + v1);
}


