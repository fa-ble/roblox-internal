// Address: 0x25f3ae0 | Name: _ZN5boost4asio6detail11posix_mutexD2Ev
// Alternative name is 'j_.pthread_mutex_destroy_1'
// attributes: thunk
void __fastcall boost::asio::detail::posix_mutex::~posix_mutex(boost::asio::detail::posix_mutex *this)
{
  pthread_mutex_destroy(&this->mutex_);
}


