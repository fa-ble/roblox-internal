// Address: 0x2547a00 | Name: _ZN5boost4asio3ssl6detail17openssl_init_base8instanceEv
std::shared_ptr<boost::asio::ssl::detail::openssl_init_base::do_init> __cdecl boost::asio::ssl::detail::openssl_init_base::instance()
{
  __int64 v0; // rdi
  std::__shared_weak_count *cntrl; // rax
  std::shared_ptr<boost::asio::ssl::detail::openssl_init_base::do_init> result; // rax
  std::shared_ptr<boost::asio::ssl::detail::openssl_init_base::do_init>::element_type *v3; // r14
  char *v4; // rax

  if ( !(_BYTE)byte_2B11508 && __cxa_guard_acquire(&byte_2B11508) )
  {
    v3 = (std::shared_ptr<boost::asio::ssl::detail::openssl_init_base::do_init>::element_type *)operator new(1u);
    stru_2B114F8.__ptr_ = v3;
    v4 = (char *)operator new(0x20u);
    *(_OWORD *)(v4 + 8) = 0;
    *(_QWORD *)v4 = &off_29B9008;
    *((_QWORD *)v4 + 3) = v3;
    stru_2B114F8.__cntrl_ = (std::__shared_weak_count *)v4;
    __cxa_atexit(
      (void (*)(void *))std::shared_ptr<boost::asio::ssl::detail::openssl_init_base::do_init>::~shared_ptr,
      &stru_2B114F8,
      &dso_handle);
    __cxa_guard_release(&byte_2B11508);
  }
  *(_QWORD *)v0 = stru_2B114F8.__ptr_;
  cntrl = stru_2B114F8.__cntrl_;
  *(_QWORD *)(v0 + 8) = stru_2B114F8.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64((volatile signed __int64 *)cntrl + 1, 1u);
  result.__ptr_ = (std::shared_ptr<boost::asio::ssl::detail::openssl_init_base::do_init>::element_type *)v0;
  return result;
}


