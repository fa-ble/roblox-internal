// Address: 0x18399c0 | Name: _ZN5boost9algorithm11ifind_firstIKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEES8_EENS_14iterator_rangeINS_14range_iteratorIT_vE4typeEEERSC_RKT0_RKNS2_6localeE
boost::iterator_range<std::__wrap_iter<const char *> > __fastcall boost::algorithm::ifind_first<std::string const,std::string>(
        const std::string *Input,
        const std::string *Search,
        const std::locale *Loc)
{
  unsigned __int64 v3; // rbp
  unsigned __int64 v4; // rbp
  char *v5; // rbx
  unsigned __int64 v6; // rbp
  unsigned __int64 v7; // rbp
  const char *v8; // r15
  const char *v9; // r14
  char *v10; // rax
  unsigned __int64 v11; // rbp
  char *v12; // rcx
  char *v13; // r15
  char v14; // bl
  __int64 v15; // rax
  char v16; // bl
  char v17; // r12
  __int64 v18; // rax
  boost::iterator_range<std::__wrap_iter<const char *> > result; // rax
  char *v20; // [rsp+8h] [rbp-70h]
  char *v21; // [rsp+10h] [rbp-68h]
  std::locale v22; // [rsp+18h] [rbp-60h] BYREF
  const char *v23; // [rsp+20h] [rbp-58h]
  const char *v24; // [rsp+28h] [rbp-50h]
  std::locale v25; // [rsp+30h] [rbp-48h] BYREF
  unsigned __int64 v26; // [rsp+38h] [rbp-40h]
  std::locale v27; // [rsp+40h] [rbp-38h] BYREF

  std::locale::locale(&v25, Loc);
  v3 = *(unsigned __int8 *)Search;
  if ( (v3 & 1) != 0 )
  {
    v4 = *((_QWORD *)Search + 1);
    v5 = (char *)*((_QWORD *)Search + 2);
  }
  else
  {
    v5 = (char *)Search + 1;
    v4 = v3 >> 1;
  }
  std::locale::locale(&v27, &v25);
  v20 = v5;
  v21 = &v5[v4];
  std::locale::locale(&v22, &v27);
  std::locale::~locale(&v27);
  v6 = *(unsigned __int8 *)Input;
  if ( (v6 & 1) != 0 )
  {
    v7 = *((_QWORD *)Input + 1);
    v8 = (const char *)*((_QWORD *)Input + 2);
    if ( v7 )
      goto LABEL_6;
LABEL_19:
    v9 = v8;
    goto LABEL_21;
  }
  v8 = (char *)Input + 1;
  v7 = v6 >> 1;
  if ( !v7 )
    goto LABEL_19;
LABEL_6:
  v9 = &v8[v7];
  v10 = v21;
  v11 = v7 - 1;
  v23 = v9;
  while ( 1 )
  {
    v12 = v20;
    if ( v20 == v10 )
    {
LABEL_17:
      v8 = v9;
      goto LABEL_21;
    }
    v26 = v11;
    v24 = v8;
    v9 = v8;
    while ( 1 )
    {
      v13 = v12;
      v14 = *v9;
      v15 = std::locale::use_facet(&v22, &std::ctype<char>::id);
      v16 = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v15 + 24LL))(v15, (unsigned int)v14);
      v17 = *v13;
      v18 = std::locale::use_facet(&v22, &std::ctype<char>::id);
      if ( v16 != (*(unsigned __int8 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v18 + 24LL))(v18, (unsigned int)v17) )
        break;
      if ( !v11 )
      {
        v9 = v23;
LABEL_14:
        ++v13;
        break;
      }
      ++v9;
      v12 = v13 + 1;
      --v11;
      if ( v13 + 1 == v21 )
        goto LABEL_14;
    }
    v10 = v21;
    if ( v13 == v21 )
      break;
    v8 = v24 + 1;
    v11 = v26 - 1;
    v9 = v23;
    if ( v24 + 1 == v23 )
      goto LABEL_17;
  }
  v8 = v24;
LABEL_21:
  std::locale::~locale(&v22);
  std::locale::~locale(&v25);
  result.m_Begin.__i = v8;
  result.m_End.__i = v9;
  return result;
}


// Address: 0x27cf5d0 | Name: _ZN5boost9algorithm10ifind_lastIKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEPKcEENS_14iterator_rangeINS_14range_iteratorIT_vE4typeEEERSE_RKT0_RKNS2_6localeE
boost::iterator_range<std::__wrap_iter<const char *> > __fastcall boost::algorithm::ifind_last<std::string const,char const*>(
        const std::string *Input,
        const char *const *Search,
        const std::locale *Loc)
{
  const char *v3; // r14
  const char *v4; // rbp
  unsigned __int64 v5; // rcx
  unsigned __int64 v6; // rcx
  const char *v7; // r15
  const char *v8; // rsi
  const char *v9; // rax
  __int64 v10; // rdi
  __int64 v11; // rcx
  const char *v12; // rbx
  const char *v13; // r13
  __int64 v14; // rdx
  const char *v15; // rbp
  __int64 v16; // rax
  __int64 v17; // r14
  char v18; // bl
  __int64 v19; // rax
  char v20; // bl
  char v21; // r15
  __int64 v22; // rax
  bool v23; // zf
  boost::iterator_range<std::__wrap_iter<const char *> > result; // rax
  const char *v25; // [rsp+8h] [rbp-80h]
  const char *v26; // [rsp+10h] [rbp-78h]
  std::locale v27; // [rsp+18h] [rbp-70h] BYREF
  const char *v28; // [rsp+20h] [rbp-68h]
  __int64 v29; // [rsp+28h] [rbp-60h]
  __int64 v30; // [rsp+30h] [rbp-58h]
  std::locale v31; // [rsp+38h] [rbp-50h] BYREF
  const char *v32; // [rsp+40h] [rbp-48h]
  const char *v33; // [rsp+48h] [rbp-40h]
  std::locale v34; // [rsp+50h] [rbp-38h] BYREF

  std::locale::locale(&v31, Loc);
  v3 = *Search;
  v4 = &v3[strlen(*Search)];
  std::locale::locale(&v34, &v31);
  v25 = v3;
  v26 = v4;
  std::locale::locale(&v27, &v34);
  std::locale::~locale(&v34);
  v5 = *(unsigned __int8 *)Input;
  if ( (v5 & 1) != 0 )
  {
    v6 = *((_QWORD *)Input + 1);
    v7 = (const char *)*((_QWORD *)Input + 2);
  }
  else
  {
    v7 = (char *)Input + 1;
    v6 = v5 >> 1;
  }
  v8 = &v7[v6];
  v9 = v4;
  if ( v3 != v4 )
  {
    v10 = (__int64)&v7[v6 - 1];
    v30 = 0;
    v11 = (__int64)v4;
    v12 = v8;
    v32 = v7;
    v28 = v8;
    while ( v12 != v7 )
    {
      v13 = v12--;
      if ( v12 == v8 )
      {
        v14 = v11;
        v15 = v8;
        v11 = (__int64)v25;
      }
      else
      {
        v14 = (__int64)v9;
        v15 = v12;
        if ( v25 != (const char *)v11 )
        {
          v29 = v10;
          v16 = 0;
          v33 = v12;
          v15 = v12;
          while ( 1 )
          {
            v17 = v16;
            v18 = v13[v16 - 1];
            v19 = std::locale::use_facet(&v27, &std::ctype<char>::id);
            v20 = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v19 + 24LL))(v19, (unsigned int)v18);
            v21 = v25[v17];
            v22 = std::locale::use_facet(&v27, &std::ctype<char>::id);
            if ( v20 != (*(unsigned __int8 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v22 + 24LL))(
                          v22,
                          (unsigned int)v21) )
            {
              v15 = (const char *)(v29 + v17);
              v11 = (__int64)&v25[v17];
              goto LABEL_18;
            }
            if ( v30 == v17 )
              break;
            ++v15;
            v16 = v17 + 1;
            if ( &v25[v17 + 1] == v26 )
              goto LABEL_17;
          }
          v15 = v28;
LABEL_17:
          v11 = (__int64)&v25[v17 + 1];
LABEL_18:
          v9 = v26;
          v14 = (__int64)v26;
          v7 = v32;
          v8 = v28;
          v10 = v29;
          v12 = v33;
        }
      }
      --v10;
      ++v30;
      v23 = v11 == v14;
      v11 = v14;
      if ( v23 )
        goto LABEL_22;
    }
  }
  v15 = v8;
  v12 = v8;
LABEL_22:
  std::locale::~locale(&v27);
  std::locale::~locale(&v31);
  result.m_Begin.__i = v12;
  result.m_End.__i = v15;
  return result;
}


