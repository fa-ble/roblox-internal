// Address: 0xe43730 | Name: _ZN5boost6detail18lcast_ret_unsignedINSt3__111char_traitsIcEEjcE7convertEv
bool __fastcall boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned int,char>::convert(
        boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned int,char> *this)
{
  unsigned int *m_value; // rcx
  const char *m_end; // rax
  bool v3; // r12
  __int64 v5; // rax
  const char *m_begin; // r8
  const char *v7; // rsi
  char m_multiplier_overflowed; // cl
  bool v9; // al
  unsigned int m_multiplier; // edi
  bool v11; // dl
  unsigned int v12; // edi
  unsigned int v13; // ebp
  int v14; // ebx
  unsigned int *v15; // rax
  unsigned int v16; // edx
  __int64 v17; // rbp
  unsigned __int64 v18; // r14
  char *v19; // rcx
  char v20; // al
  const char *v21; // r9
  const char *v22; // rdi
  char v23; // r8
  _BYTE *v24; // rax
  char v25; // cl
  unsigned __int64 v26; // r14
  unsigned __int8 v27; // r10
  bool v28; // al
  unsigned int v29; // esi
  bool v30; // dl
  unsigned int v31; // esi
  unsigned int v32; // ebp
  int v33; // ebx
  unsigned int *v34; // rax
  unsigned int v35; // edx
  _BYTE *v36; // rcx
  const char *v37; // r8
  const char *v38; // rsi
  char v39; // cl
  bool v40; // al
  unsigned int v41; // edi
  bool v42; // dl
  unsigned int v43; // edi
  unsigned int v44; // ebp
  int v45; // ebx
  unsigned int *v46; // rax
  unsigned int v47; // edx
  char v48; // cl
  bool v49; // al
  unsigned int v50; // esi
  bool v51; // dl
  unsigned int v52; // ebp
  unsigned int v53; // esi
  int v54; // ebx
  unsigned int *v55; // rax
  unsigned int v56; // edx
  std::locale v58; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int8 v59; // [rsp+10h] [rbp-48h] BYREF
  _BYTE v60[7]; // [rsp+11h] [rbp-47h] BYREF
  unsigned __int64 v61; // [rsp+18h] [rbp-40h]
  void *ptr; // [rsp+20h] [rbp-38h]

  m_value = this->m_value;
  m_end = this->m_end;
  this->m_end = m_end - 1;
  *m_value = 0;
  if ( this->m_begin > (const char *const)m_end - 1 || (unsigned __int8)(*(m_end - 1) - 48) > 9u )
    return 0;
  *m_value = *(m_end - 1) - 48;
  this->m_end = m_end - 2;
  std::locale::locale(&v58);
  v5 = std::locale::classic(&v58);
  if ( (unsigned __int8)std::locale::operator==(&v58, v5) )
  {
    m_begin = this->m_begin;
    v7 = this->m_end;
    v3 = 1;
    if ( v7 >= m_begin )
    {
      m_multiplier_overflowed = this->m_multiplier_overflowed;
      while ( 1 )
      {
        v9 = m_multiplier_overflowed != 0;
        m_multiplier = this->m_multiplier;
        v11 = m_multiplier > 0x19999999;
        m_multiplier_overflowed |= m_multiplier > 0x19999999;
        this->m_multiplier_overflowed = m_multiplier_overflowed;
        v12 = 10 * m_multiplier;
        this->m_multiplier = v12;
        if ( (unsigned __int8)(*v7 - 48) > 9u )
          break;
        v13 = *v7 - 48;
        v14 = v12 * v13;
        if ( *v7 == 48 )
        {
          v15 = this->m_value;
          v16 = *v15;
        }
        else
        {
          if ( v11 || v9 )
            break;
          if ( 0xFFFFFFFF / v13 < v12 )
            break;
          v15 = this->m_value;
          v16 = *v15;
          if ( *v15 > ~v14 )
            break;
        }
        *v15 = v14 + v16;
        this->m_end = --v7;
        if ( v7 < m_begin )
          goto LABEL_69;
      }
      v3 = 0;
    }
    goto LABEL_69;
  }
  v17 = std::locale::use_facet(&v58, &std::numpunct<char>::id);
  (*(void (__fastcall **)(unsigned __int8 *, __int64))(*(_QWORD *)v17 + 40LL))(&v59, v17);
  if ( (v59 & 1) != 0 )
  {
    v18 = v61;
    if ( !v61 )
      goto LABEL_43;
  }
  else
  {
    v18 = (unsigned __int64)v59 >> 1;
    if ( !v18 )
      goto LABEL_43;
  }
  v19 = v60;
  if ( (v59 & 1) != 0 )
    v19 = (char *)ptr;
  if ( *v19 <= 0 )
  {
LABEL_43:
    v37 = this->m_begin;
    v38 = this->m_end;
    v3 = 1;
    if ( v38 >= v37 )
    {
      v39 = this->m_multiplier_overflowed;
      do
      {
        v40 = v39 != 0;
        v41 = this->m_multiplier;
        v42 = v41 > 0x19999999;
        v39 |= v41 > 0x19999999;
        this->m_multiplier_overflowed = v39;
        v43 = 10 * v41;
        this->m_multiplier = v43;
        if ( (unsigned __int8)(*v38 - 48) > 9u )
          goto LABEL_67;
        v44 = *v38 - 48;
        v45 = v43 * v44;
        if ( *v38 == 48 )
        {
          v46 = this->m_value;
          v47 = *v46;
        }
        else
        {
          if ( v42 || v40 )
            goto LABEL_67;
          if ( 0xFFFFFFFF / v44 < v43 )
            goto LABEL_67;
          v46 = this->m_value;
          v47 = *v46;
          if ( *v46 > ~v45 )
            goto LABEL_67;
        }
        *v46 = v45 + v47;
        this->m_end = --v38;
      }
      while ( v38 >= v37 );
    }
LABEL_44:
    if ( (v59 & 1) != 0 )
      goto LABEL_68;
    goto LABEL_69;
  }
  v20 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v17 + 32LL))(v17);
  v21 = this->m_begin;
  v22 = this->m_end;
  v3 = 1;
  if ( v22 < v21 )
    goto LABEL_44;
  v23 = v20;
  v24 = v60;
  if ( (v59 & 1) != 0 )
    v24 = ptr;
  v25 = *v24 - 1;
  v26 = v18 - 1;
  v27 = 0;
  while ( v25 )
  {
    v28 = this->m_multiplier_overflowed;
    v29 = this->m_multiplier;
    v30 = v29 > 0x19999999;
    this->m_multiplier_overflowed |= v29 > 0x19999999;
    v31 = 10 * v29;
    this->m_multiplier = v31;
    if ( (unsigned __int8)(*v22 - 48) > 9u )
      goto LABEL_67;
    v32 = *v22 - 48;
    v33 = v31 * v32;
    if ( *v22 == 48 )
    {
      v34 = this->m_value;
      v35 = *v34;
    }
    else
    {
      if ( v30 || v28 )
        goto LABEL_67;
      if ( 0xFFFFFFFF / v32 < v31 )
        goto LABEL_67;
      v34 = this->m_value;
      v35 = *v34;
      if ( *v34 > ~v33 )
        goto LABEL_67;
    }
    *v34 = v33 + v35;
    --v25;
LABEL_41:
    this->m_end = --v22;
    if ( v22 < v21 )
      goto LABEL_44;
  }
  if ( *v22 == v23 )
  {
    if ( v21 == v22 )
      goto LABEL_67;
    v27 += v27 < v26;
    v36 = v60;
    if ( (v59 & 1) != 0 )
      v36 = ptr;
    v25 = v36[v27];
    goto LABEL_41;
  }
  v48 = this->m_multiplier_overflowed;
  while ( 1 )
  {
    v49 = v48 != 0;
    v50 = this->m_multiplier;
    v51 = v50 > 0x19999999;
    v48 |= v50 > 0x19999999;
    this->m_multiplier_overflowed = v48;
    v52 = 10 * v50;
    this->m_multiplier = 10 * v50;
    if ( (unsigned __int8)(*v22 - 48) > 9u )
      break;
    v53 = *v22 - 48;
    v54 = v52 * v53;
    if ( *v22 == 48 )
    {
      v55 = this->m_value;
      v56 = *v55;
    }
    else
    {
      if ( v51 || v49 || 0xFFFFFFFF / v53 < v52 )
        break;
      v55 = this->m_value;
      v56 = *v55;
      if ( *v55 > ~v54 )
      {
        v3 = 0;
        if ( (v59 & 1) == 0 )
          goto LABEL_69;
        goto LABEL_68;
      }
    }
    *v55 = v54 + v56;
    this->m_end = --v22;
    if ( v22 < v21 )
      goto LABEL_44;
  }
LABEL_67:
  v3 = 0;
  if ( (v59 & 1) != 0 )
LABEL_68:
    operator delete(ptr);
LABEL_69:
  std::locale::~locale(&v58);
  return v3;
}


// Address: 0xe440b0 | Name: _ZN5boost6detail18lcast_put_unsignedINSt3__111char_traitsIcEEjcE7convertEv
char *__fastcall boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned int,char>::convert(
        boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned int,char> *this)
{
  __int64 v2; // rax
  boost::mpl::if_c<false,int,unsigned int>::type m_value; // ecx
  char *m_finish; // rdx
  unsigned __int64 v5; // rdx
  char *v6; // rbx
  __int64 v7; // r14
  unsigned __int64 v8; // r15
  char *v9; // rcx
  char v10; // al
  char *v11; // rcx
  char v12; // r8
  char **p_m_finish; // r9
  __int64 v14; // r11
  char v15; // cl
  _BYTE *v16; // rcx
  char v17; // cl
  char *v18; // rdi
  char *v19; // rdi
  unsigned __int64 v20; // rdx
  boost::mpl::if_c<false,int,unsigned int>::type v21; // ecx
  char *v22; // rdx
  unsigned __int64 v23; // rdx
  std::locale v25; // [rsp+8h] [rbp-40h] BYREF
  unsigned __int8 v26; // [rsp+10h] [rbp-38h] BYREF
  _BYTE v27[7]; // [rsp+11h] [rbp-37h] BYREF
  unsigned __int64 v28; // [rsp+18h] [rbp-30h]
  void *ptr; // [rsp+20h] [rbp-28h]

  std::locale::locale(&v25);
  v2 = std::locale::classic(&v25);
  if ( (unsigned __int8)std::locale::operator==(&v25, v2) )
  {
    m_value = this->m_value;
    do
    {
      m_finish = this->m_finish;
      this->m_finish = m_finish - 1;
      *(m_finish - 1) = LOBYTE(this->m_zero) + m_value % 0xA;
      v5 = this->m_value;
      m_value = this->m_value / 0xA;
      this->m_value = m_value;
    }
    while ( v5 > 9 );
    v6 = this->m_finish;
    goto LABEL_28;
  }
  v7 = std::locale::use_facet(&v25, &std::numpunct<char>::id);
  (*(void (__fastcall **)(unsigned __int8 *, __int64))(*(_QWORD *)v7 + 40LL))(&v26, v7);
  if ( (v26 & 1) != 0 )
  {
    v8 = v28;
    if ( !v28 )
      goto LABEL_24;
  }
  else
  {
    v8 = (unsigned __int64)v26 >> 1;
    if ( !v8 )
      goto LABEL_24;
  }
  v9 = v27;
  if ( (v26 & 1) != 0 )
    v9 = (char *)ptr;
  if ( *v9 > 0 )
  {
    v10 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v7 + 32LL))(v7);
    v11 = v27;
    if ( (v26 & 1) != 0 )
      v11 = (char *)ptr;
    v12 = *v11;
    p_m_finish = &this->m_finish;
    v14 = 0;
    v15 = *v11;
    do
    {
      if ( !v15 )
      {
        if ( ++v14 < v8 )
        {
          v16 = v27;
          if ( (v26 & 1) != 0 )
            v16 = ptr;
          v17 = v16[v14];
          v12 = 127;
          if ( v17 > 0 )
            v12 = v17;
        }
        v18 = *p_m_finish - 1;
        *p_m_finish = v18;
        *v18 = v10;
        v15 = v12;
      }
      --v15;
      v19 = this->m_finish;
      this->m_finish = v19 - 1;
      *(v19 - 1) = LOBYTE(this->m_zero) + this->m_value % 0xA;
      v20 = this->m_value;
      this->m_value /= 0xAu;
    }
    while ( v20 > 9 );
    goto LABEL_26;
  }
LABEL_24:
  p_m_finish = &this->m_finish;
  v21 = this->m_value;
  do
  {
    v22 = this->m_finish;
    this->m_finish = v22 - 1;
    *(v22 - 1) = LOBYTE(this->m_zero) + v21 % 0xA;
    v23 = this->m_value;
    v21 = this->m_value / 0xA;
    this->m_value = v21;
  }
  while ( v23 > 9 );
LABEL_26:
  v6 = *p_m_finish;
  if ( (v26 & 1) != 0 )
    operator delete(ptr);
LABEL_28:
  std::locale::~locale(&v25);
  return v6;
}


// Address: 0xfd61e0 | Name: _ZN5boost6detail18lcast_put_unsignedINSt3__111char_traitsIcEEmcE7convertEv
char *__fastcall boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned long,char>::convert(
        boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned long,char> *this)
{
  __int64 v2; // rax
  boost::mpl::if_c<false,int,unsigned long>::type m_value; // rcx
  char *m_finish; // rsi
  boost::mpl::if_c<false,int,unsigned long>::type v5; // rsi
  char *v6; // rbx
  __int64 v7; // r14
  unsigned __int64 v8; // r15
  char *v9; // rcx
  char v10; // r8
  char *v11; // rax
  char v12; // r10
  char **p_m_finish; // r9
  __int64 v14; // r14
  char v15; // cl
  _BYTE *v16; // rax
  char v17; // al
  char *v18; // rax
  boost::mpl::if_c<false,int,unsigned long>::type v19; // rsi
  char *v20; // rdi
  boost::mpl::if_c<false,int,unsigned long>::type v21; // rsi
  boost::mpl::if_c<false,int,unsigned long>::type v22; // rcx
  char *v23; // rsi
  boost::mpl::if_c<false,int,unsigned long>::type v24; // rsi
  std::locale v26; // [rsp+8h] [rbp-40h] BYREF
  unsigned __int8 v27; // [rsp+10h] [rbp-38h] BYREF
  _BYTE v28[7]; // [rsp+11h] [rbp-37h] BYREF
  unsigned __int64 v29; // [rsp+18h] [rbp-30h]
  void *ptr; // [rsp+20h] [rbp-28h]

  std::locale::locale(&v26);
  v2 = std::locale::classic(&v26);
  if ( (unsigned __int8)std::locale::operator==(&v26, v2) )
  {
    m_value = this->m_value;
    do
    {
      m_finish = this->m_finish;
      this->m_finish = m_finish - 1;
      *(m_finish - 1) = LOBYTE(this->m_zero) + m_value % 0xA;
      v5 = this->m_value;
      m_value = this->m_value / 0xA;
      this->m_value = m_value;
    }
    while ( v5 > 9 );
    v6 = this->m_finish;
    goto LABEL_28;
  }
  v7 = std::locale::use_facet(&v26, &std::numpunct<char>::id);
  (*(void (__fastcall **)(unsigned __int8 *, __int64))(*(_QWORD *)v7 + 40LL))(&v27, v7);
  if ( (v27 & 1) != 0 )
  {
    v8 = v29;
    if ( !v29 )
      goto LABEL_24;
  }
  else
  {
    v8 = (unsigned __int64)v27 >> 1;
    if ( !v8 )
      goto LABEL_24;
  }
  v9 = v28;
  if ( (v27 & 1) != 0 )
    v9 = (char *)ptr;
  if ( *v9 > 0 )
  {
    v10 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v7 + 32LL))(v7);
    v11 = v28;
    if ( (v27 & 1) != 0 )
      v11 = (char *)ptr;
    v12 = *v11;
    p_m_finish = &this->m_finish;
    v14 = 0;
    v15 = *v11;
    do
    {
      if ( !v15 )
      {
        if ( ++v14 < v8 )
        {
          v16 = v28;
          if ( (v27 & 1) != 0 )
            v16 = ptr;
          v17 = v16[v14];
          v12 = 127;
          if ( v17 > 0 )
            v12 = v17;
        }
        v18 = (*p_m_finish)--;
        *(v18 - 1) = v10;
        v15 = v12;
      }
      v19 = this->m_value;
      v20 = this->m_finish;
      this->m_finish = v20 - 1;
      *(v20 - 1) = LOBYTE(this->m_zero) + v19 % 0xA;
      v21 = this->m_value;
      --v15;
      this->m_value /= 0xAuLL;
    }
    while ( v21 > 9 );
    goto LABEL_26;
  }
LABEL_24:
  p_m_finish = &this->m_finish;
  v22 = this->m_value;
  do
  {
    v23 = this->m_finish;
    this->m_finish = v23 - 1;
    *(v23 - 1) = LOBYTE(this->m_zero) + v22 % 0xA;
    v24 = this->m_value;
    v22 = this->m_value / 0xA;
    this->m_value = v22;
  }
  while ( v24 > 9 );
LABEL_26:
  v6 = *p_m_finish;
  if ( (v27 & 1) != 0 )
    operator delete(ptr);
LABEL_28:
  std::locale::~locale(&v26);
  return v6;
}


// Address: 0x1456c40 | Name: _ZN5boost6detail18lcast_ret_unsignedINSt3__111char_traitsIcEEmcE7convertEv
bool __fastcall boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned long,char>::convert(
        boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned long,char> *this)
{
  unsigned __int64 *m_value; // rcx
  const char *m_end; // rax
  __int64 v3; // rdx
  bool v4; // r12
  __int64 v6; // rax
  const char *m_begin; // r9
  const char *v8; // rsi
  char m_multiplier_overflowed; // cl
  bool v10; // r10
  unsigned __int64 m_multiplier; // rdi
  unsigned __int64 v12; // rbp
  unsigned __int64 v13; // rbx
  unsigned __int64 v14; // r11
  unsigned __int64 *v15; // rax
  unsigned __int64 v16; // rdx
  __int64 v17; // rbp
  unsigned __int64 v18; // r14
  char *v19; // rcx
  char v20; // al
  const char *v21; // r10
  const char *v22; // rdi
  char v23; // r9
  _BYTE *v24; // rax
  char v25; // r13
  unsigned __int64 v26; // r14
  unsigned __int8 v27; // r11
  bool v28; // al
  unsigned __int64 v29; // rsi
  bool v30; // dl
  unsigned __int64 v31; // rsi
  unsigned __int64 v32; // rcx
  unsigned __int64 v33; // rbp
  unsigned __int64 *v34; // rax
  unsigned __int64 v35; // rcx
  _BYTE *v36; // rcx
  const char *v37; // r9
  const char *v38; // rsi
  char v39; // cl
  bool v40; // r10
  unsigned __int64 v41; // rdi
  unsigned __int64 v42; // rbp
  unsigned __int64 v43; // rbx
  unsigned __int64 v44; // r11
  unsigned __int64 *v45; // rax
  unsigned __int64 v46; // rdx
  char v47; // cl
  bool v48; // r9
  unsigned __int64 v49; // rsi
  bool v50; // dl
  unsigned __int64 v51; // rsi
  unsigned __int64 v52; // rbx
  unsigned __int64 v53; // rbp
  unsigned __int64 *v54; // rax
  unsigned __int64 v55; // rdx
  unsigned __int8 v57; // [rsp+8h] [rbp-50h] BYREF
  _BYTE v58[7]; // [rsp+9h] [rbp-4Fh] BYREF
  unsigned __int64 v59; // [rsp+10h] [rbp-48h]
  void *ptr; // [rsp+18h] [rbp-40h]
  std::locale v61; // [rsp+20h] [rbp-38h] BYREF

  m_value = this->m_value;
  m_end = this->m_end;
  this->m_end = m_end - 1;
  *m_value = 0;
  if ( this->m_begin > (const char *const)m_end - 1 )
    return 0;
  v3 = *(m_end - 1);
  if ( (unsigned __int8)(v3 - 48) > 9u )
    return 0;
  *m_value = v3 - 48;
  this->m_end = m_end - 2;
  std::locale::locale(&v61);
  v6 = std::locale::classic(&v61);
  if ( (unsigned __int8)std::locale::operator==(&v61, v6) )
  {
    m_begin = this->m_begin;
    v8 = this->m_end;
    v4 = 1;
    if ( v8 >= m_begin )
    {
      m_multiplier_overflowed = this->m_multiplier_overflowed;
      while ( 1 )
      {
        v10 = m_multiplier_overflowed != 0;
        m_multiplier = this->m_multiplier;
        m_multiplier_overflowed |= m_multiplier > 0x1999999999999999LL;
        this->m_multiplier_overflowed = m_multiplier_overflowed;
        v12 = 10 * m_multiplier;
        this->m_multiplier = 10 * m_multiplier;
        if ( (unsigned __int8)(*v8 - 48) > 9u )
          break;
        v13 = *v8 - 48LL;
        v14 = v13 * v12;
        if ( *v8 == 48 )
        {
          v15 = this->m_value;
          v16 = *v15;
        }
        else
        {
          if ( m_multiplier > 0x1999999999999999LL || v10 )
            break;
          if ( 0xFFFFFFFFFFFFFFFFLL / v13 < v12 )
            break;
          v15 = this->m_value;
          v16 = *v15;
          if ( *v15 > ~v14 )
            break;
        }
        *v15 = v14 + v16;
        this->m_end = --v8;
        if ( v8 < m_begin )
          goto LABEL_69;
      }
      v4 = 0;
    }
    goto LABEL_69;
  }
  v17 = std::locale::use_facet(&v61, &std::numpunct<char>::id);
  (*(void (__fastcall **)(unsigned __int8 *, __int64))(*(_QWORD *)v17 + 40LL))(&v57, v17);
  if ( (v57 & 1) != 0 )
  {
    v18 = v59;
    if ( !v59 )
      goto LABEL_43;
  }
  else
  {
    v18 = (unsigned __int64)v57 >> 1;
    if ( !v18 )
      goto LABEL_43;
  }
  v19 = v58;
  if ( (v57 & 1) != 0 )
    v19 = (char *)ptr;
  if ( *v19 <= 0 )
  {
LABEL_43:
    v37 = this->m_begin;
    v38 = this->m_end;
    v4 = 1;
    if ( v38 >= v37 )
    {
      v39 = this->m_multiplier_overflowed;
      do
      {
        v40 = v39 != 0;
        v41 = this->m_multiplier;
        v39 |= v41 > 0x1999999999999999LL;
        this->m_multiplier_overflowed = v39;
        v42 = 10 * v41;
        this->m_multiplier = 10 * v41;
        if ( (unsigned __int8)(*v38 - 48) > 9u )
          goto LABEL_67;
        v43 = *v38 - 48LL;
        v44 = v43 * v42;
        if ( *v38 == 48 )
        {
          v45 = this->m_value;
          v46 = *v45;
        }
        else
        {
          if ( v41 > 0x1999999999999999LL || v40 )
            goto LABEL_67;
          if ( 0xFFFFFFFFFFFFFFFFLL / v43 < v42 )
            goto LABEL_67;
          v45 = this->m_value;
          v46 = *v45;
          if ( *v45 > ~v44 )
            goto LABEL_67;
        }
        *v45 = v44 + v46;
        this->m_end = --v38;
      }
      while ( v38 >= v37 );
    }
LABEL_44:
    if ( (v57 & 1) != 0 )
      goto LABEL_68;
    goto LABEL_69;
  }
  v20 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v17 + 32LL))(v17);
  v21 = this->m_begin;
  v22 = this->m_end;
  v4 = 1;
  if ( v22 < v21 )
    goto LABEL_44;
  v23 = v20;
  v24 = v58;
  if ( (v57 & 1) != 0 )
    v24 = ptr;
  v25 = *v24 - 1;
  v26 = v18 - 1;
  v27 = 0;
  while ( v25 )
  {
    v28 = this->m_multiplier_overflowed;
    v29 = this->m_multiplier;
    v30 = v29 > 0x1999999999999999LL;
    this->m_multiplier_overflowed |= v29 > 0x1999999999999999LL;
    v31 = 10 * v29;
    this->m_multiplier = v31;
    if ( (unsigned __int8)(*v22 - 48) > 9u )
      goto LABEL_67;
    v32 = *v22 - 48LL;
    v33 = v32 * v31;
    if ( *v22 == 48 )
    {
      v34 = this->m_value;
      v35 = *v34;
    }
    else
    {
      if ( v30 || v28 )
        goto LABEL_67;
      if ( 0xFFFFFFFFFFFFFFFFLL / v32 < v31 )
        goto LABEL_67;
      v34 = this->m_value;
      v35 = *v34;
      if ( *v34 > ~v33 )
        goto LABEL_67;
    }
    *v34 = v33 + v35;
    --v25;
LABEL_41:
    this->m_end = --v22;
    if ( v22 < v21 )
      goto LABEL_44;
  }
  if ( *v22 == v23 )
  {
    if ( v21 == v22 )
      goto LABEL_67;
    v27 += v27 < v26;
    v36 = v58;
    if ( (v57 & 1) != 0 )
      v36 = ptr;
    v25 = v36[v27];
    goto LABEL_41;
  }
  v47 = this->m_multiplier_overflowed;
  while ( 1 )
  {
    v48 = v47 != 0;
    v49 = this->m_multiplier;
    v50 = v49 > 0x1999999999999999LL;
    v47 |= v49 > 0x1999999999999999LL;
    this->m_multiplier_overflowed = v47;
    v51 = 10 * v49;
    this->m_multiplier = v51;
    if ( (unsigned __int8)(*v22 - 48) > 9u )
      break;
    v52 = *v22 - 48LL;
    v53 = v52 * v51;
    if ( *v22 == 48 )
    {
      v54 = this->m_value;
      v55 = *v54;
    }
    else
    {
      if ( v50 || v48 || 0xFFFFFFFFFFFFFFFFLL / v52 < v51 )
        break;
      v54 = this->m_value;
      v55 = *v54;
      if ( *v54 > ~v53 )
      {
        v4 = 0;
        if ( (v57 & 1) == 0 )
          goto LABEL_69;
        goto LABEL_68;
      }
    }
    *v54 = v53 + v55;
    this->m_end = --v22;
    if ( v22 < v21 )
      goto LABEL_44;
  }
LABEL_67:
  v4 = 0;
  if ( (v57 & 1) != 0 )
LABEL_68:
    operator delete(ptr);
LABEL_69:
  std::locale::~locale(&v61);
  return v4;
}


// Address: 0x186bbe0 | Name: _ZN5boost6detail18lcast_ret_unsignedINSt3__111char_traitsIcEEtcE7convertEv
bool __fastcall boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned short,char>::convert(
        boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned short,char> *this)
{
  unsigned __int16 *m_value; // rcx
  const char *m_end; // rax
  bool v3; // r12
  __int64 v5; // rax
  const char *m_begin; // r8
  const char *v7; // rsi
  char m_multiplier_overflowed; // cl
  bool v9; // al
  unsigned int m_multiplier; // edi
  bool v11; // dl
  unsigned __int16 v12; // di
  unsigned __int16 v13; // bp
  __int16 v14; // bx
  unsigned __int16 *v15; // rax
  unsigned __int16 v16; // dx
  __int64 v17; // rbp
  unsigned __int64 v18; // r14
  char *v19; // rcx
  char v20; // al
  const char *v21; // r9
  const char *v22; // rdi
  char v23; // r8
  _BYTE *v24; // rax
  char v25; // r11
  unsigned __int64 v26; // r14
  unsigned __int8 v27; // r10
  bool v28; // al
  unsigned int v29; // esi
  bool v30; // dl
  unsigned __int16 v31; // bp
  unsigned __int16 v32; // si
  __int16 v33; // cx
  unsigned __int16 *v34; // rax
  unsigned __int16 v35; // dx
  _BYTE *v36; // rcx
  const char *v37; // r8
  const char *v38; // rsi
  char v39; // cl
  bool v40; // al
  unsigned int v41; // edi
  bool v42; // dl
  unsigned __int16 v43; // di
  unsigned __int16 v44; // bp
  __int16 v45; // bx
  unsigned __int16 *v46; // rax
  unsigned __int16 v47; // dx
  char v48; // cl
  bool v49; // al
  unsigned int v50; // esi
  bool v51; // dl
  unsigned __int16 v52; // bp
  unsigned __int16 v53; // si
  __int16 v54; // r8
  unsigned __int16 *v55; // rax
  unsigned __int16 v56; // dx
  std::locale v58; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int8 v59; // [rsp+10h] [rbp-48h] BYREF
  _BYTE v60[7]; // [rsp+11h] [rbp-47h] BYREF
  unsigned __int64 v61; // [rsp+18h] [rbp-40h]
  void *ptr; // [rsp+20h] [rbp-38h]

  m_value = this->m_value;
  m_end = this->m_end;
  this->m_end = m_end - 1;
  *m_value = 0;
  if ( this->m_begin > (const char *const)m_end - 1 || (unsigned __int8)(*(m_end - 1) - 48) > 9u )
    return 0;
  *m_value = *(m_end - 1) - 48;
  this->m_end = m_end - 2;
  std::locale::locale(&v58);
  v5 = std::locale::classic(&v58);
  if ( (unsigned __int8)std::locale::operator==(&v58, v5) )
  {
    m_begin = this->m_begin;
    v7 = this->m_end;
    v3 = 1;
    if ( v7 >= m_begin )
    {
      m_multiplier_overflowed = this->m_multiplier_overflowed;
      while ( 1 )
      {
        v9 = m_multiplier_overflowed != 0;
        m_multiplier = this->m_multiplier;
        v11 = m_multiplier > 0x1999;
        m_multiplier_overflowed |= m_multiplier > 0x1999;
        this->m_multiplier_overflowed = m_multiplier_overflowed;
        v12 = 10 * m_multiplier;
        this->m_multiplier = v12;
        if ( (unsigned __int8)(*v7 - 48) > 9u )
          break;
        v13 = *v7 - 48;
        v14 = v12 * v13;
        if ( *v7 == 48 )
        {
          v15 = this->m_value;
          v16 = *v15;
        }
        else
        {
          if ( v11 || v9 )
            break;
          if ( (unsigned __int16)(0xFFFFu / v13) < v12 )
            break;
          v15 = this->m_value;
          v16 = *v15;
          if ( *v15 > (unsigned __int16)~v14 )
            break;
        }
        *v15 = v14 + v16;
        this->m_end = --v7;
        if ( v7 < m_begin )
          goto LABEL_69;
      }
      v3 = 0;
    }
    goto LABEL_69;
  }
  v17 = std::locale::use_facet(&v58, &std::numpunct<char>::id);
  (*(void (__fastcall **)(unsigned __int8 *, __int64))(*(_QWORD *)v17 + 40LL))(&v59, v17);
  if ( (v59 & 1) != 0 )
  {
    v18 = v61;
    if ( !v61 )
      goto LABEL_43;
  }
  else
  {
    v18 = (unsigned __int64)v59 >> 1;
    if ( !v18 )
      goto LABEL_43;
  }
  v19 = v60;
  if ( (v59 & 1) != 0 )
    v19 = (char *)ptr;
  if ( *v19 <= 0 )
  {
LABEL_43:
    v37 = this->m_begin;
    v38 = this->m_end;
    v3 = 1;
    if ( v38 >= v37 )
    {
      v39 = this->m_multiplier_overflowed;
      do
      {
        v40 = v39 != 0;
        v41 = this->m_multiplier;
        v42 = v41 > 0x1999;
        v39 |= v41 > 0x1999;
        this->m_multiplier_overflowed = v39;
        v43 = 10 * v41;
        this->m_multiplier = v43;
        if ( (unsigned __int8)(*v38 - 48) > 9u )
          goto LABEL_67;
        v44 = *v38 - 48;
        v45 = v43 * v44;
        if ( *v38 == 48 )
        {
          v46 = this->m_value;
          v47 = *v46;
        }
        else
        {
          if ( v42 || v40 )
            goto LABEL_67;
          if ( (unsigned __int16)(0xFFFFu / v44) < v43 )
            goto LABEL_67;
          v46 = this->m_value;
          v47 = *v46;
          if ( *v46 > (unsigned __int16)~v45 )
            goto LABEL_67;
        }
        *v46 = v45 + v47;
        this->m_end = --v38;
      }
      while ( v38 >= v37 );
    }
LABEL_44:
    if ( (v59 & 1) != 0 )
      goto LABEL_68;
    goto LABEL_69;
  }
  v20 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v17 + 32LL))(v17);
  v21 = this->m_begin;
  v22 = this->m_end;
  v3 = 1;
  if ( v22 < v21 )
    goto LABEL_44;
  v23 = v20;
  v24 = v60;
  if ( (v59 & 1) != 0 )
    v24 = ptr;
  v25 = *v24 - 1;
  v26 = v18 - 1;
  v27 = 0;
  while ( v25 )
  {
    v28 = this->m_multiplier_overflowed;
    v29 = this->m_multiplier;
    v30 = v29 > 0x1999;
    this->m_multiplier_overflowed |= v29 > 0x1999;
    v31 = 10 * v29;
    this->m_multiplier = 10 * v29;
    if ( (unsigned __int8)(*v22 - 48) > 9u )
      goto LABEL_67;
    v32 = *v22 - 48;
    v33 = v31 * v32;
    if ( *v22 == 48 )
    {
      v34 = this->m_value;
      v35 = *v34;
    }
    else
    {
      if ( v30 || v28 )
        goto LABEL_67;
      if ( (unsigned __int16)(0xFFFFu / v32) < v31 )
        goto LABEL_67;
      v34 = this->m_value;
      v35 = *v34;
      if ( *v34 > (unsigned __int16)~v33 )
        goto LABEL_67;
    }
    *v34 = v33 + v35;
    --v25;
LABEL_41:
    this->m_end = --v22;
    if ( v22 < v21 )
      goto LABEL_44;
  }
  if ( *v22 == v23 )
  {
    if ( v21 == v22 )
      goto LABEL_67;
    v27 += v27 < v26;
    v36 = v60;
    if ( (v59 & 1) != 0 )
      v36 = ptr;
    v25 = v36[v27];
    goto LABEL_41;
  }
  v48 = this->m_multiplier_overflowed;
  while ( 1 )
  {
    v49 = v48 != 0;
    v50 = this->m_multiplier;
    v51 = v50 > 0x1999;
    v48 |= v50 > 0x1999;
    this->m_multiplier_overflowed = v48;
    v52 = 10 * v50;
    this->m_multiplier = 10 * v50;
    if ( (unsigned __int8)(*v22 - 48) > 9u )
      break;
    v53 = *v22 - 48;
    v54 = v52 * v53;
    if ( *v22 == 48 )
    {
      v55 = this->m_value;
      v56 = *v55;
    }
    else
    {
      if ( v51 || v49 || (unsigned __int16)(0xFFFFu / v53) < v52 )
        break;
      v55 = this->m_value;
      v56 = *v55;
      if ( *v55 > (unsigned __int16)~v54 )
      {
        v3 = 0;
        if ( (v59 & 1) == 0 )
          goto LABEL_69;
        goto LABEL_68;
      }
    }
    *v55 = v54 + v56;
    this->m_end = --v22;
    if ( v22 < v21 )
      goto LABEL_44;
  }
LABEL_67:
  v3 = 0;
  if ( (v59 & 1) != 0 )
LABEL_68:
    operator delete(ptr);
LABEL_69:
  std::locale::~locale(&v58);
  return v3;
}


