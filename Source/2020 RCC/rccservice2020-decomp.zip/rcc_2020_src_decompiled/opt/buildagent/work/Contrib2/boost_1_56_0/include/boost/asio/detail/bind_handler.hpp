// Address: 0x2607dd0 | Name: _ZN5boost4asio6detail7binder1INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS5_6config15asio_tls_client16transport_configEEEFvNS3_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISG_EENS0_22deadline_timer_serviceISG_SI_EEEEEENS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeEEJNSD_ISC_EERSM_RSS_RKNS3_12placeholders4__phILi1EEEEEESU_EclEv
void __fastcall boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>::operator()(
        boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *this)
{
  std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd f; // r12
  _QWORD *v3; // r14
  volatile signed __int64 *cntrl; // rax
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *v5; // rdi
  std::__shared_weak_count *v6; // rbx
  std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type *ptr; // [rsp+0h] [rbp-68h] BYREF
  std::__shared_weak_count *v8; // [rsp+8h] [rbp-60h]
  _BYTE v9[32]; // [rsp+10h] [rbp-58h] BYREF
  _BYTE *v10; // [rsp+30h] [rbp-38h]
  unsigned __int64 v11; // [rsp+40h] [rbp-28h]

  v11 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v3 = (_QWORD *)((char *)this->handler_.__bound_args_.__base_.__value_.__ptr_ + *((_QWORD *)&this->handler_.__f_ + 1));
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd *)((char *)f + *v3 - 1);
  ptr = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v8 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v5 = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v5 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v5 )
    {
      v10 = v9;
      (*((void (__fastcall **)(boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *))v5->handler_.__f_
       + 3))(v5);
    }
    else
    {
      v10 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *))v5->handler_.__f_
                      + 2))(v5);
    }
  }
  else
  {
    v10 = 0;
  }
  ((void (__fastcall *)(_QWORD *, std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type **, _BYTE *, boost::system::error_code *))f)(
    v3,
    &ptr,
    v9,
    &this->arg1_);
  if ( v9 == v10 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v10 + 32LL))(v10);
  }
  else if ( v10 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v10 + 40LL))(v10);
  }
  v6 = v8;
  if ( v8 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
      std::__shared_weak_count::__release_weak(v6);
    }
  }
}


// Address: 0x2622990 | Name: _ZN5boost4asio6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS5_6config15asio_tls_client16transport_configEEEFvNS3_10shared_ptrINS7_10connectionISB_EEEENSD_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISJ_EENS0_22deadline_timer_serviceISJ_SL_EEEEEENS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS10_3tcpEEEEJPSC_RSG_RSP_RSV_RKNS3_12placeholders4__phILi1EEERKNS1B_ILi2EEEEEESX_S13_EclEv
void __fastcall boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *this)
{
  std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd f; // r12
  unsigned __int8 *v3; // r14
  volatile signed __int64 *cntrl; // rax
  volatile signed __int64 *v5; // rax
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *v6; // rdi
  volatile signed __int64 *v7; // rax
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9; // rbx
  std::__shared_weak_count *v10; // rbx
  std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type *v11; // [rsp+8h] [rbp-90h] BYREF
  std::__shared_weak_count *v12; // [rsp+10h] [rbp-88h]
  std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *ptr; // [rsp+18h] [rbp-80h] BYREF
  std::__shared_weak_count *v14; // [rsp+20h] [rbp-78h]
  std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >::element_type *v15; // [rsp+28h] [rbp-70h] BYREF
  std::__shared_weak_count *v16; // [rsp+30h] [rbp-68h]
  size_t index; // [rsp+38h] [rbp-60h]
  _BYTE v18[32]; // [rsp+40h] [rbp-58h] BYREF
  _BYTE *v19; // [rsp+60h] [rbp-38h]
  unsigned __int64 v20; // [rsp+70h] [rbp-28h]

  v20 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v3 = &this->handler_.__bound_args_.__base_.__value_->m_socket_init_handler.__buf_.__lx[*((_QWORD *)&this->handler_.__f_
                                                                                         + 1)];
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd *)((char *)f + *(_QWORD *)v3 - 1);
  ptr = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v14 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v11 = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  v5 = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v12 = (std::__shared_weak_count *)v5;
  if ( v5 )
    _InterlockedAdd64(v5 + 1, 1u);
  v6 = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v6 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v6 )
    {
      v19 = v18;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *))v6->handler_.__f_
       + 3))(v6);
    }
    else
    {
      v19 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *))v6->handler_.__f_
                      + 2))(v6);
    }
  }
  else
  {
    v19 = 0;
  }
  v15 = this->arg2_.values_.__ptr_;
  v7 = (volatile signed __int64 *)this->arg2_.values_.__cntrl_;
  v16 = (std::__shared_weak_count *)v7;
  if ( v7 )
    _InterlockedAdd64(v7 + 1, 1u);
  index = this->arg2_.index_;
  ((void (__fastcall *)(unsigned __int8 *, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type **, std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type **, _BYTE *, boost::system::error_code *, std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >::element_type **))f)(
    v3,
    &ptr,
    &v11,
    v18,
    &this->arg1_,
    &v15);
  v8 = v16;
  if ( v16 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v16 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
    std::__shared_weak_count::__release_weak(v8);
  }
  if ( v18 == v19 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v19 + 32LL))(v19);
  }
  else if ( v19 )
  {
    (*(void (**)(void))(*(_QWORD *)v19 + 40LL))();
  }
  v9 = v12;
  if ( v12 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v12 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
    std::__shared_weak_count::__release_weak(v9);
  }
  v10 = v14;
  if ( v14 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v14 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
      std::__shared_weak_count::__release_weak(v10);
    }
  }
}


// Address: 0x2626e80 | Name: _ZN5boost4asio6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS5_6config15asio_tls_client16transport_configEEEFvNS3_10shared_ptrINS7_10connectionISB_EEEENSD_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISJ_EENS0_22deadline_timer_serviceISJ_SL_EEEEEENS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeEEJPSC_RSG_RSP_RSV_RKNS3_12placeholders4__phILi1EEEEEESX_NS0_2ip23basic_resolver_iteratorINS1C_3tcpEEEEclEv
void __fastcall boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *this)
{
  std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd f; // r12
  unsigned __int8 *v3; // r14
  volatile signed __int64 *cntrl; // rax
  volatile signed __int64 *v5; // rax
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *v6; // rdi
  std::__shared_weak_count *v7; // rbx
  std::__shared_weak_count *v8; // rbx
  std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type *v9; // [rsp+0h] [rbp-78h] BYREF
  std::__shared_weak_count *v10; // [rsp+8h] [rbp-70h]
  std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *ptr; // [rsp+10h] [rbp-68h] BYREF
  std::__shared_weak_count *v12; // [rsp+18h] [rbp-60h]
  _BYTE v13[32]; // [rsp+20h] [rbp-58h] BYREF
  _BYTE *v14; // [rsp+40h] [rbp-38h]
  unsigned __int64 v15; // [rsp+50h] [rbp-28h]

  v15 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v3 = &this->handler_.__bound_args_.__base_.__value_->m_socket_init_handler.__buf_.__lx[*((_QWORD *)&this->handler_.__f_
                                                                                         + 1)];
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd *)((char *)f + *(_QWORD *)v3 - 1);
  ptr = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v12 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v9 = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  v5 = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v10 = (std::__shared_weak_count *)v5;
  if ( v5 )
    _InterlockedAdd64(v5 + 1, 1u);
  v6 = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v6 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v6 )
    {
      v14 = v13;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *))v6->handler_.__f_
       + 3))(v6);
    }
    else
    {
      v14 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *))v6->handler_.__f_
                      + 2))(v6);
    }
  }
  else
  {
    v14 = 0;
  }
  ((void (__fastcall *)(unsigned __int8 *, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type **, std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type **, _BYTE *, boost::system::error_code *))f)(
    v3,
    &ptr,
    &v9,
    v13,
    &this->arg1_);
  if ( v13 == v14 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v14 + 32LL))(v14);
  }
  else if ( v14 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v14 + 40LL))(v14);
  }
  v7 = v10;
  if ( v10 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  v8 = v12;
  if ( v12 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v12 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
  }
}


// Address: 0x262bd00 | Name: _ZN5boost4asio6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS5_6config15asio_tls_client16transport_configEEEFvNS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeEEJNS3_10shared_ptrISC_EERSI_RKNS3_12placeholders4__phILi1EEEEEESK_mEclEv
void __fastcall boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>::operator()(
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *this)
{
  std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd f; // r12
  _QWORD *v2; // rbx
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *v3; // rax
  _BYTE v4[32]; // [rsp+0h] [rbp-58h] BYREF
  _BYTE *v5; // [rsp+20h] [rbp-38h]
  unsigned __int64 v6; // [rsp+30h] [rbp-28h]

  v6 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v2 = (_QWORD *)((char *)this->handler_.__bound_args_.__base_.__value_.__ptr_ + *((_QWORD *)&this->handler_.__f_ + 1));
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd *)((char *)f + *v2 - 1);
  v3 = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v3 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v3 )
    {
      v5 = v4;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *))v3->handler_.__f_
       + 3))(v3);
    }
    else
    {
      v5 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *))v3->handler_.__f_
                     + 2))(v3);
    }
  }
  else
  {
    v5 = 0;
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, boost::system::error_code *))f)(v2, v4, &this->arg1_);
  if ( v4 == v5 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v5 + 32LL))(v5);
  }
  else if ( v5 )
  {
    (*(void (**)(void))(*(_QWORD *)v5 + 40LL))();
  }
}


// Address: 0x262ec70 | Name: _ZN5boost4asio6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS5_6config15asio_tls_client16transport_configEEEFvNS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeEmEJNS3_10shared_ptrISC_EERSI_RKNS3_12placeholders4__phILi1EEERKNST_ILi2EEEEEESK_mEclEv
void __fastcall boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>::operator()(
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *this)
{
  std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd f; // r12
  _QWORD *v3; // r14
  boost::system::error_code *p_arg1; // r15
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *v5; // rdi
  _BYTE v6[32]; // [rsp+0h] [rbp-58h] BYREF
  _BYTE *v7; // [rsp+20h] [rbp-38h]
  unsigned __int64 v8; // [rsp+30h] [rbp-28h]

  v8 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v3 = (_QWORD *)((char *)this->handler_.__bound_args_.__base_.__value_.__ptr_ + *((_QWORD *)&this->handler_.__f_ + 1));
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd *)((char *)f + *v3 - 1);
  p_arg1 = &this->arg1_;
  v5 = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v5 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v5 )
    {
      v7 = v6;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *))v5->handler_.__f_
       + 3))(v5);
    }
    else
    {
      v7 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *))v5->handler_.__f_
                     + 2))(v5);
    }
  }
  else
  {
    v7 = 0;
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, boost::system::error_code *, unsigned __int64))f)(
    v3,
    v6,
    p_arg1,
    this->arg2_);
  if ( v6 == v7 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v7 + 32LL))(v7);
  }
  else if ( v7 )
  {
    (*(void (**)(void))(*(_QWORD *)v7 + 40LL))();
  }
}


// Address: 0x26366b0 | Name: _ZN5boost4asio6detail7binder1INSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeEEJNS3_10shared_ptrIS9_EERSF_RKNS3_12placeholders4__phILi1EEEEEESH_EclEv
void __fastcall boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>::operator()(
        boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *this)
{
  std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd f; // r12
  _QWORD *v2; // rbx
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *v3; // rax
  _BYTE v4[32]; // [rsp+0h] [rbp-58h] BYREF
  _BYTE *v5; // [rsp+20h] [rbp-38h]
  unsigned __int64 v6; // [rsp+30h] [rbp-28h]

  v6 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v2 = (std::weak_ptr<websocketpp::transport::asio::tls_socket::connection>::element_type **)((char *)&this->handler_.__bound_args_.__base_.__value_.__ptr_->__weak_this_.__ptr_
                                                                                            + *((_QWORD *)&this->handler_.__f_
                                                                                              + 1));
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd *)((char *)f + *v2 - 1);
  v3 = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v3 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v3 )
    {
      v5 = v4;
      (*((void (__fastcall **)(boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *))v3->handler_.__f_
       + 3))(v3);
    }
    else
    {
      v5 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *))v3->handler_.__f_
                     + 2))(v3);
    }
  }
  else
  {
    v5 = 0;
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, boost::system::error_code *))f)(v2, v4, &this->arg1_);
  if ( v4 == v5 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v5 + 32LL))(v5);
  }
  else if ( v5 )
  {
    (*(void (**)(void))(*(_QWORD *)v5 + 40LL))();
  }
}


// Address: 0x2658030 | Name: _ZN5boost4asio6detail7binder1INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS5_6config11asio_client16transport_configEEEFvNS3_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISG_EENS0_22deadline_timer_serviceISG_SI_EEEEEENS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeEEJNSD_ISC_EERSM_RSS_RKNS3_12placeholders4__phILi1EEEEEESU_EclEv
void __fastcall boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>::operator()(
        boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *this)
{
  std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd f; // r12
  _QWORD *v3; // r14
  volatile signed __int64 *cntrl; // rax
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *v5; // rdi
  std::__shared_weak_count *v6; // rbx
  std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type *ptr; // [rsp+0h] [rbp-68h] BYREF
  std::__shared_weak_count *v8; // [rsp+8h] [rbp-60h]
  _BYTE v9[32]; // [rsp+10h] [rbp-58h] BYREF
  _BYTE *v10; // [rsp+30h] [rbp-38h]
  unsigned __int64 v11; // [rsp+40h] [rbp-28h]

  v11 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v3 = (_QWORD *)((char *)this->handler_.__bound_args_.__base_.__value_.__ptr_ + *((_QWORD *)&this->handler_.__f_ + 1));
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd *)((char *)f + *v3 - 1);
  ptr = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v8 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v5 = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v5 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v5 )
    {
      v10 = v9;
      (*((void (__fastcall **)(boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *))v5->handler_.__f_
       + 3))(v5);
    }
    else
    {
      v10 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *))v5->handler_.__f_
                      + 2))(v5);
    }
  }
  else
  {
    v10 = 0;
  }
  ((void (__fastcall *)(_QWORD *, std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type **, _BYTE *, boost::system::error_code *))f)(
    v3,
    &ptr,
    v9,
    &this->arg1_);
  if ( v9 == v10 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v10 + 32LL))(v10);
  }
  else if ( v10 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v10 + 40LL))(v10);
  }
  v6 = v8;
  if ( v8 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
      std::__shared_weak_count::__release_weak(v6);
    }
  }
}


// Address: 0x2664e40 | Name: _ZN5boost4asio6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS5_6config11asio_client16transport_configEEEFvNS3_10shared_ptrINS7_10connectionISB_EEEENSD_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISJ_EENS0_22deadline_timer_serviceISJ_SL_EEEEEENS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS10_3tcpEEEEJPSC_RSG_RSP_RSV_RKNS3_12placeholders4__phILi1EEERKNS1B_ILi2EEEEEESX_S13_EclEv
void __fastcall boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *this)
{
  std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd f; // r12
  unsigned __int8 *v3; // r14
  volatile signed __int64 *cntrl; // rax
  volatile signed __int64 *v5; // rax
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *v6; // rdi
  volatile signed __int64 *v7; // rax
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9; // rbx
  std::__shared_weak_count *v10; // rbx
  std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type *v11; // [rsp+8h] [rbp-90h] BYREF
  std::__shared_weak_count *v12; // [rsp+10h] [rbp-88h]
  std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *ptr; // [rsp+18h] [rbp-80h] BYREF
  std::__shared_weak_count *v14; // [rsp+20h] [rbp-78h]
  std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >::element_type *v15; // [rsp+28h] [rbp-70h] BYREF
  std::__shared_weak_count *v16; // [rsp+30h] [rbp-68h]
  size_t index; // [rsp+38h] [rbp-60h]
  _BYTE v18[32]; // [rsp+40h] [rbp-58h] BYREF
  _BYTE *v19; // [rsp+60h] [rbp-38h]
  unsigned __int64 v20; // [rsp+70h] [rbp-28h]

  v20 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v3 = &this->handler_.__bound_args_.__base_.__value_->m_socket_init_handler.__buf_.__lx[*((_QWORD *)&this->handler_.__f_
                                                                                         + 1)];
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd *)((char *)f + *(_QWORD *)v3 - 1);
  ptr = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v14 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v11 = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  v5 = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v12 = (std::__shared_weak_count *)v5;
  if ( v5 )
    _InterlockedAdd64(v5 + 1, 1u);
  v6 = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v6 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v6 )
    {
      v19 = v18;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *))v6->handler_.__f_
       + 3))(v6);
    }
    else
    {
      v19 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *))v6->handler_.__f_
                      + 2))(v6);
    }
  }
  else
  {
    v19 = 0;
  }
  v15 = this->arg2_.values_.__ptr_;
  v7 = (volatile signed __int64 *)this->arg2_.values_.__cntrl_;
  v16 = (std::__shared_weak_count *)v7;
  if ( v7 )
    _InterlockedAdd64(v7 + 1, 1u);
  index = this->arg2_.index_;
  ((void (__fastcall *)(unsigned __int8 *, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type **, std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type **, _BYTE *, boost::system::error_code *, std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >::element_type **))f)(
    v3,
    &ptr,
    &v11,
    v18,
    &this->arg1_,
    &v15);
  v8 = v16;
  if ( v16 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v16 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
    std::__shared_weak_count::__release_weak(v8);
  }
  if ( v18 == v19 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v19 + 32LL))(v19);
  }
  else if ( v19 )
  {
    (*(void (**)(void))(*(_QWORD *)v19 + 40LL))();
  }
  v9 = v12;
  if ( v12 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v12 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
    std::__shared_weak_count::__release_weak(v9);
  }
  v10 = v14;
  if ( v14 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v14 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
      std::__shared_weak_count::__release_weak(v10);
    }
  }
}


// Address: 0x2668820 | Name: _ZN5boost4asio6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS5_6config11asio_client16transport_configEEEFvNS3_10shared_ptrINS7_10connectionISB_EEEENSD_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISJ_EENS0_22deadline_timer_serviceISJ_SL_EEEEEENS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeEEJPSC_RSG_RSP_RSV_RKNS3_12placeholders4__phILi1EEEEEESX_NS0_2ip23basic_resolver_iteratorINS1C_3tcpEEEEclEv
void __fastcall boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *this)
{
  std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd f; // r12
  unsigned __int8 *v3; // r14
  volatile signed __int64 *cntrl; // rax
  volatile signed __int64 *v5; // rax
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *v6; // rdi
  std::__shared_weak_count *v7; // rbx
  std::__shared_weak_count *v8; // rbx
  std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type *v9; // [rsp+0h] [rbp-78h] BYREF
  std::__shared_weak_count *v10; // [rsp+8h] [rbp-70h]
  std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *ptr; // [rsp+10h] [rbp-68h] BYREF
  std::__shared_weak_count *v12; // [rsp+18h] [rbp-60h]
  _BYTE v13[32]; // [rsp+20h] [rbp-58h] BYREF
  _BYTE *v14; // [rsp+40h] [rbp-38h]
  unsigned __int64 v15; // [rsp+50h] [rbp-28h]

  v15 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v3 = &this->handler_.__bound_args_.__base_.__value_->m_socket_init_handler.__buf_.__lx[*((_QWORD *)&this->handler_.__f_
                                                                                         + 1)];
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd *)((char *)f + *(_QWORD *)v3 - 1);
  ptr = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v12 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v9 = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  v5 = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v10 = (std::__shared_weak_count *)v5;
  if ( v5 )
    _InterlockedAdd64(v5 + 1, 1u);
  v6 = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v6 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v6 )
    {
      v14 = v13;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *))v6->handler_.__f_
       + 3))(v6);
    }
    else
    {
      v14 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *))v6->handler_.__f_
                      + 2))(v6);
    }
  }
  else
  {
    v14 = 0;
  }
  ((void (__fastcall *)(unsigned __int8 *, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type **, std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >::element_type **, _BYTE *, boost::system::error_code *))f)(
    v3,
    &ptr,
    &v9,
    v13,
    &this->arg1_);
  if ( v13 == v14 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v14 + 32LL))(v14);
  }
  else if ( v14 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v14 + 40LL))(v14);
  }
  v7 = v10;
  if ( v10 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  v8 = v12;
  if ( v12 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v12 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
  }
}


// Address: 0x266d030 | Name: _ZN5boost4asio6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS5_6config11asio_client16transport_configEEEFvNS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeEEJNS3_10shared_ptrISC_EERSI_RKNS3_12placeholders4__phILi1EEEEEESK_mEclEv
void __fastcall boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>::operator()(
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *this)
{
  std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd f; // r12
  _QWORD *v2; // rbx
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *v3; // rax
  _BYTE v4[32]; // [rsp+0h] [rbp-58h] BYREF
  _BYTE *v5; // [rsp+20h] [rbp-38h]
  unsigned __int64 v6; // [rsp+30h] [rbp-28h]

  v6 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v2 = (_QWORD *)((char *)this->handler_.__bound_args_.__base_.__value_.__ptr_ + *((_QWORD *)&this->handler_.__f_ + 1));
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd *)((char *)f + *v2 - 1);
  v3 = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v3 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v3 )
    {
      v5 = v4;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *))v3->handler_.__f_
       + 3))(v3);
    }
    else
    {
      v5 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *))v3->handler_.__f_
                     + 2))(v3);
    }
  }
  else
  {
    v5 = 0;
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, boost::system::error_code *))f)(v2, v4, &this->arg1_);
  if ( v4 == v5 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v5 + 32LL))(v5);
  }
  else if ( v5 )
  {
    (*(void (**)(void))(*(_QWORD *)v5 + 40LL))();
  }
}


// Address: 0x266ffa0 | Name: _ZN5boost4asio6detail7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS5_6config11asio_client16transport_configEEEFvNS3_8functionIFvRKNS3_10error_codeEEEERKNS_6system10error_codeEmEJNS3_10shared_ptrISC_EERSI_RKNS3_12placeholders4__phILi1EEERKNST_ILi2EEEEEESK_mEclEv
void __fastcall boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>::operator()(
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *this)
{
  std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd f; // r12
  _QWORD *v3; // r14
  boost::system::error_code *p_arg1; // r15
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *v5; // rdi
  _BYTE v6[32]; // [rsp+0h] [rbp-58h] BYREF
  _BYTE *v7; // [rsp+20h] [rbp-38h]
  unsigned __int64 v8; // [rsp+30h] [rbp-28h]

  v8 = __readfsqword(0x28u);
  f = this->handler_.__f_;
  v3 = (_QWORD *)((char *)this->handler_.__bound_args_.__base_.__value_.__ptr_ + *((_QWORD *)&this->handler_.__f_ + 1));
  if ( ((__int64)this->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd *)((char *)f + *v3 - 1);
  p_arg1 = &this->arg1_;
  v5 = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( v5 )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v5 )
    {
      v7 = v6;
      (*((void (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *))v5->handler_.__f_
       + 3))(v5);
    }
    else
    {
      v7 = (_BYTE *)(*((__int64 (__fastcall **)(boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *))v5->handler_.__f_
                     + 2))(v5);
    }
  }
  else
  {
    v7 = 0;
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, boost::system::error_code *, unsigned __int64))f)(
    v3,
    v6,
    p_arg1,
    this->arg2_);
  if ( v6 == v7 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v7 + 32LL))(v7);
  }
  else if ( v7 )
  {
    (*(void (**)(void))(*(_QWORD *)v7 + 40LL))();
  }
}


