// Address: 0xdb5010 | Name: _ZNK5boost4_mfi3mf1Iv11CWebServiceNS_10shared_ptrINS2_7JobItemEEEEclEPS2_S5_
void __fastcall boost::_mfi::mf1<void,CWebService,boost::shared_ptr<CWebService::JobItem>>::operator()(
        const boost::_mfi::mf1<void,CWebService,boost::shared_ptr<CWebService::JobItem> > *this,
        CWebService *p,
        boost::shared_ptr<CWebService::JobItem> a1)
{
  boost::_mfi::mf1<void,CWebService,boost::shared_ptr<CWebService::JobItem> >::F f; // rcx
  _QWORD *v4; // rsi
  volatile signed __int32 *v5; // rax
  volatile signed __int32 *v6; // rbx
  __int64 v7; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,CWebService,boost::shared_ptr<CWebService::JobItem> >::F *)((char *)f + *v4 - 1);
  v7 = *(_QWORD *)a1.px;
  v5 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v8 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0xefd2c0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX16PlayerConfigurerENS_10shared_ptrIbEEEclEPS3_S5_
void __fastcall boost::_mfi::mf1<void,RBX::PlayerConfigurer,boost::shared_ptr<bool>>::operator()(
        const boost::_mfi::mf1<void,RBX::PlayerConfigurer,boost::shared_ptr<bool> > *this,
        RBX::PlayerConfigurer *p,
        boost::shared_ptr<bool> a1)
{
  boost::_mfi::mf1<void,RBX::PlayerConfigurer,boost::shared_ptr<bool> >::F f; // rcx
  _QWORD *v4; // rsi
  volatile signed __int32 *v5; // rax
  volatile signed __int32 *v6; // rbx
  __int64 v7; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::PlayerConfigurer,boost::shared_ptr<bool> >::F *)((char *)f + *v4 - 1);
  v7 = *(_QWORD *)a1.px;
  v5 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v8 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0xf035d0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX16PlayerConfigurerENS_10shared_ptrINS2_6PlayerEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::PlayerConfigurer,boost::shared_ptr<RBX::Player>>::operator()(
        const boost::_mfi::mf1<void,RBX::PlayerConfigurer,boost::shared_ptr<RBX::Player> > *this,
        RBX::PlayerConfigurer *p,
        boost::shared_ptr<RBX::Player> a1)
{
  boost::_mfi::mf1<void,RBX::PlayerConfigurer,boost::shared_ptr<RBX::Player> >::F f; // rcx
  _QWORD *v4; // rsi
  volatile signed __int32 *v5; // rax
  volatile signed __int32 *v6; // rbx
  __int64 v7; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::PlayerConfigurer,boost::shared_ptr<RBX::Player> >::F *)((char *)f + *v4 - 1);
  v7 = *(_QWORD *)a1.px;
  v5 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v8 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0xf7d770 | Name: _ZNK5boost4_mfi3mf4IvN3RBX7Network10ReplicatorERKN6RakNet13SystemAddressERKNS_10shared_ptrINS3_13NetworkStreamEEENS9_INS2_8InstanceEEERKNS2_16TextFilterResultEE4callINS9_IS4_EES7_SC_SF_SH_EEvRT_PKvRT0_RT1_RT2_RT3_
void __fastcall boost::_mfi::mf4<void,RBX::Network::Replicator,RakNet::SystemAddress const&,boost::shared_ptr<RBX::Network::NetworkStream> const&,boost::shared_ptr<RBX::Instance>,RBX::TextFilterResult const&>::call<boost::shared_ptr<RBX::Network::Replicator>,RakNet::SystemAddress const,boost::shared_ptr<RBX::Network::NetworkStream> const,boost::shared_ptr<RBX::Instance>,RBX::TextFilterResult const>(
        const boost::_mfi::mf4<void,RBX::Network::Replicator,const RakNet::SystemAddress &,const boost::shared_ptr<RBX::Network::NetworkStream> &,boost::shared_ptr<RBX::Instance>,const RBX::TextFilterResult &> *this,
        boost::shared_ptr<RBX::Network::Replicator> *u,
        const void *a3,
        const RakNet::SystemAddress *b1,
        const boost::shared_ptr<RBX::Network::NetworkStream> *b2,
        boost::shared_ptr<RBX::Instance> *b3,
        const RBX::TextFilterResult *b4)
{
  boost::_mfi::mf4<void,RBX::Network::Replicator,const RakNet::SystemAddress &,const boost::shared_ptr<RBX::Network::NetworkStream> &,boost::shared_ptr<RBX::Instance>,const RBX::TextFilterResult &>::F f; // rbx
  _QWORD *v8; // rdi
  boost::detail::sp_counted_base *pi; // rax
  volatile signed __int32 *v10; // rbx
  boost::shared_ptr<RBX::Instance>::element_type *px; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v12; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v8 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf4<void,RBX::Network::Replicator,const RakNet::SystemAddress &,const boost::shared_ptr<RBX::Network::NetworkStream> &,boost::shared_ptr<RBX::Instance>,const RBX::TextFilterResult &>::F *)((char *)f + *v8 - 1);
  px = b3->px;
  pi = b3->pn.pi_;
  v12 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  ((void (__fastcall *)(_QWORD *, const RakNet::SystemAddress *, const boost::shared_ptr<RBX::Network::NetworkStream> *, boost::shared_ptr<RBX::Instance>::element_type **, const RBX::TextFilterResult *))f)(
    v8,
    b1,
    b2,
    &px,
    b4);
  v10 = v12;
  if ( v12 && !_InterlockedSub(v12 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
    if ( !_InterlockedSub(v10 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
  }
}


// Address: 0xf89a40 | Name: _ZNK5boost4_mfi3mf2IvN3RBX7Network10ReplicatorENS_8weak_ptrINS2_9DataModelEEEdE4callINS_10shared_ptrIS4_EES7_dEEvRT_PKvRT0_RT1_
void __fastcall boost::_mfi::mf2<void,RBX::Network::Replicator,boost::weak_ptr<RBX::DataModel>,double>::call<boost::shared_ptr<RBX::Network::Replicator>,boost::weak_ptr<RBX::DataModel>,double>(
        const boost::_mfi::mf2<void,RBX::Network::Replicator,boost::weak_ptr<RBX::DataModel>,double> *this,
        boost::shared_ptr<RBX::Network::Replicator> *u,
        const void *a3,
        boost::weak_ptr<RBX::DataModel> *b1,
        double *b2)
{
  boost::_mfi::mf2<void,RBX::Network::Replicator,boost::weak_ptr<RBX::DataModel>,double>::F f; // rdx
  _QWORD *v6; // rdi
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // rdi
  boost::weak_ptr<RBX::DataModel>::element_type *px; // [rsp+0h] [rbp-18h] BYREF
  boost::detail::sp_counted_base *v10; // [rsp+8h] [rbp-10h]

  f = this->f_;
  v6 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::Network::Replicator,boost::weak_ptr<RBX::DataModel>,double>::F *)((char *)f + *v6 - 1);
  px = b1->px;
  pi = b1->pn.pi_;
  v10 = pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  ((void (__fastcall *)(_QWORD *, boost::weak_ptr<RBX::DataModel>::element_type **, double))f)(v6, &px, *b2);
  v8 = v10;
  if ( v10 )
  {
    if ( !_InterlockedSub(&v10->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
  }
}


// Address: 0xfbf8c0 | Name: _ZNK5boost4_mfi3mf3IvN3RBX7Network10Replicator9StreamJobENS_10shared_ptrINS2_8InstanceEEEPNS5_14StreamDataItemERmEclEPS5_S8_SA_SB_
void __fastcall boost::_mfi::mf3<void,RBX::Network::Replicator::StreamJob,boost::shared_ptr<RBX::Instance>,RBX::Network::Replicator::StreamJob::StreamDataItem *,unsigned long &>::operator()(
        const boost::_mfi::mf3<void,RBX::Network::Replicator::StreamJob,boost::shared_ptr<RBX::Instance>,RBX::Network::Replicator::StreamJob::StreamDataItem *,unsigned long &> *this,
        RBX::Network::Replicator::StreamJob *p,
        boost::shared_ptr<RBX::Instance> a1,
        RBX::Network::Replicator::StreamJob::StreamDataItem *a2,
        unsigned __int64 *a3)
{
  boost::_mfi::mf3<void,RBX::Network::Replicator::StreamJob,boost::shared_ptr<RBX::Instance>,RBX::Network::Replicator::StreamJob::StreamDataItem *,unsigned long &>::F f; // rbx
  _QWORD *v6; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v8; // rbx
  int (**v9)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v10; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v6 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::Network::Replicator::StreamJob,boost::shared_ptr<RBX::Instance>,RBX::Network::Replicator::StreamJob::StreamDataItem *,unsigned long &>::F *)((char *)f + *v6 - 1);
  v9 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v10 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), boost::detail::sp_counted_base *, RBX::Network::Replicator::StreamJob::StreamDataItem *))f)(
    v6,
    &v9,
    a1.pn.pi_,
    a2);
  v8 = v10;
  if ( v10 && !_InterlockedSub(v10 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
    if ( !_InterlockedSub(v8 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
  }
}


// Address: 0xfc0570 | Name: _ZNK5boost4_mfi3mf1IvN3RBX7Network10Replicator9StreamJobENS_10shared_ptrINS2_8InstanceEEEEclEPS5_S8_
void __fastcall boost::_mfi::mf1<void,RBX::Network::Replicator::StreamJob,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Network::Replicator::StreamJob,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Network::Replicator::StreamJob *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Network::Replicator::StreamJob,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Network::Replicator::StreamJob,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0xff4820 | Name: _ZNK5boost4_mfi3mf1IvN3RBX7Network16ServerReplicatorENS_10shared_ptrINS2_8InstanceEEEEclEPS4_S7_
void __fastcall boost::_mfi::mf1<void,RBX::Network::ServerReplicator,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Network::ServerReplicator,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Network::ServerReplicator *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Network::ServerReplicator,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Network::ServerReplicator,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1041640 | Name: _ZNK5boost4_mfi3mf1IvN3RBX8AnimatorENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::Animator,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Animator,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Animator *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Animator,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Animator,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x10c5790 | Name: _ZNK5boost4_mfi3mf1IvN3RBX8HumanoidENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Humanoid *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x10c64f0 | Name: _ZNK5boost4_mfi3mf2IvN3RBX8HumanoidENS_10shared_ptrINS2_8InstanceEEEbEclEPS3_S6_b
void __fastcall boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,bool>::operator()(
        const boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,bool> *this,
        RBX::Humanoid *p,
        boost::shared_ptr<RBX::Instance> a1,
        bool a2)
{
  boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,bool>::F f; // rbx
  _QWORD *v5; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v7; // rbx
  int (**v8)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,bool>::F *)((char *)f + *v5 - 1);
  v8 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v9 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), _QWORD))f)(v5, &v8, LOBYTE(a1.pn.pi_));
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x10c81b0 | Name: _ZNK5boost4_mfi3mf2IvN3RBX8HumanoidENS_10shared_ptrINS2_8InstanceEEES6_EclEPS3_S6_S6_
void __fastcall boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Humanoid *p,
        boost::shared_ptr<RBX::Instance> a1,
        boost::shared_ptr<RBX::Instance> a2)
{
  boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >::F f; // rbx
  _QWORD *v5; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v7; // rax
  volatile signed __int32 *v8; // rbx
  volatile signed __int32 *v9; // rbx
  int (**v10)(void); // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v11; // [rsp+10h] [rbp-28h]
  int (**v12)(void); // [rsp+18h] [rbp-20h] BYREF
  volatile signed __int32 *v13; // [rsp+20h] [rbp-18h]

  f = this->f_;
  v5 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v5 - 1);
  v12 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v13 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  v10 = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v11 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), int (***)(void), boost::detail::sp_counted_base *, boost::shared_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *))f)(
    v5,
    &v12,
    &v10,
    a1.pn.pi_,
    a2.px,
    a2.pn.pi_);
  v8 = v11;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  v9 = v13;
  if ( v13 && !_InterlockedSub(v13 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
    if ( !_InterlockedSub(v9 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
  }
}


// Address: 0x1129690 | Name: _ZNK5boost4_mfi3mf4IvN3RBX9Scripting14ScriptDebuggerEP9lua_StateNS_8functionIFNS2_10Reflection7VariantES6_EEERS9_RNS_10shared_ptrINSt3__112basic_stringIcNSE_11char_traitsIcEENSE_9allocatorIcEEEEEEEclEPS4_S6_SB_SC_SM_
void __fastcall boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<RBX::Reflection::Variant ()(lua_State *)>,RBX::Reflection::Variant&,boost::shared_ptr<std::string> &>::operator()(
        const boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<RBX::Reflection::Variant (lua_State *)>,RBX::Reflection::Variant &,boost::shared_ptr<std::string > &> *this,
        RBX::Scripting::ScriptDebugger *p,
        lua_State_0 *a1,
        RBX::Reflection::Variant *a3,
        boost::shared_ptr<std::string > *a4,
        __int64 a6)
{
  boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<RBX::Reflection::Variant (lua_State *)>,RBX::Reflection::Variant &,boost::shared_ptr<std::string > &>::F f; // r13
  _QWORD *v10; // rbx
  const RBX::Reflection::Type *type; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  const RBX::Reflection::Type *v13; // [rsp+0h] [rbp-48h] BYREF
  __int128 v14; // [rsp+8h] [rbp-40h] BYREF
  __int64 v15; // [rsp+18h] [rbp-30h]

  f = this->f_;
  v10 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<RBX::Reflection::Variant (lua_State *)>,RBX::Reflection::Variant &,boost::shared_ptr<std::string > &>::F *)((char *)f + *v10 - 1);
  v13 = 0;
  type = a3->_type;
  if ( a3->_type )
  {
    v13 = a3->_type;
    if ( ((unsigned __int8)type & 1) != 0 )
    {
      v15 = *(_QWORD *)&a3->value.data[8];
      v14 = *(_OWORD *)&a3->value.holder;
    }
    else
    {
      (*(void (__fastcall **)(rbx::placement_any<RBX::Reflection::Variant::Storage> *, __int128 *, _QWORD))((unsigned __int64)type & 0xFFFFFFFFFFFFFFFELL))(
        &a3->value,
        &v14,
        0);
    }
  }
  ((void (__fastcall *)(_QWORD *, lua_State_0 *, const RBX::Reflection::Type **, boost::shared_ptr<std::string > *, __int64))f)(
    v10,
    a1,
    &v13,
    a4,
    a6);
  if ( v13 && ((unsigned __int8)v13 & 1) == 0 )
  {
    v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v13 & 0xFFFFFFFFFFFFFFFELL);
    if ( v12 )
      v12(&v14, &v14, 2);
  }
}


// Address: 0x112b5a0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX9Scripting14ScriptDebuggerENS_10shared_ptrINS2_8InstanceEEEEclEPS4_S7_
void __fastcall boost::_mfi::mf1<void,RBX::Scripting::ScriptDebugger,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Scripting::ScriptDebugger,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Scripting::ScriptDebugger *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Scripting::ScriptDebugger,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Scripting::ScriptDebugger,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x112c590 | Name: _ZNK5boost4_mfi3mf4IvN3RBX9Scripting14ScriptDebuggerEP9lua_StateNS_8functionIFNS_10shared_ptrIKNSt3__13mapINS9_12basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEENS2_10Reflection7VariantENS9_4lessISG_EENSE_INS9_4pairIKSG_SI_EEEEEEEES6_EEERSR_RNS8_ISG_EEEclEPS4_S6_ST_SU_SW_
void __fastcall boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const> ()(lua_State *)>,boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>&,boost::shared_ptr<std::string> &>::operator()(
        const boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)>,boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > &,boost::shared_ptr<std::string > &> *this,
        RBX::Scripting::ScriptDebugger *p,
        lua_State_0 *a1,
        boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > *a3,
        boost::shared_ptr<std::string > *a4,
        __int64 a6)
{
  boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)>,boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > &,boost::shared_ptr<std::string > &>::F f; // r13
  _QWORD *v10; // rbx
  boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >::element_type *px; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >::element_type *v13; // [rsp+0h] [rbp-48h] BYREF
  __int128 v14; // [rsp+8h] [rbp-40h] BYREF
  boost::detail::sp_counted_base *pi; // [rsp+18h] [rbp-30h]

  f = this->f_;
  v10 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)>,boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > &,boost::shared_ptr<std::string > &>::F *)((char *)f + *v10 - 1);
  v13 = 0;
  px = a3->px;
  if ( a3->px )
  {
    v13 = a3->px;
    if ( ((unsigned __int8)px & 1) != 0 )
    {
      pi = a3[1].pn.pi_;
      v14 = *(_OWORD *)&a3->pn.pi_;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::shared_count *, __int128 *, _QWORD))((unsigned __int64)px
                                                                                & 0xFFFFFFFFFFFFFFFELL))(
        &a3->pn,
        &v14,
        0);
    }
  }
  ((void (__fastcall *)(_QWORD *, lua_State_0 *, boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >::element_type **, boost::shared_ptr<std::string > *, __int64))f)(
    v10,
    a1,
    &v13,
    a4,
    a6);
  if ( v13 && ((unsigned __int8)v13 & 1) == 0 )
  {
    v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v13 & 0xFFFFFFFFFFFFFFFELL);
    if ( v12 )
      v12(&v14, &v14, 2);
  }
}


// Address: 0x112d8f0 | Name: _ZNK5boost4_mfi3mf4IvN3RBX9Scripting14ScriptDebuggerEP9lua_StateNS_8functionIFbS6_EEERbRNS_10shared_ptrINSt3__112basic_stringIcNSC_11char_traitsIcEENSC_9allocatorIcEEEEEEEclEPS4_S6_S9_SA_SK_
void __fastcall boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<bool ()(lua_State *)>,bool &,boost::shared_ptr<std::string> &>::operator()(
        const boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<bool (lua_State *)>,bool &,boost::shared_ptr<std::string > &> *this,
        RBX::Scripting::ScriptDebugger *p,
        lua_State_0 *a1,
        bool *a3,
        boost::shared_ptr<std::string > *a4,
        __int64 a6)
{
  boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<bool (lua_State *)>,bool &,boost::shared_ptr<std::string > &>::F f; // r13
  _QWORD *v10; // rbx
  __int64 v11; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  __int64 v13; // [rsp+0h] [rbp-48h] BYREF
  __int128 v14; // [rsp+8h] [rbp-40h] BYREF
  __int64 v15; // [rsp+18h] [rbp-30h]

  f = this->f_;
  v10 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<bool (lua_State *)>,bool &,boost::shared_ptr<std::string > &>::F *)((char *)f + *v10 - 1);
  v13 = 0;
  v11 = *(_QWORD *)a3;
  if ( *(_QWORD *)a3 )
  {
    v13 = *(_QWORD *)a3;
    if ( (v11 & 1) != 0 )
    {
      v15 = *((_QWORD *)a3 + 3);
      v14 = *(_OWORD *)(a3 + 8);
    }
    else
    {
      (*(void (__fastcall **)(bool *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a3 + 8, &v14, 0);
    }
  }
  ((void (__fastcall *)(_QWORD *, lua_State_0 *, __int64 *, boost::shared_ptr<std::string > *, __int64))f)(
    v10,
    a1,
    &v13,
    a4,
    a6);
  if ( v13 && (v13 & 1) == 0 )
  {
    v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
    if ( v12 )
      v12(&v14, &v14, 2);
  }
}


// Address: 0x11353f0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX9Scripting15DebuggerManagerENS_10shared_ptrINS2_8InstanceEEEEclEPS4_S7_
void __fastcall boost::_mfi::mf1<void,RBX::Scripting::DebuggerManager,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Scripting::DebuggerManager,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Scripting::DebuggerManager *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Scripting::DebuggerManager,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Scripting::DebuggerManager,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1199910 | Name: _ZNK5boost4_mfi3mf1Iv24YieldFunctionStateObjectN3RBX10Reflection7VariantEE4callINS_10shared_ptrIS2_EES5_EEvRT_PKvRT0_
void __fastcall boost::_mfi::mf1<void,YieldFunctionStateObject,RBX::Reflection::Variant>::call<boost::shared_ptr<YieldFunctionStateObject>,RBX::Reflection::Variant>(
        const boost::_mfi::mf1<void,YieldFunctionStateObject,RBX::Reflection::Variant> *this,
        boost::shared_ptr<YieldFunctionStateObject> *u,
        const void *a3,
        RBX::Reflection::Variant *b1)
{
  boost::_mfi::mf1<void,YieldFunctionStateObject,RBX::Reflection::Variant>::F f; // r15
  _QWORD *v6; // r14
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v8; // rax
  const RBX::Reflection::Type *type; // [rsp+8h] [rbp-90h] BYREF
  const rbx::implementation::type_holder *v10; // [rsp+10h] [rbp-88h]
  _BYTE v11[96]; // [rsp+18h] [rbp-80h] BYREF
  unsigned __int64 v12; // [rsp+78h] [rbp-20h]

  v12 = __readfsqword(0x28u);
  f = this->f_;
  v6 = (boost::weak_ptr<YieldFunctionStateObject>::element_type **)((char *)&u->px->weak_this_.px
                                                                  + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,YieldFunctionStateObject,RBX::Reflection::Variant>::F *)((char *)f + *v6 - 1);
  type = b1->_type;
  v10 = 0;
  holder = b1->value.holder;
  if ( holder )
  {
    ((void (__fastcall *)(char *, _BYTE *, const void *))holder->construct)(b1->value.data, v11, a3);
    v8 = b1->value.holder;
  }
  else
  {
    v8 = 0;
  }
  v10 = v8;
  ((void (__fastcall *)(_QWORD *, const RBX::Reflection::Type **))f)(v6, &type);
  if ( v10 )
    v10->destruct(v11);
}


// Address: 0x11dab10 | Name: _ZNK5boost4_mfi3mf1IvN3RBX13ScriptContextENS_8weak_ptrINS2_10BaseScriptEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::ScriptContext,boost::weak_ptr<RBX::BaseScript>>::operator()(
        const boost::_mfi::mf1<void,RBX::ScriptContext,boost::weak_ptr<RBX::BaseScript> > *this,
        RBX::ScriptContext *p,
        boost::weak_ptr<RBX::BaseScript> a1)
{
  boost::_mfi::mf1<void,RBX::ScriptContext,boost::weak_ptr<RBX::BaseScript> >::F f; // rcx
  _QWORD *v4; // rsi
  __int64 v5; // rax
  __int64 v6; // rdi
  __int64 v7; // [rsp+0h] [rbp-18h] BYREF
  __int64 v8; // [rsp+8h] [rbp-10h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::ScriptContext,boost::weak_ptr<RBX::BaseScript> >::F *)((char *)f + *v4 - 1);
  v7 = *(_QWORD *)a1.px;
  v5 = *((_QWORD *)a1.px + 1);
  v8 = v5;
  if ( v5 )
    _InterlockedAdd((volatile signed __int32 *)(v5 + 12), 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *))f)(v4, &v7);
  v6 = v8;
  if ( v8 )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(v8 + 12), 1u) )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x11ecbe0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX21CoreScriptSyncServiceENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::CoreScriptSyncService,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::CoreScriptSyncService,boost::shared_ptr<RBX::Instance> > *this,
        RBX::CoreScriptSyncService *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::CoreScriptSyncService,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::CoreScriptSyncService,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x12ec8d0 | Name: _ZNK5boost4_mfi3mf3IvN3RBX13StandardPagesENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvvEEENSB_IFvSA_EEEE4callINS_10shared_ptrIS3_EESA_SD_SF_EEvRT_PKvRT0_RT1_RT2_
void __fastcall boost::_mfi::mf3<void,RBX::StandardPages,std::string,boost::function<void ()(void)>,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::StandardPages>,std::string,boost::function<void ()(void)>,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf3<void,RBX::StandardPages,std::string,boost::function<void ()>,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::StandardPages> *u,
        const void *a3,
        std::string *b1,
        boost::function<void ()>_0 *b2,
        boost::function<void (std::string)>_0 *b3)
{
  boost::_mfi::mf3<void,RBX::StandardPages,std::string,boost::function<void ()>,boost::function<void (std::string)> >::F f; // r12
  _QWORD *v9; // r15
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v11; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  boost::detail::function::vtable_base *v14; // [rsp+0h] [rbp-78h] BYREF
  __int128 v15; // [rsp+8h] [rbp-70h] BYREF
  void *v16; // [rsp+18h] [rbp-60h]
  boost::detail::function::vtable_base *v17; // [rsp+20h] [rbp-58h] BYREF
  __int128 v18; // [rsp+28h] [rbp-50h] BYREF
  void *obj_ptr; // [rsp+38h] [rbp-40h]
  _BYTE v20[16]; // [rsp+40h] [rbp-38h] BYREF
  void *ptr; // [rsp+50h] [rbp-28h]

  f = this->f_;
  v9 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::StandardPages,std::string,boost::function<void ()>,boost::function<void (std::string)> >::F *)((char *)f + *v9 - 1);
  std::string::basic_string(v20, b1);
  v17 = 0;
  vtable = b2->vtable;
  if ( b2->vtable )
  {
    v17 = b2->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      obj_ptr = b2->functor.bound_memfunc_ptr.obj_ptr;
      v18 = *(_OWORD *)&b2->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)vtable
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b2->functor,
        &v18,
        0);
    }
  }
  v14 = 0;
  v11 = b3->vtable;
  if ( b3->vtable )
  {
    v14 = b3->vtable;
    if ( ((unsigned __int8)v11 & 1) != 0 )
    {
      v16 = b3->functor.bound_memfunc_ptr.obj_ptr;
      v15 = *(_OWORD *)&b3->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)v11
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b3->functor,
        &v15,
        0);
    }
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, boost::detail::function::vtable_base **, boost::detail::function::vtable_base **))f)(
    v9,
    v20,
    &v17,
    &v14);
  if ( v14 )
  {
    if ( ((unsigned __int8)v14 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v14 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v15, &v15, 2);
    }
    v14 = 0;
  }
  if ( v17 )
  {
    if ( ((unsigned __int8)v17 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v17 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v18, &v18, 2);
    }
    v17 = 0;
  }
  if ( (v20[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x12ed3d0 | Name: _ZNK5boost4_mfi3mf2IvN3RBX13StandardPagesENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvSA_EEEE4callINS_10shared_ptrIS3_EESA_SD_EEvRT_PKvRT0_RT1_
void __fastcall boost::_mfi::mf2<void,RBX::StandardPages,std::string,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::StandardPages>,std::string,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf2<void,RBX::StandardPages,std::string,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::StandardPages> *u,
        const void *a3,
        std::string *b1,
        boost::function<void (std::string)>_0 *b2)
{
  boost::_mfi::mf2<void,RBX::StandardPages,std::string,boost::function<void (std::string)> >::F f; // r15
  _QWORD *v7; // rbx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(__int128 *, __int128 *, __int64); // rax
  boost::detail::function::vtable_base *v10; // [rsp+8h] [rbp-50h] BYREF
  __int128 v11; // [rsp+10h] [rbp-48h] BYREF
  void *obj_ptr; // [rsp+20h] [rbp-38h]
  _BYTE v13[16]; // [rsp+28h] [rbp-30h] BYREF
  void *ptr; // [rsp+38h] [rbp-20h]

  f = this->f_;
  v7 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::StandardPages,std::string,boost::function<void (std::string)> >::F *)((char *)f + *v7 - 1);
  std::string::basic_string(v13, b1);
  v10 = 0;
  vtable = b2->vtable;
  if ( b2->vtable )
  {
    v10 = b2->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      obj_ptr = b2->functor.bound_memfunc_ptr.obj_ptr;
      v11 = *(_OWORD *)&b2->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)vtable
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b2->functor,
        &v11,
        0);
    }
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, boost::detail::function::vtable_base **))f)(v7, v13, &v10);
  if ( v10 )
  {
    if ( ((unsigned __int8)v10 & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v10 & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v11, &v11, 2);
    }
    v10 = 0;
  }
  if ( (v13[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x12ee250 | Name: _ZNK5boost4_mfi3mf3IvN3RBX11FriendPagesENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvvEEENSB_IFvSA_EEEE4callINS_10shared_ptrIS3_EESA_SD_SF_EEvRT_PKvRT0_RT1_RT2_
void __fastcall boost::_mfi::mf3<void,RBX::FriendPages,std::string,boost::function<void ()(void)>,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::FriendPages>,std::string,boost::function<void ()(void)>,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf3<void,RBX::FriendPages,std::string,boost::function<void ()>,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::FriendPages> *u,
        const void *a3,
        std::string *b1,
        boost::function<void ()>_0 *b2,
        boost::function<void (std::string)>_0 *b3)
{
  boost::_mfi::mf3<void,RBX::FriendPages,std::string,boost::function<void ()>,boost::function<void (std::string)> >::F f; // r12
  _QWORD *v9; // r15
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v11; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  boost::detail::function::vtable_base *v14; // [rsp+0h] [rbp-78h] BYREF
  __int128 v15; // [rsp+8h] [rbp-70h] BYREF
  void *v16; // [rsp+18h] [rbp-60h]
  boost::detail::function::vtable_base *v17; // [rsp+20h] [rbp-58h] BYREF
  __int128 v18; // [rsp+28h] [rbp-50h] BYREF
  void *obj_ptr; // [rsp+38h] [rbp-40h]
  _BYTE v20[16]; // [rsp+40h] [rbp-38h] BYREF
  void *ptr; // [rsp+50h] [rbp-28h]

  f = this->f_;
  v9 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::FriendPages,std::string,boost::function<void ()>,boost::function<void (std::string)> >::F *)((char *)f + *v9 - 1);
  std::string::basic_string(v20, b1);
  v17 = 0;
  vtable = b2->vtable;
  if ( b2->vtable )
  {
    v17 = b2->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      obj_ptr = b2->functor.bound_memfunc_ptr.obj_ptr;
      v18 = *(_OWORD *)&b2->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)vtable
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b2->functor,
        &v18,
        0);
    }
  }
  v14 = 0;
  v11 = b3->vtable;
  if ( b3->vtable )
  {
    v14 = b3->vtable;
    if ( ((unsigned __int8)v11 & 1) != 0 )
    {
      v16 = b3->functor.bound_memfunc_ptr.obj_ptr;
      v15 = *(_OWORD *)&b3->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)v11
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b3->functor,
        &v15,
        0);
    }
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, boost::detail::function::vtable_base **, boost::detail::function::vtable_base **))f)(
    v9,
    v20,
    &v17,
    &v14);
  if ( v14 )
  {
    if ( ((unsigned __int8)v14 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v14 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v15, &v15, 2);
    }
    v14 = 0;
  }
  if ( v17 )
  {
    if ( ((unsigned __int8)v17 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v17 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v18, &v18, 2);
    }
    v17 = 0;
  }
  if ( (v20[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x12eed50 | Name: _ZNK5boost4_mfi3mf2IvN3RBX11FriendPagesENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvSA_EEEE4callINS_10shared_ptrIS3_EESA_SD_EEvRT_PKvRT0_RT1_
void __fastcall boost::_mfi::mf2<void,RBX::FriendPages,std::string,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::FriendPages>,std::string,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf2<void,RBX::FriendPages,std::string,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::FriendPages> *u,
        const void *a3,
        std::string *b1,
        boost::function<void (std::string)>_0 *b2)
{
  boost::_mfi::mf2<void,RBX::FriendPages,std::string,boost::function<void (std::string)> >::F f; // r15
  _QWORD *v7; // rbx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(__int128 *, __int128 *, __int64); // rax
  boost::detail::function::vtable_base *v10; // [rsp+8h] [rbp-50h] BYREF
  __int128 v11; // [rsp+10h] [rbp-48h] BYREF
  void *obj_ptr; // [rsp+20h] [rbp-38h]
  _BYTE v13[16]; // [rsp+28h] [rbp-30h] BYREF
  void *ptr; // [rsp+38h] [rbp-20h]

  f = this->f_;
  v7 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::FriendPages,std::string,boost::function<void (std::string)> >::F *)((char *)f + *v7 - 1);
  std::string::basic_string(v13, b1);
  v10 = 0;
  vtable = b2->vtable;
  if ( b2->vtable )
  {
    v10 = b2->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      obj_ptr = b2->functor.bound_memfunc_ptr.obj_ptr;
      v11 = *(_OWORD *)&b2->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)vtable
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b2->functor,
        &v11,
        0);
    }
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, boost::detail::function::vtable_base **))f)(v7, v13, &v10);
  if ( v10 )
  {
    if ( ((unsigned __int8)v10 & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v10 & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v11, &v11, 2);
    }
    v10 = 0;
  }
  if ( (v13[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x12fbf30 | Name: _ZNK5boost4_mfi3mf3IvN3RBX13LuaWebServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvbEEENSB_IFvSA_EEEE4callINS_10shared_ptrIS3_EESA_SD_SF_EEvRT_PKvRT0_RT1_RT2_
void __fastcall boost::_mfi::mf3<void,RBX::LuaWebService,std::string,boost::function<void ()(bool)>,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::LuaWebService>,std::string,boost::function<void ()(bool)>,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf3<void,RBX::LuaWebService,std::string,boost::function<void (bool)>,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::LuaWebService> *u,
        const void *a3,
        std::string *b1,
        boost::function<void (bool)> *b2,
        boost::function<void (std::string)>_0 *b3)
{
  boost::_mfi::mf3<void,RBX::LuaWebService,std::string,boost::function<void (bool)>,boost::function<void (std::string)> >::F f; // r12
  _QWORD *v9; // r15
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v11; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  boost::detail::function::vtable_base *v14; // [rsp+0h] [rbp-78h] BYREF
  __int128 v15; // [rsp+8h] [rbp-70h] BYREF
  void *v16; // [rsp+18h] [rbp-60h]
  boost::detail::function::vtable_base *v17; // [rsp+20h] [rbp-58h] BYREF
  __int128 v18; // [rsp+28h] [rbp-50h] BYREF
  void *obj_ptr; // [rsp+38h] [rbp-40h]
  _BYTE v20[16]; // [rsp+40h] [rbp-38h] BYREF
  void *ptr; // [rsp+50h] [rbp-28h]

  f = this->f_;
  v9 = (int (***)(void))((char *)&u->px->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::LuaWebService,std::string,boost::function<void (bool)>,boost::function<void (std::string)> >::F *)((char *)f + *v9 - 1);
  std::string::basic_string(v20, b1);
  v17 = 0;
  vtable = b2->vtable;
  if ( b2->vtable )
  {
    v17 = b2->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      obj_ptr = b2->functor.bound_memfunc_ptr.obj_ptr;
      v18 = *(_OWORD *)&b2->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)vtable
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b2->functor,
        &v18,
        0);
    }
  }
  v14 = 0;
  v11 = b3->vtable;
  if ( b3->vtable )
  {
    v14 = b3->vtable;
    if ( ((unsigned __int8)v11 & 1) != 0 )
    {
      v16 = b3->functor.bound_memfunc_ptr.obj_ptr;
      v15 = *(_OWORD *)&b3->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)v11
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b3->functor,
        &v15,
        0);
    }
  }
  ((void (__fastcall *)(_QWORD *, _BYTE *, boost::detail::function::vtable_base **, boost::detail::function::vtable_base **))f)(
    v9,
    v20,
    &v17,
    &v14);
  if ( v14 )
  {
    if ( ((unsigned __int8)v14 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v14 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v15, &v15, 2);
    }
    v14 = 0;
  }
  if ( v17 )
  {
    if ( ((unsigned __int8)v17 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v17 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v18, &v18, 2);
    }
    v17 = 0;
  }
  if ( (v20[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x12fce30 | Name: _ZNK5boost4_mfi3mf3IbN3RBX13LuaWebServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvbEEENSB_IFvSA_EEEE4callINS_10shared_ptrIS3_EESA_SD_SF_EEbRT_PKvRT0_RT1_RT2_
bool __fastcall boost::_mfi::mf3<bool,RBX::LuaWebService,std::string,boost::function<void ()(bool)>,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::LuaWebService>,std::string,boost::function<void ()(bool)>,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf3<bool,RBX::LuaWebService,std::string,boost::function<void (bool)>,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::LuaWebService> *u,
        const void *a3,
        std::string *b1,
        boost::function<void (bool)> *b2,
        boost::function<void (std::string)>_0 *b3)
{
  boost::_mfi::mf3<bool,RBX::LuaWebService,std::string,boost::function<void (bool)>,boost::function<void (std::string)> >::F f; // r12
  _QWORD *v9; // r15
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v11; // rax
  char v12; // bl
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  boost::detail::function::vtable_base *v16; // [rsp+0h] [rbp-78h] BYREF
  __int128 v17; // [rsp+8h] [rbp-70h] BYREF
  void *v18; // [rsp+18h] [rbp-60h]
  boost::detail::function::vtable_base *v19; // [rsp+20h] [rbp-58h] BYREF
  __int128 v20; // [rsp+28h] [rbp-50h] BYREF
  void *obj_ptr; // [rsp+38h] [rbp-40h]
  _BYTE v22[16]; // [rsp+40h] [rbp-38h] BYREF
  void *ptr; // [rsp+50h] [rbp-28h]

  f = this->f_;
  v9 = (int (***)(void))((char *)&u->px->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<bool,RBX::LuaWebService,std::string,boost::function<void (bool)>,boost::function<void (std::string)> >::F *)((char *)f + *v9 - 1);
  std::string::basic_string(v22, b1);
  v19 = 0;
  vtable = b2->vtable;
  if ( b2->vtable )
  {
    v19 = b2->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      obj_ptr = b2->functor.bound_memfunc_ptr.obj_ptr;
      v20 = *(_OWORD *)&b2->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)vtable
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b2->functor,
        &v20,
        0);
    }
  }
  v16 = 0;
  v11 = b3->vtable;
  if ( b3->vtable )
  {
    v16 = b3->vtable;
    if ( ((unsigned __int8)v11 & 1) != 0 )
    {
      v18 = b3->functor.bound_memfunc_ptr.obj_ptr;
      v17 = *(_OWORD *)&b3->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)v11
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b3->functor,
        &v17,
        0);
    }
  }
  v12 = ((__int64 (__fastcall *)(_QWORD *, _BYTE *, boost::detail::function::vtable_base **, boost::detail::function::vtable_base **))f)(
          v9,
          v22,
          &v19,
          &v16);
  if ( v16 )
  {
    if ( ((unsigned __int8)v16 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( v19 )
  {
    if ( ((unsigned __int8)v19 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v19 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v20, &v20, 2);
    }
    v19 = 0;
  }
  if ( (v22[0] & 1) != 0 )
    operator delete(ptr);
  return v12;
}


// Address: 0x13d3790 | Name: _ZNK5boost4_mfi3mf2IvN3RBX11Constraints10ConstraintENS_10shared_ptrINS2_8InstanceEEES7_EclEPS4_S7_S7_
void __fastcall boost::_mfi::mf2<void,RBX::Constraints::Constraint,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf2<void,RBX::Constraints::Constraint,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Constraints::Constraint *p,
        boost::shared_ptr<RBX::Instance> a1,
        boost::shared_ptr<RBX::Instance> a2)
{
  boost::_mfi::mf2<void,RBX::Constraints::Constraint,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >::F f; // rbx
  _QWORD *v5; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v7; // rax
  volatile signed __int32 *v8; // rbx
  volatile signed __int32 *v9; // rbx
  int (**v10)(void); // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v11; // [rsp+10h] [rbp-28h]
  int (**v12)(void); // [rsp+18h] [rbp-20h] BYREF
  volatile signed __int32 *v13; // [rsp+20h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::Constraints::Constraint,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v5 - 1);
  v12 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v13 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  v10 = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v11 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), int (***)(void), boost::detail::sp_counted_base *, boost::shared_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *))f)(
    v5,
    &v12,
    &v10,
    a1.pn.pi_,
    a2.px,
    a2.pn.pi_);
  v8 = v11;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  v9 = v13;
  if ( v13 && !_InterlockedSub(v13 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
    if ( !_InterlockedSub(v9 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
  }
}


// Address: 0x13d7110 | Name: _ZNK5boost4_mfi3mf2IvN3RBX11Constraints14WeldConstraintENS_10shared_ptrINS2_8InstanceEEES7_EclEPS4_S7_S7_
void __fastcall boost::_mfi::mf2<void,RBX::Constraints::WeldConstraint,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf2<void,RBX::Constraints::WeldConstraint,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Constraints::WeldConstraint *p,
        boost::shared_ptr<RBX::Instance> a1,
        boost::shared_ptr<RBX::Instance> a2)
{
  boost::_mfi::mf2<void,RBX::Constraints::WeldConstraint,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >::F f; // rbx
  _QWORD *v5; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v7; // rax
  volatile signed __int32 *v8; // rbx
  volatile signed __int32 *v9; // rbx
  int (**v10)(void); // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v11; // [rsp+10h] [rbp-28h]
  int (**v12)(void); // [rsp+18h] [rbp-20h] BYREF
  volatile signed __int32 *v13; // [rsp+20h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::Constraints::WeldConstraint,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v5 - 1);
  v12 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v13 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  v10 = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v11 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), int (***)(void), boost::detail::sp_counted_base *, boost::shared_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *))f)(
    v5,
    &v12,
    &v10,
    a1.pn.pi_,
    a2.px,
    a2.pn.pi_);
  v8 = v11;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  v9 = v13;
  if ( v13 && !_InterlockedSub(v13 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
    if ( !_InterlockedSub(v9 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
  }
}


// Address: 0x14168f0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX16AnalyticsServiceENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::AnalyticsService,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::AnalyticsService,boost::shared_ptr<RBX::Instance> > *this,
        RBX::AnalyticsService *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::AnalyticsService,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::AnalyticsService,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1459e10 | Name: _ZNK5boost4_mfi3mf4IvN3RBX14InventoryPagesERKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEbNS_8functionIFvvEEENSD_IFvSA_EEEE4callINS_10shared_ptrIS3_EESB_bSF_SH_EEvRT_PKvRT0_RT1_RT2_RT3_
void __fastcall boost::_mfi::mf4<void,RBX::InventoryPages,std::string const&,bool,boost::function<void ()(void)>,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::InventoryPages>,std::string const,bool,boost::function<void ()(void)>,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf4<void,RBX::InventoryPages,const std::string &,bool,boost::function<void ()>,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::InventoryPages> *u,
        const void *a3,
        const std::string *b1,
        bool *b2,
        boost::function<void ()> *b3,
        boost::function<void (std::string)> *b4)
{
  boost::_mfi::mf4<void,RBX::InventoryPages,const std::string &,bool,boost::function<void ()>,boost::function<void (std::string)> >::F f; // r12
  _QWORD *v9; // r15
  unsigned __int8 v10; // bp
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v12; // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v14)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::function::vtable_base *v15; // [rsp+0h] [rbp-68h] BYREF
  boost::detail::function::function_buffer functor; // [rsp+8h] [rbp-60h] BYREF
  boost::detail::function::vtable_base *v17; // [rsp+20h] [rbp-48h] BYREF
  boost::detail::function::function_buffer v18[2]; // [rsp+28h] [rbp-40h] BYREF

  f = this->f_;
  v9 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf4<void,RBX::InventoryPages,const std::string &,bool,boost::function<void ()>,boost::function<void (std::string)> >::F *)((char *)f + *v9 - 1);
  v10 = *b2;
  v17 = 0;
  vtable = b3->vtable;
  if ( b3->vtable )
  {
    v17 = b3->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      v18[0] = b3->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b3->functor,
        v18,
        0);
  }
  v15 = 0;
  v12 = b4->vtable;
  if ( b4->vtable )
  {
    v15 = b4->vtable;
    if ( ((unsigned __int8)v12 & 1) != 0 )
      functor = b4->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v12 & 0xFFFFFFFFFFFFFFFELL))(
        &b4->functor,
        &functor,
        0);
  }
  ((void (__fastcall *)(_QWORD *, const std::string *, _QWORD, boost::detail::function::vtable_base **, boost::detail::function::vtable_base **))f)(
    v9,
    b1,
    v10,
    &v17,
    &v15);
  if ( v15 )
  {
    if ( ((unsigned __int8)v15 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v15 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&functor, &functor, 2);
    }
    v15 = 0;
  }
  if ( v17 && ((unsigned __int8)v17 & 1) == 0 )
  {
    v14 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17 & 0xFFFFFFFFFFFFFFFELL);
    if ( v14 )
      v14(v18, v18, 2);
  }
}


// Address: 0x145b250 | Name: _ZNK5boost4_mfi3mf7IvN3RBX12AssetServiceEbNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEElSA_NS_10shared_ptrINS2_8InstanceEEENS_8functionIFvlEEENSE_IFvSA_EEEEclEPS3_bSA_lSA_SD_SG_SI_
void __fastcall boost::_mfi::mf7<void,RBX::AssetService,bool,std::string,long,std::string,boost::shared_ptr<RBX::Instance>,boost::function<void ()(long)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        unsigned __int8 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int64 *a7,
        __int64 *a8,
        __int64 *a9)
{
  char *v12; // r12
  char *v13; // rbx
  volatile signed __int32 *v14; // rax
  __int64 v15; // rax
  __int64 v16; // rax
  void (__fastcall *v17)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v18)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v19; // rbx
  __int64 v20; // [rsp+0h] [rbp-A8h] BYREF
  __int128 v21; // [rsp+8h] [rbp-A0h] BYREF
  __int64 v22; // [rsp+18h] [rbp-90h]
  __int64 v23; // [rsp+20h] [rbp-88h] BYREF
  __int128 v24; // [rsp+28h] [rbp-80h] BYREF
  __int64 v25; // [rsp+38h] [rbp-70h]
  __int64 v26; // [rsp+40h] [rbp-68h] BYREF
  volatile signed __int32 *v27; // [rsp+48h] [rbp-60h]
  _BYTE v28[16]; // [rsp+50h] [rbp-58h] BYREF
  void *ptr; // [rsp+60h] [rbp-48h]
  _BYTE v30[16]; // [rsp+68h] [rbp-40h] BYREF
  void *v31; // [rsp+78h] [rbp-30h]

  v12 = *a1;
  v13 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v12 = *(char **)&v12[*(_QWORD *)v13 - 1];
  std::string::basic_string(v30, a4);
  std::string::basic_string(v28, a6);
  v26 = *a7;
  v14 = (volatile signed __int32 *)a7[1];
  v27 = v14;
  if ( v14 )
    _InterlockedAdd(v14 + 2, 1u);
  v23 = 0;
  v15 = *a8;
  if ( *a8 )
  {
    v23 = *a8;
    if ( (v15 & 1) != 0 )
    {
      v25 = a8[3];
      v24 = *(_OWORD *)(a8 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v15 & 0xFFFFFFFFFFFFFFFELL))(a8 + 1, &v24, 0);
    }
  }
  v20 = 0;
  v16 = *a9;
  if ( *a9 )
  {
    v20 = *a9;
    if ( (v16 & 1) != 0 )
    {
      v22 = a9[3];
      v21 = *(_OWORD *)(a9 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v16 & 0xFFFFFFFFFFFFFFFELL))(a9 + 1, &v21, 0);
    }
  }
  ((void (__fastcall *)(char *, _QWORD, _BYTE *, __int64, _BYTE *, __int64 *, __int64 *, __int64 *))v12)(
    v13,
    a3,
    v30,
    a5,
    v28,
    &v26,
    &v23,
    &v20);
  if ( v20 )
  {
    if ( (v20 & 1) == 0 )
    {
      v17 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v20 & 0xFFFFFFFFFFFFFFFELL);
      if ( v17 )
        v17(&v21, &v21, 2);
    }
    v20 = 0;
  }
  if ( v23 )
  {
    if ( (v23 & 1) == 0 )
    {
      v18 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v23 & 0xFFFFFFFFFFFFFFFELL);
      if ( v18 )
        v18(&v24, &v24, 2);
    }
    v23 = 0;
  }
  v19 = v27;
  if ( v27 )
  {
    if ( !_InterlockedSub(v27 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 16LL))(v19);
      if ( !_InterlockedSub(v19 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 24LL))(v19);
    }
  }
  if ( (v28[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v30[0] & 1) != 0 )
    operator delete(v31);
}


// Address: 0x145dca0 | Name: _ZNK5boost4_mfi3mf3IvN3RBX12AssetServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvlEEENSB_IFvSA_EEEEclEPS3_SA_SD_SF_
void __fastcall boost::_mfi::mf3<void,RBX::AssetService,std::string,boost::function<void ()(long)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5)
{
  char *v7; // r12
  char *v8; // r15
  __int64 v9; // rax
  __int64 v10; // rax
  void (__fastcall *v11)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  __int64 v13; // [rsp+0h] [rbp-78h] BYREF
  __int128 v14; // [rsp+8h] [rbp-70h] BYREF
  __int64 v15; // [rsp+18h] [rbp-60h]
  __int64 v16; // [rsp+20h] [rbp-58h] BYREF
  __int128 v17; // [rsp+28h] [rbp-50h] BYREF
  __int64 v18; // [rsp+38h] [rbp-40h]
  _BYTE v19[16]; // [rsp+40h] [rbp-38h] BYREF
  void *ptr; // [rsp+50h] [rbp-28h]

  v7 = *a1;
  v8 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v7 = *(char **)&v7[*(_QWORD *)v8 - 1];
  std::string::basic_string(v19, a3);
  v16 = 0;
  v9 = *a4;
  if ( *a4 )
  {
    v16 = *a4;
    if ( (v9 & 1) != 0 )
    {
      v18 = a4[3];
      v17 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v17, 0);
    }
  }
  v13 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v13 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v15 = a5[3];
      v14 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v14, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *, __int64 *))v7)(v8, v19, &v16, &v13);
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14, &v14, 2);
    }
    v13 = 0;
  }
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( (v19[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x145e460 | Name: _ZNK5boost4_mfi3mf2IvN3RBX12AssetServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvSA_EEEEclEPS3_SA_SD_
void __fastcall boost::_mfi::mf2<void,RBX::AssetService,std::string,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4)
{
  char *v5; // r15
  char *v6; // rbx
  __int64 v7; // rax
  void (__fastcall *v8)(__int128 *, __int128 *, __int64); // rax
  __int64 v9; // [rsp+8h] [rbp-50h] BYREF
  __int128 v10; // [rsp+10h] [rbp-48h] BYREF
  __int64 v11; // [rsp+20h] [rbp-38h]
  _BYTE v12[16]; // [rsp+28h] [rbp-30h] BYREF
  void *ptr; // [rsp+38h] [rbp-20h]

  v5 = *a1;
  v6 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v5 = *(char **)&v5[*(_QWORD *)v6 - 1];
  std::string::basic_string(v12, a3);
  v9 = 0;
  v7 = *a4;
  if ( *a4 )
  {
    v9 = *a4;
    if ( (v7 & 1) != 0 )
    {
      v11 = a4[3];
      v10 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v10, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *))v5)(v6, v12, &v9);
  if ( v9 )
  {
    if ( (v9 & 1) == 0 )
    {
      v8 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v9 & 0xFFFFFFFFFFFFFFFELL);
      if ( v8 )
        v8(&v10, &v10, 2);
    }
    v9 = 0;
  }
  if ( (v12[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x14bcd10 | Name: _ZNK5boost4_mfi3mf1IvN3RBX20ChangeHistoryServiceENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::ChangeHistoryService,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::ChangeHistoryService,boost::shared_ptr<RBX::Instance> > *this,
        RBX::ChangeHistoryService *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::ChangeHistoryService,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::ChangeHistoryService,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x14bcfb0 | Name: _ZNK5boost4_mfi3mf2IvN3RBX20ChangeHistoryServiceENS_10shared_ptrINS2_8InstanceEEEPKNS2_10Reflection18PropertyDescriptorEEclEPS3_S6_SA_
void __fastcall boost::_mfi::mf2<void,RBX::ChangeHistoryService,boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*>::operator()(
        const boost::_mfi::mf2<void,RBX::ChangeHistoryService,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *> *this,
        RBX::ChangeHistoryService *p,
        boost::shared_ptr<RBX::Instance> a1,
        const RBX::Reflection::PropertyDescriptor *a2)
{
  boost::_mfi::mf2<void,RBX::ChangeHistoryService,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *>::F f; // rbx
  _QWORD *v5; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v7; // rbx
  int (**v8)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::ChangeHistoryService,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *>::F *)((char *)f + *v5 - 1);
  v8 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v9 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), boost::detail::sp_counted_base *))f)(v5, &v8, a1.pn.pi_);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x14e80a0 | Name: _ZNK5boost4_mfi3mf5IvN3RBX11ChatServiceEbNS_10shared_ptrINS2_6PlayerEEES6_NSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEERKNS2_13SystemAddressEE4callINS4_IS3_EEbS6_S6_SD_SF_EEvRT_PKvRT0_RT1_RT2_RT3_RT4_
void __fastcall boost::_mfi::mf5<void,RBX::ChatService,bool,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,RBX::SystemAddress const&>::call<boost::shared_ptr<RBX::ChatService>,bool,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,RBX::SystemAddress const>(
        const boost::_mfi::mf5<void,RBX::ChatService,bool,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,const RBX::SystemAddress &> *this,
        boost::shared_ptr<RBX::ChatService> *u,
        const void *a3,
        bool *b1,
        boost::shared_ptr<RBX::Player> *b2,
        boost::shared_ptr<RBX::Player> *b3,
        std::string *b4,
        const RBX::SystemAddress *b5)
{
  boost::_mfi::mf5<void,RBX::ChatService,bool,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,const RBX::SystemAddress &>::F f; // r14
  _QWORD *v9; // rbx
  unsigned __int8 v10; // bp
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v12; // rax
  volatile signed __int32 *v13; // rbx
  volatile signed __int32 *v14; // rbx
  boost::shared_ptr<RBX::Player>::element_type *v15; // [rsp+8h] [rbp-50h] BYREF
  volatile signed __int32 *v16; // [rsp+10h] [rbp-48h]
  boost::shared_ptr<RBX::Player>::element_type *px; // [rsp+18h] [rbp-40h] BYREF
  volatile signed __int32 *v18; // [rsp+20h] [rbp-38h]
  _BYTE v19[16]; // [rsp+28h] [rbp-30h] BYREF
  void *ptr; // [rsp+38h] [rbp-20h]

  f = this->f_;
  v9 = (int (***)(void))((char *)&u->px->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf5<void,RBX::ChatService,bool,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,const RBX::SystemAddress &>::F *)((char *)f + *v9 - 1);
  v10 = *b1;
  px = b2->px;
  pi = b2->pn.pi_;
  v18 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v15 = b3->px;
  v12 = b3->pn.pi_;
  v16 = (volatile signed __int32 *)v12;
  if ( v12 )
    _InterlockedAdd(&v12->use_count_, 1u);
  std::string::basic_string(v19, b4);
  ((void (__fastcall *)(_QWORD *, _QWORD, boost::shared_ptr<RBX::Player>::element_type **, boost::shared_ptr<RBX::Player>::element_type **, _BYTE *, const RBX::SystemAddress *))f)(
    v9,
    v10,
    &px,
    &v15,
    v19,
    b5);
  if ( (v19[0] & 1) != 0 )
    operator delete(ptr);
  v13 = v16;
  if ( v16 )
  {
    if ( !_InterlockedSub(v16 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  v14 = v18;
  if ( v18 && !_InterlockedSub(v18 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
    if ( !_InterlockedSub(v14 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
  }
}


// Address: 0x14e91d0 | Name: _ZNK5boost4_mfi3mf5IvN3RBX11ChatServiceERKNS2_16TextFilterResultENS_10shared_ptrINS2_6PlayerEEES9_NSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEERKNS2_13SystemAddressEE4callINS7_IS3_EES5_S9_S9_SG_SI_EEvRT_PKvRT0_RT1_RT2_RT3_RT4_
void __fastcall boost::_mfi::mf5<void,RBX::ChatService,RBX::TextFilterResult const&,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,RBX::SystemAddress const&>::call<boost::shared_ptr<RBX::ChatService>,RBX::TextFilterResult const,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,RBX::SystemAddress const>(
        const boost::_mfi::mf5<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,const RBX::SystemAddress &> *this,
        boost::shared_ptr<RBX::ChatService> *u,
        const void *a3,
        const RBX::TextFilterResult *b1,
        boost::shared_ptr<RBX::Player> *b2,
        boost::shared_ptr<RBX::Player> *b3,
        std::string *b4,
        const RBX::SystemAddress *b5)
{
  boost::_mfi::mf5<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,const RBX::SystemAddress &>::F f; // r15
  _QWORD *v10; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v12; // rax
  volatile signed __int32 *v13; // rbx
  volatile signed __int32 *v14; // rbx
  boost::shared_ptr<RBX::Player>::element_type *v15; // [rsp+8h] [rbp-50h] BYREF
  volatile signed __int32 *v16; // [rsp+10h] [rbp-48h]
  boost::shared_ptr<RBX::Player>::element_type *px; // [rsp+18h] [rbp-40h] BYREF
  volatile signed __int32 *v18; // [rsp+20h] [rbp-38h]
  _BYTE v19[16]; // [rsp+28h] [rbp-30h] BYREF
  void *ptr; // [rsp+38h] [rbp-20h]

  f = this->f_;
  v10 = (int (***)(void))((char *)&u->px->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf5<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,const RBX::SystemAddress &>::F *)((char *)f + *v10 - 1);
  px = b2->px;
  pi = b2->pn.pi_;
  v18 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v15 = b3->px;
  v12 = b3->pn.pi_;
  v16 = (volatile signed __int32 *)v12;
  if ( v12 )
    _InterlockedAdd(&v12->use_count_, 1u);
  std::string::basic_string(v19, b4);
  ((void (__fastcall *)(_QWORD *, const RBX::TextFilterResult *, boost::shared_ptr<RBX::Player>::element_type **, boost::shared_ptr<RBX::Player>::element_type **, _BYTE *, const RBX::SystemAddress *))f)(
    v10,
    b1,
    &px,
    &v15,
    v19,
    b5);
  if ( (v19[0] & 1) != 0 )
    operator delete(ptr);
  v13 = v16;
  if ( v16 )
  {
    if ( !_InterlockedSub(v16 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  v14 = v18;
  if ( v18 && !_InterlockedSub(v18 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
    if ( !_InterlockedSub(v14 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
  }
}


// Address: 0x14eac90 | Name: _ZNK5boost4_mfi3mf4IvN3RBX11ChatServiceEbNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvRKNS2_16TextFilterResultEEEENS_10shared_ptrINS2_6PlayerEEEE4callINSH_IS3_EEbSA_SG_SJ_EEvRT_PKvRT0_RT1_RT2_RT3_
void __fastcall boost::_mfi::mf4<void,RBX::ChatService,bool,std::string,boost::function<void ()(RBX::TextFilterResult const&)>,boost::shared_ptr<RBX::Player>>::call<boost::shared_ptr<RBX::ChatService>,bool,std::string,boost::function<void ()(RBX::TextFilterResult const&)>,boost::shared_ptr<RBX::Player>>(
        const boost::_mfi::mf4<void,RBX::ChatService,bool,std::string,boost::function<void (const RBX::TextFilterResult &)>,boost::shared_ptr<RBX::Player> > *this,
        boost::shared_ptr<RBX::ChatService> *u,
        const void *a3,
        bool *b1,
        std::string *b2,
        boost::function<void (const RBX::TextFilterResult &)> *b3,
        boost::shared_ptr<RBX::Player> *b4)
{
  boost::_mfi::mf4<void,RBX::ChatService,bool,std::string,boost::function<void (const RBX::TextFilterResult &)>,boost::shared_ptr<RBX::Player> >::F f; // r15
  _QWORD *v9; // rbx
  unsigned __int8 v10; // bp
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::sp_counted_base *pi; // rax
  volatile signed __int32 *v13; // rbx
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  boost::detail::function::vtable_base *v15; // [rsp+0h] [rbp-68h] BYREF
  __int128 v16; // [rsp+8h] [rbp-60h] BYREF
  void *obj_ptr; // [rsp+18h] [rbp-50h]
  boost::shared_ptr<RBX::Player>::element_type *px; // [rsp+20h] [rbp-48h] BYREF
  volatile signed __int32 *v19; // [rsp+28h] [rbp-40h]
  _BYTE v20[16]; // [rsp+30h] [rbp-38h] BYREF
  void *ptr; // [rsp+40h] [rbp-28h]

  f = this->f_;
  v9 = (int (***)(void))((char *)&u->px->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf4<void,RBX::ChatService,bool,std::string,boost::function<void (const RBX::TextFilterResult &)>,boost::shared_ptr<RBX::Player> >::F *)((char *)f + *v9 - 1);
  v10 = *b1;
  std::string::basic_string(v20, b2);
  v15 = 0;
  vtable = b3->vtable;
  if ( b3->vtable )
  {
    v15 = b3->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      obj_ptr = b3->functor.bound_memfunc_ptr.obj_ptr;
      v16 = *(_OWORD *)&b3->functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)vtable
                                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &b3->functor,
        &v16,
        0);
    }
  }
  px = b4->px;
  pi = b4->pn.pi_;
  v19 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  ((void (__fastcall *)(_QWORD *, _QWORD, _BYTE *, boost::detail::function::vtable_base **, boost::shared_ptr<RBX::Player>::element_type **))f)(
    v9,
    v10,
    v20,
    &v15,
    &px);
  v13 = v19;
  if ( v19 )
  {
    if ( !_InterlockedSub(v19 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  if ( v15 )
  {
    if ( ((unsigned __int8)v15 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v15 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v16, &v16, 2);
    }
    v15 = 0;
  }
  if ( (v20[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x14ec7d0 | Name: _ZNK5boost4_mfi3mf5IvN3RBX11ChatServiceERKNS2_16TextFilterResultENS_10shared_ptrINS2_6PlayerEEES9_NS_8functionIFvNSt3__112basic_stringIcNSB_11char_traitsIcEENSB_9allocatorIcEEEEEEESJ_E4callINS7_IS3_EES5_S9_S9_SJ_SJ_EEvRT_PKvRT0_RT1_RT2_RT3_RT4_
void __fastcall boost::_mfi::mf5<void,RBX::ChatService,RBX::TextFilterResult const&,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::ChatService>,RBX::TextFilterResult const,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf5<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::ChatService> *u,
        const void *a3,
        const RBX::TextFilterResult *b1,
        boost::shared_ptr<RBX::Player> *b2,
        boost::shared_ptr<RBX::Player> *b3,
        boost::function<void (std::string)>_0 *b4,
        boost::function<void (std::string)>_0 *b5)
{
  boost::_mfi::mf5<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> >::F f; // r15
  _QWORD *v10; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v12; // rax
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v14; // rax
  void (__fastcall *v15)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v16)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  volatile signed __int32 *v17; // rbx
  volatile signed __int32 *v18; // rbx
  boost::detail::function::vtable_base *v19; // [rsp+0h] [rbp-78h] BYREF
  boost::detail::function::function_buffer v20; // [rsp+8h] [rbp-70h] BYREF
  boost::detail::function::vtable_base *v21; // [rsp+20h] [rbp-58h] BYREF
  boost::detail::function::function_buffer functor; // [rsp+28h] [rbp-50h] BYREF
  boost::shared_ptr<RBX::Player>::element_type *v23; // [rsp+40h] [rbp-38h] BYREF
  volatile signed __int32 *v24; // [rsp+48h] [rbp-30h]
  boost::shared_ptr<RBX::Player>::element_type *px; // [rsp+50h] [rbp-28h] BYREF
  volatile signed __int32 *v26; // [rsp+58h] [rbp-20h]

  f = this->f_;
  v10 = (int (***)(void))((char *)&u->px->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf5<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> >::F *)((char *)f + *v10 - 1);
  px = b2->px;
  pi = b2->pn.pi_;
  v26 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v23 = b3->px;
  v12 = b3->pn.pi_;
  v24 = (volatile signed __int32 *)v12;
  if ( v12 )
    _InterlockedAdd(&v12->use_count_, 1u);
  v21 = 0;
  vtable = b4->vtable;
  if ( b4->vtable )
  {
    v21 = b4->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      functor = b4->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b4->functor,
        &functor,
        0);
  }
  v19 = 0;
  v14 = b5->vtable;
  if ( b5->vtable )
  {
    v19 = b5->vtable;
    if ( ((unsigned __int8)v14 & 1) != 0 )
      v20 = b5->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v14 & 0xFFFFFFFFFFFFFFFELL))(
        &b5->functor,
        &v20,
        0);
  }
  ((void (__fastcall *)(_QWORD *, const RBX::TextFilterResult *, boost::shared_ptr<RBX::Player>::element_type **, boost::shared_ptr<RBX::Player>::element_type **, boost::detail::function::vtable_base **, boost::detail::function::vtable_base **))f)(
    v10,
    b1,
    &px,
    &v23,
    &v21,
    &v19);
  if ( v19 )
  {
    if ( ((unsigned __int8)v19 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v19 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v20, &v20, 2);
    }
    v19 = 0;
  }
  if ( v21 )
  {
    if ( ((unsigned __int8)v21 & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v21 & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&functor, &functor, 2);
    }
    v21 = 0;
  }
  v17 = v24;
  if ( v24 )
  {
    if ( !_InterlockedSub(v24 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 16LL))(v17);
      if ( !_InterlockedSub(v17 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
    }
  }
  v18 = v26;
  if ( v26 && !_InterlockedSub(v26 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 16LL))(v18);
    if ( !_InterlockedSub(v18 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 24LL))(v18);
  }
}


// Address: 0x14eeef0 | Name: _ZNK5boost4_mfi3mf6IvN3RBX11ChatServiceERKNS2_16TextFilterResultERKNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEENS_10shared_ptrINS2_6PlayerEEESI_NS_8functionIFvSD_EEESL_E4callINSG_IS3_EES5_SE_SI_SI_SL_SL_EEvRT_PKvRT0_RT1_RT2_RT3_RT4_RT5_
void __fastcall boost::_mfi::mf6<void,RBX::ChatService,RBX::TextFilterResult const&,std::string const&,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::ChatService>,RBX::TextFilterResult const,std::string const,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf6<void,RBX::ChatService,const RBX::TextFilterResult &,const std::string &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::ChatService> *u,
        const void *a3,
        const RBX::TextFilterResult *b1,
        const std::string *b2,
        boost::shared_ptr<RBX::Player> *b3,
        boost::shared_ptr<RBX::Player> *b4,
        boost::function<void (std::string)>_0 *b5,
        boost::function<void (std::string)>_0 *b6)
{
  boost::_mfi::mf6<void,RBX::ChatService,const RBX::TextFilterResult &,const std::string &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> >::F f; // r12
  _QWORD *v12; // rbx
  boost::detail::sp_counted_base *pi; // rcx
  boost::detail::sp_counted_base *v14; // rax
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v16; // rax
  void (__fastcall *v17)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v18)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  volatile signed __int32 *v19; // rbx
  volatile signed __int32 *v20; // rbx
  boost::detail::function::vtable_base *v21; // [rsp+8h] [rbp-80h] BYREF
  boost::detail::function::function_buffer v22; // [rsp+10h] [rbp-78h] BYREF
  boost::detail::function::vtable_base *v23; // [rsp+28h] [rbp-60h] BYREF
  boost::detail::function::function_buffer functor; // [rsp+30h] [rbp-58h] BYREF
  boost::shared_ptr<RBX::Player>::element_type *v25; // [rsp+48h] [rbp-40h] BYREF
  volatile signed __int32 *v26; // [rsp+50h] [rbp-38h]
  boost::shared_ptr<RBX::Player>::element_type *px; // [rsp+58h] [rbp-30h] BYREF
  volatile signed __int32 *v28; // [rsp+60h] [rbp-28h]

  f = this->f_;
  v12 = (int (***)(void))((char *)&u->px->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf6<void,RBX::ChatService,const RBX::TextFilterResult &,const std::string &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> >::F *)((char *)f + *v12 - 1);
  px = b3->px;
  pi = b3->pn.pi_;
  v28 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v25 = b4->px;
  v14 = b4->pn.pi_;
  v26 = (volatile signed __int32 *)v14;
  if ( v14 )
    _InterlockedAdd(&v14->use_count_, 1u);
  v23 = 0;
  vtable = b5->vtable;
  if ( b5->vtable )
  {
    v23 = b5->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      functor = b5->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b5->functor,
        &functor,
        0);
  }
  v21 = 0;
  v16 = b6->vtable;
  if ( b6->vtable )
  {
    v21 = b6->vtable;
    if ( ((unsigned __int8)v16 & 1) != 0 )
      v22 = b6->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v16 & 0xFFFFFFFFFFFFFFFELL))(
        &b6->functor,
        &v22,
        0);
  }
  ((void (__fastcall *)(_QWORD *, const RBX::TextFilterResult *, const std::string *, boost::shared_ptr<RBX::Player>::element_type **, boost::shared_ptr<RBX::Player>::element_type **, boost::detail::function::vtable_base **, boost::detail::function::vtable_base **))f)(
    v12,
    b1,
    b2,
    &px,
    &v25,
    &v23,
    &v21);
  if ( v21 )
  {
    if ( ((unsigned __int8)v21 & 1) == 0 )
    {
      v17 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v21 & 0xFFFFFFFFFFFFFFFELL);
      if ( v17 )
        v17(&v22, &v22, 2);
    }
    v21 = 0;
  }
  if ( v23 )
  {
    if ( ((unsigned __int8)v23 & 1) == 0 )
    {
      v18 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v23 & 0xFFFFFFFFFFFFFFFELL);
      if ( v18 )
        v18(&functor, &functor, 2);
    }
    v23 = 0;
  }
  v19 = v26;
  if ( v26 )
  {
    if ( !_InterlockedSub(v26 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 16LL))(v19);
      if ( !_InterlockedSub(v19 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 24LL))(v19);
    }
  }
  v20 = v28;
  if ( v28 && !_InterlockedSub(v28 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 16LL))(v20);
    if ( !_InterlockedSub(v20 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 24LL))(v20);
  }
}


// Address: 0x14f0bd0 | Name: _ZNK5boost4_mfi3mf4IvN3RBX11ChatServiceERKNS2_16TextFilterResultENS_10shared_ptrINS2_6PlayerEEENS_8functionIFvNSt3__112basic_stringIcNSB_11char_traitsIcEENSB_9allocatorIcEEEEEEESJ_E4callINS7_IS3_EES5_S9_SJ_SJ_EEvRT_PKvRT0_RT1_RT2_RT3_
void __fastcall boost::_mfi::mf4<void,RBX::ChatService,RBX::TextFilterResult const&,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::ChatService>,RBX::TextFilterResult const,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf4<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::ChatService> *u,
        const void *a3,
        const RBX::TextFilterResult *b1,
        boost::shared_ptr<RBX::Player> *b2,
        boost::function<void (std::string)>_0 *b3,
        boost::function<void (std::string)>_0 *b4)
{
  boost::_mfi::mf4<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> >::F f; // r15
  _QWORD *v9; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v12; // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v14)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  volatile signed __int32 *v15; // rbx
  boost::detail::function::vtable_base *v16; // [rsp+0h] [rbp-68h] BYREF
  boost::detail::function::function_buffer v17; // [rsp+8h] [rbp-60h] BYREF
  boost::detail::function::vtable_base *v18; // [rsp+20h] [rbp-48h] BYREF
  boost::detail::function::function_buffer functor; // [rsp+28h] [rbp-40h] BYREF
  boost::shared_ptr<RBX::Player>::element_type *px; // [rsp+40h] [rbp-28h] BYREF
  volatile signed __int32 *v21; // [rsp+48h] [rbp-20h]

  f = this->f_;
  v9 = (int (***)(void))((char *)&u->px->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf4<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> >::F *)((char *)f + *v9 - 1);
  px = b2->px;
  pi = b2->pn.pi_;
  v21 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v18 = 0;
  vtable = b3->vtable;
  if ( b3->vtable )
  {
    v18 = b3->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      functor = b3->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b3->functor,
        &functor,
        0);
  }
  v16 = 0;
  v12 = b4->vtable;
  if ( b4->vtable )
  {
    v16 = b4->vtable;
    if ( ((unsigned __int8)v12 & 1) != 0 )
      v17 = b4->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v12 & 0xFFFFFFFFFFFFFFFELL))(
        &b4->functor,
        &v17,
        0);
  }
  ((void (__fastcall *)(_QWORD *, const RBX::TextFilterResult *, boost::shared_ptr<RBX::Player>::element_type **, boost::detail::function::vtable_base **, boost::detail::function::vtable_base **))f)(
    v9,
    b1,
    &px,
    &v18,
    &v16);
  if ( v16 )
  {
    if ( ((unsigned __int8)v16 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( v18 )
  {
    if ( ((unsigned __int8)v18 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v18 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&functor, &functor, 2);
    }
    v18 = 0;
  }
  v15 = v21;
  if ( v21 && !_InterlockedSub(v21 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
    if ( !_InterlockedSub(v15 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
  }
}


// Address: 0x14f1690 | Name: _ZNK5boost4_mfi3mf6IvN3RBX11ChatServiceENS_10shared_ptrINS2_8InstanceEEENSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEEbSD_SD_SD_E4callINS4_IS3_EES6_SD_bSD_SD_SD_EEvRT_PKvRT0_RT1_RT2_RT3_RT4_RT5_
void __fastcall boost::_mfi::mf6<void,RBX::ChatService,boost::shared_ptr<RBX::Instance>,std::string,bool,std::string,std::string,std::string>::call<boost::shared_ptr<RBX::ChatService>,boost::shared_ptr<RBX::Instance>,std::string,bool,std::string,std::string,std::string>(
        const boost::_mfi::mf6<void,RBX::ChatService,boost::shared_ptr<RBX::Instance>,std::string,bool,std::string,std::string,std::string > *this,
        boost::shared_ptr<RBX::ChatService> *u,
        const void *a3,
        boost::shared_ptr<RBX::Instance> *b1,
        std::string *b2,
        bool *b3,
        std::string *b4,
        std::string *b5,
        std::string *b6)
{
  boost::_mfi::mf6<void,RBX::ChatService,boost::shared_ptr<RBX::Instance>,std::string,bool,std::string,std::string,std::string >::F f; // r15
  _QWORD *v11; // rbx
  boost::detail::sp_counted_base *pi; // rax
  unsigned __int8 v13; // bp
  volatile signed __int32 *v14; // rbx
  boost::shared_ptr<RBX::Instance>::element_type *px; // [rsp+8h] [rbp-90h] BYREF
  volatile signed __int32 *v16; // [rsp+10h] [rbp-88h]
  _BYTE v17[16]; // [rsp+18h] [rbp-80h] BYREF
  void *v18; // [rsp+28h] [rbp-70h]
  _BYTE v19[16]; // [rsp+30h] [rbp-68h] BYREF
  void *v20; // [rsp+40h] [rbp-58h]
  _BYTE v21[16]; // [rsp+48h] [rbp-50h] BYREF
  void *ptr; // [rsp+58h] [rbp-40h]
  _BYTE v23[16]; // [rsp+60h] [rbp-38h] BYREF
  void *v24; // [rsp+70h] [rbp-28h]

  f = this->f_;
  v11 = (int (***)(void))((char *)&u->px->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf6<void,RBX::ChatService,boost::shared_ptr<RBX::Instance>,std::string,bool,std::string,std::string,std::string >::F *)((char *)f + *v11 - 1);
  px = b1->px;
  pi = b1->pn.pi_;
  v16 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  std::string::basic_string(v21, b2);
  v13 = *b3;
  std::string::basic_string(v19, b4);
  std::string::basic_string(v17, b5);
  std::string::basic_string(v23, b6);
  ((void (__fastcall *)(_QWORD *, boost::shared_ptr<RBX::Instance>::element_type **, _BYTE *, _QWORD, _BYTE *, _BYTE *, _BYTE *))f)(
    v11,
    &px,
    v21,
    v13,
    v19,
    v17,
    v23);
  if ( (v23[0] & 1) != 0 )
  {
    operator delete(v24);
    if ( (v17[0] & 1) == 0 )
    {
LABEL_7:
      if ( (v19[0] & 1) == 0 )
        goto LABEL_8;
LABEL_17:
      operator delete(v20);
      if ( (v21[0] & 1) == 0 )
        goto LABEL_10;
      goto LABEL_9;
    }
  }
  else if ( (v17[0] & 1) == 0 )
  {
    goto LABEL_7;
  }
  operator delete(v18);
  if ( (v19[0] & 1) != 0 )
    goto LABEL_17;
LABEL_8:
  if ( (v21[0] & 1) != 0 )
LABEL_9:
    operator delete(ptr);
LABEL_10:
  v14 = v16;
  if ( v16 && !_InterlockedSub(v16 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
    if ( !_InterlockedSub(v14 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
  }
}


// Address: 0x159da10 | Name: _ZNK5boost4_mfi3mf1IvN3RBX9DataModelENS_10shared_ptrINS2_6CEventEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::DataModel,boost::shared_ptr<RBX::CEvent>>::operator()(
        const boost::_mfi::mf1<void,RBX::DataModel,boost::shared_ptr<RBX::CEvent> > *this,
        RBX::DataModel *p,
        boost::shared_ptr<RBX::CEvent> a1)
{
  boost::_mfi::mf1<void,RBX::DataModel,boost::shared_ptr<RBX::CEvent> >::F f; // rcx
  _QWORD *v4; // rsi
  __int64 align; // rax
  volatile signed __int32 *v6; // rbx
  __int64 v7; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::DataModel,boost::shared_ptr<RBX::CEvent> >::F *)((char *)f + *v4 - 1);
  v7 = *(_QWORD *)&a1.px->manualReset;
  align = a1.px->cond.internal_mutex.__align;
  v8 = (volatile signed __int32 *)align;
  if ( align )
    _InterlockedAdd((volatile signed __int32 *)(align + 8), 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x159e400 | Name: _ZNK5boost4_mfi3mf2IvN3RBX9DataModelENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_10shared_ptrINS2_6CEventEEEEclEPS3_SA_SD_
void __fastcall boost::_mfi::mf2<void,RBX::DataModel,std::string,boost::shared_ptr<RBX::CEvent>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4)
{
  char *v5; // r15
  char *v6; // rbx
  volatile signed __int32 *v7; // rax
  volatile signed __int32 *v8; // rbx
  __int64 v9; // [rsp+8h] [rbp-40h] BYREF
  volatile signed __int32 *v10; // [rsp+10h] [rbp-38h]
  _BYTE v11[16]; // [rsp+18h] [rbp-30h] BYREF
  void *ptr; // [rsp+28h] [rbp-20h]

  v5 = *a1;
  v6 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v5 = *(char **)&v5[*(_QWORD *)v6 - 1];
  std::string::basic_string(v11, a3);
  v9 = *a4;
  v7 = (volatile signed __int32 *)a4[1];
  v10 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  ((void (__fastcall *)(char *, _BYTE *, __int64 *))v5)(v6, v11, &v9);
  v8 = v10;
  if ( v10 )
  {
    if ( !_InterlockedSub(v10 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  if ( (v11[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x15a9250 | Name: _ZNK5boost4_mfi3mf3IvN3RBX9DataModelENS_8functionIFvbEEEPNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEEPSt9exceptionEclEPS3_S6_SE_SG_
void __fastcall boost::_mfi::mf3<void,RBX::DataModel,boost::function<void ()(bool)>,std::string *,std::exception *>::operator()(
        const boost::_mfi::mf3<void,RBX::DataModel,boost::function<void (bool)>,std::string *,std::exception *> *this,
        RBX::DataModel *p,
        std::string *a2,
        std::exception *a3,
        __int64 a5)
{
  boost::_mfi::mf3<void,RBX::DataModel,boost::function<void (bool)>,std::string *,std::exception *>::F f; // r12
  _QWORD *v8; // rbx
  __int64 v9; // rcx
  void (__fastcall *v10)(__int128 *, __int128 *, __int64); // rax
  __int64 v11; // [rsp+8h] [rbp-40h] BYREF
  __int128 v12; // [rsp+10h] [rbp-38h] BYREF
  __int64 v13; // [rsp+20h] [rbp-28h]

  f = this->f_;
  v8 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::DataModel,boost::function<void (bool)>,std::string *,std::exception *>::F *)((char *)f + *v8 - 1);
  v11 = 0;
  v9 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v11 = *(_QWORD *)a2;
    if ( (v9 & 1) != 0 )
    {
      v13 = *((_QWORD *)a2 + 3);
      v12 = *(_OWORD *)((char *)a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(char *, __int128 *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))((char *)a2 + 8, &v12, 0);
    }
  }
  ((void (__fastcall *)(_QWORD *, __int64 *, std::exception *, __int64))f)(v8, &v11, a3, a5);
  if ( v11 && (v11 & 1) == 0 )
  {
    v10 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v11 & 0xFFFFFFFFFFFFFFFELL);
    if ( v10 )
      v10(&v12, &v12, 2);
  }
}


// Address: 0x1647070 | Name: _ZNK5boost4_mfi3mf4IvN3RBX13FriendServiceEiNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvNS_10shared_ptrIKNS4_6vectorINS2_10Reflection7VariantENS8_ISF_EEEEEEEEENSB_IFvSA_EEEEclEPS3_iSA_SL_SN_
void __fastcall boost::_mfi::mf4<void,RBX::FriendService,int,std::string,boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        unsigned int a3,
        __int64 a4,
        __int64 *a5,
        __int64 *a6)
{
  char *v9; // r12
  char *v10; // rbx
  __int64 v11; // rax
  __int64 v12; // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  __int64 v15; // [rsp+8h] [rbp-80h] BYREF
  __int128 v16; // [rsp+10h] [rbp-78h] BYREF
  __int64 v17; // [rsp+20h] [rbp-68h]
  __int64 v18; // [rsp+28h] [rbp-60h] BYREF
  __int128 v19; // [rsp+30h] [rbp-58h] BYREF
  __int64 v20; // [rsp+40h] [rbp-48h]
  _BYTE v21[16]; // [rsp+48h] [rbp-40h] BYREF
  void *ptr; // [rsp+58h] [rbp-30h]

  v9 = *a1;
  v10 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v9 = *(char **)&v9[*(_QWORD *)v10 - 1];
  std::string::basic_string(v21, a4);
  v18 = 0;
  v11 = *a5;
  if ( *a5 )
  {
    v18 = *a5;
    if ( (v11 & 1) != 0 )
    {
      v20 = a5[3];
      v19 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v19, 0);
    }
  }
  v15 = 0;
  v12 = *a6;
  if ( *a6 )
  {
    v15 = *a6;
    if ( (v12 & 1) != 0 )
    {
      v17 = a6[3];
      v16 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v16, 0);
    }
  }
  ((void (__fastcall *)(char *, _QWORD, _BYTE *, __int64 *, __int64 *))v9)(v10, a3, v21, &v18, &v15);
  if ( v15 )
  {
    if ( (v15 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v15 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v16, &v16, 2);
    }
    v15 = 0;
  }
  if ( v18 )
  {
    if ( (v18 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v18 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v19, &v19, 2);
    }
    v18 = 0;
  }
  if ( (v21[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x1647840 | Name: _ZNK5boost4_mfi3mf2IvN3RBX13FriendServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvSA_EEEEclEPS3_SA_SD_
void __fastcall boost::_mfi::mf2<void,RBX::FriendService,std::string,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4)
{
  char *v5; // r15
  char *v6; // rbx
  __int64 v7; // rax
  void (__fastcall *v8)(__int128 *, __int128 *, __int64); // rax
  __int64 v9; // [rsp+8h] [rbp-50h] BYREF
  __int128 v10; // [rsp+10h] [rbp-48h] BYREF
  __int64 v11; // [rsp+20h] [rbp-38h]
  _BYTE v12[16]; // [rsp+28h] [rbp-30h] BYREF
  void *ptr; // [rsp+38h] [rbp-20h]

  v5 = *a1;
  v6 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v5 = *(char **)&v5[*(_QWORD *)v6 - 1];
  std::string::basic_string(v12, a3);
  v9 = 0;
  v7 = *a4;
  if ( *a4 )
  {
    v9 = *a4;
    if ( (v7 & 1) != 0 )
    {
      v11 = a4[3];
      v10 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v10, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *))v5)(v6, v12, &v9);
  if ( v9 )
  {
    if ( (v9 & 1) == 0 )
    {
      v8 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v9 & 0xFFFFFFFFFFFFFFFELL);
      if ( v8 )
        v8(&v10, &v10, 2);
    }
    v9 = 0;
  }
  if ( (v12[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x1648670 | Name: _ZNK5boost4_mfi3mf3IvN3RBX13FriendServiceElNS_10shared_ptrIKNSt3__16vectorINS2_10Reflection7VariantENS5_9allocatorIS8_EEEEEENS_8functionIFvbEEEEclEPS3_lSD_SG_
void __fastcall boost::_mfi::mf3<void,RBX::FriendService,long,boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>,boost::function<void ()(bool)>>::operator()(
        const boost::_mfi::mf3<void,RBX::FriendService,long,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >,boost::function<void (bool)> > *this,
        RBX::FriendService *p,
        __int64 a1,
        boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > a2)
{
  boost::_mfi::mf3<void,RBX::FriendService,long,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >,boost::function<void (bool)> >::F f; // r15
  _QWORD *v6; // rbx
  volatile signed __int32 *v7; // rax
  int (**v8)(void); // rax
  void (__fastcall *v9)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v10; // rbx
  int (**v11)(void); // [rsp+0h] [rbp-48h] BYREF
  __int128 v12; // [rsp+8h] [rbp-40h] BYREF
  __int64 v13; // [rsp+18h] [rbp-30h]
  __int64 v14; // [rsp+20h] [rbp-28h] BYREF
  volatile signed __int32 *v15; // [rsp+28h] [rbp-20h]

  f = this->f_;
  v6 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::FriendService,long,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >,boost::function<void (bool)> >::F *)((char *)f + *v6 - 1);
  v14 = *(_QWORD *)a2.px;
  v7 = (volatile signed __int32 *)*((_QWORD *)a2.px + 1);
  v15 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  v11 = 0;
  v8 = a2.pn.pi_->_vptr$sp_counted_base;
  if ( a2.pn.pi_->_vptr$sp_counted_base )
  {
    v11 = a2.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v8 & 1) != 0 )
    {
      v13 = *(_QWORD *)&a2.pn.pi_[1].use_count_;
      v12 = *(_OWORD *)&a2.pn.pi_->use_count_;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, __int128 *, _QWORD))((unsigned __int64)v8
                                                                                        & 0xFFFFFFFFFFFFFFFELL))(
        &a2.pn.pi_->use_count_,
        &v12,
        0);
    }
  }
  ((void (__fastcall *)(_QWORD *, __int64, __int64 *, int (***)(void)))f)(v6, a1, &v14, &v11);
  if ( v11 )
  {
    if ( ((unsigned __int8)v11 & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v11 & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v12, &v12, 2);
    }
    v11 = 0;
  }
  v10 = v15;
  if ( v15 && !_InterlockedSub(v15 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
    if ( !_InterlockedSub(v10 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
  }
}


// Address: 0x164a380 | Name: _ZNK5boost4_mfi3mf3IvN3RBX13FriendServiceENS_9unordered13unordered_setIlNS_4hashIlEENSt3__18equal_toIlEENS8_9allocatorIlEEEENS_10shared_ptrIKNS8_6vectorINS2_10Reflection7VariantENSB_ISH_EEEEEENS_8functionIFvNSE_INS4_13unordered_mapIlNS2_26FriendService_FriendStatusES7_SA_NSB_INS8_4pairIKlSO_EEEEEEEEEEEEclEPS3_SD_SL_SW_
void __fastcall boost::_mfi::mf3<void,RBX::FriendService,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>,boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>>::operator()(
        const boost::_mfi::mf3<void,RBX::FriendService,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >,boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *this,
        RBX::FriendService *p,
        boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > a2,
        __int64 *a4)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::_mfi::mf3<void,RBX::FriendService,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >,boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> >::F f; // r12
  _QWORD *v7; // r15
  volatile signed __int32 *v8; // rax
  __int64 v9; // rax
  void (__fastcall *v10)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v11; // rbx
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r14
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer next; // rdi
  __int64 v15; // [rsp+8h] [rbp-80h] BYREF
  __int128 v16; // [rsp+10h] [rbp-78h] BYREF
  __int64 v17; // [rsp+20h] [rbp-68h]
  int (**v18)(void); // [rsp+28h] [rbp-60h] BYREF
  volatile signed __int32 *v19; // [rsp+30h] [rbp-58h]
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > v20; // [rsp+38h] [rbp-50h] BYREF

  pi = a2.pn.pi_;
  f = this->f_;
  v7 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::FriendService,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >,boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> >::F *)((char *)f + *v7 - 1);
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::table_impl(
    &v20,
    (const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *)a2.px);
  v18 = pi->_vptr$sp_counted_base;
  v8 = *(volatile signed __int32 **)&pi->use_count_;
  v19 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  v15 = 0;
  v9 = *a4;
  if ( *a4 )
  {
    v15 = *a4;
    if ( (v9 & 1) != 0 )
    {
      v17 = a4[3];
      v16 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v16, 0);
    }
  }
  ((void (__fastcall *)(_QWORD *, boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *, int (***)(void), __int64 *))f)(
    v7,
    &v20,
    &v18,
    &v15);
  if ( v15 )
  {
    if ( (v15 & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v15 & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v16, &v16, 2);
    }
    v15 = 0;
  }
  v11 = v19;
  if ( v19 )
  {
    if ( !_InterlockedSub(v19 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
  buckets = v20.buckets_;
  if ( v20.buckets_ )
  {
    if ( v20.size_ )
    {
      bucket_count = v20.bucket_count_;
      next = v20.buckets_[v20.bucket_count_].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --v20.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = v20.buckets_;
    }
    operator delete(buckets);
  }
}


// Address: 0x164b3b0 | Name: _ZNK5boost4_mfi3mf3IvN3RBX13FriendServiceElNS_9unordered13unordered_setIlNS_4hashIlEENSt3__18equal_toIlEENS8_9allocatorIlEEEENS8_12basic_stringIcNS8_11char_traitsIcEENSB_IcEEEEEclEPS3_lSD_SI_
void __fastcall boost::_mfi::mf3<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>,std::string>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *a4,
        __int64 a5)
{
  char *v7; // r12
  char *v8; // rbx
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r14
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer next; // rdi
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > v12; // [rsp+0h] [rbp-68h] BYREF
  _BYTE v13[16]; // [rsp+30h] [rbp-38h] BYREF
  void *ptr; // [rsp+40h] [rbp-28h]

  v7 = *a1;
  v8 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v7 = *(char **)&v7[*(_QWORD *)v8 - 1];
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::table_impl(
    &v12,
    a4);
  std::string::basic_string(v13, a5);
  ((void (__fastcall *)(char *, __int64, boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *, _BYTE *))v7)(
    v8,
    a3,
    &v12,
    v13);
  if ( (v13[0] & 1) != 0 )
    operator delete(ptr);
  buckets = v12.buckets_;
  if ( v12.buckets_ )
  {
    if ( v12.size_ )
    {
      bucket_count = v12.bucket_count_;
      next = v12.buckets_[v12.bucket_count_].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --v12.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = v12.buckets_;
    }
    operator delete(buckets);
  }
}


// Address: 0x164b790 | Name: _ZNK5boost4_mfi3mf2IvN3RBX13FriendServiceElNS_10shared_ptrINS_9unordered13unordered_mapIlNS2_26FriendService_FriendStatusENS_4hashIlEENSt3__18equal_toIlEENSA_9allocatorINSA_4pairIKlS7_EEEEEEEEEclEPS3_lSJ_
void __fastcall boost::_mfi::mf2<void,RBX::FriendService,long,boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>>::operator()(
        const boost::_mfi::mf2<void,RBX::FriendService,long,boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > > > *this,
        RBX::FriendService *p,
        __int64 a1,
        boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > > a2)
{
  boost::_mfi::mf2<void,RBX::FriendService,long,boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > > >::F f; // rbx
  _QWORD *v5; // rsi
  size_t bucket_count; // rax
  volatile signed __int32 *v7; // rbx
  __int64 v8; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::FriendService,long,boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > > >::F *)((char *)f + *v5 - 1);
  v8 = *(_QWORD *)&a2.px->table_.current_;
  bucket_count = a2.px->table_.bucket_count_;
  v9 = (volatile signed __int32 *)bucket_count;
  if ( bucket_count )
    _InterlockedAdd((volatile signed __int32 *)(bucket_count + 8), 1u);
  ((void (__fastcall *)(_QWORD *, __int64, __int64 *, boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >::element_type *, boost::detail::sp_counted_base *))f)(
    v5,
    a1,
    &v8,
    a2.px,
    a2.pn.pi_);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x164c4f0 | Name: _ZNK5boost4_mfi3mf4IvN3RBX13FriendServiceElNS_9unordered13unordered_setIlNS_4hashIlEENSt3__18equal_toIlEENS8_9allocatorIlEEEENS_8functionIFvNS_10shared_ptrINS4_13unordered_mapIlNS2_26FriendService_FriendStatusES7_SA_NSB_INS8_4pairIKlSH_EEEEEEEEEEENSE_IFvNS8_12basic_stringIcNS8_11char_traitsIcEENSB_IcEEEEEEEEclEPS3_lSD_SP_SW_
void __fastcall boost::_mfi::mf4<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>,boost::function<void ()(std::string)>>::operator()(
        const boost::_mfi::mf4<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)>,boost::function<void (std::string)> > *this,
        RBX::FriendService *p,
        __int64 a1,
        const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *rcx0,
        __int64 *a5,
        __int64 *a6)
{
  boost::_mfi::mf4<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)>,boost::function<void (std::string)> >::F f; // r13
  _QWORD *v10; // r12
  __int64 v11; // rax
  __int64 v12; // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r14
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer next; // rdi
  __int64 v18; // [rsp+0h] [rbp-98h] BYREF
  __int128 v19; // [rsp+8h] [rbp-90h] BYREF
  __int64 v20; // [rsp+18h] [rbp-80h]
  __int64 v21; // [rsp+20h] [rbp-78h] BYREF
  __int128 v22; // [rsp+28h] [rbp-70h] BYREF
  __int64 v23; // [rsp+38h] [rbp-60h]
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > v24; // [rsp+40h] [rbp-58h] BYREF

  f = this->f_;
  v10 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf4<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)>,boost::function<void (std::string)> >::F *)((char *)f + *v10 - 1);
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::table_impl(
    &v24,
    rcx0);
  v21 = 0;
  v11 = *a5;
  if ( *a5 )
  {
    v21 = *a5;
    if ( (v11 & 1) != 0 )
    {
      v23 = a5[3];
      v22 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v22, 0);
    }
  }
  v18 = 0;
  v12 = *a6;
  if ( *a6 )
  {
    v18 = *a6;
    if ( (v12 & 1) != 0 )
    {
      v20 = a6[3];
      v19 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v19, 0);
    }
  }
  ((void (__fastcall *)(_QWORD *, __int64, boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *, __int64 *, __int64 *))f)(
    v10,
    a1,
    &v24,
    &v21,
    &v18);
  if ( v18 )
  {
    if ( (v18 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v18 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v19, &v19, 2);
    }
    v18 = 0;
  }
  if ( v21 )
  {
    if ( (v21 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v21 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v22, &v22, 2);
    }
    v21 = 0;
  }
  buckets = v24.buckets_;
  if ( v24.buckets_ )
  {
    if ( v24.size_ )
    {
      bucket_count = v24.bucket_count_;
      next = v24.buckets_[v24.bucket_count_].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --v24.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = v24.buckets_;
    }
    operator delete(buckets);
  }
}


// Address: 0x164d440 | Name: _ZNK5boost4_mfi3mf4IvN3RBX13FriendServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_9unordered13unordered_setIlNS_4hashIlEENS4_8equal_toIlEENS8_IlEEEENS_8functionIFvNS_10shared_ptrINSB_13unordered_mapIlNS2_26FriendService_FriendStatusESE_SG_NS8_INS4_4pairIKlSM_EEEEEEEEEEENSJ_IFvSA_EEEEclEPS3_SA_SI_SU_SW_
void __fastcall boost::_mfi::mf4<void,RBX::FriendService,std::string,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *a4,
        __int64 *a5,
        __int64 *a6)
{
  char *v9; // r13
  char *v10; // r15
  __int64 v11; // rax
  __int64 v12; // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r14
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer next; // rdi
  __int64 v18; // [rsp+8h] [rbp-B0h] BYREF
  __int128 v19; // [rsp+10h] [rbp-A8h] BYREF
  __int64 v20; // [rsp+20h] [rbp-98h]
  __int64 v21; // [rsp+28h] [rbp-90h] BYREF
  __int128 v22; // [rsp+30h] [rbp-88h] BYREF
  __int64 v23; // [rsp+40h] [rbp-78h]
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > v24; // [rsp+48h] [rbp-70h] BYREF
  _BYTE v25[16]; // [rsp+78h] [rbp-40h] BYREF
  void *ptr; // [rsp+88h] [rbp-30h]

  v9 = *a1;
  v10 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v9 = *(char **)&v9[*(_QWORD *)v10 - 1];
  std::string::basic_string(v25, a3);
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::table_impl(
    &v24,
    a4);
  v21 = 0;
  v11 = *a5;
  if ( *a5 )
  {
    v21 = *a5;
    if ( (v11 & 1) != 0 )
    {
      v23 = a5[3];
      v22 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v22, 0);
    }
  }
  v18 = 0;
  v12 = *a6;
  if ( *a6 )
  {
    v18 = *a6;
    if ( (v12 & 1) != 0 )
    {
      v20 = a6[3];
      v19 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v19, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *, __int64 *, __int64 *))v9)(
    v10,
    v25,
    &v24,
    &v21,
    &v18);
  if ( v18 )
  {
    if ( (v18 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v18 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v19, &v19, 2);
    }
    v18 = 0;
  }
  if ( v21 )
  {
    if ( (v21 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v21 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v22, &v22, 2);
    }
    v21 = 0;
  }
  buckets = v24.buckets_;
  if ( v24.buckets_ )
  {
    if ( v24.size_ )
    {
      bucket_count = v24.bucket_count_;
      next = v24.buckets_[v24.bucket_count_].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --v24.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = v24.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&v24.max_load_ = 0;
  }
  if ( (v25[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x164eeb0 | Name: _ZNK5boost4_mfi3mf2IvN3RBX13FriendServiceElNS_10shared_ptrIKNSt3__16vectorINS2_10Reflection7VariantENS5_9allocatorIS8_EEEEEEEclEPS3_lSD_
void __fastcall boost::_mfi::mf2<void,RBX::FriendService,long,boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>>::operator()(
        const boost::_mfi::mf2<void,RBX::FriendService,long,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > > *this,
        RBX::FriendService *p,
        __int64 a1,
        boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > a2)
{
  boost::_mfi::mf2<void,RBX::FriendService,long,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > >::F f; // rbx
  _QWORD *v5; // rsi
  volatile signed __int32 *v6; // rax
  volatile signed __int32 *v7; // rbx
  __int64 v8; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::FriendService,long,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > >::F *)((char *)f + *v5 - 1);
  v8 = *(_QWORD *)a2.px;
  v6 = (volatile signed __int32 *)*((_QWORD *)a2.px + 1);
  v9 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64, __int64 *, boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >::element_type *, boost::detail::sp_counted_base *))f)(
    v5,
    a1,
    &v8,
    a2.px,
    a2.pn.pi_);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x164ff10 | Name: _ZNK5boost4_mfi3mf3IvN3RBX13FriendServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvNS_10shared_ptrIKNS4_6vectorINS2_10Reflection7VariantENS8_ISF_EEEEEEEEENSB_IFvSA_EEEEclEPS3_SA_SL_SN_
void __fastcall boost::_mfi::mf3<void,RBX::FriendService,std::string,boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5)
{
  char *v7; // r12
  char *v8; // r15
  __int64 v9; // rax
  __int64 v10; // rax
  void (__fastcall *v11)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  __int64 v13; // [rsp+0h] [rbp-78h] BYREF
  __int128 v14; // [rsp+8h] [rbp-70h] BYREF
  __int64 v15; // [rsp+18h] [rbp-60h]
  __int64 v16; // [rsp+20h] [rbp-58h] BYREF
  __int128 v17; // [rsp+28h] [rbp-50h] BYREF
  __int64 v18; // [rsp+38h] [rbp-40h]
  _BYTE v19[16]; // [rsp+40h] [rbp-38h] BYREF
  void *ptr; // [rsp+50h] [rbp-28h]

  v7 = *a1;
  v8 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v7 = *(char **)&v7[*(_QWORD *)v8 - 1];
  std::string::basic_string(v19, a3);
  v16 = 0;
  v9 = *a4;
  if ( *a4 )
  {
    v16 = *a4;
    if ( (v9 & 1) != 0 )
    {
      v18 = a4[3];
      v17 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v17, 0);
    }
  }
  v13 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v13 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v15 = a5[3];
      v14 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v14, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *, __int64 *))v7)(v8, v19, &v16, &v13);
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14, &v14, 2);
    }
    v13 = 0;
  }
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( (v19[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x172d3c0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX14GamepadServiceENS_10shared_ptrINS2_6CameraEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::GamepadService,boost::shared_ptr<RBX::Camera>>::operator()(
        const boost::_mfi::mf1<void,RBX::GamepadService,boost::shared_ptr<RBX::Camera> > *this,
        RBX::GamepadService *p,
        boost::shared_ptr<RBX::Camera> a1)
{
  boost::_mfi::mf1<void,RBX::GamepadService,boost::shared_ptr<RBX::Camera> >::F f; // rcx
  _QWORD *v4; // rsi
  volatile signed __int32 *v5; // rax
  volatile signed __int32 *v6; // rbx
  __int64 v7; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::GamepadService,boost::shared_ptr<RBX::Camera> >::F *)((char *)f + *v4 - 1);
  v7 = *(_QWORD *)a1.px;
  v5 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v8 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x17db1f0 | Name: _ZNK5boost4_mfi3mf2IvN3RBX10GuiServiceENS_8functionIFvN3G3D7Vector2EEEENS4_IFvNSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEEEEEEclEPS3_S8_SH_
void __fastcall boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()(G3D::Vector2)>,boost::function<void ()(std::string)>>::operator()(
        const boost::_mfi::mf2<void,RBX::GuiService,boost::function<void (G3D::Vector2)>,boost::function<void (std::string)> > *this,
        RBX::GuiService *p,
        __int64 *a3,
        __int64 *a4)
{
  boost::_mfi::mf2<void,RBX::GuiService,boost::function<void (G3D::Vector2)>,boost::function<void (std::string)> >::F f; // r15
  _QWORD *v6; // rbx
  __int64 v7; // rcx
  __int64 v8; // rax
  void (__fastcall *v9)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v10)(__int128 *, __int128 *, __int64); // rax
  __int64 v11; // [rsp+0h] [rbp-58h] BYREF
  __int128 v12; // [rsp+8h] [rbp-50h] BYREF
  __int64 v13; // [rsp+18h] [rbp-40h]
  __int64 v14; // [rsp+20h] [rbp-38h] BYREF
  __int128 v15; // [rsp+28h] [rbp-30h] BYREF
  __int64 v16; // [rsp+38h] [rbp-20h]

  f = this->f_;
  v6 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::GuiService,boost::function<void (G3D::Vector2)>,boost::function<void (std::string)> >::F *)((char *)f + *v6 - 1);
  v14 = 0;
  v7 = *a3;
  if ( *a3 )
  {
    v14 = *a3;
    if ( (v7 & 1) != 0 )
    {
      v16 = a3[3];
      v15 = *(_OWORD *)(a3 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(a3 + 1, &v15, 0);
    }
  }
  v11 = 0;
  v8 = *a4;
  if ( *a4 )
  {
    v11 = *a4;
    if ( (v8 & 1) != 0 )
    {
      v13 = a4[3];
      v12 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v8 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v12, 0);
    }
  }
  ((void (__fastcall *)(_QWORD *, __int64 *, __int64 *))f)(v6, &v14, &v11);
  if ( v11 )
  {
    if ( (v11 & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v11 & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v12, &v12, 2);
    }
    v11 = 0;
  }
  if ( v14 && (v14 & 1) == 0 )
  {
    v10 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v14 & 0xFFFFFFFFFFFFFFFELL);
    if ( v10 )
      v10(&v15, &v15, 2);
  }
}


// Address: 0x17dda10 | Name: _ZNK5boost4_mfi3mf2IvN3RBX10GuiServiceENS_8functionIFvvEEEbE4callINS_10shared_ptrIS3_EES6_bEEvRT_PKvRT0_RT1_
void __fastcall boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()(void)>,bool>::call<boost::shared_ptr<RBX::GuiService>,boost::function<void ()(void)>,bool>(
        const boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()>,bool> *this,
        boost::shared_ptr<RBX::GuiService> *u,
        const void *a3,
        boost::function<void ()>_0 *b1,
        bool *b2)
{
  boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()>,bool>::F f; // r15
  _QWORD *v7; // rbx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::function::vtable_base *v10; // [rsp+0h] [rbp-38h] BYREF
  boost::detail::function::function_buffer v11[2]; // [rsp+8h] [rbp-30h] BYREF

  f = this->f_;
  v7 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()>,bool>::F *)((char *)f + *v7 - 1);
  v10 = 0;
  vtable = b1->vtable;
  if ( b1->vtable )
  {
    v10 = b1->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      v11[0] = b1->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b1->functor,
        v11,
        0);
  }
  ((void (__fastcall *)(_QWORD *, boost::detail::function::vtable_base **, bool))f)(v7, &v10, *b2);
  if ( v10 && ((unsigned __int8)v10 & 1) == 0 )
  {
    v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v10 & 0xFFFFFFFFFFFFFFFELL);
    if ( v9 )
      v9(v11, v11, 2);
  }
}


// Address: 0x17de420 | Name: _ZNK5boost4_mfi3mf2IvN3RBX10GuiServiceENS_8functionIFvvEEENSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEEE4callINS_10shared_ptrIS3_EES6_SD_EEvRT_PKvRT0_RT1_
void __fastcall boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()(void)>,std::string>::call<boost::shared_ptr<RBX::GuiService>,boost::function<void ()(void)>,std::string>(
        const boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()>,std::string > *this,
        boost::shared_ptr<RBX::GuiService> *u,
        const void *a3,
        boost::function<void ()>_0 *b1,
        std::string *b2)
{
  boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()>,std::string >::F f; // r15
  _QWORD *v7; // rbx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::function::vtable_base *v10; // [rsp+8h] [rbp-50h] BYREF
  boost::detail::function::function_buffer functor; // [rsp+10h] [rbp-48h] BYREF
  _BYTE v12[16]; // [rsp+28h] [rbp-30h] BYREF
  void *ptr; // [rsp+38h] [rbp-20h]

  f = this->f_;
  v7 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()>,std::string >::F *)((char *)f + *v7 - 1);
  v10 = 0;
  vtable = b1->vtable;
  if ( b1->vtable )
  {
    v10 = b1->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      functor = b1->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b1->functor,
        &functor,
        0);
  }
  std::string::basic_string(v12, b2);
  ((void (__fastcall *)(_QWORD *, boost::detail::function::vtable_base **, _BYTE *))f)(v7, &v10, v12);
  if ( (v12[0] & 1) != 0 )
    operator delete(ptr);
  if ( v10 && ((unsigned __int8)v10 & 1) == 0 )
  {
    v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v10 & 0xFFFFFFFFFFFFFFFELL);
    if ( v9 )
      v9(&functor, &functor, 2);
  }
}


// Address: 0x17df0d0 | Name: _ZNK5boost4_mfi3mf3IvN3RBX10GuiServiceENS_8functionIFvvEEENSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEESD_E4callINS_10shared_ptrIS3_EES6_SD_SD_EEvRT_PKvRT0_RT1_RT2_
void __fastcall boost::_mfi::mf3<void,RBX::GuiService,boost::function<void ()(void)>,std::string,std::string>::call<boost::shared_ptr<RBX::GuiService>,boost::function<void ()(void)>,std::string,std::string>(
        const boost::_mfi::mf3<void,RBX::GuiService,boost::function<void ()>,std::string,std::string > *this,
        boost::shared_ptr<RBX::GuiService> *u,
        const void *a3,
        boost::function<void ()>_0 *b1,
        std::string *b2,
        std::string *b3)
{
  boost::_mfi::mf3<void,RBX::GuiService,boost::function<void ()>,std::string,std::string >::F f; // r12
  _QWORD *v9; // rbx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::function::vtable_base *v12; // [rsp+8h] [rbp-70h] BYREF
  boost::detail::function::function_buffer functor; // [rsp+10h] [rbp-68h] BYREF
  _BYTE v14[16]; // [rsp+28h] [rbp-50h] BYREF
  void *ptr; // [rsp+38h] [rbp-40h]
  _BYTE v16[16]; // [rsp+40h] [rbp-38h] BYREF
  void *v17; // [rsp+50h] [rbp-28h]

  f = this->f_;
  v9 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::GuiService,boost::function<void ()>,std::string,std::string >::F *)((char *)f + *v9 - 1);
  v12 = 0;
  vtable = b1->vtable;
  if ( b1->vtable )
  {
    v12 = b1->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      functor = b1->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b1->functor,
        &functor,
        0);
  }
  std::string::basic_string(v16, b2);
  std::string::basic_string(v14, b3);
  ((void (__fastcall *)(_QWORD *, boost::detail::function::vtable_base **, _BYTE *, _BYTE *))f)(v9, &v12, v16, v14);
  if ( (v14[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v16[0] & 1) != 0 )
    operator delete(v17);
  if ( v12 && ((unsigned __int8)v12 & 1) == 0 )
  {
    v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v12 & 0xFFFFFFFFFFFFFFFELL);
    if ( v11 )
      v11(&functor, &functor, 2);
  }
}


// Address: 0x17e0110 | Name: _ZNK5boost4_mfi3mf1IvN3RBX10GuiServiceENS_8functionIFvvEEEE4callINS_10shared_ptrIS3_EES6_EEvRT_PKvRT0_
void __fastcall boost::_mfi::mf1<void,RBX::GuiService,boost::function<void ()(void)>>::call<boost::shared_ptr<RBX::GuiService>,boost::function<void ()(void)>>(
        const boost::_mfi::mf1<void,RBX::GuiService,boost::function<void ()> > *this,
        boost::shared_ptr<RBX::GuiService> *u,
        const void *a3,
        boost::function<void ()>_0 *b1)
{
  boost::_mfi::mf1<void,RBX::GuiService,boost::function<void ()> >::F f; // r14
  _QWORD *v5; // rbx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v7)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::function::vtable_base *v8; // [rsp+8h] [rbp-30h] BYREF
  boost::detail::function::function_buffer functor; // [rsp+10h] [rbp-28h] BYREF

  f = this->f_;
  v5 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::GuiService,boost::function<void ()> >::F *)((char *)f + *v5 - 1);
  v8 = 0;
  vtable = b1->vtable;
  if ( b1->vtable )
  {
    v8 = b1->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      functor = b1->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b1->functor,
        &functor,
        0);
  }
  ((void (__fastcall *)(_QWORD *, boost::detail::function::vtable_base **, const void *))f)(v5, &v8, a3);
  if ( v8 && ((unsigned __int8)v8 & 1) == 0 )
  {
    v7 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v8 & 0xFFFFFFFFFFFFFFFELL);
    if ( v7 )
      v7(&functor, &functor, 2);
  }
}


// Address: 0x183e600 | Name: _ZNK5boost4_mfi3mf1IvN3RBX17HttpRbxApiServiceENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::HttpRbxApiService,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::HttpRbxApiService,boost::shared_ptr<RBX::Instance> > *this,
        RBX::HttpRbxApiService *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::HttpRbxApiService,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::HttpRbxApiService,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x187dd20 | Name: _ZNK5boost4_mfi3mf2IvN3RBX10LogServiceENS_10shared_ptrINS2_8InstanceEEENSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEEEclEPS3_S6_SD_
void __fastcall boost::_mfi::mf2<void,RBX::LogService,boost::shared_ptr<RBX::Instance>,std::string>::operator()(
        char **a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4)
{
  char *v4; // r14
  char *v5; // rbx
  volatile signed __int32 *v6; // rax
  volatile signed __int32 *v7; // rbx
  __int64 v8; // [rsp+0h] [rbp-38h] BYREF
  volatile signed __int32 *v9; // [rsp+8h] [rbp-30h]
  _BYTE v10[16]; // [rsp+10h] [rbp-28h] BYREF
  void *ptr; // [rsp+20h] [rbp-18h]

  v4 = *a1;
  v5 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v4 = *(char **)&v4[*(_QWORD *)v5 - 1];
  v8 = *a3;
  v6 = (volatile signed __int32 *)a3[1];
  v9 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  std::string::basic_string(v10, a4);
  ((void (__fastcall *)(char *, __int64 *, _BYTE *))v4)(v5, &v8, v10);
  if ( (v10[0] & 1) != 0 )
    operator delete(ptr);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x18b81d0 | Name: _ZNK5boost4_mfi3mf2IvN3RBX18MarketplaceServiceEbNS_10shared_ptrINS2_8InstanceEEEEclEPS3_bS6_
void __fastcall boost::_mfi::mf2<void,RBX::MarketplaceService,bool,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf2<void,RBX::MarketplaceService,bool,boost::shared_ptr<RBX::Instance> > *this,
        RBX::MarketplaceService *p,
        bool a1,
        boost::shared_ptr<RBX::Instance> a2)
{
  boost::_mfi::mf2<void,RBX::MarketplaceService,bool,boost::shared_ptr<RBX::Instance> >::F f; // rbx
  _QWORD *v5; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v7; // rbx
  int (**v8)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::MarketplaceService,bool,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v5 - 1);
  v8 = a2.px->_vptr$EventSource;
  px = a2.px->weak_this_.px;
  v9 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, bool, int (***)(void), boost::shared_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *))f)(
    v5,
    a1,
    &v8,
    a2.px,
    a2.pn.pi_);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x18bd1e0 | Name: _ZNK5boost4_mfi3mf3IvN3RBX18MarketplaceServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapISA_NS2_10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairIKSA_SG_EEEEEEEEEEENSB_IFvSA_EEEEclEPS3_SA_ST_SV_
void __fastcall boost::_mfi::mf3<void,RBX::MarketplaceService,std::string,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5)
{
  char *v7; // r12
  char *v8; // r15
  __int64 v9; // rax
  __int64 v10; // rax
  void (__fastcall *v11)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  __int64 v13; // [rsp+0h] [rbp-78h] BYREF
  __int128 v14; // [rsp+8h] [rbp-70h] BYREF
  __int64 v15; // [rsp+18h] [rbp-60h]
  __int64 v16; // [rsp+20h] [rbp-58h] BYREF
  __int128 v17; // [rsp+28h] [rbp-50h] BYREF
  __int64 v18; // [rsp+38h] [rbp-40h]
  _BYTE v19[16]; // [rsp+40h] [rbp-38h] BYREF
  void *ptr; // [rsp+50h] [rbp-28h]

  v7 = *a1;
  v8 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v7 = *(char **)&v7[*(_QWORD *)v8 - 1];
  std::string::basic_string(v19, a3);
  v16 = 0;
  v9 = *a4;
  if ( *a4 )
  {
    v16 = *a4;
    if ( (v9 & 1) != 0 )
    {
      v18 = a4[3];
      v17 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v17, 0);
    }
  }
  v13 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v13 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v15 = a5[3];
      v14 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v14, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *, __int64 *))v7)(v8, v19, &v16, &v13);
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14, &v14, 2);
    }
    v13 = 0;
  }
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( (v19[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x18bda50 | Name: _ZNK5boost4_mfi3mf3IvN3RBX18MarketplaceServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8weak_ptrINS2_9DataModelEEENS_8functionIFvSA_EEEEclEPS3_SA_SD_SG_
void __fastcall boost::_mfi::mf3<void,RBX::MarketplaceService,std::string,boost::weak_ptr<RBX::DataModel>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5)
{
  char *v7; // r12
  char *v8; // r15
  __int64 v9; // rax
  __int64 v10; // rax
  void (__fastcall *v11)(__int128 *, __int128 *, __int64); // rax
  __int64 v12; // rdi
  __int64 v13; // [rsp+0h] [rbp-68h] BYREF
  __int128 v14; // [rsp+8h] [rbp-60h] BYREF
  __int64 v15; // [rsp+18h] [rbp-50h]
  __int64 v16; // [rsp+20h] [rbp-48h] BYREF
  __int64 v17; // [rsp+28h] [rbp-40h]
  _BYTE v18[16]; // [rsp+30h] [rbp-38h] BYREF
  void *ptr; // [rsp+40h] [rbp-28h]

  v7 = *a1;
  v8 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v7 = *(char **)&v7[*(_QWORD *)v8 - 1];
  std::string::basic_string(v18, a3);
  v16 = *a4;
  v9 = a4[1];
  v17 = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 12), 1u);
  v13 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v13 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v15 = a5[3];
      v14 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v14, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *, __int64 *))v7)(v8, v18, &v16, &v13);
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14, &v14, 2);
    }
    v13 = 0;
  }
  v12 = v17;
  if ( v17 && !_InterlockedSub((volatile signed __int32 *)(v17 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v12 + 24LL))(v12);
  if ( (v18[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x18bec30 | Name: _ZNK5boost4_mfi3mf5IvN3RBX18MarketplaceServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEESA_NS_8weak_ptrINS2_9DataModelEEENS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapISA_NS2_10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairIKSA_SJ_EEEEEEEEEEENSE_IFvSA_EEEEclEPS3_SA_SA_SD_SW_SY_
void __fastcall boost::_mfi::mf5<void,RBX::MarketplaceService,std::string,std::string,boost::weak_ptr<RBX::DataModel>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 *a5,
        __int64 *a6,
        __int64 *a7)
{
  char *v10; // r13
  char *v11; // r14
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v14; // rax
  void (__fastcall *v15)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v16)(__int128 *, __int128 *, __int64); // rax
  __int64 v17; // rdi
  __int64 v18; // [rsp+0h] [rbp-A8h] BYREF
  __int128 v19; // [rsp+8h] [rbp-A0h] BYREF
  __int64 v20; // [rsp+18h] [rbp-90h]
  __int64 v21; // [rsp+20h] [rbp-88h] BYREF
  __int128 v22; // [rsp+28h] [rbp-80h] BYREF
  __int64 v23; // [rsp+38h] [rbp-70h]
  __int64 v24; // [rsp+40h] [rbp-68h] BYREF
  __int64 v25; // [rsp+48h] [rbp-60h]
  _BYTE v26[16]; // [rsp+50h] [rbp-58h] BYREF
  void *ptr; // [rsp+60h] [rbp-48h]
  _BYTE v28[16]; // [rsp+68h] [rbp-40h] BYREF
  void *v29; // [rsp+78h] [rbp-30h]

  v10 = *a1;
  v11 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v10 = *(char **)&v10[*(_QWORD *)v11 - 1];
  std::string::basic_string(v28, a3);
  std::string::basic_string(v26, a4);
  v24 = *a5;
  v12 = a5[1];
  v25 = v12;
  if ( v12 )
    _InterlockedAdd((volatile signed __int32 *)(v12 + 12), 1u);
  v21 = 0;
  v13 = *a6;
  if ( *a6 )
  {
    v21 = *a6;
    if ( (v13 & 1) != 0 )
    {
      v23 = a6[3];
      v22 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v13 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v22, 0);
    }
  }
  v18 = 0;
  v14 = *a7;
  if ( *a7 )
  {
    v18 = *a7;
    if ( (v14 & 1) != 0 )
    {
      v20 = a7[3];
      v19 = *(_OWORD *)(a7 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v14 & 0xFFFFFFFFFFFFFFFELL))(a7 + 1, &v19, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, _BYTE *, __int64 *, __int64 *, __int64 *))v10)(v11, v28, v26, &v24, &v21, &v18);
  if ( v18 )
  {
    if ( (v18 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v18 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v19, &v19, 2);
    }
    v18 = 0;
  }
  if ( v21 )
  {
    if ( (v21 & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v21 & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v22, &v22, 2);
    }
    v21 = 0;
  }
  v17 = v25;
  if ( v25 && !_InterlockedSub((volatile signed __int32 *)(v25 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v17 + 24LL))(v17);
  if ( (v26[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v28[0] & 1) != 0 )
    operator delete(v29);
}


// Address: 0x18bfe90 | Name: _ZNK5boost4_mfi3mf3IvN3RBX18MarketplaceServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvbEEENSB_IFvSA_EEEEclEPS3_SA_SD_SF_
void __fastcall boost::_mfi::mf3<void,RBX::MarketplaceService,std::string,boost::function<void ()(bool)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5)
{
  char *v7; // r12
  char *v8; // r15
  __int64 v9; // rax
  __int64 v10; // rax
  void (__fastcall *v11)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  __int64 v13; // [rsp+0h] [rbp-78h] BYREF
  __int128 v14; // [rsp+8h] [rbp-70h] BYREF
  __int64 v15; // [rsp+18h] [rbp-60h]
  __int64 v16; // [rsp+20h] [rbp-58h] BYREF
  __int128 v17; // [rsp+28h] [rbp-50h] BYREF
  __int64 v18; // [rsp+38h] [rbp-40h]
  _BYTE v19[16]; // [rsp+40h] [rbp-38h] BYREF
  void *ptr; // [rsp+50h] [rbp-28h]

  v7 = *a1;
  v8 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v7 = *(char **)&v7[*(_QWORD *)v8 - 1];
  std::string::basic_string(v19, a3);
  v16 = 0;
  v9 = *a4;
  if ( *a4 )
  {
    v16 = *a4;
    if ( (v9 & 1) != 0 )
    {
      v18 = a4[3];
      v17 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v17, 0);
    }
  }
  v13 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v13 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v15 = a5[3];
      v14 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v14, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *, __int64 *))v7)(v8, v19, &v16, &v13);
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14, &v14, 2);
    }
    v13 = 0;
  }
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( (v19[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x18c3840 | Name: _ZNK5boost4_mfi3mf1IvN3RBX18MarketplaceServiceENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::MarketplaceService,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::MarketplaceService,boost::shared_ptr<RBX::Instance> > *this,
        RBX::MarketplaceService *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::MarketplaceService,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::MarketplaceService,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x190cc50 | Name: _ZNK5boost4_mfi3mf1IvN3RBX19NotificationServiceENS_10shared_ptrIKNS2_11RobloxEventEEEEclEPS3_S7_
void __fastcall boost::_mfi::mf1<void,RBX::NotificationService,boost::shared_ptr<RBX::RobloxEvent const>>::operator()(
        const boost::_mfi::mf1<void,RBX::NotificationService,boost::shared_ptr<const RBX::RobloxEvent> > *this,
        RBX::NotificationService *p,
        boost::shared_ptr<const RBX::RobloxEvent> a1)
{
  boost::_mfi::mf1<void,RBX::NotificationService,boost::shared_ptr<const RBX::RobloxEvent> >::F f; // rcx
  _QWORD *v4; // rsi
  volatile signed __int32 *v5; // rax
  volatile signed __int32 *v6; // rbx
  __int64 v7; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::NotificationService,boost::shared_ptr<const RBX::RobloxEvent> >::F *)((char *)f + *v4 - 1);
  v7 = *(_QWORD *)a1.px;
  v5 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v8 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x19455c0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX8PlatformENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::Platform,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Platform,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Platform *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Platform,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Platform,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1945900 | Name: _ZNK5boost4_mfi3mf1IvN3RBX12PlatformImplINS2_17BasicPartInstanceEEENS_10shared_ptrINS2_8InstanceEEEEclEPS5_S8_
void __fastcall boost::_mfi::mf1<void,RBX::PlatformImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::PlatformImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance> >_0 *this,
        RBX::PlatformImpl<RBX::BasicPartInstance> *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::PlatformImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::PlatformImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1945cd0 | Name: _ZNK5boost4_mfi3mf2IvN3RBX12PlatformImplINS2_17BasicPartInstanceEEENS_10shared_ptrINS2_8InstanceEEEPNS2_7Motor6DEEclEPS5_S8_SA_
void __fastcall boost::_mfi::mf2<void,RBX::PlatformImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Motor6D *>::operator()(
        const boost::_mfi::mf2<void,RBX::PlatformImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Motor6D *>_0 *this,
        RBX::PlatformImpl<RBX::BasicPartInstance> *p,
        boost::shared_ptr<RBX::Instance> a1,
        RBX::Motor6D *a2)
{
  boost::_mfi::mf2<void,RBX::PlatformImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Motor6D *>::F f; // rbx
  _QWORD *v5; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v7; // rbx
  int (**v8)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::PlatformImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Motor6D *>::F *)((char *)f + *v5 - 1);
  v8 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v9 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), boost::detail::sp_counted_base *))f)(v5, &v8, a1.pn.pi_);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x197daf0 | Name: _ZNK5boost4_mfi3mf3IvN3RBX6PlayerENS2_29TeleportService_TeleportStateENS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEENS2_10Reflection7VariantENS_4hashISE_EENS8_8equal_toISE_EENSC_INS8_4pairIKSE_SG_EEEEEEEENS5_INS2_8InstanceEEEEclEPS3_S4_SR_ST_
void __fastcall boost::_mfi::mf3<void,RBX::Player,RBX::TeleportService_TeleportState,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf3<void,RBX::Player,RBX::TeleportService_TeleportState,boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Player *p,
        unsigned int a1,
        boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > a2)
{
  boost::_mfi::mf3<void,RBX::Player,RBX::TeleportService_TeleportState,boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,boost::shared_ptr<RBX::Instance> >::F f; // rbx
  _QWORD *v5; // rsi
  size_t bucket_count; // rax
  volatile signed __int32 *v7; // rax
  volatile signed __int32 *v8; // rbx
  volatile signed __int32 *v9; // rbx
  int (**v10)(void); // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v11; // [rsp+10h] [rbp-28h]
  __int64 v12; // [rsp+18h] [rbp-20h] BYREF
  volatile signed __int32 *v13; // [rsp+20h] [rbp-18h]

  f = this->f_;
  v5 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::Player,RBX::TeleportService_TeleportState,boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v5 - 1);
  v12 = *(_QWORD *)&a2.px->table_.current_;
  bucket_count = a2.px->table_.bucket_count_;
  v13 = (volatile signed __int32 *)bucket_count;
  if ( bucket_count )
    _InterlockedAdd((volatile signed __int32 *)(bucket_count + 8), 1u);
  v10 = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a2.pn.pi_->use_count_;
  v11 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, _QWORD, __int64 *, int (***)(void)))f)(v5, a1, &v12, &v10);
  v8 = v11;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  v9 = v13;
  if ( v13 && !_InterlockedSub(v13 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
    if ( !_InterlockedSub(v9 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
  }
}


// Address: 0x197e590 | Name: _ZNK5boost4_mfi3mf1IvN3RBX6PlayerENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::Player,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Player,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Player *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Player,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Player,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1a0afb0 | Name: _ZNK5boost4_mfi3mf4IvN3RBX7PlayersENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEbNS_8functionIFvNS_10shared_ptrINS2_8InstanceEEEEEENSB_IFvSA_EEEEclEPS3_SA_bSG_SI_
void __fastcall boost::_mfi::mf4<void,RBX::Players,std::string,bool,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        unsigned __int8 a4,
        __int64 *a5,
        __int64 *a6)
{
  char *v9; // r12
  char *v10; // rbx
  __int64 v11; // rax
  __int64 v12; // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  __int64 v15; // [rsp+8h] [rbp-80h] BYREF
  __int128 v16; // [rsp+10h] [rbp-78h] BYREF
  __int64 v17; // [rsp+20h] [rbp-68h]
  __int64 v18; // [rsp+28h] [rbp-60h] BYREF
  __int128 v19; // [rsp+30h] [rbp-58h] BYREF
  __int64 v20; // [rsp+40h] [rbp-48h]
  _BYTE v21[16]; // [rsp+48h] [rbp-40h] BYREF
  void *ptr; // [rsp+58h] [rbp-30h]

  v9 = *a1;
  v10 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v9 = *(char **)&v9[*(_QWORD *)v10 - 1];
  std::string::basic_string(v21, a3);
  v18 = 0;
  v11 = *a5;
  if ( *a5 )
  {
    v18 = *a5;
    if ( (v11 & 1) != 0 )
    {
      v20 = a5[3];
      v19 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v19, 0);
    }
  }
  v15 = 0;
  v12 = *a6;
  if ( *a6 )
  {
    v15 = *a6;
    if ( (v12 & 1) != 0 )
    {
      v17 = a6[3];
      v16 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v16, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, _QWORD, __int64 *, __int64 *))v9)(v10, v21, a4, &v18, &v15);
  if ( v15 )
  {
    if ( (v15 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v15 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v16, &v16, 2);
    }
    v15 = 0;
  }
  if ( v18 )
  {
    if ( (v18 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v18 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v19, &v19, 2);
    }
    v18 = 0;
  }
  if ( (v21[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x1a0d2d0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX7PlayersENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::Players,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Players,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Players *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Players,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Players,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1a0de00 | Name: _ZNK5boost4_mfi3mf2IvN3RBX11AbuseReportENS_10shared_ptrINS2_6PlayerEEERKNS2_11ChatMessageEEclERS3_S6_S9_
void __fastcall boost::_mfi::mf2<void,RBX::AbuseReport,boost::shared_ptr<RBX::Player>,RBX::ChatMessage const&>::operator()(
        const boost::_mfi::mf2<void,RBX::AbuseReport,boost::shared_ptr<RBX::Player>,const RBX::ChatMessage &> *this,
        RBX::AbuseReport *t,
        boost::shared_ptr<RBX::Player> a1,
        const RBX::ChatMessage *a2)
{
  boost::_mfi::mf2<void,RBX::AbuseReport,boost::shared_ptr<RBX::Player>,const RBX::ChatMessage &>::F f; // rbx
  _QWORD *v5; // rsi
  volatile signed __int32 *v6; // rax
  volatile signed __int32 *v7; // rbx
  __int64 v8; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (_QWORD *)((char *)t + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::AbuseReport,boost::shared_ptr<RBX::Player>,const RBX::ChatMessage &>::F *)((char *)f + *v5 - 1);
  v8 = *(_QWORD *)a1.px;
  v6 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v9 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *, boost::detail::sp_counted_base *))f)(v5, &v8, a1.pn.pi_);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x1a105e0 | Name: _ZNK5boost4_mfi3mf5IvN3RBX7PlayersERKN6RakNet13SystemAddressERKNS_10shared_ptrINS2_7Network13NetworkStreamEEENS8_INS2_8InstanceEEENS8_INS2_11ChatMessageEEERKNS2_16TextFilterResultEE4callINS8_IS3_EES6_SC_SF_SH_SJ_EEvRT_PKvRT0_RT1_RT2_RT3_RT4_
void __fastcall boost::_mfi::mf5<void,RBX::Players,RakNet::SystemAddress const&,boost::shared_ptr<RBX::Network::NetworkStream> const&,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ChatMessage>,RBX::TextFilterResult const&>::call<boost::shared_ptr<RBX::Players>,RakNet::SystemAddress const,boost::shared_ptr<RBX::Network::NetworkStream> const,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ChatMessage>,RBX::TextFilterResult const>(
        const boost::_mfi::mf5<void,RBX::Players,const RakNet::SystemAddress &,const boost::shared_ptr<RBX::Network::NetworkStream> &,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ChatMessage>,const RBX::TextFilterResult &> *this,
        boost::shared_ptr<RBX::Players> *u,
        const void *a3,
        const RakNet::SystemAddress *b1,
        const boost::shared_ptr<RBX::Network::NetworkStream> *b2,
        boost::shared_ptr<RBX::Instance> *b3,
        boost::shared_ptr<RBX::ChatMessage> *b4,
        const RBX::TextFilterResult *b5)
{
  boost::_mfi::mf5<void,RBX::Players,const RakNet::SystemAddress &,const boost::shared_ptr<RBX::Network::NetworkStream> &,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ChatMessage>,const RBX::TextFilterResult &>::F f; // rbx
  _QWORD *v9; // rdi
  boost::detail::sp_counted_base *pi; // rdx
  boost::detail::sp_counted_base *v11; // rax
  volatile signed __int32 *v12; // rbx
  volatile signed __int32 *v13; // rbx
  boost::shared_ptr<RBX::ChatMessage>::element_type *v14; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v15; // [rsp+10h] [rbp-28h]
  boost::shared_ptr<RBX::Instance>::element_type *px; // [rsp+18h] [rbp-20h] BYREF
  volatile signed __int32 *v17; // [rsp+20h] [rbp-18h]

  f = this->f_;
  v9 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf5<void,RBX::Players,const RakNet::SystemAddress &,const boost::shared_ptr<RBX::Network::NetworkStream> &,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ChatMessage>,const RBX::TextFilterResult &>::F *)((char *)f + *v9 - 1);
  px = b3->px;
  pi = b3->pn.pi_;
  v17 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v14 = b4->px;
  v11 = b4->pn.pi_;
  v15 = (volatile signed __int32 *)v11;
  if ( v11 )
    _InterlockedAdd(&v11->use_count_, 1u);
  ((void (__fastcall *)(_QWORD *, const RakNet::SystemAddress *, const boost::shared_ptr<RBX::Network::NetworkStream> *, boost::shared_ptr<RBX::Instance>::element_type **, boost::shared_ptr<RBX::ChatMessage>::element_type **, const RBX::TextFilterResult *))f)(
    v9,
    b1,
    b2,
    &px,
    &v14,
    b5);
  v12 = v15;
  if ( v15 )
  {
    if ( !_InterlockedSub(v15 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  v13 = v17;
  if ( v17 && !_InterlockedSub(v17 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
    if ( !_InterlockedSub(v13 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
  }
}


// Address: 0x1a11900 | Name: _ZNK5boost4_mfi3mf4IvN3RBX7PlayersElNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEESA_SA_EclEPS3_lSA_SA_SA_
void __fastcall boost::_mfi::mf4<void,RBX::Players,long,std::string,std::string,std::string>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  char *v9; // r13
  char *v10; // rbx
  _BYTE v11[16]; // [rsp+8h] [rbp-70h] BYREF
  void *v12; // [rsp+18h] [rbp-60h]
  _BYTE v13[16]; // [rsp+20h] [rbp-58h] BYREF
  void *v14; // [rsp+30h] [rbp-48h]
  _BYTE v15[16]; // [rsp+38h] [rbp-40h] BYREF
  void *ptr; // [rsp+48h] [rbp-30h]

  v9 = *a1;
  v10 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v9 = *(char **)&v9[*(_QWORD *)v10 - 1];
  std::string::basic_string(v15, a4);
  std::string::basic_string(v13, a5);
  std::string::basic_string(v11, a6);
  ((void (__fastcall *)(char *, __int64, _BYTE *, _BYTE *, _BYTE *))v9)(v10, a3, v15, v13, v11);
  if ( (v11[0] & 1) != 0 )
  {
    operator delete(v12);
    if ( (v13[0] & 1) == 0 )
    {
LABEL_5:
      if ( (v15[0] & 1) == 0 )
        return;
      goto LABEL_6;
    }
  }
  else if ( (v13[0] & 1) == 0 )
  {
    goto LABEL_5;
  }
  operator delete(v14);
  if ( (v15[0] & 1) == 0 )
    return;
LABEL_6:
  operator delete(ptr);
}


// Address: 0x1a11fc0 | Name: _ZNK5boost4_mfi3mf3IvN3RBX7PlayersENS_8weak_ptrINS2_6PlayerEEElNS2_29FriendService_FriendEventTypeEEclEPS3_S6_lS7_
void __fastcall boost::_mfi::mf3<void,RBX::Players,boost::weak_ptr<RBX::Player>,long,RBX::FriendService_FriendEventType>::operator()(
        const boost::_mfi::mf3<void,RBX::Players,boost::weak_ptr<RBX::Player>,long,RBX::FriendService_FriendEventType> *this,
        RBX::Players *p,
        boost::weak_ptr<RBX::Player> a1,
        __int64 a2,
        RBX::FriendService_FriendEventType a3)
{
  boost::_mfi::mf3<void,RBX::Players,boost::weak_ptr<RBX::Player>,long,RBX::FriendService_FriendEventType>::F f; // rbx
  _QWORD *v6; // rsi
  __int64 v7; // rax
  __int64 v8; // rdi
  __int64 v9; // [rsp+0h] [rbp-18h] BYREF
  __int64 v10; // [rsp+8h] [rbp-10h]

  f = this->f_;
  v6 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::Players,boost::weak_ptr<RBX::Player>,long,RBX::FriendService_FriendEventType>::F *)((char *)f + *v6 - 1);
  v9 = *(_QWORD *)a1.px;
  v7 = *((_QWORD *)a1.px + 1);
  v10 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *, boost::detail::sp_counted_base *, _QWORD))f)(
    v6,
    &v9,
    a1.pn.pi_,
    (unsigned int)a2);
  v8 = v10;
  if ( v10 )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(v10 + 12), 1u) )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 24LL))(v8);
  }
}


// Address: 0x1a7f590 | Name: _ZNK5boost4_mfi3mf2IvN3RBX13LatchedSignalIN3rbx13remote_signalEFvNS_10shared_ptrINS2_8InstanceEEENS6_IKNS2_10Reflection5TupleEEEEEES8_SC_EclEPSE_S8_SC_
void __fastcall boost::_mfi::mf2<void,RBX::LatchedSignal<rbx::remote_signal,void ()(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Reflection::Tuple const>>::operator()(
        const boost::_mfi::mf2<void,RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple> > *this,
        RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)> *p,
        boost::shared_ptr<RBX::Instance> a1,
        boost::shared_ptr<const RBX::Reflection::Tuple> a2)
{
  boost::_mfi::mf2<void,RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple> >::F f; // rbx
  _QWORD *v5; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v7; // rax
  volatile signed __int32 *v8; // rbx
  volatile signed __int32 *v9; // rbx
  int (**v10)(void); // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v11; // [rsp+10h] [rbp-28h]
  int (**v12)(void); // [rsp+18h] [rbp-20h] BYREF
  volatile signed __int32 *v13; // [rsp+20h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$LatchedSignalBase + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple> >::F *)((char *)f + *v5 - 1);
  v12 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v13 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  v10 = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v11 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), int (***)(void), boost::detail::sp_counted_base *, boost::shared_ptr<const RBX::Reflection::Tuple>::element_type *, boost::detail::sp_counted_base *))f)(
    v5,
    &v12,
    &v10,
    a1.pn.pi_,
    a2.px,
    a2.pn.pi_);
  v8 = v11;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  v9 = v13;
  if ( v13 && !_InterlockedSub(v13 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
    if ( !_InterlockedSub(v9 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
  }
}


// Address: 0x1a80c40 | Name: _ZNK5boost4_mfi3mf1IvN3RBX13LatchedSignalIN3rbx13remote_signalEFvNS_10shared_ptrIKNS2_10Reflection5TupleEEEEEESA_EclEPSC_SA_
void __fastcall boost::_mfi::mf1<void,RBX::LatchedSignal<rbx::remote_signal,void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::shared_ptr<RBX::Reflection::Tuple const>>::operator()(
        const boost::_mfi::mf1<void,RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::shared_ptr<const RBX::Reflection::Tuple> > *this,
        RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)> *p,
        boost::shared_ptr<const RBX::Reflection::Tuple> a1)
{
  boost::_mfi::mf1<void,RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::shared_ptr<const RBX::Reflection::Tuple> >::F f; // rcx
  _QWORD *v4; // rsi
  volatile signed __int32 *v5; // rax
  volatile signed __int32 *v6; // rbx
  __int64 v7; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$LatchedSignalBase + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::shared_ptr<const RBX::Reflection::Tuple> >::F *)((char *)f + *v4 - 1);
  v7 = *(_QWORD *)a1.px;
  v5 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v8 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1a852b0 | Name: _ZNK5boost4_mfi3mf4IvN3RBX18RequestDataInQueueEPNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEPSt9exceptionNS_8functionIFvSB_SD_EEENS2_16DataStoreService11HttpRequest11RequestTypeEE4callINS_10shared_ptrIS3_EESB_SD_SG_SJ_EEvRT_PKvRT0_RT1_RT2_RT3_
void __fastcall boost::_mfi::mf4<void,RBX::RequestDataInQueue,std::string *,std::exception *,boost::function<void ()(std::string *,std::exception *)>,RBX::DataStoreService::HttpRequest::RequestType>::call<boost::shared_ptr<RBX::RequestDataInQueue>,std::string *,std::exception *,boost::function<void ()(std::string *,std::exception *)>,RBX::DataStoreService::HttpRequest::RequestType>(
        const boost::_mfi::mf4<void,RBX::RequestDataInQueue,std::string *,std::exception *,boost::function<void (std::string *,std::exception *)>,RBX::DataStoreService::HttpRequest::RequestType> *this,
        boost::shared_ptr<RBX::RequestDataInQueue> *u,
        const void *a3,
        std::string **b1,
        std::exception **b2,
        boost::function<void (std::string *,std::exception *)>_0 *b3,
        RBX::DataStoreService::HttpRequest::RequestType *b4)
{
  boost::_mfi::mf4<void,RBX::RequestDataInQueue,std::string *,std::exception *,boost::function<void (std::string *,std::exception *)>,RBX::DataStoreService::HttpRequest::RequestType>::F f; // r12
  _QWORD *v8; // rbx
  __int64 v9; // r14
  __int64 v10; // r15
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::function::vtable_base *v13; // [rsp+0h] [rbp-48h] BYREF
  boost::detail::function::function_buffer v14[2]; // [rsp+8h] [rbp-40h] BYREF

  f = this->f_;
  v8 = (boost::weak_ptr<RBX::RequestDataInQueue>::element_type **)((char *)&u->px->weak_this_.px
                                                                 + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf4<void,RBX::RequestDataInQueue,std::string *,std::exception *,boost::function<void (std::string *,std::exception *)>,RBX::DataStoreService::HttpRequest::RequestType>::F *)((char *)f + *v8 - 1);
  v9 = (__int64)*b1;
  v10 = (__int64)*b2;
  v13 = 0;
  vtable = b3->vtable;
  if ( b3->vtable )
  {
    v13 = b3->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      v14[0] = b3->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b3->functor,
        v14,
        0);
  }
  ((void (__fastcall *)(_QWORD *, __int64, __int64, boost::detail::function::vtable_base **, _QWORD))f)(
    v8,
    v9,
    v10,
    &v13,
    *(unsigned int *)b4);
  if ( v13 && ((unsigned __int8)v13 & 1) == 0 )
  {
    v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v13 & 0xFFFFFFFFFFFFFFFELL);
    if ( v12 )
      v12(v14, v14, 2);
  }
}


// Address: 0x1aaa2d0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX4SeatENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::Seat,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Seat,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Seat *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Seat,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Seat,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1aaaec0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX8SeatImplINS2_17BasicPartInstanceEEENS_10shared_ptrINS2_8InstanceEEEEclEPS5_S8_
void __fastcall boost::_mfi::mf1<void,RBX::SeatImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::SeatImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance> > *this,
        RBX::SeatImpl<RBX::BasicPartInstance> *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::SeatImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::SeatImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1aab290 | Name: _ZNK5boost4_mfi3mf2IvN3RBX8SeatImplINS2_17BasicPartInstanceEEENS_10shared_ptrINS2_8InstanceEEEPNS2_4WeldEEclEPS5_S8_SA_
void __fastcall boost::_mfi::mf2<void,RBX::SeatImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Weld *>::operator()(
        const boost::_mfi::mf2<void,RBX::SeatImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Weld *> *this,
        RBX::SeatImpl<RBX::BasicPartInstance> *p,
        boost::shared_ptr<RBX::Instance> a1,
        RBX::Weld *a2)
{
  boost::_mfi::mf2<void,RBX::SeatImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Weld *>::F f; // rbx
  _QWORD *v5; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v7; // rbx
  int (**v8)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::SeatImpl<RBX::BasicPartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Weld *>::F *)((char *)f + *v5 - 1);
  v8 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v9 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), boost::detail::sp_counted_base *))f)(v5, &v8, a1.pn.pi_);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x1ab9c60 | Name: _ZNK5boost4_mfi3mf1IvN3RBX18SkateboardPlatformENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::SkateboardPlatform,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::SkateboardPlatform,boost::shared_ptr<RBX::Instance> > *this,
        RBX::SkateboardPlatform *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::SkateboardPlatform,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::SkateboardPlatform,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1b30570 | Name: _ZNK5boost4_mfi3mf2IvN3RBX14PackageServiceENS_10shared_ptrINS2_11PackageLinkEEElEclEPS3_S6_l
void __fastcall boost::_mfi::mf2<void,RBX::PackageService,boost::shared_ptr<RBX::PackageLink>,long>::operator()(
        const boost::_mfi::mf2<void,RBX::PackageService,boost::shared_ptr<RBX::PackageLink>,long> *this,
        RBX::PackageService *p,
        boost::shared_ptr<RBX::PackageLink> a1,
        __int64 a2)
{
  boost::_mfi::mf2<void,RBX::PackageService,boost::shared_ptr<RBX::PackageLink>,long>::F f; // rbx
  _QWORD *v5; // rsi
  volatile signed __int32 *v6; // rax
  volatile signed __int32 *v7; // rbx
  __int64 v8; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::PackageService,boost::shared_ptr<RBX::PackageLink>,long>::F *)((char *)f + *v5 - 1);
  v8 = *(_QWORD *)a1.px;
  v6 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v9 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *, boost::detail::sp_counted_base *))f)(v5, &v8, a1.pn.pi_);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x1b464d0 | Name: _ZNK5boost4_mfi3mf2IvN3RBX29RCCPackageModificationManagerENS_10shared_ptrINS2_11PackageLinkEEENS4_INS2_8InstanceEEEEclEPS3_S6_S8_
void __fastcall boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance> > *this,
        RBX::RCCPackageModificationManager *p,
        boost::shared_ptr<RBX::PackageLink> a1,
        boost::shared_ptr<RBX::Instance> a2)
{
  boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance> >::F f; // rbx
  _QWORD *v5; // rsi
  volatile signed __int32 *v6; // rax
  volatile signed __int32 *v7; // rax
  volatile signed __int32 *v8; // rbx
  volatile signed __int32 *v9; // rbx
  int (**v10)(void); // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v11; // [rsp+10h] [rbp-28h]
  __int64 v12; // [rsp+18h] [rbp-20h] BYREF
  volatile signed __int32 *v13; // [rsp+20h] [rbp-18h]

  f = this->f_;
  v5 = (RBX::PackageService **)((char *)&p->packageService + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v5 - 1);
  v12 = *(_QWORD *)a1.px;
  v6 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v13 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  v10 = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v11 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *, int (***)(void), boost::detail::sp_counted_base *, boost::shared_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *))f)(
    v5,
    &v12,
    &v10,
    a1.pn.pi_,
    a2.px,
    a2.pn.pi_);
  v8 = v11;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  v9 = v13;
  if ( v13 && !_InterlockedSub(v13 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
    if ( !_InterlockedSub(v9 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
  }
}


// Address: 0x1b46900 | Name: _ZNK5boost4_mfi3mf3IvN3RBX29RCCPackageModificationManagerENS_10shared_ptrINS2_11PackageLinkEEENS4_INS2_8InstanceEEEPKNS2_10Reflection18PropertyDescriptorEEclEPS3_S6_S8_SC_
void __fastcall boost::_mfi::mf3<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*>::operator()(
        const boost::_mfi::mf3<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *> *this,
        RBX::RCCPackageModificationManager *p,
        boost::shared_ptr<RBX::PackageLink> a1,
        boost::shared_ptr<RBX::Instance> a2)
{
  boost::_mfi::mf3<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *>::F f; // rbx
  _QWORD *v5; // rsi
  volatile signed __int32 *v6; // rax
  volatile signed __int32 *v7; // rax
  volatile signed __int32 *v8; // rbx
  volatile signed __int32 *v9; // rbx
  int (**v10)(void); // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v11; // [rsp+10h] [rbp-28h]
  __int64 v12; // [rsp+18h] [rbp-20h] BYREF
  volatile signed __int32 *v13; // [rsp+20h] [rbp-18h]

  f = this->f_;
  v5 = (RBX::PackageService **)((char *)&p->packageService + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *>::F *)((char *)f + *v5 - 1);
  v12 = *(_QWORD *)a1.px;
  v6 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v13 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  v10 = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v11 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *, int (***)(void), boost::shared_ptr<RBX::Instance>::element_type *))f)(
    v5,
    &v12,
    &v10,
    a2.px);
  v8 = v11;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  v9 = v13;
  if ( v13 && !_InterlockedSub(v13 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
    if ( !_InterlockedSub(v9 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
  }
}


// Address: 0x1b47340 | Name: _ZNK5boost4_mfi3mf1IvN3RBX29RCCPackageModificationManagerENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::Instance> > *this,
        RBX::RCCPackageModificationManager *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (RBX::PackageService **)((char *)&p->packageService + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1b47be0 | Name: _ZNK5boost4_mfi3mf2IvN3RBX29RCCPackageModificationManagerENS_10shared_ptrINS2_11PackageLinkEEEPKNS2_10Reflection18PropertyDescriptorEEclEPS3_S6_SA_
void __fastcall boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,RBX::Reflection::PropertyDescriptor const*>::operator()(
        const boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,const RBX::Reflection::PropertyDescriptor *> *this,
        RBX::RCCPackageModificationManager *p,
        boost::shared_ptr<RBX::PackageLink> a1,
        const RBX::Reflection::PropertyDescriptor *a2)
{
  boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,const RBX::Reflection::PropertyDescriptor *>::F f; // rbx
  _QWORD *v5; // rsi
  volatile signed __int32 *v6; // rax
  volatile signed __int32 *v7; // rbx
  __int64 v8; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (RBX::PackageService **)((char *)&p->packageService + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,const RBX::Reflection::PropertyDescriptor *>::F *)((char *)f + *v5 - 1);
  v8 = *(_QWORD *)a1.px;
  v6 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v9 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *, boost::detail::sp_counted_base *))f)(v5, &v8, a1.pn.pi_);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x1b77980 | Name: _ZNK5boost4_mfi3mf3IvN3RBX15TeleportServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvNS_10shared_ptrIKNS2_10Reflection5TupleEEEEEENSB_IFvSA_EEEEclEPS3_SA_SI_SK_
void __fastcall boost::_mfi::mf3<void,RBX::TeleportService,std::string,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5)
{
  char *v7; // r12
  char *v8; // r15
  __int64 v9; // rax
  __int64 v10; // rax
  void (__fastcall *v11)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  __int64 v13; // [rsp+0h] [rbp-78h] BYREF
  __int128 v14; // [rsp+8h] [rbp-70h] BYREF
  __int64 v15; // [rsp+18h] [rbp-60h]
  __int64 v16; // [rsp+20h] [rbp-58h] BYREF
  __int128 v17; // [rsp+28h] [rbp-50h] BYREF
  __int64 v18; // [rsp+38h] [rbp-40h]
  _BYTE v19[16]; // [rsp+40h] [rbp-38h] BYREF
  void *ptr; // [rsp+50h] [rbp-28h]

  v7 = *a1;
  v8 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v7 = *(char **)&v7[*(_QWORD *)v8 - 1];
  std::string::basic_string(v19, a3);
  v16 = 0;
  v9 = *a4;
  if ( *a4 )
  {
    v16 = *a4;
    if ( (v9 & 1) != 0 )
    {
      v18 = a4[3];
      v17 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v17, 0);
    }
  }
  v13 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v13 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v15 = a5[3];
      v14 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v14, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *, __int64 *))v7)(v8, v19, &v16, &v13);
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14, &v14, 2);
    }
    v13 = 0;
  }
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( (v19[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x1b78140 | Name: _ZNK5boost4_mfi3mf2IvN3RBX15TeleportServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_8functionIFvSA_EEEEclEPS3_SA_SD_
void __fastcall boost::_mfi::mf2<void,RBX::TeleportService,std::string,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4)
{
  char *v5; // r15
  char *v6; // rbx
  __int64 v7; // rax
  void (__fastcall *v8)(__int128 *, __int128 *, __int64); // rax
  __int64 v9; // [rsp+8h] [rbp-50h] BYREF
  __int128 v10; // [rsp+10h] [rbp-48h] BYREF
  __int64 v11; // [rsp+20h] [rbp-38h]
  _BYTE v12[16]; // [rsp+28h] [rbp-30h] BYREF
  void *ptr; // [rsp+38h] [rbp-20h]

  v5 = *a1;
  v6 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v5 = *(char **)&v5[*(_QWORD *)v6 - 1];
  std::string::basic_string(v12, a3);
  v9 = 0;
  v7 = *a4;
  if ( *a4 )
  {
    v9 = *a4;
    if ( (v7 & 1) != 0 )
    {
      v11 = a4[3];
      v10 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v10, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *))v5)(v6, v12, &v9);
  if ( v9 )
  {
    if ( (v9 & 1) == 0 )
    {
      v8 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v9 & 0xFFFFFFFFFFFFFFFELL);
      if ( v8 )
        v8(&v10, &v10, 2);
    }
    v9 = 0;
  }
  if ( (v12[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x1b78f10 | Name: _ZNK5boost4_mfi3mf4IvN3RBX15TeleportServiceENS_10shared_ptrIKNSt3__16vectorINS4_INS2_8InstanceEEENS5_9allocatorIS8_EEEEEENS4_INS_9unordered13unordered_mapINS5_12basic_stringIcNS5_11char_traitsIcEENS9_IcEEEENS2_10Reflection7VariantENS_4hashISK_EENS5_8equal_toISK_EENS9_INS5_4pairIKSK_SM_EEEEEEEES8_SK_EclEPS3_SD_SW_S8_SK_
void __fastcall boost::_mfi::mf4<void,RBX::TeleportService,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,boost::shared_ptr<RBX::Instance>,std::string>::operator()(
        char **a1,
        __int64 a2,
        __int64 *a3,
        __int64 *a4,
        __int64 *a5,
        __int64 a6)
{
  char *v6; // r14
  char *v7; // rbx
  volatile signed __int32 *v8; // rax
  volatile signed __int32 *v9; // rax
  volatile signed __int32 *v10; // rax
  volatile signed __int32 *v11; // rbx
  volatile signed __int32 *v12; // rbx
  volatile signed __int32 *v13; // rbx
  __int64 v14; // [rsp+0h] [rbp-58h] BYREF
  volatile signed __int32 *v15; // [rsp+8h] [rbp-50h]
  __int64 v16; // [rsp+10h] [rbp-48h] BYREF
  volatile signed __int32 *v17; // [rsp+18h] [rbp-40h]
  __int64 v18; // [rsp+20h] [rbp-38h] BYREF
  volatile signed __int32 *v19; // [rsp+28h] [rbp-30h]
  _BYTE v20[16]; // [rsp+30h] [rbp-28h] BYREF
  void *ptr; // [rsp+40h] [rbp-18h]

  v6 = *a1;
  v7 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v6 = *(char **)&v6[*(_QWORD *)v7 - 1];
  v18 = *a3;
  v8 = (volatile signed __int32 *)a3[1];
  v19 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  v16 = *a4;
  v9 = (volatile signed __int32 *)a4[1];
  v17 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  v14 = *a5;
  v10 = (volatile signed __int32 *)a5[1];
  v15 = v10;
  if ( v10 )
    _InterlockedAdd(v10 + 2, 1u);
  std::string::basic_string(v20, a6);
  ((void (__fastcall *)(char *, __int64 *, __int64 *, __int64 *, _BYTE *))v6)(v7, &v18, &v16, &v14, v20);
  if ( (v20[0] & 1) != 0 )
    operator delete(ptr);
  v11 = v15;
  if ( v15 )
  {
    if ( !_InterlockedSub(v15 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
  v12 = v17;
  if ( v17 )
  {
    if ( !_InterlockedSub(v17 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  v13 = v19;
  if ( v19 && !_InterlockedSub(v19 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
    if ( !_InterlockedSub(v13 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
  }
}


// Address: 0x1b79750 | Name: _ZNK5boost4_mfi3mf3IvN3RBX15TeleportServiceENS_10shared_ptrIKNSt3__16vectorINS4_INS2_8InstanceEEENS5_9allocatorIS8_EEEEEENS4_INS_9unordered13unordered_mapINS5_12basic_stringIcNS5_11char_traitsIcEENS9_IcEEEENS2_10Reflection7VariantENS_4hashISK_EENS5_8equal_toISK_EENS9_INS5_4pairIKSK_SM_EEEEEEEESK_EclEPS3_SD_SW_SK_
void __fastcall boost::_mfi::mf3<void,RBX::TeleportService,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,std::string>::operator()(
        char **a1,
        __int64 a2,
        __int64 *a3,
        __int64 *a4,
        __int64 a5)
{
  char *v5; // r14
  char *v6; // rbx
  volatile signed __int32 *v7; // rax
  volatile signed __int32 *v8; // rax
  volatile signed __int32 *v9; // rbx
  volatile signed __int32 *v10; // rbx
  __int64 v11; // [rsp+0h] [rbp-48h] BYREF
  volatile signed __int32 *v12; // [rsp+8h] [rbp-40h]
  __int64 v13; // [rsp+10h] [rbp-38h] BYREF
  volatile signed __int32 *v14; // [rsp+18h] [rbp-30h]
  _BYTE v15[16]; // [rsp+20h] [rbp-28h] BYREF
  void *ptr; // [rsp+30h] [rbp-18h]

  v5 = *a1;
  v6 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v5 = *(char **)&v5[*(_QWORD *)v6 - 1];
  v13 = *a3;
  v7 = (volatile signed __int32 *)a3[1];
  v14 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  v11 = *a4;
  v8 = (volatile signed __int32 *)a4[1];
  v12 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  std::string::basic_string(v15, a5);
  ((void (__fastcall *)(char *, __int64 *, __int64 *, _BYTE *))v5)(v6, &v13, &v11, v15);
  if ( (v15[0] & 1) != 0 )
    operator delete(ptr);
  v9 = v12;
  if ( v12 )
  {
    if ( !_InterlockedSub(v12 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
      if ( !_InterlockedSub(v9 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
    }
  }
  v10 = v14;
  if ( v14 && !_InterlockedSub(v14 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
    if ( !_InterlockedSub(v10 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
  }
}


// Address: 0x1b7d140 | Name: _ZNK5boost4_mfi3mf6IvN3RBX15TeleportServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_10shared_ptrINS4_6vectorIlNS8_IlEEEEEENSB_INS_9unordered13unordered_mapISA_NS2_10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairIKSA_SJ_EEEEEEEENSB_INS2_8InstanceEEENS_8functionIFvSA_EEESY_EclEPS3_SA_SF_ST_SV_SY_SY_
void __fastcall boost::_mfi::mf6<void,RBX::TeleportService,std::string,boost::shared_ptr<std::vector<long>>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,boost::shared_ptr<RBX::Instance>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5,
        __int64 *a6,
        __int64 *a7,
        __int64 *a8)
{
  char *v11; // r13
  char *v12; // r14
  volatile signed __int32 *v13; // rax
  volatile signed __int32 *v14; // rax
  volatile signed __int32 *v15; // rax
  __int64 v16; // rax
  __int64 v17; // rax
  void (__fastcall *v18)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v19)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v20; // rbx
  volatile signed __int32 *v21; // rbx
  volatile signed __int32 *v22; // rbx
  __int64 v23; // [rsp+8h] [rbp-B0h] BYREF
  __int128 v24; // [rsp+10h] [rbp-A8h] BYREF
  __int64 v25; // [rsp+20h] [rbp-98h]
  __int64 v26; // [rsp+28h] [rbp-90h] BYREF
  __int128 v27; // [rsp+30h] [rbp-88h] BYREF
  __int64 v28; // [rsp+40h] [rbp-78h]
  __int64 v29; // [rsp+48h] [rbp-70h] BYREF
  volatile signed __int32 *v30; // [rsp+50h] [rbp-68h]
  __int64 v31; // [rsp+58h] [rbp-60h] BYREF
  volatile signed __int32 *v32; // [rsp+60h] [rbp-58h]
  __int64 v33; // [rsp+68h] [rbp-50h] BYREF
  volatile signed __int32 *v34; // [rsp+70h] [rbp-48h]
  _BYTE v35[16]; // [rsp+78h] [rbp-40h] BYREF
  void *ptr; // [rsp+88h] [rbp-30h]

  v11 = *a1;
  v12 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v11 = *(char **)&v11[*(_QWORD *)v12 - 1];
  std::string::basic_string(v35, a3);
  v33 = *a4;
  v13 = (volatile signed __int32 *)a4[1];
  v34 = v13;
  if ( v13 )
    _InterlockedAdd(v13 + 2, 1u);
  v31 = *a5;
  v14 = (volatile signed __int32 *)a5[1];
  v32 = v14;
  if ( v14 )
    _InterlockedAdd(v14 + 2, 1u);
  v29 = *a6;
  v15 = (volatile signed __int32 *)a6[1];
  v30 = v15;
  if ( v15 )
    _InterlockedAdd(v15 + 2, 1u);
  v26 = 0;
  v16 = *a7;
  if ( *a7 )
  {
    v26 = *a7;
    if ( (v16 & 1) != 0 )
    {
      v28 = a7[3];
      v27 = *(_OWORD *)(a7 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v16 & 0xFFFFFFFFFFFFFFFELL))(a7 + 1, &v27, 0);
    }
  }
  v23 = 0;
  v17 = *a8;
  if ( *a8 )
  {
    v23 = *a8;
    if ( (v17 & 1) != 0 )
    {
      v25 = a8[3];
      v24 = *(_OWORD *)(a8 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v17 & 0xFFFFFFFFFFFFFFFELL))(a8 + 1, &v24, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *, __int64 *, __int64 *, __int64 *, __int64 *))v11)(
    v12,
    v35,
    &v33,
    &v31,
    &v29,
    &v26,
    &v23);
  if ( v23 )
  {
    if ( (v23 & 1) == 0 )
    {
      v18 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v23 & 0xFFFFFFFFFFFFFFFELL);
      if ( v18 )
        v18(&v24, &v24, 2);
    }
    v23 = 0;
  }
  if ( v26 )
  {
    if ( (v26 & 1) == 0 )
    {
      v19 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v26 & 0xFFFFFFFFFFFFFFFELL);
      if ( v19 )
        v19(&v27, &v27, 2);
    }
    v26 = 0;
  }
  v20 = v30;
  if ( v30 )
  {
    if ( !_InterlockedSub(v30 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 16LL))(v20);
      if ( !_InterlockedSub(v20 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 24LL))(v20);
    }
  }
  v21 = v32;
  if ( v32 )
  {
    if ( !_InterlockedSub(v32 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v21 + 16LL))(v21);
      if ( !_InterlockedSub(v21 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v21 + 24LL))(v21);
    }
  }
  v22 = v34;
  if ( v34 )
  {
    if ( !_InterlockedSub(v34 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 16LL))(v22);
      if ( !_InterlockedSub(v22 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 24LL))(v22);
    }
  }
  if ( (v35[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x1b7def0 | Name: _ZNK5boost4_mfi3mf7IvN3RBX15TeleportServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_10shared_ptrINS4_6vectorIlNS8_IlEEEEEENSB_INS2_5TimerILNS2_4Time12SampleMethodE0EEEEENSB_INS_9unordered13unordered_mapISA_NS2_10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairIKSA_SO_EEEEEEEENSB_INS2_8InstanceEEENS_8functionIFvSA_EEES13_EclEPS3_SA_SF_SK_SY_S10_S13_S13_
void __fastcall boost::_mfi::mf7<void,RBX::TeleportService,std::string,boost::shared_ptr<std::vector<long>>,boost::shared_ptr<RBX::Timer<(RBX::Time::SampleMethod)0>>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,boost::shared_ptr<RBX::Instance>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5,
        __int64 *a6,
        __int64 *a7,
        __int64 *a8,
        __int64 *a9)
{
  char *v12; // r13
  char *v13; // r14
  volatile signed __int32 *v14; // rax
  volatile signed __int32 *v15; // rax
  volatile signed __int32 *v16; // rcx
  volatile signed __int32 *v17; // rax
  __int64 v18; // rax
  __int64 v19; // rax
  void (__fastcall *v20)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v21)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v22; // rbx
  volatile signed __int32 *v23; // rbx
  volatile signed __int32 *v24; // rbx
  volatile signed __int32 *v25; // rbx
  __int64 v26; // [rsp+8h] [rbp-C0h] BYREF
  __int128 v27; // [rsp+10h] [rbp-B8h] BYREF
  __int64 v28; // [rsp+20h] [rbp-A8h]
  __int64 v29; // [rsp+28h] [rbp-A0h] BYREF
  __int128 v30; // [rsp+30h] [rbp-98h] BYREF
  __int64 v31; // [rsp+40h] [rbp-88h]
  __int64 v32; // [rsp+48h] [rbp-80h] BYREF
  volatile signed __int32 *v33; // [rsp+50h] [rbp-78h]
  __int64 v34; // [rsp+58h] [rbp-70h] BYREF
  volatile signed __int32 *v35; // [rsp+60h] [rbp-68h]
  __int64 v36; // [rsp+68h] [rbp-60h] BYREF
  volatile signed __int32 *v37; // [rsp+70h] [rbp-58h]
  __int64 v38; // [rsp+78h] [rbp-50h] BYREF
  volatile signed __int32 *v39; // [rsp+80h] [rbp-48h]
  _BYTE v40[16]; // [rsp+88h] [rbp-40h] BYREF
  void *ptr; // [rsp+98h] [rbp-30h]

  v12 = *a1;
  v13 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v12 = *(char **)&v12[*(_QWORD *)v13 - 1];
  std::string::basic_string(v40, a3);
  v38 = *a4;
  v14 = (volatile signed __int32 *)a4[1];
  v39 = v14;
  if ( v14 )
    _InterlockedAdd(v14 + 2, 1u);
  v36 = *a5;
  v15 = (volatile signed __int32 *)a5[1];
  v37 = v15;
  if ( v15 )
    _InterlockedAdd(v15 + 2, 1u);
  v34 = *a6;
  v16 = (volatile signed __int32 *)a6[1];
  v35 = v16;
  if ( v16 )
    _InterlockedAdd(v16 + 2, 1u);
  v32 = *a7;
  v17 = (volatile signed __int32 *)a7[1];
  v33 = v17;
  if ( v17 )
    _InterlockedAdd(v17 + 2, 1u);
  v29 = 0;
  v18 = *a8;
  if ( *a8 )
  {
    v29 = *a8;
    if ( (v18 & 1) != 0 )
    {
      v31 = a8[3];
      v30 = *(_OWORD *)(a8 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v18 & 0xFFFFFFFFFFFFFFFELL))(a8 + 1, &v30, 0);
    }
  }
  v26 = 0;
  v19 = *a9;
  if ( *a9 )
  {
    v26 = *a9;
    if ( (v19 & 1) != 0 )
    {
      v28 = a9[3];
      v27 = *(_OWORD *)(a9 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v19 & 0xFFFFFFFFFFFFFFFELL))(a9 + 1, &v27, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *, __int64 *, __int64 *, __int64 *, __int64 *, __int64 *))v12)(
    v13,
    v40,
    &v38,
    &v36,
    &v34,
    &v32,
    &v29,
    &v26);
  if ( v26 )
  {
    if ( (v26 & 1) == 0 )
    {
      v20 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v26 & 0xFFFFFFFFFFFFFFFELL);
      if ( v20 )
        v20(&v27, &v27, 2);
    }
    v26 = 0;
  }
  if ( v29 )
  {
    if ( (v29 & 1) == 0 )
    {
      v21 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v29 & 0xFFFFFFFFFFFFFFFELL);
      if ( v21 )
        v21(&v30, &v30, 2);
    }
    v29 = 0;
  }
  v22 = v33;
  if ( v33 )
  {
    if ( !_InterlockedSub(v33 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 16LL))(v22);
      if ( !_InterlockedSub(v22 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 24LL))(v22);
    }
  }
  v23 = v35;
  if ( v35 )
  {
    if ( !_InterlockedSub(v35 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 16LL))(v23);
      if ( !_InterlockedSub(v23 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 24LL))(v23);
    }
  }
  v24 = v37;
  if ( v37 )
  {
    if ( !_InterlockedSub(v37 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 16LL))(v24);
      if ( !_InterlockedSub(v24 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 24LL))(v24);
    }
  }
  v25 = v39;
  if ( v39 )
  {
    if ( !_InterlockedSub(v39 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 16LL))(v25);
      if ( !_InterlockedSub(v25 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 24LL))(v25);
    }
  }
  if ( (v40[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x1b80af0 | Name: _ZNK5boost4_mfi3mf3IvN3RBX15TeleportServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_10shared_ptrINS4_6vectorIlNS8_IlEEEEEENS_8functionIFvSA_EEEEclEPS3_SA_SF_SI_
void __fastcall boost::_mfi::mf3<void,RBX::TeleportService,std::string,boost::shared_ptr<std::vector<long>>,boost::function<void ()(std::string)>>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5)
{
  char *v7; // r12
  char *v8; // r15
  volatile signed __int32 *v9; // rax
  __int64 v10; // rax
  void (__fastcall *v11)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v12; // rbx
  __int64 v13; // [rsp+0h] [rbp-68h] BYREF
  __int128 v14; // [rsp+8h] [rbp-60h] BYREF
  __int64 v15; // [rsp+18h] [rbp-50h]
  __int64 v16; // [rsp+20h] [rbp-48h] BYREF
  volatile signed __int32 *v17; // [rsp+28h] [rbp-40h]
  _BYTE v18[16]; // [rsp+30h] [rbp-38h] BYREF
  void *ptr; // [rsp+40h] [rbp-28h]

  v7 = *a1;
  v8 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v7 = *(char **)&v7[*(_QWORD *)v8 - 1];
  std::string::basic_string(v18, a3);
  v16 = *a4;
  v9 = (volatile signed __int32 *)a4[1];
  v17 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  v13 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v13 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v15 = a5[3];
      v14 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v14, 0);
    }
  }
  ((void (__fastcall *)(char *, _BYTE *, __int64 *, __int64 *))v7)(v8, v18, &v16, &v13);
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14, &v14, 2);
    }
    v13 = 0;
  }
  v12 = v17;
  if ( v17 )
  {
    if ( !_InterlockedSub(v17 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  if ( (v18[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x1b93f50 | Name: _ZNK5boost4_mfi3mf1IvN3RBX11TestServiceENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::TestService,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::TestService,boost::shared_ptr<RBX::Instance> > *this,
        RBX::TestService *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::TestService,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::TestService,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1b94ee0 | Name: _ZNK5boost4_mfi3mf5IvN3RBX11TestServiceEiPKcS5_NS_10shared_ptrINS2_18LuaSourceContainerEEEiE4callINS6_IS3_EEiS5_S5_S8_iEEvRT_PKvRT0_RT1_RT2_RT3_RT4_
void __fastcall boost::_mfi::mf5<void,RBX::TestService,int,char const*,char const*,boost::shared_ptr<RBX::LuaSourceContainer>,int>::call<boost::shared_ptr<RBX::TestService>,int,char const*,char const*,boost::shared_ptr<RBX::LuaSourceContainer>,int>(
        const boost::_mfi::mf5<void,RBX::TestService,int,const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int> *this,
        boost::shared_ptr<RBX::TestService> *u,
        const void *a3,
        unsigned int *b1,
        const char **b2,
        const char **b3,
        boost::shared_ptr<RBX::LuaSourceContainer> *b4,
        int *b5)
{
  boost::_mfi::mf5<void,RBX::TestService,int,const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int>::F f; // rbx
  _QWORD *v9; // rdi
  __int64 v10; // rsi
  __int64 v11; // rdx
  __int64 v12; // rcx
  boost::detail::sp_counted_base *pi; // rax
  volatile signed __int32 *v14; // rbx
  boost::shared_ptr<RBX::LuaSourceContainer>::element_type *px; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v16; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v9 = (char *)u->px + *((_QWORD *)&this->f_ + 1);
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf5<void,RBX::TestService,int,const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int>::F *)((char *)f + *v9 - 1);
  v10 = *b1;
  v11 = (__int64)*b2;
  v12 = (__int64)*b3;
  px = b4->px;
  pi = b4->pn.pi_;
  v16 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  ((void (__fastcall *)(_QWORD *, __int64, __int64, __int64, boost::shared_ptr<RBX::LuaSourceContainer>::element_type **, _QWORD))f)(
    v9,
    v10,
    v11,
    v12,
    &px,
    (unsigned int)*b5);
  v14 = v16;
  if ( v16 && !_InterlockedSub(v16 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
    if ( !_InterlockedSub(v14 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
  }
}


// Address: 0x1b95560 | Name: _ZNK5boost4_mfi3mf3IvN3RBX11TestServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_10shared_ptrINS2_8InstanceEEEiEclEPS3_SA_SD_i
void __fastcall boost::_mfi::mf3<void,RBX::TestService,std::string,boost::shared_ptr<RBX::Instance>,int>::operator()(
        char **a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        unsigned int a5)
{
  char *v7; // rbp
  char *v8; // rbx
  volatile signed __int32 *v9; // rax
  volatile signed __int32 *v10; // rbx
  __int64 v11; // [rsp+0h] [rbp-48h] BYREF
  volatile signed __int32 *v12; // [rsp+8h] [rbp-40h]
  _BYTE v13[16]; // [rsp+10h] [rbp-38h] BYREF
  void *ptr; // [rsp+20h] [rbp-28h]

  v7 = *a1;
  v8 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v7 = *(char **)&v7[*(_QWORD *)v8 - 1];
  std::string::basic_string(v13, a3);
  v11 = *a4;
  v9 = (volatile signed __int32 *)a4[1];
  v12 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  ((void (__fastcall *)(char *, _BYTE *, __int64 *, _QWORD))v7)(v8, v13, &v11, a5);
  v10 = v12;
  if ( v12 )
  {
    if ( !_InterlockedSub(v12 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
      if ( !_InterlockedSub(v10 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
    }
  }
  if ( (v13[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x1b95880 | Name: _ZNK5boost4_mfi3mf4IvN3RBX11TestServiceEbNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_10shared_ptrINS2_8InstanceEEEiEclEPS3_bSA_SD_i
void __fastcall boost::_mfi::mf4<void,RBX::TestService,bool,std::string,boost::shared_ptr<RBX::Instance>,int>::operator()(
        char **a1,
        __int64 a2,
        unsigned __int8 a3,
        __int64 a4,
        __int64 *a5,
        unsigned int a6)
{
  char *v9; // rbp
  char *v10; // rbx
  volatile signed __int32 *v11; // rax
  volatile signed __int32 *v12; // rbx
  __int64 v13; // [rsp+8h] [rbp-50h] BYREF
  volatile signed __int32 *v14; // [rsp+10h] [rbp-48h]
  _BYTE v15[16]; // [rsp+18h] [rbp-40h] BYREF
  void *ptr; // [rsp+28h] [rbp-30h]

  v9 = *a1;
  v10 = &a1[1][a2];
  if ( ((unsigned __int8)*a1 & 1) != 0 )
    v9 = *(char **)&v9[*(_QWORD *)v10 - 1];
  std::string::basic_string(v15, a4);
  v13 = *a5;
  v11 = (volatile signed __int32 *)a5[1];
  v14 = v11;
  if ( v11 )
    _InterlockedAdd(v11 + 2, 1u);
  ((void (__fastcall *)(char *, _QWORD, _BYTE *, __int64 *, _QWORD))v9)(v10, a3, v15, &v13, a6);
  v12 = v14;
  if ( v14 )
  {
    if ( !_InterlockedSub(v14 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  if ( (v15[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x1b9bb40 | Name: _ZNK5boost4_mfi3mf4IvN3RBX13RenderingTestEPKcS5_NS_10shared_ptrINS2_18LuaSourceContainerEEEiEclEPS3_S5_S5_S8_i
void __fastcall boost::_mfi::mf4<void,RBX::RenderingTest,char const*,char const*,boost::shared_ptr<RBX::LuaSourceContainer>,int>::operator()(
        const boost::_mfi::mf4<void,RBX::RenderingTest,const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int> *this,
        RBX::RenderingTest *p,
        const char *a1,
        const char *a2,
        boost::shared_ptr<RBX::LuaSourceContainer> a3)
{
  boost::_mfi::mf4<void,RBX::RenderingTest,const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int>::F f; // rbx
  _QWORD *v6; // rsi
  volatile signed __int32 *v7; // rax
  volatile signed __int32 *v8; // rbx
  __int64 v9; // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v10; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v6 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf4<void,RBX::RenderingTest,const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int>::F *)((char *)f + *v6 - 1);
  v9 = *(_QWORD *)a3.px;
  v7 = (volatile signed __int32 *)*((_QWORD *)a3.px + 1);
  v10 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, const char *, const char *, __int64 *, _QWORD))f)(v6, a1, a2, &v9, LODWORD(a3.pn.pi_));
  v8 = v10;
  if ( v10 && !_InterlockedSub(v10 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
    if ( !_InterlockedSub(v8 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
  }
}


// Address: 0x1c29af0 | Name: _ZNK5boost4_mfi3mf1IvN3RBX11VehicleSeatENS_10shared_ptrINS2_8InstanceEEEEclEPS3_S6_
void __fastcall boost::_mfi::mf1<void,RBX::VehicleSeat,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::VehicleSeat,boost::shared_ptr<RBX::Instance> > *this,
        RBX::VehicleSeat *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::VehicleSeat,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::VehicleSeat,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1c29f50 | Name: _ZNK5boost4_mfi3mf1IvN3RBX8SeatImplINS2_12PartInstanceEEENS_10shared_ptrINS2_8InstanceEEEEclEPS5_S8_
void __fastcall boost::_mfi::mf1<void,RBX::SeatImpl<RBX::PartInstance>,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::SeatImpl<RBX::PartInstance>,boost::shared_ptr<RBX::Instance> > *this,
        RBX::SeatImpl<RBX::PartInstance> *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::SeatImpl<RBX::PartInstance>,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::SeatImpl<RBX::PartInstance>,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1c2ab60 | Name: _ZNK5boost4_mfi3mf2IvN3RBX8SeatImplINS2_12PartInstanceEEENS_10shared_ptrINS2_8InstanceEEEPNS2_4WeldEEclEPS5_S8_SA_
void __fastcall boost::_mfi::mf2<void,RBX::SeatImpl<RBX::PartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Weld *>::operator()(
        const boost::_mfi::mf2<void,RBX::SeatImpl<RBX::PartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Weld *> *this,
        RBX::SeatImpl<RBX::PartInstance> *p,
        boost::shared_ptr<RBX::Instance> a1,
        RBX::Weld *a2)
{
  boost::_mfi::mf2<void,RBX::SeatImpl<RBX::PartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Weld *>::F f; // rbx
  _QWORD *v5; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v7; // rbx
  int (**v8)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf2<void,RBX::SeatImpl<RBX::PartInstance>,boost::shared_ptr<RBX::Instance>,RBX::Weld *>::F *)((char *)f + *v5 - 1);
  v8 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v9 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), boost::detail::sp_counted_base *))f)(v5, &v8, a1.pn.pi_);
  v7 = v9;
  if ( v9 && !_InterlockedSub(v9 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    if ( !_InterlockedSub(v7 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  }
}


// Address: 0x1cd11e0 | Name: _ZNK5boost4_mfi3mf3IvN3RBX21ThirdPartyUserServiceENS2_11InputObject13UserInputTypeENS_8functionIFviEEENS6_IFvNSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEEEEEEclEPS3_S5_S8_SH_
void __fastcall boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>::operator()(
        const boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> > *this,
        RBX::ThirdPartyUserService *p,
        unsigned int a1,
        __int64 *a4,
        __int64 *a5)
{
  boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >::F f; // r15
  _QWORD *v8; // rbx
  __int64 v9; // rax
  __int64 v10; // rax
  void (__fastcall *v11)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  __int64 v13; // [rsp+8h] [rbp-60h] BYREF
  __int128 v14; // [rsp+10h] [rbp-58h] BYREF
  __int64 v15; // [rsp+20h] [rbp-48h]
  __int64 v16; // [rsp+28h] [rbp-40h] BYREF
  __int128 v17; // [rsp+30h] [rbp-38h] BYREF
  __int64 v18; // [rsp+40h] [rbp-28h]

  f = this->f_;
  v8 = (int (***)(void))((char *)&p->_vptr$EventSource + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >::F *)((char *)f + *v8 - 1);
  v16 = 0;
  v9 = *a4;
  if ( *a4 )
  {
    v16 = *a4;
    if ( (v9 & 1) != 0 )
    {
      v18 = a4[3];
      v17 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v17, 0);
    }
  }
  v13 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v13 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v15 = a5[3];
      v14 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v14, 0);
    }
  }
  ((void (__fastcall *)(_QWORD *, _QWORD, __int64 *, __int64 *))f)(v8, a1, &v16, &v13);
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14, &v14, 2);
    }
    v13 = 0;
  }
  if ( v16 && (v16 & 1) == 0 )
  {
    v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
    if ( v12 )
      v12(&v17, &v17, 2);
  }
}


// Address: 0x1eb84a0 | Name: _ZNK5boost4_mfi3mf5IvN3RBX14NavigationPathEP9dtNavMeshRKN3G3D7Vector3ES9_NS_8functionIFvvEEENSA_IFvNSt3__112basic_stringIcNSD_11char_traitsIcEENSD_9allocatorIcEEEEEEEE4callINS_10shared_ptrIS3_EES5_S8_S8_SC_SL_EEvRT_PKvRT0_RT1_RT2_RT3_RT4_
void __fastcall boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,G3D::Vector3 const&,G3D::Vector3 const&,boost::function<void ()(void)>,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::NavigationPath>,dtNavMesh *,G3D::Vector3 const,G3D::Vector3 const,boost::function<void ()(void)>,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,const G3D::Vector3 &,const G3D::Vector3 &,boost::function<void ()>,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::NavigationPath> *u,
        const void *a3,
        dtNavMesh **b1,
        const G3D::Vector3 *b2,
        const G3D::Vector3 *b3,
        boost::function<void ()>_0 *b4,
        boost::function<void (std::string)>_0 *b5)
{
  boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,const G3D::Vector3 &,const G3D::Vector3 &,boost::function<void ()>,boost::function<void (std::string)> >::F f; // rbp
  _QWORD *v11; // r13
  __int64 v12; // r12
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v14; // rax
  void (__fastcall *v15)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v16)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::function::vtable_base *v17; // [rsp+8h] [rbp-70h] BYREF
  boost::detail::function::function_buffer functor; // [rsp+10h] [rbp-68h] BYREF
  boost::detail::function::vtable_base *v19; // [rsp+28h] [rbp-50h] BYREF
  boost::detail::function::function_buffer v20[3]; // [rsp+30h] [rbp-48h] BYREF

  f = this->f_;
  v11 = (boost::weak_ptr<RBX::NavigationPath>::element_type **)((char *)&u->px->weak_this_.px
                                                              + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,const G3D::Vector3 &,const G3D::Vector3 &,boost::function<void ()>,boost::function<void (std::string)> >::F *)((char *)f + *v11 - 1);
  v12 = (__int64)*b1;
  v19 = 0;
  vtable = b4->vtable;
  if ( b4->vtable )
  {
    v19 = b4->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      v20[0] = b4->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b4->functor,
        v20,
        0);
  }
  v17 = 0;
  v14 = b5->vtable;
  if ( b5->vtable )
  {
    v17 = b5->vtable;
    if ( ((unsigned __int8)v14 & 1) != 0 )
      functor = b5->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v14 & 0xFFFFFFFFFFFFFFFELL))(
        &b5->functor,
        &functor,
        0);
  }
  ((void (__fastcall *)(_QWORD *, __int64, const G3D::Vector3 *, const G3D::Vector3 *, boost::detail::function::vtable_base **, boost::detail::function::vtable_base **))f)(
    v11,
    v12,
    b2,
    b3,
    &v19,
    &v17);
  if ( v17 )
  {
    if ( ((unsigned __int8)v17 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&functor, &functor, 2);
    }
    v17 = 0;
  }
  if ( v19 && ((unsigned __int8)v19 & 1) == 0 )
  {
    v16 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v19 & 0xFFFFFFFFFFFFFFFELL);
    if ( v16 )
      v16(v20, v20, 2);
  }
}


// Address: 0x1eb9910 | Name: _ZNK5boost4_mfi3mf5IvN3RBX14NavigationPathEP9dtNavMeshiRKNS_10shared_ptrIKNS2_8PathDataEEENS_8functionIFviEEENSC_IFvNSt3__112basic_stringIcNSF_11char_traitsIcEENSF_9allocatorIcEEEEEEEE4callINS6_IS3_EES5_iSA_SE_SN_EEvRT_PKvRT0_RT1_RT2_RT3_RT4_
void __fastcall boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,int,boost::shared_ptr<RBX::PathData const> const&,boost::function<void ()(int)>,boost::function<void ()(std::string)>>::call<boost::shared_ptr<RBX::NavigationPath>,dtNavMesh *,int,boost::shared_ptr<RBX::PathData const> const,boost::function<void ()(int)>,boost::function<void ()(std::string)>>(
        const boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,int,const boost::shared_ptr<const RBX::PathData> &,boost::function<void (int)>,boost::function<void (std::string)> > *this,
        boost::shared_ptr<RBX::NavigationPath> *u,
        const void *a3,
        dtNavMesh **b1,
        unsigned int *b2,
        const boost::shared_ptr<const RBX::PathData> *b3,
        boost::function<void (int)>_0 *b4,
        boost::function<void (std::string)>_0 *b5)
{
  boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,int,const boost::shared_ptr<const RBX::PathData> &,boost::function<void (int)>,boost::function<void (std::string)> >::F f; // r13
  _QWORD *v10; // rbx
  __int64 v11; // r15
  unsigned int v12; // r12d
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v14; // rax
  void (__fastcall *v15)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v16)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::function::vtable_base *v17; // [rsp+8h] [rbp-70h] BYREF
  boost::detail::function::function_buffer functor; // [rsp+10h] [rbp-68h] BYREF
  boost::detail::function::vtable_base *v19; // [rsp+28h] [rbp-50h] BYREF
  boost::detail::function::function_buffer v20[3]; // [rsp+30h] [rbp-48h] BYREF

  f = this->f_;
  v10 = (boost::weak_ptr<RBX::NavigationPath>::element_type **)((char *)&u->px->weak_this_.px
                                                              + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,int,const boost::shared_ptr<const RBX::PathData> &,boost::function<void (int)>,boost::function<void (std::string)> >::F *)((char *)f + *v10 - 1);
  v11 = (__int64)*b1;
  v12 = *b2;
  v19 = 0;
  vtable = b4->vtable;
  if ( b4->vtable )
  {
    v19 = b4->vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      v20[0] = b4->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &b4->functor,
        v20,
        0);
  }
  v17 = 0;
  v14 = b5->vtable;
  if ( b5->vtable )
  {
    v17 = b5->vtable;
    if ( ((unsigned __int8)v14 & 1) != 0 )
      functor = b5->functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v14 & 0xFFFFFFFFFFFFFFFELL))(
        &b5->functor,
        &functor,
        0);
  }
  ((void (__fastcall *)(_QWORD *, __int64, _QWORD, const boost::shared_ptr<const RBX::PathData> *, boost::detail::function::vtable_base **, boost::detail::function::vtable_base **))f)(
    v10,
    v11,
    v12,
    b3,
    &v19,
    &v17);
  if ( v17 )
  {
    if ( ((unsigned __int8)v17 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&functor, &functor, 2);
    }
    v17 = 0;
  }
  if ( v19 && ((unsigned __int8)v19 & 1) == 0 )
  {
    v16 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v19 & 0xFFFFFFFFFFFFFFFELL);
    if ( v16 )
      v16(v20, v20, 2);
  }
}


// Address: 0x1f8d650 | Name: _ZNK5boost4_mfi3mf3IvN3RBX8Graphics10RenderViewENS_10shared_ptrIN3G3D6GImageEEENS_8weak_ptrINS2_9DataModelEEElEclEPS4_S8_SB_l
void __fastcall boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>::operator()(
        const boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long> *this,
        RBX::Graphics::RenderView *p,
        boost::shared_ptr<G3D::GImage> a1,
        boost::weak_ptr<RBX::DataModel> a2)
{
  boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>::F f; // rbx
  _QWORD *v5; // rsi
  G3D::uint8 *m_byte; // rax
  __int64 v7; // rax
  __int64 v8; // rdi
  volatile signed __int32 *v9; // rbx
  int (**v10)(void); // [rsp+8h] [rbp-30h] BYREF
  __int64 v11; // [rsp+10h] [rbp-28h]
  int (**v12)(void); // [rsp+18h] [rbp-20h] BYREF
  volatile signed __int32 *v13; // [rsp+20h] [rbp-18h]

  f = this->f_;
  v5 = (int (***)(void))((char *)&p->_vptr$ViewBase + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>::F *)((char *)f + *v5 - 1);
  v12 = a1.px->_vptr$GImage;
  m_byte = a1.px->m_byte;
  v13 = (volatile signed __int32 *)m_byte;
  if ( m_byte )
    _InterlockedAdd((volatile signed __int32 *)m_byte + 2, 1u);
  v10 = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(_QWORD *)&a1.pn.pi_->use_count_;
  v11 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void), int (***)(void), boost::weak_ptr<RBX::DataModel>::element_type *))f)(
    v5,
    &v12,
    &v10,
    a2.px);
  v8 = v11;
  if ( v11 && !_InterlockedSub((volatile signed __int32 *)(v11 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 24LL))(v8);
  v9 = v13;
  if ( v13 && !_InterlockedSub(v13 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
    if ( !_InterlockedSub(v9 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
  }
}


// Address: 0x1fe2550 | Name: _ZNK5boost4_mfi3mf1IvN3RBX8Graphics12SceneUpdaterENS_10shared_ptrINS2_8InstanceEEEEclEPS4_S7_
void __fastcall boost::_mfi::mf1<void,RBX::Graphics::SceneUpdater,boost::shared_ptr<RBX::Instance>>::operator()(
        const boost::_mfi::mf1<void,RBX::Graphics::SceneUpdater,boost::shared_ptr<RBX::Instance> > *this,
        RBX::Graphics::SceneUpdater *p,
        boost::shared_ptr<RBX::Instance> a1)
{
  boost::_mfi::mf1<void,RBX::Graphics::SceneUpdater,boost::shared_ptr<RBX::Instance> >::F f; // rcx
  _QWORD *v4; // rsi
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  volatile signed __int32 *v6; // rbx
  int (**v7)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v4 = (_QWORD *)((char *)p + *((_QWORD *)&this->f_ + 1));
  if ( ((__int64)this->f_ & 1) != 0 )
    f = *(boost::_mfi::mf1<void,RBX::Graphics::SceneUpdater,boost::shared_ptr<RBX::Instance> >::F *)((char *)f + *v4 - 1);
  v7 = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  v8 = (volatile signed __int32 *)px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  ((void (__fastcall *)(_QWORD *, int (***)(void)))f)(v4, &v7);
  v6 = v8;
  if ( v8 && !_InterlockedSub(v8 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x26a0120 | Name: _ZNK5boost4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS_4asio2ip23basic_resolver_iteratorINSD_3tcpEEEE4callINSt3__110shared_ptrIS7_EESA_SG_EEvRT_PKvRT0_RT1_
void __fastcall boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::call<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>,boost::system::error_code const,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
        const boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *this,
        std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> *u,
        const void *a3,
        const boost::system::error_code *b1,
        boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> *b2)
{
  boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >::F f; // rbx
  _QWORD *v6; // rdi
  volatile signed __int64 *cntrl; // rax
  std::__shared_weak_count *v8; // rbx
  std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >::element_type *ptr; // [rsp+0h] [rbp-28h] BYREF
  std::__shared_weak_count *v10; // [rsp+8h] [rbp-20h]
  size_t index; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v6 = (char *)u->__ptr_ + *((_QWORD *)&this->f_ + 1);
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >::F *)((char *)f + *v6 - 1);
  ptr = b2->values_.__ptr_;
  cntrl = (volatile signed __int64 *)b2->values_.__cntrl_;
  v10 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  index = b2->index_;
  ((void (__fastcall *)(_QWORD *, const boost::system::error_code *, std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >::element_type **))f)(
    v6,
    b1,
    &ptr);
  v8 = v10;
  if ( v10 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
  }
}


// Address: 0x26bb550 | Name: _ZNK5boost4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS_4asio2ip23basic_resolver_iteratorINSC_3tcpEEEE4callINSt3__110shared_ptrIS6_EES9_SF_EEvRT_PKvRT0_RT1_
void __fastcall boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::call<std::shared_ptr<web::http::client::details::asio_context>,boost::system::error_code const,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
        const boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *this,
        std::shared_ptr<web::http::client::details::asio_context> *u,
        const void *a3,
        const boost::system::error_code *b1,
        boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> *b2)
{
  boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >::F f; // rbx
  _QWORD *v6; // rdi
  volatile signed __int64 *cntrl; // rax
  std::__shared_weak_count *v8; // rbx
  std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >::element_type *ptr; // [rsp+0h] [rbp-28h] BYREF
  std::__shared_weak_count *v10; // [rsp+8h] [rbp-20h]
  size_t index; // [rsp+10h] [rbp-18h]

  f = this->f_;
  v6 = (char *)u->__ptr_ + *((_QWORD *)&this->f_ + 1);
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >::F *)((char *)f + *v6 - 1);
  ptr = b2->values_.__ptr_;
  cntrl = (volatile signed __int64 *)b2->values_.__cntrl_;
  v10 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  index = b2->index_;
  ((void (__fastcall *)(_QWORD *, const boost::system::error_code *, std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >::element_type **))f)(
    v6,
    b1,
    &ptr);
  v8 = v10;
  if ( v10 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
  }
}


