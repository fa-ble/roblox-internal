// Address: 0xd9e590 | Name: _ZN5boost6detail20sp_pointer_constructIKNS_16exception_detail10clone_baseENS2_10clone_implINS2_10bad_alloc_EEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::exception_detail::clone_base const,boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>>(
        boost::shared_ptr<const boost::exception_detail::clone_base> *ppx,
        boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2875648;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xd9eca0 | Name: _ZN5boost6detail20sp_pointer_constructIKNS_16exception_detail10clone_baseENS2_10clone_implINS2_14bad_exception_EEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::exception_detail::clone_base const,boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>>(
        boost::shared_ptr<const boost::exception_detail::clone_base> *ppx,
        boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2875818;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xdb3b00 | Name: _ZN5boost10shared_ptrIN11CWebService7JobItemEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<CWebService::JobItem>::shared_ptr<CWebService::JobItem>(
        boost::shared_ptr<CWebService::JobItem> *this,
        CWebService::JobItem *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<CWebService::JobItem>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xdb51a0 | Name: _ZN5boost10shared_ptrINS_6detail16thread_data_baseEED2Ev
void __fastcall boost::shared_ptr<boost::detail::thread_data_base>::~shared_ptr(
        boost::shared_ptr<boost::detail::thread_data_base> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xdb75c0 | Name: _ZN5boost10shared_ptrIN3RBX10Reflection5TupleEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Reflection::Tuple>::shared_ptr<RBX::Reflection::Tuple>(
        boost::shared_ptr<RBX::Reflection::Tuple> *this,
        RBX::Reflection::Tuple *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Reflection::Tuple>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xdc0b00 | Name: _ZN5boost6detail20sp_pointer_constructIKNS_16exception_detail10clone_baseES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::exception_detail::clone_base const,boost::exception_detail::clone_base const>(
        boost::shared_ptr<const boost::exception_detail::clone_base> *ppx,
        const boost::exception_detail::clone_base *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28768A0;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xdcb210 | Name: _ZN5boost23atomic_compare_exchangeINS_6detail12shared_stateINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEEEEbPNS_10shared_ptrIT_EESE_SD_
__int64 __fastcall boost::atomic_compare_exchange<boost::detail::shared_state<std::string>>(
        unsigned __int64 p,
        boost::shared_ptr<boost::detail::shared_state<std::string > > *v,
        boost::shared_ptr<boost::detail::shared_state<std::string > > w)
{
  unsigned __int64 v3; // rbx
  unsigned int v4; // r14d
  boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *v5; // rax
  boost::detail::sp_counted_base *v6; // rcx
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v8; // rcx
  boost::detail::sp_counted_base *v10; // rax
  boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *px; // [rsp+8h] [rbp-60h]
  __m128i v12; // [rsp+10h] [rbp-58h] BYREF
  struct timespec requested_time; // [rsp+20h] [rbp-48h] BYREF

  px = w.px;
  v3 = p % 0x29;
  if ( _InterlockedExchange(&dword_29F1450[p % 0x29], 1) )
  {
    v4 = 0;
    v12 = _mm_slli_si128((__m128i)0x3E8uLL, 8);
    do
    {
      if ( v4 >= 4 )
      {
        if ( v4 > 0xF )
        {
          if ( v4 < 0x20 || (v4 & 1) != 0 )
          {
            sched_yield();
          }
          else
          {
            requested_time = (struct timespec)_mm_load_si128(&v12);
            nanosleep(&requested_time, 0);
          }
        }
        else
        {
          _mm_pause();
        }
      }
      ++v4;
    }
    while ( _InterlockedExchange(&dword_29F1450[v3], 1) );
  }
  v5 = *(boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type **)p;
  v6 = *(boost::detail::sp_counted_base **)(p + 8);
  if ( *(boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type **)p == v->px && v6 == v->pn.pi_ )
  {
    *(_QWORD *)p = px->_vptr$shared_state_base;
    px->_vptr$shared_state_base = (int (**)(void))v5;
    v10 = (boost::detail::sp_counted_base *)px->weak_this_.px;
    v8 = *(boost::detail::sp_counted_base **)(p + 8);
    px->weak_this_.px = (boost::weak_ptr<boost::detail::shared_state_base>::element_type *)v8;
    *(_QWORD *)(p + 8) = v10;
    dword_29F1450[v3] = 0;
    LOBYTE(v8) = 1;
  }
  else
  {
    if ( v6 )
      _InterlockedAdd(&v6->use_count_, 1u);
    dword_29F1450[v3] = 0;
    v->px = v5;
    pi = v->pn.pi_;
    v->pn.pi_ = v6;
    if ( pi )
    {
      if ( !_InterlockedSub(&pi->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
    LODWORD(v8) = 0;
  }
  return (unsigned int)v8;
}


// Address: 0xdcc9d0 | Name: _ZNK5boost10shared_ptrIKNS_16exception_detail10clone_baseEE3getEv
boost::shared_ptr<const boost::exception_detail::clone_base>::element_type *__fastcall boost::shared_ptr<boost::exception_detail::clone_base const>::get(
        const boost::shared_ptr<const boost::exception_detail::clone_base> *this)
{
  return this->px;
}


// Address: 0xdcc9e0 | Name: _ZN5boost6detail20sp_pointer_constructINS0_12shared_stateINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEESA_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::shared_state<std::string>,boost::detail::shared_state<std::string>>(
        boost::shared_ptr<boost::detail::shared_state<std::string > > *ppx,
        boost::detail::shared_state<std::string > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2878580;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::shared_state_base>::_internal_accept_owner<boost::detail::shared_state<std::string>,boost::detail::shared_state<std::string>>(
      &p->boost::enable_shared_from_this<boost::detail::shared_state_base>,
      ppx,
      p);
}


// Address: 0xdcfaf0 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvPFvRKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEERKNS_10shared_ptrIN3RBX9DataModelEEElSE_RKNSF_IKNS_9unordered13unordered_mapISC_NSG_10Reflection7VariantENS_4hashISC_EENS6_8equal_toISC_EENSA_INS6_4pairISD_SO_EEEEEEEENSG_5TimerILNSG_4Time12SampleMethodE0EEEENS4_5list6INS4_5valueISC_EENS18_ISI_EENS18_IlEES19_NS18_ISY_EENS18_IS14_EEEEEEEEEEvPNSF_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(std::string const&,boost::shared_ptr<RBX::DataModel> const&,long,std::string const&,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const> const&,RBX::Timer<(RBX::Time::SampleMethod)0>),boost::_bi::list6<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<RBX::Timer<(RBX::Time::SampleMethod)0>>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const std::string &,const boost::shared_ptr<RBX::DataModel> &,long,const std::string &,const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > &,RBX::Timer<RBX::Time::Fast>),boost::_bi::list6<boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<RBX::Timer<RBX::Time::Fast> > > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2879038;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(std::string const&,boost::shared_ptr<RBX::DataModel> const&,long,std::string const&,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const> const&,RBX::Timer<(RBX::Time::SampleMethod)0>),boost::_bi::list6<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<RBX::Timer<(RBX::Time::SampleMethod)0>>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xdd2290 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIKNS2_9unordered13unordered_mapINSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEN3RBX10Reflection7VariantENS2_4hashISC_EENS6_8equal_toISC_EENSA_INS6_4pairIKSC_SF_EEEEEEEEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>::construct_func(
        const char *src,
        char *dest)
{
  __int64 v2; // rax

  *(_QWORD *)dest = *(_QWORD *)src;
  v2 = *((_QWORD *)src + 1);
  *((_QWORD *)dest + 1) = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
}


// Address: 0xdd3c40 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_9function0IvEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::function0<void>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::function0<void> > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2879508;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::function0<void>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xdd43b0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX19RCCJobProfilingInfoES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::RCCJobProfilingInfo,RBX::RCCJobProfilingInfo>(
        boost::shared_ptr<RBX::RCCJobProfilingInfo> *ppx,
        RBX::RCCJobProfilingInfo *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2879700;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xdd7c80 | Name: _ZNK3RBX13RCCMonitoring11isCloudEditEv
bool __fastcall RBX::RCCMonitoring::isCloudEdit(const RBX::RCCMonitoring *this)
{
  return *(_DWORD *)(*((_QWORD *)this + 15) + 16LL) == 3;
}


// Address: 0xdd7c90 | Name: _ZNK3RBX13RCCMonitoring19isCloudEditPlayTestEv
bool __fastcall RBX::RCCMonitoring::isCloudEditPlayTest(const RBX::RCCMonitoring *this)
{
  return *(_DWORD *)(*((_QWORD *)this + 15) + 16LL) == 4;
}


// Address: 0xde3420 | Name: _ZN5boost10shared_ptrINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEC2IS7_EEPT_
void __fastcall boost::shared_ptr<std::string>::shared_ptr<std::string>(
        boost::shared_ptr<std::string > *this,
        std::string *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<std::string>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xde3890 | Name: _ZN5boost10shared_ptrIbE5resetIbEEvPT_
void __fastcall boost::shared_ptr<bool>::reset<bool>(boost::shared_ptr<bool> *this, bool *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<bool,bool>((boost::shared_ptr<bool> *)pn, p, &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<bool> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xde3940 | Name: _ZN5boost6detail20sp_pointer_constructIbbEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<bool,bool>(
        boost::shared_ptr<bool> *ppx,
        bool *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2879778;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xe4b3b0 | Name: _ZN5boost10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SC_EEEEEEEC2ISL_EEPT_
void __fastcall boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>(
        boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *this,
        boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>(
    &v4,
    p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xe4d2e0 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIKNSt3__16vectorIN3RBX10Reflection7VariantENS4_9allocatorIS8_EEEEEEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>>::construct_func(
        const char *src,
        char *dest)
{
  __int64 v2; // rax

  *(_QWORD *)dest = *(_QWORD *)src;
  v2 = *((_QWORD *)src + 1);
  *((_QWORD *)dest + 1) = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
}


// Address: 0xe52cb0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX11BloomEffectES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::BloomEffect,RBX::BloomEffect>(
        boost::shared_ptr<RBX::BloomEffect> *ppx,
        RBX::BloomEffect *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_287CE38;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BloomEffect,RBX::BloomEffect>(
      &p->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
      ppx,
      p);
}


// Address: 0xe5d6c0 | Name: _ZNK5boost15program_options18option_description8semanticEv
_QWORD *__fastcall boost::program_options::option_description::semantic(
        _QWORD *a1,
        const boost::program_options::option_description *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 10);
  v2 = *((_QWORD *)this + 11);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
  return a1;
}


// Address: 0xe5fc00 | Name: _ZN5boost10shared_ptrINS_15program_options19options_descriptionEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<boost::program_options::options_description>::shared_ptr<boost::program_options::options_description>(
        boost::shared_ptr<boost::program_options::options_description> *this,
        boost::program_options::options_description *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<boost::program_options::options_description>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xe61690 | Name: _ZN5boost6detail20sp_pointer_constructIKNS_15program_options14value_semanticES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::program_options::value_semantic const,boost::program_options::value_semantic const>(
        boost::shared_ptr<const boost::program_options::value_semantic>_0 *ppx,
        const boost::program_options::value_semantic *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_287DA48;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xe61770 | Name: _ZN5boost6detail20sp_pointer_constructINS_15program_options18option_descriptionES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::program_options::option_description,boost::program_options::option_description>(
        boost::shared_ptr<boost::program_options::option_description> *ppx,
        boost::program_options::option_description *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_287DAA8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xebfc10 | Name: _ZN5boost10shared_ptrIN3RBX8Security22ReplicatorCryptoSystemEE5resetINS2_29ReplicatorCryptoSystemOpenSSLEEEvPT_
void __fastcall boost::shared_ptr<RBX::Security::ReplicatorCryptoSystem>::reset<RBX::Security::ReplicatorCryptoSystemOpenSSL>(
        boost::shared_ptr<RBX::Security::ReplicatorCryptoSystem> *this,
        RBX::Security::ReplicatorCryptoSystemOpenSSL *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Security::ReplicatorCryptoSystem,RBX::Security::ReplicatorCryptoSystemOpenSSL>(
    (boost::shared_ptr<RBX::Security::ReplicatorCryptoSystem> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Security::ReplicatorCryptoSystem> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xebfd00 | Name: _ZN5boost10shared_ptrIN3RBX8Security22ReplicatorCryptoSystemEED2Ev
void __fastcall boost::shared_ptr<RBX::Security::ReplicatorCryptoSystem>::~shared_ptr(
        boost::shared_ptr<RBX::Security::ReplicatorCryptoSystem> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xec1420 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIN3RBX8InstanceEEEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<RBX::Instance>>::construct_func(
        const char *src,
        char *dest)
{
  __int64 v2; // rax

  *(_QWORD *)dest = *(_QWORD *)src;
  v2 = *((_QWORD *)src + 1);
  *((_QWORD *)dest + 1) = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
}


// Address: 0xec2c30 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Security22ReplicatorCryptoSystemENS3_29ReplicatorCryptoSystemOpenSSLEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Security::ReplicatorCryptoSystem,RBX::Security::ReplicatorCryptoSystemOpenSSL>(
        boost::shared_ptr<RBX::Security::ReplicatorCryptoSystem> *ppx,
        RBX::Security::ReplicatorCryptoSystemOpenSSL *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2880368;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::Security::ReplicatorCryptoSystem>::_internal_accept_owner<RBX::Security::ReplicatorCryptoSystem,RBX::Security::ReplicatorCryptoSystemOpenSSL>(
      &p->boost::enable_shared_from_this<RBX::Security::ReplicatorCryptoSystem>,
      ppx,
      p);
}


// Address: 0xecc0c0 | Name: _ZN3RBX7Network16ClientReplicator33hasEnoughMemoryToReceiveInstancesEv
bool __fastcall RBX::Network::ClientReplicator::hasEnoughMemoryToReceiveInstances(RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 3860);
  if ( *(int *)(v1 + 644) > 0 )
    return 0;
  if ( *(_BYTE *)(v1 + 670) )
    return 0;
  return *((_DWORD *)this + 7792) > 4;
}


// Address: 0xecc0f0 | Name: _ZN3RBX7Network16ClientReplicator6needGCEv
bool __fastcall RBX::Network::ClientReplicator::needGC(RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rcx
  bool result; // al

  v1 = *((_QWORD *)this + 3860);
  result = 1;
  if ( *(int *)(v1 + 644) <= 0 && !*(_BYTE *)(v1 + 670) )
    return *((_DWORD *)this + 7792) < 3;
  return result;
}


// Address: 0xecf580 | Name: _ZN5boost10shared_ptrIN3RBX7Network16ClientReplicator5GCJobEED2Ev
void __fastcall boost::shared_ptr<RBX::Network::ClientReplicator::GCJob>::~shared_ptr(
        boost::shared_ptr<RBX::Network::ClientReplicator::GCJob> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xecf730 | Name: _ZN5boost10shared_ptrIN3RBX7Network16ClientReplicator5GCJobEE5resetIS4_EEvPT_
void __fastcall boost::shared_ptr<RBX::Network::ClientReplicator::GCJob>::reset<RBX::Network::ClientReplicator::GCJob>(
        boost::shared_ptr<RBX::Network::ClientReplicator::GCJob> *this,
        RBX::Network::ClientReplicator::GCJob *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Network::ClientReplicator::GCJob,RBX::Network::ClientReplicator::GCJob>(
    (boost::shared_ptr<RBX::Network::ClientReplicator::GCJob> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Network::ClientReplicator::GCJob> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xecf9e0 | Name: _ZN5boost10shared_ptrINS_9unordered13unordered_mapINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SC_EEEEEEEC2ISL_EEPT_
void __fastcall boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>(
        boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *this,
        boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>(
    &v4,
    p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xecfa80 | Name: _ZN5boost10shared_ptrINSt3__16vectorIN3RBX10Reflection7VariantENS1_9allocatorIS5_EEEEEC2IS8_EEPT_
void __fastcall boost::shared_ptr<std::vector<RBX::Reflection::Variant>>::shared_ptr<std::vector<RBX::Reflection::Variant>>(
        boost::shared_ptr<std::vector<RBX::Reflection::Variant> > *this,
        std::vector<RBX::Reflection::Variant> *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<std::vector<RBX::Reflection::Variant>>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xed6670 | Name: _ZN5boost10shared_ptrIN3RBX7Network15PhysicsSenderS2EEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Network::PhysicsSenderS2>::shared_ptr<RBX::Network::PhysicsSenderS2>(
        boost::shared_ptr<RBX::Network::PhysicsSenderS2> *this,
        RBX::Network::PhysicsSenderS2 *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Network::PhysicsSenderS2>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xed67e0 | Name: _ZN5boost10shared_ptrIN3RBX7Network17PhysicsReceiverS2EEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Network::PhysicsReceiverS2>::shared_ptr<RBX::Network::PhysicsReceiverS2>(
        boost::shared_ptr<RBX::Network::PhysicsReceiverS2> *this,
        RBX::Network::PhysicsReceiverS2 *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Network::PhysicsReceiverS2>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xed69e0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network16ClientReplicator5GCJobES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::ClientReplicator::GCJob,RBX::Network::ClientReplicator::GCJob>(
        boost::shared_ptr<RBX::Network::ClientReplicator::GCJob> *ppx,
        RBX::Network::ClientReplicator::GCJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2881928;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::ClientReplicator::GCJob,RBX::Network::ClientReplicator::GCJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xedb750 | Name: _ZN3RBX7Network17ConcurrentRakPeer7rawPeerEv
RakNet::RakPeerInterface *__fastcall RBX::Network::ConcurrentRakPeer::rawPeer(RBX::Network::ConcurrentRakPeer *this)
{
  return this->peer.px;
}


// Address: 0xedb760 | Name: _ZNK3RBX7Network17ConcurrentRakPeer7rawPeerEv
const RakNet::RakPeerInterface *__fastcall RBX::Network::ConcurrentRakPeer::rawPeer(
        const RBX::Network::ConcurrentRakPeer *this)
{
  return this->peer.px;
}


// Address: 0xedba10 | Name: _ZN5boost10shared_ptrIN3RBX7Network17ConcurrentRakPeer9PacketJobEE5resetIS4_EEvPT_
void __fastcall boost::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob>::reset<RBX::Network::ConcurrentRakPeer::PacketJob>(
        boost::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob> *this,
        RBX::Network::ConcurrentRakPeer::PacketJob *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Network::ConcurrentRakPeer::PacketJob,RBX::Network::ConcurrentRakPeer::PacketJob>(
    (boost::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xedbc50 | Name: _ZN5boost10shared_ptrIN6RakNet16RakPeerInterfaceEED2Ev
void __fastcall boost::shared_ptr<RakNet::RakPeerInterface>::~shared_ptr(
        boost::shared_ptr<RakNet::RakPeerInterface> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xedbc90 | Name: _ZN5boost10shared_ptrIN3RBX7Network17ConcurrentRakPeer14StatsUpdateJobEE5resetIS4_EEvPT_
void __fastcall boost::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob>::reset<RBX::Network::ConcurrentRakPeer::StatsUpdateJob>(
        boost::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob> *this,
        RBX::Network::ConcurrentRakPeer::StatsUpdateJob *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Network::ConcurrentRakPeer::StatsUpdateJob,RBX::Network::ConcurrentRakPeer::StatsUpdateJob>(
    (boost::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xedbf70 | Name: _ZN5boost10shared_ptrIN3RBX7Network17ConcurrentRakPeer14StatsUpdateJobEED2Ev
void __fastcall boost::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob>::~shared_ptr(
        boost::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xedbfb0 | Name: _ZN5boost10shared_ptrIN3RBX7Network17ConcurrentRakPeer9PacketJobEED2Ev
void __fastcall boost::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob>::~shared_ptr(
        boost::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xede330 | Name: _ZN5boost6detail20sp_pointer_constructIN6RakNet16RakPeerInterfaceES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RakNet::RakPeerInterface,RakNet::RakPeerInterface>(
        boost::shared_ptr<RakNet::RakPeerInterface> *ppx,
        RakNet::RakPeerInterface *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2881AA8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xede410 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network17ConcurrentRakPeer9PacketJobES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::ConcurrentRakPeer::PacketJob,RBX::Network::ConcurrentRakPeer::PacketJob>(
        boost::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob> *ppx,
        RBX::Network::ConcurrentRakPeer::PacketJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2881B08;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::ConcurrentRakPeer::PacketJob,RBX::Network::ConcurrentRakPeer::PacketJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xede5c0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network17ConcurrentRakPeer14StatsUpdateJobES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::ConcurrentRakPeer::StatsUpdateJob,RBX::Network::ConcurrentRakPeer::StatsUpdateJob>(
        boost::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob> *ppx,
        RBX::Network::ConcurrentRakPeer::StatsUpdateJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2881B68;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::ConcurrentRakPeer::StatsUpdateJob,RBX::Network::ConcurrentRakPeer::StatsUpdateJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xef8f10 | Name: _ZN5boost10shared_ptrIN3RBX15GamePerfMonitorEED2Ev
void __fastcall boost::shared_ptr<RBX::GamePerfMonitor>::~shared_ptr(boost::shared_ptr<RBX::GamePerfMonitor> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xefb110 | Name: _ZN5boost10shared_ptrINS_10filesystem6detail11dir_itr_impEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<boost::filesystem::detail::dir_itr_imp>::shared_ptr<boost::filesystem::detail::dir_itr_imp>(
        boost::shared_ptr<boost::filesystem::detail::dir_itr_imp> *this,
        boost::filesystem::detail::dir_itr_imp *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<boost::filesystem::detail::dir_itr_imp>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf039a0 | Name: _ZN5boost10shared_ptrIN3RBX15GamePerfMonitorEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::GamePerfMonitor>::shared_ptr<RBX::GamePerfMonitor>(
        boost::shared_ptr<RBX::GamePerfMonitor> *this,
        RBX::GamePerfMonitor *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::GamePerfMonitor>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf11eb0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX15GamePerfMonitorES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::GamePerfMonitor,RBX::GamePerfMonitor>(
        boost::shared_ptr<RBX::GamePerfMonitor> *ppx,
        RBX::GamePerfMonitor *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2882028;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf15990 | Name: _ZN3RBX7Network14MegaReplicator17getPhysicsMegaJobEv
RBX::Network::NetworkPhysicsMegaJob *__fastcall RBX::Network::MegaReplicator::getPhysicsMegaJob(
        RBX::Network::MegaReplicator *this)
{
  return (RBX::Network::NetworkPhysicsMegaJob *)*((_QWORD *)this + 16);
}


// Address: 0xf1c160 | Name: _ZN5boost6detail8function26void_function_obj_invoker0IZN3RBX7Network21NetworkPhysicsMegaJob16stepDataModelJobERKNS3_13TaskScheduler3Job5StatsEE3$_3vE6invokeERNS1_15function_bufferE
void __fastcall boost::detail::function::void_function_obj_invoker0<RBX::Network::NetworkPhysicsMegaJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::$_3,void>::invoke(
        boost::detail::function::function_buffer *function_obj_ptr)
{
  RBX::Network::PhysicsSenderS2::sendPacket(
    (RBX::Network::PhysicsSenderS2 *)function_obj_ptr->obj_ptr,
    *((_DWORD *)&function_obj_ptr->data + 4),
    *((PacketPriority *)&function_obj_ptr->data + 5));
}


// Address: 0xf1c5a0 | Name: _ZN5boost10shared_ptrIN3RBX13TaskScheduler3JobEE5resetINS1_7Network22NetworkSendDataMegaJobEEEvPT_
void __fastcall boost::shared_ptr<RBX::TaskScheduler::Job>::reset<RBX::Network::NetworkSendDataMegaJob>(
        boost::shared_ptr<RBX::TaskScheduler::Job> *this,
        RBX::Network::NetworkSendDataMegaJob *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::TaskScheduler::Job,RBX::Network::NetworkSendDataMegaJob>(
    (boost::shared_ptr<RBX::TaskScheduler::Job> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::TaskScheduler::Job> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xf1c650 | Name: _ZN5boost10shared_ptrIN3RBX13TaskScheduler3JobEE5resetINS1_7Network20ModelCompletenessJobEEEvPT_
void __fastcall boost::shared_ptr<RBX::TaskScheduler::Job>::reset<RBX::Network::ModelCompletenessJob>(
        boost::shared_ptr<RBX::TaskScheduler::Job> *this,
        RBX::Network::ModelCompletenessJob *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::TaskScheduler::Job,RBX::Network::ModelCompletenessJob>(
    (boost::shared_ptr<RBX::TaskScheduler::Job> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::TaskScheduler::Job> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xf1ce40 | Name: _ZN5boost10shared_ptrIN3RBX7Network15CachedBitstreamEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::Network::CachedBitstream>::reset<RBX::Network::CachedBitstream>(
        boost::shared_ptr<RBX::Network::CachedBitstream> *this,
        RBX::Network::CachedBitstream *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Network::CachedBitstream,RBX::Network::CachedBitstream>(
    (boost::shared_ptr<RBX::Network::CachedBitstream> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Network::CachedBitstream> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xf1da50 | Name: _ZN5boost10shared_ptrIKNSt3__16vectorIN3RBX10Reflection7VariantENS1_9allocatorIS5_EEEEEC2IS8_EEPT_
void __fastcall boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>::shared_ptr<std::vector<RBX::Reflection::Variant>>(
        boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > *this,
        std::vector<RBX::Reflection::Variant> *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<std::vector<RBX::Reflection::Variant>>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf1e4b0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network21NetworkPhysicsMegaJobES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::NetworkPhysicsMegaJob,RBX::Network::NetworkPhysicsMegaJob>(
        boost::shared_ptr<RBX::Network::NetworkPhysicsMegaJob> *ppx,
        RBX::Network::NetworkPhysicsMegaJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2882668;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::NetworkPhysicsMegaJob,RBX::Network::NetworkPhysicsMegaJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xf1e660 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX13TaskScheduler3JobENS2_7Network22NetworkSendDataMegaJobEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::TaskScheduler::Job,RBX::Network::NetworkSendDataMegaJob>(
        boost::shared_ptr<RBX::TaskScheduler::Job> *ppx,
        RBX::Network::NetworkSendDataMegaJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28826C8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TaskScheduler::Job,RBX::Network::NetworkSendDataMegaJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xf1e810 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX13TaskScheduler3JobENS2_7Network20ModelCompletenessJobEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::TaskScheduler::Job,RBX::Network::ModelCompletenessJob>(
        boost::shared_ptr<RBX::TaskScheduler::Job> *ppx,
        RBX::Network::ModelCompletenessJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2882728;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TaskScheduler::Job,RBX::Network::ModelCompletenessJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xf20910 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network15CachedBitstreamES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::CachedBitstream,RBX::Network::CachedBitstream>(
        boost::shared_ptr<RBX::Network::CachedBitstream> *ppx,
        RBX::Network::CachedBitstream *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28827E8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf282a0 | Name: _ZN5boost10shared_ptrIN3RBX7Network19StrictNetworkFilter9WhiteListEEC2IS4_EEPT_
void __fastcall boost::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList>::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList>(
        boost::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList> *this,
        RBX::Network::StrictNetworkFilter::WhiteList *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Network::StrictNetworkFilter::WhiteList>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf3be60 | Name: _ZN5boost10shared_ptrIN3RBX7Network17ConcurrentRakPeerEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Network::ConcurrentRakPeer>::shared_ptr<RBX::Network::ConcurrentRakPeer>(
        boost::shared_ptr<RBX::Network::ConcurrentRakPeer> *this,
        RBX::Network::ConcurrentRakPeer *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Network::ConcurrentRakPeer>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf3bfd0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network16PacketReceiveJobES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::PacketReceiveJob,RBX::Network::PacketReceiveJob>(
        boost::shared_ptr<RBX::Network::PacketReceiveJob> *ppx,
        RBX::Network::PacketReceiveJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2884058;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::PacketReceiveJob,RBX::Network::PacketReceiveJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xf43eb0 | Name: _ZN5boost10shared_ptrIN3RBX14PhysicsServiceEED2Ev
void __fastcall boost::shared_ptr<RBX::PhysicsService>::~shared_ptr(boost::shared_ptr<RBX::PhysicsService> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf43f40 | Name: _ZN5boost10shared_ptrIN3RBX7Network15PhysicsSenderS210TouchJobS2EED2Ev
void __fastcall boost::shared_ptr<RBX::Network::PhysicsSenderS2::TouchJobS2>::~shared_ptr(
        boost::shared_ptr<RBX::Network::PhysicsSenderS2::TouchJobS2> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf44800 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network13NetworkStreamES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::NetworkStream,RBX::Network::NetworkStream>(
        boost::shared_ptr<RBX::Network::NetworkStream> *ppx,
        RBX::Network::NetworkStream *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28843D8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf449b0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network15PhysicsSenderS210TouchJobS2ES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::PhysicsSenderS2::TouchJobS2,RBX::Network::PhysicsSenderS2::TouchJobS2>(
        boost::shared_ptr<RBX::Network::PhysicsSenderS2::TouchJobS2> *ppx,
        RBX::Network::PhysicsSenderS2::TouchJobS2 *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2884438;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::PhysicsSenderS2::TouchJobS2,RBX::Network::PhysicsSenderS2::TouchJobS2>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xf67920 | Name: _ZN3RBX7Network10Replicator25testDisableProcessPacketsEv
void __fastcall RBX::Network::Replicator::testDisableProcessPackets(RBX::Network::Replicator *this)
{
  *(_DWORD *)(*((_QWORD *)this + 991) + 480LL) = 0;
}


// Address: 0xf67940 | Name: _ZN3RBX7Network10Replicator24testEnableProcessPacketsEv
void __fastcall RBX::Network::Replicator::testEnableProcessPackets(RBX::Network::Replicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 991);
  *(_DWORD *)(v1 + 480) = 1;
  *(_BYTE *)(v1 + 484) = 0;
}


// Address: 0xf6c3f0 | Name: _ZN5boost10shared_ptrINSt3__13mapINS1_12basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEN3RBX10Reflection7VariantENS1_4lessIS8_EENS6_INS1_4pairIKS8_SB_EEEEEEEC2ISI_EEPT_
void __fastcall boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant>>::shared_ptr<std::map<std::string,RBX::Reflection::Variant>>(
        boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> > *this,
        std::map<std::string,RBX::Reflection::Variant> *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<std::map<std::string,RBX::Reflection::Variant>>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf75430 | Name: _ZN5boost10shared_ptrIN3RBX7Network17ConcurrentRakPeerEED2Ev
void __fastcall boost::shared_ptr<RBX::Network::ConcurrentRakPeer>::~shared_ptr(
        boost::shared_ptr<RBX::Network::ConcurrentRakPeer> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf76440 | Name: _ZN5boost10shared_ptrIN3RBX7Network21DeserializePacketsJobEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::Network::DeserializePacketsJob>::reset<RBX::Network::DeserializePacketsJob>(
        boost::shared_ptr<RBX::Network::DeserializePacketsJob> *this,
        RBX::Network::DeserializePacketsJob *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Network::DeserializePacketsJob,RBX::Network::DeserializePacketsJob>(
    (boost::shared_ptr<RBX::Network::DeserializePacketsJob> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Network::DeserializePacketsJob> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xf79ea0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX13TaskScheduler7ArbiterENS2_7Network21DeserializePacketsJob12DummyArbiterEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::TaskScheduler::Arbiter,RBX::Network::DeserializePacketsJob::DummyArbiter>(
        boost::shared_ptr<RBX::TaskScheduler::Arbiter> *ppx,
        RBX::Network::DeserializePacketsJob::DummyArbiter *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2884EC8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf7cb20 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network10Replicator11SendDataJobES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::Replicator::SendDataJob,RBX::Network::Replicator::SendDataJob>(
        boost::shared_ptr<RBX::Network::Replicator::SendDataJob> *ppx,
        RBX::Network::Replicator::SendDataJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2885128;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::SendDataJob,RBX::Network::Replicator::SendDataJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xf7ccd0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network10Replicator14SendClusterJobES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::Replicator::SendClusterJob,RBX::Network::Replicator::SendClusterJob>(
        boost::shared_ptr<RBX::Network::Replicator::SendClusterJob> *ppx,
        RBX::Network::Replicator::SendClusterJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2885188;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::SendClusterJob,RBX::Network::Replicator::SendClusterJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xf7ce80 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network10Replicator17ProcessPacketsJobES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::Replicator::ProcessPacketsJob,RBX::Network::Replicator::ProcessPacketsJob>(
        boost::shared_ptr<RBX::Network::Replicator::ProcessPacketsJob> *ppx,
        RBX::Network::Replicator::ProcessPacketsJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28851E8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::ProcessPacketsJob,RBX::Network::Replicator::ProcessPacketsJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xf7d030 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network10Replicator7PingJobES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::Replicator::PingJob,RBX::Network::Replicator::PingJob>(
        boost::shared_ptr<RBX::Network::Replicator::PingJob> *ppx,
        RBX::Network::Replicator::PingJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2885248;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::PingJob,RBX::Network::Replicator::PingJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xf84d30 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network21DeserializePacketsJobES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializePacketsJob,RBX::Network::DeserializePacketsJob>(
        boost::shared_ptr<RBX::Network::DeserializePacketsJob> *ppx,
        RBX::Network::DeserializePacketsJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2885468;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::DeserializePacketsJob,RBX::Network::DeserializePacketsJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xf85260 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network23DeserializedTouchItemS2ES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedTouchItemS2,RBX::Network::DeserializedTouchItemS2>(
        boost::shared_ptr<RBX::Network::DeserializedTouchItemS2> *ppx,
        RBX::Network::DeserializedTouchItemS2 *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28854E8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf8afd0 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIKN3RBX10Reflection5TupleEEEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<RBX::Reflection::Tuple const>>::construct_func(
        const char *src,
        char *dest)
{
  __int64 v2; // rax

  *(_QWORD *)dest = *(_QWORD *)src;
  v2 = *((_QWORD *)src + 1);
  *((_QWORD *)dest + 1) = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
}


// Address: 0xf8b270 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIKNSt3__13mapINS4_12basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEN3RBX10Reflection7VariantENS4_4lessISB_EENS9_INS4_4pairIKSB_SE_EEEEEEEEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>>::construct_func(
        const char *src,
        char *dest)
{
  __int64 v2; // rax

  *(_QWORD *)dest = *(_QWORD *)src;
  v2 = *((_QWORD *)src + 1);
  *((_QWORD *)dest + 1) = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
}


// Address: 0xf8eac0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network30DeserializedChangePropertyItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedChangePropertyItem,RBX::Network::DeserializedChangePropertyItem>(
        boost::shared_ptr<RBX::Network::DeserializedChangePropertyItem> *ppx,
        RBX::Network::DeserializedChangePropertyItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2885CA8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf91450 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network23DeserializedClusterItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedClusterItem,RBX::Network::DeserializedClusterItem>(
        boost::shared_ptr<RBX::Network::DeserializedClusterItem> *ppx,
        RBX::Network::DeserializedClusterItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2885E68;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf92a00 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network30DeserializedDeleteInstanceItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedDeleteInstanceItem,RBX::Network::DeserializedDeleteInstanceItem>(
        boost::shared_ptr<RBX::Network::DeserializedDeleteInstanceItem> *ppx,
        RBX::Network::DeserializedDeleteInstanceItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28862C8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf93a30 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network31DeserializedEventInvocationItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedEventInvocationItem,RBX::Network::DeserializedEventInvocationItem>(
        boost::shared_ptr<RBX::Network::DeserializedEventInvocationItem> *ppx,
        RBX::Network::DeserializedEventInvocationItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28863D8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf9d150 | Name: _ZN5boost10shared_ptrIN3RBX7Network13NetworkStreamEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::Network::NetworkStream>::reset<RBX::Network::NetworkStream>(
        boost::shared_ptr<RBX::Network::NetworkStream> *this,
        RBX::Network::NetworkStream *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Network::NetworkStream,RBX::Network::NetworkStream>(
    (boost::shared_ptr<RBX::Network::NetworkStream> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Network::NetworkStream> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xf9d200 | Name: _ZN5boost10shared_ptrIN3RBX7Network13NetworkStreamEED2Ev
void __fastcall boost::shared_ptr<RBX::Network::NetworkStream>::~shared_ptr(
        boost::shared_ptr<RBX::Network::NetworkStream> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf9d240 | Name: _ZN5boost10shared_ptrIN3RBX7Network13NetworkStreamEEC2IS3_NSt3__114default_deleteIS3_EEEEONS6_10unique_ptrIT_T0_EE
void __fastcall boost::shared_ptr<RBX::Network::NetworkStream>::shared_ptr<RBX::Network::NetworkStream,std::default_delete<RBX::Network::NetworkStream>>(
        boost::shared_ptr<RBX::Network::NetworkStream> *this,
        std::unique_ptr<RBX::Network::NetworkStream> *r)
{
  boost::detail::sp_counted_base *v2; // r12
  RBX::Network::NetworkStream *value; // rax
  boost::detail::sp_counted_base *pi; // r15

  this->px = r->__ptr_.__value_;
  this->pn.pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x20u);
  value = r->__ptr_.__value_;
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28865A8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))value;
  r->__ptr_.__value_ = 0;
  pi = this->pn.pi_;
  if ( pi != v2 )
  {
    _InterlockedAdd(&v2->use_count_, 1u);
    if ( pi )
    {
      if ( !_InterlockedSub(&pi->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
    this->pn.pi_ = v2;
  }
  if ( !_InterlockedSub(&v2->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v2->_vptr$sp_counted_base + 2))(v2);
    if ( !_InterlockedSub(&v2->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v2->_vptr$sp_counted_base + 3))(v2);
  }
}


// Address: 0xf9d7e0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network22DeserializedMarkerItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedMarkerItem,RBX::Network::DeserializedMarkerItem>(
        boost::shared_ptr<RBX::Network::DeserializedMarkerItem> *ppx,
        RBX::Network::DeserializedMarkerItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28866A8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf9e510 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network20DeserializedPingItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedPingItem,RBX::Network::DeserializedPingItem>(
        boost::shared_ptr<RBX::Network::DeserializedPingItem> *ppx,
        RBX::Network::DeserializedPingItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2886818;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfa03c0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network31DeserializedNetPmcChallengeItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedNetPmcChallengeItem,RBX::Network::DeserializedNetPmcChallengeItem>(
        boost::shared_ptr<RBX::Network::DeserializedNetPmcChallengeItem> *ppx,
        RBX::Network::DeserializedNetPmcChallengeItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2886E88;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfa04a0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network27DeserializedIdChallengeItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedIdChallengeItem,RBX::Network::DeserializedIdChallengeItem>(
        boost::shared_ptr<RBX::Network::DeserializedIdChallengeItem> *ppx,
        RBX::Network::DeserializedIdChallengeItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2886EE8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfa0580 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network28DeserializedAacChallengeItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedAacChallengeItem,RBX::Network::DeserializedAacChallengeItem>(
        boost::shared_ptr<RBX::Network::DeserializedAacChallengeItem> *ppx,
        RBX::Network::DeserializedAacChallengeItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2886F48;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfa0660 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network34DeserializedTimeoutInfoRequestItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedTimeoutInfoRequestItem,RBX::Network::DeserializedTimeoutInfoRequestItem>(
        boost::shared_ptr<RBX::Network::DeserializedTimeoutInfoRequestItem> *ppx,
        RBX::Network::DeserializedTimeoutInfoRequestItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2886FA8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfa0740 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network25DeserializedCcRequestItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedCcRequestItem,RBX::Network::DeserializedCcRequestItem>(
        boost::shared_ptr<RBX::Network::DeserializedCcRequestItem> *ppx,
        RBX::Network::DeserializedCcRequestItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2887008;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfa0820 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network25DeserializedPmcConfigItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedPmcConfigItem,RBX::Network::DeserializedPmcConfigItem>(
        boost::shared_ptr<RBX::Network::DeserializedPmcConfigItem> *ppx,
        RBX::Network::DeserializedPmcConfigItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2887068;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfa0fc0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network19DeserializedTagItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedTagItem,RBX::Network::DeserializedTagItem>(
        boost::shared_ptr<RBX::Network::DeserializedTagItem> *ppx,
        RBX::Network::DeserializedTagItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2887178;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfa2c70 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network24DeserializedJoinDataItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedJoinDataItem,RBX::Network::DeserializedJoinDataItem>(
        boost::shared_ptr<RBX::Network::DeserializedJoinDataItem> *ppx,
        RBX::Network::DeserializedJoinDataItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2887238;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfa9af0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network44DeserializedResolveNewInstanceAtomicTreeItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedResolveNewInstanceAtomicTreeItem,RBX::Network::DeserializedResolveNewInstanceAtomicTreeItem>(
        boost::shared_ptr<RBX::Network::DeserializedResolveNewInstanceAtomicTreeItem> *ppx,
        RBX::Network::DeserializedResolveNewInstanceAtomicTreeItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28874F8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfaa730 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network27DeserializedNewInstanceItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedNewInstanceItem,RBX::Network::DeserializedNewInstanceItem>(
        boost::shared_ptr<RBX::Network::DeserializedNewInstanceItem> *ppx,
        RBX::Network::DeserializedNewInstanceItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2887558;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfabb30 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Security23ReplicatorCryptoContextENS3_30ReplicatorCryptoContextOpenSSLEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Security::ReplicatorCryptoContext,RBX::Security::ReplicatorCryptoContextOpenSSL>(
        boost::shared_ptr<RBX::Security::ReplicatorCryptoContext> *ppx,
        RBX::Security::ReplicatorCryptoContextOpenSSL *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2887708;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfb65d0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network21DeserializedStatsItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedStatsItem,RBX::Network::DeserializedStatsItem>(
        boost::shared_ptr<RBX::Network::DeserializedStatsItem> *ppx,
        RBX::Network::DeserializedStatsItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2887AD8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfbaf70 | Name: _ZN3RBX7Network10Replicator9StreamJob16stepDataModelJobERKNS_13TaskScheduler3Job5StatsE
RBX::TaskSchedulerStepResult __fastcall RBX::Network::Replicator::StreamJob::stepDataModelJob(
        RBX::Network::Replicator::StreamJob *this,
        const RBX::TaskScheduler::Job::Stats *stats)
{
  if ( *(_BYTE *)(*((_QWORD *)this + 58) + 29480LL) )
    return RBX::TaskSchedulerStepResult::TaskSchedulerStepped;
  else
    return RBX::Network::Replicator::StreamJob::work(this, stats);
}


// Address: 0xfbf300 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network30DeserializedStreamDataInfoItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedStreamDataInfoItem,RBX::Network::DeserializedStreamDataInfoItem>(
        boost::shared_ptr<RBX::Network::DeserializedStreamDataInfoItem> *ppx,
        RBX::Network::DeserializedStreamDataInfoItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2888748;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfbf3e0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network26DeserializedStreamDataItemES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::DeserializedStreamDataItem,RBX::Network::DeserializedStreamDataItem>(
        boost::shared_ptr<RBX::Network::DeserializedStreamDataItem> *ppx,
        RBX::Network::DeserializedStreamDataItem *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28887A8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfd1ae0 | Name: _ZN5boost10shared_ptrIKN3RBX7Network16ServerSchemaInfoEED2Ev
void __fastcall boost::shared_ptr<RBX::Network::ServerSchemaInfo const>::~shared_ptr(
        boost::shared_ptr<const RBX::Network::ServerSchemaInfo> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfd1b20 | Name: _ZN5boost10shared_ptrIN3RBX8Security19AslrPmcSharedHasherEED2Ev
void __fastcall boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>::~shared_ptr(
        boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfd1de0 | Name: _ZN5boost10shared_ptrIN3RBX7PlayersEED2Ev
void __fastcall boost::shared_ptr<RBX::Players>::~shared_ptr(boost::shared_ptr<RBX::Players> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfd2270 | Name: _ZN5boost10shared_ptrIN3RBX8Security19AslrPmcSharedHasherEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>::reset<RBX::Security::AslrPmcSharedHasher>(
        boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> *this,
        RBX::Security::AslrPmcSharedHasher *p)
{
  boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>::element_type *px; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> v5; // [rsp+0h] [rbp-28h] BYREF
  boost::detail::shared_count v6; // [rsp+10h] [rbp-18h] BYREF

  px = p;
  v5.px = p;
  boost::detail::shared_count::shared_count<RBX::Security::AslrPmcSharedHasher>(&v6, p);
  pi = v6.pi_;
  v5.pn = v6;
  if ( p )
  {
    boost::enable_shared_from_this<RBX::Security::AslrPmcSharedHasher>::_internal_accept_owner<RBX::Security::AslrPmcSharedHasher,RBX::Security::AslrPmcSharedHasher>(
      (const boost::enable_shared_from_this<RBX::Security::AslrPmcSharedHasher> *)p,
      &v5,
      p);
    px = v5.px;
    pi = v5.pn.pi_;
  }
  v5.px = this->px;
  this->px = px;
  v4 = this->pn.pi_;
  this->pn.pi_ = pi;
  v5.pn.pi_ = v4;
  if ( v4 && !_InterlockedSub(&v4->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
    if ( !_InterlockedSub(&v4->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
  }
}


// Address: 0xfd5980 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX8Security19AslrPmcSharedHasherEEEENS4_5list1INS4_5valueISA_EEEEEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher> > > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2888FE8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xfd5e80 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network15NetworkOwnerJobES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::NetworkOwnerJob,RBX::Network::NetworkOwnerJob>(
        boost::shared_ptr<RBX::Network::NetworkOwnerJob> *ppx,
        RBX::Network::NetworkOwnerJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28890A8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::NetworkOwnerJob,RBX::Network::NetworkOwnerJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xfd6030 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network22RomarkPhaseTrackingJobES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::RomarkPhaseTrackingJob,RBX::Network::RomarkPhaseTrackingJob>(
        boost::shared_ptr<RBX::Network::RomarkPhaseTrackingJob> *ppx,
        RBX::Network::RomarkPhaseTrackingJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2889108;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::RomarkPhaseTrackingJob,RBX::Network::RomarkPhaseTrackingJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xfe6070 | Name: _ZN5boost10shared_ptrIN3RBX6PlayerEED2Ev
void __fastcall boost::shared_ptr<RBX::Player>::~shared_ptr(boost::shared_ptr<RBX::Player> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfe60b0 | Name: _ZN5boost10shared_ptrIN3RBX9PlayerGuiEED2Ev
void __fastcall boost::shared_ptr<RBX::PlayerGui>::~shared_ptr(boost::shared_ptr<RBX::PlayerGui> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xfe75f0 | Name: _ZNK3RBX7Network16ServerReplicator16findTargetPlayerEv
RBX::Player *__fastcall RBX::Network::ServerReplicator::findTargetPlayer(const RBX::Network::ServerReplicator *this)
{
  return (RBX::Player *)*((_QWORD *)this + 3876);
}


// Address: 0xfe7600 | Name: _ZNK3RBX7Network16ServerReplicator15getRemotePlayerEv
RBX::Player *__fastcall RBX::Network::ServerReplicator::getRemotePlayer(const RBX::Network::ServerReplicator *this)
{
  return (RBX::Player *)*((_QWORD *)this + 3876);
}


// Address: 0xfed190 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX9DataModelEEENS6_INS7_7Network16ServerReplicatorEEEi14PacketPriorityiENS4_5list5INS4_5valueIS9_EENSH_ISC_EENSH_IiEENSH_ISD_EESK_EEEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_288A8E8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xff55b0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network10Replicator12SendStatsJobES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::Replicator::SendStatsJob,RBX::Network::Replicator::SendStatsJob>(
        boost::shared_ptr<RBX::Network::Replicator::SendStatsJob> *ppx,
        RBX::Network::Replicator::SendStatsJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_288B2C8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::SendStatsJob,RBX::Network::Replicator::SendStatsJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0xff60f0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7Network10Replicator9StreamJobES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Network::Replicator::StreamJob,RBX::Network::Replicator::StreamJob>(
        boost::shared_ptr<RBX::Network::Replicator::StreamJob> *ppx,
        RBX::Network::Replicator::StreamJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_288B328;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::StreamJob,RBX::Network::Replicator::StreamJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1013d60 | Name: _ZN5boost10shared_ptrIN3RBX8Security13AslrPmcServerEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::Security::AslrPmcServer>::reset<RBX::Security::AslrPmcServer>(
        boost::shared_ptr<RBX::Security::AslrPmcServer> *this,
        RBX::Security::AslrPmcServer *p)
{
  boost::shared_ptr<RBX::Security::AslrPmcServer>::element_type *px; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::Security::AslrPmcServer> v5; // [rsp+0h] [rbp-28h] BYREF
  boost::detail::shared_count v6; // [rsp+10h] [rbp-18h] BYREF

  px = p;
  v5.px = p;
  boost::detail::shared_count::shared_count<RBX::Security::AslrPmcServer>(&v6, p);
  pi = v6.pi_;
  v5.pn = v6;
  if ( p )
  {
    boost::enable_shared_from_this<RBX::Security::AslrPmcServer>::_internal_accept_owner<RBX::Security::AslrPmcServer,RBX::Security::AslrPmcServer>(
      (const boost::enable_shared_from_this<RBX::Security::AslrPmcServer> *)p,
      &v5,
      p);
    px = v5.px;
    pi = v5.pn.pi_;
  }
  v5.px = this->px;
  this->px = px;
  v4 = this->pn.pi_;
  this->pn.pi_ = pi;
  v5.pn.pi_ = v4;
  if ( v4 && !_InterlockedSub(&v4->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
    if ( !_InterlockedSub(&v4->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
  }
}


// Address: 0x1031440 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Security19AslrPmcSharedHasher17SectionDataVectorES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Security::AslrPmcSharedHasher::SectionDataVector,RBX::Security::AslrPmcSharedHasher::SectionDataVector>(
        boost::shared_ptr<RBX::Security::AslrPmcSharedHasher::SectionDataVector> *ppx,
        RBX::Security::AslrPmcSharedHasher::SectionDataVector *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_288CD50;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1032810 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvPFvNS_10shared_ptrIN3RBX8Security19AslrPmcSharedHasherEEENSt3__112basic_stringIcNSB_11char_traitsIcEENSB_9allocatorIcEEEEmENS4_5list3INS4_5valueISA_EENSL_ISH_EENSL_ImEEEEEEEEEEvPNS6_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>>,boost::_bi::value<std::string>,boost::_bi::value<unsigned long>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> >,boost::_bi::value<std::string >,boost::_bi::value<unsigned long> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_288CDF8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>>,boost::_bi::value<std::string>,boost::_bi::value<unsigned long>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1042ff0 | Name: _ZNK3RBX14AnimationTrack9getLengthEv
float __fastcall RBX::AnimationTrack::getLength(const RBX::AnimationTrack *this)
{
  return RBX::KeyframeSequence::getDuration((const RBX::KeyframeSequence *)this->keyframeSequence.px);
}


// Address: 0x1043300 | Name: _ZNK3RBX14AnimationTrack12getAnimationEv
RBX::Animation *__fastcall RBX::AnimationTrack::getAnimation(const RBX::AnimationTrack *this)
{
  return (RBX::Animation *)this->animation.px;
}


// Address: 0x1044630 | Name: _ZNK3RBX14AnimationTrack19getKeyframeSequenceEv
const RBX::KeyframeSequence *__fastcall RBX::AnimationTrack::getKeyframeSequence(const RBX::AnimationTrack *this)
{
  return (const RBX::KeyframeSequence *)this->keyframeSequence.px;
}


// Address: 0x1046260 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIN3RBX10Reflection13DescribedBaseEEEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<RBX::Reflection::DescribedBase>>::construct_func(
        const char *src,
        char *dest)
{
  __int64 v2; // rax

  *(_QWORD *)dest = *(_QWORD *)src;
  v2 = *((_QWORD *)src + 1);
  *((_QWORD *)dest + 1) = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
}


// Address: 0x104db20 | Name: _ZN3RBX16KeyframeSequence12getKeyframesEv
boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **__fastcall RBX::KeyframeSequence::getKeyframes(
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **a1,
        RBX::KeyframeSequence *this)
{
  boost::detail::sp_counted_base *pi; // rax

  *a1 = this->children.object.px;
  pi = this->children.object.pn.pi_;
  a1[1] = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  return a1;
}


// Address: 0x106a100 | Name: _ZN3RBX4Pose11getSubPosesEv
boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **__fastcall RBX::Pose::getSubPoses(
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **a1,
        RBX::Pose *this)
{
  boost::detail::sp_counted_base *pi; // rax

  *a1 = this->children.object.px;
  pi = this->children.object.pn.pi_;
  a1[1] = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  return a1;
}


// Address: 0x106f680 | Name: _ZN3RBX8Humanoid19getCurrentStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::Humanoid::getCurrentStateType(RBX::Humanoid *this)
{
  __int64 v1; // rdi

  v1 = *((_QWORD *)this + 309);
  if ( v1 )
    return (*(RBX::HUMAN::StateType (__fastcall **)(__int64))(*(_QWORD *)v1 + 128LL))(v1);
  else
    return RBX::HUMAN::StateType::xx;
}


// Address: 0x108f170 | Name: _ZNK3RBX8Humanoid26getYAxisRotationalVelocityEv
float __fastcall RBX::Humanoid::getYAxisRotationalVelocity(const RBX::Humanoid *this)
{
  __int64 v1; // rdi

  v1 = *((_QWORD *)this + 309);
  if ( v1 )
    return (*(float (__fastcall **)(__int64))(*(_QWORD *)v1 + 120LL))(v1);
  else
    return 0.0;
}


// Address: 0x108f190 | Name: _ZThn440_NK3RBX8Humanoid26getYAxisRotationalVelocityEv
void __fastcall `non-virtual thunk to'RBX::Humanoid::getYAxisRotationalVelocity(const RBX::Humanoid *this)
{
  __int64 v1; // rdi

  v1 = *((_QWORD *)this + 254);
  if ( v1 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v1 + 120LL))(v1);
}


// Address: 0x10902d0 | Name: _ZN3RBX8Humanoid15getRootBodyFastEv
RBX::Body *__fastcall RBX::Humanoid::getRootBodyFast(RBX::Humanoid *this)
{
  __int64 v1; // rax
  __int64 v2; // rax

  v1 = *((_QWORD *)this + 175);
  if ( !v1 )
    return 0;
  v2 = *(_QWORD *)(v1 + 232);
  if ( v2 )
    return *(RBX::Body **)(v2 + 200);
  else
    return 0;
}


// Address: 0x10903a0 | Name: _ZN3RBX8Humanoid16getAppendageFastENS0_13AppendageTypeERN5boost10shared_ptrINS_12PartInstanceEEE
RBX::PartInstance *__fastcall RBX::Humanoid::getAppendageFast(
        RBX::Humanoid *this,
        RBX::Humanoid::AppendageType appendage,
        boost::shared_ptr<RBX::PartInstance> *appendagePart)
{
  return appendagePart->px;
}


// Address: 0x1090cc0 | Name: _ZN3RBX8Humanoid21getTorsoPrimitiveFastEv
RBX::Primitive *__fastcall RBX::Humanoid::getTorsoPrimitiveFast(RBX::Humanoid *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 175);
  if ( v1 )
    return *(RBX::Primitive **)(v1 + 232);
  else
    return 0;
}


// Address: 0x1090ce0 | Name: _ZN3RBX8Humanoid16getTorsoBodyFastEv
RBX::Body *__fastcall RBX::Humanoid::getTorsoBodyFast(RBX::Humanoid *this)
{
  __int64 v1; // rax
  __int64 v2; // rcx
  RBX::Body *result; // rax

  v1 = *((_QWORD *)this + 175);
  if ( !v1 )
    return 0;
  v2 = *(_QWORD *)(v1 + 232);
  result = (RBX::Body *)(v2 + 152);
  if ( !v2 )
    return 0;
  return result;
}


// Address: 0x10a31e0 | Name: _ZNK3RBX8Humanoid11getSeatPartEv
RBX::PartInstance *__fastcall RBX::Humanoid::getSeatPart(const RBX::Humanoid *this)
{
  return (RBX::PartInstance *)*((_QWORD *)this + 62);
}


// Address: 0x10a3210 | Name: _ZNK3RBX8Humanoid13getWalkToPartEv
RBX::PartInstance *__fastcall RBX::Humanoid::getWalkToPart(const RBX::Humanoid *this)
{
  return (RBX::PartInstance *)*((_QWORD *)this + 64);
}


// Address: 0x10ace60 | Name: _ZN5boost10shared_ptrIN3RBX12PartInstanceEED2Ev
void __fastcall boost::shared_ptr<RBX::PartInstance>::~shared_ptr(boost::shared_ptr<RBX::PartInstance> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10adbe0 | Name: _ZN5boost10shared_ptrIN3G3D5PlaneEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<G3D::Plane>::reset<G3D::Plane>(boost::shared_ptr<G3D::Plane> *this, G3D::Plane *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<G3D::Plane,G3D::Plane>((boost::shared_ptr<G3D::Plane> *)pn, p, &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<G3D::Plane> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x10ae3e0 | Name: _ZN5boost10shared_ptrIN3RBX5HUMAN13HumanoidStateEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::HUMAN::HumanoidState>::reset<RBX::HUMAN::HumanoidState>(
        boost::shared_ptr<RBX::HUMAN::HumanoidState> *this,
        RBX::HUMAN::HumanoidState *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::HUMAN::HumanoidState,RBX::HUMAN::HumanoidState>(
    (boost::shared_ptr<RBX::HUMAN::HumanoidState> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::HUMAN::HumanoidState> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x10b0900 | Name: _ZN3RBX8Humanoid13getEngineBodyEv
RBX::Body *__fastcall RBX::Humanoid::getEngineBody(RBX::Humanoid *this)
{
  __int64 v1; // rax
  __int64 v2; // rax

  v1 = *((_QWORD *)this + 175);
  if ( !v1 )
    return 0;
  v2 = *(_QWORD *)(v1 + 232);
  if ( v2 )
    return *(RBX::Body **)(v2 + 200);
  else
    return 0;
}


// Address: 0x10b0a70 | Name: _ZThn128_N3RBX8Humanoid13getEngineBodyEv
void __fastcall `non-virtual thunk to'RBX::Humanoid::getEngineBody(RBX::Humanoid *this)
{
  ;
}


// Address: 0x10c6d30 | Name: _ZN5boost6detail20sp_pointer_constructIN3G3D5PlaneES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<G3D::Plane,G3D::Plane>(
        boost::shared_ptr<G3D::Plane> *ppx,
        G3D::Plane *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2894C88;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10c9780 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX5HUMAN13HumanoidStateES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::HUMAN::HumanoidState,RBX::HUMAN::HumanoidState>(
        boost::shared_ptr<RBX::HUMAN::HumanoidState> *ppx,
        RBX::HUMAN::HumanoidState *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2894D08;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10c9860 | Name: _ZN5boost10shared_ptrIN3RBX6GfxGuiEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::GfxGui>::shared_ptr<RBX::GfxGui>(
        boost::shared_ptr<RBX::GfxGui> *this,
        RBX::GfxGui *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::GfxGui>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10d1f20 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX24HumanoidAssetRequirementES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::HumanoidAssetRequirement,RBX::HumanoidAssetRequirement>(
        boost::shared_ptr<RBX::HumanoidAssetRequirement> *ppx,
        RBX::HumanoidAssetRequirement *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2895288;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10ff3b0 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrINSt3__16vectorIN3RBX10Reflection7VariantENS4_9allocatorIS8_EEEEEEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<std::vector<RBX::Reflection::Variant>>>::construct_func(
        const char *src,
        char *dest)
{
  __int64 v2; // rax

  *(_QWORD *)dest = *(_QWORD *)src;
  v2 = *((_QWORD *)src + 1);
  *((_QWORD *)dest + 1) = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
}


// Address: 0x10ffb30 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrINS2_9unordered13unordered_mapINSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEN3RBX10Reflection7VariantENS2_4hashISC_EENS6_8equal_toISC_EENSA_INS6_4pairIKSC_SF_EEEEEEEEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>::construct_func(
        const char *src,
        char *dest)
{
  __int64 v2; // rax

  *(_QWORD *)dest = *(_QWORD *)src;
  v2 = *((_QWORD *)src + 1);
  *((_QWORD *)dest + 1) = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
}


// Address: 0x1111f10 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataIPFvvEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<void (*)(void)>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<void (*)()> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_287C7C8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<void (*)(void)>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1121870 | Name: _ZNK3RBX9Scripting14ScriptDebugger9getScriptEv
RBX::Instance *__fastcall RBX::Scripting::ScriptDebugger::getScript(const RBX::Scripting::ScriptDebugger *this)
{
  return (RBX::Instance *)*((_QWORD *)this + 27);
}


// Address: 0x11348e0 | Name: _ZN5boost10shared_ptrIN3RBX9Scripting15DebuggerManagerEED2Ev
void __fastcall boost::shared_ptr<RBX::Scripting::DebuggerManager>::~shared_ptr(
        boost::shared_ptr<RBX::Scripting::DebuggerManager> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x11cbdb0 | Name: _ZN5boost10shared_ptrIN3RBX11ScriptStatsEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RBX::ScriptStats>::reset<RBX::ScriptStats>(
        boost::shared_ptr<RBX::ScriptStats> *this,
        RBX::ScriptStats *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::ScriptStats,RBX::ScriptStats>(
    (boost::shared_ptr<RBX::ScriptStats> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::ScriptStats> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x11cec30 | Name: _ZN5boost10shared_ptrIN16RobloxExtraSpace6SharedEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RobloxExtraSpace::Shared>::shared_ptr<RobloxExtraSpace::Shared>(
        boost::shared_ptr<RobloxExtraSpace::Shared> *this,
        RobloxExtraSpace::Shared *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RobloxExtraSpace::Shared>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x11cfd40 | Name: _ZN5boost10shared_ptrINS_6detail20tss_cleanup_functionEED2Ev
void __fastcall boost::shared_ptr<boost::detail::tss_cleanup_function>::~shared_ptr(
        boost::shared_ptr<boost::detail::tss_cleanup_function> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x11d8520 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX11ScriptStatsES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::ScriptStats,RBX::ScriptStats>(
        boost::shared_ptr<RBX::ScriptStats> *ppx,
        RBX::ScriptStats *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A0F48;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x11d8a70 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13ScriptContextEEENS4_5list1INS4_5valueIPS9_EEEEEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ScriptContext>,boost::_bi::list1<boost::_bi::value<RBX::ScriptContext*>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ScriptContext>,boost::_bi::list1<boost::_bi::value<RBX::ScriptContext *> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A1058;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ScriptContext>,boost::_bi::list1<boost::_bi::value<RBX::ScriptContext*>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x11f8210 | Name: _ZN5boost10shared_ptrIN12_GLOBAL__N_111SharedStateEED2Ev
void __fastcall boost::shared_ptr<`anonymous namespace'::SharedState>::~shared_ptr(
        boost::shared_ptr<(anonymous namespace)::SharedState> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1200480 | Name: _ZN5boost10shared_ptrIN3RBX9Analytics16EphemeralCounter21EphemeralCounterStateEED2Ev
void __fastcall boost::shared_ptr<RBX::Analytics::EphemeralCounter::EphemeralCounterState>::~shared_ptr(
        boost::shared_ptr<RBX::Analytics::EphemeralCounter::EphemeralCounterState> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1200ce0 | Name: _ZN5boost10shared_ptrIN3RBX9Analytics11EventIngest16EventIngestStateEED2Ev
void __fastcall boost::shared_ptr<RBX::Analytics::EventIngest::EventIngestState>::~shared_ptr(
        boost::shared_ptr<RBX::Analytics::EventIngest::EventIngestState> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1203df0 | Name: _ZN5boost10shared_ptrIN3RBX9Analytics5Event15GAReporterStateEED2Ev
void __fastcall boost::shared_ptr<RBX::Analytics::Event::GAReporterState>::~shared_ptr(
        boost::shared_ptr<RBX::Analytics::Event::GAReporterState> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1204bf0 | Name: _ZN5boost23atomic_compare_exchangeINS_6detail12shared_stateIvEEEEbPNS_10shared_ptrIT_EES7_S6_
__int64 __fastcall boost::atomic_compare_exchange<boost::detail::shared_state<void>>(
        unsigned __int64 p,
        boost::shared_ptr<boost::detail::shared_state<void> > *v,
        boost::shared_ptr<boost::detail::shared_state<void> > w)
{
  unsigned __int64 v3; // rbx
  unsigned int v4; // r14d
  boost::shared_ptr<boost::detail::shared_state<void> >::element_type *v5; // rax
  boost::detail::sp_counted_base *v6; // rcx
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v8; // rcx
  boost::detail::sp_counted_base *v10; // rax
  boost::shared_ptr<boost::detail::shared_state<void> >::element_type *px; // [rsp+8h] [rbp-60h]
  __m128i v12; // [rsp+10h] [rbp-58h] BYREF
  struct timespec requested_time; // [rsp+20h] [rbp-48h] BYREF

  px = w.px;
  v3 = p % 0x29;
  if ( _InterlockedExchange(&dword_29F1450[p % 0x29], 1) )
  {
    v4 = 0;
    v12 = _mm_slli_si128((__m128i)0x3E8uLL, 8);
    do
    {
      if ( v4 >= 4 )
      {
        if ( v4 > 0xF )
        {
          if ( v4 < 0x20 || (v4 & 1) != 0 )
          {
            sched_yield();
          }
          else
          {
            requested_time = (struct timespec)_mm_load_si128(&v12);
            nanosleep(&requested_time, 0);
          }
        }
        else
        {
          _mm_pause();
        }
      }
      ++v4;
    }
    while ( _InterlockedExchange(&dword_29F1450[v3], 1) );
  }
  v5 = *(boost::shared_ptr<boost::detail::shared_state<void> >::element_type **)p;
  v6 = *(boost::detail::sp_counted_base **)(p + 8);
  if ( *(boost::shared_ptr<boost::detail::shared_state<void> >::element_type **)p == v->px && v6 == v->pn.pi_ )
  {
    *(_QWORD *)p = px->_vptr$shared_state_base;
    px->_vptr$shared_state_base = (int (**)(void))v5;
    v10 = (boost::detail::sp_counted_base *)px->weak_this_.px;
    v8 = *(boost::detail::sp_counted_base **)(p + 8);
    px->weak_this_.px = (boost::weak_ptr<boost::detail::shared_state_base>::element_type *)v8;
    *(_QWORD *)(p + 8) = v10;
    dword_29F1450[v3] = 0;
    LOBYTE(v8) = 1;
  }
  else
  {
    if ( v6 )
      _InterlockedAdd(&v6->use_count_, 1u);
    dword_29F1450[v3] = 0;
    v->px = v5;
    pi = v->pn.pi_;
    v->pn.pi_ = v6;
    if ( pi )
    {
      if ( !_InterlockedSub(&pi->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
    LODWORD(v8) = 0;
  }
  return (unsigned int)v8;
}


// Address: 0x1204e70 | Name: _ZN5boost6detail20sp_pointer_constructINS0_12shared_stateIvEES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::shared_state<void>,boost::detail::shared_state<void>>(
        boost::shared_ptr<boost::detail::shared_state<void> > *ppx,
        boost::detail::shared_state<void>_0 *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A2328;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::shared_state_base>::_internal_accept_owner<boost::detail::shared_state<void>,boost::detail::shared_state<void>>(
      &p->boost::enable_shared_from_this<boost::detail::shared_state_base>,
      ppx,
      p);
}


// Address: 0x12138e0 | Name: _ZN5boost10shared_ptrIN3RBX18HttpQueueStatsItemEED2Ev
void __fastcall boost::shared_ptr<RBX::HttpQueueStatsItem>::~shared_ptr(
        boost::shared_ptr<RBX::HttpQueueStatsItem> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x122a1e0 | Name: _ZN5boost10shared_ptrIN3RBX24CacheableContentProvider10CachedItemEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::CacheableContentProvider::CachedItem>::shared_ptr<RBX::CacheableContentProvider::CachedItem>(
        boost::shared_ptr<RBX::CacheableContentProvider::CachedItem> *this,
        RBX::CacheableContentProvider::CachedItem *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::CacheableContentProvider::CachedItem>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x122ad10 | Name: _ZN5boost10shared_ptrIKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEC2IS7_EEPT_
void __fastcall boost::shared_ptr<std::string const>::shared_ptr<std::string>(
        boost::shared_ptr<const std::string > *this,
        std::string *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<std::string>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x122ae00 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX24CacheableContentProviderEEENS4_5list1INS4_5valueIPS9_EEEEEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::CacheableContentProvider>,boost::_bi::list1<boost::_bi::value<RBX::CacheableContentProvider*>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::CacheableContentProvider>,boost::_bi::list1<boost::_bi::value<RBX::CacheableContentProvider *> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A33E8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::CacheableContentProvider>,boost::_bi::list1<boost::_bi::value<RBX::CacheableContentProvider*>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x12384c0 | Name: _ZNK3RBX15ContentProvider19getRequestQueueSizeEv
int __fastcall RBX::ContentProvider::getRequestQueueSize(const RBX::ContentProvider *this)
{
  return RBX::AsyncHttpQueue::getRequestQueueSize(*((const RBX::AsyncHttpQueue **)this + 19));
}


// Address: 0x1239bb0 | Name: _ZN3RBX15ContentProvider12setCacheSizeEi
void __fastcall RBX::ContentProvider::setCacheSize(RBX::ContentProvider *this, int count)
{
  RBX::AsyncHttpCache<RBX::CachedContent>::setCacheSize(*((RBX::AsyncHttpCache<RBX::CachedContent> **)this + 19), count);
}


// Address: 0x1239bc0 | Name: _ZNK3RBX15ContentProvider21getFailedRequestCountEv
int __fastcall RBX::ContentProvider::getFailedRequestCount(const RBX::ContentProvider *this)
{
  return RBX::AsyncHttpQueue::getFailedRequestCount(*((const RBX::AsyncHttpQueue **)this + 19));
}


// Address: 0x1240150 | Name: _ZN3RBX15ContentProvider19isRequestQueueEmptyEv
bool __fastcall RBX::ContentProvider::isRequestQueueEmpty(RBX::ContentProvider *this)
{
  return RBX::AsyncHttpQueue::isRequestQueueEmpty(*((RBX::AsyncHttpQueue **)this + 19));
}


// Address: 0x12434e0 | Name: _ZN3RBX15ContentProvider12clearContentEv
void __fastcall RBX::ContentProvider::clearContent(RBX::ContentProvider *this)
{
  RBX::AsyncHttpCache<RBX::CachedContent>::clearCache(*((RBX::AsyncHttpCache<RBX::CachedContent> **)this + 19));
}


// Address: 0x12540a0 | Name: _ZN5boost10shared_ptrIN3RBX13BatchAssetApiEED2Ev
void __fastcall boost::shared_ptr<RBX::BatchAssetApi>::~shared_ptr(boost::shared_ptr<RBX::BatchAssetApi> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1254200 | Name: _ZN5boost10shared_ptrIN3RBX21BatchThumbnailFetcherEED2Ev
void __fastcall boost::shared_ptr<RBX::BatchThumbnailFetcher>::~shared_ptr(
        boost::shared_ptr<RBX::BatchThumbnailFetcher> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1254240 | Name: _ZN5boost10shared_ptrIN3RBX14AsyncHttpCacheINS1_13CachedContentEEEE5resetIS4_EEvPT_
void __fastcall boost::shared_ptr<RBX::AsyncHttpCache<RBX::CachedContent>>::reset<RBX::AsyncHttpCache<RBX::CachedContent>>(
        boost::shared_ptr<RBX::AsyncHttpCache<RBX::CachedContent> > *this,
        RBX::AsyncHttpCache<RBX::CachedContent> *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::AsyncHttpCache<RBX::CachedContent>,RBX::AsyncHttpCache<RBX::CachedContent>>(
    (boost::shared_ptr<RBX::AsyncHttpCache<RBX::CachedContent> > *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::AsyncHttpCache<RBX::CachedContent> > *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x12543f0 | Name: _ZN5boost10shared_ptrIN3RBX14AsyncHttpCacheINS1_13CachedContentEEEED2Ev
void __fastcall boost::shared_ptr<RBX::AsyncHttpCache<RBX::CachedContent>>::~shared_ptr(
        boost::shared_ptr<RBX::AsyncHttpCache<RBX::CachedContent> > *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x125c5d0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX14AsyncHttpCacheINS2_13CachedContentEEES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::AsyncHttpCache<RBX::CachedContent>,RBX::AsyncHttpCache<RBX::CachedContent>>(
        boost::shared_ptr<RBX::AsyncHttpCache<RBX::CachedContent> > *ppx,
        RBX::AsyncHttpCache<RBX::CachedContent> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A4498;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::AsyncHttpQueue>::_internal_accept_owner<RBX::AsyncHttpCache<RBX::CachedContent>,RBX::AsyncHttpCache<RBX::CachedContent>>(
      &p->boost::enable_shared_from_this<RBX::AsyncHttpQueue>,
      ppx,
      p);
}


// Address: 0x125f140 | Name: _ZN5boost6detail20sp_pointer_constructINSt3__113basic_istreamIcNS2_11char_traitsIcEEEENS2_14basic_ifstreamIcS5_EEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<std::istream,std::ifstream>(
        boost::shared_ptr<std::istream > *ppx,
        std::ifstream *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A4788;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1281840 | Name: _ZN5boost6detail20sp_pointer_constructINS_6random23mersenne_twister_engineIjLm32ELm624ELm397ELm31ELj2567483615ELm11ELj4294967295ELm7ELj2636928640ELm15ELj4022730752ELm18ELj1812433253EEES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>,boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>>(
        boost::shared_ptr<boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> > *ppx,
        boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A5348;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x12946a0 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX17HttpClientHandlerEEENS4_5list1INS4_5valueIPS9_EEEEEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClientHandler>,boost::_bi::list1<boost::_bi::value<RBX::HttpClientHandler*>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClientHandler>,boost::_bi::list1<boost::_bi::value<RBX::HttpClientHandler *> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A5B18;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClientHandler>,boost::_bi::list1<boost::_bi::value<RBX::HttpClientHandler*>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1295340 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX10HttpClientEEENS4_5list1INS4_5valueIPS9_EEEEEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClient>,boost::_bi::list1<boost::_bi::value<RBX::HttpClient*>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClient>,boost::_bi::list1<boost::_bi::value<RBX::HttpClient *> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A5C88;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClient>,boost::_bi::list1<boost::_bi::value<RBX::HttpClient*>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x129fb20 | Name: _ZN5boost23atomic_compare_exchangeINS_6detail12shared_stateINS_10shared_ptrIN3RBX12HttpResponseEEEEEEEbPNS3_IT_EESA_S9_
__int64 __fastcall boost::atomic_compare_exchange<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>>(
        unsigned __int64 p,
        boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > > *v,
        boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > > w)
{
  unsigned __int64 v3; // rbx
  unsigned int v4; // r14d
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type *v5; // rax
  boost::detail::sp_counted_base *v6; // rcx
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v8; // rcx
  boost::detail::sp_counted_base *v10; // rax
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type *px; // [rsp+8h] [rbp-60h]
  __m128i v12; // [rsp+10h] [rbp-58h] BYREF
  struct timespec requested_time; // [rsp+20h] [rbp-48h] BYREF

  px = w.px;
  v3 = p % 0x29;
  if ( _InterlockedExchange(&dword_29F1450[p % 0x29], 1) )
  {
    v4 = 0;
    v12 = _mm_slli_si128((__m128i)0x3E8uLL, 8);
    do
    {
      if ( v4 >= 4 )
      {
        if ( v4 > 0xF )
        {
          if ( v4 < 0x20 || (v4 & 1) != 0 )
          {
            sched_yield();
          }
          else
          {
            requested_time = (struct timespec)_mm_load_si128(&v12);
            nanosleep(&requested_time, 0);
          }
        }
        else
        {
          _mm_pause();
        }
      }
      ++v4;
    }
    while ( _InterlockedExchange(&dword_29F1450[v3], 1) );
  }
  v5 = *(boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type **)p;
  v6 = *(boost::detail::sp_counted_base **)(p + 8);
  if ( *(boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type **)p == v->px
    && v6 == v->pn.pi_ )
  {
    *(_QWORD *)p = px->_vptr$shared_state_base;
    px->_vptr$shared_state_base = (int (**)(void))v5;
    v10 = (boost::detail::sp_counted_base *)px->weak_this_.px;
    v8 = *(boost::detail::sp_counted_base **)(p + 8);
    px->weak_this_.px = (boost::weak_ptr<boost::detail::shared_state_base>::element_type *)v8;
    *(_QWORD *)(p + 8) = v10;
    dword_29F1450[v3] = 0;
    LOBYTE(v8) = 1;
  }
  else
  {
    if ( v6 )
      _InterlockedAdd(&v6->use_count_, 1u);
    dword_29F1450[v3] = 0;
    v->px = v5;
    pi = v->pn.pi_;
    v->pn.pi_ = v6;
    if ( pi )
    {
      if ( !_InterlockedSub(&pi->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
    LODWORD(v8) = 0;
  }
  return (unsigned int)v8;
}


// Address: 0x129fe90 | Name: _ZN5boost6detail20sp_pointer_constructINS0_12shared_stateINS_10shared_ptrIN3RBX12HttpResponseEEEEES7_EEvPNS3_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>,boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>>(
        boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > > *ppx,
        boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >_0 *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A61A8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::shared_state_base>::_internal_accept_owner<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>,boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>>(
      &p->boost::enable_shared_from_this<boost::detail::shared_state_base>,
      ppx,
      p);
}


// Address: 0x12d87f0 | Name: _ZN3RBX5Pages14getCurrentPageEv
boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >::element_type **__fastcall RBX::Pages::getCurrentPage(
        boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >::element_type **a1,
        RBX::Pages *this)
{
  boost::detail::sp_counted_base *pi; // rax

  *a1 = this->currentPage.px;
  pi = this->currentPage.pn.pi_;
  a1[1] = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  return a1;
}


// Address: 0x12e7830 | Name: _ZN5boost10shared_ptrIN3RBX14AsyncHttpCacheINS1_13LuaWebService23CachedLuaWebServiceInfoEEEE5resetIS5_EEvPT_
void __fastcall boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo>>::reset<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo>>(
        boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo> > *this,
        RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo> *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo>,RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo>>(
    (boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo> > *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo> > *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x12e78e0 | Name: _ZN5boost10shared_ptrIN3RBX14AsyncHttpCacheINS1_13LuaWebService26CachedRawLuaWebServiceInfoEEEE5resetIS5_EEvPT_
void __fastcall boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo>>::reset<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo>>(
        boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo> > *this,
        RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo> *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo>,RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo>>(
    (boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo> > *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo> > *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x12f2bf0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX14AsyncHttpCacheINS2_13LuaWebService23CachedLuaWebServiceInfoEEES6_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo>,RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo>>(
        boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo> > *ppx,
        RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A7258;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::AsyncHttpQueue>::_internal_accept_owner<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo>,RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo>>(
      &p->boost::enable_shared_from_this<RBX::AsyncHttpQueue>,
      ppx,
      p);
}


// Address: 0x12f5e80 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX14AsyncHttpCacheINS2_13LuaWebService26CachedRawLuaWebServiceInfoEEES6_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo>,RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo>>(
        boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo> > *ppx,
        RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A7428;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::AsyncHttpQueue>::_internal_accept_owner<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo>,RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo>>(
      &p->boost::enable_shared_from_this<RBX::AsyncHttpQueue>,
      ppx,
      p);
}


// Address: 0x130ad80 | Name: _ZN3RBX10RunService13getPhysicsJobEv
RBX::TaskScheduler::Job *__fastcall RBX::RunService::getPhysicsJob(RBX::RunService *this)
{
  return (RBX::TaskScheduler::Job *)this->physicsJob.px;
}


// Address: 0x130ad90 | Name: _ZN3RBX10RunService12getHeartbeatEv
RBX::TaskScheduler::Job *__fastcall RBX::RunService::getHeartbeat(RBX::RunService *this)
{
  return (RBX::TaskScheduler::Job *)this->heartbeatTask.px;
}


// Address: 0x13106a0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX10PhysicsJobES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::PhysicsJob,RBX::PhysicsJob>(
        boost::shared_ptr<RBX::PhysicsJob> *ppx,
        RBX::PhysicsJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A8278;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::PhysicsJob,RBX::PhysicsJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1310850 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX13HeartbeatTaskES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::HeartbeatTask,RBX::HeartbeatTask>(
        boost::shared_ptr<RBX::HeartbeatTask> *ppx,
        RBX::HeartbeatTask *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28A82D8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::HeartbeatTask,RBX::HeartbeatTask>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1313500 | Name: _ZN3RBX11SimpleTimerC2ERKN5boost10shared_ptrINS_9TimerDataEEE
void __fastcall RBX::SimpleTimer::SimpleTimer(
        RBX::SimpleTimer *this,
        const boost::shared_ptr<RBX::TimerData> *timerData)
{
  boost::detail::sp_counted_base *pi; // rax

  this->timerData.px = timerData->px;
  pi = timerData->pn.pi_;
  this->timerData.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
}


// Address: 0x1313a30 | Name: _ZN5boost10shared_ptrIN3RBX14TimerTickerJobEED2Ev
void __fastcall boost::shared_ptr<RBX::TimerTickerJob>::~shared_ptr(boost::shared_ptr<RBX::TimerTickerJob> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1314350 | Name: _ZNK3RBX10Soundscape12SoundChannel9getVolumeEv
float __fastcall RBX::Soundscape::SoundChannel::getVolume(const RBX::Soundscape::SoundChannel *this)
{
  return *(double *)(*((_QWORD *)this + 19) + 64LL);
}


// Address: 0x13143c0 | Name: _ZNK3RBX10Soundscape12SoundChannel8getPitchEv
float __fastcall RBX::Soundscape::SoundChannel::getPitch(const RBX::Soundscape::SoundChannel *this)
{
  return *(double *)(*((_QWORD *)this + 19) + 72LL);
}


// Address: 0x1314440 | Name: _ZNK3RBX10Soundscape12SoundChannel14getMinDistanceEv
float __fastcall RBX::Soundscape::SoundChannel::getMinDistance(const RBX::Soundscape::SoundChannel *this)
{
  return *(double *)(*((_QWORD *)this + 19) + 80LL);
}


// Address: 0x1314540 | Name: _ZNK3RBX10Soundscape12SoundChannel17luaGetSoundLengthEv
double __fastcall RBX::Soundscape::SoundChannel::luaGetSoundLength(const RBX::Soundscape::SoundChannel *this)
{
  return *(double *)(*((_QWORD *)this + 19) + 48LL);
}


// Address: 0x1314550 | Name: _ZNK3RBX10Soundscape12SoundChannel15getTimePositionEv
double __fastcall RBX::Soundscape::SoundChannel::getTimePosition(const RBX::Soundscape::SoundChannel *this)
{
  return *(double *)(*((_QWORD *)this + 19) + 56LL);
}


// Address: 0x13146b0 | Name: _ZNK3RBX10Soundscape12SoundChannel19getPlaybackLoudnessEv
float __fastcall RBX::Soundscape::SoundChannel::getPlaybackLoudness(const RBX::Soundscape::SoundChannel *this)
{
  return RBX::Soundscape::FMODPlaybackChannel::getPlaybackLoudness(*((const RBX::Soundscape::FMODPlaybackChannel **)this
                                                                   + 19));
}


// Address: 0x13146c0 | Name: _ZNK3RBX10Soundscape12SoundChannel9getLoopedEv
bool __fastcall RBX::Soundscape::SoundChannel::getLooped(const RBX::Soundscape::SoundChannel *this)
{
  return *(_BYTE *)(*((_QWORD *)this + 19) + 96LL);
}


// Address: 0x1314940 | Name: _ZNK3RBX10Soundscape12SoundChannel12getIsPlayingEv
bool __fastcall RBX::Soundscape::SoundChannel::getIsPlaying(const RBX::Soundscape::SoundChannel *this)
{
  return *(_BYTE *)(*((_QWORD *)this + 19) + 44LL);
}


// Address: 0x1314950 | Name: _ZNK3RBX10Soundscape12SoundChannel11getIsPausedEv
bool __fastcall RBX::Soundscape::SoundChannel::getIsPaused(const RBX::Soundscape::SoundChannel *this)
{
  return *(_BYTE *)(*((_QWORD *)this + 19) + 44LL) == 0;
}


// Address: 0x13177d0 | Name: _ZNK3RBX10Soundscape12SoundChannel12getIsSound3DEv
bool __fastcall RBX::Soundscape::SoundChannel::getIsSound3D(const RBX::Soundscape::SoundChannel *this)
{
  return *(_BYTE *)(*((_QWORD *)this + 19) + 97LL);
}


// Address: 0x13177e0 | Name: _ZNK3RBX10Soundscape12SoundChannel18getSoundPosition3DEv
G3D::Vector3 __fastcall RBX::Soundscape::SoundChannel::getSoundPosition3D(const RBX::Soundscape::SoundChannel *this)
{
  __int64 v1; // rax
  G3D::Vector3 result; // 0:xmm0_8.8,8:xmm1_4.4

  v1 = *((_QWORD *)this + 19);
  *(_QWORD *)&result.x = *(_QWORD *)(v1 + 100);
  result.z = *(float *)(v1 + 108);
  return result;
}


// Address: 0x1318710 | Name: _ZN3rbx7signals17slot_with_functorIZN3RBX10Soundscape12SoundChannel17onAncestorChangedERKNS2_15AncestorChangedEE3$_2JiEE7do_callEPNS0_9slot_baseEi
void __fastcall rbx::signals::slot_with_functor<RBX::Soundscape::SoundChannel::onAncestorChanged(RBX::AncestorChanged const&)::$_2,int>::do_call(
        rbx::signals::slot_base *slot,
        int args)
{
  RBX::Soundscape::SoundChannel::playbackActionSync(
    *(RBX::Soundscape::SoundChannel **)&slot[1].rbx::intrusive_ptr_target<rbx::signals::slot_base>,
    args);
}


// Address: 0x1320ef0 | Name: _ZNK3RBX10Soundscape19FMODPlaybackChannel14hasLoadedSoundEv
bool __fastcall RBX::Soundscape::FMODPlaybackChannel::hasLoadedSound(const RBX::Soundscape::FMODPlaybackChannel *this)
{
  return *((_QWORD *)this + 2) != 0;
}


// Address: 0x132bc50 | Name: _ZN5boost10shared_ptrIN3RBX10Soundscape15FMODPlaybackDSPEED2Ev
void __fastcall boost::shared_ptr<RBX::Soundscape::FMODPlaybackDSP>::~shared_ptr(
        boost::shared_ptr<RBX::Soundscape::FMODPlaybackDSP> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1341920 | Name: _ZN5boost10shared_ptrIN4FMOD6SystemEE5resetIS2_17FMODSystemReleaseEEvPT_T0_
void __fastcall boost::shared_ptr<FMOD::System>::reset<FMOD::System,FMODSystemRelease>(
        boost::shared_ptr<FMOD::System> *this,
        FMOD::System *p,
        FMODSystemRelease d)
{
  boost::detail::sp_counted_base *v3; // rax
  boost::detail::sp_counted_base *pi; // r14

  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AE5B8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->px = p;
  pi = this->pn.pi_;
  this->pn.pi_ = v3;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1344840 | Name: _ZN5boost10shared_ptrIN3RBX10Soundscape26NonBlockingFmodSoundLoaderEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>(
        boost::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader> *this,
        RBX::Soundscape::NonBlockingFmodSoundLoader *p)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::shared_count v3; // [rsp+8h] [rbp-20h] BYREF

  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Soundscape::NonBlockingFmodSoundLoader>(&v3, p);
  pi = this->pn.pi_;
  this->pn = v3;
  v3.pi_ = pi;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::Soundscape::NonBlockingFmodSoundLoader>::_internal_accept_owner<RBX::Soundscape::NonBlockingFmodSoundLoader,RBX::Soundscape::NonBlockingFmodSoundLoader>(
      (const boost::enable_shared_from_this<RBX::Soundscape::NonBlockingFmodSoundLoader> *)p,
      this,
      p);
}


// Address: 0x13481d0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX10Soundscape8SoundJobES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Soundscape::SoundJob,RBX::Soundscape::SoundJob>(
        boost::shared_ptr<RBX::Soundscape::SoundJob> *ppx,
        RBX::Soundscape::SoundJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28AE678;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Soundscape::SoundJob,RBX::Soundscape::SoundJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x13518e0 | Name: _ZN5boost10shared_ptrIN3RBX14BaseThreadPool8PoolDataEED2Ev
void __fastcall boost::shared_ptr<RBX::BaseThreadPool::PoolData>::~shared_ptr(
        boost::shared_ptr<RBX::BaseThreadPool::PoolData> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1352700 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX14BaseThreadPool8PoolDataES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::BaseThreadPool::PoolData,RBX::BaseThreadPool::PoolData>(
        boost::shared_ptr<RBX::BaseThreadPool::PoolData> *ppx,
        RBX::BaseThreadPool::PoolData *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28AEB18;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1352e10 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvPFvPKcNS_10shared_ptrIN3RBX14BaseThreadPool8PoolDataEEENSA_14ShutdownPolicyEENS4_5list3INS4_5valueIS7_EENSH_ISC_EENSH_ISD_EEEEEEEEEEvPNS8_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<char const*>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData>>,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const char *,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<const char *>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData> >,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28AEBC8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<char const*>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData>>,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x13612f0 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX8WsClientEEENS4_5list1INS4_5valueIPS9_EEEEEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::WsClient>,boost::_bi::list1<boost::_bi::value<RBX::WsClient*>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::WsClient>,boost::_bi::list1<boost::_bi::value<RBX::WsClient *> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28AEF68;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::WsClient>,boost::_bi::list1<boost::_bi::value<RBX::WsClient*>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1369b80 | Name: _ZN5boost10shared_ptrINSt3__113basic_istreamIcNS1_11char_traitsIcEEEEE5resetINS1_19basic_istringstreamIcS4_NS1_9allocatorIcEEEEEEvPT_
void __fastcall boost::shared_ptr<std::istream>::reset<std::istringstream>(
        boost::shared_ptr<std::istream > *this,
        std::istringstream *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<std::istream,std::istringstream>(
    (boost::shared_ptr<std::istream > *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<std::istream > *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x1369ff0 | Name: _ZN5boost6detail20sp_pointer_constructINSt3__113basic_istreamIcNS2_11char_traitsIcEEEENS2_19basic_istringstreamIcS5_NS2_9allocatorIcEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<std::istream,std::istringstream>(
        boost::shared_ptr<std::istream > *ppx,
        std::istringstream *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28AF1A8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x136fe20 | Name: _ZN3RBX13BatchAssetApi12resolveAssetERKNS_10HttpTargetEfON5boost8functionIFvRKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEfPSD_EEE
void __fastcall RBX::BatchAssetApi::resolveAsset(
        RBX::BatchAssetApi *this,
        const RBX::HttpTarget *target,
        float prio,
        RBX::BatchAssetApi::ResolveCallback *callback)
{
  RBX::BatchAssetApiState::resolveAsset(this->ba.px, target, prio, callback);
}


// Address: 0x136fe30 | Name: _ZN3RBX13BatchAssetApi21updateRequestPriorityERKNS_10HttpTargetEf
__int64 __fastcall RBX::BatchAssetApi::updateRequestPriority(
        RBX::BatchAssetApi *this,
        const RBX::HttpTarget *target,
        float a3,
        float prio)
{
  return RBX::BatchAssetApiState::updateRequestPriority(this->ba.px, target, a3, prio);
}


// Address: 0x1370140 | Name: _ZN5boost6detail11thread_dataIZN3RBX18BatchAssetApiState17startWorkerThreadEvE3$_0E3runEv
void __fastcall boost::detail::thread_data<RBX::BatchAssetApiState::startWorkerThread(void)::$_0>::run(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_Shared_HttpBatchAsset_cpp:350:38)> *this)
{
  RBX::BatchAssetApiState::workerThreadFunction(*((RBX::BatchAssetApiState **)this + 52));
}


// Address: 0x13f66f0 | Name: _ZN5boost10shared_ptrIN3RBX13AdvLuaDraggerEED2Ev
void __fastcall boost::shared_ptr<RBX::AdvLuaDragger>::~shared_ptr(boost::shared_ptr<RBX::AdvLuaDragger> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x14132c0 | Name: _ZN5boost10shared_ptrIN3RBX10AttachmentEED2Ev
void __fastcall boost::shared_ptr<RBX::Attachment>::~shared_ptr(boost::shared_ptr<RBX::Attachment> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1436600 | Name: _ZN5boost10shared_ptrIN3RBX11HandlesBase20MouseDownCaptureInfoEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::HandlesBase::MouseDownCaptureInfo>::reset<RBX::HandlesBase::MouseDownCaptureInfo>(
        boost::shared_ptr<RBX::HandlesBase::MouseDownCaptureInfo> *this,
        RBX::HandlesBase::MouseDownCaptureInfo *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::HandlesBase::MouseDownCaptureInfo,RBX::HandlesBase::MouseDownCaptureInfo>(
    (boost::shared_ptr<RBX::HandlesBase::MouseDownCaptureInfo> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::HandlesBase::MouseDownCaptureInfo> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x1439310 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX11HandlesBase20MouseDownCaptureInfoES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::HandlesBase::MouseDownCaptureInfo,RBX::HandlesBase::MouseDownCaptureInfo>(
        boost::shared_ptr<RBX::HandlesBase::MouseDownCaptureInfo> *ppx,
        RBX::HandlesBase::MouseDownCaptureInfo *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28B69A8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x149ddb0 | Name: _ZNK3RBX6Camera33getCameraSubjectInstanceDangerousEv
RBX::Instance *__fastcall RBX::Camera::getCameraSubjectInstanceDangerous(const RBX::Camera *this)
{
  return (RBX::Instance *)*((_QWORD *)this + 62);
}


// Address: 0x14a0ad0 | Name: _ZNK3RBX6Camera21isLockedToFirstPersonEv
bool __fastcall RBX::Camera::isLockedToFirstPerson(const RBX::Camera *this)
{
  const void *v1; // rdi
  _DWORD *v2; // rax

  v1 = (const void *)*((_QWORD *)this + 62);
  if ( !v1 )
    return 0;
  v2 = __dynamic_cast(
         v1,
         (const struct __class_type_info *)&`typeinfo for'RBX::Instance,
         (const struct __class_type_info *)&`typeinfo for'RBX::ICharacterSubject,
         -2);
  return v2 && v2[3] == 1;
}


// Address: 0x14a0c80 | Name: _ZN3RBX6Camera16getCameraSubjectEv
RBX::CameraSubject *__fastcall RBX::Camera::getCameraSubject(RBX::Camera *this)
{
  const void *v1; // rdi

  v1 = (const void *)*((_QWORD *)this + 62);
  if ( v1 )
    return (RBX::CameraSubject *)__dynamic_cast(
                                   v1,
                                   (const struct __class_type_info *)&`typeinfo for'RBX::Instance,
                                   (const struct __class_type_info *)&`typeinfo for'RBX::CameraSubject,
                                   -2);
  else
    return 0;
}


// Address: 0x14a4500 | Name: _ZNK3RBX6Camera21getConstCameraSubjectEv
const RBX::CameraSubject *__fastcall RBX::Camera::getConstCameraSubject(const RBX::Camera *this)
{
  const void *v1; // rdi

  v1 = (const void *)*((_QWORD *)this + 62);
  if ( v1 )
    return (const RBX::CameraSubject *)__dynamic_cast(
                                         v1,
                                         (const struct __class_type_info *)&`typeinfo for'RBX::Instance,
                                         (const struct __class_type_info *)&`typeinfo for'RBX::CameraSubject,
                                         -2);
  else
    return 0;
}


// Address: 0x14acfe0 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIKNSt3__16vectorINS3_IN3RBX8InstanceEEENS4_9allocatorIS8_EEEEEEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>>::construct_func(
        const char *src,
        char *dest)
{
  __int64 v2; // rax

  *(_QWORD *)dest = *(_QWORD *)src;
  v2 = *((_QWORD *)src + 1);
  *((_QWORD *)dest + 1) = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
}


// Address: 0x14adf30 | Name: _ZN5boost6detail20sp_pointer_constructINSt3__16vectorINS_10shared_ptrIN3RBX8InstanceEEENS2_9allocatorIS7_EEEESA_EEvPNS4_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<std::vector<boost::shared_ptr<RBX::Instance>>,std::vector<boost::shared_ptr<RBX::Instance>>>(
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *ppx,
        std::vector<boost::shared_ptr<RBX::Instance>> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28BA918;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x14f5970 | Name: _ZNK3RBX19LocalizationService23getIsTextScraperRunningEv
bool __fastcall RBX::LocalizationService::getIsTextScraperRunning(const RBX::LocalizationService *this)
{
  return RBX::TextScraper::isRunning(*((const RBX::TextScraper **)this + 65));
}


// Address: 0x1506d50 | Name: _ZN3RBX19LocalizationService16addKnownUsernameERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::LocalizationService::addKnownUsername(RBX::LocalizationService *this, const std::string *username)
{
  RBX::TextScraper::addKnownUser(*((RBX::TextScraper **)this + 65), username);
}


// Address: 0x150adb0 | Name: _ZN5boost10shared_ptrISt9exceptionE5resetISt13runtime_errorEEvPT_
void __fastcall boost::shared_ptr<std::exception>::reset<std::runtime_error>(
        boost::shared_ptr<std::exception> *this,
        std::runtime_error *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<std::exception,std::runtime_error>(
    (boost::shared_ptr<std::exception> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<std::exception> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x15149e0 | Name: _ZN5boost6detail20sp_pointer_constructISt9exceptionSt13runtime_errorEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<std::exception,std::runtime_error>(
        boost::shared_ptr<std::exception> *ppx,
        std::runtime_error *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28BFA68;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1544420 | Name: _ZN5boost10shared_ptrIN3RBX17copy_on_write_ptrINSt3__16vectorINS0_INS1_8InstanceEEENS3_9allocatorIS6_EEEEEEEC2ISA_EEPT_
void __fastcall boost::shared_ptr<RBX::copy_on_write_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>::shared_ptr<RBX::copy_on_write_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>(
        boost::shared_ptr<RBX::copy_on_write_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > > *this,
        RBX::copy_on_write_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::copy_on_write_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>(
    &v4,
    p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x154c2a0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX7CSGMeshES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::CSGMesh,RBX::CSGMesh>(
        boost::shared_ptr<RBX::CSGMesh> *ppx,
        RBX::CSGMesh *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28C1CC8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x15698e0 | Name: _ZNK3RBX9DataModel11getGameTimeEv
double __fastcall RBX::DataModel::getGameTime(const RBX::DataModel *this)
{
  return *(double *)(*((_QWORD *)this + 95) + 176LL);
}


// Address: 0x15698f0 | Name: _ZNK3RBX9DataModel12getSmoothFpsEv
double __fastcall RBX::DataModel::getSmoothFps(const RBX::DataModel *this)
{
  return RBX::RunService::smoothFps(*((const RBX::RunService **)this + 95));
}


// Address: 0x1569970 | Name: _ZNK3RBX9DataModel24getAveUpdateBroadphaseDtEv
double __fastcall RBX::DataModel::getAveUpdateBroadphaseDt(const RBX::DataModel *this)
{
  return RBX::World::getUpdateBroadphaseDtAveMsec(*(const RBX::World **)(*((_QWORD *)this + 99) + 472LL));
}


// Address: 0x1569990 | Name: _ZNK3RBX9DataModel20getAveStepContactsDtEv
double __fastcall RBX::DataModel::getAveStepContactsDt(const RBX::DataModel *this)
{
  return RBX::World::getStepContactsDtAveMsec(*(const RBX::World **)(*((_QWORD *)this + 99) + 472LL));
}


// Address: 0x15699b0 | Name: _ZNK3RBX9DataModel31getWorldUnthrottledMarkReportedEv
double __fastcall RBX::DataModel::getWorldUnthrottledMarkReported(const RBX::DataModel *this)
{
  return RBX::World::getWorldUnthrottledMarkReported(*(RBX::World **)(*((_QWORD *)this + 99) + 472LL));
}


// Address: 0x15699d0 | Name: _ZNK3RBX9DataModel32getWorldUnthrottledReadyToReportEv
bool __fastcall RBX::DataModel::getWorldUnthrottledReadyToReport(const RBX::DataModel *this)
{
  return RBX::World::readyToReportSessionUnthrottled(*(RBX::World **)(*((_QWORD *)this + 99) + 472LL));
}


// Address: 0x15699f0 | Name: _ZNK3RBX9DataModel32getCurrentUnthrottledWorldStepIdEv
int __fastcall RBX::DataModel::getCurrentUnthrottledWorldStepId(const RBX::DataModel *this)
{
  return *(_DWORD *)(*(_QWORD *)(*((_QWORD *)this + 99) + 472LL) + 100LL);
}


// Address: 0x1569a10 | Name: _ZNK3RBX9DataModel25getInterpolationAverageDtERdRm
void __fastcall RBX::DataModel::getInterpolationAverageDt(const RBX::DataModel *this, double *avgOut, size_t *countOut)
{
  __int64 v3; // rax
  __int64 v4; // rcx
  size_t v5; // rax

  v3 = *((_QWORD *)this + 99);
  v4 = *(_QWORD *)(v3 + 720);
  v5 = *(_QWORD *)(v3 + 728);
  *(_QWORD *)avgOut = v4;
  *countOut = v5;
}


// Address: 0x15763f0 | Name: _ZN3RBX9DataModel24setAllowCustomAnimationsEb
void __fastcall RBX::DataModel::setAllowCustomAnimations(RBX::DataModel *this, bool v)
{
  RBX::StarterPlayerService::setAllowCustomAnimations(*((RBX::StarterPlayerService **)this + 93), v);
}


// Address: 0x1578890 | Name: _ZN3RBXL26getJobTimePeakFractionFuncEPNS_9DataModelEN5boost10shared_ptrIKNS_13TaskScheduler3JobEEERNSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEEdPd
void __fastcall RBX::getJobTimePeakFractionFunc(
        RBX::DataModel *dataModel,
        boost::shared_ptr<const RBX::TaskScheduler::Job> job,
        std::string *jobname,
        double greaterThan,
        double *result)
{
  _QWORD *v5; // r9
  char *v6; // rax
  unsigned __int64 v7; // r8
  double v8; // xmm1_8
  double *v9; // rsi
  unsigned __int64 v10; // rax
  double v11; // xmm1_8
  __m128i v12; // xmm0
  __m128i v13; // xmm0

  v5 = *(_QWORD **)job.px;
  v6 = (char *)dataModel + 128;
  if ( !dataModel )
    v6 = 0;
  if ( (char *)v5[6] == v6 )
  {
    v7 = v5[35];
    v8 = 0.0;
    if ( v7 )
    {
      v9 = (double *)v5[33];
      if ( v9 )
      {
        v10 = 0;
        do
        {
          v11 = *v9++;
          if ( v9 == (double *)v5[32] )
            v9 = (double *)v5[31];
          v10 += v11 > greaterThan;
          if ( v9 == (double *)v5[34] )
            v9 = 0;
        }
        while ( v9 );
        v12 = (__m128i)_mm_sub_pd(
                         (__m128d)_mm_unpacklo_epi32((__m128i)v10, (__m128i)xmmword_3E4930),
                         *(__m128d *)(&errorFunction.functor.data + 8));
        v8 = *(double *)_mm_shuffle_epi32(v12, 78).m128i_i64 + *(double *)v12.m128i_i64;
      }
    }
    v13 = (__m128i)_mm_sub_pd(
                     (__m128d)_mm_unpacklo_epi32((__m128i)v7, (__m128i)xmmword_3E4930),
                     *(__m128d *)(&errorFunction.functor.data + 8));
    *(double *)jobname = v8 / (*(double *)_mm_shuffle_epi32(v13, 78).m128i_i64 + *(double *)v13.m128i_i64);
  }
}


// Address: 0x1578960 | Name: _ZN3RBXL30getJobIntervalPeakFractionFuncEPNS_9DataModelEN5boost10shared_ptrIKNS_13TaskScheduler3JobEEERNSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEEdPd
void __fastcall RBX::getJobIntervalPeakFractionFunc(
        RBX::DataModel *dataModel,
        boost::shared_ptr<const RBX::TaskScheduler::Job> job,
        std::string *jobname,
        double greaterThan,
        double *result)
{
  _QWORD *v5; // r9
  char *v6; // rax
  unsigned __int64 v7; // r8
  double v8; // xmm1_8
  double *v9; // rsi
  unsigned __int64 v10; // rax
  double v11; // xmm1_8
  __m128i v12; // xmm0
  __m128i v13; // xmm0

  v5 = *(_QWORD **)job.px;
  v6 = (char *)dataModel + 128;
  if ( !dataModel )
    v6 = 0;
  if ( (char *)v5[6] == v6 )
  {
    v7 = v5[43];
    v8 = 0.0;
    if ( v7 )
    {
      v9 = (double *)v5[41];
      if ( v9 )
      {
        v10 = 0;
        do
        {
          v11 = *v9++;
          if ( v9 == (double *)v5[40] )
            v9 = (double *)v5[39];
          v10 += v11 > greaterThan;
          if ( v9 == (double *)v5[42] )
            v9 = 0;
        }
        while ( v9 );
        v12 = (__m128i)_mm_sub_pd(
                         (__m128d)_mm_unpacklo_epi32((__m128i)v10, (__m128i)xmmword_3E4930),
                         *(__m128d *)(&errorFunction.functor.data + 8));
        v8 = *(double *)_mm_shuffle_epi32(v12, 78).m128i_i64 + *(double *)v12.m128i_i64;
      }
    }
    v13 = (__m128i)_mm_sub_pd(
                     (__m128d)_mm_unpacklo_epi32((__m128i)v7, (__m128i)xmmword_3E4930),
                     *(__m128d *)(&errorFunction.functor.data + 8));
    *(double *)jobname = v8 / (*(double *)_mm_shuffle_epi32(v13, 78).m128i_i64 + *(double *)v13.m128i_i64);
  }
}


// Address: 0x157af60 | Name: _ZNK3RBX9DataModel14getLocalPeerIdEv
RBX::PeerId::Type __fastcall RBX::DataModel::getLocalPeerId(const RBX::DataModel *this)
{
  return *(_DWORD *)(*(_QWORD *)(*((_QWORD *)this + 99) + 472LL) + 928LL);
}


// Address: 0x1580fd0 | Name: _ZNK3RBX9DataModel12getWorkspaceEv
RBX::Workspace *__fastcall RBX::DataModel::getWorkspace(const RBX::DataModel *this)
{
  return (RBX::Workspace *)*((_QWORD *)this + 99);
}


// Address: 0x158b870 | Name: _ZN5boost10shared_ptrIN3RBX9DataModel16WindowInputStateEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::DataModel::WindowInputState>::shared_ptr<RBX::DataModel::WindowInputState>(
        boost::shared_ptr<RBX::DataModel::WindowInputState> *this,
        RBX::DataModel::WindowInputState *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::DataModel::WindowInputState>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1593f10 | Name: _ZN5boost10shared_ptrIN3RBX9DataModel10LegacyLock14Implementation6EventsEEC2IS5_EEPT_
void __fastcall boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>(
        boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events> *this,
        RBX::DataModel::LegacyLock::Implementation::Events *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::DataModel::LegacyLock::Implementation::Events>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x15a4780 | Name: _ZN5boost23atomic_compare_exchangeINS_6detail12shared_stateINS_10shared_ptrINSt3__16vectorINS3_INS5_INS3_IN3RBX8InstanceEEENS4_9allocatorIS8_EEEEEENS9_ISC_EEEEEEEEEEbPNS3_IT_EESJ_SI_
__int64 __fastcall boost::atomic_compare_exchange<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>>(
        unsigned __int64 p,
        boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > > *v,
        boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > > w)
{
  unsigned __int64 v3; // rbx
  unsigned int v4; // r14d
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type *v5; // rax
  boost::detail::sp_counted_base *v6; // rcx
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v8; // rcx
  boost::detail::sp_counted_base *v10; // rax
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type *px; // [rsp+8h] [rbp-60h]
  __m128i v12; // [rsp+10h] [rbp-58h] BYREF
  struct timespec requested_time; // [rsp+20h] [rbp-48h] BYREF

  px = w.px;
  v3 = p % 0x29;
  if ( _InterlockedExchange(&dword_29F1450[p % 0x29], 1) )
  {
    v4 = 0;
    v12 = _mm_slli_si128((__m128i)0x3E8uLL, 8);
    do
    {
      if ( v4 >= 4 )
      {
        if ( v4 > 0xF )
        {
          if ( v4 < 0x20 || (v4 & 1) != 0 )
          {
            sched_yield();
          }
          else
          {
            requested_time = (struct timespec)_mm_load_si128(&v12);
            nanosleep(&requested_time, 0);
          }
        }
        else
        {
          _mm_pause();
        }
      }
      ++v4;
    }
    while ( _InterlockedExchange(&dword_29F1450[v3], 1) );
  }
  v5 = *(boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type **)p;
  v6 = *(boost::detail::sp_counted_base **)(p + 8);
  if ( *(boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type **)p == v->px
    && v6 == v->pn.pi_ )
  {
    *(_QWORD *)p = px->_vptr$shared_state_base;
    px->_vptr$shared_state_base = (int (**)(void))v5;
    v10 = (boost::detail::sp_counted_base *)px->weak_this_.px;
    v8 = *(boost::detail::sp_counted_base **)(p + 8);
    px->weak_this_.px = (boost::weak_ptr<boost::detail::shared_state_base>::element_type *)v8;
    *(_QWORD *)(p + 8) = v10;
    dword_29F1450[v3] = 0;
    LOBYTE(v8) = 1;
  }
  else
  {
    if ( v6 )
      _InterlockedAdd(&v6->use_count_, 1u);
    dword_29F1450[v3] = 0;
    v->px = v5;
    pi = v->pn.pi_;
    v->pn.pi_ = v6;
    if ( pi )
    {
      if ( !_InterlockedSub(&pi->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
    LODWORD(v8) = 0;
  }
  return (unsigned int)v8;
}


// Address: 0x15a4af0 | Name: _ZN5boost6detail20sp_pointer_constructINS0_12shared_stateINS_10shared_ptrINSt3__16vectorINS3_INS5_INS3_IN3RBX8InstanceEEENS4_9allocatorIS8_EEEEEENS9_ISC_EEEEEEEESG_EEvPNS3_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>,boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>>(
        boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > > *ppx,
        boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28C7038;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::shared_state_base>::_internal_accept_owner<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>,boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>>(
      &p->boost::enable_shared_from_this<boost::detail::shared_state_base>,
      ppx,
      p);
}


// Address: 0x15a4e60 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrINSt3__16vectorINS3_IN3RBX8InstanceEEENS4_9allocatorIS8_EEEEEEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>::construct_func(
        const char *src,
        char *dest)
{
  __int64 v2; // rax

  *(_QWORD *)dest = *(_QWORD *)src;
  v2 = *((_QWORD *)src + 1);
  *((_QWORD *)dest + 1) = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
}


// Address: 0x15ace60 | Name: _ZN3RBX19LocalStorageService15getLocalStorageEv
boost::shared_ptr<RBX::LocalStorage>::element_type **__fastcall RBX::LocalStorageService::getLocalStorage(
        boost::shared_ptr<RBX::LocalStorage>::element_type **a1,
        RBX::LocalStorageService *this)
{
  boost::detail::sp_counted_base *pi; // rax

  *a1 = this->localStorage.px;
  pi = this->localStorage.pn.pi_;
  a1[1] = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  return a1;
}


// Address: 0x15b9ca0 | Name: _ZN3RBX29processInputForPlayerMovementERKNS_16PlayerActionTypeERKN5boost10shared_ptrINS_11InputObjectEEE
bool __fastcall RBX::processInputForPlayerMovement(
        const RBX::PlayerActionType *playerMovement,
        const boost::shared_ptr<RBX::InputObject> *inputObject)
{
  int v2; // eax
  bool result; // al

  if ( *((_DWORD *)inputObject->px + 32) != 8 )
    return 0;
  v2 = *((_DWORD *)inputObject->px + 56);
  if ( v2 > 272 )
  {
    if ( v2 == 273 )
    {
      if ( *playerMovement == RBX::PlayerActionType::CHARACTER_FORWARD )
        return 1;
    }
    else if ( v2 == 274 )
    {
LABEL_8:
      result = 1;
      if ( *playerMovement == RBX::PlayerActionType::CHARACTER_BACKWARD )
        return result;
    }
    return 0;
  }
  switch ( v2 )
  {
    case 'a':
      result = 1;
      if ( *playerMovement != RBX::PlayerActionType::CHARACTER_LEFT )
        return 0;
      break;
    case 'b':
    case 'c':
    case 'e':
    case 'f':
    case 'g':
    case 'h':
    case 'i':
    case 'j':
    case 'k':
    case 'l':
    case 'm':
    case 'n':
    case 'o':
    case 'p':
    case 'q':
    case 'r':
    case 't':
    case 'u':
    case 'v':
      return 0;
    case 'd':
      result = 1;
      if ( *playerMovement != RBX::PlayerActionType::CHARACTER_RIGHT )
        return 0;
      break;
    case 's':
      goto LABEL_8;
    case 'w':
      if ( *playerMovement )
        return 0;
      result = 1;
      break;
    default:
      if ( v2 != 32 )
        return 0;
      result = 1;
      if ( *playerMovement != RBX::PlayerActionType::CHARACTER_JUMP )
        return 0;
      break;
  }
  return result;
}


// Address: 0x15d20f0 | Name: _ZN5boost10shared_ptrIN3RBX7GuiItemEED2Ev
void __fastcall boost::shared_ptr<RBX::GuiItem>::~shared_ptr(boost::shared_ptr<RBX::GuiItem> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x15dbe10 | Name: _ZN5boost10shared_ptrIN3RBX12DataStoreJobEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RBX::DataStoreJob>::reset<RBX::DataStoreJob>(
        boost::shared_ptr<RBX::DataStoreJob> *this,
        RBX::DataStoreJob *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::DataStoreJob,RBX::DataStoreJob>(
    (boost::shared_ptr<RBX::DataStoreJob> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::DataStoreJob> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x15ddc30 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX12DataStoreJobES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::DataStoreJob,RBX::DataStoreJob>(
        boost::shared_ptr<RBX::DataStoreJob> *ppx,
        RBX::DataStoreJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28CA3D8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::DataStoreJob,RBX::DataStoreJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x160a1d0 | Name: _ZN5boost6detail8function26void_function_obj_invoker2IZN3RBX9DataStore12sendBatchGetERNSt3__118basic_stringstreamIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEE4$_18vPNS5_12basic_stringIcS8_SA_EEPSt9exceptionE6invokeERNS1_15function_bufferESG_SI_
void __fastcall boost::detail::function::void_function_obj_invoker2<RBX::DataStore::sendBatchGet(std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>> &)::$_18,void,std::string *,std::exception *>::invoke(
        boost::detail::function::function_buffer *function_obj_ptr,
        std::string *a0,
        std::exception *a1)
{
  RBX::DataStore::processFetchCachedKeys((RBX::DataStore *)function_obj_ptr->obj_ptr, a0, a1);
}


// Address: 0x161d8d0 | Name: _ZN5boost10shared_ptrIN12_GLOBAL__N_121DynamicSettingsPickerEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<`anonymous namespace'::DynamicSettingsPicker>::shared_ptr<`anonymous namespace'::DynamicSettingsPicker>(
        boost::shared_ptr<(anonymous namespace)::DynamicSettingsPicker> *this,
        `anonymous namespace'::DynamicSettingsPicker *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->px = p;
  this->pn.pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28CD9C8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pn.pi_ = v2;
}


// Address: 0x161fe40 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX27DynamicFastVariableReloaderEEENS4_5list1INS4_5valueIPS9_EEEEEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::DynamicFastVariableReloader>,boost::_bi::list1<boost::_bi::value<RBX::DynamicFastVariableReloader*>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::DynamicFastVariableReloader>,boost::_bi::list1<boost::_bi::value<RBX::DynamicFastVariableReloader *> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28CDB18;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::DynamicFastVariableReloader>,boost::_bi::list1<boost::_bi::value<RBX::DynamicFastVariableReloader*>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1651870 | Name: _ZN5boost10shared_ptrIN3RBX9DataModelEED2Ev
void __fastcall boost::shared_ptr<RBX::DataModel>::~shared_ptr(boost::shared_ptr<RBX::DataModel> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1651b00 | Name: _ZN5boost10shared_ptrIN3RBX11CommonVerbsEED2Ev
void __fastcall boost::shared_ptr<RBX::CommonVerbs>::~shared_ptr(boost::shared_ptr<RBX::CommonVerbs> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1651c90 | Name: _ZN5boost10shared_ptrIN3RBX16PlayerConfigurerEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RBX::PlayerConfigurer>::reset<RBX::PlayerConfigurer>(
        boost::shared_ptr<RBX::PlayerConfigurer> *this,
        RBX::PlayerConfigurer *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::PlayerConfigurer,RBX::PlayerConfigurer>(
    (boost::shared_ptr<RBX::PlayerConfigurer> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::PlayerConfigurer> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x1651fb0 | Name: _ZN5boost10shared_ptrIN3RBX11CommonVerbsEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::CommonVerbs>::shared_ptr<RBX::CommonVerbs>(
        boost::shared_ptr<RBX::CommonVerbs> *this,
        RBX::CommonVerbs *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::CommonVerbs>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1652810 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX16PlayerConfigurerES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::PlayerConfigurer,RBX::PlayerConfigurer>(
        boost::shared_ptr<RBX::PlayerConfigurer> *ppx,
        RBX::PlayerConfigurer *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28D0B68;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::GameConfigurer>::_internal_accept_owner<RBX::PlayerConfigurer,RBX::PlayerConfigurer>(
      (const boost::enable_shared_from_this<RBX::GameConfigurer> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x16eaf80 | Name: _ZN3RBX13DragUtilities14getPrimitives2EN5boost10shared_ptrINS_8InstanceEEERNSt3__16vectorIPNS_9PrimitiveENS5_9allocatorIS8_EEEE
void __fastcall RBX::DragUtilities::getPrimitives2(
        boost::shared_ptr<RBX::Instance> instance,
        std::vector<RBX::Primitive *> *primitives)
{
  RBX::DragUtilities::getPrimitives(
    (const RBX::Instance *)instance.px->_vptr$EventSource,
    (std::vector<RBX::Primitive *> *)instance.pn.pi_);
}


// Address: 0x16f9710 | Name: _ZNK3RBX13VelocityMotor7getHoleEv
RBX::Hole *__fastcall RBX::VelocityMotor::getHole(const RBX::VelocityMotor *this)
{
  return this->hole.px;
}


// Address: 0x16fac00 | Name: _ZN3RBX13VelocityMotor27onEvent_HoleAncestorChangedEv
void __fastcall RBX::VelocityMotor::onEvent_HoleAncestorChanged(RBX::VelocityMotor *this)
{
  RBX::VelocityMotor::setPart(this, 1, this->hole.px);
}


// Address: 0x1708680 | Name: _ZN5boost6detail8function26void_function_obj_invoker0IZN3RBX9Explosion9onSteppedERKNS3_7SteppedEE3$_0vE6invokeERNS1_15function_bufferE
void __fastcall boost::detail::function::void_function_obj_invoker0<RBX::Explosion::onStepped(RBX::Stepped const&)::$_0,void>::invoke(
        boost::detail::function::function_buffer *function_obj_ptr)
{
  RBX::Instance::setParentInternal((RBX::Instance *)function_obj_ptr->obj_ptr, 0, 0);
}


// Address: 0x1750cf0 | Name: _ZN3RBX9GuiBase2d19layoutSizingChangedEv
void __fastcall RBX::GuiBase2d::layoutSizingChanged(RBX::GuiBase2d *this)
{
  RBX::LayoutNode::setLayoutDirty((RBX::LayoutNode *)this->layoutNode.px, 1);
}


// Address: 0x1750d10 | Name: _ZN3RBX9GuiBase2d24layoutPositioningChangedEv
void __fastcall RBX::GuiBase2d::layoutPositioningChanged(RBX::GuiBase2d *this)
{
  RBX::LayoutNode::setViewportDirty((RBX::LayoutNode *)this->layoutNode.px, 1);
}


// Address: 0x1750d30 | Name: _ZN3RBX9GuiBase2d25parentLayoutSizingChangedEv
void __fastcall RBX::GuiBase2d::parentLayoutSizingChanged(RBX::GuiBase2d *this)
{
  RBX::LayoutNode::parentLayoutSizingChanged((RBX::LayoutNode *)this->layoutNode.px);
}


// Address: 0x1751360 | Name: _ZN3RBX9GuiBase2d12updateLayoutEPKc
void __fastcall RBX::GuiBase2d::updateLayout(RBX::GuiBase2d *this, const char *context)
{
  RBX::LayoutNode::layout((RBX::LayoutNode *)this->layoutNode.px, context, RBX::LayoutNode::RelayoutMode::FullRelayout);
}


// Address: 0x17a9800 | Name: _ZNK3RBX9GuiObject23getSelectionImageObjectEv
RBX::GuiObject *__fastcall RBX::GuiObject::getSelectionImageObject(const RBX::GuiObject *this)
{
  return this->selectionImageObject.px;
}


// Address: 0x17e4630 | Name: _ZN3RBX10DialogRoot17getCurrentPlayersEv
_QWORD *__fastcall RBX::DialogRoot::getCurrentPlayers(_QWORD *a1, RBX::DialogRoot *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 18);
  v2 = *((_QWORD *)this + 19);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
  return a1;
}


// Address: 0x17f3fb0 | Name: _ZN5boost10shared_ptrI10MemStorageEC2IS1_EEPT_
void __fastcall boost::shared_ptr<MemStorage>::shared_ptr<MemStorage>(
        boost::shared_ptr<MemStorage> *this,
        MemStorage *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<MemStorage>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x17fb7c0 | Name: _ZNK3RBX6Rocket18getTargetDangerousEv
RBX::PartInstance *__fastcall RBX::Rocket::getTargetDangerous(const RBX::Rocket *this)
{
  return this->target.px;
}


// Address: 0x1839dc0 | Name: _ZN5boost10shared_ptrIN3RBX13HttpRbxApiJobEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RBX::HttpRbxApiJob>::reset<RBX::HttpRbxApiJob>(
        boost::shared_ptr<RBX::HttpRbxApiJob> *this,
        RBX::HttpRbxApiJob *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::HttpRbxApiJob,RBX::HttpRbxApiJob>(
    (boost::shared_ptr<RBX::HttpRbxApiJob> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::HttpRbxApiJob> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x183e6c0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX13HttpRbxApiJobES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::HttpRbxApiJob,RBX::HttpRbxApiJob>(
        boost::shared_ptr<RBX::HttpRbxApiJob> *ppx,
        RBX::HttpRbxApiJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28F3D78;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::HttpRbxApiJob,RBX::HttpRbxApiJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x18c2030 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX20MarketplaceApiClientES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::MarketplaceApiClient,RBX::MarketplaceApiClient>(
        boost::shared_ptr<RBX::MarketplaceApiClient> *ppx,
        RBX::MarketplaceApiClient *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_28FFD18;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x18da230 | Name: _ZN3RBX19MegaClusterInstance16countCellsScriptEv
int __fastcall RBX::MegaClusterInstance::countCellsScript(RBX::MegaClusterInstance *this)
{
  return RBX::Voxel2::Grid::getNonEmptyCellCountApprox(*((const RBX::Voxel2::Grid **)this + 50));
}


// Address: 0x18e0100 | Name: _ZNK3RBX19MegaClusterInstance11isAllocatedEv
bool __fastcall RBX::MegaClusterInstance::isAllocated(const RBX::MegaClusterInstance *this)
{
  return *(_QWORD *)(*((_QWORD *)this + 50) + 16LL) != 0;
}


// Address: 0x18e08c0 | Name: _ZNK3RBX19MegaClusterInstance20getNonEmptyCellCountEv
unsigned int __fastcall RBX::MegaClusterInstance::getNonEmptyCellCount(const RBX::MegaClusterInstance *this)
{
  return RBX::Voxel2::Grid::getNonEmptyCellCountApprox(*((const RBX::Voxel2::Grid **)this + 50));
}


// Address: 0x18eda30 | Name: _ZN5boost10shared_ptrIN3RBX6Voxel24GridEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Voxel2::Grid>::shared_ptr<RBX::Voxel2::Grid>(
        boost::shared_ptr<RBX::Voxel2::Grid> *this,
        RBX::Voxel2::Grid *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Voxel2::Grid>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x192fc60 | Name: _ZN3RBX13PartOperation32raiseTriangleCountPropertyChangeEN5boost10shared_ptrIS0_EE
void __fastcall RBX::PartOperation::raiseTriangleCountPropertyChange(boost::shared_ptr<RBX::PartOperation> self)
{
  RBX::Instance::raisePropertyChanged(*(RBX::Instance **)self.px, &stru_2A60150);
}


// Address: 0x1933990 | Name: _ZN5boost10shared_ptrIN3RBX7CSGMeshEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RBX::CSGMesh>::reset<RBX::CSGMesh>(
        boost::shared_ptr<RBX::CSGMesh> *this,
        RBX::CSGMesh *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::CSGMesh,RBX::CSGMesh>((boost::shared_ptr<RBX::CSGMesh> *)pn, p, &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::CSGMesh> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x1937b10 | Name: _ZN3RBX5Stats20PerformanceStatsItem19setLatestRenderTimeEf
void __fastcall RBX::Stats::PerformanceStatsItem::setLatestRenderTime(RBX::Stats::Item **this, float a2, float msec)
{
  RBX::Stats::Item::formatValue(*(this + 24), a2, "%.4f msec", a2);
}


// Address: 0x1937b30 | Name: _ZN3RBX5Stats20PerformanceStatsItem16setLatestCPUTimeEf
void __fastcall RBX::Stats::PerformanceStatsItem::setLatestCPUTime(RBX::Stats::Item **this, float a2, float msec)
{
  RBX::Stats::Item::formatValue(*(this + 22), a2, "%.4f msec", a2);
}


// Address: 0x1937b50 | Name: _ZN3RBX5Stats20PerformanceStatsItem23setLatestNetwokReceivedEf
void __fastcall RBX::Stats::PerformanceStatsItem::setLatestNetwokReceived(
        RBX::Stats::Item **this,
        float a2,
        float kbPerSec)
{
  RBX::Stats::Item::formatValue(*(this + 28), a2, "%.2f KB/s", a2);
}


// Address: 0x1937b70 | Name: _ZN3RBX5Stats20PerformanceStatsItem19setLatestNetwokSentEf
void __fastcall RBX::Stats::PerformanceStatsItem::setLatestNetwokSent(
        RBX::Stats::Item **this,
        float a2,
        float kbPerSec)
{
  RBX::Stats::Item::formatValue(*(this + 30), a2, "%.2f KB/s", a2);
}


// Address: 0x1937b90 | Name: _ZN3RBX5Stats20PerformanceStatsItem17setLatestPingTimeEf
void __fastcall RBX::Stats::PerformanceStatsItem::setLatestPingTime(RBX::Stats::Item **this, float a2, float msec)
{
  RBX::Stats::Item::formatValue(*(this + 26), a2, "%.4f msec", a2);
}


// Address: 0x1950380 | Name: _ZN3RBX6Player15getUserJoinDataEv
_QWORD *__fastcall RBX::Player::getUserJoinData(_QWORD *a1, RBX::Player *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 24);
  v2 = *((_QWORD *)this + 25);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
  return a1;
}


// Address: 0x1951ac0 | Name: _ZNK3RBX6Player26getReplicationFocusIHasLocEv
_QWORD *__fastcall RBX::Player::getReplicationFocusIHasLoc(_QWORD *a1, const RBX::Player *this)
{
  __int64 v2; // rcx
  signed __int32 v3; // eax
  signed __int32 v4; // ett

  *a1 = 0;
  v2 = *((_QWORD *)this + 19);
  a1[1] = v2;
  if ( !v2 )
    return a1;
  v3 = *(_DWORD *)(v2 + 8);
  while ( v3 )
  {
    v4 = v3;
    v3 = _InterlockedCompareExchange((volatile signed __int32 *)(v2 + 8), v3 + 1, v3);
    if ( v4 == v3 )
    {
      *a1 = *((_QWORD *)this + 18);
      return a1;
    }
  }
  a1[1] = 0;
  return a1;
}


// Address: 0x1957e10 | Name: _ZN3RBX6Player19getInternalJoinDataEv
_QWORD *__fastcall RBX::Player::getInternalJoinData(_QWORD *a1, RBX::Player *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 26);
  v2 = *((_QWORD *)this + 27);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
  return a1;
}


// Address: 0x195aed0 | Name: _ZL8addChildRKN5boost10shared_ptrIN3RBX13ModelInstanceEEERKNS0_INS1_8InstanceEEE
void __fastcall addChild(
        const boost::shared_ptr<RBX::ModelInstance> *parent,
        const boost::shared_ptr<RBX::Instance> *child)
{
  RBX::Instance::setParentInternal(child->px, (RBX::Instance *)parent->px, 0);
}


// Address: 0x1960980 | Name: _ZNK3RBX6Player21getDangerousCharacterEv
RBX::ModelInstance *__fastcall RBX::Player::getDangerousCharacter(const RBX::Player *this)
{
  return (RBX::ModelInstance *)*((_QWORD *)this + 20);
}


// Address: 0x19644f0 | Name: _ZN5boost10shared_ptrIN6RakNet13SystemAddressEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RakNet::SystemAddress>::reset<RakNet::SystemAddress>(
        boost::shared_ptr<RakNet::SystemAddress> *this,
        RakNet::SystemAddress *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RakNet::SystemAddress,RakNet::SystemAddress>(
    (boost::shared_ptr<RakNet::SystemAddress> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RakNet::SystemAddress> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x197cb30 | Name: _ZN5boost10shared_ptrIN3RBX19PersistentDataStoreEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::PersistentDataStore>::shared_ptr<RBX::PersistentDataStore>(
        boost::shared_ptr<RBX::PersistentDataStore> *this,
        RBX::PersistentDataStore *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::PersistentDataStore>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x197ee80 | Name: _ZN5boost6detail20sp_pointer_constructIN6RakNet13SystemAddressES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RakNet::SystemAddress,RakNet::SystemAddress>(
        boost::shared_ptr<RakNet::SystemAddress> *ppx,
        RakNet::SystemAddress *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2927D78;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x19a5e80 | Name: _ZN5boost6detail20sp_pointer_constructINSt3__16vectorINS_10shared_ptrINS3_INS4_IN3RBX8InstanceEEENS2_9allocatorIS7_EEEEEENS8_ISB_EEEESD_EEvPNS4_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>,std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>(
        boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > *ppx,
        std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29282E8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x19abb80 | Name: _ZN3RBX13BasePlayerGui13render3dAdornEPNS_5AdornE
void __fastcall RBX::BasePlayerGui::render3dAdorn(RBX::BasePlayerGui *this, RBX::Adorn *adorn)
{
  RBX::IAdornableCollector::render3dAdornItems(*((RBX::IAdornableCollector **)this + 24), adorn);
}


// Address: 0x19b0920 | Name: _ZN3RBX14CoreGuiService11removeChildEPNS_8InstanceE
void __fastcall RBX::CoreGuiService::removeChild(RBX::CoreGuiService *this, RBX::Instance *instance)
{
  RBX::Instance ***v2; // rcx
  RBX::Instance **v3; // rax
  RBX::Instance **v4; // rcx

  v2 = *(RBX::Instance ****)(*((_QWORD *)this + 29) + 72LL);
  if ( v2 )
  {
    v3 = *v2;
    v4 = v2[1];
    if ( v3 != v4 )
    {
      while ( *v3 != instance )
      {
        v3 += 2;
        if ( v4 == v3 )
          return;
      }
      RBX::Instance::remove(instance);
    }
  }
}


// Address: 0x19b23a0 | Name: _ZN5boost10shared_ptrIN3RBX19IAdornableCollectorEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::IAdornableCollector>::shared_ptr<RBX::IAdornableCollector>(
        boost::shared_ptr<RBX::IAdornableCollector> *this,
        RBX::IAdornableCollector *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::IAdornableCollector>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x19b2d80 | Name: _ZNK3RBX13BasePlayerGui23getSelectionImageObjectEv
RBX::GuiObject *__fastcall RBX::BasePlayerGui::getSelectionImageObject(const RBX::BasePlayerGui *this)
{
  return (RBX::GuiObject *)*((_QWORD *)this + 26);
}


// Address: 0x19ca600 | Name: _ZNK3RBX7Players23getLocalPlayerDangerousEv
RBX::Instance *__fastcall RBX::Players::getLocalPlayerDangerous(const RBX::Players *this)
{
  return (RBX::Instance *)*((_QWORD *)this + 44);
}


// Address: 0x19f2100 | Name: _ZN3RBX7Players10getPlayersEv
_QWORD *__fastcall RBX::Players::getPlayers(_QWORD *a1, RBX::Players *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 39);
  v2 = *((_QWORD *)this + 40);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
  return a1;
}


// Address: 0x19f2130 | Name: _ZNK3RBX7Players13getNumPlayersEv
int __fastcall RBX::Players::getNumPlayers(const RBX::Players *this)
{
  return (*(_QWORD *)(*((_QWORD *)this + 39) + 8LL) - **((_QWORD **)this + 39)) >> 4;
}


// Address: 0x1a0d390 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX13AbuseReporter4dataES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::AbuseReporter::data,RBX::AbuseReporter::data>(
        boost::shared_ptr<RBX::AbuseReporter::data> *ppx,
        RBX::AbuseReporter::data *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_292D418;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1a1e750 | Name: _ZN5boost10shared_ptrIKN3RBX17LuaScriptFileDescEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::LuaScriptFileDesc const>::shared_ptr<RBX::LuaScriptFileDesc>(
        boost::shared_ptr<const RBX::LuaScriptFileDesc> *this,
        RBX::LuaScriptFileDesc *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::LuaScriptFileDesc>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1a270a0 | Name: _ZN3RBX9PluginGui23hasFunctionBoundToCloseEv
bool __fastcall RBX::PluginGui::hasFunctionBoundToClose(RBX::PluginGui *this)
{
  return *((_QWORD *)this + 117) != 0;
}


// Address: 0x1a27620 | Name: _ZN3RBX9PluginGui12updateGfxGuiEPNS_5AdornE
void __fastcall RBX::PluginGui::updateGfxGui(RBX::PluginGui *this, RBX::Adorn *adorn)
{
  RBX::GfxGui::setToScreenSpace(*((RBX::GfxGui **)this + 66));
}


// Address: 0x1a31ab0 | Name: _ZN3RBX6Plugin11getMouseLuaEv
_QWORD *__fastcall RBX::Plugin::getMouseLua(_QWORD *a1, RBX::Plugin *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 20);
  v2 = *((_QWORD *)this + 21);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
  return a1;
}


// Address: 0x1a4d170 | Name: _ZNK3RBX16QWidgetPluginGui19getPluginGuiOptionsEv
_QWORD *__fastcall RBX::QWidgetPluginGui::getPluginGuiOptions(_QWORD *a1, const RBX::QWidgetPluginGui *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 119);
  v2 = *((_QWORD *)this + 120);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
  return a1;
}


// Address: 0x1a54ef0 | Name: _ZNK3RBX15PluginUIElement15getParentPluginEv
_QWORD *__fastcall RBX::PluginUIElement::getParentPlugin(_QWORD *a1, const RBX::PluginUIElement *this)
{
  __int64 v2; // rcx
  signed __int32 v3; // eax
  signed __int32 v4; // ett

  *a1 = 0;
  v2 = *((_QWORD *)this + 17);
  a1[1] = v2;
  if ( !v2 )
    return a1;
  v3 = *(_DWORD *)(v2 + 8);
  while ( v3 )
  {
    v4 = v3;
    v3 = _InterlockedCompareExchange((volatile signed __int32 *)(v2 + 8), v3 + 1, v3);
    if ( v4 == v3 )
    {
      *a1 = *((_QWORD *)this + 16);
      return a1;
    }
  }
  a1[1] = 0;
  return a1;
}


// Address: 0x1a83a50 | Name: _ZN5boost10shared_ptrIN3RBX6CEventEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::CEvent>::shared_ptr<RBX::CEvent>(
        boost::shared_ptr<RBX::CEvent> *this,
        RBX::CEvent *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::CEvent>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1a8ad50 | Name: _ZNK3RBX9WorldRoot10getTerrainEv
RBX::Instance *__fastcall RBX::WorldRoot::getTerrain(const RBX::WorldRoot *this)
{
  return (RBX::Instance *)*((_QWORD *)this + 63);
}


// Address: 0x1a98470 | Name: _ZN3RBX18ScriptMouseCommand12onMouseHoverERKN5boost10shared_ptrINS_11InputObjectEEE
void __fastcall RBX::ScriptMouseCommand::onMouseHover(
        RBX::ScriptMouseCommand *this,
        const boost::shared_ptr<RBX::InputObject> *inputObject)
{
  (*(void (__fastcall **)(boost::shared_ptr<RBX::Mouse>::element_type *, const boost::shared_ptr<RBX::InputObject> *))(*(_QWORD *)this->mouse.px + 304LL))(
    this->mouse.px,
    inputObject);
}


// Address: 0x1a98480 | Name: _ZN3RBX18ScriptMouseCommand11onMouseIdleERKN5boost10shared_ptrINS_11InputObjectEEE
void __fastcall RBX::ScriptMouseCommand::onMouseIdle(
        RBX::ScriptMouseCommand *this,
        const boost::shared_ptr<RBX::InputObject> *inputObject)
{
  (*(void (__fastcall **)(boost::shared_ptr<RBX::Mouse>::element_type *, const boost::shared_ptr<RBX::InputObject> *))(*(_QWORD *)this->mouse.px + 304LL))(
    this->mouse.px,
    inputObject);
}


// Address: 0x1aa7770 | Name: _ZNK3RBX8SeatImplINS_17BasicPartInstanceEE11getOccupantEv
RBX::Humanoid *__fastcall RBX::SeatImpl<RBX::BasicPartInstance>::getOccupant(
        const RBX::SeatImpl<RBX::BasicPartInstance> *this)
{
  return (RBX::Humanoid *)this->occupant.px;
}


// Address: 0x1aadf60 | Name: _ZN3RBX9Selection13getSelection2Ev
_QWORD *__fastcall RBX::Selection::getSelection2(_QWORD *a1, RBX::Selection *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 17);
  v2 = *((_QWORD *)this + 18);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
  return a1;
}


// Address: 0x1ab5a40 | Name: _ZNK3RBX18SkateboardPlatform16getControllerLuaEv
RBX::SkateboardController *__fastcall RBX::SkateboardPlatform::getControllerLua(const RBX::SkateboardPlatform *this)
{
  return this->myController.px;
}


// Address: 0x1afac90 | Name: _ZN3RBX21PlayerEmulatorService21getEmulatedPolicyInfoEv
_QWORD *__fastcall RBX::PlayerEmulatorService::getEmulatedPolicyInfo(_QWORD *a1, RBX::PlayerEmulatorService *this)
{
  __int64 v2; // rax

  *a1 = *((_QWORD *)this + 20);
  v2 = *((_QWORD *)this + 21);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
  return a1;
}


// Address: 0x1b14840 | Name: _ZN5boost10shared_ptrINS_7promiseINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEEEC2IS9_EEPT_
void __fastcall boost::shared_ptr<boost::promise<std::string>>::shared_ptr<boost::promise<std::string>>(
        boost::shared_ptr<boost::promise<std::string > > *this,
        boost::promise<std::string > *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<boost::promise<std::string>>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1b15090 | Name: _ZN5boost6detail20sp_pointer_constructINSt3__16vectorINS_10shared_ptrIN3RBX11PackageLinkEEENS2_9allocatorIS7_EEEESA_EEvPNS4_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<std::vector<boost::shared_ptr<RBX::PackageLink>>,std::vector<boost::shared_ptr<RBX::PackageLink>>>(
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::PackageLink>> > *ppx,
        std::vector<boost::shared_ptr<RBX::PackageLink>> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2954DD8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1b2ca20 | Name: _ZN5boost6detail8function26void_function_obj_invoker0IZN3RBX14PackageService27retrieveAllPackageAssetDataEvE4$_11vE6invokeERNS1_15function_bufferE
void __fastcall boost::detail::function::void_function_obj_invoker0<RBX::PackageService::retrieveAllPackageAssetData(void)::$_11,void>::invoke(
        boost::detail::function::function_buffer *function_obj_ptr)
{
  boost::promise<void>::set_value((boost::promise<void> *)function_obj_ptr->obj_ptr);
}


// Address: 0x1b2d0f0 | Name: _ZN5boost6detail8function26void_function_obj_invoker0IZN3RBX14PackageService29getUpdateNeededPackagesHelperENS_10shared_ptrINS3_8InstanceEEENS5_INSt3__16vectorIS7_NS8_9allocatorIS7_EEEEEENS5_INS_7promiseIvEEEEE4$_14vE6invokeERNS1_15function_bufferE
void __fastcall boost::detail::function::void_function_obj_invoker0<RBX::PackageService::getUpdateNeededPackagesHelper(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>,boost::shared_ptr<boost::promise<void>>)::$_14,void>::invoke(
        boost::detail::function::function_buffer *function_obj_ptr)
{
  boost::promise<void>::set_value((boost::promise<void> *)function_obj_ptr->obj_ptr);
}


// Address: 0x1b3e4f0 | Name: _ZN5boost6detail20sp_pointer_constructIN16PackageUtilities23AutoUpdateApplyMetadataES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<PackageUtilities::AutoUpdateApplyMetadata,PackageUtilities::AutoUpdateApplyMetadata>(
        boost::shared_ptr<PackageUtilities::AutoUpdateApplyMetadata> *ppx,
        PackageUtilities::AutoUpdateApplyMetadata *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2955508;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1b46280 | Name: _ZN5boost10shared_ptrIN3RBX18RCCPackageListenerEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::RCCPackageListener>::shared_ptr<RBX::RCCPackageListener>(
        boost::shared_ptr<RBX::RCCPackageListener> *this,
        RBX::RCCPackageListener *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::RCCPackageListener>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1b4d1f0 | Name: _ZN3RBX5Teams8getTeamsEv
boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **__fastcall RBX::Teams::getTeams(
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **a1,
        RBX::Teams *this)
{
  boost::detail::sp_counted_base *pi; // rax

  *a1 = this->teams.object.px;
  pi = this->teams.object.pn.pi_;
  a1[1] = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  return a1;
}


// Address: 0x1bb89e0 | Name: _ZN3RBX11TextScraper12parameterizeERiRKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEERS8_
void __fastcall RBX::TextScraper::parameterize(
        RBX::TextScraper *this,
        int *paramCnt,
        const std::string *input,
        std::string *output)
{
  (*((void (__fastcall **)(boost::shared_ptr<RBX::ParameterizeHandler>::element_type *, int *, const std::string *, std::string *))this->parameterizeHandlerHead.px->_vptr$ParameterizeHandler
   + 2))(
    this->parameterizeHandlerHead.px,
    paramCnt,
    input,
    output);
}


// Address: 0x1bb8a10 | Name: _ZN3RBX11TextScraper21parameterizeUsernamesERiRKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEERS8_
void __fastcall RBX::TextScraper::parameterizeUsernames(
        RBX::TextScraper *this,
        int *paramCnt,
        const std::string *input,
        std::string *output)
{
  RBX::UsernameHandler::handleUsernames(this->usernameHandlerPtr.px, paramCnt, input, output);
}


// Address: 0x1bbc9c0 | Name: _ZN5boost10shared_ptrINS_9unordered13unordered_mapINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEN3RBX26UntranslatedSourceContextsENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SB_EEEEEEED2Ev
void __fastcall boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::UntranslatedSourceContexts,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::UntranslatedSourceContexts>>>>::~shared_ptr(
        boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::UntranslatedSourceContexts,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::UntranslatedSourceContexts> > > > *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1bbdc30 | Name: _ZN5boost10shared_ptrIKN3RBX10Reflection5TupleEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Reflection::Tuple const>::shared_ptr<RBX::Reflection::Tuple>(
        boost::shared_ptr<const RBX::Reflection::Tuple> *this,
        RBX::Reflection::Tuple *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Reflection::Tuple>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1bd46f0 | Name: _ZN5boost10shared_ptrIN3RBX10TypesetterEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::Typesetter>::shared_ptr<RBX::Typesetter>(
        boost::shared_ptr<RBX::Typesetter> *this,
        RBX::Typesetter *p)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::shared_count v3; // [rsp+8h] [rbp-20h] BYREF

  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Typesetter>(&v3, p);
  pi = this->pn.pi_;
  this->pn = v3;
  v3.pi_ = pi;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::Typesetter>::_internal_accept_owner<RBX::Typesetter,RBX::Typesetter>(
      (const boost::enable_shared_from_this<RBX::Typesetter> *)p,
      this,
      p);
}


// Address: 0x1bd7670 | Name: _ZN5boost10shared_ptrIN3RBX19HinteractableResultEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::HinteractableResult>::shared_ptr<RBX::HinteractableResult>(
        boost::shared_ptr<RBX::HinteractableResult> *this,
        RBX::HinteractableResult *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::HinteractableResult>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1bd78e0 | Name: _ZN5boost6detail20sp_pointer_constructINSt3__16vectorINS_10shared_ptrIN3RBX19HinteractableResultEEENS2_9allocatorIS7_EEEESA_EEvPNS4_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<std::vector<boost::shared_ptr<RBX::HinteractableResult>>,std::vector<boost::shared_ptr<RBX::HinteractableResult>>>(
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HinteractableResult>> > *ppx,
        std::vector<boost::shared_ptr<RBX::HinteractableResult>> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_295F348;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1bf1720 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX5TweenES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Tween,RBX::Tween>(
        boost::shared_ptr<RBX::Tween> *ppx,
        RBX::Tween *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_2963C28;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Tween,RBX::Tween>(
      &p->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
      ppx,
      p);
}


// Address: 0x1c025b0 | Name: _ZN5boost10shared_ptrIN3RBX16UserInputService16WindowInputStateEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::UserInputService::WindowInputState>::shared_ptr<RBX::UserInputService::WindowInputState>(
        boost::shared_ptr<RBX::UserInputService::WindowInputState> *this,
        RBX::UserInputService::WindowInputState *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::UserInputService::WindowInputState>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1c25490 | Name: _ZNK3RBX8SeatImplINS_12PartInstanceEE11getOccupantEv
RBX::Humanoid *__fastcall RBX::SeatImpl<RBX::PartInstance>::getOccupant(const RBX::SeatImpl<RBX::PartInstance> *this)
{
  return (RBX::Humanoid *)this->occupant.px;
}


// Address: 0x1c2b7e0 | Name: _ZNK3RBX10VideoFrame8isLoadedEv
bool __fastcall RBX::VideoFrame::isLoaded(const RBX::VideoFrame *this)
{
  return *((_QWORD *)this + 184) != 0;
}


// Address: 0x1c32d00 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8VideoJobES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::VideoJob,RBX::VideoJob>(
        boost::shared_ptr<RBX::VideoJob> *ppx,
        RBX::VideoJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_296EED8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::VideoJob,RBX::VideoJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1c425c0 | Name: _ZNK3RBX9Workspace25getCurrentCameraDangerousEv
RBX::Camera *__fastcall RBX::Workspace::getCurrentCameraDangerous(const RBX::Workspace *this)
{
  return (RBX::Camera *)*((_QWORD *)this + 113);
}


// Address: 0x1c45c90 | Name: _ZN3RBX9Workspace17getOverrideCameraEv
RBX::Camera *__fastcall RBX::Workspace::getOverrideCamera(RBX::Workspace *this)
{
  return (RBX::Camera *)*((_QWORD *)this + 111);
}


// Address: 0x1c4d1f0 | Name: _ZN3RBX10hash_valueERKNS_9TouchPairE
size_t __fastcall RBX::hash_value(const RBX::TouchPair *p)
{
  boost::shared_ptr<RBX::PartInstance>::element_type *px; // r8

  px = p->p2.px;
  return ((unsigned __int64)p->p1.px + ((unsigned __int64)p->p1.px >> 3))
       ^ ((unsigned __int64)&px[8092791].primitiveWorldChanging.head.px
        + 64 * (__int64)((__int64)p->p1.px + ((unsigned __int64)p->p1.px >> 3))
        + ((unsigned __int64)px >> 3)
        + (((unsigned __int64)p->p1.px + ((unsigned __int64)p->p1.px >> 3)) >> 2)
        + 1)
       ^ (*(unsigned int *)p->gap20
        + ((((unsigned __int64)p->p1.px + ((unsigned __int64)p->p1.px >> 3))
          ^ ((unsigned __int64)&px[8092791].primitiveWorldChanging.head.px
           + 64 * (__int64)((__int64)p->p1.px + ((unsigned __int64)p->p1.px >> 3))
           + ((unsigned __int64)px >> 3)
           + (((unsigned __int64)p->p1.px + ((unsigned __int64)p->p1.px >> 3)) >> 2)
           + 1)) << 6)
        + ((((unsigned __int64)p->p1.px + ((unsigned __int64)p->p1.px >> 3))
          ^ ((unsigned __int64)&px[8092791].primitiveWorldChanging.head.px
           + 64 * (__int64)((__int64)p->p1.px + ((unsigned __int64)p->p1.px >> 3))
           + ((unsigned __int64)px >> 3)
           + (((unsigned __int64)p->p1.px + ((unsigned __int64)p->p1.px >> 3)) >> 2)
           + 1)) >> 2)
        + 2654435769u);
}


// Address: 0x1c4eae0 | Name: _ZN5boost10shared_ptrIbEC2IbNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3RBX5MouseERKNS0_INS7_11InputObjectEEEEENS3_5list2INS3_5valueIPNS7_11PluginMouseEEENSF_ISA_EEEEEEEEPT_T0_
void __fastcall boost::shared_ptr<bool>::shared_ptr<bool,boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Mouse,boost::shared_ptr<RBX::InputObject> const&>,boost::_bi::list2<boost::_bi::value<RBX::PluginMouse *>,boost::_bi::value<boost::shared_ptr<RBX::InputObject>>>>>(
        boost::shared_ptr<bool> *this,
        bool *p,
        __int64 a3)
{
  boost::detail::shared_count *p_pn; // rdi
  boost::detail::sp_counted_base *v4; // rax
  boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Mouse,const boost::shared_ptr<RBX::InputObject> &>,boost::_bi::list2<boost::_bi::value<RBX::PluginMouse *>,boost::_bi::value<boost::shared_ptr<RBX::InputObject> > > > v5; // [rsp+0h] [rbp-38h]
  volatile signed __int32 *v6; // [rsp+20h] [rbp-18h]

  this->px = p;
  p_pn = &this->pn;
  v5.f_ = *(boost::_mfi::mf1<void,RBX::Mouse,const boost::shared_ptr<RBX::InputObject> &> *)a3;
  *(_OWORD *)&v5.l_.a1_.t_ = *(_OWORD *)(a3 + 16);
  v4 = *(boost::detail::sp_counted_base **)(a3 + 32);
  v5.l_.a2_.t_.pn.pi_ = v4;
  if ( v4 )
    _InterlockedAdd(&v4->use_count_, 1u);
  boost::detail::shared_count::shared_count<bool *,boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Mouse,boost::shared_ptr<RBX::InputObject> const&>,boost::_bi::list2<boost::_bi::value<RBX::PluginMouse *>,boost::_bi::value<boost::shared_ptr<RBX::InputObject>>>>>(
    p_pn,
    p,
    v5);
  if ( v6 && !_InterlockedSub(v6 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x1cb6280 | Name: _ZN5boost10shared_ptrIN3RBX17SignalRConnectionEED2Ev
void __fastcall boost::shared_ptr<RBX::SignalRConnection>::~shared_ptr(boost::shared_ptr<RBX::SignalRConnection> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1cbf260 | Name: _ZNK3RBX4Path9getStatusEv
RBX::Path::PathStatus __fastcall RBX::Path::getStatus(const RBX::Path *this)
{
  return 5 * (this->navigationPath.px->status != RBX::NavigationPath::NavigationStatus::Success);
}


// Address: 0x1cbf6c0 | Name: _ZN3RBX4Path24getOrCreateBlockedSignalEb
rbx::signal<void (int)> *__fastcall RBX::Path::getOrCreateBlockedSignal(RBX::Path *this, bool create)
{
  return RBX::NavigationPath::getOrCreateBlockedSignal(this->navigationPath.px, create);
}


// Address: 0x1cd13b0 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvNS5_IvNS_4_mfi3mf3IvN3RBX21ThirdPartyUserServiceENS8_11InputObject13UserInputTypeENS_8functionIFviEEENSC_IFvNSt3__112basic_stringIcNSF_11char_traitsIcEENSF_9allocatorIcEEEEEEEEENS4_5list4INS4_5valueIPS9_EENSQ_ISB_EENSQ_ISE_EENSQ_ISN_EEEEEENS4_5list1INSQ_INS8_12DataModelJob8TaskTypeEEEEEEEEEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > >,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_298AB98;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1ce2450 | Name: _ZN3RBX15getMeshTriCountEN5boost10shared_ptrINS_12FileMeshDataEEE
__int64 __fastcall RBX::getMeshTriCount(boost::shared_ptr<RBX::FileMeshData> meshData)
{
  return *(unsigned int *)(*(_QWORD *)(*(_QWORD *)meshData.px + 72LL) + 4LL);
}


// Address: 0x1ce25d0 | Name: _ZN3RBX14getTextureSizeEN5boost10shared_ptrIN3G3D6GImageEEE
__m128 __fastcall RBX::getTextureSize(boost::shared_ptr<G3D::GImage> textureData)
{
  return _mm_cvtepi32_ps((__m128i)*(unsigned __int64 *)((char *)textureData.px->_vptr$GImage + 20));
}


// Address: 0x1d032b0 | Name: _ZN3RBX8UILayout24layoutPositioningChangedEv
void __fastcall RBX::UILayout::layoutPositioningChanged(RBX::UILayout *this)
{
  RBX::LayoutNode::setViewportDirty((RBX::LayoutNode *)this->layoutNode.px, 1);
}


// Address: 0x1d032d0 | Name: _ZN3RBX8UILayout19layoutSizingChangedEv
void __fastcall RBX::UILayout::layoutSizingChanged(RBX::UILayout *this)
{
  RBX::LayoutNode::setLayoutDirty((RBX::LayoutNode *)this->layoutNode.px, 1);
}


// Address: 0x1d032f0 | Name: _ZN3RBX8UILayout25parentLayoutSizingChangedEv
void __fastcall RBX::UILayout::parentLayoutSizingChanged(RBX::UILayout *this)
{
  RBX::LayoutNode::parentLayoutPositioningChanged((RBX::LayoutNode *)this->layoutNode.px);
}


// Address: 0x1d034d0 | Name: _ZN3RBX8UILayout12updateLayoutEPKc
void __fastcall RBX::UILayout::updateLayout(RBX::UILayout *this, const char *context)
{
  RBX::LayoutNode *px; // rdi

  px = (RBX::LayoutNode *)this->layoutNode.px;
  if ( !context )
    context = "UILayout::updateLayout";
  RBX::LayoutNode::layout(px, context, RBX::LayoutNode::RelayoutMode::FullRelayout);
}


// Address: 0x1d034f0 | Name: _ZN3RBX8UILayout13getLayoutNodeEv
RBX::LayoutNode *__fastcall RBX::UILayout::getLayoutNode(RBX::UILayout *this)
{
  return (RBX::LayoutNode *)this->layoutNode.px;
}


// Address: 0x1d12fb0 | Name: _ZN3RBX15KeyboardService32getKeyboardGuiSelectionDirectionERKN5boost10shared_ptrINS_11InputObjectEEE
RBX::Vector2 __fastcall RBX::KeyboardService::getKeyboardGuiSelectionDirection(
        RBX::KeyboardService *this,
        const boost::shared_ptr<RBX::InputObject> *inputObject)
{
  _DWORD *px; // rax
  int v4; // ecx
  int v5; // eax
  RBX::Vector2 result; // 0:xmm0_8.8

  px = inputObject->px;
  result = 0;
  if ( *((_DWORD *)inputObject->px + 32) == 8 )
  {
    v4 = px[34];
    if ( v4 != 2 && v4 != 4 )
    {
      result = (RBX::Vector2)3212836864LL;
      v5 = px[56];
      switch ( v5 )
      {
        case 'a':
          return result;
        case 'b':
        case 'c':
        case 'e':
        case 'f':
        case 'g':
        case 'h':
        case 'i':
        case 'j':
        case 'k':
        case 'l':
        case 'm':
        case 'n':
        case 'o':
        case 'p':
        case 'q':
        case 'r':
        case 't':
        case 'u':
        case 'v':
LABEL_11:
          result = 0;
          break;
        case 'd':
LABEL_8:
          result = (RBX::Vector2)1065353216LL;
          break;
        case 's':
LABEL_9:
          result = (RBX::Vector2)0x3F80000000000000LL;
          break;
        case 'w':
LABEL_10:
          result = (RBX::Vector2)0xBF80000000000000LL;
          break;
        default:
          switch ( v5 )
          {
            case 273:
              goto LABEL_10;
            case 274:
              goto LABEL_9;
            case 275:
              goto LABEL_8;
            case 276:
              return result;
            default:
              goto LABEL_11;
          }
      }
    }
  }
  return result;
}


// Address: 0x1d3f8a0 | Name: _ZN3RBX10ChildAddedC2ERKS0_
void __fastcall RBX::ChildAdded::ChildAdded(RBX::ChildAdded *this, const RBX::ChildAdded *event)
{
  boost::detail::sp_counted_base *pi; // rax

  this->child.px = event->child.px;
  pi = event->child.pn.pi_;
  this->child.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
}


// Address: 0x1d3f8d0 | Name: _ZN3RBX12ChildRemovedC2ERKS0_
void __fastcall RBX::ChildRemoved::ChildRemoved(RBX::ChildRemoved *this, const RBX::ChildRemoved *event)
{
  boost::detail::sp_counted_base *pi; // rax

  this->child.px = event->child.px;
  pi = event->child.pn.pi_;
  this->child.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
}


// Address: 0x1d457d0 | Name: _ZN3RBX8Instance12getChildren2Ev
boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **__fastcall RBX::Instance::getChildren2(
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **a1,
        RBX::Instance *this)
{
  boost::detail::sp_counted_base *pi; // rax

  *a1 = this->children.object.px;
  pi = this->children.object.pn.pi_;
  a1[1] = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  return a1;
}


// Address: 0x1d45800 | Name: _ZN3RBX8Instance15isDescendantOf2EN5boost10shared_ptrIS0_EE
char __fastcall RBX::Instance::isDescendantOf2(RBX::Instance *this, boost::shared_ptr<RBX::Instance> ancestor)
{
  while ( 1 )
  {
    this = this->parent;
    if ( this == (RBX::Instance *)ancestor.px->_vptr$EventSource )
      break;
    if ( !this )
      return 0;
  }
  return 1;
}


// Address: 0x1d45980 | Name: _ZN3RBX8Instance13isAncestorOf2EN5boost10shared_ptrIS0_EE
char __fastcall RBX::Instance::isAncestorOf2(RBX::Instance *this, boost::shared_ptr<RBX::Instance> descendant)
{
  RBX::Instance *v2; // rax

  v2 = (RBX::Instance *)descendant.px->_vptr$EventSource;
  while ( v2 )
  {
    v2 = v2->parent;
    if ( v2 == this )
      return 1;
  }
  return 0;
}


// Address: 0x1e398c0 | Name: _ZN5boost10shared_ptrIN3RBX14ChunkMeshShapeEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RBX::ChunkMeshShape>::reset<RBX::ChunkMeshShape>(
        boost::shared_ptr<RBX::ChunkMeshShape> *this,
        RBX::ChunkMeshShape *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::ChunkMeshShape,RBX::ChunkMeshShape>(
    (boost::shared_ptr<RBX::ChunkMeshShape> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::ChunkMeshShape> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x1e39b30 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX14ChunkMeshShapeES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::ChunkMeshShape,RBX::ChunkMeshShape>(
        boost::shared_ptr<RBX::ChunkMeshShape> *ppx,
        RBX::ChunkMeshShape *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A0648;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1e8ca40 | Name: _ZN5boost10shared_ptrI10XmlElementEC2IS1_EEPT_
void __fastcall boost::shared_ptr<XmlElement>::shared_ptr<XmlElement>(
        boost::shared_ptr<XmlElement> *this,
        XmlElement *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<XmlElement>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1eacc10 | Name: _ZN5boost10shared_ptrIN3RBX8FontDataEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::FontData>::shared_ptr<RBX::FontData>(
        boost::shared_ptr<RBX::FontData> *this,
        RBX::FontData *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::FontData>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1eb5b20 | Name: _ZN5boost6detail8function26void_function_obj_invoker1IZN3RBX14NavigationPath10updateImplEP9dtNavMeshRKNS_10shared_ptrIKNS3_8PathDataEEEE3$_1vPNS3_9DataModelEE6invokeERNS1_15function_bufferESF_
void __fastcall boost::detail::function::void_function_obj_invoker1<RBX::NavigationPath::updateImpl(dtNavMesh *,boost::shared_ptr<RBX::PathData const> const&)::$_1,void,RBX::DataModel *>::invoke(
        boost::detail::function::function_buffer *function_obj_ptr,
        RBX::DataModel *a0)
{
  rbx::signal<void ()(int)>::operator()(
    (rbx::signal<void (int)> *)function_obj_ptr->obj_ptr + 12,
    *((_DWORD *)&function_obj_ptr->data + 4));
}


// Address: 0x1ebe690 | Name: _ZN5boost10shared_ptrIN3RBX19NavigationDebugDrawEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RBX::NavigationDebugDraw>::reset<RBX::NavigationDebugDraw>(
        boost::shared_ptr<RBX::NavigationDebugDraw> *this,
        RBX::NavigationDebugDraw *p)
{
  RBX::NavigationDebugDraw *px; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<RBX::NavigationDebugDraw> v5; // [rsp+0h] [rbp-28h] BYREF
  boost::detail::shared_count v6; // [rsp+10h] [rbp-18h] BYREF

  px = p;
  v5.px = p;
  boost::detail::shared_count::shared_count<RBX::NavigationDebugDraw>(&v6, p);
  pi = v6.pi_;
  v5.pn = v6;
  if ( p )
  {
    boost::enable_shared_from_this<RBX::NavigationDebugDraw>::_internal_accept_owner<RBX::NavigationDebugDraw,RBX::NavigationDebugDraw>(
      p,
      &v5,
      p);
    px = v5.px;
    pi = v5.pn.pi_;
  }
  v5.px = this->px;
  this->px = px;
  v4 = this->pn.pi_;
  this->pn.pi_ = pi;
  v5.pn.pi_ = v4;
  if ( v4 && !_InterlockedSub(&v4->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
    if ( !_InterlockedSub(&v4->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
  }
}


// Address: 0x1ebf6d0 | Name: _ZN5boost10shared_ptrIN3RBX14NavigationTileEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RBX::NavigationTile>::reset<RBX::NavigationTile>(
        boost::shared_ptr<RBX::NavigationTile> *this,
        RBX::NavigationTile *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::NavigationTile,RBX::NavigationTile>(
    (boost::shared_ptr<RBX::NavigationTile> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::NavigationTile> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x1ebf780 | Name: _ZN5boost10shared_ptrIN3RBX17NavigationService13NavigationJobEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::NavigationService::NavigationJob>::reset<RBX::NavigationService::NavigationJob>(
        boost::shared_ptr<RBX::NavigationService::NavigationJob> *this,
        RBX::NavigationService::NavigationJob *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::NavigationService::NavigationJob,RBX::NavigationService::NavigationJob>(
    (boost::shared_ptr<RBX::NavigationService::NavigationJob> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::NavigationService::NavigationJob> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x1ec0c30 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX14NavigationTileES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::NavigationTile,RBX::NavigationTile>(
        boost::shared_ptr<RBX::NavigationTile> *ppx,
        RBX::NavigationTile *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A3078;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1ec4e90 | Name: _ZN5boost10shared_ptrIN3RBX18HeightfieldBuilderEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::HeightfieldBuilder>::shared_ptr<RBX::HeightfieldBuilder>(
        boost::shared_ptr<RBX::HeightfieldBuilder> *this,
        RBX::HeightfieldBuilder *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::HeightfieldBuilder>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1ec50b0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX17NavigationService13NavigationJobES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::NavigationService::NavigationJob,RBX::NavigationService::NavigationJob>(
        boost::shared_ptr<RBX::NavigationService::NavigationJob> *ppx,
        RBX::NavigationService::NavigationJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A33A8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::NavigationService::NavigationJob,RBX::NavigationService::NavigationJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1ec8c30 | Name: _ZN5boost10shared_ptrIN3RBX17NavigationContextEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RBX::NavigationContext>::reset<RBX::NavigationContext>(
        boost::shared_ptr<RBX::NavigationContext> *this,
        RBX::NavigationContext *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::NavigationContext,RBX::NavigationContext>(
    (boost::shared_ptr<RBX::NavigationContext> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::NavigationContext> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x1ecb990 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX17NavigationContextES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::NavigationContext,RBX::NavigationContext>(
        boost::shared_ptr<RBX::NavigationContext> *ppx,
        RBX::NavigationContext *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A35A8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f24b60 | Name: _ZN5boost10shared_ptrIN3RBX10ThreadPoolEED2Ev
void __fastcall boost::shared_ptr<RBX::ThreadPool>::~shared_ptr(boost::shared_ptr<RBX::ThreadPool> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f62280 | Name: _ZN5boost6detail20sp_pointer_constructINSt3__16vectorINS_10shared_ptrIN3RBX13PartOperationEEENS2_9allocatorIS7_EEEESA_EEvPNS4_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<std::vector<boost::shared_ptr<RBX::PartOperation>>,std::vector<boost::shared_ptr<RBX::PartOperation>>>(
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::PartOperation>> > *ppx,
        std::vector<boost::shared_ptr<RBX::PartOperation>> *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A48C8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f7c8a0 | Name: _ZN5boost10shared_ptrIN3RBX12FileMeshDataEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::FileMeshData>::shared_ptr<RBX::FileMeshData>(
        boost::shared_ptr<RBX::FileMeshData> *this,
        RBX::FileMeshData *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::FileMeshData>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f7ff70 | Name: _ZN3RBX8Graphics10RenderView12getWorkspaceEv
RBX::Instance *__fastcall RBX::Graphics::RenderView::getWorkspace(RBX::Graphics::RenderView *this)
{
  return (RBX::Instance *)*((_QWORD *)this->dataModel.px + 99);
}


// Address: 0x1f8a390 | Name: _ZN5boost6detail8function26void_function_obj_invoker1IZN3RBX8Graphics10RenderView13bindWorkspaceENS_10shared_ptrINS3_9DataModelEEEE3$_0vPS7_E6invokeERNS1_15function_bufferESA_
void __fastcall boost::detail::function::void_function_obj_invoker1<RBX::Graphics::RenderView::bindWorkspace(boost::shared_ptr<RBX::DataModel>)::$_0,void,RBX::DataModel*>::invoke(
        boost::detail::function::function_buffer *function_obj_ptr,
        RBX::DataModel *a0)
{
  RBX::Instance::setParentInternal((RBX::Instance *)function_obj_ptr->obj_ptr, 0, 0);
}


// Address: 0x1f8a560 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics7TextureEED2Ev
void __fastcall boost::shared_ptr<RBX::Graphics::Texture>::~shared_ptr(
        boost::shared_ptr<RBX::Graphics::Texture>_0 *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f8a5c0 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics25FrameRateManagerStatsItemEED2Ev
void __fastcall boost::shared_ptr<RBX::Graphics::FrameRateManagerStatsItem>::~shared_ptr(
        boost::shared_ptr<RBX::Graphics::FrameRateManagerStatsItem> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f8a660 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics21RenderSettingsForTestEED2Ev
void __fastcall boost::shared_ptr<RBX::Graphics::RenderSettingsForTest>::~shared_ptr(
        boost::shared_ptr<RBX::Graphics::RenderSettingsForTest> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f8a6a0 | Name: _ZN5boost10shared_ptrIN3RBX13RenderingTestEED2Ev
void __fastcall boost::shared_ptr<RBX::RenderingTest>::~shared_ptr(boost::shared_ptr<RBX::RenderingTest> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f8bf20 | Name: _ZN3RBX8Graphics10RenderView12getDataModelEv
RBX::DataModel *__fastcall RBX::Graphics::RenderView::getDataModel(RBX::Graphics::RenderView *this)
{
  return (RBX::DataModel *)this->dataModel.px;
}


// Address: 0x1f8d160 | Name: _ZN5boost6detail20sp_pointer_constructIN3G3D6GImageES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<G3D::GImage,G3D::GImage>(
        boost::shared_ptr<G3D::GImage> *ppx,
        G3D::GImage *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A5228;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f8d770 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseENS0_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf3IvN3RBX8Graphics10RenderViewENS_10shared_ptrIN3G3D6GImageEEENS_8weak_ptrINS8_9DataModelEEElEENS4_5list4INS4_5valueIPSA_EENSK_ISE_EENSK_ISH_EENSK_IlEEEEEEEEEEvPNSB_IT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView*>,boost::_bi::value<boost::shared_ptr<G3D::GImage>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<long> > > > *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A52D8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView*>,boost::_bi::value<boost::shared_ptr<G3D::GImage>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>>>>>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x1f94700 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics12VertexLayoutEED2Ev
void __fastcall boost::shared_ptr<RBX::Graphics::VertexLayout>::~shared_ptr(
        boost::shared_ptr<RBX::Graphics::VertexLayout>_0 *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f94ac0 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics13GlyphRendererEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Graphics::GlyphRenderer>::shared_ptr<RBX::Graphics::GlyphRenderer>(
        boost::shared_ptr<RBX::Graphics::GlyphRenderer> *this,
        RBX::Graphics::GlyphRenderer *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Graphics::GlyphRenderer>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f99280 | Name: _ZN3RBX8Graphics10TextureRef21updateAllRefsToFailedEv
void __fastcall RBX::Graphics::TextureRef::updateAllRefsToFailed(RBX::Graphics::TextureRef *this)
{
  this->data.px->status = RBX::Graphics::TextureRef::Status::Status_Failed;
}


// Address: 0x1f99290 | Name: _ZN3RBX8Graphics10TextureRef22updateAllRefsToWaitingEv
void __fastcall RBX::Graphics::TextureRef::updateAllRefsToWaiting(RBX::Graphics::TextureRef *this)
{
  this->data.px->status = RBX::Graphics::TextureRef::Status::Status_Waiting;
}


// Address: 0x1f992a0 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics10TextureRef4DataEEC2IS4_EEPT_
void __fastcall boost::shared_ptr<RBX::Graphics::TextureRef::Data>::shared_ptr<RBX::Graphics::TextureRef::Data>(
        boost::shared_ptr<RBX::Graphics::TextureRef::Data> *this,
        RBX::Graphics::TextureRef::Data *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Graphics::TextureRef::Data>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1fa2f00 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX16TextureProxyBaseENS2_8Graphics12TextureProxyEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::TextureProxyBase,RBX::Graphics::TextureProxy>(
        boost::shared_ptr<RBX::TextureProxyBase>_1 *ppx,
        RBX::Graphics::TextureProxy *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A57E8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1fa2fe0 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics9TechniqueEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Graphics::Technique>::shared_ptr<RBX::Graphics::Technique>(
        boost::shared_ptr<RBX::Graphics::Technique> *this,
        RBX::Graphics::Technique *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Graphics::Technique>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1fba4c0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics6RTPool2RTES5_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::RTPool::RT,RBX::Graphics::RTPool::RT>(
        boost::shared_ptr<RBX::Graphics::RTPool::RT> *ppx,
        RBX::Graphics::RTPool::RT *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A5988;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1fbaf60 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics12SceneManager12GuiClusterRTEEC2IS4_EEPT_
void __fastcall boost::shared_ptr<RBX::Graphics::SceneManager::GuiClusterRT>::shared_ptr<RBX::Graphics::SceneManager::GuiClusterRT>(
        boost::shared_ptr<RBX::Graphics::SceneManager::GuiClusterRT> *this,
        RBX::Graphics::SceneManager::GuiClusterRT *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Graphics::SceneManager::GuiClusterRT>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1fbd2c0 | Name: _ZNK3RBX8Graphics10GuiCluster12getSpaceRootEv
RBX::Instance *__fastcall RBX::Graphics::GuiCluster::getSpaceRoot(const RBX::Graphics::GuiCluster *this)
{
  return (RBX::Instance *)*((_QWORD *)this + 17);
}


// Address: 0x1fbdb30 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics11FramebufferEED2Ev
void __fastcall boost::shared_ptr<RBX::Graphics::Framebuffer>::~shared_ptr(
        boost::shared_ptr<RBX::Graphics::Framebuffer> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1fbdb80 | Name: _ZN5boost10shared_ptrIN3RBX13ViewportFrameEED2Ev
void __fastcall boost::shared_ptr<RBX::ViewportFrame>::~shared_ptr(boost::shared_ptr<RBX::ViewportFrame> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1fe18a0 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics10GuiClusterEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::Graphics::GuiCluster>::reset<RBX::Graphics::GuiCluster>(
        boost::shared_ptr<RBX::Graphics::GuiCluster> *this,
        RBX::Graphics::GuiCluster *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Graphics::GuiCluster,RBX::Graphics::GuiCluster>(
    (boost::shared_ptr<RBX::Graphics::GuiCluster> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Graphics::GuiCluster> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x1fe38c0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics10GuiClusterES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::GuiCluster,RBX::Graphics::GuiCluster>(
        boost::shared_ptr<RBX::Graphics::GuiCluster> *ppx,
        RBX::Graphics::GuiCluster *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A5FA8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1febfa0 | Name: _ZN5boost10shared_ptrIN3RBX5LightEED2Ev
void __fastcall boost::shared_ptr<RBX::Light>::~shared_ptr(boost::shared_ptr<RBX::Light> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1ffc630 | Name: _ZNK3RBX8Graphics7Shadows19ShadowMapSystemImpl12getShadowmapEv
_QWORD *__fastcall RBX::Graphics::Shadows::ShadowMapSystemImpl::getShadowmap(
        _QWORD *a1,
        const RBX::Graphics::Shadows::ShadowMapSystemImpl *this)
{
  __int64 v2; // rax

  *a1 = *(unsigned __int64 *)((char *)&stru_80670.r_offset + (_QWORD)this);
  v2 = *((_QWORD *)this + 65743);
  a1[1] = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 8), 1u);
  return a1;
}


// Address: 0x200d5d0 | Name: _ZN5boost10shared_ptrIN3RBX21CustomParticleEmitterEED2Ev
void __fastcall boost::shared_ptr<RBX::CustomParticleEmitter>::~shared_ptr(
        boost::shared_ptr<RBX::CustomParticleEmitter> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2016370 | Name: _ZNK3RBX8Graphics14TextureManager18hasPendingRequestsEv
bool __fastcall RBX::Graphics::TextureManager::hasPendingRequests(const RBX::Graphics::TextureManager *this)
{
  return *(_QWORD *)(*((_QWORD *)this + 31) + 40LL) != 0;
}


// Address: 0x201cc30 | Name: _ZN5boost10shared_ptrIN3RBX10ThreadPoolEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<RBX::ThreadPool>::reset<RBX::ThreadPool>(
        boost::shared_ptr<RBX::ThreadPool> *this,
        RBX::ThreadPool *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::ThreadPool,RBX::ThreadPool>(
    (boost::shared_ptr<RBX::ThreadPool> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::ThreadPool> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x201df00 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX10ThreadPoolES3_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::ThreadPool,RBX::ThreadPool>(
        boost::shared_ptr<RBX::ThreadPool> *ppx,
        RBX::ThreadPool *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A67C8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x201dfe0 | Name: _ZN5boost10shared_ptrIN3rbx10safe_queueIN3RBX8Graphics14TextureManager11LoadedImageEEEEC2IS7_EEPT_
void __fastcall boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>(
        boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage> > *this,
        rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage> *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2025260 | Name: _ZN3RBX8Graphics15ImageLoadResultC2ERKN5boost10shared_ptrINS0_5ImageEEERKNS0_9ImageInfoE
void __fastcall RBX::Graphics::ImageLoadResult::ImageLoadResult(
        RBX::Graphics::ImageLoadResult *this,
        const boost::shared_ptr<RBX::Graphics::Image> *image,
        const RBX::Graphics::ImageInfo *info)
{
  boost::detail::sp_counted_base *pi; // rax

  this->image.px = image->px;
  pi = image->pn.pi_;
  this->image.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  this->info = *info;
}


// Address: 0x2029170 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics5ImageEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Graphics::Image>::shared_ptr<RBX::Graphics::Image>(
        boost::shared_ptr<RBX::Graphics::Image> *this,
        RBX::Graphics::Image *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Graphics::Image>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2030660 | Name: _ZN3RBX8Graphics13SmoothCluster19reloadMaterialTableEv
void __fastcall RBX::Graphics::SmoothCluster::reloadMaterialTable(RBX::Graphics::SmoothCluster *this)
{
  *((_QWORD *)this + 29) = *(_QWORD *)(*((_QWORD *)this + 1) + 416LL);
  RBX::Graphics::SmoothCluster::updateMaterialConstants(this);
}


// Address: 0x2038030 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics8MaterialEED2Ev
void __fastcall boost::shared_ptr<RBX::Graphics::Material>::~shared_ptr(
        boost::shared_ptr<RBX::Graphics::Material> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2038070 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics6BufferEED2Ev
void __fastcall boost::shared_ptr<RBX::Graphics::Buffer>::~shared_ptr(boost::shared_ptr<RBX::Graphics::Buffer>_0 *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2038d00 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics8MaterialES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::Material,RBX::Graphics::Material>(
        boost::shared_ptr<RBX::Graphics::Material> *ppx,
        RBX::Graphics::Material *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A7208;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x20474f0 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics7EmitterEED2Ev
void __fastcall boost::shared_ptr<RBX::Graphics::Emitter>::~shared_ptr(boost::shared_ptr<RBX::Graphics::Emitter> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2047770 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics7EmitterEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::Graphics::Emitter>::reset<RBX::Graphics::Emitter>(
        boost::shared_ptr<RBX::Graphics::Emitter> *this,
        RBX::Graphics::Emitter *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Graphics::Emitter,RBX::Graphics::Emitter>(
    (boost::shared_ptr<RBX::Graphics::Emitter> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Graphics::Emitter> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x20478c0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics7EmitterES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::Emitter,RBX::Graphics::Emitter>(
        boost::shared_ptr<RBX::Graphics::Emitter> *ppx,
        RBX::Graphics::Emitter *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29A7458;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2058c00 | Name: _ZN5boost10shared_ptrIN3RBX5DecalEED2Ev
void __fastcall boost::shared_ptr<RBX::Decal>::~shared_ptr(boost::shared_ptr<RBX::Decal> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2060a50 | Name: _ZNK3RBX8Graphics11MeshManager18hasPendingRequestsEv
bool __fastcall RBX::Graphics::MeshManager::hasPendingRequests(const RBX::Graphics::MeshManager *this)
{
  return *(_QWORD *)(*((_QWORD *)this + 9) + 40LL) != 0;
}


// Address: 0x2068250 | Name: _ZN5boost10shared_ptrIN3rbx10safe_queueIN3RBX8Graphics11MeshManager7MeshJobEEEEC2IS7_EEPT_
void __fastcall boost::shared_ptr<rbx::safe_queue<RBX::Graphics::MeshManager::MeshJob>>::shared_ptr<rbx::safe_queue<RBX::Graphics::MeshManager::MeshJob>>(
        boost::shared_ptr<rbx::safe_queue<RBX::Graphics::MeshManager::MeshJob> > *this,
        rbx::safe_queue<RBX::Graphics::MeshManager::MeshJob> *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<rbx::safe_queue<RBX::Graphics::MeshManager::MeshJob>>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x20863e0 | Name: _ZN5boost10shared_ptrIN3RBX12FileMeshDataEED2Ev
void __fastcall boost::shared_ptr<RBX::FileMeshData>::~shared_ptr(boost::shared_ptr<RBX::FileMeshData> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x209a1c0 | Name: _ZN3RBX8Graphics17TextureCompositor10getTextureERKN5boost10shared_ptrINS1_3JobEEE
_QWORD *__fastcall RBX::Graphics::TextureCompositor::getTexture(
        _QWORD *a1,
        RBX::Graphics::TextureCompositor *this,
        const RBX::Graphics::TextureCompositor::JobHandle *job)
{
  _QWORD *px; // rax
  __int64 v4; // rax

  px = job->px;
  *a1 = *((_QWORD *)job->px + 27);
  v4 = px[28];
  a1[1] = v4;
  if ( v4 )
    _InterlockedAdd((volatile signed __int32 *)(v4 + 8), 1u);
  return a1;
}


// Address: 0x209a1f0 | Name: _ZN3RBX8Graphics17TextureCompositor12getTextureIdERKN5boost10shared_ptrINS1_3JobEEE
const std::string *__fastcall RBX::Graphics::TextureCompositor::getTextureId(
        RBX::Graphics::TextureCompositor *this,
        const RBX::Graphics::TextureCompositor::JobHandle *job)
{
  return (const std::string *)job->px;
}


// Address: 0x20a0950 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics17TextureCompositor3JobEEC2IS4_EEPT_
void __fastcall boost::shared_ptr<RBX::Graphics::TextureCompositor::Job>::shared_ptr<RBX::Graphics::TextureCompositor::Job>(
        boost::shared_ptr<RBX::Graphics::TextureCompositor::Job> *this,
        RBX::Graphics::TextureCompositor::Job *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Graphics::TextureCompositor::Job>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x20a1950 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics13GeometryBatchEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Graphics::GeometryBatch>::shared_ptr<RBX::Graphics::GeometryBatch>(
        boost::shared_ptr<RBX::Graphics::GeometryBatch> *this,
        RBX::Graphics::GeometryBatch_0 *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Graphics::GeometryBatch>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x20a2d20 | Name: _ZNSt3__17__sort4IRN3RBX8Graphics18PriorityComparatorIN5boost10shared_ptrINS2_17TextureCompositor3JobEEEEEPS8_EEjT0_SC_SC_SC_T_
unsigned int __fastcall std::__sort4<RBX::Graphics::PriorityComparator<boost::shared_ptr<RBX::Graphics::TextureCompositor::Job>> &,boost::shared_ptr<RBX::Graphics::TextureCompositor::Job>*>(
        boost::shared_ptr<RBX::Graphics::TextureCompositor::Job> *__x1,
        boost::shared_ptr<RBX::Graphics::TextureCompositor::Job> *__x2,
        boost::shared_ptr<RBX::Graphics::TextureCompositor::Job> *__x3,
        boost::shared_ptr<RBX::Graphics::TextureCompositor::Job> *__x4,
        RBX::Graphics::PriorityComparator<boost::shared_ptr<RBX::Graphics::TextureCompositor::Job> > *__c)
{
  float *px; // r8
  float v6; // xmm1_4
  boost::shared_ptr<RBX::Graphics::TextureCompositor::Job>::element_type *v7; // r9
  float v8; // xmm0_4
  boost::shared_ptr<RBX::Graphics::TextureCompositor::Job>::element_type *v9; // r10
  float v10; // xmm2_4
  boost::detail::sp_counted_base *v11; // r8
  unsigned int result; // eax
  boost::detail::sp_counted_base *pi; // r9
  boost::shared_ptr<RBX::Graphics::TextureCompositor::Job>::element_type *v14; // r10
  boost::detail::sp_counted_base *v15; // r8
  boost::detail::sp_counted_base *v16; // r8
  boost::detail::sp_counted_base *v17; // r8
  boost::shared_ptr<RBX::Graphics::TextureCompositor::Job>::element_type *v18; // r8
  boost::detail::sp_counted_base *v19; // r8
  boost::shared_ptr<RBX::Graphics::TextureCompositor::Job>::element_type *v20; // r8
  boost::detail::sp_counted_base *v21; // r8
  boost::shared_ptr<RBX::Graphics::TextureCompositor::Job>::element_type *v22; // rdx
  boost::detail::sp_counted_base *v23; // rcx

  px = (float *)__x2->px;
  v6 = *((float *)__x2->px + 22);
  v7 = __x1->px;
  v8 = *((float *)__x1->px + 22);
  v9 = __x3->px;
  v10 = *((float *)__x3->px + 22);
  if ( v8 <= v6 )
  {
    result = 0;
    if ( v6 <= v10 )
    {
      px = (float *)__x3->px;
    }
    else
    {
      __x2->px = v9;
      __x3->px = px;
      pi = __x3->pn.pi_;
      __x3->pn.pi_ = __x2->pn.pi_;
      __x2->pn.pi_ = pi;
      v14 = __x1->px;
      result = 1;
      if ( *((float *)__x1->px + 22) > *((float *)__x2->px + 22) )
      {
        __x1->px = __x2->px;
        __x2->px = v14;
        v15 = __x2->pn.pi_;
        __x2->pn.pi_ = __x1->pn.pi_;
        __x1->pn.pi_ = v15;
        px = (float *)__x3->px;
        result = 2;
      }
    }
  }
  else
  {
    if ( v6 <= v10 )
    {
      __x1->px = px;
      __x2->px = v7;
      v16 = __x2->pn.pi_;
      __x2->pn.pi_ = __x1->pn.pi_;
      __x1->pn.pi_ = v16;
      px = (float *)__x3->px;
      result = 1;
      if ( v8 <= *((float *)__x3->px + 22) )
        goto LABEL_11;
      v7 = __x2->px;
      __x2->px = px;
      __x3->px = v7;
      v17 = __x3->pn.pi_;
      __x3->pn.pi_ = __x2->pn.pi_;
      __x2->pn.pi_ = v17;
      result = 2;
    }
    else
    {
      __x1->px = v9;
      __x3->px = v7;
      v11 = __x3->pn.pi_;
      __x3->pn.pi_ = __x1->pn.pi_;
      __x1->pn.pi_ = v11;
      result = 1;
    }
    px = (float *)v7;
  }
LABEL_11:
  if ( px[22] > *((float *)__x4->px + 22) )
  {
    v18 = __x3->px;
    __x3->px = __x4->px;
    __x4->px = v18;
    v19 = __x4->pn.pi_;
    __x4->pn.pi_ = __x3->pn.pi_;
    __x3->pn.pi_ = v19;
    v20 = __x2->px;
    if ( *((float *)__x2->px + 22) <= *((float *)__x3->px + 22) )
    {
      ++result;
    }
    else
    {
      __x2->px = __x3->px;
      __x3->px = v20;
      v21 = __x3->pn.pi_;
      __x3->pn.pi_ = __x2->pn.pi_;
      __x2->pn.pi_ = v21;
      v22 = __x1->px;
      if ( *((float *)__x1->px + 22) <= *((float *)__x2->px + 22) )
      {
        result += 2;
      }
      else
      {
        __x1->px = __x2->px;
        __x2->px = v22;
        v23 = __x2->pn.pi_;
        __x2->pn.pi_ = __x1->pn.pi_;
        __x1->pn.pi_ = v23;
        result += 3;
      }
    }
  }
  return result;
}


// Address: 0x20a3b50 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics20TextureCompositorJobEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<RBX::Graphics::TextureCompositorJob>::shared_ptr<RBX::Graphics::TextureCompositorJob>(
        boost::shared_ptr<RBX::Graphics::TextureCompositorJob> *this,
        RBX::Graphics::TextureCompositorJob *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::Graphics::TextureCompositorJob>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x20a8d80 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics9TechniqueEED2Ev
void __fastcall boost::shared_ptr<RBX::Graphics::Technique>::~shared_ptr(
        boost::shared_ptr<RBX::Graphics::Technique> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x20a8de0 | Name: _ZN5boost10shared_ptrIN3RBX4BeamEED2Ev
void __fastcall boost::shared_ptr<RBX::Beam>::~shared_ptr(boost::shared_ptr<RBX::Beam> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x20af650 | Name: _ZN5boost10shared_ptrIN3RBX5TrailEED2Ev
void __fastcall boost::shared_ptr<RBX::Trail>::~shared_ptr(boost::shared_ptr<RBX::Trail> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x20bbd50 | Name: _ZN5boost10shared_ptrIN3RBX8FontDataEED2Ev
void __fastcall boost::shared_ptr<RBX::FontData>::~shared_ptr(boost::shared_ptr<RBX::FontData> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2759d20 | Name: _ZN3RBX8Graphics12RenderbufferC2ERKN5boost10shared_ptrINS0_7TextureEEE
void __fastcall RBX::Graphics::Renderbuffer::Renderbuffer(
        RBX::Graphics::Renderbuffer *this,
        const boost::shared_ptr<RBX::Graphics::Texture> *texture)
{
  boost::detail::sp_counted_base *pi; // rax

  this->texture.px = texture->px;
  pi = texture->pn.pi_;
  this->texture.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  *(_QWORD *)&this->index = 0;
}


// Address: 0x2759d50 | Name: _ZN3RBX8Graphics12RenderbufferC2ERKN5boost10shared_ptrINS0_7TextureEEEjj
void __fastcall RBX::Graphics::Renderbuffer::Renderbuffer(
        RBX::Graphics::Renderbuffer *this,
        const boost::shared_ptr<RBX::Graphics::Texture> *texture,
        unsigned int index,
        unsigned int mip)
{
  boost::detail::sp_counted_base *pi; // rax

  this->texture.px = texture->px;
  pi = texture->pn.pi_;
  this->texture.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  this->index = index;
  this->mip = mip;
}


// Address: 0x275a3f0 | Name: _ZN3RBX8Graphics13GeometryBatchC2ERKN5boost10shared_ptrINS0_8GeometryEEENS4_9PrimitiveEjj
void __fastcall RBX::Graphics::GeometryBatch::GeometryBatch(
        RBX::Graphics::GeometryBatch *this,
        const boost::shared_ptr<RBX::Graphics::Geometry> *geometry,
        RBX::Graphics::Geometry::Primitive primitive,
        unsigned int offset,
        unsigned int count)
{
  boost::detail::sp_counted_base *pi; // rax

  this->geometry.px = geometry->px;
  pi = geometry->pn.pi_;
  this->geometry.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  this->primitive = primitive;
  this->offset = offset;
  this->count = count;
}


// Address: 0x275cbc0 | Name: _ZN3RBX8Graphics8DeviceGL18updateWindowHandleEPv
void __fastcall RBX::Graphics::DeviceGL::updateWindowHandle(RBX::Graphics::DeviceGL *this, void *hwnd)
{
  (*(void (__fastcall **)(_QWORD, void *))(**((_QWORD **)this + 21) + 40LL))(*((_QWORD *)this + 21), hwnd);
}


// Address: 0x275d5a0 | Name: _ZN3RBX8Graphics8DeviceGL18getMainFramebufferEv
RBX::Graphics::Framebuffer *__fastcall RBX::Graphics::DeviceGL::getMainFramebuffer(RBX::Graphics::DeviceGL *this)
{
  return (RBX::Graphics::Framebuffer *)*((_QWORD *)this + 23);
}


// Address: 0x275df30 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics9ContextGLEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::Graphics::ContextGL>::reset<RBX::Graphics::ContextGL>(
        boost::shared_ptr<RBX::Graphics::ContextGL> *this,
        RBX::Graphics::ContextGL *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Graphics::ContextGL,RBX::Graphics::ContextGL>(
    (boost::shared_ptr<RBX::Graphics::ContextGL> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Graphics::ContextGL> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x275dfe0 | Name: _ZN5boost10shared_ptrIN3RBX8Graphics13FramebufferGLEE5resetIS3_EEvPT_
void __fastcall boost::shared_ptr<RBX::Graphics::FramebufferGL>::reset<RBX::Graphics::FramebufferGL>(
        boost::shared_ptr<RBX::Graphics::FramebufferGL> *this,
        RBX::Graphics::FramebufferGL *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::Graphics::FramebufferGL,RBX::Graphics::FramebufferGL>(
    (boost::shared_ptr<RBX::Graphics::FramebufferGL> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<RBX::Graphics::FramebufferGL> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x275e3b0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics9ContextGLES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::ContextGL,RBX::Graphics::ContextGL>(
        boost::shared_ptr<RBX::Graphics::ContextGL> *ppx,
        RBX::Graphics::ContextGL *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29CA0A8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x275e490 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics13FramebufferGLES4_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::FramebufferGL,RBX::Graphics::FramebufferGL>(
        boost::shared_ptr<RBX::Graphics::FramebufferGL> *ppx,
        RBX::Graphics::FramebufferGL *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29CA108;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x275e570 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics6ShaderENS3_8ShaderGLEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::Shader,RBX::Graphics::ShaderGL>(
        boost::shared_ptr<RBX::Graphics::Shader>_0 *ppx,
        RBX::Graphics::ShaderGL *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29CA168;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x275e650 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics13ShaderProgramENS3_15ShaderProgramGLEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::ShaderProgram,RBX::Graphics::ShaderProgramGL>(
        boost::shared_ptr<RBX::Graphics::ShaderProgram> *ppx,
        RBX::Graphics::ShaderProgramGL *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29CA1C8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x275e7e0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics12VertexLayoutENS3_14VertexLayoutGLEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::VertexLayout,RBX::Graphics::VertexLayoutGL>(
        boost::shared_ptr<RBX::Graphics::VertexLayout>_0 *ppx,
        RBX::Graphics::VertexLayoutGL *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29CA288;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x275e8c0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics7TextureENS3_9TextureGLEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::Texture,RBX::Graphics::TextureGL>(
        boost::shared_ptr<RBX::Graphics::Texture>_0 *ppx,
        RBX::Graphics::TextureGL *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29CA2E8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x275ea50 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX8Graphics11FramebufferENS3_13FramebufferGLEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::Graphics::Framebuffer,RBX::Graphics::FramebufferGL>(
        boost::shared_ptr<RBX::Graphics::Framebuffer> *ppx,
        RBX::Graphics::FramebufferGL *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29CA108;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x27beb90 | Name: _ZN5boost10shared_ptrIN3RBX9TaskQueueEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::TaskQueue>::shared_ptr<RBX::TaskQueue>(
        boost::shared_ptr<RBX::TaskQueue> *this,
        RBX::TaskQueue *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::TaskQueue>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x27bedd0 | Name: _ZNK3RBX12TaskQueueJob21getDesiredWorkerCountEv
int __fastcall RBX::TaskQueueJob::getDesiredWorkerCount(const RBX::TaskQueueJob *this)
{
  __int64 v1; // rax
  int v2; // ecx
  int v3; // edx
  int result; // eax

  v1 = *((_QWORD *)this + 54);
  v3 = *(_DWORD *)(v1 + 16);
  result = *(_DWORD *)(v1 + 128);
  v2 = result;
  if ( v3 <= result )
    result = v3;
  if ( v3 <= 0 )
    return v2;
  return result;
}


// Address: 0x27bedf0 | Name: _ZN5boost6detail20sp_pointer_constructIN3RBX13TaskScheduler3JobENS2_12TaskQueueJobEEEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<RBX::TaskScheduler::Job,RBX::TaskQueueJob>(
        boost::shared_ptr<RBX::TaskScheduler::Job> *ppx,
        RBX::TaskQueueJob *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29CAFD8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TaskScheduler::Job,RBX::TaskQueueJob>(
      (const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *)((char *)p + 8),
      ppx,
      p);
}


// Address: 0x27bff10 | Name: _ZN5boost10shared_ptrIN3RBX13TaskScheduler7ArbiterEED2Ev
void __fastcall boost::shared_ptr<RBX::TaskScheduler::Arbiter>::~shared_ptr(
        boost::shared_ptr<RBX::TaskScheduler::Arbiter> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x27c00a0 | Name: _ZN5boost10shared_ptrINS_15circular_bufferIdNSt3__19allocatorIdEEEEEC2IS5_EEPT_
void __fastcall boost::shared_ptr<boost::circular_buffer<double,std::allocator<double>>>::shared_ptr<boost::circular_buffer<double,std::allocator<double>>>(
        boost::shared_ptr<boost::circular_buffer<double,std::allocator<double> > > *this,
        boost::circular_buffer<double,std::allocator<double> > *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<boost::circular_buffer<double,std::allocator<double>>>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x27c9300 | Name: _ZN5boost10shared_ptrIN3RBX4dataEEC2IS2_EEPT_
void __fastcall boost::shared_ptr<RBX::data>::shared_ptr<RBX::data>(boost::shared_ptr<RBX::data> *this, RBX::data *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<RBX::data>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x27c93a0 | Name: _ZN5boost10shared_ptrIN3RBX4dataEED2Ev
void __fastcall boost::shared_ptr<RBX::data>::~shared_ptr(boost::shared_ptr<RBX::data> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x283e080 | Name: _ZN5boost10shared_ptrINS_10filesystem16filesystem_error5m_impEED2Ev
void __fastcall boost::shared_ptr<boost::filesystem::filesystem_error::m_imp>::~shared_ptr(
        boost::shared_ptr<boost::filesystem::filesystem_error::m_imp> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x283e2c0 | Name: _ZN5boost10shared_ptrINS_10filesystem16filesystem_error5m_impEEC2IS3_EEPT_
void __fastcall boost::shared_ptr<boost::filesystem::filesystem_error::m_imp>::shared_ptr<boost::filesystem::filesystem_error::m_imp>(
        boost::shared_ptr<boost::filesystem::filesystem_error::m_imp> *this,
        boost::filesystem::filesystem_error::m_imp *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_count v4; // [rsp+0h] [rbp-18h] BYREF

  v4.pi_ = v2;
  this->px = p;
  this->pn.pi_ = 0;
  boost::detail::shared_count::shared_count<boost::filesystem::filesystem_error::m_imp>(&v4, p);
  pi = this->pn.pi_;
  this->pn = v4;
  v4.pi_ = pi;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x28431e0 | Name: _ZNK5boost6thread15get_thread_infoEv
boost::shared_ptr<boost::detail::thread_data_base>::element_type **__fastcall boost::thread::get_thread_info(
        boost::shared_ptr<boost::detail::thread_data_base>::element_type **a1,
        const boost::thread *this)
{
  boost::detail::sp_counted_base *pi; // rax

  *a1 = this->thread_info.px;
  pi = this->thread_info.pn.pi_;
  a1[1] = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  return a1;
}


// Address: 0x2845720 | Name: _ZN5boost10shared_ptrINS_6detail16thread_data_baseEE5resetIS2_EEvPT_
void __fastcall boost::shared_ptr<boost::detail::thread_data_base>::reset<boost::detail::thread_data_base>(
        boost::shared_ptr<boost::detail::thread_data_base> *this,
        boost::detail::thread_data_base *p)
{
  __m128i v2; // xmm0
  volatile signed __int32 *v3; // xmm0_8
  boost::detail::shared_count pn[2]; // [rsp+0h] [rbp-28h] BYREF

  pn[0].pi_ = (boost::detail::sp_counted_base *)p;
  pn[1].pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data_base>(
    (boost::shared_ptr<boost::detail::thread_data_base> *)pn,
    p,
    &pn[1]);
  v2 = _mm_loadu_si128((const __m128i *)this);
  *this = *(boost::shared_ptr<boost::detail::thread_data_base> *)&pn[0].pi_;
  *(__m128i *)&pn[0].pi_ = v2;
  v3 = (volatile signed __int32 *)_mm_shuffle_epi32(v2, 78).m128i_u64[0];
  if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 16LL))(v3, *(double *)&v3);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0x2845d80 | Name: _ZN5boost6detail20sp_pointer_constructINS0_16thread_data_baseES2_EEvPNS_10shared_ptrIT_EEPT0_RNS0_12shared_countE
void __fastcall boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data_base>(
        boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data_base *p,
        boost::detail::shared_count *pn)
{
  boost::detail::sp_counted_base *v4; // rax
  boost::detail::sp_counted_base *pi; // rbx

  v4 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v4->use_count_ = 0x100000001LL;
  v4->_vptr$sp_counted_base = (int (**)(void))&off_29CFEF8;
  v4[1]._vptr$sp_counted_base = (int (**)(void))p;
  pi = pn->pi_;
  pn->pi_ = v4;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( p )
    boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data_base>(
      (const boost::enable_shared_from_this<boost::detail::thread_data_base> *)((char *)p + 8),
      ppx,
      p);
}


