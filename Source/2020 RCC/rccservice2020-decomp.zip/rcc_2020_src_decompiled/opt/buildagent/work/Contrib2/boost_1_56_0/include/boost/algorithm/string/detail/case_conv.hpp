// Address: 0x1370ea0 | Name: _ZN5boost9algorithm6detail20transform_range_copyINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEES9_NS1_9to_lowerFIcEEEET_RKT0_T1_
__int64 __fastcall boost::algorithm::detail::transform_range_copy<std::string,std::string,boost::algorithm::detail::to_lowerF<char>>(
        __int64 a1,
        unsigned __int8 *a2,
        std::locale *a3)
{
  unsigned __int64 v4; // rbx
  unsigned __int64 v5; // rbx
  unsigned __int8 *v6; // r13
  __int64 i; // rbp
  signed __int8 v8; // r12
  __int64 v9; // rax
  char v10; // al

  v4 = *a2;
  if ( (v4 & 1) != 0 )
  {
    v5 = *((_QWORD *)a2 + 1);
    v6 = (unsigned __int8 *)*((_QWORD *)a2 + 2);
  }
  else
  {
    v6 = a2 + 1;
    v5 = v4 >> 1;
  }
  *(_OWORD *)a1 = 0;
  *(_QWORD *)(a1 + 16) = 0;
  if ( v5 )
  {
    for ( i = 0; i != v5; ++i )
    {
      v8 = v6[i];
      v9 = std::locale::use_facet(a3, &std::ctype<char>::id);
      v10 = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v9 + 40LL))(v9, (unsigned int)v8);
      std::string::push_back(a1, (unsigned int)v10);
    }
  }
  return a1;
}


