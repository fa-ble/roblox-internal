// Address: 0x15dc2c0 | Name: _ZN5boost9date_time9base_timeINS_10posix_time5ptimeENS0_19counted_time_systemINS0_16counted_time_repINS2_33millisec_posix_time_system_configEEEEEEpLERKNS2_13time_durationE
boost::date_time::base_time<boost::posix_time::ptime,boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config> > >::time_type __fastcall boost::date_time::base_time<boost::posix_time::ptime,boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>>::operator+=(
        boost::date_time::base_time<boost::posix_time::ptime,boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config> > > *this,
        const boost::date_time::base_time<boost::posix_time::ptime,boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config> > >::time_duration_type *td)
{
  boost::date_time::int_adapter<long>::int_type v4; // rbx
  boost::date_time::base_time<boost::posix_time::ptime,boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config> > >::time_type result; // rax
  unsigned int v6; // ecx
  unsigned __int64 v7; // rax
  unsigned __int16 v8; // rcx^4
  __int16 v9; // dx
  __int16 v10; // si
  boost::date_time::int_adapter<long>::int_type value; // rsi
  unsigned __int64 v12; // rdx
  unsigned __int64 v13; // rbp
  unsigned __int64 v14; // rdi
  unsigned __int64 v15; // rdx

  v4 = 0x7FFFFFFFFFFFFFFELL;
  result.time_.time_count_.value_ = this->time_.time_count_.value_;
  if ( this->time_.time_count_.value_ == 0x8000000000000000LL )
  {
    v6 = 0;
    goto LABEL_9;
  }
  if ( result.time_.time_count_.value_ != 0x7FFFFFFFFFFFFFFELL )
  {
    v6 = -1;
    if ( result.time_.time_count_.value_ != 0x7FFFFFFFFFFFFFFFLL )
    {
      *(boost::date_time::gregorian_calendar_base<boost::date_time::year_month_day_base<boost::gregorian::greg_year,boost::gregorian::greg_month,boost::gregorian::greg_day>,unsigned int>::ymd_type *)&v7 = boost::date_time::gregorian_calendar_base<boost::date_time::year_month_day_base<boost::gregorian::greg_year,boost::gregorian::greg_month,boost::gregorian::greg_day>,unsigned int>::from_day_number(SLODWORD(result.time_.time_count_.value_) / 500654080);
      v8 = WORD2(v7);
      v9 = v7 + 4800;
      v7 >>= 16;
      v10 = ((unsigned __int64)(715827883LL * (14 - (unsigned __int16)v7)) >> 63)
          + ((715827883LL * (14 - (unsigned __int16)v7)) >> 33);
      v6 = (153 * (unsigned int)(unsigned __int16)(v7 + 12 * v10 - 3) + 2) / 5
         + ((unsigned int)(2622 * ((unsigned __int16)(v9 - v10) >> 4)) >> 16)
         + ((unsigned __int16)(v9 - v10) >> 2)
         + v8
         + 365 * (unsigned __int16)(v9 - v10)
         - 32045
         - ((unsigned int)(5243 * ((unsigned __int16)(v9 - v10) >> 2)) >> 17);
      result.time_.time_count_.value_ = this->time_.time_count_.value_;
      if ( this->time_.time_count_.value_ == 0x8000000000000000LL )
      {
LABEL_9:
        value = td->ticks_.value_;
        if ( td->ticks_.value_ == 0x7FFFFFFFFFFFFFFELL )
        {
          value = 0x7FFFFFFFFFFFFFFELL;
          goto LABEL_28;
        }
        v12 = result.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFFLL;
        if ( result.time_.time_count_.value_ == 0x8000000000000000LL )
        {
          v13 = 0x7FFFFFFFFFFFFFFFLL;
          v14 = 0x8000000000000000LL;
LABEL_15:
          if ( value == v13 )
            v14 = 0x7FFFFFFFFFFFFFFELL;
          if ( v12 < 2 || value == v13 )
          {
            value = v14;
            goto LABEL_28;
          }
          goto LABEL_22;
        }
        if ( result.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFFLL )
        {
          v13 = 0x8000000000000000LL;
          v14 = 0x7FFFFFFFFFFFFFFFLL;
          goto LABEL_15;
        }
        if ( v12 >= 2 )
        {
LABEL_22:
          if ( value == 0x8000000000000000LL )
          {
            value = 0x8000000000000000LL;
LABEL_28:
            if ( v6 + 2 >= 3 && (unsigned __int64)(value - 0x7FFFFFFFFFFFFFFELL) > 2 )
            {
              result.time_.time_count_.value_ = value + 86400000000LL * v6;
              goto LABEL_55;
            }
            switch ( value )
            {
              case 0x8000000000000000LL:
                goto LABEL_32;
              case 0x7FFFFFFFFFFFFFFELL:
                goto LABEL_48;
              case 0x7FFFFFFFFFFFFFFFLL:
LABEL_32:
                if ( v6 == -2 )
                  goto LABEL_54;
                break;
              default:
                if ( v6 + 1 >= 2 )
                {
                  result.time_.time_count_.value_ = 0x7FFFFFFFFFFFFFFELL;
                  if ( v6 == -2 )
                    goto LABEL_55;
                  goto LABEL_52;
                }
                break;
            }
            v15 = value - 0x7FFFFFFFFFFFFFFFLL;
            if ( value == 0x8000000000000000LL )
            {
              result.time_.time_count_.value_ = 0x8000000000000000LL;
              if ( v6 == -1 )
              {
                result.time_.time_count_.value_ = 0x7FFFFFFFFFFFFFFELL;
                goto LABEL_55;
              }
LABEL_41:
              if ( v15 < 2 )
                goto LABEL_55;
              goto LABEL_49;
            }
            if ( value == 0x7FFFFFFFFFFFFFFFLL )
            {
              result.time_.time_count_.value_ = 0x7FFFFFFFFFFFFFFFLL;
              if ( !v6 )
              {
                result.time_.time_count_.value_ = 0x7FFFFFFFFFFFFFFELL;
                goto LABEL_55;
              }
              goto LABEL_41;
            }
            if ( v15 >= 2 )
            {
LABEL_49:
              if ( v6 == -1 )
              {
                v4 = 0x7FFFFFFFFFFFFFFFLL;
                goto LABEL_54;
              }
              if ( !v6 )
              {
                v4 = 0x8000000000000000LL;
LABEL_54:
                result.time_.time_count_.value_ = v4;
                goto LABEL_55;
              }
LABEL_52:
              result.time_.time_count_.value_ = v6 + value;
              goto LABEL_55;
            }
LABEL_48:
            result.time_.time_count_.value_ = value;
            goto LABEL_55;
          }
          if ( value == 0x7FFFFFFFFFFFFFFFLL )
            goto LABEL_28;
LABEL_26:
          value += result.time_.time_count_.value_;
          goto LABEL_28;
        }
LABEL_21:
        value = result.time_.time_count_.value_;
        goto LABEL_28;
      }
      if ( result.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFELL )
        goto LABEL_21;
      if ( result.time_.time_count_.value_ != 0x7FFFFFFFFFFFFFFFLL )
      {
        value = td->ticks_.value_;
        result.time_.time_count_.value_ %= 86400000000LL;
        if ( (unsigned __int64)(td->ticks_.value_ - 0x7FFFFFFFFFFFFFFELL) > 2 )
          goto LABEL_26;
        goto LABEL_9;
      }
    }
    result.time_.time_count_.value_ = 0x7FFFFFFFFFFFFFFFLL;
    goto LABEL_9;
  }
LABEL_55:
  this->time_.time_count_.value_ = result.time_.time_count_.value_;
  return result;
}


