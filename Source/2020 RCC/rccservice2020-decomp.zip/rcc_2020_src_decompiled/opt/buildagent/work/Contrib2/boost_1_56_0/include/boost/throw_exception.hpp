// Address: 0xd9f210 | Name: _ZN5boost15throw_exceptionINS_12bad_weak_ptrEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::bad_weak_ptr>(const boost::bad_weak_ptr *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *exception; // rbx
  _OWORD v2[2]; // [rsp+0h] [rbp-48h] BYREF
  __int64 v3; // [rsp+20h] [rbp-28h]
  int v4; // [rsp+28h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)__cxa_allocate_exception(0x38u);
  v2[1] = 0;
  v3 = 0;
  v4 = -1;
  v2[0] = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2875CE0, (__m128i)(unsigned __int64)off_2875D08);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::bad_weak_ptr> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::~clone_impl);
}


// Address: 0xd9ff10 | Name: _ZN5boost15throw_exceptionINS_17bad_function_callEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::bad_function_call>(const boost::bad_function_call *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)__cxa_allocate_exception(0x40u);
  std::runtime_error::runtime_error((std::runtime_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_2875E90;
  v2[2] = off_2875EB8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::bad_function_call> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::~clone_impl);
}


// Address: 0xdaf920 | Name: _ZN5boost15throw_exceptionINS_21thread_resource_errorEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::thread_resource_error>(const boost::thread_resource_error *e)
{
  void *exception; // r15
  _QWORD v2[2]; // [rsp+8h] [rbp-80h] BYREF
  __int128 v3; // [rsp+18h] [rbp-70h]
  _BYTE v4[16]; // [rsp+28h] [rbp-60h] BYREF
  __int64 (__fastcall **v5)(); // [rsp+40h] [rbp-48h]
  __int128 v6; // [rsp+48h] [rbp-40h]
  __int64 v7; // [rsp+58h] [rbp-30h]
  int v8; // [rsp+60h] [rbp-28h]

  exception = __cxa_allocate_exception(0x68u);
  std::runtime_error::runtime_error((std::runtime_error *)v2, e);
  v2[0] = off_2875F00;
  v3 = *((_OWORD *)e + 1);
  std::string::basic_string(v4, (char *)e + 32);
  v6 = 0;
  v7 = 0;
  v8 = -1;
  v2[0] = off_28761D0;
  v5 = off_28761F8;
  boost::enable_current_exception<boost::exception_detail::error_info_injector<boost::thread_resource_error>>(
    exception,
    v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::~clone_impl);
}


// Address: 0xdb0490 | Name: _ZN5boost15throw_exceptionINS_10lock_errorEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::lock_error>(const boost::lock_error *e)
{
  void *exception; // r15
  _QWORD v2[2]; // [rsp+8h] [rbp-80h] BYREF
  __int128 v3; // [rsp+18h] [rbp-70h]
  _BYTE v4[16]; // [rsp+28h] [rbp-60h] BYREF
  __int64 (__fastcall **v5)(); // [rsp+40h] [rbp-48h]
  __int128 v6; // [rsp+48h] [rbp-40h]
  __int64 v7; // [rsp+58h] [rbp-30h]
  int v8; // [rsp+60h] [rbp-28h]

  exception = __cxa_allocate_exception(0x68u);
  std::runtime_error::runtime_error((std::runtime_error *)v2, e);
  v2[0] = off_2875F00;
  v3 = *((_OWORD *)e + 1);
  std::string::basic_string(v4, (char *)e + 32);
  v6 = 0;
  v7 = 0;
  v8 = -1;
  v2[0] = off_2876380;
  v5 = off_28763A8;
  boost::enable_current_exception<boost::exception_detail::error_info_injector<boost::lock_error>>(exception, v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::~clone_impl);
}


// Address: 0xdcb130 | Name: _ZN5boost15throw_exceptionINS_25promise_already_satisfiedEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::promise_already_satisfied>(
        const boost::promise_already_satisfied *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *exception; // r15
  _QWORD v2[2]; // [rsp+8h] [rbp-60h] BYREF
  __int128 v3; // [rsp+18h] [rbp-50h]
  __int64 (__fastcall **v4)(); // [rsp+28h] [rbp-40h]
  __int128 v5; // [rsp+30h] [rbp-38h]
  __int64 v6; // [rsp+40h] [rbp-28h]
  int v7; // [rsp+48h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)__cxa_allocate_exception(0x50u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = *((_OWORD *)e + 1);
  v5 = 0;
  v6 = 0;
  v7 = -1;
  v2[0] = off_2878720;
  v4 = off_2878748;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::promise_already_satisfied> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::~clone_impl);
}


// Address: 0xdcbf80 | Name: _ZN5boost15throw_exceptionINS_15condition_errorEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::condition_error>(const boost::condition_error *e)
{
  void *exception; // r15
  _QWORD v2[2]; // [rsp+8h] [rbp-80h] BYREF
  __int128 v3; // [rsp+18h] [rbp-70h]
  _BYTE v4[16]; // [rsp+28h] [rbp-60h] BYREF
  __int64 (__fastcall **v5)(); // [rsp+40h] [rbp-48h]
  __int128 v6; // [rsp+48h] [rbp-40h]
  __int64 v7; // [rsp+58h] [rbp-30h]
  int v8; // [rsp+60h] [rbp-28h]

  exception = __cxa_allocate_exception(0x68u);
  std::runtime_error::runtime_error((std::runtime_error *)v2, e);
  v2[0] = off_2875F00;
  v3 = *((_OWORD *)e + 1);
  std::string::basic_string(v4, (char *)e + 32);
  v6 = 0;
  v7 = 0;
  v8 = -1;
  v2[0] = off_2878510;
  v5 = off_2878538;
  boost::enable_current_exception<boost::exception_detail::error_info_injector<boost::condition_error>>(exception, v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::~clone_impl);
}


// Address: 0xdcd730 | Name: _ZN5boost15throw_exceptionINS_13promise_movedEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::promise_moved>(const boost::promise_moved *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *exception; // r15
  _QWORD v2[2]; // [rsp+8h] [rbp-60h] BYREF
  __int128 v3; // [rsp+18h] [rbp-50h]
  __int64 (__fastcall **v4)(); // [rsp+28h] [rbp-40h]
  __int128 v5; // [rsp+30h] [rbp-38h]
  __int64 v6; // [rsp+40h] [rbp-28h]
  int v7; // [rsp+48h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)__cxa_allocate_exception(0x50u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = *((_OWORD *)e + 1);
  v5 = 0;
  v6 = 0;
  v7 = -1;
  v2[0] = off_2878A80;
  v4 = off_2878AA8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::promise_moved> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::~clone_impl);
}


// Address: 0xdcd810 | Name: _ZN5boost15throw_exceptionINS_24future_already_retrievedEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::future_already_retrieved>(
        const boost::future_already_retrieved *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *exception; // r15
  _QWORD v2[2]; // [rsp+8h] [rbp-60h] BYREF
  __int128 v3; // [rsp+18h] [rbp-50h]
  __int64 (__fastcall **v4)(); // [rsp+28h] [rbp-40h]
  __int128 v5; // [rsp+30h] [rbp-38h]
  __int64 v6; // [rsp+40h] [rbp-28h]
  int v7; // [rsp+48h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)__cxa_allocate_exception(0x50u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = *((_OWORD *)e + 1);
  v5 = 0;
  v6 = 0;
  v7 = -1;
  v2[0] = off_2878C30;
  v4 = off_2878C58;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::future_already_retrieved> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::~clone_impl);
}


// Address: 0xdce6d0 | Name: _ZN5boost15throw_exceptionINS_20future_uninitializedEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::future_uninitialized>(const boost::future_uninitialized *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *exception; // r15
  _QWORD v2[2]; // [rsp+8h] [rbp-60h] BYREF
  __int128 v3; // [rsp+18h] [rbp-50h]
  __int64 (__fastcall **v4)(); // [rsp+28h] [rbp-40h]
  __int128 v5; // [rsp+30h] [rbp-38h]
  __int64 v6; // [rsp+40h] [rbp-28h]
  int v7; // [rsp+48h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)__cxa_allocate_exception(0x50u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = *((_OWORD *)e + 1);
  v5 = 0;
  v6 = 0;
  v7 = -1;
  v2[0] = off_2878DE0;
  v4 = off_2878E08;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::future_uninitialized> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::~clone_impl);
}


// Address: 0xe40d20 | Name: _ZN5boost15throw_exceptionINS_16bad_lexical_castEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::bad_lexical_cast>(const boost::bad_lexical_cast *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *exception; // r15
  __int64 (__fastcall **v2)(std::bad_cast *); // [rsp+0h] [rbp-58h] BYREF
  __int128 v3; // [rsp+8h] [rbp-50h]
  __int64 (__fastcall **v4)(); // [rsp+18h] [rbp-40h]
  __int128 v5; // [rsp+20h] [rbp-38h]
  __int64 v6; // [rsp+30h] [rbp-28h]
  int v7; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)__cxa_allocate_exception(0x48u);
  v3 = *(_OWORD *)((char *)e + 8);
  v5 = 0;
  v6 = 0;
  v7 = -1;
  v2 = off_287BC40;
  v4 = off_287BC68;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::bad_lexical_cast> *)&v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::~clone_impl);
}


// Address: 0xe42020 | Name: _ZN5boost15throw_exceptionINS_15program_options20invalid_option_valueEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::invalid_option_value>(
        const boost::program_options::invalid_option_value *e)
{
  char *exception; // r15
  _QWORD v2[15]; // [rsp+8h] [rbp-C0h] BYREF
  int v3; // [rsp+80h] [rbp-48h]
  boost::exception b; // [rsp+88h] [rbp-40h] BYREF

  exception = (char *)__cxa_allocate_exception(0xB0u);
  boost::program_options::error_with_option_name::error_with_option_name(
    (boost::program_options::error_with_option_name *)v2,
    e);
  v3 = *((_DWORD *)e + 30);
  memset(&b.data_, 0, 24);
  b.throw_line_ = -1;
  v2[0] = &off_287C110;
  b._vptr$exception = (int (**)(void))off_287C148;
  *((_QWORD *)exception + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *)exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *)v2);
  *(_QWORD *)exception = &off_287C060;
  *((_QWORD *)exception + 16) = off_287C0A8;
  *((_QWORD *)exception + 21) = &off_287C0E0;
  boost::exception_detail::copy_boost_exception((boost::exception *)(exception + 128), &b);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::~clone_impl);
}


// Address: 0xe421a0 | Name: _ZN5boost15throw_exceptionINS_15program_options16validation_errorEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::validation_error>(
        const boost::program_options::validation_error *e)
{
  char *exception; // r15
  _QWORD v2[15]; // [rsp+8h] [rbp-C0h] BYREF
  int v3; // [rsp+80h] [rbp-48h]
  boost::exception b; // [rsp+88h] [rbp-40h] BYREF

  exception = (char *)__cxa_allocate_exception(0xB0u);
  boost::program_options::error_with_option_name::error_with_option_name(
    (boost::program_options::error_with_option_name *)v2,
    e);
  v3 = *((_DWORD *)e + 30);
  memset(&b.data_, 0, 24);
  b.throw_line_ = -1;
  v2[0] = &off_287BEE0;
  b._vptr$exception = (int (**)(void))off_287BF18;
  *((_QWORD *)exception + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::validation_error> *)exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::validation_error> *)v2);
  *(_QWORD *)exception = &off_287BE30;
  *((_QWORD *)exception + 16) = off_287BE78;
  *((_QWORD *)exception + 21) = &off_287BEB0;
  boost::exception_detail::copy_boost_exception((boost::exception *)(exception + 128), &b);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::~clone_impl);
}


// Address: 0xe45080 | Name: _ZN5boost15throw_exceptionINS_12bad_any_castEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::bad_any_cast>(const boost::bad_any_cast *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *exception; // rbx
  _OWORD v2[2]; // [rsp+0h] [rbp-48h] BYREF
  __int64 v3; // [rsp+20h] [rbp-28h]
  int v4; // [rsp+28h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)__cxa_allocate_exception(0x38u);
  v2[1] = 0;
  v3 = 0;
  v4 = -1;
  v2[0] = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_287C2E0, (__m128i)(unsigned __int64)off_287C308);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::bad_any_cast> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::~clone_impl);
}


// Address: 0xe58480 | Name: _ZN5boost15throw_exceptionINS_15program_options26invalid_command_line_styleEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::invalid_command_line_style>(
        const boost::program_options::invalid_command_line_style *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_287D1F0;
  v2[2] = off_287D218;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::~clone_impl);
}


// Address: 0xe58560 | Name: _ZN5boost15throw_exceptionINS_15program_options33too_many_positional_options_errorEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::too_many_positional_options_error>(
        const boost::program_options::too_many_positional_options_error *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_287D380;
  v2[2] = off_287D3A8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::~clone_impl);
}


// Address: 0xe58640 | Name: _ZN5boost15throw_exceptionINS_15program_options14unknown_optionEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::unknown_option>(
        const boost::program_options::unknown_option *e)
{
  boost::exception *exception; // rbx
  _QWORD v2[15]; // [rsp+0h] [rbp-B8h] BYREF
  boost::exception b; // [rsp+78h] [rbp-40h] BYREF

  exception = (boost::exception *)__cxa_allocate_exception(0xA8u);
  boost::program_options::error_with_option_name::error_with_option_name(
    (boost::program_options::error_with_option_name *)v2,
    e);
  memset(&b.data_, 0, 24);
  b.throw_line_ = -1;
  v2[0] = &off_287D500;
  b._vptr$exception = (int (**)(void))off_287D538;
  exception[4]._vptr$exception = (int (**)(void))&off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *)exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *)v2);
  exception->_vptr$exception = (int (**)(void))&off_287D450;
  exception[3]._vptr$exception = (int (**)(void))off_287D498;
  exception[4]._vptr$exception = (int (**)(void))&off_287D4D0;
  boost::exception_detail::copy_boost_exception(exception + 3, &b);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::~clone_impl);
}


// Address: 0xe58830 | Name: _ZN5boost15throw_exceptionINS_15program_options27invalid_command_line_syntaxEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::invalid_command_line_syntax>(
        const boost::program_options::invalid_command_line_syntax *e)
{
  char *exception; // r15
  _QWORD v2[15]; // [rsp+8h] [rbp-C0h] BYREF
  int v3; // [rsp+80h] [rbp-48h]
  boost::exception b; // [rsp+88h] [rbp-40h] BYREF

  exception = (char *)__cxa_allocate_exception(0xB0u);
  boost::program_options::error_with_option_name::error_with_option_name(
    (boost::program_options::error_with_option_name *)v2,
    e);
  v3 = *((_DWORD *)e + 30);
  memset(&b.data_, 0, 24);
  b.throw_line_ = -1;
  v2[0] = &off_287D698;
  b._vptr$exception = (int (**)(void))off_287D6D8;
  *((_QWORD *)exception + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *)exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *)v2);
  *(_QWORD *)exception = &off_287D5E0;
  *((_QWORD *)exception + 16) = off_287D630;
  *((_QWORD *)exception + 21) = &off_287D668;
  boost::exception_detail::copy_boost_exception((boost::exception *)(exception + 128), &b);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::~clone_impl);
}


// Address: 0xe5b680 | Name: _ZN5boost15throw_exceptionISt11logic_errorEEvRKT_
void __fastcall __noreturn boost::throw_exception<std::logic_error>(const std::logic_error *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_287D860;
  v2[2] = off_287D888;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<std::logic_error> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::~clone_impl);
}


// Address: 0xe5fca0 | Name: _ZN5boost15throw_exceptionINS_15program_options16ambiguous_optionEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::ambiguous_option>(
        const boost::program_options::ambiguous_option *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *exception; // r15
  _BYTE v2[144]; // [rsp+8h] [rbp-D0h] BYREF

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)__cxa_allocate_exception(0xC0u);
  boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *)v2,
    e);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::~clone_impl);
}


// Address: 0xe60f60 | Name: _ZN5boost15throw_exceptionINS_15program_options5errorEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::error>(
        const boost::program_options::error *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_287DA00;
  v2[2] = off_287DA28;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::error> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::~clone_impl);
}


// Address: 0xe665d0 | Name: _ZN5boost15throw_exceptionINS_15program_options20multiple_occurrencesEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::multiple_occurrences>(
        const boost::program_options::multiple_occurrences *e)
{
  boost::exception *exception; // rbx
  _QWORD v2[15]; // [rsp+0h] [rbp-B8h] BYREF
  boost::exception b; // [rsp+78h] [rbp-40h] BYREF

  exception = (boost::exception *)__cxa_allocate_exception(0xA8u);
  boost::program_options::error_with_option_name::error_with_option_name(
    (boost::program_options::error_with_option_name *)v2,
    e);
  memset(&b.data_, 0, 24);
  b.throw_line_ = -1;
  v2[0] = &off_287E220;
  b._vptr$exception = (int (**)(void))off_287E258;
  exception[4]._vptr$exception = (int (**)(void))&off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *)exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *)v2);
  exception->_vptr$exception = (int (**)(void))&off_287E170;
  exception[3]._vptr$exception = (int (**)(void))off_287E1B8;
  exception[4]._vptr$exception = (int (**)(void))&off_287E1F0;
  boost::exception_detail::copy_boost_exception(exception + 3, &b);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::~clone_impl);
}


// Address: 0xe66800 | Name: _ZN5boost15throw_exceptionINS_15program_options15multiple_valuesEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::multiple_values>(
        const boost::program_options::multiple_values *e)
{
  boost::exception *exception; // rbx
  _QWORD v2[15]; // [rsp+0h] [rbp-B8h] BYREF
  boost::exception b; // [rsp+78h] [rbp-40h] BYREF

  exception = (boost::exception *)__cxa_allocate_exception(0xA8u);
  boost::program_options::error_with_option_name::error_with_option_name(
    (boost::program_options::error_with_option_name *)v2,
    e);
  memset(&b.data_, 0, 24);
  b.throw_line_ = -1;
  v2[0] = &off_287E3B0;
  b._vptr$exception = (int (**)(void))off_287E3E8;
  exception[4]._vptr$exception = (int (**)(void))&off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *)exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *)v2);
  exception->_vptr$exception = (int (**)(void))&off_287E300;
  exception[3]._vptr$exception = (int (**)(void))off_287E348;
  exception[4]._vptr$exception = (int (**)(void))&off_287E380;
  boost::exception_detail::copy_boost_exception(exception + 3, &b);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::~clone_impl);
}


// Address: 0xe66a30 | Name: _ZN5boost15throw_exceptionINS_15program_options18invalid_bool_valueEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::invalid_bool_value>(
        const boost::program_options::invalid_bool_value *e)
{
  char *exception; // r15
  _QWORD v2[15]; // [rsp+8h] [rbp-C0h] BYREF
  int v3; // [rsp+80h] [rbp-48h]
  boost::exception b; // [rsp+88h] [rbp-40h] BYREF

  exception = (char *)__cxa_allocate_exception(0xB0u);
  boost::program_options::error_with_option_name::error_with_option_name(
    (boost::program_options::error_with_option_name *)v2,
    e);
  v3 = *((_DWORD *)e + 30);
  memset(&b.data_, 0, 24);
  b.throw_line_ = -1;
  v2[0] = &off_287E660;
  b._vptr$exception = (int (**)(void))off_287E698;
  *((_QWORD *)exception + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *)exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *)v2);
  *(_QWORD *)exception = &off_287E5B0;
  *((_QWORD *)exception + 16) = off_287E5F8;
  *((_QWORD *)exception + 21) = &off_287E630;
  boost::exception_detail::copy_boost_exception((boost::exception *)(exception + 128), &b);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::~clone_impl);
}


// Address: 0xe6a280 | Name: _ZN5boost15throw_exceptionINS_15program_options15required_optionEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::program_options::required_option>(
        const boost::program_options::required_option *e)
{
  boost::exception *exception; // rbx
  _QWORD v2[15]; // [rsp+0h] [rbp-B8h] BYREF
  boost::exception b; // [rsp+78h] [rbp-40h] BYREF

  exception = (boost::exception *)__cxa_allocate_exception(0xA8u);
  boost::program_options::error_with_option_name::error_with_option_name(
    (boost::program_options::error_with_option_name *)v2,
    e);
  memset(&b.data_, 0, 24);
  b.throw_line_ = -1;
  v2[0] = &off_287E970;
  b._vptr$exception = (int (**)(void))off_287E9A8;
  exception[4]._vptr$exception = (int (**)(void))&off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::required_option> *)exception,
    (const boost::exception_detail::error_info_injector<boost::program_options::required_option> *)v2);
  exception->_vptr$exception = (int (**)(void))&off_287E8C0;
  exception[3]._vptr$exception = (int (**)(void))off_287E908;
  exception[4]._vptr$exception = (int (**)(void))&off_287E940;
  boost::exception_detail::copy_boost_exception(exception + 3, &b);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::~clone_impl);
}


// Address: 0xea7d50 | Name: _ZN5boost15throw_exceptionISt12length_errorEEvRKT_
void __fastcall __noreturn boost::throw_exception<std::length_error>(const std::length_error *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_287F390;
  v2[2] = off_287F3B8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<std::length_error> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::~clone_impl);
}


// Address: 0xf80160 | Name: _ZN5boost15throw_exceptionISt9bad_allocEEvRKT_
void __fastcall __noreturn boost::throw_exception<std::bad_alloc>(const std::bad_alloc *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *exception; // rbx
  _OWORD v2[2]; // [rsp+0h] [rbp-48h] BYREF
  __int64 v3; // [rsp+20h] [rbp-28h]
  int v4; // [rsp+28h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)__cxa_allocate_exception(0x38u);
  v2[1] = 0;
  v3 = 0;
  v4 = -1;
  v2[0] = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2885420, (__m128i)(unsigned __int64)off_2885448);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<std::bad_alloc> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::~clone_impl);
}


// Address: 0xfe7d90 | Name: _ZN5boost15throw_exceptionINS_9gregorian8bad_yearEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::gregorian::bad_year>(const boost::gregorian::bad_year *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_2889BA0;
  v2[2] = off_2889BC8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::gregorian::bad_year> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::~clone_impl);
}


// Address: 0xfe8630 | Name: _ZN5boost15throw_exceptionINS_9gregorian9bad_monthEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::gregorian::bad_month>(const boost::gregorian::bad_month *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_2889D50;
  v2[2] = off_2889D78;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::gregorian::bad_month> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::~clone_impl);
}


// Address: 0xfe8ee0 | Name: _ZN5boost15throw_exceptionINS_9gregorian16bad_day_of_monthEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::gregorian::bad_day_of_month>(
        const boost::gregorian::bad_day_of_month *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_2889F00;
  v2[2] = off_2889F28;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::~clone_impl);
}


// Address: 0xfe9870 | Name: _ZN5boost15throw_exceptionISt13runtime_errorEEvRKT_
void __fastcall __noreturn boost::throw_exception<std::runtime_error>(const std::runtime_error *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)__cxa_allocate_exception(0x40u);
  std::runtime_error::runtime_error((std::runtime_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_288A090;
  v2[2] = off_288A0B8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<std::runtime_error> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::~clone_impl);
}


// Address: 0x1217ed0 | Name: _ZN5boost16exception_detail16throw_exception_ISt12out_of_rangeEEvRKT_PKcS7_i
void __fastcall __noreturn boost::exception_detail::throw_exception_<std::out_of_range>(
        const std::out_of_range *x,
        const char *current_function,
        const char *file,
        int line)
{
  _QWORD v6[6]; // [rsp+0h] [rbp-58h] BYREF
  int v7; // [rsp+30h] [rbp-28h]

  std::logic_error::logic_error((std::logic_error *)v6, x);
  v6[3] = 0;
  v6[0] = off_28A2EC0;
  v6[2] = off_28A2EE8;
  v6[4] = current_function;
  v6[5] = file;
  v7 = line;
  boost::throw_exception<boost::exception_detail::error_info_injector<std::out_of_range>>((const boost::exception_detail::error_info_injector<std::out_of_range> *)v6);
}


// Address: 0x1217f70 | Name: _ZN5boost15throw_exceptionINS_16exception_detail19error_info_injectorISt12out_of_rangeEEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::exception_detail::error_info_injector<std::out_of_range>>(
        const boost::exception_detail::error_info_injector<std::out_of_range> *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *exception; // r15
  __int64 v3; // rdi
  _QWORD v4[2]; // [rsp+0h] [rbp-58h] BYREF
  __int64 (__fastcall **v5)(); // [rsp+10h] [rbp-48h]
  __int64 v6; // [rsp+18h] [rbp-40h]
  __int128 v7; // [rsp+20h] [rbp-38h]
  int v8; // [rsp+30h] [rbp-28h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v4, e);
  v4[0] = (char *)&`vtable for'std::out_of_range + 16;
  v5 = (__int64 (__fastcall **)())&off_2875508;
  v3 = *((_QWORD *)e + 3);
  v6 = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  v8 = *((_DWORD *)e + 12);
  v7 = *((_OWORD *)e + 2);
  v4[0] = off_28A2EC0;
  v5 = off_28A2EE8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<std::out_of_range> *)v4);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::~clone_impl);
}


// Address: 0x1282760 | Name: _ZN5boost16exception_detail16throw_exception_ISt13runtime_errorEEvRKT_PKcS7_i
void __fastcall __noreturn boost::exception_detail::throw_exception_<std::runtime_error>(
        const std::runtime_error *x,
        const char *current_function,
        const char *file,
        int line)
{
  _QWORD v6[6]; // [rsp+0h] [rbp-58h] BYREF
  int v7; // [rsp+30h] [rbp-28h]

  std::runtime_error::runtime_error((std::runtime_error *)v6, x);
  v6[3] = 0;
  v6[0] = off_288A090;
  v6[2] = off_288A0B8;
  v6[4] = current_function;
  v6[5] = file;
  v7 = line;
  boost::throw_exception<boost::exception_detail::error_info_injector<std::runtime_error>>((const boost::exception_detail::error_info_injector<std::runtime_error> *)v6);
}


// Address: 0x1282a80 | Name: _ZN5boost15throw_exceptionINS_16exception_detail19error_info_injectorISt13runtime_errorEEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::exception_detail::error_info_injector<std::runtime_error>>(
        const boost::exception_detail::error_info_injector<std::runtime_error> *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *exception; // r15
  __int64 v3; // rdi
  _QWORD v4[2]; // [rsp+0h] [rbp-58h] BYREF
  __int64 (__fastcall **v5)(); // [rsp+10h] [rbp-48h]
  __int64 v6; // [rsp+18h] [rbp-40h]
  __int128 v7; // [rsp+20h] [rbp-38h]
  int v8; // [rsp+30h] [rbp-28h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)__cxa_allocate_exception(0x40u);
  std::runtime_error::runtime_error((std::runtime_error *)v4, e);
  v5 = (__int64 (__fastcall **)())&off_2875508;
  v3 = *((_QWORD *)e + 3);
  v6 = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  v8 = *((_DWORD *)e + 12);
  v7 = *((_OWORD *)e + 2);
  v4[0] = off_288A090;
  v5 = off_288A0B8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<std::runtime_error> *)v4);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::~clone_impl);
}


// Address: 0x1282b70 | Name: _ZN5boost15throw_exceptionISt16invalid_argumentEEvRKT_
void __fastcall __noreturn boost::throw_exception<std::invalid_argument>(const std::invalid_argument *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_28A54D0;
  v2[2] = off_28A54F8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<std::invalid_argument> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::~clone_impl);
}


// Address: 0x1492280 | Name: _ZN5boost15throw_exceptionISt12out_of_rangeEEvRKT_
void __fastcall __noreturn boost::throw_exception<std::out_of_range>(const std::out_of_range *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_28A2EC0;
  v2[2] = off_28A2EE8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<std::out_of_range> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::~clone_impl);
}


// Address: 0x14b8ca0 | Name: _ZN5boost15throw_exceptionINS_19bad_optional_accessEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::bad_optional_access>(const boost::bad_optional_access *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *exception; // r15
  _QWORD v2[3]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v3; // [rsp+20h] [rbp-38h]
  __int64 v4; // [rsp+30h] [rbp-28h]
  int v5; // [rsp+38h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)__cxa_allocate_exception(0x40u);
  std::logic_error::logic_error((std::logic_error *)v2, e);
  v3 = 0;
  v4 = 0;
  v5 = -1;
  v2[0] = off_28BAE70;
  v2[2] = off_28BAE98;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<boost::bad_optional_access> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::~clone_impl);
}


// Address: 0x2029fd0 | Name: _ZN5boost15throw_exceptionINSt3__18ios_base7failureEEEvRKT_
void __fastcall __noreturn boost::throw_exception<std::ios_base::failure>(const std::ios_base::failure *e)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *exception; // r15
  _QWORD v2[2]; // [rsp+8h] [rbp-60h] BYREF
  __int128 v3; // [rsp+18h] [rbp-50h]
  __int64 (__fastcall **v4)(); // [rsp+28h] [rbp-40h]
  __int128 v5; // [rsp+30h] [rbp-38h]
  __int64 v6; // [rsp+40h] [rbp-28h]
  int v7; // [rsp+48h] [rbp-20h]

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)__cxa_allocate_exception(0x50u);
  std::runtime_error::runtime_error((std::runtime_error *)v2, e);
  v3 = *((_OWORD *)e + 1);
  v5 = 0;
  v6 = 0;
  v7 = -1;
  v2[0] = off_29A6DC0;
  v4 = off_29A6DE8;
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::clone_impl(
    exception,
    (const boost::exception_detail::error_info_injector<std::ios_base::failure> *)v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::~clone_impl);
}


// Address: 0x25f4460 | Name: _ZN5boost15throw_exceptionINS_6system12system_errorEEEvRKT_
void __fastcall __noreturn boost::throw_exception<boost::system::system_error>(const boost::system::system_error *e)
{
  void *exception; // r15
  _QWORD v2[2]; // [rsp+8h] [rbp-80h] BYREF
  __int128 v3; // [rsp+18h] [rbp-70h]
  _BYTE v4[16]; // [rsp+28h] [rbp-60h] BYREF
  __int64 (__fastcall **v5)(); // [rsp+40h] [rbp-48h]
  __int128 v6; // [rsp+48h] [rbp-40h]
  __int64 v7; // [rsp+58h] [rbp-30h]
  int v8; // [rsp+60h] [rbp-28h]

  exception = __cxa_allocate_exception(0x68u);
  std::runtime_error::runtime_error((std::runtime_error *)v2, e);
  v2[0] = off_2875F00;
  v3 = *((_OWORD *)e + 1);
  std::string::basic_string(v4, (char *)e + 32);
  v6 = 0;
  v7 = 0;
  v8 = -1;
  v2[0] = off_29C27A0;
  v5 = off_29C27C8;
  boost::enable_current_exception<boost::exception_detail::error_info_injector<boost::system::system_error>>(
    exception,
    v2);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::~clone_impl);
}


