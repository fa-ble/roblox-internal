// Address: 0xe53f10 | Name: _ZN5boost15program_options14invalid_syntax12get_templateENS1_6kind_tE
boost::program_options::invalid_syntax *__fastcall boost::program_options::invalid_syntax::get_template(
        boost::program_options::invalid_syntax *this,
        boost::program_options::invalid_syntax::kind_t a2,
        int a3)
{
  unsigned int v3; // edx
  const char *v4; // r14
  size_t v5; // rax
  size_t v6; // r13
  char *v7; // r12
  size_t v8; // rbx

  v3 = a3 - 30;
  if ( v3 > 6 )
    v4 = "unknown command line syntax error for '%s'";
  else
    v4 = (&off_287D6F0)[v3];
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v5 = strlen(v4);
  if ( v5 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(this);
    JUMPOUT(0xE53FC5);
  }
  v6 = v5;
  if ( v5 >= 0x17 )
  {
    v8 = (v5 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v7 = (char *)operator new(v8);
    *((_QWORD *)this + 2) = v7;
    *(_QWORD *)this = v8 | 1;
    *((_QWORD *)this + 1) = v6;
  }
  else
  {
    *(_BYTE *)this = 2 * v5;
    v7 = (char *)this + 1;
    if ( !v5 )
      goto LABEL_10;
  }
  memcpy(v7, v4, v6);
LABEL_10:
  v7[v6] = 0;
  return this;
}


// Address: 0xe53fd0 | Name: _ZN5boost15program_options6detail7cmdlineC2ERKNSt3__16vectorINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS8_ISA_EEEE
void __fastcall boost::program_options::detail::cmdline::cmdline(
        boost::program_options::detail::cmdline *this,
        const std::vector<std::string> *args)
{
  __int128 v2; // xmm0

  v2 = 0;
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  *((_QWORD *)this + 6) = 0;
  *((_QWORD *)this + 10) = 0;
  if ( this != args )
  {
    std::vector<std::string>::assign<std::string*>(this, *(std::string **)args, *((std::string **)args + 1));
    v2 = 0;
  }
  *((_DWORD *)this + 6) = 1015;
  *((_BYTE *)this + 28) = 0;
  *((_OWORD *)this + 2) = v2;
}


// Address: 0xe54100 | Name: _ZN5boost15program_options6detail7cmdline4initERKNSt3__16vectorINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS8_ISA_EEEE
void __fastcall boost::program_options::detail::cmdline::init(
        boost::program_options::detail::cmdline *this,
        const std::vector<std::string> *args)
{
  if ( this != args )
    std::vector<std::string>::assign<std::string*>(this, *(std::string **)args, *((std::string **)args + 1));
  *((_DWORD *)this + 6) = 1015;
  *((_BYTE *)this + 28) = 0;
  *((_OWORD *)this + 2) = 0;
}


// Address: 0xe54130 | Name: _ZN5boost15program_options6detail7cmdlineC2EiPKPKc
void __fastcall boost::program_options::detail::cmdline::cmdline(
        boost::program_options::detail::cmdline *this,
        int argc,
        const char *const *argv)
{
  std::string *v3; // r14
  std::string *v4; // rax
  std::string *v5; // rbx
  std::string *v6; // rdi
  std::string *__first; // [rsp+0h] [rbp-38h] BYREF
  std::string *__last; // [rsp+8h] [rbp-30h]

  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  *((_QWORD *)this + 6) = 0;
  *((_QWORD *)this + 10) = 0;
  std::vector<std::string>::vector<char const* const*>(
    (std::vector<std::string> *)&__first,
    argv + 1,
    &(&argv[argc])[argc == 0]);
  if ( this != (boost::program_options::detail::cmdline *)&__first )
    std::vector<std::string>::assign<std::string*>(this, __first, __last);
  *((_DWORD *)this + 6) = 1015;
  *((_BYTE *)this + 28) = 0;
  *((_OWORD *)this + 2) = 0;
  v3 = __first;
  if ( __first )
  {
    v4 = __last;
    if ( __last == __first )
    {
      v6 = __first;
    }
    else
    {
      do
      {
        v5 = (std::string *)((char *)v4 - 24);
        if ( (*((_BYTE *)v4 - 24) & 1) != 0 )
          operator delete(*((void **)v4 - 1));
        v4 = v5;
      }
      while ( v3 != v5 );
      v6 = __first;
    }
    __last = v3;
    operator delete(v6);
  }
}


// Address: 0xe54310 | Name: _ZN5boost15program_options6detail7cmdline5styleEi
void __fastcall boost::program_options::detail::cmdline::style(
        boost::program_options::detail::cmdline *this,
        int style)
{
  int v2; // ebp

  v2 = 1015;
  if ( style )
    v2 = style;
  boost::program_options::detail::cmdline::check_style(this, v2);
  *((_DWORD *)this + 6) = v2;
}


// Address: 0xe54340 | Name: _ZNK5boost15program_options6detail7cmdline11check_styleEi
void __fastcall boost::program_options::detail::cmdline::check_style(
        const boost::program_options::detail::cmdline *this,
        int style)
{
  bool v2; // al
  bool v3; // cl
  const char *v4; // rbx
  bool v5; // zf
  const char *v6; // rax
  int v7; // esi
  const char *v8; // rbx
  size_t v9; // rax
  size_t v10; // r14
  char *v11; // r15
  size_t v12; // r12
  __int128 dest; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  _QWORD v15[6]; // [rsp+18h] [rbp-30h] BYREF

  v2 = (style & 0x1001) != 0;
  v3 = (style & 0x30) == 0;
  v4 = 0;
  v5 = !v2 || !v3;
  if ( v2 && v3 )
    v4 = "boost::program_options misconfiguration: choose one or other of 'command_line_style::long_allow_next' (whitespa"
         "ce separated arguments) or 'command_line_style::long_allow_adjacent' ('=' separated arguments) for long options.";
  v6 = "boost::program_options misconfiguration: choose one or other of 'command_line_style::short_allow_next' (whitespac"
       "e separated arguments) or 'command_line_style::short_allow_adjacent' ('=' separated arguments) for short options.";
  if ( !v5 )
    v6 = v4;
  if ( (style & 0xC2) != 2 )
    v6 = v4;
  v7 = style & 0xE;
  v8 = "boost::program_options misconfiguration: choose one or other of 'command_line_style::allow_slash_for_short' (slas"
       "hes) or 'command_line_style::allow_dash_for_short' (dashes) for short options.";
  if ( v6 )
    v8 = v6;
  if ( v7 != 2 )
    v8 = v6;
  if ( v8 )
  {
    dest = 0;
    ptr = 0;
    v9 = strlen(v8);
    if ( v9 >= 0xFFFFFFFFFFFFFFF0LL )
      v9 = std::__basic_string_common<true>::__throw_length_error(&dest);
    v10 = v9;
    if ( v9 >= 0x17 )
    {
      v12 = (v9 + 16) & 0xFFFFFFFFFFFFFFF0LL;
      v11 = (char *)operator new(v12);
      ptr = v11;
      *(_QWORD *)&dest = v12 | 1;
      *((_QWORD *)&dest + 1) = v10;
    }
    else
    {
      LOBYTE(dest) = 2 * v9;
      v11 = (char *)&dest + 1;
      if ( !v9 )
      {
LABEL_19:
        v11[v10] = 0;
        std::logic_error::logic_error(v15, &dest);
        v15[0] = off_287CE98;
        boost::throw_exception<boost::program_options::invalid_command_line_style>((const boost::program_options::invalid_command_line_style *)v15);
      }
    }
    memcpy(v11, v8, v10);
    goto LABEL_19;
  }
}


// Address: 0xe54480 | Name: _ZN5boost15program_options6detail7cmdline18allow_unregisteredEv
void __fastcall boost::program_options::detail::cmdline::allow_unregistered(
        boost::program_options::detail::cmdline *this)
{
  *((_BYTE *)this + 28) = 1;
}


// Address: 0xe54490 | Name: _ZNK5boost15program_options6detail7cmdline15is_style_activeENS0_18command_line_style7style_tE
bool __fastcall boost::program_options::detail::cmdline::is_style_active(
        const boost::program_options::detail::cmdline *this,
        boost::program_options::detail::cmdline::style_t style)
{
  return (style & *((_DWORD *)this + 6)) != 0;
}


// Address: 0xe544a0 | Name: _ZN5boost15program_options6detail7cmdline23set_options_descriptionERKNS0_19options_descriptionE
void __fastcall boost::program_options::detail::cmdline::set_options_description(
        boost::program_options::detail::cmdline *this,
        const boost::program_options::options_description *desc)
{
  *((_QWORD *)this + 4) = desc;
}


// Address: 0xe544b0 | Name: _ZN5boost15program_options6detail7cmdline22set_positional_optionsERKNS0_30positional_options_descriptionE
void __fastcall boost::program_options::detail::cmdline::set_positional_options(
        boost::program_options::detail::cmdline *this,
        const boost::program_options::positional_options_description *positional)
{
  *((_QWORD *)this + 5) = positional;
}


// Address: 0xe544c0 | Name: _ZN5boost15program_options6detail7cmdline27get_canonical_option_prefixEv
int __fastcall boost::program_options::detail::cmdline::get_canonical_option_prefix(
        boost::program_options::detail::cmdline *this)
{
  int v1; // ecx
  int result; // eax

  v1 = *((_DWORD *)this + 6);
  result = 1;
  if ( (v1 & 1) == 0 )
  {
    result = 4096;
    if ( (v1 & 0x1000) == 0 )
    {
      result = 4;
      if ( (*((_DWORD *)this + 6) & 6) != 6 )
        return 8 * ((*((_DWORD *)this + 6) & 0xA) == 10);
    }
  }
  return result;
}


// Address: 0xe54500 | Name: _ZN5boost15program_options6detail7cmdline3runEv
std::__vector_base<boost::program_options::basic_option<char>> *__fastcall boost::program_options::detail::cmdline::run(
        boost::program_options::detail::cmdline *this,
        const std::string **a2)
{
  const std::string **v2; // rbx
  void (__fastcall *v4)(boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>::dummy *); // rcx
  void (__fastcall *v5)(boost::function1<std::pair<std::string,std::string >,const std::string &>::dummy *); // rcx
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v6; // rdi
  void (__fastcall *v7)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  int v8; // eax
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v9; // rdi
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v11; // rdi
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v13; // rdi
  void (__fastcall *v14)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v15; // rdi
  void (__fastcall *v16)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v17; // rdi
  void (__fastcall *v18)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  __int128 v19; // xmm0
  const std::string *v20; // rax
  const std::string *v21; // r15
  bool v22; // zf
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v23; // rcx
  boost::detail::function::vtable_base *vtable; // rbp
  __int64 v25; // r15
  unsigned __int64 v26; // r12
  boost::detail::function::vtable_base *v27; // rcx
  char *obj_ptr; // rsi
  unsigned int v29; // ebp
  unsigned __int64 v30; // rdx
  boost::detail::function::vtable_base *v31; // rcx
  unsigned int v32; // ebp
  unsigned __int64 v33; // rsi
  const boost::program_options::basic_option<char> *v34; // rsi
  boost::program_options::basic_option<char> *v35; // rdi
  void **v36; // rbp
  void **v37; // rax
  void **v38; // r13
  unsigned __int64 v39; // rbp
  const std::string *v40; // rsi
  boost::program_options::basic_option<char> *v41; // rdi
  const std::string *v42; // r15
  const std::string *v43; // rbx
  const std::string *v44; // rax
  const std::string *v45; // rbx
  const std::string *v46; // rbx
  __int64 v47; // rbx
  __int64 v48; // rax
  __int64 v49; // rbp
  void *v50; // rdi
  __int64 v51; // rbx
  __int64 v52; // rax
  __int64 v53; // rbp
  void *v54; // rdi
  char *v55; // rcx
  char *v56; // rax
  boost::program_options::basic_option<char> *v57; // rax
  boost::program_options::basic_option<char> *v58; // rdi
  unsigned __int64 v59; // rsi
  int v60; // r12d
  const boost::program_options::basic_option<char> *v61; // rsi
  char *v62; // rcx
  unsigned __int64 v63; // rax
  const boost::program_options::option_description *nothrow; // rax
  const boost::program_options::option_description *v65; // rbp
  const boost::program_options::option_description *v66; // rsi
  boost::shared_ptr<const boost::program_options::value_semantic>_0 v67; // rax
  unsigned int v68; // r13d
  volatile signed __int32 *v69; // r15
  const boost::program_options::option_description *v70; // rsi
  boost::shared_ptr<const boost::program_options::value_semantic>_0 v71; // rax
  __int64 v72; // rdx
  unsigned int v73; // r15d
  volatile signed __int32 *v74; // rbp
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> **v75; // rcx
  __int64 v76; // rdx
  unsigned __int64 v77; // r13
  int v78; // edx
  std::vector<std::string> *v79; // r12
  int v80; // r13d
  unsigned __int64 v81; // r15
  char *v82; // rbx
  __int64 v83; // rbp
  unsigned __int64 v84; // rax
  int v85; // esi
  const std::string *v86; // rsi
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v87; // rdi
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> **v88; // rax
  const std::string *v89; // rsi
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v90; // rdi
  void *v91; // rdx
  char *v92; // r13
  _BYTE *v93; // rax
  boost::program_options::basic_option<char> *v94; // rsi
  std::__vector_base<boost::program_options::basic_option<char>> *v95; // rdi
  boost::program_options::basic_option<char> *v96; // rcx
  unsigned __int64 v97; // rdi
  unsigned int v98; // edx
  int v99; // esi
  __int64 v100; // rdi
  unsigned __int64 v101; // rbp
  unsigned __int64 v102; // rcx
  unsigned int v103; // ebx
  unsigned int v104; // r15d
  __int64 v105; // rbp
  int v106; // eax
  int v107; // edx
  void *v108; // rcx
  size_t v109; // r8
  const void *v110; // r9
  __int64 v111; // rax
  const std::string **v112; // rbx
  __int64 v113; // rax
  unsigned __int64 v114; // rdx
  unsigned __int64 v115; // rsi
  unsigned __int64 v116; // rax
  char v117; // cl
  unsigned int v118; // edx
  unsigned __int64 v119; // rcx
  __int64 v120; // rsi
  unsigned __int64 v121; // rbp
  unsigned __int64 v122; // rdi
  char v123; // cl
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v124; // rbx
  std::__vector_base<boost::program_options::basic_option<char>> *v125; // r14
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v126; // rbp
  boost::detail::function::vtable_base *v127; // rax
  void (__fastcall *v128)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v129; // rdi
  __m128i *v131; // rax
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v132[2]; // [rsp+0h] [rbp-F8h] BYREF
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *v133; // [rsp+10h] [rbp-E8h]
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> **v134; // [rsp+20h] [rbp-D8h]
  const std::string **v135; // [rsp+28h] [rbp-D0h]
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> f; // [rsp+30h] [rbp-C8h] BYREF
  __int128 v137; // [rsp+50h] [rbp-A8h] BYREF
  __int128 v138; // [rsp+60h] [rbp-98h] BYREF
  __int128 v139; // [rsp+70h] [rbp-88h]
  __int16 v140; // [rsp+80h] [rbp-78h]
  std::__vector_base<boost::program_options::basic_option<char>> *v141; // [rsp+88h] [rbp-70h]
  void *ptr[2]; // [rsp+90h] [rbp-68h] BYREF
  boost::program_options::basic_option<char> *v143; // [rsp+A0h] [rbp-58h]
  _QWORD *v144; // [rsp+A8h] [rbp-50h]
  _QWORD v145[2]; // [rsp+B0h] [rbp-48h] BYREF
  std::vector<std::string> *v146; // [rsp+C0h] [rbp-38h]

  v2 = a2;
  *(_OWORD *)v132 = 0;
  v133 = 0;
  v4 = boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>::dummy::nonnull;
  if ( !a2[10] )
    v4 = 0;
  if ( v4 )
    std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>::__push_back_slow_path<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> const&>(
      (std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>> *)v132,
      (const boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *)(a2 + 10));
  v5 = boost::function1<std::pair<std::string,std::string>,std::string const&>::dummy::nonnull;
  if ( !a2[6] )
    v5 = 0;
  if ( v5 )
  {
    *(_OWORD *)&f.functor.obj_ptr = (unsigned __int64)boost::program_options::detail::cmdline::handle_additional_parser;
    f.functor.bound_memfunc_ptr.obj_ptr = a2;
    f.vtable = (boost::detail::function::vtable_base *)((char *)off_287D228 + 1);
    v6 = v132[1];
    if ( v132[1] >= v133 )
    {
      std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>::__push_back_slow_path<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>(
        (std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>> *)v132,
        &f);
    }
    else
    {
      v132[1]->vtable = 0;
      boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>::move_assign(
        v6,
        &f);
      ++v132[1];
    }
    if ( f.vtable )
    {
      if ( ((__int64)f.vtable & 1) == 0 )
      {
        v7 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)f.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v7 )
          v7(&f.functor, &f.functor, 2);
      }
      f.vtable = 0;
    }
  }
  v8 = *((_DWORD *)a2 + 6);
  if ( (v8 & 1) != 0 )
  {
    *(_OWORD *)&f.functor.obj_ptr = (unsigned __int64)boost::program_options::detail::cmdline::parse_long_option;
    f.functor.bound_memfunc_ptr.obj_ptr = a2;
    f.vtable = (boost::detail::function::vtable_base *)((char *)off_287D228 + 1);
    v9 = v132[1];
    if ( v132[1] >= v133 )
    {
      std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>::__push_back_slow_path<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>(
        (std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>> *)v132,
        &f);
    }
    else
    {
      v132[1]->vtable = 0;
      boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>::move_assign(
        v9,
        &f);
      ++v132[1];
    }
    if ( f.vtable )
    {
      if ( ((__int64)f.vtable & 1) == 0 )
      {
        v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)f.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v10 )
          v10(&f.functor, &f.functor, 2);
      }
      f.vtable = 0;
    }
    v8 = *((_DWORD *)a2 + 6);
  }
  if ( (v8 & 0x1000) != 0 )
  {
    *(_OWORD *)&f.functor.obj_ptr = (unsigned __int64)boost::program_options::detail::cmdline::parse_disguised_long_option;
    f.functor.bound_memfunc_ptr.obj_ptr = a2;
    f.vtable = (boost::detail::function::vtable_base *)((char *)off_287D228 + 1);
    v11 = v132[1];
    if ( v132[1] >= v133 )
    {
      std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>::__push_back_slow_path<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>(
        (std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>> *)v132,
        &f);
    }
    else
    {
      v132[1]->vtable = 0;
      boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>::move_assign(
        v11,
        &f);
      ++v132[1];
    }
    if ( f.vtable )
    {
      if ( ((__int64)f.vtable & 1) == 0 )
      {
        v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)f.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v12 )
          v12(&f.functor, &f.functor, 2);
      }
      f.vtable = 0;
    }
    v8 = *((_DWORD *)a2 + 6);
  }
  if ( (v8 & 6) == 6 )
  {
    *(_OWORD *)&f.functor.obj_ptr = (unsigned __int64)boost::program_options::detail::cmdline::parse_short_option;
    f.functor.bound_memfunc_ptr.obj_ptr = a2;
    f.vtable = (boost::detail::function::vtable_base *)((char *)off_287D228 + 1);
    v13 = v132[1];
    if ( v132[1] >= v133 )
    {
      std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>::__push_back_slow_path<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>(
        (std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>> *)v132,
        &f);
    }
    else
    {
      v132[1]->vtable = 0;
      boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>::move_assign(
        v13,
        &f);
      ++v132[1];
    }
    if ( f.vtable )
    {
      if ( ((__int64)f.vtable & 1) == 0 )
      {
        v14 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)f.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v14 )
          v14(&f.functor, &f.functor, 2);
      }
      f.vtable = 0;
    }
    v8 = *((_DWORD *)a2 + 6);
  }
  if ( (v8 & 0xA) == 0xA )
  {
    *(_OWORD *)&f.functor.obj_ptr = (unsigned __int64)boost::program_options::detail::cmdline::parse_dos_option;
    f.functor.bound_memfunc_ptr.obj_ptr = a2;
    f.vtable = (boost::detail::function::vtable_base *)((char *)off_287D228 + 1);
    v15 = v132[1];
    if ( v132[1] >= v133 )
    {
      std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>::__push_back_slow_path<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>(
        (std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>> *)v132,
        &f);
    }
    else
    {
      v132[1]->vtable = 0;
      boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>::move_assign(
        v15,
        &f);
      ++v132[1];
    }
    if ( f.vtable )
    {
      if ( ((__int64)f.vtable & 1) == 0 )
      {
        v16 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)f.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v16 )
          v16(&f.functor, &f.functor, 2);
      }
      f.vtable = 0;
    }
  }
  v134 = &v132[1];
  *(_OWORD *)&f.functor.obj_ptr = (unsigned __int64)boost::program_options::detail::cmdline::parse_terminator;
  f.functor.bound_memfunc_ptr.obj_ptr = a2;
  f.vtable = (boost::detail::function::vtable_base *)((char *)off_287D228 + 1);
  v17 = v132[1];
  if ( v132[1] >= v133 )
  {
    std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>::__push_back_slow_path<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>>(
      (std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>> *)v132,
      &f);
  }
  else
  {
    v132[1]->vtable = 0;
    boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>::move_assign(
      v17,
      &f);
    ++v132[1];
  }
  if ( f.vtable )
  {
    if ( ((__int64)f.vtable & 1) == 0 )
    {
      v18 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)f.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v18 )
        v18(&f.functor, &f.functor, 2);
    }
    f.vtable = 0;
  }
  v19 = 0;
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v20 = *a2;
  v21 = a2[1];
  v22 = *a2 == v21;
  v141 = this;
  v135 = a2;
  if ( v22 )
  {
    v144 = (_QWORD *)((char *)this + 8);
    *(_OWORD *)ptr = 0;
    v143 = 0;
    v55 = 0;
  }
  else
  {
    v144 = (_QWORD *)((char *)this + 8);
    do
    {
      v23 = v132[0];
      if ( *v134 == v132[0] )
      {
LABEL_88:
        *(_OWORD *)&f.vtable = v19;
        *((_QWORD *)&f.functor.data + 1) = 0;
        *((_DWORD *)&f.functor.data + 4) = -1;
        v139 = v19;
        v138 = v19;
        v137 = v19;
        v140 = 0;
        std::vector<std::string>::__push_back_slow_path<std::string const&>((std::vector<std::string> *)&v137, *v2);
        v40 = *v2;
        if ( (_QWORD)v139 == *((_QWORD *)&v139 + 1) )
        {
          std::vector<std::string>::__push_back_slow_path<std::string const&>(
            (std::vector<std::string> *)((char *)&v138 + 8),
            v40);
        }
        else
        {
          std::string::basic_string(v139, v40);
          *(_QWORD *)&v139 = v139 + 24;
        }
        v41 = (boost::program_options::basic_option<char> *)*((_QWORD *)this + 1);
        if ( v41 == *((boost::program_options::basic_option<char> **)this + 2) )
        {
          std::vector<boost::program_options::basic_option<char>>::__push_back_slow_path<boost::program_options::basic_option<char> const&>(
            this,
            (const boost::program_options::basic_option<char> *)&f);
        }
        else
        {
          boost::program_options::basic_option<char>::basic_option(
            v41,
            (const boost::program_options::basic_option<char> *)&f);
          *v144 += 88LL;
        }
        v42 = *v2;
        v43 = v2[1];
        v44 = (const std::string *)((char *)v42 + 24);
        v19 = 0;
        if ( (const std::string *)((char *)v42 + 24) == v43 )
          goto LABEL_230;
        v45 = (const std::string *)((char *)v43 - 24);
        do
        {
          if ( (*(_BYTE *)v42 & 1) != 0 )
          {
            **((_BYTE **)v42 + 2) = 0;
            *((_QWORD *)v42 + 1) = 0;
          }
          else
          {
            *(_WORD *)v42 = 0;
          }
          std::string::reserve(v42, 0);
          *((_QWORD *)v42 + 2) = *((_QWORD *)v42 + 5);
          *(__m128i *)v42 = _mm_loadu_si128((const __m128i *)((char *)v42 + 24));
          v19 = 0;
          *(_OWORD *)((char *)v42 + 24) = 0;
          *((_QWORD *)v42 + 5) = 0;
          v42 = (const std::string *)((char *)v42 + 24);
        }
        while ( v45 != v42 );
        v44 = v135[1];
        if ( v44 != v42 )
        {
LABEL_230:
          do
          {
            v46 = (const std::string *)((char *)v44 - 24);
            if ( (*((_BYTE *)v44 - 24) & 1) != 0 )
            {
              operator delete(*((void **)v44 - 1));
              v19 = 0;
            }
            v44 = v46;
          }
          while ( v42 != v46 );
        }
        v135[1] = v42;
        v47 = *((_QWORD *)&v138 + 1);
        if ( *((_QWORD *)&v138 + 1) )
        {
          v48 = v139;
          if ( (_QWORD)v139 == *((_QWORD *)&v138 + 1) )
          {
            v50 = (void *)*((_QWORD *)&v138 + 1);
          }
          else
          {
            do
            {
              v49 = v48 - 24;
              if ( (*(_BYTE *)(v48 - 24) & 1) != 0 )
                operator delete(*(void **)(v48 - 8));
              v48 = v49;
            }
            while ( v47 != v49 );
            v50 = (void *)*((_QWORD *)&v138 + 1);
          }
          *(_QWORD *)&v139 = v47;
          operator delete(v50);
          v19 = 0;
        }
        v51 = v137;
        if ( (_QWORD)v137 )
        {
          v52 = *((_QWORD *)&v137 + 1);
          if ( *((_QWORD *)&v137 + 1) == (_QWORD)v137 )
          {
            v54 = (void *)v137;
          }
          else
          {
            do
            {
              v53 = v52 - 24;
              if ( (*(_BYTE *)(v52 - 24) & 1) != 0 )
                operator delete(*(void **)(v52 - 8));
              v52 = v53;
            }
            while ( v51 != v53 );
            v54 = (void *)v137;
          }
          *((_QWORD *)&v137 + 1) = v51;
          operator delete(v54);
          v19 = 0;
        }
        if ( ((__int64)f.vtable & 1) != 0 )
        {
          operator delete(*((void **)&f.functor.data + 1));
          v19 = 0;
        }
        v2 = v135;
      }
      else
      {
        vtable = v132[0]->vtable;
        if ( !v132[0]->vtable )
        {
LABEL_224:
          std::runtime_error::runtime_error((std::runtime_error *)ptr, "call to empty boost::function");
          ptr[0] = off_2875ED8;
          boost::throw_exception<boost::bad_function_call>((const boost::bad_function_call *)ptr);
        }
        v25 = v21 - v20;
        v26 = 0;
        while ( 1 )
        {
          (*(void (__fastcall **)(boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *, boost::detail::function::function_buffer *, const std::string **))(((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL) + 8))(
            &f,
            &v23[v26].functor,
            v2);
          v27 = f.vtable;
          obj_ptr = (char *)f.functor.obj_ptr;
          if ( f.vtable != f.functor.obj_ptr )
          {
            *(_OWORD *)ptr = 0;
            v143 = 0;
            if ( (void *)((boost::detail::function::vtable_base *)f.functor.obj_ptr - f.vtable) != &inputbuff.encodingTable[3] )
            {
              v29 = 1;
              v30 = 0;
              do
              {
                boost::program_options::detail::cmdline::finish_option(
                  (boost::program_options::detail::cmdline *)v2,
                  (boost::program_options::option *)&v27[11 * v30],
                  (std::vector<std::string> *)ptr,
                  (const std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>> *)v132);
                v30 = v29;
                v27 = f.vtable;
                obj_ptr = (char *)f.functor.obj_ptr;
                ++v29;
              }
              while ( 0x2E8BA2E8BA2E8BA3LL
                    * (((boost::detail::function::vtable_base *)f.functor.obj_ptr - f.vtable) >> 3)
                    - 1 > v30 );
            }
            boost::program_options::detail::cmdline::finish_option(
              (boost::program_options::detail::cmdline *)v2,
              (boost::program_options::option *)(obj_ptr - 88),
              (std::vector<std::string> *)v2,
              (const std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>> *)v132);
            v31 = f.vtable;
            if ( f.functor.obj_ptr != f.vtable )
            {
              v32 = 1;
              v33 = 0;
              do
              {
                v34 = (const boost::program_options::basic_option<char> *)&v31[11 * v33];
                v35 = (boost::program_options::basic_option<char> *)*((_QWORD *)this + 1);
                if ( v35 == *((boost::program_options::basic_option<char> **)this + 2) )
                {
                  std::vector<boost::program_options::basic_option<char>>::__push_back_slow_path<boost::program_options::basic_option<char> const&>(
                    this,
                    v34);
                }
                else
                {
                  boost::program_options::basic_option<char>::basic_option(v35, v34);
                  *v144 += 88LL;
                }
                v33 = v32;
                v31 = f.vtable;
                ++v32;
              }
              while ( 0x2E8BA2E8BA2E8BA3LL
                    * (((boost::detail::function::vtable_base *)f.functor.obj_ptr - f.vtable) >> 3) > v33 );
            }
            v36 = (void **)ptr[0];
            if ( ptr[0] )
            {
              v37 = (void **)ptr[1];
              if ( ptr[1] != ptr[0] )
              {
                do
                {
                  v38 = v37 - 3;
                  if ( (*(_BYTE *)(v37 - 3) & 1) != 0 )
                    operator delete(*(v37 - 1));
                  v37 = v38;
                }
                while ( v36 != v38 );
              }
              ptr[1] = v36;
              operator delete(v36);
              this = v141;
            }
          }
          v39 = 0xAAAAAAAAAAAAAAABLL * ((v2[1] - *v2) >> 3);
          std::__vector_base<boost::program_options::basic_option<char>>::~__vector_base((std::__vector_base<boost::program_options::basic_option<char>> *)&f);
          v2 = v135;
          v19 = 0;
          if ( v39 != -1431655765 * (unsigned int)(v25 >> 3) )
            break;
          v26 = (unsigned int)(v26 + 1);
          v23 = v132[0];
          if ( *v134 - v132[0] <= v26 )
            goto LABEL_88;
          v25 = v135[1] - *v135;
          vtable = v132[0][v26].vtable;
          if ( !vtable )
            goto LABEL_224;
        }
      }
      v20 = *v2;
      v21 = v2[1];
    }
    while ( *v2 != v21 );
    v55 = *(char **)this;
    v56 = (char *)*((_QWORD *)this + 1);
    *(_OWORD *)ptr = 0;
    v143 = 0;
    if ( v56 != v55 )
    {
      v57 = 0;
      v58 = 0;
      v59 = 0;
      v60 = 0;
      while ( 1 )
      {
        v61 = (const boost::program_options::basic_option<char> *)&v55[88 * v59];
        if ( v58 == v57 )
        {
          std::vector<boost::program_options::basic_option<char>>::__push_back_slow_path<boost::program_options::basic_option<char> const&>(
            (std::vector<boost::program_options::basic_option<char>> *)ptr,
            v61);
          v62 = (char *)ptr[1];
        }
        else
        {
          boost::program_options::basic_option<char>::basic_option(v58, v61);
          v62 = (char *)ptr[1] + 88;
          ptr[1] = (char *)ptr[1] + 88;
        }
        v63 = (unsigned __int8)*(v62 - 88);
        if ( (v63 & 1) != 0 )
        {
          if ( !*((_QWORD *)v62 - 10) )
            goto LABEL_161;
        }
        else if ( !(v63 >> 1) )
        {
          goto LABEL_161;
        }
        v134 = (boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> **)v62;
        nothrow = boost::program_options::options_description::find_nothrow(
                    v2[4],
                    (const std::string *)(v62 - 88),
                    ((_DWORD)v2[3] & 0x200) != 0,
                    ((_DWORD)v2[3] & 0x400) != 0,
                    ((_DWORD)v2[3] & 0x800) != 0);
        v65 = nothrow;
        if ( !nothrow )
          goto LABEL_161;
        v66 = nothrow;
        v67 = boost::program_options::option_description::semantic(nothrow);
        v68 = (*((__int64 (__fastcall **)(boost::detail::function::vtable_base *, const boost::program_options::option_description *, boost::detail::sp_counted_base *))f.vtable->manager
               + 1))(
                f.vtable,
                v66,
                v67.pn.pi_);
        v69 = (volatile signed __int32 *)f.functor.obj_ptr;
        if ( f.functor.obj_ptr )
        {
          if ( !_InterlockedSub((volatile signed __int32 *)f.functor.obj_ptr + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v69 + 16LL))(v69);
            if ( !_InterlockedSub(v69 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v69 + 24LL))(v69);
          }
        }
        v70 = v65;
        v71 = boost::program_options::option_description::semantic(v65);
        v73 = (*((__int64 (__fastcall **)(boost::detail::function::vtable_base *, const boost::program_options::option_description *, boost::detail::sp_counted_base *))f.vtable->manager
               + 2))(
                f.vtable,
                v65,
                v71.pn.pi_);
        v74 = (volatile signed __int32 *)f.functor.obj_ptr;
        v75 = v134;
        if ( f.functor.obj_ptr )
        {
          if ( !_InterlockedSub((volatile signed __int32 *)f.functor.obj_ptr + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *, const boost::program_options::option_description *, __int64, boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> **))(*(_QWORD *)v74 + 16LL))(
              v74,
              v70,
              v72,
              v75);
            v75 = v134;
            if ( !_InterlockedSub(v74 + 3, 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *, const boost::program_options::option_description *, __int64, boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> **))(*(_QWORD *)v74 + 24LL))(
                v74,
                v70,
                v76,
                v75);
              v75 = v134;
            }
          }
        }
        if ( v68 >= v73 )
        {
LABEL_161:
          v85 = v60;
          goto LABEL_162;
        }
        v77 = 0xAAAAAAAAAAAAAAABLL * (((char *)*(v75 - 6) - (char *)*(v75 - 7)) >> 3);
        v78 = v60;
        if ( v77 < v73 && v73 != (_DWORD)v77 )
        {
          v79 = (std::vector<std::string> *)(v75 - 7);
          v146 = (std::vector<std::string> *)(v75 - 4);
          v80 = v77 - v73;
          while ( 1 )
          {
            v81 = (unsigned int)(v78 + 1);
            v82 = *(char **)v141;
            if ( 0x2E8BA2E8BA2E8BA3LL * ((__int64)(*((_QWORD *)v141 + 1) - *(_QWORD *)v141) >> 3) <= v81 )
              break;
            v83 = 88 * v81;
            v84 = (unsigned __int8)v82[88 * v81];
            if ( (v84 & 1) != 0 )
            {
              if ( *(_QWORD *)&v82[v83 + 8] )
                break;
            }
            else if ( v84 >> 1 )
            {
              break;
            }
            v85 = v78;
            if ( *(_DWORD *)&v82[v83 + 24] != 0x7FFFFFFF )
            {
              v86 = *(const std::string **)&v82[v83 + 32];
              v87 = *(v75 - 6);
              if ( v87 == *(v75 - 5) )
              {
                std::vector<std::string>::__push_back_slow_path<std::string const&>(v79, v86);
                v88 = v134;
              }
              else
              {
                std::string::basic_string(v87, v86);
                v88 = v134;
                *(v134 - 6) = (boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *)((char *)*(v134 - 6) + 24);
              }
              v89 = *(const std::string **)&v82[v83 + 56];
              v90 = *(v88 - 3);
              if ( v90 == *(v88 - 2) )
              {
                std::vector<std::string>::__push_back_slow_path<std::string const&>(v146, v89);
                v75 = v134;
              }
              else
              {
                std::string::basic_string(v90, v89);
                v75 = v134;
                *(v134 - 3) = (boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *)((char *)*(v134 - 3) + 24);
              }
              v78 = v81;
              v85 = v81;
              if ( ++v80 )
                continue;
            }
            goto LABEL_162;
          }
        }
        v85 = v78;
LABEL_162:
        v59 = (unsigned int)(v85 + 1);
        v55 = *(char **)v141;
        v91 = (void *)*((_QWORD *)v141 + 1);
        if ( 0x2E8BA2E8BA2E8BA3LL * (((__int64)v91 - *(_QWORD *)v141) >> 3) <= v59 )
        {
          v92 = (char *)ptr[0];
          v93 = ptr[1];
          v94 = v143;
          v2 = v135;
          goto LABEL_167;
        }
        v58 = (boost::program_options::basic_option<char> *)ptr[1];
        v57 = v143;
        v60 = v59;
        v2 = v135;
      }
    }
  }
  v94 = 0;
  v93 = 0;
  v92 = 0;
  v91 = v55;
LABEL_167:
  v95 = v141;
  *(_QWORD *)v141 = v92;
  ptr[0] = v55;
  *((_QWORD *)v95 + 1) = v93;
  ptr[1] = v91;
  v96 = (boost::program_options::basic_option<char> *)*((_QWORD *)v95 + 2);
  *((_QWORD *)v95 + 2) = v94;
  v143 = v96;
  if ( v93 != v92 )
  {
    v97 = 0;
    v98 = 1;
    v99 = 0;
    do
    {
      v100 = 88 * v97;
      v101 = (unsigned __int8)v92[v100];
      if ( (v101 & 1) != 0 )
      {
        if ( !*(_QWORD *)&v92[v100 + 8] )
LABEL_173:
          *(_DWORD *)&v92[v100 + 24] = v99++;
      }
      else if ( !(v101 >> 1) )
      {
        goto LABEL_173;
      }
      v97 = v98++;
    }
    while ( 0x2E8BA2E8BA2E8BA3LL * ((v93 - v92) >> 3) > v97 );
  }
  if ( v2[5] )
  {
    if ( v93 == v92 )
      goto LABEL_212;
    v102 = 0;
    v103 = 1;
    v104 = 0;
    do
    {
      v105 = 88 * v102;
      if ( *(_DWORD *)&v92[88 * v102 + 24] != -1 )
      {
        if ( v104 >= boost::program_options::positional_options_description::max_total_count(v135[5]) )
        {
          v131 = (__m128i *)operator new(0x50u);
          *((_QWORD *)&f.functor.data + 1) = v131;
          *(_OWORD *)&f.vtable = xmmword_3E6530;
          strcpy(v131[1].m128i_i8, "nal options have been specified on the command line");
          *v131 = _mm_loadu_si128((const __m128i *)&xmmword_3EBFEA);
          std::logic_error::logic_error(v145, &f);
          v145[0] = off_287CEF8;
          if ( ((__int64)f.vtable & 1) != 0 )
            operator delete(*((void **)&f.functor.data + 1));
          v145[0] = off_287CF20;
          boost::throw_exception<boost::program_options::too_many_positional_options_error>((const boost::program_options::too_many_positional_options_error *)v145);
        }
        v106 = (unsigned int)boost::program_options::positional_options_description::name_for_position(v135[5], v104);
        std::string::operator=((soap *)&v92[v105], v106, v107, v108, v109, v110);
        ++v104;
        v93 = (_BYTE *)*v144;
        v92 = *(char **)v141;
      }
      v102 = v103++;
    }
    while ( 0x2E8BA2E8BA2E8BA3LL * ((v93 - v92) >> 3) > v102 );
  }
  v111 = v93 - v92;
  v112 = v135;
  if ( v111 )
  {
    v113 = v111 >> 3;
    v114 = (unsigned __int8)*v92;
    if ( (v114 & 1) != 0 )
      v115 = *((_QWORD *)v92 + 1);
    else
      v115 = v114 >> 1;
    v116 = 0x2E8BA2E8BA2E8BA3LL * v113;
    v117 = 10;
    if ( v115 > 2 )
    {
LABEL_196:
      v92[81] = (*((_DWORD *)v112 + 6) >> v117) & 1;
      if ( v116 >= 2 )
      {
        v118 = 2;
        v119 = 1;
        while ( 1 )
        {
          v120 = 88 * v119;
          v121 = (unsigned __int8)v92[88 * v119];
          if ( (v121 & 1) != 0 )
            v122 = *(_QWORD *)&v92[v120 + 8];
          else
            v122 = v121 >> 1;
          v123 = 10;
          if ( v122 > 2 )
            goto LABEL_211;
          if ( (v121 & 1) != 0 )
          {
            if ( *(_QWORD *)&v92[v120 + 8] < 2u )
              goto LABEL_210;
          }
          else
          {
            v112 = v135;
            if ( (unsigned __int8)((unsigned __int8)v121 >> 1) < 2uLL )
              goto LABEL_210;
          }
          if ( (v121 & 1) == 0 )
            break;
          if ( **(_BYTE **)&v92[v120 + 16] == 45 )
            goto LABEL_210;
LABEL_211:
          v92[v120 + 81] = (*((_DWORD *)v112 + 6) >> v123) & 1;
          v119 = v118++;
          if ( v116 <= v119 )
            goto LABEL_212;
        }
        if ( v92[v120 + 1] != 45 )
          goto LABEL_211;
LABEL_210:
        v123 = 11;
        goto LABEL_211;
      }
      goto LABEL_212;
    }
    if ( (v114 & 1) != 0 )
    {
      if ( *((_QWORD *)v92 + 1) < 2u )
        goto LABEL_195;
    }
    else
    {
      v112 = v135;
      if ( (unsigned __int8)((unsigned __int8)v114 >> 1) < 2uLL )
        goto LABEL_195;
    }
    if ( (v114 & 1) != 0 )
    {
      if ( **((_BYTE **)v92 + 2) != 45 )
        goto LABEL_196;
    }
    else if ( v92[1] != 45 )
    {
      goto LABEL_196;
    }
LABEL_195:
    v117 = 11;
    goto LABEL_196;
  }
LABEL_212:
  std::__vector_base<boost::program_options::basic_option<char>>::~__vector_base((std::__vector_base<boost::program_options::basic_option<char>> *)ptr);
  v124 = v132[0];
  v125 = v141;
  if ( v132[0] )
  {
    v126 = v132[1];
    if ( v132[1] == v132[0] )
    {
      v129 = v132[0];
    }
    else
    {
      do
      {
        v127 = v126[-1].vtable;
        if ( v127 )
        {
          if ( ((unsigned __int8)v127 & 1) == 0 )
          {
            v128 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v127 & 0xFFFFFFFFFFFFFFFELL);
            if ( v128 )
              v128(&v126[-1].functor, &v126[-1].functor, 2);
          }
          v126[-1].vtable = 0;
        }
        --v126;
      }
      while ( v124 != v126 );
      v129 = v132[0];
    }
    v132[1] = v124;
    operator delete(v129);
  }
  return v125;
}


// Address: 0xe559c0 | Name: _ZN5boost15program_options6detail7cmdline24handle_additional_parserERNSt3__16vectorINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS8_ISA_EEEE
std::vector<boost::program_options::basic_option<char>> *__fastcall boost::program_options::detail::cmdline::handle_additional_parser(
        std::vector<boost::program_options::basic_option<char>> *this,
        __int64 a2,
        _QWORD *a3)
{
  __int64 v4; // rax
  int v6; // edx
  void *v7; // rcx
  size_t v8; // r8
  const void *v9; // r9
  boost::program_options::basic_option<char> *v10; // rdi
  __int64 v11; // rbx
  __int64 v12; // r12
  __int64 v13; // rax
  __int64 v14; // r12
  __int64 v15; // r12
  void **v16; // r15
  void **v17; // rax
  void **v18; // rbx
  void *v19; // rdi
  void **v20; // r15
  void **v21; // rax
  void **v22; // rbx
  void *v23; // rdi
  __int128 v25; // [rsp+0h] [rbp-A8h] BYREF
  void *v26; // [rsp+10h] [rbp-98h]
  int v27; // [rsp+18h] [rbp-90h]
  void *v28[2]; // [rsp+20h] [rbp-88h] BYREF
  void *ptr[2]; // [rsp+30h] [rbp-78h]
  __int128 v30; // [rsp+40h] [rbp-68h]
  __int16 v31; // [rsp+50h] [rbp-58h]
  char v32[8]; // [rsp+58h] [rbp-50h] BYREF
  __int64 v33; // [rsp+60h] [rbp-48h]
  void *v34; // [rsp+68h] [rbp-40h]
  char v35[8]; // [rsp+70h] [rbp-38h] BYREF
  __int64 v36; // [rsp+78h] [rbp-30h]
  void *v37; // [rsp+80h] [rbp-28h]

  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v4 = *(_QWORD *)(a2 + 48);
  if ( !v4 )
  {
    std::runtime_error::runtime_error((std::runtime_error *)&v25, "call to empty boost::function");
    *(_QWORD *)&v25 = off_2875ED8;
    boost::throw_exception<boost::bad_function_call>((const boost::bad_function_call *)&v25);
  }
  (*(void (__fastcall **)(char *, __int64, _QWORD))((v4 & 0xFFFFFFFFFFFFFFFELL) + 8))(v32, a2 + 56, *a3);
  if ( (v32[0] & 1) != 0 )
  {
    if ( !v33 )
      goto LABEL_44;
  }
  else if ( !((unsigned __int64)(unsigned __int8)v32[0] >> 1) )
  {
    goto LABEL_44;
  }
  v25 = 0;
  v26 = 0;
  v27 = -1;
  v30 = 0;
  *(_OWORD *)ptr = 0;
  *(_OWORD *)v28 = 0;
  v31 = 0;
  std::string::operator=((soap *)&v25, (int)v32, v6, v7, v8, v9);
  if ( (v35[0] & 1) == 0 )
  {
    if ( !((unsigned __int64)(unsigned __int8)v35[0] >> 1) )
      goto LABEL_13;
LABEL_10:
    if ( v28[1] == ptr[0] )
    {
      std::vector<std::string>::__push_back_slow_path<std::string const&>(
        (std::vector<std::string> *)v28,
        (const std::string *)v35);
    }
    else
    {
      std::string::basic_string(v28[1], v35);
      v28[1] = (char *)v28[1] + 24;
    }
    goto LABEL_13;
  }
  if ( v36 )
    goto LABEL_10;
LABEL_13:
  v10 = (boost::program_options::basic_option<char> *)*((_QWORD *)this + 1);
  if ( v10 == *((boost::program_options::basic_option<char> **)this + 2) )
  {
    std::vector<boost::program_options::basic_option<char>>::__push_back_slow_path<boost::program_options::basic_option<char> const&>(
      this,
      (const boost::program_options::basic_option<char> *)&v25);
  }
  else
  {
    boost::program_options::basic_option<char>::basic_option(
      v10,
      (const boost::program_options::basic_option<char> *)&v25);
    *((_QWORD *)this + 1) += 88LL;
  }
  v11 = *a3;
  v12 = a3[1];
  v13 = *a3 + 24LL;
  if ( v13 == v12 )
    goto LABEL_52;
  v14 = v12 - 24;
  do
  {
    if ( (*(_BYTE *)v11 & 1) != 0 )
    {
      **(_BYTE **)(v11 + 16) = 0;
      *(_QWORD *)(v11 + 8) = 0;
    }
    else
    {
      *(_WORD *)v11 = 0;
    }
    std::string::reserve(v11, 0);
    *(_QWORD *)(v11 + 16) = *(_QWORD *)(v11 + 40);
    *(_OWORD *)v11 = *(_OWORD *)(v11 + 24);
    *(_OWORD *)(v11 + 24) = 0;
    *(_QWORD *)(v11 + 40) = 0;
    v11 += 24;
  }
  while ( v14 != v11 );
  v13 = a3[1];
  if ( v13 != v11 )
  {
LABEL_52:
    do
    {
      v15 = v13 - 24;
      if ( (*(_BYTE *)(v13 - 24) & 1) != 0 )
        operator delete(*(void **)(v13 - 8));
      v13 = v15;
    }
    while ( v11 != v15 );
  }
  a3[1] = v11;
  v16 = (void **)ptr[1];
  if ( ptr[1] )
  {
    v17 = (void **)v30;
    if ( (void *)v30 == ptr[1] )
    {
      v19 = ptr[1];
    }
    else
    {
      do
      {
        v18 = v17 - 3;
        if ( (*(_BYTE *)(v17 - 3) & 1) != 0 )
          operator delete(*(v17 - 1));
        v17 = v18;
      }
      while ( v16 != v18 );
      v19 = ptr[1];
    }
    *(_QWORD *)&v30 = v16;
    operator delete(v19);
  }
  v20 = (void **)v28[0];
  if ( v28[0] )
  {
    v21 = (void **)v28[1];
    if ( v28[1] == v28[0] )
    {
      v23 = v28[0];
    }
    else
    {
      do
      {
        v22 = v21 - 3;
        if ( (*(_BYTE *)(v21 - 3) & 1) != 0 )
          operator delete(*(v21 - 1));
        v21 = v22;
      }
      while ( v20 != v22 );
      v23 = v28[0];
    }
    v28[1] = v20;
    operator delete(v23);
  }
  if ( (v25 & 1) != 0 )
    operator delete(v26);
LABEL_44:
  if ( (v35[0] & 1) != 0 )
    operator delete(v37);
  if ( (v32[0] & 1) != 0 )
    operator delete(v34);
  return this;
}


// Address: 0xe55d70 | Name: _ZN5boost15program_options6detail7cmdline17parse_long_optionERNSt3__16vectorINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS8_ISA_EEEE
std::vector<boost::program_options::basic_option<char>> *__fastcall boost::program_options::detail::cmdline::parse_long_option(
        std::vector<boost::program_options::basic_option<char>> *this,
        __int64 a2,
        unsigned __int8 **a3)
{
  __int64 v5; // rbx
  unsigned __int64 v6; // rax
  __int64 v7; // rax
  __int64 v8; // r13
  int v9; // edx
  void *v10; // rcx
  size_t v11; // r8
  const void *v12; // r9
  int v13; // eax
  int v14; // r8d
  boost::program_options::basic_option<char> *v15; // rdi
  __int64 v16; // rbx
  unsigned __int8 *v17; // r12
  __int64 v18; // rax
  unsigned __int8 *v19; // r12
  __int64 v20; // r12
  void **v21; // r15
  void **v22; // rax
  void **v23; // rbx
  void *v24; // rdi
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer left; // r15
  unsigned __int64 value; // rax
  std::__tree_node_base<void *> *v27; // rbx
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v28; // rdi
  __int128 v30; // [rsp+0h] [rbp-E8h] BYREF
  void *v31; // [rsp+10h] [rbp-D8h]
  __int128 v32; // [rsp+20h] [rbp-C8h] BYREF
  void *v33; // [rsp+30h] [rbp-B8h]
  __int128 v34; // [rsp+40h] [rbp-A8h] BYREF
  void *v35; // [rsp+50h] [rbp-98h]
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > v36; // [rsp+58h] [rbp-90h] BYREF
  void *ptr[2]; // [rsp+70h] [rbp-78h] BYREF
  __int128 v38; // [rsp+80h] [rbp-68h]
  __int16 v39; // [rsp+90h] [rbp-58h]

  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v5 = (__int64)*a3;
  v6 = **a3;
  if ( (v6 & 1) != 0 )
  {
    if ( *(_QWORD *)(v5 + 8) < 3u )
      return this;
  }
  else if ( v6 >> 1 < 3 )
  {
    return this;
  }
  if ( (v6 & 1) != 0 )
  {
    if ( **(_BYTE **)(v5 + 16) != 45 )
      return this;
  }
  else if ( *(_BYTE *)(v5 + 1) != 45 )
  {
    return this;
  }
  if ( (v6 & 1) != 0 )
  {
    if ( *(_BYTE *)(*(_QWORD *)(v5 + 16) + 1LL) != 45 )
      return this;
  }
  else if ( *(_BYTE *)(v5 + 2) != 45 )
  {
    return this;
  }
  v30 = 0;
  v31 = 0;
  v32 = 0;
  v33 = 0;
  v7 = std::string::find(v5, 61, 0);
  if ( v7 == -1 )
  {
    std::string::basic_string(&v34, v5, 2, -1, v5);
    if ( (v30 & 1) != 0 )
    {
      *(_BYTE *)v31 = 0;
      *((_QWORD *)&v30 + 1) = 0;
    }
    else
    {
      LOWORD(v30) = 0;
    }
    std::string::reserve(&v30, 0);
    v31 = v35;
    v30 = v34;
  }
  else
  {
    v8 = v7;
    std::string::basic_string(&v34, v5, 2, v7 - 2, v5);
    if ( (v30 & 1) != 0 )
    {
      *(_BYTE *)v31 = 0;
      *((_QWORD *)&v30 + 1) = 0;
    }
    else
    {
      LOWORD(v30) = 0;
    }
    std::string::reserve(&v30, 0);
    v31 = v35;
    v30 = v34;
    std::string::basic_string(&v34, v5, v8 + 1, -1, v5);
    if ( (v32 & 1) != 0 )
    {
      *(_BYTE *)v33 = 0;
      *((_QWORD *)&v32 + 1) = 0;
    }
    else
    {
      LOWORD(v32) = 0;
    }
    std::string::reserve(&v32, 0);
    v32 = v34;
    v33 = v35;
    if ( (v34 & 1) != 0 )
    {
      if ( !*((_QWORD *)&v32 + 1) )
        goto LABEL_26;
    }
    else if ( !((unsigned __int64)(unsigned __int8)v34 >> 1) )
    {
LABEL_26:
      v13 = *(_DWORD *)(a2 + 24);
      v14 = 1;
      if ( (v13 & 1) == 0 )
      {
        v14 = 4096;
        if ( (v13 & 0x1000) == 0 )
        {
          v14 = 4;
          if ( (*(_DWORD *)(a2 + 24) & 6) != 6 )
            v14 = 8 * ((*(_DWORD *)(a2 + 24) & 0xA) == 10);
        }
      }
      boost::program_options::invalid_command_line_syntax::invalid_command_line_syntax(
        (boost::program_options::invalid_command_line_syntax *)&v34,
        boost::program_options::invalid_syntax::kind_t::empty_adjacent_parameter,
        (const std::string *)&v30,
        (const std::string *)&v30,
        v14);
      boost::throw_exception<boost::program_options::invalid_command_line_syntax>((const boost::program_options::invalid_command_line_syntax *)&v34);
    }
  }
  v34 = 0;
  v35 = 0;
  LODWORD(v36.__begin_node_) = -1;
  v38 = 0;
  *(_OWORD *)ptr = 0;
  *(_OWORD *)&v36.__pair1_.__value_.__left_ = 0;
  v39 = 0;
  std::string::operator=((soap *)&v34, (int)&v30, v9, v10, v11, v12);
  if ( (v32 & 1) != 0 )
  {
    if ( !*((_QWORD *)&v32 + 1) )
      goto LABEL_40;
  }
  else if ( !((unsigned __int64)(unsigned __int8)v32 >> 1) )
  {
    goto LABEL_40;
  }
  if ( (void *)v36.__pair3_.__value_ == ptr[0] )
  {
    std::vector<std::string>::__push_back_slow_path<std::string const&>(
      (std::vector<std::string> *)&v36.__pair1_,
      (const std::string *)&v32);
  }
  else
  {
    std::string::basic_string(v36.__pair3_.__value_, &v32);
    v36.__pair3_.__value_ += 24LL;
  }
LABEL_40:
  if ( (_QWORD)v38 == *((_QWORD *)&v38 + 1) )
  {
    std::vector<std::string>::__push_back_slow_path<std::string const&>(
      (std::vector<std::string> *)&ptr[1],
      (const std::string *)v5);
  }
  else
  {
    std::string::basic_string(v38, v5);
    *(_QWORD *)&v38 = v38 + 24;
  }
  v15 = (boost::program_options::basic_option<char> *)*((_QWORD *)this + 1);
  if ( v15 == *((boost::program_options::basic_option<char> **)this + 2) )
  {
    std::vector<boost::program_options::basic_option<char>>::__push_back_slow_path<boost::program_options::basic_option<char> const&>(
      this,
      (const boost::program_options::basic_option<char> *)&v34);
  }
  else
  {
    boost::program_options::basic_option<char>::basic_option(
      v15,
      (const boost::program_options::basic_option<char> *)&v34);
    *((_QWORD *)this + 1) += 88LL;
  }
  v16 = (__int64)*a3;
  v17 = a3[1];
  v18 = (__int64)(*a3 + 24);
  if ( (unsigned __int8 *)v18 == v17 )
    goto LABEL_82;
  v19 = v17 - 24;
  do
  {
    if ( (*(_BYTE *)v16 & 1) != 0 )
    {
      **(_BYTE **)(v16 + 16) = 0;
      *(_QWORD *)(v16 + 8) = 0;
    }
    else
    {
      *(_WORD *)v16 = 0;
    }
    std::string::reserve(v16, 0);
    *(_QWORD *)(v16 + 16) = *(_QWORD *)(v16 + 40);
    *(_OWORD *)v16 = *(_OWORD *)(v16 + 24);
    *(_OWORD *)(v16 + 24) = 0;
    *(_QWORD *)(v16 + 40) = 0;
    v16 += 24;
  }
  while ( v19 != (unsigned __int8 *)v16 );
  v18 = (__int64)a3[1];
  if ( v18 != v16 )
  {
LABEL_82:
    do
    {
      v20 = v18 - 24;
      if ( (*(_BYTE *)(v18 - 24) & 1) != 0 )
        operator delete(*(void **)(v18 - 8));
      v18 = v20;
    }
    while ( v16 != v20 );
  }
  a3[1] = (unsigned __int8 *)v16;
  v21 = (void **)ptr[1];
  if ( ptr[1] )
  {
    v22 = (void **)v38;
    if ( (void *)v38 == ptr[1] )
    {
      v24 = ptr[1];
    }
    else
    {
      do
      {
        v23 = v22 - 3;
        if ( (*(_BYTE *)(v22 - 3) & 1) != 0 )
          operator delete(*(v22 - 1));
        v22 = v23;
      }
      while ( v21 != v23 );
      v24 = ptr[1];
    }
    *(_QWORD *)&v38 = v21;
    operator delete(v24);
  }
  left = v36.__pair1_.__value_.__left_;
  if ( v36.__pair1_.__value_.__left_ )
  {
    value = v36.__pair3_.__value_;
    if ( (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v36.__pair3_.__value_ == v36.__pair1_.__value_.__left_ )
    {
      v28 = v36.__pair1_.__value_.__left_;
    }
    else
    {
      do
      {
        v27 = (std::__tree_node_base<void *> *)(value - 24);
        if ( (*(_BYTE *)(value - 24) & 1) != 0 )
          operator delete(*(void **)(value - 8));
        value = (unsigned __int64)v27;
      }
      while ( left != v27 );
      v28 = v36.__pair1_.__value_.__left_;
    }
    v36.__pair3_.__value_ = (unsigned __int64)left;
    operator delete(v28);
  }
  if ( (v34 & 1) == 0 )
  {
    if ( (v32 & 1) == 0 )
      goto LABEL_74;
LABEL_78:
    operator delete(v33);
    if ( (v30 & 1) == 0 )
      return this;
    goto LABEL_75;
  }
  operator delete(v35);
  if ( (v32 & 1) != 0 )
    goto LABEL_78;
LABEL_74:
  if ( (v30 & 1) != 0 )
LABEL_75:
    operator delete(v31);
  return this;
}


// Address: 0xe563e0 | Name: _ZN5boost15program_options6detail7cmdline27parse_disguised_long_optionERNSt3__16vectorINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS8_ISA_EEEE
std::vector<boost::program_options::basic_option<char>> *__fastcall boost::program_options::detail::cmdline::parse_disguised_long_option(
        std::vector<boost::program_options::basic_option<char>> *this,
        __int64 a2,
        unsigned __int8 **a3)
{
  unsigned __int8 *v4; // r15
  unsigned __int64 v5; // rax
  const boost::program_options::options_description *v6; // r13
  __int64 v7; // rcx
  const boost::program_options::option_description *nothrow; // r13
  unsigned __int8 *v9; // rax
  unsigned __int8 v10; // cl
  unsigned __int8 *v11; // rax
  _BYTE v13[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]

  v4 = *a3;
  v5 = **a3;
  if ( (v5 & 1) != 0 )
  {
    if ( *((_QWORD *)v4 + 1) < 2u )
      goto LABEL_25;
  }
  else if ( v5 >> 1 < 2 )
  {
    goto LABEL_25;
  }
  if ( (v5 & 1) != 0 )
  {
    if ( **((_BYTE **)v4 + 2) != 45 )
      goto LABEL_13;
  }
  else if ( v4[1] != 45 )
  {
    goto LABEL_13;
  }
  if ( (v5 & 1) != 0 )
  {
    if ( *(_BYTE *)(*((_QWORD *)v4 + 2) + 1LL) != 45 )
      goto LABEL_18;
LABEL_13:
    if ( (*(_BYTE *)(a2 + 24) & 8) == 0 )
      goto LABEL_25;
    if ( (v5 & 1) != 0 )
    {
      if ( **((_BYTE **)v4 + 2) != 47 )
        goto LABEL_25;
    }
    else if ( v4[1] != 47 )
    {
      goto LABEL_25;
    }
    goto LABEL_18;
  }
  if ( v4[2] == 45 )
    goto LABEL_13;
LABEL_18:
  v6 = *(const boost::program_options::options_description **)(a2 + 32);
  v7 = std::string::find(v4, 61, 0) - 1;
  std::string::basic_string(v13, v4, 1, v7, v4);
  nothrow = boost::program_options::options_description::find_nothrow(
              v6,
              (const std::string *)v13,
              (*(_DWORD *)(a2 + 24) & 0x200) != 0,
              (*(_DWORD *)(a2 + 24) & 0x400) != 0,
              (*(_DWORD *)(a2 + 24) & 0x800) != 0);
  if ( (v13[0] & 1) != 0 )
    operator delete(ptr);
  if ( nothrow )
  {
    std::string::insert(*a3, 0, "-");
    v9 = *a3;
    v10 = **a3;
    if ( (v10 & 1) != 0 )
    {
      if ( *(_BYTE *)(*((_QWORD *)v9 + 2) + 1LL) == 47 )
        goto LABEL_23;
    }
    else if ( v9[2] == 47 )
    {
LABEL_23:
      if ( (v10 & 1) != 0 )
        v11 = (unsigned __int8 *)*((_QWORD *)v9 + 2);
      else
        v11 = v9 + 1;
      v11[1] = 45;
    }
    boost::program_options::detail::cmdline::parse_long_option(this, a2, a3);
    return this;
  }
LABEL_25:
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  return this;
}


// Address: 0xe56610 | Name: _ZN5boost15program_options6detail7cmdline18parse_short_optionERNSt3__16vectorINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS8_ISA_EEEE
std::vector<boost::program_options::basic_option<char>> *__fastcall boost::program_options::detail::cmdline::parse_short_option(
        std::vector<boost::program_options::basic_option<char>> *this,
        __int64 a2,
        unsigned __int8 **a3)
{
  __int64 v5; // r12
  unsigned __int64 v6; // rax
  const boost::program_options::option_description *nothrow; // rax
  int v9; // edx
  void *v10; // rcx
  size_t v11; // r8
  const void *v12; // r9
  const boost::program_options::option_description *v13; // rsi
  boost::shared_ptr<const boost::program_options::value_semantic>_0 v14; // rax
  bool v15; // bl
  unsigned __int64 v16; // rax
  volatile signed __int32 *v17; // rbp
  boost::program_options::basic_option<char> *v18; // rdi
  char *v19; // rcx
  char v20; // bl
  void *v21; // rbp
  __int64 v22; // r13
  unsigned __int8 *v23; // rbp
  __int64 v24; // rax
  unsigned __int8 *v25; // rbp
  __int64 v26; // rbx
  int v27; // r13d
  __int64 v28; // rbx
  __int64 v29; // rax
  __int64 v30; // rbp
  void *v31; // rdi
  void **v32; // rbx
  void **v33; // rax
  void **v34; // rbp
  void *v35; // rdi
  boost::program_options::basic_option<char> *v36; // rdi
  __int64 v37; // rbx
  unsigned __int8 *v38; // rbp
  __int64 v39; // rax
  unsigned __int8 *v40; // rbp
  __int64 v41; // rbp
  __int64 v42; // rbx
  __int64 v43; // rax
  __int64 v44; // rbp
  void *v45; // rdi
  void **v46; // rbx
  void **v47; // rax
  void **v48; // rbp
  void *v49; // rdi
  __int128 v51; // [rsp+10h] [rbp-F8h] BYREF
  void *v52; // [rsp+20h] [rbp-E8h]
  int v53; // [rsp+28h] [rbp-E0h]
  void *v54[2]; // [rsp+30h] [rbp-D8h] BYREF
  __int128 v55; // [rsp+40h] [rbp-C8h] BYREF
  __int128 v56; // [rsp+50h] [rbp-B8h]
  __int16 v57; // [rsp+60h] [rbp-A8h]
  __int128 v58; // [rsp+70h] [rbp-98h] BYREF
  void *v59; // [rsp+80h] [rbp-88h]
  unsigned __int8 v60; // [rsp+88h] [rbp-80h] BYREF
  char v61; // [rsp+89h] [rbp-7Fh] BYREF
  unsigned __int64 v62; // [rsp+90h] [rbp-78h]
  void *v63; // [rsp+98h] [rbp-70h]
  __int128 v64; // [rsp+A0h] [rbp-68h] BYREF
  void *ptr; // [rsp+B0h] [rbp-58h]
  _QWORD v66[9]; // [rsp+C0h] [rbp-48h]

  v66[2] = __readfsqword(0x28u);
  v5 = (__int64)*a3;
  v6 = **a3;
  if ( (v6 & 1) != 0 )
  {
    if ( *(_QWORD *)(v5 + 8) < 2u )
      goto LABEL_13;
  }
  else if ( v6 >> 1 < 2 )
  {
    goto LABEL_13;
  }
  if ( (v6 & 1) != 0 )
  {
    if ( **(_BYTE **)(v5 + 16) != 45 )
      goto LABEL_13;
  }
  else if ( *(_BYTE *)(v5 + 1) != 45 )
  {
    goto LABEL_13;
  }
  if ( (v6 & 1) == 0 )
  {
    if ( *(_BYTE *)(v5 + 2) != 45 )
      goto LABEL_15;
LABEL_13:
    *(_OWORD *)this = 0;
    *((_QWORD *)this + 2) = 0;
    return this;
  }
  if ( *(_BYTE *)(*(_QWORD *)(v5 + 16) + 1LL) == 45 )
    goto LABEL_13;
LABEL_15:
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  std::string::basic_string(&v58, v5, 0, 2, v5);
  std::string::basic_string(&v60, v5, 2, -1, v5);
  while ( 1 )
  {
    nothrow = boost::program_options::options_description::find_nothrow(
                *(const boost::program_options::options_description **)(a2 + 32),
                (const std::string *)&v58,
                0,
                0,
                (*(_DWORD *)(a2 + 24) & 0x800) != 0);
    if ( !nothrow || (*(_BYTE *)(a2 + 25) & 1) == 0 )
      break;
    v13 = nothrow;
    v14 = boost::program_options::option_description::semantic(nothrow);
    if ( (*(unsigned int (__fastcall **)(_QWORD, const boost::program_options::option_description *, boost::detail::sp_counted_base *))(*(_QWORD *)v51 + 16LL))(
           v51,
           v13,
           v14.pn.pi_) )
    {
      v15 = 0;
    }
    else
    {
      if ( (v60 & 1) != 0 )
        v16 = v62;
      else
        v16 = (unsigned __int64)v60 >> 1;
      v15 = v16 != 0;
    }
    v17 = (volatile signed __int32 *)*((_QWORD *)&v51 + 1);
    if ( *((_QWORD *)&v51 + 1) )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v51 + 1) + 8LL), 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 16LL))(v17);
        if ( !_InterlockedSub(v17 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
      }
    }
    if ( !v15 )
      break;
    v51 = 0;
    v52 = 0;
    v53 = -1;
    v56 = 0;
    v55 = 0;
    *(_OWORD *)v54 = 0;
    v57 = 0;
    std::string::operator=((soap *)&v51, (int)&v58, v9, v10, v11, v12);
    v18 = (boost::program_options::basic_option<char> *)*((_QWORD *)this + 1);
    if ( v18 == *((boost::program_options::basic_option<char> **)this + 2) )
    {
      std::vector<boost::program_options::basic_option<char>>::__push_back_slow_path<boost::program_options::basic_option<char> const&>(
        this,
        (const boost::program_options::basic_option<char> *)&v51);
    }
    else
    {
      boost::program_options::basic_option<char>::basic_option(
        v18,
        (const boost::program_options::basic_option<char> *)&v51);
      *((_QWORD *)this + 1) += 88LL;
    }
    if ( (v60 & 1) != 0 )
    {
      if ( !v62 )
        goto LABEL_39;
    }
    else if ( !((unsigned __int64)v60 >> 1) )
    {
LABEL_39:
      v22 = (__int64)*a3;
      v23 = a3[1];
      v24 = (__int64)(*a3 + 24);
      if ( (unsigned __int8 *)v24 == v23 )
        goto LABEL_121;
      v25 = v23 - 24;
      do
      {
        if ( (*(_BYTE *)v22 & 1) != 0 )
        {
          **(_BYTE **)(v22 + 16) = 0;
          *(_QWORD *)(v22 + 8) = 0;
        }
        else
        {
          *(_WORD *)v22 = 0;
        }
        std::string::reserve(v22, 0);
        *(_QWORD *)(v22 + 16) = *(_QWORD *)(v22 + 40);
        *(_OWORD *)v22 = *(_OWORD *)(v22 + 24);
        *(_OWORD *)(v22 + 24) = 0;
        *(_QWORD *)(v22 + 40) = 0;
        v22 += 24;
      }
      while ( v25 != (unsigned __int8 *)v22 );
      v24 = (__int64)a3[1];
      if ( v24 != v22 )
      {
LABEL_121:
        do
        {
          v26 = v24 - 24;
          if ( (*(_BYTE *)(v24 - 24) & 1) != 0 )
            operator delete(*(void **)(v24 - 8));
          v24 = v26;
        }
        while ( v22 != v26 );
      }
      a3[1] = (unsigned __int8 *)v22;
      v27 = 2;
      goto LABEL_54;
    }
    v64 = 0;
    ptr = 0;
    LOWORD(v64) = 11522;
    BYTE2(v64) = 0;
    v19 = &v61;
    if ( (v60 & 1) != 0 )
      v19 = (char *)v63;
    std::string::push_back(&v64, (unsigned int)*v19);
    v20 = v64;
    v66[0] = *(_QWORD *)((char *)&v64 + 1);
    *(_QWORD *)((char *)v66 + 7) = *((_QWORD *)&v64 + 1);
    v21 = ptr;
    v64 = 0;
    ptr = 0;
    if ( (v58 & 1) != 0 )
    {
      *(_BYTE *)v59 = 0;
      *((_QWORD *)&v58 + 1) = 0;
    }
    else
    {
      LOWORD(v58) = 0;
    }
    std::string::reserve(&v58, 0);
    LOBYTE(v58) = v20;
    *((_QWORD *)&v58 + 1) = *(_QWORD *)((char *)v66 + 7);
    *(_QWORD *)((char *)&v58 + 1) = v66[0];
    v59 = v21;
    *(_QWORD *)((char *)v66 + 7) = 0;
    v66[0] = 0;
    if ( (v64 & 1) != 0 )
      operator delete(ptr);
    v27 = 0;
    std::string::erase(&v60, 0, 1);
LABEL_54:
    v28 = *((_QWORD *)&v55 + 1);
    if ( *((_QWORD *)&v55 + 1) )
    {
      v29 = v56;
      if ( (_QWORD)v56 == *((_QWORD *)&v55 + 1) )
      {
        v31 = (void *)*((_QWORD *)&v55 + 1);
      }
      else
      {
        do
        {
          v30 = v29 - 24;
          if ( (*(_BYTE *)(v29 - 24) & 1) != 0 )
            operator delete(*(void **)(v29 - 8));
          v29 = v30;
        }
        while ( v28 != v30 );
        v31 = (void *)*((_QWORD *)&v55 + 1);
      }
      *(_QWORD *)&v56 = v28;
      operator delete(v31);
    }
    v32 = (void **)v54[0];
    if ( v54[0] )
    {
      v33 = (void **)v54[1];
      if ( v54[1] == v54[0] )
      {
        v35 = v54[0];
      }
      else
      {
        do
        {
          v34 = v33 - 3;
          if ( (*(_BYTE *)(v33 - 3) & 1) != 0 )
            operator delete(*(v33 - 1));
          v33 = v34;
        }
        while ( v32 != v34 );
        v35 = v54[0];
      }
      v54[1] = v32;
      operator delete(v35);
    }
    if ( (v51 & 1) != 0 )
      operator delete(v52);
    if ( v27 )
      goto LABEL_115;
  }
  v51 = 0;
  v52 = 0;
  v53 = -1;
  v56 = 0;
  v55 = 0;
  *(_OWORD *)v54 = 0;
  v57 = 0;
  std::string::operator=((soap *)&v51, (int)&v58, v9, v10, v11, v12);
  if ( (_QWORD)v56 == *((_QWORD *)&v56 + 1) )
  {
    std::vector<std::string>::__push_back_slow_path<std::string const&>(
      (std::vector<std::string> *)((char *)&v55 + 8),
      (const std::string *)v5);
  }
  else
  {
    std::string::basic_string(v56, v5);
    *(_QWORD *)&v56 = v56 + 24;
  }
  if ( (v60 & 1) == 0 )
  {
    if ( !((unsigned __int64)v60 >> 1) )
      goto LABEL_84;
LABEL_81:
    if ( v54[1] == (void *)v55 )
    {
      std::vector<std::string>::__push_back_slow_path<std::string const&>(
        (std::vector<std::string> *)v54,
        (const std::string *)&v60);
    }
    else
    {
      std::string::basic_string(v54[1], &v60);
      v54[1] = (char *)v54[1] + 24;
    }
    goto LABEL_84;
  }
  if ( v62 )
    goto LABEL_81;
LABEL_84:
  v36 = (boost::program_options::basic_option<char> *)*((_QWORD *)this + 1);
  if ( v36 == *((boost::program_options::basic_option<char> **)this + 2) )
  {
    std::vector<boost::program_options::basic_option<char>>::__push_back_slow_path<boost::program_options::basic_option<char> const&>(
      this,
      (const boost::program_options::basic_option<char> *)&v51);
  }
  else
  {
    boost::program_options::basic_option<char>::basic_option(
      v36,
      (const boost::program_options::basic_option<char> *)&v51);
    *((_QWORD *)this + 1) += 88LL;
  }
  v37 = (__int64)*a3;
  v38 = a3[1];
  v39 = (__int64)(*a3 + 24);
  if ( (unsigned __int8 *)v39 == v38 )
    goto LABEL_122;
  v40 = v38 - 24;
  do
  {
    if ( (*(_BYTE *)v37 & 1) != 0 )
    {
      **(_BYTE **)(v37 + 16) = 0;
      *(_QWORD *)(v37 + 8) = 0;
    }
    else
    {
      *(_WORD *)v37 = 0;
    }
    std::string::reserve(v37, 0);
    *(_QWORD *)(v37 + 16) = *(_QWORD *)(v37 + 40);
    *(_OWORD *)v37 = *(_OWORD *)(v37 + 24);
    *(_OWORD *)(v37 + 24) = 0;
    *(_QWORD *)(v37 + 40) = 0;
    v37 += 24;
  }
  while ( v40 != (unsigned __int8 *)v37 );
  v39 = (__int64)a3[1];
  if ( v39 != v37 )
  {
LABEL_122:
    do
    {
      v41 = v39 - 24;
      if ( (*(_BYTE *)(v39 - 24) & 1) != 0 )
        operator delete(*(void **)(v39 - 8));
      v39 = v41;
    }
    while ( v37 != v41 );
  }
  a3[1] = (unsigned __int8 *)v37;
  v42 = *((_QWORD *)&v55 + 1);
  if ( *((_QWORD *)&v55 + 1) )
  {
    v43 = v56;
    if ( (_QWORD)v56 == *((_QWORD *)&v55 + 1) )
    {
      v45 = (void *)*((_QWORD *)&v55 + 1);
    }
    else
    {
      do
      {
        v44 = v43 - 24;
        if ( (*(_BYTE *)(v43 - 24) & 1) != 0 )
          operator delete(*(void **)(v43 - 8));
        v43 = v44;
      }
      while ( v42 != v44 );
      v45 = (void *)*((_QWORD *)&v55 + 1);
    }
    *(_QWORD *)&v56 = v42;
    operator delete(v45);
  }
  v46 = (void **)v54[0];
  if ( v54[0] )
  {
    v47 = (void **)v54[1];
    if ( v54[1] == v54[0] )
    {
      v49 = v54[0];
    }
    else
    {
      do
      {
        v48 = v47 - 3;
        if ( (*(_BYTE *)(v47 - 3) & 1) != 0 )
          operator delete(*(v47 - 1));
        v47 = v48;
      }
      while ( v46 != v48 );
      v49 = v54[0];
    }
    v54[1] = v46;
    operator delete(v49);
  }
  if ( (v51 & 1) != 0 )
    operator delete(v52);
LABEL_115:
  if ( (v60 & 1) != 0 )
    operator delete(v63);
  if ( (v58 & 1) != 0 )
    operator delete(v59);
  return this;
}


// Address: 0xe57050 | Name: _ZN5boost15program_options6detail7cmdline16parse_dos_optionERNSt3__16vectorINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS8_ISA_EEEE
std::vector<boost::program_options::basic_option<char>> *__fastcall boost::program_options::detail::cmdline::parse_dos_option(
        std::vector<boost::program_options::basic_option<char>> *this,
        __int64 a2,
        unsigned __int8 **a3)
{
  __int64 v5; // rbx
  unsigned __int64 v6; // rax
  __int64 v7; // rax
  int v8; // edx
  void *v9; // rcx
  size_t v10; // r8
  const void *v11; // r9
  boost::program_options::basic_option<char> *v12; // rdi
  __int64 v13; // rbx
  unsigned __int8 *v14; // r12
  __int64 v15; // rax
  unsigned __int8 *v16; // r12
  __int64 v17; // r12
  void **v18; // r15
  void **v19; // rax
  void **v20; // rbx
  void *v21; // rdi
  void **v22; // r15
  void **v23; // rax
  void **v24; // rbx
  void *v25; // rdi
  __int128 v27; // [rsp+0h] [rbp-A8h] BYREF
  void *ptr; // [rsp+10h] [rbp-98h]
  int v29; // [rsp+18h] [rbp-90h]
  void *v30[2]; // [rsp+20h] [rbp-88h] BYREF
  void *v31[2]; // [rsp+30h] [rbp-78h] BYREF
  __int128 v32; // [rsp+40h] [rbp-68h]
  __int16 v33; // [rsp+50h] [rbp-58h]
  char v34[8]; // [rsp+58h] [rbp-50h] BYREF
  __int64 v35; // [rsp+60h] [rbp-48h]
  void *v36; // [rsp+68h] [rbp-40h]
  __int128 v37; // [rsp+70h] [rbp-38h] BYREF
  void *v38; // [rsp+80h] [rbp-28h]

  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v5 = (__int64)*a3;
  v6 = **a3;
  if ( (v6 & 1) != 0 )
  {
    if ( *(_QWORD *)(v5 + 8) < 2u )
      return this;
  }
  else if ( v6 >> 1 < 2 )
  {
    return this;
  }
  if ( (v6 & 1) != 0 )
  {
    if ( **(_BYTE **)(v5 + 16) != 47 )
      return this;
  }
  else if ( *(_BYTE *)(v5 + 1) != 47 )
  {
    return this;
  }
  std::string::basic_string(&v27, v5, 1, 1, v5);
  v7 = std::string::insert(&v27, 0, "-");
  v38 = *(void **)(v7 + 16);
  v37 = *(_OWORD *)v7;
  *(_OWORD *)v7 = 0;
  *(_QWORD *)(v7 + 16) = 0;
  if ( (v27 & 1) != 0 )
    operator delete(ptr);
  std::string::basic_string(v34, v5, 2, -1, v5);
  v27 = 0;
  ptr = 0;
  v29 = -1;
  v32 = 0;
  *(_OWORD *)v31 = 0;
  *(_OWORD *)v30 = 0;
  v33 = 0;
  std::string::operator=((soap *)&v27, (int)&v37, v8, v9, v10, v11);
  if ( (v34[0] & 1) != 0 )
  {
    if ( !v35 )
      goto LABEL_18;
  }
  else if ( !((unsigned __int64)(unsigned __int8)v34[0] >> 1) )
  {
    goto LABEL_18;
  }
  if ( v30[1] == v31[0] )
  {
    std::vector<std::string>::__push_back_slow_path<std::string const&>(
      (std::vector<std::string> *)v30,
      (const std::string *)v34);
  }
  else
  {
    std::string::basic_string(v30[1], v34);
    v30[1] = (char *)v30[1] + 24;
  }
LABEL_18:
  if ( (_QWORD)v32 == *((_QWORD *)&v32 + 1) )
  {
    std::vector<std::string>::__push_back_slow_path<std::string const&>(
      (std::vector<std::string> *)&v31[1],
      (const std::string *)v5);
  }
  else
  {
    std::string::basic_string(v32, v5);
    *(_QWORD *)&v32 = v32 + 24;
  }
  v12 = (boost::program_options::basic_option<char> *)*((_QWORD *)this + 1);
  if ( v12 == *((boost::program_options::basic_option<char> **)this + 2) )
  {
    std::vector<boost::program_options::basic_option<char>>::__push_back_slow_path<boost::program_options::basic_option<char> const&>(
      this,
      (const boost::program_options::basic_option<char> *)&v27);
  }
  else
  {
    boost::program_options::basic_option<char>::basic_option(
      v12,
      (const boost::program_options::basic_option<char> *)&v27);
    *((_QWORD *)this + 1) += 88LL;
  }
  v13 = (__int64)*a3;
  v14 = a3[1];
  v15 = (__int64)(*a3 + 24);
  if ( (unsigned __int8 *)v15 == v14 )
    goto LABEL_60;
  v16 = v14 - 24;
  do
  {
    if ( (*(_BYTE *)v13 & 1) != 0 )
    {
      **(_BYTE **)(v13 + 16) = 0;
      *(_QWORD *)(v13 + 8) = 0;
    }
    else
    {
      *(_WORD *)v13 = 0;
    }
    std::string::reserve(v13, 0);
    *(_QWORD *)(v13 + 16) = *(_QWORD *)(v13 + 40);
    *(_OWORD *)v13 = *(_OWORD *)(v13 + 24);
    *(_OWORD *)(v13 + 24) = 0;
    *(_QWORD *)(v13 + 40) = 0;
    v13 += 24;
  }
  while ( v16 != (unsigned __int8 *)v13 );
  v15 = (__int64)a3[1];
  if ( v15 != v13 )
  {
LABEL_60:
    do
    {
      v17 = v15 - 24;
      if ( (*(_BYTE *)(v15 - 24) & 1) != 0 )
        operator delete(*(void **)(v15 - 8));
      v15 = v17;
    }
    while ( v13 != v17 );
  }
  a3[1] = (unsigned __int8 *)v13;
  v18 = (void **)v31[1];
  if ( v31[1] )
  {
    v19 = (void **)v32;
    if ( (void *)v32 == v31[1] )
    {
      v21 = v31[1];
    }
    else
    {
      do
      {
        v20 = v19 - 3;
        if ( (*(_BYTE *)(v19 - 3) & 1) != 0 )
          operator delete(*(v19 - 1));
        v19 = v20;
      }
      while ( v18 != v20 );
      v21 = v31[1];
    }
    *(_QWORD *)&v32 = v18;
    operator delete(v21);
  }
  v22 = (void **)v30[0];
  if ( v30[0] )
  {
    v23 = (void **)v30[1];
    if ( v30[1] == v30[0] )
    {
      v25 = v30[0];
    }
    else
    {
      do
      {
        v24 = v23 - 3;
        if ( (*(_BYTE *)(v23 - 3) & 1) != 0 )
          operator delete(*(v23 - 1));
        v23 = v24;
      }
      while ( v22 != v24 );
      v25 = v30[0];
    }
    v30[1] = v22;
    operator delete(v25);
  }
  if ( (v27 & 1) == 0 )
  {
    if ( (v34[0] & 1) == 0 )
      goto LABEL_52;
LABEL_56:
    operator delete(v36);
    if ( (v37 & 1) == 0 )
      return this;
    goto LABEL_53;
  }
  operator delete(ptr);
  if ( (v34[0] & 1) != 0 )
    goto LABEL_56;
LABEL_52:
  if ( (v37 & 1) != 0 )
LABEL_53:
    operator delete(v38);
  return this;
}


// Address: 0xe574c0 | Name: _ZN5boost15program_options6detail7cmdline16parse_terminatorERNSt3__16vectorINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS8_ISA_EEEE
std::vector<boost::program_options::basic_option<char>> *__fastcall boost::program_options::detail::cmdline::parse_terminator(
        std::vector<boost::program_options::basic_option<char>> *this,
        __int64 a2,
        unsigned __int8 **a3)
{
  std::vector<boost::program_options::basic_option<char>> *v4; // rbx
  unsigned __int8 *v5; // rdi
  unsigned __int64 v6; // rax
  unsigned __int8 *v7; // r12
  unsigned __int8 *v8; // rcx
  unsigned __int64 v9; // r13
  const std::string *v10; // rbp
  boost::program_options::basic_option<char> *v11; // rdi
  __int64 v12; // rbp
  __int64 v13; // rax
  __int64 v14; // rbx
  void *v15; // rdi
  __int64 v16; // rbp
  __int64 v17; // rax
  __int64 v18; // rbx
  void *v19; // rdi
  unsigned __int8 *v20; // rbp
  std::__vector_base<boost::program_options::basic_option<char>> *v22; // [rsp+8h] [rbp-90h]
  __int128 v23; // [rsp+10h] [rbp-88h] BYREF
  void *v24; // [rsp+20h] [rbp-78h]
  int v25; // [rsp+28h] [rbp-70h]
  __int128 v26; // [rsp+30h] [rbp-68h] BYREF
  __int128 v27; // [rsp+40h] [rbp-58h] BYREF
  __int128 v28; // [rsp+50h] [rbp-48h]
  __int16 v29; // [rsp+60h] [rbp-38h]

  v4 = this;
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v5 = *a3;
  v6 = **a3;
  if ( (v6 & 1) != 0 )
  {
    if ( *((_QWORD *)v5 + 1) != 2 )
      return v4;
  }
  else if ( v6 >> 1 != 2 )
  {
    return v4;
  }
  if ( !(unsigned int)std::string::compare(v5, 0, -1, "--", 2) )
  {
    v7 = *a3;
    v8 = a3[1];
    if ( 0xAAAAAAAAAAAAAAABLL * ((v8 - *a3) >> 3) >= 2 )
    {
      v9 = 1;
      v22 = v4;
      do
      {
        v23 = 0;
        v24 = 0;
        v25 = -1;
        v28 = 0;
        v27 = 0;
        v26 = 0;
        v29 = 0;
        std::vector<std::string>::__push_back_slow_path<std::string const&>(
          (std::vector<std::string> *)&v26,
          (const std::string *)&v7[24 * v9]);
        v10 = (const std::string *)&(*a3)[24 * v9];
        if ( (_QWORD)v28 == *((_QWORD *)&v28 + 1) )
        {
          std::vector<std::string>::__push_back_slow_path<std::string const&>(
            (std::vector<std::string> *)((char *)&v27 + 8),
            v10);
        }
        else
        {
          std::string::basic_string(v28, v10);
          *(_QWORD *)&v28 = v28 + 24;
        }
        v25 = 0x7FFFFFFF;
        v11 = (boost::program_options::basic_option<char> *)*((_QWORD *)v4 + 1);
        if ( v11 == *((boost::program_options::basic_option<char> **)v4 + 2) )
        {
          std::vector<boost::program_options::basic_option<char>>::__push_back_slow_path<boost::program_options::basic_option<char> const&>(
            v4,
            (const boost::program_options::basic_option<char> *)&v23);
        }
        else
        {
          boost::program_options::basic_option<char>::basic_option(
            v11,
            (const boost::program_options::basic_option<char> *)&v23);
          *((_QWORD *)v4 + 1) += 88LL;
        }
        v12 = *((_QWORD *)&v27 + 1);
        if ( *((_QWORD *)&v27 + 1) )
        {
          v13 = v28;
          if ( (_QWORD)v28 == *((_QWORD *)&v27 + 1) )
          {
            v15 = (void *)*((_QWORD *)&v27 + 1);
          }
          else
          {
            do
            {
              v14 = v13 - 24;
              if ( (*(_BYTE *)(v13 - 24) & 1) != 0 )
                operator delete(*(void **)(v13 - 8));
              v13 = v14;
            }
            while ( v12 != v14 );
            v15 = (void *)*((_QWORD *)&v27 + 1);
            v4 = v22;
          }
          *(_QWORD *)&v28 = v12;
          operator delete(v15);
        }
        v16 = v26;
        if ( (_QWORD)v26 )
        {
          v17 = *((_QWORD *)&v26 + 1);
          if ( *((_QWORD *)&v26 + 1) == (_QWORD)v26 )
          {
            v19 = (void *)v26;
          }
          else
          {
            do
            {
              v18 = v17 - 24;
              if ( (*(_BYTE *)(v17 - 24) & 1) != 0 )
                operator delete(*(void **)(v17 - 8));
              v17 = v18;
            }
            while ( v16 != v18 );
            v19 = (void *)v26;
            v4 = v22;
          }
          *((_QWORD *)&v26 + 1) = v16;
          operator delete(v19);
        }
        if ( (v23 & 1) != 0 )
          operator delete(v24);
        v9 = (unsigned int)(v9 + 1);
        v7 = *a3;
        v8 = a3[1];
      }
      while ( 0xAAAAAAAAAAAAAAABLL * ((v8 - *a3) >> 3) > v9 );
    }
    if ( v7 != v8 )
    {
      do
      {
        v20 = v8 - 24;
        if ( (*(v8 - 24) & 1) != 0 )
          operator delete(*((void **)v8 - 1));
        v8 = v20;
      }
      while ( v7 != v20 );
    }
    a3[1] = v7;
  }
  return v4;
}


// Address: 0xe57820 | Name: _ZN5boost15program_options6detail7cmdline13finish_optionERNS0_12basic_optionIcEERNSt3__16vectorINS6_12basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEENSB_ISD_EEEERKNS7_INS_9function1INS7_IS4_NSB_IS4_EEEESG_EENSB_ISK_EEEE
void __fastcall boost::program_options::detail::cmdline::finish_option(
        boost::program_options::detail::cmdline *this,
        boost::program_options::option *opt,
        std::vector<std::string> *other_tokens,
        const std::vector<boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>> *style_parsers)
{
  boost::program_options::option *v5; // r15
  unsigned __int64 v7; // rax
  int v8; // edx
  void *v9; // rcx
  size_t v10; // r8
  const void *v11; // r9
  __int64 v12; // rsi
  const boost::program_options::options_description *v13; // rdi
  _BOOL4 v14; // edx
  _BOOL4 v15; // ecx
  _BOOL4 v16; // r8d
  const boost::program_options::option_description *nothrow; // rax
  const boost::program_options::option_description *v18; // r14
  int v19; // eax
  int v20; // edx
  void *v21; // rcx
  size_t v22; // r8
  const void *v23; // r9
  boost::shared_ptr<const boost::program_options::value_semantic>_0 v24; // rax
  boost::shared_ptr<const boost::program_options::value_semantic>_0 v25; // rax
  int v26; // r12d
  __int64 v27; // rcx
  unsigned __int64 v28; // rax
  const std::string *v29; // r14
  int v30; // ebp
  int v31; // edx
  void *v32; // rcx
  size_t v33; // r8
  const void *v34; // r9
  std::vector<std::string> *v35; // r14
  unsigned int v36; // ebp
  __int64 v37; // rax
  __int64 v38; // rcx
  const std::string *v39; // rsi
  __int64 v40; // rdi
  const std::string *v41; // rsi
  __int64 v42; // rdi
  const std::string *v43; // rbp
  __int64 v44; // rbx
  __int64 v45; // rax
  const std::string *v46; // rbx
  const std::string *v47; // rbx
  void **v48; // rbx
  int v49; // ebp
  void **v50; // rax
  void **v51; // rbp
  void *v52; // rdi
  std::vector<std::string> *v53; // rax
  unsigned int v54; // [rsp+Ch] [rbp-15Ch]
  int v55; // [rsp+Ch] [rbp-15Ch]
  void *ptr[2]; // [rsp+10h] [rbp-158h] BYREF
  void *v57; // [rsp+20h] [rbp-148h]
  __int128 v58; // [rsp+30h] [rbp-138h] BYREF
  void *v59; // [rsp+40h] [rbp-128h]
  boost::program_options::detail::cmdline *v60; // [rsp+48h] [rbp-120h]
  __int128 v61; // [rsp+50h] [rbp-118h] BYREF
  void *v62; // [rsp+60h] [rbp-108h]
  __int128 v63; // [rsp+D0h] [rbp-98h] BYREF
  void *v64; // [rsp+E0h] [rbp-88h]
  boost::program_options::option *v65; // [rsp+E8h] [rbp-80h]
  std::vector<std::string> *v66; // [rsp+F0h] [rbp-78h]
  _BYTE v67[16]; // [rsp+F8h] [rbp-70h] BYREF
  void *v68; // [rsp+108h] [rbp-60h]
  std::vector<std::string> *v69; // [rsp+110h] [rbp-58h]
  std::vector<std::string> *v70; // [rsp+118h] [rbp-50h]
  __int128 v71; // [rsp+120h] [rbp-48h] BYREF
  void *v72; // [rsp+130h] [rbp-38h]

  v5 = opt;
  v7 = *(unsigned __int8 *)opt;
  if ( (v7 & 1) != 0 )
  {
    if ( !*((_QWORD *)opt + 1) )
      return;
  }
  else if ( !(v7 >> 1) )
  {
    return;
  }
  v66 = other_tokens;
  std::string::basic_string(v67, opt);
  v12 = *((_QWORD *)opt + 7);
  if ( *((_QWORD *)v5 + 8) != v12 )
    std::string::operator=((soap *)v67, v12, v8, v9, v10, v11);
  v13 = (const boost::program_options::options_description *)*((_QWORD *)this + 4);
  v14 = (*((_DWORD *)this + 6) >> 9) & 1;
  v15 = (*((_DWORD *)this + 6) >> 10) & 1;
  v16 = (*((_DWORD *)this + 6) >> 11) & 1;
  v65 = v5;
  nothrow = boost::program_options::options_description::find_nothrow(v13, v5, v14, v15, v16);
  v18 = nothrow;
  if ( nothrow )
  {
    v60 = this;
    v19 = (unsigned int)boost::program_options::option_description::key(nothrow, v5);
    std::string::operator=((soap *)v5, v19, v20, v21, v22, v23);
    v24 = boost::program_options::option_description::semantic(v18);
    v54 = (*(__int64 (__fastcall **)(_QWORD, const boost::program_options::option_description *, boost::detail::sp_counted_base *))(*(_QWORD *)v61 + 8LL))(
            v61,
            v18,
            v24.pn.pi_);
    if ( *((_QWORD *)&v61 + 1) )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v61 + 1) + 8LL), 1u) )
      {
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v61 + 1) + 16LL))(*((_QWORD *)&v61 + 1));
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v61 + 1) + 12LL), 1u) )
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v61 + 1) + 24LL))(*((_QWORD *)&v61 + 1));
      }
    }
    v25 = boost::program_options::option_description::semantic(v18);
    v26 = (*(__int64 (__fastcall **)(_QWORD, const boost::program_options::option_description *, boost::detail::sp_counted_base *))(*(_QWORD *)v61 + 16LL))(
            v61,
            v18,
            v25.pn.pi_);
    if ( *((_QWORD *)&v61 + 1) )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v61 + 1) + 8LL), 1u) )
      {
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v61 + 1) + 16LL))(*((_QWORD *)&v61 + 1));
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v61 + 1) + 12LL), 1u) )
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v61 + 1) + 24LL))(*((_QWORD *)&v61 + 1));
      }
    }
    v27 = *((_QWORD *)v5 + 4);
    v28 = 0xAAAAAAAAAAAAAAABLL * ((*((_QWORD *)v5 + 5) - v27) >> 3);
    v29 = *(const std::string **)v66;
    if ( v54 > (unsigned int)v28 - 1431655765 * (unsigned int)((*((_QWORD *)v66 + 1) - *(_QWORD *)v66) >> 3) )
    {
      v58 = 0;
      v59 = 0;
      *(_OWORD *)ptr = 0;
      v57 = 0;
      boost::program_options::invalid_command_line_syntax::invalid_command_line_syntax(
        (boost::program_options::invalid_command_line_syntax *)&v61,
        boost::program_options::invalid_syntax::kind_t::missing_parameter,
        (const std::string *)&v58,
        (const std::string *)ptr,
        0);
      boost::throw_exception<boost::program_options::invalid_command_line_syntax>((const boost::program_options::invalid_command_line_syntax *)&v61);
    }
    if ( !v26 && v27 != *((_QWORD *)v5 + 5) )
    {
      v58 = 0;
      v59 = 0;
      *(_OWORD *)ptr = 0;
      v57 = 0;
      boost::program_options::invalid_command_line_syntax::invalid_command_line_syntax(
        (boost::program_options::invalid_command_line_syntax *)&v61,
        boost::program_options::invalid_syntax::kind_t::extra_parameter,
        (const std::string *)&v58,
        (const std::string *)ptr,
        0);
      boost::throw_exception<boost::program_options::invalid_command_line_syntax>((const boost::program_options::invalid_command_line_syntax *)&v61);
    }
    if ( v29 != *((const std::string **)v66 + 1) )
    {
      v69 = (boost::program_options::option *)((char *)v5 + 56);
      v70 = (boost::program_options::option *)((char *)v5 + 32);
      v30 = v54 - v28;
      if ( v28 > v54 )
        v30 = 0;
      do
      {
        if ( !v30 )
          break;
        v58 = 0;
        v59 = 0;
        *(_OWORD *)ptr = 0;
        v57 = 0;
        v55 = v30;
        ptr[1] = operator new(0x18u);
        ptr[0] = ptr[1];
        v57 = (char *)ptr[1] + 24;
        std::string::basic_string(ptr[1], v29);
        ptr[1] = (char *)ptr[1] + 24;
        v35 = v66;
        if ( (_QWORD)v58 == *((_QWORD *)&v58 + 1) )
        {
          v36 = 0;
          while ( 1 )
          {
            v37 = *(_QWORD *)style_parsers;
            if ( (__int64)(*((_QWORD *)style_parsers + 1) - *(_QWORD *)style_parsers) >> 5 <= (unsigned __int64)v36 )
              break;
            v38 = *(_QWORD *)(v37 + 32LL * v36);
            if ( !v38 )
            {
              std::runtime_error::runtime_error((std::runtime_error *)&v63, "call to empty boost::function");
              *(_QWORD *)&v63 = off_2875ED8;
              boost::throw_exception<boost::bad_function_call>((const boost::bad_function_call *)&v63);
            }
            (*(void (__fastcall **)(__int128 *, __int64, void **))((v38 & 0xFFFFFFFFFFFFFFFELL) + 8))(
              &v61,
              v37 + 32LL * v36 + 8,
              ptr);
            std::vector<boost::program_options::basic_option<char>>::deallocate((std::vector<boost::program_options::basic_option<char>> *)&v58);
            v58 = v61;
            v59 = v62;
            v61 = 0;
            v62 = 0;
            std::__vector_base<boost::program_options::basic_option<char>>::~__vector_base((std::__vector_base<boost::program_options::basic_option<char>> *)&v61);
            ++v36;
            if ( (_QWORD)v58 != *((_QWORD *)&v58 + 1) )
              goto LABEL_28;
          }
        }
        else
        {
LABEL_28:
          std::string::operator=((soap *)v67, *(_QWORD *)v35, v31, v32, v33, v34);
          if ( boost::program_options::options_description::find_nothrow(
                 *((const boost::program_options::options_description **)v60 + 4),
                 *(const std::string **)v35,
                 (*((_DWORD *)v60 + 6) & 0x200) != 0,
                 (*((_DWORD *)v60 + 6) & 0x400) != 0,
                 (*((_DWORD *)v60 + 6) & 0x800) != 0) )
          {
            v63 = 0;
            v64 = 0;
            v71 = 0;
            v72 = 0;
            boost::program_options::invalid_command_line_syntax::invalid_command_line_syntax(
              (boost::program_options::invalid_command_line_syntax *)&v61,
              boost::program_options::invalid_syntax::kind_t::missing_parameter,
              (const std::string *)&v63,
              (const std::string *)&v71,
              0);
            boost::throw_exception<boost::program_options::invalid_command_line_syntax>((const boost::program_options::invalid_command_line_syntax *)&v61);
          }
        }
        v39 = *(const std::string **)v35;
        v40 = *((_QWORD *)v5 + 5);
        if ( v40 == *((_QWORD *)v5 + 6) )
        {
          std::vector<std::string>::__push_back_slow_path<std::string const&>(v70, v39);
        }
        else
        {
          std::string::basic_string(v40, v39);
          *((_QWORD *)v5 + 5) += 24LL;
        }
        v41 = *(const std::string **)v35;
        v42 = *((_QWORD *)v5 + 8);
        if ( v42 == *((_QWORD *)v5 + 9) )
        {
          std::vector<std::string>::__push_back_slow_path<std::string const&>(v69, v41);
        }
        else
        {
          std::string::basic_string(v42, v41);
          *((_QWORD *)v5 + 8) += 24LL;
        }
        v43 = *(const std::string **)v35;
        v44 = *((_QWORD *)v35 + 1);
        v45 = *(_QWORD *)v35 + 24LL;
        if ( v45 == v44 )
          goto LABEL_67;
        v46 = (const std::string *)(v44 - 24);
        do
        {
          if ( (*(_BYTE *)v43 & 1) != 0 )
          {
            **((_BYTE **)v43 + 2) = 0;
            *((_QWORD *)v43 + 1) = 0;
          }
          else
          {
            *(_WORD *)v43 = 0;
          }
          std::string::reserve(v43, 0);
          *((_QWORD *)v43 + 2) = *((_QWORD *)v43 + 5);
          *(_OWORD *)v43 = *(_OWORD *)((char *)v43 + 24);
          *(_OWORD *)((char *)v43 + 24) = 0;
          *((_QWORD *)v43 + 5) = 0;
          v43 = (const std::string *)((char *)v43 + 24);
        }
        while ( v46 != v43 );
        v45 = *((_QWORD *)v35 + 1);
        if ( (const std::string *)v45 != v43 )
        {
LABEL_67:
          do
          {
            v47 = (const std::string *)(v45 - 24);
            if ( (*(_BYTE *)(v45 - 24) & 1) != 0 )
              operator delete(*(void **)(v45 - 8));
            v45 = (__int64)v47;
          }
          while ( v43 != v47 );
        }
        *((_QWORD *)v35 + 1) = v43;
        v48 = (void **)ptr[0];
        v49 = v55;
        if ( ptr[0] )
        {
          v50 = (void **)ptr[1];
          if ( ptr[1] == ptr[0] )
          {
            v52 = ptr[0];
          }
          else
          {
            do
            {
              v51 = v50 - 3;
              if ( (*(_BYTE *)(v50 - 3) & 1) != 0 )
                operator delete(*(v50 - 1));
              v50 = v51;
            }
            while ( v48 != v51 );
            v52 = ptr[0];
            v49 = v55;
          }
          ptr[1] = v48;
          operator delete(v52);
        }
        v30 = v49 - 1;
        std::__vector_base<boost::program_options::basic_option<char>>::~__vector_base((std::__vector_base<boost::program_options::basic_option<char>> *)&v58);
        v53 = v35;
        v29 = *(const std::string **)v35;
        v5 = v65;
      }
      while ( v29 != *((const std::string **)v53 + 1) );
    }
  }
  else
  {
    if ( !*((_BYTE *)this + 28) )
    {
      v60 = this;
      v58 = 0;
      v59 = 0;
      boost::program_options::unknown_option::unknown_option(
        (boost::program_options::unknown_option *)&v61,
        (const std::string *)&v58);
      boost::throw_exception<boost::program_options::unknown_option>((const boost::program_options::unknown_option *)&v61);
    }
    *((_BYTE *)v5 + 80) = 1;
  }
  if ( (v67[0] & 1) != 0 )
    operator delete(v68);
}


// Address: 0xe582c0 | Name: _ZN5boost15program_options6detail7cmdline21set_additional_parserENS_9function1INSt3__14pairINS4_12basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEESB_EERKSB_EE
void __fastcall boost::program_options::detail::cmdline::set_additional_parser(
        boost::program_options::detail::cmdline *this,
        const boost::function1<std::pair<std::string,std::string >,const std::string &> *a2)
{
  boost::function1<std::pair<std::string,std::string>,std::string const&>::operator=(
    (boost::function1<std::pair<std::string,std::string >,const std::string &> *)((char *)this + 48),
    a2);
}


// Address: 0xe582d0 | Name: _ZN5boost15program_options6detail7cmdline18extra_style_parserENS_9function1INSt3__16vectorINS0_12basic_optionIcEENS4_9allocatorIS7_EEEERNS5_INS4_12basic_stringIcNS4_11char_traitsIcEENS8_IcEEEENS8_ISF_EEEEEE
void __fastcall boost::program_options::detail::cmdline::extra_style_parser(
        boost::program_options::detail::cmdline *this,
        const boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *a2)
{
  boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &>::operator=(
    (boost::function1<std::vector<boost::program_options::basic_option<char>>,std::vector<std::string> &> *)((char *)this + 80),
    a2);
}


