// Address: 0x2839980 | Name: _Z31setFFlagFSRemoveJunctionSupportv
void __cdecl setFFlagFSRemoveJunctionSupport()
{
  ;
}


// Address: 0x2839990 | Name: _ZN5boost10filesystem8absoluteERKNS0_4pathES3_
boost::filesystem *__fastcall boost::filesystem::absolute(
        boost::filesystem *this,
        const boost::filesystem::path *a2,
        const boost::filesystem::path *a3)
{
  __int64 v4; // r12
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rcx
  boost::filesystem::path *v8; // rax
  boost::filesystem::path *v9; // rax
  boost::filesystem::path *v10; // rax
  boost::filesystem::path *v11; // rax
  boost::filesystem::path *v12; // rax
  _BYTE v14[8]; // [rsp+8h] [rbp-110h] BYREF
  __int64 v15; // [rsp+10h] [rbp-108h]
  void *ptr; // [rsp+18h] [rbp-100h]
  _BYTE v17[16]; // [rsp+20h] [rbp-F8h] BYREF
  void *v18; // [rsp+30h] [rbp-E8h]
  _BYTE v19[8]; // [rsp+38h] [rbp-E0h] BYREF
  __int64 v20; // [rsp+40h] [rbp-D8h]
  void *v21; // [rsp+48h] [rbp-D0h]
  _BYTE v22[8]; // [rsp+50h] [rbp-C8h] BYREF
  unsigned __int64 v23; // [rsp+58h] [rbp-C0h]
  void *v24; // [rsp+60h] [rbp-B8h]
  _BYTE v25[8]; // [rsp+68h] [rbp-B0h] BYREF
  unsigned __int64 v26; // [rsp+70h] [rbp-A8h]
  void *v27; // [rsp+78h] [rbp-A0h]
  _BYTE v28[16]; // [rsp+80h] [rbp-98h] BYREF
  void *v29; // [rsp+90h] [rbp-88h]
  _BYTE v30[16]; // [rsp+98h] [rbp-80h] BYREF
  void *v31; // [rsp+A8h] [rbp-70h]
  _BYTE v32[16]; // [rsp+B0h] [rbp-68h] BYREF
  void *v33; // [rsp+C0h] [rbp-58h]
  _BYTE v34[16]; // [rsp+C8h] [rbp-50h] BYREF
  void *v35; // [rsp+D8h] [rbp-40h]
  _BYTE v36[16]; // [rsp+E0h] [rbp-38h] BYREF
  void *v37; // [rsp+F0h] [rbp-28h]

  boost::filesystem::path::root_directory((boost::filesystem::path *)v14);
  if ( (v14[0] & 1) == 0 )
  {
    if ( v14[0] <= 1u )
      goto LABEL_3;
LABEL_6:
    std::string::basic_string(v17, a3);
    goto LABEL_7;
  }
  v4 = v15;
  operator delete(ptr);
  if ( v4 )
    goto LABEL_6;
LABEL_3:
  boost::filesystem::detail::current_path((boost::filesystem::detail *)v14, 0);
  boost::filesystem::absolute((boost::filesystem *)v17, a3, (const boost::filesystem::path *)v14);
  if ( (v14[0] & 1) != 0 )
    operator delete(ptr);
LABEL_7:
  boost::filesystem::path::root_name((boost::filesystem::path *)v22);
  boost::filesystem::path::root_name((boost::filesystem::path *)v19);
  boost::filesystem::path::root_directory((boost::filesystem::path *)v25);
  v5 = *(unsigned __int8 *)a2;
  if ( (v5 & 1) != 0 )
  {
    if ( *((_QWORD *)a2 + 1) )
      goto LABEL_9;
LABEL_12:
    std::string::basic_string(this, v17);
    goto LABEL_49;
  }
  if ( !(v5 >> 1) )
    goto LABEL_12;
LABEL_9:
  if ( (v22[0] & 1) != 0 )
    v6 = v23;
  else
    v6 = (unsigned __int64)v22[0] >> 1;
  if ( (v25[0] & 1) != 0 )
  {
    v7 = v26;
    if ( v6 )
      goto LABEL_16;
  }
  else
  {
    v7 = (unsigned __int64)v25[0] >> 1;
    if ( v6 )
    {
LABEL_16:
      if ( v7 )
      {
LABEL_17:
        std::string::basic_string(this, a2);
        goto LABEL_49;
      }
      boost::filesystem::path::root_directory((boost::filesystem::path *)v32);
      std::string::basic_string(v14, v22);
      v9 = boost::filesystem::path::operator/=((boost::filesystem::path *)v14, (const boost::filesystem::path *)v32);
      std::string::basic_string(v34, v9);
      if ( (v14[0] & 1) != 0 )
        operator delete(ptr);
      boost::filesystem::path::relative_path((boost::filesystem::path *)v30);
      std::string::basic_string(v14, v34);
      v10 = boost::filesystem::path::operator/=((boost::filesystem::path *)v14, (const boost::filesystem::path *)v30);
      std::string::basic_string(v36, v10);
      if ( (v14[0] & 1) != 0 )
        operator delete(ptr);
      boost::filesystem::path::relative_path((boost::filesystem::path *)v28);
      std::string::basic_string(v14, v36);
      v11 = boost::filesystem::path::operator/=((boost::filesystem::path *)v14, (const boost::filesystem::path *)v28);
      std::string::basic_string(this, v11);
      if ( (v14[0] & 1) != 0 )
      {
        operator delete(ptr);
        if ( (v28[0] & 1) == 0 )
        {
LABEL_29:
          if ( (v36[0] & 1) == 0 )
            goto LABEL_30;
          goto LABEL_45;
        }
      }
      else if ( (v28[0] & 1) == 0 )
      {
        goto LABEL_29;
      }
      operator delete(v29);
      if ( (v36[0] & 1) == 0 )
      {
LABEL_30:
        if ( (v30[0] & 1) == 0 )
          goto LABEL_31;
        goto LABEL_46;
      }
LABEL_45:
      operator delete(v37);
      if ( (v30[0] & 1) == 0 )
      {
LABEL_31:
        if ( (v34[0] & 1) == 0 )
          goto LABEL_32;
        goto LABEL_47;
      }
LABEL_46:
      operator delete(v31);
      if ( (v34[0] & 1) == 0 )
      {
LABEL_32:
        if ( (v32[0] & 1) == 0 )
          goto LABEL_49;
LABEL_48:
        operator delete(v33);
        goto LABEL_49;
      }
LABEL_47:
      operator delete(v35);
      if ( (v32[0] & 1) == 0 )
        goto LABEL_49;
      goto LABEL_48;
    }
  }
  if ( v7 )
  {
    if ( (v19[0] & 1) != 0 )
    {
      if ( !v20 )
        goto LABEL_17;
    }
    else if ( !((unsigned __int64)v19[0] >> 1) )
    {
      goto LABEL_17;
    }
    std::string::basic_string(v14, v19);
    v8 = boost::filesystem::path::operator/=((boost::filesystem::path *)v14, a2);
    std::string::basic_string(this, v8);
  }
  else
  {
    std::string::basic_string(v14, v17);
    v12 = boost::filesystem::path::operator/=((boost::filesystem::path *)v14, a2);
    std::string::basic_string(this, v12);
  }
  if ( (v14[0] & 1) != 0 )
  {
    operator delete(ptr);
    if ( (v25[0] & 1) == 0 )
      goto LABEL_50;
LABEL_37:
    operator delete(v27);
    if ( (v19[0] & 1) == 0 )
      goto LABEL_51;
LABEL_38:
    operator delete(v21);
    if ( (v22[0] & 1) == 0 )
      goto LABEL_52;
LABEL_39:
    operator delete(v24);
    if ( (v17[0] & 1) == 0 )
      return this;
    goto LABEL_53;
  }
LABEL_49:
  if ( (v25[0] & 1) != 0 )
    goto LABEL_37;
LABEL_50:
  if ( (v19[0] & 1) != 0 )
    goto LABEL_38;
LABEL_51:
  if ( (v22[0] & 1) != 0 )
    goto LABEL_39;
LABEL_52:
  if ( (v17[0] & 1) != 0 )
LABEL_53:
    operator delete(v18);
  return this;
}


// Address: 0x2839fa0 | Name: _ZN5boost10filesystem6detail32possible_large_file_size_supportEv
bool __cdecl boost::filesystem::detail::possible_large_file_size_support()
{
  return 1;
}


// Address: 0x2839fb0 | Name: _ZN5boost10filesystem6detail9canonicalERKNS0_4pathES4_PNS_6system10error_codeE
boost::filesystem::detail *__fastcall boost::filesystem::detail::canonical(
        boost::filesystem::detail *this,
        const boost::filesystem::path *a2,
        const boost::filesystem::path *a3,
        boost::system::error_code *a4)
{
  __int64 v6; // rbp
  const boost::system::error_category *v7; // rax
  char v8; // cl
  bool v9; // bl
  const boost::filesystem::path *v10; // rax
  const boost::filesystem::path *v11; // rax
  boost::filesystem::file_type m_value; // eax
  int v13; // ebx
  char v14; // bp
  int v15; // edx
  void *v16; // rcx
  size_t v17; // r8
  const void *v18; // r9
  bool v19; // bl
  __int64 v20; // rbx
  int v21; // edx
  void *v22; // rcx
  size_t v23; // r8
  const void *v24; // r9
  bool v25; // bl
  char v26; // bp
  boost::filesystem::filesystem_error *exception; // rbp
  const boost::system::error_category *v29; // rax
  boost::filesystem::filesystem_error *v30; // rbp
  __int128 v31; // [rsp+10h] [rbp-118h] BYREF
  void *ptr; // [rsp+20h] [rbp-108h]
  __int64 v33; // [rsp+28h] [rbp-100h]
  __int64 v34; // [rsp+30h] [rbp-F8h]
  __int128 v35; // [rsp+40h] [rbp-E8h] BYREF
  void *v36; // [rsp+50h] [rbp-D8h]
  _BYTE v37[16]; // [rsp+60h] [rbp-C8h] BYREF
  void *v38; // [rsp+70h] [rbp-B8h]
  boost::system::error_code v39; // [rsp+78h] [rbp-B0h] BYREF
  _BYTE v40[8]; // [rsp+88h] [rbp-A0h] BYREF
  __int64 v41; // [rsp+90h] [rbp-98h]
  void *v42; // [rsp+98h] [rbp-90h]
  __int64 v43; // [rsp+A0h] [rbp-88h]
  __int64 v44; // [rsp+A8h] [rbp-80h]
  _BYTE v45[16]; // [rsp+B0h] [rbp-78h] BYREF
  void *v46; // [rsp+C0h] [rbp-68h]
  _BYTE v47[16]; // [rsp+C8h] [rbp-60h] BYREF
  void *v48; // [rsp+D8h] [rbp-50h]
  _BYTE v49[16]; // [rsp+E0h] [rbp-48h] BYREF
  void *v50; // [rsp+F0h] [rbp-38h]
  boost::system::error_code v51; // 0:ecx.4,8:r8.8

  boost::filesystem::path::root_directory((boost::filesystem::path *)&v31);
  if ( (v31 & 1) != 0 )
  {
    v6 = *((_QWORD *)&v31 + 1);
    operator delete(ptr);
    if ( !v6 )
      goto LABEL_3;
LABEL_5:
    std::string::basic_string(v37, a2);
    goto LABEL_6;
  }
  if ( (unsigned __int8)v31 > 1u )
    goto LABEL_5;
LABEL_3:
  boost::filesystem::absolute((boost::filesystem *)v37, a2, a3);
LABEL_6:
  boost::filesystem::path::root_path((boost::filesystem::path *)v47);
  v35 = 0;
  v36 = 0;
  v39.m_val = 0;
  v39.m_cat = boost::system::system_category();
  if ( boost::filesystem::detail::status((const boost::filesystem::path *)v37, &v39).m_value == boost::filesystem::file_type::file_not_found )
  {
    if ( !a4 )
    {
      exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
      v31 = 0;
      ptr = 0;
      ptr = operator new(0x20u);
      v31 = *(_OWORD *)&stru_3EB180.vtable;
      strcpy((char *)ptr, "boost::filesystem::canonical");
      v29 = boost::system::generic_category();
      v51.m_val = 2;
      v51.m_cat = v29;
      boost::filesystem::filesystem_error::filesystem_error(
        exception,
        (const std::string *)&v31,
        (const boost::filesystem::path *)v37,
        v51);
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
        (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
    }
    v7 = boost::system::generic_category();
    a4->m_val = 2;
    a4->m_cat = v7;
    std::string::basic_string(this, &v35);
    goto LABEL_72;
  }
  if ( v39.m_val )
  {
    if ( !a4 )
    {
      v30 = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
      v31 = 0;
      ptr = 0;
      ptr = operator new(0x20u);
      v31 = *(_OWORD *)&stru_3EB180.vtable;
      strcpy((char *)ptr, "boost::filesystem::canonical");
      boost::filesystem::filesystem_error::filesystem_error(
        v30,
        (const std::string *)&v31,
        (const boost::filesystem::path *)v37,
        v39);
      __cxa_throw(
        v30,
        (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
        (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
    }
    *a4 = v39;
    std::string::basic_string(this, &v35);
    goto LABEL_72;
  }
  v8 = 1;
LABEL_13:
  if ( v8 )
  {
    if ( (v35 & 1) != 0 )
    {
      *(_BYTE *)v36 = 0;
      *((_QWORD *)&v35 + 1) = 0;
    }
    else
    {
      LOWORD(v35) = 0;
    }
    boost::filesystem::path::begin((boost::filesystem::path *)&v31);
    while ( 1 )
    {
      boost::filesystem::path::end((boost::filesystem::path *)v40);
      v9 = 1;
      if ( v33 == v43 )
      {
        v9 = v34 != v44;
        if ( (v40[0] & 1) == 0 )
        {
LABEL_20:
          if ( !v9 )
            goto LABEL_33;
          goto LABEL_24;
        }
      }
      else if ( (v40[0] & 1) == 0 )
      {
        goto LABEL_20;
      }
      operator delete(v42);
      if ( !v9 )
      {
LABEL_33:
        v13 = 4;
        goto LABEL_34;
      }
LABEL_24:
      v10 = boost::filesystem::detail::dot_path();
      if ( boost::filesystem::path::compare((const boost::filesystem::path *)&v31, v10) )
      {
        v11 = boost::filesystem::detail::dot_dot_path();
        if ( boost::filesystem::path::compare((const boost::filesystem::path *)&v31, v11) )
        {
          boost::filesystem::path::operator/=((boost::filesystem::path *)&v35, (const boost::filesystem::path *)&v31);
          m_value = boost::filesystem::detail::symlink_status((const boost::filesystem::path *)&v35, a4).m_value;
          if ( a4 && a4->m_val )
          {
            *(_OWORD *)this = 0;
            *((_QWORD *)this + 2) = 0;
            v13 = 1;
LABEL_34:
            v8 = 0;
LABEL_35:
            if ( (v31 & 1) == 0 )
              goto LABEL_37;
LABEL_36:
            v14 = v8;
            operator delete(ptr);
            v8 = v14;
            goto LABEL_37;
          }
          if ( m_value == boost::filesystem::file_type::symlink_file )
          {
            boost::filesystem::detail::read_symlink(
              (boost::filesystem::detail *)v45,
              (const boost::filesystem::path *)&v35,
              a4);
            if ( a4 && a4->m_val )
            {
              *(_OWORD *)this = 0;
              *((_QWORD *)this + 2) = 0;
              v13 = 1;
              v8 = 0;
              if ( (v45[0] & 1) != 0 )
                goto LABEL_67;
              goto LABEL_35;
            }
            boost::filesystem::path::remove_filename((boost::filesystem::path *)&v35);
            boost::filesystem::path::root_directory((boost::filesystem::path *)v40);
            if ( (v40[0] & 1) == 0 )
            {
              if ( v40[0] <= 1u )
                goto LABEL_46;
LABEL_55:
              boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)&v31);
              while ( 2 )
              {
                boost::filesystem::path::end((boost::filesystem::path *)v40);
                v25 = 1;
                if ( v33 == v43 )
                {
                  v25 = v34 != v44;
                  if ( (v40[0] & 1) == 0 )
                    goto LABEL_58;
                }
                else if ( (v40[0] & 1) == 0 )
                {
LABEL_58:
                  if ( !v25 )
                    goto LABEL_63;
LABEL_62:
                  boost::filesystem::path::operator/=(
                    (boost::filesystem::path *)v45,
                    (const boost::filesystem::path *)&v31);
                  boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)&v31);
                  continue;
                }
                break;
              }
              operator delete(v42);
              if ( !v25 )
              {
LABEL_63:
                std::string::operator=((soap *)v37, (int)v45, v21, v22, v23, v24);
                goto LABEL_66;
              }
              goto LABEL_62;
            }
            v20 = v41;
            operator delete(v42);
            if ( v20 )
              goto LABEL_55;
LABEL_46:
            std::string::basic_string(v49, &v35);
            boost::filesystem::path::operator/=((boost::filesystem::path *)v49, (const boost::filesystem::path *)v45);
            boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)&v31);
            while ( 2 )
            {
              boost::filesystem::path::end((boost::filesystem::path *)v40);
              v19 = 1;
              if ( v33 == v43 )
              {
                v19 = v34 != v44;
                if ( (v40[0] & 1) == 0 )
                  goto LABEL_49;
              }
              else if ( (v40[0] & 1) == 0 )
              {
LABEL_49:
                if ( !v19 )
                  break;
                goto LABEL_53;
              }
              operator delete(v42);
              if ( v19 )
              {
LABEL_53:
                boost::filesystem::path::operator/=(
                  (boost::filesystem::path *)v49,
                  (const boost::filesystem::path *)&v31);
                boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)&v31);
                continue;
              }
              break;
            }
            std::string::operator=((soap *)v37, (int)v49, v15, v16, v17, v18);
            if ( (v49[0] & 1) != 0 )
              operator delete(v50);
LABEL_66:
            v8 = 1;
            v13 = 4;
            if ( (v45[0] & 1) == 0 )
              goto LABEL_35;
LABEL_67:
            v26 = v8;
            operator delete(v46);
            v8 = v26;
            if ( (v31 & 1) != 0 )
              goto LABEL_36;
LABEL_37:
            if ( v13 != 4 )
              goto LABEL_72;
            goto LABEL_13;
          }
        }
        else if ( boost::filesystem::path::compare(
                    (const boost::filesystem::path *)&v35,
                    (const boost::filesystem::path *)v47) )
        {
          boost::filesystem::path::remove_filename((boost::filesystem::path *)&v35);
        }
      }
      boost::filesystem::path::m_path_iterator_increment((boost::filesystem::path::iterator *)&v31);
    }
  }
  if ( a4 )
  {
    a4->m_val = 0;
    a4->m_cat = boost::system::system_category();
  }
  std::string::basic_string(this, &v35);
LABEL_72:
  if ( (v35 & 1) == 0 )
  {
    if ( (v47[0] & 1) == 0 )
      goto LABEL_74;
LABEL_78:
    operator delete(v48);
    if ( (v37[0] & 1) == 0 )
      return this;
    goto LABEL_75;
  }
  operator delete(v36);
  if ( (v47[0] & 1) != 0 )
    goto LABEL_78;
LABEL_74:
  if ( (v37[0] & 1) != 0 )
LABEL_75:
    operator delete(v38);
  return this;
}


// Address: 0x283a770 | Name: _ZN5boost10filesystem6detail14symlink_statusERKNS0_4pathEPNS_6system10error_codeE
boost::filesystem::file_status __fastcall boost::filesystem::detail::symlink_status(
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  const char *v3; // rsi
  int *v4; // rax
  int *v5; // r15
  int v6; // ebp
  const boost::system::error_category *v7; // rax
  __int64 v8; // rax
  __int64 v9; // rcx
  unsigned int v10; // edx
  boost::filesystem::filesystem_error *exception; // rbx
  int v12; // ebp
  const boost::system::error_category *v13; // rax
  __int128 v14; // [rsp+0h] [rbp-C8h] BYREF
  void *ptr; // [rsp+10h] [rbp-B8h]
  _BYTE v16[24]; // [rsp+18h] [rbp-B0h] BYREF
  int v17; // [rsp+30h] [rbp-98h]
  boost::system::error_code v19; // 0:ecx.4,8:r8.8

  if ( (*(_BYTE *)p & 1) != 0 )
    v3 = (const char *)*((_QWORD *)p + 2);
  else
    v3 = (char *)p + 1;
  if ( __lxstat64(1, v3, (struct stat64 *)v16) )
  {
    v4 = __errno_location();
    v5 = v4;
    if ( ec )
    {
      v6 = *v4;
      v7 = boost::system::system_category();
      ec->m_val = v6;
      ec->m_cat = v7;
    }
    v8 = 0;
    v9 = 1;
    if ( *v5 != 2 && *v5 != 20 )
    {
      if ( !ec )
      {
        exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
        ptr = operator new(0x20u);
        v14 = xmmword_3E5070;
        strcpy((char *)ptr, "boost::filesystem::status");
        v12 = *v5;
        v13 = boost::system::system_category();
        v19.m_val = v12;
        v19.m_cat = v13;
        boost::filesystem::filesystem_error::filesystem_error(exception, (const std::string *)&v14, p, v19);
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
          (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
      }
      v8 = 0xFFFF;
      v9 = 0;
    }
  }
  else
  {
    if ( ec )
    {
      ec->m_val = 0;
      ec->m_cat = boost::system::system_category();
    }
    v8 = 0xFFFF;
    v9 = 10;
    switch ( ((v17 & 0xF000u) - 4096) >> 12 )
    {
      case 0u:
        v10 = v17 & 0xFFF;
        v9 = 7;
        goto LABEL_21;
      case 1u:
        v10 = v17 & 0xFFF;
        v9 = 6;
        goto LABEL_21;
      case 3u:
        v10 = v17 & 0xFFF;
        v9 = 3;
        goto LABEL_21;
      case 5u:
        v10 = v17 & 0xFFF;
        v9 = 5;
        goto LABEL_21;
      case 7u:
        v10 = v17 & 0xFFF;
        v9 = 2;
        goto LABEL_21;
      case 9u:
        v10 = v17 & 0xFFF;
        v9 = 4;
        goto LABEL_21;
      case 0xBu:
        v10 = v17 & 0xFFF;
        v9 = 8;
LABEL_21:
        v8 = v10;
        break;
      default:
        return (boost::filesystem::file_status)(v9 | (v8 << 32));
    }
  }
  return (boost::filesystem::file_status)(v9 | (v8 << 32));
}


// Address: 0x283a960 | Name: _ZN5boost10filesystem6detail12read_symlinkERKNS0_4pathEPNS_6system10error_codeE
boost::filesystem::detail *__fastcall boost::filesystem::detail::read_symlink(
        boost::filesystem::detail *this,
        const boost::filesystem::path *path1_arg,
        boost::system::error_code *a3)
{
  size_t i; // rbx
  char *v6; // rax
  char *v7; // r13
  const char *v8; // rdi
  ssize_t v9; // rax
  const boost::system::error_category *v10; // rax
  int v11; // ebx
  boost::filesystem::filesystem_error *exception; // r12
  int v14; // ebx
  const boost::system::error_category *v15; // rax
  __int128 v16; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  boost::system::error_code v18; // 0:ecx.4,8:r8.8

  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  for ( i = 64; ; i *= 2LL )
  {
    v6 = (char *)operator new[](i);
    v7 = v6;
    v8 = (char *)path1_arg + 1;
    if ( (*(_BYTE *)path1_arg & 1) != 0 )
      v8 = (const char *)*((_QWORD *)path1_arg + 2);
    v9 = readlink(v8, v6, i);
    if ( v9 == -1 )
    {
      if ( !a3 )
      {
        exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
        ptr = operator new(0x20u);
        v16 = xmmword_3E71E0;
        strcpy((char *)ptr, "boost::filesystem::read_symlink");
        v14 = *__errno_location();
        v15 = boost::system::system_category();
        v18.m_val = v14;
        v18.m_cat = v15;
        boost::filesystem::filesystem_error::filesystem_error(exception, (const std::string *)&v16, path1_arg, v18);
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
          (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
      }
      v11 = *__errno_location();
      v10 = boost::system::system_category();
      a3->m_val = v11;
      goto LABEL_11;
    }
    if ( v9 != i )
      break;
    operator delete[](v7);
  }
  boost::filesystem::path::assign<char *>(this, v7, &v7[v9]);
  if ( !a3 )
    goto LABEL_12;
  a3->m_val = 0;
  v10 = boost::system::system_category();
LABEL_11:
  a3->m_cat = v10;
LABEL_12:
  operator delete[](v7);
  return this;
}


// Address: 0x283ab00 | Name: _ZN5boost10filesystem6detail4copyERKNS0_4pathES4_PNS_6system10error_codeE
void __fastcall boost::filesystem::detail::copy(
        const boost::filesystem::path *from,
        const boost::filesystem::path *to,
        boost::system::error_code *ec)
{
  boost::filesystem::file_type m_value; // eax
  const boost::system::error_category *v5; // rax
  _BYTE v6[16]; // [rsp+8h] [rbp-30h] BYREF
  void *ptr; // [rsp+18h] [rbp-20h]

  m_value = boost::filesystem::detail::symlink_status(from, ec).m_value;
  if ( !ec->m_val )
  {
    switch ( m_value )
    {
      case boost::filesystem::file_type::regular_file:
        boost::filesystem::detail::copy_file(from, to, boost::filesystem::detail::copy_option::none, ec);
        break;
      case boost::filesystem::file_type::directory_file:
        boost::filesystem::detail::copy_directory(from, to, ec);
        break;
      case boost::filesystem::file_type::symlink_file:
        boost::filesystem::detail::read_symlink((boost::filesystem::detail *)v6, from, ec);
        if ( !ec->m_val )
          boost::filesystem::detail::create_symlink((const boost::filesystem::path *)v6, to, ec);
        if ( (v6[0] & 1) != 0 )
          operator delete(ptr);
        break;
      default:
        v5 = boost::system::system_category();
        ec->m_val = 38;
        ec->m_cat = v5;
        break;
    }
  }
}


// Address: 0x283abd0 | Name: _ZN5boost10filesystem6detail14copy_directoryERKNS0_4pathES4_PNS_6system10error_codeE
void __fastcall boost::filesystem::detail::copy_directory(
        const boost::filesystem::path *from,
        const boost::filesystem::path *to,
        boost::system::error_code *ec)
{
  const char *v6; // rsi
  char v7; // bl
  const char *v8; // rdi
  __int128 v9; // [rsp+0h] [rbp-C8h] BYREF
  void *ptr; // [rsp+10h] [rbp-B8h]
  _BYTE v11[24]; // [rsp+18h] [rbp-B0h] BYREF
  __mode_t mode; // [rsp+30h] [rbp-98h]

  if ( (*(_BYTE *)from & 1) != 0 )
    v6 = (const char *)*((_QWORD *)from + 2);
  else
    v6 = (char *)from + 1;
  v7 = 1;
  if ( !__xstat64(1, v6, (struct stat64 *)v11) )
  {
    if ( (*(_BYTE *)to & 1) != 0 )
      v8 = (const char *)*((_QWORD *)to + 2);
    else
      v8 = (char *)to + 1;
    v7 = mkdir(v8, mode) != 0;
  }
  ptr = operator new(0x30u);
  v9 = xmmword_3E8C20;
  strcpy((char *)ptr, "boost::filesystem::copy_directory");
  `anonymous namespace'::error(v7, from, to, ec, (const std::string *)&v9);
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x283acb0 | Name: _ZN12_GLOBAL__N_15errorEbRKN5boost10filesystem4pathES4_PNS0_6system10error_codeERKNSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEE
bool __fastcall `anonymous namespace'::error(
        bool was_error,
        const boost::filesystem::path *p1,
        const boost::filesystem::path *p2,
        boost::system::error_code *ec,
        const std::string *message)
{
  const boost::system::error_category *v5; // rax
  int v7; // ebp
  boost::filesystem::filesystem_error *exception; // rbx
  int v11; // ebp
  const boost::system::error_category *v12; // rax
  boost::system::error_code v14; // 0:r8d.4,8:r9.8

  if ( was_error )
  {
    if ( !ec )
    {
      exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
      v11 = *__errno_location();
      v12 = boost::system::system_category();
      v14.m_val = v11;
      v14.m_cat = v12;
      boost::filesystem::filesystem_error::filesystem_error(exception, message, p1, p2, v14);
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
        (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
    }
    v7 = *__errno_location();
    v5 = boost::system::system_category();
    ec->m_val = v7;
    goto LABEL_6;
  }
  if ( ec )
  {
    ec->m_val = 0;
    v5 = boost::system::system_category();
LABEL_6:
    ec->m_cat = v5;
  }
  return (char)v5;
}


// Address: 0x283ad40 | Name: _ZN5boost10filesystem6detail9copy_fileERKNS0_4pathES4_NS1_11copy_optionEPNS_6system10error_codeE
void __fastcall boost::filesystem::detail::copy_file(
        const boost::filesystem::path *from,
        const boost::filesystem::path *to,
        boost::filesystem::detail::copy_option option,
        boost::system::error_code *ec)
{
  char *v5; // r13
  const boost::filesystem::path *v6; // r15
  const char *v7; // r14
  size_t v8; // rax
  size_t v9; // rbx
  size_t v10; // rbp
  const char *v11; // r14
  size_t v12; // rax
  size_t v13; // rbx
  char *v14; // r13
  size_t v15; // rbp
  char *v16; // r13
  char *v17; // rbx
  char *v18; // rdi
  int v19; // r14d
  bool v20; // bl
  const char *v21; // rdi
  int v22; // ebp
  ssize_t v23; // r15
  ssize_t v24; // rax
  ssize_t v25; // rbx
  int v26; // eax
  int *v27; // rbx
  int v28; // ebp
  struct _Unwind_Exception *v29; // rax
  struct _Unwind_Exception *v30; // rbp
  __int128 dest; // [rsp+0h] [rbp-118h] BYREF
  char *file; // [rsp+10h] [rbp-108h]
  char v33[16]; // [rsp+20h] [rbp-F8h] BYREF
  void *v34; // [rsp+30h] [rbp-E8h]
  boost::system::error_code *v35; // [rsp+38h] [rbp-E0h]
  const boost::filesystem::path *v36; // [rsp+40h] [rbp-D8h]
  boost::filesystem::path *p1; // [rsp+48h] [rbp-D0h]
  __int128 v38; // [rsp+50h] [rbp-C8h] BYREF
  void *ptr; // [rsp+60h] [rbp-B8h]
  unsigned int v40; // [rsp+68h] [rbp-B0h]

  v5 = (char *)(unsigned int)option;
  v6 = to;
  if ( (*(_BYTE *)from & 1) != 0 )
    v7 = (const char *)*((_QWORD *)from + 2);
  else
    v7 = (char *)from + 1;
  dest = 0;
  file = 0;
  v8 = strlen(v7);
  if ( v8 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
    goto LABEL_49;
  }
  v9 = v8;
  LODWORD(v35) = (_DWORD)v5;
  p1 = from;
  if ( v8 >= 0x17 )
  {
    v10 = (v8 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v5 = (char *)operator new(v10);
    file = v5;
    *(_QWORD *)&dest = v10 | 1;
    *((_QWORD *)&dest + 1) = v9;
    goto LABEL_9;
  }
  LOBYTE(dest) = 2 * v8;
  v5 = (char *)&dest + 1;
  if ( v8 )
LABEL_9:
    memcpy(v5, v7, v9);
  v5[v9] = 0;
  if ( (*(_BYTE *)to & 1) != 0 )
    v11 = (const char *)*((_QWORD *)to + 2);
  else
    v11 = (char *)to + 1;
  *(_OWORD *)v33 = 0;
  v34 = 0;
  v12 = strlen(v11);
  if ( v12 >= 0xFFFFFFFFFFFFFFF0LL )
  {
LABEL_49:
    std::__basic_string_common<true>::__throw_length_error(v33);
    v30 = v29;
    operator delete[](v5);
    if ( (v33[0] & 1) != 0 )
    {
      operator delete(v34);
      if ( (dest & 1) != 0 )
      {
LABEL_54:
        operator delete(file);
        _Unwind_Resume(v30);
      }
    }
    else if ( (dest & 1) != 0 )
    {
      goto LABEL_54;
    }
    _Unwind_Resume(v30);
  }
  v13 = v12;
  if ( v12 >= 0x17 )
  {
    v15 = (v12 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v14 = (char *)operator new(v15);
    v34 = v14;
    *(_QWORD *)v33 = v15 | 1;
    *(_QWORD *)&v33[8] = v13;
    goto LABEL_18;
  }
  v33[0] = 2 * v12;
  v14 = &v33[1];
  if ( v12 )
LABEL_18:
    memcpy(v14, v11, v13);
  v14[v13] = 0;
  v16 = (char *)operator new[](0x8000u);
  v17 = (char *)&dest + 1;
  v18 = (char *)&dest + 1;
  if ( (dest & 1) != 0 )
    v18 = file;
  v19 = open64(v18, 0);
  if ( v19 < 0 )
    goto LABEL_26;
  if ( (dest & 1) != 0 )
    v17 = file;
  if ( __xstat64(1, v17, (struct stat64 *)&v38) )
  {
    close(v19);
LABEL_26:
    v20 = 0;
    goto LABEL_27;
  }
  v36 = to;
  if ( (v33[0] & 1) != 0 )
    v21 = (const char *)v34;
  else
    v21 = &v33[1];
  v22 = open64(v21, (((_DWORD)v35 == 0) << 7) | 0x241, v40);
  if ( v22 < 0 )
  {
    v27 = __errno_location();
    v28 = *v27;
    close(v19);
    *v27 = v28;
    v20 = 0;
    v6 = v36;
  }
  else
  {
    v35 = ec;
LABEL_43:
    v25 = read(v19, v16, 0x8000u);
    if ( v25 > 0 )
    {
      v23 = 0;
      while ( 1 )
      {
        v24 = write(v22, &v16[v23], v25 - v23);
        if ( v24 < 0 )
          break;
        v23 += v24;
        if ( v23 >= v25 )
          goto LABEL_43;
      }
      v25 = v24;
    }
    v26 = close(v19);
    ec = v35;
    v20 = (v26 | close(v22)) >= 0 && v25 >= 0;
    v6 = v36;
  }
LABEL_27:
  operator delete[](v16);
  v38 = 0;
  ptr = 0;
  ptr = operator new(0x20u);
  v38 = *(_OWORD *)&stru_3EB180.vtable;
  strcpy((char *)ptr, "boost::filesystem::copy_file");
  `anonymous namespace'::error(!v20, p1, v6, ec, (const std::string *)&v38);
  if ( (v38 & 1) != 0 )
  {
    operator delete(ptr);
    if ( (v33[0] & 1) == 0 )
    {
LABEL_29:
      if ( (dest & 1) == 0 )
        return;
      goto LABEL_30;
    }
  }
  else if ( (v33[0] & 1) == 0 )
  {
    goto LABEL_29;
  }
  operator delete(v34);
  if ( (dest & 1) != 0 )
LABEL_30:
    operator delete(file);
}


// Address: 0x283b120 | Name: _ZN5boost10filesystem6detail12copy_symlinkERKNS0_4pathES4_PNS_6system10error_codeE
void __fastcall boost::filesystem::detail::copy_symlink(
        const boost::filesystem::path *existing_symlink,
        const boost::filesystem::path *new_symlink,
        boost::system::error_code *ec)
{
  _BYTE v4[16]; // [rsp+0h] [rbp-28h] BYREF
  void *ptr; // [rsp+10h] [rbp-18h]

  boost::filesystem::detail::read_symlink((boost::filesystem::detail *)v4, existing_symlink, ec);
  if ( !ec || !ec->m_val )
    boost::filesystem::detail::create_symlink((const boost::filesystem::path *)v4, new_symlink, ec);
  if ( (v4[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x283b190 | Name: _ZN5boost10filesystem6detail14create_symlinkERKNS0_4pathES4_PNS_6system10error_codeE
void __fastcall boost::filesystem::detail::create_symlink(
        const boost::filesystem::path *to,
        const boost::filesystem::path *from,
        boost::system::error_code *ec)
{
  const char *v6; // rdi
  const char *v7; // rsi
  _BOOL8 v8; // rbp
  __int128 v9; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  if ( (*(_BYTE *)to & 1) != 0 )
  {
    v6 = (const char *)*((_QWORD *)to + 2);
    if ( (*(_BYTE *)from & 1) == 0 )
    {
LABEL_3:
      v7 = (char *)from + 1;
      goto LABEL_6;
    }
  }
  else
  {
    v6 = (char *)to + 1;
    if ( (*(_BYTE *)from & 1) == 0 )
      goto LABEL_3;
  }
  v7 = (const char *)*((_QWORD *)from + 2);
LABEL_6:
  v8 = symlink(v6, v7) != 0;
  ptr = operator new(0x30u);
  v9 = xmmword_3E8C20;
  strcpy((char *)ptr, "boost::filesystem::create_symlink");
  `anonymous namespace'::error(v8, to, from, ec, (const std::string *)&v9);
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x283b260 | Name: _ZN5boost10filesystem6detail18create_directoriesERKNS0_4pathEPNS_6system10error_codeE
bool __fastcall boost::filesystem::detail::create_directories(
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  bool directory; // bl
  boost::filesystem::filesystem_error *exception; // r14
  boost::system::error_code v5; // [rsp+8h] [rbp-50h] BYREF
  _BYTE v6[8]; // [rsp+18h] [rbp-40h] BYREF
  __int64 v7; // [rsp+20h] [rbp-38h]
  void *ptr; // [rsp+28h] [rbp-30h]
  __int128 v9; // [rsp+30h] [rbp-28h] BYREF
  void *v10; // [rsp+40h] [rbp-18h]

  v5.m_val = 0;
  v5.m_cat = boost::system::system_category();
  if ( boost::filesystem::detail::status(p, &v5).m_value == boost::filesystem::file_type::directory_file )
  {
    if ( ec )
    {
      ec->m_val = 0;
      ec->m_cat = boost::system::system_category();
    }
    return 0;
  }
  boost::filesystem::path::parent_path((boost::filesystem::path *)v6);
  if ( (v6[0] & 1) != 0 )
  {
    if ( !v7 )
      goto LABEL_14;
  }
  else if ( !((unsigned __int64)v6[0] >> 1) )
  {
    goto LABEL_14;
  }
  if ( boost::filesystem::detail::status((const boost::filesystem::path *)v6, &v5).m_value != boost::filesystem::file_type::file_not_found
    || (boost::filesystem::detail::create_directories((const boost::filesystem::path *)v6, &v5), !v5.m_val) )
  {
LABEL_14:
    directory = boost::filesystem::detail::create_directory(p, ec);
    if ( (v6[0] & 1) == 0 )
      return directory;
LABEL_15:
    operator delete(ptr);
    return directory;
  }
  if ( !ec )
  {
    exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
    v9 = 0;
    v10 = 0;
    v10 = operator new(0x30u);
    v9 = xmmword_3E6A90;
    strcpy((char *)v10, "boost::filesystem::create_directories");
    boost::filesystem::filesystem_error::filesystem_error(
      exception,
      (const std::string *)&v9,
      (const boost::filesystem::path *)v6,
      v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
      (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
  }
  *ec = v5;
  directory = 0;
  if ( (v6[0] & 1) != 0 )
    goto LABEL_15;
  return directory;
}


// Address: 0x283b440 | Name: _ZN5boost10filesystem6detail16create_directoryERKNS0_4pathEPNS_6system10error_codeE
bool __fastcall boost::filesystem::detail::create_directory(
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  const char *v3; // rdi
  int v4; // ebp
  const boost::system::error_category *v5; // rax
  bool v6; // bp
  boost::filesystem::filesystem_error *exception; // rbx
  const boost::system::error_category *v9; // rax
  __int128 v10; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  boost::system::error_code v12; // [rsp+20h] [rbp-28h] BYREF
  boost::system::error_code v13; // 0:ecx.4,8:r8.8

  if ( (*(_BYTE *)p & 1) != 0 )
    v3 = (const char *)*((_QWORD *)p + 2);
  else
    v3 = (char *)p + 1;
  if ( mkdir(v3, 0x1FFu) )
  {
    v4 = *__errno_location();
    v12.m_val = 0;
    v12.m_cat = boost::system::system_category();
    if ( v4 == 17 && boost::filesystem::detail::status(p, &v12).m_value == boost::filesystem::file_type::directory_file )
    {
      if ( !ec )
        return 0;
      ec->m_val = 0;
      v5 = boost::system::system_category();
    }
    else
    {
      if ( !ec )
      {
        exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
        ptr = operator new(0x30u);
        v10 = xmmword_3E71C0;
        strcpy((char *)ptr, "boost::filesystem::create_directory");
        v9 = boost::system::system_category();
        v13.m_val = v4;
        v13.m_cat = v9;
        boost::filesystem::filesystem_error::filesystem_error(exception, (const std::string *)&v10, p, v13);
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
          (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
      }
      v5 = boost::system::system_category();
      ec->m_val = v4;
    }
    ec->m_cat = v5;
    return 0;
  }
  v6 = 1;
  if ( ec )
  {
    ec->m_val = 0;
    ec->m_cat = boost::system::system_category();
  }
  return v6;
}


// Address: 0x283b5a0 | Name: _ZN5boost10filesystem6detail24create_directory_symlinkERKNS0_4pathES4_PNS_6system10error_codeE
void __fastcall boost::filesystem::detail::create_directory_symlink(
        const boost::filesystem::path *to,
        const boost::filesystem::path *from,
        boost::system::error_code *ec)
{
  const char *v6; // rdi
  const char *v7; // rsi
  _BOOL8 v8; // rbp
  __int128 v9; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  if ( (*(_BYTE *)to & 1) != 0 )
  {
    v6 = (const char *)*((_QWORD *)to + 2);
    if ( (*(_BYTE *)from & 1) == 0 )
    {
LABEL_3:
      v7 = (char *)from + 1;
      goto LABEL_6;
    }
  }
  else
  {
    v6 = (char *)to + 1;
    if ( (*(_BYTE *)from & 1) == 0 )
      goto LABEL_3;
  }
  v7 = (const char *)*((_QWORD *)from + 2);
LABEL_6:
  v8 = symlink(v6, v7) != 0;
  ptr = operator new(0x30u);
  v9 = xmmword_3EA4C0;
  strcpy((char *)ptr, "boost::filesystem::create_directory_symlink");
  `anonymous namespace'::error(v8, to, from, ec, (const std::string *)&v9);
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x283b670 | Name: _ZN5boost10filesystem6detail16create_hard_linkERKNS0_4pathES4_PNS_6system10error_codeE
void __fastcall boost::filesystem::detail::create_hard_link(
        const boost::filesystem::path *to,
        const boost::filesystem::path *from,
        boost::system::error_code *ec)
{
  const char *v6; // rdi
  const char *v7; // rsi
  _BOOL8 v8; // rbp
  __int128 v9; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  if ( (*(_BYTE *)to & 1) != 0 )
  {
    v6 = (const char *)*((_QWORD *)to + 2);
    if ( (*(_BYTE *)from & 1) == 0 )
    {
LABEL_3:
      v7 = (char *)from + 1;
      goto LABEL_6;
    }
  }
  else
  {
    v6 = (char *)to + 1;
    if ( (*(_BYTE *)from & 1) == 0 )
      goto LABEL_3;
  }
  v7 = (const char *)*((_QWORD *)from + 2);
LABEL_6:
  v8 = link(v6, v7) != 0;
  ptr = operator new(0x30u);
  v9 = xmmword_3E71C0;
  strcpy((char *)ptr, "boost::filesystem::create_hard_link");
  `anonymous namespace'::error(v8, to, from, ec, (const std::string *)&v9);
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x283b740 | Name: _ZN5boost10filesystem6detail12current_pathEPNS_6system10error_codeE
boost::filesystem::detail *__fastcall boost::filesystem::detail::current_path(
        boost::filesystem::detail *this,
        boost::system::error_code *a2)
{
  size_t i; // r13
  char *v3; // r12
  int *v4; // rbp
  int v5; // r14d
  void *v6; // rbx
  int v7; // ebp
  const boost::system::error_category *v8; // rax
  boost::filesystem::filesystem_error *exception; // rbx
  int v11; // ebp
  const boost::system::error_category *v12; // rax
  __int128 v13; // [rsp+10h] [rbp-48h] BYREF
  void *ptr; // [rsp+20h] [rbp-38h]
  boost::system::error_code v15; // 0:edx.4,8:rcx.8

  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  for ( i = 128; ; i *= 2LL )
  {
    v3 = (char *)operator new[](i);
    if ( getcwd(v3, i) )
      break;
    v4 = __errno_location();
    v5 = *v4;
    v6 = operator new(0x20u);
    ptr = v6;
    v13 = xmmword_3E71E0;
    strcpy((char *)v6, "boost::filesystem::current_path");
    if ( v5 != 34 )
    {
      if ( !a2 )
      {
        exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
        v11 = *v4;
        v12 = boost::system::system_category();
        v15.m_val = v11;
        v15.m_cat = v12;
        boost::filesystem::filesystem_error::filesystem_error(exception, (const std::string *)&v13, v15);
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
          (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
      }
      v7 = *v4;
      v8 = boost::system::system_category();
      a2->m_val = v7;
      goto LABEL_8;
    }
    if ( a2 )
    {
      a2->m_val = 0;
      v8 = boost::system::system_category();
LABEL_8:
      a2->m_cat = v8;
    }
    operator delete(v6);
    operator delete[](v3);
    if ( v5 != 34 )
      return this;
  }
  std::string::assign(this, v3);
  if ( a2 )
  {
    a2->m_val = 0;
    a2->m_cat = boost::system::system_category();
  }
  operator delete[](v3);
  return this;
}


// Address: 0x283b900 | Name: _ZN5boost10filesystem6detail12current_pathERKNS0_4pathEPNS_6system10error_codeE
void __fastcall boost::filesystem::detail::current_path(
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  const char *v3; // rdi
  _BOOL8 v4; // rbp
  __int128 v5; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  if ( (*(_BYTE *)p & 1) != 0 )
    v3 = (const char *)*((_QWORD *)p + 2);
  else
    v3 = (char *)p + 1;
  v4 = chdir(v3) != 0;
  ptr = operator new(0x20u);
  v5 = xmmword_3E71E0;
  strcpy((char *)ptr, "boost::filesystem::current_path");
  `anonymous namespace'::error(v4, p, ec, (const std::string *)&v5);
  if ( (v5 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x283b9b0 | Name: _ZN12_GLOBAL__N_15errorEbRKN5boost10filesystem4pathEPNS0_6system10error_codeERKNSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEE
bool __fastcall `anonymous namespace'::error(
        bool was_error,
        const boost::filesystem::path *p,
        boost::system::error_code *ec,
        const std::string *message)
{
  int v5; // r14d
  const boost::system::error_category *v6; // rax
  boost::filesystem::filesystem_error *exception; // rbx
  int v10; // ebp
  const boost::system::error_category *v11; // rax
  boost::system::error_code v12; // 0:ecx.4,8:r8.8

  if ( was_error )
  {
    if ( !ec )
    {
      exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
      v10 = *__errno_location();
      v11 = boost::system::system_category();
      v12.m_val = v10;
      v12.m_cat = v11;
      boost::filesystem::filesystem_error::filesystem_error(exception, message, p, v12);
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
        (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
    }
    v5 = *__errno_location();
    v6 = boost::system::system_category();
    ec->m_val = v5;
    goto LABEL_6;
  }
  if ( ec )
  {
    ec->m_val = 0;
    v6 = boost::system::system_category();
LABEL_6:
    ec->m_cat = v6;
  }
  return was_error;
}


// Address: 0x283ba40 | Name: _ZN5boost10filesystem6detail10equivalentERKNS0_4pathES4_PNS_6system10error_codeE
bool __fastcall boost::filesystem::detail::equivalent(
        const boost::filesystem::path *p1,
        const boost::filesystem::path *p2,
        boost::system::error_code *ec)
{
  const char *v5; // rsi
  int v6; // ebp
  const char *v7; // rsi
  int v8; // eax
  bool v9; // bl
  __int128 v11; // [rsp+0h] [rbp-168h] BYREF
  void *ptr; // [rsp+10h] [rbp-158h]
  _QWORD v13[18]; // [rsp+20h] [rbp-148h] BYREF
  _QWORD v14[23]; // [rsp+B0h] [rbp-B8h] BYREF

  if ( (*(_BYTE *)p2 & 1) != 0 )
    v5 = (const char *)*((_QWORD *)p2 + 2);
  else
    v5 = (char *)p2 + 1;
  v6 = __xstat64(1, v5, (struct stat64 *)v14);
  if ( (*(_BYTE *)p1 & 1) != 0 )
    v7 = (const char *)*((_QWORD *)p1 + 2);
  else
    v7 = (char *)p1 + 1;
  v8 = __xstat64(1, v7, (struct stat64 *)v13);
  if ( v6 | v8 )
  {
    v9 = v8 != 0 && v6 != 0;
    ptr = operator new(0x20u);
    v11 = xmmword_3E9C50;
    strcpy((char *)ptr, "boost::filesystem::equivalent");
    `anonymous namespace'::error(v9, p1, p2, ec, (const std::string *)&v11);
    if ( (v11 & 1) != 0 )
      operator delete(ptr);
  }
  else if ( v13[0] == v14[0] && v13[1] == v14[1] && v13[6] == v14[6] )
  {
    return v13[11] == v14[11];
  }
  return 0;
}


// Address: 0x283bb80 | Name: _ZN5boost10filesystem6detail9file_sizeERKNS0_4pathEPNS_6system10error_codeE
uintmax_t __fastcall boost::filesystem::detail::file_size(
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  const char *v3; // rsi
  _BOOL8 v4; // rbx
  bool v5; // bl
  uintmax_t v6; // r15
  int v7; // ebx
  const boost::system::error_category *v8; // r12
  boost::filesystem::filesystem_error *exception; // rbx
  __int128 v11; // [rsp+0h] [rbp-D8h] BYREF
  void *ptr; // [rsp+10h] [rbp-C8h]
  _BYTE v13[24]; // [rsp+20h] [rbp-B8h] BYREF
  int v14; // [rsp+38h] [rbp-A0h]
  uintmax_t v15; // [rsp+50h] [rbp-88h]
  boost::system::error_code v16; // 0:ecx.4,8:r8.8

  if ( (*(_BYTE *)p & 1) != 0 )
    v3 = (const char *)*((_QWORD *)p + 2);
  else
    v3 = (char *)p + 1;
  v4 = __xstat64(1, v3, (struct stat64 *)v13) != 0;
  ptr = operator new(0x20u);
  v11 = *(_OWORD *)&stru_3EB180.vtable;
  strcpy((char *)ptr, "boost::filesystem::file_size");
  v5 = `anonymous namespace'::error(v4, p, ec, (const std::string *)&v11);
  if ( (v11 & 1) != 0 )
    operator delete(ptr);
  v6 = -1;
  if ( !v5 )
  {
    v7 = v14 & 0xF000;
    v8 = boost::system::system_category();
    ptr = operator new(0x20u);
    v11 = *(_OWORD *)&stru_3EB180.vtable;
    strcpy((char *)ptr, "boost::filesystem::file_size");
    if ( v7 == 0x8000 )
    {
      if ( ec )
      {
        ec->m_val = 0;
        ec->m_cat = boost::system::system_category();
        if ( (v11 & 1) == 0 )
          return v15;
      }
    }
    else
    {
      if ( !ec )
      {
        exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
        v16.m_val = 1;
        v16.m_cat = v8;
        boost::filesystem::filesystem_error::filesystem_error(exception, (const std::string *)&v11, p, v16);
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
          (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
      }
      ec->m_val = 1;
      ec->m_cat = v8;
    }
    operator delete(ptr);
    if ( v7 == 0x8000 )
      return v15;
  }
  return v6;
}


// Address: 0x283bd20 | Name: _ZN5boost10filesystem6detail15hard_link_countERKNS0_4pathEPNS_6system10error_codeE
uintmax_t __fastcall boost::filesystem::detail::hard_link_count(
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  const char *v3; // rsi
  _BOOL8 v4; // rbp
  uintmax_t v5; // rbx
  __int128 v7; // [rsp+0h] [rbp-C8h] BYREF
  void *ptr; // [rsp+10h] [rbp-B8h]
  _BYTE v9[16]; // [rsp+20h] [rbp-A8h] BYREF
  uintmax_t v10; // [rsp+30h] [rbp-98h]

  if ( (*(_BYTE *)p & 1) != 0 )
    v3 = (const char *)*((_QWORD *)p + 2);
  else
    v3 = (char *)p + 1;
  v4 = __xstat64(1, v3, (struct stat64 *)v9) != 0;
  ptr = operator new(0x30u);
  v7 = xmmword_3EB1A0;
  strcpy((char *)ptr, "boost::filesystem::hard_link_count");
  if ( !`anonymous namespace'::error(v4, p, ec, (const std::string *)&v7) )
  {
    v5 = v10;
    if ( (v7 & 1) == 0 )
      return v5;
    goto LABEL_8;
  }
  v5 = 0;
  if ( (v7 & 1) != 0 )
LABEL_8:
    operator delete(ptr);
  return v5;
}


// Address: 0x283bdf0 | Name: _ZN5boost10filesystem6detail12initial_pathEPNS_6system10error_codeE
boost::filesystem::detail *__fastcall boost::filesystem::detail::initial_path(
        boost::filesystem::detail *this,
        boost::system::error_code *a2)
{
  int v2; // edx
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9
  _BYTE v7[16]; // [rsp+8h] [rbp-30h] BYREF
  void *ptr; // [rsp+18h] [rbp-20h]

  if ( !(_BYTE)byte_2CE5588 && __cxa_guard_acquire(&byte_2CE5588) )
  {
    xmmword_2CE5570 = 0;
    qword_2CE5580 = 0;
    __cxa_atexit((void (*)(void *))boost::filesystem::path::~path, &xmmword_2CE5570, &dso_handle);
    __cxa_guard_release(&byte_2CE5588);
  }
  if ( (xmmword_2CE5570 & 1) != 0 )
  {
    if ( *(&xmmword_2CE5570 + 1) )
      goto LABEL_4;
  }
  else if ( (unsigned __int64)xmmword_2CE5570 >> 1 )
  {
LABEL_4:
    if ( a2 )
    {
      a2->m_val = 0;
      a2->m_cat = boost::system::system_category();
    }
    goto LABEL_9;
  }
  boost::filesystem::detail::current_path((boost::filesystem::detail *)v7, a2);
  std::string::operator=((soap *)&xmmword_2CE5570, (int)v7, v2, v3, v4, v5);
  if ( (v7[0] & 1) != 0 )
    operator delete(ptr);
LABEL_9:
  std::string::basic_string(this, &xmmword_2CE5570);
  return this;
}


// Address: 0x283bf00 | Name: _ZN5boost10filesystem6detail8is_emptyERKNS0_4pathEPNS_6system10error_codeE
bool __fastcall boost::filesystem::detail::is_empty(const boost::filesystem::path *p, boost::system::error_code *ec)
{
  const char *v3; // rsi
  _BOOL8 v4; // rbx
  bool v5; // bl
  bool v6; // bl
  boost::filesystem::directory_iterator v7; // kr00_16
  __int128 v9; // [rsp+0h] [rbp-C8h] BYREF
  void *ptr; // [rsp+10h] [rbp-B8h]
  _BYTE v11[24]; // [rsp+20h] [rbp-A8h] BYREF
  int v12; // [rsp+38h] [rbp-90h]
  __int64 v13; // [rsp+50h] [rbp-78h]

  if ( (*(_BYTE *)p & 1) != 0 )
    v3 = (const char *)*((_QWORD *)p + 2);
  else
    v3 = (char *)p + 1;
  v4 = __xstat64(1, v3, (struct stat64 *)v11) != 0;
  ptr = operator new(0x20u);
  v9 = xmmword_3E5420;
  strcpy((char *)ptr, "boost::filesystem::is_empty");
  v5 = `anonymous namespace'::error(v4, p, ec, (const std::string *)&v9);
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
  if ( v5 )
    return 0;
  if ( (v12 & 0xF000) != 0x4000 )
    return v13 == 0;
  boost::filesystem::directory_iterator::directory_iterator((boost::filesystem::directory_iterator *)&v9, p);
  v7 = (boost::filesystem::directory_iterator)v9;
  v6 = (_QWORD)v9 == (_QWORD)xmmword_2CE5550;
  if ( *((_QWORD *)&v9 + 1) )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v9 + 1) + 8LL), 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7.m_imp.pn.pi_->_vptr$sp_counted_base + 2))(v7.m_imp.pn.pi_);
      if ( !_InterlockedSub(&v7.m_imp.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7.m_imp.pn.pi_->_vptr$sp_counted_base + 3))(v7.m_imp.pn.pi_);
    }
  }
  return v6;
}


// Address: 0x283c030 | Name: _ZN5boost10filesystem6detail15last_write_timeERKNS0_4pathEPNS_6system10error_codeE
time_t __fastcall boost::filesystem::detail::last_write_time(
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  const char *v3; // rsi
  _BOOL8 v4; // rbp
  bool v5; // bl
  time_t result; // rax
  __int128 v7; // [rsp+0h] [rbp-C8h] BYREF
  void *ptr; // [rsp+10h] [rbp-B8h]
  _BYTE v9[88]; // [rsp+20h] [rbp-A8h] BYREF
  time_t v10; // [rsp+78h] [rbp-50h]

  if ( (*(_BYTE *)p & 1) != 0 )
    v3 = (const char *)*((_QWORD *)p + 2);
  else
    v3 = (char *)p + 1;
  v4 = __xstat64(1, v3, (struct stat64 *)v9) != 0;
  ptr = operator new(0x30u);
  v7 = xmmword_3EB1A0;
  strcpy((char *)ptr, "boost::filesystem::last_write_time");
  v5 = `anonymous namespace'::error(v4, p, ec, (const std::string *)&v7);
  if ( (v7 & 1) != 0 )
    operator delete(ptr);
  result = -1;
  if ( !v5 )
    return v10;
  return result;
}


// Address: 0x283c100 | Name: _ZN5boost10filesystem6detail15last_write_timeERKNS0_4pathElPNS_6system10error_codeE
void __fastcall boost::filesystem::detail::last_write_time(
        const boost::filesystem::path *p,
        const time_t new_time,
        boost::system::error_code *ec)
{
  const char *v5; // r15
  const char *v6; // rsi
  _BOOL8 v7; // rbx
  bool v8; // bl
  _BOOL8 v9; // rbx
  __int128 v10; // [rsp+0h] [rbp-E8h] BYREF
  void *ptr; // [rsp+10h] [rbp-D8h]
  struct utimbuf file_times; // [rsp+20h] [rbp-C8h] BYREF
  _BYTE v13[72]; // [rsp+30h] [rbp-B8h] BYREF
  __time_t v14; // [rsp+78h] [rbp-70h]

  v5 = (char *)p + 1;
  v6 = (char *)p + 1;
  if ( (*(_BYTE *)p & 1) != 0 )
    v6 = (const char *)*((_QWORD *)p + 2);
  v7 = __xstat64(1, v6, (struct stat64 *)v13) != 0;
  ptr = operator new(0x30u);
  v10 = xmmword_3EB1A0;
  strcpy((char *)ptr, "boost::filesystem::last_write_time");
  v8 = `anonymous namespace'::error(v7, p, ec, (const std::string *)&v10);
  if ( (v10 & 1) != 0 )
    operator delete(ptr);
  if ( !v8 )
  {
    file_times.actime = v14;
    file_times.modtime = new_time;
    if ( (*(_BYTE *)p & 1) != 0 )
      v5 = (const char *)*((_QWORD *)p + 2);
    v9 = utime(v5, &file_times) != 0;
    ptr = operator new(0x30u);
    v10 = xmmword_3EB1A0;
    strcpy((char *)ptr, "boost::filesystem::last_write_time");
    `anonymous namespace'::error(v9, p, ec, (const std::string *)&v10);
    if ( (v10 & 1) != 0 )
      operator delete(ptr);
  }
}


// Address: 0x283c260 | Name: _ZN5boost10filesystem6detail11permissionsERKNS0_4pathENS0_5permsEPNS_6system10error_codeE
void __fastcall boost::filesystem::detail::permissions(
        const boost::filesystem::path *p,
        boost::filesystem::perms prms,
        boost::system::error_code *ec)
{
  boost::filesystem::perms v4; // ebp
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  boost::filesystem::perms v8; // eax
  const char *v9; // rdi
  int v10; // ebp
  const boost::system::error_category *v11; // rax
  boost::filesystem::filesystem_error *exception; // rbx
  boost::filesystem::filesystem_error *v13; // rbx
  int v14; // ebp
  const boost::system::error_category *v15; // rax
  __int128 v16; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  boost::system::error_code v18; // [rsp+20h] [rbp-28h] BYREF
  boost::system::error_code v19; // 0:ecx.4,8:r8.8

  if ( (prms & 0x3000) == 0x3000 )
    return;
  v4 = prms;
  v18.m_val = 0;
  v18.m_cat = boost::system::system_category();
  if ( (prms & 0x4000) != 0 )
  {
    v6 = (unsigned __int64)boost::filesystem::detail::symlink_status(p, &v18);
    if ( v18.m_val )
      goto LABEL_4;
  }
  else
  {
    v6 = (unsigned __int64)boost::filesystem::detail::status(p, &v18);
    if ( v18.m_val )
    {
LABEL_4:
      if ( !ec )
      {
        exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
        ptr = operator new(0x20u);
        v16 = *(_OWORD *)&stru_3E8880.vtable;
        strcpy((char *)ptr, "boost::filesystem::permissions");
        boost::filesystem::filesystem_error::filesystem_error(exception, (const std::string *)&v16, p, v18);
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
          (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
      }
      *ec = v18;
      return;
    }
  }
  v7 = HIDWORD(v6);
  if ( (prms & 0x1000) != 0 )
  {
    v8 = prms | v7;
  }
  else
  {
    if ( (prms & 0x2000) == 0 )
      goto LABEL_12;
    v8 = ~prms & v7;
  }
  v4 = v8;
LABEL_12:
  if ( (*(_BYTE *)p & 1) != 0 )
    v9 = (const char *)*((_QWORD *)p + 2);
  else
    v9 = (char *)p + 1;
  if ( chmod(v9, dword_2CE5590 & v4) )
  {
    if ( !ec )
    {
      v13 = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
      ptr = operator new(0x20u);
      v16 = *(_OWORD *)&stru_3E8880.vtable;
      strcpy((char *)ptr, "boost::filesystem::permissions");
      v14 = *__errno_location();
      v15 = boost::system::generic_category();
      v19.m_val = v14;
      v19.m_cat = v15;
      boost::filesystem::filesystem_error::filesystem_error(v13, (const std::string *)&v16, p, v19);
      __cxa_throw(
        v13,
        (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
        (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
    }
    v10 = *__errno_location();
    v11 = boost::system::generic_category();
    ec->m_val = v10;
    ec->m_cat = v11;
  }
}


// Address: 0x283c470 | Name: _ZN5boost10filesystem6detail6removeERKNS0_4pathEPNS_6system10error_codeE
bool __fastcall boost::filesystem::detail::remove(const boost::filesystem::path *p, boost::system::error_code *ec)
{
  boost::filesystem::file_type m_value; // ebx
  boost::filesystem::filesystem_error *exception; // rbx
  boost::system::error_code v5; // [rsp+0h] [rbp-48h] BYREF
  __int128 v6; // [rsp+10h] [rbp-38h] BYREF
  void *ptr; // [rsp+20h] [rbp-28h]

  v5.m_val = 0;
  v5.m_cat = boost::system::system_category();
  m_value = boost::filesystem::detail::symlink_status(p, &v5).m_value;
  ptr = operator new(0x20u);
  v6 = xmmword_3E5070;
  strcpy((char *)ptr, "boost::filesystem::remove");
  if ( m_value )
  {
    if ( ec )
    {
      ec->m_val = 0;
      ec->m_cat = boost::system::system_category();
      if ( (v6 & 1) == 0 )
        return `anonymous namespace'::remove_file_or_directory(p, m_value, ec);
    }
  }
  else
  {
    if ( !ec )
    {
      exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
      boost::filesystem::filesystem_error::filesystem_error(exception, (const std::string *)&v6, p, v5);
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
        (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
    }
    *ec = v5;
  }
  operator delete(ptr);
  if ( m_value )
    return `anonymous namespace'::remove_file_or_directory(p, m_value, ec);
  return 0;
}


// Address: 0x283c590 | Name: _ZN12_GLOBAL__N_124remove_file_or_directoryERKN5boost10filesystem4pathENS1_9file_typeEPNS0_6system10error_codeE
bool __fastcall `anonymous namespace'::remove_file_or_directory(
        const boost::filesystem::path *p,
        boost::filesystem::file_type type,
        boost::system::error_code *ec)
{
  const char *v5; // rdi
  const char *v6; // rdi
  _BOOL8 v7; // rbp
  bool v8; // al
  _BOOL8 v9; // rbp
  bool v10; // bl
  __int128 v12; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  if ( type == boost::filesystem::file_type::directory_file )
  {
    if ( (*(_BYTE *)p & 1) != 0 )
      v5 = (const char *)*((_QWORD *)p + 2);
    else
      v5 = (char *)p + 1;
    v7 = rmdir(v5) != 0;
    ptr = operator new(0x20u);
    v12 = xmmword_3E5070;
    strcpy((char *)ptr, "boost::filesystem::remove");
    v8 = `anonymous namespace'::error(v7, p, ec, (const std::string *)&v12);
  }
  else
  {
    if ( type == boost::filesystem::file_type::file_not_found )
    {
      if ( ec )
      {
        ec->m_val = 0;
        ec->m_cat = boost::system::system_category();
      }
      return 0;
    }
    if ( (*(_BYTE *)p & 1) != 0 )
      v6 = (const char *)*((_QWORD *)p + 2);
    else
      v6 = (char *)p + 1;
    v9 = unlink(v6) != 0;
    ptr = operator new(0x20u);
    v12 = xmmword_3E5070;
    strcpy((char *)ptr, "boost::filesystem::remove");
    v8 = `anonymous namespace'::error(v9, p, ec, (const std::string *)&v12);
  }
  v10 = v8;
  if ( (v12 & 1) != 0 )
    operator delete(ptr);
  return !v10;
}


// Address: 0x283c6d0 | Name: _ZN5boost10filesystem6detail10remove_allERKNS0_4pathEPNS_6system10error_codeE
uintmax_t __fastcall boost::filesystem::detail::remove_all(
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  boost::filesystem::file_type m_value; // ebx
  boost::filesystem::filesystem_error *exception; // rbx
  boost::system::error_code v5; // [rsp+0h] [rbp-48h] BYREF
  __int128 v6; // [rsp+10h] [rbp-38h] BYREF
  void *ptr; // [rsp+20h] [rbp-28h]

  v5.m_val = 0;
  v5.m_cat = boost::system::system_category();
  m_value = boost::filesystem::detail::symlink_status(p, &v5).m_value;
  ptr = operator new(0x20u);
  v6 = xmmword_3E9C50;
  strcpy((char *)ptr, "boost::filesystem::remove_all");
  if ( m_value == boost::filesystem::file_type::status_error )
  {
    if ( !ec )
    {
      exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
      boost::filesystem::filesystem_error::filesystem_error(exception, (const std::string *)&v6, p, v5);
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
        (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
    }
    *ec = v5;
LABEL_8:
    operator delete(ptr);
    if ( (unsigned int)m_value > boost::filesystem::file_type::file_not_found )
      return `anonymous namespace'::remove_all_aux(p, m_value, ec);
    return 0;
  }
  if ( !ec )
    goto LABEL_8;
  ec->m_val = 0;
  ec->m_cat = boost::system::system_category();
  if ( (v6 & 1) != 0 )
    goto LABEL_8;
  if ( (unsigned int)m_value > boost::filesystem::file_type::file_not_found )
    return `anonymous namespace'::remove_all_aux(p, m_value, ec);
  return 0;
}


// Address: 0x283c7f0 | Name: _ZN12_GLOBAL__N_114remove_all_auxERKN5boost10filesystem4pathENS1_9file_typeEPNS0_6system10error_codeE
uintmax_t __fastcall `anonymous namespace'::remove_all_aux(
        const boost::filesystem::path *p,
        boost::filesystem::file_type type,
        boost::system::error_code *ec)
{
  uintmax_t v4; // rbp
  boost::filesystem::file_type m_value; // eax
  int v6; // r13d
  boost::detail::sp_counted_base *pi; // r12
  boost::filesystem::directory_iterator it; // [rsp+8h] [rbp-40h] BYREF

  if ( type != boost::filesystem::file_type::directory_file )
  {
    v4 = 1;
LABEL_15:
    `anonymous namespace'::remove_file_or_directory(p, type, ec);
    return v4;
  }
  boost::filesystem::directory_iterator::directory_iterator(&it, p);
  v4 = 1;
  while ( 1 )
  {
    if ( it.m_imp.px == (boost::shared_ptr<boost::filesystem::detail::dir_itr_imp>::element_type *)xmmword_2CE5550 )
    {
      v6 = 2;
      goto LABEL_10;
    }
    m_value = boost::filesystem::detail::symlink_status((const boost::filesystem::path *)it.m_imp.px, ec).m_value;
    if ( ec )
    {
      if ( ec->m_val )
        break;
    }
    v4 += `anonymous namespace'::remove_all_aux((const boost::filesystem::path *)it.m_imp.px, m_value, ec);
    boost::filesystem::detail::directory_iterator_increment(&it, 0);
  }
  v6 = 1;
LABEL_10:
  pi = it.m_imp.pn.pi_;
  if ( it.m_imp.pn.pi_ )
  {
    if ( !_InterlockedSub(&it.m_imp.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  if ( v6 == 2 )
    goto LABEL_15;
  return v4;
}


// Address: 0x283c930 | Name: _ZN5boost10filesystem6detail6renameERKNS0_4pathES4_PNS_6system10error_codeE
void __fastcall boost::filesystem::detail::rename(
        const boost::filesystem::path *old_p,
        const boost::filesystem::path *new_p,
        boost::system::error_code *ec)
{
  const char *v6; // rdi
  const char *v7; // rsi
  _BOOL8 v8; // rbp
  __int128 v9; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  if ( (*(_BYTE *)old_p & 1) != 0 )
  {
    v6 = (const char *)*((_QWORD *)old_p + 2);
    if ( (*(_BYTE *)new_p & 1) == 0 )
    {
LABEL_3:
      v7 = (char *)new_p + 1;
      goto LABEL_6;
    }
  }
  else
  {
    v6 = (char *)old_p + 1;
    if ( (*(_BYTE *)new_p & 1) == 0 )
      goto LABEL_3;
  }
  v7 = (const char *)*((_QWORD *)new_p + 2);
LABEL_6:
  v8 = rename(v6, v7) != 0;
  ptr = operator new(0x20u);
  v9 = xmmword_3E5070;
  strcpy((char *)ptr, "boost::filesystem::rename");
  `anonymous namespace'::error(v8, old_p, new_p, ec, (const std::string *)&v9);
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x283c9f0 | Name: _ZN5boost10filesystem6detail11resize_fileERKNS0_4pathEmPNS_6system10error_codeE
void __fastcall boost::filesystem::detail::resize_file(
        const boost::filesystem::path *p,
        uintmax_t size,
        boost::system::error_code *ec)
{
  const char *v5; // rdi
  _BOOL8 v6; // rbp
  __int128 v7; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  if ( (*(_BYTE *)p & 1) != 0 )
    v5 = (const char *)*((_QWORD *)p + 2);
  else
    v5 = (char *)p + 1;
  v6 = truncate64(v5, size) != 0;
  ptr = operator new(0x20u);
  v7 = *(_OWORD *)&stru_3E8880.vtable;
  strcpy((char *)ptr, "boost::filesystem::resize_file");
  `anonymous namespace'::error(v6, p, ec, (const std::string *)&v7);
  if ( (v7 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x283caa0 | Name: _ZN5boost10filesystem6detail5spaceERKNS0_4pathEPNS_6system10error_codeE
boost::filesystem::space_info *__fastcall boost::filesystem::detail::space(
        boost::filesystem::space_info *__return_ptr retstr,
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  const char *v5; // rdi
  _BOOL8 v6; // rbp
  bool v7; // bl
  uintmax_t v8; // rcx
  uintmax_t v9; // rdi
  uintmax_t v10; // rsi
  __int128 v12; // [rsp+0h] [rbp-A8h] BYREF
  void *ptr; // [rsp+10h] [rbp-98h]
  struct statvfs64 buf; // [rsp+18h] [rbp-90h] BYREF

  if ( (*(_BYTE *)p & 1) != 0 )
    v5 = (const char *)*((_QWORD *)p + 2);
  else
    v5 = (char *)p + 1;
  v6 = statvfs64(v5, &buf) != 0;
  ptr = operator new(0x20u);
  v12 = *(_OWORD *)&userJoinData.vtable;
  strcpy((char *)ptr, "boost::filesystem::space");
  v7 = `anonymous namespace'::error(v6, p, ec, (const std::string *)&v12);
  if ( (v12 & 1) != 0 )
    operator delete(ptr);
  if ( v7 )
  {
    v8 = 0;
    v9 = 0;
    v10 = 0;
  }
  else
  {
    v10 = buf.f_frsize * buf.f_blocks;
    v9 = buf.f_frsize * buf.f_bfree;
    v8 = buf.f_bavail * buf.f_frsize;
  }
  retstr->available = v8;
  retstr->free = v9;
  retstr->capacity = v10;
  return retstr;
}


// Address: 0x283cb90 | Name: _ZN5boost10filesystem6detail6statusERKNS0_4pathEPNS_6system10error_codeE
boost::filesystem::file_status __fastcall boost::filesystem::detail::status(
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  const char *v3; // rsi
  int *v4; // rax
  int *v5; // r15
  int v6; // ebp
  const boost::system::error_category *v7; // rax
  __int64 v8; // rax
  __int64 v9; // rcx
  unsigned int v10; // edx
  boost::filesystem::filesystem_error *exception; // rbx
  int v12; // ebp
  const boost::system::error_category *v13; // rax
  __int128 v14; // [rsp+0h] [rbp-C8h] BYREF
  void *ptr; // [rsp+10h] [rbp-B8h]
  _BYTE v16[24]; // [rsp+18h] [rbp-B0h] BYREF
  int v17; // [rsp+30h] [rbp-98h]
  boost::system::error_code v19; // 0:ecx.4,8:r8.8

  if ( (*(_BYTE *)p & 1) != 0 )
    v3 = (const char *)*((_QWORD *)p + 2);
  else
    v3 = (char *)p + 1;
  if ( __xstat64(1, v3, (struct stat64 *)v16) )
  {
    v4 = __errno_location();
    v5 = v4;
    if ( ec )
    {
      v6 = *v4;
      v7 = boost::system::system_category();
      ec->m_val = v6;
      ec->m_cat = v7;
    }
    v8 = 0;
    v9 = 1;
    if ( *v5 != 2 && *v5 != 20 )
    {
      if ( !ec )
      {
        exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
        ptr = operator new(0x20u);
        v14 = xmmword_3E5070;
        strcpy((char *)ptr, "boost::filesystem::status");
        v12 = *v5;
        v13 = boost::system::system_category();
        v19.m_val = v12;
        v19.m_cat = v13;
        boost::filesystem::filesystem_error::filesystem_error(exception, (const std::string *)&v14, p, v19);
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
          (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
      }
      v8 = 0xFFFF;
      v9 = 0;
    }
  }
  else
  {
    if ( ec )
    {
      ec->m_val = 0;
      ec->m_cat = boost::system::system_category();
    }
    v8 = 0xFFFF;
    v9 = 10;
    switch ( ((v17 & 0xF000u) - 4096) >> 12 )
    {
      case 0u:
        v10 = v17 & 0xFFF;
        v9 = 7;
        goto LABEL_20;
      case 1u:
        v10 = v17 & 0xFFF;
        v9 = 6;
        goto LABEL_20;
      case 3u:
        v10 = v17 & 0xFFF;
        v9 = 3;
        goto LABEL_20;
      case 5u:
        v10 = v17 & 0xFFF;
        v9 = 5;
        goto LABEL_20;
      case 7u:
        v10 = v17 & 0xFFF;
        v9 = 2;
        goto LABEL_20;
      case 0xBu:
        v10 = v17 & 0xFFF;
        v9 = 8;
LABEL_20:
        v8 = v10;
        break;
      default:
        return (boost::filesystem::file_status)(v9 | (v8 << 32));
    }
  }
  return (boost::filesystem::file_status)(v9 | (v8 << 32));
}


// Address: 0x283cd70 | Name: _ZN5boost10filesystem6detail19temp_directory_pathEPNS_6system10error_codeE
boost::filesystem::detail *__fastcall boost::filesystem::detail::temp_directory_path(
        boost::filesystem::detail *this,
        boost::system::error_code *ec)
{
  char *v2; // rax
  const char *v3; // r12
  size_t v4; // rax
  size_t v5; // rbx
  char *v6; // r13
  size_t v7; // rbp
  unsigned __int64 v8; // rax
  boost::filesystem::file_type m_value; // eax
  struct _Unwind_Exception *v11; // rax
  struct _Unwind_Exception *v12; // rbx
  __int128 v13; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]

  v2 = getenv("TMPDIR");
  if ( !v2 )
  {
    v2 = getenv("TMP");
    if ( !v2 )
    {
      v2 = getenv("TEMP");
      if ( !v2 )
        v2 = getenv("TEMPDIR");
    }
  }
  v3 = "/tmp";
  if ( v2 )
    v3 = v2;
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v4 = strlen(v3);
  if ( v4 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(this);
    v12 = v11;
    if ( (*(_BYTE *)this & 1) != 0 )
    {
      operator delete(*((void **)this + 2));
      _Unwind_Resume(v12);
    }
    _Unwind_Resume(v11);
  }
  v5 = v4;
  if ( v4 >= 0x17 )
  {
    v7 = (v4 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v6 = (char *)operator new(v7);
    *((_QWORD *)this + 2) = v6;
    *(_QWORD *)this = v7 | 1;
    *((_QWORD *)this + 1) = v5;
    goto LABEL_12;
  }
  *(_BYTE *)this = 2 * v4;
  v6 = (char *)this + 1;
  if ( v4 )
LABEL_12:
    memcpy(v6, v3, v5);
  v6[v5] = 0;
  v8 = *(unsigned __int8 *)this;
  if ( (v8 & 1) != 0 )
  {
    if ( *((_QWORD *)this + 1) )
      goto LABEL_15;
LABEL_20:
    *__errno_location() = 20;
    ptr = operator new(0x30u);
    v13 = xmmword_3E6AA0;
    strcpy((char *)ptr, "boost::filesystem::temp_directory_path");
    `anonymous namespace'::error(1, this, ec, (const std::string *)&v13);
    if ( (v13 & 1) != 0 )
      operator delete(ptr);
    return this;
  }
  if ( !(v8 >> 1) )
    goto LABEL_20;
LABEL_15:
  if ( ec )
    m_value = boost::filesystem::detail::status(this, ec).m_value;
  else
    m_value = boost::filesystem::detail::status(this, 0).m_value;
  if ( m_value != boost::filesystem::file_type::directory_file )
    goto LABEL_20;
  return this;
}


// Address: 0x283cf70 | Name: _ZN5boost10filesystem6detail15system_completeERKNS0_4pathEPNS_6system10error_codeE
boost::filesystem::detail *__fastcall boost::filesystem::detail::system_complete(
        boost::filesystem::detail *this,
        const boost::filesystem::path *a2,
        boost::system::error_code *a3)
{
  unsigned __int64 v3; // rax
  boost::filesystem::path *v4; // rax
  __int64 v5; // r15
  _BYTE v7[8]; // [rsp+0h] [rbp-48h] BYREF
  __int64 v8; // [rsp+8h] [rbp-40h]
  void *ptr; // [rsp+10h] [rbp-38h]
  _BYTE v10[16]; // [rsp+18h] [rbp-30h] BYREF
  void *v11; // [rsp+28h] [rbp-20h]

  v3 = *(unsigned __int8 *)a2;
  if ( (v3 & 1) != 0 )
  {
    if ( !*((_QWORD *)a2 + 1) )
      goto LABEL_12;
  }
  else if ( !(v3 >> 1) )
  {
    goto LABEL_12;
  }
  boost::filesystem::path::root_directory((boost::filesystem::path *)v7);
  if ( (v7[0] & 1) != 0 )
  {
    v5 = v8;
    operator delete(ptr);
    if ( !v5 )
      goto LABEL_7;
LABEL_12:
    std::string::basic_string(this, a2);
    return this;
  }
  if ( v7[0] > 1u )
    goto LABEL_12;
LABEL_7:
  boost::filesystem::detail::current_path((boost::filesystem::detail *)v10, 0);
  std::string::basic_string(v7, v10);
  v4 = boost::filesystem::path::operator/=((boost::filesystem::path *)v7, a2);
  std::string::basic_string(this, v4);
  if ( (v7[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v10[0] & 1) != 0 )
    operator delete(v11);
  return this;
}


// Address: 0x283d080 | Name: _ZNK5boost10filesystem15directory_entry12m_get_statusEPNS_6system10error_codeE
boost::filesystem::file_status __fastcall boost::filesystem::directory_entry::m_get_status(
        const boost::filesystem::directory_entry *this,
        boost::system::error_code *ec)
{
  unsigned __int64 v2; // rax
  __int64 v3; // rax

  v2 = *((_QWORD *)this + 3);
  if ( HIDWORD(v2) != 0xFFFF && (_DWORD)v2 )
  {
    if ( !ec )
      return (boost::filesystem::file_status)*((_QWORD *)this + 3);
LABEL_8:
    ec->m_val = 0;
    ec->m_cat = boost::system::system_category();
    return (boost::filesystem::file_status)*((_QWORD *)this + 3);
  }
  v3 = *((_QWORD *)this + 4);
  if ( (v3 & 0xFFFFFFFF00000000LL) == 0xFFFF00000000LL || ((unsigned int)v3 | 4) == 4 )
  {
    *((boost::filesystem::file_status *)this + 3) = boost::filesystem::detail::status(this, ec);
    return (boost::filesystem::file_status)*((_QWORD *)this + 3);
  }
  *((_QWORD *)this + 3) = v3;
  if ( ec )
    goto LABEL_8;
  return (boost::filesystem::file_status)*((_QWORD *)this + 3);
}


// Address: 0x283d110 | Name: _ZNK5boost10filesystem15directory_entry20m_get_symlink_statusEPNS_6system10error_codeE
boost::filesystem::file_status __fastcall boost::filesystem::directory_entry::m_get_symlink_status(
        const boost::filesystem::directory_entry *this,
        boost::system::error_code *ec)
{
  boost::filesystem::file_status result; // 0:rax.8

  result = (boost::filesystem::file_status)*((_QWORD *)this + 4);
  if ( HIDWORD(*(unsigned __int64 *)&result) == 0xFFFF || result.m_value == boost::filesystem::file_type::status_error )
  {
    result = boost::filesystem::detail::symlink_status(this, ec);
    *((boost::filesystem::file_status *)this + 4) = result;
  }
  else if ( ec )
  {
    ec->m_val = 0;
    ec->m_cat = boost::system::system_category();
    return (boost::filesystem::file_status)*((_QWORD *)this + 4);
  }
  return result;
}


// Address: 0x283d170 | Name: _ZN5boost10filesystem11path_traits8dispatchERKNS0_15directory_entryERNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEERKNS5_7codecvtIwc11__mbstate_tEE
void __fastcall boost::filesystem::path_traits::dispatch(
        const boost::filesystem::directory_entry *de,
        std::string *to,
        const boost::filesystem::path_traits::codecvt_type *a3)
{
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9

  std::string::operator=((soap *)to, (int)de, (int)a3, v3, v4, v5);
}


// Address: 0x283d180 | Name: _ZN5boost10filesystem11path_traits8dispatchERKNS0_15directory_entryERNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEE
void __fastcall boost::filesystem::path_traits::dispatch(const boost::filesystem::directory_entry *de, std::string *to)
{
  int v2; // edx
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9

  std::string::operator=((soap *)to, (int)de, v2, v3, v4, v5);
}


// Address: 0x283d190 | Name: _ZN5boost10filesystem6detail13dir_itr_closeERPvS3_
boost::system::error_code __fastcall boost::filesystem::detail::dir_itr_close(void **handle, void **buffer)
{
  void *v3; // rdi
  int m_val; // ebx
  boost::system::error_code result; // 0:eax.4,8:rdx.8

  free(*buffer);
  *buffer = 0;
  v3 = *handle;
  if ( v3 )
  {
    *handle = 0;
    if ( closedir(v3) )
      m_val = *__errno_location();
    else
      m_val = 0;
    result.m_cat = boost::system::system_category();
  }
  else
  {
    m_val = stru_2CE5560.m_val;
    result.m_cat = stru_2CE5560.m_cat;
  }
  result.m_val = m_val;
  return result;
}


// Address: 0x283d1f0 | Name: _ZN5boost10filesystem6detail28directory_iterator_constructERNS0_18directory_iteratorERKNS0_4pathEPNS_6system10error_codeE
void __fastcall boost::filesystem::detail::directory_iterator_construct(
        boost::filesystem::directory_iterator *it,
        const boost::filesystem::path *p,
        boost::system::error_code *ec)
{
  unsigned __int64 v5; // rbx
  unsigned __int64 v6; // rbx
  char *v7; // rax
  char *v8; // rbp
  _QWORD *px; // rbp
  const char *v10; // rdi
  char *v11; // rdi
  DIR *v12; // rax
  int m_val; // r13d
  const boost::system::error_category *m_cat; // rbx
  const boost::system::error_category *v15; // rax
  boost::detail::sp_counted_base *pi; // rbp
  __int128 v17; // xmm0
  char *v18; // rax
  char *v19; // rbp
  boost::system::error_code *v20; // rbx
  boost::filesystem::path *v21; // rax
  int v22; // edx
  void *v23; // rcx
  size_t v24; // r8
  const void *v25; // r9
  char *v26; // rcx
  unsigned __int64 v27; // rax
  boost::detail::sp_counted_base *v28; // rbx
  boost::filesystem::filesystem_error *v29; // rbp
  boost::filesystem::filesystem_error *exception; // rbp
  _OWORD v31[2]; // [rsp+0h] [rbp-A8h] BYREF
  _BYTE v32[16]; // [rsp+20h] [rbp-88h] BYREF
  void *v33; // [rsp+30h] [rbp-78h]
  _BYTE v34[16]; // [rsp+38h] [rbp-70h] BYREF
  void *v35; // [rsp+48h] [rbp-60h]
  _BYTE v36[24]; // [rsp+50h] [rbp-58h] BYREF
  unsigned __int64 v37; // [rsp+70h] [rbp-38h]
  boost::system::error_code v38; // 0:ecx.4,8:r8.8

  v37 = __readfsqword(0x28u);
  v5 = *(unsigned __int8 *)p;
  if ( (v5 & 1) != 0 )
    v6 = *((_QWORD *)p + 1);
  else
    v6 = v5 >> 1;
  v7 = (char *)operator new(0x40u);
  v8 = v7;
  *(_QWORD *)&v36[16] = v7;
  *(_OWORD *)v36 = xmmword_3E67B0;
  strcpy(v7, "boost::filesystem::directory_iterator::construct");
  if ( !v6 )
  {
    if ( !ec )
    {
      exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
      boost::filesystem::filesystem_error::filesystem_error(exception, (const std::string *)v36, p, stru_2CE5598);
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
        (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
    }
    *ec = stru_2CE5598;
    v11 = v7;
    goto LABEL_25;
  }
  if ( ec )
  {
    ec->m_val = 0;
    ec->m_cat = boost::system::system_category();
  }
  operator delete(v8);
  memset(v31, 0, 24);
  px = it->m_imp.px;
  if ( (*(_BYTE *)p & 1) != 0 )
    v10 = (const char *)*((_QWORD *)p + 2);
  else
    v10 = (char *)p + 1;
  v12 = opendir(v10);
  px[5] = v12;
  if ( v12 )
  {
    memset(v36, 0, 21);
    LOWORD(v31[0]) = 0;
    std::string::reserve(v31, 0);
    LOWORD(v31[0]) = 11778;
    BYTE2(v31[0]) = 0;
    *(_OWORD *)((char *)v31 + 3) = *(_OWORD *)v36;
    *(_QWORD *)&v31[1] = *(_QWORD *)&v36[13];
    m_val = stru_2CE5560.m_val;
    if ( stru_2CE5560.m_val )
    {
      m_cat = stru_2CE5560.m_cat;
      goto LABEL_17;
    }
    px[6] = malloc(0x1019u);
  }
  else
  {
    m_val = *__errno_location();
    v15 = boost::system::system_category();
    if ( m_val )
    {
      m_cat = v15;
LABEL_17:
      pi = it->m_imp.pn.pi_;
      v17 = 0;
      *it = 0;
      if ( pi )
      {
        if ( !_InterlockedSub(&pi->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          v17 = 0;
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          {
            (*((void (__fastcall **)(boost::detail::sp_counted_base *, double))pi->_vptr$sp_counted_base + 3))(pi, 0.0);
            v17 = 0;
          }
        }
      }
      *(_OWORD *)v36 = v17;
      *(_QWORD *)&v36[16] = 0;
      v18 = (char *)operator new(0x40u);
      *(_QWORD *)&v36[16] = v18;
      *(_OWORD *)v36 = xmmword_3E67B0;
      strcpy(v18, "boost::filesystem::directory_iterator::construct");
      if ( !ec )
      {
        v29 = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
        v38.m_val = m_val;
        v38.m_cat = m_cat;
        boost::filesystem::filesystem_error::filesystem_error(v29, (const std::string *)v36, p, v38);
        __cxa_throw(
          v29,
          (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
          (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
      }
      ec->m_val = m_val;
      ec->m_cat = m_cat;
      operator delete(v18);
      goto LABEL_23;
    }
  }
  v19 = (char *)it->m_imp.px;
  if ( !*((_QWORD *)it->m_imp.px + 5) )
  {
    v28 = it->m_imp.pn.pi_;
    *it = 0;
    if ( v28 )
    {
      if ( !_InterlockedSub(&v28->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v28->_vptr$sp_counted_base + 2))(v28);
        if ( !_InterlockedSub(&v28->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v28->_vptr$sp_counted_base + 3))(v28);
      }
    }
    goto LABEL_23;
  }
  std::string::basic_string(v32, v31);
  std::string::basic_string(v36, p);
  v20 = (boost::system::error_code *)v36;
  v21 = boost::filesystem::path::operator/=((boost::filesystem::path *)v36, (const boost::filesystem::path *)v32);
  std::string::basic_string(v34, v21);
  if ( (v36[0] & 1) != 0 )
    operator delete(*(void **)&v36[16]);
  std::string::operator=((soap *)v19, (int)v34, v22, v23, v24, v25);
  *(_OWORD *)(v19 + 24) = xmmword_3E5E60;
  if ( (v34[0] & 1) != 0 )
    operator delete(v35);
  if ( (v32[0] & 1) != 0 )
    operator delete(v33);
  if ( (v31[0] & 1) != 0 )
  {
    v26 = *(char **)&v31[1];
    if ( **(_BYTE **)&v31[1] != 46 )
      goto LABEL_23;
  }
  else
  {
    v26 = (char *)v31 + 1;
    if ( BYTE1(v31[0]) != 46 )
      goto LABEL_23;
  }
  if ( (v31[0] & 1) != 0 )
  {
    v27 = *((_QWORD *)&v31[0] + 1);
    if ( *((_QWORD *)&v31[0] + 1) == 1 )
      goto LABEL_49;
  }
  else
  {
    v27 = (unsigned __int64)LOBYTE(v31[0]) >> 1;
    if ( v27 == 1 )
    {
LABEL_49:
      *(_DWORD *)v36 = 0;
      *(_QWORD *)&v36[8] = boost::system::system_category();
      if ( ec )
        v20 = ec;
      boost::filesystem::detail::directory_iterator_increment(it, v20);
      goto LABEL_23;
    }
  }
  if ( v26[1] == 46 && v27 == 2 )
    goto LABEL_49;
LABEL_23:
  if ( (v31[0] & 1) == 0 )
    return;
  v11 = *(char **)&v31[1];
LABEL_25:
  operator delete(v11);
}


// Address: 0x283d6a0 | Name: _ZN5boost10filesystem6detail28directory_iterator_incrementERNS0_18directory_iteratorEPNS_6system10error_codeE
void __fastcall boost::filesystem::detail::directory_iterator_increment(
        boost::filesystem::directory_iterator *it,
        boost::system::error_code *ec)
{
  int *v4; // r14
  boost::shared_ptr<boost::filesystem::detail::dir_itr_imp>::element_type *px; // rbp
  struct dirent64 *v6; // r13
  DIR *v7; // r12
  int v8; // ebp
  char *v9; // rcx
  unsigned __int64 v10; // rax
  struct dirent64 *v11; // rax
  DIR *v12; // rdi
  unsigned __int8 v13; // al
  unsigned int v14; // ecx
  unsigned int v15; // edx
  boost::shared_ptr<boost::filesystem::detail::dir_itr_imp>::element_type *v16; // rsi
  boost::detail::sp_counted_base *v17; // rbp
  int v18; // ebp
  const boost::system::error_category *v19; // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::filesystem::filesystem_error *exception; // rbp
  int v22; // ebx
  const boost::system::error_category *v23; // rax
  unsigned int v24; // [rsp+0h] [rbp-88h]
  unsigned int v25; // [rsp+4h] [rbp-84h]
  struct dirent64 *result[3]; // [rsp+8h] [rbp-80h] BYREF
  __int128 v27; // [rsp+20h] [rbp-68h] BYREF
  void *v28; // [rsp+30h] [rbp-58h]
  __int128 v29; // [rsp+40h] [rbp-48h] BYREF
  void *v30; // [rsp+50h] [rbp-38h]
  boost::system::error_code v31; // 0:ecx.4,8:r8.8

  v27 = 0;
  v28 = 0;
  boost::system::system_category();
  v4 = __errno_location();
  px = it->m_imp.px;
  v25 = 0;
  v24 = 0;
  while ( 1 )
  {
    v6 = (struct dirent64 *)*((_QWORD *)px + 6);
    v7 = (DIR *)*((_QWORD *)px + 5);
    *v4 = 0;
    if ( sysconf(68) < 0 )
    {
      result[0] = 0;
      v11 = readdir64(v7);
      if ( v11 )
      {
        strcpy(v6->d_name, v11->d_name);
        result[0] = v6;
        if ( v6 )
          goto LABEL_26;
        goto LABEL_21;
      }
      if ( *v4 )
        goto LABEL_4;
    }
    else if ( readdir64_r(v7, v6, result) )
    {
      goto LABEL_4;
    }
    if ( result[0] )
    {
LABEL_26:
      std::string::assign(&v27, v6->d_name);
      v13 = __ROR1__(v6->d_type, 1) - 2;
      v14 = 0;
      v15 = 0;
      if ( v13 <= 3u )
      {
        v14 = dword_3E6DA0[(char)v13];
        v15 = dword_3EA420[(char)v13];
      }
      v24 = v15;
      v25 = v14;
      goto LABEL_29;
    }
LABEL_21:
    free(*((void **)px + 6));
    *((_QWORD *)px + 6) = 0;
    v12 = (DIR *)*((_QWORD *)px + 5);
    if ( v12 )
    {
      *((_QWORD *)px + 5) = 0;
      if ( closedir(v12) )
LABEL_4:
        v8 = *v4;
      else
        v8 = 0;
      boost::system::system_category();
      if ( v8 )
        break;
      goto LABEL_6;
    }
LABEL_29:
    if ( stru_2CE5560.m_val )
      break;
LABEL_6:
    if ( ec )
    {
      ec->m_val = 0;
      ec->m_cat = boost::system::system_category();
    }
    px = it->m_imp.px;
    if ( !*((_QWORD *)it->m_imp.px + 5) )
    {
      pi = it->m_imp.pn.pi_;
      *it = 0;
      if ( pi )
      {
        if ( !_InterlockedSub(&pi->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
      }
      goto LABEL_44;
    }
    v9 = (char *)&v27 + 1;
    if ( (v27 & 1) != 0 )
      v9 = (char *)v28;
    if ( *v9 != 46 )
    {
LABEL_37:
      std::string::basic_string(result, &v27);
      boost::filesystem::path::remove_filename((boost::filesystem::path *)px);
      boost::filesystem::path::operator/=((boost::filesystem::path *)px, (const boost::filesystem::path *)result);
      *((_QWORD *)px + 3) = v24 | 0xFFFF00000000LL;
      *((_QWORD *)px + 4) = v25 | 0xFFFF00000000LL;
      if ( ((__int64)result[0] & 1) == 0 )
        goto LABEL_44;
LABEL_38:
      operator delete(result[2]);
      if ( (v27 & 1) == 0 )
        return;
      goto LABEL_45;
    }
    if ( (v27 & 1) != 0 )
    {
      v10 = *((_QWORD *)&v27 + 1);
      if ( *((_QWORD *)&v27 + 1) != 1 )
        goto LABEL_14;
    }
    else
    {
      v10 = (unsigned __int64)(unsigned __int8)v27 >> 1;
      if ( v10 != 1 )
      {
LABEL_14:
        if ( v9[1] != 46 || v10 != 2 )
          goto LABEL_37;
      }
    }
  }
  v16 = it->m_imp.px;
  boost::filesystem::path::parent_path((boost::filesystem::path *)result);
  v17 = it->m_imp.pn.pi_;
  *it = 0;
  if ( v17 )
  {
    if ( !_InterlockedSub(&v17->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, boost::shared_ptr<boost::filesystem::detail::dir_itr_imp>::element_type *))v17->_vptr$sp_counted_base
       + 2))(
        v17,
        v16);
      if ( !_InterlockedSub(&v17->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
    }
  }
  if ( !ec )
  {
    exception = (boost::filesystem::filesystem_error *)__cxa_allocate_exception(0x48u);
    v29 = 0;
    v30 = 0;
    v30 = operator new(0x40u);
    v29 = xmmword_3EA820;
    strcpy((char *)v30, "boost::filesystem::directory_iterator::operator++");
    v22 = *v4;
    v23 = boost::system::system_category();
    v31.m_val = v22;
    v31.m_cat = v23;
    boost::filesystem::filesystem_error::filesystem_error(
      exception,
      (const std::string *)&v29,
      (const boost::filesystem::path *)result,
      v31);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::filesystem::filesystem_error,
      (void (*)(void *))boost::filesystem::filesystem_error::~filesystem_error);
  }
  v18 = *v4;
  v19 = boost::system::system_category();
  ec->m_val = v18;
  ec->m_cat = v19;
  if ( ((__int64)result[0] & 1) != 0 )
    goto LABEL_38;
LABEL_44:
  if ( (v27 & 1) == 0 )
    return;
LABEL_45:
  operator delete(v28);
}


// Address: 0x283e9f0 | Name: _GLOBAL__sub_I_operations.cpp
void __cdecl GLOBAL__sub_I_operations_cpp()
{
  const boost::system::error_category *v0; // rax

  xmmword_2CE5550 = 0;
  __cxa_atexit(
    (void (*)(void *))boost::filesystem::directory_iterator::~directory_iterator,
    &xmmword_2CE5550,
    &dso_handle);
  stru_2CE5560.m_val = 0;
  stru_2CE5560.m_cat = boost::system::system_category();
  dword_2CE5590 = 4095;
  v0 = boost::system::system_category();
  stru_2CE5598.m_val = 2;
  stru_2CE5598.m_cat = v0;
}


