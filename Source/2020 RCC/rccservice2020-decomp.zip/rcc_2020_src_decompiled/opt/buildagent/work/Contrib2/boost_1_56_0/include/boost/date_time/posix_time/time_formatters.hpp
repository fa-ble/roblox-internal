// Address: 0x186c040 | Name: _ZN5boost10posix_time21to_simple_string_typeIcEENSt3__112basic_stringIT_NS2_11char_traitsIS4_EENS2_9allocatorIS4_EEEENS0_13time_durationE
__int64 __fastcall boost::posix_time::to_simple_string_type<char>(__int64 a1, __int64 *a2)
{
  __int64 v4; // rcx
  __int64 (__fastcall **v5)(); // rax
  __int64 v6; // rsi
  std::ostream *v7; // rax
  __int64 (__fastcall **v8)(); // rax
  unsigned int v9; // edi
  __int64 v10; // rsi
  std::ostream *v11; // rax
  __int64 (__fastcall **v12)(); // rax
  unsigned int v13; // ecx
  __int64 v14; // rsi
  __int64 v15; // rcx
  __int64 v16; // rbx
  std::ostream *v17; // rax
  __int64 v18; // rcx
  char __str; // [rsp+Fh] [rbp-139h] BYREF
  __int64 (__fastcall **v21)(); // [rsp+10h] [rbp-138h] BYREF
  _QWORD v22[8]; // [rsp+18h] [rbp-130h] BYREF
  __int128 v23; // [rsp+58h] [rbp-F0h]
  void *ptr[2]; // [rsp+68h] [rbp-E0h]
  int v25; // [rsp+78h] [rbp-D0h]
  _QWORD v26[18]; // [rsp+80h] [rbp-C8h] BYREF
  int v27; // [rsp+110h] [rbp-38h]

  v26[0] = &off_2876B60;
  std::ios_base::init((std::ios_base *)v26, v22);
  v26[17] = 0;
  v27 = -1;
  v21 = &off_2876AC8;
  v26[0] = off_2876AF0;
  std::streambuf::basic_streambuf(v22);
  v22[0] = &off_28753A8;
  *(_OWORD *)ptr = 0;
  v23 = 0;
  v25 = 16;
  v4 = *a2;
  if ( *a2 == 0x8000000000000000LL )
  {
    std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v21, "-infinity", 9u);
  }
  else if ( v4 == 0x7FFFFFFFFFFFFFFELL )
  {
    std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v21, "not-a-date-time", 0xFu);
  }
  else if ( v4 == 0x7FFFFFFFFFFFFFFFLL )
  {
    std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v21, "+infinity", 9u);
  }
  else
  {
    if ( v4 < 0 )
    {
      __str = 45;
      std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v21, &__str, 1u);
      v4 = *a2;
    }
    v5 = v21;
    *(_QWORD *)((char *)&v22[2] + (_QWORD)*(v21 - 3)) = 2;
    *(_DWORD *)((char *)&v26[4] + (_QWORD)*(v5 - 3)) = 48;
    v6 = (unsigned int)((int)v4 / 694967296);
    if ( (int)v4 / 694967296 < 1 )
      v6 = (unsigned int)((int)v4 / -694967296);
    v7 = (std::ostream *)std::ostream::operator<<(&v21, v6);
    std::__put_character_sequence<char,std::char_traits<char>>(v7, ":", 1u);
    v8 = v21;
    *(_QWORD *)((char *)&v22[2] + (_QWORD)*(v21 - 3)) = 2;
    *(_DWORD *)((char *)&v26[4] + (_QWORD)*(v8 - 3)) = 48;
    v9 = (int)(*a2 / 60000000) % 60;
    v10 = -v9;
    if ( (signed int)-v9 < 1 )
      v10 = v9;
    v11 = (std::ostream *)std::ostream::operator<<(&v21, v10);
    std::__put_character_sequence<char,std::char_traits<char>>(v11, ":", 1u);
    v12 = v21;
    *(_QWORD *)((char *)&v22[2] + (_QWORD)*(v21 - 3)) = 2;
    *(_DWORD *)((char *)&v26[4] + (_QWORD)*(v12 - 3)) = 48;
    v13 = (int)(*a2 / 1000000) % 60;
    v14 = -v13;
    if ( (signed int)-v13 < 1 )
      v14 = v13;
    std::ostream::operator<<(&v21, v14);
    v15 = *a2 % 1000000;
    v16 = 1000000 * (*a2 / 1000000) - *a2;
    if ( v16 < 1 )
      v16 = v15;
    if ( v16 )
    {
      v17 = std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v21, ".", 1u);
      v18 = *(_QWORD *)v17;
      *(_QWORD *)((char *)v17 + *(_QWORD *)(*(_QWORD *)v17 - 24LL) + 24) = 6;
      *(_DWORD *)((char *)v17 + *(_QWORD *)(v18 - 24) + 144) = 48;
      std::ostream::operator<<(v17, v16);
    }
  }
  std::stringbuf::str(a1, (__int64)v22);
  v21 = &off_2876AC8;
  v26[0] = off_2876AF0;
  v22[0] = &off_28753A8;
  if ( (v23 & 1) != 0 )
    operator delete(ptr[0]);
  std::streambuf::~streambuf();
  std::ostream::~ostream(&v21, data);
  std::ios::~ios();
  return a1;
}


