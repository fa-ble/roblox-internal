// Address: 0x25f7a40 | Name: _ZN5boost4asio6detail16service_registry6createINS0_23socket_acceptor_serviceINS0_2ip3tcpEEEEEPNS0_10io_service7serviceERS8_
boost::asio::io_service::service *__fastcall boost::asio::detail::service_registry::create<boost::asio::socket_acceptor_service<boost::asio::ip::tcp>>(
        boost::asio::io_service *owner)
{
  char *v1; // rbx
  boost::asio::detail::service_registry *service_registry; // rdi
  boost::asio::io_service::service *v3; // rax
  boost::asio::io_service::service::key_0 key; // [rsp+8h] [rbp-20h] BYREF

  v1 = (char *)operator new(0x30u);
  *(_OWORD *)(v1 + 8) = 0;
  *((_QWORD *)v1 + 3) = owner;
  *((_QWORD *)v1 + 4) = 0;
  *(_QWORD *)v1 = &off_29C2A08;
  service_registry = owner->service_registry_;
  key.type_info_ = (const std::type_info *)&`typeinfo for'boost::asio::detail::typeid_wrapper<boost::asio::detail::epoll_reactor>;
  key.id_ = 0;
  v3 = boost::asio::detail::service_registry::do_use_service(
         service_registry,
         &key,
         boost::asio::detail::service_registry::create<boost::asio::detail::epoll_reactor>);
  *((_QWORD *)v1 + 5) = v3;
  boost::asio::detail::task_io_service::init_task((boost::asio::detail::task_io_service_0 *)v3[1]._vptr$service);
  return (boost::asio::io_service::service *)v1;
}


// Address: 0x25f7c30 | Name: _ZN5boost4asio6detail16service_registry6createINS1_13epoll_reactorEEEPNS0_10io_service7serviceERS5_
boost::asio::io_service::service *__fastcall boost::asio::detail::service_registry::create<boost::asio::detail::epoll_reactor>(
        boost::asio::io_service *owner)
{
  boost::asio::detail::epoll_reactor *v1; // rbx

  v1 = (boost::asio::detail::epoll_reactor *)operator new(0xB0u);
  boost::asio::detail::epoll_reactor::epoll_reactor(v1, owner);
  return v1;
}


// Address: 0x25f9320 | Name: _ZN5boost4asio6detail16service_registryC2INS1_15task_io_serviceEmEERNS0_10io_serviceEPT_T0_
void __fastcall boost::asio::detail::service_registry::service_registry<boost::asio::detail::task_io_service,unsigned long>(
        boost::asio::detail::service_registry *this,
        boost::asio::io_service *o,
        boost::asio::detail::task_io_service_0 *a3,
        unsigned __int64 arg)
{
  int v5; // ebx
  const boost::system::error_category *v6; // rax
  boost::asio::detail::task_io_service_0 *v7; // rbx
  const boost::system::error_category *v8; // rbp
  _QWORD v9[2]; // [rsp+0h] [rbp-68h] BYREF
  int v10; // [rsp+10h] [rbp-58h]
  const boost::system::error_category *v11; // [rsp+18h] [rbp-50h]
  __int128 v12; // [rsp+20h] [rbp-48h]
  void *ptr; // [rsp+30h] [rbp-38h]

  v5 = pthread_mutex_init(&this->mutex_.mutex_, 0);
  v6 = boost::system::system_category();
  if ( v5 )
  {
    v8 = v6;
    std::runtime_error::runtime_error((std::runtime_error *)v9, "mutex");
    v9[0] = off_2875F00;
    v10 = v5;
    v11 = v8;
    v12 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v9);
  }
  this->owner_ = o;
  v7 = (boost::asio::detail::task_io_service_0 *)operator new(0xD8u);
  boost::asio::detail::task_io_service::task_io_service(v7, o, arg);
  this->first_service_ = v7;
  v7->key_.type_info_ = (const std::type_info *)&`typeinfo for'boost::asio::detail::typeid_wrapper<boost::asio::detail::task_io_service>;
  v7->key_.id_ = 0;
  v7->next_ = 0;
}


// Address: 0x2605740 | Name: _ZN5boost4asio6detail16service_registry6createINS0_22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS6_EEEEEEPNS0_10io_service7serviceERSA_
boost::asio::io_service::service *__fastcall boost::asio::detail::service_registry::create<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>(
        boost::asio::io_service *owner)
{
  char *v1; // rbx

  v1 = (char *)operator new(0x70u);
  *(_OWORD *)(v1 + 8) = 0;
  *((_QWORD *)v1 + 3) = owner;
  *((_QWORD *)v1 + 4) = 0;
  *(_QWORD *)v1 = &off_29C3118;
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::deadline_timer_service(
    (boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *)(v1 + 40),
    owner);
  return (boost::asio::io_service::service *)v1;
}


// Address: 0x26191f0 | Name: _ZN5boost4asio6detail16service_registry6createINS1_14strand_serviceEEEPNS0_10io_service7serviceERS5_
boost::asio::io_service::service *__fastcall boost::asio::detail::service_registry::create<boost::asio::detail::strand_service>(
        boost::asio::io_service *owner)
{
  char *v1; // rbx
  int v2; // ebp
  const boost::system::error_category *v3; // rax
  const boost::system::error_category *v5; // r14
  _QWORD v6[2]; // [rsp+0h] [rbp-58h] BYREF
  int v7; // [rsp+10h] [rbp-48h]
  const boost::system::error_category *v8; // [rsp+18h] [rbp-40h]
  __int128 v9; // [rsp+20h] [rbp-38h]
  void *ptr; // [rsp+30h] [rbp-28h]

  v1 = (char *)operator new(0x668u);
  *(_OWORD *)(v1 + 8) = 0;
  *((_QWORD *)v1 + 3) = owner;
  *((_QWORD *)v1 + 4) = 0;
  *(_QWORD *)v1 = off_29C38E8;
  *((_QWORD *)v1 + 5) = owner->impl_;
  v2 = pthread_mutex_init((pthread_mutex_t *)(v1 + 48), 0);
  v3 = boost::system::system_category();
  if ( v2 )
  {
    v5 = v3;
    std::runtime_error::runtime_error((std::runtime_error *)v6, "mutex");
    v6[0] = off_2875F00;
    v7 = v2;
    v8 = v5;
    v9 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v6);
  }
  memset(v1 + 88, 0, 0x610u);
  return (boost::asio::io_service::service *)v1;
}


// Address: 0x261a6a0 | Name: _ZN5boost4asio6detail16service_registry6createINS0_21stream_socket_serviceINS0_2ip3tcpEEEEEPNS0_10io_service7serviceERS8_
boost::asio::io_service::service *__fastcall boost::asio::detail::service_registry::create<boost::asio::stream_socket_service<boost::asio::ip::tcp>>(
        boost::asio::io_service *owner)
{
  char *v1; // rbx
  boost::asio::detail::service_registry *service_registry; // rdi
  boost::asio::io_service::service *v3; // rax
  boost::asio::io_service::service::key_0 key; // [rsp+8h] [rbp-20h] BYREF

  v1 = (char *)operator new(0x30u);
  *(_OWORD *)(v1 + 8) = 0;
  *((_QWORD *)v1 + 3) = owner;
  *((_QWORD *)v1 + 4) = 0;
  *(_QWORD *)v1 = &off_29C3AA8;
  service_registry = owner->service_registry_;
  key.type_info_ = (const std::type_info *)&`typeinfo for'boost::asio::detail::typeid_wrapper<boost::asio::detail::epoll_reactor>;
  key.id_ = 0;
  v3 = boost::asio::detail::service_registry::do_use_service(
         service_registry,
         &key,
         boost::asio::detail::service_registry::create<boost::asio::detail::epoll_reactor>);
  *((_QWORD *)v1 + 5) = v3;
  boost::asio::detail::task_io_service::init_task((boost::asio::detail::task_io_service_0 *)v3[1]._vptr$service);
  return (boost::asio::io_service::service *)v1;
}


// Address: 0x261e360 | Name: _ZN5boost4asio6detail16service_registry6createINS0_2ip16resolver_serviceINS4_3tcpEEEEEPNS0_10io_service7serviceERS8_
boost::asio::io_service::service *__fastcall boost::asio::detail::service_registry::create<boost::asio::ip::resolver_service<boost::asio::ip::tcp>>(
        boost::asio::io_service *owner)
{
  char *v1; // rbx

  v1 = (char *)operator new(0x78u);
  *(_OWORD *)(v1 + 8) = 0;
  *((_QWORD *)v1 + 3) = owner;
  *((_QWORD *)v1 + 4) = 0;
  *(_QWORD *)v1 = &off_29C3CD8;
  boost::asio::detail::resolver_service_base::resolver_service_base(
    (boost::asio::detail::resolver_service_base *)(v1 + 40),
    owner);
  return (boost::asio::io_service::service *)v1;
}


// Address: 0x26970a0 | Name: _ZN5boost4asio6detail16service_registry6createINS0_22waitable_timer_serviceINSt3__16chrono12steady_clockENS0_11wait_traitsIS7_EEEEEEPNS0_10io_service7serviceERSB_
boost::asio::io_service::service *__fastcall boost::asio::detail::service_registry::create<boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>(
        boost::asio::io_service *owner)
{
  char *v1; // rbx

  v1 = (char *)operator new(0x60u);
  *(_OWORD *)(v1 + 8) = 0;
  *((_QWORD *)v1 + 3) = owner;
  *((_QWORD *)v1 + 4) = 0;
  *(_QWORD *)v1 = &off_29C70A8;
  boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::deadline_timer_service(
    (boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *)(v1 + 40),
    owner);
  return (boost::asio::io_service::service *)v1;
}


