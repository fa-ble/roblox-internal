// Address: 0xdabdb0 | Name: _ZNK5boost6system12system_error4whatEv
const char *__fastcall boost::system::system_error::what(const boost::system::system_error *this)
{
  unsigned __int8 v1; // al
  unsigned __int64 v2; // rcx
  _BYTE *v3; // rbx
  __int64 v5; // rax
  unsigned __int64 v6; // rax
  char *v7; // rsi
  unsigned __int64 v8; // rdx
  unsigned __int8 v10; // [rsp+0h] [rbp-28h] BYREF
  char v11; // [rsp+1h] [rbp-27h] BYREF
  unsigned __int64 v12; // [rsp+8h] [rbp-20h]
  void *ptr; // [rsp+10h] [rbp-18h]

  v1 = *((_BYTE *)this + 32);
  if ( (v1 & 1) != 0 )
    v2 = *((_QWORD *)this + 5);
  else
    v2 = (unsigned __int64)v1 >> 1;
  v3 = (char *)this + 32;
  if ( !v2 )
  {
    v5 = std::runtime_error::what(this);
    std::string::assign((char *)this + 32, v5);
    v6 = (unsigned __int8)*v3;
    if ( (v6 & 1) != 0 )
    {
      if ( !*((_QWORD *)this + 5) )
        goto LABEL_12;
    }
    else if ( !(v6 >> 1) )
    {
LABEL_12:
      (*(void (__fastcall **)(unsigned __int8 *, _QWORD, _QWORD))(**((_QWORD **)this + 3) + 24LL))(
        &v10,
        *((_QWORD *)this + 3),
        *((unsigned int *)this + 4));
      if ( (v10 & 1) != 0 )
      {
        v7 = (char *)ptr;
        v8 = v12;
      }
      else
      {
        v8 = (unsigned __int64)v10 >> 1;
        v7 = &v11;
      }
      std::string::append((char *)this + 32, v7, v8);
      if ( (v10 & 1) != 0 )
        operator delete(ptr);
      if ( (*v3 & 1) == 0 )
        return (char *)this + 33;
      return (const char *)*((_QWORD *)this + 6);
    }
    std::string::append((char *)this + 32, ": ");
    goto LABEL_12;
  }
  if ( (v1 & 1) != 0 )
    return (const char *)*((_QWORD *)this + 6);
  return (char *)this + 33;
}


// Address: 0xdabeb6 | Name: sub_DABEB6
void __fastcall __noreturn sub_DABEB6()
{
  void *v0; // rax

  __cxa_call_unexpected(v0);
}


// Address: 0xdaf430 | Name: _ZN5boost6system12system_errorD0Ev
void __fastcall boost::system::system_error::~system_error(boost::system::system_error *this)
{
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdb0230 | Name: _ZN5boost6system12system_errorD2Ev
void __fastcall boost::system::system_error::~system_error(boost::system::system_error *this)
{
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
}


// Address: 0x283ed70 | Name: _ZN5boost6system12system_errorC2EiRKNS0_14error_categoryEPKc
void __fastcall boost::system::system_error::system_error(
        boost::system::system_error *this,
        int ev,
        const boost::system::error_category *ecat,
        const char *what_arg)
{
  std::runtime_error::runtime_error(this, what_arg);
  *(_QWORD *)this = off_2875F00;
  *((_DWORD *)this + 4) = ev;
  *((_QWORD *)this + 3) = ecat;
  *((_OWORD *)this + 2) = 0;
  *((_QWORD *)this + 6) = 0;
}


