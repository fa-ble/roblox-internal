// Address: 0x28396e0 | Name: _ZN5boost6chrono12system_clock3nowEv
boost::chrono::system_clock::time_point __cdecl boost::chrono::system_clock::now()
{
  struct timespec tp; // [rsp+8h] [rbp-10h] BYREF

  clock_gettime(0, &tp);
  return (boost::chrono::system_clock::time_point)(tp.tv_nsec + 1000000000 * tp.tv_sec);
}


// Address: 0x2839710 | Name: _ZN5boost6chrono12system_clock3nowERNS_6system10error_codeE
boost::chrono::system_clock::time_point __fastcall boost::chrono::system_clock::now(boost::system::error_code *ec)
{
  int v1; // ebp
  const boost::system::error_category *v2; // rax
  int v4; // ebp
  const boost::system::error_category *v5; // rbx
  struct timespec v6; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v7[2]; // [rsp+10h] [rbp-58h] BYREF
  int v8; // [rsp+20h] [rbp-48h]
  const boost::system::error_category *v9; // [rsp+28h] [rbp-40h]
  __int128 v10; // [rsp+30h] [rbp-38h]
  void *ptr; // [rsp+40h] [rbp-28h]

  if ( clock_gettime(0, &v6) )
  {
    if ( ec == (boost::system::error_code *)&dword_2CE5608 )
    {
      v4 = *__errno_location();
      v5 = boost::system::system_category();
      std::runtime_error::runtime_error((std::runtime_error *)v7, "chrono::system_clock");
      v7[0] = off_2875F00;
      v8 = v4;
      v9 = v5;
      v10 = 0;
      ptr = 0;
      boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v7);
    }
    v1 = *__errno_location();
    v2 = boost::system::system_category();
    ec->m_val = v1;
    ec->m_cat = v2;
    return 0;
  }
  else
  {
    if ( ec != (boost::system::error_code *)&dword_2CE5608 )
    {
      ec->m_val = 0;
      ec->m_cat = boost::system::system_category();
    }
    return (boost::chrono::system_clock::time_point)(v6.tv_nsec + 1000000000 * v6.tv_sec);
  }
}


// Address: 0x2839800 | Name: _ZN5boost6chrono12system_clock9to_time_tERKNS0_10time_pointIS1_NS0_8durationIlNS_5ratioILl1ELl1000000000EEEEEEE
time_t __fastcall boost::chrono::system_clock::to_time_t(const boost::chrono::system_clock::time_point *t)
{
  return t->d_.rep_ / 1000000000;
}


// Address: 0x2839820 | Name: _ZN5boost6chrono12system_clock11from_time_tEl
boost::chrono::system_clock::time_point __fastcall boost::chrono::system_clock::from_time_t(time_t t)
{
  return (boost::chrono::system_clock::time_point)(1000000000 * t);
}


// Address: 0x2839830 | Name: _ZN5boost6chrono12steady_clock3nowEv
boost::chrono::steady_clock::time_point __cdecl boost::chrono::steady_clock::now()
{
  struct timespec tp; // [rsp+8h] [rbp-10h] BYREF

  clock_gettime(1, &tp);
  return (boost::chrono::steady_clock::time_point)(tp.tv_nsec + 1000000000 * tp.tv_sec);
}


// Address: 0x2839860 | Name: _ZN5boost6chrono12steady_clock3nowERNS_6system10error_codeE
boost::chrono::steady_clock::time_point __fastcall boost::chrono::steady_clock::now(boost::system::error_code *ec)
{
  int v1; // ebp
  const boost::system::error_category *v2; // rax
  int v4; // ebp
  const boost::system::error_category *v5; // rbx
  struct timespec v6; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v7[2]; // [rsp+10h] [rbp-58h] BYREF
  int v8; // [rsp+20h] [rbp-48h]
  const boost::system::error_category *v9; // [rsp+28h] [rbp-40h]
  __int128 v10; // [rsp+30h] [rbp-38h]
  void *ptr; // [rsp+40h] [rbp-28h]

  if ( clock_gettime(1, &v6) )
  {
    if ( ec == (boost::system::error_code *)&dword_2CE5608 )
    {
      v4 = *__errno_location();
      v5 = boost::system::system_category();
      std::runtime_error::runtime_error((std::runtime_error *)v7, "chrono::steady_clock");
      v7[0] = off_2875F00;
      v8 = v4;
      v9 = v5;
      v10 = 0;
      ptr = 0;
      boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v7);
    }
    v1 = *__errno_location();
    v2 = boost::system::system_category();
    ec->m_val = v1;
    ec->m_cat = v2;
    return 0;
  }
  else
  {
    if ( ec != (boost::system::error_code *)&dword_2CE5608 )
    {
      ec->m_val = 0;
      ec->m_cat = boost::system::system_category();
    }
    return (boost::chrono::steady_clock::time_point)(v6.tv_nsec + 1000000000 * v6.tv_sec);
  }
}


