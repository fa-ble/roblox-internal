// Address: 0x2615640 | Name: _ZN5boost4asio10async_readINS0_3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEEEENS0_17mutable_buffers_1ENS0_6detail19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEENS0_12async_resultINS0_12handler_typeIT2_FvSL_mEE4typeEE4typeERT_RKT0_T1_OST_
boost::asio::async_result<websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > >::type __fastcall boost::asio::async_read<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::detail::transfer_at_least_t completion_condition,
        websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *handler)
{
  websocketpp::transport::asio::handler_allocator *allocator; // rax
  websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *f; // rdi
  size_t size; // rdx
  char *v9; // rbx
  size_t v10; // rdx
  boost::asio::mutable_buffers_1 v11; // [rsp+0h] [rbp-F8h] BYREF
  boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > v12; // [rsp+10h] [rbp-E8h] BYREF
  websocketpp::transport::asio::handler_allocator *v13; // [rsp+80h] [rbp-78h]
  _BYTE v14[32]; // [rsp+90h] [rbp-68h] BYREF
  std::function<void (const boost::system::error_code &,unsigned long)>::__base *v15; // [rsp+B0h] [rbp-48h]
  unsigned __int64 v16; // [rsp+D0h] [rbp-28h]

  v16 = __readfsqword(0x28u);
  allocator = handler->allocator_;
  v13 = handler->allocator_;
  f = (websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *)handler->handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      v15 = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)v14;
      (*((void (__fastcall **)(websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *, _BYTE *))&f->allocator_->storage_.data_.align_
       + 3))(
        f,
        v14);
      allocator = v13;
      f = (websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *)v15;
    }
    else
    {
      v15 = handler->handler_.__f_;
      handler->handler_.__f_ = 0;
    }
  }
  else
  {
    v15 = 0;
    f = 0;
  }
  v12.completion_condition_ = completion_condition;
  v12.stream_ = s;
  v12.buffer_ = buffers->boost::asio::mutable_buffer;
  v12.start_ = 0;
  v12.total_transferred_ = 0;
  v12.handler_.allocator_ = allocator;
  if ( f )
  {
    if ( v14 == (_BYTE *)f )
    {
      v12.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&v12.handler_.handler_;
      (*((void (__fastcall **)(websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *, std::function<void (const boost::system::error_code &,unsigned long)> *))&f->allocator_->storage_.data_.align_
       + 3))(
        f,
        &v12.handler_.handler_);
    }
    else
    {
      v12.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)f;
      v15 = 0;
    }
  }
  else
  {
    v12.handler_.handler_.__f_ = 0;
  }
  boost::system::system_category();
  v12.start_ = 1;
  size = v12.buffer_.size_;
  v9 = 0;
  if ( v12.buffer_.size_ >= v12.total_transferred_ )
    v9 = (char *)v12.buffer_.data_ + v12.total_transferred_;
  else
    size = v12.total_transferred_;
  v10 = size - v12.total_transferred_;
  if ( v10 >= (unsigned __int64)(v12.completion_condition_.minimum_ > v12.total_transferred_) << 16 )
    v10 = (unsigned __int64)(v12.completion_condition_.minimum_ > v12.total_transferred_) << 16;
  v11.data_ = v9;
  v11.size_ = v10;
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
    v12.stream_,
    &v11,
    &v12);
  if ( &v12.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v12.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v12.handler_.handler_.__f_->_vptr$__base
     + 4))(v12.handler_.handler_.__f_);
  }
  else if ( v12.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v12.handler_.handler_.__f_->_vptr$__base + 5))();
  }
  if ( v14 == (_BYTE *)v15 )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v15->_vptr$__base
     + 4))(v15);
  }
  else if ( v15 )
  {
    (*((void (**)(void))v15->_vptr$__base + 5))();
  }
}


// Address: 0x2615970 | Name: _ZN5boost4asio6detail7read_opINS0_3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEEEENS0_17mutable_buffers_1ENS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEclESN_mi
void __fastcall boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>::operator()(
        boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  size_t total_transferred; // rcx
  unsigned __int64 v6; // r8
  const boost::system::error_category *m_cat; // rdx
  std::function<void (const boost::system::error_code &,unsigned long)>::__base *f; // rdi
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *stream; // rdi
  size_t size; // rsi
  char *v11; // r9
  size_t v12; // rsi
  _QWORD *exception; // rax
  boost::asio::mutable_buffers_1 v14; // [rsp+0h] [rbp-18h] BYREF
  size_t v15; // [rsp+10h] [rbp-8h] BYREF

  this->start_ = start;
  if ( start == 1 )
  {
    total_transferred = this->total_transferred_;
    if ( ec->m_val )
      v6 = 0;
    else
      v6 = (unsigned __int64)(this->completion_condition_.minimum_ > total_transferred) << 16;
LABEL_12:
    stream = this->stream_;
    size = this->buffer_.size_;
    v11 = 0;
    if ( size >= total_transferred )
      v11 = (char *)this->buffer_.data_ + total_transferred;
    else
      size = total_transferred;
    v12 = size - total_transferred;
    if ( v12 >= v6 )
      v12 = v6;
    v14.data_ = v11;
    v14.size_ = v12;
    boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
      stream,
      &v14,
      this);
    return;
  }
  total_transferred = bytes_transferred + this->total_transferred_;
  this->total_transferred_ = total_transferred;
  if ( bytes_transferred
    && !ec->m_val
    && this->completion_condition_.minimum_ > total_transferred
    && total_transferred != this->buffer_.size_ )
  {
    v6 = 0x10000;
    goto LABEL_12;
  }
  m_cat = ec->m_cat;
  LODWORD(v14.data_) = ec->m_val;
  v14.size_ = (size_t)m_cat;
  v15 = total_transferred;
  f = this->handler_.handler_.__f_;
  if ( !f )
  {
    exception = __cxa_allocate_exception(8u);
    *exception = off_28852C8;
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::bad_function_call,
      (void (*)(void *))&std::exception::~exception);
  }
  (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, boost::asio::mutable_buffers_1 *, size_t *))f->_vptr$__base
   + 6))(
    f,
    &v14,
    &v15);
}


// Address: 0x265dad0 | Name: _ZN5boost4asio10async_readINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_6detail19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEENS0_12async_resultINS0_12handler_typeIT2_FvSI_mEE4typeEE4typeERT_RKT0_T1_OSQ_
boost::asio::async_result<websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > >::type __fastcall boost::asio::async_read<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::detail::transfer_at_least_t completion_condition,
        websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *handler)
{
  websocketpp::transport::asio::handler_allocator *allocator; // rax
  websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *f; // rdi
  size_t size; // rdx
  char *v9; // rdi
  size_t v10; // rdx
  boost::asio::mutable_buffers_1 v11; // [rsp+0h] [rbp-F8h] BYREF
  boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > v12; // [rsp+10h] [rbp-E8h] BYREF
  websocketpp::transport::asio::handler_allocator *v13; // [rsp+80h] [rbp-78h]
  _BYTE v14[32]; // [rsp+90h] [rbp-68h] BYREF
  std::function<void (const boost::system::error_code &,unsigned long)>::__base *v15; // [rsp+B0h] [rbp-48h]
  unsigned __int64 v16; // [rsp+D0h] [rbp-28h]

  v16 = __readfsqword(0x28u);
  allocator = handler->allocator_;
  v13 = handler->allocator_;
  f = (websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *)handler->handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      v15 = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)v14;
      (*((void (__fastcall **)(websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *, _BYTE *))&f->allocator_->storage_.data_.align_
       + 3))(
        f,
        v14);
      allocator = v13;
      f = (websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *)v15;
    }
    else
    {
      v15 = handler->handler_.__f_;
      handler->handler_.__f_ = 0;
    }
  }
  else
  {
    v15 = 0;
    f = 0;
  }
  v12.completion_condition_ = completion_condition;
  v12.stream_ = s;
  v12.buffer_ = buffers->boost::asio::mutable_buffer;
  v12.start_ = 0;
  v12.total_transferred_ = 0;
  v12.handler_.allocator_ = allocator;
  if ( f )
  {
    if ( v14 == (_BYTE *)f )
    {
      v12.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&v12.handler_.handler_;
      (*((void (__fastcall **)(websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *, std::function<void (const boost::system::error_code &,unsigned long)> *))&f->allocator_->storage_.data_.align_
       + 3))(
        f,
        &v12.handler_.handler_);
    }
    else
    {
      v12.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)f;
      v15 = 0;
    }
  }
  else
  {
    v12.handler_.handler_.__f_ = 0;
  }
  boost::system::system_category();
  v12.start_ = 1;
  size = v12.buffer_.size_;
  v9 = 0;
  if ( v12.buffer_.size_ >= v12.total_transferred_ )
    v9 = (char *)v12.buffer_.data_ + v12.total_transferred_;
  else
    size = v12.total_transferred_;
  v10 = size - v12.total_transferred_;
  if ( v10 >= (unsigned __int64)(v12.completion_condition_.minimum_ > v12.total_transferred_) << 16 )
    v10 = (unsigned __int64)(v12.completion_condition_.minimum_ > v12.total_transferred_) << 16;
  v11.data_ = v9;
  v11.size_ = v10;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
    v12.stream_->service_,
    &v12.stream_->implementation,
    &v11,
    0,
    &v12);
  if ( &v12.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v12.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v12.handler_.handler_.__f_->_vptr$__base
     + 4))(v12.handler_.handler_.__f_);
  }
  else if ( v12.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v12.handler_.handler_.__f_->_vptr$__base + 5))();
  }
  if ( v14 == (_BYTE *)v15 )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v15->_vptr$__base
     + 4))(v15);
  }
  else if ( v15 )
  {
    (*((void (**)(void))v15->_vptr$__base + 5))();
  }
}


// Address: 0x265dcf0 | Name: _ZN5boost4asio6detail7read_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENS0_17mutable_buffers_1ENS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEclESK_mi
void __fastcall boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>::operator()(
        boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  size_t total_transferred; // rcx
  unsigned __int64 v6; // r8
  const boost::system::error_category *m_cat; // rdx
  std::function<void (const boost::system::error_code &,unsigned long)>::__base *f; // rdi
  size_t size; // rdi
  char *v10; // rdx
  size_t v11; // rdi
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *stream; // rsi
  _QWORD *exception; // rax
  boost::asio::mutable_buffers_1 v14; // [rsp+0h] [rbp-18h] BYREF
  size_t v15; // [rsp+10h] [rbp-8h] BYREF

  this->start_ = start;
  if ( start == 1 )
  {
    total_transferred = this->total_transferred_;
    if ( ec->m_val )
      v6 = 0;
    else
      v6 = (unsigned __int64)(this->completion_condition_.minimum_ > total_transferred) << 16;
LABEL_12:
    size = this->buffer_.size_;
    v10 = 0;
    if ( size >= total_transferred )
      v10 = (char *)this->buffer_.data_ + total_transferred;
    else
      size = total_transferred;
    v11 = size - total_transferred;
    if ( v11 >= v6 )
      v11 = v6;
    stream = this->stream_;
    v14.data_ = v10;
    v14.size_ = v11;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
      stream->service_,
      &stream->implementation,
      &v14,
      0,
      this);
    return;
  }
  total_transferred = bytes_transferred + this->total_transferred_;
  this->total_transferred_ = total_transferred;
  if ( bytes_transferred
    && !ec->m_val
    && this->completion_condition_.minimum_ > total_transferred
    && total_transferred != this->buffer_.size_ )
  {
    v6 = 0x10000;
    goto LABEL_12;
  }
  m_cat = ec->m_cat;
  LODWORD(v14.data_) = ec->m_val;
  v14.size_ = (size_t)m_cat;
  v15 = total_transferred;
  f = this->handler_.handler_.__f_;
  if ( !f )
  {
    exception = __cxa_allocate_exception(8u);
    *exception = off_28852C8;
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::bad_function_call,
      (void (*)(void *))&std::exception::~exception);
  }
  (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, boost::asio::mutable_buffers_1 *, size_t *))f->_vptr$__base
   + 6))(
    f,
    &v14,
    &v15);
}


// Address: 0x26b1a00 | Name: _ZN5boost4asio10async_readINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEEEENSt3__19allocatorIcEENS0_6detail18transfer_exactly_tERKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSH_5list2INSH_5valueINSC_10shared_ptrISP_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT2_FvSR_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EET1_OS1A_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::async_read<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        boost::asio::detail::transfer_exactly_t completion_condition,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // rax
  volatile signed __int64 *cntrl; // rcx
  size_t size; // rax
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  size_t v11; // rsi
  size_t v12; // rbx
  std::__shared_weak_count *v13; // rbx
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-80h] BYREF
  boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > v15; // [rsp+18h] [rbp-70h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> f; // [rsp+60h] [rbp-28h]

  f = handler->f_;
  ptr = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v15.completion_condition_ = completion_condition;
  v15.stream_ = s;
  v15.streambuf_ = b;
  v15.total_transferred_ = 0;
  v15.handler_.f_ = f;
  v15.handler_.l_.a1_.t_.__ptr_ = ptr;
  v15.handler_.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  boost::system::system_category();
  v15.start_ = 1;
  size = 0x10000;
  if ( completion_condition.size_ < 0x10000 )
    size = completion_condition.size_;
  if ( !completion_condition.size_ )
    size = 0;
  v9 = *((_QWORD *)b + 6) - *((_QWORD *)b + 3);
  v10 = *((_QWORD *)b + 11) - *((_QWORD *)b + 9) - v9;
  v11 = *((_QWORD *)b + 8) - v9;
  if ( v11 >= size )
    v11 = size;
  v12 = 512;
  if ( v10 > 0x200 )
    v12 = *((_QWORD *)b + 11) - *((_QWORD *)b + 9) - v9;
  if ( v11 < v12 )
    v12 = v11;
  boost::asio::basic_streambuf<std::allocator<char>>::reserve(b, v12);
  buffers.data_ = (void *)*((_QWORD *)b + 6);
  buffers.size_ = v12;
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
    s,
    &buffers,
    &v15);
  v13 = v15.handler_.l_.a1_.t_.__cntrl_;
  if ( v15.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v15.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
      std::__shared_weak_count::__release_weak(v13);
    }
  }
}


// Address: 0x26b1b60 | Name: _ZN5boost4asio10async_readINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__19allocatorIcEENS0_6detail18transfer_exactly_tERKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSD_5list2INSD_5valueINS8_10shared_ptrISL_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT2_FvSN_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EET1_OS16_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::async_read<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        boost::asio::detail::transfer_exactly_t completion_condition,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // rax
  volatile signed __int64 *cntrl; // rcx
  size_t size; // rax
  __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  size_t v11; // rsi
  size_t v12; // rbx
  std::__shared_weak_count *v13; // rbx
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-80h] BYREF
  boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > v15; // [rsp+18h] [rbp-70h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> f; // [rsp+60h] [rbp-28h]

  f = handler->f_;
  ptr = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v15.completion_condition_ = completion_condition;
  v15.stream_ = s;
  v15.streambuf_ = b;
  v15.total_transferred_ = 0;
  v15.handler_.f_ = f;
  v15.handler_.l_.a1_.t_.__ptr_ = ptr;
  v15.handler_.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  boost::system::system_category();
  v15.start_ = 1;
  size = 0x10000;
  if ( completion_condition.size_ < 0x10000 )
    size = completion_condition.size_;
  if ( !completion_condition.size_ )
    size = 0;
  v9 = *((_QWORD *)b + 6) - *((_QWORD *)b + 3);
  v10 = *((_QWORD *)b + 11) - *((_QWORD *)b + 9) - v9;
  v11 = *((_QWORD *)b + 8) - v9;
  if ( v11 >= size )
    v11 = size;
  v12 = 512;
  if ( v10 > 0x200 )
    v12 = *((_QWORD *)b + 11) - *((_QWORD *)b + 9) - v9;
  if ( v11 < v12 )
    v12 = v11;
  boost::asio::basic_streambuf<std::allocator<char>>::reserve(b, v12);
  buffers.data_ = (void *)*((_QWORD *)b + 6);
  buffers.size_ = v12;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
    s->service_,
    &s->implementation,
    &buffers,
    0,
    &v15);
  v13 = v15.handler_.l_.a1_.t_.__cntrl_;
  if ( v15.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v15.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
      std::__shared_weak_count::__release_weak(v13);
    }
  }
}


// Address: 0x26b1cc0 | Name: _ZN5boost4asio6detail17read_streambuf_opINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEEEENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSH_5list2INSH_5valueINSD_10shared_ptrISP_EEEEPFNS_3argILi1EEEvEEEEEEclEST_mi
void __fastcall boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
        boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  size_t total_transferred; // rdi
  unsigned __int64 v6; // rax
  size_t v7; // rdi
  boost::asio::basic_streambuf<std::allocator<char> > *streambuf; // r15
  __int64 v9; // rcx
  int v10; // eax
  __int64 v11; // rax
  unsigned __int64 v12; // rbx
  __int64 v13; // rdx
  size_t v14; // rsi
  size_t v15; // rbx
  __int64 v16; // rax
  size_t v17; // rdi
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *stream; // r12
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F f; // rax
  _QWORD *v20; // rdi
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-30h] BYREF

  this->start_ = start;
  total_transferred = this->total_transferred_;
  if ( start == 1 )
  {
    if ( ec->m_val || this->completion_condition_.size_ <= total_transferred )
    {
      v6 = 0;
    }
    else
    {
      v6 = 0x10000;
      if ( this->completion_condition_.size_ - total_transferred < 0x10000 )
        v6 = this->completion_condition_.size_ - total_transferred;
    }
    streambuf = this->streambuf_;
    v13 = *((_QWORD *)streambuf + 6) - *((_QWORD *)streambuf + 3);
    v14 = *((_QWORD *)streambuf + 8) - v13;
    if ( v14 >= v6 )
      v14 = v6;
    v15 = 512;
    if ( (unsigned __int64)(*((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v13) > 0x200 )
      v15 = *((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v13;
    if ( v14 < v15 )
      v15 = v14;
LABEL_31:
    stream = this->stream_;
    boost::asio::basic_streambuf<std::allocator<char>>::reserve(streambuf, v15);
    buffers.data_ = (void *)*((_QWORD *)streambuf + 6);
    buffers.size_ = v15;
    boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
      stream,
      &buffers,
      this);
    return;
  }
  v7 = bytes_transferred + total_transferred;
  this->total_transferred_ = v7;
  streambuf = this->streambuf_;
  v9 = *((_QWORD *)streambuf + 6);
  v10 = *((_QWORD *)streambuf + 7) - v9;
  if ( v9 + bytes_transferred <= *((_QWORD *)streambuf + 7) )
    v10 = bytes_transferred;
  v11 = v9 + v10;
  *((_QWORD *)streambuf + 6) = v11;
  *((_QWORD *)streambuf + 4) = v11;
  if ( ec->m_val || this->completion_condition_.size_ <= v7 )
  {
    v12 = 0;
  }
  else
  {
    v12 = 0x10000;
    if ( this->completion_condition_.size_ - v7 < 0x10000 )
      v12 = this->completion_condition_.size_ - v7;
  }
  v16 = v11 - *((_QWORD *)streambuf + 3);
  v17 = *((_QWORD *)streambuf + 8) - v16;
  if ( v17 >= v12 )
    v17 = v12;
  v15 = 512;
  if ( (unsigned __int64)(*((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v16) > 0x200 )
    v15 = *((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v16;
  if ( v17 < v15 )
    v15 = v17;
  if ( (ec->m_val != 0 || bytes_transferred != 0) && v15 )
    goto LABEL_31;
  f = this->handler_.f_.f_;
  v20 = (char *)this->handler_.l_.a1_.t_.__ptr_ + *((_QWORD *)&this->handler_.f_.f_ + 1);
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F *)((char *)f + *v20 - 1);
  ((void (__fastcall *)(_QWORD *))f)(v20);
}


// Address: 0x26b3420 | Name: _ZN5boost4asio6detail17read_streambuf_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSD_5list2INSD_5valueINS9_10shared_ptrISL_EEEEPFNS_3argILi1EEEvEEEEEEclESP_mi
void __fastcall boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
        boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  size_t total_transferred; // rdi
  unsigned __int64 v6; // rax
  size_t v7; // rdi
  boost::asio::basic_streambuf<std::allocator<char> > *streambuf; // r15
  __int64 v9; // rcx
  int v10; // eax
  __int64 v11; // rax
  unsigned __int64 v12; // rbx
  __int64 v13; // rdx
  size_t v14; // rsi
  size_t v15; // rbx
  __int64 v16; // rax
  size_t v17; // rdi
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *stream; // r12
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F f; // rax
  _QWORD *v20; // rdi
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-30h] BYREF

  this->start_ = start;
  total_transferred = this->total_transferred_;
  if ( start == 1 )
  {
    if ( ec->m_val || this->completion_condition_.size_ <= total_transferred )
    {
      v6 = 0;
    }
    else
    {
      v6 = 0x10000;
      if ( this->completion_condition_.size_ - total_transferred < 0x10000 )
        v6 = this->completion_condition_.size_ - total_transferred;
    }
    streambuf = this->streambuf_;
    v13 = *((_QWORD *)streambuf + 6) - *((_QWORD *)streambuf + 3);
    v14 = *((_QWORD *)streambuf + 8) - v13;
    if ( v14 >= v6 )
      v14 = v6;
    v15 = 512;
    if ( (unsigned __int64)(*((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v13) > 0x200 )
      v15 = *((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v13;
    if ( v14 < v15 )
      v15 = v14;
LABEL_31:
    stream = this->stream_;
    boost::asio::basic_streambuf<std::allocator<char>>::reserve(streambuf, v15);
    buffers.data_ = (void *)*((_QWORD *)streambuf + 6);
    buffers.size_ = v15;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
      stream->service_,
      &stream->implementation,
      &buffers,
      0,
      this);
    return;
  }
  v7 = bytes_transferred + total_transferred;
  this->total_transferred_ = v7;
  streambuf = this->streambuf_;
  v9 = *((_QWORD *)streambuf + 6);
  v10 = *((_QWORD *)streambuf + 7) - v9;
  if ( v9 + bytes_transferred <= *((_QWORD *)streambuf + 7) )
    v10 = bytes_transferred;
  v11 = v9 + v10;
  *((_QWORD *)streambuf + 6) = v11;
  *((_QWORD *)streambuf + 4) = v11;
  if ( ec->m_val || this->completion_condition_.size_ <= v7 )
  {
    v12 = 0;
  }
  else
  {
    v12 = 0x10000;
    if ( this->completion_condition_.size_ - v7 < 0x10000 )
      v12 = this->completion_condition_.size_ - v7;
  }
  v16 = v11 - *((_QWORD *)streambuf + 3);
  v17 = *((_QWORD *)streambuf + 8) - v16;
  if ( v17 >= v12 )
    v17 = v12;
  v15 = 512;
  if ( (unsigned __int64)(*((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v16) > 0x200 )
    v15 = *((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v16;
  if ( v17 < v15 )
    v15 = v17;
  if ( (ec->m_val != 0 || bytes_transferred != 0) && v15 )
    goto LABEL_31;
  f = this->handler_.f_.f_;
  v20 = (char *)this->handler_.l_.a1_.t_.__ptr_ + *((_QWORD *)&this->handler_.f_.f_ + 1);
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F *)((char *)f + *v20 - 1);
  ((void (__fastcall *)(_QWORD *))f)(v20);
}


// Address: 0x26b5440 | Name: _ZN5boost4asio10async_readINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEEEENSt3__19allocatorIcEENS0_6detail18transfer_exactly_tERKNS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSH_5list3INSH_5valueINSC_10shared_ptrISP_EEEEPFNS_3argILi1EEEvENSW_IiEEEEEEEENS0_12async_resultINS0_12handler_typeIT2_FvSR_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EET1_OS1B_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > >::type __fastcall boost::asio::async_read<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>> const&>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        boost::asio::detail::transfer_exactly_t completion_condition,
        const boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // rax
  volatile signed __int64 *cntrl; // rdx
  int t; // ecx
  size_t size; // rax
  __int64 v10; // rdx
  unsigned __int64 v11; // rcx
  size_t v12; // rsi
  size_t v13; // rbx
  std::__shared_weak_count *v14; // rbx
  boost::asio::mutable_buffers_1 v15; // [rsp+0h] [rbp-88h] BYREF
  boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > v16; // [rsp+10h] [rbp-78h] BYREF
  boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int> f; // [rsp+60h] [rbp-28h]

  f = handler->f_;
  ptr = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  t = handler->l_.a3_.t_;
  v16.completion_condition_ = completion_condition;
  v16.stream_ = s;
  v16.streambuf_ = b;
  v16.total_transferred_ = 0;
  v16.handler_.f_ = f;
  v16.handler_.l_.a1_.t_.__ptr_ = ptr;
  v16.handler_.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  v16.handler_.l_.a3_.t_ = t;
  boost::system::system_category();
  v16.start_ = 1;
  size = 0x10000;
  if ( completion_condition.size_ < 0x10000 )
    size = completion_condition.size_;
  if ( !completion_condition.size_ )
    size = 0;
  v10 = *((_QWORD *)b + 6) - *((_QWORD *)b + 3);
  v11 = *((_QWORD *)b + 11) - *((_QWORD *)b + 9) - v10;
  v12 = *((_QWORD *)b + 8) - v10;
  if ( v12 >= size )
    v12 = size;
  v13 = 512;
  if ( v11 > 0x200 )
    v13 = *((_QWORD *)b + 11) - *((_QWORD *)b + 9) - v10;
  if ( v12 < v13 )
    v13 = v12;
  boost::asio::basic_streambuf<std::allocator<char>>::reserve(b, v13);
  v15.data_ = (void *)*((_QWORD *)b + 6);
  v15.size_ = v13;
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>(
    s,
    &v15,
    &v16);
  v14 = v16.handler_.l_.a1_.t_.__cntrl_;
  if ( v16.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v16.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(v14);
      std::__shared_weak_count::__release_weak(v14);
    }
  }
}


// Address: 0x26b55a0 | Name: _ZN5boost4asio10async_readINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__19allocatorIcEENS0_6detail18transfer_exactly_tERKNS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSD_5list3INSD_5valueINS8_10shared_ptrISL_EEEEPFNS_3argILi1EEEvENSS_IiEEEEEEEENS0_12async_resultINS0_12handler_typeIT2_FvSN_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EET1_OS17_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > >::type __fastcall boost::asio::async_read<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>> const&>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        boost::asio::detail::transfer_exactly_t completion_condition,
        const boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // rax
  volatile signed __int64 *cntrl; // rdx
  int t; // ecx
  size_t size; // rax
  __int64 v10; // rdx
  unsigned __int64 v11; // rcx
  size_t v12; // rsi
  size_t v13; // rbx
  std::__shared_weak_count *v14; // rbx
  boost::asio::mutable_buffers_1 v15; // [rsp+0h] [rbp-88h] BYREF
  boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > v16; // [rsp+10h] [rbp-78h] BYREF
  boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int> f; // [rsp+60h] [rbp-28h]

  f = handler->f_;
  ptr = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  t = handler->l_.a3_.t_;
  v16.completion_condition_ = completion_condition;
  v16.stream_ = s;
  v16.streambuf_ = b;
  v16.total_transferred_ = 0;
  v16.handler_.f_ = f;
  v16.handler_.l_.a1_.t_.__ptr_ = ptr;
  v16.handler_.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  v16.handler_.l_.a3_.t_ = t;
  boost::system::system_category();
  v16.start_ = 1;
  size = 0x10000;
  if ( completion_condition.size_ < 0x10000 )
    size = completion_condition.size_;
  if ( !completion_condition.size_ )
    size = 0;
  v10 = *((_QWORD *)b + 6) - *((_QWORD *)b + 3);
  v11 = *((_QWORD *)b + 11) - *((_QWORD *)b + 9) - v10;
  v12 = *((_QWORD *)b + 8) - v10;
  if ( v12 >= size )
    v12 = size;
  v13 = 512;
  if ( v11 > 0x200 )
    v13 = *((_QWORD *)b + 11) - *((_QWORD *)b + 9) - v10;
  if ( v12 < v13 )
    v13 = v12;
  boost::asio::basic_streambuf<std::allocator<char>>::reserve(b, v13);
  v15.data_ = (void *)*((_QWORD *)b + 6);
  v15.size_ = v13;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>(
    s->service_,
    &s->implementation,
    &v15,
    0,
    &v16);
  v14 = v16.handler_.l_.a1_.t_.__cntrl_;
  if ( v16.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v16.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(v14);
      std::__shared_weak_count::__release_weak(v14);
    }
  }
}


// Address: 0x26b5700 | Name: _ZN5boost4asio6detail17read_streambuf_opINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEEEENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSH_5list3INSH_5valueINSD_10shared_ptrISP_EEEEPFNS_3argILi1EEEvENSW_IiEEEEEEEclEST_mi
void __fastcall boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>::operator()(
        boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  size_t total_transferred; // rdi
  unsigned __int64 v6; // rax
  size_t v7; // rdi
  boost::asio::basic_streambuf<std::allocator<char> > *streambuf; // r15
  __int64 v9; // rcx
  int v10; // eax
  __int64 v11; // rax
  unsigned __int64 v12; // rbx
  __int64 v13; // rdx
  size_t v14; // rsi
  size_t v15; // rbx
  __int64 v16; // rax
  size_t v17; // rdi
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *stream; // r12
  boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>::F f; // rax
  web::http::client::details::asio_context *v20; // rdi
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-30h] BYREF

  this->start_ = start;
  total_transferred = this->total_transferred_;
  if ( start == 1 )
  {
    if ( ec->m_val || this->completion_condition_.size_ <= total_transferred )
    {
      v6 = 0;
    }
    else
    {
      v6 = 0x10000;
      if ( this->completion_condition_.size_ - total_transferred < 0x10000 )
        v6 = this->completion_condition_.size_ - total_transferred;
    }
    streambuf = this->streambuf_;
    v13 = *((_QWORD *)streambuf + 6) - *((_QWORD *)streambuf + 3);
    v14 = *((_QWORD *)streambuf + 8) - v13;
    if ( v14 >= v6 )
      v14 = v6;
    v15 = 512;
    if ( (unsigned __int64)(*((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v13) > 0x200 )
      v15 = *((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v13;
    if ( v14 < v15 )
      v15 = v14;
LABEL_31:
    stream = this->stream_;
    boost::asio::basic_streambuf<std::allocator<char>>::reserve(streambuf, v15);
    buffers.data_ = (void *)*((_QWORD *)streambuf + 6);
    buffers.size_ = v15;
    boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>(
      stream,
      &buffers,
      this);
    return;
  }
  v7 = bytes_transferred + total_transferred;
  this->total_transferred_ = v7;
  streambuf = this->streambuf_;
  v9 = *((_QWORD *)streambuf + 6);
  v10 = *((_QWORD *)streambuf + 7) - v9;
  if ( v9 + bytes_transferred <= *((_QWORD *)streambuf + 7) )
    v10 = bytes_transferred;
  v11 = v9 + v10;
  *((_QWORD *)streambuf + 6) = v11;
  *((_QWORD *)streambuf + 4) = v11;
  if ( ec->m_val || this->completion_condition_.size_ <= v7 )
  {
    v12 = 0;
  }
  else
  {
    v12 = 0x10000;
    if ( this->completion_condition_.size_ - v7 < 0x10000 )
      v12 = this->completion_condition_.size_ - v7;
  }
  v16 = v11 - *((_QWORD *)streambuf + 3);
  v17 = *((_QWORD *)streambuf + 8) - v16;
  if ( v17 >= v12 )
    v17 = v12;
  v15 = 512;
  if ( (unsigned __int64)(*((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v16) > 0x200 )
    v15 = *((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v16;
  if ( v17 < v15 )
    v15 = v17;
  if ( (ec->m_val != 0 || bytes_transferred != 0) && v15 )
    goto LABEL_31;
  f = this->handler_.f_.f_;
  v20 = (web::http::client::details::asio_context *)((char *)this->handler_.l_.a1_.t_.__ptr_
                                                   + *((_QWORD *)&this->handler_.f_.f_ + 1));
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>::F *)((char *)f + *(_QWORD *)v20 - 1);
  f(v20, ec, this->handler_.l_.a3_.t_);
}


// Address: 0x26b6f00 | Name: _ZN5boost4asio6detail17read_streambuf_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSD_5list3INSD_5valueINS9_10shared_ptrISL_EEEEPFNS_3argILi1EEEvENSS_IiEEEEEEEclESP_mi
void __fastcall boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>::operator()(
        boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  size_t total_transferred; // rdi
  unsigned __int64 v6; // rax
  size_t v7; // rdi
  boost::asio::basic_streambuf<std::allocator<char> > *streambuf; // r15
  __int64 v9; // rcx
  int v10; // eax
  __int64 v11; // rax
  unsigned __int64 v12; // rbx
  __int64 v13; // rdx
  size_t v14; // rsi
  size_t v15; // rbx
  __int64 v16; // rax
  size_t v17; // rdi
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *stream; // r12
  boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>::F f; // rax
  web::http::client::details::asio_context *v20; // rdi
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-30h] BYREF

  this->start_ = start;
  total_transferred = this->total_transferred_;
  if ( start == 1 )
  {
    if ( ec->m_val || this->completion_condition_.size_ <= total_transferred )
    {
      v6 = 0;
    }
    else
    {
      v6 = 0x10000;
      if ( this->completion_condition_.size_ - total_transferred < 0x10000 )
        v6 = this->completion_condition_.size_ - total_transferred;
    }
    streambuf = this->streambuf_;
    v13 = *((_QWORD *)streambuf + 6) - *((_QWORD *)streambuf + 3);
    v14 = *((_QWORD *)streambuf + 8) - v13;
    if ( v14 >= v6 )
      v14 = v6;
    v15 = 512;
    if ( (unsigned __int64)(*((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v13) > 0x200 )
      v15 = *((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v13;
    if ( v14 < v15 )
      v15 = v14;
LABEL_31:
    stream = this->stream_;
    boost::asio::basic_streambuf<std::allocator<char>>::reserve(streambuf, v15);
    buffers.data_ = (void *)*((_QWORD *)streambuf + 6);
    buffers.size_ = v15;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>(
      stream->service_,
      &stream->implementation,
      &buffers,
      0,
      this);
    return;
  }
  v7 = bytes_transferred + total_transferred;
  this->total_transferred_ = v7;
  streambuf = this->streambuf_;
  v9 = *((_QWORD *)streambuf + 6);
  v10 = *((_QWORD *)streambuf + 7) - v9;
  if ( v9 + bytes_transferred <= *((_QWORD *)streambuf + 7) )
    v10 = bytes_transferred;
  v11 = v9 + v10;
  *((_QWORD *)streambuf + 6) = v11;
  *((_QWORD *)streambuf + 4) = v11;
  if ( ec->m_val || this->completion_condition_.size_ <= v7 )
  {
    v12 = 0;
  }
  else
  {
    v12 = 0x10000;
    if ( this->completion_condition_.size_ - v7 < 0x10000 )
      v12 = this->completion_condition_.size_ - v7;
  }
  v16 = v11 - *((_QWORD *)streambuf + 3);
  v17 = *((_QWORD *)streambuf + 8) - v16;
  if ( v17 >= v12 )
    v17 = v12;
  v15 = 512;
  if ( (unsigned __int64)(*((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v16) > 0x200 )
    v15 = *((_QWORD *)streambuf + 11) - *((_QWORD *)streambuf + 9) - v16;
  if ( v17 < v15 )
    v15 = v17;
  if ( (ec->m_val != 0 || bytes_transferred != 0) && v15 )
    goto LABEL_31;
  f = this->handler_.f_.f_;
  v20 = (web::http::client::details::asio_context *)((char *)this->handler_.l_.a1_.t_.__ptr_
                                                   + *((_QWORD *)&this->handler_.f_.f_ + 1));
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>::F *)((char *)f + *(_QWORD *)v20 - 1);
  f(v20, ec, this->handler_.l_.a3_.t_);
}


