// Address: 0x2546d40 | Name: __cxx_global_var_init.44_0
void __cdecl _cxx_global_var_init_44_0()
{
  if ( !(_BYTE)qword_2B114B8 )
  {
    boost::asio::ssl::detail::openssl_init_base::instance();
    __cxa_atexit(
      (void (*)(void *))boost::asio::ssl::detail::openssl_init<true>::~openssl_init,
      &unk_2B114A8,
      &dso_handle);
    qword_2B114B8 = 1;
  }
}


// Address: 0x2546d80 | Name: _ZN5boost4asio3ssl6detail12openssl_initILb1EED2Ev
void __fastcall boost::asio::ssl::detail::openssl_init<true>::~openssl_init(
        boost::asio::ssl::detail::openssl_init<true> *this)
{
  volatile signed __int64 *cntrl; // rbx

  cntrl = (volatile signed __int64 *)this->ref_.__cntrl_;
  if ( cntrl )
  {
    if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
  }
}


