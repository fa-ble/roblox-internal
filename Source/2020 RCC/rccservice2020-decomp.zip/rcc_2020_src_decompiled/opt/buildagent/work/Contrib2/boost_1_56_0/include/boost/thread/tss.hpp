// Address: 0x11c9940 | Name: _ZN5boost19thread_specific_ptrIiEC2Ev
void __fastcall boost::thread_specific_ptr<int>::thread_specific_ptr(boost::thread_specific_ptr<int> *this)
{
  boost::shared_ptr<boost::detail::tss_cleanup_function>::element_type *v1; // r14
  boost::detail::sp_counted_base *v2; // rax

  v1 = (boost::shared_ptr<boost::detail::tss_cleanup_function>::element_type *)operator new(8u);
  v1->_vptr$tss_cleanup_function = (int (**)(void))&off_28A07B8;
  this->cleanup.px = v1;
  this->cleanup.pn.pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28A0808;
  v2[1]._vptr$sp_counted_base = (int (**)(void))v1;
  this->cleanup.pn.pi_ = v2;
}


// Address: 0x11c99d0 | Name: _ZN5boost19thread_specific_ptrIiED2Ev
void __fastcall boost::thread_specific_ptr<int>::~thread_specific_ptr(boost::thread_specific_ptr<int> *this)
{
  bool v1; // r8
  volatile signed __int32 *v2; // rbx
  boost::detail::sp_counted_base *pi; // rbx
  __int128 v4; // [rsp+0h] [rbp-28h] BYREF

  v4 = 0;
  boost::detail::set_tss_data(
    this,
    (boost::shared_ptr<boost::detail::tss_cleanup_function>_0)(unsigned __int64)&v4,
    (char *)&dword_0 + 1,
    v1);
  v2 = (volatile signed __int32 *)*((_QWORD *)&v4 + 1);
  if ( *((_QWORD *)&v4 + 1) )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v4 + 1) + 8LL), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
      if ( !_InterlockedSub(v2 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
    }
  }
  pi = this->cleanup.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x11ce510 | Name: _ZN5boost19thread_specific_ptrIiE5resetEPi
void __fastcall boost::thread_specific_ptr<int>::reset(boost::thread_specific_ptr<int> *this, int *new_value)
{
  bool v2; // r8
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<boost::detail::tss_cleanup_function>_0 func; // [rsp+8h] [rbp-20h] BYREF

  if ( boost::detail::get_tss_data(this) != new_value )
  {
    func.px = this->cleanup.px;
    pi = this->cleanup.pn.pi_;
    func.pn.pi_ = pi;
    if ( pi )
      _InterlockedAdd(&pi->use_count_, 1u);
    boost::detail::set_tss_data(
      this,
      (boost::shared_ptr<boost::detail::tss_cleanup_function>_0)__PAIR128__((unsigned __int64)new_value, &func),
      (char *)&dword_0 + 1,
      v2);
    v4 = func.pn.pi_;
    if ( func.pn.pi_ && !_InterlockedSub(&func.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
  }
}


// Address: 0x11cfcc0 | Name: _ZN5boost6detail20tss_cleanup_functionD2Ev
void __fastcall boost::detail::tss_cleanup_function::~tss_cleanup_function(boost::detail::tss_cleanup_function *this)
{
  ;
}


// Address: 0x11cfcd0 | Name: _ZN5boost19thread_specific_ptrIiE11delete_dataD0Ev
// Alternative name is 'j__ZdlPv_408'
// attributes: thunk
void __fastcall boost::thread_specific_ptr<int>::delete_data::~delete_data(
        boost::thread_specific_ptr<int>::delete_data *this)
{
  operator delete(this);
}


// Address: 0x11cfce0 | Name: _ZN5boost19thread_specific_ptrIiE11delete_dataclEPv
void __fastcall boost::thread_specific_ptr<int>::delete_data::operator()(
        boost::thread_specific_ptr<int>::delete_data *this,
        void *data)
{
  if ( data )
    operator delete(data);
}


// Address: 0x1593520 | Name: _ZN5boost19thread_specific_ptrIPN3RBX9DataModel10GenericJobEEC2Ev
void __fastcall boost::thread_specific_ptr<RBX::DataModel::GenericJob *>::thread_specific_ptr(
        boost::thread_specific_ptr<RBX::DataModel::GenericJob *> *this)
{
  boost::shared_ptr<boost::detail::tss_cleanup_function>::element_type *v1; // r14
  boost::detail::sp_counted_base *v2; // rax

  v1 = (boost::shared_ptr<boost::detail::tss_cleanup_function>::element_type *)operator new(8u);
  v1->_vptr$tss_cleanup_function = (int (**)(void))&off_28C53B0;
  this->cleanup.px = v1;
  this->cleanup.pn.pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28C53F8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))v1;
  this->cleanup.pn.pi_ = v2;
}


// Address: 0x15935b0 | Name: _ZN5boost19thread_specific_ptrIPN3RBX9DataModel10GenericJobEE11delete_dataD0Ev
// Alternative name is 'j__ZdlPv_632'
// attributes: thunk
void __fastcall boost::thread_specific_ptr<RBX::DataModel::GenericJob *>::delete_data::~delete_data(
        boost::thread_specific_ptr<RBX::DataModel::GenericJob *>::delete_data *this)
{
  operator delete(this);
}


// Address: 0x15935c0 | Name: _ZN5boost19thread_specific_ptrIPN3RBX9DataModel10GenericJobEE11delete_dataclEPv
void __fastcall boost::thread_specific_ptr<RBX::DataModel::GenericJob *>::delete_data::operator()(
        boost::thread_specific_ptr<RBX::DataModel::GenericJob *>::delete_data *this,
        void *data)
{
  if ( data )
    operator delete(data);
}


// Address: 0x1593620 | Name: _ZN5boost19thread_specific_ptrIPN3RBX9DataModel10GenericJobEED2Ev
void __fastcall boost::thread_specific_ptr<RBX::DataModel::GenericJob *>::~thread_specific_ptr(
        boost::thread_specific_ptr<RBX::DataModel::GenericJob *> *this)
{
  bool v1; // r8
  volatile signed __int32 *v2; // rbx
  boost::detail::sp_counted_base *pi; // rbx
  __int128 v4; // [rsp+0h] [rbp-28h] BYREF

  v4 = 0;
  boost::detail::set_tss_data(
    this,
    (boost::shared_ptr<boost::detail::tss_cleanup_function>_0)(unsigned __int64)&v4,
    (char *)&dword_0 + 1,
    v1);
  v2 = (volatile signed __int32 *)*((_QWORD *)&v4 + 1);
  if ( *((_QWORD *)&v4 + 1) )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v4 + 1) + 8LL), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
      if ( !_InterlockedSub(v2 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
    }
  }
  pi = this->cleanup.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x15a25a0 | Name: _ZN5boost19thread_specific_ptrIPN3RBX9DataModel10GenericJobEE5resetEPS4_
void __fastcall boost::thread_specific_ptr<RBX::DataModel::GenericJob *>::reset(
        boost::thread_specific_ptr<RBX::DataModel::GenericJob *> *this,
        RBX::DataModel::GenericJob **new_value)
{
  bool v2; // r8
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::shared_ptr<boost::detail::tss_cleanup_function>_0 func; // [rsp+8h] [rbp-20h] BYREF

  if ( boost::detail::get_tss_data(this) != new_value )
  {
    func.px = this->cleanup.px;
    pi = this->cleanup.pn.pi_;
    func.pn.pi_ = pi;
    if ( pi )
      _InterlockedAdd(&pi->use_count_, 1u);
    boost::detail::set_tss_data(
      this,
      (boost::shared_ptr<boost::detail::tss_cleanup_function>_0)__PAIR128__((unsigned __int64)new_value, &func),
      (char *)&dword_0 + 1,
      v2);
    v4 = func.pn.pi_;
    if ( func.pn.pi_ && !_InterlockedSub(&func.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
  }
}


