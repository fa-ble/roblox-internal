// Address: 0xfeb710 | Name: _ZN5boost9algorithm10iter_splitINSt3__16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEEKS9_NS0_6detail13token_finderFINSD_10is_any_ofFIcEEEEEERT_SJ_RT0_T1_
std::vector<std::string> *__fastcall boost::algorithm::iter_split<std::vector<std::string>,std::string const,boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
        std::vector<std::string> *Result,
        const std::string *Input,
        _DWORD *a3)
{
  unsigned __int64 v5; // r13
  unsigned __int64 v6; // r13
  char *v7; // r15
  std::__wrap_iter<const char *> v8; // r13
  size_t v9; // rbx
  void *p_ptr; // rdi
  const void *v11; // rsi
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  unsigned __int64 v14; // rax
  void (__fastcall *v15)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v16)(__int128 *, __int128 *, __int64); // rax
  boost::detail::function::vtable_base *v17; // r15
  __int128 v18; // xmm1
  __m128i v19; // xmm0
  __int64 v20; // rax
  boost::detail::function::vtable_base *v21; // rbx
  boost::detail::function::vtable_base *v22; // rdi
  void (__fastcall *v23)(std::__wrap_iter<const char *> *, std::__wrap_iter<const char *> *, __int64); // rax
  void (__fastcall *v24)(std::__wrap_iter<const char *> *, std::__wrap_iter<const char *> *, __int64); // rax
  boost::iterators::transform_iterator<boost::algorithm::detail::copy_iterator_rangeF<std::string,std::__wrap_iter<const char *> >,boost::algorithm::split_iterator<std::__wrap_iter<const char *> >,boost::iterators::use_default,boost::iterators::use_default>_0 v26; // [rsp+0h] [rbp-1F8h] BYREF
  std::enable_if<true,boost::iterators::transform_iterator<boost::algorithm::detail::copy_iterator_rangeF<std::string,std::__wrap_iter<const char *> >,boost::algorithm::split_iterator<std::__wrap_iter<const char *> >,boost::iterators::use_default,boost::iterators::use_default> >::type_1 __last; // [rsp+50h] [rbp-1A8h] BYREF
  __int128 v28; // [rsp+A0h] [rbp-158h]
  char v29; // [rsp+B0h] [rbp-148h]
  unsigned __int64 v30; // [rsp+C0h] [rbp-138h]
  __int128 v31; // [rsp+C8h] [rbp-130h] BYREF
  std::__wrap_iter<const char *>::iterator_type v32; // [rsp+D8h] [rbp-120h]
  __int128 v33; // [rsp+E0h] [rbp-118h]
  __int128 v34; // [rsp+F0h] [rbp-108h]
  char v35; // [rsp+100h] [rbp-F8h]
  std::__wrap_iter<const char *>::iterator_type i; // [rsp+110h] [rbp-E8h]
  __int128 v37; // [rsp+118h] [rbp-E0h] BYREF
  std::__wrap_iter<const char *>::iterator_type v38; // [rsp+128h] [rbp-D0h]
  __int128 v39; // [rsp+130h] [rbp-C8h]
  __int128 v40; // [rsp+140h] [rbp-B8h]
  bool const_qualified; // [rsp+150h] [rbp-A8h]
  boost::algorithm::split_iterator<std::__wrap_iter<const char *> >_0 v42; // [rsp+160h] [rbp-98h] BYREF
  void *ptr; // [rsp+1A8h] [rbp-50h] BYREF
  unsigned __int64 v44; // [rsp+1B8h] [rbp-40h]
  int v45; // [rsp+1C0h] [rbp-38h]
  unsigned __int64 v46; // [rsp+1C8h] [rbp-30h]

  v46 = __readfsqword(0x28u);
  v5 = *(unsigned __int8 *)Input;
  if ( (v5 & 1) != 0 )
  {
    v6 = *((_QWORD *)Input + 1);
    v7 = (char *)*((_QWORD *)Input + 2);
  }
  else
  {
    v7 = (char *)Input + 1;
    v6 = v5 >> 1;
  }
  v8.__i = &v7[v6];
  v9 = *((_QWORD *)a3 + 2);
  v44 = v9;
  ptr = 0;
  if ( v9 > 0x10 )
  {
    p_ptr = operator new[](v9);
    ptr = p_ptr;
    v11 = *(const void **)a3;
  }
  else
  {
    p_ptr = &ptr;
    v11 = a3;
  }
  memcpy(p_ptr, v11, v9);
  v45 = a3[6];
  boost::algorithm::split_iterator<std::__wrap_iter<char const*>>::split_iterator<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
    &v42,
    (std::__wrap_iter<const char *>)v7,
    v8,
    (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> >)v26.m_iterator.boost::algorithm::detail::find_iterator_base<std::__wrap_iter<const char *> >);
  v26.m_iterator.m_Match.m_Begin.__i = 0;
  vtable = v42.m_Finder.vtable;
  if ( v42.m_Finder.vtable )
  {
    v26.m_iterator.m_Match.m_Begin.__i = (std::__wrap_iter<const char *>::iterator_type)v42.m_Finder.vtable;
    if ( ((__int64)v42.m_Finder.vtable & 1) != 0 )
    {
      v26.m_iterator.m_End.__i = (std::__wrap_iter<const char *>::iterator_type)v42.m_Finder.functor.bound_memfunc_ptr.obj_ptr;
      *(_OWORD *)&v26.m_iterator.m_Match.m_End.__i = *(_OWORD *)&v42.m_Finder.functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, std::__wrap_iter<const char *> *, _QWORD))((unsigned __int64)v42.m_Finder.vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v42.m_Finder.functor,
        &v26.m_iterator.m_Match.m_End,
        0);
      vtable = v42.m_Finder.vtable;
    }
  }
  else
  {
    vtable = 0;
  }
  *(boost::algorithm::split_iterator<std::__wrap_iter<const char *> >::match_type *)&v26.m_iterator.m_bEof = v42.m_Match;
  *(_OWORD *)&__last.m_iterator.m_Finder.vtable = *(_OWORD *)&v42.m_Next.__i;
  __last.m_iterator.m_Finder.functor.type.const_qualified = v42.m_bEof;
  if ( vtable )
  {
    if ( ((unsigned __int8)vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v42.m_Finder.functor, &v42.m_Finder.functor, 2);
    }
    v42.m_Finder.vtable = 0;
  }
  if ( v44 >= 0x11 && ptr )
    operator delete[](ptr);
  __last.m_iterator.m_Match.m_Begin.__i = 0;
  v28 = 0;
  *(_OWORD *)&__last.m_iterator.m_bEof = 0;
  v29 = 1;
  i = 0;
  if ( v26.m_iterator.m_Match.m_Begin.__i )
  {
    i = v26.m_iterator.m_Match.m_Begin.__i;
    if ( ((__int64)v26.m_iterator.m_Match.m_Begin.__i & 1) == 0 )
    {
      (*(void (__fastcall **)(std::__wrap_iter<const char *> *, __int128 *, _QWORD))((unsigned __int64)v26.m_iterator.m_Match.m_Begin.__i
                                                                                   & 0xFFFFFFFFFFFFFFFELL))(
        &v26.m_iterator.m_Match.m_End,
        &v37,
        0);
      v14 = (unsigned __int64)__last.m_iterator.m_Match.m_Begin.__i;
      goto LABEL_25;
    }
    v38 = v26.m_iterator.m_End.__i;
    v37 = *(_OWORD *)&v26.m_iterator.m_Match.m_End.__i;
  }
  v14 = 0;
LABEL_25:
  v39 = *(_OWORD *)&v26.m_iterator.m_bEof;
  v40 = *(_OWORD *)&__last.m_iterator.m_Finder.vtable;
  const_qualified = __last.m_iterator.m_Finder.functor.type.const_qualified;
  v30 = 0;
  if ( v14 )
  {
    v30 = v14;
    if ( (v14 & 1) != 0 )
    {
      v32 = __last.m_iterator.m_End.__i;
      v31 = *(_OWORD *)&__last.m_iterator.m_Match.m_End.__i;
    }
    else
    {
      (*(void (__fastcall **)(std::__wrap_iter<const char *> *, __int128 *, _QWORD))(v14 & 0xFFFFFFFFFFFFFFFELL))(
        &__last.m_iterator.m_Match.m_End,
        &v31,
        0);
    }
  }
  v33 = *(_OWORD *)&__last.m_iterator.m_bEof;
  v34 = v28;
  v35 = v29;
  std::vector<std::string>::vector<boost::iterators::transform_iterator<boost::algorithm::detail::copy_iterator_rangeF<std::string,std::__wrap_iter<char const*>>,boost::algorithm::split_iterator<std::__wrap_iter<char const*>>,boost::iterators::use_default,boost::iterators::use_default>>(
    (std::vector<std::string> *)&v26,
    v26,
    __last);
  if ( v30 )
  {
    if ( (v30 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v30 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v31, &v31, 2);
    }
    v30 = 0;
  }
  if ( i )
  {
    if ( ((unsigned __int8)i & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)i & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v37, &v37, 2);
    }
    i = 0;
  }
  v18 = *(_OWORD *)&v26.m_iterator.m_Finder.vtable;
  v26.m_iterator.m_Finder.vtable = *(boost::detail::function::vtable_base **)Result;
  v17 = v26.m_iterator.m_Finder.vtable;
  v19 = _mm_loadu_si128((const __m128i *)((char *)Result + 8));
  *(_OWORD *)Result = v18;
  *((_QWORD *)Result + 2) = *((_QWORD *)&v26.m_iterator.m_Finder.functor.data + 1);
  *(__m128i *)&v26.m_iterator.m_Finder.functor.obj_ptr = v19;
  if ( v17 )
  {
    v20 = v19.m128i_i64[0];
    if ( (boost::detail::function::vtable_base *)v19.m128i_i64[0] == v17 )
    {
      v22 = v17;
    }
    else
    {
      do
      {
        v21 = (boost::detail::function::vtable_base *)(v20 - 24);
        if ( (*(_BYTE *)(v20 - 24) & 1) != 0 )
          operator delete(*(void **)(v20 - 8));
        v20 = (__int64)v21;
      }
      while ( v17 != v21 );
      v22 = v26.m_iterator.m_Finder.vtable;
    }
    v26.m_iterator.m_Finder.functor.obj_ptr = v17;
    operator delete(v22);
  }
  if ( __last.m_iterator.m_Match.m_Begin.__i )
  {
    if ( ((__int64)__last.m_iterator.m_Match.m_Begin.__i & 1) == 0 )
    {
      v23 = *(void (__fastcall **)(std::__wrap_iter<const char *> *, std::__wrap_iter<const char *> *, __int64))((unsigned __int64)__last.m_iterator.m_Match.m_Begin.__i & 0xFFFFFFFFFFFFFFFELL);
      if ( v23 )
        v23(&__last.m_iterator.m_Match.m_End, &__last.m_iterator.m_Match.m_End, 2);
    }
    __last.m_iterator.m_Match.m_Begin.__i = 0;
  }
  if ( v26.m_iterator.m_Match.m_Begin.__i )
  {
    if ( ((__int64)v26.m_iterator.m_Match.m_Begin.__i & 1) == 0 )
    {
      v24 = *(void (__fastcall **)(std::__wrap_iter<const char *> *, std::__wrap_iter<const char *> *, __int64))((unsigned __int64)v26.m_iterator.m_Match.m_Begin.__i & 0xFFFFFFFFFFFFFFFELL);
      if ( v24 )
        v24(&v26.m_iterator.m_Match.m_End, &v26.m_iterator.m_Match.m_End, 2);
    }
    v26.m_iterator.m_Match.m_Begin.__i = 0;
  }
  return Result;
}


// Address: 0x1015000 | Name: _ZN5boost9algorithm10iter_splitINSt3__13setINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS2_4lessIS9_EENS7_IS9_EEEEKS9_NS0_6detail13token_finderFINSF_10is_any_ofFIcEEEEEERT_SL_RT0_T1_
__m128i *__fastcall boost::algorithm::iter_split<std::set<std::string>,std::string const,boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
        std::set<std::string> *Result,
        const std::string *Input,
        _DWORD *a3)
{
  unsigned __int64 v5; // rbp
  unsigned __int64 v6; // rbp
  char *v7; // r15
  std::__wrap_iter<const char *> v8; // rbp
  size_t v9; // rbx
  void *v10; // rdi
  const void *v11; // rsi
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  __int64 v14; // rax
  unsigned __int64 v15; // r8
  char v16; // cl
  std::__wrap_iter<const char *>::iterator_type v17; // rbp
  unsigned __int64 i; // r12
  unsigned __int64 v19; // r15
  _BYTE *v20; // rax
  unsigned __int64 v21; // rcx
  _BYTE *v22; // rcx
  unsigned __int64 v23; // r12
  __int64 v24; // rdx
  std::__tree_node_base<void *> *v25; // r12
  const char *v26; // rcx
  __int64 v27; // rax
  __int64 v28; // rdx
  std::__tree_node_base<void *> *left; // rax
  std::__tree<std::string>::__parent_pointer v30; // rcx
  __int64 v31; // rdi
  unsigned __int64 v32; // r8
  __int64 v33; // rsi
  __int64 v34; // rdi
  __int64 v35; // rbx
  __int128 v36; // xmm1
  __int128 v37; // xmm1
  __int128 v38; // xmm1
  __int128 v39; // xmm1
  __int64 v40; // rbx
  __int64 v41; // rdi
  __int64 v42; // rsi
  __int64 v43; // rdx
  __int128 v44; // xmm1
  __m128i *v45; // rbx
  void (__fastcall **v46)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // r8
  void (__fastcall *v47)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v48)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  __m128i si128; // xmm0
  __m128i v50; // xmm1
  unsigned __int64 v51; // rcx
  unsigned __int64 value; // rdx
  __int64 *v53; // rdi
  std::__tree_node<std::string,void *> *v54; // xmm0_8
  std::__tree<std::string> *p_hint; // rax
  __int64 v56; // rcx
  __int64 v57; // r8
  __int64 v58; // r9
  void (__fastcall *v59)(__int128 *, __int128 *, __int64, __int64, __int64, __int64, std::__tree<std::string>::__iter_pointer, std::__tree_end_node<std::__tree_node_base<void *> *>::pointer, unsigned __int64); // rax
  void (__fastcall *v60)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  std::__tree<std::string> __hint; // [rsp+0h] [rbp-2D8h] BYREF
  __int128 v63; // [rsp+20h] [rbp-2B8h] BYREF
  void *v64; // [rsp+30h] [rbp-2A8h]
  unsigned __int64 v65; // [rsp+40h] [rbp-298h]
  boost::detail::function::function_buffer v66; // [rsp+48h] [rbp-290h] BYREF
  boost::algorithm::split_iterator<std::__wrap_iter<const char *> >::match_type v67; // [rsp+60h] [rbp-278h]
  __int128 v68; // [rsp+70h] [rbp-268h]
  char v69; // [rsp+80h] [rbp-258h]
  __int64 v70; // [rsp+90h] [rbp-248h]
  __int128 v71; // [rsp+98h] [rbp-240h] BYREF
  __int64 v72; // [rsp+A8h] [rbp-230h]
  __int128 v73; // [rsp+B0h] [rbp-228h]
  __int128 v74; // [rsp+C0h] [rbp-218h]
  char v75; // [rsp+D0h] [rbp-208h]
  unsigned __int64 v76; // [rsp+E0h] [rbp-1F8h]
  boost::detail::function::function_buffer v77; // [rsp+E8h] [rbp-1F0h] BYREF
  boost::algorithm::split_iterator<std::__wrap_iter<const char *> >::match_type v78; // [rsp+100h] [rbp-1D8h]
  __int128 v79; // [rsp+110h] [rbp-1C8h]
  char v80; // [rsp+120h] [rbp-1B8h]
  unsigned __int64 v81; // [rsp+130h] [rbp-1A8h]
  boost::detail::function::function_buffer functor; // [rsp+138h] [rbp-1A0h] BYREF
  boost::algorithm::split_iterator<std::__wrap_iter<const char *> >::match_type m_Match; // [rsp+150h] [rbp-188h]
  __int128 v84; // [rsp+160h] [rbp-178h]
  bool m_bEof; // [rsp+170h] [rbp-168h]
  std::set<std::string> *v86; // [rsp+180h] [rbp-158h]
  std::__tree<std::string>::__parent_pointer __parent; // [rsp+188h] [rbp-150h] BYREF
  __int64 v88; // [rsp+190h] [rbp-148h]
  __int128 v89; // [rsp+198h] [rbp-140h] BYREF
  __int64 v90; // [rsp+1A8h] [rbp-130h]
  __int128 v91; // [rsp+1B0h] [rbp-128h]
  __int128 v92; // [rsp+1C0h] [rbp-118h]
  char v93; // [rsp+1D0h] [rbp-108h]
  __int64 v94; // [rsp+1E0h] [rbp-F8h]
  __int128 v95; // [rsp+1E8h] [rbp-F0h] BYREF
  __int64 v96; // [rsp+1F8h] [rbp-E0h]
  __int128 v97; // [rsp+200h] [rbp-D8h]
  __int128 v98; // [rsp+210h] [rbp-C8h]
  char v99; // [rsp+220h] [rbp-B8h]
  boost::algorithm::split_iterator<std::__wrap_iter<const char *> >_0 v100; // [rsp+230h] [rbp-A8h] BYREF
  std::__tree<std::string>::__node_base_pointer __dummy; // [rsp+278h] [rbp-60h] BYREF
  void *ptr[2]; // [rsp+280h] [rbp-58h] BYREF
  unsigned __int64 v103; // [rsp+290h] [rbp-48h]
  int v104; // [rsp+298h] [rbp-40h]
  unsigned __int64 v105; // [rsp+2A0h] [rbp-38h]

  v105 = __readfsqword(0x28u);
  v5 = *(unsigned __int8 *)Input;
  if ( (v5 & 1) != 0 )
  {
    v6 = *((_QWORD *)Input + 1);
    v7 = (char *)*((_QWORD *)Input + 2);
  }
  else
  {
    v7 = (char *)Input + 1;
    v6 = v5 >> 1;
  }
  v8.__i = &v7[v6];
  v9 = *((_QWORD *)a3 + 2);
  v103 = v9;
  ptr[0] = 0;
  if ( v9 > 0x10 )
  {
    v10 = operator new[](v9);
    ptr[0] = v10;
    v11 = *(const void **)a3;
  }
  else
  {
    v10 = ptr;
    v11 = a3;
  }
  memcpy(v10, v11, v9);
  v104 = a3[6];
  boost::algorithm::split_iterator<std::__wrap_iter<char const*>>::split_iterator<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
    &v100,
    (std::__wrap_iter<const char *>)v7,
    v8,
    ptr);
  v81 = 0;
  vtable = v100.m_Finder.vtable;
  if ( v100.m_Finder.vtable )
  {
    v81 = (unsigned __int64)v100.m_Finder.vtable;
    if ( ((__int64)v100.m_Finder.vtable & 1) != 0 )
    {
      functor = v100.m_Finder.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v100.m_Finder.vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v100.m_Finder.functor,
        &functor,
        0);
      vtable = v100.m_Finder.vtable;
    }
  }
  else
  {
    vtable = 0;
  }
  m_Match = v100.m_Match;
  v84 = *(_OWORD *)&v100.m_Next.__i;
  m_bEof = v100.m_bEof;
  if ( vtable )
  {
    if ( ((unsigned __int8)vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v100.m_Finder.functor, &v100.m_Finder.functor, 2);
    }
    v100.m_Finder.vtable = 0;
  }
  if ( v103 >= 0x11 && ptr[0] )
    operator delete[](ptr[0]);
  v94 = 0;
  v98 = 0;
  v97 = 0;
  v99 = 1;
  v76 = 0;
  if ( !v81 )
    goto LABEL_24;
  v76 = v81;
  if ( (v81 & 1) != 0 )
  {
    v77 = functor;
LABEL_24:
    v14 = 0;
    goto LABEL_25;
  }
  (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))(v81 & 0xFFFFFFFFFFFFFFFELL))(
    &functor,
    &v77,
    0);
  v14 = v94;
LABEL_25:
  v78 = m_Match;
  v79 = v84;
  v80 = m_bEof;
  v70 = 0;
  if ( v14 )
  {
    v70 = v14;
    if ( (v14 & 1) != 0 )
    {
      v72 = v96;
      v71 = v95;
    }
    else
    {
      (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(v14 & 0xFFFFFFFFFFFFFFFELL))(&v95, &v71, 0);
    }
  }
  v73 = v97;
  v74 = v98;
  v75 = v99;
  *(_OWORD *)&__hint.__pair1_.__value_.__left_ = 0;
  __hint.__begin_node_ = &__hint.__pair1_.__value_;
  v65 = 0;
  if ( v76 )
  {
    v65 = v76;
    if ( (v76 & 1) != 0 )
      v66 = v77;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))(v76 & 0xFFFFFFFFFFFFFFFELL))(
        &v77,
        &v66,
        0);
  }
  v67 = v78;
  v68 = v79;
  v69 = v80;
  v88 = 0;
  if ( v70 )
  {
    v88 = v70;
    if ( (v70 & 1) != 0 )
    {
      v90 = v72;
      v89 = v71;
    }
    else
    {
      (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(v70 & 0xFFFFFFFFFFFFFFFELL))(&v71, &v89, 0);
    }
  }
  v86 = Result;
  v91 = v73;
  v92 = v74;
  v93 = v75;
  while ( 1 )
  {
    v15 = v65;
    v16 = v65 == 0 || v69 != 0;
    if ( !v88 )
    {
      if ( v16 )
        goto LABEL_92;
      goto LABEL_44;
    }
    if ( ((v93 == 0) & (unsigned __int8)~v16) == 0 )
    {
      if ( (v93 != 0) == v16 )
        goto LABEL_88;
      goto LABEL_44;
    }
    i = (unsigned __int64)v67.m_End.__i;
    v17 = v67.m_Begin.__i;
    v19 = v67.m_End.__i - v67.m_Begin.__i;
    if ( v67.m_End.__i - v67.m_Begin.__i == *((_QWORD *)&v91 + 1) - (_QWORD)v91 )
      break;
LABEL_45:
    v63 = 0;
    v64 = 0;
    if ( v19 >= 0xFFFFFFFFFFFFFFF0LL )
      std::__basic_string_common<true>::__throw_length_error(&v63);
    if ( v19 > 0x16 )
    {
      v20 = operator new((v19 + 16) & 0xFFFFFFFFFFFFFFF0LL);
      v64 = v20;
      *(_QWORD *)&v63 = (v19 + 16) & 0xFFFFFFFFFFFFFFF0LL | 1;
      *((_QWORD *)&v63 + 1) = v19;
      if ( v17 == (std::__wrap_iter<const char *>::iterator_type)i )
        goto LABEL_57;
LABEL_50:
      v21 = i - (_QWORD)v17;
      if ( i - (unsigned __int64)v17 < 0x20 || (unsigned __int64)v20 < i && (unsigned __int64)v17 < i + v20 - v17 )
      {
        v22 = v20;
LABEL_54:
        v23 = i - (_QWORD)v17;
        v24 = 0;
        do
        {
          v22[v24] = v17[v24];
          ++v24;
        }
        while ( v23 != v24 );
        goto LABEL_56;
      }
      v32 = v21 & 0xFFFFFFFFFFFFFFE0LL;
      v33 = ((unsigned __int8)(((v21 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3;
      if ( (v21 & 0xFFFFFFFFFFFFFFE0LL) - 32 >= 0x60 )
      {
        v35 = v33 - ((((v21 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1);
        v34 = 0;
        do
        {
          v36 = *(_OWORD *)&v17[v34 + 16];
          *(_OWORD *)&v20[v34] = *(_OWORD *)&v17[v34];
          *(_OWORD *)&v20[v34 + 16] = v36;
          v37 = *(_OWORD *)&v17[v34 + 48];
          *(_OWORD *)&v20[v34 + 32] = *(_OWORD *)&v17[v34 + 32];
          *(_OWORD *)&v20[v34 + 48] = v37;
          v38 = *(_OWORD *)&v17[v34 + 80];
          *(_OWORD *)&v20[v34 + 64] = *(_OWORD *)&v17[v34 + 64];
          *(_OWORD *)&v20[v34 + 80] = v38;
          v39 = *(_OWORD *)&v17[v34 + 112];
          *(_OWORD *)&v20[v34 + 96] = *(_OWORD *)&v17[v34 + 96];
          *(_OWORD *)&v20[v34 + 112] = v39;
          v34 += 128;
          v35 += 4;
        }
        while ( v35 );
        if ( (((unsigned __int8)(((v21 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) != 0 )
          goto LABEL_84;
      }
      else
      {
        v34 = 0;
        if ( (((unsigned __int8)(((v21 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
          goto LABEL_86;
LABEL_84:
        v40 = (__int64)&v17[v34 + 16];
        v41 = (__int64)&v20[v34 + 16];
        v42 = 32 * v33;
        v43 = 0;
        do
        {
          v44 = *(_OWORD *)(v40 + v43);
          *(_OWORD *)(v41 + v43 - 16) = *(_OWORD *)(v40 + v43 - 16);
          *(_OWORD *)(v41 + v43) = v44;
          v43 += 32;
        }
        while ( v42 != v43 );
      }
LABEL_86:
      if ( v32 != v21 )
      {
        v22 = &v20[v32];
        v17 += v32;
        goto LABEL_54;
      }
LABEL_56:
      v20 += v19;
      goto LABEL_57;
    }
    LOBYTE(v63) = 2 * v19;
    v20 = (char *)&v63 + 1;
    if ( v17 != (std::__wrap_iter<const char *>::iterator_type)i )
      goto LABEL_50;
LABEL_57:
    *v20 = 0;
    v25 = std::__tree<std::string>::__find_equal<std::string>(
            &__hint,
            (std::__tree<std::string>::const_iterator)&__hint.__pair1_,
            &__parent,
            &__dummy,
            (const std::string *)&v63);
    if ( v25->__left_ )
    {
      if ( (v63 & 1) == 0 )
        goto LABEL_60;
LABEL_59:
      operator delete(v64);
      goto LABEL_60;
    }
    left = (std::__tree_node_base<void *> *)operator new(0x38u);
    left[1].__parent_ = (std::__tree_node_base<void *>::__parent_pointer)v64;
    *(_OWORD *)&left[1].__left_ = v63;
    v63 = 0;
    v64 = 0;
    v30 = __parent;
    *(_OWORD *)&left->__left_ = 0;
    left->__parent_ = v30;
    v25->__left_ = left;
    if ( __hint.__begin_node_->__left_ )
    {
      __hint.__begin_node_ = __hint.__begin_node_->__left_;
      left = v25->__left_;
    }
    std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(__hint.__pair1_.__value_.__left_, left);
    ++__hint.__pair3_.__value_;
    if ( (v63 & 1) != 0 )
      goto LABEL_59;
LABEL_60:
    v26 = (const char *)*((_QWORD *)&v68 + 1);
    if ( v65 )
    {
      v27 = (*(__int64 (__fastcall **)(boost::detail::function::function_buffer *, _QWORD, _QWORD))((v65 & 0xFFFFFFFFFFFFFFFELL)
                                                                                                  + 8))(
              &v66,
              v68,
              *((_QWORD *)&v68 + 1));
      v26 = (const char *)*((_QWORD *)&v68 + 1);
      if ( v28 != *((_QWORD *)&v68 + 1) )
        goto LABEL_38;
    }
    else
    {
      v28 = *((_QWORD *)&v68 + 1);
      v27 = *((_QWORD *)&v68 + 1);
    }
    if ( (const char *)v27 == v26 && v67.m_End.__i == v26 )
      v69 = 1;
LABEL_38:
    v67.m_Begin.__i = (std::__wrap_iter<const char *>::iterator_type)v68;
    v67.m_End.__i = (std::__wrap_iter<const char *>::iterator_type)v27;
    *(_QWORD *)&v68 = v28;
  }
  if ( v67.m_Begin.__i != v67.m_End.__i )
  {
    v31 = 0;
    while ( v67.m_Begin.__i[v31] == *(_BYTE *)(v91 + v31) )
    {
      if ( v67.m_End.__i - v67.m_Begin.__i == ++v31 )
        goto LABEL_75;
    }
    goto LABEL_45;
  }
LABEL_75:
  if ( (_QWORD)v68 != (_QWORD)v92 )
    goto LABEL_45;
  if ( *((_QWORD *)&v68 + 1) != *((_QWORD *)&v92 + 1) )
  {
LABEL_44:
    i = (unsigned __int64)v67.m_End.__i;
    v17 = v67.m_Begin.__i;
    v19 = v67.m_End.__i - v67.m_Begin.__i;
    goto LABEL_45;
  }
LABEL_88:
  if ( (v88 & 1) == 0 && *(_QWORD *)(v88 & 0xFFFFFFFFFFFFFFFELL) )
  {
    (*(void (__fastcall **)(__int128 *, __int128 *, __int64))(v88 & 0xFFFFFFFFFFFFFFFELL))(&v89, &v89, 2);
    v15 = v65;
  }
  v88 = 0;
LABEL_92:
  v45 = (__m128i *)v86;
  if ( v15 )
  {
    if ( (v15 & 1) == 0 )
    {
      v46 = (void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))(v15 & 0xFFFFFFFFFFFFFFFELL);
      if ( *v46 )
        (*v46)(&v66, &v66, 2);
    }
    v65 = 0;
  }
  if ( v70 )
  {
    if ( (v70 & 1) == 0 )
    {
      v47 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v70 & 0xFFFFFFFFFFFFFFFELL);
      if ( v47 )
        v47(&v71, &v71, 2);
    }
    v70 = 0;
  }
  if ( v76 )
  {
    if ( (v76 & 1) == 0 )
    {
      v48 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))(v76 & 0xFFFFFFFFFFFFFFFELL);
      if ( v48 )
        v48(&v77, &v77, 2);
    }
    v76 = 0;
  }
  si128 = _mm_load_si128((const __m128i *)&__hint);
  v50 = _mm_loadu_si128(v45);
  *v45 = si128;
  *(__m128i *)&__hint.__begin_node_ = v50;
  v51 = v45[1].m128i_u64[0];
  value = __hint.__pair3_.__value_;
  v45[1].m128i_i64[0] = __hint.__pair3_.__value_;
  __hint.__pair3_.__value_ = v51;
  v53 = (__int64 *)(_mm_shuffle_epi32(si128, 78).m128i_u64[0] + 16);
  v54 = (std::__tree_node<std::string,void *> *)_mm_shuffle_epi32(v50, 78).m128i_u64[0];
  if ( !value )
    v53 = (__int64 *)v45;
  *v53 = (__int64)&v45->m128i_i64[1];
  p_hint = (std::__tree<std::string> *)((char *)v54 + 16);
  if ( !v51 )
    p_hint = &__hint;
  p_hint->__begin_node_ = &__hint.__pair1_.__value_;
  std::__tree<std::string>::destroy(&__hint, v54);
  if ( v94 )
  {
    if ( (v94 & 1) == 0 )
    {
      v59 = *(void (__fastcall **)(__int128 *, __int128 *, __int64, __int64, __int64, __int64, std::__tree<std::string>::__iter_pointer, std::__tree_end_node<std::__tree_node_base<void *> *>::pointer, unsigned __int64))(v94 & 0xFFFFFFFFFFFFFFFELL);
      if ( v59 )
        v59(
          &v95,
          &v95,
          2,
          v56,
          v57,
          v58,
          __hint.__begin_node_,
          __hint.__pair1_.__value_.__left_,
          __hint.__pair3_.__value_);
    }
    v94 = 0;
  }
  if ( v81 )
  {
    if ( (v81 & 1) == 0 )
    {
      v60 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))(v81 & 0xFFFFFFFFFFFFFFFELL);
      if ( v60 )
        v60(&functor, &functor, 2);
    }
    v81 = 0;
  }
  return v45;
}


// Address: 0x10189e0 | Name: _ZN5boost9algorithm10iter_splitINSt3__16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEES9_NS0_6detail13token_finderFINSC_10is_any_ofFIcEEEEEERT_SI_RT0_T1_
std::vector<std::string> *__fastcall boost::algorithm::iter_split<std::vector<std::string>,std::string,boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
        std::vector<std::string> *Result,
        std::string *Input,
        _DWORD *a3)
{
  unsigned __int64 v5; // r13
  unsigned __int64 v6; // r13
  char *v7; // r15
  std::__wrap_iter<char *> v8; // r13
  size_t v9; // rbx
  void *p_ptr; // rdi
  const void *v11; // rsi
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  unsigned __int64 v14; // rax
  void (__fastcall *v15)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v16)(__int128 *, __int128 *, __int64); // rax
  boost::detail::function::vtable_base *v17; // r15
  __int128 v18; // xmm1
  __m128i v19; // xmm0
  __int64 v20; // rax
  boost::detail::function::vtable_base *v21; // rbx
  boost::detail::function::vtable_base *v22; // rdi
  void (__fastcall *v23)(std::__wrap_iter<char *> *, std::__wrap_iter<char *> *, __int64); // rax
  void (__fastcall *v24)(std::__wrap_iter<char *> *, std::__wrap_iter<char *> *, __int64); // rax
  boost::iterators::transform_iterator<boost::algorithm::detail::copy_iterator_rangeF<std::string,std::__wrap_iter<char *> >,boost::algorithm::split_iterator<std::__wrap_iter<char *> >,boost::iterators::use_default,boost::iterators::use_default> v26; // [rsp+0h] [rbp-1F8h] BYREF
  std::enable_if<true,boost::iterators::transform_iterator<boost::algorithm::detail::copy_iterator_rangeF<std::string,std::__wrap_iter<char *> >,boost::algorithm::split_iterator<std::__wrap_iter<char *> >,boost::iterators::use_default,boost::iterators::use_default> >::type __last; // [rsp+50h] [rbp-1A8h] BYREF
  __int128 v28; // [rsp+A0h] [rbp-158h]
  char v29; // [rsp+B0h] [rbp-148h]
  unsigned __int64 v30; // [rsp+C0h] [rbp-138h]
  __int128 v31; // [rsp+C8h] [rbp-130h] BYREF
  std::__wrap_iter<char *>::iterator_type v32; // [rsp+D8h] [rbp-120h]
  __int128 v33; // [rsp+E0h] [rbp-118h]
  __int128 v34; // [rsp+F0h] [rbp-108h]
  char v35; // [rsp+100h] [rbp-F8h]
  std::__wrap_iter<char *>::iterator_type i; // [rsp+110h] [rbp-E8h]
  __int128 v37; // [rsp+118h] [rbp-E0h] BYREF
  std::__wrap_iter<char *>::iterator_type v38; // [rsp+128h] [rbp-D0h]
  __int128 v39; // [rsp+130h] [rbp-C8h]
  __int128 v40; // [rsp+140h] [rbp-B8h]
  bool const_qualified; // [rsp+150h] [rbp-A8h]
  boost::algorithm::split_iterator<std::__wrap_iter<char *> > v42; // [rsp+160h] [rbp-98h] BYREF
  void *ptr; // [rsp+1A8h] [rbp-50h] BYREF
  unsigned __int64 v44; // [rsp+1B8h] [rbp-40h]
  int v45; // [rsp+1C0h] [rbp-38h]
  unsigned __int64 v46; // [rsp+1C8h] [rbp-30h]

  v46 = __readfsqword(0x28u);
  v5 = *(unsigned __int8 *)Input;
  if ( (v5 & 1) != 0 )
  {
    v6 = *((_QWORD *)Input + 1);
    v7 = (char *)*((_QWORD *)Input + 2);
  }
  else
  {
    v7 = (char *)Input + 1;
    v6 = v5 >> 1;
  }
  v8.__i = &v7[v6];
  v9 = *((_QWORD *)a3 + 2);
  v44 = v9;
  ptr = 0;
  if ( v9 > 0x10 )
  {
    p_ptr = operator new[](v9);
    ptr = p_ptr;
    v11 = *(const void **)a3;
  }
  else
  {
    p_ptr = &ptr;
    v11 = a3;
  }
  memcpy(p_ptr, v11, v9);
  v45 = a3[6];
  boost::algorithm::split_iterator<std::__wrap_iter<char *>>::split_iterator<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
    &v42,
    (std::__wrap_iter<char *>)v7,
    v8,
    (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> >)v26.m_iterator.boost::algorithm::detail::find_iterator_base<std::__wrap_iter<char *> >);
  v26.m_iterator.m_Match.m_Begin.__i = 0;
  vtable = v42.m_Finder.vtable;
  if ( v42.m_Finder.vtable )
  {
    v26.m_iterator.m_Match.m_Begin.__i = (std::__wrap_iter<char *>::iterator_type)v42.m_Finder.vtable;
    if ( ((__int64)v42.m_Finder.vtable & 1) != 0 )
    {
      v26.m_iterator.m_End.__i = (std::__wrap_iter<char *>::iterator_type)v42.m_Finder.functor.bound_memfunc_ptr.obj_ptr;
      *(_OWORD *)&v26.m_iterator.m_Match.m_End.__i = *(_OWORD *)&v42.m_Finder.functor.obj_ptr;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, std::__wrap_iter<char *> *, _QWORD))((unsigned __int64)v42.m_Finder.vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v42.m_Finder.functor,
        &v26.m_iterator.m_Match.m_End,
        0);
      vtable = v42.m_Finder.vtable;
    }
  }
  else
  {
    vtable = 0;
  }
  *(boost::algorithm::split_iterator<std::__wrap_iter<char *> >::match_type *)&v26.m_iterator.m_bEof = v42.m_Match;
  *(_OWORD *)&__last.m_iterator.m_Finder.vtable = *(_OWORD *)&v42.m_Next.__i;
  __last.m_iterator.m_Finder.functor.type.const_qualified = v42.m_bEof;
  if ( vtable )
  {
    if ( ((unsigned __int8)vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v42.m_Finder.functor, &v42.m_Finder.functor, 2);
    }
    v42.m_Finder.vtable = 0;
  }
  if ( v44 >= 0x11 && ptr )
    operator delete[](ptr);
  __last.m_iterator.m_Match.m_Begin.__i = 0;
  v28 = 0;
  *(_OWORD *)&__last.m_iterator.m_bEof = 0;
  v29 = 1;
  i = 0;
  if ( v26.m_iterator.m_Match.m_Begin.__i )
  {
    i = v26.m_iterator.m_Match.m_Begin.__i;
    if ( ((__int64)v26.m_iterator.m_Match.m_Begin.__i & 1) == 0 )
    {
      (*(void (__fastcall **)(std::__wrap_iter<char *> *, __int128 *, _QWORD))((unsigned __int64)v26.m_iterator.m_Match.m_Begin.__i
                                                                             & 0xFFFFFFFFFFFFFFFELL))(
        &v26.m_iterator.m_Match.m_End,
        &v37,
        0);
      v14 = (unsigned __int64)__last.m_iterator.m_Match.m_Begin.__i;
      goto LABEL_25;
    }
    v38 = v26.m_iterator.m_End.__i;
    v37 = *(_OWORD *)&v26.m_iterator.m_Match.m_End.__i;
  }
  v14 = 0;
LABEL_25:
  v39 = *(_OWORD *)&v26.m_iterator.m_bEof;
  v40 = *(_OWORD *)&__last.m_iterator.m_Finder.vtable;
  const_qualified = __last.m_iterator.m_Finder.functor.type.const_qualified;
  v30 = 0;
  if ( v14 )
  {
    v30 = v14;
    if ( (v14 & 1) != 0 )
    {
      v32 = __last.m_iterator.m_End.__i;
      v31 = *(_OWORD *)&__last.m_iterator.m_Match.m_End.__i;
    }
    else
    {
      (*(void (__fastcall **)(std::__wrap_iter<char *> *, __int128 *, _QWORD))(v14 & 0xFFFFFFFFFFFFFFFELL))(
        &__last.m_iterator.m_Match.m_End,
        &v31,
        0);
    }
  }
  v33 = *(_OWORD *)&__last.m_iterator.m_bEof;
  v34 = v28;
  v35 = v29;
  std::vector<std::string>::vector<boost::iterators::transform_iterator<boost::algorithm::detail::copy_iterator_rangeF<std::string,std::__wrap_iter<char *>>,boost::algorithm::split_iterator<std::__wrap_iter<char *>>,boost::iterators::use_default,boost::iterators::use_default>>(
    (std::vector<std::string> *)&v26,
    v26,
    __last);
  if ( v30 )
  {
    if ( (v30 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v30 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v31, &v31, 2);
    }
    v30 = 0;
  }
  if ( i )
  {
    if ( ((unsigned __int8)i & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)i & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v37, &v37, 2);
    }
    i = 0;
  }
  v18 = *(_OWORD *)&v26.m_iterator.m_Finder.vtable;
  v26.m_iterator.m_Finder.vtable = *(boost::detail::function::vtable_base **)Result;
  v17 = v26.m_iterator.m_Finder.vtable;
  v19 = _mm_loadu_si128((const __m128i *)((char *)Result + 8));
  *(_OWORD *)Result = v18;
  *((_QWORD *)Result + 2) = *((_QWORD *)&v26.m_iterator.m_Finder.functor.data + 1);
  *(__m128i *)&v26.m_iterator.m_Finder.functor.obj_ptr = v19;
  if ( v17 )
  {
    v20 = v19.m128i_i64[0];
    if ( (boost::detail::function::vtable_base *)v19.m128i_i64[0] == v17 )
    {
      v22 = v17;
    }
    else
    {
      do
      {
        v21 = (boost::detail::function::vtable_base *)(v20 - 24);
        if ( (*(_BYTE *)(v20 - 24) & 1) != 0 )
          operator delete(*(void **)(v20 - 8));
        v20 = (__int64)v21;
      }
      while ( v17 != v21 );
      v22 = v26.m_iterator.m_Finder.vtable;
    }
    v26.m_iterator.m_Finder.functor.obj_ptr = v17;
    operator delete(v22);
  }
  if ( __last.m_iterator.m_Match.m_Begin.__i )
  {
    if ( ((__int64)__last.m_iterator.m_Match.m_Begin.__i & 1) == 0 )
    {
      v23 = *(void (__fastcall **)(std::__wrap_iter<char *> *, std::__wrap_iter<char *> *, __int64))((unsigned __int64)__last.m_iterator.m_Match.m_Begin.__i & 0xFFFFFFFFFFFFFFFELL);
      if ( v23 )
        v23(&__last.m_iterator.m_Match.m_End, &__last.m_iterator.m_Match.m_End, 2);
    }
    __last.m_iterator.m_Match.m_Begin.__i = 0;
  }
  if ( v26.m_iterator.m_Match.m_Begin.__i )
  {
    if ( ((__int64)v26.m_iterator.m_Match.m_Begin.__i & 1) == 0 )
    {
      v24 = *(void (__fastcall **)(std::__wrap_iter<char *> *, std::__wrap_iter<char *> *, __int64))((unsigned __int64)v26.m_iterator.m_Match.m_Begin.__i & 0xFFFFFFFFFFFFFFFELL);
      if ( v24 )
        v24(&v26.m_iterator.m_Match.m_End, &v26.m_iterator.m_Match.m_End, 2);
    }
    v26.m_iterator.m_Match.m_Begin.__i = 0;
  }
  return Result;
}


// Address: 0x110f9d0 | Name: _ZN5boost9algorithm10iter_splitINSt3__16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEENS_16basic_string_refIcS6_EENS0_6detail13token_finderFINSE_10is_any_ofFIcEEEEEERT_SK_RT0_T1_
std::vector<std::string> *__fastcall boost::algorithm::iter_split<std::vector<std::string>,boost::basic_string_ref<char,std::char_traits<char>>,boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
        std::vector<std::string> *Result,
        boost::basic_string_ref<char,std::char_traits<char> > *Input,
        _DWORD *a3)
{
  const char *v5; // r15
  const char *v6; // r12
  size_t v7; // rbx
  void *p_ptr; // rdi
  const void *v9; // rsi
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  __int64 v12; // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  void *v15; // r15
  __int128 v16; // xmm1
  __m128i v17; // xmm0
  __int64 v18; // rax
  void *v19; // rbx
  void *v20; // rdi
  void (__fastcall *v21)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v22)(_BYTE *, _BYTE *, __int64); // rax
  _BYTE v24[168]; // [rsp+0h] [rbp-238h] BYREF
  char v25; // [rsp+A8h] [rbp-190h]
  __int64 v26; // [rsp+B8h] [rbp-180h]
  __int128 v27; // [rsp+C0h] [rbp-178h] BYREF
  __int64 v28; // [rsp+D0h] [rbp-168h]
  __int128 v29; // [rsp+D8h] [rbp-160h]
  __int128 v30; // [rsp+E8h] [rbp-150h]
  char v31; // [rsp+F8h] [rbp-140h]
  __int64 v32; // [rsp+108h] [rbp-130h]
  __int128 v33; // [rsp+110h] [rbp-128h] BYREF
  __int64 v34; // [rsp+120h] [rbp-118h]
  __int128 v35; // [rsp+128h] [rbp-110h]
  __int128 v36; // [rsp+138h] [rbp-100h]
  char v37; // [rsp+148h] [rbp-F0h]
  boost::algorithm::split_iterator<const char *> v38; // [rsp+158h] [rbp-E0h] BYREF
  __int64 v39; // [rsp+1A0h] [rbp-98h]
  __int128 v40; // [rsp+1C0h] [rbp-78h]
  __int128 v41; // [rsp+1D0h] [rbp-68h]
  char v42; // [rsp+1E0h] [rbp-58h]
  void *ptr; // [rsp+1E8h] [rbp-50h] BYREF
  unsigned __int64 v44; // [rsp+1F8h] [rbp-40h]
  int v45; // [rsp+200h] [rbp-38h]
  unsigned __int64 v46; // [rsp+208h] [rbp-30h]

  v46 = __readfsqword(0x28u);
  v5 = Input->ptr_;
  v6 = &Input->ptr_[Input->len_];
  v7 = *((_QWORD *)a3 + 2);
  v44 = v7;
  ptr = 0;
  if ( v7 > 0x10 )
  {
    p_ptr = operator new[](v7);
    ptr = p_ptr;
    v9 = *(const void **)a3;
  }
  else
  {
    p_ptr = &ptr;
    v9 = a3;
  }
  memcpy(p_ptr, v9, v7);
  v45 = a3[6];
  boost::algorithm::split_iterator<char const*>::split_iterator<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
    &v38,
    v5,
    v6,
    *(boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)v24);
  *(_QWORD *)&v24[24] = 0;
  vtable = v38.m_Finder.vtable;
  if ( v38.m_Finder.vtable )
  {
    *(_QWORD *)&v24[24] = v38.m_Finder.vtable;
    if ( ((__int64)v38.m_Finder.vtable & 1) != 0 )
    {
      *(boost::detail::function::function_buffer *)&v24[32] = v38.m_Finder.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, _BYTE *, _QWORD))((unsigned __int64)v38.m_Finder.vtable
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        &v38.m_Finder.functor,
        &v24[32],
        0);
      vtable = v38.m_Finder.vtable;
    }
  }
  else
  {
    vtable = 0;
  }
  *(boost::algorithm::split_iterator<const char *>::match_type *)&v24[56] = v38.m_Match;
  *(_OWORD *)&v24[72] = *(_OWORD *)&v38.m_Next;
  v24[88] = v38.m_bEof;
  if ( vtable )
  {
    if ( ((unsigned __int8)vtable & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v38.m_Finder.functor, &v38.m_Finder.functor, 2);
    }
    v38.m_Finder.vtable = 0;
  }
  if ( v44 >= 0x11 && ptr )
    operator delete[](ptr);
  v39 = 0;
  v40 = 0;
  v42 = 1;
  *(_QWORD *)&v24[104] = 0;
  *(_OWORD *)&v24[136] = 0;
  *(_OWORD *)&v24[152] = v41;
  v25 = 1;
  v32 = 0;
  if ( *(_QWORD *)&v24[24] )
  {
    v32 = *(_QWORD *)&v24[24];
    if ( (v24[24] & 1) == 0 )
    {
      (*(void (__fastcall **)(_BYTE *, __int128 *, _QWORD))(*(_QWORD *)&v24[24] & 0xFFFFFFFFFFFFFFFELL))(
        &v24[32],
        &v33,
        0);
      v12 = *(_QWORD *)&v24[104];
      goto LABEL_22;
    }
    v34 = *(_QWORD *)&v24[48];
    v33 = *(_OWORD *)&v24[32];
  }
  v12 = 0;
LABEL_22:
  v35 = *(_OWORD *)&v24[56];
  v36 = *(_OWORD *)&v24[72];
  v37 = v24[88];
  v26 = 0;
  if ( v12 )
  {
    v26 = v12;
    if ( (v12 & 1) != 0 )
    {
      v28 = *(_QWORD *)&v24[128];
      v27 = *(_OWORD *)&v24[112];
    }
    else
    {
      (*(void (__fastcall **)(_BYTE *, __int128 *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(&v24[112], &v27, 0);
    }
  }
  v29 = *(_OWORD *)&v24[136];
  v30 = *(_OWORD *)&v24[152];
  v31 = v25;
  std::vector<std::string>::vector<boost::iterators::transform_iterator<boost::algorithm::detail::copy_iterator_rangeF<std::string,char const*>,boost::algorithm::split_iterator<char const*>,boost::iterators::use_default,boost::iterators::use_default>>(
    (std::vector<std::string> *)v24,
    *(boost::iterators::transform_iterator<boost::algorithm::detail::copy_iterator_rangeF<std::string,const char *>,boost::algorithm::split_iterator<const char *>,boost::iterators::use_default,boost::iterators::use_default> *)v24,
    *(std::enable_if<true,boost::iterators::transform_iterator<boost::algorithm::detail::copy_iterator_rangeF<std::string,const char *>,boost::algorithm::split_iterator<const char *>,boost::iterators::use_default,boost::iterators::use_default> >::type *)&v24[80]);
  if ( v26 )
  {
    if ( (v26 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v26 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v27, &v27, 2);
    }
    v26 = 0;
  }
  if ( v32 )
  {
    if ( (v32 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v32 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v33, &v33, 2);
    }
    v32 = 0;
  }
  v16 = *(_OWORD *)v24;
  *(_QWORD *)v24 = *(_QWORD *)Result;
  v15 = *(void **)v24;
  v17 = _mm_loadu_si128((const __m128i *)((char *)Result + 8));
  *(_OWORD *)Result = v16;
  *((_QWORD *)Result + 2) = *(_QWORD *)&v24[16];
  *(__m128i *)&v24[8] = v17;
  if ( v15 )
  {
    v18 = v17.m128i_i64[0];
    if ( (void *)v17.m128i_i64[0] == v15 )
    {
      v20 = v15;
    }
    else
    {
      do
      {
        v19 = (void *)(v18 - 24);
        if ( (*(_BYTE *)(v18 - 24) & 1) != 0 )
          operator delete(*(void **)(v18 - 8));
        v18 = (__int64)v19;
      }
      while ( v15 != v19 );
      v20 = *(void **)v24;
    }
    *(_QWORD *)&v24[8] = v15;
    operator delete(v20);
  }
  if ( *(_QWORD *)&v24[104] )
  {
    if ( (v24[104] & 1) == 0 )
    {
      v21 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)&v24[104] & 0xFFFFFFFFFFFFFFFELL);
      if ( v21 )
        v21(&v24[112], &v24[112], 2);
    }
    *(_QWORD *)&v24[104] = 0;
  }
  if ( *(_QWORD *)&v24[24] )
  {
    if ( (v24[24] & 1) == 0 )
    {
      v22 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)&v24[24] & 0xFFFFFFFFFFFFFFFELL);
      if ( v22 )
        v22(&v24[32], &v24[32], 2);
    }
    *(_QWORD *)&v24[24] = 0;
  }
  return Result;
}


// Address: 0x275ab60 | Name: _ZN5boost9algorithm10iter_splitINSt3__16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEEKS9_NS0_6detail13token_finderFINSD_14is_from_rangeFIcEEEEEERT_SJ_RT0_T1_
// local variable allocation has failed, the output may be wrong!
std::vector<std::string> *__fastcall boost::algorithm::iter_split<std::vector<std::string>,std::string const,boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_from_rangeF<char>>>(
        std::vector<std::string> *Result,
        const std::string *Input,
        boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_from_rangeF<char> > Finder)
{
  unsigned __int64 v5; // rdx
  unsigned __int64 v6; // rdx
  char *v7; // rsi
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  __int64 v10; // rax
  void (__fastcall *v11)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void *v13; // r14
  __int128 v14; // xmm1
  __m128i v15; // xmm0
  __int64 v16; // rax
  void *v17; // rbx
  void *v18; // rdi
  void (__fastcall *v19)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v20)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  _BYTE v22[24]; // [rsp+0h] [rbp-1B8h] BYREF
  unsigned __int64 v23; // [rsp+18h] [rbp-1A0h]
  boost::detail::function::function_buffer functor; // [rsp+20h] [rbp-198h] BYREF
  boost::algorithm::split_iterator<std::__wrap_iter<const char *> >::match_type m_Match; // [rsp+38h] [rbp-180h]
  __int128 v26; // [rsp+48h] [rbp-170h]
  bool m_bEof; // [rsp+58h] [rbp-160h]
  __int64 v28; // [rsp+68h] [rbp-150h]
  __int128 v29; // [rsp+70h] [rbp-148h] BYREF
  __int64 v30; // [rsp+80h] [rbp-138h]
  __int128 v31; // [rsp+88h] [rbp-130h]
  __int128 v32; // [rsp+98h] [rbp-120h]
  char v33; // [rsp+A8h] [rbp-110h]
  __int64 v34; // [rsp+B8h] [rbp-100h] BYREF
  __int128 v35; // [rsp+C0h] [rbp-F8h] BYREF
  __int64 v36; // [rsp+D0h] [rbp-E8h]
  __int128 v37; // [rsp+D8h] [rbp-E0h]
  __int128 v38; // [rsp+E8h] [rbp-D0h]
  char v39; // [rsp+F8h] [rbp-C0h]
  unsigned __int64 v40; // [rsp+108h] [rbp-B0h] BYREF
  boost::detail::function::function_buffer v41; // [rsp+110h] [rbp-A8h] BYREF
  boost::algorithm::split_iterator<std::__wrap_iter<const char *> >::match_type v42; // [rsp+128h] [rbp-90h]
  __int128 v43; // [rsp+138h] [rbp-80h]
  bool v44; // [rsp+148h] [rbp-70h]
  boost::algorithm::split_iterator<std::__wrap_iter<const char *> > v45; // [rsp+158h] [rbp-60h] BYREF
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_from_rangeF<char> > v46; // 0:kr00_8.8

  v5 = *(unsigned __int8 *)Input;
  if ( (v5 & 1) != 0 )
  {
    v6 = *((_QWORD *)Input + 1);
    v7 = (char *)*((_QWORD *)Input + 2);
  }
  else
  {
    v7 = (char *)Input + 1;
    v6 = v5 >> 1;
  }
  v46.m_Pred = Finder.m_Pred;
  v46.m_eCompress = Finder.m_eCompress;
  boost::algorithm::split_iterator<std::__wrap_iter<char const*>>::split_iterator<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_from_rangeF<char>>>(
    &v45,
    (std::__wrap_iter<const char *>)v7,
    (std::__wrap_iter<const char *>)&v7[v6],
    v46);
  v23 = 0;
  vtable = v45.m_Finder.vtable;
  if ( v45.m_Finder.vtable )
  {
    v23 = (unsigned __int64)v45.m_Finder.vtable;
    if ( ((__int64)v45.m_Finder.vtable & 1) != 0 )
    {
      functor = v45.m_Finder.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v45.m_Finder.vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v45.m_Finder.functor,
        &functor,
        0);
      vtable = v45.m_Finder.vtable;
    }
  }
  else
  {
    vtable = 0;
  }
  m_Match = v45.m_Match;
  v26 = *(_OWORD *)&v45.m_Next.__i;
  m_bEof = v45.m_bEof;
  if ( vtable )
  {
    if ( ((unsigned __int8)vtable & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v45.m_Finder.functor, &v45.m_Finder.functor, 2);
    }
    v45.m_Finder.vtable = 0;
  }
  v28 = 0;
  v32 = 0;
  v31 = 0;
  v33 = 1;
  v40 = 0;
  if ( v23 )
  {
    v40 = v23;
    if ( (v23 & 1) == 0 )
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))(v23 & 0xFFFFFFFFFFFFFFFELL))(
        &functor,
        &v41,
        0);
      v10 = v28;
      goto LABEL_19;
    }
    v41 = functor;
  }
  v10 = 0;
LABEL_19:
  v42 = m_Match;
  v43 = v26;
  v44 = m_bEof;
  v34 = 0;
  if ( v10 )
  {
    v34 = v10;
    if ( (v10 & 1) != 0 )
    {
      v36 = v30;
      v35 = v29;
    }
    else
    {
      (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(&v29, &v35, 0);
    }
  }
  v37 = v31;
  v38 = v32;
  v39 = v33;
  std::vector<std::string>::vector<boost::iterators::transform_iterator<boost::algorithm::detail::copy_iterator_rangeF<std::string,std::__wrap_iter<char const*>>,boost::algorithm::split_iterator<std::__wrap_iter<char const*>>,boost::iterators::use_default,boost::iterators::use_default>>(
    (std::vector<std::string> *)v22,
    (__int64)&v40,
    (__int64)&v34);
  if ( v34 )
  {
    if ( (v34 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v34 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v35, &v35, 2);
    }
    v34 = 0;
  }
  if ( v40 )
  {
    if ( (v40 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))(v40 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v41, &v41, 2);
    }
    v40 = 0;
  }
  v14 = *(_OWORD *)v22;
  *(_QWORD *)v22 = *(_QWORD *)Result;
  v13 = *(void **)v22;
  v15 = _mm_loadu_si128((const __m128i *)((char *)Result + 8));
  *(_OWORD *)Result = v14;
  *((_QWORD *)Result + 2) = *(_QWORD *)&v22[16];
  *(__m128i *)&v22[8] = v15;
  if ( v13 )
  {
    v16 = v15.m128i_i64[0];
    if ( (void *)v15.m128i_i64[0] == v13 )
    {
      v18 = v13;
    }
    else
    {
      do
      {
        v17 = (void *)(v16 - 24);
        if ( (*(_BYTE *)(v16 - 24) & 1) != 0 )
          operator delete(*(void **)(v16 - 8));
        v16 = (__int64)v17;
      }
      while ( v13 != v17 );
      v18 = *(void **)v22;
    }
    *(_QWORD *)&v22[8] = v13;
    operator delete(v18);
  }
  if ( v28 )
  {
    if ( (v28 & 1) == 0 )
    {
      v19 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v28 & 0xFFFFFFFFFFFFFFFELL);
      if ( v19 )
        v19(&v29, &v29, 2);
    }
    v28 = 0;
  }
  if ( v23 )
  {
    if ( (v23 & 1) == 0 )
    {
      v20 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))(v23 & 0xFFFFFFFFFFFFFFFELL);
      if ( v20 )
        v20(&functor, &functor, 2);
    }
    v23 = 0;
  }
  return Result;
}


