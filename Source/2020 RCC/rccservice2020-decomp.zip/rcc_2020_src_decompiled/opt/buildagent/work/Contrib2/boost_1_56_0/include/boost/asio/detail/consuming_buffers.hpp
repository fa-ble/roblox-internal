// Address: 0x2611d00 | Name: _ZN5boost4asio6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorIS3_NS4_9allocatorIS3_EEEEEC2ERKS8_
void __fastcall boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
        boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *this,
        const std::vector<boost::asio::const_buffer> *buffers)
{
  __int128 v3; // xmm0
  signed __int64 v4; // rdi
  char *v6; // rax
  char *v7; // r14
  const void *v8; // rsi
  __int64 v9; // rbx
  char *v10; // rcx
  char *v11; // rax
  struct _Unwind_Exception *v12; // rax
  struct _Unwind_Exception *v13; // rbx
  void *v14; // rdi

  v3 = 0;
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v4 = *((_QWORD *)buffers + 1) - *(_QWORD *)buffers;
  if ( v4 )
  {
    if ( (unsigned __int64)(v4 >> 4) >> 60 )
    {
      std::__vector_base_common<true>::__throw_length_error(this);
      v13 = v12;
      v14 = *(void **)this;
      if ( *(_QWORD *)this )
      {
        *((_QWORD *)this + 1) = v14;
        operator delete(v14);
      }
      _Unwind_Resume(v13);
    }
    v6 = (char *)operator new(v4);
    v7 = v6;
    *((_QWORD *)this + 1) = v6;
    *(_QWORD *)this = v6;
    *((_QWORD *)this + 2) = &v6[16 * (v4 >> 4)];
    v8 = *(const void **)buffers;
    v9 = *((_QWORD *)buffers + 1) - *(_QWORD *)buffers;
    if ( v9 <= 0 )
    {
      v10 = v6;
    }
    else
    {
      memcpy(v6, v8, *((_QWORD *)buffers + 1) - *(_QWORD *)buffers);
      v10 = &v7[v9];
      *((_QWORD *)this + 1) = &v7[v9];
    }
    v11 = v7;
    v3 = 0;
  }
  else
  {
    v10 = 0;
    v7 = 0;
    v11 = 0;
  }
  *((_BYTE *)this + 24) = v11 == v10;
  *((_OWORD *)this + 2) = v3;
  *((_QWORD *)this + 6) = v11;
  *((_QWORD *)this + 7) = -1;
  if ( v11 != v10 )
  {
    *((_OWORD *)this + 2) = *(_OWORD *)v7;
    *((_QWORD *)this + 6) = v11 + 16;
  }
}


// Address: 0x2612170 | Name: _ZN5boost4asio6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorIS3_NS4_9allocatorIS3_EEEEEC2ERKS9_
void __fastcall boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
        boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *this,
        const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *other)
{
  signed __int64 v4; // rdi
  char *v5; // rax
  char *v6; // r15
  const void *v7; // rsi
  __int64 v8; // r12
  struct _Unwind_Exception *v9; // rax
  struct _Unwind_Exception *v10; // rbx
  void *v11; // rdi

  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v4 = *((_QWORD *)other + 1) - *(_QWORD *)other;
  if ( v4 )
  {
    if ( (unsigned __int64)(v4 >> 4) >> 60 )
    {
      std::__vector_base_common<true>::__throw_length_error(this);
      v10 = v9;
      v11 = *(void **)this;
      if ( *(_QWORD *)this )
      {
        *((_QWORD *)this + 1) = v11;
        operator delete(v11);
      }
      _Unwind_Resume(v10);
    }
    v5 = (char *)operator new(v4);
    v6 = v5;
    *((_QWORD *)this + 1) = v5;
    *(_QWORD *)this = v5;
    *((_QWORD *)this + 2) = &v5[16 * (v4 >> 4)];
    v7 = *(const void **)other;
    v8 = *((_QWORD *)other + 1) - *(_QWORD *)other;
    if ( v8 > 0 )
    {
      memcpy(v5, v7, *((_QWORD *)other + 1) - *(_QWORD *)other);
      *((_QWORD *)this + 1) = &v6[v8];
    }
  }
  else
  {
    v6 = 0;
  }
  *((_BYTE *)this + 24) = *((_BYTE *)other + 24);
  *((_OWORD *)this + 2) = *((_OWORD *)other + 2);
  *((_QWORD *)this + 6) = v6;
  *((_QWORD *)this + 7) = *((_QWORD *)other + 7);
  *((_QWORD *)this + 6) = &v6[*((_QWORD *)other + 6) - *(_QWORD *)other];
}


