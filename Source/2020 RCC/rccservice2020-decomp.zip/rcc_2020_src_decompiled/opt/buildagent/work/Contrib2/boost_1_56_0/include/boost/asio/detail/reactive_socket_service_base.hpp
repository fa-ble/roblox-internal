// Address: 0x2609fb0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *handler)
{
  unsigned __int64 v8; // rax
  char **v9; // rax
  char *v10; // rbx
  char v11; // al
  boost::asio::detail::socket_type socket; // r15d
  boost::asio::detail::socket_ops::state_type state; // r13
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *f; // rax
  int start; // [rsp+14h] [rbp-44h]

  start = handler->start_;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( v8 )
  {
    v9 = *(char ***)(v8 + 8);
    if ( v9 )
    {
      v10 = *v9;
      if ( *v9 )
      {
        *v9 = 0;
        v11 = *v10;
        if ( (unsigned __int8)*v10 > 0xCFu )
          goto LABEL_7;
        operator delete(v10);
      }
    }
  }
  v10 = (char *)operator new(0xD1u);
  v11 = -48;
LABEL_7:
  v10[208] = v11;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v10 = 0;
  *((_QWORD *)v10 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>::do_complete;
  *((_DWORD *)v10 + 4) = 0;
  *((_DWORD *)v10 + 6) = 0;
  *((_QWORD *)v10 + 4) = boost::system::system_category();
  *((_QWORD *)v10 + 5) = 0;
  *((_QWORD *)v10 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v10 + 14) = socket;
  v10[60] = state;
  *((boost::asio::mutable_buffers_1 *)v10 + 4) = *buffers;
  *((_DWORD *)v10 + 20) = flags;
  *((_QWORD *)v10 + 12) = handler->next_layer_;
  *((_QWORD *)v10 + 13) = handler->core_;
  *((_DWORD *)v10 + 29) = handler->start_;
  *((_DWORD *)v10 + 30) = handler->want_;
  *((_OWORD *)v10 + 8) = handler->ec_;
  *((_QWORD *)v10 + 18) = handler->bytes_transferred_;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *)handler->handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_ == (std::function<void (const boost::system::error_code &)> *)f )
    {
      *((_QWORD *)v10 + 24) = v10 + 160;
      (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *, char *))handler->handler_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__f_,
        v10 + 160);
    }
    else
    {
      *((_QWORD *)v10 + 24) = f;
      handler->handler_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v10 + 24) = 0;
  }
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v10,
    start == 0,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x260ae30 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > *handler)
{
  bool v6; // r15
  unsigned __int64 v8; // rax
  void **v9; // rax
  void *v10; // rdi
  char *v11; // rbx
  boost::asio::detail::socket_type socket; // r12d
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > *f; // rdi
  bool v14; // [rsp+Bh] [rbp-3Dh]

  v6 = handler->start_ == 0;
  v14 = handler->handler_.start_ == 0;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( v8 )
  {
    v9 = *(void ***)(v8 + 8);
    if ( v9 )
    {
      v10 = *v9;
      if ( *v9 )
      {
        *v9 = 0;
        operator delete(v10);
      }
    }
  }
  v11 = (char *)operator new(0x101u);
  v11[256] = 0;
  socket = impl->socket_;
  *(_QWORD *)v11 = 0;
  *((_QWORD *)v11 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>>::do_complete;
  *((_DWORD *)v11 + 4) = 0;
  *((_DWORD *)v11 + 6) = 0;
  *((_QWORD *)v11 + 4) = boost::system::system_category();
  *((_QWORD *)v11 + 5) = 0;
  *((_QWORD *)v11 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v11 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v11 + 4) = *buffers;
  *((_DWORD *)v11 + 20) = flags;
  *((_QWORD *)v11 + 12) = handler->stream_;
  *(boost::asio::mutable_buffer *)(v11 + 104) = handler->buffer_;
  *((_DWORD *)v11 + 30) = handler->start_;
  *((_QWORD *)v11 + 16) = handler->total_transferred_;
  *((_OWORD *)v11 + 9) = *(_OWORD *)&handler->handler_.next_layer_;
  *((_DWORD *)v11 + 41) = handler->handler_.start_;
  *((_DWORD *)v11 + 42) = handler->handler_.want_;
  *((_OWORD *)v11 + 11) = handler->handler_.ec_;
  *((_QWORD *)v11 + 24) = handler->handler_.bytes_transferred_;
  f = (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > *)handler->handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_ == (std::function<void (const boost::system::error_code &)> *)f )
    {
      *((_QWORD *)v11 + 30) = v11 + 208;
      ((void (__fastcall *)(boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > *, char *))f->stream_->service_)(
        f,
        v11 + 208);
    }
    else
    {
      *((_QWORD *)v11 + 30) = f;
      handler->handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v11 + 30) = 0;
  }
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v11,
    v14 || v6,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x2612d20 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_8write_opINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorISG_NSH_9allocatorISG_EEEEEEEENS1_8write_opINS5_6streamISD_EESL_NS1_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSH_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *handler)
{
  bool v6; // r12
  boost::asio::mutable_buffers_1 *v7; // rbx
  boost::asio::detail::socket_type socket; // r14d
  boost::asio::detail::socket_ops::state_type state; // bp
  bool v10; // [rsp+Fh] [rbp-49h]

  v6 = *((_DWORD *)handler + 20) == 0;
  v10 = *((_DWORD *)handler + 46) == 0;
  v7 = (boost::asio::mutable_buffers_1 *)*((_QWORD *)handler + 26);
  if ( LOBYTE(v7[64].data_) )
    v7 = (boost::asio::mutable_buffers_1 *)operator new(0x170u);
  else
    LOBYTE(v7[64].data_) = 1;
  socket = impl->socket_;
  state = impl->state_;
  v7->data_ = 0;
  v7->size_ = (size_t)boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::do_complete;
  LODWORD(v7[1].data_) = 0;
  LODWORD(v7[1].size_) = 0;
  v7[2].data_ = (void *)boost::system::system_category();
  v7[2].size_ = 0;
  v7[3].data_ = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  LODWORD(v7[3].size_) = socket;
  BYTE4(v7[3].size_) = state;
  v7[4] = *buffers;
  LODWORD(v7[5].data_) = flags;
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)&v7[6],
    handler);
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v7,
    v10 || v6,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26136d0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_8write_opINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorISI_NSJ_9allocatorISI_EEEEEEEENS5_INSD_6streamISB_EESN_SC_N11websocketpp9transport4asio20custom_alloc_handlerINSJ_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *handler)
{
  char v7; // r12
  char *v8; // rbx
  boost::asio::detail::socket_type socket; // ebp

  if ( *((_DWORD *)handler + 6) )
    v7 = *((_DWORD *)handler + 32) == 0 || *((_DWORD *)handler + 58) == 0;
  else
    v7 = 1;
  v8 = (char *)*((_QWORD *)handler + 32);
  if ( v8[1024] )
    v8 = (char *)operator new(0x1A0u);
  else
    v8[1024] = 1;
  socket = impl->socket_;
  *(_QWORD *)v8 = 0;
  *((_QWORD *)v8 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>::do_complete;
  *((_DWORD *)v8 + 4) = 0;
  *((_DWORD *)v8 + 6) = 0;
  *((_QWORD *)v8 + 4) = boost::system::system_category();
  *((_QWORD *)v8 + 5) = 0;
  *((_QWORD *)v8 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v8 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v8 + 4) = *buffers;
  *((_DWORD *)v8 + 20) = flags;
  *((_QWORD *)v8 + 12) = *(_QWORD *)handler;
  *(_OWORD *)(v8 + 104) = *(_OWORD *)((char *)handler + 8);
  *((_DWORD *)v8 + 30) = *((_DWORD *)handler + 6);
  *((_QWORD *)v8 + 16) = *((_QWORD *)handler + 4);
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)(v8 + 144),
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *)((char *)handler + 48));
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v8,
    v7,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26168b0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_7read_opIS4_EENS1_7read_opINS5_6streamISD_EES4_NS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *handler)
{
  char *buf; // rbx
  boost::asio::detail::socket_type socket; // r15d
  boost::asio::detail::socket_ops::state_type state; // r12
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *f; // rax
  char v11; // [rsp+Fh] [rbp-49h]

  if ( handler->start_ )
    v11 = handler->handler_.start_ == 0;
  else
    v11 = 1;
  buf = handler->handler_.handler_.allocator_->storage_.data_.buf;
  if ( buf[1024] )
    buf = (char *)operator new(0x110u);
  else
    buf[1024] = 1;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)buf = 0;
  *((_QWORD *)buf + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::do_complete;
  *((_DWORD *)buf + 4) = 0;
  *((_DWORD *)buf + 6) = 0;
  *((_QWORD *)buf + 4) = boost::system::system_category();
  *((_QWORD *)buf + 5) = 0;
  *((_QWORD *)buf + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)buf + 14) = socket;
  buf[60] = state;
  *((boost::asio::mutable_buffers_1 *)buf + 4) = *buffers;
  *((_DWORD *)buf + 20) = flags;
  *((_QWORD *)buf + 12) = handler->next_layer_;
  *((_QWORD *)buf + 13) = handler->core_;
  *((_OWORD *)buf + 7) = handler->op_;
  *((_DWORD *)buf + 32) = handler->start_;
  *((_DWORD *)buf + 33) = handler->want_;
  *(boost::system::error_code *)(buf + 136) = handler->ec_;
  *((_QWORD *)buf + 19) = handler->bytes_transferred_;
  *((_QWORD *)buf + 20) = handler->handler_.completion_condition_.minimum_;
  *((_QWORD *)buf + 21) = handler->handler_.stream_;
  *((_OWORD *)buf + 11) = handler->handler_.buffer_;
  *((_DWORD *)buf + 48) = handler->handler_.start_;
  *(_OWORD *)(buf + 200) = *(_OWORD *)&handler->handler_.total_transferred_;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)handler->handler_.handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      *((_QWORD *)buf + 32) = buf + 224;
      (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, char *))handler->handler_.handler_.handler_.__f_->_vptr$__base
       + 3))(
        handler->handler_.handler_.handler_.__f_,
        buf + 224);
    }
    else
    {
      *((_QWORD *)buf + 32) = f;
      handler->handler_.handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)buf + 32) = 0;
  }
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)buf,
    v11,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26171c0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_7read_opIS4_EENS1_7read_opINSD_6streamISB_EES4_NS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *handler)
{
  bool v8; // al
  char *buf; // rbx
  boost::asio::detail::socket_type socket; // r12d
  bool v11; // [rsp+Fh] [rbp-39h]

  v8 = 1;
  if ( handler->start_ && handler->handler_.start_ )
    v8 = handler->handler_.handler_.start_ == 0;
  v11 = v8;
  buf = handler->handler_.handler_.handler_.allocator_->storage_.data_.buf;
  if ( buf[1024] )
    buf = (char *)operator new(0x140u);
  else
    buf[1024] = 1;
  socket = impl->socket_;
  *(_QWORD *)buf = 0;
  *((_QWORD *)buf + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>::do_complete;
  *((_DWORD *)buf + 4) = 0;
  *((_DWORD *)buf + 6) = 0;
  *((_QWORD *)buf + 4) = boost::system::system_category();
  *((_QWORD *)buf + 5) = 0;
  *((_QWORD *)buf + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)buf + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)buf + 4) = *buffers;
  *((_DWORD *)buf + 20) = flags;
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::write_op(
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *)(buf + 96),
    handler);
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)buf,
    v11,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x262a210 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorIS5_NS6_9allocatorIS5_EEEEEENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISF_EEEESA_NS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENS6_6__bindIMN11websocketpp9transport4asio10connectionINSO_6config15asio_tls_client16transport_configEEEFvNS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNS6_10shared_ptrISV_EERS11_RKNS6_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  _QWORD *v9; // rax
  bool v10; // al
  unsigned __int64 v11; // rax
  void **v12; // rax
  void *v13; // rdi
  boost::asio::detail::reactor_op *v14; // rbx
  boost::asio::detail::socket_type socket; // ebp
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *v16; // rdi
  unsigned __int64 v17; // rax
  char v18; // r8
  bool v19; // dl
  unsigned __int64 v20; // rcx
  __int64 v21; // rsi
  __int64 v22; // rdi
  unsigned __int64 v23; // rbp
  unsigned __int64 v24; // rcx
  bool v25; // [rsp+14h] [rbp-44h]

  if ( !*((_DWORD *)handler + 18) )
  {
    v10 = 1;
LABEL_8:
    v25 = v10;
    goto LABEL_9;
  }
  v9 = (_QWORD *)__readfsqword(0xFFFFFFE0);
  if ( v9 )
  {
    while ( *v9 != *((_QWORD *)handler + 13) )
    {
      v9 = (_QWORD *)v9[2];
      if ( !v9 )
        goto LABEL_5;
    }
    v10 = v9[1] != 0;
    goto LABEL_8;
  }
LABEL_5:
  v25 = 0;
LABEL_9:
  v11 = __readfsqword(0xFFFFFFD8);
  if ( v11 )
  {
    v12 = *(void ***)(v11 + 8);
    if ( v12 )
    {
      v13 = *v12;
      if ( *v12 )
      {
        *v12 = 0;
        operator delete(v13);
      }
    }
  }
  v14 = (boost::asio::detail::reactor_op *)operator new(0x151u);
  LOBYTE(v14[6].next_) = 0;
  socket = impl->socket_;
  v14->next_ = 0;
  v14->func_ = boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete;
  v14->task_result_ = 0;
  v14->ec_.m_val = 0;
  v14->ec_.m_cat = boost::system::system_category();
  v14->bytes_transferred_ = 0;
  v14->perform_func_ = boost::asio::detail::reactive_socket_send_op_base<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>::do_perform;
  LODWORD(v14[1].next_) = socket;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)&v14[1].func_,
    buffers);
  v14[2].task_result_ = flags;
  v14[2].ec_.m_cat = *(const boost::system::error_category **)handler;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)&v14[2].bytes_transferred_,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 8));
  LODWORD(v14[3].perform_func_) = *((_DWORD *)handler + 18);
  v14[4].next_ = (boost::asio::detail::task_io_service_operation *)*((_QWORD *)handler + 10);
  *(_OWORD *)&v14[4].task_result_ = *((_OWORD *)handler + 6);
  *(_OWORD *)&v14[4].ec_.m_cat = *((_OWORD *)handler + 7);
  *(_OWORD *)&v14[4].perform_func_ = *((_OWORD *)handler + 8);
  *((_OWORD *)handler + 8) = 0;
  v16 = (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)*((_QWORD *)handler + 22);
  if ( v16 )
  {
    if ( (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 144) != v16 )
    {
      v14[5].bytes_transferred_ = (size_t)v16;
      *((_QWORD *)handler + 22) = 0;
      if ( (impl->state_ & 0x10) != 0 )
        goto LABEL_16;
LABEL_21:
      v18 = 0;
      v19 = v25;
      goto LABEL_37;
    }
    v14[5].bytes_transferred_ = (size_t)&v14[5].func_;
    (*(void (__fastcall **)(boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, boost::asio::detail::task_io_service_operation::func_type *))(*(_QWORD *)v16 + 24LL))(
      v16,
      &v14[5].func_);
    if ( (impl->state_ & 0x10) == 0 )
      goto LABEL_21;
  }
  else
  {
    v14[5].bytes_transferred_ = 0;
    if ( (impl->state_ & 0x10) == 0 )
      goto LABEL_21;
  }
LABEL_16:
  v17 = *((_QWORD *)buffers + 7);
  v18 = 1;
  if ( *((_BYTE *)buffers + 24) | (v17 == 0) )
  {
    v19 = v25;
  }
  else
  {
    v20 = *((_QWORD *)buffers + 5);
    if ( v20 >= v17 )
      v20 = *((_QWORD *)buffers + 7);
    v21 = *((_QWORD *)buffers + 6);
    v22 = *((_QWORD *)buffers + 1) - v21;
    v23 = 0;
    v19 = v25;
    while ( !v20 )
    {
      if ( !v17 || !v22 )
        goto LABEL_37;
      v24 = *(_QWORD *)(v21 + 8);
      if ( v24 >= v17 )
        v24 = *((_QWORD *)buffers + 7);
      if ( v24 )
        break;
      if ( *((_QWORD *)buffers + 1) != v21 + 16 )
      {
        v20 = *(_QWORD *)(v21 + 24);
        if ( v20 >= v17 )
          v20 = *((_QWORD *)buffers + 7);
        v21 += 32;
        v23 += 2LL;
        v22 -= 32;
        if ( v23 < 0x40 )
          continue;
      }
      goto LABEL_37;
    }
    v18 = 0;
  }
LABEL_37:
  boost::asio::detail::reactive_socket_service_base::start_op(this, impl, 1, v14, v19, 1, v18);
}


// Address: 0x262d910 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSC_6__bindIMN11websocketpp9transport4asio10connectionINSJ_6config15asio_tls_client16transport_configEEEFvNSC_8functionIFvRKNSC_10error_codeEEEERKNS_6system10error_codeEmEJNSC_10shared_ptrISQ_EERSW_RKNSC_12placeholders4__phILi1EEERKNS17_ILi2EEEEEENS1_26is_continuation_if_runningEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  bool v8; // zf
  _QWORD *v9; // rax
  bool v10; // al
  unsigned __int64 v11; // rax
  void **v12; // rax
  void *v13; // rdi
  _QWORD *v14; // rbp
  boost::asio::detail::socket_type socket; // r14d
  boost::asio::detail::socket_ops::state_type state; // r12
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v17; // rdi
  bool v18; // [rsp+Ch] [rbp-5Ch]
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > >::ptr v19; // [rsp+18h] [rbp-50h] BYREF
  boost::asio::detail::reactive_socket_service_base *v20; // [rsp+30h] [rbp-38h]

  v8 = *((_DWORD *)handler + 10) == 0;
  v20 = this;
  if ( v8 )
  {
    v10 = 1;
LABEL_8:
    v18 = v10;
    goto LABEL_9;
  }
  v9 = (_QWORD *)__readfsqword(0xFFFFFFE0);
  if ( v9 )
  {
    while ( *v9 != *((_QWORD *)handler + 9) )
    {
      v9 = (_QWORD *)v9[2];
      if ( !v9 )
        goto LABEL_5;
    }
    v10 = v9[1] != 0;
    goto LABEL_8;
  }
LABEL_5:
  v18 = 0;
LABEL_9:
  v19.h = handler;
  v11 = __readfsqword(0xFFFFFFD8);
  if ( v11 )
  {
    v12 = *(void ***)(v11 + 8);
    if ( v12 )
    {
      v13 = *v12;
      if ( *v12 )
      {
        *v12 = 0;
        operator delete(v13);
      }
    }
  }
  v14 = operator new(0x101u);
  *((_BYTE *)v14 + 256) = 0;
  v19.v = v14;
  v19.p = 0;
  socket = impl->socket_;
  state = impl->state_;
  *v14 = 0;
  v14[1] = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete;
  *((_DWORD *)v14 + 4) = 0;
  *((_DWORD *)v14 + 6) = 0;
  v14[4] = boost::system::system_category();
  v14[5] = 0;
  v14[6] = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v14 + 14) = socket;
  *((_BYTE *)v14 + 60) = state;
  *((boost::asio::mutable_buffers_1 *)v14 + 4) = *buffers;
  *((_DWORD *)v14 + 20) = flags;
  *((_OWORD *)v14 + 6) = *(_OWORD *)handler;
  v14[16] = *((_QWORD *)handler + 4);
  *((_OWORD *)v14 + 7) = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  *((_DWORD *)v14 + 34) = *((_DWORD *)handler + 10);
  v14[18] = *((_QWORD *)handler + 6);
  *((_OWORD *)v14 + 10) = *((_OWORD *)handler + 4);
  v14[22] = *((_QWORD *)handler + 10);
  *(_OWORD *)(v14 + 23) = *(_OWORD *)((char *)handler + 88);
  v14[25] = *((_QWORD *)handler + 13);
  *((_OWORD *)handler + 6) = 0;
  v17 = (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)*((_QWORD *)handler + 18);
  if ( v17 )
  {
    if ( (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 112) == v17 )
    {
      v14[30] = v14 + 26;
      (*(void (__fastcall **)(boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *))(*(_QWORD *)v17 + 24LL))(v17);
    }
    else
    {
      v14[30] = v17;
      *((_QWORD *)handler + 18) = 0;
    }
  }
  else
  {
    v14[30] = 0;
  }
  v19.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *)v14;
  boost::asio::detail::reactive_socket_service_base::start_op(
    v20,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v14,
    v18,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
  *(_OWORD *)&v19.v = 0;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(&v19);
}


// Address: 0x2632810 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSI_8functionIFvRKNSI_10error_codeEEEERKNS_6system10error_codeEEJNSI_10shared_ptrISO_EERSU_RKNSI_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  unsigned __int64 v8; // rax
  bool v9; // al
  unsigned __int64 v10; // rax
  void **v11; // rax
  void *v12; // rdi
  boost::asio::mutable_buffers_1 *v13; // rbx
  boost::asio::detail::socket_type socket; // r14d
  boost::asio::detail::socket_ops::state_type state; // r13
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *f; // rdi
  bool v17; // [rsp+14h] [rbp-44h]

  if ( !handler->start_ )
  {
    v9 = 1;
LABEL_8:
    v17 = v9;
    goto LABEL_9;
  }
  v8 = __readfsqword(0xFFFFFFE0);
  if ( v8 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v8 != handler->handler_.dispatcher_.impl_ )
    {
      v8 = *(_QWORD *)(v8 + 16);
      if ( !v8 )
        goto LABEL_5;
    }
    v9 = *(_QWORD *)(v8 + 8) != 0;
    goto LABEL_8;
  }
LABEL_5:
  v17 = 0;
LABEL_9:
  v10 = __readfsqword(0xFFFFFFD8);
  if ( v10 )
  {
    v11 = *(void ***)(v10 + 8);
    if ( v11 )
    {
      v12 = *v11;
      if ( *v11 )
      {
        *v11 = 0;
        operator delete(v12);
      }
    }
  }
  v13 = (boost::asio::mutable_buffers_1 *)operator new(0x101u);
  LOBYTE(v13[16].data_) = 0;
  socket = impl->socket_;
  state = impl->state_;
  v13->data_ = 0;
  v13->size_ = (size_t)boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete;
  LODWORD(v13[1].data_) = 0;
  LODWORD(v13[1].size_) = 0;
  v13[2].data_ = (void *)boost::system::system_category();
  v13[2].size_ = 0;
  v13[3].data_ = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  LODWORD(v13[3].size_) = socket;
  BYTE4(v13[3].size_) = state;
  v13[4] = *buffers;
  LODWORD(v13[5].data_) = flags;
  v13[6] = *(boost::asio::mutable_buffers_1 *)&handler->next_layer_;
  LODWORD(v13[7].data_) = handler->op_.type_;
  HIDWORD(v13[7].data_) = handler->start_;
  LODWORD(v13[7].size_) = handler->want_;
  v13[8] = (boost::asio::mutable_buffers_1)handler->ec_;
  v13[9].data_ = (void *)handler->bytes_transferred_;
  v13[10] = (boost::asio::mutable_buffers_1)handler->handler_.dispatcher_;
  v13[11] = *(boost::asio::mutable_buffers_1 *)&handler->handler_.handler_.__f_;
  v13[12] = (boost::asio::mutable_buffers_1)handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)handler->handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v13[15].data_ = &v13[13];
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, boost::asio::mutable_buffers_1 *))f->next_layer_->service_)(
        f,
        &v13[13]);
    }
    else
    {
      v13[15].data_ = f;
      handler->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v13[15].data_ = 0;
  }
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v13,
    v17,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x2634cd0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSK_8functionIFvRKNSK_10error_codeEEEERKNS_6system10error_codeEEJNSK_10shared_ptrISQ_EERSW_RKNSK_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *handler)
{
  char v7; // r14
  unsigned __int64 v8; // rax
  unsigned __int64 v9; // rax
  void **v10; // rax
  void *v11; // rdi
  char *v12; // rbx
  boost::asio::detail::socket_type socket; // ebp

  v7 = 1;
  if ( handler->start_ && handler->handler_.start_ )
  {
    v8 = __readfsqword(0xFFFFFFE0);
    if ( v8 )
    {
      while ( *(boost::asio::detail::strand_service::implementation_type *)v8 != handler->handler_.handler_.dispatcher_.impl_ )
      {
        v8 = *(_QWORD *)(v8 + 16);
        if ( !v8 )
          goto LABEL_6;
      }
      v7 = *(_QWORD *)(v8 + 8) != 0;
    }
    else
    {
LABEL_6:
      v7 = 0;
    }
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( v9 )
  {
    v10 = *(void ***)(v9 + 8);
    if ( v10 )
    {
      v11 = *v10;
      if ( *v10 )
      {
        *v10 = 0;
        operator delete(v11);
      }
    }
  }
  v12 = (char *)operator new(0x131u);
  v12[304] = 0;
  socket = impl->socket_;
  *(_QWORD *)v12 = 0;
  *((_QWORD *)v12 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>>::do_complete;
  *((_DWORD *)v12 + 4) = 0;
  *((_DWORD *)v12 + 6) = 0;
  *((_QWORD *)v12 + 4) = boost::system::system_category();
  *((_QWORD *)v12 + 5) = 0;
  *((_QWORD *)v12 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v12 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v12 + 4) = *buffers;
  *((_DWORD *)v12 + 20) = flags;
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::write_op(
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *)(v12 + 96),
    handler);
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v12,
    v7,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x2637490 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJNSF_10shared_ptrISL_EERSR_RKNSF_12placeholders4__phILi1EEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  int start; // r14d
  unsigned __int64 v9; // rax
  char **v10; // rax
  char *v11; // rbx
  char v12; // al
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > >::ptr v13; // [rsp+8h] [rbp-50h] BYREF
  boost::asio::detail::reactive_socket_service_base *v14; // [rsp+20h] [rbp-38h]

  v14 = this;
  start = handler->start_;
  v13.h = handler;
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 )
    goto LABEL_6;
  v10 = *(char ***)(v9 + 8);
  if ( !v10 )
    goto LABEL_6;
  v11 = *v10;
  if ( !*v10 )
    goto LABEL_6;
  *v10 = 0;
  v12 = *v11;
  if ( (unsigned __int8)*v11 <= 0xEFu )
  {
    operator delete(v11);
LABEL_6:
    v11 = (char *)operator new(0xF1u);
    v12 = -16;
  }
  v11[240] = v12;
  v13.v = v11;
  v13.p = 0;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::reactive_socket_recv_op(
    (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *)v11,
    impl->socket_,
    impl->state_,
    buffers,
    flags,
    handler);
  v13.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *)v11;
  boost::asio::detail::reactive_socket_service_base::start_op(
    v14,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v11,
    start == 0,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
  *(_OWORD *)&v13.v = 0;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::ptr::reset(&v13);
}


// Address: 0x2638190 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSH_8functionIFvRKNSH_10error_codeEEEERKNS_6system10error_codeEEJNSH_10shared_ptrISN_EERST_RKNSH_12placeholders4__phILi1EEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *handler)
{
  bool v6; // r15
  unsigned __int64 v8; // rax
  void **v9; // rax
  void *v10; // rdi
  char *v11; // rbx
  boost::asio::detail::socket_type socket; // ebp
  bool v13; // [rsp+Bh] [rbp-3Dh]

  v6 = handler->start_ == 0;
  v13 = handler->handler_.start_ == 0;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( v8 )
  {
    v9 = *(void ***)(v8 + 8);
    if ( v9 )
    {
      v10 = *v9;
      if ( *v9 )
      {
        *v9 = 0;
        operator delete(v10);
      }
    }
  }
  v11 = (char *)operator new(0x121u);
  v11[288] = 0;
  socket = impl->socket_;
  *(_QWORD *)v11 = 0;
  *((_QWORD *)v11 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>>::do_complete;
  *((_DWORD *)v11 + 4) = 0;
  *((_DWORD *)v11 + 6) = 0;
  *((_QWORD *)v11 + 4) = boost::system::system_category();
  *((_QWORD *)v11 + 5) = 0;
  *((_QWORD *)v11 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v11 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v11 + 4) = *buffers;
  *((_DWORD *)v11 + 20) = flags;
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::write_op(
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *)(v11 + 96),
    handler);
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v11,
    v13 || v6,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x265c650 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorIS5_NS6_9allocatorIS5_EEEEEENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISF_EEEESA_NS1_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINS6_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *handler)
{
  boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> >,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *v9; // r15
  char v10; // r9
  unsigned __int64 v11; // rax
  unsigned __int64 v12; // rcx
  __int64 v13; // rsi
  __int64 v14; // rdx
  unsigned __int64 v15; // rbp
  unsigned __int64 v16; // rcx
  int v17; // [rsp+14h] [rbp-34h]

  v17 = *((_DWORD *)handler + 18);
  v9 = (boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> >,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)*((_QWORD *)handler + 12);
  if ( *((_BYTE *)v9 + 1024) )
    v9 = (boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> >,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)operator new(0x130u);
  else
    *((_BYTE *)v9 + 1024) = 1;
  boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::reactive_socket_send_op(
    v9,
    impl->socket_,
    buffers,
    flags,
    handler);
  if ( (impl->state_ & 0x10) != 0 )
  {
    v11 = *((_QWORD *)buffers + 7);
    v10 = 1;
    if ( !(*((_BYTE *)buffers + 24) | (v11 == 0)) )
    {
      v12 = *((_QWORD *)buffers + 5);
      if ( v12 >= v11 )
        v12 = *((_QWORD *)buffers + 7);
      v13 = *((_QWORD *)buffers + 6);
      v14 = *((_QWORD *)buffers + 1) - v13;
      v15 = 0;
      while ( !v12 )
      {
        if ( !v11 || !v14 )
          goto LABEL_7;
        v16 = *(_QWORD *)(v13 + 8);
        if ( v16 >= v11 )
          v16 = *((_QWORD *)buffers + 7);
        if ( v16 )
          break;
        if ( *((_QWORD *)buffers + 1) != v13 + 16 )
        {
          v12 = *(_QWORD *)(v13 + 24);
          if ( v12 >= v11 )
            v12 = *((_QWORD *)buffers + 7);
          v13 += 32;
          v15 += 2LL;
          v14 -= 32;
          if ( v15 < 0x40 )
            continue;
        }
        goto LABEL_7;
      }
      v10 = 0;
    }
  }
  else
  {
    v10 = 0;
  }
LABEL_7:
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v9,
    v17 == 0,
    1,
    v10);
}


// Address: 0x265df10 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS1_7read_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *handler)
{
  char *buf; // rbx
  boost::asio::detail::socket_type socket; // r12d
  boost::asio::detail::socket_ops::state_type state; // bp
  boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *f; // rax
  int start; // [rsp+14h] [rbp-44h]

  buf = handler->handler_.allocator_->storage_.data_.buf;
  start = handler->start_;
  if ( buf[1024] )
    buf = (char *)operator new(0xD0u);
  else
    buf[1024] = 1;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)buf = 0;
  *((_QWORD *)buf + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::do_complete;
  *((_DWORD *)buf + 4) = 0;
  *((_DWORD *)buf + 6) = 0;
  *((_QWORD *)buf + 4) = boost::system::system_category();
  *((_QWORD *)buf + 5) = 0;
  *((_QWORD *)buf + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)buf + 14) = socket;
  buf[60] = state;
  *((boost::asio::mutable_buffers_1 *)buf + 4) = *buffers;
  *((_DWORD *)buf + 20) = flags;
  *((_OWORD *)buf + 6) = *(_OWORD *)&handler->completion_condition_.minimum_;
  *((_OWORD *)buf + 7) = handler->buffer_;
  *((_DWORD *)buf + 32) = handler->start_;
  *(_OWORD *)(buf + 136) = *(_OWORD *)&handler->total_transferred_;
  f = (boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)handler->handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      *((_QWORD *)buf + 24) = buf + 160;
      (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, char *))handler->handler_.handler_.__f_->_vptr$__base
       + 3))(
        handler->handler_.handler_.__f_,
        buf + 160);
    }
    else
    {
      *((_QWORD *)buf + 24) = f;
      handler->handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)buf + 24) = 0;
  }
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)buf,
    start == 0,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x266b630 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorIS5_NS6_9allocatorIS5_EEEEEENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISF_EEEESA_NS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENS6_6__bindIMN11websocketpp9transport4asio10connectionINSO_6config11asio_client16transport_configEEEFvNS6_8functionIFvRKNS6_10error_codeEEEERKNS_6system10error_codeEEJNS6_10shared_ptrISV_EERS11_RKNS6_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  _QWORD *v9; // rax
  bool v10; // al
  unsigned __int64 v11; // rax
  void **v12; // rax
  void *v13; // rdi
  boost::asio::detail::reactor_op *v14; // rbx
  boost::asio::detail::socket_type socket; // ebp
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *v16; // rdi
  unsigned __int64 v17; // rax
  char v18; // r8
  bool v19; // dl
  unsigned __int64 v20; // rcx
  __int64 v21; // rsi
  __int64 v22; // rdi
  unsigned __int64 v23; // rbp
  unsigned __int64 v24; // rcx
  bool v25; // [rsp+14h] [rbp-44h]

  if ( !*((_DWORD *)handler + 18) )
  {
    v10 = 1;
LABEL_8:
    v25 = v10;
    goto LABEL_9;
  }
  v9 = (_QWORD *)__readfsqword(0xFFFFFFE0);
  if ( v9 )
  {
    while ( *v9 != *((_QWORD *)handler + 13) )
    {
      v9 = (_QWORD *)v9[2];
      if ( !v9 )
        goto LABEL_5;
    }
    v10 = v9[1] != 0;
    goto LABEL_8;
  }
LABEL_5:
  v25 = 0;
LABEL_9:
  v11 = __readfsqword(0xFFFFFFD8);
  if ( v11 )
  {
    v12 = *(void ***)(v11 + 8);
    if ( v12 )
    {
      v13 = *v12;
      if ( *v12 )
      {
        *v12 = 0;
        operator delete(v13);
      }
    }
  }
  v14 = (boost::asio::detail::reactor_op *)operator new(0x151u);
  LOBYTE(v14[6].next_) = 0;
  socket = impl->socket_;
  v14->next_ = 0;
  v14->func_ = boost::asio::detail::reactive_socket_send_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete;
  v14->task_result_ = 0;
  v14->ec_.m_val = 0;
  v14->ec_.m_cat = boost::system::system_category();
  v14->bytes_transferred_ = 0;
  v14->perform_func_ = boost::asio::detail::reactive_socket_send_op_base<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>::do_perform;
  LODWORD(v14[1].next_) = socket;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)&v14[1].func_,
    buffers);
  v14[2].task_result_ = flags;
  v14[2].ec_.m_cat = *(const boost::system::error_category **)handler;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)&v14[2].bytes_transferred_,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 8));
  LODWORD(v14[3].perform_func_) = *((_DWORD *)handler + 18);
  v14[4].next_ = (boost::asio::detail::task_io_service_operation *)*((_QWORD *)handler + 10);
  *(_OWORD *)&v14[4].task_result_ = *((_OWORD *)handler + 6);
  *(_OWORD *)&v14[4].ec_.m_cat = *((_OWORD *)handler + 7);
  *(_OWORD *)&v14[4].perform_func_ = *((_OWORD *)handler + 8);
  *((_OWORD *)handler + 8) = 0;
  v16 = (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)*((_QWORD *)handler + 22);
  if ( v16 )
  {
    if ( (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 144) != v16 )
    {
      v14[5].bytes_transferred_ = (size_t)v16;
      *((_QWORD *)handler + 22) = 0;
      if ( (impl->state_ & 0x10) != 0 )
        goto LABEL_16;
LABEL_21:
      v18 = 0;
      v19 = v25;
      goto LABEL_37;
    }
    v14[5].bytes_transferred_ = (size_t)&v14[5].func_;
    (*(void (__fastcall **)(boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, boost::asio::detail::task_io_service_operation::func_type *))(*(_QWORD *)v16 + 24LL))(
      v16,
      &v14[5].func_);
    if ( (impl->state_ & 0x10) == 0 )
      goto LABEL_21;
  }
  else
  {
    v14[5].bytes_transferred_ = 0;
    if ( (impl->state_ & 0x10) == 0 )
      goto LABEL_21;
  }
LABEL_16:
  v17 = *((_QWORD *)buffers + 7);
  v18 = 1;
  if ( *((_BYTE *)buffers + 24) | (v17 == 0) )
  {
    v19 = v25;
  }
  else
  {
    v20 = *((_QWORD *)buffers + 5);
    if ( v20 >= v17 )
      v20 = *((_QWORD *)buffers + 7);
    v21 = *((_QWORD *)buffers + 6);
    v22 = *((_QWORD *)buffers + 1) - v21;
    v23 = 0;
    v19 = v25;
    while ( !v20 )
    {
      if ( !v17 || !v22 )
        goto LABEL_37;
      v24 = *(_QWORD *)(v21 + 8);
      if ( v24 >= v17 )
        v24 = *((_QWORD *)buffers + 7);
      if ( v24 )
        break;
      if ( *((_QWORD *)buffers + 1) != v21 + 16 )
      {
        v20 = *(_QWORD *)(v21 + 24);
        if ( v20 >= v17 )
          v20 = *((_QWORD *)buffers + 7);
        v21 += 32;
        v23 += 2LL;
        v22 -= 32;
        if ( v23 < 0x40 )
          continue;
      }
      goto LABEL_37;
    }
    v18 = 0;
  }
LABEL_37:
  boost::asio::detail::reactive_socket_service_base::start_op(this, impl, 1, v14, v19, 1, v18);
}


// Address: 0x266ec40 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSC_6__bindIMN11websocketpp9transport4asio10connectionINSJ_6config11asio_client16transport_configEEEFvNSC_8functionIFvRKNSC_10error_codeEEEERKNS_6system10error_codeEmEJNSC_10shared_ptrISQ_EERSW_RKNSC_12placeholders4__phILi1EEERKNS17_ILi2EEEEEENS1_26is_continuation_if_runningEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  bool v8; // zf
  _QWORD *v9; // rax
  bool v10; // al
  unsigned __int64 v11; // rax
  void **v12; // rax
  void *v13; // rdi
  _QWORD *v14; // rbp
  boost::asio::detail::socket_type socket; // r14d
  boost::asio::detail::socket_ops::state_type state; // r12
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v17; // rdi
  bool v18; // [rsp+Ch] [rbp-5Ch]
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > >::ptr v19; // [rsp+18h] [rbp-50h] BYREF
  boost::asio::detail::reactive_socket_service_base *v20; // [rsp+30h] [rbp-38h]

  v8 = *((_DWORD *)handler + 10) == 0;
  v20 = this;
  if ( v8 )
  {
    v10 = 1;
LABEL_8:
    v18 = v10;
    goto LABEL_9;
  }
  v9 = (_QWORD *)__readfsqword(0xFFFFFFE0);
  if ( v9 )
  {
    while ( *v9 != *((_QWORD *)handler + 9) )
    {
      v9 = (_QWORD *)v9[2];
      if ( !v9 )
        goto LABEL_5;
    }
    v10 = v9[1] != 0;
    goto LABEL_8;
  }
LABEL_5:
  v18 = 0;
LABEL_9:
  v19.h = handler;
  v11 = __readfsqword(0xFFFFFFD8);
  if ( v11 )
  {
    v12 = *(void ***)(v11 + 8);
    if ( v12 )
    {
      v13 = *v12;
      if ( *v12 )
      {
        *v12 = 0;
        operator delete(v13);
      }
    }
  }
  v14 = operator new(0x101u);
  *((_BYTE *)v14 + 256) = 0;
  v19.v = v14;
  v19.p = 0;
  socket = impl->socket_;
  state = impl->state_;
  *v14 = 0;
  v14[1] = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete;
  *((_DWORD *)v14 + 4) = 0;
  *((_DWORD *)v14 + 6) = 0;
  v14[4] = boost::system::system_category();
  v14[5] = 0;
  v14[6] = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v14 + 14) = socket;
  *((_BYTE *)v14 + 60) = state;
  *((boost::asio::mutable_buffers_1 *)v14 + 4) = *buffers;
  *((_DWORD *)v14 + 20) = flags;
  *((_OWORD *)v14 + 6) = *(_OWORD *)handler;
  v14[16] = *((_QWORD *)handler + 4);
  *((_OWORD *)v14 + 7) = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  *((_DWORD *)v14 + 34) = *((_DWORD *)handler + 10);
  v14[18] = *((_QWORD *)handler + 6);
  *((_OWORD *)v14 + 10) = *((_OWORD *)handler + 4);
  v14[22] = *((_QWORD *)handler + 10);
  *(_OWORD *)(v14 + 23) = *(_OWORD *)((char *)handler + 88);
  v14[25] = *((_QWORD *)handler + 13);
  *((_OWORD *)handler + 6) = 0;
  v17 = (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)*((_QWORD *)handler + 18);
  if ( v17 )
  {
    if ( (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)handler + 112) == v17 )
    {
      v14[30] = v14 + 26;
      (*(void (__fastcall **)(boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *))(*(_QWORD *)v17 + 24LL))(v17);
    }
    else
    {
      v14[30] = v17;
      *((_QWORD *)handler + 18) = 0;
    }
  }
  else
  {
    v14[30] = 0;
  }
  v19.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *)v14;
  boost::asio::detail::reactive_socket_service_base::start_op(
    v20,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v14,
    v18,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
  *(_OWORD *)&v19.v = 0;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(&v19);
}


// Address: 0x26a2bb0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_8write_opINS0_15const_buffers_1EEENS1_8write_opINS5_6streamIRSD_EESF_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSQ_5list2INSQ_5valueINSN_10shared_ptrISZ_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *handler)
{
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbx
  char v10; // al
  boost::asio::detail::socket_type socket; // r13d
  boost::asio::detail::socket_ops::state_type state; // r15
  bool v13; // [rsp+17h] [rbp-41h]

  v13 = handler->start_ == 0 || handler->handler_.start_ == 0;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_6;
  v8 = *(_BYTE ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_6;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 <= 0xE7u )
  {
    operator delete(v9);
LABEL_6:
    v9 = operator new(0xE9u);
    v10 = -24;
  }
  v9[232] = v10;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_DWORD *)v9 + 6) = 0;
  *((_QWORD *)v9 + 4) = boost::system::system_category();
  *((_QWORD *)v9 + 5) = 0;
  *((_QWORD *)v9 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v9 + 14) = socket;
  v9[60] = state;
  *((boost::asio::mutable_buffers_1 *)v9 + 4) = *buffers;
  *((_DWORD *)v9 + 20) = flags;
  *((_QWORD *)v9 + 11) = handler->next_layer_;
  *((_QWORD *)v9 + 12) = handler->core_;
  *(boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *)(v9 + 104) = handler->op_;
  *((_DWORD *)v9 + 30) = handler->start_;
  *((_DWORD *)v9 + 31) = handler->want_;
  *((_OWORD *)v9 + 8) = handler->ec_;
  *((_QWORD *)v9 + 18) = handler->bytes_transferred_;
  *((_QWORD *)v9 + 19) = handler->handler_.stream_;
  *((_OWORD *)v9 + 10) = handler->handler_.buffer_;
  *((_DWORD *)v9 + 44) = handler->handler_.start_;
  *(_OWORD *)(v9 + 184) = *(_OWORD *)&handler->handler_.total_transferred_;
  *(boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> *)(v9 + 200) = handler->handler_.handler_.handler_.f_;
  *(boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> *)(v9 + 216) = handler->handler_.handler_.handler_.l_;
  handler->handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v9,
    v13,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26a3510 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_8write_opINS0_15const_buffers_1EEENS5_INSD_6streamIRSB_EESH_SC_NS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSQ_5list2INSQ_5valueINSN_10shared_ptrISZ_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > > *handler)
{
  char v7; // r14
  unsigned __int64 v8; // rax
  void **v9; // rax
  void *v10; // rdi
  char *v11; // rbx
  boost::asio::detail::socket_type socket; // ebp

  if ( handler->start_ )
    v7 = handler->handler_.start_ == 0 || handler->handler_.handler_.start_ == 0;
  else
    v7 = 1;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( v8 )
  {
    v9 = *(void ***)(v8 + 8);
    if ( v9 )
    {
      v10 = *v9;
      if ( *v9 )
      {
        *v9 = 0;
        operator delete(v10);
      }
    }
  }
  v11 = (char *)operator new(0x111u);
  v11[272] = 0;
  socket = impl->socket_;
  *(_QWORD *)v11 = 0;
  *((_QWORD *)v11 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>>::do_complete;
  *((_DWORD *)v11 + 4) = 0;
  *((_DWORD *)v11 + 6) = 0;
  *((_QWORD *)v11 + 4) = boost::system::system_category();
  *((_QWORD *)v11 + 5) = 0;
  *((_QWORD *)v11 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v11 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v11 + 4) = *buffers;
  *((_DWORD *)v11 + 20) = flags;
  *((_QWORD *)v11 + 11) = handler->stream_;
  *((_OWORD *)v11 + 6) = handler->buffer_;
  *((_DWORD *)v11 + 28) = handler->start_;
  *(_OWORD *)(v11 + 120) = *(_OWORD *)&handler->total_transferred_;
  *((_QWORD *)v11 + 17) = handler->handler_.core_;
  *((_OWORD *)v11 + 9) = handler->handler_.op_;
  *((_DWORD *)v11 + 40) = handler->handler_.start_;
  *((_DWORD *)v11 + 41) = handler->handler_.want_;
  *(boost::system::error_code *)(v11 + 168) = handler->handler_.ec_;
  *(_OWORD *)(v11 + 184) = *(_OWORD *)&handler->handler_.bytes_transferred_;
  *(boost::asio::const_buffer *)(v11 + 200) = handler->handler_.handler_.buffer_;
  *((_DWORD *)v11 + 54) = handler->handler_.handler_.start_;
  *((_OWORD *)v11 + 14) = *(_OWORD *)&handler->handler_.handler_.total_transferred_;
  *((_OWORD *)v11 + 15) = handler->handler_.handler_.handler_.handler_.f_;
  *((_OWORD *)v11 + 16) = handler->handler_.handler_.handler_.handler_.l_;
  handler->handler_.handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v11,
    v7,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26a3b10 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_15const_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSH_5list2INSH_5valueINSE_10shared_ptrISQ_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::const_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *handler)
{
  int start; // ebp
  unsigned __int64 v8; // rax
  _BYTE **v9; // rax
  _BYTE *v10; // rbx
  char v11; // al
  bool v12; // r15
  boost::asio::detail::socket_type socket; // ebp

  start = handler->start_;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *(_BYTE ***)(v8 + 8);
  if ( !v9 )
    goto LABEL_6;
  v10 = *v9;
  if ( !*v9 )
    goto LABEL_6;
  *v9 = 0;
  v11 = *v10;
  if ( *v10 <= 0xA7u )
  {
    operator delete(v10);
LABEL_6:
    v10 = operator new(0xA9u);
    v11 = -88;
  }
  v12 = start == 0;
  v10[168] = v11;
  socket = impl->socket_;
  *(_QWORD *)v10 = 0;
  *((_QWORD *)v10 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::do_complete;
  *((_DWORD *)v10 + 4) = 0;
  *((_DWORD *)v10 + 6) = 0;
  *((_QWORD *)v10 + 4) = boost::system::system_category();
  *((_QWORD *)v10 + 5) = 0;
  *((_QWORD *)v10 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::const_buffers_1>::do_perform;
  *((_DWORD *)v10 + 14) = socket;
  *((boost::asio::const_buffers_1 *)v10 + 4) = *buffers;
  *((_DWORD *)v10 + 20) = flags;
  *((_QWORD *)v10 + 11) = handler->stream_;
  *((_OWORD *)v10 + 6) = handler->buffer_;
  *((_DWORD *)v10 + 28) = handler->start_;
  *(_OWORD *)(v10 + 120) = *(_OWORD *)&handler->total_transferred_;
  *(boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> *)(v10 + 136) = handler->handler_.handler_.f_;
  *(boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> *)(v10 + 152) = handler->handler_.handler_.l_;
  handler->handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v10,
    v12,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26a58d0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_7read_opIS4_EENS1_26read_until_delim_string_opINS5_6streamIRSD_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSN_5list2INSN_5valueINSK_10shared_ptrISW_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *handler)
{
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbp
  char v10; // al
  boost::asio::detail::socket_type socket; // r12d
  boost::asio::detail::socket_ops::state_type state; // r14
  const boost::asio::mutable_buffers_1 *v13; // rcx
  bool v14; // [rsp+Fh] [rbp-59h]
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::ptr v15; // [rsp+10h] [rbp-58h] BYREF
  const boost::asio::mutable_buffers_1 *v16; // [rsp+28h] [rbp-40h]
  boost::asio::detail::reactive_socket_service_base *v17; // [rsp+30h] [rbp-38h]

  v16 = buffers;
  v17 = this;
  v14 = *((_DWORD *)handler + 8) == 0 || *((_DWORD *)handler + 26) == 0;
  v15.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_6;
  v8 = *(_BYTE ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_6;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 <= 0xEFu )
  {
    operator delete(v9);
LABEL_6:
    v9 = operator new(0xF1u);
    v10 = -16;
  }
  v9[240] = v10;
  v15.v = v9;
  v15.p = 0;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_DWORD *)v9 + 6) = 0;
  *((_QWORD *)v9 + 4) = boost::system::system_category();
  *((_QWORD *)v9 + 5) = 0;
  *((_QWORD *)v9 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v9 + 14) = socket;
  v9[60] = state;
  v13 = v16;
  *((boost::asio::mutable_buffers_1 *)v9 + 4) = *v16;
  *((_DWORD *)v9 + 20) = flags;
  *((_QWORD *)v9 + 11) = *(_QWORD *)handler;
  *((_QWORD *)v9 + 12) = *((_QWORD *)handler + 1);
  *(_OWORD *)(v9 + 104) = *((_OWORD *)handler + 1);
  *((_DWORD *)v9 + 30) = *((_DWORD *)handler + 8);
  *((_DWORD *)v9 + 31) = *((_DWORD *)handler + 9);
  *((_OWORD *)v9 + 8) = *(_OWORD *)((char *)handler + 40);
  *((_QWORD *)v9 + 18) = *((_QWORD *)handler + 7);
  *((_QWORD *)v9 + 19) = *((_QWORD *)handler + 8);
  *((_QWORD *)v9 + 20) = *((_QWORD *)handler + 9);
  *((_QWORD *)v9 + 23) = *((_QWORD *)handler + 12);
  *(_OWORD *)(v9 + 168) = *((_OWORD *)handler + 5);
  *((_OWORD *)handler + 5) = 0;
  *((_QWORD *)handler + 12) = 0;
  *((_DWORD *)v9 + 48) = *((_DWORD *)handler + 26);
  *((_QWORD *)v9 + 25) = *((_QWORD *)handler + 14);
  *((_OWORD *)v9 + 13) = *(_OWORD *)((char *)handler + 120);
  *((_OWORD *)v9 + 14) = *(_OWORD *)((char *)handler + 136);
  *(_OWORD *)((char *)handler + 136) = 0;
  v15.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *)v9;
  boost::asio::detail::reactive_socket_service_base::start_op(
    v17,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v9,
    v14,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (v13->size_ == 0));
  *(_OWORD *)&v15.v = 0;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v15);
}


// Address: 0x26a64d0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_7read_opIS4_EENS1_26read_until_delim_string_opINSD_6streamIRSB_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISY_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *handler)
{
  char v7; // r14
  unsigned __int64 v8; // rax
  void **v9; // rax
  void *v10; // rdi
  char *v11; // rbx
  boost::asio::detail::socket_type socket; // ebp

  if ( *((_DWORD *)handler + 6) )
    v7 = *((_DWORD *)handler + 18) == 0 || *((_DWORD *)handler + 36) == 0;
  else
    v7 = 1;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( v8 )
  {
    v9 = *(void ***)(v8 + 8);
    if ( v9 )
    {
      v10 = *v9;
      if ( *v9 )
      {
        *v9 = 0;
        operator delete(v10);
      }
    }
  }
  v11 = (char *)operator new(0x119u);
  v11[280] = 0;
  socket = impl->socket_;
  *(_QWORD *)v11 = 0;
  *((_QWORD *)v11 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>::do_complete;
  *((_DWORD *)v11 + 4) = 0;
  *((_DWORD *)v11 + 6) = 0;
  *((_QWORD *)v11 + 4) = boost::system::system_category();
  *((_QWORD *)v11 + 5) = 0;
  *((_QWORD *)v11 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v11 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v11 + 4) = *buffers;
  *((_DWORD *)v11 + 20) = flags;
  *((_QWORD *)v11 + 11) = *(_QWORD *)handler;
  *((_OWORD *)v11 + 6) = *(_OWORD *)((char *)handler + 8);
  *((_DWORD *)v11 + 28) = *((_DWORD *)handler + 6);
  *(_OWORD *)(v11 + 120) = *((_OWORD *)handler + 2);
  *((_QWORD *)v11 + 17) = *((_QWORD *)handler + 6);
  *((_OWORD *)v11 + 9) = *(_OWORD *)((char *)handler + 56);
  *((_DWORD *)v11 + 40) = *((_DWORD *)handler + 18);
  *((_DWORD *)v11 + 41) = *((_DWORD *)handler + 19);
  *(_OWORD *)(v11 + 168) = *((_OWORD *)handler + 5);
  *(_OWORD *)(v11 + 184) = *((_OWORD *)handler + 6);
  *((_QWORD *)v11 + 25) = *((_QWORD *)handler + 14);
  *((_QWORD *)v11 + 28) = *((_QWORD *)handler + 17);
  *((_OWORD *)v11 + 13) = *(_OWORD *)((char *)handler + 120);
  *(_OWORD *)((char *)handler + 120) = 0;
  *((_QWORD *)handler + 17) = 0;
  *((_DWORD *)v11 + 58) = *((_DWORD *)handler + 36);
  *((_QWORD *)v11 + 30) = *((_QWORD *)handler + 19);
  *(_OWORD *)(v11 + 248) = *((_OWORD *)handler + 10);
  *(_OWORD *)(v11 + 264) = *((_OWORD *)handler + 11);
  *((_OWORD *)handler + 11) = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v11,
    v7,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26a6f70 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSC_10shared_ptrISO_EEEEPFNS_3argILi1EEEvEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *handler)
{
  int v7; // r12d
  unsigned __int64 v8; // rax
  _BYTE **v9; // rax
  _BYTE *v10; // rbx
  char v11; // al
  boost::asio::detail::socket_type socket; // r12d
  boost::asio::detail::socket_ops::state_type state; // r15
  bool is_continuation; // [rsp+Ch] [rbp-5Ch]
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > >::ptr v16; // [rsp+20h] [rbp-48h] BYREF

  v7 = *((_DWORD *)handler + 10);
  v16.h = handler;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *(_BYTE ***)(v8 + 8);
  if ( !v9 )
    goto LABEL_6;
  v10 = *v9;
  if ( !*v9 )
    goto LABEL_6;
  *v9 = 0;
  v11 = *v10;
  if ( *v10 <= 0xAFu )
  {
    operator delete(v10);
LABEL_6:
    v10 = operator new(0xB1u);
    v11 = -80;
  }
  is_continuation = v7 == 0;
  v10[176] = v11;
  v16.v = v10;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v10 = 0;
  *((_QWORD *)v10 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::do_complete;
  *((_DWORD *)v10 + 4) = 0;
  *((_DWORD *)v10 + 6) = 0;
  *((_QWORD *)v10 + 4) = boost::system::system_category();
  *((_QWORD *)v10 + 5) = 0;
  *((_QWORD *)v10 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v10 + 14) = socket;
  v10[60] = state;
  *((boost::asio::mutable_buffers_1 *)v10 + 4) = *buffers;
  *((_DWORD *)v10 + 20) = flags;
  *((_QWORD *)v10 + 11) = *(_QWORD *)handler;
  *((_QWORD *)v10 + 12) = *((_QWORD *)handler + 1);
  *((_QWORD *)v10 + 15) = *((_QWORD *)handler + 4);
  *(_OWORD *)(v10 + 104) = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  *((_DWORD *)v10 + 32) = *((_DWORD *)handler + 10);
  *((_QWORD *)v10 + 17) = *((_QWORD *)handler + 6);
  *((_OWORD *)v10 + 9) = *(_OWORD *)((char *)handler + 56);
  *((_QWORD *)v10 + 20) = *((_QWORD *)handler + 9);
  *((_QWORD *)v10 + 21) = *((_QWORD *)handler + 10);
  *(_OWORD *)((char *)handler + 72) = 0;
  v16.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)v10;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v10,
    is_continuation,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
  *(_OWORD *)&v16.v = 0;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::ptr::reset(&v16);
}


// Address: 0x26a8e20 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSt3__110shared_ptrISN_EEEEPFNS_3argILi1EEEvEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  int start; // r13d
  unsigned __int64 v8; // rax
  _BYTE **v9; // rax
  _BYTE *v10; // rbx
  char v11; // al
  boost::asio::detail::socket_type socket; // r13d
  boost::asio::detail::socket_ops::state_type state; // r14
  bool is_continuation; // [rsp+14h] [rbp-44h]

  start = handler->start_;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *(_BYTE ***)(v8 + 8);
  if ( !v9 )
    goto LABEL_6;
  v10 = *v9;
  if ( !*v9 )
    goto LABEL_6;
  *v9 = 0;
  v11 = *v10;
  if ( *v10 <= 0xAFu )
  {
    operator delete(v10);
LABEL_6:
    v10 = operator new(0xB1u);
    v11 = -80;
  }
  is_continuation = start == 0;
  v10[176] = v11;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v10 = 0;
  *((_QWORD *)v10 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::do_complete;
  *((_DWORD *)v10 + 4) = 0;
  *((_DWORD *)v10 + 6) = 0;
  *((_QWORD *)v10 + 4) = boost::system::system_category();
  *((_QWORD *)v10 + 5) = 0;
  *((_QWORD *)v10 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v10 + 14) = socket;
  v10[60] = state;
  *((boost::asio::mutable_buffers_1 *)v10 + 4) = *buffers;
  *((_DWORD *)v10 + 20) = flags;
  *((_QWORD *)v10 + 11) = handler->next_layer_;
  *((_QWORD *)v10 + 12) = handler->core_;
  *((_DWORD *)v10 + 26) = handler->op_.type_;
  *((_DWORD *)v10 + 27) = handler->start_;
  *((_DWORD *)v10 + 28) = handler->want_;
  *(boost::system::error_code *)(v10 + 120) = handler->ec_;
  *((_QWORD *)v10 + 17) = handler->bytes_transferred_;
  *((_OWORD *)v10 + 9) = handler->handler_.f_;
  *((_OWORD *)v10 + 10) = handler->handler_.l_;
  handler->handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v10,
    is_continuation,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26a9610 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSH_5list2INSH_5valueINSt3__110shared_ptrISP_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  bool v7; // r15
  unsigned __int64 v8; // rax
  _BYTE **v9; // rax
  _BYTE *v10; // rbx
  char v11; // al
  boost::asio::detail::socket_type socket; // ebp

  v7 = handler->start_ == 0 || handler->handler_.start_ == 0;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *(_BYTE ***)(v8 + 8);
  if ( !v9 )
    goto LABEL_6;
  v10 = *v9;
  if ( !*v9 )
    goto LABEL_6;
  *v9 = 0;
  v11 = *v10;
  if ( *v10 <= 0xD7u )
  {
    operator delete(v10);
LABEL_6:
    v10 = operator new(0xD9u);
    v11 = -40;
  }
  v10[216] = v11;
  socket = impl->socket_;
  *(_QWORD *)v10 = 0;
  *((_QWORD *)v10 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete;
  *((_DWORD *)v10 + 4) = 0;
  *((_DWORD *)v10 + 6) = 0;
  *((_QWORD *)v10 + 4) = boost::system::system_category();
  *((_QWORD *)v10 + 5) = 0;
  *((_QWORD *)v10 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v10 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v10 + 4) = *buffers;
  *((_DWORD *)v10 + 20) = flags;
  *((_QWORD *)v10 + 11) = handler->stream_;
  *((_OWORD *)v10 + 6) = handler->buffer_;
  *((_DWORD *)v10 + 28) = handler->start_;
  *(_OWORD *)(v10 + 120) = *(_OWORD *)&handler->total_transferred_;
  *((_QWORD *)v10 + 17) = handler->handler_.core_;
  *((_DWORD *)v10 + 36) = handler->handler_.op_.type_;
  *((_DWORD *)v10 + 37) = handler->handler_.start_;
  *((_DWORD *)v10 + 38) = handler->handler_.want_;
  *((_OWORD *)v10 + 10) = handler->handler_.ec_;
  *((_QWORD *)v10 + 22) = handler->handler_.bytes_transferred_;
  *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)(v10 + 184) = handler->handler_.handler_.f_;
  *(boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> *)(v10 + 200) = handler->handler_.handler_.l_;
  handler->handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v10,
    v7,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26aa600 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_8write_opINS0_15const_buffers_1EEENS1_8write_opINS5_6streamIRSD_EESF_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSQ_5list2INSQ_5valueINSN_10shared_ptrISY_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *handler)
{
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbx
  char v10; // al
  boost::asio::detail::socket_type socket; // r13d
  boost::asio::detail::socket_ops::state_type state; // r15
  bool v13; // [rsp+17h] [rbp-41h]

  v13 = handler->start_ == 0 || handler->handler_.start_ == 0;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_6;
  v8 = *(_BYTE ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_6;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 <= 0xE7u )
  {
    operator delete(v9);
LABEL_6:
    v9 = operator new(0xE9u);
    v10 = -24;
  }
  v9[232] = v10;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_DWORD *)v9 + 6) = 0;
  *((_QWORD *)v9 + 4) = boost::system::system_category();
  *((_QWORD *)v9 + 5) = 0;
  *((_QWORD *)v9 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v9 + 14) = socket;
  v9[60] = state;
  *((boost::asio::mutable_buffers_1 *)v9 + 4) = *buffers;
  *((_DWORD *)v9 + 20) = flags;
  *((_QWORD *)v9 + 11) = handler->next_layer_;
  *((_QWORD *)v9 + 12) = handler->core_;
  *(boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *)(v9 + 104) = handler->op_;
  *((_DWORD *)v9 + 30) = handler->start_;
  *((_DWORD *)v9 + 31) = handler->want_;
  *((_OWORD *)v9 + 8) = handler->ec_;
  *((_QWORD *)v9 + 18) = handler->bytes_transferred_;
  *((_QWORD *)v9 + 19) = handler->handler_.stream_;
  *((_OWORD *)v9 + 10) = handler->handler_.buffer_;
  *((_DWORD *)v9 + 44) = handler->handler_.start_;
  *(_OWORD *)(v9 + 184) = *(_OWORD *)&handler->handler_.total_transferred_;
  *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)(v9 + 200) = handler->handler_.handler_.handler_.f_;
  *(boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> *)(v9 + 216) = handler->handler_.handler_.handler_.l_;
  handler->handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v9,
    v13,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26aaf60 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_8write_opINS0_15const_buffers_1EEENS5_INSD_6streamIRSB_EESH_SC_NS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSQ_5list2INSQ_5valueINSN_10shared_ptrISY_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > > *handler)
{
  char v7; // r14
  unsigned __int64 v8; // rax
  void **v9; // rax
  void *v10; // rdi
  char *v11; // rbx
  boost::asio::detail::socket_type socket; // ebp

  if ( handler->start_ )
    v7 = handler->handler_.start_ == 0 || handler->handler_.handler_.start_ == 0;
  else
    v7 = 1;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( v8 )
  {
    v9 = *(void ***)(v8 + 8);
    if ( v9 )
    {
      v10 = *v9;
      if ( *v9 )
      {
        *v9 = 0;
        operator delete(v10);
      }
    }
  }
  v11 = (char *)operator new(0x111u);
  v11[272] = 0;
  socket = impl->socket_;
  *(_QWORD *)v11 = 0;
  *((_QWORD *)v11 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>>::do_complete;
  *((_DWORD *)v11 + 4) = 0;
  *((_DWORD *)v11 + 6) = 0;
  *((_QWORD *)v11 + 4) = boost::system::system_category();
  *((_QWORD *)v11 + 5) = 0;
  *((_QWORD *)v11 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v11 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v11 + 4) = *buffers;
  *((_DWORD *)v11 + 20) = flags;
  *((_QWORD *)v11 + 11) = handler->stream_;
  *((_OWORD *)v11 + 6) = handler->buffer_;
  *((_DWORD *)v11 + 28) = handler->start_;
  *(_OWORD *)(v11 + 120) = *(_OWORD *)&handler->total_transferred_;
  *((_QWORD *)v11 + 17) = handler->handler_.core_;
  *((_OWORD *)v11 + 9) = handler->handler_.op_;
  *((_DWORD *)v11 + 40) = handler->handler_.start_;
  *((_DWORD *)v11 + 41) = handler->handler_.want_;
  *(boost::system::error_code *)(v11 + 168) = handler->handler_.ec_;
  *(_OWORD *)(v11 + 184) = *(_OWORD *)&handler->handler_.bytes_transferred_;
  *(boost::asio::const_buffer *)(v11 + 200) = handler->handler_.handler_.buffer_;
  *((_DWORD *)v11 + 54) = handler->handler_.handler_.start_;
  *((_OWORD *)v11 + 14) = *(_OWORD *)&handler->handler_.handler_.total_transferred_;
  *((_OWORD *)v11 + 15) = handler->handler_.handler_.handler_.handler_.f_;
  *((_OWORD *)v11 + 16) = handler->handler_.handler_.handler_.handler_.l_;
  handler->handler_.handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v11,
    v7,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26ab560 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_15const_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSH_5list2INSH_5valueINSE_10shared_ptrISP_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::const_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  int start; // ebp
  unsigned __int64 v8; // rax
  _BYTE **v9; // rax
  _BYTE *v10; // rbx
  char v11; // al
  bool v12; // r15
  boost::asio::detail::socket_type socket; // ebp

  start = handler->start_;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *(_BYTE ***)(v8 + 8);
  if ( !v9 )
    goto LABEL_6;
  v10 = *v9;
  if ( !*v9 )
    goto LABEL_6;
  *v9 = 0;
  v11 = *v10;
  if ( *v10 <= 0xA7u )
  {
    operator delete(v10);
LABEL_6:
    v10 = operator new(0xA9u);
    v11 = -88;
  }
  v12 = start == 0;
  v10[168] = v11;
  socket = impl->socket_;
  *(_QWORD *)v10 = 0;
  *((_QWORD *)v10 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete;
  *((_DWORD *)v10 + 4) = 0;
  *((_DWORD *)v10 + 6) = 0;
  *((_QWORD *)v10 + 4) = boost::system::system_category();
  *((_QWORD *)v10 + 5) = 0;
  *((_QWORD *)v10 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::const_buffers_1>::do_perform;
  *((_DWORD *)v10 + 14) = socket;
  *((boost::asio::const_buffers_1 *)v10 + 4) = *buffers;
  *((_DWORD *)v10 + 20) = flags;
  *((_QWORD *)v10 + 11) = handler->stream_;
  *((_OWORD *)v10 + 6) = handler->buffer_;
  *((_DWORD *)v10 + 28) = handler->start_;
  *(_OWORD *)(v10 + 120) = *(_OWORD *)&handler->total_transferred_;
  *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)(v10 + 136) = handler->handler_.handler_.f_;
  *(boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> *)(v10 + 152) = handler->handler_.handler_.l_;
  handler->handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v10,
    v12,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26add50 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_7read_opIS4_EENS1_26read_until_delim_string_opINS5_6streamIRSD_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSN_5list2INSN_5valueINSK_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbp
  char v10; // al
  boost::asio::detail::socket_type socket; // r12d
  boost::asio::detail::socket_ops::state_type state; // r14
  const boost::asio::mutable_buffers_1 *v13; // rcx
  bool v14; // [rsp+Fh] [rbp-59h]
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::ptr v15; // [rsp+10h] [rbp-58h] BYREF
  const boost::asio::mutable_buffers_1 *v16; // [rsp+28h] [rbp-40h]
  boost::asio::detail::reactive_socket_service_base *v17; // [rsp+30h] [rbp-38h]

  v16 = buffers;
  v17 = this;
  v14 = *((_DWORD *)handler + 8) == 0 || *((_DWORD *)handler + 26) == 0;
  v15.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_6;
  v8 = *(_BYTE ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_6;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 <= 0xEFu )
  {
    operator delete(v9);
LABEL_6:
    v9 = operator new(0xF1u);
    v10 = -16;
  }
  v9[240] = v10;
  v15.v = v9;
  v15.p = 0;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_DWORD *)v9 + 6) = 0;
  *((_QWORD *)v9 + 4) = boost::system::system_category();
  *((_QWORD *)v9 + 5) = 0;
  *((_QWORD *)v9 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v9 + 14) = socket;
  v9[60] = state;
  v13 = v16;
  *((boost::asio::mutable_buffers_1 *)v9 + 4) = *v16;
  *((_DWORD *)v9 + 20) = flags;
  *((_QWORD *)v9 + 11) = *(_QWORD *)handler;
  *((_QWORD *)v9 + 12) = *((_QWORD *)handler + 1);
  *(_OWORD *)(v9 + 104) = *((_OWORD *)handler + 1);
  *((_DWORD *)v9 + 30) = *((_DWORD *)handler + 8);
  *((_DWORD *)v9 + 31) = *((_DWORD *)handler + 9);
  *((_OWORD *)v9 + 8) = *(_OWORD *)((char *)handler + 40);
  *((_QWORD *)v9 + 18) = *((_QWORD *)handler + 7);
  *((_QWORD *)v9 + 19) = *((_QWORD *)handler + 8);
  *((_QWORD *)v9 + 20) = *((_QWORD *)handler + 9);
  *((_QWORD *)v9 + 23) = *((_QWORD *)handler + 12);
  *(_OWORD *)(v9 + 168) = *((_OWORD *)handler + 5);
  *((_OWORD *)handler + 5) = 0;
  *((_QWORD *)handler + 12) = 0;
  *((_DWORD *)v9 + 48) = *((_DWORD *)handler + 26);
  *((_QWORD *)v9 + 25) = *((_QWORD *)handler + 14);
  *((_OWORD *)v9 + 13) = *(_OWORD *)((char *)handler + 120);
  *((_OWORD *)v9 + 14) = *(_OWORD *)((char *)handler + 136);
  *(_OWORD *)((char *)handler + 136) = 0;
  v15.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *)v9;
  boost::asio::detail::reactive_socket_service_base::start_op(
    v17,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v9,
    v14,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (v13->size_ == 0));
  *(_OWORD *)&v15.v = 0;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v15);
}


// Address: 0x26ae950 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_7read_opIS4_EENS1_26read_until_delim_string_opINSD_6streamIRSB_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *handler)
{
  char v7; // r14
  unsigned __int64 v8; // rax
  void **v9; // rax
  void *v10; // rdi
  char *v11; // rbx
  boost::asio::detail::socket_type socket; // ebp

  if ( *((_DWORD *)handler + 6) )
    v7 = *((_DWORD *)handler + 18) == 0 || *((_DWORD *)handler + 36) == 0;
  else
    v7 = 1;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( v8 )
  {
    v9 = *(void ***)(v8 + 8);
    if ( v9 )
    {
      v10 = *v9;
      if ( *v9 )
      {
        *v9 = 0;
        operator delete(v10);
      }
    }
  }
  v11 = (char *)operator new(0x119u);
  v11[280] = 0;
  socket = impl->socket_;
  *(_QWORD *)v11 = 0;
  *((_QWORD *)v11 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>::do_complete;
  *((_DWORD *)v11 + 4) = 0;
  *((_DWORD *)v11 + 6) = 0;
  *((_QWORD *)v11 + 4) = boost::system::system_category();
  *((_QWORD *)v11 + 5) = 0;
  *((_QWORD *)v11 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v11 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v11 + 4) = *buffers;
  *((_DWORD *)v11 + 20) = flags;
  *((_QWORD *)v11 + 11) = *(_QWORD *)handler;
  *((_OWORD *)v11 + 6) = *(_OWORD *)((char *)handler + 8);
  *((_DWORD *)v11 + 28) = *((_DWORD *)handler + 6);
  *(_OWORD *)(v11 + 120) = *((_OWORD *)handler + 2);
  *((_QWORD *)v11 + 17) = *((_QWORD *)handler + 6);
  *((_OWORD *)v11 + 9) = *(_OWORD *)((char *)handler + 56);
  *((_DWORD *)v11 + 40) = *((_DWORD *)handler + 18);
  *((_DWORD *)v11 + 41) = *((_DWORD *)handler + 19);
  *(_OWORD *)(v11 + 168) = *((_OWORD *)handler + 5);
  *(_OWORD *)(v11 + 184) = *((_OWORD *)handler + 6);
  *((_QWORD *)v11 + 25) = *((_QWORD *)handler + 14);
  *((_QWORD *)v11 + 28) = *((_QWORD *)handler + 17);
  *((_OWORD *)v11 + 13) = *(_OWORD *)((char *)handler + 120);
  *(_OWORD *)((char *)handler + 120) = 0;
  *((_QWORD *)handler + 17) = 0;
  *((_DWORD *)v11 + 58) = *((_DWORD *)handler + 36);
  *((_QWORD *)v11 + 30) = *((_QWORD *)handler + 19);
  *(_OWORD *)(v11 + 248) = *((_OWORD *)handler + 10);
  *(_OWORD *)(v11 + 264) = *((_OWORD *)handler + 11);
  *((_OWORD *)handler + 11) = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v11,
    v7,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26af3f0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSC_10shared_ptrISN_EEEEPFNS_3argILi1EEEvEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  int v7; // r12d
  unsigned __int64 v8; // rax
  _BYTE **v9; // rax
  _BYTE *v10; // rbx
  char v11; // al
  boost::asio::detail::socket_type socket; // r12d
  boost::asio::detail::socket_ops::state_type state; // r15
  bool is_continuation; // [rsp+Ch] [rbp-5Ch]
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > >::ptr v16; // [rsp+20h] [rbp-48h] BYREF

  v7 = *((_DWORD *)handler + 10);
  v16.h = handler;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *(_BYTE ***)(v8 + 8);
  if ( !v9 )
    goto LABEL_6;
  v10 = *v9;
  if ( !*v9 )
    goto LABEL_6;
  *v9 = 0;
  v11 = *v10;
  if ( *v10 <= 0xAFu )
  {
    operator delete(v10);
LABEL_6:
    v10 = operator new(0xB1u);
    v11 = -80;
  }
  is_continuation = v7 == 0;
  v10[176] = v11;
  v16.v = v10;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v10 = 0;
  *((_QWORD *)v10 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::do_complete;
  *((_DWORD *)v10 + 4) = 0;
  *((_DWORD *)v10 + 6) = 0;
  *((_QWORD *)v10 + 4) = boost::system::system_category();
  *((_QWORD *)v10 + 5) = 0;
  *((_QWORD *)v10 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v10 + 14) = socket;
  v10[60] = state;
  *((boost::asio::mutable_buffers_1 *)v10 + 4) = *buffers;
  *((_DWORD *)v10 + 20) = flags;
  *((_QWORD *)v10 + 11) = *(_QWORD *)handler;
  *((_QWORD *)v10 + 12) = *((_QWORD *)handler + 1);
  *((_QWORD *)v10 + 15) = *((_QWORD *)handler + 4);
  *(_OWORD *)(v10 + 104) = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  *((_DWORD *)v10 + 32) = *((_DWORD *)handler + 10);
  *((_QWORD *)v10 + 17) = *((_QWORD *)handler + 6);
  *((_OWORD *)v10 + 9) = *(_OWORD *)((char *)handler + 56);
  *((_QWORD *)v10 + 20) = *((_QWORD *)handler + 9);
  *((_QWORD *)v10 + 21) = *((_QWORD *)handler + 10);
  *(_OWORD *)((char *)handler + 72) = 0;
  v16.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)v10;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v10,
    is_continuation,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
  *(_OWORD *)&v16.v = 0;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::ptr::reset(&v16);
}


// Address: 0x26b2690 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_7read_opIS4_EENS1_17read_streambuf_opINS5_6streamIRSD_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSO_5list2INSO_5valueINSK_10shared_ptrISW_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbx
  char v10; // al
  boost::asio::detail::socket_type socket; // r13d
  boost::asio::detail::socket_ops::state_type state; // r15
  bool v13; // [rsp+17h] [rbp-41h]

  v13 = handler->start_ == 0 || handler->handler_.start_ == 0;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_6;
  v8 = *(_BYTE ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_6;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 <= 0xDFu )
  {
    operator delete(v9);
LABEL_6:
    v9 = operator new(0xE1u);
    v10 = -32;
  }
  v9[224] = v10;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_DWORD *)v9 + 6) = 0;
  *((_QWORD *)v9 + 4) = boost::system::system_category();
  *((_QWORD *)v9 + 5) = 0;
  *((_QWORD *)v9 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v9 + 14) = socket;
  v9[60] = state;
  *((boost::asio::mutable_buffers_1 *)v9 + 4) = *buffers;
  *((_DWORD *)v9 + 20) = flags;
  *((_QWORD *)v9 + 11) = handler->next_layer_;
  *((_QWORD *)v9 + 12) = handler->core_;
  *(boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)(v9 + 104) = handler->op_;
  *((_DWORD *)v9 + 30) = handler->start_;
  *((_DWORD *)v9 + 31) = handler->want_;
  *((_OWORD *)v9 + 8) = handler->ec_;
  *((_QWORD *)v9 + 18) = handler->bytes_transferred_;
  *(_OWORD *)(v9 + 152) = *(_OWORD *)&handler->handler_.completion_condition_.size_;
  *((_QWORD *)v9 + 21) = handler->handler_.streambuf_;
  *((_DWORD *)v9 + 44) = handler->handler_.start_;
  *((_QWORD *)v9 + 23) = handler->handler_.total_transferred_;
  *((_OWORD *)v9 + 12) = handler->handler_.handler_.f_;
  *((_OWORD *)v9 + 13) = handler->handler_.handler_.l_;
  handler->handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v9,
    v13,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26b2fc0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_7read_opIS4_EENS1_17read_streambuf_opINSD_6streamIRSB_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSQ_5list2INSQ_5valueINSM_10shared_ptrISY_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *handler)
{
  char v7; // r14
  unsigned __int64 v8; // rax
  void **v9; // rax
  void *v10; // rdi
  char *v11; // rbx
  boost::asio::detail::socket_type socket; // ebp

  if ( handler->start_ )
    v7 = handler->handler_.start_ == 0 || handler->handler_.handler_.start_ == 0;
  else
    v7 = 1;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( v8 )
  {
    v9 = *(void ***)(v8 + 8);
    if ( v9 )
    {
      v10 = *v9;
      if ( *v9 )
      {
        *v9 = 0;
        operator delete(v10);
      }
    }
  }
  v11 = (char *)operator new(0x109u);
  v11[264] = 0;
  socket = impl->socket_;
  *(_QWORD *)v11 = 0;
  *((_QWORD *)v11 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>::do_complete;
  *((_DWORD *)v11 + 4) = 0;
  *((_DWORD *)v11 + 6) = 0;
  *((_QWORD *)v11 + 4) = boost::system::system_category();
  *((_QWORD *)v11 + 5) = 0;
  *((_QWORD *)v11 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v11 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v11 + 4) = *buffers;
  *((_DWORD *)v11 + 20) = flags;
  *((_QWORD *)v11 + 11) = handler->stream_;
  *((_OWORD *)v11 + 6) = handler->buffer_;
  *((_DWORD *)v11 + 28) = handler->start_;
  *(_OWORD *)(v11 + 120) = *(_OWORD *)&handler->total_transferred_;
  *((_QWORD *)v11 + 17) = handler->handler_.core_;
  *((_OWORD *)v11 + 9) = handler->handler_.op_;
  *((_DWORD *)v11 + 40) = handler->handler_.start_;
  *((_DWORD *)v11 + 41) = handler->handler_.want_;
  *(boost::system::error_code *)(v11 + 168) = handler->handler_.ec_;
  *(_OWORD *)(v11 + 184) = *(_OWORD *)&handler->handler_.bytes_transferred_;
  *(_OWORD *)(v11 + 200) = *(_OWORD *)&handler->handler_.handler_.stream_;
  *((_DWORD *)v11 + 54) = handler->handler_.handler_.start_;
  *((_QWORD *)v11 + 28) = handler->handler_.handler_.total_transferred_;
  *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)(v11 + 232) = handler->handler_.handler_.handler_.f_;
  *(boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> *)(v11 + 248) = handler->handler_.handler_.handler_.l_;
  handler->handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v11,
    v7,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26b3660 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS1_17read_streambuf_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSG_5list2INSG_5valueINSC_10shared_ptrISO_EEEEPFNS_3argILi1EEEvEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  int start; // r13d
  unsigned __int64 v8; // rax
  _BYTE **v9; // rax
  _BYTE *v10; // rbx
  char v11; // al
  boost::asio::detail::socket_type socket; // r13d
  boost::asio::detail::socket_ops::state_type state; // r14
  bool is_continuation; // [rsp+14h] [rbp-44h]

  start = handler->start_;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *(_BYTE ***)(v8 + 8);
  if ( !v9 )
    goto LABEL_6;
  v10 = *v9;
  if ( !*v9 )
    goto LABEL_6;
  *v9 = 0;
  v11 = *v10;
  if ( *v10 <= 0x9Fu )
  {
    operator delete(v10);
LABEL_6:
    v10 = operator new(0xA1u);
    v11 = -96;
  }
  is_continuation = start == 0;
  v10[160] = v11;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v10 = 0;
  *((_QWORD *)v10 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::do_complete;
  *((_DWORD *)v10 + 4) = 0;
  *((_DWORD *)v10 + 6) = 0;
  *((_QWORD *)v10 + 4) = boost::system::system_category();
  *((_QWORD *)v10 + 5) = 0;
  *((_QWORD *)v10 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v10 + 14) = socket;
  v10[60] = state;
  *((boost::asio::mutable_buffers_1 *)v10 + 4) = *buffers;
  *((_DWORD *)v10 + 20) = flags;
  *(_OWORD *)(v10 + 88) = *(_OWORD *)&handler->completion_condition_.size_;
  *((_QWORD *)v10 + 13) = handler->streambuf_;
  *((_DWORD *)v10 + 28) = handler->start_;
  *((_QWORD *)v10 + 15) = handler->total_transferred_;
  *((_OWORD *)v10 + 8) = handler->handler_.f_;
  *((_OWORD *)v10 + 9) = handler->handler_.l_;
  handler->handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v10,
    is_continuation,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26b6100 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_7read_opIS4_EENS1_17read_streambuf_opINS5_6streamIRSD_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSO_5list3INSO_5valueINSK_10shared_ptrISW_EEEEPFNS_3argILi1EEEvENS13_IiEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > *handler)
{
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbx
  char v10; // al
  boost::asio::detail::socket_type socket; // r13d
  boost::asio::detail::socket_ops::state_type state; // r15
  bool v13; // [rsp+17h] [rbp-41h]

  v13 = handler->start_ == 0 || handler->handler_.start_ == 0;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_6;
  v8 = *(_BYTE ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_6;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 <= 0xE7u )
  {
    operator delete(v9);
LABEL_6:
    v9 = operator new(0xE9u);
    v10 = -24;
  }
  v9[232] = v10;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_DWORD *)v9 + 6) = 0;
  *((_QWORD *)v9 + 4) = boost::system::system_category();
  *((_QWORD *)v9 + 5) = 0;
  *((_QWORD *)v9 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v9 + 14) = socket;
  v9[60] = state;
  *((boost::asio::mutable_buffers_1 *)v9 + 4) = *buffers;
  *((_DWORD *)v9 + 20) = flags;
  *((_QWORD *)v9 + 11) = handler->next_layer_;
  *((_QWORD *)v9 + 12) = handler->core_;
  *(boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)(v9 + 104) = handler->op_;
  *((_DWORD *)v9 + 30) = handler->start_;
  *((_DWORD *)v9 + 31) = handler->want_;
  *((_OWORD *)v9 + 8) = handler->ec_;
  *((_QWORD *)v9 + 18) = handler->bytes_transferred_;
  *(_OWORD *)(v9 + 152) = *(_OWORD *)&handler->handler_.completion_condition_.size_;
  *((_QWORD *)v9 + 21) = handler->handler_.streambuf_;
  *((_DWORD *)v9 + 44) = handler->handler_.start_;
  *((_QWORD *)v9 + 23) = handler->handler_.total_transferred_;
  *((_OWORD *)v9 + 12) = handler->handler_.handler_.f_;
  *((_OWORD *)v9 + 13) = handler->handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  *((_DWORD *)v9 + 56) = handler->handler_.handler_.l_.a3_.t_;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v9,
    v13,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26b6a90 | Name: _ZN5boost4asio6detail28reactive_socket_service_base10async_sendINS0_17mutable_buffers_1ENS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEES4_NS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSE_7read_opIS4_EENS1_17read_streambuf_opINSD_6streamIRSB_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSQ_5list3INSQ_5valueINSM_10shared_ptrISY_EEEEPFNS_3argILi1EEEvENS15_IiEEEEEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > > *handler)
{
  char v7; // r14
  unsigned __int64 v8; // rax
  void **v9; // rax
  void *v10; // rdi
  char *v11; // rbx
  boost::asio::detail::socket_type socket; // ebp

  if ( handler->start_ )
    v7 = handler->handler_.start_ == 0 || handler->handler_.handler_.start_ == 0;
  else
    v7 = 1;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( v8 )
  {
    v9 = *(void ***)(v8 + 8);
    if ( v9 )
    {
      v10 = *v9;
      if ( *v9 )
      {
        *v9 = 0;
        operator delete(v10);
      }
    }
  }
  v11 = (char *)operator new(0x111u);
  v11[272] = 0;
  socket = impl->socket_;
  *(_QWORD *)v11 = 0;
  *((_QWORD *)v11 + 1) = boost::asio::detail::reactive_socket_send_op<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>>::do_complete;
  *((_DWORD *)v11 + 4) = 0;
  *((_DWORD *)v11 + 6) = 0;
  *((_QWORD *)v11 + 4) = boost::system::system_category();
  *((_QWORD *)v11 + 5) = 0;
  *((_QWORD *)v11 + 6) = boost::asio::detail::reactive_socket_send_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v11 + 14) = socket;
  *((boost::asio::mutable_buffers_1 *)v11 + 4) = *buffers;
  *((_DWORD *)v11 + 20) = flags;
  *((_QWORD *)v11 + 11) = handler->stream_;
  *((_OWORD *)v11 + 6) = handler->buffer_;
  *((_DWORD *)v11 + 28) = handler->start_;
  *(_OWORD *)(v11 + 120) = *(_OWORD *)&handler->total_transferred_;
  *((_QWORD *)v11 + 17) = handler->handler_.core_;
  *((_OWORD *)v11 + 9) = handler->handler_.op_;
  *((_DWORD *)v11 + 40) = handler->handler_.start_;
  *((_DWORD *)v11 + 41) = handler->handler_.want_;
  *(boost::system::error_code *)(v11 + 168) = handler->handler_.ec_;
  *(_OWORD *)(v11 + 184) = *(_OWORD *)&handler->handler_.bytes_transferred_;
  *(_OWORD *)(v11 + 200) = *(_OWORD *)&handler->handler_.handler_.stream_;
  *((_DWORD *)v11 + 54) = handler->handler_.handler_.start_;
  *((_QWORD *)v11 + 28) = handler->handler_.handler_.total_transferred_;
  *(boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int> *)(v11 + 232) = handler->handler_.handler_.handler_.f_;
  *(boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> *)(v11 + 248) = handler->handler_.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  *((_DWORD *)v11 + 66) = handler->handler_.handler_.handler_.l_.a3_.t_;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    1,
    (boost::asio::detail::reactor_op *)v11,
    v7,
    1,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


// Address: 0x26b7150 | Name: _ZN5boost4asio6detail28reactive_socket_service_base13async_receiveINS0_17mutable_buffers_1ENS1_17read_streambuf_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSG_5list3INSG_5valueINSC_10shared_ptrISO_EEEEPFNS_3argILi1EEEvENSV_IiEEEEEEEEEEvRNS2_24base_implementation_typeERKT_iRT0_
void __fastcall boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > *handler)
{
  int start; // r13d
  unsigned __int64 v8; // rax
  _BYTE **v9; // rax
  _BYTE *v10; // rbx
  char v11; // al
  boost::asio::detail::socket_type socket; // r13d
  boost::asio::detail::socket_ops::state_type state; // r14
  bool is_continuation; // [rsp+14h] [rbp-44h]

  start = handler->start_;
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 )
    goto LABEL_6;
  v9 = *(_BYTE ***)(v8 + 8);
  if ( !v9 )
    goto LABEL_6;
  v10 = *v9;
  if ( !*v9 )
    goto LABEL_6;
  *v9 = 0;
  v11 = *v10;
  if ( *v10 <= 0xA7u )
  {
    operator delete(v10);
LABEL_6:
    v10 = operator new(0xA9u);
    v11 = -88;
  }
  is_continuation = start == 0;
  v10[168] = v11;
  socket = impl->socket_;
  state = impl->state_;
  *(_QWORD *)v10 = 0;
  *((_QWORD *)v10 + 1) = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>::do_complete;
  *((_DWORD *)v10 + 4) = 0;
  *((_DWORD *)v10 + 6) = 0;
  *((_QWORD *)v10 + 4) = boost::system::system_category();
  *((_QWORD *)v10 + 5) = 0;
  *((_QWORD *)v10 + 6) = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  *((_DWORD *)v10 + 14) = socket;
  v10[60] = state;
  *((boost::asio::mutable_buffers_1 *)v10 + 4) = *buffers;
  *((_DWORD *)v10 + 20) = flags;
  *(_OWORD *)(v10 + 88) = *(_OWORD *)&handler->completion_condition_.size_;
  *((_QWORD *)v10 + 13) = handler->streambuf_;
  *((_DWORD *)v10 + 28) = handler->start_;
  *((_QWORD *)v10 + 15) = handler->total_transferred_;
  *((_OWORD *)v10 + 8) = handler->handler_.f_;
  *((_OWORD *)v10 + 9) = handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  *((_DWORD *)v10 + 40) = handler->handler_.l_.a3_.t_;
  boost::asio::detail::reactive_socket_service_base::start_op(
    this,
    impl,
    2 * (flags & 1),
    (boost::asio::detail::reactor_op *)v10,
    is_continuation,
    (flags & 1) == 0,
    ((unsigned __int8)(impl->state_ & 0x10) >> 4) & (buffers->size_ == 0));
}


