// Address: 0x260f990 | Name: _ZN5boost4asio6detail15task_io_service4postINS1_15wrapped_handlerINS0_10io_service6strandENSt3__18functionIFvvEEENS1_26is_continuation_if_runningEEEEEvRT_
void __fastcall boost::asio::detail::task_io_service::post<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::detail::task_io_service_0 *this,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *handler)
{
  unsigned __int64 v2; // rax
  bool v3; // bp
  unsigned __int64 v4; // rax
  char **v5; // rax
  char *v6; // rbx
  char v7; // al
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *f; // rax

  v2 = __readfsqword(0xFFFFFFE0);
  if ( v2 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v2 != handler->dispatcher_.impl_ )
    {
      v2 = *(_QWORD *)(v2 + 16);
      if ( !v2 )
        goto LABEL_4;
    }
    v3 = *(_QWORD *)(v2 + 8) != 0;
  }
  else
  {
LABEL_4:
    v3 = 0;
  }
  v4 = __readfsqword(0xFFFFFFD8);
  if ( v4 )
  {
    v5 = *(char ***)(v4 + 8);
    if ( v5 )
    {
      v6 = *v5;
      if ( *v5 )
      {
        *v5 = 0;
        v7 = *v6;
        if ( (unsigned __int8)*v6 > 0x5Fu )
          goto LABEL_12;
        operator delete(v6);
      }
    }
  }
  v6 = (char *)operator new(0x61u);
  v7 = 96;
LABEL_12:
  v6[96] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_OWORD *)v6 + 2) = handler->dispatcher_;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_ == (std::function<void ()> *)f )
    {
      *((_QWORD *)v6 + 10) = v6 + 48;
      (*((void (__fastcall **)(std::function<void ()>::__base *, char *))handler->handler_.__f_->_vptr$__base + 3))(
        handler->handler_.__f_,
        v6 + 48);
    }
    else
    {
      *((_QWORD *)v6 + 10) = f;
      handler->handler_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v6 + 10) = 0;
  }
  boost::asio::detail::task_io_service::post_immediate_completion(
    this,
    (boost::asio::detail::task_io_service::operation *)v6,
    v3);
}


// Address: 0x2626410 | Name: _ZN5boost4asio6detail15task_io_service4postINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EENS6_23basic_resolver_iteratorIS7_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSI_6config15asio_tls_client16transport_configEEEFvNSG_10shared_ptrINSK_10connectionISO_EEEENSQ_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISW_EENS0_22deadline_timer_serviceISW_SY_EEEEEENSG_8functionIFvRKNSG_10error_codeEEEERKNS_6system10error_codeEEJPSP_RST_RS12_RS18_RKNSG_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES1A_EEEEvRT_
void __fastcall boost::asio::detail::task_io_service::post<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>>(
        boost::asio::detail::task_io_service_0 *this,
        boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> *handler)
{
  unsigned __int64 v2; // rax
  bool v3; // bp
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al

  v2 = __readfsqword(0xFFFFFFE0);
  if ( v2 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v2 != handler->handler_.handler_.dispatcher_.impl_ )
    {
      v2 = *(_QWORD *)(v2 + 16);
      if ( !v2 )
        goto LABEL_4;
    }
    v3 = *(_QWORD *)(v2 + 8) != 0;
  }
  else
  {
LABEL_4:
    v3 = 0;
  }
  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_11;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_11;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_11;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0xEFu )
  {
    operator delete(v6);
LABEL_11:
    v6 = operator new(0xF1u);
    v7 = -16;
  }
  v6[240] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    (boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)(v6 + 32),
    &handler->handler_);
  *((_OWORD *)v6 + 14) = handler->arg1_;
  boost::asio::detail::task_io_service::post_immediate_completion(
    this,
    (boost::asio::detail::task_io_service::operation *)v6,
    v3);
}


// Address: 0x2667db0 | Name: _ZN5boost4asio6detail15task_io_service4postINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EENS6_23basic_resolver_iteratorIS7_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSI_6config11asio_client16transport_configEEEFvNSG_10shared_ptrINSK_10connectionISO_EEEENSQ_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISW_EENS0_22deadline_timer_serviceISW_SY_EEEEEENSG_8functionIFvRKNSG_10error_codeEEEERKNS_6system10error_codeEEJPSP_RST_RS12_RS18_RKNSG_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES1A_EEEEvRT_
void __fastcall boost::asio::detail::task_io_service::post<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>>(
        boost::asio::detail::task_io_service_0 *this,
        boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> *handler)
{
  unsigned __int64 v2; // rax
  bool v3; // bp
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al

  v2 = __readfsqword(0xFFFFFFE0);
  if ( v2 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v2 != handler->handler_.handler_.dispatcher_.impl_ )
    {
      v2 = *(_QWORD *)(v2 + 16);
      if ( !v2 )
        goto LABEL_4;
    }
    v3 = *(_QWORD *)(v2 + 8) != 0;
  }
  else
  {
LABEL_4:
    v3 = 0;
  }
  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_11;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_11;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_11;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0xEFu )
  {
    operator delete(v6);
LABEL_11:
    v6 = operator new(0xF1u);
    v7 = -16;
  }
  v6[240] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    (boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)(v6 + 32),
    &handler->handler_);
  *((_OWORD *)v6 + 14) = handler->arg1_;
  boost::asio::detail::task_io_service::post_immediate_completion(
    this,
    (boost::asio::detail::task_io_service::operation *)v6,
    v3);
}


// Address: 0x26a1320 | Name: _ZN5boost4asio6detail15task_io_service4postINS1_7binder1INS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSJ_3tcpEEEEENS5_5list3INS5_5valueINSt3__110shared_ptrISE_EEEEPFNS_3argILi1EEEvENSP_ISM_EEEEEESG_EEEEvRT_
void __fastcall boost::asio::detail::task_io_service::post<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>(
        boost::asio::detail::task_io_service_0 *this,
        boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> *handler)
{
  unsigned __int64 v3; // rax
  _BYTE **v4; // rax
  _BYTE *v5; // rsi
  char v6; // al
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> >::ptr v7; // [rsp+0h] [rbp-28h] BYREF

  v7.h = handler;
  v3 = __readfsqword(0xFFFFFFD8);
  if ( !v3 )
    goto LABEL_6;
  v4 = *(_BYTE ***)(v3 + 8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *v4;
  if ( !*v4 )
    goto LABEL_6;
  *v4 = 0;
  v6 = *v5;
  if ( *v5 <= 0x5Fu )
  {
    operator delete(v5);
LABEL_6:
    v5 = operator new(0x61u);
    v6 = 96;
  }
  v5[96] = v6;
  v7.v = v5;
  *(_QWORD *)v5 = 0;
  *((_QWORD *)v5 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::do_complete;
  *((_DWORD *)v5 + 4) = 0;
  *(boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)(v5 + 24) = handler->handler_.f_;
  *(boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> *)(v5 + 40) = handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>;
  handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> = 0;
  *(std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)(v5 + 56) = handler->handler_.l_.a3_.t_.values_;
  handler->handler_.l_.a3_.t_.values_ = 0;
  *((_QWORD *)v5 + 9) = handler->handler_.l_.a3_.t_.index_;
  *((_OWORD *)v5 + 5) = handler->arg1_;
  boost::asio::detail::task_io_service::post_immediate_completion(
    this,
    (boost::asio::detail::task_io_service::operation *)v5,
    0);
  *(_OWORD *)&v7.v = 0;
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::ptr::reset(&v7);
}


// Address: 0x26bc230 | Name: _ZN5boost4asio6detail15task_io_service4postINS1_7binder1INS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSI_3tcpEEEEENS5_5list3INS5_5valueINSt3__110shared_ptrISD_EEEEPFNS_3argILi1EEEvENSO_ISL_EEEEEESF_EEEEvRT_
void __fastcall boost::asio::detail::task_io_service::post<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>(
        boost::asio::detail::task_io_service_0 *this,
        boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> *handler)
{
  unsigned __int64 v3; // rax
  _BYTE **v4; // rax
  _BYTE *v5; // rsi
  char v6; // al
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> >::ptr v7; // [rsp+0h] [rbp-28h] BYREF

  v7.h = handler;
  v3 = __readfsqword(0xFFFFFFD8);
  if ( !v3 )
    goto LABEL_6;
  v4 = *(_BYTE ***)(v3 + 8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *v4;
  if ( !*v4 )
    goto LABEL_6;
  *v4 = 0;
  v6 = *v5;
  if ( *v5 <= 0x5Fu )
  {
    operator delete(v5);
LABEL_6:
    v5 = operator new(0x61u);
    v6 = 96;
  }
  v5[96] = v6;
  v7.v = v5;
  *(_QWORD *)v5 = 0;
  *((_QWORD *)v5 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::do_complete;
  *((_DWORD *)v5 + 4) = 0;
  *(boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)(v5 + 24) = handler->handler_.f_;
  *(boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> *)(v5 + 40) = handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  *(std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)(v5 + 56) = handler->handler_.l_.a3_.t_.values_;
  handler->handler_.l_.a3_.t_.values_ = 0;
  *((_QWORD *)v5 + 9) = handler->handler_.l_.a3_.t_.index_;
  *((_OWORD *)v5 + 5) = handler->arg1_;
  boost::asio::detail::task_io_service::post_immediate_completion(
    this,
    (boost::asio::detail::task_io_service::operation *)v5,
    0);
  *(_OWORD *)&v7.v = 0;
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::ptr::reset(&v7);
}


// Address: 0x26cec10 | Name: _ZN5boost4asio6detail15task_io_service4postINS_3_bi6bind_tIvPFvPvENS4_5list1INS4_5valueIS6_EEEEEEEEvRT_
void __fastcall boost::asio::detail::task_io_service::post<boost::_bi::bind_t<void,void (*)(void *),boost::_bi::list1<boost::_bi::value<void *>>>>(
        boost::asio::detail::task_io_service *this,
        boost::_bi::bind_t<void,void (*)(void *),boost::_bi::list1<boost::_bi::value<void *> > > *handler)
{
  unsigned __int64 v2; // rax
  _BYTE **v3; // rax
  _BYTE *v4; // rbx
  char v5; // al

  v2 = __readfsqword(0xFFFFFFD8);
  if ( !v2 )
    goto LABEL_6;
  v3 = *(_BYTE ***)(v2 + 8);
  if ( !v3 )
    goto LABEL_6;
  v4 = *v3;
  if ( !*v3 )
    goto LABEL_6;
  *v3 = 0;
  v5 = *v4;
  if ( *v4 <= 0x27u )
  {
    operator delete(v4);
LABEL_6:
    v4 = operator new(0x29u);
    v5 = 40;
  }
  v4[40] = v5;
  *(_QWORD *)v4 = 0;
  *((_QWORD *)v4 + 1) = boost::asio::detail::completion_handler<boost::_bi::bind_t<void,void (*)(void *),boost::_bi::list1<boost::_bi::value<void *>>>>::do_complete;
  *((_DWORD *)v4 + 4) = 0;
  *(boost::_bi::bind_t<void,void (*)(void *),boost::_bi::list1<boost::_bi::value<void *> > > *)(v4 + 24) = *handler;
  boost::asio::detail::task_io_service::post_immediate_completion(
    this,
    (boost::asio::detail::task_io_service::operation *)v4,
    0);
}


