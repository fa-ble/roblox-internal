// Address: 0x269f190 | Name: _ZN5boost4asio20basic_waitable_timerINSt3__16chrono12steady_clockENS0_11wait_traitsIS4_EENS0_22waitable_timer_serviceIS4_S6_EEE16expires_from_nowERKNS3_8durationIxNS2_5ratioILl1ELl1000000000EEEEE
size_t __fastcall boost::asio::basic_waitable_timer<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>,boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::expires_from_now(
        boost::asio::basic_waitable_timer<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>,boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this,
        const boost::asio::basic_waitable_timer<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>,boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::duration *expiry_time)
{
  std::chrono::duration<long long,std::ratio<1,1000000000> >::rep v2; // r12
  boost::asio::basic_io_object<boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> >,false>::service_type *service; // r14
  __int64 v4; // rax
  std::chrono::duration<long long,std::ratio<1,1000000000> >::rep rep; // rcx
  size_t v6; // r14

  v2 = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  service = this->service;
  v4 = std::chrono::steady_clock::now((std::chrono::steady_clock *)this);
  if ( v4 >= 0 )
  {
    rep = expiry_time->__rep_;
    if ( 0x7FFFFFFFFFFFFFFFLL - v4 < expiry_time->__rep_ )
      goto LABEL_4;
    goto LABEL_3;
  }
  v2 = 0x8000000000000000LL;
  rep = expiry_time->__rep_;
  if ( expiry_time->__rep_ >= -(__int64)(v4 ^ 0x8000000000000000LL) )
LABEL_3:
    v2 = v4 + rep;
LABEL_4:
  if ( this->implementation.might_have_pending_waits )
  {
    v6 = boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>(
           *((boost::asio::detail::epoll_reactor **)service + 11),
           (boost::asio::basic_io_object<boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> >,false>::service_type *)((char *)service + 40),
           &this->implementation.timer_data,
           0xFFFFFFFFFFFFFFFFLL);
    this->implementation.might_have_pending_waits = 0;
    boost::system::system_category();
  }
  else
  {
    boost::system::system_category();
    v6 = 0;
  }
  this->implementation.expiry.__d_.__rep_ = v2;
  boost::system::system_category();
  return v6;
}


