// Address: 0xdb0200 | Name: _ZN5boost21thread_resource_errorD0Ev
void __fastcall boost::thread_resource_error::~thread_resource_error(boost::thread_resource_error *this)
{
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdb0e20 | Name: _ZN5boost10lock_errorD0Ev
void __fastcall boost::lock_error::~lock_error(boost::lock_error *this)
{
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdcc860 | Name: _ZN5boost15condition_errorD0Ev
void __fastcall boost::condition_error::~condition_error(boost::condition_error *this)
{
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


