// Address: 0xd9e630 | Name: _ZN5boost6detail15sp_counted_baseD2Ev
void __fastcall boost::detail::sp_counted_base::~sp_counted_base(boost::detail::sp_counted_base *this)
{
  ;
}


// Address: 0xd9e660 | Name: _ZN5boost6detail15sp_counted_base7destroyEv
void __fastcall boost::detail::sp_counted_base::destroy(boost::detail::sp_counted_base *this)
{
  if ( this )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))this->_vptr$sp_counted_base + 1))(this);
}


