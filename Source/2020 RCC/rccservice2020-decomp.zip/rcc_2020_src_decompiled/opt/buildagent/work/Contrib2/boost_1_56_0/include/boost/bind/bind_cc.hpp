// Address: 0xdbc5f0 | Name: _ZN5boost4bindIvRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERKNS_10shared_ptrIN3RBX9DataModelEEElS9_RKNSA_IKNS_9unordered13unordered_mapIS7_NSB_10Reflection7VariantENS_4hashIS7_EENS1_8equal_toIS7_EENS5_INS1_4pairIS8_SJ_EEEEEEEENSB_5TimerILNSB_4Time12SampleMethodE0EEES7_SD_lS7_ST_SZ_EENS_3_bi6bind_tIT_PFS12_T0_T1_T2_T3_T4_T5_ENS10_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEES1A_S1C_S1D_S1E_S1F_S1G_S1H_
_QWORD *__fastcall boost::bind<void,std::string const&,boost::shared_ptr<RBX::DataModel> const&,long,std::string const&,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const> const&,RBX::Timer<(RBX::Time::SampleMethod)0>,std::string,boost::shared_ptr<RBX::DataModel>,long,std::string,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>,RBX::Timer<(RBX::Time::SampleMethod)0>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 a5,
        __int64 a6,
        double a7,
        __int64 *a8)
{
  volatile signed __int32 *v11; // rax
  volatile signed __int32 *v12; // rax
  volatile signed __int32 *v13; // rbx
  volatile signed __int32 *v14; // rbx
  volatile signed __int32 *v15; // rbx
  volatile signed __int32 *v16; // rbx
  __int64 v18; // [rsp+8h] [rbp-E0h] BYREF
  volatile signed __int32 *v19; // [rsp+10h] [rbp-D8h]
  __int64 v20; // [rsp+18h] [rbp-D0h] BYREF
  volatile signed __int32 *v21; // [rsp+20h] [rbp-C8h]
  double v22; // [rsp+28h] [rbp-C0h]
  _BYTE v23[16]; // [rsp+30h] [rbp-B8h] BYREF
  void *v24; // [rsp+40h] [rbp-A8h]
  _BYTE v25[16]; // [rsp+48h] [rbp-A0h] BYREF
  void *v26; // [rsp+58h] [rbp-90h]
  _BYTE v27[16]; // [rsp+60h] [rbp-88h] BYREF
  void *v28; // [rsp+70h] [rbp-78h]
  volatile signed __int32 *v29; // [rsp+80h] [rbp-68h]
  char v30; // [rsp+90h] [rbp-58h]
  void *ptr; // [rsp+A0h] [rbp-48h]
  volatile signed __int32 *v32; // [rsp+B0h] [rbp-38h]

  v22 = a7;
  std::string::basic_string(v25, a3);
  v20 = *a4;
  v11 = (volatile signed __int32 *)a4[1];
  v21 = v11;
  if ( v11 )
    _InterlockedAdd(v11 + 2, 1u);
  std::string::basic_string(v23, a6);
  v18 = *a8;
  v12 = (volatile signed __int32 *)a8[1];
  v19 = v12;
  if ( v12 )
    _InterlockedAdd(v12 + 2, 1u);
  boost::_bi::list6<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<RBX::Timer<(RBX::Time::SampleMethod)0>>>::list6(
    v27,
    v25,
    &v20,
    a5,
    v23,
    &v18,
    v22);
  *a1 = a2;
  boost::_bi::storage6<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<RBX::Timer<(RBX::Time::SampleMethod)0>>>::storage6(
    (boost::_bi::storage6<boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<RBX::Timer<RBX::Time::Fast> > > *)(a1 + 1),
    (const boost::_bi::storage6<boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<RBX::Timer<RBX::Time::Fast> > > *)v27);
  v13 = v32;
  if ( v32 )
  {
    if ( !_InterlockedSub(v32 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  if ( (v30 & 1) != 0 )
    operator delete(ptr);
  v14 = v29;
  if ( v29 )
  {
    if ( !_InterlockedSub(v29 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
      if ( !_InterlockedSub(v14 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
    }
  }
  if ( (v27[0] & 1) != 0 )
    operator delete(v28);
  v15 = v19;
  if ( v19 )
  {
    if ( !_InterlockedSub(v19 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  if ( (v23[0] & 1) != 0 )
    operator delete(v24);
  v16 = v21;
  if ( v21 )
  {
    if ( !_InterlockedSub(v21 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
      if ( !_InterlockedSub(v16 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
    }
  }
  if ( (v25[0] & 1) != 0 )
    operator delete(v26);
  return a1;
}


// Address: 0xde3a20 | Name: _ZN5boost4bindIvRKNS_8weak_ptrIN3RBX9DataModelEEERKNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEERKNS_10shared_ptrISD_EERKNSG_IbEEiSF_iPSD_PSt9exceptionS4_SD_SH_SK_iSD_iNS_3argILi1EEENSQ_ILi2EEEEENS_3_bi6bind_tIT_PFSV_T0_T1_T2_T3_T4_T5_T6_T7_T8_ENST_9list_av_9IT9_T10_T11_T12_T13_T14_T15_T16_T17_E4typeEEES16_S18_S19_S1A_S1B_S1C_S1D_S1E_S1F_S1G_
boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::DataModel> &,const std::string &,const boost::shared_ptr<std::string > &,const boost::shared_ptr<bool> &,int,const std::string &,int,std::string *,std::exception *),boost::_bi::list9<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<std::string > >,boost::_bi::value<boost::shared_ptr<bool> >,boost::_bi::value<int>,boost::_bi::value<std::string >,boost::_bi::value<int>,boost::arg<1>,boost::arg<2> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel> const&,std::string const&,boost::shared_ptr<std::string> const&,boost::shared_ptr<bool> const&,int,std::string const&,int,std::string*,std::exception *,boost::weak_ptr<RBX::DataModel>,std::string,boost::shared_ptr<std::string>,boost::shared_ptr<bool>,int,std::string,int,boost::arg<1>,boost::arg<2>>(
        boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::DataModel> &,const std::string &,const boost::shared_ptr<std::string > &,const boost::shared_ptr<bool> &,int,const std::string &,int,std::string *,std::exception *),boost::_bi::list9<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<std::string > >,boost::_bi::value<boost::shared_ptr<bool> >,boost::_bi::value<int>,boost::_bi::value<std::string >,boost::_bi::value<int>,boost::arg<1>,boost::arg<2> > > *this,
        void (*f)(const boost::weak_ptr<RBX::DataModel> *, const std::string *, const boost::shared_ptr<std::string > *, const boost::shared_ptr<bool> *, int, const std::string *, int, std::string *, std::exception *),
        __int64 *a3,
        __int64 a4,
        __int64 *a5,
        __int64 *a6,
        int a7,
        __int64 a8,
        unsigned int a9)
{
  __int64 v12; // rax
  volatile signed __int32 *v13; // rax
  volatile signed __int32 *v14; // rax
  volatile signed __int32 *v15; // rbx
  volatile signed __int32 *v16; // rbx
  __int64 v17; // rdi
  __int64 v19; // [rsp+8h] [rbp-F0h] BYREF
  volatile signed __int32 *v20; // [rsp+10h] [rbp-E8h]
  __int64 v21; // [rsp+18h] [rbp-E0h] BYREF
  volatile signed __int32 *v22; // [rsp+20h] [rbp-D8h]
  __int64 v23; // [rsp+28h] [rbp-D0h] BYREF
  __int64 v24; // [rsp+30h] [rbp-C8h]
  _BYTE v25[16]; // [rsp+38h] [rbp-C0h] BYREF
  void *v26; // [rsp+48h] [rbp-B0h]
  _BYTE v27[16]; // [rsp+50h] [rbp-A8h] BYREF
  void *v28; // [rsp+60h] [rbp-98h]
  _BYTE v29[96]; // [rsp+68h] [rbp-90h] BYREF
  void *ptr; // [rsp+C8h] [rbp-30h]

  v23 = *a3;
  v12 = a3[1];
  v24 = v12;
  if ( v12 )
    _InterlockedAdd((volatile signed __int32 *)(v12 + 12), 1u);
  std::string::basic_string(v25, a4);
  v21 = *a5;
  v13 = (volatile signed __int32 *)a5[1];
  v22 = v13;
  if ( v13 )
    _InterlockedAdd(v13 + 2, 1u);
  v19 = *a6;
  v14 = (volatile signed __int32 *)a6[1];
  v20 = v14;
  if ( v14 )
    _InterlockedAdd(v14 + 2, 1u);
  std::string::basic_string(v27, a8);
  boost::_bi::list9<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<std::string>>,boost::_bi::value<boost::shared_ptr<bool>>,boost::_bi::value<int>,boost::_bi::value<std::string>,boost::_bi::value<int>,boost::arg<1>,boost::arg<2>>::list9(
    (unsigned int)v29,
    (unsigned int)&v23,
    (unsigned int)v25,
    (unsigned int)&v21,
    (unsigned int)&v19,
    a7,
    (__int64)v27,
    a9);
  boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel> const&,std::string const&,boost::shared_ptr<std::string> const&,boost::shared_ptr<bool> const&,int,std::string const&,int,std::string*,std::exception *),boost::_bi::list9<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<std::string>>,boost::_bi::value<boost::shared_ptr<bool>>,boost::_bi::value<int>,boost::_bi::value<std::string>,boost::_bi::value<int>,boost::arg<1>,boost::arg<2>>>::bind_t(
    this,
    f,
    (const boost::_bi::list9<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<std::string > >,boost::_bi::value<boost::shared_ptr<bool> >,boost::_bi::value<int>,boost::_bi::value<std::string >,boost::_bi::value<int>,boost::arg<1>,boost::arg<2> > *)v29);
  if ( (v29[80] & 1) != 0 )
    operator delete(ptr);
  boost::_bi::storage4<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<std::string>>,boost::_bi::value<boost::shared_ptr<bool>>>::~storage4((boost::_bi::storage4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<std::string > >,boost::_bi::value<boost::shared_ptr<bool> > > *)v29);
  if ( (v27[0] & 1) != 0 )
    operator delete(v28);
  v15 = v20;
  if ( v20 )
  {
    if ( !_InterlockedSub(v20 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  v16 = v22;
  if ( v22 )
  {
    if ( !_InterlockedSub(v22 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
      if ( !_InterlockedSub(v16 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
    }
  }
  if ( (v25[0] & 1) != 0 )
    operator delete(v26);
  v17 = v24;
  if ( v24 && !_InterlockedSub((volatile signed __int32 *)(v24 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v17 + 24LL))(v17);
  return this;
}


// Address: 0xef9610 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENS_10shared_ptrIbEES4_S6_EENS_3_bi6bind_tIT_PFS9_T0_T1_ENS7_9list_av_2IT2_T3_E4typeEEESD_SF_SG_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<bool>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<bool> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<bool>,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<bool>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<bool>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<bool> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, boost::shared_ptr<bool>),
        boost::weak_ptr<RBX::DataModel> a1,
        boost::shared_ptr<bool> a2)
{
  boost::detail::sp_counted_base *v5; // rax
  volatile signed __int32 *v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // rax
  boost::detail::sp_counted_base *v9; // rbx
  boost::detail::sp_counted_base *v10; // rdi
  volatile signed __int32 *v11; // rbx
  boost::detail::sp_counted_base *v12; // rdi
  int (**v14)(void); // [rsp+0h] [rbp-58h] BYREF
  volatile signed __int32 *v15; // [rsp+8h] [rbp-50h]
  boost::_bi::value<boost::weak_ptr<RBX::DataModel> > a1a; // [rsp+10h] [rbp-48h] BYREF
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<bool> > > v17; // [rsp+20h] [rbp-38h] BYREF

  a1a.t_.px = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  a1a.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->weak_count_, 1u);
  v14 = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v15 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::shared_ptr<bool>>>::list2(
    &v17,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(&v14, &a1a),
    (boost::_bi::value<boost::shared_ptr<bool> >)__PAIR128__((unsigned __int64)a2.px, (unsigned __int64)a1.pn.pi_));
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v17.a1_.t_.px;
  pi = v17.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v17.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a2_.t_.px = v17.a2_.t_.px;
  v8 = v17.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v17.a2_.t_.pn.pi_;
  if ( v8 )
  {
    _InterlockedAdd(&v8->use_count_, 1u);
    v9 = v17.a2_.t_.pn.pi_;
    if ( v17.a2_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v17.a2_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
        if ( !_InterlockedSub(&v9->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
      }
    }
  }
  v10 = v17.a1_.t_.pn.pi_;
  if ( v17.a1_.t_.pn.pi_ && !_InterlockedSub(&v17.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
  v11 = v15;
  if ( v15 )
  {
    if ( !_InterlockedSub(v15 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
  v12 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ && !_InterlockedSub(&a1a.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
  return retstr;
}


// Address: 0xf44080 | Name: _ZN5boost4bindIbiiRNSt3__16vectorIfNS1_9allocatorIfEEEEbNS_3argILi1EEENS7_ILi2EEES5_bEENS_3_bi6bind_tIT_PFSC_T0_T1_T2_T3_ENSA_9list_av_4IT4_T5_T6_T7_E4typeEEESI_SK_SL_SM_SN_
__int64 __fastcall boost::bind<bool,int,int,std::vector<float> &,bool,boost::arg<1>,boost::arg<2>,std::vector<float>,bool>(
        __int64 a1,
        void **a2,
        __int64 a3,
        int a4)
{
  unsigned __int8 v4; // r12
  void **v5; // r14
  const void *v7; // r13
  signed __int64 v8; // rbx
  void **v9; // r12
  char *v10; // rbp
  void *v11; // r14
  signed __int64 v12; // rbx
  char *v13; // rbp
  struct _Unwind_Exception *v15; // r14
  void *v16; // rdi
  void *ptr[2]; // [rsp+0h] [rbp-78h] BYREF
  char *v18; // [rsp+10h] [rbp-68h]
  int v19; // [rsp+24h] [rbp-54h]
  void *src; // [rsp+28h] [rbp-50h] BYREF
  _BYTE *v21; // [rsp+30h] [rbp-48h]
  char v22; // [rsp+40h] [rbp-38h]

  v4 = a4;
  v5 = a2;
  *(_OWORD *)ptr = 0;
  v18 = 0;
  v7 = *(const void **)a3;
  v8 = *(_QWORD *)(a3 + 8) - *(_QWORD *)a3;
  if ( v8 )
  {
    v19 = a4;
    v9 = a2;
    if ( (unsigned __int64)(v8 >> 2) > 0x3FFFFFFFFFFFFFFFLL )
    {
      std::__vector_base_common<true>::__throw_length_error(ptr);
      goto LABEL_15;
    }
    v10 = (char *)operator new(v8);
    ptr[1] = v10;
    ptr[0] = v10;
    v18 = &v10[4 * (v8 >> 2)];
    v5 = a2;
    v4 = v19;
    if ( v8 > 0 )
    {
      memcpy(v10, v7, v8);
      ptr[1] = &v10[v8];
    }
  }
  boost::_bi::list4<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::vector<float>>,boost::_bi::value<bool>>::list4(
    &src,
    ptr,
    v4);
  *(_QWORD *)a1 = v5;
  *(_OWORD *)(a1 + 8) = 0;
  *(_QWORD *)(a1 + 24) = 0;
  v11 = src;
  v12 = v21 - (_BYTE *)src;
  if ( v21 == src )
    goto LABEL_9;
  v9 = (void **)(a1 + 8);
  if ( (unsigned __int64)(v12 >> 2) > 0x3FFFFFFFFFFFFFFFLL )
  {
LABEL_15:
    v15 = (struct _Unwind_Exception *)std::__vector_base_common<true>::__throw_length_error(v9);
    v16 = *v9;
    if ( *v9 )
    {
      *(_QWORD *)(a1 + 16) = v16;
      operator delete(v16);
    }
    if ( src )
    {
      v21 = src;
      operator delete(src);
    }
    if ( ptr[0] )
    {
      ptr[1] = ptr[0];
      operator delete(ptr[0]);
    }
    _Unwind_Resume(v15);
  }
  v13 = (char *)operator new(v21 - (_BYTE *)src);
  *(_QWORD *)(a1 + 16) = v13;
  *(_QWORD *)(a1 + 8) = v13;
  *(_QWORD *)(a1 + 24) = &v13[4 * (v12 >> 2)];
  if ( v12 > 0 )
  {
    memcpy(v13, v11, v12);
    *(_QWORD *)(a1 + 16) = &v13[v12];
  }
LABEL_9:
  *(_BYTE *)(a1 + 32) = v22;
  if ( v11 )
  {
    v21 = v11;
    operator delete(v11);
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
  return a1;
}


// Address: 0xf76a30 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX8InstanceEEENS1_INS2_7Network10ReplicatorEEEEENS_3_bi6bind_tIT_PFSA_T0_ENS8_9list_av_1IT1_E4typeEEESD_SF_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Instance>),boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> > > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Network::Replicator>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Instance>),boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> > > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::Instance>),
        boost::shared_ptr<RBX::Network::Replicator> a1)
{
  boost::shared_ptr<RBX::Network::Replicator>::element_type *v3; // r12
  boost::detail::sp_counted_base *v4; // rbx

  v3 = *(boost::shared_ptr<RBX::Network::Replicator>::element_type **)a1.px;
  v4 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v4 )
  {
    _InterlockedAdd(&v4->use_count_, 1u);
    _InterlockedAdd(&v4->use_count_, 1u);
    _InterlockedAdd(&v4->use_count_, 1u);
    if ( !_InterlockedSub(&v4->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::Instance>), boost::shared_ptr<RBX::Network::Replicator>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 2))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v3;
    retstr->l_.a1_.t_.pn.pi_ = v4;
    _InterlockedAdd(&v4->use_count_, 1u);
    if ( !_InterlockedSub(&v4->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::Instance>), boost::shared_ptr<RBX::Network::Replicator>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 2))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
    if ( !_InterlockedSub(&v4->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::Instance>), boost::shared_ptr<RBX::Network::Replicator>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 2))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v3;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0xfd1e20 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX7Network6ServerEEES5_EENS_3_bi6bind_tIT_PFS8_T0_ENS6_9list_av_1IT1_E4typeEEESB_SD_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Network::Server>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Network::Server> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::Network::Server>,boost::weak_ptr<RBX::Network::Server>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Network::Server>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Network::Server> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::Network::Server>),
        boost::weak_ptr<RBX::Network::Server> a1)
{
  boost::weak_ptr<RBX::Network::Server>::element_type *v3; // r12
  boost::detail::sp_counted_base *v4; // rbx

  v3 = *(boost::weak_ptr<RBX::Network::Server>::element_type **)a1.px;
  v4 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v4 )
  {
    _InterlockedAdd(&v4->weak_count_, 1u);
    _InterlockedAdd(&v4->weak_count_, 1u);
    _InterlockedAdd(&v4->weak_count_, 1u);
    if ( !_InterlockedSub(&v4->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Network::Server>), boost::weak_ptr<RBX::Network::Server>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 3))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v3;
    retstr->l_.a1_.t_.pn.pi_ = v4;
    _InterlockedAdd(&v4->weak_count_, 1u);
    if ( !_InterlockedSub(&v4->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Network::Server>), boost::weak_ptr<RBX::Network::Server>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 3))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
    if ( !_InterlockedSub(&v4->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Network::Server>), boost::weak_ptr<RBX::Network::Server>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 3))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v3;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0xfe63c0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENS1_INS2_7Network16ServerReplicatorEEEi14PacketPriorityiS4_S7_iS8_iEENS_3_bi6bind_tIT_PFSB_T0_T1_T2_T3_T4_ENS9_9list_av_5IT5_T6_T7_T8_T9_E4typeEEESI_SK_SL_SM_SN_SO_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, boost::weak_ptr<RBX::Network::ServerReplicator>, int, PacketPriority, int),
        boost::weak_ptr<RBX::DataModel> a1,
        boost::weak_ptr<RBX::Network::ServerReplicator> a2,
        int a3)
{
  boost::detail::sp_counted_base *v6; // rax
  __int64 v7; // rcx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v9; // rax
  boost::detail::sp_counted_base *v10; // rdi
  boost::detail::sp_counted_base *v11; // rdi
  __int64 v12; // rdi
  boost::detail::sp_counted_base *v13; // rdi
  boost::_bi::value<PacketPriority> v15; // [rsp+0h] [rbp-68h]
  int (**a1a)(void); // [rsp+8h] [rbp-60h] BYREF
  __int64 v17; // [rsp+10h] [rbp-58h]
  boost::_bi::value<boost::weak_ptr<RBX::DataModel> > v18; // [rsp+18h] [rbp-50h] BYREF
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > v19; // [rsp+28h] [rbp-40h] BYREF

  v18.t_.px = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v18.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->weak_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(_QWORD *)&a1.pn.pi_->use_count_;
  v17 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>::list5(
    &v19,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(&a1a, &v18),
    (boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >)__PAIR128__(LODWORD(a2.pn.pi_), LODWORD(a2.px)),
    (boost::_bi::value<int>)a3,
    v15,
    (boost::_bi::value<int>)a1a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v19.a1_.t_.px;
  pi = v19.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v19.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a2_.t_.px = v19.a2_.t_.px;
  v9 = v19.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v19.a2_.t_.pn.pi_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->weak_count_, 1u);
    v10 = v19.a2_.t_.pn.pi_;
  }
  else
  {
    v10 = 0;
  }
  retstr->l_.a3_.t_ = v19.a3_.t_;
  retstr->l_.a4_.t_ = v19.a4_.t_;
  retstr->l_.a5_.t_ = v19.a5_.t_;
  if ( v10 && !_InterlockedSub(&v10->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
  v11 = v19.a1_.t_.pn.pi_;
  if ( v19.a1_.t_.pn.pi_ && !_InterlockedSub(&v19.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
  v12 = v17;
  if ( v17 && !_InterlockedSub((volatile signed __int32 *)(v17 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v12 + 24LL))(v12);
  v13 = v18.t_.pn.pi_;
  if ( v18.t_.pn.pi_ && !_InterlockedSub(&v18.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
  return retstr;
}


// Address: 0xfe6740 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX7Network16ServerReplicatorEEENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEES5_SC_EENS_3_bi6bind_tIT_PFSF_T0_T1_ENSD_9list_av_2IT2_T3_E4typeEEESJ_SL_SM_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::Network::ServerReplicator>,std::string,boost::weak_ptr<RBX::Network::ServerReplicator>,std::string>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4)
{
  __int64 v5; // rax
  __int64 v6; // rax
  __int64 v7; // rdi
  __int64 v8; // rdi
  __int64 v10; // [rsp+8h] [rbp-60h] BYREF
  __int64 v11; // [rsp+10h] [rbp-58h]
  _BYTE v12[16]; // [rsp+18h] [rbp-50h] BYREF
  void *v13; // [rsp+28h] [rbp-40h]
  __int64 v14; // [rsp+30h] [rbp-38h] BYREF
  __int64 v15; // [rsp+38h] [rbp-30h]
  _BYTE v16[16]; // [rsp+40h] [rbp-28h] BYREF
  void *ptr; // [rsp+50h] [rbp-18h]

  v10 = *a3;
  v5 = a3[1];
  v11 = v5;
  if ( v5 )
    _InterlockedAdd((volatile signed __int32 *)(v5 + 12), 1u);
  std::string::basic_string(v12, a4);
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<std::string>>::list2(
    &v14,
    &v10,
    v12);
  *a1 = a2;
  a1[1] = v14;
  v6 = v15;
  a1[2] = v15;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)(v6 + 12), 1u);
  std::string::basic_string(a1 + 3, v16);
  if ( (v16[0] & 1) != 0 )
    operator delete(ptr);
  v7 = v15;
  if ( v15 && !_InterlockedSub((volatile signed __int32 *)(v15 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v7 + 24LL))(v7);
  if ( (v12[0] & 1) != 0 )
    operator delete(v13);
  v8 = v11;
  if ( v11 && !_InterlockedSub((volatile signed __int32 *)(v11 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 24LL))(v8);
  return a1;
}


// Address: 0xfe6bf0 | Name: _ZN5boost4bindIvRKNS_8weak_ptrIN3RBX7Network16ServerReplicatorEEEllS5_llEENS_3_bi6bind_tIT_PFSA_T0_T1_T2_ENS8_9list_av_3IT3_T4_T5_E4typeEEESF_SH_SI_SJ_
boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::Network::ServerReplicator> &,long,long),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<long>,boost::_bi::value<long> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::Network::ServerReplicator> const&,long,long,boost::weak_ptr<RBX::Network::ServerReplicator>,long,long>(
        boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::Network::ServerReplicator> &,long,long),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<long>,boost::_bi::value<long> > > *__return_ptr retstr,
        void (*f)(const boost::weak_ptr<RBX::Network::ServerReplicator> *, __int64, __int64),
        boost::weak_ptr<RBX::Network::ServerReplicator> a1,
        __int64 a2,
        __int64 a3)
{
  __int64 v5; // rax
  boost::detail::sp_counted_base *pi; // r12
  boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *v8; // rbp
  boost::detail::sp_counted_base *v9; // rbx

  pi = a1.pn.pi_;
  v8 = *(boost::weak_ptr<RBX::Network::ServerReplicator>::element_type **)a1.px;
  v9 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v9 )
  {
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::weak_ptr<RBX::Network::ServerReplicator> *, __int64, __int64), boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *, boost::detail::sp_counted_base *, __int64, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3,
        v5);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::weak_ptr<RBX::Network::ServerReplicator> *, __int64, __int64), boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::weak_ptr<RBX::Network::ServerReplicator> *, __int64, __int64), boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v8;
    retstr->l_.a1_.t_.pn.pi_ = v9;
    _InterlockedAdd(&v9->weak_count_, 1u);
    retstr->l_.a2_.t_ = (__int64)pi;
    retstr->l_.a3_.t_ = a2;
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::weak_ptr<RBX::Network::ServerReplicator> *, __int64, __int64), boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::weak_ptr<RBX::Network::ServerReplicator> *, __int64, __int64), boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v8;
    retstr->l_.a1_.t_.pn.pi_ = 0;
    retstr->l_.a2_.t_ = (__int64)a1.pn.pi_;
    retstr->l_.a3_.t_ = a2;
  }
  return retstr;
}


// Address: 0xfe6ea0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX7Network16ServerReplicatorEEEbiS5_biEENS_3_bi6bind_tIT_PFS8_T0_T1_T2_ENS6_9list_av_3IT3_T4_T5_E4typeEEESD_SF_SG_SH_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Network::ServerReplicator>,bool,int),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<bool>,boost::_bi::value<int> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::Network::ServerReplicator>,bool,int,boost::weak_ptr<RBX::Network::ServerReplicator>,bool,int>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Network::ServerReplicator>,bool,int),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<bool>,boost::_bi::value<int> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::Network::ServerReplicator>, bool, int),
        boost::weak_ptr<RBX::Network::ServerReplicator> a1,
        __int64 a2,
        __int64 a3)
{
  __int64 v5; // rax
  int v6; // r15d
  char pi; // r12
  boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *v8; // rbp
  boost::detail::sp_counted_base *v9; // rbx

  v6 = a2;
  pi = (char)a1.pn.pi_;
  v8 = *(boost::weak_ptr<RBX::Network::ServerReplicator>::element_type **)a1.px;
  v9 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v9 )
  {
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Network::ServerReplicator>, bool, int), boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *, boost::detail::sp_counted_base *, __int64, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3,
        v5);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Network::ServerReplicator>, bool, int), boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Network::ServerReplicator>, bool, int), boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v8;
    retstr->l_.a1_.t_.pn.pi_ = v9;
    _InterlockedAdd(&v9->weak_count_, 1u);
    retstr->l_.a2_.t_ = pi;
    retstr->l_.a3_.t_ = v6;
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Network::ServerReplicator>, bool, int), boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Network::ServerReplicator>, bool, int), boost::weak_ptr<RBX::Network::ServerReplicator>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v8;
    retstr->l_.a1_.t_.pn.pi_ = 0;
    retstr->l_.a2_.t_ = (bool)a1.pn.pi_;
    retstr->l_.a3_.t_ = a2;
  }
  return retstr;
}


// Address: 0xfe7380 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEES4_EENS_3_bi6bind_tIT_PFS7_T0_ENS5_9list_av_1IT1_E4typeEEESA_SC_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::DataModel> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::DataModel>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::DataModel> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>),
        boost::weak_ptr<RBX::DataModel> a1)
{
  boost::weak_ptr<RBX::DataModel>::element_type *v3; // r12
  boost::detail::sp_counted_base *v4; // rbx

  v3 = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v4 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v4 )
  {
    _InterlockedAdd(&v4->weak_count_, 1u);
    _InterlockedAdd(&v4->weak_count_, 1u);
    _InterlockedAdd(&v4->weak_count_, 1u);
    if ( !_InterlockedSub(&v4->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::DataModel>), boost::weak_ptr<RBX::DataModel>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 3))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v3;
    retstr->l_.a1_.t_.pn.pi_ = v4;
    _InterlockedAdd(&v4->weak_count_, 1u);
    if ( !_InterlockedSub(&v4->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::DataModel>), boost::weak_ptr<RBX::DataModel>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 3))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
    if ( !_InterlockedSub(&v4->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::DataModel>), boost::weak_ptr<RBX::DataModel>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 3))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v3;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x105fd60 | Name: _ZN5boost4bindIvN3RBX17HttpRequestResultEPNSt3__113basic_istreamIcNS3_11char_traitsIcEEEENS_8weak_ptrINS1_24KeyframeSequenceProviderEEENS9_INS1_16KeyframeSequenceEEERKNS3_12basic_stringIcS6_NS3_9allocatorIcEEEERKNS1_18InstanceIdentifierENS_8functionIFvNS_10shared_ptrINS1_8InstanceEEEEEENSN_IFvSH_EEENS_3argILi1EEENSV_ILi2EEESB_SD_SH_SK_SS_SU_EENS_3_bi6bind_tIT_PFS10_T0_T1_T2_T3_T4_T5_T6_T7_ENSY_9list_av_8IT8_T9_T10_T11_T12_T13_T14_T15_E4typeEEES1A_S1C_S1D_S1E_S1F_S1G_S1H_S1I_S1J_
_QWORD *__fastcall boost::bind<void,RBX::HttpRequestResult,std::istream *,boost::weak_ptr<RBX::KeyframeSequenceProvider>,boost::weak_ptr<RBX::KeyframeSequence>,std::string const&,RBX::InstanceIdentifier const&,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>,boost::arg<1>,boost::arg<2>,boost::weak_ptr<RBX::KeyframeSequenceProvider>,boost::weak_ptr<RBX::KeyframeSequence>,std::string,RBX::InstanceIdentifier,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 *a4,
        __int64 a5,
        const RBX::InstanceIdentifier *a6,
        __int64 *a7,
        __int64 *a8)
{
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  void (__fastcall *v14)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v15)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v16)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v17)(__int128 *, __int128 *, __int64); // rax
  __int64 v18; // rdi
  __int64 v19; // rdi
  __int64 v21; // [rsp+10h] [rbp-1A8h] BYREF
  __int128 v22; // [rsp+18h] [rbp-1A0h] BYREF
  __int64 v23; // [rsp+28h] [rbp-190h]
  __int64 v24; // [rsp+30h] [rbp-188h] BYREF
  __int128 v25; // [rsp+38h] [rbp-180h] BYREF
  __int64 v26; // [rsp+48h] [rbp-170h]
  __int64 v27; // [rsp+50h] [rbp-168h] BYREF
  __int64 v28; // [rsp+58h] [rbp-160h]
  __int64 v29; // [rsp+60h] [rbp-158h] BYREF
  __int64 v30; // [rsp+68h] [rbp-150h]
  _BYTE v31[16]; // [rsp+70h] [rbp-148h] BYREF
  void *ptr; // [rsp+80h] [rbp-138h]
  _BYTE v33[16]; // [rsp+88h] [rbp-130h] BYREF
  void *v34; // [rsp+98h] [rbp-120h]
  char v35; // [rsp+A0h] [rbp-118h]
  void *v36; // [rsp+B0h] [rbp-108h]
  char v37; // [rsp+B8h] [rbp-100h]
  void *v38; // [rsp+C8h] [rbp-F0h]
  _BYTE v39[136]; // [rsp+D8h] [rbp-E0h] BYREF
  __int64 v40; // [rsp+160h] [rbp-58h]
  _BYTE v41[24]; // [rsp+168h] [rbp-50h] BYREF
  __int64 v42; // [rsp+180h] [rbp-38h]
  _BYTE v43[48]; // [rsp+188h] [rbp-30h] BYREF

  v29 = *a3;
  v10 = a3[1];
  v30 = v10;
  if ( v10 )
    _InterlockedAdd((volatile signed __int32 *)(v10 + 12), 1u);
  v27 = *a4;
  v11 = a4[1];
  v28 = v11;
  if ( v11 )
    _InterlockedAdd((volatile signed __int32 *)(v11 + 12), 1u);
  std::string::basic_string(v31, a5);
  boost::_bi::value<RBX::InstanceIdentifier>::value((boost::_bi::value<RBX::InstanceIdentifier> *)v33, a6);
  v24 = 0;
  v12 = *a7;
  if ( *a7 )
  {
    v24 = *a7;
    if ( (v12 & 1) != 0 )
    {
      v26 = a7[3];
      v25 = *(_OWORD *)(a7 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(a7 + 1, &v25, 0);
    }
  }
  v21 = 0;
  v13 = *a8;
  if ( *a8 )
  {
    v21 = *a8;
    if ( (v13 & 1) != 0 )
    {
      v23 = a8[3];
      v22 = *(_OWORD *)(a8 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v13 & 0xFFFFFFFFFFFFFFFELL))(a8 + 1, &v22, 0);
    }
  }
  boost::_bi::list8<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequenceProvider>>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence>>,boost::_bi::value<std::string>,boost::_bi::value<RBX::InstanceIdentifier>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list8(
    (unsigned int)v39,
    (unsigned int)&v29,
    (unsigned int)&v27,
    (unsigned int)v31,
    (unsigned int)v33,
    (unsigned int)&v24,
    (__int64)&v21);
  *a1 = a2;
  boost::_bi::storage8<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequenceProvider>>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence>>,boost::_bi::value<std::string>,boost::_bi::value<RBX::InstanceIdentifier>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage8(
    (boost::_bi::storage8<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequenceProvider> >,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<std::string >,boost::_bi::value<RBX::InstanceIdentifier>,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::storage8<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequenceProvider> >,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<std::string >,boost::_bi::value<RBX::InstanceIdentifier>,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v39);
  if ( v42 )
  {
    if ( (v42 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v42 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(v43, v43, 2);
    }
    v42 = 0;
  }
  if ( v40 )
  {
    if ( (v40 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v40 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(v41, v41, 2);
    }
    v40 = 0;
  }
  boost::_bi::storage6<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequenceProvider>>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence>>,boost::_bi::value<std::string>,boost::_bi::value<RBX::InstanceIdentifier>>::~storage6((boost::_bi::storage6<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequenceProvider> >,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<std::string >,boost::_bi::value<RBX::InstanceIdentifier> > *)v39);
  if ( v21 )
  {
    if ( (v21 & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v21 & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v22, &v22, 2);
    }
    v21 = 0;
  }
  if ( v24 )
  {
    if ( (v24 & 1) == 0 )
    {
      v17 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v24 & 0xFFFFFFFFFFFFFFFELL);
      if ( v17 )
        v17(&v25, &v25, 2);
    }
    v24 = 0;
  }
  if ( (v37 & 1) != 0 )
  {
    operator delete(v38);
    if ( (v35 & 1) == 0 )
    {
LABEL_35:
      if ( (v33[0] & 1) == 0 )
        goto LABEL_36;
LABEL_47:
      operator delete(v34);
      if ( (v31[0] & 1) == 0 )
        goto LABEL_38;
      goto LABEL_37;
    }
  }
  else if ( (v35 & 1) == 0 )
  {
    goto LABEL_35;
  }
  operator delete(v36);
  if ( (v33[0] & 1) != 0 )
    goto LABEL_47;
LABEL_36:
  if ( (v31[0] & 1) != 0 )
LABEL_37:
    operator delete(ptr);
LABEL_38:
  v18 = v28;
  if ( v28 && !_InterlockedSub((volatile signed __int32 *)(v28 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v18 + 24LL))(v18);
  v19 = v30;
  if ( v30 && !_InterlockedSub((volatile signed __int32 *)(v30 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v19 + 24LL))(v19);
  return a1;
}


// Address: 0x1061540 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEENS_10shared_ptrINS2_8InstanceEEES6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSE_T0_T1_ENSC_9list_av_2IT2_T3_E4typeEEESI_SK_SL_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,boost::shared_ptr<RBX::Instance>),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > >_0 *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,boost::shared_ptr<RBX::Instance>,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,boost::shared_ptr<RBX::Instance>),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > >_0 *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>_0, boost::shared_ptr<RBX::Instance>),
        __int64 a2)
{
  unsigned __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(char *, char *, __int64); // rax
  boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >_0 v8; // [rsp+0h] [rbp-58h] BYREF
  __int64 v9; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v10; // [rsp+28h] [rbp-30h] BYREF

  v8.t_.functor.obj_ptr = 0;
  v3 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v8.t_.functor.obj_ptr = *(void **)a2;
    if ( (v3 & 1) != 0 )
    {
      v9 = *(_QWORD *)(a2 + 24);
      *(_OWORD *)(&v8.t_.functor.data + 8) = *(_OWORD *)(a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v8.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v10,
    v8,
    (boost::arg<1>)&v8.t_.functor);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v10.a1_.t_.vtable;
  if ( v10.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v10.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v10.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v10.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v10.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v10.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v10.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v10.a1_.t_.functor, &v10.a1_.t_.functor, 2);
      }
    }
    v10.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( v8.t_.functor.obj_ptr )
  {
    if ( (v8.t_.functor.data & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v8.t_.functor.obj_ptr
                                                          & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(v8.t_.functor.bound_memfunc_ptr.gap8, v8.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v8.t_.functor.obj_ptr = 0;
  }
  return retstr;
}


// Address: 0x1062cf0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX16KeyframeSequenceEEENS_10shared_ptrIS3_EENS_8functionIFvNS5_INS2_8InstanceEEEEEENS7_IFvNSt3__112basic_stringIcNSC_11char_traitsIcEENSC_9allocatorIcEEEEEEES4_S6_SB_SK_EENS_3_bi6bind_tIT_PFSN_T0_T1_T2_T3_ENSL_9list_av_4IT4_T5_T6_T7_E4typeEEEST_SV_SW_SX_SY_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::KeyframeSequence>,boost::shared_ptr<RBX::KeyframeSequence>,boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::KeyframeSequence>,boost::shared_ptr<RBX::KeyframeSequence>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::KeyframeSequence>,boost::shared_ptr<RBX::KeyframeSequence>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::KeyframeSequence>,boost::shared_ptr<RBX::KeyframeSequence>,boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::KeyframeSequence>, boost::shared_ptr<RBX::KeyframeSequence>, boost::function<void (boost::shared_ptr<RBX::Instance>)>_0, boost::function<void (std::string)>_0),
        boost::weak_ptr<RBX::KeyframeSequence> a1,
        boost::shared_ptr<RBX::KeyframeSequence> a2)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *px; // rax
  volatile signed __int32 *v7; // rax
  int (**v8)(void); // rax
  boost::detail::function::vtable_base *v9; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  volatile signed __int32 *v13; // rbx
  boost::detail::sp_counted_base *v14; // rdi
  boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >_0 v16; // [rsp+0h] [rbp-D8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 a2a; // [rsp+20h] [rbp-B8h] BYREF
  int (**a1a)(void); // [rsp+40h] [rbp-98h] BYREF
  volatile signed __int32 *v19; // [rsp+48h] [rbp-90h]
  boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > v20; // [rsp+50h] [rbp-88h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > v21; // [rsp+60h] [rbp-78h] BYREF

  pi = a2.pn.pi_;
  v20.t_.px = (boost::weak_ptr<RBX::KeyframeSequence>::element_type *)a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  v20.t_.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->weak_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v19 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  a2a.t_.vtable = 0;
  v8 = a2.px->_vptr$EventSource;
  if ( a2.px->_vptr$EventSource )
  {
    a2a.t_.vtable = (boost::detail::function::vtable_base *)a2.px->_vptr$EventSource;
    if ( ((unsigned __int8)v8 & 1) != 0 )
      a2a.t_.functor = *(boost::detail::function::function_buffer *)&a2.px->weak_this_.px;
    else
      (*(void (__fastcall **)(boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v8 & 0xFFFFFFFFFFFFFFFELL))(
        &a2.px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
        &a2a.t_.functor,
        0);
  }
  v16.t_.vtable = 0;
  v9 = (boost::detail::function::vtable_base *)pi->_vptr$sp_counted_base;
  if ( pi->_vptr$sp_counted_base )
  {
    v16.t_.vtable = (boost::detail::function::vtable_base *)pi->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v9 & 1) != 0 )
      v16.t_.functor = *(boost::detail::function::function_buffer *)&pi->use_count_;
    else
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v9 & 0xFFFFFFFFFFFFFFFELL))(
        &pi->use_count_,
        &v16.t_.functor,
        0);
  }
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence>>,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v21,
    (boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >)__PAIR128__(&a1a, &v20),
    (boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >)__PAIR128__(&v16, &a2a),
    v16,
    a2a);
  retstr->f_ = f;
  boost::_bi::storage3<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence>>,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>>::storage3(
    &retstr->l_,
    &v21);
  retstr->l_.a4_.t_.vtable = 0;
  vtable = v21.a4_.t_.vtable;
  if ( v21.a4_.t_.vtable )
  {
    retstr->l_.a4_.t_.vtable = v21.a4_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      retstr->l_.a4_.t_.functor = v21.a4_.t_.functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v21.a4_.t_.functor,
        &retstr->l_.a4_.t_.functor,
        0);
  }
  boost::_bi::storage4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence>>,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage4(&v21);
  if ( v16.t_.vtable )
  {
    if ( ((__int64)v16.t_.vtable & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v16.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v16.t_.functor, &v16.t_.functor, 2);
    }
    v16.t_.vtable = 0;
  }
  if ( a2a.t_.vtable )
  {
    if ( ((__int64)a2a.t_.vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)a2a.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&a2a.t_.functor, &a2a.t_.functor, 2);
    }
    a2a.t_.vtable = 0;
  }
  v13 = v19;
  if ( v19 )
  {
    if ( !_InterlockedSub(v19 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  v14 = v20.t_.pn.pi_;
  if ( v20.t_.pn.pi_ && !_InterlockedSub(&v20.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
  return retstr;
}


// Address: 0x10af3e0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX8HumanoidEEENS1_INS2_9DataModelEEENS_10shared_ptrINSt3__16vectorINS7_INS9_INS7_INS2_8InstanceEEENS8_9allocatorISB_EEEEEENSC_ISF_EEEEEENS7_INS9_INS7_INS2_24HumanoidAssetRequirementEEENSC_ISK_EEEEEENS7_INS2_19HumanoidDescriptionEEENS_8functionIFvvEEENSQ_IFvNS8_12basic_stringIcNS8_11char_traitsIcEENSC_IcEEEEEEES4_S6_NS_3argILi1EEESN_SP_SS_SZ_EENS_3_bi6bind_tIT_PFS14_T0_T1_T2_T3_T4_T5_T6_ENS12_9list_av_7IT7_T8_T9_T10_T11_T12_T13_E4typeEEES1D_S1F_S1G_S1H_S1I_S1J_S1K_S1L_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Humanoid>,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> >,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> >,boost::shared_ptr<RBX::HumanoidDescription>,boost::function<void ()>,boost::function<void (std::string)>),boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::Humanoid> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> > >,boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription> >,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::Humanoid>,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>>>,boost::shared_ptr<RBX::HumanoidDescription>,boost::function<void ()(void)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::Humanoid>,boost::weak_ptr<RBX::DataModel>,boost::arg<1>,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>>>,boost::shared_ptr<RBX::HumanoidDescription>,boost::function<void ()(void)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Humanoid>,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> >,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> >,boost::shared_ptr<RBX::HumanoidDescription>,boost::function<void ()>,boost::function<void (std::string)>),boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::Humanoid> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> > >,boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription> >,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::Humanoid>, boost::weak_ptr<RBX::DataModel>, boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> >, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> >, boost::shared_ptr<RBX::HumanoidDescription>, boost::function<void ()>_0, boost::function<void (std::string)>_0),
        boost::weak_ptr<RBX::Humanoid> a1,
        boost::weak_ptr<RBX::DataModel> a2,
        __int64 a3,
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> > a4)
{
  boost::detail::sp_counted_base *v7; // rax
  __int64 v8; // rax
  volatile signed __int32 *v9; // rax
  __int64 v10; // rax
  unsigned __int64 v11; // rax
  __int64 v12; // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v14)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v15)(boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription> > *, boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription> > *, __int64); // rax
  void (__fastcall *v16)(char *, char *, __int64); // rax
  volatile signed __int32 *v17; // rbx
  volatile signed __int32 *v18; // rbx
  __int64 v19; // rdi
  boost::detail::sp_counted_base *pi; // rdi
  boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> > > v22; // [rsp+0h] [rbp-118h] BYREF
  boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription> > v23; // [rsp+10h] [rbp-108h] BYREF
  boost::_bi::value<boost::function<void ()> >_0 v24; // [rsp+20h] [rbp-F8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 v25; // [rsp+40h] [rbp-D8h] BYREF
  volatile signed __int32 *v26; // [rsp+60h] [rbp-B8h]
  int (**a1a)(void); // [rsp+68h] [rbp-B0h] BYREF
  __int64 v28; // [rsp+70h] [rbp-A8h]
  boost::_bi::value<boost::weak_ptr<RBX::Humanoid> > v29; // [rsp+78h] [rbp-A0h] BYREF
  boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::Humanoid> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> > >,boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription> >,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > v30; // [rsp+88h] [rbp-90h] BYREF

  v29.t_.px = *(boost::weak_ptr<RBX::Humanoid>::element_type **)a1.px;
  v7 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v29.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->weak_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v8 = *(_QWORD *)&a1.pn.pi_->use_count_;
  v28 = v8;
  if ( v8 )
    _InterlockedAdd((volatile signed __int32 *)(v8 + 12), 1u);
  v25.t_.functor.bound_memfunc_ptr.obj_ptr = *(void **)a2.px;
  v9 = (volatile signed __int32 *)*((_QWORD *)a2.px + 1);
  v26 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  v25.t_.functor.obj_ptr = a2.pn.pi_->_vptr$sp_counted_base;
  v10 = *(_QWORD *)&a2.pn.pi_->use_count_;
  *((_QWORD *)&v25.t_.functor.data + 1) = v10;
  if ( v10 )
    _InterlockedAdd((volatile signed __int32 *)(v10 + 8), 1u);
  v24.t_.functor.obj_ptr = 0;
  v11 = *(_QWORD *)a3;
  if ( *(_QWORD *)a3 )
  {
    v24.t_.functor.obj_ptr = *(void **)a3;
    if ( (v11 & 1) != 0 )
    {
      v25.t_.vtable = *(boost::detail::function::vtable_base **)(a3 + 24);
      *(_OWORD *)(&v24.t_.functor.data + 8) = *(_OWORD *)(a3 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(
        a3 + 8,
        &v24.t_.functor.type.const_qualified,
        0);
    }
  }
  v22.t_.pn.pi_ = 0;
  v12 = *(_QWORD *)a4.px;
  if ( *(_QWORD *)a4.px )
  {
    v22.t_.pn.pi_ = *(boost::detail::sp_counted_base **)a4.px;
    if ( (v12 & 1) != 0 )
    {
      v24.t_.vtable = (boost::detail::function::vtable_base *)*((_QWORD *)a4.px + 3);
      v23 = *(boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription> > *)((char *)a4.px + 8);
    }
    else
    {
      (*(void (__fastcall **)(char *, boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription> > *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(
        (char *)a4.px + 8,
        &v23,
        0);
    }
  }
  v22.t_.px = &v22.t_.pn;
  boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::Humanoid>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>>>>,boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription>>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list7(
    &v30,
    (boost::_bi::value<boost::weak_ptr<RBX::Humanoid> >)__PAIR128__(&a1a, &v29),
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(
                                                           (boost::_bi::value<boost::function<void (std::string)> >_0 *)&v25.t_.functor,
                                                           (boost::_bi::value<boost::function<void (std::string)> >_0 *)(&v25.t_.functor.data + 16)),
    (boost::arg<1>)&v24.t_.functor,
    v22,
    v23,
    v24,
    v25);
  retstr->f_ = f;
  boost::_bi::storage7<boost::_bi::value<boost::weak_ptr<RBX::Humanoid>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>>>>,boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription>>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage7(
    &retstr->l_,
    &v30);
  if ( v30.a7_.t_.vtable )
  {
    if ( ((__int64)v30.a7_.t_.vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v30.a7_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v30.a7_.t_.functor, &v30.a7_.t_.functor, 2);
    }
    v30.a7_.t_.vtable = 0;
  }
  if ( v30.a6_.t_.vtable )
  {
    if ( ((__int64)v30.a6_.t_.vtable & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v30.a6_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v30.a6_.t_.functor, &v30.a6_.t_.functor, 2);
    }
    v30.a6_.t_.vtable = 0;
  }
  boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::Humanoid>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>>>>,boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription>>>::~storage5(&v30);
  if ( v22.t_.pn.pi_ )
  {
    if ( ((__int64)v22.t_.pn.pi_ & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription> > *, boost::_bi::value<boost::shared_ptr<RBX::HumanoidDescription> > *, __int64))((unsigned __int64)v22.t_.pn.pi_ & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v23, &v23, 2);
    }
    v22.t_.pn.pi_ = 0;
  }
  if ( v24.t_.functor.obj_ptr )
  {
    if ( (v24.t_.functor.data & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v24.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(v24.t_.functor.bound_memfunc_ptr.gap8, v24.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v24.t_.functor.obj_ptr = 0;
  }
  v17 = (volatile signed __int32 *)*((_QWORD *)&v25.t_.functor.data + 1);
  if ( *((_QWORD *)&v25.t_.functor.data + 1) )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v25.t_.functor.data + 1) + 8LL), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 16LL))(v17);
      if ( !_InterlockedSub(v17 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
    }
  }
  v18 = v26;
  if ( v26 )
  {
    if ( !_InterlockedSub(v26 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 16LL))(v18);
      if ( !_InterlockedSub(v18 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 24LL))(v18);
    }
  }
  v19 = v28;
  if ( v28 && !_InterlockedSub((volatile signed __int32 *)(v28 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v19 + 24LL))(v19);
  pi = v29.t_.pn.pi_;
  if ( v29.t_.pn.pi_ && !_InterlockedSub(&v29.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  return retstr;
}


// Address: 0x10b8100 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEEbS6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSB_T0_T1_ENS9_9list_av_2IT2_T3_E4typeEEESF_SH_SI_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,bool),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,bool,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,bool),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>_0, bool),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x10d5170 | Name: _ZN5boost4bindIvRKNS_8weak_ptrIN3RBX13ModelInstanceEEENS1_INS2_8InstanceEEElRKNSt3__18functionIFvNS_10shared_ptrIS7_EEEEES4_NS_3argILi1EEElSE_EENS_3_bi6bind_tIT_PFSL_T0_T1_T2_T3_ENSJ_9list_av_4IT4_T5_T6_T7_E4typeEEESR_ST_SU_SV_SW_
boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::ModelInstance> &,boost::weak_ptr<RBX::Instance>,long,const std::function<void (boost::shared_ptr<RBX::Instance>)> &),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::ModelInstance> const&,boost::weak_ptr<RBX::Instance>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)> const&,boost::weak_ptr<RBX::ModelInstance>,boost::arg<1>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)>>(
        boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::ModelInstance> &,boost::weak_ptr<RBX::Instance>,long,const std::function<void (boost::shared_ptr<RBX::Instance>)> &),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > > > *__return_ptr retstr,
        void (*f)(const boost::weak_ptr<RBX::ModelInstance> *, boost::weak_ptr<RBX::Instance>, __int64, const std::function<void (boost::shared_ptr<RBX::Instance>)> *),
        boost::weak_ptr<RBX::ModelInstance> a1,
        boost::_bi::value<long> a2,
        __int64 a3)
{
  boost::detail::sp_counted_base *pi; // r12
  __int64 v7; // rax
  __int64 v8; // rdi
  boost::detail::sp_counted_base *v9; // rax
  std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *v10; // rdi
  boost::detail::sp_counted_base *v11; // rdi
  __int64 v12; // rdi
  boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > v14; // [rsp+0h] [rbp-B8h] BYREF
  boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > *v15; // [rsp+30h] [rbp-88h]
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > > v16; // [rsp+40h] [rbp-78h] BYREF
  unsigned __int64 v17; // [rsp+90h] [rbp-28h]

  pi = a1.pn.pi_;
  v17 = __readfsqword(0x28u);
  *(_QWORD *)v14.t_.__buf_.__lx = *(_QWORD *)a1.px;
  v7 = *((_QWORD *)a1.px + 1);
  *(_QWORD *)&v14.t_.__buf_.__lx[8] = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  v8 = *(_QWORD *)(a2.t_ + 32);
  if ( v8 )
  {
    if ( a2.t_ == v8 )
    {
      v15 = (boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > *)&v14.t_.__buf_.__lx[16];
      (*(void (__fastcall **)(__int64, unsigned __int8 *, boost::weak_ptr<RBX::ModelInstance>::element_type *, boost::detail::sp_counted_base *, boost::_bi::value<long>, __int64, _QWORD, _QWORD))(*(_QWORD *)v8 + 24LL))(
        v8,
        &v14.t_.__buf_.__lx[16],
        a1.px,
        a1.pn.pi_,
        a2,
        a3,
        *(_QWORD *)v14.t_.__buf_.__lx,
        *(_QWORD *)&v14.t_.__buf_.__lx[8]);
    }
    else
    {
      v15 = (boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > *)(*(__int64 (__fastcall **)(__int64, void (*)(const boost::weak_ptr<RBX::ModelInstance> *, boost::weak_ptr<RBX::Instance>, __int64, const std::function<void (boost::shared_ptr<RBX::Instance>)> *), boost::weak_ptr<RBX::ModelInstance>::element_type *, boost::detail::sp_counted_base *, boost::_bi::value<long>, __int64, _QWORD, _QWORD))(*(_QWORD *)v8 + 16LL))(
                                                                                            v8,
                                                                                            f,
                                                                                            a1.px,
                                                                                            a1.pn.pi_,
                                                                                            a2,
                                                                                            a3,
                                                                                            *(_QWORD *)v14.t_.__buf_.__lx,
                                                                                            *(_QWORD *)&v14.t_.__buf_.__lx[8]);
    }
  }
  else
  {
    v15 = 0;
  }
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance>>,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void ()(boost::shared_ptr<RBX::Instance>)>>>::list4(
    &v16,
    (boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >)__PAIR128__((unsigned __int64)pi, &v14),
    (boost::arg<1>)&v14.t_.__buf_.__lx[16],
    a2,
    v14);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v16.a1_.t_.px;
  v9 = v16.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v16.a1_.t_.pn.pi_;
  if ( v9 )
    _InterlockedAdd(&v9->weak_count_, 1u);
  retstr->l_.a3_.t_ = v16.a3_.t_;
  v10 = v16.a4_.t_.__f_;
  if ( v16.a4_.t_.__f_ )
  {
    if ( &v16.a4_ == (boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > *)v16.a4_.t_.__f_ )
    {
      retstr->l_.a4_.t_.__f_ = (std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *)&retstr->l_.a4_;
      (*((void (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *))v10->_vptr$__base + 3))(v10);
    }
    else
    {
      retstr->l_.a4_.t_.__f_ = (std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *)(*((__int64 (**)(void))v16.a4_.t_.__f_->_vptr$__base
                                                                                                  + 2))();
    }
  }
  else
  {
    retstr->l_.a4_.t_.__f_ = 0;
  }
  if ( &v16.a4_ == (boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > *)v16.a4_.t_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *))v16.a4_.t_.__f_->_vptr$__base
     + 4))(v16.a4_.t_.__f_);
  }
  else if ( v16.a4_.t_.__f_ )
  {
    (*((void (**)(void))v16.a4_.t_.__f_->_vptr$__base + 5))();
  }
  v11 = v16.a1_.t_.pn.pi_;
  if ( v16.a1_.t_.pn.pi_ && !_InterlockedSub(&v16.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
  if ( &v14.t_.__buf_.__lx[16] == (unsigned __int8 *)v15 )
  {
    (*(void (__fastcall **)(boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > *))(*(_QWORD *)v15->t_.__buf_.__lx + 32LL))(v15);
  }
  else if ( v15 )
  {
    (*(void (**)(void))(*(_QWORD *)v15->t_.__buf_.__lx + 40LL))();
  }
  v12 = *(_QWORD *)&v14.t_.__buf_.__lx[8];
  if ( *(_QWORD *)&v14.t_.__buf_.__lx[8]
    && !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v14.t_.__buf_.__lx[8] + 12LL), 1u) )
  {
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v12 + 24LL))(v12);
  }
  return retstr;
}


// Address: 0x1122990 | Name: _ZN5boost4bindIN3RBX10Reflection7VariantENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEiP9lua_StateSA_iNS_3argILi1EEEEENS_3_bi6bind_tIT_PFSH_T0_T1_T2_ENSF_9list_av_3IT3_T4_T5_E4typeEEESM_SO_SP_SQ_
__int64 __fastcall boost::bind<RBX::Reflection::Variant,std::string,int,lua_State *,std::string,int,boost::arg<1>>(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        int a4)
{
  int v5; // ecx
  int v6; // r8d
  int v7; // r9d
  _BYTE v9[16]; // [rsp+8h] [rbp-70h] BYREF
  void *ptr; // [rsp+18h] [rbp-60h]
  _BYTE v11[16]; // [rsp+20h] [rbp-58h] BYREF
  void *v12; // [rsp+30h] [rbp-48h]
  int v13; // [rsp+38h] [rbp-40h]
  _BYTE v14[16]; // [rsp+40h] [rbp-38h] BYREF
  void *v15; // [rsp+50h] [rbp-28h]

  std::string::basic_string(v14, a3);
  std::string::basic_string(v9, v14);
  boost::_bi::storage3<boost::_bi::value<std::string>,boost::_bi::value<int>,boost::arg<1>>::storage3(
    (unsigned int)v11,
    (unsigned int)v9,
    a4,
    v5,
    v6,
    v7);
  if ( (v9[0] & 1) != 0 )
    operator delete(ptr);
  *(_QWORD *)a1 = a2;
  std::string::basic_string(a1 + 8, v11);
  *(_DWORD *)(a1 + 32) = v13;
  if ( (v11[0] & 1) != 0 )
    operator delete(v12);
  if ( (v14[0] & 1) != 0 )
    operator delete(v15);
  return a1;
}


// Address: 0x1123dc0 | Name: _ZN5boost4bindIbNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERKN3RBX10Reflection7VariantEiP9lua_StateS7_NS_17reference_wrapperISB_EEiNS_3argILi1EEEEENS_3_bi6bind_tIT_PFSL_T0_T1_T2_T3_ENSJ_9list_av_4IT4_T5_T6_T7_E4typeEEESR_ST_SU_SV_SW_
__int64 __fastcall boost::bind<bool,std::string,RBX::Reflection::Variant const&,int,lua_State *,std::string,boost::reference_wrapper<RBX::Reflection::Variant const>,int,boost::arg<1>>(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        int a4,
        int a5)
{
  int v7; // r8d
  int v8; // r9d
  char v10[8]; // [rsp+0h] [rbp-68h] BYREF
  int v11; // [rsp+8h] [rbp-60h]
  void *v12; // [rsp+10h] [rbp-58h]
  char v13[8]; // [rsp+18h] [rbp-50h] BYREF
  int v14; // [rsp+20h] [rbp-48h]
  void *ptr; // [rsp+28h] [rbp-40h]
  __int64 v16; // [rsp+30h] [rbp-38h]
  int v17; // [rsp+38h] [rbp-30h]

  std::string::basic_string(v10, a3);
  boost::_bi::list4<boost::_bi::value<std::string>,boost::reference_wrapper<RBX::Reflection::Variant const>,boost::_bi::value<int>,boost::arg<1>>::list4(
    (unsigned int)v13,
    (unsigned int)v10,
    a4,
    a5,
    v7,
    v8,
    v10[0],
    v11,
    v12,
    v13[0],
    v14,
    ptr);
  *(_QWORD *)a1 = a2;
  std::string::basic_string(a1 + 8, v13);
  *(_QWORD *)(a1 + 32) = v16;
  *(_DWORD *)(a1 + 40) = v17;
  if ( (v13[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v10[0] & 1) != 0 )
    operator delete(v12);
  return a1;
}


// Address: 0x1123f80 | Name: _ZN5boost4bindIbNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERKN3RBX10Reflection7VariantEP9lua_StateS7_NS_17reference_wrapperISB_EENS_3argILi1EEEEENS_3_bi6bind_tIT_PFSL_T0_T1_T2_ENSJ_9list_av_3IT3_T4_T5_E4typeEEESQ_SS_ST_SU_
_QWORD *__fastcall boost::bind<bool,std::string,RBX::Reflection::Variant const&,lua_State *,std::string,boost::reference_wrapper<RBX::Reflection::Variant const>,boost::arg<1>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        int a4)
{
  int v5; // ecx
  int v6; // r8d
  int v7; // r9d
  _BYTE v9[16]; // [rsp+8h] [rbp-70h] BYREF
  void *ptr; // [rsp+18h] [rbp-60h]
  _BYTE v11[16]; // [rsp+20h] [rbp-58h] BYREF
  void *v12; // [rsp+30h] [rbp-48h]
  __int64 v13; // [rsp+38h] [rbp-40h]
  _BYTE v14[16]; // [rsp+40h] [rbp-38h] BYREF
  void *v15; // [rsp+50h] [rbp-28h]

  std::string::basic_string(v14, a3);
  std::string::basic_string(v9, v14);
  boost::_bi::storage3<boost::_bi::value<std::string>,boost::reference_wrapper<RBX::Reflection::Variant const>,boost::arg<1>>::storage3(
    (unsigned int)v11,
    (unsigned int)v9,
    a4,
    v5,
    v6,
    v7);
  if ( (v9[0] & 1) != 0 )
    operator delete(ptr);
  *a1 = a2;
  std::string::basic_string(a1 + 1, v11);
  a1[4] = v13;
  if ( (v11[0] & 1) != 0 )
    operator delete(v12);
  if ( (v14[0] & 1) != 0 )
    operator delete(v15);
  return a1;
}


// Address: 0x1199ab0 | Name: _ZN5boost4bindIvNS_13intrusive_ptrIN3RBX3Lua13WeakThreadRefEEENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEES5_SC_EENS_3_bi6bind_tIT_PFSF_T0_T1_ENSD_9list_av_2IT2_T3_E4typeEEESJ_SL_SM_
_QWORD *__fastcall boost::bind<void,boost::intrusive_ptr<RBX::Lua::WeakThreadRef>,std::string,boost::intrusive_ptr<RBX::Lua::WeakThreadRef>,std::string>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4)
{
  __int64 v5; // rax
  int v6; // ecx
  int v7; // r8d
  int v8; // r9d
  __int64 v9; // rax
  __int64 v10; // rdi
  __int64 v11; // rdi
  __int64 v13; // [rsp+8h] [rbp-50h] BYREF
  __int64 v14; // [rsp+10h] [rbp-48h] BYREF
  _BYTE v15[16]; // [rsp+18h] [rbp-40h] BYREF
  void *ptr; // [rsp+28h] [rbp-30h]
  _BYTE v17[16]; // [rsp+30h] [rbp-28h] BYREF
  void *v18; // [rsp+40h] [rbp-18h]

  v5 = *a3;
  v13 = v5;
  if ( v5 )
    _InterlockedAdd((volatile signed __int32 *)(v5 + 8), 1u);
  std::string::basic_string(v17, a4);
  boost::_bi::list2<boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef>>,boost::_bi::value<std::string>>::list2(
    (unsigned int)&v14,
    (unsigned int)&v13,
    (unsigned int)v17,
    v6,
    v7,
    v8);
  *a1 = a2;
  v9 = v14;
  a1[1] = v14;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 8), 1u);
  std::string::basic_string(a1 + 2, v15);
  if ( (v15[0] & 1) != 0 )
    operator delete(ptr);
  v10 = v14;
  if ( v14 && !_InterlockedSub((volatile signed __int32 *)(v14 + 8), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v10 + 16LL))(v10);
  if ( (v17[0] & 1) != 0 )
    operator delete(v18);
  v11 = v13;
  if ( v13 && !_InterlockedSub((volatile signed __int32 *)(v13 + 8), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 16LL))(v11);
  return a1;
}


// Address: 0x119aea0 | Name: _ZN5boost4bindIvN3RBX3Lua15WeakFunctionRefENS_10shared_ptrIKNS1_10Reflection5TupleEEENS_8functionIFvS8_EEENS9_IFvNSt3__112basic_stringIcNSC_11char_traitsIcEENSC_9allocatorIcEEEEEEENS_13intrusive_ptrINS2_13WeakThreadRefEEES3_NS_3argILi1EEENSO_ILi2EEENSO_ILi3EEESN_EENS_3_bi6bind_tIT_PFSU_T0_T1_T2_T3_T4_ENSS_9list_av_5IT5_T6_T7_T8_T9_E4typeEEES11_S13_S14_S15_S16_S17_
boost::_bi::bind_t<void,void (*)(RBX::Lua::WeakFunctionRef,boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>,boost::intrusive_ptr<RBX::Lua::WeakThreadRef>),boost::_bi::list5<boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef> > > > *__fastcall boost::bind<void,RBX::Lua::WeakFunctionRef,boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>,boost::intrusive_ptr<RBX::Lua::WeakThreadRef>,RBX::Lua::WeakFunctionRef,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::intrusive_ptr<RBX::Lua::WeakThreadRef>>(
        boost::_bi::bind_t<void,void (*)(RBX::Lua::WeakFunctionRef,boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>,boost::intrusive_ptr<RBX::Lua::WeakThreadRef>),boost::_bi::list5<boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef> > > > *__return_ptr retstr,
        void (*f)(RBX::Lua::WeakFunctionRef, boost::shared_ptr<const RBX::Reflection::Tuple>, boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>, boost::function<void (std::string)>, boost::intrusive_ptr<RBX::Lua::WeakThreadRef>),
        const RBX::Lua::WeakFunctionRef *a2,
        __int64 *a3,
        boost::arg<3> a4,
        boost::intrusive_ptr<RBX::Lua::WeakThreadRef> a5)
{
  boost::arg<3> v8; // cl
  boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef> > v9; // r8
  __int64 v10; // rax
  RBX::Lua::WeakThreadRef *v11; // rax
  RBX::Lua::WeakThreadRef *v12; // rdi
  int (**v13)(void); // rdi
  boost::_bi::value<RBX::Lua::WeakFunctionRef> v15; // [rsp+0h] [rbp-98h] BYREF
  RBX::Lua::WeakThreadRef *v16; // [rsp+40h] [rbp-58h]
  RBX::Lua::WeakFunctionRef v17; // [rsp+48h] [rbp-50h] BYREF

  RBX::Lua::WeakFunctionRef::WeakFunctionRef(&v17, a2);
  v10 = *a3;
  v15.t_._vptr$WeakThreadRef = (int (**)(void))v10;
  if ( v10 )
    _InterlockedAdd((volatile signed __int32 *)(v10 + 8), 1u);
  boost::_bi::list5<boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef>>>::list5(
    (boost::_bi::list5<boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef> > > *)&v15.t_.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>,
    v15,
    (boost::arg<1>)&v17,
    (boost::arg<2>)&v15,
    v8,
    v9);
  retstr->f_ = f;
  RBX::Lua::WeakFunctionRef::WeakFunctionRef(
    &retstr->l_.a1_.t_,
    (const RBX::Lua::WeakFunctionRef *)&v15.t_.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>);
  v11 = v16;
  retstr->l_.a5_.t_.px = v16;
  if ( v11 )
  {
    _InterlockedAdd(&v11->refs.v, 1u);
    v12 = v16;
    if ( v16 )
    {
      if ( !_InterlockedSub(&v16->refs.v, 1u) )
        (*((void (__fastcall **)(RBX::Lua::WeakThreadRef *))v12->_vptr$WeakThreadRef + 2))(v12);
    }
  }
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef((RBX::Lua::WeakFunctionRef *)&v15.t_.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>);
  v13 = v15.t_._vptr$WeakThreadRef;
  if ( v15.t_._vptr$WeakThreadRef && !_InterlockedSub((volatile signed __int32 *)v15.t_._vptr$WeakThreadRef + 2, 1u) )
    (*((void (__fastcall **)(int (**)(void)))*v13 + 2))(v13);
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef(&v17);
  return retstr;
}


// Address: 0x119b080 | Name: _ZN5boost4bindINS_10shared_ptrIN3RBX10Reflection5TupleEEENS2_3Lua15WeakFunctionRefENS1_IKS4_EENS_13intrusive_ptrINS6_13WeakThreadRefEEENS2_19StudioGameStateTypeES7_NS_3argILi1EEESC_SD_EENS_3_bi6bind_tIT_PFSI_T0_T1_T2_T3_ENSG_9list_av_4IT4_T5_T6_T7_E4typeEEESO_SQ_SR_SS_ST_
boost::_bi::bind_t<boost::shared_ptr<RBX::Reflection::Tuple>,boost::shared_ptr<RBX::Reflection::Tuple> (*)(RBX::Lua::WeakFunctionRef,boost::shared_ptr<const RBX::Reflection::Tuple>,boost::intrusive_ptr<RBX::Lua::WeakThreadRef>,RBX::StudioGameStateType),boost::_bi::list4<boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1>,boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef> >,boost::_bi::value<RBX::StudioGameStateType> > > *__fastcall boost::bind<boost::shared_ptr<RBX::Reflection::Tuple>,RBX::Lua::WeakFunctionRef,boost::shared_ptr<RBX::Reflection::Tuple const>,boost::intrusive_ptr<RBX::Lua::WeakThreadRef>,RBX::StudioGameStateType,RBX::Lua::WeakFunctionRef,boost::arg<1>,boost::intrusive_ptr<RBX::Lua::WeakThreadRef>,RBX::StudioGameStateType>(
        boost::_bi::bind_t<boost::shared_ptr<RBX::Reflection::Tuple>,boost::shared_ptr<RBX::Reflection::Tuple> (*)(RBX::Lua::WeakFunctionRef,boost::shared_ptr<const RBX::Reflection::Tuple>,boost::intrusive_ptr<RBX::Lua::WeakThreadRef>,RBX::StudioGameStateType),boost::_bi::list4<boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1>,boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef> >,boost::_bi::value<RBX::StudioGameStateType> > > *__return_ptr retstr,
        boost::shared_ptr<RBX::Reflection::Tuple> (*f)(RBX::Lua::WeakFunctionRef, boost::shared_ptr<const RBX::Reflection::Tuple>, boost::intrusive_ptr<RBX::Lua::WeakThreadRef>, RBX::StudioGameStateType),
        const RBX::Lua::WeakFunctionRef *a2,
        boost::intrusive_ptr<RBX::Lua::WeakThreadRef> a3,
        boost::_bi::value<RBX::StudioGameStateType> a4)
{
  int (**v8)(void); // rax
  RBX::Lua::WeakThreadRef *v9; // rax
  volatile signed __int32 *v10; // rdi
  int (**v11)(void); // rdi
  boost::_bi::value<RBX::Lua::WeakFunctionRef> v13; // [rsp+0h] [rbp-A8h] BYREF
  RBX::Lua::WeakThreadRef *v14; // [rsp+40h] [rbp-68h]
  RBX::StudioGameStateType v15; // [rsp+48h] [rbp-60h]
  RBX::Lua::WeakFunctionRef v16; // [rsp+50h] [rbp-58h] BYREF

  RBX::Lua::WeakFunctionRef::WeakFunctionRef(&v16, a2);
  v8 = a3.px->_vptr$WeakThreadRef;
  v13.t_._vptr$WeakThreadRef = v8;
  if ( v8 )
    _InterlockedAdd((volatile signed __int32 *)v8 + 2, 1u);
  boost::_bi::list4<boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1>,boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef>>,boost::_bi::value<RBX::StudioGameStateType>>::list4(
    (boost::_bi::list4<boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1>,boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef> >,boost::_bi::value<RBX::StudioGameStateType> > *)&v13.t_.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>,
    v13,
    (boost::arg<1>)&v16,
    (boost::_bi::value<boost::intrusive_ptr<RBX::Lua::WeakThreadRef> >)&v13,
    a4);
  retstr->f_ = f;
  RBX::Lua::WeakFunctionRef::WeakFunctionRef(
    &retstr->l_.a1_.t_,
    (const RBX::Lua::WeakFunctionRef *)&v13.t_.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>);
  v9 = v14;
  retstr->l_.a3_.t_.px = v14;
  if ( v9 )
  {
    _InterlockedAdd(&v9->refs.v, 1u);
    v10 = (volatile signed __int32 *)v14;
    retstr->l_.a4_.t_ = v15;
    if ( v10 && !_InterlockedSub(v10 + 2, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
  }
  else
  {
    retstr->l_.a4_.t_ = v15;
  }
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef((RBX::Lua::WeakFunctionRef *)&v13.t_.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>);
  v11 = v13.t_._vptr$WeakThreadRef;
  if ( v13.t_._vptr$WeakThreadRef && !_InterlockedSub((volatile signed __int32 *)v13.t_._vptr$WeakThreadRef + 2, 1u) )
    (*((void (__fastcall **)(int (**)(void)))*v11 + 2))(v11);
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef(&v16);
  return retstr;
}


// Address: 0x11a09e0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX10Reflection19TGenericSlotWrapperINS2_3Lua18FunctionScriptSlotEEEEERKNSt3__16vectorINS3_7VariantENS9_9allocatorISB_EEEES8_SE_EENS_3_bi6bind_tIT_PFSJ_T0_T1_ENSH_9list_av_2IT2_T3_E4typeEEESN_SP_SQ_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::Reflection::TGenericSlotWrapper<RBX::Lua::FunctionScriptSlot>>,std::vector<RBX::Reflection::Variant> const&,boost::weak_ptr<RBX::Reflection::TGenericSlotWrapper<RBX::Lua::FunctionScriptSlot>>,std::vector<RBX::Reflection::Variant>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        const std::vector<RBX::Reflection::Variant> *a4)
{
  __int64 v5; // rax
  __int64 v6; // rax
  char *v7; // r14
  char *v8; // rbx
  __int64 v9; // rax
  void *v10; // rdi
  __int64 v11; // rdi
  char *v12; // r14
  char *v13; // rbx
  __int64 v14; // rax
  void *v15; // rdi
  __int64 v16; // rdi
  void *v18; // [rsp+0h] [rbp-68h] BYREF
  char *v19; // [rsp+8h] [rbp-60h]
  __int64 v20; // [rsp+18h] [rbp-50h] BYREF
  __int64 v21; // [rsp+20h] [rbp-48h]
  void *ptr; // [rsp+28h] [rbp-40h] BYREF
  char *v23; // [rsp+30h] [rbp-38h]
  __int64 v24; // [rsp+40h] [rbp-28h] BYREF
  __int64 v25; // [rsp+48h] [rbp-20h]

  v24 = *a3;
  v5 = a3[1];
  v25 = v5;
  if ( v5 )
    _InterlockedAdd((volatile signed __int32 *)(v5 + 12), 1u);
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)&v18, a4);
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::Reflection::TGenericSlotWrapper<RBX::Lua::FunctionScriptSlot>>>,boost::_bi::value<std::vector<RBX::Reflection::Variant>>>::list2(
    &v20,
    &v24,
    &v18);
  *a1 = a2;
  a1[1] = v20;
  v6 = v21;
  a1[2] = v21;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)(v6 + 12), 1u);
  std::vector<RBX::Reflection::Variant>::vector(
    (std::vector<RBX::Reflection::Variant> *)(a1 + 3),
    (const std::vector<RBX::Reflection::Variant> *)&ptr);
  v7 = (char *)ptr;
  if ( ptr )
  {
    v8 = v23;
    if ( v23 == ptr )
    {
      v10 = ptr;
    }
    else
    {
      do
      {
        v9 = *((_QWORD *)v8 - 13);
        if ( v9 )
          (*(void (__fastcall **)(char *))(v9 + 16))(v8 - 96);
        v8 -= 112;
      }
      while ( v7 != v8 );
      v10 = ptr;
    }
    v23 = v7;
    operator delete(v10);
  }
  v11 = v21;
  if ( v21 && !_InterlockedSub((volatile signed __int32 *)(v21 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 24LL))(v11);
  v12 = (char *)v18;
  if ( v18 )
  {
    v13 = v19;
    if ( v19 == v18 )
    {
      v15 = v18;
    }
    else
    {
      do
      {
        v14 = *((_QWORD *)v13 - 13);
        if ( v14 )
          (*(void (__fastcall **)(char *))(v14 + 16))(v13 - 96);
        v13 -= 112;
      }
      while ( v12 != v13 );
      v15 = v18;
    }
    v19 = v12;
    operator delete(v15);
  }
  v16 = v25;
  if ( v25 && !_InterlockedSub((volatile signed __int32 *)(v25 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v16 + 24LL))(v16);
  return a1;
}


// Address: 0x11a2370 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX10Reflection19TGenericSlotWrapperINS2_3Lua14WaitScriptSlotEEEEERKNSt3__16vectorINS3_7VariantENS9_9allocatorISB_EEEES8_SE_EENS_3_bi6bind_tIT_PFSJ_T0_T1_ENSH_9list_av_2IT2_T3_E4typeEEESN_SP_SQ_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::Reflection::TGenericSlotWrapper<RBX::Lua::WaitScriptSlot>>,std::vector<RBX::Reflection::Variant> const&,boost::weak_ptr<RBX::Reflection::TGenericSlotWrapper<RBX::Lua::WaitScriptSlot>>,std::vector<RBX::Reflection::Variant>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        const std::vector<RBX::Reflection::Variant> *a4)
{
  __int64 v5; // rax
  __int64 v6; // rax
  char *v7; // r14
  char *v8; // rbx
  __int64 v9; // rax
  void *v10; // rdi
  __int64 v11; // rdi
  char *v12; // r14
  char *v13; // rbx
  __int64 v14; // rax
  void *v15; // rdi
  __int64 v16; // rdi
  void *v18; // [rsp+0h] [rbp-68h] BYREF
  char *v19; // [rsp+8h] [rbp-60h]
  __int64 v20; // [rsp+18h] [rbp-50h] BYREF
  __int64 v21; // [rsp+20h] [rbp-48h]
  void *ptr; // [rsp+28h] [rbp-40h] BYREF
  char *v23; // [rsp+30h] [rbp-38h]
  __int64 v24; // [rsp+40h] [rbp-28h] BYREF
  __int64 v25; // [rsp+48h] [rbp-20h]

  v24 = *a3;
  v5 = a3[1];
  v25 = v5;
  if ( v5 )
    _InterlockedAdd((volatile signed __int32 *)(v5 + 12), 1u);
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)&v18, a4);
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::Reflection::TGenericSlotWrapper<RBX::Lua::WaitScriptSlot>>>,boost::_bi::value<std::vector<RBX::Reflection::Variant>>>::list2(
    &v20,
    &v24,
    &v18);
  *a1 = a2;
  a1[1] = v20;
  v6 = v21;
  a1[2] = v21;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)(v6 + 12), 1u);
  std::vector<RBX::Reflection::Variant>::vector(
    (std::vector<RBX::Reflection::Variant> *)(a1 + 3),
    (const std::vector<RBX::Reflection::Variant> *)&ptr);
  v7 = (char *)ptr;
  if ( ptr )
  {
    v8 = v23;
    if ( v23 == ptr )
    {
      v10 = ptr;
    }
    else
    {
      do
      {
        v9 = *((_QWORD *)v8 - 13);
        if ( v9 )
          (*(void (__fastcall **)(char *))(v9 + 16))(v8 - 96);
        v8 -= 112;
      }
      while ( v7 != v8 );
      v10 = ptr;
    }
    v23 = v7;
    operator delete(v10);
  }
  v11 = v21;
  if ( v21 && !_InterlockedSub((volatile signed __int32 *)(v21 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 24LL))(v11);
  v12 = (char *)v18;
  if ( v18 )
  {
    v13 = v19;
    if ( v19 == v18 )
    {
      v15 = v18;
    }
    else
    {
      do
      {
        v14 = *((_QWORD *)v13 - 13);
        if ( v14 )
          (*(void (__fastcall **)(char *))(v14 + 16))(v13 - 96);
        v13 -= 112;
      }
      while ( v12 != v13 );
      v15 = v18;
    }
    v19 = v12;
    operator delete(v15);
  }
  v16 = v25;
  if ( v25 && !_InterlockedSub((volatile signed __int32 *)(v25 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v16 + 24LL))(v16);
  return a1;
}


// Address: 0x11a75c0 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX8InstanceEEENS1_INS2_15ContentProviderEEENS2_13HttpResultJobENS1_INS2_18LuaSourceContainer20LinkedScriptLoadDataEEENS_3argILi1EEES6_S7_SA_EENS_3_bi6bind_tIT_PFSF_T0_T1_T2_T3_ENSD_9list_av_4IT4_T5_T6_T7_E4typeEEESL_SN_SO_SP_SQ_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ContentProvider>,RBX::HttpResultJob,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>),boost::_bi::list4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::ContentProvider> >,boost::_bi::value<RBX::HttpResultJob>,boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> > > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ContentProvider>,RBX::HttpResultJob,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>,boost::arg<1>,boost::shared_ptr<RBX::ContentProvider>,RBX::HttpResultJob,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ContentProvider>,RBX::HttpResultJob,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>),boost::_bi::list4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::ContentProvider> >,boost::_bi::value<RBX::HttpResultJob>,boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> > > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::ContentProvider>, RBX::HttpResultJob, boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>),
        _QWORD *a1,
        boost::shared_ptr<RBX::ContentProvider> a2,
        RBX::HttpResultJob a3)
{
  volatile signed __int32 *v5; // rax
  volatile signed __int32 *v6; // rax
  boost::_bi::value<boost::shared_ptr<RBX::ContentProvider> > v7; // rdx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v9; // rax
  boost::detail::sp_counted_base *v10; // rbx
  boost::detail::sp_counted_base *v11; // rbx
  volatile signed __int32 *v12; // rbx
  volatile signed __int32 *v13; // rbx
  boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> > v15; // [rsp+0h] [rbp-68h] BYREF
  volatile signed __int32 *v16; // [rsp+10h] [rbp-58h]
  boost::arg<1> a1a[8]; // [rsp+18h] [rbp-50h] BYREF
  volatile signed __int32 *v18; // [rsp+20h] [rbp-48h]
  boost::_bi::list4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::ContentProvider> >,boost::_bi::value<RBX::HttpResultJob>,boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> > > v19; // [rsp+28h] [rbp-40h] BYREF

  *(_QWORD *)&a1a[0].gap0 = *a1;
  v5 = (volatile signed __int32 *)a1[1];
  v18 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  v15.t_.pn.pi_ = (boost::detail::sp_counted_base *)a2.pn.pi_->_vptr$sp_counted_base;
  v6 = *(volatile signed __int32 **)&a2.pn.pi_->use_count_;
  v16 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  v7.t_.px = (boost::shared_ptr<RBX::ContentProvider>::element_type *)LODWORD(a2.px);
  v7.t_.pn.pi_ = (boost::detail::sp_counted_base *)&v15.t_.pn;
  boost::_bi::list4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::ContentProvider>>,boost::_bi::value<RBX::HttpResultJob>,boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>>>::list4(
    &v19,
    (boost::arg<1>)a1a,
    v7,
    (boost::_bi::value<RBX::HttpResultJob>)a2.pn.pi_,
    v15);
  retstr->f_ = f;
  retstr->l_.a2_.t_.px = v19.a2_.t_.px;
  pi = v19.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v19.a2_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a3_.t_ = v19.a3_.t_;
  retstr->l_.a4_.t_.px = v19.a4_.t_.px;
  v9 = v19.a4_.t_.pn.pi_;
  retstr->l_.a4_.t_.pn.pi_ = v19.a4_.t_.pn.pi_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    v10 = v19.a4_.t_.pn.pi_;
    if ( v19.a4_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v19.a4_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
        if ( !_InterlockedSub(&v10->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
      }
    }
  }
  v11 = v19.a2_.t_.pn.pi_;
  if ( v19.a2_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v19.a2_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 2))(v11);
      if ( !_InterlockedSub(&v11->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
    }
  }
  v12 = v16;
  if ( v16 )
  {
    if ( !_InterlockedSub(v16 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  v13 = v18;
  if ( v18 )
  {
    if ( !_InterlockedSub(v18 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  return retstr;
}


// Address: 0x11a77b0 | Name: _ZN5boost4bindIvPN3RBX9DataModelENS_8functionIFvvEEENS_3argILi1EEES6_EENS_3_bi6bind_tIT_PFSB_T0_T1_ENS9_9list_av_2IT2_T3_E4typeEEESF_SH_SI_
boost::_bi::bind_t<void,void (*)(RBX::DataModel *,boost::function<void ()>),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void ()> > > > *__fastcall boost::bind<void,RBX::DataModel *,boost::function<void ()(void)>,boost::arg<1>,boost::function<void ()(void)>>(
        boost::_bi::bind_t<void,void (*)(RBX::DataModel *,boost::function<void ()>),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void ()> > > > *__return_ptr retstr,
        void (*f)(RBX::DataModel *, boost::function<void ()>_0),
        __int64 a1)
{
  unsigned __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(char *, char *, __int64); // rax
  boost::_bi::value<boost::function<void ()> >_0 v8; // [rsp+0h] [rbp-58h] BYREF
  __int64 v9; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void ()> > > v10; // [rsp+28h] [rbp-30h] BYREF

  v8.t_.functor.obj_ptr = 0;
  v3 = *(_QWORD *)a1;
  if ( *(_QWORD *)a1 )
  {
    v8.t_.functor.obj_ptr = *(void **)a1;
    if ( (v3 & 1) != 0 )
    {
      v9 = *(_QWORD *)(a1 + 24);
      *(_OWORD *)(&v8.t_.functor.data + 8) = *(_OWORD *)(a1 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(
        a1 + 8,
        &v8.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void ()(void)>>>::list2(
    &v10,
    (boost::arg<1>)&v8.t_.functor,
    v8);
  retstr->f_ = f;
  retstr->l_.a2_.t_.vtable = 0;
  vtable = v10.a2_.t_.vtable;
  if ( v10.a2_.t_.vtable )
  {
    retstr->l_.a2_.t_.vtable = v10.a2_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a2_.t_.functor = v10.a2_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v10.a2_.t_.functor,
        &retstr->l_.a2_.t_.functor,
        0);
      if ( !v10.a2_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v10.a2_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v10.a2_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v10.a2_.t_.functor, &v10.a2_.t_.functor, 2);
      }
    }
    v10.a2_.t_.vtable = 0;
  }
LABEL_14:
  if ( v8.t_.functor.obj_ptr )
  {
    if ( (v8.t_.functor.data & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v8.t_.functor.obj_ptr
                                                          & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(v8.t_.functor.bound_memfunc_ptr.gap8, v8.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v8.t_.functor.obj_ptr = 0;
  }
  return retstr;
}


// Address: 0x11a7c60 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX18LuaSourceContainerEEENS_10shared_ptrINS2_8InstanceEEES4_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSC_T0_T1_ENSA_9list_av_2IT2_T3_E4typeEEESG_SI_SJ_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LuaSourceContainer>,boost::shared_ptr<RBX::Instance>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::LuaSourceContainer>,boost::shared_ptr<RBX::Instance>,boost::weak_ptr<RBX::LuaSourceContainer>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LuaSourceContainer>,boost::shared_ptr<RBX::Instance>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::LuaSourceContainer>, boost::shared_ptr<RBX::Instance>),
        boost::weak_ptr<RBX::LuaSourceContainer> a1,
        __int64 a2)
{
  boost::weak_ptr<RBX::LuaSourceContainer>::element_type *v4; // r12
  boost::detail::sp_counted_base *v5; // rbx

  v4 = *(boost::weak_ptr<RBX::LuaSourceContainer>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v5 )
  {
    _InterlockedAdd(&v5->weak_count_, 1u);
    _InterlockedAdd(&v5->weak_count_, 1u);
    _InterlockedAdd(&v5->weak_count_, 1u);
    _InterlockedAdd(&v5->weak_count_, 1u);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LuaSourceContainer>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::LuaSourceContainer>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 3))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LuaSourceContainer>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::LuaSourceContainer>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 3))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->weak_count_, 1u);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LuaSourceContainer>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::LuaSourceContainer>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 3))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LuaSourceContainer>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::LuaSourceContainer>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 3))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x11a83c0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX18LuaSourceContainerEEENS2_17HttpRequestResultENS_10shared_ptrIKNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEEEES4_S5_SF_EENS_3_bi6bind_tIT_PFSI_T0_T1_T2_ENSG_9list_av_3IT3_T4_T5_E4typeEEESN_SP_SQ_SR_
// local variable allocation has failed, the output may be wrong!
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LuaSourceContainer>,RBX::HttpRequestResult,boost::shared_ptr<const std::string >),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> >,boost::_bi::value<RBX::HttpRequestResult>,boost::_bi::value<boost::shared_ptr<const std::string > > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::LuaSourceContainer>,RBX::HttpRequestResult,boost::shared_ptr<std::string const>,boost::weak_ptr<RBX::LuaSourceContainer>,RBX::HttpRequestResult,boost::shared_ptr<std::string const>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LuaSourceContainer>,RBX::HttpRequestResult,boost::shared_ptr<const std::string >),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> >,boost::_bi::value<RBX::HttpRequestResult>,boost::_bi::value<boost::shared_ptr<const std::string > > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::LuaSourceContainer>, RBX::HttpRequestResult, boost::shared_ptr<const std::string >),
        boost::weak_ptr<RBX::LuaSourceContainer> a1,
        _QWORD *a2,
        __int64 a5)
{
  boost::detail::sp_counted_base *v6; // rax
  volatile signed __int32 *v7; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v9; // rax
  boost::detail::sp_counted_base *v10; // rbx
  boost::detail::sp_counted_base *v11; // rdi
  volatile signed __int32 *v12; // rbx
  boost::detail::sp_counted_base *v13; // rdi
  boost::_bi::value<RBX::HttpRequestResult> v15[2]; // [rsp+8h] [rbp-60h] BYREF
  volatile signed __int32 *v16; // [rsp+10h] [rbp-58h]
  boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> > a1a; // [rsp+18h] [rbp-50h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> >,boost::_bi::value<RBX::HttpRequestResult>,boost::_bi::value<boost::shared_ptr<const std::string > > > v18; // [rsp+28h] [rbp-40h] BYREF

  a1a.t_.px = *(boost::weak_ptr<RBX::LuaSourceContainer>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  a1a.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->weak_count_, 1u);
  *(_QWORD *)&v15[0].t_ = *a2;
  v7 = (volatile signed __int32 *)a2[1];
  v16 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer>>,boost::_bi::value<RBX::HttpRequestResult>,boost::_bi::value<boost::shared_ptr<std::string const>>>::list3(
    &v18,
    (boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> >)__PAIR128__(LODWORD(a1.pn.pi_), &a1a),
    (boost::_bi::value<RBX::HttpRequestResult>)v15,
    *(boost::_bi::value<boost::shared_ptr<const std::string > > *)&a2);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v18.a1_.t_.px;
  pi = v18.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v18.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a2_.t_ = v18.a2_.t_;
  retstr->l_.a3_.t_.px = v18.a3_.t_.px;
  v9 = v18.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v18.a3_.t_.pn.pi_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    v10 = v18.a3_.t_.pn.pi_;
    if ( v18.a3_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v18.a3_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
        if ( !_InterlockedSub(&v10->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
      }
    }
  }
  v11 = v18.a1_.t_.pn.pi_;
  if ( v18.a1_.t_.pn.pi_ && !_InterlockedSub(&v18.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
  v12 = v16;
  if ( v16 )
  {
    if ( !_InterlockedSub(v16 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  v13 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ && !_InterlockedSub(&a1a.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
  return retstr;
}


// Address: 0x11a8740 | Name: _ZN5boost4bindIvPN3RBX9DataModelENS_10shared_ptrINS1_18LuaSourceContainer20LinkedScriptLoadDataEEENS_3argILi1EEES7_EENS_3_bi6bind_tIT_PFSC_T0_T1_ENSA_9list_av_2IT2_T3_E4typeEEESG_SI_SJ_
boost::_bi::bind_t<void,void (*)(RBX::DataModel *,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> > > > *__fastcall boost::bind<void,RBX::DataModel *,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>,boost::arg<1>,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>>(
        boost::_bi::bind_t<void,void (*)(RBX::DataModel *,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> > > > *__return_ptr retstr,
        void (*f)(RBX::DataModel *, boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>),
        __int64 a1,
        boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> a2)
{
  boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>::element_type *v4; // r12
  boost::detail::sp_counted_base *v5; // rbx

  v4 = *(boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>::element_type **)a1;
  v5 = *(boost::detail::sp_counted_base **)(a1 + 8);
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::DataModel *, boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>), __int64, boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>::element_type *, boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1,
        a2.px,
        a2.pn.pi_);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_ = f;
    retstr->l_.a2_.t_.px = v4;
    retstr->l_.a2_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::DataModel *, boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>), __int64, boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>::element_type *, boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1,
        a2.px,
        a2.pn.pi_);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::DataModel *, boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>), __int64, boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>::element_type *, boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1,
        a2.px,
        a2.pn.pi_);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a2_.t_.px = v4;
    retstr->l_.a2_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x11a88d0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX18LuaSourceContainerEEENS2_17HttpRequestResultENS_10shared_ptrIKNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEEEENS6_INS3_20LinkedScriptLoadDataEEES4_NS_3argILi1EEENSI_ILi2EEESH_EENS_3_bi6bind_tIT_PFSN_T0_T1_T2_T3_ENSL_9list_av_4IT4_T5_T6_T7_E4typeEEEST_SV_SW_SX_SY_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LuaSourceContainer>,RBX::HttpRequestResult,boost::shared_ptr<const std::string >,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::LuaSourceContainer>,RBX::HttpRequestResult,boost::shared_ptr<std::string const>,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>,boost::weak_ptr<RBX::LuaSourceContainer>,boost::arg<1>,boost::arg<2>,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LuaSourceContainer>,RBX::HttpRequestResult,boost::shared_ptr<const std::string >,boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::LuaSourceContainer>, RBX::HttpRequestResult, boost::shared_ptr<const std::string >, boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>),
        boost::weak_ptr<RBX::LuaSourceContainer> a1,
        boost::arg<1> a2,
        boost::arg<2> a3)
{
  boost::detail::sp_counted_base *v6; // rax
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v9; // rax
  boost::detail::sp_counted_base *v10; // rbx
  boost::detail::sp_counted_base *v11; // rdi
  boost::detail::sp_counted_base *v12; // rbx
  boost::detail::sp_counted_base *v13; // rdi
  boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> > v15; // [rsp+0h] [rbp-58h] BYREF
  boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> > a1a; // [rsp+10h] [rbp-48h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData> > > v17; // [rsp+20h] [rbp-38h] BYREF

  a1a.t_.px = *(boost::weak_ptr<RBX::LuaSourceContainer>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  a1a.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->weak_count_, 1u);
  v15.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v15.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::shared_ptr<RBX::LuaSourceContainer::LinkedScriptLoadData>>>::list4(
    &v17,
    (boost::_bi::value<boost::weak_ptr<RBX::LuaSourceContainer> >)__PAIR128__(&v15, &a1a),
    (boost::arg<1>)a1.pn.pi_,
    (boost::arg<2>)a2.gap0,
    v15);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v17.a1_.t_.px;
  pi = v17.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v17.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a4_.t_.px = v17.a4_.t_.px;
  v9 = v17.a4_.t_.pn.pi_;
  retstr->l_.a4_.t_.pn.pi_ = v17.a4_.t_.pn.pi_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    v10 = v17.a4_.t_.pn.pi_;
    if ( v17.a4_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v17.a4_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
        if ( !_InterlockedSub(&v10->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
      }
    }
  }
  v11 = v17.a1_.t_.pn.pi_;
  if ( v17.a1_.t_.pn.pi_ && !_InterlockedSub(&v17.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
  v12 = v15.t_.pn.pi_;
  if ( v15.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v15.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
      if ( !_InterlockedSub(&v12->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
    }
  }
  v13 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ && !_InterlockedSub(&a1a.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
  return retstr;
}


// Address: 0x11ca700 | Name: _ZN5boost4bindIvP9lua_StateNS_8functionIFvNS_10shared_ptrIKN3RBX10Reflection5TupleEEEEEENS_3argILi1EEESB_EENS_3_bi6bind_tIT_PFSG_T0_T1_ENSE_9list_av_2IT2_T3_E4typeEEESK_SM_SN_
boost::_bi::bind_t<void,void (*)(lua_State *,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> > > > *__fastcall boost::bind<void,lua_State *,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::arg<1>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>>(
        boost::_bi::bind_t<void,void (*)(lua_State *,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> > > > *__return_ptr retstr,
        void (*f)(lua_State *, boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>_0),
        __int64 a1)
{
  unsigned __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(char *, char *, __int64); // rax
  boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> >_0 v8; // [rsp+0h] [rbp-58h] BYREF
  __int64 v9; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> > > v10; // [rsp+28h] [rbp-30h] BYREF

  v8.t_.functor.obj_ptr = 0;
  v3 = *(_QWORD *)a1;
  if ( *(_QWORD *)a1 )
  {
    v8.t_.functor.obj_ptr = *(void **)a1;
    if ( (v3 & 1) != 0 )
    {
      v9 = *(_QWORD *)(a1 + 24);
      *(_OWORD *)(&v8.t_.functor.data + 8) = *(_OWORD *)(a1 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(
        a1 + 8,
        &v8.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>>>::list2(
    &v10,
    (boost::arg<1>)&v8.t_.functor,
    v8);
  retstr->f_ = f;
  retstr->l_.a2_.t_.vtable = 0;
  vtable = v10.a2_.t_.vtable;
  if ( v10.a2_.t_.vtable )
  {
    retstr->l_.a2_.t_.vtable = v10.a2_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a2_.t_.functor = v10.a2_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v10.a2_.t_.functor,
        &retstr->l_.a2_.t_.functor,
        0);
      if ( !v10.a2_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v10.a2_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v10.a2_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v10.a2_.t_.functor, &v10.a2_.t_.functor, 2);
      }
    }
    v10.a2_.t_.vtable = 0;
  }
LABEL_14:
  if ( v8.t_.functor.obj_ptr )
  {
    if ( (v8.t_.functor.data & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v8.t_.functor.obj_ptr
                                                          & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(v8.t_.functor.bound_memfunc_ptr.gap8, v8.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v8.t_.functor.obj_ptr = 0;
  }
  return retstr;
}


// Address: 0x11caa30 | Name: _ZN5boost4bindIvP9lua_StateNS_8functionIFvPKcS5_NS_10shared_ptrIN3RBX18LuaSourceContainerEEEiEEENS_3argILi1EEESB_EENS_3_bi6bind_tIT_PFSG_T0_T1_ENSE_9list_av_2IT2_T3_E4typeEEESK_SM_SN_
boost::_bi::bind_t<void,void (*)(lua_State *,boost::function<void (const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int)>),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void (const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int)> > > > *__fastcall boost::bind<void,lua_State *,boost::function<void ()(char const*,char const*,boost::shared_ptr<RBX::LuaSourceContainer>,int)>,boost::arg<1>,boost::function<void ()(char const*,char const*,boost::shared_ptr<RBX::LuaSourceContainer>,int)>>(
        boost::_bi::bind_t<void,void (*)(lua_State *,boost::function<void (const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int)>),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void (const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int)> > > > *__return_ptr retstr,
        void (*f)(lua_State *, boost::function<void (const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int)>),
        __int64 a1)
{
  unsigned __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(char *, char *, __int64); // rax
  boost::_bi::value<boost::function<void (const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int)> > v8; // [rsp+0h] [rbp-58h] BYREF
  __int64 v9; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void (const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int)> > > v10; // [rsp+28h] [rbp-30h] BYREF

  v8.t_.functor.obj_ptr = 0;
  v3 = *(_QWORD *)a1;
  if ( *(_QWORD *)a1 )
  {
    v8.t_.functor.obj_ptr = *(void **)a1;
    if ( (v3 & 1) != 0 )
    {
      v9 = *(_QWORD *)(a1 + 24);
      *(_OWORD *)(&v8.t_.functor.data + 8) = *(_OWORD *)(a1 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(
        a1 + 8,
        &v8.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::function<void ()(char const*,char const*,boost::shared_ptr<RBX::LuaSourceContainer>,int)>>>::list2(
    &v10,
    (boost::arg<1>)&v8.t_.functor,
    v8);
  retstr->f_ = f;
  retstr->l_.a2_.t_.vtable = 0;
  vtable = v10.a2_.t_.vtable;
  if ( v10.a2_.t_.vtable )
  {
    retstr->l_.a2_.t_.vtable = v10.a2_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a2_.t_.functor = v10.a2_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v10.a2_.t_.functor,
        &retstr->l_.a2_.t_.functor,
        0);
      if ( !v10.a2_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v10.a2_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v10.a2_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v10.a2_.t_.functor, &v10.a2_.t_.functor, 2);
      }
    }
    v10.a2_.t_.vtable = 0;
  }
LABEL_14:
  if ( v8.t_.functor.obj_ptr )
  {
    if ( (v8.t_.functor.data & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v8.t_.functor.obj_ptr
                                                          & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(v8.t_.functor.bound_memfunc_ptr.gap8, v8.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v8.t_.functor.obj_ptr = 0;
  }
  return retstr;
}


// Address: 0x11cb170 | Name: _ZN5boost4bindIvP9lua_StateiNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_3argILi1EEENSA_ILi2EEES9_EENS_3_bi6bind_tIT_PFSF_T0_T1_T2_ENSD_9list_av_3IT3_T4_T5_E4typeEEESK_SM_SN_SO_
_QWORD *__fastcall boost::bind<void,lua_State *,int,std::string,boost::arg<1>,boost::arg<2>,std::string>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3)
{
  _BYTE v4[16]; // [rsp+8h] [rbp-60h] BYREF
  void *v5; // [rsp+18h] [rbp-50h]
  _BYTE v6[16]; // [rsp+20h] [rbp-48h] BYREF
  void *ptr; // [rsp+30h] [rbp-38h]
  _BYTE v8[16]; // [rsp+38h] [rbp-30h] BYREF
  void *v9; // [rsp+48h] [rbp-20h]

  std::string::basic_string(v8, a3);
  std::string::basic_string(v6, v8);
  std::string::basic_string(v4, v6);
  if ( (v6[0] & 1) != 0 )
    operator delete(ptr);
  *a1 = a2;
  std::string::basic_string(a1 + 1, v4);
  if ( (v4[0] & 1) != 0 )
    operator delete(v5);
  if ( (v8[0] & 1) != 0 )
    operator delete(v9);
  return a1;
}


// Address: 0x11cb250 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX12ModuleScriptEEEP9lua_StateiS4_NS_3argILi1EEEiEENS_3_bi6bind_tIT_PFSB_T0_T1_T2_ENS9_9list_av_3IT3_T4_T5_E4typeEEESG_SI_SJ_SK_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::ModuleScript>,lua_State *,int),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> >,boost::arg<1>,boost::_bi::value<int> > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::ModuleScript>,lua_State *,int,boost::shared_ptr<RBX::ModuleScript>,boost::arg<1>,int>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::ModuleScript>,lua_State *,int),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> >,boost::arg<1>,boost::_bi::value<int> > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::ModuleScript>, lua_State *, int),
        boost::shared_ptr<RBX::ModuleScript> a1,
        boost::_bi::value<int> a2,
        int a3)
{
  boost::detail::sp_counted_base *v5; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v7; // r14
  boost::detail::sp_counted_base *v8; // rbx
  boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> > a1a; // [rsp+8h] [rbp-40h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> >,boost::arg<1>,boost::_bi::value<int> > v11; // [rsp+18h] [rbp-30h] BYREF

  a1a.t_.px = *(boost::shared_ptr<RBX::ModuleScript>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  a1a.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->use_count_, 1u);
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::ModuleScript>>,boost::arg<1>,boost::_bi::value<int>>::list3(
    &v11,
    (boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> >)__PAIR128__(LODWORD(a1.pn.pi_), &a1a),
    (boost::arg<1>)a1.pn.pi_,
    a2);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v11.a1_.t_.px;
  pi = v11.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v11.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v7 = v11.a1_.t_.pn.pi_;
    retstr->l_.a3_.t_ = v11.a3_.t_;
    if ( v7 )
    {
      if ( !_InterlockedSub(&v7->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
  }
  else
  {
    retstr->l_.a3_.t_ = v11.a3_.t_;
  }
  v8 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
  }
  return retstr;
}


// Address: 0x11cb4b0 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX12ModuleScriptEEEP9lua_StateS4_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSB_T0_T1_ENS9_9list_av_2IT2_T3_E4typeEEESF_SH_SI_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::ModuleScript>,lua_State *),boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::ModuleScript>,lua_State *,boost::shared_ptr<RBX::ModuleScript>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::ModuleScript>,lua_State *),boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::ModuleScript>, lua_State *),
        boost::shared_ptr<RBX::ModuleScript> a1,
        __int64 a2)
{
  boost::shared_ptr<RBX::ModuleScript>::element_type *v4; // r12
  boost::detail::sp_counted_base *v5; // rbx

  v4 = *(boost::shared_ptr<RBX::ModuleScript>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::ModuleScript>, lua_State *), boost::shared_ptr<RBX::ModuleScript>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::ModuleScript>, lua_State *), boost::shared_ptr<RBX::ModuleScript>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::ModuleScript>, lua_State *), boost::shared_ptr<RBX::ModuleScript>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::ModuleScript>, lua_State *), boost::shared_ptr<RBX::ModuleScript>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x11cb6e0 | Name: _ZN5boost4bindIvNS_10shared_ptrINSt3__16vectorINS1_IN3RBX8InstanceEEENS2_9allocatorIS6_EEEEEENS1_INS4_12ModuleScriptEEERNS4_13ScriptContextERKNS4_8Security8IdentityEP9lua_StatePNSD_15AssetModuleInfoESA_SC_NS_17reference_wrapperISD_EESG_SK_SM_EENS_3_bi6bind_tIT_PFSR_T0_T1_T2_T3_T4_T5_ENSP_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEESZ_S11_S12_S13_S14_S15_S16_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >,boost::shared_ptr<RBX::ModuleScript>,RBX::ScriptContext &,const RBX::Security::Identity &,lua_State *,RBX::ScriptContext::AssetModuleInfo *),boost::_bi::list6<boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > >,boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> >,boost::reference_wrapper<RBX::ScriptContext>,boost::_bi::value<RBX::Security::Identity>,boost::_bi::value<lua_State *>,boost::_bi::value<RBX::ScriptContext::AssetModuleInfo *> > > *__fastcall boost::bind<void,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>,boost::shared_ptr<RBX::ModuleScript>,RBX::ScriptContext &,RBX::Security::Identity const&,lua_State *,RBX::ScriptContext::AssetModuleInfo *,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>,boost::shared_ptr<RBX::ModuleScript>,boost::reference_wrapper<RBX::ScriptContext>,RBX::Security::Identity,lua_State *,RBX::ScriptContext::AssetModuleInfo *>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >,boost::shared_ptr<RBX::ModuleScript>,RBX::ScriptContext &,const RBX::Security::Identity &,lua_State *,RBX::ScriptContext::AssetModuleInfo *),boost::_bi::list6<boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > >,boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> >,boost::reference_wrapper<RBX::ScriptContext>,boost::_bi::value<RBX::Security::Identity>,boost::_bi::value<lua_State *>,boost::_bi::value<RBX::ScriptContext::AssetModuleInfo *> > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >, boost::shared_ptr<RBX::ModuleScript>, RBX::ScriptContext *, const RBX::Security::Identity *, lua_State *, RBX::ScriptContext::AssetModuleInfo *),
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > a1,
        boost::shared_ptr<RBX::ModuleScript> a2,
        boost::reference_wrapper<RBX::ScriptContext> a3,
        RBX::Security::Identity a4)
{
  boost::detail::sp_counted_base *v6; // rdx
  volatile signed __int32 *v7; // rcx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v9; // rax
  boost::detail::sp_counted_base *v10; // rbx
  boost::detail::sp_counted_base *v11; // rbx
  volatile signed __int32 *v12; // rbx
  boost::detail::sp_counted_base *v13; // rbx
  boost::_bi::value<RBX::Security::Identity> v15; // [rsp-10h] [rbp-98h]
  boost::_bi::value<lua_State *> v16; // [rsp+0h] [rbp-88h]
  boost::_bi::value<RBX::ScriptContext::AssetModuleInfo *> a1a; // [rsp+8h] [rbp-80h] BYREF
  volatile signed __int32 *v18; // [rsp+10h] [rbp-78h]
  boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > > v19; // [rsp+18h] [rbp-70h] BYREF
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > >,boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> >,boost::reference_wrapper<RBX::ScriptContext>,boost::_bi::value<RBX::Security::Identity>,boost::_bi::value<lua_State *>,boost::_bi::value<RBX::ScriptContext::AssetModuleInfo *> > v20; // [rsp+28h] [rbp-60h] BYREF

  v19.t_.px = *(boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v19.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->use_count_, 1u);
  a1a.t_ = (RBX::ScriptContext::AssetModuleInfo *)a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v18 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  v15.t_.assetId = a4.assetId;
  *(_QWORD *)&v15.t_.type = a2.pn.pi_;
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>,boost::_bi::value<boost::shared_ptr<RBX::ModuleScript>>,boost::reference_wrapper<RBX::ScriptContext>,boost::_bi::value<RBX::Security::Identity>,boost::_bi::value<lua_State *>,boost::_bi::value<RBX::ScriptContext::AssetModuleInfo *>>::list6(
    &v20,
    (boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > >)__PAIR128__(&a1a, &v19),
    (boost::_bi::value<boost::shared_ptr<RBX::ModuleScript> >)__PAIR128__(LODWORD(a3.t_), (unsigned __int64)a2.px),
    *(boost::reference_wrapper<RBX::ScriptContext> *)&a4.type,
    v15,
    v16,
    a1a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v20.a1_.t_.px;
  pi = v20.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v20.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a2_.t_.px = v20.a2_.t_.px;
  v9 = v20.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v20.a2_.t_.pn.pi_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    v10 = v20.a2_.t_.pn.pi_;
  }
  else
  {
    v10 = 0;
  }
  retstr->l_.a3_.t_ = v20.a3_.t_;
  retstr->l_.a4_ = v20.a4_;
  *(_OWORD *)&retstr->l_.a5_.t_ = *(_OWORD *)&v20.a5_.t_;
  if ( v10 )
  {
    if ( !_InterlockedSub(&v10->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
      if ( !_InterlockedSub(&v10->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  v11 = v20.a1_.t_.pn.pi_;
  if ( v20.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v20.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 2))(v11);
      if ( !_InterlockedSub(&v11->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
    }
  }
  v12 = v18;
  if ( v18 )
  {
    if ( !_InterlockedSub(v18 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  v13 = v19.t_.pn.pi_;
  if ( v19.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v19.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
      if ( !_InterlockedSub(&v13->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
    }
  }
  return retstr;
}


// Address: 0x11ce5d0 | Name: _ZN5boost4bindIvNS_8functionIFvNS_10shared_ptrIKN3RBX10Reflection5TupleEEEEEEP9lua_StateS9_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSG_T0_T1_ENSE_9list_av_2IT2_T3_E4typeEEESK_SM_SN_
boost::_bi::bind_t<void,void (*)(boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,lua_State *),boost::_bi::list2<boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,lua_State *,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,lua_State *),boost::_bi::list2<boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>_0, lua_State *),
        __int64 a2)
{
  unsigned __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(char *, char *, __int64); // rax
  boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> >_0 v8; // [rsp+0h] [rbp-58h] BYREF
  __int64 v9; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> >,boost::arg<1> > v10; // [rsp+28h] [rbp-30h] BYREF

  v8.t_.functor.obj_ptr = 0;
  v3 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v8.t_.functor.obj_ptr = *(void **)a2;
    if ( (v3 & 1) != 0 )
    {
      v9 = *(_QWORD *)(a2 + 24);
      *(_OWORD *)(&v8.t_.functor.data + 8) = *(_OWORD *)(a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v8.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>>,boost::arg<1>>::list2(
    &v10,
    v8,
    (boost::arg<1>)&v8.t_.functor);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v10.a1_.t_.vtable;
  if ( v10.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v10.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v10.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v10.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v10.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v10.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v10.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v10.a1_.t_.functor, &v10.a1_.t_.functor, 2);
      }
    }
    v10.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( v8.t_.functor.obj_ptr )
  {
    if ( (v8.t_.functor.data & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v8.t_.functor.obj_ptr
                                                          & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(v8.t_.functor.bound_memfunc_ptr.gap8, v8.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v8.t_.functor.obj_ptr = 0;
  }
  return retstr;
}


// Address: 0x11ce900 | Name: _ZN5boost4bindIvNS_8functionIFvNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEEEP9lua_StateSA_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSH_T0_T1_ENSF_9list_av_2IT2_T3_E4typeEEESL_SN_SO_
boost::_bi::bind_t<void,void (*)(boost::function<void (std::string)>,lua_State *),boost::_bi::list2<boost::_bi::value<boost::function<void (std::string)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(std::string)>,lua_State *,boost::function<void ()(std::string)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (std::string)>,lua_State *),boost::_bi::list2<boost::_bi::value<boost::function<void (std::string)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (std::string)>_0, lua_State *),
        __int64 a2)
{
  unsigned __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(char *, char *, __int64); // rax
  boost::_bi::value<boost::function<void (std::string)> >_0 v8; // [rsp+0h] [rbp-58h] BYREF
  __int64 v9; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (std::string)> >,boost::arg<1> > v10; // [rsp+28h] [rbp-30h] BYREF

  v8.t_.functor.obj_ptr = 0;
  v3 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v8.t_.functor.obj_ptr = *(void **)a2;
    if ( (v3 & 1) != 0 )
    {
      v9 = *(_QWORD *)(a2 + 24);
      *(_OWORD *)(&v8.t_.functor.data + 8) = *(_OWORD *)(a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v8.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(std::string)>>,boost::arg<1>>::list2(
    &v10,
    v8,
    (boost::arg<1>)&v8.t_.functor);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v10.a1_.t_.vtable;
  if ( v10.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v10.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v10.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v10.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v10.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v10.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v10.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v10.a1_.t_.functor, &v10.a1_.t_.functor, 2);
      }
    }
    v10.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( v8.t_.functor.obj_ptr )
  {
    if ( (v8.t_.functor.data & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v8.t_.functor.obj_ptr
                                                          & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(v8.t_.functor.bound_memfunc_ptr.gap8, v8.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v8.t_.functor.obj_ptr = 0;
  }
  return retstr;
}


// Address: 0x1228510 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX24CacheableContentProviderEEENS2_17HttpRequestResultEPNSt3__113basic_istreamIcNS6_11char_traitsIcEEEENS_10shared_ptrIKNS6_12basic_stringIcS9_NS6_9allocatorIcEEEEEERSH_S4_NS_3argILi1EEENSK_ILi2EEENSK_ILi3EEESG_EENS_3_bi6bind_tIT_PFSQ_T0_T1_T2_T3_T4_ENSO_9list_av_5IT5_T6_T7_T8_T9_E4typeEEESX_SZ_S10_S11_S12_S13_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::CacheableContentProvider>,RBX::HttpRequestResult,std::istream *,boost::shared_ptr<std::string const>,std::string const&,boost::weak_ptr<RBX::CacheableContentProvider>,boost::arg<1>,boost::arg<2>,boost::arg<3>,std::string>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4)
{
  __int64 v5; // rax
  __int64 v6; // rax
  __int64 v7; // rdi
  __int64 v8; // rdi
  __int64 v10; // [rsp+8h] [rbp-60h] BYREF
  __int64 v11; // [rsp+10h] [rbp-58h]
  _BYTE v12[16]; // [rsp+18h] [rbp-50h] BYREF
  void *v13; // [rsp+28h] [rbp-40h]
  __int64 v14; // [rsp+30h] [rbp-38h] BYREF
  __int64 v15; // [rsp+38h] [rbp-30h]
  _BYTE v16[16]; // [rsp+40h] [rbp-28h] BYREF
  void *ptr; // [rsp+50h] [rbp-18h]

  v10 = *a3;
  v5 = a3[1];
  v11 = v5;
  if ( v5 )
    _InterlockedAdd((volatile signed __int32 *)(v5 + 12), 1u);
  std::string::basic_string(v12, a4);
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::CacheableContentProvider>>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::_bi::value<std::string>>::list5(
    &v14,
    &v10,
    v12);
  *a1 = a2;
  a1[1] = v14;
  v6 = v15;
  a1[2] = v15;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)(v6 + 12), 1u);
  std::string::basic_string(a1 + 3, v16);
  if ( (v16[0] & 1) != 0 )
    operator delete(ptr);
  v7 = v15;
  if ( v15 && !_InterlockedSub((volatile signed __int32 *)(v15 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v7 + 24LL))(v7);
  if ( (v12[0] & 1) != 0 )
    operator delete(v13);
  v8 = v11;
  if ( v11 && !_InterlockedSub((volatile signed __int32 *)(v11 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 24LL))(v8);
  return a1;
}


// Address: 0x12574a0 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEEiS6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSB_T0_T1_ENS9_9list_av_2IT2_T3_E4typeEEESF_SH_SI_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,int),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > >_0 *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,int,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,int),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > >_0 *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>_0, int),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x12e7d20 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX13LuaWebServiceEEENS2_17HttpRequestResultENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEENS_8functionIFvNS_10shared_ptrIKNS6_6vectorINS2_10Reflection7VariantENSA_ISH_EEEEEEEEENSD_IFvSC_EEES4_NS_3argILi1EEESC_SN_SP_EENS_3_bi6bind_tIT_PFSU_T0_T1_T2_T3_T4_ENSS_9list_av_5IT5_T6_T7_T8_T9_E4typeEEES11_S13_S14_S15_S16_S17_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::LuaWebService>,RBX::HttpRequestResult,std::string,boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::LuaWebService>,boost::arg<1>,std::string,boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        __int64 *a5,
        __int64 *a6)
{
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  __int64 v14; // rdi
  __int64 v16; // [rsp+8h] [rbp-F0h] BYREF
  __int128 v17; // [rsp+10h] [rbp-E8h] BYREF
  __int64 v18; // [rsp+20h] [rbp-D8h]
  __int64 v19; // [rsp+28h] [rbp-D0h] BYREF
  __int128 v20; // [rsp+30h] [rbp-C8h] BYREF
  __int64 v21; // [rsp+40h] [rbp-B8h]
  __int64 v22; // [rsp+48h] [rbp-B0h] BYREF
  __int64 v23; // [rsp+50h] [rbp-A8h]
  _BYTE v24[16]; // [rsp+58h] [rbp-A0h] BYREF
  void *ptr; // [rsp+68h] [rbp-90h]
  _BYTE v26[136]; // [rsp+70h] [rbp-88h] BYREF

  v22 = *a3;
  v9 = a3[1];
  v23 = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 12), 1u);
  std::string::basic_string(v24, a4);
  v19 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v19 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v21 = a5[3];
      v20 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v20, 0);
    }
  }
  v16 = 0;
  v11 = *a6;
  if ( *a6 )
  {
    v16 = *a6;
    if ( (v11 & 1) != 0 )
    {
      v18 = a6[3];
      v17 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v17, 0);
    }
  }
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    v26,
    &v22,
    v24,
    &v19,
    &v16);
  *a1 = a2;
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    (boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage5((boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( v19 )
  {
    if ( (v19 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v19 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v20, &v20, 2);
    }
    v19 = 0;
  }
  if ( (v24[0] & 1) != 0 )
    operator delete(ptr);
  v14 = v23;
  if ( v23 && !_InterlockedSub((volatile signed __int32 *)(v23 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 24LL))(v14);
  return a1;
}


// Address: 0x12e88e0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX13LuaWebServiceEEENS2_17HttpRequestResultENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEENS_8functionIFvNS_10shared_ptrIKNS6_3mapISC_NS2_10Reflection7VariantENS6_4lessISC_EENSA_INS6_4pairIKSC_SH_EEEEEEEEEEENSD_IFvSC_EEES4_NS_3argILi1EEESC_SS_SU_EENS_3_bi6bind_tIT_PFSZ_T0_T1_T2_T3_T4_ENSX_9list_av_5IT5_T6_T7_T8_T9_E4typeEEES16_S18_S19_S1A_S1B_S1C_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::LuaWebService>,RBX::HttpRequestResult,std::string,boost::function<void ()(boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::LuaWebService>,boost::arg<1>,std::string,boost::function<void ()(boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        __int64 *a5,
        __int64 *a6)
{
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  __int64 v14; // rdi
  __int64 v16; // [rsp+8h] [rbp-F0h] BYREF
  __int128 v17; // [rsp+10h] [rbp-E8h] BYREF
  __int64 v18; // [rsp+20h] [rbp-D8h]
  __int64 v19; // [rsp+28h] [rbp-D0h] BYREF
  __int128 v20; // [rsp+30h] [rbp-C8h] BYREF
  __int64 v21; // [rsp+40h] [rbp-B8h]
  __int64 v22; // [rsp+48h] [rbp-B0h] BYREF
  __int64 v23; // [rsp+50h] [rbp-A8h]
  _BYTE v24[16]; // [rsp+58h] [rbp-A0h] BYREF
  void *ptr; // [rsp+68h] [rbp-90h]
  _BYTE v26[136]; // [rsp+70h] [rbp-88h] BYREF

  v22 = *a3;
  v9 = a3[1];
  v23 = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 12), 1u);
  std::string::basic_string(v24, a4);
  v19 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v19 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v21 = a5[3];
      v20 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v20, 0);
    }
  }
  v16 = 0;
  v11 = *a6;
  if ( *a6 )
  {
    v16 = *a6;
    if ( (v11 & 1) != 0 )
    {
      v18 = a6[3];
      v17 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v17, 0);
    }
  }
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    v26,
    &v22,
    v24,
    &v19,
    &v16);
  *a1 = a2;
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    (boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage5((boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( v19 )
  {
    if ( (v19 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v19 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v20, &v20, 2);
    }
    v19 = 0;
  }
  if ( (v24[0] & 1) != 0 )
    operator delete(ptr);
  v14 = v23;
  if ( v23 && !_InterlockedSub((volatile signed __int32 *)(v23 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 24LL))(v14);
  return a1;
}


// Address: 0x12e9280 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX13LuaWebServiceEEENS2_17HttpRequestResultENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEENS_8functionIFvbEEENSD_IFvSC_EEES4_NS_3argILi1EEESC_SF_SH_EENS_3_bi6bind_tIT_PFSM_T0_T1_T2_T3_T4_ENSK_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEST_SV_SW_SX_SY_SZ_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::LuaWebService>,RBX::HttpRequestResult,std::string,boost::function<void ()(bool)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::LuaWebService>,boost::arg<1>,std::string,boost::function<void ()(bool)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        __int64 *a5,
        __int64 *a6)
{
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  __int64 v14; // rdi
  __int64 v16; // [rsp+8h] [rbp-F0h] BYREF
  __int128 v17; // [rsp+10h] [rbp-E8h] BYREF
  __int64 v18; // [rsp+20h] [rbp-D8h]
  __int64 v19; // [rsp+28h] [rbp-D0h] BYREF
  __int128 v20; // [rsp+30h] [rbp-C8h] BYREF
  __int64 v21; // [rsp+40h] [rbp-B8h]
  __int64 v22; // [rsp+48h] [rbp-B0h] BYREF
  __int64 v23; // [rsp+50h] [rbp-A8h]
  _BYTE v24[16]; // [rsp+58h] [rbp-A0h] BYREF
  void *ptr; // [rsp+68h] [rbp-90h]
  _BYTE v26[136]; // [rsp+70h] [rbp-88h] BYREF

  v22 = *a3;
  v9 = a3[1];
  v23 = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 12), 1u);
  std::string::basic_string(v24, a4);
  v19 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v19 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v21 = a5[3];
      v20 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v20, 0);
    }
  }
  v16 = 0;
  v11 = *a6;
  if ( *a6 )
  {
    v16 = *a6;
    if ( (v11 & 1) != 0 )
    {
      v18 = a6[3];
      v17 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v17, 0);
    }
  }
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    v26,
    &v22,
    v24,
    &v19,
    &v16);
  *a1 = a2;
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    (boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage5((boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( v19 )
  {
    if ( (v19 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v19 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v20, &v20, 2);
    }
    v19 = 0;
  }
  if ( (v24[0] & 1) != 0 )
    operator delete(ptr);
  v14 = v23;
  if ( v23 && !_InterlockedSub((volatile signed __int32 *)(v23 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 24LL))(v14);
  return a1;
}


// Address: 0x12e9a60 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX13LuaWebServiceEEENS2_17HttpRequestResultENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEENS_8functionIFviEEENSD_IFvSC_EEES4_NS_3argILi1EEESC_SF_SH_EENS_3_bi6bind_tIT_PFSM_T0_T1_T2_T3_T4_ENSK_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEST_SV_SW_SX_SY_SZ_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::LuaWebService>,RBX::HttpRequestResult,std::string,boost::function<void ()(int)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::LuaWebService>,boost::arg<1>,std::string,boost::function<void ()(int)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        __int64 *a5,
        __int64 *a6)
{
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  __int64 v14; // rdi
  __int64 v16; // [rsp+8h] [rbp-F0h] BYREF
  __int128 v17; // [rsp+10h] [rbp-E8h] BYREF
  __int64 v18; // [rsp+20h] [rbp-D8h]
  __int64 v19; // [rsp+28h] [rbp-D0h] BYREF
  __int128 v20; // [rsp+30h] [rbp-C8h] BYREF
  __int64 v21; // [rsp+40h] [rbp-B8h]
  __int64 v22; // [rsp+48h] [rbp-B0h] BYREF
  __int64 v23; // [rsp+50h] [rbp-A8h]
  _BYTE v24[16]; // [rsp+58h] [rbp-A0h] BYREF
  void *ptr; // [rsp+68h] [rbp-90h]
  _BYTE v26[136]; // [rsp+70h] [rbp-88h] BYREF

  v22 = *a3;
  v9 = a3[1];
  v23 = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 12), 1u);
  std::string::basic_string(v24, a4);
  v19 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v19 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v21 = a5[3];
      v20 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v20, 0);
    }
  }
  v16 = 0;
  v11 = *a6;
  if ( *a6 )
  {
    v16 = *a6;
    if ( (v11 & 1) != 0 )
    {
      v18 = a6[3];
      v17 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v17, 0);
    }
  }
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    v26,
    &v22,
    v24,
    &v19,
    &v16);
  *a1 = a2;
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    (boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage5((boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( v19 )
  {
    if ( (v19 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v19 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v20, &v20, 2);
    }
    v19 = 0;
  }
  if ( (v24[0] & 1) != 0 )
    operator delete(ptr);
  v14 = v23;
  if ( v23 && !_InterlockedSub((volatile signed __int32 *)(v23 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 24LL))(v14);
  return a1;
}


// Address: 0x12ea080 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX13LuaWebServiceEEENS2_17HttpRequestResultENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEENS_8functionIFvSC_EEESF_S4_NS_3argILi1EEESC_SF_SF_EENS_3_bi6bind_tIT_PFSK_T0_T1_T2_T3_T4_ENSI_9list_av_5IT5_T6_T7_T8_T9_E4typeEEESR_ST_SU_SV_SW_SX_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::LuaWebService>,RBX::HttpRequestResult,std::string,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::LuaWebService>,boost::arg<1>,std::string,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        __int64 *a5,
        __int64 *a6)
{
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  __int64 v14; // rdi
  __int64 v16; // [rsp+8h] [rbp-F0h] BYREF
  __int128 v17; // [rsp+10h] [rbp-E8h] BYREF
  __int64 v18; // [rsp+20h] [rbp-D8h]
  __int64 v19; // [rsp+28h] [rbp-D0h] BYREF
  __int128 v20; // [rsp+30h] [rbp-C8h] BYREF
  __int64 v21; // [rsp+40h] [rbp-B8h]
  __int64 v22; // [rsp+48h] [rbp-B0h] BYREF
  __int64 v23; // [rsp+50h] [rbp-A8h]
  _BYTE v24[16]; // [rsp+58h] [rbp-A0h] BYREF
  void *ptr; // [rsp+68h] [rbp-90h]
  _BYTE v26[136]; // [rsp+70h] [rbp-88h] BYREF

  v22 = *a3;
  v9 = a3[1];
  v23 = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 12), 1u);
  std::string::basic_string(v24, a4);
  v19 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v19 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v21 = a5[3];
      v20 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v20, 0);
    }
  }
  v16 = 0;
  v11 = *a6;
  if ( *a6 )
  {
    v16 = *a6;
    if ( (v11 & 1) != 0 )
    {
      v18 = a6[3];
      v17 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v17, 0);
    }
  }
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    v26,
    &v22,
    v24,
    &v19,
    &v16);
  *a1 = a2;
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    (boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage5((boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( v19 )
  {
    if ( (v19 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v19 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v20, &v20, 2);
    }
    v19 = 0;
  }
  if ( (v24[0] & 1) != 0 )
    operator delete(ptr);
  v14 = v23;
  if ( v23 && !_InterlockedSub((volatile signed __int32 *)(v23 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 24LL))(v14);
  return a1;
}


// Address: 0x1346930 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEENS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEES4_NS_4hashISG_EENSA_8equal_toISG_EENSE_INSA_4pairIKSG_S4_EEEEEEEES6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSW_T0_T1_ENSU_9list_av_2IT2_T3_E4typeEEES10_S12_S13_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > >_0 *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > >_0 *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>_0, boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x1450290 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEERKNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_8functionIFvlEEENSE_IFvSB_EEENS_10shared_ptrIS3_EENS_3argILi1EEESG_SI_EENS_3_bi6bind_tIT_PFSP_T0_T1_T2_T3_ENSN_9list_av_4IT4_T5_T6_T7_E4typeEEESV_SX_SY_SZ_S10_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,const std::string &,boost::function<void (long)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (long)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,std::string const&,boost::function<void ()(long)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::DataModel>,boost::arg<1>,boost::function<void ()(long)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,const std::string &,boost::function<void (long)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (long)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, const std::string *, boost::function<void (long)>, boost::function<void (std::string)>),
        boost::shared_ptr<RBX::DataModel> a1,
        __int64 a2)
{
  boost::detail::sp_counted_base *v5; // rax
  int (**v6)(void); // rax
  boost::detail::function::vtable_base *v7; // rax
  void (__fastcall *v8)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::_bi::value<boost::function<void (long)> > v12; // [rsp+0h] [rbp-B8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> > a1a; // [rsp+20h] [rbp-98h] BYREF
  boost::_bi::value<boost::shared_ptr<RBX::DataModel> > v14; // [rsp+40h] [rbp-78h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (long)> >,boost::_bi::value<boost::function<void (std::string)> > > v15; // [rsp+50h] [rbp-68h] BYREF

  v14.t_.px = *(boost::shared_ptr<RBX::DataModel>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v14.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->use_count_, 1u);
  a1a.t_.vtable = 0;
  v6 = a1.pn.pi_->_vptr$sp_counted_base;
  if ( a1.pn.pi_->_vptr$sp_counted_base )
  {
    a1a.t_.vtable = (boost::detail::function::vtable_base *)a1.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v6 & 1) != 0 )
      a1a.t_.functor = *(boost::detail::function::function_buffer *)&a1.pn.pi_->use_count_;
    else
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v6 & 0xFFFFFFFFFFFFFFFELL))(
        &a1.pn.pi_->use_count_,
        &a1a.t_.functor,
        0);
  }
  v12.t_.vtable = 0;
  v7 = *(boost::detail::function::vtable_base **)a2;
  if ( *(_QWORD *)a2 )
  {
    v12.t_.vtable = *(boost::detail::function::vtable_base **)a2;
    if ( ((unsigned __int8)v7 & 1) != 0 )
      v12.t_.functor = *(boost::detail::function::function_buffer *)(a2 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v7
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v12.t_.functor,
        0);
  }
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(long)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v15,
    (boost::_bi::value<boost::shared_ptr<RBX::DataModel> >)__PAIR128__(&a1a, &v14),
    (boost::arg<1>)&v12,
    v12,
    a1a);
  retstr->f_ = f;
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(long)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage4(
    &retstr->l_,
    &v15);
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(long)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage4(&v15);
  if ( v12.t_.vtable )
  {
    if ( ((__int64)v12.t_.vtable & 1) == 0 )
    {
      v8 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v12.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v8 )
        v8(&v12.t_.functor, &v12.t_.functor, 2);
    }
    v12.t_.vtable = 0;
  }
  if ( a1a.t_.vtable )
  {
    if ( ((__int64)a1a.t_.vtable & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)a1a.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&a1a.t_.functor, &a1a.t_.functor, 2);
    }
    a1a.t_.vtable = 0;
  }
  pi = v14.t_.pn.pi_;
  if ( v14.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v14.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x1450590 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEERKNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_8functionIFvSB_EEENS_10shared_ptrIS3_EENS_3argILi1EEESG_EENS_3_bi6bind_tIT_PFSN_T0_T1_T2_ENSL_9list_av_3IT3_T4_T5_E4typeEEESS_SU_SV_SW_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,const std::string &,boost::function<void (std::string)>),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,std::string const&,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::DataModel>,boost::arg<1>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,const std::string &,boost::function<void (std::string)>),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, const std::string *, boost::function<void (std::string)>),
        boost::shared_ptr<RBX::DataModel> a1,
        boost::arg<1> a2)
{
  boost::detail::sp_counted_base *v4; // rax
  int (**v5)(void); // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v8)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v9; // rbx
  void (__fastcall *v10)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *v11; // rbx
  boost::_bi::value<boost::function<void (std::string)> > v13; // [rsp+0h] [rbp-88h] BYREF
  __int64 v14; // [rsp+20h] [rbp-68h]
  boost::_bi::value<boost::shared_ptr<RBX::DataModel> > v15; // [rsp+28h] [rbp-60h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > v16; // [rsp+38h] [rbp-50h] BYREF

  v15.t_.px = *(boost::shared_ptr<RBX::DataModel>::element_type **)a1.px;
  v4 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v15.t_.pn.pi_ = v4;
  if ( v4 )
    _InterlockedAdd(&v4->use_count_, 1u);
  v13.t_.functor.obj_ptr = 0;
  v5 = a1.pn.pi_->_vptr$sp_counted_base;
  if ( a1.pn.pi_->_vptr$sp_counted_base )
  {
    v13.t_.functor.obj_ptr = a1.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v5 & 1) != 0 )
    {
      v14 = *(_QWORD *)&a1.pn.pi_[1].use_count_;
      *(_OWORD *)(&v13.t_.functor.data + 8) = *(_OWORD *)&a1.pn.pi_->use_count_;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, bool *, _QWORD))((unsigned __int64)v5
                                                                                    & 0xFFFFFFFFFFFFFFFELL))(
        &a1.pn.pi_->use_count_,
        &v13.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>>::list3(
    &v16,
    (boost::_bi::value<boost::shared_ptr<RBX::DataModel> >)__PAIR128__(
                                                             (boost::_bi::value<boost::function<void (std::string)> > *)&v13.t_.functor,
                                                             &v15),
    (boost::arg<1>)a1.pn.pi_,
    v13);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v16.a1_.t_.px;
  pi = v16.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v16.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v16.a3_.t_.vtable;
  if ( v16.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v16.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v16.a3_.t_.functor;
LABEL_17:
      v16.a3_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v16.a3_.t_.functor,
      &retstr->l_.a3_.t_.functor,
      0);
    if ( v16.a3_.t_.vtable )
    {
      if ( ((__int64)v16.a3_.t_.vtable & 1) == 0 )
      {
        v8 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v16.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v8 )
          v8(&v16.a3_.t_.functor, &v16.a3_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v9 = v16.a1_.t_.pn.pi_;
  if ( v16.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v16.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  if ( v13.t_.functor.obj_ptr )
  {
    if ( (v13.t_.functor.data & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v13.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(v13.t_.functor.bound_memfunc_ptr.gap8, v13.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v13.t_.functor.obj_ptr = 0;
  }
  v11 = v15.t_.pn.pi_;
  if ( v15.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v15.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 2))(v11);
      if ( !_InterlockedSub(&v11->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
    }
  }
  return retstr;
}


// Address: 0x1451770 | Name: _ZN5boost4bindIvNS_8functionIFvNS_10shared_ptrIKNSt3__16vectorIN3RBX10Reflection7VariantENS3_9allocatorIS7_EEEEEEEEENS3_12basic_stringIcNS3_11char_traitsIcEENS8_IcEEEESE_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSO_T0_T1_ENSM_9list_av_2IT2_T3_E4typeEEESS_SU_SV_
boost::_bi::bind_t<void,void (*)(boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)>,std::string),boost::_bi::list2<boost::_bi::value<boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,std::string,boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)>,std::string),boost::_bi::list2<boost::_bi::value<boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)>, std::string),
        __int64 a2)
{
  unsigned __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(char *, char *, __int64); // rax
  boost::_bi::value<boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)> > v8; // [rsp+0h] [rbp-58h] BYREF
  __int64 v9; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)> >,boost::arg<1> > v10; // [rsp+28h] [rbp-30h] BYREF

  v8.t_.functor.obj_ptr = 0;
  v3 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v8.t_.functor.obj_ptr = *(void **)a2;
    if ( (v3 & 1) != 0 )
    {
      v9 = *(_QWORD *)(a2 + 24);
      *(_OWORD *)(&v8.t_.functor.data + 8) = *(_OWORD *)(a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v8.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>>,boost::arg<1>>::list2(
    &v10,
    v8,
    (boost::arg<1>)&v8.t_.functor);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v10.a1_.t_.vtable;
  if ( v10.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v10.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v10.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v10.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v10.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v10.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v10.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v10.a1_.t_.functor, &v10.a1_.t_.functor, 2);
      }
    }
    v10.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( v8.t_.functor.obj_ptr )
  {
    if ( (v8.t_.functor.data & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v8.t_.functor.obj_ptr
                                                          & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(v8.t_.functor.bound_memfunc_ptr.gap8, v8.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v8.t_.functor.obj_ptr = 0;
  }
  return retstr;
}


// Address: 0x1451a10 | Name: _ZN5boost4bindIvPNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEPSt9exceptionNS_8functionIFvS7_EEESD_NS_3argILi1EEENSE_ILi2EEESD_SD_EENS_3_bi6bind_tIT_PFSJ_T0_T1_T2_T3_ENSH_9list_av_4IT4_T5_T6_T7_E4typeEEESP_SR_SS_ST_SU_
boost::_bi::bind_t<void,void (*)(std::string *,std::exception *,boost::function<void (std::string)>,boost::function<void (std::string)>),boost::_bi::list4<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,std::string *,std::exception *,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,boost::arg<1>,boost::arg<2>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(std::string *,std::exception *,boost::function<void (std::string)>,boost::function<void (std::string)>),boost::_bi::list4<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(std::string *, std::exception *, boost::function<void (std::string)>, boost::function<void (std::string)>),
        __int64 a1,
        __int64 a2)
{
  boost::detail::function::vtable_base *v5; // rcx
  boost::detail::function::vtable_base *v6; // rax
  void (__fastcall *v7)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v8)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<void (std::string)> > v12; // [rsp+0h] [rbp-98h] BYREF
  boost::_bi::value<boost::function<void (std::string)> > a1a; // [rsp+20h] [rbp-78h] BYREF
  boost::_bi::list4<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > l; // [rsp+40h] [rbp-58h] BYREF

  a1a.t_.vtable = 0;
  v5 = *(boost::detail::function::vtable_base **)a1;
  if ( *(_QWORD *)a1 )
  {
    a1a.t_.vtable = *(boost::detail::function::vtable_base **)a1;
    if ( ((unsigned __int8)v5 & 1) != 0 )
      a1a.t_.functor = *(boost::detail::function::function_buffer *)(a1 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v5
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a1 + 8,
        &a1a.t_.functor,
        0);
  }
  v12.t_.vtable = 0;
  v6 = *(boost::detail::function::vtable_base **)a2;
  if ( *(_QWORD *)a2 )
  {
    v12.t_.vtable = *(boost::detail::function::vtable_base **)a2;
    if ( ((unsigned __int8)v6 & 1) != 0 )
      v12.t_.functor = *(boost::detail::function::function_buffer *)(a2 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v6
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v12.t_.functor,
        0);
  }
  boost::_bi::list4<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &l,
    (boost::arg<1>)&a1a,
    (boost::arg<2>)&v12,
    v12,
    a1a);
  boost::_bi::bind_t<void,void (*)(std::string *,std::exception *,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>),boost::_bi::list4<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>::bind_t(
    retstr,
    f,
    &l);
  if ( l.a4_.t_.vtable )
  {
    if ( ((__int64)l.a4_.t_.vtable & 1) == 0 )
    {
      v7 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)l.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v7 )
        v7(&l.a4_.t_.functor, &l.a4_.t_.functor, 2);
    }
    l.a4_.t_.vtable = 0;
  }
  if ( l.a3_.t_.vtable )
  {
    if ( ((__int64)l.a3_.t_.vtable & 1) == 0 )
    {
      v8 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)l.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v8 )
        v8(&l.a3_.t_.functor, &l.a3_.t_.functor, 2);
    }
    l.a3_.t_.vtable = 0;
  }
  if ( v12.t_.vtable )
  {
    if ( ((__int64)v12.t_.vtable & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v12.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v12.t_.functor, &v12.t_.functor, 2);
    }
    v12.t_.vtable = 0;
  }
  if ( a1a.t_.vtable )
  {
    if ( ((__int64)a1a.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)a1a.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&a1a.t_.functor, &a1a.t_.functor, 2);
    }
    a1a.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x14520a0 | Name: _ZN5boost4bindIvNS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashISB_EENS5_8equal_toISB_EENS9_INS5_4pairIKSB_SE_EEEEEEEEEEENS1_IFvSB_EEESB_SR_ST_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSY_T0_T1_T2_ENSW_9list_av_3IT3_T4_T5_E4typeEEES13_S15_S16_S17_
boost::_bi::bind_t<void,void (*)(boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)>,boost::function<void (std::string)>,std::string),boost::_bi::list3<boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> >,boost::_bi::value<boost::function<void (std::string)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>,std::string,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)>,boost::function<void (std::string)>,std::string),boost::_bi::list3<boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> >,boost::_bi::value<boost::function<void (std::string)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)>, boost::function<void (std::string)>, std::string),
        __int64 a3,
        __int64 a4)
{
  boost::detail::function::vtable_base *v5; // rcx
  boost::detail::function::vtable_base *v6; // rax
  void (__fastcall *v7)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v8)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> > v12; // [rsp+0h] [rbp-98h] BYREF
  boost::_bi::value<boost::function<void (std::string)> > a3a; // [rsp+20h] [rbp-78h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> >,boost::_bi::value<boost::function<void (std::string)> >,boost::arg<1> > l; // [rsp+40h] [rbp-58h] BYREF

  a3a.t_.vtable = 0;
  v5 = *(boost::detail::function::vtable_base **)a3;
  if ( *(_QWORD *)a3 )
  {
    a3a.t_.vtable = *(boost::detail::function::vtable_base **)a3;
    if ( ((unsigned __int8)v5 & 1) != 0 )
      a3a.t_.functor = *(boost::detail::function::function_buffer *)(a3 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v5
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a3 + 8,
        &a3a.t_.functor,
        0);
  }
  v12.t_.vtable = 0;
  v6 = *(boost::detail::function::vtable_base **)a4;
  if ( *(_QWORD *)a4 )
  {
    v12.t_.vtable = *(boost::detail::function::vtable_base **)a4;
    if ( ((unsigned __int8)v6 & 1) != 0 )
      v12.t_.functor = *(boost::detail::function::function_buffer *)(a4 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v6
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a4 + 8,
        &v12.t_.functor,
        0);
  }
  boost::_bi::list3<boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::arg<1>>::list3(
    &l,
    v12,
    a3a,
    (boost::arg<1>)&a3a);
  boost::_bi::bind_t<void,void (*)(boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>,std::string),boost::_bi::list3<boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::arg<1>>>::bind_t(
    retstr,
    f,
    &l);
  if ( l.a2_.t_.vtable )
  {
    if ( ((__int64)l.a2_.t_.vtable & 1) == 0 )
    {
      v7 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)l.a2_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v7 )
        v7(&l.a2_.t_.functor, &l.a2_.t_.functor, 2);
    }
    l.a2_.t_.vtable = 0;
  }
  if ( l.a1_.t_.vtable )
  {
    if ( ((__int64)l.a1_.t_.vtable & 1) == 0 )
    {
      v8 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)l.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v8 )
        v8(&l.a1_.t_.functor, &l.a1_.t_.functor, 2);
    }
    l.a1_.t_.vtable = 0;
  }
  if ( v12.t_.vtable )
  {
    if ( ((__int64)v12.t_.vtable & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v12.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v12.t_.functor, &v12.t_.functor, 2);
    }
    v12.t_.vtable = 0;
  }
  if ( a3a.t_.vtable )
  {
    if ( ((__int64)a3a.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)a3a.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&a3a.t_.functor, &a3a.t_.functor, 2);
    }
    a3a.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x1452f10 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEElS6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSB_T0_T1_ENS9_9list_av_2IT2_T3_E4typeEEESF_SH_SI_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,long),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,long,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,long),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>, __int64),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x1454c70 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEENS_10shared_ptrIKNSt3__16vectorIS4_NS8_9allocatorIS4_EEEEEES6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSJ_T0_T1_ENSH_9list_av_2IT2_T3_E4typeEEESN_SP_SQ_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>, boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x14561a0 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEENS_10shared_ptrIKNS3_5TupleEEES6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSF_T0_T1_ENSD_9list_av_2IT2_T3_E4typeEEESJ_SL_SM_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,boost::shared_ptr<const RBX::Reflection::Tuple>),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,boost::shared_ptr<const RBX::Reflection::Tuple>),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>, boost::shared_ptr<const RBX::Reflection::Tuple>),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x14600e0 | Name: _ZN5boost4bindIvNS_10shared_ptrINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEENS1_ISt9exceptionEES8_NS_8functionIFvNS1_IKN3RBX10Reflection5TupleEEEEEENSC_IFvS8_EEENS_3argILi1EEENSM_ILi2EEES8_SJ_SL_EENS_3_bi6bind_tIT_PFSR_T0_T1_T2_T3_T4_ENSP_9list_av_5IT5_T6_T7_T8_T9_E4typeEEESY_S10_S11_S12_S13_S14_
_QWORD *__fastcall boost::bind<void,boost::shared_ptr<std::string>,boost::shared_ptr<std::exception>,std::string,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>,boost::arg<1>,boost::arg<2>,std::string,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5)
{
  __int64 v7; // rax
  __int64 v8; // rax
  void (__fastcall *v9)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v10)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v11)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  __int64 v14; // [rsp+8h] [rbp-D0h] BYREF
  __int128 v15; // [rsp+10h] [rbp-C8h] BYREF
  __int64 v16; // [rsp+20h] [rbp-B8h]
  __int64 v17; // [rsp+28h] [rbp-B0h] BYREF
  __int128 v18; // [rsp+30h] [rbp-A8h] BYREF
  __int64 v19; // [rsp+40h] [rbp-98h]
  _BYTE v20[16]; // [rsp+48h] [rbp-90h] BYREF
  void *v21; // [rsp+58h] [rbp-80h]
  _BYTE v22[16]; // [rsp+60h] [rbp-78h] BYREF
  void *ptr; // [rsp+70h] [rbp-68h]
  __int64 v24; // [rsp+78h] [rbp-60h]
  _BYTE v25[24]; // [rsp+80h] [rbp-58h] BYREF
  __int64 v26; // [rsp+98h] [rbp-40h]
  _BYTE v27[56]; // [rsp+A0h] [rbp-38h] BYREF

  std::string::basic_string(v20, a3);
  v17 = 0;
  v7 = *a4;
  if ( *a4 )
  {
    v17 = *a4;
    if ( (v7 & 1) != 0 )
    {
      v19 = a4[3];
      v18 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v18, 0);
    }
  }
  v14 = 0;
  v8 = *a5;
  if ( *a5 )
  {
    v14 = *a5;
    if ( (v8 & 1) != 0 )
    {
      v16 = a5[3];
      v15 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v8 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v15, 0);
    }
  }
  boost::_bi::list5<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    v22,
    v20,
    &v17,
    &v14);
  *a1 = a2;
  boost::_bi::storage5<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage5(
    (boost::_bi::storage5<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::storage5<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v22);
  if ( v26 )
  {
    if ( (v26 & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v26 & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(v27, v27, 2);
    }
    v26 = 0;
  }
  if ( v24 )
  {
    if ( (v24 & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v24 & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(v25, v25, 2);
    }
    v24 = 0;
  }
  if ( (v22[0] & 1) != 0 )
    operator delete(ptr);
  if ( v14 )
  {
    if ( (v14 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v14 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v15, &v15, 2);
    }
    v14 = 0;
  }
  if ( v17 )
  {
    if ( (v17 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v17 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v18, &v18, 2);
    }
    v17 = 0;
  }
  if ( (v20[0] & 1) != 0 )
    operator delete(v21);
  return a1;
}


// Address: 0x148c9c0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX12BadgeServiceEEEllPNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEPSt9exceptionNS_8functionIFvbEEENSF_IFvSB_EEES4_llNS_3argILi1EEENSK_ILi2EEESH_SJ_EENS_3_bi6bind_tIT_PFSP_T0_T1_T2_T3_T4_T5_T6_ENSN_9list_av_7IT7_T8_T9_T10_T11_T12_T13_E4typeEEESY_S10_S11_S12_S13_S14_S15_S16_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::BadgeService>,long,long,std::string *,std::exception *,boost::function<void (bool)>,boost::function<void (std::string)>),boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::BadgeService> >,boost::_bi::value<long>,boost::_bi::value<long>,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::BadgeService>,long,long,std::string *,std::exception *,boost::function<void ()(bool)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::BadgeService>,long,long,boost::arg<1>,boost::arg<2>,boost::function<void ()(bool)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::BadgeService>,long,long,std::string *,std::exception *,boost::function<void (bool)>,boost::function<void (std::string)>),boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::BadgeService> >,boost::_bi::value<long>,boost::_bi::value<long>,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::BadgeService>, __int64, __int64, std::string *, std::exception *, boost::function<void (bool)>, boost::function<void (std::string)>_0),
        boost::weak_ptr<RBX::BadgeService> a1,
        boost::_bi::value<long> a2,
        __int64 a3,
        __int64 a4)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v9; // rax
  boost::detail::function::vtable_base *v10; // rax
  boost::detail::function::vtable_base *v11; // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v14; // rdi
  void (__fastcall *v15)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v16)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v17; // rdi
  boost::arg<2> v19; // [rsp+0h] [rbp-D8h]
  boost::_bi::value<boost::function<void (bool)> > v20; // [rsp+8h] [rbp-D0h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 v21; // [rsp+28h] [rbp-B0h] BYREF
  boost::_bi::value<boost::weak_ptr<RBX::BadgeService> > a1a; // [rsp+48h] [rbp-90h] BYREF
  boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::BadgeService> >,boost::_bi::value<long>,boost::_bi::value<long>,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> > > v23; // [rsp+58h] [rbp-80h] BYREF

  pi = a1.pn.pi_;
  a1a.t_.px = *(boost::weak_ptr<RBX::BadgeService>::element_type **)a1.px;
  v9 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  a1a.t_.pn.pi_ = v9;
  if ( v9 )
    _InterlockedAdd(&v9->weak_count_, 1u);
  v21.t_.vtable = 0;
  v10 = *(boost::detail::function::vtable_base **)a3;
  if ( *(_QWORD *)a3 )
  {
    v21.t_.vtable = *(boost::detail::function::vtable_base **)a3;
    if ( ((unsigned __int8)v10 & 1) != 0 )
      v21.t_.functor = *(boost::detail::function::function_buffer *)(a3 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v10
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a3 + 8,
        &v21.t_.functor,
        0);
  }
  v20.t_.vtable = 0;
  v11 = *(boost::detail::function::vtable_base **)a4;
  if ( *(_QWORD *)a4 )
  {
    v20.t_.vtable = *(boost::detail::function::vtable_base **)a4;
    if ( ((unsigned __int8)v11 & 1) != 0 )
      v20.t_.functor = *(boost::detail::function::function_buffer *)(a4 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v11
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a4 + 8,
        &v20.t_.functor,
        0);
  }
  boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::BadgeService>>,boost::_bi::value<long>,boost::_bi::value<long>,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list7(
    &v23,
    (boost::_bi::value<boost::weak_ptr<RBX::BadgeService> >)__PAIR128__((unsigned __int64)pi, &a1a),
    a2,
    (boost::_bi::value<long>)&v21,
    (boost::arg<1>)&v20,
    v19,
    v20,
    v21);
  retstr->f_ = f;
  boost::_bi::storage7<boost::_bi::value<boost::weak_ptr<RBX::BadgeService>>,boost::_bi::value<long>,boost::_bi::value<long>,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage7(
    &retstr->l_,
    &v23);
  if ( v23.a7_.t_.vtable )
  {
    if ( ((__int64)v23.a7_.t_.vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v23.a7_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v23.a7_.t_.functor, &v23.a7_.t_.functor, 2);
    }
    v23.a7_.t_.vtable = 0;
  }
  if ( v23.a6_.t_.vtable )
  {
    if ( ((__int64)v23.a6_.t_.vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v23.a6_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v23.a6_.t_.functor, &v23.a6_.t_.functor, 2);
    }
    v23.a6_.t_.vtable = 0;
  }
  v14 = v23.a1_.t_.pn.pi_;
  if ( v23.a1_.t_.pn.pi_ && !_InterlockedSub(&v23.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
  if ( v20.t_.vtable )
  {
    if ( ((__int64)v20.t_.vtable & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v20.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v20.t_.functor, &v20.t_.functor, 2);
    }
    v20.t_.vtable = 0;
  }
  if ( v21.t_.vtable )
  {
    if ( ((__int64)v21.t_.vtable & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v21.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v21.t_.functor, &v21.t_.functor, 2);
    }
    v21.t_.vtable = 0;
  }
  v17 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ && !_InterlockedSub(&a1a.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
  return retstr;
}


// Address: 0x148d040 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX12BadgeServiceEEElllS4_lllEENS_3_bi6bind_tIT_PFS7_T0_T1_T2_T3_ENS5_9list_av_4IT4_T5_T6_T7_E4typeEEESD_SF_SG_SH_SI_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::BadgeService>,long,long,long),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::BadgeService> >,boost::_bi::value<long>,boost::_bi::value<long>,boost::_bi::value<long> > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::BadgeService>,long,long,long,boost::shared_ptr<RBX::BadgeService>,long,long,long>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::BadgeService>,long,long,long),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::BadgeService> >,boost::_bi::value<long>,boost::_bi::value<long>,boost::_bi::value<long> > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::BadgeService>, __int64, __int64, __int64),
        boost::shared_ptr<RBX::BadgeService> a1,
        boost::_bi::value<long> a2,
        boost::_bi::value<long> a3)
{
  volatile signed __int32 *v5; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v7; // rbx
  volatile signed __int32 *v8; // rbx
  __int64 v10; // [rsp+0h] [rbp-48h] BYREF
  volatile signed __int32 *v11; // [rsp+8h] [rbp-40h]
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::BadgeService> >,boost::_bi::value<long>,boost::_bi::value<long>,boost::_bi::value<long> > v12; // [rsp+10h] [rbp-38h] BYREF

  v10 = *(_QWORD *)a1.px;
  v5 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v11 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::BadgeService>>,boost::_bi::value<long>,boost::_bi::value<long>,boost::_bi::value<long>>::list4(
    &v12,
    (boost::_bi::value<boost::shared_ptr<RBX::BadgeService> >)__PAIR128__((unsigned __int64)a1.pn.pi_, &v10),
    a2,
    a3,
    a3);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v12.a1_.t_.px;
  pi = v12.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v12.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v7 = v12.a1_.t_.pn.pi_;
  }
  else
  {
    v7 = 0;
  }
  *(_OWORD *)&retstr->l_.a2_.t_ = *(_OWORD *)&v12.a2_.t_;
  retstr->l_.a4_.t_ = v12.a4_.t_;
  if ( v7 )
  {
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  v8 = v11;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  return retstr;
}


// Address: 0x148d2c0 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX12BadgeServiceEEERKNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEllS4_SB_llEENS_3_bi6bind_tIT_PFSG_T0_T1_T2_T3_ENSE_9list_av_4IT4_T5_T6_T7_E4typeEEESM_SO_SP_SQ_SR_
__int64 __fastcall boost::bind<void,boost::shared_ptr<RBX::BadgeService>,std::string const&,long,long,boost::shared_ptr<RBX::BadgeService>,std::string,long,long>(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  volatile signed __int32 *v8; // rax
  volatile signed __int32 *v9; // rax
  volatile signed __int32 *v10; // rbx
  volatile signed __int32 *v11; // rbx
  __int64 v13; // [rsp+0h] [rbp-88h] BYREF
  volatile signed __int32 *v14; // [rsp+8h] [rbp-80h]
  _BYTE v15[16]; // [rsp+10h] [rbp-78h] BYREF
  void *v16; // [rsp+20h] [rbp-68h]
  __int64 v17; // [rsp+28h] [rbp-60h] BYREF
  volatile signed __int32 *v18; // [rsp+30h] [rbp-58h]
  char v19[16]; // [rsp+38h] [rbp-50h] BYREF
  void *ptr; // [rsp+48h] [rbp-40h]
  __int128 v21; // [rsp+50h] [rbp-38h]

  v13 = *a3;
  v8 = (volatile signed __int32 *)a3[1];
  v14 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  std::string::basic_string(v15, a4);
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::BadgeService>>,boost::_bi::value<std::string>,boost::_bi::value<long>,boost::_bi::value<long>>::list4(
    &v17,
    &v13,
    v15,
    a5,
    a6);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = v17;
  v9 = v18;
  *(_QWORD *)(a1 + 16) = v18;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  std::string::basic_string(a1 + 24, v19);
  *(_OWORD *)(a1 + 48) = v21;
  if ( (v19[0] & 1) != 0 )
    operator delete(ptr);
  v10 = v18;
  if ( v18 )
  {
    if ( !_InterlockedSub(v18 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
      if ( !_InterlockedSub(v10 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
    }
  }
  if ( (v15[0] & 1) != 0 )
    operator delete(v16);
  v11 = v14;
  if ( v14 )
  {
    if ( !_InterlockedSub(v14 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
  return a1;
}


// Address: 0x1499eb0 | Name: _ZN5boost4bindIvNS_10shared_ptrINS_8functionIFvNS1_IKN3RBX10Reflection5TupleEEENS2_IFvS7_EEENS2_IFvNSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEEEEEEEEEES7_S9_SI_SL_NS_3argILi1EEENSM_ILi2EEENSM_ILi3EEEEENS_3_bi6bind_tIT_PFSS_T0_T1_T2_T3_ENSQ_9list_av_4IT4_T5_T6_T7_E4typeEEESY_S10_S11_S12_S13_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >,boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3> > > *__fastcall boost::bind<void,boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>,boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>,boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>,boost::arg<1>,boost::arg<2>,boost::arg<3>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >,boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3> > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >, boost::shared_ptr<const RBX::Reflection::Tuple>, boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>_0, boost::function<void (std::string)>_0),
        boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > a1,
        boost::arg<1> a2,
        boost::arg<2> a3)
{
  boost::detail::sp_counted_base *obj_ptr; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v7; // rbx
  boost::detail::sp_counted_base *v8; // rbx
  boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > > a1a; // [rsp+8h] [rbp-30h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3> > v11; // [rsp+18h] [rbp-20h] BYREF

  a1a.t_.px = (boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >::element_type *)a1.px->vtable;
  obj_ptr = (boost::detail::sp_counted_base *)a1.px->functor.obj_ptr;
  a1a.t_.pn.pi_ = obj_ptr;
  if ( obj_ptr )
    _InterlockedAdd(&obj_ptr->use_count_, 1u);
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>>,boost::arg<1>,boost::arg<2>,boost::arg<3>>::list4(
    &v11,
    (boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >)__PAIR128__((unsigned __int64)a1.px, &a1a),
    (boost::arg<1>)a1.pn.pi_,
    (boost::arg<2>)a2.gap0,
    (boost::arg<3>)a3.gap0);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v11.a1_.t_.px;
  pi = v11.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v11.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v7 = v11.a1_.t_.pn.pi_;
    if ( v11.a1_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v11.a1_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
  }
  v8 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
  }
  return retstr;
}


// Address: 0x14d8b90 | Name: _ZN5boost4bindIvRKN3RBX16TextFilterResultENS_10shared_ptrINS1_6PlayerEEENS_8functionIFvNSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEEEEESH_NS_3argILi1EEES7_SH_SH_EENS_3_bi6bind_tIT_PFSM_T0_T1_T2_T3_ENSK_9list_av_4IT4_T5_T6_T7_E4typeEEESS_SU_SV_SW_SX_
boost::_bi::bind_t<void,void (*)(const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)>),boost::_bi::list4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::TextFilterResult const&,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,boost::arg<1>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)>),boost::_bi::list4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(const RBX::TextFilterResult *, boost::shared_ptr<RBX::Player>, boost::function<void (std::string)>_0, boost::function<void (std::string)>_0),
        _QWORD *a1,
        boost::shared_ptr<RBX::Player> a2)
{
  boost::detail::sp_counted_base *pi; // rbx
  volatile signed __int32 *v5; // rax
  __int64 v6; // rax
  boost::detail::function::vtable_base *v7; // rax
  boost::_bi::value<boost::shared_ptr<RBX::Player> > v8; // rdx
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  volatile signed __int32 *v11; // rbx
  boost::_bi::value<boost::function<void (std::string)> >_0 v13; // [rsp+0h] [rbp-B8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 a2a; // [rsp+20h] [rbp-98h] BYREF
  boost::arg<1> a1a[8]; // [rsp+40h] [rbp-78h] BYREF
  volatile signed __int32 *v16; // [rsp+48h] [rbp-70h]
  boost::_bi::list4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > v17; // [rsp+50h] [rbp-68h] BYREF

  pi = a2.pn.pi_;
  *(_QWORD *)&a1a[0].gap0 = *a1;
  v5 = (volatile signed __int32 *)a1[1];
  v16 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  a2a.t_.vtable = 0;
  v6 = *(_QWORD *)a2.px;
  if ( *(_QWORD *)a2.px )
  {
    a2a.t_.vtable = *(boost::detail::function::vtable_base **)a2.px;
    if ( (v6 & 1) != 0 )
      a2a.t_.functor = *(boost::detail::function::function_buffer *)((char *)a2.px + 8);
    else
      (*(void (__fastcall **)(char *, boost::detail::function::function_buffer *, _QWORD))(v6 & 0xFFFFFFFFFFFFFFFELL))(
        (char *)a2.px + 8,
        &a2a.t_.functor,
        0);
  }
  v13.t_.vtable = 0;
  v7 = (boost::detail::function::vtable_base *)pi->_vptr$sp_counted_base;
  if ( pi->_vptr$sp_counted_base )
  {
    v13.t_.vtable = (boost::detail::function::vtable_base *)pi->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v7 & 1) != 0 )
      v13.t_.functor = *(boost::detail::function::function_buffer *)&pi->use_count_;
    else
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v7 & 0xFFFFFFFFFFFFFFFELL))(
        &pi->use_count_,
        &v13.t_.functor,
        0);
  }
  v8.t_.px = &a2a;
  v8.t_.pn.pi_ = (boost::detail::sp_counted_base *)&v13;
  boost::_bi::list4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v17,
    (boost::arg<1>)a1a,
    v8,
    v13,
    a2a);
  retstr->f_ = f;
  boost::_bi::storage4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage4(
    &retstr->l_,
    &v17);
  boost::_bi::storage4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage4(&v17);
  if ( v13.t_.vtable )
  {
    if ( ((__int64)v13.t_.vtable & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v13.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v13.t_.functor, &v13.t_.functor, 2);
    }
    v13.t_.vtable = 0;
  }
  if ( a2a.t_.vtable )
  {
    if ( ((__int64)a2a.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)a2a.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&a2a.t_.functor, &a2a.t_.functor, 2);
    }
    a2a.t_.vtable = 0;
  }
  v11 = v16;
  if ( v16 )
  {
    if ( !_InterlockedSub(v16 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
  return retstr;
}


// Address: 0x14da4a0 | Name: _ZN5boost4bindIvbNS_10shared_ptrIN3RBX6PlayerEEENS_8functionIFvNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEEEENS2_16TextFilterResultENS_3argILi1EEES4_SE_SF_EENS_3_bi6bind_tIT_PFSK_T0_T1_T2_T3_ENSI_9list_av_4IT4_T5_T6_T7_E4typeEEESQ_SS_ST_SU_SV_
_QWORD *__fastcall boost::bind<void,bool,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,RBX::TextFilterResult,boost::arg<1>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,RBX::TextFilterResult>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 *a4,
        const RBX::TextFilterResult *a5)
{
  volatile signed __int32 *v6; // rax
  __int64 v7; // rax
  void (__fastcall *v8)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v9; // rbx
  __int64 v11; // [rsp+0h] [rbp-128h] BYREF
  __int128 v12; // [rsp+8h] [rbp-120h] BYREF
  __int64 v13; // [rsp+18h] [rbp-110h]
  __int64 v14; // [rsp+20h] [rbp-108h] BYREF
  volatile signed __int32 *v15; // [rsp+28h] [rbp-100h]
  _BYTE v16[16]; // [rsp+30h] [rbp-F8h] BYREF
  char v17; // [rsp+40h] [rbp-E8h]
  void *ptr; // [rsp+50h] [rbp-D8h]
  char v19; // [rsp+58h] [rbp-D0h]
  void *v20; // [rsp+68h] [rbp-C0h]
  char v21; // [rsp+70h] [rbp-B8h]
  void *v22; // [rsp+80h] [rbp-A8h]
  _BYTE v23[160]; // [rsp+88h] [rbp-A0h] BYREF

  v14 = *a3;
  v6 = (volatile signed __int32 *)a3[1];
  v15 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  v11 = 0;
  v7 = *a4;
  if ( *a4 )
  {
    v11 = *a4;
    if ( (v7 & 1) != 0 )
    {
      v13 = a4[3];
      v12 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v12, 0);
    }
  }
  boost::_bi::value<RBX::TextFilterResult>::value((boost::_bi::value<RBX::TextFilterResult> *)v16, a5);
  boost::_bi::list4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<RBX::TextFilterResult>>::list4(
    v23,
    &v14,
    &v11,
    v16);
  *a1 = a2;
  boost::_bi::storage4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<RBX::TextFilterResult>>::storage4(
    (boost::_bi::storage4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<RBX::TextFilterResult> > *)(a1 + 1),
    (const boost::_bi::storage4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<RBX::TextFilterResult> > *)v23);
  boost::_bi::storage4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<RBX::TextFilterResult>>::~storage4((boost::_bi::storage4<boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<RBX::TextFilterResult> > *)v23);
  if ( (v21 & 1) != 0 )
  {
    operator delete(v22);
    if ( (v19 & 1) == 0 )
    {
LABEL_9:
      if ( (v17 & 1) == 0 )
        goto LABEL_11;
      goto LABEL_10;
    }
  }
  else if ( (v19 & 1) == 0 )
  {
    goto LABEL_9;
  }
  operator delete(v20);
  if ( (v17 & 1) != 0 )
LABEL_10:
    operator delete(ptr);
LABEL_11:
  if ( v11 )
  {
    if ( (v11 & 1) == 0 )
    {
      v8 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v11 & 0xFFFFFFFFFFFFFFFELL);
      if ( v8 )
        v8(&v12, &v12, 2);
    }
    v11 = 0;
  }
  v9 = v15;
  if ( v15 )
  {
    if ( !_InterlockedSub(v15 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
      if ( !_InterlockedSub(v9 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
    }
  }
  return a1;
}


// Address: 0x14dc430 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEENSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEES6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSI_T0_T1_ENSG_9list_av_2IT2_T3_E4typeEEESM_SO_SP_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,std::string),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > >_0 *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,std::string,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,std::string),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > >_0 *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>, std::string),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x150ae60 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX19LocalizationServiceEEENS_10shared_ptrIKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEEENS5_ISt9exceptionEEliS4_NS_3argILi3EEENSH_ILi4EEEliEENS_3_bi6bind_tIT_PFSM_T0_T1_T2_T3_T4_ENSK_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEST_SV_SW_SX_SY_SZ_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LocalizationService>,boost::shared_ptr<const std::string >,boost::shared_ptr<std::exception>,long,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> >,boost::arg<3>,boost::arg<4>,boost::_bi::value<long>,boost::_bi::value<int> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::LocalizationService>,boost::shared_ptr<std::string const>,boost::shared_ptr<std::exception>,long,int,boost::weak_ptr<RBX::LocalizationService>,boost::arg<3>,boost::arg<4>,long,int>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LocalizationService>,boost::shared_ptr<const std::string >,boost::shared_ptr<std::exception>,long,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> >,boost::arg<3>,boost::arg<4>,boost::_bi::value<long>,boost::_bi::value<int> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::LocalizationService>, boost::shared_ptr<const std::string >, boost::shared_ptr<std::exception>, __int64, int),
        boost::weak_ptr<RBX::LocalizationService> a1,
        boost::arg<3> a2,
        boost::_bi::value<long> a3)
{
  boost::detail::sp_counted_base *v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // rdi
  boost::detail::sp_counted_base *v9; // rdi
  boost::_bi::value<int> v11; // [rsp+0h] [rbp-48h]
  boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> > a1a; // [rsp+8h] [rbp-40h] BYREF
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> >,boost::arg<3>,boost::arg<4>,boost::_bi::value<long>,boost::_bi::value<int> > v13; // [rsp+18h] [rbp-30h] BYREF

  a1a.t_.px = *(boost::weak_ptr<RBX::LocalizationService>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  a1a.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->weak_count_, 1u);
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService>>,boost::arg<3>,boost::arg<4>,boost::_bi::value<long>,boost::_bi::value<int>>::list5(
    &v13,
    (boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> >)__PAIR128__((unsigned __int64)a1.pn.pi_, &a1a),
    a2,
    (boost::arg<4>)a2.gap0,
    a3,
    v11);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v13.a1_.t_.px;
  pi = v13.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v13.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->weak_count_, 1u);
    v8 = v13.a1_.t_.pn.pi_;
  }
  else
  {
    v8 = 0;
  }
  retstr->l_.a4_.t_ = v13.a4_.t_;
  retstr->l_.a5_.t_ = v13.a5_.t_;
  if ( v8 && !_InterlockedSub(&v8->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
  v9 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ && !_InterlockedSub(&a1a.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
  return retstr;
}


// Address: 0x150afe0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX19LocalizationServiceEEENS_10shared_ptrIKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEEENS5_ISt9exceptionEESC_SC_biS4_NS_3argILi3EEENSH_ILi4EEESC_SC_biEENS_3_bi6bind_tIT_PFSM_T0_T1_T2_T3_T4_T5_T6_ENSK_9list_av_7IT7_T8_T9_T10_T11_T12_T13_E4typeEEESV_SX_SY_SZ_S10_S11_S12_S13_
__int64 __fastcall boost::bind<void,boost::weak_ptr<RBX::LocalizationService>,boost::shared_ptr<std::string const>,boost::shared_ptr<std::exception>,std::string,std::string,bool,int,boost::weak_ptr<RBX::LocalizationService>,boost::arg<3>,boost::arg<4>,std::string,std::string,bool,int>(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        __int64 a5,
        unsigned __int8 a6,
        __int64 a7)
{
  __int64 v10; // rax
  __int64 v11; // rdi
  __int64 v12; // rdi
  __int64 v14; // [rsp+0h] [rbp-A8h] BYREF
  __int64 v15; // [rsp+8h] [rbp-A0h]
  _BYTE v16[16]; // [rsp+10h] [rbp-98h] BYREF
  void *v17; // [rsp+20h] [rbp-88h]
  _BYTE v18[16]; // [rsp+28h] [rbp-80h] BYREF
  void *v19; // [rsp+38h] [rbp-70h]
  _BYTE v20[8]; // [rsp+40h] [rbp-68h] BYREF
  __int64 v21; // [rsp+48h] [rbp-60h]
  char v22; // [rsp+50h] [rbp-58h]
  void *v23; // [rsp+60h] [rbp-48h]
  char v24; // [rsp+68h] [rbp-40h]
  void *ptr; // [rsp+78h] [rbp-30h]
  char v26; // [rsp+80h] [rbp-28h]
  int v27; // [rsp+84h] [rbp-24h]

  v14 = *a3;
  v10 = a3[1];
  v15 = v10;
  if ( v10 )
    _InterlockedAdd((volatile signed __int32 *)(v10 + 12), 1u);
  std::string::basic_string(v18, a4);
  std::string::basic_string(v16, a5);
  ((void (__fastcall *)(_BYTE *, __int64 *, _BYTE *, _BYTE *, _QWORD, _QWORD))boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService>>,boost::arg<3>,boost::arg<4>,boost::_bi::value<std::string>,boost::_bi::value<std::string>,boost::_bi::value<bool>,boost::_bi::value<int>>::list7)(
    v20,
    &v14,
    v18,
    v16,
    a6,
    (unsigned int)a7);
  *(_QWORD *)a1 = a2;
  boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService>>,boost::arg<3>,boost::arg<4>,boost::_bi::value<std::string>,boost::_bi::value<std::string>>::storage5(
    (boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> >,boost::arg<3>,boost::arg<4>,boost::_bi::value<std::string >,boost::_bi::value<std::string > > *)(a1 + 8),
    (const boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> >,boost::arg<3>,boost::arg<4>,boost::_bi::value<std::string >,boost::_bi::value<std::string > > *)v20);
  *(_BYTE *)(a1 + 72) = v26;
  *(_DWORD *)(a1 + 76) = v27;
  if ( (v24 & 1) != 0 )
    operator delete(ptr);
  if ( (v22 & 1) != 0 )
    operator delete(v23);
  v11 = v21;
  if ( v21 && !_InterlockedSub((volatile signed __int32 *)(v21 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 24LL))(v11);
  if ( (v16[0] & 1) != 0 )
    operator delete(v17);
  if ( (v18[0] & 1) != 0 )
    operator delete(v19);
  v12 = v15;
  if ( v15 && !_InterlockedSub((volatile signed __int32 *)(v15 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v12 + 24LL))(v12);
  return a1;
}


// Address: 0x150b290 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX19LocalizationServiceEEEPNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEPSt9exceptionliS4_NS_3argILi1EEENSF_ILi2EEEliEENS_3_bi6bind_tIT_PFSK_T0_T1_T2_T3_T4_ENSI_9list_av_5IT5_T6_T7_T8_T9_E4typeEEESR_ST_SU_SV_SW_SX_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LocalizationService>,std::string *,std::exception *,long,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<long>,boost::_bi::value<int> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::LocalizationService>,std::string *,std::exception *,long,int,boost::weak_ptr<RBX::LocalizationService>,boost::arg<1>,boost::arg<2>,long,int>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LocalizationService>,std::string *,std::exception *,long,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<long>,boost::_bi::value<int> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::LocalizationService>, std::string *, std::exception *, __int64, int),
        boost::weak_ptr<RBX::LocalizationService> a1,
        boost::arg<1> a2,
        boost::_bi::value<long> a3)
{
  boost::detail::sp_counted_base *v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // rdi
  boost::detail::sp_counted_base *v9; // rdi
  boost::_bi::value<int> v11; // [rsp+0h] [rbp-48h]
  boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> > a1a; // [rsp+8h] [rbp-40h] BYREF
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<long>,boost::_bi::value<int> > v13; // [rsp+18h] [rbp-30h] BYREF

  a1a.t_.px = *(boost::weak_ptr<RBX::LocalizationService>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  a1a.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->weak_count_, 1u);
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::LocalizationService>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<long>,boost::_bi::value<int>>::list5(
    &v13,
    (boost::_bi::value<boost::weak_ptr<RBX::LocalizationService> >)__PAIR128__((unsigned __int64)a1.pn.pi_, &a1a),
    a2,
    (boost::arg<2>)a2.gap0,
    a3,
    v11);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v13.a1_.t_.px;
  pi = v13.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v13.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->weak_count_, 1u);
    v8 = v13.a1_.t_.pn.pi_;
  }
  else
  {
    v8 = 0;
  }
  retstr->l_.a4_.t_ = v13.a4_.t_;
  retstr->l_.a5_.t_ = v13.a5_.t_;
  if ( v8 && !_InterlockedSub(&v8->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
  v9 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ && !_InterlockedSub(&a1a.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
  return retstr;
}


// Address: 0x1587550 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_8functionIFvvEEES4_NS_3argILi1EEESE_EENS_3_bi6bind_tIT_PFSJ_T0_T1_T2_ENSH_9list_av_3IT3_T4_T5_E4typeEEESO_SQ_SR_SS_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void ()>),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void ()> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void ()(void)>,boost::weak_ptr<RBX::DataModel>,boost::arg<1>,boost::function<void ()(void)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void ()>),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void ()> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, std::string, boost::function<void ()>),
        boost::weak_ptr<RBX::DataModel> a1,
        boost::arg<1> a2)
{
  boost::detail::sp_counted_base *v5; // rax
  int (**v6)(void); // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v10; // rdi
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v12; // rdi
  boost::_bi::value<boost::function<void ()> >_0 v14; // [rsp+0h] [rbp-78h] BYREF
  boost::_bi::value<boost::weak_ptr<RBX::DataModel> > a1a; // [rsp+20h] [rbp-58h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void ()> > > v16; // [rsp+30h] [rbp-48h] BYREF

  a1a.t_.px = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  a1a.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->weak_count_, 1u);
  v14.t_.vtable = 0;
  v6 = a1.pn.pi_->_vptr$sp_counted_base;
  if ( a1.pn.pi_->_vptr$sp_counted_base )
  {
    v14.t_.vtable = (boost::detail::function::vtable_base *)a1.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v6 & 1) != 0 )
      v14.t_.functor = *(boost::detail::function::function_buffer *)&a1.pn.pi_->use_count_;
    else
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v6 & 0xFFFFFFFFFFFFFFFELL))(
        &a1.pn.pi_->use_count_,
        &v14.t_.functor,
        0);
  }
  boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(void)>>>::list3(
    &v16,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(&v14, &a1a),
    (boost::arg<1>)a1.pn.pi_,
    v14);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v16.a1_.t_.px;
  pi = v16.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v16.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v16.a3_.t_.vtable;
  if ( v16.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v16.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v16.a3_.t_.functor;
LABEL_17:
      v16.a3_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v16.a3_.t_.functor,
      &retstr->l_.a3_.t_.functor,
      0);
    if ( v16.a3_.t_.vtable )
    {
      if ( ((__int64)v16.a3_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v16.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v16.a3_.t_.functor, &v16.a3_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v10 = v16.a1_.t_.pn.pi_;
  if ( v16.a1_.t_.pn.pi_ && !_InterlockedSub(&v16.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
  if ( v14.t_.vtable )
  {
    if ( ((__int64)v14.t_.vtable & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v14.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14.t_.functor, &v14.t_.functor, 2);
    }
    v14.t_.vtable = 0;
  }
  v12 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ && !_InterlockedSub(&a1a.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
  return retstr;
}


// Address: 0x1587aa0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_8functionIFvSB_EEES4_NS_3argILi1EEESE_EENS_3_bi6bind_tIT_PFSJ_T0_T1_T2_ENSH_9list_av_3IT3_T4_T5_E4typeEEESO_SQ_SR_SS_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void (std::string)>),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::DataModel>,boost::arg<1>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void (std::string)>),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, std::string, boost::function<void (std::string)>),
        boost::weak_ptr<RBX::DataModel> a1,
        boost::arg<1> a2)
{
  boost::detail::sp_counted_base *v5; // rax
  int (**v6)(void); // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v10; // rdi
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v12; // rdi
  boost::_bi::value<boost::function<void (std::string)> >_0 v14; // [rsp+0h] [rbp-78h] BYREF
  boost::_bi::value<boost::weak_ptr<RBX::DataModel> > a1a; // [rsp+20h] [rbp-58h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > v16; // [rsp+30h] [rbp-48h] BYREF

  a1a.t_.px = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  a1a.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->weak_count_, 1u);
  v14.t_.vtable = 0;
  v6 = a1.pn.pi_->_vptr$sp_counted_base;
  if ( a1.pn.pi_->_vptr$sp_counted_base )
  {
    v14.t_.vtable = (boost::detail::function::vtable_base *)a1.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v6 & 1) != 0 )
      v14.t_.functor = *(boost::detail::function::function_buffer *)&a1.pn.pi_->use_count_;
    else
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v6 & 0xFFFFFFFFFFFFFFFELL))(
        &a1.pn.pi_->use_count_,
        &v14.t_.functor,
        0);
  }
  boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>>::list3(
    &v16,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(&v14, &a1a),
    (boost::arg<1>)a1.pn.pi_,
    v14);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v16.a1_.t_.px;
  pi = v16.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v16.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v16.a3_.t_.vtable;
  if ( v16.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v16.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v16.a3_.t_.functor;
LABEL_17:
      v16.a3_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v16.a3_.t_.functor,
      &retstr->l_.a3_.t_.functor,
      0);
    if ( v16.a3_.t_.vtable )
    {
      if ( ((__int64)v16.a3_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v16.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v16.a3_.t_.functor, &v16.a3_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v10 = v16.a1_.t_.pn.pi_;
  if ( v16.a1_.t_.pn.pi_ && !_InterlockedSub(&v16.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
  if ( v14.t_.vtable )
  {
    if ( ((__int64)v14.t_.vtable & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v14.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14.t_.functor, &v14.t_.functor, 2);
    }
    v14.t_.vtable = 0;
  }
  v12 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ && !_InterlockedSub(&a1a.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
  return retstr;
}


// Address: 0x15880a0 | Name: _ZN5boost4bindIvPN3RBX9DataModelENS_10shared_ptrIKNS1_13TaskScheduler3JobEEERNSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEEdPdS3_NS_3argILi1EEESF_dSH_EENS_3_bi6bind_tIT_PFSM_T0_T1_T2_T3_T4_ENSK_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEST_SV_SW_SX_SY_SZ_
__int64 __fastcall boost::bind<void,RBX::DataModel *,boost::shared_ptr<RBX::TaskScheduler::Job const>,std::string &,double,double *,RBX::DataModel *,boost::arg<1>,std::string,double,double *>(
        __int64 a1,
        __int64 a2,
        int a3,
        __int64 a4,
        int a5)
{
  int v7; // r8d
  int v8; // r9d
  _BYTE v10[16]; // [rsp+10h] [rbp-88h] BYREF
  void *ptr; // [rsp+20h] [rbp-78h]
  _BYTE v12[16]; // [rsp+28h] [rbp-70h] BYREF
  void *v13; // [rsp+38h] [rbp-60h]
  __int64 v14; // [rsp+40h] [rbp-58h] BYREF
  _BYTE v15[16]; // [rsp+48h] [rbp-50h] BYREF
  void *v16; // [rsp+58h] [rbp-40h]
  __int128 v17; // [rsp+60h] [rbp-38h]

  std::string::basic_string(v12, a4);
  std::string::basic_string(v10, v12);
  boost::_bi::storage5<boost::_bi::value<RBX::DataModel *>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<double>,boost::_bi::value<double *>>::storage5(
    (unsigned int)&v14,
    a3,
    (unsigned int)v10,
    a5,
    v7,
    v8);
  if ( (v10[0] & 1) != 0 )
    operator delete(ptr);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = v14;
  std::string::basic_string(a1 + 16, v15);
  *(_OWORD *)(a1 + 40) = v17;
  if ( (v15[0] & 1) != 0 )
    operator delete(v16);
  if ( (v12[0] & 1) != 0 )
    operator delete(v13);
  return a1;
}


// Address: 0x158cea0 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEENS_10shared_ptrIKNSt3__16vectorINS7_INS2_8InstanceEEENS8_9allocatorISB_EEEEEES6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSL_T0_T1_ENSJ_9list_av_2IT2_T3_E4typeEEESP_SR_SS_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>_0, boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x15938a0 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX9DataModel10LegacyLock14Implementation6EventsEEES7_EENS_3_bi6bind_tIT_PFSA_T0_ENS8_9list_av_1IT1_E4typeEEESD_SF_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>),boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events> > > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>,boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>),boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events> > > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>),
        boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events> a1)
{
  boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>::element_type *v3; // r12
  boost::detail::sp_counted_base *align; // rbx

  v3 = *(boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>::element_type **)&a1.px->acquiredLock.manualReset;
  align = (boost::detail::sp_counted_base *)a1.px->acquiredLock.cond.internal_mutex.__align;
  if ( align )
  {
    _InterlockedAdd(&align->use_count_, 1u);
    _InterlockedAdd(&align->use_count_, 1u);
    _InterlockedAdd(&align->use_count_, 1u);
    if ( !_InterlockedSub(&align->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>), boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>::element_type *, boost::detail::sp_counted_base *))align->_vptr$sp_counted_base
       + 2))(
        align,
        f,
        a1.px,
        a1.pn.pi_);
      if ( !_InterlockedSub(&align->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))align->_vptr$sp_counted_base + 3))(align);
    }
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v3;
    retstr->l_.a1_.t_.pn.pi_ = align;
    _InterlockedAdd(&align->use_count_, 1u);
    if ( !_InterlockedSub(&align->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>), boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>::element_type *, boost::detail::sp_counted_base *))align->_vptr$sp_counted_base
       + 2))(
        align,
        f,
        a1.px,
        a1.pn.pi_);
      if ( !_InterlockedSub(&align->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))align->_vptr$sp_counted_base + 3))(align);
    }
    if ( !_InterlockedSub(&align->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>), boost::shared_ptr<RBX::DataModel::LegacyLock::Implementation::Events>::element_type *, boost::detail::sp_counted_base *))align->_vptr$sp_counted_base
       + 2))(
        align,
        f,
        a1.px,
        a1.pn.pi_);
      if ( !_InterlockedSub(&align->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))align->_vptr$sp_counted_base + 3))(align);
    }
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v3;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x159a330 | Name: _ZN5boost4bindIvNS_10shared_ptrINS_8functionIFvNS1_IKN3RBX10Reflection5TupleEEENS2_IFvS7_EEENS2_IFvNSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEEEEEEEEEES9_SI_SL_NS_3argILi1EEENSM_ILi2EEEEENS_3_bi6bind_tIT_PFSR_T0_T1_T2_ENSP_9list_av_3IT3_T4_T5_E4typeEEESW_SY_SZ_S10_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2> > > *__fastcall boost::bind<void,boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>,boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>,boost::arg<1>,boost::arg<2>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2> > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >, boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>_0, boost::function<void (std::string)>_0),
        boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > a1,
        boost::arg<1> a2,
        boost::arg<2> a3)
{
  boost::detail::sp_counted_base *obj_ptr; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v7; // rbx
  boost::detail::sp_counted_base *v8; // rbx
  boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > > a1a; // [rsp+8h] [rbp-30h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2> > v11; // [rsp+18h] [rbp-20h] BYREF

  a1a.t_.px = (boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >::element_type *)a1.px->vtable;
  obj_ptr = (boost::detail::sp_counted_base *)a1.px->functor.obj_ptr;
  a1a.t_.pn.pi_ = obj_ptr;
  if ( obj_ptr )
    _InterlockedAdd(&obj_ptr->use_count_, 1u);
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>>,boost::arg<1>,boost::arg<2>>::list3(
    &v11,
    (boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >)__PAIR128__((unsigned __int64)a1.px, &a1a),
    (boost::arg<1>)a1.pn.pi_,
    (boost::arg<2>)a2.gap0);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v11.a1_.t_.px;
  pi = v11.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v11.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v7 = v11.a1_.t_.pn.pi_;
    if ( v11.a1_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v11.a1_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
  }
  v8 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
  }
  return retstr;
}


// Address: 0x15dc580 | Name: _ZN5boost4bindIvN3RBX16DataStoreService11HttpRequestEPNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEPSt9exceptionS3_NS_3argILi1EEENSE_ILi2EEEEENS_3_bi6bind_tIT_PFSJ_T0_T1_T2_ENSH_9list_av_3IT3_T4_T5_E4typeEEESO_SQ_SR_SS_
_QWORD *__fastcall boost::bind<void,RBX::DataStoreService::HttpRequest,std::string *,std::exception *,RBX::DataStoreService::HttpRequest,boost::arg<1>,boost::arg<2>>(
        _QWORD *a1,
        __int64 a2,
        const RBX::DataStoreService::HttpRequest *a3)
{
  _BYTE v4[152]; // [rsp+8h] [rbp-1E0h] BYREF
  _BYTE v5[152]; // [rsp+A0h] [rbp-148h] BYREF
  _BYTE v6[176]; // [rsp+138h] [rbp-B0h] BYREF

  RBX::DataStoreService::HttpRequest::HttpRequest((RBX::DataStoreService::HttpRequest *)v6, a3);
  RBX::DataStoreService::HttpRequest::HttpRequest(
    (RBX::DataStoreService::HttpRequest *)v5,
    (const RBX::DataStoreService::HttpRequest *)v6);
  boost::_bi::storage3<boost::_bi::value<RBX::DataStoreService::HttpRequest>,boost::arg<1>,boost::arg<2>>::storage3((RBX::DataStoreService::HttpRequest *)v4);
  RBX::DataStoreService::HttpRequest::~HttpRequest((RBX::DataStoreService::HttpRequest *)v5);
  *a1 = a2;
  RBX::DataStoreService::HttpRequest::HttpRequest(
    (RBX::DataStoreService::HttpRequest *)(a1 + 1),
    (const RBX::DataStoreService::HttpRequest *)v4);
  RBX::DataStoreService::HttpRequest::~HttpRequest((RBX::DataStoreService::HttpRequest *)v4);
  RBX::DataStoreService::HttpRequest::~HttpRequest((RBX::DataStoreService::HttpRequest *)v6);
  return a1;
}


// Address: 0x160c730 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEES4_S6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSB_T0_T1_ENS9_9list_av_2IT2_T3_E4typeEEESF_SH_SI_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,RBX::Reflection::Variant),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,RBX::Reflection::Variant,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,RBX::Reflection::Variant),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>_0, RBX::Reflection::Variant),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x17a9900 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9GuiObjectEEENS2_3Lua15WeakFunctionRefENS2_9TweenInfo11TweenStatusES4_S6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSD_T0_T1_T2_ENSB_9list_av_3IT3_T4_T5_E4typeEEESI_SK_SL_SM_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef,RBX::TweenInfo::TweenStatus),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >,boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef,RBX::TweenInfo::TweenStatus,boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef,RBX::TweenInfo::TweenStatus),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >,boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::GuiObject>, RBX::Lua::WeakFunctionRef, RBX::TweenInfo::TweenStatus),
        boost::weak_ptr<RBX::GuiObject> a1,
        boost::arg<1> a3)
{
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  boost::arg<1> v6; // cl
  RBX::Lua::WeakThreadRef *next; // rax
  RBX::Lua::WeakThreadRef *v8; // rdi
  __int64 v9; // rdi
  boost::_bi::value<RBX::Lua::WeakFunctionRef> v11; // [rsp+0h] [rbp-A8h] BYREF
  RBX::Lua::WeakFunctionRef a1a; // [rsp+58h] [rbp-50h] BYREF

  v11.t_._vptr$WeakThreadRef = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  *(_QWORD *)&v11.t_.refs.v = px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->weak_this_.px + 1, 1u);
  RBX::Lua::WeakFunctionRef::WeakFunctionRef(&a1a, (const RBX::Lua::WeakFunctionRef *)a1.pn.pi_);
  boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::GuiObject>>,boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1>>::list3(
    (boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >,boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::arg<1> > *)&v11.t_.previous,
    (boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >)__PAIR128__(&a1a, &v11),
    v11,
    v6);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::GuiObject>::element_type *)v11.t_.previous;
  next = v11.t_.next;
  retstr->l_.a1_.t_.pn.pi_ = (boost::detail::sp_counted_base *)v11.t_.next;
  if ( next )
    _InterlockedAdd((volatile signed __int32 *)&next->rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef> + 1, 1u);
  RBX::Lua::WeakFunctionRef::WeakFunctionRef(
    &retstr->l_.a2_.t_,
    (const RBX::Lua::WeakFunctionRef *)&v11.t_.liveThreadRef);
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef((RBX::Lua::WeakFunctionRef *)&v11.t_.liveThreadRef);
  v8 = v11.t_.next;
  if ( v11.t_.next
    && !_InterlockedSub(
          (volatile signed __int32 *)&v11.t_.next->rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef> + 1,
          1u) )
  {
    (*((void (__fastcall **)(RBX::Lua::WeakThreadRef *))v8->_vptr$WeakThreadRef + 3))(v8);
  }
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef(&a1a);
  v9 = *(_QWORD *)&v11.t_.refs.v;
  if ( *(_QWORD *)&v11.t_.refs.v && !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v11.t_.refs.v + 12LL), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v9 + 24LL))(v9);
  return retstr;
}


// Address: 0x17a9c00 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9GuiObjectEEENS2_3Lua15WeakFunctionRefES4_S6_EENS_3_bi6bind_tIT_PFS9_T0_T1_ENS7_9list_av_2IT2_T3_E4typeEEESD_SF_SG_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >,boost::_bi::value<RBX::Lua::WeakFunctionRef> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef,boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >,boost::_bi::value<RBX::Lua::WeakFunctionRef> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::GuiObject>, RBX::Lua::WeakFunctionRef),
        boost::weak_ptr<RBX::GuiObject> a1)
{
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  RBX::Lua::WeakThreadRef *next; // rax
  RBX::Lua::WeakThreadRef *v6; // rdi
  __int64 v7; // rdi
  boost::_bi::value<RBX::Lua::WeakFunctionRef> v9; // [rsp+0h] [rbp-A8h] BYREF
  RBX::Lua::WeakFunctionRef a1a; // [rsp+58h] [rbp-50h] BYREF

  v9.t_._vptr$WeakThreadRef = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  *(_QWORD *)&v9.t_.refs.v = px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->weak_this_.px + 1, 1u);
  RBX::Lua::WeakFunctionRef::WeakFunctionRef(&a1a, (const RBX::Lua::WeakFunctionRef *)a1.pn.pi_);
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::GuiObject>>,boost::_bi::value<RBX::Lua::WeakFunctionRef>>::list2(
    (boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >,boost::_bi::value<RBX::Lua::WeakFunctionRef> > *)&v9.t_.previous,
    (boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >)__PAIR128__(&a1a, &v9),
    v9);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::GuiObject>::element_type *)v9.t_.previous;
  next = v9.t_.next;
  retstr->l_.a1_.t_.pn.pi_ = (boost::detail::sp_counted_base *)v9.t_.next;
  if ( next )
    _InterlockedAdd((volatile signed __int32 *)&next->rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef> + 1, 1u);
  RBX::Lua::WeakFunctionRef::WeakFunctionRef(
    &retstr->l_.a2_.t_,
    (const RBX::Lua::WeakFunctionRef *)&v9.t_.liveThreadRef);
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef((RBX::Lua::WeakFunctionRef *)&v9.t_.liveThreadRef);
  v6 = v9.t_.next;
  if ( v9.t_.next
    && !_InterlockedSub(
          (volatile signed __int32 *)&v9.t_.next->rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef> + 1,
          1u) )
  {
    (*((void (__fastcall **)(RBX::Lua::WeakThreadRef *))v6->_vptr$WeakThreadRef + 3))(v6);
  }
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef(&a1a);
  v7 = *(_QWORD *)&v9.t_.refs.v;
  if ( *(_QWORD *)&v9.t_.refs.v && !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v9.t_.refs.v + 12LL), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v7 + 24LL))(v7);
  return retstr;
}


// Address: 0x17ca570 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9GuiObjectEEENS2_3Lua15WeakFunctionRefEbS4_S6_bEENS_3_bi6bind_tIT_PFS9_T0_T1_T2_ENS7_9list_av_3IT3_T4_T5_E4typeEEESE_SG_SH_SI_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef,bool),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >,boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::_bi::value<bool> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef,bool,boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef,bool>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::GuiObject>,RBX::Lua::WeakFunctionRef,bool),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >,boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::_bi::value<bool> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::GuiObject>, RBX::Lua::WeakFunctionRef, bool),
        boost::weak_ptr<RBX::GuiObject> a1,
        boost::_bi::value<bool> a3)
{
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  RBX::Lua::WeakThreadRef *next; // rax
  RBX::Lua::WeakThreadRef *v8; // rdi
  __int64 v9; // rdi
  boost::_bi::value<RBX::Lua::WeakFunctionRef> v11; // [rsp+0h] [rbp-B8h] BYREF
  bool v12; // [rsp+58h] [rbp-60h]
  RBX::Lua::WeakFunctionRef a1a; // [rsp+60h] [rbp-58h] BYREF

  v11.t_._vptr$WeakThreadRef = a1.px->_vptr$EventSource;
  px = a1.px->weak_this_.px;
  *(_QWORD *)&v11.t_.refs.v = px;
  if ( px )
    _InterlockedAdd((volatile signed __int32 *)&px->weak_this_.px + 1, 1u);
  RBX::Lua::WeakFunctionRef::WeakFunctionRef(&a1a, (const RBX::Lua::WeakFunctionRef *)a1.pn.pi_);
  boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::GuiObject>>,boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::_bi::value<bool>>::list3(
    (boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >,boost::_bi::value<RBX::Lua::WeakFunctionRef>,boost::_bi::value<bool> > *)&v11.t_.previous,
    (boost::_bi::value<boost::weak_ptr<RBX::GuiObject> >)__PAIR128__(&a1a, &v11),
    v11,
    a3);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::GuiObject>::element_type *)v11.t_.previous;
  next = v11.t_.next;
  retstr->l_.a1_.t_.pn.pi_ = (boost::detail::sp_counted_base *)v11.t_.next;
  if ( next )
    _InterlockedAdd((volatile signed __int32 *)&next->rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef> + 1, 1u);
  RBX::Lua::WeakFunctionRef::WeakFunctionRef(
    &retstr->l_.a2_.t_,
    (const RBX::Lua::WeakFunctionRef *)&v11.t_.liveThreadRef);
  retstr->l_.a3_.t_ = v12;
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef((RBX::Lua::WeakFunctionRef *)&v11.t_.liveThreadRef);
  v8 = v11.t_.next;
  if ( v11.t_.next
    && !_InterlockedSub(
          (volatile signed __int32 *)&v11.t_.next->rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef> + 1,
          1u) )
  {
    (*((void (__fastcall **)(RBX::Lua::WeakThreadRef *))v8->_vptr$WeakThreadRef + 3))(v8);
  }
  RBX::Lua::WeakFunctionRef::~WeakFunctionRef(&a1a);
  v9 = *(_QWORD *)&v11.t_.refs.v;
  if ( *(_QWORD *)&v11.t_.refs.v && !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v11.t_.refs.v + 12LL), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v9 + 24LL))(v9);
  return retstr;
}


// Address: 0x17d35e0 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEEN3G3D7Vector2ES6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSD_T0_T1_ENSB_9list_av_2IT2_T3_E4typeEEESH_SJ_SK_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,G3D::Vector2),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > >_0 *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,G3D::Vector2,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,G3D::Vector2),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > >_0 *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>_0, G3D::Vector2),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x17d87e0 | Name: _ZN5boost4bindIvNS_10shared_ptrINS_8functionIFvNS1_IKN3RBX10Reflection5TupleEEENS2_IFvS7_EEENS2_IFvNSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEEEEEEEEEESG_SG_S9_SI_SL_NS_3argILi1EEENSM_ILi2EEENSM_ILi3EEENSM_ILi4EEEEENS_3_bi6bind_tIT_PFST_T0_T1_T2_T3_T4_ENSR_9list_av_5IT5_T6_T7_T8_T9_E4typeEEES10_S12_S13_S14_S15_S16_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >,std::string,std::string,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>),boost::_bi::list5<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > > *__fastcall boost::bind<void,boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>,std::string,std::string,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>,boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >,std::string,std::string,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>),boost::_bi::list5<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >, std::string, std::string, boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>, boost::function<void (std::string)>),
        boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > a1,
        boost::arg<1> a2,
        boost::arg<2> a3)
{
  boost::detail::sp_counted_base *obj_ptr; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v7; // rbx
  boost::detail::sp_counted_base *v8; // rbx
  boost::arg<4> v10; // [rsp+0h] [rbp-38h]
  boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > > a1a; // [rsp+8h] [rbp-30h] BYREF
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > v12; // [rsp+18h] [rbp-20h] BYREF

  a1a.t_.px = (boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >::element_type *)a1.px->vtable;
  obj_ptr = (boost::detail::sp_counted_base *)a1.px->functor.obj_ptr;
  a1a.t_.pn.pi_ = obj_ptr;
  if ( obj_ptr )
    _InterlockedAdd(&obj_ptr->use_count_, 1u);
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>>::list5(
    &v12,
    (boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >)__PAIR128__((unsigned __int64)a1.px, &a1a),
    (boost::arg<1>)a1.pn.pi_,
    (boost::arg<2>)a2.gap0,
    (boost::arg<3>)a3.gap0,
    v10);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v12.a1_.t_.px;
  pi = v12.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v12.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v7 = v12.a1_.t_.pn.pi_;
    if ( v12.a1_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v12.a1_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
  }
  v8 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
  }
  return retstr;
}


// Address: 0x183a3d0 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX17HttpRbxApiServiceEEENS3_14HttpApiRequestENS_8functionIFvNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEEEEES4_S5_SF_EENS_3_bi6bind_tIT_PFSI_T0_T1_T2_ENSG_9list_av_3IT3_T4_T5_E4typeEEESN_SP_SQ_SR_
_QWORD *__fastcall boost::bind<void,boost::shared_ptr<RBX::HttpRbxApiService>,RBX::HttpRbxApiService::HttpApiRequest,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::HttpRbxApiService>,RBX::HttpRbxApiService::HttpApiRequest,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        const RBX::HttpRbxApiService::HttpApiRequest *a4,
        __int64 *a5)
{
  volatile signed __int32 *v6; // rax
  __int64 v7; // rax
  void (__fastcall *v8)(_BYTE *, _BYTE *, __int64); // rax
  volatile signed __int32 *v9; // rbx
  void (__fastcall *v10)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v11; // rbx
  __int64 v13; // [rsp+0h] [rbp-2F8h] BYREF
  __int128 v14; // [rsp+8h] [rbp-2F0h] BYREF
  __int64 v15; // [rsp+18h] [rbp-2E0h]
  __int64 v16; // [rsp+20h] [rbp-2D8h] BYREF
  volatile signed __int32 *v17; // [rsp+28h] [rbp-2D0h]
  char v18[8]; // [rsp+30h] [rbp-2C8h] BYREF
  volatile signed __int32 *v19; // [rsp+38h] [rbp-2C0h]
  char v20[320]; // [rsp+40h] [rbp-2B8h] BYREF
  __int64 v21; // [rsp+180h] [rbp-178h]
  _BYTE v22[24]; // [rsp+188h] [rbp-170h] BYREF
  _BYTE v23[344]; // [rsp+1A0h] [rbp-158h] BYREF

  v16 = *a3;
  v6 = (volatile signed __int32 *)a3[1];
  v17 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  RBX::HttpRbxApiService::HttpApiRequest::HttpApiRequest((RBX::HttpRbxApiService::HttpApiRequest *)v23, a4);
  v13 = 0;
  v7 = *a5;
  if ( *a5 )
  {
    v13 = *a5;
    if ( (v7 & 1) != 0 )
    {
      v15 = a5[3];
      v14 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v14, 0);
    }
  }
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::HttpRbxApiService>>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<boost::function<void ()(std::string)>>>::list3(
    v18,
    &v16,
    v23,
    &v13);
  *a1 = a2;
  boost::_bi::storage3<boost::_bi::value<boost::shared_ptr<RBX::HttpRbxApiService>>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage3(
    (boost::_bi::storage3<boost::_bi::value<boost::shared_ptr<RBX::HttpRbxApiService> >,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::storage3<boost::_bi::value<boost::shared_ptr<RBX::HttpRbxApiService> >,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<boost::function<void (std::string)> > > *)v18);
  if ( v21 )
  {
    if ( (v21 & 1) == 0 )
    {
      v8 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v21 & 0xFFFFFFFFFFFFFFFELL);
      if ( v8 )
        v8(v22, v22, 2);
    }
    v21 = 0;
  }
  RBX::HttpRbxApiService::HttpApiRequest::~HttpApiRequest((RBX::HttpRbxApiService::HttpApiRequest *)v20);
  v9 = v19;
  if ( v19 )
  {
    if ( !_InterlockedSub(v19 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
      if ( !_InterlockedSub(v9 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
    }
  }
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v14, &v14, 2);
    }
    v13 = 0;
  }
  RBX::HttpRbxApiService::HttpApiRequest::~HttpApiRequest((RBX::HttpRbxApiService::HttpApiRequest *)v23);
  v11 = v17;
  if ( v17 )
  {
    if ( !_InterlockedSub(v17 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
  return a1;
}


// Address: 0x183a920 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX17HttpRbxApiServiceEEENS1_INSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEEENS1_ISt9exceptionEENS3_14HttpApiRequestENS_8functionIFvSB_EEESI_S4_NS_3argILi1EEENSJ_ILi2EEESF_SI_SI_EENS_3_bi6bind_tIT_PFSO_T0_T1_T2_T3_T4_T5_ENSM_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEESW_SY_SZ_S10_S11_S12_S13_
__int64 __fastcall boost::bind<void,boost::shared_ptr<RBX::HttpRbxApiService>,boost::shared_ptr<std::string>,boost::shared_ptr<std::exception>,RBX::HttpRbxApiService::HttpApiRequest,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::HttpRbxApiService>,boost::arg<1>,boost::arg<2>,RBX::HttpRbxApiService::HttpApiRequest,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        const RBX::HttpRbxApiService::HttpApiRequest *a4,
        __int64 *a5,
        __int64 *a6)
{
  volatile signed __int32 *v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  void (__fastcall *v12)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v14; // rbx
  __int64 v16; // [rsp+8h] [rbp-340h] BYREF
  __int128 v17; // [rsp+10h] [rbp-338h] BYREF
  __int64 v18; // [rsp+20h] [rbp-328h]
  __int64 v19; // [rsp+28h] [rbp-320h] BYREF
  __int128 v20; // [rsp+30h] [rbp-318h] BYREF
  __int64 v21; // [rsp+40h] [rbp-308h]
  __int64 v22; // [rsp+48h] [rbp-300h] BYREF
  volatile signed __int32 *v23; // [rsp+50h] [rbp-2F8h]
  _BYTE v24[368]; // [rsp+58h] [rbp-2F0h] BYREF
  __int64 v25; // [rsp+1C8h] [rbp-180h]
  __int128 v26; // [rsp+1D0h] [rbp-178h] BYREF
  __int64 v27; // [rsp+1E0h] [rbp-168h]
  _BYTE v28[352]; // [rsp+1E8h] [rbp-160h] BYREF

  v22 = *a3;
  v8 = (volatile signed __int32 *)a3[1];
  v23 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  RBX::HttpRbxApiService::HttpApiRequest::HttpApiRequest((RBX::HttpRbxApiService::HttpApiRequest *)v28, a4);
  v19 = 0;
  v9 = *a5;
  if ( *a5 )
  {
    v19 = *a5;
    if ( (v9 & 1) != 0 )
    {
      v21 = a5[3];
      v20 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v20, 0);
    }
  }
  v16 = 0;
  v10 = *a6;
  if ( *a6 )
  {
    v16 = *a6;
    if ( (v10 & 1) != 0 )
    {
      v18 = a6[3];
      v17 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v17, 0);
    }
  }
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::HttpRbxApiService>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list6(
    v24,
    &v22,
    v28,
    &v19,
    &v16);
  *(_QWORD *)a1 = a2;
  boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::HttpRbxApiService>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage5(
    (boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::HttpRbxApiService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 8),
    (const boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::HttpRbxApiService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<boost::function<void (std::string)> > > *)v24);
  *(_QWORD *)(a1 + 376) = 0;
  v11 = v25;
  if ( v25 )
  {
    *(_QWORD *)(a1 + 376) = v25;
    if ( (v11 & 1) != 0 )
    {
      *(_QWORD *)(a1 + 400) = v27;
      *(_OWORD *)(a1 + 384) = v26;
    }
    else
    {
      (*(void (__fastcall **)(__int128 *, __int64, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(&v26, a1 + 384, 0);
    }
  }
  boost::_bi::storage6<boost::_bi::value<boost::shared_ptr<RBX::HttpRbxApiService>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage6((boost::_bi::storage6<boost::_bi::value<boost::shared_ptr<RBX::HttpRbxApiService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v24);
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( v19 )
  {
    if ( (v19 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v19 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v20, &v20, 2);
    }
    v19 = 0;
  }
  RBX::HttpRbxApiService::HttpApiRequest::~HttpApiRequest((RBX::HttpRbxApiService::HttpApiRequest *)v28);
  v14 = v23;
  if ( v23 )
  {
    if ( !_InterlockedSub(v23 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
      if ( !_InterlockedSub(v14 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
    }
  }
  return a1;
}


// Address: 0x183af50 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX17HttpRbxApiServiceEEEPNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEPSt9exceptionNS3_14HttpApiRequestENS2_18ThrottlingPriorityENS_8functionIFvSB_EEESJ_S4_NS_3argILi1EEENSK_ILi2EEESF_SG_SJ_SJ_EENS_3_bi6bind_tIT_PFSP_T0_T1_T2_T3_T4_T5_T6_ENSN_9list_av_7IT7_T8_T9_T10_T11_T12_T13_E4typeEEESY_S10_S11_S12_S13_S14_S15_S16_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::HttpRbxApiService>,std::string *,std::exception *,RBX::HttpRbxApiService::HttpApiRequest,RBX::ThrottlingPriority,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::HttpRbxApiService>,boost::arg<1>,boost::arg<2>,RBX::HttpRbxApiService::HttpApiRequest,RBX::ThrottlingPriority,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        const RBX::HttpRbxApiService::HttpApiRequest *a4,
        unsigned int a5,
        __int64 *a6,
        __int64 *a7)
{
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  __int64 v15; // rdi
  __int64 v17; // [rsp+0h] [rbp-348h] BYREF
  __int128 v18; // [rsp+8h] [rbp-340h] BYREF
  __int64 v19; // [rsp+18h] [rbp-330h]
  __int64 v20; // [rsp+20h] [rbp-328h] BYREF
  __int128 v21; // [rsp+28h] [rbp-320h] BYREF
  __int64 v22; // [rsp+38h] [rbp-310h]
  __int64 v23; // [rsp+40h] [rbp-308h] BYREF
  __int64 v24; // [rsp+48h] [rbp-300h]
  _BYTE v25[320]; // [rsp+50h] [rbp-2F8h] BYREF
  _BYTE v26[440]; // [rsp+190h] [rbp-1B8h] BYREF

  v23 = *a3;
  v10 = a3[1];
  v24 = v10;
  if ( v10 )
    _InterlockedAdd((volatile signed __int32 *)(v10 + 12), 1u);
  RBX::HttpRbxApiService::HttpApiRequest::HttpApiRequest((RBX::HttpRbxApiService::HttpApiRequest *)v25, a4);
  v20 = 0;
  v11 = *a6;
  if ( *a6 )
  {
    v20 = *a6;
    if ( (v11 & 1) != 0 )
    {
      v22 = a6[3];
      v21 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v21, 0);
    }
  }
  v17 = 0;
  v12 = *a7;
  if ( *a7 )
  {
    v17 = *a7;
    if ( (v12 & 1) != 0 )
    {
      v19 = a7[3];
      v18 = *(_OWORD *)(a7 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(a7 + 1, &v18, 0);
    }
  }
  boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::HttpRbxApiService>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<RBX::ThrottlingPriority>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list7(
    v26,
    &v23,
    v25,
    a5,
    &v20,
    &v17);
  *a1 = a2;
  boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::HttpRbxApiService>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<RBX::ThrottlingPriority>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list7(
    (boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::HttpRbxApiService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<RBX::ThrottlingPriority>,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::list7<boost::_bi::value<boost::weak_ptr<RBX::HttpRbxApiService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<RBX::ThrottlingPriority>,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  boost::_bi::storage7<boost::_bi::value<boost::weak_ptr<RBX::HttpRbxApiService>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<RBX::ThrottlingPriority>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage7((boost::_bi::storage7<boost::_bi::value<boost::weak_ptr<RBX::HttpRbxApiService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::HttpRbxApiService::HttpApiRequest>,boost::_bi::value<RBX::ThrottlingPriority>,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v26);
  if ( v17 )
  {
    if ( (v17 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v17 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v18, &v18, 2);
    }
    v17 = 0;
  }
  if ( v20 )
  {
    if ( (v20 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v20 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v21, &v21, 2);
    }
    v20 = 0;
  }
  RBX::HttpRbxApiService::HttpApiRequest::~HttpApiRequest((RBX::HttpRbxApiService::HttpApiRequest *)v25);
  v15 = v24;
  if ( v24 && !_InterlockedSub((volatile signed __int32 *)(v24 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 24LL))(v15);
  return a1;
}


// Address: 0x1876ca0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX10LogServiceEEENS_10shared_ptrINS2_8InstanceEEES4_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSC_T0_T1_ENSA_9list_av_2IT2_T3_E4typeEEESG_SI_SJ_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LogService>,boost::shared_ptr<RBX::Instance>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::LogService>,boost::shared_ptr<RBX::Instance>,boost::weak_ptr<RBX::LogService>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LogService>,boost::shared_ptr<RBX::Instance>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::LogService>, boost::shared_ptr<RBX::Instance>),
        boost::weak_ptr<RBX::LogService> a1,
        __int64 a2)
{
  int (**v4)(void); // r12
  boost::detail::sp_counted_base *px; // rbx

  v4 = a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  if ( px )
  {
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LogService>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::LogService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LogService>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::LogService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::LogService>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = px;
    _InterlockedAdd(&px->weak_count_, 1u);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LogService>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::LogService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LogService>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::LogService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::LogService>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1876e30 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX10LogServiceEEEbS4_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFS9_T0_T1_ENS7_9list_av_2IT2_T3_E4typeEEESD_SF_SG_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LogService>,bool),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::LogService>,bool,boost::weak_ptr<RBX::LogService>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LogService>,bool),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::LogService>, bool),
        boost::weak_ptr<RBX::LogService> a1,
        __int64 a2)
{
  int (**v4)(void); // r12
  boost::detail::sp_counted_base *px; // rbx

  v4 = a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  if ( px )
  {
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LogService>, bool), boost::weak_ptr<RBX::LogService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LogService>, bool), boost::weak_ptr<RBX::LogService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::LogService>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = px;
    _InterlockedAdd(&px->weak_count_, 1u);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LogService>, bool), boost::weak_ptr<RBX::LogService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::LogService>, bool), boost::weak_ptr<RBX::LogService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::LogService>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x18772f0 | Name: _ZN5boost4bindIvN3RBX18StandardOutMessageENS_8weak_ptrINS1_10LogServiceEEES2_S5_EENS_3_bi6bind_tIT_PFS8_T0_T1_ENS6_9list_av_2IT2_T3_E4typeEEESC_SE_SF_
__int64 __fastcall boost::bind<void,RBX::StandardOutMessage,boost::weak_ptr<RBX::LogService>,RBX::StandardOutMessage,boost::weak_ptr<RBX::LogService>>(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        __int64 *a4)
{
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rdi
  __int64 v10; // rdi
  __int64 v12; // [rsp+8h] [rbp-C0h] BYREF
  __int64 v13; // [rsp+10h] [rbp-B8h]
  __int64 v14; // [rsp+18h] [rbp-B0h] BYREF
  _BYTE v15[16]; // [rsp+20h] [rbp-A8h] BYREF
  void *v16; // [rsp+30h] [rbp-98h]
  _BYTE v17[16]; // [rsp+38h] [rbp-90h] BYREF
  void *v18; // [rsp+48h] [rbp-80h]
  __int64 v19; // [rsp+50h] [rbp-78h]
  __int64 v20; // [rsp+58h] [rbp-70h] BYREF
  _BYTE v21[16]; // [rsp+60h] [rbp-68h] BYREF
  void *v22; // [rsp+70h] [rbp-58h]
  _BYTE v23[16]; // [rsp+78h] [rbp-50h] BYREF
  void *ptr; // [rsp+88h] [rbp-40h]
  __int128 v25; // [rsp+90h] [rbp-38h]
  __int64 v26; // [rsp+A0h] [rbp-28h]

  v14 = *a3;
  std::string::basic_string(v15, a3 + 1);
  std::string::basic_string(v17, a3 + 4);
  v19 = a3[7];
  v12 = *a4;
  v7 = a4[1];
  v13 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  boost::_bi::list2<boost::_bi::value<RBX::StandardOutMessage>,boost::_bi::value<boost::weak_ptr<RBX::LogService>>>::list2(
    &v20,
    &v14,
    &v12);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = v20;
  std::string::basic_string(a1 + 16, v21);
  std::string::basic_string(a1 + 40, v23);
  *(_OWORD *)(a1 + 64) = v25;
  v8 = v26;
  *(_QWORD *)(a1 + 80) = v26;
  if ( v8 )
  {
    _InterlockedAdd((volatile signed __int32 *)(v8 + 12), 1u);
    v9 = v26;
    if ( v26 )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(v26 + 12), 1u) )
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v9 + 24LL))(v9);
    }
  }
  if ( (v23[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v21[0] & 1) != 0 )
    operator delete(v22);
  v10 = v13;
  if ( v13 && !_InterlockedSub((volatile signed __int32 *)(v13 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v10 + 24LL))(v10);
  if ( (v17[0] & 1) != 0 )
    operator delete(v18);
  if ( (v15[0] & 1) != 0 )
    operator delete(v16);
  return a1;
}


// Address: 0x1877740 | Name: _ZN5boost4bindIvN3RBX10HttpResultENS_8weak_ptrINS1_10LogServiceEEES2_S5_EENS_3_bi6bind_tIT_PFS8_T0_T1_ENS6_9list_av_2IT2_T3_E4typeEEESC_SE_SF_
__int64 __fastcall boost::bind<void,RBX::HttpResult,boost::weak_ptr<RBX::LogService>,RBX::HttpResult,boost::weak_ptr<RBX::LogService>>(
        __int64 a1,
        __int64 a2,
        __int128 *a3,
        __int64 *a4)
{
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rdi
  __int64 v10; // rdi
  __int64 v12; // [rsp+0h] [rbp-D8h] BYREF
  __int64 v13; // [rsp+8h] [rbp-D0h]
  __int128 v14; // [rsp+10h] [rbp-C8h] BYREF
  __int64 v15; // [rsp+20h] [rbp-B8h]
  _BYTE v16[16]; // [rsp+28h] [rbp-B0h] BYREF
  void *v17; // [rsp+38h] [rbp-A0h]
  _BYTE v18[16]; // [rsp+40h] [rbp-98h] BYREF
  void *v19; // [rsp+50h] [rbp-88h]
  __int128 v20; // [rsp+60h] [rbp-78h] BYREF
  __int64 v21; // [rsp+70h] [rbp-68h]
  _BYTE v22[16]; // [rsp+78h] [rbp-60h] BYREF
  void *v23; // [rsp+88h] [rbp-50h]
  _BYTE v24[16]; // [rsp+90h] [rbp-48h] BYREF
  void *ptr; // [rsp+A0h] [rbp-38h]
  __int64 v26; // [rsp+A8h] [rbp-30h]
  __int64 v27; // [rsp+B0h] [rbp-28h]

  v15 = *((_QWORD *)a3 + 2);
  v14 = *a3;
  std::string::basic_string(v16, (char *)a3 + 24);
  std::string::basic_string(v18, a3 + 3);
  v12 = *a4;
  v7 = a4[1];
  v13 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  boost::_bi::list2<boost::_bi::value<RBX::HttpResult>,boost::_bi::value<boost::weak_ptr<RBX::LogService>>>::list2(
    &v20,
    &v14,
    &v12);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 24) = v21;
  *(_OWORD *)(a1 + 8) = v20;
  std::string::basic_string(a1 + 32, v22);
  std::string::basic_string(a1 + 56, v24);
  *(_QWORD *)(a1 + 80) = v26;
  v8 = v27;
  *(_QWORD *)(a1 + 88) = v27;
  if ( v8 )
  {
    _InterlockedAdd((volatile signed __int32 *)(v8 + 12), 1u);
    v9 = v27;
    if ( v27 )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(v27 + 12), 1u) )
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v9 + 24LL))(v9);
    }
  }
  if ( (v24[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v22[0] & 1) != 0 )
    operator delete(v23);
  v10 = v13;
  if ( v13 && !_InterlockedSub((volatile signed __int32 *)(v13 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v10 + 24LL))(v10);
  if ( (v18[0] & 1) != 0 )
    operator delete(v19);
  if ( (v16[0] & 1) != 0 )
    operator delete(v17);
  return a1;
}


// Address: 0x18780c0 | Name: _ZN5boost4bindIvNS_8functionIFvvEEENS_8weak_ptrIN3RBX10LogServiceEEEPNSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEEPSt9exceptionS3_S7_NS_3argILi1EEENSI_ILi2EEEEENS_3_bi6bind_tIT_PFSN_T0_T1_T2_T3_ENSL_9list_av_4IT4_T5_T6_T7_E4typeEEEST_SV_SW_SX_SY_
boost::_bi::bind_t<void,void (*)(boost::function<void ()>,boost::weak_ptr<RBX::LogService>,std::string *,std::exception *),boost::_bi::list4<boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::arg<1>,boost::arg<2> > > *__fastcall boost::bind<void,boost::function<void ()(void)>,boost::weak_ptr<RBX::LogService>,std::string *,std::exception *,boost::function<void ()(void)>,boost::weak_ptr<RBX::LogService>,boost::arg<1>,boost::arg<2>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void ()>,boost::weak_ptr<RBX::LogService>,std::string *,std::exception *),boost::_bi::list4<boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::arg<1>,boost::arg<2> > > *__return_ptr retstr,
        void (*f)(boost::function<void ()>_0, boost::weak_ptr<RBX::LogService>, std::string *, std::exception *),
        boost::weak_ptr<RBX::LogService> a2,
        __int64 a3,
        __int64 a4)
{
  boost::detail::sp_counted_base *pi; // rbx
  __int64 v7; // rax
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::sp_counted_base *v9; // rax
  boost::detail::sp_counted_base *v10; // rdi
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  __int64 v12; // rdi
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<void ()> >_0 v15; // [rsp+0h] [rbp-78h] BYREF
  int (**a2a)(void); // [rsp+20h] [rbp-58h] BYREF
  __int64 v17; // [rsp+28h] [rbp-50h]
  boost::_bi::list4<boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::arg<1>,boost::arg<2> > v18; // [rsp+30h] [rbp-48h] BYREF

  pi = a2.pn.pi_;
  v15.t_.vtable = 0;
  a2.pn.pi_ = (boost::detail::sp_counted_base *)a2.px->_vptr$EventSource;
  if ( a2.px->_vptr$EventSource )
  {
    v15.t_.vtable = (boost::detail::function::vtable_base *)a2.px->_vptr$EventSource;
    if ( ((__int64)a2.pn.pi_ & 1) != 0 )
    {
      a2.pn.pi_ = (boost::detail::sp_counted_base *)a2.px->descriptor;
      v15.t_.functor.bound_memfunc_ptr.obj_ptr = a2.pn.pi_;
      *(boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *)&v15.t_.functor.obj_ptr = a2.px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>;
    }
    else
    {
      (*(void (__fastcall **)(boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *, boost::detail::function::function_buffer *, _QWORD, unsigned __int64, __int64, __int64, boost::detail::function::vtable_base *))((unsigned __int64)a2.pn.pi_ & 0xFFFFFFFFFFFFFFFELL))(
        &a2.px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
        &v15.t_.functor,
        0,
        (unsigned __int64)a2.pn.pi_ & 0xFFFFFFFFFFFFFFFELL,
        a3,
        a4,
        v15.t_.vtable);
    }
  }
  a2a = pi->_vptr$sp_counted_base;
  v7 = *(_QWORD *)&pi->use_count_;
  v17 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  boost::_bi::list4<boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::weak_ptr<RBX::LogService>>,boost::arg<1>,boost::arg<2>>::list4(
    &v18,
    v15,
    (boost::_bi::value<boost::weak_ptr<RBX::LogService> >)__PAIR128__(&a2a, &v15),
    (boost::arg<1>)a2.pn.pi_,
    (boost::arg<2>)a3);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v18.a1_.t_.vtable;
  if ( v18.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v18.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      retstr->l_.a1_.t_.functor = v18.a1_.t_.functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v18.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
  }
  retstr->l_.a2_.t_.px = v18.a2_.t_.px;
  v9 = v18.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v18.a2_.t_.pn.pi_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->weak_count_, 1u);
    v10 = v18.a2_.t_.pn.pi_;
    if ( v18.a2_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v18.a2_.t_.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  if ( v18.a1_.t_.vtable )
  {
    if ( ((__int64)v18.a1_.t_.vtable & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v18.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v18.a1_.t_.functor, &v18.a1_.t_.functor, 2);
    }
    v18.a1_.t_.vtable = 0;
  }
  v12 = v17;
  if ( v17 && !_InterlockedSub((volatile signed __int32 *)(v17 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v12 + 24LL))(v12);
  if ( v15.t_.vtable )
  {
    if ( ((__int64)v15.t_.vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v15.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v15.t_.functor, &v15.t_.functor, 2);
    }
    v15.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x1878470 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX10LogServiceEEENS1_INS2_6PlayerEEES4_S6_EENS_3_bi6bind_tIT_PFS9_T0_T1_ENS7_9list_av_2IT2_T3_E4typeEEESD_SF_SG_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LogService>,boost::weak_ptr<RBX::Player>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::_bi::value<boost::weak_ptr<RBX::Player> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::LogService>,boost::weak_ptr<RBX::Player>,boost::weak_ptr<RBX::LogService>,boost::weak_ptr<RBX::Player>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::LogService>,boost::weak_ptr<RBX::Player>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::_bi::value<boost::weak_ptr<RBX::Player> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::LogService>, boost::weak_ptr<RBX::Player>),
        boost::weak_ptr<RBX::LogService> a1,
        boost::weak_ptr<RBX::Player> a2)
{
  boost::detail::sp_counted_base *px; // rax
  __int64 v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // rax
  boost::detail::sp_counted_base *v9; // rdi
  boost::detail::sp_counted_base *v10; // rdi
  __int64 v11; // rdi
  boost::detail::sp_counted_base *v12; // rdi
  int (**a1a)(void); // [rsp+8h] [rbp-50h] BYREF
  __int64 v15; // [rsp+10h] [rbp-48h]
  boost::_bi::value<boost::weak_ptr<RBX::LogService> > v16; // [rsp+18h] [rbp-40h] BYREF
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService> >,boost::_bi::value<boost::weak_ptr<RBX::Player> > > v17; // [rsp+28h] [rbp-30h] BYREF

  v16.t_.px = (boost::weak_ptr<RBX::LogService>::element_type *)a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  v16.t_.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->weak_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(_QWORD *)&a1.pn.pi_->use_count_;
  v15 = v6;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)(v6 + 12), 1u);
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService>>,boost::_bi::value<boost::weak_ptr<RBX::Player>>>::list2(
    &v17,
    (boost::_bi::value<boost::weak_ptr<RBX::LogService> >)__PAIR128__(&a1a, &v16),
    (boost::_bi::value<boost::weak_ptr<RBX::Player> >)__PAIR128__((unsigned __int64)a2.px, (unsigned __int64)a1.pn.pi_));
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v17.a1_.t_.px;
  pi = v17.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v17.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a2_.t_.px = v17.a2_.t_.px;
  v8 = v17.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v17.a2_.t_.pn.pi_;
  if ( v8 )
  {
    _InterlockedAdd(&v8->weak_count_, 1u);
    v9 = v17.a2_.t_.pn.pi_;
    if ( v17.a2_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v17.a2_.t_.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  v10 = v17.a1_.t_.pn.pi_;
  if ( v17.a1_.t_.pn.pi_ && !_InterlockedSub(&v17.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
  v11 = v15;
  if ( v15 && !_InterlockedSub((volatile signed __int32 *)(v15 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 24LL))(v11);
  v12 = v16.t_.pn.pi_;
  if ( v16.t_.pn.pi_ && !_InterlockedSub(&v16.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
  return retstr;
}


// Address: 0x1878750 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX10LogServiceEEENSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEES4_SB_EENS_3_bi6bind_tIT_PFSE_T0_T1_ENSC_9list_av_2IT2_T3_E4typeEEESI_SK_SL_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::LogService>,std::string,boost::weak_ptr<RBX::LogService>,std::string>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4)
{
  __int64 v5; // rax
  __int64 v6; // rax
  __int64 v7; // rdi
  __int64 v8; // rdi
  __int64 v10; // [rsp+8h] [rbp-60h] BYREF
  __int64 v11; // [rsp+10h] [rbp-58h]
  _BYTE v12[16]; // [rsp+18h] [rbp-50h] BYREF
  void *v13; // [rsp+28h] [rbp-40h]
  __int64 v14; // [rsp+30h] [rbp-38h] BYREF
  __int64 v15; // [rsp+38h] [rbp-30h]
  _BYTE v16[16]; // [rsp+40h] [rbp-28h] BYREF
  void *ptr; // [rsp+50h] [rbp-18h]

  v10 = *a3;
  v5 = a3[1];
  v11 = v5;
  if ( v5 )
    _InterlockedAdd((volatile signed __int32 *)(v5 + 12), 1u);
  std::string::basic_string(v12, a4);
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::LogService>>,boost::_bi::value<std::string>>::list2(
    &v14,
    &v10,
    v12);
  *a1 = a2;
  a1[1] = v14;
  v6 = v15;
  a1[2] = v15;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)(v6 + 12), 1u);
  std::string::basic_string(a1 + 3, v16);
  if ( (v16[0] & 1) != 0 )
    operator delete(ptr);
  v7 = v15;
  if ( v15 && !_InterlockedSub((volatile signed __int32 *)(v15 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v7 + 24LL))(v7);
  if ( (v12[0] & 1) != 0 )
    operator delete(v13);
  v8 = v11;
  if ( v11 && !_InterlockedSub((volatile signed __int32 *)(v11 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 24LL))(v8);
  return a1;
}


// Address: 0x18a1480 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENSt3__16vectorINS2_10Reflection7VariantENS5_9allocatorIS8_EEEENS2_13SystemAddressEbbS4_SB_SC_bNS_3argILi1EEEEENS_3_bi6bind_tIT_PFSH_T0_T1_T2_T3_T4_ENSF_9list_av_5IT5_T6_T7_T8_T9_E4typeEEESO_SQ_SR_SS_ST_SU_
__int64 __fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,std::vector<RBX::Reflection::Variant>,RBX::SystemAddress,bool,bool,boost::weak_ptr<RBX::DataModel>,std::vector<RBX::Reflection::Variant>,RBX::SystemAddress,bool,boost::arg<1>>(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        const std::vector<RBX::Reflection::Variant> *a4,
        __int64 a5,
        unsigned __int8 a6)
{
  __int64 v9; // rax
  __int64 v10; // rax
  char *v11; // rbp
  char *v12; // rbx
  __int64 v13; // rax
  void *v14; // rdi
  __int64 v15; // rdi
  char *v16; // rbp
  char *v17; // rbx
  __int64 v18; // rax
  void *v19; // rdi
  __int64 v20; // rdi
  void *v22; // [rsp+0h] [rbp-88h] BYREF
  char *v23; // [rsp+8h] [rbp-80h]
  __int64 v24; // [rsp+18h] [rbp-70h] BYREF
  __int64 v25; // [rsp+20h] [rbp-68h]
  __int64 v26; // [rsp+28h] [rbp-60h] BYREF
  __int64 v27; // [rsp+30h] [rbp-58h]
  void *ptr; // [rsp+38h] [rbp-50h] BYREF
  char *v29; // [rsp+40h] [rbp-48h]
  __int64 v30; // [rsp+50h] [rbp-38h]
  char v31; // [rsp+58h] [rbp-30h]

  v24 = *a3;
  v9 = a3[1];
  v25 = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 12), 1u);
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)&v22, a4);
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<std::vector<RBX::Reflection::Variant>>,boost::_bi::value<RBX::SystemAddress>,boost::_bi::value<bool>,boost::arg<1>>::list5(
    &v26,
    &v24,
    &v22,
    a5,
    a6);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = v26;
  v10 = v27;
  *(_QWORD *)(a1 + 16) = v27;
  if ( v10 )
    _InterlockedAdd((volatile signed __int32 *)(v10 + 12), 1u);
  std::vector<RBX::Reflection::Variant>::vector(
    (std::vector<RBX::Reflection::Variant> *)(a1 + 24),
    (const std::vector<RBX::Reflection::Variant> *)&ptr);
  *(_QWORD *)(a1 + 48) = v30;
  *(_BYTE *)(a1 + 56) = v31;
  v11 = (char *)ptr;
  if ( ptr )
  {
    v12 = v29;
    if ( v29 == ptr )
    {
      v14 = ptr;
    }
    else
    {
      do
      {
        v13 = *((_QWORD *)v12 - 13);
        if ( v13 )
          (*(void (__fastcall **)(char *))(v13 + 16))(v12 - 96);
        v12 -= 112;
      }
      while ( v11 != v12 );
      v14 = ptr;
    }
    v29 = v11;
    operator delete(v14);
  }
  v15 = v27;
  if ( v27 && !_InterlockedSub((volatile signed __int32 *)(v27 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 24LL))(v15);
  v16 = (char *)v22;
  if ( v22 )
  {
    v17 = v23;
    if ( v23 == v22 )
    {
      v19 = v22;
    }
    else
    {
      do
      {
        v18 = *((_QWORD *)v17 - 13);
        if ( v18 )
          (*(void (__fastcall **)(char *))(v18 + 16))(v17 - 96);
        v17 -= 112;
      }
      while ( v16 != v17 );
      v19 = v22;
    }
    v23 = v16;
    operator delete(v19);
  }
  v20 = v25;
  if ( v25 && !_InterlockedSub((volatile signed __int32 *)(v25 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v20 + 24LL))(v20);
  return a1;
}


// Address: 0x18a19d0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENSt3__16vectorINS2_10Reflection7VariantENS5_9allocatorIS8_EEEENS2_13SystemAddressEbNS5_12basic_stringIcNS5_11char_traitsIcEENS9_IcEEEES4_SB_SC_bNS_3argILi1EEEEENS_3_bi6bind_tIT_PFSM_T0_T1_T2_T3_T4_ENSK_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEST_SV_SW_SX_SY_SZ_
__int64 __fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,std::vector<RBX::Reflection::Variant>,RBX::SystemAddress,bool,std::string,boost::weak_ptr<RBX::DataModel>,std::vector<RBX::Reflection::Variant>,RBX::SystemAddress,bool,boost::arg<1>>(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        const std::vector<RBX::Reflection::Variant> *a4,
        __int64 a5,
        unsigned __int8 a6)
{
  __int64 v9; // rax
  __int64 v10; // rax
  char *v11; // rbp
  char *v12; // rbx
  __int64 v13; // rax
  void *v14; // rdi
  __int64 v15; // rdi
  char *v16; // rbp
  char *v17; // rbx
  __int64 v18; // rax
  void *v19; // rdi
  __int64 v20; // rdi
  void *v22; // [rsp+0h] [rbp-88h] BYREF
  char *v23; // [rsp+8h] [rbp-80h]
  __int64 v24; // [rsp+18h] [rbp-70h] BYREF
  __int64 v25; // [rsp+20h] [rbp-68h]
  __int64 v26; // [rsp+28h] [rbp-60h] BYREF
  __int64 v27; // [rsp+30h] [rbp-58h]
  void *ptr; // [rsp+38h] [rbp-50h] BYREF
  char *v29; // [rsp+40h] [rbp-48h]
  __int64 v30; // [rsp+50h] [rbp-38h]
  char v31; // [rsp+58h] [rbp-30h]

  v24 = *a3;
  v9 = a3[1];
  v25 = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 12), 1u);
  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)&v22, a4);
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<std::vector<RBX::Reflection::Variant>>,boost::_bi::value<RBX::SystemAddress>,boost::_bi::value<bool>,boost::arg<1>>::list5(
    &v26,
    &v24,
    &v22,
    a5,
    a6);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = v26;
  v10 = v27;
  *(_QWORD *)(a1 + 16) = v27;
  if ( v10 )
    _InterlockedAdd((volatile signed __int32 *)(v10 + 12), 1u);
  std::vector<RBX::Reflection::Variant>::vector(
    (std::vector<RBX::Reflection::Variant> *)(a1 + 24),
    (const std::vector<RBX::Reflection::Variant> *)&ptr);
  *(_QWORD *)(a1 + 48) = v30;
  *(_BYTE *)(a1 + 56) = v31;
  v11 = (char *)ptr;
  if ( ptr )
  {
    v12 = v29;
    if ( v29 == ptr )
    {
      v14 = ptr;
    }
    else
    {
      do
      {
        v13 = *((_QWORD *)v12 - 13);
        if ( v13 )
          (*(void (__fastcall **)(char *))(v13 + 16))(v12 - 96);
        v12 -= 112;
      }
      while ( v11 != v12 );
      v14 = ptr;
    }
    v29 = v11;
    operator delete(v14);
  }
  v15 = v27;
  if ( v27 && !_InterlockedSub((volatile signed __int32 *)(v27 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 24LL))(v15);
  v16 = (char *)v22;
  if ( v22 )
  {
    v17 = v23;
    if ( v23 == v22 )
    {
      v19 = v22;
    }
    else
    {
      do
      {
        v18 = *((_QWORD *)v17 - 13);
        if ( v18 )
          (*(void (__fastcall **)(char *))(v18 + 16))(v17 - 96);
        v17 -= 112;
      }
      while ( v16 != v17 );
      v19 = v22;
    }
    v23 = v16;
    operator delete(v19);
  }
  v20 = v25;
  if ( v25 && !_InterlockedSub((volatile signed __int32 *)(v25 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v20 + 24LL))(v20);
  return a1;
}


// Address: 0x18a1f20 | Name: _ZN5boost4bindIvPN3RBX9DataModelENSt3__16vectorINS1_10Reflection7VariantENS4_9allocatorIS7_EEEENS1_13SystemAddressEbNS_3argILi1EEESA_SB_bEENS_3_bi6bind_tIT_PFSG_T0_T1_T2_T3_ENSE_9list_av_4IT4_T5_T6_T7_E4typeEEESM_SO_SP_SQ_SR_
__int64 __fastcall boost::bind<void,RBX::DataModel *,std::vector<RBX::Reflection::Variant>,RBX::SystemAddress,bool,boost::arg<1>,std::vector<RBX::Reflection::Variant>,RBX::SystemAddress,bool>(
        __int64 a1,
        __int64 a2,
        const std::vector<RBX::Reflection::Variant> *a3,
        __int64 a4,
        unsigned int a5)
{
  char *v8; // rbx
  char *v9; // rbp
  __int64 v10; // rax
  void *v11; // rdi
  char *v12; // rbx
  char *v13; // rbp
  __int64 v14; // rax
  void *v15; // rdi
  void *v17; // [rsp+0h] [rbp-68h] BYREF
  char *v18; // [rsp+8h] [rbp-60h]
  void *ptr; // [rsp+18h] [rbp-50h] BYREF
  char *v20; // [rsp+20h] [rbp-48h]
  __int64 v21; // [rsp+30h] [rbp-38h]
  char v22; // [rsp+38h] [rbp-30h]

  std::vector<RBX::Reflection::Variant>::vector((std::vector<RBX::Reflection::Variant> *)&v17, a3);
  boost::_bi::list4<boost::arg<1>,boost::_bi::value<std::vector<RBX::Reflection::Variant>>,boost::_bi::value<RBX::SystemAddress>,boost::_bi::value<bool>>::list4(
    &ptr,
    &v17,
    a4,
    a5);
  *(_QWORD *)a1 = a2;
  std::vector<RBX::Reflection::Variant>::vector(
    (std::vector<RBX::Reflection::Variant> *)(a1 + 8),
    (const std::vector<RBX::Reflection::Variant> *)&ptr);
  *(_QWORD *)(a1 + 32) = v21;
  *(_BYTE *)(a1 + 40) = v22;
  v8 = (char *)ptr;
  if ( ptr )
  {
    v9 = v20;
    if ( v20 == ptr )
    {
      v11 = ptr;
    }
    else
    {
      do
      {
        v10 = *((_QWORD *)v9 - 13);
        if ( v10 )
          (*(void (__fastcall **)(char *))(v10 + 16))(v9 - 96);
        v9 -= 112;
      }
      while ( v8 != v9 );
      v11 = ptr;
    }
    v20 = v8;
    operator delete(v11);
  }
  v12 = (char *)v17;
  if ( v17 )
  {
    v13 = v18;
    if ( v18 == v17 )
    {
      v15 = v17;
    }
    else
    {
      do
      {
        v14 = *((_QWORD *)v13 - 13);
        if ( v14 )
          (*(void (__fastcall **)(char *))(v14 + 16))(v13 - 96);
        v13 -= 112;
      }
      while ( v12 != v13 );
      v15 = v17;
    }
    v18 = v12;
    operator delete(v15);
  }
  return a1;
}


// Address: 0x18a44a0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX18MarketplaceServiceEEENSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEES4_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSG_T0_T1_ENSE_9list_av_2IT2_T3_E4typeEEESK_SM_SN_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,std::string),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::MarketplaceService>,std::string,boost::weak_ptr<RBX::MarketplaceService>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,std::string),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::MarketplaceService>, std::string),
        boost::weak_ptr<RBX::MarketplaceService> a1,
        __int64 a2)
{
  int (**v4)(void); // r12
  boost::detail::sp_counted_base *px; // rbx

  v4 = a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  if ( px )
  {
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::MarketplaceService>, std::string), boost::weak_ptr<RBX::MarketplaceService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::MarketplaceService>, std::string), boost::weak_ptr<RBX::MarketplaceService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::MarketplaceService>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = px;
    _InterlockedAdd(&px->weak_count_, 1u);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::MarketplaceService>, std::string), boost::weak_ptr<RBX::MarketplaceService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::MarketplaceService>, std::string), boost::weak_ptr<RBX::MarketplaceService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::MarketplaceService>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x18a46b0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX18MarketplaceServiceEEENS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEENS2_10Reflection7VariantENS_4hashISE_EENS8_8equal_toISE_EENSC_INS8_4pairIKSE_SG_EEEEEEEES4_SR_EENS_3_bi6bind_tIT_PFSU_T0_T1_ENSS_9list_av_2IT2_T3_E4typeEEESY_S10_S11_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::MarketplaceService>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>,boost::weak_ptr<RBX::MarketplaceService>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::MarketplaceService>, boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >),
        boost::weak_ptr<RBX::MarketplaceService> a1,
        boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > a2)
{
  boost::detail::sp_counted_base *px; // rax
  volatile signed __int32 *v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // rax
  boost::detail::sp_counted_base *v9; // rbx
  boost::detail::sp_counted_base *v10; // rdi
  volatile signed __int32 *v11; // rbx
  boost::detail::sp_counted_base *v12; // rdi
  int (**v14)(void); // [rsp+0h] [rbp-58h] BYREF
  volatile signed __int32 *v15; // [rsp+8h] [rbp-50h]
  boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> > a1a; // [rsp+10h] [rbp-48h] BYREF
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > v17; // [rsp+20h] [rbp-38h] BYREF

  a1a.t_.px = (boost::weak_ptr<RBX::MarketplaceService>::element_type *)a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  a1a.t_.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->weak_count_, 1u);
  v14 = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v15 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService>>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>>::list2(
    &v17,
    (boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >)__PAIR128__(&v14, &a1a),
    (boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >)__PAIR128__((unsigned __int64)a2.px, (unsigned __int64)a1.pn.pi_));
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v17.a1_.t_.px;
  pi = v17.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v17.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a2_.t_.px = v17.a2_.t_.px;
  v8 = v17.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v17.a2_.t_.pn.pi_;
  if ( v8 )
  {
    _InterlockedAdd(&v8->use_count_, 1u);
    v9 = v17.a2_.t_.pn.pi_;
    if ( v17.a2_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v17.a2_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
        if ( !_InterlockedSub(&v9->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
      }
    }
  }
  v10 = v17.a1_.t_.pn.pi_;
  if ( v17.a1_.t_.pn.pi_ && !_InterlockedSub(&v17.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
  v11 = v15;
  if ( v15 )
  {
    if ( !_InterlockedSub(v15 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
  v12 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ && !_InterlockedSub(&a1a.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
  return retstr;
}


// Address: 0x18a4d20 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX18MarketplaceServiceEEENSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEiiNS1_IKNS2_10Reflection5TupleEEES4_SB_iiNS_3argILi1EEEEENS_3_bi6bind_tIT_PFSK_T0_T1_T2_T3_T4_ENSI_9list_av_5IT5_T6_T7_T8_T9_E4typeEEESR_ST_SU_SV_SW_SX_
__int64 __fastcall boost::bind<void,boost::shared_ptr<RBX::MarketplaceService>,std::string,int,int,boost::shared_ptr<RBX::Reflection::Tuple const>,boost::shared_ptr<RBX::MarketplaceService>,std::string,int,int,boost::arg<1>>(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        unsigned int a5,
        unsigned int a6)
{
  volatile signed __int32 *v8; // rax
  volatile signed __int32 *v9; // rax
  volatile signed __int32 *v10; // rbp
  volatile signed __int32 *v11; // rbp
  __int64 v13; // [rsp+0h] [rbp-78h] BYREF
  volatile signed __int32 *v14; // [rsp+8h] [rbp-70h]
  _BYTE v15[16]; // [rsp+10h] [rbp-68h] BYREF
  void *v16; // [rsp+20h] [rbp-58h]
  __int64 v17; // [rsp+28h] [rbp-50h] BYREF
  volatile signed __int32 *v18; // [rsp+30h] [rbp-48h]
  char v19[16]; // [rsp+38h] [rbp-40h] BYREF
  void *ptr; // [rsp+48h] [rbp-30h]
  int v21; // [rsp+50h] [rbp-28h]
  int v22; // [rsp+54h] [rbp-24h]

  v13 = *a3;
  v8 = (volatile signed __int32 *)a3[1];
  v14 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  std::string::basic_string(v15, a4);
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::MarketplaceService>>,boost::_bi::value<std::string>,boost::_bi::value<int>,boost::_bi::value<int>,boost::arg<1>>::list5(
    &v17,
    &v13,
    v15,
    a5,
    a6);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = v17;
  v9 = v18;
  *(_QWORD *)(a1 + 16) = v18;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  std::string::basic_string(a1 + 24, v19);
  *(_DWORD *)(a1 + 48) = v21;
  *(_DWORD *)(a1 + 52) = v22;
  if ( (v19[0] & 1) != 0 )
    operator delete(ptr);
  v10 = v18;
  if ( v18 )
  {
    if ( !_InterlockedSub(v18 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
      if ( !_InterlockedSub(v10 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
    }
  }
  if ( (v15[0] & 1) != 0 )
    operator delete(v16);
  v11 = v14;
  if ( v14 )
  {
    if ( !_InterlockedSub(v14 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
  return a1;
}


// Address: 0x18a5150 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX18MarketplaceServiceEEENSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEESB_S4_SB_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSG_T0_T1_T2_ENSE_9list_av_3IT3_T4_T5_E4typeEEESL_SN_SO_SP_
_QWORD *__fastcall boost::bind<void,boost::weak_ptr<RBX::MarketplaceService>,std::string,std::string,boost::weak_ptr<RBX::MarketplaceService>,std::string,boost::arg<1>>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4)
{
  __int64 v5; // rax
  __int64 v6; // rax
  __int64 v7; // rdi
  __int64 v8; // rdi
  __int64 v10; // [rsp+8h] [rbp-60h] BYREF
  __int64 v11; // [rsp+10h] [rbp-58h]
  _BYTE v12[16]; // [rsp+18h] [rbp-50h] BYREF
  void *v13; // [rsp+28h] [rbp-40h]
  __int64 v14; // [rsp+30h] [rbp-38h] BYREF
  __int64 v15; // [rsp+38h] [rbp-30h]
  _BYTE v16[16]; // [rsp+40h] [rbp-28h] BYREF
  void *ptr; // [rsp+50h] [rbp-18h]

  v10 = *a3;
  v5 = a3[1];
  v11 = v5;
  if ( v5 )
    _InterlockedAdd((volatile signed __int32 *)(v5 + 12), 1u);
  std::string::basic_string(v12, a4);
  boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService>>,boost::_bi::value<std::string>,boost::arg<1>>::list3(
    &v14,
    &v10,
    v12);
  *a1 = a2;
  a1[1] = v14;
  v6 = v15;
  a1[2] = v15;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)(v6 + 12), 1u);
  std::string::basic_string(a1 + 3, v16);
  if ( (v16[0] & 1) != 0 )
    operator delete(ptr);
  v7 = v15;
  if ( v15 && !_InterlockedSub((volatile signed __int32 *)(v15 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v7 + 24LL))(v7);
  if ( (v12[0] & 1) != 0 )
    operator delete(v13);
  v8 = v11;
  if ( v11 && !_InterlockedSub((volatile signed __int32 *)(v11 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 24LL))(v8);
  return a1;
}


// Address: 0x18a5ab0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX18MarketplaceServiceEEENS_10shared_ptrINS2_8InstanceEEES4_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSC_T0_T1_ENSA_9list_av_2IT2_T3_E4typeEEESG_SI_SJ_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,boost::shared_ptr<RBX::Instance>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::MarketplaceService>,boost::shared_ptr<RBX::Instance>,boost::weak_ptr<RBX::MarketplaceService>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,boost::shared_ptr<RBX::Instance>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::MarketplaceService>, boost::shared_ptr<RBX::Instance>),
        boost::weak_ptr<RBX::MarketplaceService> a1,
        __int64 a2)
{
  int (**v4)(void); // r12
  boost::detail::sp_counted_base *px; // rbx

  v4 = a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  if ( px )
  {
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::MarketplaceService>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::MarketplaceService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::MarketplaceService>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::MarketplaceService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::MarketplaceService>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = px;
    _InterlockedAdd(&px->weak_count_, 1u);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::MarketplaceService>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::MarketplaceService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::MarketplaceService>, boost::shared_ptr<RBX::Instance>), boost::weak_ptr<RBX::MarketplaceService>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::MarketplaceService>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x18a5b70 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX18MarketplaceServiceEEEPNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEPSt9exceptionNS_8functionIFvbEEENSF_IFvSB_EEEllNS_10shared_ptrIS3_EENS_3argILi1EEENSM_ILi2EEESH_SJ_llEENS_3_bi6bind_tIT_PFSR_T0_T1_T2_T3_T4_T5_T6_ENSP_9list_av_7IT7_T8_T9_T10_T11_T12_T13_E4typeEEES10_S12_S13_S14_S15_S16_S17_S18_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,std::string *,std::exception *,boost::function<void (bool)>,boost::function<void (std::string)>,long,long),boost::_bi::list7<boost::_bi::value<boost::shared_ptr<RBX::MarketplaceService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<long>,boost::_bi::value<long> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::MarketplaceService>,std::string *,std::exception *,boost::function<void ()(bool)>,boost::function<void ()(std::string)>,long,long,boost::shared_ptr<RBX::MarketplaceService>,boost::arg<1>,boost::arg<2>,boost::function<void ()(bool)>,boost::function<void ()(std::string)>,long,long>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,std::string *,std::exception *,boost::function<void (bool)>,boost::function<void (std::string)>,long,long),boost::_bi::list7<boost::_bi::value<boost::shared_ptr<RBX::MarketplaceService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<long>,boost::_bi::value<long> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::MarketplaceService>, std::string *, std::exception *, boost::function<void (bool)>, boost::function<void (std::string)>_0, __int64, __int64),
        boost::shared_ptr<RBX::MarketplaceService> a1,
        __int64 a2,
        boost::arg<2> a3,
        boost::function<void (bool)> a4)
{
  boost::detail::sp_counted_base *px; // rax
  int (**v9)(void); // rax
  unsigned __int64 v10; // rax
  void (__fastcall *v11)(char *, char *, __int64); // rax
  void (__fastcall *v12)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::_bi::value<boost::function<void (bool)> > v15; // [rsp+0h] [rbp-D8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 v16; // [rsp+20h] [rbp-B8h] BYREF
  boost::_bi::value<long> v17; // [rsp+40h] [rbp-98h]
  boost::_bi::value<boost::shared_ptr<RBX::MarketplaceService> > v18; // [rsp+48h] [rbp-90h] BYREF
  boost::_bi::list7<boost::_bi::value<boost::shared_ptr<RBX::MarketplaceService> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<long>,boost::_bi::value<long> > v19; // [rsp+58h] [rbp-80h] BYREF

  v18.t_.px = (boost::shared_ptr<RBX::MarketplaceService>::element_type *)a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  v18.t_.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->use_count_, 1u);
  v16.t_.functor.obj_ptr = 0;
  v9 = a1.pn.pi_->_vptr$sp_counted_base;
  if ( a1.pn.pi_->_vptr$sp_counted_base )
  {
    v16.t_.functor.obj_ptr = a1.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v9 & 1) != 0 )
    {
      v17.t_ = *(_QWORD *)&a1.pn.pi_[1].use_count_;
      *(_OWORD *)(&v16.t_.functor.data + 8) = *(_OWORD *)&a1.pn.pi_->use_count_;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, bool *, _QWORD))((unsigned __int64)v9
                                                                                    & 0xFFFFFFFFFFFFFFFELL))(
        &a1.pn.pi_->use_count_,
        &v16.t_.functor.type.const_qualified,
        0);
    }
  }
  v15.t_.functor.obj_ptr = 0;
  v10 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v15.t_.functor.obj_ptr = *(void **)a2;
    if ( (v10 & 1) != 0 )
    {
      v16.t_.vtable = *(boost::detail::function::vtable_base **)(a2 + 24);
      *(_OWORD *)(&v15.t_.functor.data + 8) = *(_OWORD *)(a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v15.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list7<boost::_bi::value<boost::shared_ptr<RBX::MarketplaceService>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<long>,boost::_bi::value<long>>::list7(
    &v19,
    (boost::_bi::value<boost::shared_ptr<RBX::MarketplaceService> >)__PAIR128__(
                                                                      (boost::_bi::value<boost::function<void (std::string)> >_0 *)&v16.t_.functor,
                                                                      &v18),
    (boost::arg<1>)&v15.t_.functor,
    a3,
    v15,
    v16,
    (boost::_bi::value<long>)a4.vtable,
    v17);
  retstr->f_ = f;
  boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::MarketplaceService>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage5(
    &retstr->l_,
    &v19);
  *(_OWORD *)&retstr->l_.a6_.t_ = *(_OWORD *)&v19.a6_.t_;
  boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::MarketplaceService>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage5(&v19);
  if ( v15.t_.functor.obj_ptr )
  {
    if ( (v15.t_.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v15.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v15.t_.functor.bound_memfunc_ptr.gap8, v15.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v15.t_.functor.obj_ptr = 0;
  }
  if ( v16.t_.functor.obj_ptr )
  {
    if ( (v16.t_.functor.data & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v16.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(v16.t_.functor.bound_memfunc_ptr.gap8, v16.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v16.t_.functor.obj_ptr = 0;
  }
  pi = v18.t_.pn.pi_;
  if ( v18.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v18.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x18a6280 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX18MarketplaceServiceEEENS1_INS2_9DataModelEEENS1_INS2_12TimerServiceEEEliNS2_14MembershipTypeES4_S6_S8_liNS_3argILi1EEEEENS_3_bi6bind_tIT_PFSE_T0_T1_T2_T3_T4_T5_ENSC_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEESM_SO_SP_SQ_SR_SS_ST_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::TimerService>,long,int,RBX::MembershipType),boost::_bi::list6<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::TimerService> >,boost::_bi::value<long>,boost::_bi::value<int>,boost::arg<1> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::MarketplaceService>,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::TimerService>,long,int,RBX::MembershipType,boost::weak_ptr<RBX::MarketplaceService>,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::TimerService>,long,int,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::TimerService>,long,int,RBX::MembershipType),boost::_bi::list6<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::TimerService> >,boost::_bi::value<long>,boost::_bi::value<int>,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::MarketplaceService>, boost::weak_ptr<RBX::DataModel>, boost::weak_ptr<RBX::TimerService>, __int64, int, RBX::MembershipType),
        boost::weak_ptr<RBX::MarketplaceService> a1,
        boost::weak_ptr<RBX::DataModel> a2,
        boost::weak_ptr<RBX::TimerService> a3)
{
  boost::detail::sp_counted_base *px; // rax
  __int64 v7; // rax
  __int64 v8; // rcx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v10; // rax
  boost::detail::sp_counted_base *v11; // rax
  boost::detail::sp_counted_base *v12; // rdi
  boost::detail::sp_counted_base *v13; // rdi
  boost::detail::sp_counted_base *v14; // rdi
  __int64 v15; // rdi
  __int64 v16; // rdi
  boost::detail::sp_counted_base *v17; // rdi
  boost::_bi::value<boost::weak_ptr<RBX::TimerService> > v19; // [rsp+0h] [rbp-88h] BYREF
  __int64 a2_8; // [rsp+10h] [rbp-78h]
  int (**a1a)(void); // [rsp+18h] [rbp-70h] BYREF
  __int64 v22; // [rsp+20h] [rbp-68h]
  boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> > v23; // [rsp+28h] [rbp-60h] BYREF
  boost::_bi::list6<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::TimerService> >,boost::_bi::value<long>,boost::_bi::value<int>,boost::arg<1> > v24; // [rsp+38h] [rbp-50h] BYREF

  v23.t_.px = (boost::weak_ptr<RBX::MarketplaceService>::element_type *)a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  v23.t_.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->weak_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(_QWORD *)&a1.pn.pi_->use_count_;
  v22 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  v19.t_.pn.pi_ = *(boost::detail::sp_counted_base **)a2.px;
  v8 = *((_QWORD *)a2.px + 1);
  a2_8 = v8;
  if ( v8 )
    _InterlockedAdd((volatile signed __int32 *)(v8 + 12), 1u);
  boost::_bi::list6<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::TimerService>>,boost::_bi::value<long>,boost::_bi::value<int>,boost::arg<1>>::list6(
    &v24,
    (boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >)__PAIR128__(&a1a, &v23),
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(
                                                           (unsigned __int64)a2.pn.pi_,
                                                           (boost::_bi::value<boost::weak_ptr<RBX::TimerService> > *)&v19.t_.pn),
    v19,
    (boost::_bi::value<long>)LODWORD(a3.px),
    (boost::_bi::value<int>)a2_8,
    (boost::arg<1>)a1a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v24.a1_.t_.px;
  pi = v24.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v24.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a2_.t_.px = v24.a2_.t_.px;
  v10 = v24.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v24.a2_.t_.pn.pi_;
  if ( v10 )
    _InterlockedAdd(&v10->weak_count_, 1u);
  retstr->l_.a3_.t_.px = v24.a3_.t_.px;
  v11 = v24.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v24.a3_.t_.pn.pi_;
  if ( v11 )
  {
    _InterlockedAdd(&v11->weak_count_, 1u);
    v12 = v24.a3_.t_.pn.pi_;
  }
  else
  {
    v12 = 0;
  }
  retstr->l_.a4_.t_ = v24.a4_.t_;
  retstr->l_.a5_.t_ = v24.a5_.t_;
  if ( v12 && !_InterlockedSub(&v12->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
  v13 = v24.a2_.t_.pn.pi_;
  if ( v24.a2_.t_.pn.pi_ && !_InterlockedSub(&v24.a2_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
  v14 = v24.a1_.t_.pn.pi_;
  if ( v24.a1_.t_.pn.pi_ && !_InterlockedSub(&v24.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
  v15 = a2_8;
  if ( a2_8 && !_InterlockedSub((volatile signed __int32 *)(a2_8 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 24LL))(v15);
  v16 = v22;
  if ( v22 && !_InterlockedSub((volatile signed __int32 *)(v22 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v16 + 24LL))(v16);
  v17 = v23.t_.pn.pi_;
  if ( v23.t_.pn.pi_ && !_InterlockedSub(&v23.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
  return retstr;
}


// Address: 0x18a67a0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX18MarketplaceServiceEEENS1_INS2_9DataModelEEENS1_INS2_12TimerServiceEEElNSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEES4_S6_S8_lNS_3argILi1EEEEENS_3_bi6bind_tIT_PFSK_T0_T1_T2_T3_T4_ENSI_9list_av_5IT5_T6_T7_T8_T9_E4typeEEESR_ST_SU_SV_SW_SX_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::TimerService>,long,std::string),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::TimerService> >,boost::_bi::value<long>,boost::arg<1> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::MarketplaceService>,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::TimerService>,long,std::string,boost::weak_ptr<RBX::MarketplaceService>,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::TimerService>,long,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::MarketplaceService>,boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::TimerService>,long,std::string),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::TimerService> >,boost::_bi::value<long>,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::MarketplaceService>, boost::weak_ptr<RBX::DataModel>, boost::weak_ptr<RBX::TimerService>, __int64, std::string),
        boost::weak_ptr<RBX::MarketplaceService> a1,
        boost::weak_ptr<RBX::DataModel> a2)
{
  boost::detail::sp_counted_base *px; // rax
  __int64 v6; // rax
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v9; // rax
  boost::detail::sp_counted_base *v10; // rax
  boost::detail::sp_counted_base *v11; // rdi
  boost::detail::sp_counted_base *v12; // rdi
  boost::detail::sp_counted_base *v13; // rdi
  boost::detail::sp_counted_base *v14; // rdi
  __int64 v15; // rdi
  boost::detail::sp_counted_base *v16; // rdi
  boost::_bi::value<boost::weak_ptr<RBX::TimerService> > v18; // [rsp+0h] [rbp-78h] BYREF
  int (**a1a)(void); // [rsp+10h] [rbp-68h] BYREF
  __int64 v20; // [rsp+18h] [rbp-60h]
  boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> > v21; // [rsp+20h] [rbp-58h] BYREF
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::TimerService> >,boost::_bi::value<long>,boost::arg<1> > v22; // [rsp+30h] [rbp-48h] BYREF

  v21.t_.px = (boost::weak_ptr<RBX::MarketplaceService>::element_type *)a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  v21.t_.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->weak_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(_QWORD *)&a1.pn.pi_->use_count_;
  v20 = v6;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)(v6 + 12), 1u);
  v18.t_.px = *(boost::weak_ptr<RBX::TimerService>::element_type **)a2.px;
  v7 = (boost::detail::sp_counted_base *)*((_QWORD *)a2.px + 1);
  v18.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->weak_count_, 1u);
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::TimerService>>,boost::_bi::value<long>,boost::arg<1>>::list5(
    &v22,
    (boost::_bi::value<boost::weak_ptr<RBX::MarketplaceService> >)__PAIR128__(&a1a, &v21),
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__((unsigned __int64)a2.pn.pi_, &v18),
    v18,
    (boost::_bi::value<long>)a2.pn.pi_,
    (boost::arg<1>)a1a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v22.a1_.t_.px;
  pi = v22.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v22.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a2_.t_.px = v22.a2_.t_.px;
  v9 = v22.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v22.a2_.t_.pn.pi_;
  if ( v9 )
    _InterlockedAdd(&v9->weak_count_, 1u);
  retstr->l_.a3_.t_.px = v22.a3_.t_.px;
  v10 = v22.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v22.a3_.t_.pn.pi_;
  if ( v10 )
  {
    _InterlockedAdd(&v10->weak_count_, 1u);
    v11 = v22.a3_.t_.pn.pi_;
    retstr->l_.a4_.t_ = v22.a4_.t_;
    if ( v11 && !_InterlockedSub(&v11->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
  }
  else
  {
    retstr->l_.a4_.t_ = v22.a4_.t_;
  }
  v12 = v22.a2_.t_.pn.pi_;
  if ( v22.a2_.t_.pn.pi_ && !_InterlockedSub(&v22.a2_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
  v13 = v22.a1_.t_.pn.pi_;
  if ( v22.a1_.t_.pn.pi_ && !_InterlockedSub(&v22.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
  v14 = v18.t_.pn.pi_;
  if ( v18.t_.pn.pi_ && !_InterlockedSub(&v18.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
  v15 = v20;
  if ( v20 && !_InterlockedSub((volatile signed __int32 *)(v20 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 24LL))(v15);
  v16 = v21.t_.pn.pi_;
  if ( v21.t_.pn.pi_ && !_InterlockedSub(&v21.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
  return retstr;
}


// Address: 0x18b6c50 | Name: _ZN5boost4bindIvNS_10shared_ptrINS_8functionIFvNS1_IKN3RBX10Reflection5TupleEEENS2_IFvS7_EEENS2_IFvNSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEEEEEEEEEENS1_IKNS_9unordered13unordered_mapISG_NS4_7VariantENS_4hashISG_EENSA_8equal_toISG_EENSE_INSA_4pairIKSG_SO_EEEEEEEES9_SI_SL_NS_3argILi1EEENS10_ILi2EEENS10_ILi3EEEEENS_3_bi6bind_tIT_PFS16_T0_T1_T2_T3_ENS14_9list_av_4IT4_T5_T6_T7_E4typeEEES1C_S1E_S1F_S1G_S1H_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >,boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3> > > *__fastcall boost::bind<void,boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>,boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>,boost::arg<1>,boost::arg<2>,boost::arg<3>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >,boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3> > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >, boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >, boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>_0, boost::function<void (std::string)>_0),
        boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > a1,
        boost::arg<1> a2,
        boost::arg<2> a3)
{
  boost::detail::sp_counted_base *obj_ptr; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v7; // rbx
  boost::detail::sp_counted_base *v8; // rbx
  boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > > a1a; // [rsp+8h] [rbp-30h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3> > v11; // [rsp+18h] [rbp-20h] BYREF

  a1a.t_.px = (boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >::element_type *)a1.px->vtable;
  obj_ptr = (boost::detail::sp_counted_base *)a1.px->functor.obj_ptr;
  a1a.t_.pn.pi_ = obj_ptr;
  if ( obj_ptr )
    _InterlockedAdd(&obj_ptr->use_count_, 1u);
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>>,boost::arg<1>,boost::arg<2>,boost::arg<3>>::list4(
    &v11,
    (boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >)__PAIR128__((unsigned __int64)a1.px, &a1a),
    (boost::arg<1>)a1.pn.pi_,
    (boost::arg<2>)a2.gap0,
    (boost::arg<3>)a3.gap0);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v11.a1_.t_.px;
  pi = v11.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v11.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v7 = v11.a1_.t_.pn.pi_;
    if ( v11.a1_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v11.a1_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
  }
  v8 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
  }
  return retstr;
}


// Address: 0x1923050 | Name: _ZN5boost4bindIvPN3RBX9PrimitiveERNS_10shared_ptrINSt3__16vectorINS4_INS1_8InstanceEEENS5_9allocatorIS8_EEEEEENS_3argILi1EEESC_EENS_3_bi6bind_tIT_PFSI_T0_T1_ENSG_9list_av_2IT2_T3_E4typeEEESM_SO_SP_
boost::_bi::bind_t<void,void (*)(RBX::Primitive *,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > &),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > > > > *__fastcall boost::bind<void,RBX::Primitive *,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>> &,boost::arg<1>,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>(
        boost::_bi::bind_t<void,void (*)(RBX::Primitive *,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > &),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > > > > *__return_ptr retstr,
        void (*f)(RBX::Primitive *, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *),
        __int64 a1,
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > a2)
{
  boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *v4; // r12
  boost::detail::sp_counted_base *v5; // rbx

  v4 = *(boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **)a1;
  v5 = *(boost::detail::sp_counted_base **)(a1 + 8);
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Primitive *, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *), __int64, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1,
        a2.px,
        a2.pn.pi_);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_ = f;
    retstr->l_.a2_.t_.px = v4;
    retstr->l_.a2_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Primitive *, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *), __int64, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1,
        a2.px,
        a2.pn.pi_);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Primitive *, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *), __int64, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1,
        a2.px,
        a2.pn.pi_);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a2_.t_.px = v4;
    retstr->l_.a2_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1933760 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX13PartOperationEEES4_EENS_3_bi6bind_tIT_PFS7_T0_ENS5_9list_av_1IT1_E4typeEEESA_SC_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::PartOperation>),boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::PartOperation> > > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::PartOperation>,boost::shared_ptr<RBX::PartOperation>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::PartOperation>),boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::PartOperation> > > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::PartOperation>),
        boost::shared_ptr<RBX::PartOperation> a1)
{
  boost::shared_ptr<RBX::PartOperation>::element_type *v3; // r12
  boost::detail::sp_counted_base *v4; // rbx

  v3 = *(boost::shared_ptr<RBX::PartOperation>::element_type **)a1.px;
  v4 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v4 )
  {
    _InterlockedAdd(&v4->use_count_, 1u);
    _InterlockedAdd(&v4->use_count_, 1u);
    _InterlockedAdd(&v4->use_count_, 1u);
    if ( !_InterlockedSub(&v4->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::PartOperation>), boost::shared_ptr<RBX::PartOperation>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 2))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v3;
    retstr->l_.a1_.t_.pn.pi_ = v4;
    _InterlockedAdd(&v4->use_count_, 1u);
    if ( !_InterlockedSub(&v4->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::PartOperation>), boost::shared_ptr<RBX::PartOperation>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 2))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
    if ( !_InterlockedSub(&v4->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::PartOperation>), boost::shared_ptr<RBX::PartOperation>::element_type *, boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base
       + 2))(
        v4,
        f,
        a1.px,
        a1.pn.pi_);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v3;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1963690 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX6PlayerEEENS_10shared_ptrIKNSt3__13mapINS6_12basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEENS2_10Reflection7VariantENS6_4lessISD_EENSB_INS6_4pairIKSD_SF_EEEEEEEES4_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFST_T0_T1_ENSR_9list_av_2IT2_T3_E4typeEEESX_SZ_S10_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Player>,boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::Player>,boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>,boost::weak_ptr<RBX::Player>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Player>,boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::Player>, boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >),
        boost::weak_ptr<RBX::Player> a1,
        __int64 a2)
{
  boost::weak_ptr<RBX::Player>::element_type *v4; // r12
  boost::detail::sp_counted_base *v5; // rbx

  v4 = *(boost::weak_ptr<RBX::Player>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v5 )
  {
    _InterlockedAdd(&v5->weak_count_, 1u);
    _InterlockedAdd(&v5->weak_count_, 1u);
    _InterlockedAdd(&v5->weak_count_, 1u);
    _InterlockedAdd(&v5->weak_count_, 1u);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Player>, boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 3))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Player>, boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 3))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->weak_count_, 1u);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Player>, boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 3))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Player>, boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 3))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1963c70 | Name: _ZN5boost4bindIvRNS_8weak_ptrIN3RBX6PlayerEEEPKNS2_15ServiceProviderES4_S8_EENS_3_bi6bind_tIT_PFSB_T0_T1_ENS9_9list_av_2IT2_T3_E4typeEEESF_SH_SI_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Player> &,const RBX::ServiceProvider *),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::_bi::value<const RBX::ServiceProvider *> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::Player> &,RBX::ServiceProvider const*,boost::weak_ptr<RBX::Player>,RBX::ServiceProvider const*>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Player> &,const RBX::ServiceProvider *),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::_bi::value<const RBX::ServiceProvider *> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::Player> *, const RBX::ServiceProvider *),
        boost::weak_ptr<RBX::Player> a1,
        const RBX::ServiceProvider *a2)
{
  boost::detail::sp_counted_base *pi; // r15
  boost::weak_ptr<RBX::Player>::element_type *v5; // r13
  boost::detail::sp_counted_base *v6; // rbx

  pi = a1.pn.pi_;
  v5 = *(boost::weak_ptr<RBX::Player>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v6 )
  {
    _InterlockedAdd(&v6->weak_count_, 1u);
    _InterlockedAdd(&v6->weak_count_, 1u);
    _InterlockedAdd(&v6->weak_count_, 1u);
    _InterlockedAdd(&v6->weak_count_, 1u);
    if ( !_InterlockedSub(&v6->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Player> *, const RBX::ServiceProvider *), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, const RBX::ServiceProvider *))v6->_vptr$sp_counted_base
       + 3))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&v6->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Player> *, const RBX::ServiceProvider *), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, const RBX::ServiceProvider *))v6->_vptr$sp_counted_base
       + 3))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v5;
    retstr->l_.a1_.t_.pn.pi_ = v6;
    _InterlockedAdd(&v6->weak_count_, 1u);
    retstr->l_.a2_.t_ = (const RBX::ServiceProvider *)pi;
    if ( !_InterlockedSub(&v6->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Player> *, const RBX::ServiceProvider *), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, const RBX::ServiceProvider *))v6->_vptr$sp_counted_base
       + 3))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&v6->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Player> *, const RBX::ServiceProvider *), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, const RBX::ServiceProvider *))v6->_vptr$sp_counted_base
       + 3))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v5;
    retstr->l_.a1_.t_.pn.pi_ = 0;
    retstr->l_.a2_.t_ = (const RBX::ServiceProvider *)a1.pn.pi_;
  }
  return retstr;
}


// Address: 0x1964a60 | Name: _ZN5boost4bindIvRKNS_10shared_ptrIN3RBX13ModelInstanceEEERKNS1_INS2_8InstanceEEES4_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSF_T0_T1_ENSD_9list_av_2IT2_T3_E4typeEEESJ_SL_SM_
boost::_bi::bind_t<void,void (*)(const boost::shared_ptr<RBX::ModelInstance> &,const boost::shared_ptr<RBX::Instance> &),boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::ModelInstance> const&,boost::shared_ptr<RBX::Instance> const&,boost::shared_ptr<RBX::ModelInstance>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(const boost::shared_ptr<RBX::ModelInstance> &,const boost::shared_ptr<RBX::Instance> &),boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(const boost::shared_ptr<RBX::ModelInstance> *, const boost::shared_ptr<RBX::Instance> *),
        boost::shared_ptr<RBX::ModelInstance> a1,
        __int64 a2)
{
  boost::shared_ptr<RBX::ModelInstance>::element_type *v4; // r12
  boost::detail::sp_counted_base *v5; // rbx

  v4 = *(boost::shared_ptr<RBX::ModelInstance>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::shared_ptr<RBX::ModelInstance> *, const boost::shared_ptr<RBX::Instance> *), boost::shared_ptr<RBX::ModelInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::shared_ptr<RBX::ModelInstance> *, const boost::shared_ptr<RBX::Instance> *), boost::shared_ptr<RBX::ModelInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::shared_ptr<RBX::ModelInstance> *, const boost::shared_ptr<RBX::Instance> *), boost::shared_ptr<RBX::ModelInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::shared_ptr<RBX::ModelInstance> *, const boost::shared_ptr<RBX::Instance> *), boost::shared_ptr<RBX::ModelInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1964d50 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX6PlayerEEElNS2_17HttpRequestResultENS1_INSt3__16vectorINS1_INS2_8InstanceEEENS6_9allocatorIS9_EEEEEENS1_ISt9exceptionEENS_8functionIFvNS1_INS2_9AnimationEEEEEES4_lNS_3argILi1EEENSL_ILi2EEENSL_ILi3EEESK_EENS_3_bi6bind_tIT_PFSR_T0_T1_T2_T3_T4_T5_ENSP_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEESZ_S11_S12_S13_S14_S15_S16_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Player>,long,RBX::HttpRequestResult,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >,boost::shared_ptr<std::exception>,boost::function<void (boost::shared_ptr<RBX::Animation>)>),boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<long>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Animation>)> > > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::Player>,long,RBX::HttpRequestResult,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>,boost::shared_ptr<std::exception>,boost::function<void ()(boost::shared_ptr<RBX::Animation>)>,boost::shared_ptr<RBX::Player>,long,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::function<void ()(boost::shared_ptr<RBX::Animation>)>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Player>,long,RBX::HttpRequestResult,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >,boost::shared_ptr<std::exception>,boost::function<void (boost::shared_ptr<RBX::Animation>)>),boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<long>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Animation>)> > > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::Player>, __int64, RBX::HttpRequestResult, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >, boost::shared_ptr<std::exception>, boost::function<void (boost::shared_ptr<RBX::Animation>)>),
        boost::shared_ptr<RBX::Player> a1,
        __int64 *a2,
        boost::arg<1> a3)
{
  boost::detail::sp_counted_base *pi; // r15
  volatile signed __int32 *v6; // rax
  __int64 v7; // rax
  boost::detail::sp_counted_base *v8; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v11; // rbx
  void (__fastcall *v12)(boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Animation>)> > *, boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Animation>)> > *, __int64); // rax
  volatile signed __int32 *v13; // rbx
  boost::arg<3> v15[8]; // [rsp+0h] [rbp-88h] BYREF
  boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Animation>)> > v16; // [rsp+8h] [rbp-80h] BYREF
  volatile signed __int32 *v17; // [rsp+28h] [rbp-60h]
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<long>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Animation>)> > > v18; // [rsp+30h] [rbp-58h] BYREF

  pi = a1.pn.pi_;
  v16.t_.functor.bound_memfunc_ptr.obj_ptr = *(void **)a1.px;
  v6 = (volatile signed __int32 *)*((_QWORD *)a1.px + 1);
  v17 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  *(_QWORD *)&v15[0].gap0 = 0;
  v7 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&v15[0].gap0 = *a2;
    if ( (v7 & 1) != 0 )
    {
      *((_QWORD *)&v16.t_.functor.data + 1) = a2[3];
      *(_OWORD *)&v16.t_.vtable = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Animation>)> > *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 1,
        &v16,
        0);
    }
  }
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<long>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Animation>)>>>::list6(
    &v18,
    (boost::_bi::value<boost::shared_ptr<RBX::Player> >)__PAIR128__(
                                                          (unsigned __int64)pi,
                                                          (boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Animation>)> > *)(&v16.t_.functor.data + 16)),
    (boost::_bi::value<long>)v15,
    (boost::arg<1>)a2,
    (boost::arg<2>)a3.gap0,
    v15[0],
    v16);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v18.a1_.t_.px;
  v8 = v18.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v18.a1_.t_.pn.pi_;
  if ( v8 )
    _InterlockedAdd(&v8->use_count_, 1u);
  retstr->l_.a2_.t_ = v18.a2_.t_;
  retstr->l_.a6_.t_.vtable = 0;
  vtable = v18.a6_.t_.vtable;
  if ( v18.a6_.t_.vtable )
  {
    retstr->l_.a6_.t_.vtable = v18.a6_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a6_.t_.functor = v18.a6_.t_.functor;
LABEL_17:
      v18.a6_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v18.a6_.t_.functor,
      &retstr->l_.a6_.t_.functor,
      0);
    if ( v18.a6_.t_.vtable )
    {
      if ( ((__int64)v18.a6_.t_.vtable & 1) == 0 )
      {
        v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v18.a6_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v10 )
          v10(&v18.a6_.t_.functor, &v18.a6_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v11 = v18.a1_.t_.pn.pi_;
  if ( v18.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v18.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 2))(v11);
      if ( !_InterlockedSub(&v11->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
    }
  }
  if ( *(_QWORD *)&v15[0].gap0 )
  {
    if ( (v15[0].gap0 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Animation>)> > *, boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Animation>)> > *, __int64))(*(_QWORD *)&v15[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v16, &v16, 2);
    }
    *(_QWORD *)&v15[0].gap0 = 0;
  }
  v13 = v17;
  if ( v17 )
  {
    if ( !_InterlockedSub(v17 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  return retstr;
}


// Address: 0x1981680 | Name: _ZN5boost4bindIvRKNS_8weak_ptrIN3RBX6PlayerEEENS3_15CanManageStatusES4_S7_EENS_3_bi6bind_tIT_PFSA_T0_T1_ENS8_9list_av_2IT2_T3_E4typeEEESE_SG_SH_
boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::Player> &,RBX::Player::CanManageStatus),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::_bi::value<RBX::Player::CanManageStatus> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::Player> const&,RBX::Player::CanManageStatus,boost::weak_ptr<RBX::Player>,RBX::Player::CanManageStatus>(
        boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::Player> &,RBX::Player::CanManageStatus),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::_bi::value<RBX::Player::CanManageStatus> > > *__return_ptr retstr,
        void (*f)(const boost::weak_ptr<RBX::Player> *, RBX::Player::CanManageStatus),
        boost::weak_ptr<RBX::Player> a1,
        __int64 a2)
{
  RBX::Player::CanManageStatus pi; // r15d
  boost::weak_ptr<RBX::Player>::element_type *v5; // r12
  boost::detail::sp_counted_base *v6; // rbx

  pi = (RBX::Player::CanManageStatus)a1.pn.pi_;
  v5 = *(boost::weak_ptr<RBX::Player>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v6 )
  {
    _InterlockedAdd(&v6->weak_count_, 1u);
    _InterlockedAdd(&v6->weak_count_, 1u);
    _InterlockedAdd(&v6->weak_count_, 1u);
    _InterlockedAdd(&v6->weak_count_, 1u);
    if ( !_InterlockedSub(&v6->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::weak_ptr<RBX::Player> *, RBX::Player::CanManageStatus), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 3))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&v6->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::weak_ptr<RBX::Player> *, RBX::Player::CanManageStatus), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 3))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v5;
    retstr->l_.a1_.t_.pn.pi_ = v6;
    _InterlockedAdd(&v6->weak_count_, 1u);
    retstr->l_.a2_.t_ = pi;
    if ( !_InterlockedSub(&v6->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::weak_ptr<RBX::Player> *, RBX::Player::CanManageStatus), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 3))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
    if ( !_InterlockedSub(&v6->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(const boost::weak_ptr<RBX::Player> *, RBX::Player::CanManageStatus), boost::weak_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 3))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v5;
    retstr->l_.a1_.t_.pn.pi_ = 0;
    retstr->l_.a2_.t_ = (RBX::Player::CanManageStatus)a1.pn.pi_;
  }
  return retstr;
}


// Address: 0x19a3380 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX6PlayerEEENS2_21PlayerCharacterLoader10AvatarDataENS5_16AssetLoadingDataENS2_17HttpRequestResultENS_10shared_ptrINSt3__16vectorINS9_INS2_8InstanceEEENSA_9allocatorISD_EEEEEENS2_4TimeENS2_12AssetService9AssetTypeElbS4_S6_S7_NS_3argILi1EEENSL_ILi2EEESI_SK_lbEENS_3_bi6bind_tIT_PFSQ_T0_T1_T2_T3_T4_T5_T6_T7_T8_ENSO_9list_av_9IT9_T10_T11_T12_T13_T14_T15_T16_T17_E4typeEEES11_S13_S14_S15_S16_S17_S18_S19_S1A_S1B_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Player>,RBX::PlayerCharacterLoader::AvatarData,RBX::PlayerCharacterLoader::AssetLoadingData,RBX::HttpRequestResult,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >,RBX::Time,RBX::AssetService::AssetType,long,bool),boost::_bi::list9<boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::_bi::value<RBX::PlayerCharacterLoader::AvatarData>,boost::_bi::value<RBX::PlayerCharacterLoader::AssetLoadingData>,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::Time>,boost::_bi::value<RBX::AssetService::AssetType>,boost::_bi::value<long>,boost::_bi::value<bool> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::Player>,RBX::PlayerCharacterLoader::AvatarData,RBX::PlayerCharacterLoader::AssetLoadingData,RBX::HttpRequestResult,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>,RBX::Time,RBX::AssetService::AssetType,long,bool,boost::weak_ptr<RBX::Player>,RBX::PlayerCharacterLoader::AvatarData,RBX::PlayerCharacterLoader::AssetLoadingData,boost::arg<1>,boost::arg<2>,RBX::Time,RBX::AssetService::AssetType,long,bool>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Player>,RBX::PlayerCharacterLoader::AvatarData,RBX::PlayerCharacterLoader::AssetLoadingData,RBX::HttpRequestResult,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >,RBX::Time,RBX::AssetService::AssetType,long,bool),boost::_bi::list9<boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::_bi::value<RBX::PlayerCharacterLoader::AvatarData>,boost::_bi::value<RBX::PlayerCharacterLoader::AssetLoadingData>,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::Time>,boost::_bi::value<RBX::AssetService::AssetType>,boost::_bi::value<long>,boost::_bi::value<bool> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::Player>, RBX::PlayerCharacterLoader::AvatarData, RBX::PlayerCharacterLoader::AssetLoadingData, RBX::HttpRequestResult, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >, RBX::Time, RBX::AssetService::AssetType, __int64, bool),
        boost::weak_ptr<RBX::Player> a1,
        __int64 a4,
        boost::arg<2> a5,
        RBX::Time a6,
        RBX::PlayerCharacterLoader::AvatarData a2)
{
  double v8; // rax
  int (**v9)(void); // rax
  boost::detail::sp_counted_base *v10; // rax
  boost::detail::sp_counted_base *v11; // rdx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v13; // rax
  boost::detail::sp_counted_base *v14; // rax
  boost::detail::sp_counted_base *v15; // rax
  boost::detail::sp_counted_base *v16; // rbx
  boost::detail::sp_counted_base *v17; // rbx
  int (**v18)(void); // rdi
  double sec; // rdi
  boost::_bi::value<RBX::PlayerCharacterLoader::AvatarData> v21; // [rsp+0h] [rbp-E8h] BYREF
  boost::_bi::value<RBX::PlayerCharacterLoader::AssetLoadingData> a4a; // [rsp+20h] [rbp-C8h] BYREF
  boost::_bi::value<long> a1a; // [rsp+40h] [rbp-A8h] BYREF
  boost::_bi::value<bool> v24[8]; // [rsp+48h] [rbp-A0h]
  int (**v25)(void); // [rsp+50h] [rbp-98h]
  __int64 v26; // [rsp+58h] [rbp-90h]
  boost::_bi::list9<boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::_bi::value<RBX::PlayerCharacterLoader::AvatarData>,boost::_bi::value<RBX::PlayerCharacterLoader::AssetLoadingData>,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::Time>,boost::_bi::value<RBX::AssetService::AssetType>,boost::_bi::value<long>,boost::_bi::value<bool> > v27; // [rsp+60h] [rbp-88h] BYREF

  v21.t_.description.pn.pi_ = *(boost::detail::sp_counted_base **)a1.px;
  v8 = *((double *)a1.px + 1);
  v21.t_.avatarFetchStartTime.sec = v8;
  if ( v8 != 0.0 )
    _InterlockedAdd((volatile signed __int32 *)(*(_QWORD *)&v8 + 12LL), 1u);
  LOBYTE(a1a.t_) = a1.pn.pi_->_vptr$sp_counted_base;
  *(_QWORD *)&v24[0].t_ = *(_QWORD *)&a1.pn.pi_->use_count_;
  v9 = a1.pn.pi_[1]._vptr$sp_counted_base;
  v25 = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)v9 + 3, 1u);
  v26 = *(_QWORD *)&a1.pn.pi_[1].use_count_;
  a4a.t_.characterModel.px = *(boost::shared_ptr<RBX::ModelInstance>::element_type **)a4;
  v10 = *(boost::detail::sp_counted_base **)(a4 + 8);
  a4a.t_.characterModel.pn.pi_ = v10;
  if ( v10 )
    _InterlockedAdd(&v10->use_count_, 1u);
  a4a.t_.loadingAssetsRemaining.px = *(boost::shared_ptr<int>::element_type **)(a4 + 16);
  v11 = *(boost::detail::sp_counted_base **)(a4 + 24);
  a4a.t_.loadingAssetsRemaining.pn.pi_ = v11;
  if ( v11 )
    _InterlockedAdd(&v11->use_count_, 1u);
  *(_DWORD *)&v21.t_.bUseR15 = LOBYTE(a2.description.px);
  boost::_bi::list9<boost::_bi::value<boost::weak_ptr<RBX::Player>>,boost::_bi::value<RBX::PlayerCharacterLoader::AvatarData>,boost::_bi::value<RBX::PlayerCharacterLoader::AssetLoadingData>,boost::arg<1>,boost::arg<2>,boost::_bi::value<RBX::Time>,boost::_bi::value<RBX::AssetService::AssetType>,boost::_bi::value<long>,boost::_bi::value<bool>>::list9(
    &v27,
    (boost::_bi::value<boost::weak_ptr<RBX::Player> >)__PAIR128__(
                                                        &a1a,
                                                        (boost::_bi::value<RBX::PlayerCharacterLoader::AvatarData> *)&v21.t_.description.pn),
    v21,
    a4a,
    (boost::arg<1>)&a4a,
    a5,
    (boost::_bi::value<RBX::Time>)a6.sec,
    *(boost::_bi::value<RBX::AssetService::AssetType> *)&a2.bUseR15,
    a1a,
    v24[0]);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v27.a1_.t_.px;
  pi = v27.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v27.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a2_.t_.bUseR15 = v27.a2_.t_.bUseR15;
  retstr->l_.a2_.t_.description.px = v27.a2_.t_.description.px;
  v13 = v27.a2_.t_.description.pn.pi_;
  retstr->l_.a2_.t_.description.pn.pi_ = v27.a2_.t_.description.pn.pi_;
  if ( v13 )
    _InterlockedAdd(&v13->weak_count_, 1u);
  *(_OWORD *)&retstr->l_.a2_.t_.avatarFetchStartTime.sec = *(_OWORD *)&v27.a2_.t_.avatarFetchStartTime.sec;
  v14 = v27.a3_.t_.characterModel.pn.pi_;
  retstr->l_.a3_.t_.characterModel.pn.pi_ = v27.a3_.t_.characterModel.pn.pi_;
  if ( v14 )
    _InterlockedAdd(&v14->use_count_, 1u);
  retstr->l_.a3_.t_.loadingAssetsRemaining.px = v27.a3_.t_.loadingAssetsRemaining.px;
  v15 = v27.a3_.t_.loadingAssetsRemaining.pn.pi_;
  retstr->l_.a3_.t_.loadingAssetsRemaining.pn.pi_ = v27.a3_.t_.loadingAssetsRemaining.pn.pi_;
  if ( v15 )
    _InterlockedAdd(&v15->use_count_, 1u);
  retstr->l_.a6_.t_.sec = v27.a6_.t_.sec;
  retstr->l_.a7_.t_ = v27.a7_.t_;
  retstr->l_.a8_.t_ = v27.a8_.t_;
  retstr->l_.a9_.t_ = v27.a9_.t_;
  boost::_bi::storage3<boost::_bi::value<boost::weak_ptr<RBX::Player>>,boost::_bi::value<RBX::PlayerCharacterLoader::AvatarData>,boost::_bi::value<RBX::PlayerCharacterLoader::AssetLoadingData>>::~storage3(&v27);
  v16 = a4a.t_.loadingAssetsRemaining.pn.pi_;
  if ( a4a.t_.loadingAssetsRemaining.pn.pi_ )
  {
    if ( !_InterlockedSub(&a4a.t_.loadingAssetsRemaining.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
      if ( !_InterlockedSub(&v16->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
    }
  }
  v17 = a4a.t_.characterModel.pn.pi_;
  if ( a4a.t_.characterModel.pn.pi_ )
  {
    if ( !_InterlockedSub(&a4a.t_.characterModel.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
      if ( !_InterlockedSub(&v17->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
    }
  }
  v18 = v25;
  if ( v25 && !_InterlockedSub((volatile signed __int32 *)v25 + 3, 1u) )
    (*((void (__fastcall **)(int (**)(void)))*v18 + 3))(v18);
  sec = v21.t_.avatarFetchStartTime.sec;
  if ( *(_QWORD *)&v21.t_.avatarFetchStartTime.sec
    && !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v21.t_.avatarFetchStartTime.sec + 12LL), 1u) )
  {
    (*(void (__fastcall **)(double))(**(_QWORD **)&sec + 24LL))(COERCE_DOUBLE(*(_QWORD *)&sec));
  }
  return retstr;
}


// Address: 0x19a3bc0 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX5PagesEEENS_8weak_ptrINS2_6PlayerEEENS5_INS2_19HumanoidDescriptionEEENS_9unordered13unordered_mapINSt3__112basic_stringIcNSC_11char_traitsIcEENSC_9allocatorIcEEEENSC_3setIlNSC_4lessIlEENSG_IlEEEENS_4hashISI_EENSC_8equal_toISI_EENSG_INSC_4pairIKSI_SN_EEEEEES4_S7_S9_SW_EENS_3_bi6bind_tIT_PFSZ_T0_T1_T2_T3_ENSX_9list_av_4IT4_T5_T6_T7_E4typeEEES15_S17_S18_S19_S1A_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Pages>,boost::weak_ptr<RBX::Player>,boost::weak_ptr<RBX::HumanoidDescription>,boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > >),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::Pages> >,boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::_bi::value<boost::weak_ptr<RBX::HumanoidDescription> >,boost::_bi::value<boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > > > > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::Pages>,boost::weak_ptr<RBX::Player>,boost::weak_ptr<RBX::HumanoidDescription>,boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::set<long>>>>,boost::shared_ptr<RBX::Pages>,boost::weak_ptr<RBX::Player>,boost::weak_ptr<RBX::HumanoidDescription>,boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::set<long>>>>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Pages>,boost::weak_ptr<RBX::Player>,boost::weak_ptr<RBX::HumanoidDescription>,boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > >),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::Pages> >,boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::_bi::value<boost::weak_ptr<RBX::HumanoidDescription> >,boost::_bi::value<boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > > > > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::Pages>, boost::weak_ptr<RBX::Player>, boost::weak_ptr<RBX::HumanoidDescription>, boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > >),
        boost::shared_ptr<RBX::Pages> a1,
        boost::weak_ptr<RBX::Player> a2)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *px; // rax
  __int64 v7; // rax
  boost::detail::sp_counted_base *v8; // rax
  __m128i v9; // xmm1
  double v10; // xmm0_8
  unsigned __int64 v11; // rdx
  unsigned __int64 v12; // rax
  size_t v13; // rax
  unsigned __int64 v14; // rax
  unsigned __int64 v15; // rax
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r13
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx
  boost::detail::sp_counted_base *v19; // rdi
  boost::detail::sp_counted_base *v20; // rdi
  boost::detail::sp_counted_base *v21; // rbx
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > >::bucket_pointer v22; // r15
  size_t v23; // r13
  boost::unordered::detail::ptr_bucket::link_pointer v24; // rbx
  boost::detail::sp_counted_base *v25; // rdi
  __int64 v26; // rdi
  boost::detail::sp_counted_base *v27; // rbx
  boost::_bi::value<boost::weak_ptr<RBX::HumanoidDescription> > v29; // [rsp+0h] [rbp-F8h]
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > > a2a; // [rsp+10h] [rbp-E8h] BYREF
  boost::_bi::value<boost::weak_ptr<RBX::Player> > v31; // [rsp+40h] [rbp-B8h] BYREF
  int (**a1a)(void); // [rsp+50h] [rbp-A8h] BYREF
  __int64 v33; // [rsp+58h] [rbp-A0h]
  boost::_bi::value<boost::shared_ptr<RBX::Pages> > v34; // [rsp+60h] [rbp-98h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::Pages> >,boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::_bi::value<boost::weak_ptr<RBX::HumanoidDescription> >,boost::_bi::value<boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > > > > v35; // [rsp+70h] [rbp-88h] BYREF

  pi = a2.pn.pi_;
  v34.t_.px = (boost::shared_ptr<RBX::Pages>::element_type *)a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  v34.t_.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->use_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(_QWORD *)&a1.pn.pi_->use_count_;
  v33 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  v31.t_.px = *(boost::weak_ptr<RBX::Player>::element_type **)a2.px;
  v8 = (boost::detail::sp_counted_base *)*((_QWORD *)a2.px + 1);
  v31.t_.pn.pi_ = v8;
  if ( v8 )
    _InterlockedAdd(&v8->weak_count_, 1u);
  a2a.current_ = 0;
  v9 = (__m128i)_mm_sub_pd(
                  (__m128d)_mm_unpacklo_ps(
                             (__m128)(unsigned __int64)a2.pn.pi_[1]._vptr$sp_counted_base,
                             (__m128)xmmword_3E4930),
                  *(__m128d *)(&errorFunction.functor.data + 8));
  HIDWORD(v29.t_.pn.pi_) = a2.pn.pi_[1].use_count_;
  v10 = floor((*(double *)_mm_shuffle_epi32(v9, 78).m128i_i64 + *(double *)v9.m128i_i64) / *((float *)&v29.t_.pn.pi_ + 1))
      + 1.0;
  v11 = (unsigned int)(int)v10;
  if ( v10 >= 9.223372036854776e18 )
    v11 = (unsigned int)(int)(v10 - 9.223372036854776e18) ^ 0x8000000000000000LL;
  v12 = -1;
  if ( v10 < 1.844674407370955e19 )
    v12 = v11;
  if ( v12 >= 5 )
  {
    v14 = (v12 - 1) | ((v12 - 1) >> 1) | (((v12 - 1) | ((v12 - 1) >> 1)) >> 2);
    v15 = v14 | (v14 >> 4) | ((v14 | (v14 >> 4)) >> 8);
    v13 = (v15 | (v15 >> 16) | ((v15 | (v15 >> 16)) >> 32)) + 1;
  }
  else
  {
    v13 = 4;
  }
  a2a.bucket_count_ = v13;
  a2a.size_ = 0;
  a2a.mlf_ = *((float *)&v29.t_.pn.pi_ + 1);
  *(_OWORD *)&a2a.max_load_ = 0;
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::init(
    &a2a,
    (const boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > > *)pi);
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::Pages>>,boost::_bi::value<boost::weak_ptr<RBX::Player>>,boost::_bi::value<boost::weak_ptr<RBX::HumanoidDescription>>,boost::_bi::value<boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::set<long>>>>>>::list4(
    &v35,
    (boost::_bi::value<boost::shared_ptr<RBX::Pages> >)__PAIR128__(&a1a, &v34),
    (boost::_bi::value<boost::weak_ptr<RBX::Player> >)__PAIR128__(&a2a, &v31),
    v29,
    (boost::_bi::value<boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > > >)a2a);
  retstr->f_ = f;
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::Pages>>,boost::_bi::value<boost::weak_ptr<RBX::Player>>,boost::_bi::value<boost::weak_ptr<RBX::HumanoidDescription>>,boost::_bi::value<boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::set<long>>>>>>::list4(
    &retstr->l_,
    &v35);
  buckets = v35.a4_.t_.table_.buckets_;
  if ( v35.a4_.t_.table_.buckets_ )
  {
    if ( v35.a4_.t_.table_.size_ )
    {
      bucket_count = v35.a4_.t_.table_.bucket_count_;
      next = v35.a4_.t_.table_.buckets_[v35.a4_.t_.table_.bucket_count_].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        std::__tree<long>::destroy((std::__tree<long> *)&next[5], (std::__tree<long>::__node_pointer)next[6].next_);
        if ( ((__int64)next[2].next_ & 1) != 0 )
          operator delete(next[4].next_);
        operator delete(next);
        --v35.a4_.t_.table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = v35.a4_.t_.table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&v35.a4_.t_.table_.max_load_ = 0;
  }
  v19 = v35.a3_.t_.pn.pi_;
  if ( v35.a3_.t_.pn.pi_ && !_InterlockedSub(&v35.a3_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v19->_vptr$sp_counted_base + 3))(v19);
  v20 = v35.a2_.t_.pn.pi_;
  if ( v35.a2_.t_.pn.pi_ && !_InterlockedSub(&v35.a2_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v20->_vptr$sp_counted_base + 3))(v20);
  v21 = v35.a1_.t_.pn.pi_;
  if ( v35.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v35.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 2))(v21);
      if ( !_InterlockedSub(&v21->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 3))(v21);
    }
  }
  v22 = a2a.buckets_;
  if ( a2a.buckets_ )
  {
    if ( a2a.size_ )
    {
      v23 = a2a.bucket_count_;
      v24 = a2a.buckets_[a2a.bucket_count_].next_;
      do
      {
        v22[v23] = (boost::unordered::detail::ptr_bucket)v24->next_;
        std::__tree<long>::destroy((std::__tree<long> *)&v24[5], (std::__tree<long>::__node_pointer)v24[6].next_);
        if ( ((__int64)v24[2].next_ & 1) != 0 )
          operator delete(v24[4].next_);
        operator delete(v24);
        --a2a.size_;
        v24 = v22[v23].next_;
      }
      while ( v24 );
      v22 = a2a.buckets_;
    }
    operator delete(v22);
    *(_OWORD *)&a2a.max_load_ = 0;
  }
  v25 = v31.t_.pn.pi_;
  if ( v31.t_.pn.pi_ && !_InterlockedSub(&v31.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v25->_vptr$sp_counted_base + 3))(v25);
  v26 = v33;
  if ( v33 && !_InterlockedSub((volatile signed __int32 *)(v33 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v26 + 24LL))(v26);
  v27 = v34.t_.pn.pi_;
  if ( v34.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v34.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v27->_vptr$sp_counted_base + 2))(v27);
      if ( !_InterlockedSub(&v27->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v27->_vptr$sp_counted_base + 3))(v27);
    }
  }
  return retstr;
}


// Address: 0x19f2c70 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_8functionIFvlEEENSC_IFvSB_EEES4_NS_3argILi1EEESE_SG_EENS_3_bi6bind_tIT_PFSL_T0_T1_T2_T3_ENSJ_9list_av_4IT4_T5_T6_T7_E4typeEEESR_ST_SU_SV_SW_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void (long)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (long)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void ()(long)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::DataModel>,boost::arg<1>,boost::function<void ()(long)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void (long)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (long)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, std::string, boost::function<void (long)>, boost::function<void (std::string)>),
        boost::weak_ptr<RBX::DataModel> a1,
        __int64 a2)
{
  boost::detail::sp_counted_base *v6; // rax
  int (**v7)(void); // rax
  boost::detail::function::vtable_base *v8; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *pi; // rdi
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v14; // rdi
  boost::_bi::value<boost::function<void (long)> >_0 v16; // [rsp+0h] [rbp-B8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 a1a; // [rsp+20h] [rbp-98h] BYREF
  boost::_bi::value<boost::weak_ptr<RBX::DataModel> > v18; // [rsp+40h] [rbp-78h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (long)> >,boost::_bi::value<boost::function<void (std::string)> > > v19; // [rsp+50h] [rbp-68h] BYREF

  v18.t_.px = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v18.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->weak_count_, 1u);
  a1a.t_.vtable = 0;
  v7 = a1.pn.pi_->_vptr$sp_counted_base;
  if ( a1.pn.pi_->_vptr$sp_counted_base )
  {
    a1a.t_.vtable = (boost::detail::function::vtable_base *)a1.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v7 & 1) != 0 )
      a1a.t_.functor = *(boost::detail::function::function_buffer *)&a1.pn.pi_->use_count_;
    else
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v7 & 0xFFFFFFFFFFFFFFFELL))(
        &a1.pn.pi_->use_count_,
        &a1a.t_.functor,
        0);
  }
  v16.t_.vtable = 0;
  v8 = *(boost::detail::function::vtable_base **)a2;
  if ( *(_QWORD *)a2 )
  {
    v16.t_.vtable = *(boost::detail::function::vtable_base **)a2;
    if ( ((unsigned __int8)v8 & 1) != 0 )
      v16.t_.functor = *(boost::detail::function::function_buffer *)(a2 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v8
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v16.t_.functor,
        0);
  }
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(long)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v19,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(&a1a, &v18),
    (boost::arg<1>)&v16,
    v16,
    a1a);
  retstr->f_ = f;
  boost::_bi::storage4<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(long)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage4(
    &retstr->l_,
    &v19);
  if ( v19.a4_.t_.vtable )
  {
    if ( ((__int64)v19.a4_.t_.vtable & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v19.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v19.a4_.t_.functor, &v19.a4_.t_.functor, 2);
    }
    v19.a4_.t_.vtable = 0;
  }
  if ( v19.a3_.t_.vtable )
  {
    if ( ((__int64)v19.a3_.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v19.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v19.a3_.t_.functor, &v19.a3_.t_.functor, 2);
    }
    v19.a3_.t_.vtable = 0;
  }
  pi = v19.a1_.t_.pn.pi_;
  if ( v19.a1_.t_.pn.pi_ && !_InterlockedSub(&v19.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  if ( v16.t_.vtable )
  {
    if ( ((__int64)v16.t_.vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v16.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v16.t_.functor, &v16.t_.functor, 2);
    }
    v16.t_.vtable = 0;
  }
  if ( a1a.t_.vtable )
  {
    if ( ((__int64)a1a.t_.vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)a1a.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&a1a.t_.functor, &a1a.t_.functor, 2);
    }
    a1a.t_.vtable = 0;
  }
  v14 = v18.t_.pn.pi_;
  if ( v18.t_.pn.pi_ && !_InterlockedSub(&v18.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
  return retstr;
}


// Address: 0x19f32b0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_8functionIFvSB_EEESE_S4_NS_3argILi1EEESE_SE_EENS_3_bi6bind_tIT_PFSJ_T0_T1_T2_T3_ENSH_9list_av_4IT4_T5_T6_T7_E4typeEEESP_SR_SS_ST_SU_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void (std::string)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::DataModel>,boost::arg<1>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,std::string,boost::function<void (std::string)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, std::string, boost::function<void (std::string)>, boost::function<void (std::string)>),
        boost::weak_ptr<RBX::DataModel> a1,
        __int64 a2)
{
  boost::detail::sp_counted_base *v6; // rax
  int (**v7)(void); // rax
  boost::detail::function::vtable_base *v8; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *pi; // rdi
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v14; // rdi
  boost::_bi::value<boost::function<void (std::string)> >_0 v16; // [rsp+0h] [rbp-B8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 a1a; // [rsp+20h] [rbp-98h] BYREF
  boost::_bi::value<boost::weak_ptr<RBX::DataModel> > v18; // [rsp+40h] [rbp-78h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > v19; // [rsp+50h] [rbp-68h] BYREF

  v18.t_.px = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v18.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->weak_count_, 1u);
  a1a.t_.vtable = 0;
  v7 = a1.pn.pi_->_vptr$sp_counted_base;
  if ( a1.pn.pi_->_vptr$sp_counted_base )
  {
    a1a.t_.vtable = (boost::detail::function::vtable_base *)a1.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v7 & 1) != 0 )
      a1a.t_.functor = *(boost::detail::function::function_buffer *)&a1.pn.pi_->use_count_;
    else
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v7 & 0xFFFFFFFFFFFFFFFELL))(
        &a1.pn.pi_->use_count_,
        &a1a.t_.functor,
        0);
  }
  v16.t_.vtable = 0;
  v8 = *(boost::detail::function::vtable_base **)a2;
  if ( *(_QWORD *)a2 )
  {
    v16.t_.vtable = *(boost::detail::function::vtable_base **)a2;
    if ( ((unsigned __int8)v8 & 1) != 0 )
      v16.t_.functor = *(boost::detail::function::function_buffer *)(a2 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v8
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v16.t_.functor,
        0);
  }
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v19,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(&a1a, &v18),
    (boost::arg<1>)&v16,
    v16,
    a1a);
  retstr->f_ = f;
  boost::_bi::storage4<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage4(
    &retstr->l_,
    &v19);
  if ( v19.a4_.t_.vtable )
  {
    if ( ((__int64)v19.a4_.t_.vtable & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v19.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v19.a4_.t_.functor, &v19.a4_.t_.functor, 2);
    }
    v19.a4_.t_.vtable = 0;
  }
  if ( v19.a3_.t_.vtable )
  {
    if ( ((__int64)v19.a3_.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v19.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v19.a3_.t_.functor, &v19.a3_.t_.functor, 2);
    }
    v19.a3_.t_.vtable = 0;
  }
  pi = v19.a1_.t_.pn.pi_;
  if ( v19.a1_.t_.pn.pi_ && !_InterlockedSub(&v19.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  if ( v16.t_.vtable )
  {
    if ( ((__int64)v16.t_.vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v16.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v16.t_.functor, &v16.t_.functor, 2);
    }
    v16.t_.vtable = 0;
  }
  if ( a1a.t_.vtable )
  {
    if ( ((__int64)a1a.t_.vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)a1a.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&a1a.t_.functor, &a1a.t_.functor, 2);
    }
    a1a.t_.vtable = 0;
  }
  v14 = v18.t_.pn.pi_;
  if ( v18.t_.pn.pi_ && !_InterlockedSub(&v18.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
  return retstr;
}


// Address: 0x19f3b30 | Name: _ZN5boost4bindIvNS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairIKSA_SD_EEEEEEEENS_8weak_ptrINSB_9DataModelEEENS1_INSB_13ModelInstanceEEENS_8functionIFvNS1_INSB_8InstanceEEEEEENSU_IFvSA_EEESO_SR_ST_SY_S10_EENS_3_bi6bind_tIT_PFS13_T0_T1_T2_T3_T4_ENS11_9list_av_5IT5_T6_T7_T8_T9_E4typeEEES1A_S1C_S1D_S1E_S1F_S1G_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<RBX::ModelInstance>,boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::function<void (std::string)>),boost::_bi::list5<boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<RBX::ModelInstance>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<RBX::ModelInstance>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<RBX::ModelInstance>,boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::function<void (std::string)>),boost::_bi::list5<boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >, boost::weak_ptr<RBX::DataModel>, boost::shared_ptr<RBX::ModelInstance>, boost::function<void (boost::shared_ptr<RBX::Instance>)>_0, boost::function<void (std::string)>_0),
        boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > a1,
        boost::weak_ptr<RBX::DataModel> a2,
        boost::shared_ptr<RBX::ModelInstance> a3)
{
  boost::detail::sp_counted_base *bucket_count; // rax
  __int64 v7; // rax
  volatile signed __int32 *v8; // rax
  int (**v9)(void); // rax
  __int64 v10; // rax
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v12)(boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >_0 *, boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >_0 *, __int64); // rax
  void (__fastcall *v13)(boost::_bi::value<boost::function<void (std::string)> >_0 *, boost::_bi::value<boost::function<void (std::string)> >_0 *, __int64); // rax
  volatile signed __int32 *v14; // rbx
  __int64 v15; // rdi
  boost::detail::sp_counted_base *pi; // rbx
  boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> > v18; // [rsp+0h] [rbp-F8h]
  __int64 v19; // [rsp+8h] [rbp-F0h]
  boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >_0 v20; // [rsp+10h] [rbp-E8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 v21; // [rsp+30h] [rbp-C8h] BYREF
  volatile signed __int32 *v22; // [rsp+50h] [rbp-A8h]
  int (**a1a)(void); // [rsp+58h] [rbp-A0h] BYREF
  __int64 v24; // [rsp+60h] [rbp-98h]
  boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > v25; // [rsp+68h] [rbp-90h] BYREF
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > v26; // [rsp+78h] [rbp-80h] BYREF

  v25.t_.px = *(boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >::element_type **)&a1.px->table_.current_;
  bucket_count = (boost::detail::sp_counted_base *)a1.px->table_.bucket_count_;
  v25.t_.pn.pi_ = bucket_count;
  if ( bucket_count )
    _InterlockedAdd(&bucket_count->use_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(_QWORD *)&a1.pn.pi_->use_count_;
  v24 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  v21.t_.functor.bound_memfunc_ptr.obj_ptr = *(void **)a2.px;
  v8 = (volatile signed __int32 *)*((_QWORD *)a2.px + 1);
  v22 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  v20.t_.functor.bound_memfunc_ptr.obj_ptr = 0;
  v9 = a2.pn.pi_->_vptr$sp_counted_base;
  if ( a2.pn.pi_->_vptr$sp_counted_base )
  {
    v20.t_.functor.bound_memfunc_ptr.obj_ptr = a2.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v9 & 1) != 0 )
    {
      *((_QWORD *)&v21.t_.functor.data + 1) = *(_QWORD *)&a2.pn.pi_[1].use_count_;
      *(_OWORD *)&v21.t_.vtable = *(_OWORD *)&a2.pn.pi_->use_count_;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::_bi::value<boost::function<void (std::string)> >_0 *, _QWORD))((unsigned __int64)v9 & 0xFFFFFFFFFFFFFFFELL))(
        &a2.pn.pi_->use_count_,
        &v21,
        0);
    }
  }
  v18.t_.pn.pi_ = 0;
  v10 = *(_QWORD *)a3.px;
  if ( *(_QWORD *)a3.px )
  {
    v18.t_.pn.pi_ = *(boost::detail::sp_counted_base **)a3.px;
    if ( (v10 & 1) != 0 )
    {
      *((_QWORD *)&v20.t_.functor.data + 1) = *((_QWORD *)a3.px + 3);
      *(_OWORD *)&v20.t_.vtable = *(_OWORD *)((char *)a3.px + 8);
    }
    else
    {
      (*(void (__fastcall **)(char *, boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >_0 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(
        (char *)a3.px + 8,
        &v20,
        0);
    }
  }
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    &v26,
    (boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >)__PAIR128__(&a1a, &v25),
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(
                                                           (boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >_0 *)(&v20.t_.functor.data + 16),
                                                           (boost::_bi::value<boost::function<void (std::string)> >_0 *)(&v21.t_.functor.data + 16)),
    v18,
    v20,
    v21);
  retstr->f_ = f;
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    &retstr->l_,
    &v26);
  if ( v26.a5_.t_.vtable )
  {
    if ( ((__int64)v26.a5_.t_.vtable & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v26.a5_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v26.a5_.t_.functor, &v26.a5_.t_.functor, 2);
    }
    v26.a5_.t_.vtable = 0;
  }
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>>::~storage4(&v26);
  if ( v19 )
  {
    if ( (v19 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >_0 *, boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >_0 *, __int64))(v19 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v20, &v20, 2);
    }
  }
  if ( v20.t_.functor.bound_memfunc_ptr.obj_ptr )
  {
    if ( (*(&v20.t_.functor.data + 16) & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::_bi::value<boost::function<void (std::string)> >_0 *, boost::_bi::value<boost::function<void (std::string)> >_0 *, __int64))((unsigned __int64)v20.t_.functor.bound_memfunc_ptr.obj_ptr & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v21, &v21, 2);
    }
    v20.t_.functor.bound_memfunc_ptr.obj_ptr = 0;
  }
  v14 = v22;
  if ( v22 )
  {
    if ( !_InterlockedSub(v22 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
      if ( !_InterlockedSub(v14 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
    }
  }
  v15 = v24;
  if ( v24 && !_InterlockedSub((volatile signed __int32 *)(v24 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 24LL))(v15);
  pi = v25.t_.pn.pi_;
  if ( v25.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v25.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x19f46e0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEENS2_10Reflection7VariantENS_4hashISF_EENS9_8equal_toISF_EENSD_INS9_4pairIKSF_SH_EEEEEEEEEEENS5_IFvSF_EEESF_S4_SU_SW_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFS11_T0_T1_T2_T3_ENSZ_9list_av_4IT4_T5_T6_T7_E4typeEEES17_S19_S1A_S1B_S1C_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)>,boost::function<void (std::string)>,std::string),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> >,boost::_bi::value<boost::function<void (std::string)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>,std::string,boost::weak_ptr<RBX::DataModel>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)>,boost::function<void (std::string)>,std::string),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> >,boost::_bi::value<boost::function<void (std::string)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)>, boost::function<void (std::string)>, std::string),
        boost::weak_ptr<RBX::DataModel> a1,
        __int64 a4)
{
  boost::detail::sp_counted_base *v6; // rax
  int (**v7)(void); // rax
  boost::detail::function::vtable_base *v8; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *pi; // rdi
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v14; // rdi
  boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> >_0 v16; // [rsp+0h] [rbp-B8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 a1a; // [rsp+20h] [rbp-98h] BYREF
  boost::_bi::value<boost::weak_ptr<RBX::DataModel> > v18; // [rsp+40h] [rbp-78h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> >,boost::_bi::value<boost::function<void (std::string)> >,boost::arg<1> > v19; // [rsp+50h] [rbp-68h] BYREF

  v18.t_.px = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v18.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->weak_count_, 1u);
  a1a.t_.vtable = 0;
  v7 = a1.pn.pi_->_vptr$sp_counted_base;
  if ( a1.pn.pi_->_vptr$sp_counted_base )
  {
    a1a.t_.vtable = (boost::detail::function::vtable_base *)a1.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v7 & 1) != 0 )
      a1a.t_.functor = *(boost::detail::function::function_buffer *)&a1.pn.pi_->use_count_;
    else
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v7 & 0xFFFFFFFFFFFFFFFELL))(
        &a1.pn.pi_->use_count_,
        &a1a.t_.functor,
        0);
  }
  v16.t_.vtable = 0;
  v8 = *(boost::detail::function::vtable_base **)a4;
  if ( *(_QWORD *)a4 )
  {
    v16.t_.vtable = *(boost::detail::function::vtable_base **)a4;
    if ( ((unsigned __int8)v8 & 1) != 0 )
      v16.t_.functor = *(boost::detail::function::function_buffer *)(a4 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v8
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a4 + 8,
        &v16.t_.functor,
        0);
  }
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::arg<1>>::list4(
    &v19,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(&a1a, &v18),
    v16,
    a1a,
    (boost::arg<1>)&v16);
  retstr->f_ = f;
  boost::_bi::storage3<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage3(
    &retstr->l_,
    &v19);
  if ( v19.a3_.t_.vtable )
  {
    if ( ((__int64)v19.a3_.t_.vtable & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v19.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v19.a3_.t_.functor, &v19.a3_.t_.functor, 2);
    }
    v19.a3_.t_.vtable = 0;
  }
  if ( v19.a2_.t_.vtable )
  {
    if ( ((__int64)v19.a2_.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v19.a2_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v19.a2_.t_.functor, &v19.a2_.t_.functor, 2);
    }
    v19.a2_.t_.vtable = 0;
  }
  pi = v19.a1_.t_.pn.pi_;
  if ( v19.a1_.t_.pn.pi_ && !_InterlockedSub(&v19.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  if ( v16.t_.vtable )
  {
    if ( ((__int64)v16.t_.vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v16.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v16.t_.functor, &v16.t_.functor, 2);
    }
    v16.t_.vtable = 0;
  }
  if ( a1a.t_.vtable )
  {
    if ( ((__int64)a1a.t_.vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)a1a.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&a1a.t_.functor, &a1a.t_.functor, 2);
    }
    a1a.t_.vtable = 0;
  }
  v14 = v18.t_.pn.pi_;
  if ( v18.t_.pn.pi_ && !_InterlockedSub(&v18.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
  return retstr;
}


// Address: 0x19f4df0 | Name: _ZN5boost4bindIvNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEbNS_8functionIFvNS_10shared_ptrIN3RBX8InstanceEEEEEENS8_IFvS7_EEENS_3argILi1EEEbSE_SG_EENS_3_bi6bind_tIT_PFSL_T0_T1_T2_T3_ENSJ_9list_av_4IT4_T5_T6_T7_E4typeEEESR_ST_SU_SV_SW_
boost::_bi::bind_t<void,void (*)(std::string,bool,boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::function<void (std::string)>),boost::_bi::list4<boost::arg<1>,boost::_bi::value<bool>,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,std::string,bool,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>,boost::arg<1>,bool,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(std::string,bool,boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::function<void (std::string)>),boost::_bi::list4<boost::arg<1>,boost::_bi::value<bool>,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(std::string, bool, boost::function<void (boost::shared_ptr<RBX::Instance>)>, boost::function<void (std::string)>),
        boost::arg<1> a1,
        __int64 a2,
        __int64 a5)
{
  boost::detail::function::vtable_base *v7; // rax
  boost::detail::function::vtable_base *v8; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >_0 v14; // [rsp+0h] [rbp-A8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 v15; // [rsp+20h] [rbp-88h] BYREF
  boost::_bi::list4<boost::arg<1>,boost::_bi::value<bool>,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > l; // [rsp+40h] [rbp-68h] BYREF

  v15.t_.vtable = 0;
  v7 = *(boost::detail::function::vtable_base **)a2;
  if ( *(_QWORD *)a2 )
  {
    v15.t_.vtable = *(boost::detail::function::vtable_base **)a2;
    if ( ((unsigned __int8)v7 & 1) != 0 )
      v15.t_.functor = *(boost::detail::function::function_buffer *)(a2 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v7
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v15.t_.functor,
        0);
  }
  v14.t_.vtable = 0;
  v8 = *(boost::detail::function::vtable_base **)a5;
  if ( *(_QWORD *)a5 )
  {
    v14.t_.vtable = *(boost::detail::function::vtable_base **)a5;
    if ( ((unsigned __int8)v8 & 1) != 0 )
      v14.t_.functor = *(boost::detail::function::function_buffer *)(a5 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v8
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a5 + 8,
        &v14.t_.functor,
        0);
  }
  boost::_bi::list4<boost::arg<1>,boost::_bi::value<bool>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &l,
    a1,
    (boost::_bi::value<bool>)&v15,
    v14,
    v15);
  boost::_bi::bind_t<void,void (*)(std::string,bool,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>),boost::_bi::list4<boost::arg<1>,boost::_bi::value<bool>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>::bind_t(
    retstr,
    f,
    &l);
  if ( l.a4_.t_.vtable )
  {
    if ( ((__int64)l.a4_.t_.vtable & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)l.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&l.a4_.t_.functor, &l.a4_.t_.functor, 2);
    }
    l.a4_.t_.vtable = 0;
  }
  if ( l.a3_.t_.vtable )
  {
    if ( ((__int64)l.a3_.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)l.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&l.a3_.t_.functor, &l.a3_.t_.functor, 2);
    }
    l.a3_.t_.vtable = 0;
  }
  if ( v14.t_.vtable )
  {
    if ( ((__int64)v14.t_.vtable & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v14.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v14.t_.functor, &v14.t_.functor, 2);
    }
    v14.t_.vtable = 0;
  }
  if ( v15.t_.vtable )
  {
    if ( ((__int64)v15.t_.vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v15.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v15.t_.functor, &v15.t_.functor, 2);
    }
    v15.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x19f5cc0 | Name: _ZN5boost4bindIN3RBX13worker_thread11work_resultENS_10shared_ptrINS1_13AbuseReporter4dataEEENSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEES7_SE_EENS_3_bi6bind_tIT_PFSH_T0_T1_ENSF_9list_av_2IT2_T3_E4typeEEESL_SN_SO_
_QWORD *__fastcall boost::bind<RBX::worker_thread::work_result,boost::shared_ptr<RBX::AbuseReporter::data>,std::string,boost::shared_ptr<RBX::AbuseReporter::data>,std::string>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4)
{
  volatile signed __int32 *v4; // rax
  volatile signed __int32 *v5; // rax
  volatile signed __int32 *v6; // rbx
  volatile signed __int32 *v7; // rbx
  __int64 v9; // [rsp+0h] [rbp-68h] BYREF
  volatile signed __int32 *v10; // [rsp+8h] [rbp-60h]
  _BYTE v11[16]; // [rsp+10h] [rbp-58h] BYREF
  void *v12; // [rsp+20h] [rbp-48h]
  __int64 v13; // [rsp+28h] [rbp-40h] BYREF
  volatile signed __int32 *v14; // [rsp+30h] [rbp-38h]
  char v15[16]; // [rsp+38h] [rbp-30h] BYREF
  void *ptr; // [rsp+48h] [rbp-20h]

  v9 = *a3;
  v4 = (volatile signed __int32 *)a3[1];
  v10 = v4;
  if ( v4 )
    _InterlockedAdd(v4 + 2, 1u);
  std::string::basic_string(v11, a4);
  boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::AbuseReporter::data>>,boost::_bi::value<std::string>>::list2(
    &v13,
    &v9,
    v11);
  *a1 = a2;
  a1[1] = v13;
  v5 = v14;
  a1[2] = v14;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  std::string::basic_string(a1 + 3, v15);
  if ( (v15[0] & 1) != 0 )
    operator delete(ptr);
  v6 = v14;
  if ( v14 )
  {
    if ( !_InterlockedSub(v14 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( (v11[0] & 1) != 0 )
    operator delete(v12);
  v7 = v10;
  if ( v10 )
  {
    if ( !_InterlockedSub(v10 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
      if ( !_InterlockedSub(v7 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
    }
  }
  return a1;
}


// Address: 0x19f78b0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX8InstanceEEElbS4_lbEENS_3_bi6bind_tIT_PFS7_T0_T1_T2_ENS5_9list_av_3IT3_T4_T5_E4typeEEESC_SE_SF_SG_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Instance>,long,bool),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::Instance> >,boost::_bi::value<long>,boost::_bi::value<bool> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::Instance>,long,bool,boost::weak_ptr<RBX::Instance>,long,bool>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Instance>,long,bool),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::Instance> >,boost::_bi::value<long>,boost::_bi::value<bool> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::Instance>, __int64, bool),
        boost::weak_ptr<RBX::Instance> a1,
        _BOOL8 a2,
        __int64 a3)
{
  __int64 v5; // rax
  bool v6; // r15
  boost::detail::sp_counted_base *pi; // r12
  int (**v8)(void); // rbp
  boost::detail::sp_counted_base *px; // rbx

  v6 = a2;
  pi = a1.pn.pi_;
  v8 = a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  if ( px )
  {
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    _InterlockedAdd(&px->weak_count_, 1u);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Instance>, __int64, bool), boost::weak_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *, _BOOL8, __int64, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3,
        v5);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Instance>, __int64, bool), boost::weak_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *, _BOOL8, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Instance>, __int64, bool), boost::weak_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *, _BOOL8, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::Instance>::element_type *)v8;
    retstr->l_.a1_.t_.pn.pi_ = px;
    _InterlockedAdd(&px->weak_count_, 1u);
    retstr->l_.a2_.t_ = (__int64)pi;
    retstr->l_.a3_.t_ = v6;
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Instance>, __int64, bool), boost::weak_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *, _BOOL8, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::Instance>, __int64, bool), boost::weak_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *, _BOOL8, __int64))px->_vptr$sp_counted_base
       + 3))(
        px,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = (boost::weak_ptr<RBX::Instance>::element_type *)v8;
    retstr->l_.a1_.t_.pn.pi_ = 0;
    retstr->l_.a2_.t_ = (__int64)a1.pn.pi_;
    retstr->l_.a3_.t_ = a2;
  }
  return retstr;
}


// Address: 0x19fbc40 | Name: _ZN5boost4bindIvN3RBX17HttpRequestResultENS_10shared_ptrINSt3__16vectorINS3_INS1_8InstanceEEENS4_9allocatorIS7_EEEEEENS4_12basic_stringIcNS4_11char_traitsIcEENS8_IcEEEENS3_INS1_13ModelInstanceEEENS3_IiEENS_8functionIFvS7_EEENSK_IFvSG_EEENS_3argILi1EEENSP_ILi2EEESG_SI_SJ_SM_SO_EENS_3_bi6bind_tIT_PFSU_T0_T1_T2_T3_T4_T5_T6_ENSS_9list_av_7IT7_T8_T9_T10_T11_T12_T13_E4typeEEES13_S15_S16_S17_S18_S19_S1A_S1B_
_QWORD *__fastcall boost::bind<void,RBX::HttpRequestResult,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>,std::string,boost::shared_ptr<RBX::ModelInstance>,boost::shared_ptr<int>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>,boost::arg<1>,boost::arg<2>,std::string,boost::shared_ptr<RBX::ModelInstance>,boost::shared_ptr<int>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5,
        __int64 *a6,
        __int64 *a7)
{
  volatile signed __int32 *v10; // rax
  volatile signed __int32 *v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  void (__fastcall *v14)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v15)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v16)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v17; // rbx
  volatile signed __int32 *v18; // rbx
  __int64 v20; // [rsp+0h] [rbp-118h] BYREF
  __int128 v21; // [rsp+8h] [rbp-110h] BYREF
  __int64 v22; // [rsp+18h] [rbp-100h]
  __int64 v23; // [rsp+20h] [rbp-F8h] BYREF
  __int128 v24; // [rsp+28h] [rbp-F0h] BYREF
  __int64 v25; // [rsp+38h] [rbp-E0h]
  __int64 v26; // [rsp+40h] [rbp-D8h] BYREF
  volatile signed __int32 *v27; // [rsp+48h] [rbp-D0h]
  __int64 v28; // [rsp+50h] [rbp-C8h] BYREF
  volatile signed __int32 *v29; // [rsp+58h] [rbp-C0h]
  _BYTE v30[16]; // [rsp+60h] [rbp-B8h] BYREF
  void *ptr; // [rsp+70h] [rbp-A8h]
  _BYTE v32[88]; // [rsp+78h] [rbp-A0h] BYREF
  __int64 v33; // [rsp+D0h] [rbp-48h]
  _BYTE v34[64]; // [rsp+D8h] [rbp-40h] BYREF

  std::string::basic_string(v30, a3);
  v28 = *a4;
  v10 = (volatile signed __int32 *)a4[1];
  v29 = v10;
  if ( v10 )
    _InterlockedAdd(v10 + 2, 1u);
  v26 = *a5;
  v11 = (volatile signed __int32 *)a5[1];
  v27 = v11;
  if ( v11 )
    _InterlockedAdd(v11 + 2, 1u);
  v23 = 0;
  v12 = *a6;
  if ( *a6 )
  {
    v23 = *a6;
    if ( (v12 & 1) != 0 )
    {
      v25 = a6[3];
      v24 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v24, 0);
    }
  }
  v20 = 0;
  v13 = *a7;
  if ( *a7 )
  {
    v20 = *a7;
    if ( (v13 & 1) != 0 )
    {
      v22 = a7[3];
      v21 = *(_OWORD *)(a7 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v13 & 0xFFFFFFFFFFFFFFFELL))(a7 + 1, &v21, 0);
    }
  }
  boost::_bi::list7<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance>>,boost::_bi::value<boost::shared_ptr<int>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list7(
    v32,
    v30,
    &v28,
    &v26,
    &v23,
    &v20);
  *a1 = a2;
  boost::_bi::storage7<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance>>,boost::_bi::value<boost::shared_ptr<int>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage7(
    (boost::_bi::storage7<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> >,boost::_bi::value<boost::shared_ptr<int> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::storage7<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> >,boost::_bi::value<boost::shared_ptr<int> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v32);
  if ( v33 )
  {
    if ( (v33 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v33 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(v34, v34, 2);
    }
    v33 = 0;
  }
  boost::_bi::storage6<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance>>,boost::_bi::value<boost::shared_ptr<int>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>>::~storage6((boost::_bi::storage6<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> >,boost::_bi::value<boost::shared_ptr<int> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > > *)v32);
  if ( v20 )
  {
    if ( (v20 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v20 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v21, &v21, 2);
    }
    v20 = 0;
  }
  if ( v23 )
  {
    if ( (v23 & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v23 & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v24, &v24, 2);
    }
    v23 = 0;
  }
  v17 = v27;
  if ( v27 )
  {
    if ( !_InterlockedSub(v27 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 16LL))(v17);
      if ( !_InterlockedSub(v17 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
    }
  }
  v18 = v29;
  if ( v29 )
  {
    if ( !_InterlockedSub(v29 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 16LL))(v18);
      if ( !_InterlockedSub(v18 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 24LL))(v18);
    }
  }
  if ( (v30[0] & 1) != 0 )
    operator delete(ptr);
  return a1;
}


// Address: 0x19fcc00 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX8InstanceEEENS_8weak_ptrIS3_EENS1_INS2_13ModelInstanceEEENS_3argILi1EEEEENS_3_bi6bind_tIT_PFSD_T0_T1_ENSB_9list_av_2IT2_T3_E4typeEEESH_SJ_SK_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Instance>,boost::weak_ptr<RBX::Instance>),boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::Instance>,boost::weak_ptr<RBX::Instance>,boost::shared_ptr<RBX::ModelInstance>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Instance>,boost::weak_ptr<RBX::Instance>),boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::ModelInstance> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::Instance>, boost::weak_ptr<RBX::Instance>),
        boost::shared_ptr<RBX::ModelInstance> a1,
        __int64 a2)
{
  boost::shared_ptr<RBX::ModelInstance>::element_type *v4; // r12
  boost::detail::sp_counted_base *v5; // rbx

  v4 = *(boost::shared_ptr<RBX::ModelInstance>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::Instance>, boost::weak_ptr<RBX::Instance>), boost::shared_ptr<RBX::ModelInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::Instance>, boost::weak_ptr<RBX::Instance>), boost::shared_ptr<RBX::ModelInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::Instance>, boost::weak_ptr<RBX::Instance>), boost::shared_ptr<RBX::ModelInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::shared_ptr<RBX::Instance>, boost::weak_ptr<RBX::Instance>), boost::shared_ptr<RBX::ModelInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1a121f0 | Name: _ZN5boost4bindIvNS_10shared_ptrINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEENS1_ISt9exceptionEES8_NS_8functionIFvNS1_IKN3RBX10Reflection5TupleEEEEEENSC_IFvS8_EEENS_8weak_ptrINSD_7PlayersEEENS_3argILi1EEENSP_ILi2EEES8_SJ_SL_SO_EENS_3_bi6bind_tIT_PFSU_T0_T1_T2_T3_T4_T5_ENSS_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEES12_S14_S15_S16_S17_S18_S19_
_QWORD *__fastcall boost::bind<void,boost::shared_ptr<std::string>,boost::shared_ptr<std::exception>,std::string,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::Players>,boost::arg<1>,boost::arg<2>,std::string,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::Players>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5,
        __int64 *a6)
{
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v14; // rdi
  void (__fastcall *v15)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v16)(__int128 *, __int128 *, __int64); // rax
  __int64 v18; // [rsp+0h] [rbp-F8h] BYREF
  __int128 v19; // [rsp+8h] [rbp-F0h] BYREF
  __int64 v20; // [rsp+18h] [rbp-E0h]
  __int64 v21; // [rsp+20h] [rbp-D8h] BYREF
  __int128 v22; // [rsp+28h] [rbp-D0h] BYREF
  __int64 v23; // [rsp+38h] [rbp-C0h]
  __int64 v24; // [rsp+40h] [rbp-B8h] BYREF
  __int64 v25; // [rsp+48h] [rbp-B0h]
  _BYTE v26[16]; // [rsp+50h] [rbp-A8h] BYREF
  void *ptr; // [rsp+60h] [rbp-98h]
  _BYTE v28[88]; // [rsp+68h] [rbp-90h] BYREF
  __int64 v29; // [rsp+C0h] [rbp-38h]
  __int64 v30; // [rsp+C8h] [rbp-30h]

  std::string::basic_string(v26, a3);
  v21 = 0;
  v10 = *a4;
  if ( *a4 )
  {
    v21 = *a4;
    if ( (v10 & 1) != 0 )
    {
      v23 = a4[3];
      v22 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v22, 0);
    }
  }
  v18 = 0;
  v11 = *a5;
  if ( *a5 )
  {
    v18 = *a5;
    if ( (v11 & 1) != 0 )
    {
      v20 = a5[3];
      v19 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v19, 0);
    }
  }
  v24 = *a6;
  v12 = a6[1];
  v25 = v12;
  if ( v12 )
    _InterlockedAdd((volatile signed __int32 *)(v12 + 12), 1u);
  boost::_bi::list6<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::weak_ptr<RBX::Players>>>::list6(
    v28,
    v26,
    &v21,
    &v18,
    &v24);
  *a1 = a2;
  boost::_bi::storage5<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage5(
    (boost::_bi::storage5<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 1),
    (const boost::_bi::storage5<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v28);
  a1[12] = v29;
  v13 = v30;
  a1[13] = v30;
  if ( v13 )
    _InterlockedAdd((volatile signed __int32 *)(v13 + 12), 1u);
  boost::_bi::storage6<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::weak_ptr<RBX::Players>>>::~storage6((boost::_bi::storage6<boost::arg<1>,boost::arg<2>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::weak_ptr<RBX::Players> > > *)v28);
  v14 = v25;
  if ( v25 && !_InterlockedSub((volatile signed __int32 *)(v25 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 24LL))(v14);
  if ( v18 )
  {
    if ( (v18 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v18 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v19, &v19, 2);
    }
    v18 = 0;
  }
  if ( v21 )
  {
    if ( (v21 & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v21 & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v22, &v22, 2);
    }
    v21 = 0;
  }
  if ( (v26[0] & 1) != 0 )
    operator delete(ptr);
  return a1;
}


// Address: 0x1a2d770 | Name: _ZN5boost4bindIvPN3RBX13ScriptContextENS_10shared_ptrINS1_6PluginEEENS4_INS1_8InstanceEEES3_S6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSD_T0_T1_T2_ENSB_9list_av_3IT3_T4_T5_E4typeEEESI_SK_SL_SM_
boost::_bi::bind_t<void,void (*)(RBX::ScriptContext *,boost::shared_ptr<RBX::Plugin>,boost::shared_ptr<RBX::Instance>),boost::_bi::list3<boost::_bi::value<RBX::ScriptContext *>,boost::_bi::value<boost::shared_ptr<RBX::Plugin> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::ScriptContext *,boost::shared_ptr<RBX::Plugin>,boost::shared_ptr<RBX::Instance>,RBX::ScriptContext *,boost::shared_ptr<RBX::Plugin>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(RBX::ScriptContext *,boost::shared_ptr<RBX::Plugin>,boost::shared_ptr<RBX::Instance>),boost::_bi::list3<boost::_bi::value<RBX::ScriptContext *>,boost::_bi::value<boost::shared_ptr<RBX::Plugin> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::ScriptContext *, boost::shared_ptr<RBX::Plugin>, boost::shared_ptr<RBX::Instance>),
        RBX::ScriptContext *a1,
        boost::shared_ptr<RBX::Plugin> a2,
        __int64 a3)
{
  __int64 v5; // rax
  boost::shared_ptr<RBX::Plugin>::element_type *v7; // r13
  boost::detail::sp_counted_base *v8; // rbx
  bool v9; // bp

  v7 = *(boost::shared_ptr<RBX::Plugin>::element_type **)a2.px;
  v8 = (boost::detail::sp_counted_base *)*((_QWORD *)a2.px + 1);
  v9 = v8 == 0;
  if ( v8 )
  {
    _InterlockedAdd(&v8->use_count_, 1u);
    _InterlockedAdd(&v8->use_count_, 1u);
    _InterlockedAdd(&v8->use_count_, 1u);
    _InterlockedAdd(&v8->use_count_, 1u);
    if ( !_InterlockedSub(&v8->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::ScriptContext *, boost::shared_ptr<RBX::Plugin>, boost::shared_ptr<RBX::Instance>), RBX::ScriptContext *, boost::shared_ptr<RBX::Plugin>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v8->_vptr$sp_counted_base
       + 2))(
        v8,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3,
        v5);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
    if ( !_InterlockedSub(&v8->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::ScriptContext *, boost::shared_ptr<RBX::Plugin>, boost::shared_ptr<RBX::Instance>), RBX::ScriptContext *, boost::shared_ptr<RBX::Plugin>::element_type *, boost::detail::sp_counted_base *, __int64))v8->_vptr$sp_counted_base
       + 2))(
        v8,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
  }
  else
  {
    v9 = 1;
  }
  retstr->f_ = f;
  retstr->l_.a1_.t_ = a1;
  retstr->l_.a2_.t_.px = v7;
  retstr->l_.a2_.t_.pn.pi_ = v8;
  if ( !v9 )
  {
    _InterlockedAdd(&v8->use_count_, 1u);
    if ( !_InterlockedSub(&v8->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::ScriptContext *, boost::shared_ptr<RBX::Plugin>, boost::shared_ptr<RBX::Instance>), RBX::ScriptContext *, boost::shared_ptr<RBX::Plugin>::element_type *, boost::detail::sp_counted_base *, __int64))v8->_vptr$sp_counted_base
       + 2))(
        v8,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
    if ( !_InterlockedSub(&v8->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::ScriptContext *, boost::shared_ptr<RBX::Plugin>, boost::shared_ptr<RBX::Instance>), RBX::ScriptContext *, boost::shared_ptr<RBX::Plugin>::element_type *, boost::detail::sp_counted_base *, __int64))v8->_vptr$sp_counted_base
       + 2))(
        v8,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
  }
  return retstr;
}


// Address: 0x1a615d0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEEliNSt3__16vectorINS5_4pairINS_8functionIFvNS_10shared_ptrIKNS2_10Reflection5TupleEEEEEENS8_IFvNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEEEEEENSJ_ISO_EEEESL_S4_liSQ_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSV_T0_T1_T2_T3_T4_ENST_9list_av_5IT5_T6_T7_T8_T9_E4typeEEES12_S14_S15_S16_S17_S18_
__int64 __fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,long,int,std::vector<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>,std::string,boost::weak_ptr<RBX::DataModel>,long,int,std::vector<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>,boost::arg<1>>(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        unsigned int a5,
        const std::vector<std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> >> *a6)
{
  __int64 v9; // rax
  __int64 v10; // rax
  std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *v11; // rbx
  std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *v12; // rbp
  signed __int64 v13; // rdi
  __int64 v14; // r14
  std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *v15; // rdi
  __int64 v16; // rdi
  __int64 v17; // rdi
  void *v19; // rax
  __int64 v20; // [rsp+0h] [rbp-88h] BYREF
  __int64 v21; // [rsp+8h] [rbp-80h]
  __int64 v22; // [rsp+10h] [rbp-78h] BYREF
  __int64 v23; // [rsp+18h] [rbp-70h]
  __int64 v24; // [rsp+20h] [rbp-68h]
  int v25; // [rsp+28h] [rbp-60h]
  std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *v26; // [rsp+30h] [rbp-58h] BYREF
  std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *v27; // [rsp+38h] [rbp-50h]
  _BYTE v28[64]; // [rsp+48h] [rbp-40h] BYREF

  v20 = *a3;
  v9 = a3[1];
  v21 = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 12), 1u);
  std::vector<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>::vector(
    (std::vector<std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> >> *)v28,
    a6);
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<int>,boost::_bi::value<std::vector<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>>,boost::arg<1>>::list5(
    &v22,
    &v20,
    a4,
    a5,
    v28);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = v22;
  v10 = v23;
  *(_QWORD *)(a1 + 16) = v23;
  if ( v10 )
    _InterlockedAdd((volatile signed __int32 *)(v10 + 12), 1u);
  *(_QWORD *)(a1 + 24) = v24;
  *(_DWORD *)(a1 + 32) = v25;
  *(_OWORD *)(a1 + 40) = 0;
  *(_QWORD *)(a1 + 56) = 0;
  v11 = v26;
  v12 = v27;
  v13 = (char *)v27 - (char *)v26;
  if ( v27 != v26 )
  {
    v14 = v13 >> 6;
    if ( (unsigned __int64)(v13 >> 6) >> 58 )
    {
      std::__vector_base_common<true>::__throw_length_error(a1 + 40);
      sub_D9C950(v19);
    }
    v15 = (std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *)operator new(v13);
    *(_QWORD *)(a1 + 48) = v15;
    *(_QWORD *)(a1 + 40) = v15;
    for ( *(_QWORD *)(a1 + 56) = &v15[v14]; v12 != v11; *(_QWORD *)(a1 + 48) = v15 )
    {
      std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>::pair(
        v15,
        v11++);
      v15 = (std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *)(*(_QWORD *)(a1 + 48) + 64LL);
    }
  }
  std::__vector_base<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>::~__vector_base((std::__vector_base<std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> >> *)&v26);
  v16 = v23;
  if ( v23 && !_InterlockedSub((volatile signed __int32 *)(v23 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v16 + 24LL))(v16);
  std::__vector_base<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>::~__vector_base((std::__vector_base<std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> >> *)v28);
  v17 = v21;
  if ( v21 && !_InterlockedSub((volatile signed __int32 *)(v21 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v17 + 24LL))(v17);
  return a1;
}


// Address: 0x1a618c0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEElNSt3__16vectorINS5_4pairINS_8functionIFvNS_10shared_ptrIKNS2_10Reflection5TupleEEEEEENS8_IFvNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEEEEEENSJ_ISO_EEEESL_S4_lSQ_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSV_T0_T1_T2_T3_ENST_9list_av_4IT4_T5_T6_T7_E4typeEEES11_S13_S14_S15_S16_
__int64 __fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,long,std::vector<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>,std::string,boost::weak_ptr<RBX::DataModel>,long,std::vector<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>,boost::arg<1>>(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        const std::vector<std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> >> *a5)
{
  __int64 v7; // rax
  __int64 v8; // rax
  std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *v9; // rbx
  std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *v10; // r14
  signed __int64 v11; // rdi
  __int64 v12; // r13
  std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *v13; // rdi
  __int64 v14; // rdi
  __int64 v15; // rdi
  void *v17; // rax
  __int64 v18; // [rsp+8h] [rbp-80h] BYREF
  __int64 v19; // [rsp+10h] [rbp-78h]
  __int64 v20; // [rsp+18h] [rbp-70h] BYREF
  __int64 v21; // [rsp+20h] [rbp-68h]
  __int64 v22; // [rsp+28h] [rbp-60h]
  std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *v23; // [rsp+30h] [rbp-58h] BYREF
  std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *v24; // [rsp+38h] [rbp-50h]
  _BYTE v25[64]; // [rsp+48h] [rbp-40h] BYREF

  v18 = *a3;
  v7 = a3[1];
  v19 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  std::vector<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>::vector(
    (std::vector<std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> >> *)v25,
    a5);
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::vector<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>>,boost::arg<1>>::list4(
    &v20,
    &v18,
    a4,
    v25);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = v20;
  v8 = v21;
  *(_QWORD *)(a1 + 16) = v21;
  if ( v8 )
    _InterlockedAdd((volatile signed __int32 *)(v8 + 12), 1u);
  *(_QWORD *)(a1 + 24) = v22;
  *(_OWORD *)(a1 + 32) = 0;
  *(_QWORD *)(a1 + 48) = 0;
  v9 = v23;
  v10 = v24;
  v11 = (char *)v24 - (char *)v23;
  if ( v24 != v23 )
  {
    v12 = v11 >> 6;
    if ( (unsigned __int64)(v11 >> 6) >> 58 )
    {
      std::__vector_base_common<true>::__throw_length_error(a1 + 32);
      sub_D9C950(v17);
    }
    v13 = (std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *)operator new(v11);
    *(_QWORD *)(a1 + 40) = v13;
    *(_QWORD *)(a1 + 32) = v13;
    for ( *(_QWORD *)(a1 + 48) = &v13[v12]; v10 != v9; *(_QWORD *)(a1 + 40) = v13 )
    {
      std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>::pair(
        v13,
        v9++);
      v13 = (std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> > *)(*(_QWORD *)(a1 + 40) + 64LL);
    }
  }
  std::__vector_base<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>::~__vector_base((std::__vector_base<std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> >> *)&v23);
  v14 = v21;
  if ( v21 && !_InterlockedSub((volatile signed __int32 *)(v21 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 24LL))(v14);
  std::__vector_base<std::pair<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>>>::~__vector_base((std::__vector_base<std::pair<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)> >> *)v25);
  v15 = v19;
  if ( v19 && !_InterlockedSub((volatile signed __int32 *)(v19 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 24LL))(v15);
  return a1;
}


// Address: 0x1a61ba0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENS_10shared_ptrINSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEEESC_NS_8functionIFviEEENSE_IFvSC_EEES4_SD_NS_3argILi1EEESG_SI_EENS_3_bi6bind_tIT_PFSN_T0_T1_T2_T3_T4_ENSL_9list_av_5IT5_T6_T7_T8_T9_E4typeEEESU_SW_SX_SY_SZ_S10_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::string >,std::string,boost::function<void (int)>,boost::function<void (std::string)>),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<std::string > >,boost::arg<1>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::string>,std::string,boost::function<void ()(int)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::string>,boost::arg<1>,boost::function<void ()(int)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::string >,std::string,boost::function<void (int)>,boost::function<void (std::string)>),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<std::string > >,boost::arg<1>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, boost::shared_ptr<std::string >, std::string, boost::function<void (int)>, boost::function<void (std::string)>),
        boost::weak_ptr<RBX::DataModel> a1,
        boost::shared_ptr<std::string > a2)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v6; // rax
  volatile signed __int32 *v7; // rax
  __int64 v8; // rax
  boost::detail::function::vtable_base *v9; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  volatile signed __int32 *v13; // rbx
  boost::detail::sp_counted_base *v14; // rdi
  boost::_bi::value<boost::function<void (int)> > v16; // [rsp+0h] [rbp-D8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> > a2a; // [rsp+20h] [rbp-B8h] BYREF
  int (**a1a)(void); // [rsp+40h] [rbp-98h] BYREF
  volatile signed __int32 *v19; // [rsp+48h] [rbp-90h]
  boost::_bi::value<boost::weak_ptr<RBX::DataModel> > v20; // [rsp+50h] [rbp-88h] BYREF
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<std::string > >,boost::arg<1>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > v21; // [rsp+60h] [rbp-78h] BYREF

  pi = a2.pn.pi_;
  v20.t_.px = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v6 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v20.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->weak_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v19 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  a2a.t_.vtable = 0;
  v8 = *(_QWORD *)a2.px;
  if ( *(_QWORD *)a2.px )
  {
    a2a.t_.vtable = *(boost::detail::function::vtable_base **)a2.px;
    if ( (v8 & 1) != 0 )
      a2a.t_.functor = *(boost::detail::function::function_buffer *)((char *)a2.px + 8);
    else
      (*(void (__fastcall **)(char *, boost::detail::function::function_buffer *, _QWORD))(v8 & 0xFFFFFFFFFFFFFFFELL))(
        (char *)a2.px + 8,
        &a2a.t_.functor,
        0);
  }
  v16.t_.vtable = 0;
  v9 = (boost::detail::function::vtable_base *)pi->_vptr$sp_counted_base;
  if ( pi->_vptr$sp_counted_base )
  {
    v16.t_.vtable = (boost::detail::function::vtable_base *)pi->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v9 & 1) != 0 )
      v16.t_.functor = *(boost::detail::function::function_buffer *)&pi->use_count_;
    else
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v9 & 0xFFFFFFFFFFFFFFFELL))(
        &pi->use_count_,
        &v16.t_.functor,
        0);
  }
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::shared_ptr<std::string>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    &v21,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(&a1a, &v20),
    (boost::_bi::value<boost::shared_ptr<std::string > >)__PAIR128__(&v16, &a2a),
    (boost::arg<1>)a2.pn.pi_,
    v16,
    a2a);
  retstr->f_ = f;
  boost::_bi::storage4<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::shared_ptr<std::string>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(int)>>>::storage4(
    &retstr->l_,
    &v21);
  retstr->l_.a5_.t_.vtable = 0;
  vtable = v21.a5_.t_.vtable;
  if ( v21.a5_.t_.vtable )
  {
    retstr->l_.a5_.t_.vtable = v21.a5_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      retstr->l_.a5_.t_.functor = v21.a5_.t_.functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v21.a5_.t_.functor,
        &retstr->l_.a5_.t_.functor,
        0);
  }
  boost::_bi::storage5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::shared_ptr<std::string>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage5(&v21);
  if ( v16.t_.vtable )
  {
    if ( ((__int64)v16.t_.vtable & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v16.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v16.t_.functor, &v16.t_.functor, 2);
    }
    v16.t_.vtable = 0;
  }
  if ( a2a.t_.vtable )
  {
    if ( ((__int64)a2a.t_.vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)a2a.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&a2a.t_.functor, &a2a.t_.functor, 2);
    }
    a2a.t_.vtable = 0;
  }
  v13 = v19;
  if ( v19 )
  {
    if ( !_InterlockedSub(v19 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  v14 = v20.t_.pn.pi_;
  if ( v20.t_.pn.pi_ && !_InterlockedSub(&v20.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
  return retstr;
}


// Address: 0x1a61fc0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEENS_10shared_ptrINSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEEESC_NS_8functionIFvSC_EEES4_SD_NS_3argILi1EEESG_EENS_3_bi6bind_tIT_PFSL_T0_T1_T2_T3_ENSJ_9list_av_4IT4_T5_T6_T7_E4typeEEESR_ST_SU_SV_SW_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::string >,std::string,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<std::string > >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::string>,std::string,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::string>,boost::arg<1>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::shared_ptr<std::string >,std::string,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<std::string > >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, boost::shared_ptr<std::string >, std::string, boost::function<void (std::string)>),
        boost::weak_ptr<RBX::DataModel> a1,
        boost::shared_ptr<std::string > a2)
{
  boost::detail::sp_counted_base *v5; // rax
  volatile signed __int32 *v6; // rax
  __int64 v7; // rax
  void (__fastcall *v8)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v10; // rdi
  void (__fastcall *v11)(char *, char *, __int64); // rax
  volatile signed __int32 *v12; // rbx
  boost::detail::sp_counted_base *v13; // rdi
  boost::_bi::value<boost::function<void (std::string)> > v15; // [rsp+0h] [rbp-98h] BYREF
  __int64 v16; // [rsp+20h] [rbp-78h]
  int (**a1a)(void); // [rsp+28h] [rbp-70h] BYREF
  volatile signed __int32 *v18; // [rsp+30h] [rbp-68h]
  boost::_bi::value<boost::weak_ptr<RBX::DataModel> > v19; // [rsp+38h] [rbp-60h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::shared_ptr<std::string > >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > v20; // [rsp+48h] [rbp-50h] BYREF

  v19.t_.px = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v19.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->weak_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v18 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  v15.t_.functor.obj_ptr = 0;
  v7 = *(_QWORD *)a2.px;
  if ( *(_QWORD *)a2.px )
  {
    v15.t_.functor.obj_ptr = *(void **)a2.px;
    if ( (v7 & 1) != 0 )
    {
      v16 = *((_QWORD *)a2.px + 3);
      *(_OWORD *)(&v15.t_.functor.data + 8) = *(_OWORD *)((char *)a2.px + 8);
    }
    else
    {
      (*(void (__fastcall **)(char *, bool *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(
        (char *)a2.px + 8,
        &v15.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::shared_ptr<std::string>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v20,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(&a1a, &v19),
    (boost::_bi::value<boost::shared_ptr<std::string > >)__PAIR128__(
                                                           (unsigned __int64)a2.px,
                                                           (boost::_bi::value<boost::function<void (std::string)> > *)&v15.t_.functor),
    (boost::arg<1>)a2.pn.pi_,
    v15);
  retstr->f_ = f;
  boost::_bi::storage4<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::shared_ptr<std::string>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage4(
    &retstr->l_,
    &v20);
  if ( v20.a4_.t_.vtable )
  {
    if ( ((__int64)v20.a4_.t_.vtable & 1) == 0 )
    {
      v8 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v20.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v8 )
        v8(&v20.a4_.t_.functor, &v20.a4_.t_.functor, 2);
    }
    v20.a4_.t_.vtable = 0;
  }
  pi = v20.a2_.t_.pn.pi_;
  if ( v20.a2_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v20.a2_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  v10 = v20.a1_.t_.pn.pi_;
  if ( v20.a1_.t_.pn.pi_ && !_InterlockedSub(&v20.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
  if ( v15.t_.functor.obj_ptr )
  {
    if ( (v15.t_.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v15.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v15.t_.functor.bound_memfunc_ptr.gap8, v15.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v15.t_.functor.obj_ptr = 0;
  }
  v12 = v18;
  if ( v18 )
  {
    if ( !_InterlockedSub(v18 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  v13 = v19.t_.pn.pi_;
  if ( v19.t_.pn.pi_ && !_InterlockedSub(&v19.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
  return retstr;
}


// Address: 0x1a76990 | Name: _ZN5boost4bindIvNS_10shared_ptrINS_8functionIFvNS1_IKN3RBX10Reflection5TupleEEENS2_IFvS7_EEENS2_IFvNSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEEEEEEEEEENS1_INS3_8InstanceEEES7_S9_SI_SL_NS_3argILi1EEENSO_ILi2EEENSO_ILi3EEENSO_ILi4EEEEENS_3_bi6bind_tIT_PFSV_T0_T1_T2_T3_T4_ENST_9list_av_5IT5_T6_T7_T8_T9_E4typeEEES12_S14_S15_S16_S17_S18_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>),boost::_bi::list5<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > > *__fastcall boost::bind<void,boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>,boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>),boost::_bi::list5<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<const RBX::Reflection::Tuple>, boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>, boost::function<void (std::string)>),
        boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > a1,
        boost::arg<1> a2,
        boost::arg<2> a3)
{
  boost::detail::sp_counted_base *obj_ptr; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v7; // rbx
  boost::detail::sp_counted_base *v8; // rbx
  boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > > a1a; // [rsp+8h] [rbp-30h] BYREF
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > v11; // [rsp+18h] [rbp-20h] BYREF

  a1a.t_.px = (boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> >::element_type *)a1.px->vtable;
  obj_ptr = (boost::detail::sp_counted_base *)a1.px->functor.obj_ptr;
  a1a.t_.pn.pi_ = obj_ptr;
  if ( obj_ptr )
    _InterlockedAdd(&obj_ptr->use_count_, 1u);
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>,boost::function<void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::function<void ()(std::string)>)>>>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>>::list5(
    &v11,
    (boost::_bi::value<boost::shared_ptr<boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>,boost::function<void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::function<void (std::string)>)> > >)__PAIR128__((unsigned __int64)a1.px, &a1a),
    (boost::arg<1>)a1.pn.pi_,
    (boost::arg<2>)a2.gap0,
    (boost::arg<3>)a3.gap0);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v11.a1_.t_.px;
  pi = v11.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v11.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v7 = v11.a1_.t_.pn.pi_;
    if ( v11.a1_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v11.a1_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
  }
  v8 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
  }
  return retstr;
}


// Address: 0x1ab5ba0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX13ModelInstanceEEES4_S4_S4_EENS_3_bi6bind_tIT_PFS7_T0_T1_ENS5_9list_av_2IT2_T3_E4typeEEESB_SD_SE_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::ModelInstance>,boost::weak_ptr<RBX::ModelInstance>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> > > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::ModelInstance>,boost::weak_ptr<RBX::ModelInstance>,boost::weak_ptr<RBX::ModelInstance>,boost::weak_ptr<RBX::ModelInstance>>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::ModelInstance>,boost::weak_ptr<RBX::ModelInstance>),boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> > > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::ModelInstance>, boost::weak_ptr<RBX::ModelInstance>),
        boost::weak_ptr<RBX::ModelInstance> a1,
        boost::weak_ptr<RBX::ModelInstance> a2)
{
  boost::detail::sp_counted_base *v5; // rax
  __int64 v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // rax
  boost::detail::sp_counted_base *v9; // rdi
  boost::detail::sp_counted_base *v10; // rdi
  __int64 v11; // rdi
  boost::detail::sp_counted_base *v12; // rdi
  int (**a1a)(void); // [rsp+8h] [rbp-50h] BYREF
  __int64 v15; // [rsp+10h] [rbp-48h]
  boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> > v16; // [rsp+18h] [rbp-40h] BYREF
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> > > v17; // [rsp+28h] [rbp-30h] BYREF

  v16.t_.px = *(boost::weak_ptr<RBX::ModelInstance>::element_type **)a1.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  v16.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->weak_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(_QWORD *)&a1.pn.pi_->use_count_;
  v15 = v6;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)(v6 + 12), 1u);
  boost::_bi::list2<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance>>,boost::_bi::value<boost::weak_ptr<RBX::ModelInstance>>>::list2(
    &v17,
    (boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >)__PAIR128__(&a1a, &v16),
    (boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >)__PAIR128__(
                                                               (unsigned __int64)a2.px,
                                                               (unsigned __int64)a1.pn.pi_));
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v17.a1_.t_.px;
  pi = v17.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v17.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a2_.t_.px = v17.a2_.t_.px;
  v8 = v17.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v17.a2_.t_.pn.pi_;
  if ( v8 )
  {
    _InterlockedAdd(&v8->weak_count_, 1u);
    v9 = v17.a2_.t_.pn.pi_;
    if ( v17.a2_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v17.a2_.t_.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  v10 = v17.a1_.t_.pn.pi_;
  if ( v17.a1_.t_.pn.pi_ && !_InterlockedSub(&v17.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
  v11 = v15;
  if ( v15 && !_InterlockedSub((volatile signed __int32 *)(v15 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 24LL))(v11);
  v12 = v16.t_.pn.pi_;
  if ( v16.t_.pn.pi_ && !_InterlockedSub(&v16.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
  return retstr;
}


// Address: 0x1b2fc90 | Name: _ZN5boost4bindIvPN3RBX9DataModelENS_10shared_ptrINS1_8InstanceEEES6_NS4_INS_7promiseIvEEEENS_8functionIFvS6_EEES3_S6_NS_3argILi1EEES9_SC_EENS_3_bi6bind_tIT_PFSH_T0_T1_T2_T3_T4_ENSF_9list_av_5IT5_T6_T7_T8_T9_E4typeEEESO_SQ_SR_SS_ST_SU_
boost::_bi::bind_t<void,void (*)(RBX::DataModel *,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<boost::promise<void> >,boost::function<void (boost::shared_ptr<RBX::Instance>)>),boost::_bi::list5<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<boost::promise<void> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > > > *__fastcall boost::bind<void,RBX::DataModel *,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<boost::promise<void>>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,RBX::DataModel *,boost::shared_ptr<RBX::Instance>,boost::arg<1>,boost::shared_ptr<boost::promise<void>>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>(
        boost::_bi::bind_t<void,void (*)(RBX::DataModel *,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<boost::promise<void> >,boost::function<void (boost::shared_ptr<RBX::Instance>)>),boost::_bi::list5<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<boost::promise<void> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > > > *__return_ptr retstr,
        void (*f)(RBX::DataModel *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<boost::promise<void> >, boost::function<void (boost::shared_ptr<RBX::Instance>)>),
        RBX::DataModel *a1,
        boost::shared_ptr<RBX::Instance> a2,
        __int64 a3)
{
  boost::detail::sp_counted_base *px; // rax
  volatile signed __int32 *v7; // rax
  boost::detail::sp_counted_base *v8; // rax
  boost::_bi::value<boost::shared_ptr<RBX::Instance> > v9; // rdx
  void (__fastcall *v10)(boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > *, boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > *, __int64); // rax
  volatile signed __int32 *v11; // rbx
  boost::detail::sp_counted_base *pi; // rbx
  boost::_bi::value<boost::shared_ptr<boost::promise<void> > > v14; // [rsp+0h] [rbp-A8h] BYREF
  boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > v15; // [rsp+10h] [rbp-98h] BYREF
  volatile signed __int32 *v16; // [rsp+30h] [rbp-78h]
  boost::_bi::value<boost::shared_ptr<RBX::Instance> > v17; // [rsp+38h] [rbp-70h] BYREF
  boost::_bi::list5<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<boost::promise<void> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > > v18; // [rsp+48h] [rbp-60h] BYREF

  v17.t_.px = (boost::shared_ptr<RBX::Instance>::element_type *)a2.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a2.px->weak_this_.px;
  v17.t_.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->use_count_, 1u);
  v15.t_.functor.bound_memfunc_ptr.obj_ptr = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(volatile signed __int32 **)&a2.pn.pi_->use_count_;
  v16 = v7;
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  v14.t_.pn.pi_ = 0;
  v8 = *(boost::detail::sp_counted_base **)a3;
  if ( *(_QWORD *)a3 )
  {
    v14.t_.pn.pi_ = *(boost::detail::sp_counted_base **)a3;
    if ( ((unsigned __int8)v8 & 1) != 0 )
    {
      *((_QWORD *)&v15.t_.functor.data + 1) = *(_QWORD *)(a3 + 24);
      *(_OWORD *)&v15.t_.vtable = *(_OWORD *)(a3 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > *, _QWORD))((unsigned __int64)v8 & 0xFFFFFFFFFFFFFFFELL))(
        a3 + 8,
        &v15,
        0);
    }
  }
  v9.t_.px = (boost::shared_ptr<RBX::Instance>::element_type *)&v17;
  v9.t_.pn.pi_ = (boost::detail::sp_counted_base *)(&v15.t_.functor.data + 16);
  boost::_bi::list5<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<boost::promise<void>>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>>::list5(
    &v18,
    (boost::_bi::value<RBX::DataModel *>)a1,
    v9,
    (boost::arg<1>)&v14.t_.pn,
    v14,
    v15);
  retstr->f_ = f;
  boost::_bi::list5<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<boost::promise<void>>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>>::list5(
    &retstr->l_,
    &v18);
  boost::_bi::storage5<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<boost::promise<void>>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>>::~storage5(&v18);
  if ( v14.t_.pn.pi_ )
  {
    if ( ((__int64)v14.t_.pn.pi_ & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > *, boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > *, __int64))((unsigned __int64)v14.t_.pn.pi_ & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v15, &v15, 2);
    }
    v14.t_.pn.pi_ = 0;
  }
  v11 = v16;
  if ( v16 )
  {
    if ( !_InterlockedSub(v16 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
  pi = v17.t_.pn.pi_;
  if ( v17.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v17.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x1b3c3e0 | Name: _ZN5boost4bindIvNS_10shared_ptrIN3RBX8InstanceEEES4_NS1_INS_7promiseIvEEEENS_8functionIFvS4_EEES4_S4_S7_SA_EENS_3_bi6bind_tIT_PFSD_T0_T1_T2_T3_ENSB_9list_av_4IT4_T5_T6_T7_E4typeEEESJ_SL_SM_SN_SO_
boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<boost::promise<void> >,boost::function<void (boost::shared_ptr<RBX::Instance>)>),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<boost::promise<void> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > > > *__fastcall boost::bind<void,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<boost::promise<void>>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<boost::promise<void>>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>(
        boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<boost::promise<void> >,boost::function<void (boost::shared_ptr<RBX::Instance>)>),boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<boost::promise<void> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > > > *__return_ptr retstr,
        void (*f)(boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<boost::promise<void> >, boost::function<void (boost::shared_ptr<RBX::Instance>)>_0),
        boost::shared_ptr<RBX::Instance> a1,
        boost::shared_ptr<RBX::Instance> a2)
{
  boost::detail::sp_counted_base *px; // rax
  volatile signed __int32 *v5; // rax
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *v6; // rax
  int (**v7)(void); // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v9; // rax
  boost::detail::sp_counted_base *v10; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v13)(_BYTE *, _BYTE *, __int64); // rax
  volatile signed __int32 *v14; // rbx
  volatile signed __int32 *v15; // rbx
  boost::detail::sp_counted_base *v16; // rbx
  _BYTE v18[48]; // [rsp+0h] [rbp-B8h] BYREF
  int (**a1a)(void); // [rsp+30h] [rbp-88h] BYREF
  volatile signed __int32 *v20; // [rsp+38h] [rbp-80h]
  boost::_bi::value<boost::shared_ptr<RBX::Instance> > v21; // [rsp+40h] [rbp-78h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<boost::promise<void> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> > > v22; // [rsp+50h] [rbp-68h] BYREF

  v21.t_.px = (boost::shared_ptr<RBX::Instance>::element_type *)a1.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a1.px->weak_this_.px;
  v21.t_.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->use_count_, 1u);
  a1a = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v20 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  *(_QWORD *)&v18[32] = a2.px->_vptr$EventSource;
  v6 = a2.px->weak_this_.px;
  *(_QWORD *)&v18[40] = v6;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)&v6->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>, 1u);
  *(_QWORD *)v18 = 0;
  v7 = a2.pn.pi_->_vptr$sp_counted_base;
  if ( a2.pn.pi_->_vptr$sp_counted_base )
  {
    *(_QWORD *)v18 = a2.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v7 & 1) != 0 )
    {
      *(_QWORD *)&v18[24] = *(_QWORD *)&a2.pn.pi_[1].use_count_;
      *(_OWORD *)&v18[8] = *(_OWORD *)&a2.pn.pi_->use_count_;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, _BYTE *, _QWORD))((unsigned __int64)v7
                                                                                     & 0xFFFFFFFFFFFFFFFELL))(
        &a2.pn.pi_->use_count_,
        &v18[8],
        0);
    }
  }
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::shared_ptr<boost::promise<void>>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>>::list4(
    &v22,
    (boost::_bi::value<boost::shared_ptr<RBX::Instance> >)__PAIR128__(&a1a, &v21),
    (boost::_bi::value<boost::shared_ptr<RBX::Instance> >)__PAIR128__(v18, &v18[32]),
    *(boost::_bi::value<boost::shared_ptr<boost::promise<void> > > *)v18,
    *(boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >_0 *)&v18[16]);
  retstr->f_ = f;
  retstr->l_.a1_.t_.px = v22.a1_.t_.px;
  pi = v22.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v22.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a2_.t_.px = v22.a2_.t_.px;
  v9 = v22.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v22.a2_.t_.pn.pi_;
  if ( v9 )
    _InterlockedAdd(&v9->use_count_, 1u);
  retstr->l_.a3_.t_.px = v22.a3_.t_.px;
  v10 = v22.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v22.a3_.t_.pn.pi_;
  if ( v10 )
    _InterlockedAdd(&v10->use_count_, 1u);
  retstr->l_.a4_.t_.vtable = 0;
  vtable = v22.a4_.t_.vtable;
  if ( v22.a4_.t_.vtable )
  {
    retstr->l_.a4_.t_.vtable = v22.a4_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a4_.t_.functor = v22.a4_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v22.a4_.t_.functor,
        &retstr->l_.a4_.t_.functor,
        0);
      if ( !v22.a4_.t_.vtable )
        goto LABEL_26;
      if ( ((__int64)v22.a4_.t_.vtable & 1) == 0 )
      {
        v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v22.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v12 )
          v12(&v22.a4_.t_.functor, &v22.a4_.t_.functor, 2);
      }
    }
    v22.a4_.t_.vtable = 0;
  }
LABEL_26:
  boost::_bi::storage3<boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::shared_ptr<boost::promise<void>>>>::~storage3(&v22);
  if ( *(_QWORD *)v18 )
  {
    if ( (v18[0] & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)v18 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v18[8], &v18[8], 2);
    }
    *(_QWORD *)v18 = 0;
  }
  v14 = *(volatile signed __int32 **)&v18[40];
  if ( *(_QWORD *)&v18[40] )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v18[40] + 8LL), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
      if ( !_InterlockedSub(v14 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
    }
  }
  v15 = v20;
  if ( v20 )
  {
    if ( !_InterlockedSub(v20 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  v16 = v21.t_.pn.pi_;
  if ( v21.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v21.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
      if ( !_InterlockedSub(&v16->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
    }
  }
  return retstr;
}


// Address: 0x1b3c910 | Name: _ZN5boost4bindIvNSt3__16vectorINS_10shared_ptrIN3RBX8InstanceEEENS1_9allocatorIS6_EEEES6_NS3_IN16PackageUtilities23AutoUpdateApplyMetadataEEENS3_INS_7promiseIvEEEES9_NS_3argILi1EEESC_SF_EENS_3_bi6bind_tIT_PFSK_T0_T1_T2_T3_ENSI_9list_av_4IT4_T5_T6_T7_E4typeEEESQ_SS_ST_SU_SV_
_QWORD *__fastcall boost::bind<void,std::vector<boost::shared_ptr<RBX::Instance>>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<PackageUtilities::AutoUpdateApplyMetadata>,boost::shared_ptr<boost::promise<void>>,std::vector<boost::shared_ptr<RBX::Instance>>,boost::arg<1>,boost::shared_ptr<PackageUtilities::AutoUpdateApplyMetadata>,boost::shared_ptr<boost::promise<void>>>(
        _QWORD *a1,
        __int64 a2,
        const std::vector<boost::shared_ptr<RBX::Instance>> *a3,
        __int64 *a4,
        __int64 *a5)
{
  volatile signed __int32 *v8; // rax
  volatile signed __int32 *v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  volatile signed __int32 *v12; // rbx
  volatile signed __int32 *v13; // rbx
  char *v14; // r14
  char *v15; // rbx
  volatile signed __int32 *v16; // r12
  void *v17; // rdi
  void *ptr; // [rsp+8h] [rbp-90h] BYREF
  char *v20; // [rsp+10h] [rbp-88h]
  __int64 v21; // [rsp+20h] [rbp-78h] BYREF
  volatile signed __int32 *v22; // [rsp+28h] [rbp-70h]
  __int64 v23; // [rsp+30h] [rbp-68h] BYREF
  volatile signed __int32 *v24; // [rsp+38h] [rbp-60h]
  _BYTE v25[24]; // [rsp+40h] [rbp-58h] BYREF
  __int64 v26; // [rsp+58h] [rbp-40h]
  __int64 v27; // [rsp+60h] [rbp-38h]
  __int64 v28; // [rsp+68h] [rbp-30h]
  __int64 v29; // [rsp+70h] [rbp-28h]

  std::vector<boost::shared_ptr<RBX::Instance>>::vector((std::vector<boost::shared_ptr<RBX::Instance>> *)&ptr, a3);
  v23 = *a4;
  v8 = (volatile signed __int32 *)a4[1];
  v24 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  v21 = *a5;
  v9 = (volatile signed __int32 *)a5[1];
  v22 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  boost::_bi::list4<boost::_bi::value<std::vector<boost::shared_ptr<RBX::Instance>>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<PackageUtilities::AutoUpdateApplyMetadata>>,boost::_bi::value<boost::shared_ptr<boost::promise<void>>>>::list4(
    v25,
    &ptr,
    &v23,
    &v21);
  *a1 = a2;
  std::vector<boost::shared_ptr<RBX::Instance>>::vector(
    (std::vector<boost::shared_ptr<RBX::Instance>> *)(a1 + 1),
    (const std::vector<boost::shared_ptr<RBX::Instance>> *)v25);
  a1[4] = v26;
  v10 = v27;
  a1[5] = v27;
  if ( v10 )
    _InterlockedAdd((volatile signed __int32 *)(v10 + 8), 1u);
  a1[6] = v28;
  v11 = v29;
  a1[7] = v29;
  if ( v11 )
    _InterlockedAdd((volatile signed __int32 *)(v11 + 8), 1u);
  boost::_bi::storage4<boost::_bi::value<std::vector<boost::shared_ptr<RBX::Instance>>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<PackageUtilities::AutoUpdateApplyMetadata>>,boost::_bi::value<boost::shared_ptr<boost::promise<void>>>>::~storage4((boost::_bi::storage4<boost::_bi::value<std::vector<boost::shared_ptr<RBX::Instance>> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<PackageUtilities::AutoUpdateApplyMetadata> >,boost::_bi::value<boost::shared_ptr<boost::promise<void> > > > *)v25);
  v12 = v22;
  if ( v22 )
  {
    if ( !_InterlockedSub(v22 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  v13 = v24;
  if ( v24 )
  {
    if ( !_InterlockedSub(v24 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  v14 = (char *)ptr;
  if ( ptr )
  {
    v15 = v20;
    if ( v20 == ptr )
    {
      v17 = ptr;
    }
    else
    {
      do
      {
        v16 = (volatile signed __int32 *)*((_QWORD *)v15 - 1);
        if ( v16 )
        {
          if ( !_InterlockedSub(v16 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
            if ( !_InterlockedSub(v16 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
          }
        }
        v15 -= 16;
      }
      while ( v14 != v15 );
      v17 = ptr;
    }
    v20 = v14;
    operator delete(v17);
  }
  return a1;
}


// Address: 0x1c038a0 | Name: _ZN5boost4bindIvNS_8weak_ptrIN3RBX9DataModelEEEbNS2_11InputObject13UserInputTypeES4_bS6_EENS_3_bi6bind_tIT_PFS9_T0_T1_T2_ENS7_9list_av_3IT3_T4_T5_E4typeEEESE_SG_SH_SI_
boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,bool,RBX::InputObject::UserInputType),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<bool>,boost::_bi::value<RBX::InputObject::UserInputType> > > *__fastcall boost::bind<void,boost::weak_ptr<RBX::DataModel>,bool,RBX::InputObject::UserInputType,boost::weak_ptr<RBX::DataModel>,bool,RBX::InputObject::UserInputType>(
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,bool,RBX::InputObject::UserInputType),boost::_bi::list3<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<bool>,boost::_bi::value<RBX::InputObject::UserInputType> > > *__return_ptr retstr,
        void (*f)(boost::weak_ptr<RBX::DataModel>, bool, RBX::InputObject::UserInputType),
        boost::weak_ptr<RBX::DataModel> a1,
        __int64 a2,
        __int64 a3)
{
  __int64 v5; // rax
  RBX::InputObject::UserInputType v6; // r15d
  char pi; // r12
  boost::weak_ptr<RBX::DataModel>::element_type *v8; // rbp
  boost::detail::sp_counted_base *v9; // rbx

  v6 = (int)a2;
  pi = (char)a1.pn.pi_;
  v8 = *(boost::weak_ptr<RBX::DataModel>::element_type **)a1.px;
  v9 = (boost::detail::sp_counted_base *)*((_QWORD *)a1.px + 1);
  if ( v9 )
  {
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    _InterlockedAdd(&v9->weak_count_, 1u);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::DataModel>, bool, RBX::InputObject::UserInputType), boost::weak_ptr<RBX::DataModel>::element_type *, boost::detail::sp_counted_base *, __int64, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3,
        v5);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::DataModel>, bool, RBX::InputObject::UserInputType), boost::weak_ptr<RBX::DataModel>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::DataModel>, bool, RBX::InputObject::UserInputType), boost::weak_ptr<RBX::DataModel>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v8;
    retstr->l_.a1_.t_.pn.pi_ = v9;
    _InterlockedAdd(&v9->weak_count_, 1u);
    retstr->l_.a2_.t_ = pi;
    retstr->l_.a3_.t_ = v6;
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::DataModel>, bool, RBX::InputObject::UserInputType), boost::weak_ptr<RBX::DataModel>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
    if ( !_InterlockedSub(&v9->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(boost::weak_ptr<RBX::DataModel>, bool, RBX::InputObject::UserInputType), boost::weak_ptr<RBX::DataModel>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 3))(
        v9,
        f,
        a1.px,
        a1.pn.pi_,
        a2,
        a3);
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a1_.t_.px = v8;
    retstr->l_.a1_.t_.pn.pi_ = 0;
    retstr->l_.a2_.t_ = (bool)a1.pn.pi_;
    retstr->l_.a3_.t_ = a2;
  }
  return retstr;
}


// Address: 0x1cb7b70 | Name: _ZN5boost4bindIvNS_8functionIFvN3RBX10Reflection7VariantEEEEN3rbx7signals10connectionES6_NS_3argILi1EEEEENS_3_bi6bind_tIT_PFSE_T0_T1_ENSC_9list_av_2IT2_T3_E4typeEEESI_SK_SL_
boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,rbx::signals::connection),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__fastcall boost::bind<void,boost::function<void ()(RBX::Reflection::Variant)>,rbx::signals::connection,boost::function<void ()(RBX::Reflection::Variant)>,boost::arg<1>>(
        boost::_bi::bind_t<void,void (*)(boost::function<void (RBX::Reflection::Variant)>,rbx::signals::connection),boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(boost::function<void (RBX::Reflection::Variant)>_0, rbx::signals::connection),
        __int64 *a2)
{
  __int64 v3; // rcx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v6)(__int128 *, __int128 *, __int64); // rax
  boost::arg<1> a2a[8]; // [rsp+8h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-48h] BYREF
  __int64 v10; // [rsp+20h] [rbp-38h]
  boost::_bi::list2<boost::_bi::value<boost::function<void (RBX::Reflection::Variant)> >,boost::arg<1> >_0 v11; // [rsp+28h] [rbp-30h] BYREF

  *(_QWORD *)&a2a[0].gap0 = 0;
  v3 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&a2a[0].gap0 = *a2;
    if ( (v3 & 1) != 0 )
    {
      v10 = a2[3];
      v9 = *(_OWORD *)(a2 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v9, 0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::function<void ()(RBX::Reflection::Variant)>>,boost::arg<1>>::list2(
    &v11,
    (__int64)a2a);
  retstr->f_ = f;
  retstr->l_.a1_.t_.vtable = 0;
  vtable = v11.a1_.t_.vtable;
  if ( v11.a1_.t_.vtable )
  {
    retstr->l_.a1_.t_.vtable = v11.a1_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a1_.t_.functor = v11.a1_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v11.a1_.t_.functor,
        &retstr->l_.a1_.t_.functor,
        0);
      if ( !v11.a1_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v11.a1_.t_.vtable & 1) == 0 )
      {
        v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11.a1_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v5 )
          v5(&v11.a1_.t_.functor, &v11.a1_.t_.functor, 2);
      }
    }
    v11.a1_.t_.vtable = 0;
  }
LABEL_14:
  if ( *(_QWORD *)&a2a[0].gap0 )
  {
    if ( (a2a[0].gap0 & 1) == 0 )
    {
      v6 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&a2a[0].gap0 & 0xFFFFFFFFFFFFFFFELL);
      if ( v6 )
        v6(&v9, &v9, 2);
    }
    *(_QWORD *)&a2a[0].gap0 = 0;
  }
  return retstr;
}


// Address: 0x1d34790 | Name: _ZN5boost4bindIvN3RBX10Reflection7VariantENS_10shared_ptrINSt3__16vectorINS4_INS1_8InstanceEEENS5_9allocatorIS8_EEEEEENS_3argILi1EEESC_EENS_3_bi6bind_tIT_PFSH_T0_T1_ENSF_9list_av_2IT2_T3_E4typeEEESL_SN_SO_
boost::_bi::bind_t<void,void (*)(RBX::Reflection::Variant,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > > > > *__fastcall boost::bind<void,RBX::Reflection::Variant,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>,boost::arg<1>,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>(
        boost::_bi::bind_t<void,void (*)(RBX::Reflection::Variant,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >),boost::_bi::list2<boost::arg<1>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > > > > *__return_ptr retstr,
        void (*f)(RBX::Reflection::Variant, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >),
        __int64 a1,
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > a2)
{
  boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *v4; // r12
  boost::detail::sp_counted_base *v5; // rbx

  v4 = *(boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **)a1;
  v5 = *(boost::detail::sp_counted_base **)(a1 + 8);
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Reflection::Variant, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >), __int64, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1,
        a2.px,
        a2.pn.pi_);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_ = f;
    retstr->l_.a2_.t_.px = v4;
    retstr->l_.a2_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Reflection::Variant, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >), __int64, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1,
        a2.px,
        a2.pn.pi_);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Reflection::Variant, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >), __int64, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base
       + 2))(
        v5,
        f,
        a1,
        a2.px,
        a2.pn.pi_);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_ = f;
    retstr->l_.a2_.t_.px = v4;
    retstr->l_.a2_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1d465a0 | Name: _ZN5boost4bindIvN3RBX3Lua13WeakThreadRefERKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEES3_SA_EENS_3_bi6bind_tIT_PFSF_T0_T1_ENSD_9list_av_2IT2_T3_E4typeEEESJ_SL_SM_
__int64 __fastcall boost::bind<void,RBX::Lua::WeakThreadRef,std::string const&,RBX::Lua::WeakThreadRef,std::string>(
        __int64 a1,
        __int64 a2,
        const RBX::Lua::WeakThreadRef *a3,
        __int64 a4)
{
  int v5; // ecx
  int v6; // r8d
  int v7; // r9d
  int v9; // [rsp+0h] [rbp-A8h] BYREF
  void *v10; // [rsp+8h] [rbp-A0h]
  RBX::Lua::WeakThreadRef v11; // [rsp+10h] [rbp-98h] BYREF
  _BYTE v12[16]; // [rsp+48h] [rbp-60h] BYREF
  void *ptr; // [rsp+58h] [rbp-50h]
  RBX::Lua::WeakThreadRef v14; // [rsp+60h] [rbp-48h] BYREF

  RBX::Lua::WeakThreadRef::WeakThreadRef(&v14, a3);
  std::string::basic_string(&v9, a4);
  boost::_bi::list2<boost::_bi::value<RBX::Lua::WeakThreadRef>,boost::_bi::value<std::string>>::list2(
    (unsigned int)&v11.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>,
    (unsigned int)&v14,
    (unsigned int)&v9,
    v5,
    v6,
    v7,
    v9,
    v10,
    v11);
  *(_QWORD *)a1 = a2;
  RBX::Lua::WeakThreadRef::WeakThreadRef(
    (RBX::Lua::WeakThreadRef *)(a1 + 8),
    (const RBX::Lua::WeakThreadRef *)&v11.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>);
  std::string::basic_string(a1 + 56, v12);
  if ( (v12[0] & 1) != 0 )
    operator delete(ptr);
  RBX::Lua::WeakThreadRef::~WeakThreadRef((RBX::Lua::WeakThreadRef *)&v11.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>);
  if ( (v9 & 1) != 0 )
    operator delete(v11._vptr$WeakThreadRef);
  RBX::Lua::WeakThreadRef::~WeakThreadRef(&v14);
  return a1;
}


// Address: 0x201cee0 | Name: _ZN5boost4bindIvRKNS_10shared_ptrIN3rbx10safe_queueIN3RBX8Graphics14TextureManager11LoadedImageEEEEEPNS5_6DeviceERKNS4_9ContentIdESG_jjfRKNS4_18InstanceIdentifierENS4_4TimeES9_SD_SE_SE_jjfSH_SK_EENS_3_bi6bind_tIT_PFSN_T0_T1_T2_T3_T4_T5_T6_T7_T8_ENSL_9list_av_9IT9_T10_T11_T12_T13_T14_T15_T16_T17_E4typeEEESY_S10_S11_S12_S13_S14_S15_S16_S17_S18_
_QWORD *__fastcall boost::bind<void,boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>> const&,RBX::Graphics::Device *,RBX::ContentId const&,RBX::ContentId const&,unsigned int,unsigned int,float,RBX::InstanceIdentifier const&,RBX::Time,boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>,RBX::Graphics::Device *,RBX::ContentId,RBX::ContentId,unsigned int,unsigned int,float,RBX::InstanceIdentifier,RBX::Time>(
        _QWORD *a1,
        __int64 a2,
        __int64 *a3,
        int a4,
        __int64 a5,
        __int64 a6,
        float a7,
        double a8,
        int a9,
        int a10,
        RBX::InstanceIdentifier *t)
{
  volatile signed __int32 *v13; // rax
  double v14; // xmm1_8
  volatile signed __int32 *v15; // rbx
  __int64 v17; // [rsp+10h] [rbp-168h] BYREF
  volatile signed __int32 *v18; // [rsp+18h] [rbp-160h]
  double v19; // [rsp+20h] [rbp-158h]
  _BYTE v20[16]; // [rsp+28h] [rbp-150h] BYREF
  void *v21; // [rsp+38h] [rbp-140h]
  _BYTE v22[16]; // [rsp+40h] [rbp-138h] BYREF
  void *ptr; // [rsp+50h] [rbp-128h]
  _BYTE v24[16]; // [rsp+58h] [rbp-120h] BYREF
  void *v25; // [rsp+68h] [rbp-110h]
  char v26; // [rsp+70h] [rbp-108h]
  void *v27; // [rsp+80h] [rbp-F8h]
  char v28; // [rsp+88h] [rbp-F0h]
  void *v29; // [rsp+98h] [rbp-E0h]
  _BYTE v30[208]; // [rsp+A8h] [rbp-D0h] BYREF

  v19 = a8;
  v17 = *a3;
  v13 = (volatile signed __int32 *)a3[1];
  v18 = v13;
  if ( v13 )
    _InterlockedAdd(v13 + 2, 1u);
  std::string::basic_string(v22, a5);
  std::string::basic_string(v20, a6);
  boost::_bi::value<RBX::InstanceIdentifier>::value((boost::_bi::value<RBX::InstanceIdentifier> *)v24, t);
  v14 = v19;
  boost::_bi::list9<boost::_bi::value<boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>>,boost::_bi::value<RBX::Graphics::Device *>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<unsigned int>,boost::_bi::value<unsigned int>,boost::_bi::value<float>,boost::_bi::value<RBX::InstanceIdentifier>,boost::_bi::value<RBX::Time>>::list9(
    (unsigned int)v30,
    (unsigned int)&v17,
    a4,
    (unsigned int)v22,
    (unsigned int)v20,
    a9,
    a10,
    (__int64)v24);
  *a1 = a2;
  boost::_bi::list9<boost::_bi::value<boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>>,boost::_bi::value<RBX::Graphics::Device *>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<unsigned int>,boost::_bi::value<unsigned int>,boost::_bi::value<float>,boost::_bi::value<RBX::InstanceIdentifier>,boost::_bi::value<RBX::Time>>::list9(
    (boost::_bi::list9<boost::_bi::value<boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage> > >,boost::_bi::value<RBX::Graphics::Device *>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<unsigned int>,boost::_bi::value<unsigned int>,boost::_bi::value<float>,boost::_bi::value<RBX::InstanceIdentifier>,boost::_bi::value<RBX::Time> > *)(a1 + 1),
    (const boost::_bi::list9<boost::_bi::value<boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage> > >,boost::_bi::value<RBX::Graphics::Device *>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<unsigned int>,boost::_bi::value<unsigned int>,boost::_bi::value<float>,boost::_bi::value<RBX::InstanceIdentifier>,boost::_bi::value<RBX::Time> > *)v30);
  boost::_bi::storage8<boost::_bi::value<boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>>,boost::_bi::value<RBX::Graphics::Device *>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<unsigned int>,boost::_bi::value<unsigned int>,boost::_bi::value<float>,boost::_bi::value<RBX::InstanceIdentifier>>::~storage8((boost::_bi::storage8<boost::_bi::value<boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage> > >,boost::_bi::value<RBX::Graphics::Device *>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<unsigned int>,boost::_bi::value<unsigned int>,boost::_bi::value<float>,boost::_bi::value<RBX::InstanceIdentifier> > *)v30);
  if ( (v28 & 1) != 0 )
  {
    operator delete(v29);
    if ( (v26 & 1) == 0 )
    {
LABEL_5:
      if ( (v24[0] & 1) == 0 )
        goto LABEL_6;
      goto LABEL_16;
    }
  }
  else if ( (v26 & 1) == 0 )
  {
    goto LABEL_5;
  }
  operator delete(v27);
  if ( (v24[0] & 1) == 0 )
  {
LABEL_6:
    if ( (v20[0] & 1) == 0 )
      goto LABEL_7;
LABEL_17:
    operator delete(v21);
    if ( (v22[0] & 1) == 0 )
      goto LABEL_9;
    goto LABEL_8;
  }
LABEL_16:
  operator delete(v25);
  if ( (v20[0] & 1) != 0 )
    goto LABEL_17;
LABEL_7:
  if ( (v22[0] & 1) != 0 )
LABEL_8:
    operator delete(ptr);
LABEL_9:
  v15 = v18;
  if ( v18 )
  {
    if ( !_InterlockedSub(v18 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, double, double))(*(_QWORD *)v15 + 16LL))(
        v15,
        COERCE_DOUBLE((unsigned __int64)LODWORD(a7)),
        v14);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  return a1;
}


// Address: 0x201d220 | Name: _ZN5boost4bindIvRKNS_10shared_ptrIN3rbx10safe_queueIN3RBX8Graphics14TextureManager11LoadedImageEEEEEPNS5_6DeviceERKNS4_9ContentIdEjjRKNS4_18InstanceIdentifierENS4_4TimeERKNS1_IKNSt3__112basic_stringIcNSL_11char_traitsIcEENSL_9allocatorIcEEEEEES9_SD_SE_jjSH_SK_ST_EENS_3_bi6bind_tIT_PFSY_T0_T1_T2_T3_T4_T5_T6_T7_ENSW_9list_av_8IT8_T9_T10_T11_T12_T13_T14_T15_E4typeEEES18_S1A_S1B_S1C_S1D_S1E_S1F_S1G_S1H_
__int64 __fastcall boost::bind<void,boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>> const&,RBX::Graphics::Device *,RBX::ContentId const&,unsigned int,unsigned int,RBX::InstanceIdentifier const&,RBX::Time,boost::shared_ptr<std::string const> const&,boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>,RBX::Graphics::Device *,RBX::ContentId,unsigned int,unsigned int,RBX::InstanceIdentifier,RBX::Time,boost::shared_ptr<std::string const>>(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        int a4,
        __int64 a5,
        int a6,
        double a7,
        int a8,
        RBX::InstanceIdentifier *t,
        __int64 *a10)
{
  volatile signed __int32 *v12; // rax
  volatile signed __int32 *v13; // rax
  volatile signed __int32 *v14; // rax
  volatile signed __int32 *v15; // rbx
  volatile signed __int32 *v16; // rbx
  volatile signed __int32 *v17; // rbx
  volatile signed __int32 *v18; // rbx
  __int64 v20; // [rsp+0h] [rbp-158h] BYREF
  volatile signed __int32 *v21; // [rsp+8h] [rbp-150h]
  __int64 v22; // [rsp+10h] [rbp-148h] BYREF
  volatile signed __int32 *v23; // [rsp+18h] [rbp-140h]
  double v24; // [rsp+20h] [rbp-138h]
  _BYTE v25[16]; // [rsp+28h] [rbp-130h] BYREF
  void *v26; // [rsp+38h] [rbp-120h]
  _BYTE v27[16]; // [rsp+40h] [rbp-118h] BYREF
  void *v28; // [rsp+50h] [rbp-108h]
  char v29; // [rsp+58h] [rbp-100h]
  void *v30; // [rsp+68h] [rbp-F0h]
  char v31; // [rsp+70h] [rbp-E8h]
  void *v32; // [rsp+80h] [rbp-D8h]
  char v33[8]; // [rsp+90h] [rbp-C8h] BYREF
  volatile signed __int32 *v34; // [rsp+98h] [rbp-C0h]
  char v35; // [rsp+A8h] [rbp-B0h]
  void *ptr; // [rsp+B8h] [rbp-A0h]
  char v37; // [rsp+C8h] [rbp-90h]
  void *v38; // [rsp+D8h] [rbp-80h]
  char v39; // [rsp+E0h] [rbp-78h]
  void *v40; // [rsp+F0h] [rbp-68h]
  char v41; // [rsp+F8h] [rbp-60h]
  void *v42; // [rsp+108h] [rbp-50h]
  __int128 v43; // [rsp+118h] [rbp-40h]
  volatile signed __int32 *v44; // [rsp+128h] [rbp-30h]

  v24 = a7;
  v22 = *a3;
  v12 = (volatile signed __int32 *)a3[1];
  v23 = v12;
  if ( v12 )
    _InterlockedAdd(v12 + 2, 1u);
  std::string::basic_string(v25, a5);
  boost::_bi::value<RBX::InstanceIdentifier>::value((boost::_bi::value<RBX::InstanceIdentifier> *)v27, t);
  v20 = *a10;
  v13 = (volatile signed __int32 *)a10[1];
  v21 = v13;
  if ( v13 )
    _InterlockedAdd(v13 + 2, 1u);
  boost::_bi::list8<boost::_bi::value<boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>>,boost::_bi::value<RBX::Graphics::Device *>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<unsigned int>,boost::_bi::value<unsigned int>,boost::_bi::value<RBX::InstanceIdentifier>,boost::_bi::value<RBX::Time>,boost::_bi::value<boost::shared_ptr<std::string const>>>::list8(
    (unsigned int)v33,
    (unsigned int)&v22,
    a4,
    (unsigned int)v25,
    a6,
    a8,
    (__int64)v27,
    (__int64)&v20);
  *(_QWORD *)a1 = a2;
  boost::_bi::storage6<boost::_bi::value<boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>>,boost::_bi::value<RBX::Graphics::Device *>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<unsigned int>,boost::_bi::value<unsigned int>,boost::_bi::value<RBX::InstanceIdentifier>>::storage6(
    (boost::_bi::storage6<boost::_bi::value<boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage> > >,boost::_bi::value<RBX::Graphics::Device *>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<unsigned int>,boost::_bi::value<unsigned int>,boost::_bi::value<RBX::InstanceIdentifier> > *)(a1 + 8),
    (const boost::_bi::storage6<boost::_bi::value<boost::shared_ptr<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage> > >,boost::_bi::value<RBX::Graphics::Device *>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<unsigned int>,boost::_bi::value<unsigned int>,boost::_bi::value<RBX::InstanceIdentifier> > *)v33);
  *(_OWORD *)(a1 + 144) = v43;
  v14 = v44;
  *(_QWORD *)(a1 + 160) = v44;
  if ( v14 )
  {
    _InterlockedAdd(v14 + 2, 1u);
    v15 = v44;
    if ( v44 )
    {
      if ( !_InterlockedSub(v44 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
        if ( !_InterlockedSub(v15 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
      }
    }
  }
  if ( (v41 & 1) != 0 )
  {
    operator delete(v42);
    if ( (v39 & 1) == 0 )
    {
LABEL_12:
      if ( (v37 & 1) == 0 )
        goto LABEL_13;
LABEL_35:
      operator delete(v38);
      if ( (v35 & 1) == 0 )
        goto LABEL_15;
      goto LABEL_14;
    }
  }
  else if ( (v39 & 1) == 0 )
  {
    goto LABEL_12;
  }
  operator delete(v40);
  if ( (v37 & 1) != 0 )
    goto LABEL_35;
LABEL_13:
  if ( (v35 & 1) != 0 )
LABEL_14:
    operator delete(ptr);
LABEL_15:
  v16 = v34;
  if ( v34 )
  {
    if ( !_InterlockedSub(v34 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
      if ( !_InterlockedSub(v16 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
    }
  }
  v17 = v21;
  if ( v21 )
  {
    if ( !_InterlockedSub(v21 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 16LL))(v17);
      if ( !_InterlockedSub(v17 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
    }
  }
  if ( (v31 & 1) != 0 )
  {
    operator delete(v32);
    if ( (v29 & 1) == 0 )
    {
LABEL_25:
      if ( (v27[0] & 1) == 0 )
        goto LABEL_26;
LABEL_39:
      operator delete(v28);
      if ( (v25[0] & 1) == 0 )
        goto LABEL_28;
      goto LABEL_27;
    }
  }
  else if ( (v29 & 1) == 0 )
  {
    goto LABEL_25;
  }
  operator delete(v30);
  if ( (v27[0] & 1) != 0 )
    goto LABEL_39;
LABEL_26:
  if ( (v25[0] & 1) != 0 )
LABEL_27:
    operator delete(v26);
LABEL_28:
  v18 = v23;
  if ( v23 )
  {
    if ( !_InterlockedSub(v23 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 16LL))(v18);
      if ( !_InterlockedSub(v18 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 24LL))(v18);
    }
  }
  return a1;
}


