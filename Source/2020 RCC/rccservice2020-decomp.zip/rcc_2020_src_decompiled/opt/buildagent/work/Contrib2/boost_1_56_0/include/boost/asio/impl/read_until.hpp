// Address: 0x262c350 | Name: _ZN5boost4asio16async_read_untilINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__19allocatorIcEENS0_6detail15wrapped_handlerINS0_10io_service6strandENS8_6__bindIMN11websocketpp9transport4asio10connectionINSG_6config15asio_tls_client16transport_configEEEFvNS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeEmEJNS8_10shared_ptrISN_EERST_RKNS8_12placeholders4__phILi1EEERKNS14_ILi2EEEEEENSB_26is_continuation_if_runningEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSV_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EERKNS8_12basic_stringIcNS8_11char_traitsIcEESA_EEOS1G_
boost::asio::async_result<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >::type __fastcall boost::asio::async_read_until<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        const std::string *delim,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::__shared_weak_count *v7; // rbx
  std::__shared_weak_count *v8; // rbx
  boost::system::error_code v9; // [rsp+0h] [rbp-148h] BYREF
  _QWORD v10[2]; // [rsp+10h] [rbp-138h] BYREF
  _BYTE v11[16]; // [rsp+20h] [rbp-128h] BYREF
  void *ptr; // [rsp+30h] [rbp-118h]
  int v13; // [rsp+38h] [rbp-110h]
  __int64 v14; // [rsp+40h] [rbp-108h]
  boost::asio::io_service::strand v15; // [rsp+50h] [rbp-F8h]
  __int128 v16; // [rsp+60h] [rbp-E8h]
  std::__shared_weak_count *v17[2]; // [rsp+70h] [rbp-D8h]
  _BYTE v18[32]; // [rsp+80h] [rbp-C8h] BYREF
  std::function<void (const std::error_code &)>::__base *v19; // [rsp+A0h] [rbp-A8h]
  boost::asio::io_service::strand dispatcher; // [rsp+B0h] [rbp-98h]
  __int128 v21; // [rsp+C0h] [rbp-88h]
  std::__shared_weak_count *v22[2]; // [rsp+D0h] [rbp-78h]
  _BYTE v23[32]; // [rsp+E0h] [rbp-68h] BYREF
  std::function<void (const std::error_code &)>::__base *v24; // [rsp+100h] [rbp-48h]
  unsigned __int64 v25; // [rsp+120h] [rbp-28h]

  v25 = __readfsqword(0x28u);
  dispatcher = handler->dispatcher_;
  v21 = *(_OWORD *)&handler->handler_.__f_;
  *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)v22 = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v24 = (std::function<void (const std::error_code &)>::__base *)v23;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *))f->dispatcher_.service_->owner_)(
        f,
        v23);
    }
    else
    {
      v24 = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v24 = 0;
  }
  v10[0] = s;
  v10[1] = b;
  std::string::basic_string(v11, delim);
  v13 = 0;
  v14 = 0;
  v15 = dispatcher;
  v16 = v21;
  *(_OWORD *)v17 = *(_OWORD *)v22;
  *(_OWORD *)v22 = 0;
  if ( v24 )
  {
    if ( v23 == (_BYTE *)v24 )
    {
      v19 = (std::function<void (const std::error_code &)>::__base *)v18;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *))v24->_vptr$__base + 3))(
        v24,
        v18);
    }
    else
    {
      v19 = v24;
      v24 = 0;
    }
  }
  else
  {
    v19 = 0;
  }
  v9.m_val = 0;
  v9.m_cat = boost::system::system_category();
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
    (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)v10,
    &v9,
    0,
    1);
  if ( v18 == (_BYTE *)v19 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v19->_vptr$__base + 4))(v19);
  }
  else if ( v19 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v19->_vptr$__base + 5))(v19);
  }
  v7 = v17[1];
  if ( !v17[1] || _InterlockedExchangeAdd64((volatile signed __int64 *)v17[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    if ( (v11[0] & 1) == 0 )
      goto LABEL_19;
    goto LABEL_18;
  }
  (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
  std::__shared_weak_count::__release_weak(v7);
  if ( (v11[0] & 1) != 0 )
LABEL_18:
    operator delete(ptr);
LABEL_19:
  if ( v23 == (_BYTE *)v24 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v24->_vptr$__base + 4))(v24);
  }
  else if ( v24 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v24->_vptr$__base + 5))(v24);
  }
  v8 = v22[1];
  if ( v22[1] )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
  }
}


// Address: 0x262cfa0 | Name: _ZN5boost4asio6detail26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENS9_6__bindIMN11websocketpp9transport4asio10connectionINSG_6config15asio_tls_client16transport_configEEEFvNS9_8functionIFvRKNS9_10error_codeEEEERKNS_6system10error_codeEmEJNS9_10shared_ptrISN_EERST_RKNS9_12placeholders4__phILi1EEERKNS14_ILi2EEEEEENS1_26is_continuation_if_runningEEEEclESX_mi
void __fastcall boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  int v4; // r10d
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v6; // r12
  boost::asio::basic_streambuf<std::allocator<char> > *v7; // rdi
  __int64 v8; // rax
  int v9; // ecx
  __int64 v10; // rsi
  __int64 v11; // r11
  const boost::system::error_category *v12; // rcx
  boost::system::error_code *p_arg1; // rbx
  __int64 v14; // r15
  __int64 v15; // r9
  const boost::system::error_category *v16; // r13
  unsigned __int64 *v17; // rbp
  unsigned __int64 v18; // rax
  const boost::system::error_category *v19; // rdx
  unsigned __int64 v20; // rbp
  boost::system::error_code *v21; // rax
  const boost::system::error_category *m_cat; // r15
  bool v23; // cf
  unsigned __int64 v24; // rdx
  _BYTE *v25; // rbp
  char v26; // al
  unsigned __int64 v27; // rax
  const boost::system::error_category *v28; // rdx
  _BYTE *v29; // r14
  __int64 v30; // r12
  const boost::system::error_category *v31; // r11
  __int64 v32; // rdx
  __int64 v33; // rax
  boost::system::error_code *v34; // rbp
  boost::system::error_code *v35; // rax
  boost::system::error_code *v36; // rax
  __int64 v37; // rax
  unsigned __int64 v38; // rsi
  __int64 v39; // rax
  unsigned __int64 v40; // rdx
  const boost::system::error_category *v41; // rbx
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v42; // r14
  unsigned __int64 v43; // [rsp+0h] [rbp-A8h]
  int v44; // [rsp+8h] [rbp-A0h]
  int v45; // [rsp+Ch] [rbp-9Ch]
  boost::system::error_code arg1; // [rsp+10h] [rbp-98h] BYREF
  char v47; // [rsp+20h] [rbp-88h] BYREF
  _BYTE *v48; // [rsp+28h] [rbp-80h]
  __int64 *v49; // [rsp+30h] [rbp-78h]
  const boost::system::error_category *v50; // [rsp+38h] [rbp-70h]
  boost::asio::basic_streambuf<std::allocator<char> > *v51; // [rsp+40h] [rbp-68h]
  const boost::system::error_code *v52; // [rsp+48h] [rbp-60h]
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v53; // [rsp+50h] [rbp-58h]
  __int64 v54; // [rsp+58h] [rbp-50h]
  unsigned __int64 v55; // [rsp+60h] [rbp-48h]
  _BYTE *v56; // [rsp+68h] [rbp-40h]
  unsigned __int64 arg2[7]; // [rsp+70h] [rbp-38h] BYREF

  v4 = start;
  v6 = this;
  *((_DWORD *)this + 10) = start;
  v7 = (boost::asio::basic_streambuf<std::allocator<char> > *)*((_QWORD *)this + 1);
  if ( start != 1 )
  {
    v8 = *((_QWORD *)v7 + 6);
    v9 = *((_QWORD *)v7 + 7) - v8;
    if ( v8 + bytes_transferred <= *((_QWORD *)v7 + 7) )
      v9 = bytes_transferred;
    v10 = v8 + v9;
    *((_QWORD *)v7 + 6) = v10;
    *((_QWORD *)v7 + 4) = v10;
    if ( !bytes_transferred || ec->m_val )
    {
      v17 = (unsigned __int64 *)((char *)v6 + 48);
      if ( *((_QWORD *)v6 + 6) != -1 )
        goto LABEL_88;
      goto LABEL_14;
    }
  }
  v11 = *((_QWORD *)v7 + 3);
  v12 = (const boost::system::error_category *)(*((_QWORD *)v7 + 6) - v11);
  *(_QWORD *)&arg1.m_val = v11;
  arg1.m_cat = v12;
  p_arg1 = &arg1;
  if ( !v12 )
    p_arg1 = (boost::system::error_code *)&v47;
  v14 = *((_QWORD *)v6 + 6);
  if ( v14 <= 0 )
  {
    if ( v14 < 0 )
    {
      v15 = (__int64)v12;
      v19 = 0;
      v16 = 0;
      v20 = -v14;
LABEL_25:
      while ( 2 )
      {
        v16 = (const boost::system::error_category *)((char *)v16 - (__int64)v19);
        if ( p_arg1 == &arg1 )
        {
          v14 = 0;
        }
        else
        {
          v20 -= (unsigned __int64)v19;
          v21 = p_arg1;
          while ( &arg1 != v21 )
          {
            m_cat = v21[-1].m_cat;
            --v21;
            if ( m_cat )
            {
              v11 = *(_QWORD *)&v21->m_val;
              v15 = (__int64)m_cat;
              p_arg1 = v21;
              v19 = m_cat;
              v23 = (unsigned __int64)m_cat < v20;
              v14 = (__int64)m_cat - v20;
              if ( v23 )
                goto LABEL_25;
              goto LABEL_32;
            }
          }
          v14 = (__int64)v19 - v20;
          if ( (unsigned __int64)v19 < v20 )
            continue;
LABEL_32:
          v16 = (const boost::system::error_category *)((char *)v16 - v20);
        }
        break;
      }
    }
    else
    {
      v14 = 0;
      v15 = (__int64)v12;
      v16 = 0;
    }
  }
  else if ( (__int64)v12 <= v14 )
  {
    v11 = 0;
    v16 = 0;
    v15 = (__int64)v12;
    while ( 1 )
    {
      v16 = (const boost::system::error_category *)((char *)v16 + v15);
      if ( &arg1 == p_arg1 )
        break;
      v14 -= v15;
      v15 = (__int64)p_arg1[1].m_cat;
      ++p_arg1;
      if ( v14 < v15 )
      {
        v11 = *(_QWORD *)&p_arg1->m_val;
        v16 = (const boost::system::error_category *)((char *)v16 + v14);
        goto LABEL_34;
      }
    }
    v15 = 0;
    v14 = 0;
    p_arg1 = (boost::system::error_code *)&v47;
  }
  else
  {
    v15 = (__int64)v12;
    v16 = (const boost::system::error_category *)*((_QWORD *)v6 + 6);
  }
LABEL_34:
  v24 = *((unsigned __int8 *)v6 + 16);
  if ( (v24 & 1) != 0 )
  {
    v43 = *((_QWORD *)v6 + 3);
    v25 = (_BYTE *)*((_QWORD *)v6 + 4);
  }
  else
  {
    v25 = (char *)v6 + 17;
    v43 = v24 >> 1;
  }
  v49 = (__int64 *)((char *)v6 + 48);
  if ( v16 == v12 )
  {
    v26 = 0;
    v16 = v12;
LABEL_39:
    v17 = (unsigned __int64 *)v49;
    goto LABEL_75;
  }
  v55 = v24;
  v44 = v4;
  v51 = v7;
  v52 = ec;
  v53 = v6;
  v27 = v43;
  v56 = &v25[v43];
  v28 = v16;
  v48 = v25;
  while ( 2 )
  {
    LOBYTE(v7) = 1;
    v45 = (int)v7;
    if ( v27 )
    {
      v29 = v25;
      v54 = v11;
      v30 = v11;
      v31 = v28;
      v32 = v15;
      v33 = v14;
      v34 = p_arg1;
      v50 = v31;
      while ( v31 != v12 )
      {
        if ( *(_BYTE *)(v30 + v33) != *v29 )
          goto LABEL_55;
        if ( ++v33 == v32 )
        {
          LODWORD(v7) = (_DWORD)v12;
          if ( &v34[1] == (boost::system::error_code *)&v47 )
          {
            v34 = (boost::system::error_code *)&v47;
            v33 = 0;
          }
          else
          {
            while ( 1 )
            {
              v35 = v34;
              v32 = (__int64)v34[1].m_cat;
              ++v34;
              if ( v32 )
                break;
              if ( &arg1 == v34 )
              {
                v34 = (boost::system::error_code *)&v47;
                break;
              }
            }
            v30 = *(_QWORD *)&v35[1].m_val;
            v33 = 0;
          }
        }
        v31 = (const boost::system::error_category *)((char *)v31 + 1);
        if ( ++v29 == v56 )
          goto LABEL_68;
      }
      if ( v29 != v48 )
      {
        v45 = 0;
LABEL_68:
        v16 = v50;
        break;
      }
LABEL_55:
      v28 = (const boost::system::error_category *)((char *)&v50->_vptr$error_category + 1);
      if ( ++v14 == v15 )
      {
        v11 = v54;
        if ( &p_arg1[1] != (boost::system::error_code *)&v47 )
        {
          v25 = v48;
          while ( 1 )
          {
            v36 = p_arg1;
            v15 = (__int64)p_arg1[1].m_cat;
            ++p_arg1;
            if ( v15 )
              break;
            if ( &arg1 == p_arg1 )
            {
              p_arg1 = (boost::system::error_code *)&v47;
              break;
            }
          }
          v11 = *(_QWORD *)&v36[1].m_val;
          v14 = 0;
          goto LABEL_65;
        }
        v14 = 0;
        p_arg1 = (boost::system::error_code *)&v47;
      }
      else
      {
        v11 = v54;
      }
      v25 = v48;
LABEL_65:
      v27 = v43;
      if ( v28 != v12 )
        continue;
      v26 = 0;
      v16 = v12;
      v6 = v53;
      ec = v52;
      v7 = v51;
      v4 = v44;
      goto LABEL_39;
    }
    break;
  }
  v6 = v53;
  ec = v52;
  v7 = v51;
  v4 = v44;
  v17 = (unsigned __int64 *)v49;
  if ( v16 == v12 )
  {
    v26 = 0;
    v16 = v12;
  }
  else
  {
    if ( (_BYTE)v45 )
    {
      if ( (v55 & 1) != 0 )
        v37 = *((_QWORD *)v53 + 3);
      else
        v37 = (unsigned __int8)v55 >> 1;
      v39 = (__int64)v16 + v37;
      *v49 = v39;
      goto LABEL_93;
    }
    v26 = 1;
  }
LABEL_75:
  v38 = *((_QWORD *)v7 + 8) - (_QWORD)v12;
  if ( v38 )
  {
    if ( !v26 )
      v16 = v12;
    *v17 = (unsigned __int64)v16;
    v40 = 0x10000;
    if ( v38 < 0x10000 )
      v40 = v38;
    v41 = (const boost::system::error_category *)(&inputbuff + 480);
    if ( *((_QWORD *)v7 + 11) - *((_QWORD *)v7 + 9) - (_QWORD)v12 > 0x200u )
      v41 = (const boost::system::error_category *)(*((_QWORD *)v7 + 11) - *((_QWORD *)v7 + 9) - (_QWORD)v12);
    if ( v40 < (unsigned __int64)v41 )
      v41 = (const boost::system::error_category *)v40;
    v39 = (__int64)v16;
    if ( v4 )
      goto LABEL_94;
    goto LABEL_86;
  }
  *v17 = -1;
  v39 = -1;
LABEL_93:
  v41 = 0;
  if ( v4 )
    goto LABEL_94;
LABEL_86:
  if ( !v41 )
  {
    if ( v39 != -1 )
    {
LABEL_88:
      arg1 = *ec;
      if ( ec->m_val )
      {
LABEL_89:
        v18 = 0;
LABEL_90:
        arg2[0] = v18;
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,unsigned long>(
          (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *)((char *)v6 + 64),
          &arg1,
          arg2);
        return;
      }
LABEL_16:
      v18 = 0;
      if ( *v17 != -1 )
        v18 = *v17;
      goto LABEL_90;
    }
LABEL_14:
    if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
      __cxa_guard_release(&byte_2B114E0);
    arg1.m_val = 3;
    arg1.m_cat = (const boost::system::error_category *)off_2870A08;
    if ( ec->m_val )
      goto LABEL_89;
    goto LABEL_16;
  }
LABEL_94:
  v42 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)v6;
  boost::asio::basic_streambuf<std::allocator<char>>::reserve(v7, (size_t)v41);
  *(_QWORD *)&arg1.m_val = *((_QWORD *)v7 + 6);
  arg1.m_cat = v41;
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>(
    v42,
    (const boost::asio::mutable_buffers_1 *)&arg1,
    v6);
}


// Address: 0x266d680 | Name: _ZN5boost4asio16async_read_untilINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__19allocatorIcEENS0_6detail15wrapped_handlerINS0_10io_service6strandENS8_6__bindIMN11websocketpp9transport4asio10connectionINSG_6config11asio_client16transport_configEEEFvNS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeEmEJNS8_10shared_ptrISN_EERST_RKNS8_12placeholders4__phILi1EEERKNS14_ILi2EEEEEENSB_26is_continuation_if_runningEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSV_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EERKNS8_12basic_stringIcNS8_11char_traitsIcEESA_EEOS1G_
boost::asio::async_result<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >::type __fastcall boost::asio::async_read_until<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        const std::string *delim,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::__shared_weak_count *v7; // rbx
  std::__shared_weak_count *v8; // rbx
  boost::system::error_code v9; // [rsp+0h] [rbp-148h] BYREF
  _QWORD v10[2]; // [rsp+10h] [rbp-138h] BYREF
  _BYTE v11[16]; // [rsp+20h] [rbp-128h] BYREF
  void *ptr; // [rsp+30h] [rbp-118h]
  int v13; // [rsp+38h] [rbp-110h]
  __int64 v14; // [rsp+40h] [rbp-108h]
  boost::asio::io_service::strand v15; // [rsp+50h] [rbp-F8h]
  __int128 v16; // [rsp+60h] [rbp-E8h]
  std::__shared_weak_count *v17[2]; // [rsp+70h] [rbp-D8h]
  _BYTE v18[32]; // [rsp+80h] [rbp-C8h] BYREF
  std::function<void (const std::error_code &)>::__base *v19; // [rsp+A0h] [rbp-A8h]
  boost::asio::io_service::strand dispatcher; // [rsp+B0h] [rbp-98h]
  __int128 v21; // [rsp+C0h] [rbp-88h]
  std::__shared_weak_count *v22[2]; // [rsp+D0h] [rbp-78h]
  _BYTE v23[32]; // [rsp+E0h] [rbp-68h] BYREF
  std::function<void (const std::error_code &)>::__base *v24; // [rsp+100h] [rbp-48h]
  unsigned __int64 v25; // [rsp+120h] [rbp-28h]

  v25 = __readfsqword(0x28u);
  dispatcher = handler->dispatcher_;
  v21 = *(_OWORD *)&handler->handler_.__f_;
  *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)v22 = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v24 = (std::function<void (const std::error_code &)>::__base *)v23;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *))f->dispatcher_.service_->owner_)(
        f,
        v23);
    }
    else
    {
      v24 = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v24 = 0;
  }
  v10[0] = s;
  v10[1] = b;
  std::string::basic_string(v11, delim);
  v13 = 0;
  v14 = 0;
  v15 = dispatcher;
  v16 = v21;
  *(_OWORD *)v17 = *(_OWORD *)v22;
  *(_OWORD *)v22 = 0;
  if ( v24 )
  {
    if ( v23 == (_BYTE *)v24 )
    {
      v19 = (std::function<void (const std::error_code &)>::__base *)v18;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *))v24->_vptr$__base + 3))(
        v24,
        v18);
    }
    else
    {
      v19 = v24;
      v24 = 0;
    }
  }
  else
  {
    v19 = 0;
  }
  v9.m_val = 0;
  v9.m_cat = boost::system::system_category();
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
    (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)v10,
    &v9,
    0,
    1);
  if ( v18 == (_BYTE *)v19 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v19->_vptr$__base + 4))(v19);
  }
  else if ( v19 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v19->_vptr$__base + 5))(v19);
  }
  v7 = v17[1];
  if ( !v17[1] || _InterlockedExchangeAdd64((volatile signed __int64 *)v17[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    if ( (v11[0] & 1) == 0 )
      goto LABEL_19;
    goto LABEL_18;
  }
  (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
  std::__shared_weak_count::__release_weak(v7);
  if ( (v11[0] & 1) != 0 )
LABEL_18:
    operator delete(ptr);
LABEL_19:
  if ( v23 == (_BYTE *)v24 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v24->_vptr$__base + 4))(v24);
  }
  else if ( v24 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v24->_vptr$__base + 5))(v24);
  }
  v8 = v22[1];
  if ( v22[1] )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
  }
}


// Address: 0x266e2d0 | Name: _ZN5boost4asio6detail26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENS9_6__bindIMN11websocketpp9transport4asio10connectionINSG_6config11asio_client16transport_configEEEFvNS9_8functionIFvRKNS9_10error_codeEEEERKNS_6system10error_codeEmEJNS9_10shared_ptrISN_EERST_RKNS9_12placeholders4__phILi1EEERKNS14_ILi2EEEEEENS1_26is_continuation_if_runningEEEEclESX_mi
void __fastcall boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  int v4; // r10d
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v6; // r12
  boost::asio::basic_streambuf<std::allocator<char> > *v7; // rdi
  __int64 v8; // rax
  int v9; // ecx
  __int64 v10; // rsi
  __int64 v11; // r11
  const boost::system::error_category *v12; // rcx
  boost::system::error_code *p_arg1; // rbx
  __int64 v14; // r15
  __int64 v15; // r9
  const boost::system::error_category *v16; // r13
  unsigned __int64 *v17; // rbp
  unsigned __int64 v18; // rax
  const boost::system::error_category *v19; // rdx
  unsigned __int64 v20; // rbp
  boost::system::error_code *v21; // rax
  const boost::system::error_category *m_cat; // r15
  bool v23; // cf
  unsigned __int64 v24; // rdx
  _BYTE *v25; // rbp
  char v26; // al
  unsigned __int64 v27; // rax
  const boost::system::error_category *v28; // rdx
  _BYTE *v29; // r14
  __int64 v30; // r12
  const boost::system::error_category *v31; // r11
  __int64 v32; // rdx
  __int64 v33; // rax
  boost::system::error_code *v34; // rbp
  boost::system::error_code *v35; // rax
  boost::system::error_code *v36; // rax
  __int64 v37; // rax
  unsigned __int64 v38; // rsi
  __int64 v39; // rax
  unsigned __int64 v40; // rdx
  const boost::system::error_category *v41; // rbx
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v42; // r14
  unsigned __int64 v43; // [rsp+0h] [rbp-A8h]
  int v44; // [rsp+8h] [rbp-A0h]
  int v45; // [rsp+Ch] [rbp-9Ch]
  boost::system::error_code arg1; // [rsp+10h] [rbp-98h] BYREF
  char v47; // [rsp+20h] [rbp-88h] BYREF
  _BYTE *v48; // [rsp+28h] [rbp-80h]
  __int64 *v49; // [rsp+30h] [rbp-78h]
  const boost::system::error_category *v50; // [rsp+38h] [rbp-70h]
  boost::asio::basic_streambuf<std::allocator<char> > *v51; // [rsp+40h] [rbp-68h]
  const boost::system::error_code *v52; // [rsp+48h] [rbp-60h]
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v53; // [rsp+50h] [rbp-58h]
  __int64 v54; // [rsp+58h] [rbp-50h]
  unsigned __int64 v55; // [rsp+60h] [rbp-48h]
  _BYTE *v56; // [rsp+68h] [rbp-40h]
  unsigned __int64 arg2[7]; // [rsp+70h] [rbp-38h] BYREF

  v4 = start;
  v6 = this;
  *((_DWORD *)this + 10) = start;
  v7 = (boost::asio::basic_streambuf<std::allocator<char> > *)*((_QWORD *)this + 1);
  if ( start != 1 )
  {
    v8 = *((_QWORD *)v7 + 6);
    v9 = *((_QWORD *)v7 + 7) - v8;
    if ( v8 + bytes_transferred <= *((_QWORD *)v7 + 7) )
      v9 = bytes_transferred;
    v10 = v8 + v9;
    *((_QWORD *)v7 + 6) = v10;
    *((_QWORD *)v7 + 4) = v10;
    if ( !bytes_transferred || ec->m_val )
    {
      v17 = (unsigned __int64 *)((char *)v6 + 48);
      if ( *((_QWORD *)v6 + 6) != -1 )
        goto LABEL_88;
      goto LABEL_14;
    }
  }
  v11 = *((_QWORD *)v7 + 3);
  v12 = (const boost::system::error_category *)(*((_QWORD *)v7 + 6) - v11);
  *(_QWORD *)&arg1.m_val = v11;
  arg1.m_cat = v12;
  p_arg1 = &arg1;
  if ( !v12 )
    p_arg1 = (boost::system::error_code *)&v47;
  v14 = *((_QWORD *)v6 + 6);
  if ( v14 <= 0 )
  {
    if ( v14 < 0 )
    {
      v15 = (__int64)v12;
      v19 = 0;
      v16 = 0;
      v20 = -v14;
LABEL_25:
      while ( 2 )
      {
        v16 = (const boost::system::error_category *)((char *)v16 - (__int64)v19);
        if ( p_arg1 == &arg1 )
        {
          v14 = 0;
        }
        else
        {
          v20 -= (unsigned __int64)v19;
          v21 = p_arg1;
          while ( &arg1 != v21 )
          {
            m_cat = v21[-1].m_cat;
            --v21;
            if ( m_cat )
            {
              v11 = *(_QWORD *)&v21->m_val;
              v15 = (__int64)m_cat;
              p_arg1 = v21;
              v19 = m_cat;
              v23 = (unsigned __int64)m_cat < v20;
              v14 = (__int64)m_cat - v20;
              if ( v23 )
                goto LABEL_25;
              goto LABEL_32;
            }
          }
          v14 = (__int64)v19 - v20;
          if ( (unsigned __int64)v19 < v20 )
            continue;
LABEL_32:
          v16 = (const boost::system::error_category *)((char *)v16 - v20);
        }
        break;
      }
    }
    else
    {
      v14 = 0;
      v15 = (__int64)v12;
      v16 = 0;
    }
  }
  else if ( (__int64)v12 <= v14 )
  {
    v11 = 0;
    v16 = 0;
    v15 = (__int64)v12;
    while ( 1 )
    {
      v16 = (const boost::system::error_category *)((char *)v16 + v15);
      if ( &arg1 == p_arg1 )
        break;
      v14 -= v15;
      v15 = (__int64)p_arg1[1].m_cat;
      ++p_arg1;
      if ( v14 < v15 )
      {
        v11 = *(_QWORD *)&p_arg1->m_val;
        v16 = (const boost::system::error_category *)((char *)v16 + v14);
        goto LABEL_34;
      }
    }
    v15 = 0;
    v14 = 0;
    p_arg1 = (boost::system::error_code *)&v47;
  }
  else
  {
    v15 = (__int64)v12;
    v16 = (const boost::system::error_category *)*((_QWORD *)v6 + 6);
  }
LABEL_34:
  v24 = *((unsigned __int8 *)v6 + 16);
  if ( (v24 & 1) != 0 )
  {
    v43 = *((_QWORD *)v6 + 3);
    v25 = (_BYTE *)*((_QWORD *)v6 + 4);
  }
  else
  {
    v25 = (char *)v6 + 17;
    v43 = v24 >> 1;
  }
  v49 = (__int64 *)((char *)v6 + 48);
  if ( v16 == v12 )
  {
    v26 = 0;
    v16 = v12;
LABEL_39:
    v17 = (unsigned __int64 *)v49;
    goto LABEL_75;
  }
  v55 = v24;
  v44 = v4;
  v51 = v7;
  v52 = ec;
  v53 = v6;
  v27 = v43;
  v56 = &v25[v43];
  v28 = v16;
  v48 = v25;
  while ( 2 )
  {
    LOBYTE(v7) = 1;
    v45 = (int)v7;
    if ( v27 )
    {
      v29 = v25;
      v54 = v11;
      v30 = v11;
      v31 = v28;
      v32 = v15;
      v33 = v14;
      v34 = p_arg1;
      v50 = v31;
      while ( v31 != v12 )
      {
        if ( *(_BYTE *)(v30 + v33) != *v29 )
          goto LABEL_55;
        if ( ++v33 == v32 )
        {
          LODWORD(v7) = (_DWORD)v12;
          if ( &v34[1] == (boost::system::error_code *)&v47 )
          {
            v34 = (boost::system::error_code *)&v47;
            v33 = 0;
          }
          else
          {
            while ( 1 )
            {
              v35 = v34;
              v32 = (__int64)v34[1].m_cat;
              ++v34;
              if ( v32 )
                break;
              if ( &arg1 == v34 )
              {
                v34 = (boost::system::error_code *)&v47;
                break;
              }
            }
            v30 = *(_QWORD *)&v35[1].m_val;
            v33 = 0;
          }
        }
        v31 = (const boost::system::error_category *)((char *)v31 + 1);
        if ( ++v29 == v56 )
          goto LABEL_68;
      }
      if ( v29 != v48 )
      {
        v45 = 0;
LABEL_68:
        v16 = v50;
        break;
      }
LABEL_55:
      v28 = (const boost::system::error_category *)((char *)&v50->_vptr$error_category + 1);
      if ( ++v14 == v15 )
      {
        v11 = v54;
        if ( &p_arg1[1] != (boost::system::error_code *)&v47 )
        {
          v25 = v48;
          while ( 1 )
          {
            v36 = p_arg1;
            v15 = (__int64)p_arg1[1].m_cat;
            ++p_arg1;
            if ( v15 )
              break;
            if ( &arg1 == p_arg1 )
            {
              p_arg1 = (boost::system::error_code *)&v47;
              break;
            }
          }
          v11 = *(_QWORD *)&v36[1].m_val;
          v14 = 0;
          goto LABEL_65;
        }
        v14 = 0;
        p_arg1 = (boost::system::error_code *)&v47;
      }
      else
      {
        v11 = v54;
      }
      v25 = v48;
LABEL_65:
      v27 = v43;
      if ( v28 != v12 )
        continue;
      v26 = 0;
      v16 = v12;
      v6 = v53;
      ec = v52;
      v7 = v51;
      v4 = v44;
      goto LABEL_39;
    }
    break;
  }
  v6 = v53;
  ec = v52;
  v7 = v51;
  v4 = v44;
  v17 = (unsigned __int64 *)v49;
  if ( v16 == v12 )
  {
    v26 = 0;
    v16 = v12;
  }
  else
  {
    if ( (_BYTE)v45 )
    {
      if ( (v55 & 1) != 0 )
        v37 = *((_QWORD *)v53 + 3);
      else
        v37 = (unsigned __int8)v55 >> 1;
      v39 = (__int64)v16 + v37;
      *v49 = v39;
      goto LABEL_93;
    }
    v26 = 1;
  }
LABEL_75:
  v38 = *((_QWORD *)v7 + 8) - (_QWORD)v12;
  if ( v38 )
  {
    if ( !v26 )
      v16 = v12;
    *v17 = (unsigned __int64)v16;
    v40 = 0x10000;
    if ( v38 < 0x10000 )
      v40 = v38;
    v41 = (const boost::system::error_category *)(&inputbuff + 480);
    if ( *((_QWORD *)v7 + 11) - *((_QWORD *)v7 + 9) - (_QWORD)v12 > 0x200u )
      v41 = (const boost::system::error_category *)(*((_QWORD *)v7 + 11) - *((_QWORD *)v7 + 9) - (_QWORD)v12);
    if ( v40 < (unsigned __int64)v41 )
      v41 = (const boost::system::error_category *)v40;
    v39 = (__int64)v16;
    if ( v4 )
      goto LABEL_94;
    goto LABEL_86;
  }
  *v17 = -1;
  v39 = -1;
LABEL_93:
  v41 = 0;
  if ( v4 )
    goto LABEL_94;
LABEL_86:
  if ( !v41 )
  {
    if ( v39 != -1 )
    {
LABEL_88:
      arg1 = *ec;
      if ( ec->m_val )
      {
LABEL_89:
        v18 = 0;
LABEL_90:
        arg2[0] = v18;
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,unsigned long>(
          (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *)((char *)v6 + 64),
          &arg1,
          arg2);
        return;
      }
LABEL_16:
      v18 = 0;
      if ( *v17 != -1 )
        v18 = *v17;
      goto LABEL_90;
    }
LABEL_14:
    if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
      __cxa_guard_release(&byte_2B114E0);
    arg1.m_val = 3;
    arg1.m_cat = (const boost::system::error_category *)off_2870A08;
    if ( ec->m_val )
      goto LABEL_89;
    goto LABEL_16;
  }
LABEL_94:
  v42 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)v6;
  boost::asio::basic_streambuf<std::allocator<char>>::reserve(v7, (size_t)v41);
  *(_QWORD *)&arg1.m_val = *((_QWORD *)v7 + 6);
  arg1.m_cat = v41;
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>(
    v42,
    (const boost::asio::mutable_buffers_1 *)&arg1,
    v6);
}


// Address: 0x26a4780 | Name: _ZN5boost4asio16async_read_untilINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEEEENSt3__19allocatorIcEERKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSC_10shared_ptrISO_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSQ_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EERKNSC_12basic_stringIcNSC_11char_traitsIcEESE_EEOS19_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::async_read_until<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        const std::string *delim,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *v4; // r14
  volatile signed __int64 *cntrl; // rbx
  std::__shared_weak_count *v6; // rbx
  boost::system::error_code ec; // [rsp+8h] [rbp-90h] BYREF
  _QWORD v8[2]; // [rsp+18h] [rbp-80h] BYREF
  _BYTE v9[16]; // [rsp+28h] [rbp-70h] BYREF
  void *ptr; // [rsp+38h] [rbp-60h]
  int v11; // [rsp+40h] [rbp-58h]
  __int64 v12; // [rsp+48h] [rbp-50h]
  boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> v13; // [rsp+50h] [rbp-48h]
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *v14; // [rsp+60h] [rbp-38h]
  std::__shared_weak_count *v15; // [rsp+68h] [rbp-30h]
  boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> f; // [rsp+70h] [rbp-28h]

  f = handler->f_;
  v4 = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v8[0] = s;
  v8[1] = b;
  std::string::basic_string(v9, delim);
  v11 = 0;
  v12 = 0;
  v13 = f;
  v14 = v4;
  v15 = (std::__shared_weak_count *)cntrl;
  ec.m_val = 0;
  ec.m_cat = boost::system::system_category();
  boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>::operator()(
    (boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *)v8,
    &ec,
    0,
    1);
  v6 = v15;
  if ( v15 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v15 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
    if ( (v9[0] & 1) == 0 )
      return;
  }
  else if ( (v9[0] & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26a48e0 | Name: _ZN5boost4asio16async_read_untilINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__19allocatorIcEERKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSB_5list2INSB_5valueINS8_10shared_ptrISK_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSM_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EERKNS8_12basic_stringIcNS8_11char_traitsIcEESA_EEOS15_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::async_read_until<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        const std::string *delim,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *v4; // r14
  volatile signed __int64 *cntrl; // rbx
  std::__shared_weak_count *v6; // rbx
  boost::system::error_code ec; // [rsp+8h] [rbp-90h] BYREF
  _QWORD v8[2]; // [rsp+18h] [rbp-80h] BYREF
  _BYTE v9[16]; // [rsp+28h] [rbp-70h] BYREF
  void *ptr; // [rsp+38h] [rbp-60h]
  int v11; // [rsp+40h] [rbp-58h]
  __int64 v12; // [rsp+48h] [rbp-50h]
  boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> v13; // [rsp+50h] [rbp-48h]
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *v14; // [rsp+60h] [rbp-38h]
  std::__shared_weak_count *v15; // [rsp+68h] [rbp-30h]
  boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> f; // [rsp+70h] [rbp-28h]

  f = handler->f_;
  v4 = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v8[0] = s;
  v8[1] = b;
  std::string::basic_string(v9, delim);
  v11 = 0;
  v12 = 0;
  v13 = f;
  v14 = v4;
  v15 = (std::__shared_weak_count *)cntrl;
  ec.m_val = 0;
  ec.m_cat = boost::system::system_category();
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>::operator()(
    (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *)v8,
    &ec,
    0,
    1);
  v6 = v15;
  if ( v15 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v15 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
    if ( (v9[0] & 1) == 0 )
      return;
  }
  else if ( (v9[0] & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26a4a40 | Name: _ZN5boost4asio6detail26read_until_delim_string_opINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEEEENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSG_5list2INSG_5valueINSD_10shared_ptrISP_EEEEPFNS_3argILi1EEEvEEEEEEclEST_mi
void __fastcall boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>::operator()(
        boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *v4; // r15
  boost::asio::basic_streambuf<std::allocator<char> > *v5; // rbp
  __int64 v6; // rax
  int v7; // edi
  __int64 v8; // rdi
  void *data; // r8
  signed __int64 v10; // r10
  boost::asio::mutable_buffers_1 *p_buffers; // rbx
  __int64 v12; // r14
  __int64 v13; // r9
  __int64 v14; // r11
  size_t v15; // rdx
  unsigned __int64 v16; // rax
  boost::asio::mutable_buffers_1 *v17; // rsi
  size_t size; // r14
  bool v19; // cf
  unsigned __int64 v20; // rax
  _BYTE *v21; // rdx
  unsigned __int64 v22; // rbp
  char v23; // al
  signed __int64 v24; // rbp
  boost::asio::basic_streambuf<std::allocator<char> > *v25; // rdi
  int v26; // esi
  _BYTE *v27; // rsi
  __int64 v28; // r12
  _BYTE *v29; // rbp
  _BYTE *v30; // r15
  __int64 v31; // rdx
  boost::asio::mutable_buffers_1 *v32; // r13
  boost::asio::mutable_buffers_1 *v33; // rdx
  __int64 v34; // rax
  unsigned __int64 v35; // rcx
  __int64 v36; // rax
  unsigned __int64 v37; // rdx
  size_t v38; // rbx
  char *v39; // rax
  _QWORD *v40; // rdi
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *v41; // r12
  int v42; // [rsp+Ch] [rbp-8Ch]
  boost::asio::mutable_buffers_1 buffers; // [rsp+10h] [rbp-88h] BYREF
  _BYTE v44[4]; // [rsp+20h] [rbp-78h] BYREF
  int v45; // [rsp+24h] [rbp-74h]
  boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *v46; // [rsp+28h] [rbp-70h]
  _BYTE *v47; // [rsp+30h] [rbp-68h]
  boost::asio::basic_streambuf<std::allocator<char> > *v48; // [rsp+38h] [rbp-60h]
  signed __int64 v49; // [rsp+40h] [rbp-58h]
  unsigned __int64 v50; // [rsp+48h] [rbp-50h]
  void *v51; // [rsp+50h] [rbp-48h]
  __int64 v52; // [rsp+58h] [rbp-40h]
  boost::asio::mutable_buffers_1 *v53; // [rsp+60h] [rbp-38h]

  v4 = this;
  *((_DWORD *)this + 10) = start;
  v5 = (boost::asio::basic_streambuf<std::allocator<char> > *)*((_QWORD *)this + 1);
  v53 = (boost::asio::mutable_buffers_1 *)ec;
  if ( start == 1 )
    goto LABEL_6;
  v6 = *((_QWORD *)v5 + 6);
  v7 = *((_QWORD *)v5 + 7) - v6;
  if ( v6 + bytes_transferred <= *((_QWORD *)v5 + 7) )
    v7 = bytes_transferred;
  v8 = v6 + v7;
  *((_QWORD *)v5 + 6) = v8;
  *((_QWORD *)v5 + 4) = v8;
  if ( bytes_transferred )
  {
    if ( !ec->m_val )
    {
LABEL_6:
      data = (void *)*((_QWORD *)v5 + 3);
      v10 = *((_QWORD *)v5 + 6) - (_QWORD)data;
      buffers.data_ = data;
      buffers.size_ = v10;
      p_buffers = &buffers;
      if ( !v10 )
        p_buffers = (boost::asio::mutable_buffers_1 *)v44;
      v12 = *((_QWORD *)v4 + 6);
      v48 = v5;
      v42 = start;
      if ( v12 <= 0 )
      {
        if ( v12 < 0 )
        {
          v13 = v10;
          v15 = 0;
          v14 = 0;
          v16 = -v12;
LABEL_22:
          while ( 2 )
          {
            v14 -= v15;
            if ( p_buffers == &buffers )
            {
              v12 = 0;
            }
            else
            {
              v16 -= v15;
              v17 = p_buffers;
              while ( &buffers != v17 )
              {
                size = v17[-1].size_;
                --v17;
                if ( size )
                {
                  data = v17->data_;
                  v13 = size;
                  p_buffers = v17;
                  v15 = size;
                  v19 = size < v16;
                  v12 = size - v16;
                  if ( v19 )
                    goto LABEL_22;
                  goto LABEL_29;
                }
              }
              v12 = v15 - v16;
              if ( v15 < v16 )
                continue;
LABEL_29:
              v14 -= v16;
            }
            break;
          }
        }
        else
        {
          v12 = 0;
          v13 = v10;
          v14 = 0;
        }
      }
      else if ( v10 <= v12 )
      {
        data = 0;
        v14 = 0;
        v13 = v10;
        while ( 1 )
        {
          v14 += v13;
          if ( &buffers == p_buffers )
            break;
          v12 -= v13;
          v13 = p_buffers[1].size_;
          ++p_buffers;
          if ( v12 < v13 )
          {
            data = p_buffers->data_;
            v14 += v12;
            goto LABEL_31;
          }
        }
        v13 = 0;
        v12 = 0;
        p_buffers = (boost::asio::mutable_buffers_1 *)v44;
      }
      else
      {
        v13 = v10;
        v14 = v12;
      }
LABEL_31:
      v20 = *((unsigned __int8 *)v4 + 16);
      if ( (v20 & 1) != 0 )
      {
        v22 = *((_QWORD *)v4 + 3);
        v21 = (_BYTE *)*((_QWORD *)v4 + 4);
        if ( v14 != v10 )
        {
LABEL_36:
          v52 = *((unsigned __int8 *)v4 + 16);
          v27 = &v21[v22];
          v28 = v14;
          v46 = v4;
          v47 = v21;
          v50 = v22;
          while ( 1 )
          {
            LOBYTE(v20) = 1;
            v45 = v20;
            if ( !v22 )
              break;
            v29 = v21;
            v51 = data;
            v30 = data;
            v20 = v13;
            v31 = v12;
            v32 = p_buffers;
            v49 = v28;
            while ( v28 != v10 )
            {
              if ( v30[v31] != *v29 )
                goto LABEL_52;
              if ( ++v31 == v20 )
              {
                if ( &v32[1] == (boost::asio::mutable_buffers_1 *)v44 )
                {
                  v32 = (boost::asio::mutable_buffers_1 *)v44;
                }
                else
                {
                  while ( 1 )
                  {
                    v33 = v32;
                    v20 = v32[1].size_;
                    ++v32;
                    if ( v20 )
                      break;
                    if ( &buffers == v32 )
                    {
                      v32 = (boost::asio::mutable_buffers_1 *)v44;
                      break;
                    }
                  }
                  v30 = v33[1].data_;
                }
                v31 = 0;
              }
              ++v28;
              if ( ++v29 == v27 )
                goto LABEL_65;
            }
            if ( v29 != v47 )
            {
              v45 = 0;
LABEL_65:
              v4 = v46;
              v24 = v49;
              goto LABEL_66;
            }
LABEL_52:
            v28 = v49 + 1;
            if ( ++v12 == v13 )
            {
              LODWORD(v20) = (_DWORD)p_buffers + 16;
              v4 = v46;
              data = v51;
              v22 = v50;
              if ( &p_buffers[1] == (boost::asio::mutable_buffers_1 *)v44 )
              {
                v12 = 0;
                p_buffers = (boost::asio::mutable_buffers_1 *)v44;
                v21 = v47;
              }
              else
              {
                v21 = v47;
                while ( 1 )
                {
                  v20 = (unsigned __int64)p_buffers;
                  v13 = p_buffers[1].size_;
                  ++p_buffers;
                  if ( v13 )
                    break;
                  if ( &buffers == p_buffers )
                  {
                    p_buffers = (boost::asio::mutable_buffers_1 *)v44;
                    break;
                  }
                }
                data = *(void **)(v20 + 16);
                v12 = 0;
              }
            }
            else
            {
              v4 = v46;
              data = v51;
              v21 = v47;
              v22 = v50;
            }
            if ( v28 == v10 )
              goto LABEL_35;
          }
          v24 = v14;
LABEL_66:
          v25 = v48;
          v26 = v42;
          if ( v24 == v10 )
          {
            v23 = 0;
            v24 = v10;
          }
          else
          {
            if ( (_BYTE)v45 )
            {
              if ( (v52 & 1) != 0 )
                v34 = *((_QWORD *)v4 + 3);
              else
                v34 = (unsigned __int8)v52 >> 1;
              v36 = v24 + v34;
              *((_QWORD *)v4 + 6) = v36;
              goto LABEL_91;
            }
            v23 = 1;
          }
LABEL_72:
          v35 = *((_QWORD *)v25 + 8) - v10;
          if ( v35 )
          {
            if ( !v23 )
              v24 = v10;
            *((_QWORD *)v4 + 6) = v24;
            v37 = 0x10000;
            if ( v35 < 0x10000 )
              v37 = v35;
            v38 = 512;
            if ( (unsigned __int64)(*((_QWORD *)v25 + 11) - *((_QWORD *)v25 + 9) - v10) > 0x200 )
              v38 = *((_QWORD *)v25 + 11) - *((_QWORD *)v25 + 9) - v10;
            if ( v37 < v38 )
              v38 = v37;
            v36 = v24;
            if ( v26 )
              goto LABEL_92;
            goto LABEL_83;
          }
          *((_QWORD *)v4 + 6) = -1;
          v36 = -1;
LABEL_91:
          v38 = 0;
          if ( v26 )
            goto LABEL_92;
LABEL_83:
          if ( v38 )
          {
LABEL_92:
            v41 = *(boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> **)v4;
            boost::asio::basic_streambuf<std::allocator<char>>::reserve(v25, v38);
            buffers.data_ = (void *)*((_QWORD *)v25 + 6);
            buffers.size_ = v38;
            boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>(
              v41,
              &buffers,
              v4);
            return;
          }
          if ( v36 != -1 )
            goto LABEL_85;
LABEL_14:
          if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
            __cxa_guard_release(&byte_2B114E0);
          LODWORD(buffers.data_) = 3;
          buffers.size_ = (size_t)off_2870A08;
          goto LABEL_86;
        }
      }
      else
      {
        v21 = (char *)v4 + 17;
        v22 = v20 >> 1;
        if ( v14 != v10 )
          goto LABEL_36;
      }
LABEL_35:
      v23 = 0;
      v24 = v10;
      v25 = v48;
      v26 = v42;
      goto LABEL_72;
    }
  }
  if ( *((_QWORD *)v4 + 6) == -1 )
    goto LABEL_14;
LABEL_85:
  buffers = *v53;
LABEL_86:
  v39 = (char *)*((_QWORD *)v4 + 7);
  v40 = (_QWORD *)(*((_QWORD *)v4 + 8) + *((_QWORD *)v4 + 9));
  if ( ((unsigned __int8)v39 & 1) != 0 )
    v39 = *(char **)&v39[*v40 - 1];
  ((void (__fastcall *)(_QWORD *, boost::asio::mutable_buffers_1 *))v39)(v40, &buffers);
}


// Address: 0x26a69e0 | Name: _ZN5boost4asio6detail26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSC_5list2INSC_5valueINS9_10shared_ptrISL_EEEEPFNS_3argILi1EEEvEEEEEEclESP_mi
void __fastcall boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>::operator()(
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *v4; // r15
  boost::asio::basic_streambuf<std::allocator<char> > *v5; // rbp
  __int64 v6; // rax
  int v7; // edi
  __int64 v8; // rdi
  void *data; // r8
  signed __int64 v10; // r10
  boost::asio::mutable_buffers_1 *p_buffers; // rbx
  __int64 v12; // r14
  __int64 v13; // r9
  __int64 v14; // r11
  size_t v15; // rdx
  unsigned __int64 v16; // rax
  boost::asio::mutable_buffers_1 *v17; // rsi
  size_t size; // r14
  bool v19; // cf
  unsigned __int64 v20; // rax
  _BYTE *v21; // rdx
  unsigned __int64 v22; // rbp
  char v23; // al
  signed __int64 v24; // rbp
  boost::asio::basic_streambuf<std::allocator<char> > *v25; // rdi
  int v26; // esi
  _BYTE *v27; // rsi
  __int64 v28; // r12
  _BYTE *v29; // rbp
  _BYTE *v30; // r15
  __int64 v31; // rdx
  boost::asio::mutable_buffers_1 *v32; // r13
  boost::asio::mutable_buffers_1 *v33; // rdx
  __int64 v34; // rax
  unsigned __int64 v35; // rcx
  __int64 v36; // rax
  unsigned __int64 v37; // rdx
  size_t v38; // rbx
  char *v39; // rax
  _QWORD *v40; // rdi
  __int64 v41; // r12
  int v42; // [rsp+Ch] [rbp-8Ch]
  boost::asio::mutable_buffers_1 buffers; // [rsp+10h] [rbp-88h] BYREF
  _BYTE v44[4]; // [rsp+20h] [rbp-78h] BYREF
  int v45; // [rsp+24h] [rbp-74h]
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *v46; // [rsp+28h] [rbp-70h]
  _BYTE *v47; // [rsp+30h] [rbp-68h]
  boost::asio::basic_streambuf<std::allocator<char> > *v48; // [rsp+38h] [rbp-60h]
  signed __int64 v49; // [rsp+40h] [rbp-58h]
  unsigned __int64 v50; // [rsp+48h] [rbp-50h]
  void *v51; // [rsp+50h] [rbp-48h]
  __int64 v52; // [rsp+58h] [rbp-40h]
  boost::asio::mutable_buffers_1 *v53; // [rsp+60h] [rbp-38h]

  v4 = this;
  *((_DWORD *)this + 10) = start;
  v5 = (boost::asio::basic_streambuf<std::allocator<char> > *)*((_QWORD *)this + 1);
  v53 = (boost::asio::mutable_buffers_1 *)ec;
  if ( start == 1 )
    goto LABEL_6;
  v6 = *((_QWORD *)v5 + 6);
  v7 = *((_QWORD *)v5 + 7) - v6;
  if ( v6 + bytes_transferred <= *((_QWORD *)v5 + 7) )
    v7 = bytes_transferred;
  v8 = v6 + v7;
  *((_QWORD *)v5 + 6) = v8;
  *((_QWORD *)v5 + 4) = v8;
  if ( bytes_transferred )
  {
    if ( !ec->m_val )
    {
LABEL_6:
      data = (void *)*((_QWORD *)v5 + 3);
      v10 = *((_QWORD *)v5 + 6) - (_QWORD)data;
      buffers.data_ = data;
      buffers.size_ = v10;
      p_buffers = &buffers;
      if ( !v10 )
        p_buffers = (boost::asio::mutable_buffers_1 *)v44;
      v12 = *((_QWORD *)v4 + 6);
      v48 = v5;
      v42 = start;
      if ( v12 <= 0 )
      {
        if ( v12 < 0 )
        {
          v13 = v10;
          v15 = 0;
          v14 = 0;
          v16 = -v12;
LABEL_22:
          while ( 2 )
          {
            v14 -= v15;
            if ( p_buffers == &buffers )
            {
              v12 = 0;
            }
            else
            {
              v16 -= v15;
              v17 = p_buffers;
              while ( &buffers != v17 )
              {
                size = v17[-1].size_;
                --v17;
                if ( size )
                {
                  data = v17->data_;
                  v13 = size;
                  p_buffers = v17;
                  v15 = size;
                  v19 = size < v16;
                  v12 = size - v16;
                  if ( v19 )
                    goto LABEL_22;
                  goto LABEL_29;
                }
              }
              v12 = v15 - v16;
              if ( v15 < v16 )
                continue;
LABEL_29:
              v14 -= v16;
            }
            break;
          }
        }
        else
        {
          v12 = 0;
          v13 = v10;
          v14 = 0;
        }
      }
      else if ( v10 <= v12 )
      {
        data = 0;
        v14 = 0;
        v13 = v10;
        while ( 1 )
        {
          v14 += v13;
          if ( &buffers == p_buffers )
            break;
          v12 -= v13;
          v13 = p_buffers[1].size_;
          ++p_buffers;
          if ( v12 < v13 )
          {
            data = p_buffers->data_;
            v14 += v12;
            goto LABEL_31;
          }
        }
        v13 = 0;
        v12 = 0;
        p_buffers = (boost::asio::mutable_buffers_1 *)v44;
      }
      else
      {
        v13 = v10;
        v14 = v12;
      }
LABEL_31:
      v20 = *((unsigned __int8 *)v4 + 16);
      if ( (v20 & 1) != 0 )
      {
        v22 = *((_QWORD *)v4 + 3);
        v21 = (_BYTE *)*((_QWORD *)v4 + 4);
        if ( v14 != v10 )
        {
LABEL_36:
          v52 = *((unsigned __int8 *)v4 + 16);
          v27 = &v21[v22];
          v28 = v14;
          v46 = v4;
          v47 = v21;
          v50 = v22;
          while ( 1 )
          {
            LOBYTE(v20) = 1;
            v45 = v20;
            if ( !v22 )
              break;
            v29 = v21;
            v51 = data;
            v30 = data;
            v20 = v13;
            v31 = v12;
            v32 = p_buffers;
            v49 = v28;
            while ( v28 != v10 )
            {
              if ( v30[v31] != *v29 )
                goto LABEL_52;
              if ( ++v31 == v20 )
              {
                if ( &v32[1] == (boost::asio::mutable_buffers_1 *)v44 )
                {
                  v32 = (boost::asio::mutable_buffers_1 *)v44;
                }
                else
                {
                  while ( 1 )
                  {
                    v33 = v32;
                    v20 = v32[1].size_;
                    ++v32;
                    if ( v20 )
                      break;
                    if ( &buffers == v32 )
                    {
                      v32 = (boost::asio::mutable_buffers_1 *)v44;
                      break;
                    }
                  }
                  v30 = v33[1].data_;
                }
                v31 = 0;
              }
              ++v28;
              if ( ++v29 == v27 )
                goto LABEL_65;
            }
            if ( v29 != v47 )
            {
              v45 = 0;
LABEL_65:
              v4 = v46;
              v24 = v49;
              goto LABEL_66;
            }
LABEL_52:
            v28 = v49 + 1;
            if ( ++v12 == v13 )
            {
              LODWORD(v20) = (_DWORD)p_buffers + 16;
              v4 = v46;
              data = v51;
              v22 = v50;
              if ( &p_buffers[1] == (boost::asio::mutable_buffers_1 *)v44 )
              {
                v12 = 0;
                p_buffers = (boost::asio::mutable_buffers_1 *)v44;
                v21 = v47;
              }
              else
              {
                v21 = v47;
                while ( 1 )
                {
                  v20 = (unsigned __int64)p_buffers;
                  v13 = p_buffers[1].size_;
                  ++p_buffers;
                  if ( v13 )
                    break;
                  if ( &buffers == p_buffers )
                  {
                    p_buffers = (boost::asio::mutable_buffers_1 *)v44;
                    break;
                  }
                }
                data = *(void **)(v20 + 16);
                v12 = 0;
              }
            }
            else
            {
              v4 = v46;
              data = v51;
              v21 = v47;
              v22 = v50;
            }
            if ( v28 == v10 )
              goto LABEL_35;
          }
          v24 = v14;
LABEL_66:
          v25 = v48;
          v26 = v42;
          if ( v24 == v10 )
          {
            v23 = 0;
            v24 = v10;
          }
          else
          {
            if ( (_BYTE)v45 )
            {
              if ( (v52 & 1) != 0 )
                v34 = *((_QWORD *)v4 + 3);
              else
                v34 = (unsigned __int8)v52 >> 1;
              v36 = v24 + v34;
              *((_QWORD *)v4 + 6) = v36;
              goto LABEL_91;
            }
            v23 = 1;
          }
LABEL_72:
          v35 = *((_QWORD *)v25 + 8) - v10;
          if ( v35 )
          {
            if ( !v23 )
              v24 = v10;
            *((_QWORD *)v4 + 6) = v24;
            v37 = 0x10000;
            if ( v35 < 0x10000 )
              v37 = v35;
            v38 = 512;
            if ( (unsigned __int64)(*((_QWORD *)v25 + 11) - *((_QWORD *)v25 + 9) - v10) > 0x200 )
              v38 = *((_QWORD *)v25 + 11) - *((_QWORD *)v25 + 9) - v10;
            if ( v37 < v38 )
              v38 = v37;
            v36 = v24;
            if ( v26 )
              goto LABEL_92;
            goto LABEL_83;
          }
          *((_QWORD *)v4 + 6) = -1;
          v36 = -1;
LABEL_91:
          v38 = 0;
          if ( v26 )
            goto LABEL_92;
LABEL_83:
          if ( v38 )
          {
LABEL_92:
            v41 = *(_QWORD *)v4;
            boost::asio::basic_streambuf<std::allocator<char>>::reserve(v25, v38);
            buffers.data_ = (void *)*((_QWORD *)v25 + 6);
            buffers.size_ = v38;
            boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>(
              *(boost::asio::stream_socket_service<boost::asio::ip::tcp> **)(v41 + 24),
              (boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *)v41,
              &buffers,
              0,
              v4);
            return;
          }
          if ( v36 != -1 )
            goto LABEL_85;
LABEL_14:
          if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
            __cxa_guard_release(&byte_2B114E0);
          LODWORD(buffers.data_) = 3;
          buffers.size_ = (size_t)off_2870A08;
          goto LABEL_86;
        }
      }
      else
      {
        v21 = (char *)v4 + 17;
        v22 = v20 >> 1;
        if ( v14 != v10 )
          goto LABEL_36;
      }
LABEL_35:
      v23 = 0;
      v24 = v10;
      v25 = v48;
      v26 = v42;
      goto LABEL_72;
    }
  }
  if ( *((_QWORD *)v4 + 6) == -1 )
    goto LABEL_14;
LABEL_85:
  buffers = *v53;
LABEL_86:
  v39 = (char *)*((_QWORD *)v4 + 7);
  v40 = (_QWORD *)(*((_QWORD *)v4 + 8) + *((_QWORD *)v4 + 9));
  if ( ((unsigned __int8)v39 & 1) != 0 )
    v39 = *(char **)&v39[*v40 - 1];
  ((void (__fastcall *)(_QWORD *, boost::asio::mutable_buffers_1 *))v39)(v40, &buffers);
}


// Address: 0x26acc00 | Name: _ZN5boost4asio16async_read_untilINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEEEENSt3__19allocatorIcEERKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSC_10shared_ptrISN_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSP_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EERKNSC_12basic_stringIcNSC_11char_traitsIcEESE_EEOS18_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::async_read_until<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        const std::string *delim,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *v4; // r14
  volatile signed __int64 *cntrl; // rbx
  std::__shared_weak_count *v6; // rbx
  boost::system::error_code ec; // [rsp+8h] [rbp-90h] BYREF
  _QWORD v8[2]; // [rsp+18h] [rbp-80h] BYREF
  _BYTE v9[16]; // [rsp+28h] [rbp-70h] BYREF
  void *ptr; // [rsp+38h] [rbp-60h]
  int v11; // [rsp+40h] [rbp-58h]
  __int64 v12; // [rsp+48h] [rbp-50h]
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> v13; // [rsp+50h] [rbp-48h]
  std::shared_ptr<web::http::client::details::asio_context>::element_type *v14; // [rsp+60h] [rbp-38h]
  std::__shared_weak_count *v15; // [rsp+68h] [rbp-30h]
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> f; // [rsp+70h] [rbp-28h]

  f = handler->f_;
  v4 = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v8[0] = s;
  v8[1] = b;
  std::string::basic_string(v9, delim);
  v11 = 0;
  v12 = 0;
  v13 = f;
  v14 = v4;
  v15 = (std::__shared_weak_count *)cntrl;
  ec.m_val = 0;
  ec.m_cat = boost::system::system_category();
  boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
    (boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *)v8,
    &ec,
    0,
    1);
  v6 = v15;
  if ( v15 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v15 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
    if ( (v9[0] & 1) == 0 )
      return;
  }
  else if ( (v9[0] & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26acd60 | Name: _ZN5boost4asio16async_read_untilINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__19allocatorIcEERKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSB_5list2INSB_5valueINS8_10shared_ptrISJ_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSL_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EERKNS8_12basic_stringIcNS8_11char_traitsIcEESA_EEOS14_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::async_read_until<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        const std::string *delim,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *v4; // r14
  volatile signed __int64 *cntrl; // rbx
  std::__shared_weak_count *v6; // rbx
  boost::system::error_code ec; // [rsp+8h] [rbp-90h] BYREF
  _QWORD v8[2]; // [rsp+18h] [rbp-80h] BYREF
  _BYTE v9[16]; // [rsp+28h] [rbp-70h] BYREF
  void *ptr; // [rsp+38h] [rbp-60h]
  int v11; // [rsp+40h] [rbp-58h]
  __int64 v12; // [rsp+48h] [rbp-50h]
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> v13; // [rsp+50h] [rbp-48h]
  std::shared_ptr<web::http::client::details::asio_context>::element_type *v14; // [rsp+60h] [rbp-38h]
  std::__shared_weak_count *v15; // [rsp+68h] [rbp-30h]
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> f; // [rsp+70h] [rbp-28h]

  f = handler->f_;
  v4 = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v8[0] = s;
  v8[1] = b;
  std::string::basic_string(v9, delim);
  v11 = 0;
  v12 = 0;
  v13 = f;
  v14 = v4;
  v15 = (std::__shared_weak_count *)cntrl;
  ec.m_val = 0;
  ec.m_cat = boost::system::system_category();
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
    (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *)v8,
    &ec,
    0,
    1);
  v6 = v15;
  if ( v15 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v15 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
    if ( (v9[0] & 1) == 0 )
      return;
  }
  else if ( (v9[0] & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26acec0 | Name: _ZN5boost4asio6detail26read_until_delim_string_opINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEEEENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSG_5list2INSG_5valueINSD_10shared_ptrISO_EEEEPFNS_3argILi1EEEvEEEEEEclESS_mi
void __fastcall boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
        boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *v4; // r15
  boost::asio::basic_streambuf<std::allocator<char> > *v5; // rbp
  __int64 v6; // rax
  int v7; // edi
  __int64 v8; // rdi
  void *data; // r8
  signed __int64 v10; // r10
  boost::asio::mutable_buffers_1 *p_buffers; // rbx
  __int64 v12; // r14
  __int64 v13; // r9
  __int64 v14; // r11
  size_t v15; // rdx
  unsigned __int64 v16; // rax
  boost::asio::mutable_buffers_1 *v17; // rsi
  size_t size; // r14
  bool v19; // cf
  unsigned __int64 v20; // rax
  _BYTE *v21; // rdx
  unsigned __int64 v22; // rbp
  char v23; // al
  signed __int64 v24; // rbp
  boost::asio::basic_streambuf<std::allocator<char> > *v25; // rdi
  int v26; // esi
  _BYTE *v27; // rsi
  __int64 v28; // r12
  _BYTE *v29; // rbp
  _BYTE *v30; // r15
  __int64 v31; // rdx
  boost::asio::mutable_buffers_1 *v32; // r13
  boost::asio::mutable_buffers_1 *v33; // rdx
  __int64 v34; // rax
  unsigned __int64 v35; // rcx
  __int64 v36; // rax
  unsigned __int64 v37; // rdx
  size_t v38; // rbx
  char *v39; // rax
  _QWORD *v40; // rdi
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *v41; // r12
  int v42; // [rsp+Ch] [rbp-8Ch]
  boost::asio::mutable_buffers_1 buffers; // [rsp+10h] [rbp-88h] BYREF
  _BYTE v44[4]; // [rsp+20h] [rbp-78h] BYREF
  int v45; // [rsp+24h] [rbp-74h]
  boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *v46; // [rsp+28h] [rbp-70h]
  _BYTE *v47; // [rsp+30h] [rbp-68h]
  boost::asio::basic_streambuf<std::allocator<char> > *v48; // [rsp+38h] [rbp-60h]
  signed __int64 v49; // [rsp+40h] [rbp-58h]
  unsigned __int64 v50; // [rsp+48h] [rbp-50h]
  void *v51; // [rsp+50h] [rbp-48h]
  __int64 v52; // [rsp+58h] [rbp-40h]
  boost::asio::mutable_buffers_1 *v53; // [rsp+60h] [rbp-38h]

  v4 = this;
  *((_DWORD *)this + 10) = start;
  v5 = (boost::asio::basic_streambuf<std::allocator<char> > *)*((_QWORD *)this + 1);
  v53 = (boost::asio::mutable_buffers_1 *)ec;
  if ( start == 1 )
    goto LABEL_6;
  v6 = *((_QWORD *)v5 + 6);
  v7 = *((_QWORD *)v5 + 7) - v6;
  if ( v6 + bytes_transferred <= *((_QWORD *)v5 + 7) )
    v7 = bytes_transferred;
  v8 = v6 + v7;
  *((_QWORD *)v5 + 6) = v8;
  *((_QWORD *)v5 + 4) = v8;
  if ( bytes_transferred )
  {
    if ( !ec->m_val )
    {
LABEL_6:
      data = (void *)*((_QWORD *)v5 + 3);
      v10 = *((_QWORD *)v5 + 6) - (_QWORD)data;
      buffers.data_ = data;
      buffers.size_ = v10;
      p_buffers = &buffers;
      if ( !v10 )
        p_buffers = (boost::asio::mutable_buffers_1 *)v44;
      v12 = *((_QWORD *)v4 + 6);
      v48 = v5;
      v42 = start;
      if ( v12 <= 0 )
      {
        if ( v12 < 0 )
        {
          v13 = v10;
          v15 = 0;
          v14 = 0;
          v16 = -v12;
LABEL_22:
          while ( 2 )
          {
            v14 -= v15;
            if ( p_buffers == &buffers )
            {
              v12 = 0;
            }
            else
            {
              v16 -= v15;
              v17 = p_buffers;
              while ( &buffers != v17 )
              {
                size = v17[-1].size_;
                --v17;
                if ( size )
                {
                  data = v17->data_;
                  v13 = size;
                  p_buffers = v17;
                  v15 = size;
                  v19 = size < v16;
                  v12 = size - v16;
                  if ( v19 )
                    goto LABEL_22;
                  goto LABEL_29;
                }
              }
              v12 = v15 - v16;
              if ( v15 < v16 )
                continue;
LABEL_29:
              v14 -= v16;
            }
            break;
          }
        }
        else
        {
          v12 = 0;
          v13 = v10;
          v14 = 0;
        }
      }
      else if ( v10 <= v12 )
      {
        data = 0;
        v14 = 0;
        v13 = v10;
        while ( 1 )
        {
          v14 += v13;
          if ( &buffers == p_buffers )
            break;
          v12 -= v13;
          v13 = p_buffers[1].size_;
          ++p_buffers;
          if ( v12 < v13 )
          {
            data = p_buffers->data_;
            v14 += v12;
            goto LABEL_31;
          }
        }
        v13 = 0;
        v12 = 0;
        p_buffers = (boost::asio::mutable_buffers_1 *)v44;
      }
      else
      {
        v13 = v10;
        v14 = v12;
      }
LABEL_31:
      v20 = *((unsigned __int8 *)v4 + 16);
      if ( (v20 & 1) != 0 )
      {
        v22 = *((_QWORD *)v4 + 3);
        v21 = (_BYTE *)*((_QWORD *)v4 + 4);
        if ( v14 != v10 )
        {
LABEL_36:
          v52 = *((unsigned __int8 *)v4 + 16);
          v27 = &v21[v22];
          v28 = v14;
          v46 = v4;
          v47 = v21;
          v50 = v22;
          while ( 1 )
          {
            LOBYTE(v20) = 1;
            v45 = v20;
            if ( !v22 )
              break;
            v29 = v21;
            v51 = data;
            v30 = data;
            v20 = v13;
            v31 = v12;
            v32 = p_buffers;
            v49 = v28;
            while ( v28 != v10 )
            {
              if ( v30[v31] != *v29 )
                goto LABEL_52;
              if ( ++v31 == v20 )
              {
                if ( &v32[1] == (boost::asio::mutable_buffers_1 *)v44 )
                {
                  v32 = (boost::asio::mutable_buffers_1 *)v44;
                }
                else
                {
                  while ( 1 )
                  {
                    v33 = v32;
                    v20 = v32[1].size_;
                    ++v32;
                    if ( v20 )
                      break;
                    if ( &buffers == v32 )
                    {
                      v32 = (boost::asio::mutable_buffers_1 *)v44;
                      break;
                    }
                  }
                  v30 = v33[1].data_;
                }
                v31 = 0;
              }
              ++v28;
              if ( ++v29 == v27 )
                goto LABEL_65;
            }
            if ( v29 != v47 )
            {
              v45 = 0;
LABEL_65:
              v4 = v46;
              v24 = v49;
              goto LABEL_66;
            }
LABEL_52:
            v28 = v49 + 1;
            if ( ++v12 == v13 )
            {
              LODWORD(v20) = (_DWORD)p_buffers + 16;
              v4 = v46;
              data = v51;
              v22 = v50;
              if ( &p_buffers[1] == (boost::asio::mutable_buffers_1 *)v44 )
              {
                v12 = 0;
                p_buffers = (boost::asio::mutable_buffers_1 *)v44;
                v21 = v47;
              }
              else
              {
                v21 = v47;
                while ( 1 )
                {
                  v20 = (unsigned __int64)p_buffers;
                  v13 = p_buffers[1].size_;
                  ++p_buffers;
                  if ( v13 )
                    break;
                  if ( &buffers == p_buffers )
                  {
                    p_buffers = (boost::asio::mutable_buffers_1 *)v44;
                    break;
                  }
                }
                data = *(void **)(v20 + 16);
                v12 = 0;
              }
            }
            else
            {
              v4 = v46;
              data = v51;
              v21 = v47;
              v22 = v50;
            }
            if ( v28 == v10 )
              goto LABEL_35;
          }
          v24 = v14;
LABEL_66:
          v25 = v48;
          v26 = v42;
          if ( v24 == v10 )
          {
            v23 = 0;
            v24 = v10;
          }
          else
          {
            if ( (_BYTE)v45 )
            {
              if ( (v52 & 1) != 0 )
                v34 = *((_QWORD *)v4 + 3);
              else
                v34 = (unsigned __int8)v52 >> 1;
              v36 = v24 + v34;
              *((_QWORD *)v4 + 6) = v36;
              goto LABEL_91;
            }
            v23 = 1;
          }
LABEL_72:
          v35 = *((_QWORD *)v25 + 8) - v10;
          if ( v35 )
          {
            if ( !v23 )
              v24 = v10;
            *((_QWORD *)v4 + 6) = v24;
            v37 = 0x10000;
            if ( v35 < 0x10000 )
              v37 = v35;
            v38 = 512;
            if ( (unsigned __int64)(*((_QWORD *)v25 + 11) - *((_QWORD *)v25 + 9) - v10) > 0x200 )
              v38 = *((_QWORD *)v25 + 11) - *((_QWORD *)v25 + 9) - v10;
            if ( v37 < v38 )
              v38 = v37;
            v36 = v24;
            if ( v26 )
              goto LABEL_92;
            goto LABEL_83;
          }
          *((_QWORD *)v4 + 6) = -1;
          v36 = -1;
LABEL_91:
          v38 = 0;
          if ( v26 )
            goto LABEL_92;
LABEL_83:
          if ( v38 )
          {
LABEL_92:
            v41 = *(boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> **)v4;
            boost::asio::basic_streambuf<std::allocator<char>>::reserve(v25, v38);
            buffers.data_ = (void *)*((_QWORD *)v25 + 6);
            buffers.size_ = v38;
            boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
              v41,
              &buffers,
              v4);
            return;
          }
          if ( v36 != -1 )
            goto LABEL_85;
LABEL_14:
          if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
            __cxa_guard_release(&byte_2B114E0);
          LODWORD(buffers.data_) = 3;
          buffers.size_ = (size_t)off_2870A08;
          goto LABEL_86;
        }
      }
      else
      {
        v21 = (char *)v4 + 17;
        v22 = v20 >> 1;
        if ( v14 != v10 )
          goto LABEL_36;
      }
LABEL_35:
      v23 = 0;
      v24 = v10;
      v25 = v48;
      v26 = v42;
      goto LABEL_72;
    }
  }
  if ( *((_QWORD *)v4 + 6) == -1 )
    goto LABEL_14;
LABEL_85:
  buffers = *v53;
LABEL_86:
  v39 = (char *)*((_QWORD *)v4 + 7);
  v40 = (_QWORD *)(*((_QWORD *)v4 + 8) + *((_QWORD *)v4 + 9));
  if ( ((unsigned __int8)v39 & 1) != 0 )
    v39 = *(char **)&v39[*v40 - 1];
  ((void (__fastcall *)(_QWORD *, boost::asio::mutable_buffers_1 *))v39)(v40, &buffers);
}


// Address: 0x26aee60 | Name: _ZN5boost4asio6detail26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSC_5list2INSC_5valueINS9_10shared_ptrISK_EEEEPFNS_3argILi1EEEvEEEEEEclESO_mi
void __fastcall boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *v4; // r15
  boost::asio::basic_streambuf<std::allocator<char> > *v5; // rbp
  __int64 v6; // rax
  int v7; // edi
  __int64 v8; // rdi
  void *data; // r8
  signed __int64 v10; // r10
  boost::asio::mutable_buffers_1 *p_buffers; // rbx
  __int64 v12; // r14
  __int64 v13; // r9
  __int64 v14; // r11
  size_t v15; // rdx
  unsigned __int64 v16; // rax
  boost::asio::mutable_buffers_1 *v17; // rsi
  size_t size; // r14
  bool v19; // cf
  unsigned __int64 v20; // rax
  _BYTE *v21; // rdx
  unsigned __int64 v22; // rbp
  char v23; // al
  signed __int64 v24; // rbp
  boost::asio::basic_streambuf<std::allocator<char> > *v25; // rdi
  int v26; // esi
  _BYTE *v27; // rsi
  __int64 v28; // r12
  _BYTE *v29; // rbp
  _BYTE *v30; // r15
  __int64 v31; // rdx
  boost::asio::mutable_buffers_1 *v32; // r13
  boost::asio::mutable_buffers_1 *v33; // rdx
  __int64 v34; // rax
  unsigned __int64 v35; // rcx
  __int64 v36; // rax
  unsigned __int64 v37; // rdx
  size_t v38; // rbx
  char *v39; // rax
  _QWORD *v40; // rdi
  __int64 v41; // r12
  int v42; // [rsp+Ch] [rbp-8Ch]
  boost::asio::mutable_buffers_1 buffers; // [rsp+10h] [rbp-88h] BYREF
  _BYTE v44[4]; // [rsp+20h] [rbp-78h] BYREF
  int v45; // [rsp+24h] [rbp-74h]
  boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *v46; // [rsp+28h] [rbp-70h]
  _BYTE *v47; // [rsp+30h] [rbp-68h]
  boost::asio::basic_streambuf<std::allocator<char> > *v48; // [rsp+38h] [rbp-60h]
  signed __int64 v49; // [rsp+40h] [rbp-58h]
  unsigned __int64 v50; // [rsp+48h] [rbp-50h]
  void *v51; // [rsp+50h] [rbp-48h]
  __int64 v52; // [rsp+58h] [rbp-40h]
  boost::asio::mutable_buffers_1 *v53; // [rsp+60h] [rbp-38h]

  v4 = this;
  *((_DWORD *)this + 10) = start;
  v5 = (boost::asio::basic_streambuf<std::allocator<char> > *)*((_QWORD *)this + 1);
  v53 = (boost::asio::mutable_buffers_1 *)ec;
  if ( start == 1 )
    goto LABEL_6;
  v6 = *((_QWORD *)v5 + 6);
  v7 = *((_QWORD *)v5 + 7) - v6;
  if ( v6 + bytes_transferred <= *((_QWORD *)v5 + 7) )
    v7 = bytes_transferred;
  v8 = v6 + v7;
  *((_QWORD *)v5 + 6) = v8;
  *((_QWORD *)v5 + 4) = v8;
  if ( bytes_transferred )
  {
    if ( !ec->m_val )
    {
LABEL_6:
      data = (void *)*((_QWORD *)v5 + 3);
      v10 = *((_QWORD *)v5 + 6) - (_QWORD)data;
      buffers.data_ = data;
      buffers.size_ = v10;
      p_buffers = &buffers;
      if ( !v10 )
        p_buffers = (boost::asio::mutable_buffers_1 *)v44;
      v12 = *((_QWORD *)v4 + 6);
      v48 = v5;
      v42 = start;
      if ( v12 <= 0 )
      {
        if ( v12 < 0 )
        {
          v13 = v10;
          v15 = 0;
          v14 = 0;
          v16 = -v12;
LABEL_22:
          while ( 2 )
          {
            v14 -= v15;
            if ( p_buffers == &buffers )
            {
              v12 = 0;
            }
            else
            {
              v16 -= v15;
              v17 = p_buffers;
              while ( &buffers != v17 )
              {
                size = v17[-1].size_;
                --v17;
                if ( size )
                {
                  data = v17->data_;
                  v13 = size;
                  p_buffers = v17;
                  v15 = size;
                  v19 = size < v16;
                  v12 = size - v16;
                  if ( v19 )
                    goto LABEL_22;
                  goto LABEL_29;
                }
              }
              v12 = v15 - v16;
              if ( v15 < v16 )
                continue;
LABEL_29:
              v14 -= v16;
            }
            break;
          }
        }
        else
        {
          v12 = 0;
          v13 = v10;
          v14 = 0;
        }
      }
      else if ( v10 <= v12 )
      {
        data = 0;
        v14 = 0;
        v13 = v10;
        while ( 1 )
        {
          v14 += v13;
          if ( &buffers == p_buffers )
            break;
          v12 -= v13;
          v13 = p_buffers[1].size_;
          ++p_buffers;
          if ( v12 < v13 )
          {
            data = p_buffers->data_;
            v14 += v12;
            goto LABEL_31;
          }
        }
        v13 = 0;
        v12 = 0;
        p_buffers = (boost::asio::mutable_buffers_1 *)v44;
      }
      else
      {
        v13 = v10;
        v14 = v12;
      }
LABEL_31:
      v20 = *((unsigned __int8 *)v4 + 16);
      if ( (v20 & 1) != 0 )
      {
        v22 = *((_QWORD *)v4 + 3);
        v21 = (_BYTE *)*((_QWORD *)v4 + 4);
        if ( v14 != v10 )
        {
LABEL_36:
          v52 = *((unsigned __int8 *)v4 + 16);
          v27 = &v21[v22];
          v28 = v14;
          v46 = v4;
          v47 = v21;
          v50 = v22;
          while ( 1 )
          {
            LOBYTE(v20) = 1;
            v45 = v20;
            if ( !v22 )
              break;
            v29 = v21;
            v51 = data;
            v30 = data;
            v20 = v13;
            v31 = v12;
            v32 = p_buffers;
            v49 = v28;
            while ( v28 != v10 )
            {
              if ( v30[v31] != *v29 )
                goto LABEL_52;
              if ( ++v31 == v20 )
              {
                if ( &v32[1] == (boost::asio::mutable_buffers_1 *)v44 )
                {
                  v32 = (boost::asio::mutable_buffers_1 *)v44;
                }
                else
                {
                  while ( 1 )
                  {
                    v33 = v32;
                    v20 = v32[1].size_;
                    ++v32;
                    if ( v20 )
                      break;
                    if ( &buffers == v32 )
                    {
                      v32 = (boost::asio::mutable_buffers_1 *)v44;
                      break;
                    }
                  }
                  v30 = v33[1].data_;
                }
                v31 = 0;
              }
              ++v28;
              if ( ++v29 == v27 )
                goto LABEL_65;
            }
            if ( v29 != v47 )
            {
              v45 = 0;
LABEL_65:
              v4 = v46;
              v24 = v49;
              goto LABEL_66;
            }
LABEL_52:
            v28 = v49 + 1;
            if ( ++v12 == v13 )
            {
              LODWORD(v20) = (_DWORD)p_buffers + 16;
              v4 = v46;
              data = v51;
              v22 = v50;
              if ( &p_buffers[1] == (boost::asio::mutable_buffers_1 *)v44 )
              {
                v12 = 0;
                p_buffers = (boost::asio::mutable_buffers_1 *)v44;
                v21 = v47;
              }
              else
              {
                v21 = v47;
                while ( 1 )
                {
                  v20 = (unsigned __int64)p_buffers;
                  v13 = p_buffers[1].size_;
                  ++p_buffers;
                  if ( v13 )
                    break;
                  if ( &buffers == p_buffers )
                  {
                    p_buffers = (boost::asio::mutable_buffers_1 *)v44;
                    break;
                  }
                }
                data = *(void **)(v20 + 16);
                v12 = 0;
              }
            }
            else
            {
              v4 = v46;
              data = v51;
              v21 = v47;
              v22 = v50;
            }
            if ( v28 == v10 )
              goto LABEL_35;
          }
          v24 = v14;
LABEL_66:
          v25 = v48;
          v26 = v42;
          if ( v24 == v10 )
          {
            v23 = 0;
            v24 = v10;
          }
          else
          {
            if ( (_BYTE)v45 )
            {
              if ( (v52 & 1) != 0 )
                v34 = *((_QWORD *)v4 + 3);
              else
                v34 = (unsigned __int8)v52 >> 1;
              v36 = v24 + v34;
              *((_QWORD *)v4 + 6) = v36;
              goto LABEL_91;
            }
            v23 = 1;
          }
LABEL_72:
          v35 = *((_QWORD *)v25 + 8) - v10;
          if ( v35 )
          {
            if ( !v23 )
              v24 = v10;
            *((_QWORD *)v4 + 6) = v24;
            v37 = 0x10000;
            if ( v35 < 0x10000 )
              v37 = v35;
            v38 = 512;
            if ( (unsigned __int64)(*((_QWORD *)v25 + 11) - *((_QWORD *)v25 + 9) - v10) > 0x200 )
              v38 = *((_QWORD *)v25 + 11) - *((_QWORD *)v25 + 9) - v10;
            if ( v37 < v38 )
              v38 = v37;
            v36 = v24;
            if ( v26 )
              goto LABEL_92;
            goto LABEL_83;
          }
          *((_QWORD *)v4 + 6) = -1;
          v36 = -1;
LABEL_91:
          v38 = 0;
          if ( v26 )
            goto LABEL_92;
LABEL_83:
          if ( v38 )
          {
LABEL_92:
            v41 = *(_QWORD *)v4;
            boost::asio::basic_streambuf<std::allocator<char>>::reserve(v25, v38);
            buffers.data_ = (void *)*((_QWORD *)v25 + 6);
            buffers.size_ = v38;
            boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
              *(boost::asio::stream_socket_service<boost::asio::ip::tcp> **)(v41 + 24),
              (boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *)v41,
              &buffers,
              0,
              v4);
            return;
          }
          if ( v36 != -1 )
            goto LABEL_85;
LABEL_14:
          if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
            __cxa_guard_release(&byte_2B114E0);
          LODWORD(buffers.data_) = 3;
          buffers.size_ = (size_t)off_2870A08;
          goto LABEL_86;
        }
      }
      else
      {
        v21 = (char *)v4 + 17;
        v22 = v20 >> 1;
        if ( v14 != v10 )
          goto LABEL_36;
      }
LABEL_35:
      v23 = 0;
      v24 = v10;
      v25 = v48;
      v26 = v42;
      goto LABEL_72;
    }
  }
  if ( *((_QWORD *)v4 + 6) == -1 )
    goto LABEL_14;
LABEL_85:
  buffers = *v53;
LABEL_86:
  v39 = (char *)*((_QWORD *)v4 + 7);
  v40 = (_QWORD *)(*((_QWORD *)v4 + 8) + *((_QWORD *)v4 + 9));
  if ( ((unsigned __int8)v39 & 1) != 0 )
    v39 = *(char **)&v39[*v40 - 1];
  ((void (__fastcall *)(_QWORD *, boost::asio::mutable_buffers_1 *))v39)(v40, &buffers);
}


