// Address: 0x2620aa0 | Name: _ZN5boost4asio2ip23basic_resolver_iteratorINS1_3tcpEE6createEP8addrinfoRKNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEESF_
boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> *__fastcall boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>::create(
        boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> *__return_ptr retstr,
        boost::asio::detail::addrinfo_type *address_info,
        const std::string *host_name,
        const std::string *service_name)
{
  boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> *v4; // rbp
  boost::asio::detail::addrinfo_type *v6; // rbx
  char *ai_canonname; // rsi
  std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> *v8; // rax
  _QWORD *v9; // r13
  size_t ai_addrlen; // rdx
  unsigned __int64 v11; // rax
  const boost::system::error_category *v13; // rbx
  __m256i v14; // [rsp+10h] [rbp-C8h] BYREF
  __int128 v15; // [rsp+30h] [rbp-A8h] BYREF
  void *v16; // [rsp+40h] [rbp-98h]
  __int128 v17; // [rsp+48h] [rbp-90h] BYREF
  void *ptr; // [rsp+58h] [rbp-80h]
  _BYTE v19[16]; // [rsp+68h] [rbp-70h] BYREF
  void *v20; // [rsp+78h] [rbp-60h]
  boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> *v21; // [rsp+80h] [rbp-58h]
  _OWORD dest[5]; // [rsp+88h] [rbp-50h] BYREF

  v4 = retstr;
  retstr->values_ = 0;
  retstr->index_ = 0;
  if ( !address_info )
    return v4;
  v6 = address_info;
  std::string::basic_string(v19, host_name);
  ai_canonname = address_info->ai_canonname;
  if ( ai_canonname )
    std::string::assign(v19, ai_canonname);
  v8 = (std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> *)operator new(0x18u);
  *(_OWORD *)v8 = 0;
  *((_QWORD *)v8 + 2) = 0;
  std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>>>::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>>>(
    (std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)&v14,
    v8,
    0);
  v9 = (_QWORD *)v14.m256i_i64[0];
  v14.m256i_i64[0] = 0;
  retstr->values_.__ptr_ = v9;
  v21 = retstr;
  retstr->values_.__cntrl_ = (std::__shared_weak_count *)v14.m256i_i64[1];
  do
  {
    if ( (v6->ai_family | 8) != 0xA )
      goto LABEL_14;
    dest[0] = 2u;
    DWORD2(dest[1]) = 0;
    ai_addrlen = v6->ai_addrlen;
    if ( ai_addrlen >= 0x81 )
    {
      v13 = boost::system::system_category();
      std::runtime_error::runtime_error((std::runtime_error *)&v14, (const char *)&uri_string);
      v14.m256i_i64[0] = (__int64)off_2875F00;
      v14.m256i_i32[4] = 22;
      v14.m256i_i64[3] = (__int64)v13;
      v15 = 0;
      v16 = 0;
      boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)&v14);
    }
    memcpy(dest, v6->ai_addr, ai_addrlen);
    *(_OWORD *)((char *)&v14.m256i_u64[1] + 4) = *(_OWORD *)((char *)dest + 12);
    *(_OWORD *)v14.m256i_i8 = dest[0];
    std::string::basic_string(&v15, v19);
    std::string::basic_string(&v17, service_name);
    v11 = v9[1];
    if ( v11 >= v9[2] )
    {
      std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>>::__push_back_slow_path<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>>(
        (std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> *)v9,
        (boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp> *)&v14);
      if ( (v17 & 1) == 0 )
        goto LABEL_12;
LABEL_11:
      operator delete(ptr);
      goto LABEL_12;
    }
    *(_OWORD *)(v11 + 12) = *(_OWORD *)((char *)&v14.m256i_u64[1] + 4);
    *(_OWORD *)v11 = *(_OWORD *)v14.m256i_i8;
    *(_QWORD *)(v11 + 48) = v16;
    *(_OWORD *)(v11 + 32) = v15;
    v15 = 0;
    v16 = 0;
    *(_QWORD *)(v11 + 72) = ptr;
    *(_OWORD *)(v11 + 56) = v17;
    v17 = 0;
    ptr = 0;
    v9[1] += 80LL;
    if ( (v17 & 1) != 0 )
      goto LABEL_11;
LABEL_12:
    if ( (v15 & 1) != 0 )
      operator delete(v16);
LABEL_14:
    v6 = v6->ai_next;
  }
  while ( v6 );
  if ( (v19[0] & 1) != 0 )
    operator delete(v20);
  return v21;
}


