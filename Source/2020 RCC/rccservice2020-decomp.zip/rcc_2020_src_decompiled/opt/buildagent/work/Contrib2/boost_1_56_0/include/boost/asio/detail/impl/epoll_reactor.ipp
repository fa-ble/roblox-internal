// Address: 0x25f7c70 | Name: _ZN5boost4asio6detail13epoll_reactorC2ERNS0_10io_serviceE
void __fastcall boost::asio::detail::epoll_reactor::epoll_reactor(
        boost::asio::detail::epoll_reactor *this,
        boost::asio::io_service *io_service)
{
  int v2; // ebp
  const boost::system::error_category *v3; // rax
  int v4; // ebp
  int v5; // eax
  int v6; // r12d
  int v7; // ebp
  const boost::system::error_category *v8; // rax
  int timer_fd; // edx
  const boost::system::error_category *v10; // r15
  const boost::system::error_category *v11; // r12
  struct epoll_event event; // [rsp+10h] [rbp-78h] BYREF
  int v13; // [rsp+20h] [rbp-68h]
  const boost::system::error_category *v14; // [rsp+28h] [rbp-60h]
  __int128 v15; // [rsp+30h] [rbp-58h]
  void *ptr; // [rsp+40h] [rbp-48h]
  __int64 buf[7]; // [rsp+50h] [rbp-38h] BYREF

  this->key_ = 0;
  this->owner_ = io_service;
  this->next_ = 0;
  this->_vptr$service = (int (**)(void))off_29C2AC8;
  this->io_service_ = io_service->impl_;
  v2 = pthread_mutex_init(&this->mutex_.mutex_, 0);
  v3 = boost::system::system_category();
  if ( v2 )
  {
    v10 = v3;
    std::runtime_error::runtime_error((std::runtime_error *)&event, "mutex");
    *(_QWORD *)&event.events = off_2875F00;
    v13 = v2;
    v14 = v10;
    v15 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)&event);
  }
  boost::asio::detail::eventfd_select_interrupter::open_descriptors(&this->interrupter_);
  this->epoll_fd_ = boost::asio::detail::epoll_reactor::do_epoll_create();
  v4 = timerfd_create(1, 0x80000);
  if ( v4 == -1 )
  {
    v4 = -1;
    if ( *__errno_location() == 22 )
    {
      v5 = timerfd_create(1, 0);
      if ( v5 != -1 )
      {
        v6 = v5;
        fcntl(v5, 2, 1);
        v4 = v6;
      }
    }
  }
  this->timer_fd_ = v4;
  this->timer_queues_.first_ = 0;
  this->shutdown_ = 0;
  v7 = pthread_mutex_init(&this->registered_descriptors_mutex_.mutex_, 0);
  v8 = boost::system::system_category();
  if ( v7 )
  {
    v11 = v8;
    std::runtime_error::runtime_error((std::runtime_error *)&event, "mutex");
    *(_QWORD *)&event.events = off_2875F00;
    v13 = v7;
    v14 = v11;
    v15 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)&event);
  }
  this->registered_descriptors_ = 0;
  event.events = -2147483639;
  event.data.u64 = (uint64_t)&this->interrupter_;
  epoll_ctl(this->epoll_fd_, 1, this->interrupter_.read_descriptor_, &event);
  buf[0] = 1;
  write(this->interrupter_.write_descriptor_, buf, 8u);
  timer_fd = this->timer_fd_;
  if ( timer_fd != -1 )
  {
    event.events = 9;
    event.data.u64 = (uint64_t)&this->timer_fd_;
    epoll_ctl(this->epoll_fd_, 1, timer_fd, &event);
  }
}


// Address: 0x25f7f90 | Name: _ZN5boost4asio6detail13epoll_reactor15do_epoll_createEv
int __cdecl boost::asio::detail::epoll_reactor::do_epoll_create()
{
  int v0; // ebx
  int *v1; // r14
  int v2; // ebp
  int v3; // eax
  const boost::system::error_category *v4; // rax
  const boost::system::error_category *v6; // r14
  _QWORD v7[2]; // [rsp+0h] [rbp-58h] BYREF
  int v8; // [rsp+10h] [rbp-48h]
  const boost::system::error_category *v9; // [rsp+18h] [rbp-40h]
  __int128 v10; // [rsp+20h] [rbp-38h]
  void *ptr; // [rsp+30h] [rbp-28h]

  v0 = epoll_create1(0x80000);
  if ( v0 == -1 )
  {
    v1 = __errno_location();
    v2 = *v1;
    if ( *v1 == 38 || v2 == 22 )
    {
      v3 = epoll_create(20000);
      if ( v3 != -1 )
      {
        v0 = v3;
        fcntl(v3, 2, 1);
        return v0;
      }
      v2 = *v1;
    }
    v4 = boost::system::system_category();
    v0 = -1;
    if ( v2 )
    {
      v6 = v4;
      std::runtime_error::runtime_error((std::runtime_error *)v7, "epoll");
      v7[0] = off_2875F00;
      v8 = v2;
      v9 = v6;
      v10 = 0;
      ptr = 0;
      boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v7);
    }
  }
  return v0;
}


// Address: 0x25f8110 | Name: _ZN5boost4asio6detail13epoll_reactorD2Ev
void __fastcall boost::asio::detail::epoll_reactor::~epoll_reactor(boost::asio::detail::epoll_reactor *this)
{
  int epoll_fd; // edi
  int timer_fd; // edi
  boost::asio::detail::epoll_reactor::descriptor_state *live_list; // rbx
  boost::asio::detail::epoll_reactor::descriptor_state *next; // r15
  boost::asio::detail::epoll_reactor::descriptor_state *free_list; // rbx
  boost::asio::detail::epoll_reactor::descriptor_state *v7; // r15
  int write_descriptor; // edi

  this->_vptr$service = (int (**)(void))off_29C2AC8;
  epoll_fd = this->epoll_fd_;
  if ( epoll_fd != -1 )
    close(epoll_fd);
  timer_fd = this->timer_fd_;
  if ( timer_fd != -1 )
    close(timer_fd);
  live_list = this->registered_descriptors_.live_list_;
  if ( live_list )
  {
    do
    {
      next = live_list->next_;
      boost::asio::detail::epoll_reactor::descriptor_state::~descriptor_state(live_list);
      operator delete(live_list);
      live_list = next;
    }
    while ( next );
  }
  free_list = this->registered_descriptors_.free_list_;
  if ( free_list )
  {
    do
    {
      v7 = free_list->next_;
      boost::asio::detail::epoll_reactor::descriptor_state::~descriptor_state(free_list);
      operator delete(free_list);
      free_list = v7;
    }
    while ( v7 );
  }
  pthread_mutex_destroy(&this->registered_descriptors_mutex_.mutex_);
  write_descriptor = this->interrupter_.write_descriptor_;
  if ( write_descriptor != -1 )
  {
    if ( write_descriptor == this->interrupter_.read_descriptor_ )
    {
LABEL_13:
      close(write_descriptor);
      goto LABEL_14;
    }
    close(write_descriptor);
  }
  write_descriptor = this->interrupter_.read_descriptor_;
  if ( write_descriptor != -1 )
    goto LABEL_13;
LABEL_14:
  pthread_mutex_destroy(&this->mutex_.mutex_);
}


// Address: 0x25f8220 | Name: _ZN5boost4asio6detail13epoll_reactorD0Ev
void __fastcall boost::asio::detail::epoll_reactor::~epoll_reactor(boost::asio::detail::epoll_reactor *this)
{
  boost::asio::detail::epoll_reactor::~epoll_reactor(this);
  operator delete(this);
}


// Address: 0x25f8240 | Name: _ZN5boost4asio6detail13epoll_reactor16shutdown_serviceEv
void __fastcall boost::asio::detail::epoll_reactor::shutdown_service(boost::asio::detail::epoll_reactor *this)
{
  boost::asio::detail::epoll_reactor::descriptor_state *live_list; // rax
  boost::asio::detail::reactor_op *back; // rdx
  boost::asio::detail::reactor_op *front; // rsi
  boost::asio::detail::reactor_op *v4; // rsi
  boost::asio::detail::reactor_op *v5; // rsi
  boost::asio::detail::epoll_reactor::descriptor_state *prev; // rsi
  boost::asio::detail::epoll_reactor::descriptor_state *next; // rsi
  boost::asio::detail::timer_queue_base *i; // rbx
  _QWORD *v9; // r15
  _QWORD *v10; // rbx
  void (__fastcall *v11)(_QWORD, _QWORD *, int *, _QWORD); // r12
  _QWORD *j; // rbx
  void (__fastcall *v13)(_QWORD, _QWORD *, int *, _QWORD); // r15
  __int128 v14; // [rsp+0h] [rbp-48h] BYREF
  int v15; // [rsp+18h] [rbp-30h] BYREF
  const boost::system::error_category *v16; // [rsp+20h] [rbp-28h]

  pthread_mutex_lock(&this->mutex_.mutex_);
  this->shutdown_ = 1;
  pthread_mutex_unlock(&this->mutex_.mutex_);
  v14 = 0;
  live_list = this->registered_descriptors_.live_list_;
  if ( live_list )
  {
    back = 0;
    do
    {
      front = live_list->op_queue_[0].front_;
      if ( front )
      {
        if ( !back )
          back = (boost::asio::detail::reactor_op *)&v14;
        back->next_ = front;
        back = live_list->op_queue_[0].back_;
        *((_QWORD *)&v14 + 1) = back;
        live_list->op_queue_[0] = 0;
      }
      v4 = live_list->op_queue_[1].front_;
      if ( v4 )
      {
        if ( !back )
          back = (boost::asio::detail::reactor_op *)&v14;
        back->next_ = v4;
        back = live_list->op_queue_[1].back_;
        *((_QWORD *)&v14 + 1) = back;
        live_list->op_queue_[1] = 0;
      }
      v5 = live_list->op_queue_[2].front_;
      if ( v5 )
      {
        if ( !back )
          back = (boost::asio::detail::reactor_op *)&v14;
        back->next_ = v5;
        back = live_list->op_queue_[2].back_;
        *((_QWORD *)&v14 + 1) = back;
        live_list->op_queue_[2] = 0;
      }
      live_list->shutdown_ = 1;
      if ( this->registered_descriptors_.live_list_ == live_list )
        this->registered_descriptors_.live_list_ = live_list->next_;
      prev = live_list->prev_;
      if ( prev )
        prev->next_ = live_list->next_;
      next = live_list->next_;
      if ( next )
        next->prev_ = live_list->prev_;
      live_list->next_ = this->registered_descriptors_.free_list_;
      live_list->prev_ = 0;
      this->registered_descriptors_.free_list_ = live_list;
      live_list = this->registered_descriptors_.live_list_;
    }
    while ( live_list );
  }
  for ( i = this->timer_queues_.first_; i; i = i->next_ )
    (*((void (__fastcall **)(boost::asio::detail::timer_queue_base *, __int128 *))i->_vptr$timer_queue_base + 6))(
      i,
      &v14);
  v9 = (_QWORD *)v14;
  if ( (_QWORD)v14 )
  {
    v14 = 0;
    do
    {
      v10 = v9;
      v9 = (_QWORD *)*v9;
      v11 = (void (__fastcall *)(_QWORD, _QWORD *, int *, _QWORD))v10[1];
      *v10 = 0;
      v15 = 0;
      v16 = boost::system::system_category();
      v11(0, v10, &v15, 0);
    }
    while ( v9 );
    for ( j = (_QWORD *)v14; (_QWORD)v14; j = (_QWORD *)v14 )
    {
      *(_QWORD *)&v14 = *j;
      if ( !(_QWORD)v14 )
        v14 = 0u;
      *j = 0;
      v13 = (void (__fastcall *)(_QWORD, _QWORD *, int *, _QWORD))j[1];
      v15 = 0;
      v16 = boost::system::system_category();
      v13(0, j, &v15, 0);
    }
  }
}


// Address: 0x25f84e0 | Name: _ZN5boost4asio6detail13epoll_reactor12fork_serviceENS0_10io_service10fork_eventE
void __fastcall boost::asio::detail::epoll_reactor::fork_service(
        boost::asio::detail::epoll_reactor *this,
        boost::asio::io_service::fork_event fork_ev)
{
  int epoll_fd; // edi
  int *p_timer_fd; // r12
  int timer_fd; // edi
  int v6; // ebx
  int v7; // eax
  int v8; // ebp
  boost::asio::detail::select_interrupter *p_interrupter; // r14
  int write_descriptor; // edi
  int v11; // edx
  boost::asio::detail::timer_queue_base *first; // rbx
  __int64 v13; // rcx
  int v14; // esi
  __syscall_slong_t v15; // rax
  boost::asio::detail::epoll_reactor::descriptor_state *i; // rbp
  int v17; // ebx
  const boost::system::error_category *v18; // rax
  __syscall_slong_t v19; // r13
  struct epoll_event v20; // [rsp+0h] [rbp-98h] BYREF
  struct itimerspec buf; // [rsp+10h] [rbp-88h] BYREF
  __int128 v22; // [rsp+30h] [rbp-68h]
  void *ptr; // [rsp+40h] [rbp-58h]
  struct itimerspec otmr; // [rsp+48h] [rbp-50h] BYREF

  if ( fork_ev != boost::asio::io_service::fork_event::fork_child )
    return;
  epoll_fd = this->epoll_fd_;
  if ( epoll_fd != -1 )
    close(epoll_fd);
  this->epoll_fd_ = -1;
  this->epoll_fd_ = boost::asio::detail::epoll_reactor::do_epoll_create();
  p_timer_fd = &this->timer_fd_;
  timer_fd = this->timer_fd_;
  if ( timer_fd != -1 )
    close(timer_fd);
  *p_timer_fd = -1;
  v6 = timerfd_create(1, 0x80000);
  if ( v6 == -1 )
  {
    v6 = -1;
    if ( *__errno_location() == 22 )
    {
      v7 = timerfd_create(1, 0);
      if ( v7 != -1 )
      {
        v8 = v7;
        fcntl(v7, 2, 1);
        v6 = v8;
      }
    }
  }
  this->timer_fd_ = v6;
  p_interrupter = &this->interrupter_;
  write_descriptor = this->interrupter_.write_descriptor_;
  if ( write_descriptor != -1 )
  {
    if ( write_descriptor == p_interrupter->read_descriptor_ )
    {
LABEL_14:
      close(write_descriptor);
      goto LABEL_15;
    }
    close(write_descriptor);
  }
  write_descriptor = p_interrupter->read_descriptor_;
  if ( p_interrupter->read_descriptor_ != -1 )
    goto LABEL_14;
LABEL_15:
  this->interrupter_ = (boost::asio::detail::select_interrupter)-1LL;
  boost::asio::detail::eventfd_select_interrupter::open_descriptors(&this->interrupter_);
  v20.events = -2147483639;
  v20.data.u64 = (uint64_t)&this->interrupter_;
  epoll_ctl(this->epoll_fd_, 1, this->interrupter_.read_descriptor_, &v20);
  buf.it_interval.tv_sec = 1;
  write(this->interrupter_.write_descriptor_, &buf, 8u);
  v11 = this->timer_fd_;
  if ( v11 != -1 )
  {
    v20.events = 9;
    v20.data.u64 = (uint64_t)&this->timer_fd_;
    epoll_ctl(this->epoll_fd_, 1, v11, &v20);
    if ( this->timer_fd_ != -1 )
    {
      buf.it_interval = 0;
      first = this->timer_queues_.first_;
      if ( first )
      {
        v13 = 300000000;
        do
        {
          v13 = (*((__int64 (__fastcall **)(boost::asio::detail::timer_queue_base *, __int64))first->_vptr$timer_queue_base
                 + 4))(
                  first,
                  v13);
          first = first->next_;
        }
        while ( first );
        buf.it_value.tv_sec = v13 / 1000000;
        if ( !v13 )
        {
          v14 = 1;
          v15 = 1;
LABEL_25:
          buf.it_value.tv_nsec = v15;
          timerfd_settime(*p_timer_fd, v14, &buf, &otmr);
          goto LABEL_26;
        }
      }
      else
      {
        buf.it_value.tv_sec = 300;
        v13 = 300000000;
      }
      v15 = 1000 * (v13 % 1000000);
      v14 = 0;
      goto LABEL_25;
    }
  }
  LODWORD(buf.it_interval.tv_sec) = -2147483639;
  *(__time_t *)((char *)&buf.it_interval.tv_sec + 4) = (__time_t)&this->interrupter_;
  epoll_ctl(this->epoll_fd_, 3, this->interrupter_.read_descriptor_, (struct epoll_event *)&buf);
LABEL_26:
  pthread_mutex_lock(&this->registered_descriptors_mutex_.mutex_);
  for ( i = this->registered_descriptors_.live_list_; i; i = i->next_ )
  {
    v20.events = i->registered_events_;
    v20.data.u64 = (uint64_t)i;
    if ( epoll_ctl(this->epoll_fd_, 1, i->descriptor_, &v20) )
    {
      v17 = *__errno_location();
      v18 = boost::system::system_category();
      if ( v17 )
      {
        v19 = (__syscall_slong_t)v18;
        std::runtime_error::runtime_error((std::runtime_error *)&buf, "epoll re-registration");
        buf.it_interval.tv_sec = (__time_t)off_2875F00;
        LODWORD(buf.it_value.tv_sec) = v17;
        buf.it_value.tv_nsec = v19;
        v22 = 0;
        ptr = 0;
        boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)&buf);
      }
    }
  }
  pthread_mutex_unlock(&this->registered_descriptors_mutex_.mutex_);
}


// Address: 0x25f8c90 | Name: _ZN5boost4asio6detail13epoll_reactor21deregister_descriptorEiRPNS2_16descriptor_stateEb
void __fastcall boost::asio::detail::epoll_reactor::deregister_descriptor(
        boost::asio::detail::epoll_reactor *this,
        boost::asio::detail::socket_type descriptor,
        boost::asio::detail::epoll_reactor::per_descriptor_data *descriptor_data,
        bool closing)
{
  boost::asio::detail::mutex *p_mutex; // r15
  boost::asio::detail::epoll_reactor::per_descriptor_data v7; // rax
  boost::asio::detail::reactor_op *i; // rbp
  const boost::system::error_category *v9; // rax
  boost::asio::detail::epoll_reactor::per_descriptor_data v10; // rcx
  boost::asio::detail::reactor_op *front; // rax
  boost::asio::detail::task_io_service_operation *next; // rdx
  boost::asio::detail::task_io_service_operation **p_back; // rax
  boost::asio::detail::reactor_op *j; // rbp
  const boost::system::error_category *v15; // rax
  boost::asio::detail::epoll_reactor::per_descriptor_data v16; // rcx
  boost::asio::detail::reactor_op *v17; // rax
  boost::asio::detail::task_io_service_operation *v18; // rdx
  boost::asio::detail::task_io_service_operation **v19; // rax
  boost::asio::detail::reactor_op *k; // rbp
  const boost::system::error_category *v21; // rax
  boost::asio::detail::epoll_reactor::per_descriptor_data v22; // rcx
  boost::asio::detail::reactor_op *v23; // rax
  boost::asio::detail::task_io_service_operation *v24; // rdx
  boost::asio::detail::task_io_service_operation **v25; // rax
  boost::asio::detail::epoll_reactor::per_descriptor_data v26; // rbp
  boost::asio::detail::epoll_reactor::descriptor_state *prev; // rax
  boost::asio::detail::epoll_reactor::descriptor_state *v28; // rax
  boost::asio::detail::task_io_service_operation *m; // rbx
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // rbp
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> v31; // [rsp+0h] [rbp-58h] BYREF
  __int64 event; // [rsp+18h] [rbp-40h] BYREF
  const boost::system::error_category *event_8; // [rsp+20h] [rbp-38h]

  if ( *descriptor_data )
  {
    p_mutex = &(*descriptor_data)->mutex_;
    pthread_mutex_lock(&p_mutex->mutex_);
    v7 = *descriptor_data;
    if ( (*descriptor_data)->shutdown_ )
    {
      pthread_mutex_unlock(&p_mutex->mutex_);
    }
    else
    {
      if ( !closing )
      {
        LODWORD(event_8) = 0;
        event = 0;
        epoll_ctl(this->epoll_fd_, 2, descriptor, (struct epoll_event *)&event);
        v7 = *descriptor_data;
      }
      v31 = 0;
      for ( i = v7->op_queue_[0].front_; i; i = (*descriptor_data)->op_queue_[0].front_ )
      {
        v9 = boost::system::system_category();
        i->ec_.m_val = 125;
        i->ec_.m_cat = v9;
        v10 = *descriptor_data;
        front = (*descriptor_data)->op_queue_[0].front_;
        if ( front )
        {
          next = front->next_;
          v10->op_queue_[0].front_ = (boost::asio::detail::reactor_op *)front->next_;
          if ( !next )
            v10->op_queue_[0].back_ = 0;
          front->next_ = 0;
        }
        i->next_ = 0;
        if ( v31.back_ )
        {
          v31.back_->next_ = i;
          p_back = &v31.back_;
        }
        else
        {
          v31.back_ = i;
          p_back = (boost::asio::detail::task_io_service_operation **)&v31;
        }
        *p_back = i;
        v7 = *descriptor_data;
      }
      for ( j = v7->op_queue_[1].front_; j; j = (*descriptor_data)->op_queue_[1].front_ )
      {
        v15 = boost::system::system_category();
        j->ec_.m_val = 125;
        j->ec_.m_cat = v15;
        v16 = *descriptor_data;
        v17 = (*descriptor_data)->op_queue_[1].front_;
        if ( v17 )
        {
          v18 = v17->next_;
          v16->op_queue_[1].front_ = (boost::asio::detail::reactor_op *)v17->next_;
          if ( !v18 )
            v16->op_queue_[1].back_ = 0;
          v17->next_ = 0;
        }
        j->next_ = 0;
        if ( v31.back_ )
        {
          v31.back_->next_ = j;
          v19 = &v31.back_;
        }
        else
        {
          v31.back_ = j;
          v19 = (boost::asio::detail::task_io_service_operation **)&v31;
        }
        *v19 = j;
        v7 = *descriptor_data;
      }
      for ( k = v7->op_queue_[2].front_; k; k = (*descriptor_data)->op_queue_[2].front_ )
      {
        v21 = boost::system::system_category();
        k->ec_.m_val = 125;
        k->ec_.m_cat = v21;
        v22 = *descriptor_data;
        v23 = (*descriptor_data)->op_queue_[2].front_;
        if ( v23 )
        {
          v24 = v23->next_;
          v22->op_queue_[2].front_ = (boost::asio::detail::reactor_op *)v23->next_;
          if ( !v24 )
            v22->op_queue_[2].back_ = 0;
          v23->next_ = 0;
        }
        k->next_ = 0;
        if ( v31.back_ )
        {
          v31.back_->next_ = k;
          v25 = &v31.back_;
        }
        else
        {
          v31.back_ = k;
          v25 = (boost::asio::detail::task_io_service_operation **)&v31;
        }
        *v25 = k;
        v7 = *descriptor_data;
      }
      v7->descriptor_ = -1;
      v7->shutdown_ = 1;
      pthread_mutex_unlock(&p_mutex->mutex_);
      v26 = *descriptor_data;
      pthread_mutex_lock(&this->registered_descriptors_mutex_.mutex_);
      if ( this->registered_descriptors_.live_list_ == v26 )
        this->registered_descriptors_.live_list_ = v26->next_;
      prev = v26->prev_;
      if ( prev )
        prev->next_ = v26->next_;
      v28 = v26->next_;
      if ( v28 )
        v28->prev_ = v26->prev_;
      v26->next_ = this->registered_descriptors_.free_list_;
      v26->prev_ = 0;
      this->registered_descriptors_.free_list_ = v26;
      pthread_mutex_unlock(&this->registered_descriptors_mutex_.mutex_);
      *descriptor_data = 0;
      boost::asio::detail::task_io_service::post_deferred_completions(this->io_service_, &v31);
      for ( m = v31.front_; v31.front_; m = v31.front_ )
      {
        v31.front_ = m->next_;
        if ( !v31.front_ )
          v31 = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation>)0LL;
        m->next_ = 0;
        func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))m->func_;
        LODWORD(event) = 0;
        event_8 = boost::system::system_category();
        func(0, m, &event, 0);
      }
    }
  }
}


// Address: 0x2608bf0 | Name: _ZN5boost4asio6detail13epoll_reactor10cancel_opsEiRPNS2_16descriptor_stateE
void __fastcall boost::asio::detail::epoll_reactor::cancel_ops(
        boost::asio::detail::epoll_reactor *this,
        boost::asio::detail::socket_type a2,
        boost::asio::detail::epoll_reactor::per_descriptor_data *descriptor_data)
{
  boost::asio::detail::epoll_reactor::per_descriptor_data v4; // rdi
  boost::asio::detail::epoll_reactor::per_descriptor_data v6; // rax
  boost::asio::detail::reactor_op *front; // rcx
  _QWORD *p_next; // rbx
  boost::asio::detail::reactor_op *v9; // r15
  const boost::system::error_category *v10; // rax
  boost::asio::detail::epoll_reactor::per_descriptor_data v11; // rcx
  boost::asio::detail::reactor_op *v12; // rax
  boost::asio::detail::task_io_service_operation *next; // rdx
  boost::asio::detail::task_io_service_operation **p_back; // rax
  boost::asio::detail::reactor_op *v15; // rcx
  boost::asio::detail::reactor_op *v16; // rbx
  const boost::system::error_category *v17; // rax
  boost::asio::detail::epoll_reactor::per_descriptor_data v18; // rcx
  boost::asio::detail::reactor_op *v19; // rax
  boost::asio::detail::task_io_service_operation *v20; // rdx
  boost::asio::detail::task_io_service_operation **v21; // rax
  pthread_mutex_t *v22; // rbx
  boost::asio::detail::reactor_op *i; // rbp
  const boost::system::error_category *v24; // rax
  boost::asio::detail::epoll_reactor::per_descriptor_data v25; // rcx
  boost::asio::detail::reactor_op *v26; // rax
  boost::asio::detail::task_io_service_operation *v27; // rdx
  boost::asio::detail::task_io_service_operation **v28; // rax
  boost::asio::detail::task_io_service_operation *j; // rbx
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // rbp
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> v31; // [rsp+0h] [rbp-68h] BYREF
  pthread_mutex_t *mutex; // [rsp+18h] [rbp-50h]
  int v33; // [rsp+20h] [rbp-48h] BYREF
  const boost::system::error_category *v34; // [rsp+28h] [rbp-40h]
  boost::asio::detail::epoll_reactor *v35; // [rsp+30h] [rbp-38h]

  v4 = *descriptor_data;
  if ( *descriptor_data )
  {
    mutex = &v4->mutex_.mutex_;
    pthread_mutex_lock(&v4->mutex_.mutex_);
    v31 = 0;
    v6 = *descriptor_data;
    front = (*descriptor_data)->op_queue_[0].front_;
    if ( front )
    {
      p_next = 0;
      do
      {
        v9 = front;
        v10 = boost::system::system_category();
        v9->ec_.m_val = 125;
        v9->ec_.m_cat = v10;
        v11 = *descriptor_data;
        v12 = (*descriptor_data)->op_queue_[0].front_;
        if ( v12 )
        {
          next = v12->next_;
          v11->op_queue_[0].front_ = (boost::asio::detail::reactor_op *)v12->next_;
          if ( !next )
            v11->op_queue_[0].back_ = 0;
          v12->next_ = 0;
        }
        v9->next_ = 0;
        if ( p_next )
        {
          *p_next = v9;
          p_back = &v31.back_;
        }
        else
        {
          v31.back_ = v9;
          p_back = (boost::asio::detail::task_io_service_operation **)&v31;
        }
        *p_back = v9;
        v6 = *descriptor_data;
        front = (*descriptor_data)->op_queue_[0].front_;
        p_next = &v9->next_;
      }
      while ( front );
    }
    else
    {
      v9 = 0;
    }
    v15 = v6->op_queue_[1].front_;
    v35 = this;
    if ( v15 )
    {
      do
      {
        v16 = v15;
        v17 = boost::system::system_category();
        v16->ec_.m_val = 125;
        v16->ec_.m_cat = v17;
        v18 = *descriptor_data;
        v19 = (*descriptor_data)->op_queue_[1].front_;
        if ( v19 )
        {
          v20 = v19->next_;
          v18->op_queue_[1].front_ = (boost::asio::detail::reactor_op *)v19->next_;
          if ( !v20 )
            v18->op_queue_[1].back_ = 0;
          v19->next_ = 0;
        }
        v16->next_ = 0;
        if ( v9 )
        {
          v9->next_ = v16;
          v21 = &v31.back_;
        }
        else
        {
          v31.back_ = v16;
          v21 = (boost::asio::detail::task_io_service_operation **)&v31;
        }
        *v21 = v16;
        v6 = *descriptor_data;
        v15 = (*descriptor_data)->op_queue_[1].front_;
        v9 = v16;
      }
      while ( v15 );
      v9 = v16;
    }
    v22 = mutex;
    for ( i = v6->op_queue_[2].front_; i; i = (*descriptor_data)->op_queue_[2].front_ )
    {
      v24 = boost::system::system_category();
      i->ec_.m_val = 125;
      i->ec_.m_cat = v24;
      v25 = *descriptor_data;
      v26 = (*descriptor_data)->op_queue_[2].front_;
      if ( v26 )
      {
        v27 = v26->next_;
        v25->op_queue_[2].front_ = (boost::asio::detail::reactor_op *)v26->next_;
        if ( !v27 )
          v25->op_queue_[2].back_ = 0;
        v26->next_ = 0;
      }
      i->next_ = 0;
      if ( v9 )
      {
        v9->next_ = i;
        v28 = &v31.back_;
      }
      else
      {
        v31.back_ = i;
        v28 = (boost::asio::detail::task_io_service_operation **)&v31;
      }
      *v28 = i;
      v9 = i;
    }
    pthread_mutex_unlock(v22);
    boost::asio::detail::task_io_service::post_deferred_completions(v35->io_service_, &v31);
    for ( j = v31.front_; v31.front_; j = v31.front_ )
    {
      v31.front_ = j->next_;
      if ( !v31.front_ )
        v31 = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation>)0LL;
      j->next_ = 0;
      func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))j->func_;
      v33 = 0;
      v34 = boost::system::system_category();
      func(0, j, &v33, 0);
    }
  }
}


// Address: 0x260a620 | Name: _ZN5boost4asio6detail13epoll_reactor8start_opEiiRPNS2_16descriptor_stateEPNS1_10reactor_opEbb
void __fastcall boost::asio::detail::epoll_reactor::start_op(
        boost::asio::detail::epoll_reactor *this,
        int op_type,
        boost::asio::detail::socket_type descriptor,
        boost::asio::detail::epoll_reactor::per_descriptor_data *descriptor_data,
        boost::asio::detail::reactor_op *op,
        bool is_continuation,
        char a7)
{
  boost::asio::detail::mutex *p_mutex; // r15
  epoll_data_t v12; // rax
  const boost::system::error_category *v13; // rax
  __int64 v14; // rsi
  __int64 v15; // rbp
  boost::asio::detail::epoll_reactor *v16; // rdx
  epoll_data_t v17; // rax
  uint32_t registered_events; // ecx
  int v19; // ebp
  const boost::system::error_category *v20; // rax
  epoll_data_t v21; // rcx
  _QWORD **v22; // rax
  struct epoll_event event; // [rsp+18h] [rbp-40h] BYREF

  if ( !*descriptor_data )
  {
    v13 = boost::system::system_category();
    op->ec_.m_val = 9;
    op->ec_.m_cat = v13;
    boost::asio::detail::task_io_service::post_immediate_completion(this->io_service_, op, is_continuation);
    return;
  }
  p_mutex = &(*descriptor_data)->mutex_;
  pthread_mutex_lock(&p_mutex->mutex_);
  v12.u64 = (uint64_t)*descriptor_data;
  if ( !(*descriptor_data)->shutdown_ )
  {
    v14 = 16LL * op_type;
    if ( *(_QWORD *)(v12.u64 + v14 + 96) )
    {
LABEL_19:
      v21.u64 = (uint64_t)*descriptor_data;
      op->next_ = 0;
      v22 = (_QWORD **)(v21.u64 + v14 + 104);
      if ( *v22 )
      {
        **v22 = op;
      }
      else
      {
        *v22 = &op->next_;
        v22 = (_QWORD **)(v21.u64 + v14 + 96);
      }
      *v22 = &op->next_;
      _InterlockedAdd64(&this->io_service_->outstanding_work_.__a_, 1u);
      goto LABEL_23;
    }
    if ( a7 )
    {
      v15 = 16LL * op_type;
      v16 = this;
      if ( op_type || !*(_QWORD *)(v12.u64 + 128) )
      {
        if ( ((unsigned __int8 (__fastcall *)(boost::asio::detail::reactor_op *, __int64, boost::asio::detail::epoll_reactor *))op->perform_func_)(
               op,
               v14,
               this) )
        {
          pthread_mutex_unlock(&p_mutex->mutex_);
          boost::asio::detail::task_io_service::post_immediate_completion(this->io_service_, op, is_continuation);
          return;
        }
        if ( op_type != 1 )
          goto LABEL_19;
        v17.u64 = (uint64_t)*descriptor_data;
        registered_events = (*descriptor_data)->registered_events_;
        if ( (registered_events & 4) != 0 )
          goto LABEL_19;
        event.events = registered_events | 4;
        event.data = v17;
        if ( epoll_ctl(this->epoll_fd_, 3, descriptor, &event) )
        {
          v19 = *__errno_location();
          v20 = boost::system::system_category();
          op->ec_.m_val = v19;
          op->ec_.m_cat = v20;
          boost::asio::detail::task_io_service::post_immediate_completion(this->io_service_, op, is_continuation);
          goto LABEL_23;
        }
        (*descriptor_data)->registered_events_ |= event.events;
        goto LABEL_18;
      }
    }
    else
    {
      v15 = 16LL * op_type;
      v16 = this;
      if ( op_type == 1 )
        *(_BYTE *)(v12.u64 + 92) |= 4u;
    }
    event.events = *(_DWORD *)(v12.u64 + 92);
    event.data = v12;
    epoll_ctl(v16->epoll_fd_, 3, descriptor, &event);
LABEL_18:
    v14 = v15;
    goto LABEL_19;
  }
  boost::asio::detail::task_io_service::post_immediate_completion(this->io_service_, op, is_continuation);
LABEL_23:
  pthread_mutex_unlock(&p_mutex->mutex_);
}


// Address: 0x261f370 | Name: _ZN5boost4asio6detail13epoll_reactor3runEbRNS1_8op_queueINS1_25task_io_service_operationEEE
void __fastcall boost::asio::detail::epoll_reactor::run(
        boost::asio::detail::epoll_reactor *this,
        bool block,
        boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *ops)
{
  Elf64_Rela *v5; // r13
  boost::asio::detail::timer_queue_base *first; // rbx
  int *p_timer_fd; // r15
  __int64 v8; // rax
  boost::asio::detail::task_io_service_operation *back; // rdx
  int timer_fd; // ebp
  int v11; // ecx
  boost::asio::detail::select_interrupter *p_interrupter; // rsi
  epoll_data_t *p_data; // rdi
  boost::asio::detail::task_io_service_operation *u64; // rbx
  boost::asio::detail::timer_queue_base *i; // rbx
  boost::asio::detail::timer_queue_base *v16; // rbx
  __int64 v17; // rcx
  int v18; // esi
  __syscall_slong_t v19; // rax
  struct itimerspec v20; // [rsp+0h] [rbp-678h] BYREF
  struct itimerspec otmr; // [rsp+20h] [rbp-658h] BYREF
  struct epoll_event v22; // [rsp+40h] [rbp-638h] BYREF

  if ( this->timer_fd_ == -1 )
  {
    pthread_mutex_lock(&this->mutex_.mutex_);
    LODWORD(v5) = 0;
    if ( block )
    {
      first = this->timer_queues_.first_;
      if ( first )
      {
        v5 = &stru_493E0;
        do
        {
          v5 = (Elf64_Rela *)(*((__int64 (__fastcall **)(boost::asio::detail::timer_queue_base *, Elf64_Rela *))first->_vptr$timer_queue_base
                              + 3))(
                               first,
                               v5);
          first = first->next_;
        }
        while ( first );
      }
      else
      {
        v5 = &stru_493E0;
      }
    }
    pthread_mutex_unlock(&this->mutex_.mutex_);
  }
  else
  {
    LODWORD(v5) = -block;
  }
  p_timer_fd = &this->timer_fd_;
  LODWORD(v8) = epoll_wait(this->epoll_fd_, &v22, 128, (int)v5);
  timer_fd = this->timer_fd_;
  LOBYTE(v11) = timer_fd == -1;
  if ( (int)v8 > 0 )
  {
    p_interrupter = &this->interrupter_;
    v8 = (unsigned int)v8;
    p_data = &v22.data;
    do
    {
      u64 = (boost::asio::detail::task_io_service_operation *)p_data->u64;
      if ( p_data->ptr == p_interrupter )
      {
        LOBYTE(back) = 1;
        if ( timer_fd != -1 )
          LODWORD(back) = v11;
        v11 = (int)back;
      }
      else if ( u64 == (boost::asio::detail::task_io_service_operation *)p_timer_fd )
      {
        LOBYTE(v11) = 1;
      }
      else
      {
        u64->task_result_ = HIDWORD(p_data[-1].u64);
        u64->next_ = 0;
        back = ops->back_;
        if ( back )
        {
          back->next_ = u64;
          ops->back_ = u64;
        }
        else
        {
          ops->back_ = u64;
          ops->front_ = u64;
        }
      }
      p_data = (epoll_data_t *)((char *)p_data + 12);
      --v8;
    }
    while ( v8 );
  }
  if ( (v11 & 1) != 0 )
  {
    pthread_mutex_lock(&this->mutex_.mutex_);
    for ( i = this->timer_queues_.first_; i; i = i->next_ )
      (*((void (__fastcall **)(boost::asio::detail::timer_queue_base *, boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *))i->_vptr$timer_queue_base
       + 5))(
        i,
        ops);
    if ( *p_timer_fd == -1 )
      goto LABEL_36;
    v20.it_interval = 0;
    v16 = this->timer_queues_.first_;
    if ( v16 )
    {
      v17 = 300000000;
      do
      {
        v17 = (*((__int64 (__fastcall **)(boost::asio::detail::timer_queue_base *, __int64))v16->_vptr$timer_queue_base
               + 4))(
                v16,
                v17);
        v16 = v16->next_;
      }
      while ( v16 );
      v20.it_value.tv_sec = v17 / 1000000;
      if ( !v17 )
      {
        v18 = 1;
        v19 = 1;
LABEL_35:
        v20.it_value.tv_nsec = v19;
        timerfd_settime(*p_timer_fd, v18, &v20, &otmr);
LABEL_36:
        pthread_mutex_unlock(&this->mutex_.mutex_);
        return;
      }
    }
    else
    {
      v20.it_value.tv_sec = 300;
      v17 = 300000000;
    }
    v19 = 1000 * (v17 % 1000000);
    v18 = 0;
    goto LABEL_35;
  }
}


// Address: 0x2625050 | Name: _ZN5boost4asio6detail13epoll_reactor25allocate_descriptor_stateEv
boost::asio::detail::epoll_reactor::descriptor_state *__fastcall boost::asio::detail::epoll_reactor::allocate_descriptor_state(
        boost::asio::detail::epoll_reactor *this)
{
  boost::asio::detail::epoll_reactor::descriptor_state *free_list; // rbx
  boost::asio::detail::epoll_reactor::descriptor_state **p_next; // rcx
  int v3; // ebp
  const boost::system::error_category *v4; // rax
  boost::asio::detail::epoll_reactor::descriptor_state *live_list; // rax
  const boost::system::error_category *v7; // r12
  _QWORD v8[2]; // [rsp+0h] [rbp-68h] BYREF
  int v9; // [rsp+10h] [rbp-58h]
  const boost::system::error_category *v10; // [rsp+18h] [rbp-50h]
  __int128 v11; // [rsp+20h] [rbp-48h]
  void *ptr; // [rsp+30h] [rbp-38h]

  pthread_mutex_lock(&this->registered_descriptors_mutex_.mutex_);
  free_list = this->registered_descriptors_.free_list_;
  if ( free_list )
  {
    p_next = &free_list->next_;
    this->registered_descriptors_.free_list_ = free_list->next_;
  }
  else
  {
    free_list = (boost::asio::detail::epoll_reactor::descriptor_state *)operator new(0x98u);
    free_list->boost::asio::detail::operation::next_ = 0;
    free_list->func_ = boost::asio::detail::epoll_reactor::descriptor_state::do_complete;
    free_list->task_result_ = 0;
    v3 = pthread_mutex_init(&free_list->mutex_.mutex_, 0);
    v4 = boost::system::system_category();
    if ( v3 )
    {
      v7 = v4;
      std::runtime_error::runtime_error((std::runtime_error *)v8, "mutex");
      v8[0] = off_2875F00;
      v9 = v3;
      v10 = v7;
      v11 = 0;
      ptr = 0;
      boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v8);
    }
    free_list->op_queue_[2] = 0;
    free_list->op_queue_[1] = 0;
    free_list->op_queue_[0] = 0;
    p_next = &free_list->next_;
  }
  *p_next = this->registered_descriptors_.live_list_;
  free_list->prev_ = 0;
  live_list = this->registered_descriptors_.live_list_;
  if ( live_list )
    live_list->prev_ = free_list;
  this->registered_descriptors_.live_list_ = free_list;
  pthread_mutex_unlock(&this->registered_descriptors_mutex_.mutex_);
  return free_list;
}


// Address: 0x26251b0 | Name: _ZN5boost4asio6detail13epoll_reactor16descriptor_state11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationERKNS_6system10error_codeEm
void __fastcall boost::asio::detail::epoll_reactor::descriptor_state::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *ec,
        size_t bytes_transferred)
{
  boost::asio::detail::operation *v5; // rax

  if ( owner )
  {
    v5 = boost::asio::detail::epoll_reactor::descriptor_state::perform_io(
           (boost::asio::detail::epoll_reactor::descriptor_state *)base,
           bytes_transferred);
    if ( v5 )
      v5->func_(owner, v5, ec, 0);
  }
}


// Address: 0x26251f0 | Name: _ZN5boost4asio6detail13epoll_reactor16descriptor_state10perform_ioEj
boost::asio::detail::operation *__fastcall boost::asio::detail::epoll_reactor::descriptor_state::perform_io(
        boost::asio::detail::epoll_reactor::descriptor_state *this,
        uint32_t events)
{
  boost::asio::detail::reactor_op *front; // rbp
  boost::asio::detail::reactor_op **v3; // rcx
  boost::asio::detail::reactor_op *v4; // rax
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *p_back; // rcx
  boost::asio::detail::reactor_op *v6; // rbp
  boost::asio::detail::reactor_op **v7; // rcx
  boost::asio::detail::reactor_op *v8; // rax
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *p_ops; // rcx
  boost::asio::detail::reactor_op *v10; // rbp
  boost::asio::detail::reactor_op **v11; // rcx
  boost::asio::detail::reactor_op *v12; // rax
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *v13; // rcx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  boost::asio::detail::epoll_reactor::perform_io_cleanup_on_block_exit v16; // [rsp+8h] [rbp-50h] BYREF

  pthread_mutex_lock(&this->mutex_.mutex_);
  v16.reactor_ = this->reactor_;
  memset(&v16.ops_, 0, 24);
  if ( (events & 0x1A) != 0 )
  {
    front = this->op_queue_[2].front_;
    if ( front )
    {
      do
      {
        if ( !front->perform_func_(front) )
          break;
        v3 = (boost::asio::detail::reactor_op **)this->op_queue_[2].front_;
        if ( v3 )
        {
          v4 = *v3;
          this->op_queue_[2].front_ = *v3;
          if ( !v4 )
            this->op_queue_[2].back_ = 0;
          *v3 = 0;
        }
        else
        {
          v4 = 0;
        }
        front->next_ = 0;
        if ( v16.ops_.back_ )
        {
          v16.ops_.back_->next_ = front;
          p_back = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)&v16.ops_.back_;
        }
        else
        {
          v16.ops_.back_ = front;
          p_back = &v16.ops_;
        }
        p_back->front_ = front;
        front = v4;
      }
      while ( v4 );
    }
  }
  if ( (events & 0x1C) != 0 )
  {
    v6 = this->op_queue_[1].front_;
    if ( v6 )
    {
      do
      {
        if ( !v6->perform_func_(v6) )
          break;
        v7 = (boost::asio::detail::reactor_op **)this->op_queue_[1].front_;
        if ( v7 )
        {
          v8 = *v7;
          this->op_queue_[1].front_ = *v7;
          if ( !v8 )
            this->op_queue_[1].back_ = 0;
          *v7 = 0;
        }
        else
        {
          v8 = 0;
        }
        v6->next_ = 0;
        if ( v16.ops_.back_ )
        {
          v16.ops_.back_->next_ = v6;
          p_ops = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)&v16.ops_.back_;
        }
        else
        {
          v16.ops_.back_ = v6;
          p_ops = &v16.ops_;
        }
        p_ops->front_ = v6;
        v6 = v8;
      }
      while ( v8 );
    }
  }
  if ( (events & 0x19) != 0 )
  {
    v10 = this->op_queue_[0].front_;
    if ( v10 )
    {
      do
      {
        if ( !v10->perform_func_(v10) )
          break;
        v11 = (boost::asio::detail::reactor_op **)this->op_queue_[0].front_;
        if ( v11 )
        {
          v12 = *v11;
          this->op_queue_[0].front_ = *v11;
          if ( !v12 )
            this->op_queue_[0].back_ = 0;
          *v11 = 0;
        }
        else
        {
          v12 = 0;
        }
        v10->next_ = 0;
        if ( v16.ops_.back_ )
        {
          v16.ops_.back_->next_ = v10;
          v13 = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)&v16.ops_.back_;
        }
        else
        {
          v16.ops_.back_ = v10;
          v13 = &v16.ops_;
        }
        v13->front_ = v10;
        v10 = v12;
      }
      while ( v12 );
    }
  }
  v14 = v16.ops_.front_;
  v16.first_op_ = v16.ops_.front_;
  if ( v16.ops_.front_ )
  {
    v16.ops_.front_ = v16.ops_.front_->next_;
    if ( !v16.ops_.front_ )
      v16.ops_.back_ = 0;
    v14->next_ = 0;
  }
  pthread_mutex_unlock(&this->mutex_.mutex_);
  boost::asio::detail::epoll_reactor::perform_io_cleanup_on_block_exit::~perform_io_cleanup_on_block_exit(&v16);
  return v14;
}


// Address: 0x2625440 | Name: _ZN5boost4asio6detail13epoll_reactor32perform_io_cleanup_on_block_exitD2Ev
void __fastcall boost::asio::detail::epoll_reactor::perform_io_cleanup_on_block_exit::~perform_io_cleanup_on_block_exit(
        boost::asio::detail::epoll_reactor::perform_io_cleanup_on_block_exit *this)
{
  boost::asio::detail::task_io_service_operation *i; // rbx
  boost::asio::detail::task_io_service_operation *next; // rax
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  int v4; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v5; // [rsp+10h] [rbp-28h]

  if ( this->first_op_ )
  {
    if ( this->ops_.front_ )
      boost::asio::detail::task_io_service::post_deferred_completions(this->reactor_->io_service_, &this->ops_);
  }
  else
  {
    _InterlockedAdd64(&this->reactor_->io_service_->outstanding_work_.__a_, 1u);
  }
  for ( i = this->ops_.front_; i; i = this->ops_.front_ )
  {
    next = i->next_;
    this->ops_.front_ = i->next_;
    if ( !next )
      this->ops_.back_ = 0;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v4 = 0;
    v5 = boost::system::system_category();
    func(0, i, &v4, 0);
  }
}


