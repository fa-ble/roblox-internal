// Address: 0x1877be0 | Name: _ZN5boost31circular_buffer_space_optimizedIN3RBX18StandardOutMessageENSt3__19allocatorIS2_EEE13rset_capacityERKNS_10cb_details16capacity_controlImEE
void __fastcall boost::circular_buffer_space_optimized<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage>>::rset_capacity(
        boost::circular_buffer_space_optimized<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> > *this,
        const boost::circular_buffer_space_optimized<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::capacity_type *capacity_ctrl)
{
  unsigned __int64 v2; // r8
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::size_type m_size; // rax
  bool v4; // cc
  __int64 v5; // rax
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer m_first; // rcx
  RBX::StandardOutMessage *v7; // rcx
  RBX::StandardOutMessage *v8; // rdx
  __int64 v9; // rax
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer m_last; // rdx
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::capacity_type m_min_capacity; // rsi
  unsigned __int64 v12; // rbx
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::size_type v13; // rcx
  unsigned __int64 m_capacity; // rbx
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::iterator last; // [rsp+8h] [rbp-40h] BYREF
  _QWORD first[2]; // [rsp+18h] [rbp-30h] BYREF
  char v17; // [rsp+28h] [rbp-20h] BYREF

  this->m_capacity_ctrl = *capacity_ctrl;
  m_size = this->m_size;
  v4 = m_size <= capacity_ctrl->m_capacity;
  v5 = m_size - capacity_ctrl->m_capacity;
  if ( !v4 )
  {
    m_first = this->m_first;
    first[0] = this;
    first[1] = m_first;
    if ( v5 <= 0 )
    {
      v8 = m_first;
      if ( v5 < 0 )
      {
        v9 = -v5;
        m_last = m_first;
        if ( !m_first )
        {
          m_last = this->m_last;
          m_first = m_last;
        }
        if ( (m_last - this->m_buff) >> 6 < v9 )
          v9 -= (this->m_end - this->m_buff) >> 6;
        v8 = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)((char *)m_first - 64 * v9);
      }
    }
    else
    {
      if ( (this->m_end - m_first) >> 6 <= v5 )
        v5 -= (this->m_end - this->m_buff) >> 6;
      v7 = (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::pointer)((char *)m_first + 64 * v5);
      v8 = 0;
      if ( v7 != this->m_last )
        v8 = v7;
    }
    last.m_buff = this;
    last.m_it = v8;
    boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage>>::rerase(
      (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> > *)&v17,
      (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::iterator)__PAIR128__(first, (unsigned __int64)this),
      (boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage> >::iterator)__PAIR128__(v2, &last));
  }
  m_min_capacity = this->m_capacity_ctrl.m_min_capacity;
  v12 = (this->m_end - this->m_buff) >> 6;
  if ( m_min_capacity <= v12 )
  {
    v13 = this->m_size;
    while ( v12 / 3 >= v13 )
    {
      v12 >>= 1;
      if ( v12 <= m_min_capacity )
      {
        v12 = this->m_capacity_ctrl.m_min_capacity;
        break;
      }
    }
    m_capacity = v12 << (v13 + v12 / 5 >= v12);
    if ( m_capacity > this->m_capacity_ctrl.m_capacity )
      m_capacity = this->m_capacity_ctrl.m_capacity;
    m_min_capacity = m_capacity;
  }
  boost::circular_buffer<RBX::StandardOutMessage,std::allocator<RBX::StandardOutMessage>>::set_capacity(
    this,
    m_min_capacity);
}


// Address: 0x1877ec0 | Name: _ZN5boost31circular_buffer_space_optimizedINS_10shared_ptrINS_9unordered13unordered_mapINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairIKSA_SD_EEEEEEEENS8_ISN_EEE13rset_capacityERKNS_10cb_details16capacity_controlImEE
void __fastcall boost::circular_buffer_space_optimized<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>>::rset_capacity(
        boost::circular_buffer_space_optimized<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *this,
        const boost::circular_buffer_space_optimized<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::capacity_type *capacity_ctrl)
{
  unsigned __int64 v2; // r8
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::size_type m_size; // rax
  bool v4; // cc
  __int64 v5; // rax
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer m_first; // rcx
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *v7; // rcx
  boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *v8; // rdx
  __int64 v9; // rax
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::pointer m_last; // rdx
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::capacity_type m_min_capacity; // rsi
  unsigned __int64 v12; // rbx
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::size_type v13; // rcx
  unsigned __int64 m_capacity; // rbx
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::iterator last; // [rsp+8h] [rbp-40h] BYREF
  _QWORD first[2]; // [rsp+18h] [rbp-30h] BYREF
  char v17; // [rsp+28h] [rbp-20h] BYREF

  this->m_capacity_ctrl = *capacity_ctrl;
  m_size = this->m_size;
  v4 = m_size <= capacity_ctrl->m_capacity;
  v5 = m_size - capacity_ctrl->m_capacity;
  if ( !v4 )
  {
    m_first = this->m_first;
    first[0] = this;
    first[1] = m_first;
    if ( v5 <= 0 )
    {
      v8 = m_first;
      if ( v5 < 0 )
      {
        v9 = -v5;
        m_last = m_first;
        if ( !m_first )
        {
          m_last = this->m_last;
          m_first = m_last;
        }
        if ( m_last - this->m_buff < v9 )
          v9 -= this->m_end - this->m_buff;
        v8 = &m_first[-v9];
      }
    }
    else
    {
      if ( this->m_end - m_first <= v5 )
        v5 -= this->m_end - this->m_buff;
      v7 = &m_first[v5];
      v8 = 0;
      if ( v7 != this->m_last )
        v8 = v7;
    }
    last.m_buff = this;
    last.m_it = v8;
    boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>>::rerase(
      (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > > *)&v17,
      (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::iterator)__PAIR128__(first, (unsigned __int64)this),
      (boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > >::iterator)__PAIR128__(v2, &last));
  }
  m_min_capacity = this->m_capacity_ctrl.m_min_capacity;
  v12 = this->m_end - this->m_buff;
  if ( m_min_capacity <= v12 )
  {
    v13 = this->m_size;
    while ( v12 / 3 >= v13 )
    {
      v12 >>= 1;
      if ( v12 <= m_min_capacity )
      {
        v12 = this->m_capacity_ctrl.m_min_capacity;
        break;
      }
    }
    m_capacity = v12 << (v13 + v12 / 5 >= v12);
    if ( m_capacity > this->m_capacity_ctrl.m_capacity )
      m_capacity = this->m_capacity_ctrl.m_capacity;
    m_min_capacity = m_capacity;
  }
  boost::circular_buffer<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,std::allocator<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>>::set_capacity(
    this,
    m_min_capacity);
}


// Address: 0x1e232f0 | Name: _ZN5boost31circular_buffer_space_optimizedIN3RBX18NetworkPhysicsData12NetworkFrameENSt3__19allocatorIS3_EEE5eraseENS_10cb_details8iteratorINS_15circular_bufferIS3_S6_EENS8_15nonconst_traitsINS_9container16allocator_traitsIS6_EEEEEESH_
boost::circular_buffer_space_optimized<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *__fastcall boost::circular_buffer_space_optimized<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>::erase(
        boost::circular_buffer_space_optimized<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *this,
        boost::circular_buffer_space_optimized<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::iterator first,
        boost::circular_buffer_space_optimized<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::iterator last)
{
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *m_buff; // r14
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *v4; // r8
  RBX::NetworkPhysicsData::NetworkFrame *v5; // r15
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_end; // rsi
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer v7; // r9
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer v8; // rcx
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer v9; // rdi
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_last; // rbx
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer v11; // rbp
  RBX::NetworkPhysicsData::NetworkFrame *v12; // rax
  __int128 v13; // xmm0
  unsigned __int64 m_size; // rdi
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer m_first; // rcx
  __int64 v16; // r15
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer v17; // rax
  RBX::NetworkPhysicsData::NetworkFrame *v18; // rdx
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer v19; // rax
  __int64 v20; // r15
  __int64 v21; // rcx
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer v22; // rax
  __int64 v23; // r15
  signed __int64 v24; // r12
  unsigned __int64 v25; // rcx
  unsigned __int64 v26; // rsi
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::capacity_type v27; // rsi
  RBX::NetworkPhysicsData::NetworkFrame *v28; // rsi
  boost::circular_buffer_space_optimized<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *result; // rax
  RBX::NetworkPhysicsData::NetworkFrame *v30; // rsi
  RBX::NetworkPhysicsData::NetworkFrame *v31; // rcx
  __int64 v32; // r12
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer v33; // rcx

  m_buff = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > *)first.m_buff;
  v4 = *(boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> > **)first.m_it;
  v5 = *(RBX::NetworkPhysicsData::NetworkFrame **)&first.m_it->replicationRootGuid.index;
  m_end = last.m_buff->m_end;
  if ( v5 == m_end )
  {
    m_size = m_buff->m_size;
    if ( m_size )
      goto LABEL_25;
LABEL_15:
    m_first = 0;
    if ( v5 )
      goto LABEL_26;
LABEL_16:
    v16 = 96 * v4->m_size;
    goto LABEL_30;
  }
  if ( m_end )
  {
    v7 = last.m_buff->m_buff;
    v8 = *(boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer *)&first.m_it->replicationRootGuid.index;
    do
    {
      v9 = v8 + 1;
      if ( &v8[1] == v4->m_end )
        v9 = v4->m_buff;
      m_last = v4->m_last;
      v11 = m_end + 1;
      if ( &m_end[1] == *(boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer *)&v7->replicationRootGuid.index )
        v11 = *(boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer *)&v7->pendingSend;
      v12 = 0;
      if ( v11 != *(boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer *)&v7->pv.position.rotation.elt[1][0] )
        v12 = v11;
      v8->pendingSend = m_end->pendingSend;
      v8->replicationRootGuid.scope.peerId.peerId = m_end->replicationRootGuid.scope.peerId.peerId;
      v8->replicationRootGuid.index = m_end->replicationRootGuid.index;
      v8->pv.position.rotation.elt[2][2] = m_end->pv.position.rotation.elt[2][2];
      v13 = *(_OWORD *)&m_end->pv.position.rotation.elt[0][0];
      *(_OWORD *)&v8->pv.position.rotation.elt[1][1] = *(_OWORD *)&m_end->pv.position.rotation.elt[1][1];
      *(_OWORD *)&v8->pv.position.rotation.elt[0][0] = v13;
      v8->pv.position.translation.z = m_end->pv.position.translation.z;
      *(_QWORD *)&v8->pv.position.translation.x = *(_QWORD *)&m_end->pv.position.translation.x;
      *(_QWORD *)&v8->pv.velocity.rotational.y = *(_QWORD *)&m_end->pv.velocity.rotational.y;
      *(_OWORD *)&v8->pv.velocity.linear.x = *(_OWORD *)&m_end->pv.velocity.linear.x;
      v8->remoteTime.sec = m_end->remoteTime.sec;
      v8 = 0;
      if ( v9 != m_last )
        v8 = v9;
      m_end = v12;
    }
    while ( v12 );
  }
  else
  {
    v8 = *(boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer *)&first.m_it->replicationRootGuid.index;
  }
  v17 = m_buff->m_buff;
  v18 = m_buff->m_last;
  m_size = m_buff->m_size;
  do
  {
    if ( v18 == v17 )
    {
      v18 = m_buff->m_end;
      m_buff->m_last = v18;
    }
    m_buff->m_last = --v18;
    --m_size;
  }
  while ( v18 != v8 );
  m_buff->m_size = m_size;
  if ( v8 == v5 )
    v5 = 0;
  v4 = m_buff;
  if ( !m_size )
    goto LABEL_15;
LABEL_25:
  m_first = m_buff->m_first;
  if ( !v5 )
    goto LABEL_16;
LABEL_26:
  v19 = v4->m_first;
  if ( v19 <= v5 )
  {
    v16 = (char *)v5 - (char *)v19;
LABEL_30:
    v20 = (__int64)v4->m_buff + v16;
    if ( !m_first )
      goto LABEL_28;
LABEL_31:
    v22 = v4->m_first;
    if ( m_first >= v22 )
      v21 = (__int64)v4->m_buff + (char *)m_first - (char *)v22;
    else
      v21 = (__int64)m_first + (char *)v4->m_end - (char *)v22;
    goto LABEL_34;
  }
  v20 = (__int64)v5 + (char *)v4->m_end - (char *)v19;
  if ( m_first )
    goto LABEL_31;
LABEL_28:
  v21 = (__int64)&v4->m_buff[v4->m_size];
LABEL_34:
  v23 = v20 - v21;
  v24 = 0xAAAAAAAAAAAAAAABLL * (v23 >> 5);
  v25 = 0xAAAAAAAAAAAAAAABLL * (((char *)m_buff->m_end - (char *)m_buff->m_buff) >> 5);
  while ( v25 / 3 >= m_size )
  {
    v25 >>= 1;
    v26 = (unsigned __int64)m_buff[1].m_end;
    if ( v25 <= v26 )
      goto LABEL_39;
  }
  v26 = v25;
LABEL_39:
  v27 = v26 << (m_size + v26 / 5 >= v26);
  if ( (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer)v27 > m_buff[1].m_buff )
    v27 = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::capacity_type)m_buff[1].m_buff;
  boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame>>::set_capacity(
    m_buff,
    v27);
  if ( m_buff->m_size )
    v28 = m_buff->m_first;
  else
    v28 = 0;
  result = this;
  if ( v23 <= 0 )
  {
    v31 = v28;
    if ( v23 < 0 )
    {
      v32 = 0x5555555555555555LL * (v23 >> 5);
      v33 = v28;
      if ( !v28 )
      {
        v33 = m_buff->m_last;
        v28 = v33;
      }
      if ( (__int64)(0xAAAAAAAAAAAAAAABLL * (((char *)v33 - (char *)m_buff->m_buff) >> 5)) < v32 )
        v32 -= 0xAAAAAAAAAAAAAAABLL * (((char *)m_buff->m_end - (char *)m_buff->m_buff) >> 5);
      v31 = &v28[-v32];
    }
  }
  else
  {
    if ( (__int64)(0xAAAAAAAAAAAAAAABLL * (((char *)m_buff->m_end - (char *)v28) >> 5)) <= v24 )
      v24 -= 0xAAAAAAAAAAAAAAABLL * (((char *)m_buff->m_end - (char *)m_buff->m_buff) >> 5);
    v30 = v28 + v24;
    v31 = 0;
    if ( v30 != m_buff->m_last )
      v31 = v30;
  }
  this->m_buff = (boost::circular_buffer<RBX::NetworkPhysicsData::NetworkFrame,std::allocator<RBX::NetworkPhysicsData::NetworkFrame> >::pointer)m_buff;
  this->m_end = v31;
  return result;
}


